################################################################################
 R-IN32M4-CL3 TSN Sample Program

                                           2022 Renesas Electronics Corporation 
################################################################################

======================
 Release Notes
======================


--------------------------------------------------------------------------------
 Release V1.0.6 (2022/7/29):
--------------------------------------------------------------------------------
 - Added CC-Link IE Safety Communication Function support
 - Update to protocol version 2.0
 - Added certification class A support

--------------------------------------------------------------------------------
 Release V1.0.5 (2021/12/31):
--------------------------------------------------------------------------------
 - Added SLMP commands sent and received by user programs
 - Added description of expansion unit during CANopen communication
 - Added communication speed setting via SLMP
 - SLMP command execution related user program function added
 - Added R-IN32M4-CL3 driver interface function

--------------------------------------------------------------------------------
 Release V1.0.2 (2020/11/10):
--------------------------------------------------------------------------------
 - Add synchronous cyclic communications.
 - Add CANOpen sample application.
 - Support for new evaluation board : SBEV-RIN32M4CL3

--------------------------------------------------------------------------------
 Release V1.0.1 (2020/4/30):
--------------------------------------------------------------------------------
 - Update of sample application CC-Link IE TSN (Remote station)
 - Update of R18UZ0070JJ R-IN32M4-CL3 User's Manual CC-Link IE TSN

--------------------------------------------------------------------------------
 Release V1.0.0 (2019/11/11):
--------------------------------------------------------------------------------
 - First release.


