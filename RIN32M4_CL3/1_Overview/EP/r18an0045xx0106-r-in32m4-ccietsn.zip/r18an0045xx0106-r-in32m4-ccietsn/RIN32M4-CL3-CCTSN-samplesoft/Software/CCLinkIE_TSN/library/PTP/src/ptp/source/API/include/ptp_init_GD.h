/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_INIT_GD_H__
#define __PTP_INIT_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"










#endif


