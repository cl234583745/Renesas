/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayCommonSM.h"
#include "MDDelayReqReceiveSM.h"
#include "MDDelayReqReceiveSM_1588.h"

#include "ptp_PDRQReceive_1588.h"

#define D_FUNC	0

VOID (*const MDDelayReqReceiveSM_1588_Matrix[DMDDRQR_STATUS_MAX][DMDDRQR_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDDelayReqReceiveSM_01_1588, &MDDelayReqReceiveSM_NP_1588, &MDDelayReqReceiveSM_NP_1588},
	{&MDDelayReqReceiveSM_01_1588, &MDDelayReqReceiveSM_02_1588, &MDDelayReqReceiveSM_00_1588},
	{&MDDelayReqReceiveSM_01_1588, &MDDelayReqReceiveSM_02_1588, &MDDelayReqReceiveSM_00_1588}
};

VOID MDDelayReqReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDDREQRCVSM_EV	enEvt = MDDRQR_E_EVENT_MAX;
	MDDREQRCVSM_ST	enSts = MDDRQR_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDDReqRcvEvent(usEvent, pstPort);
	enSts = GetMDDReqRcvStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDDelayReqReceiveSM_1588 ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDDRQR_STATUS_MAX) && (enEvt != MDDRQR_E_EVENT_MAX))
	{
		(*MDDelayReqReceiveSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDDReqRcvStatus(pstPort);
	printf ("<END  > [%02d]MDDelayReqReceiveSM_1588 ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDDelayReqReceiveSM_00_1588(PORTDATA* pstPort)
{
	MDDREQRVSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDDelayReqReceiveSM_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDDReqRcvSMGlobal(pstPort);

	MDDReqRcv_NotEnable_1588(pstGbl, pstPort);
	SetMDDReqRcvStatus(MDDRQR_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDDelayReqReceiveSM_00_1588::-\n") );

	return;
}

VOID MDDelayReqReceiveSM_01_1588(PORTDATA* pstPort)
{
	MDDREQRVSM_GD*	pstGbl = NULL;
	pstGbl = GetMDDReqRcvSMGlobal(pstPort);

	MDDReqRcv_NotEnable_1588(pstGbl, pstPort);
	SetMDDReqRcvStatus(MDDRQR_NOT_ENABLED, pstPort);
	return;
}

VOID MDDelayReqReceiveSM_02_1588(PORTDATA* pstPort)
{
	MDDREQRVSM_GD*	pstGbl = NULL;
	pstGbl = GetMDDReqRcvSMGlobal(pstPort);

	if (ConMDDelayReqReceive_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82001308);
		MDDReqRcv_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqRcvStatus(MDDRQR_NOT_ENABLED, pstPort);
		return;
	}

	if (SetMDDlyReqEvIngresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_8200130B);
		MDDReqRcv_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqRcvStatus(MDDRQR_NOT_ENABLED, pstPort);
		return;
	}

#ifdef	PTP_USE_TRANS
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		PTP_NOTICE_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82000012);
		MDDReqRcv_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqRcvStatus(MDDRQR_NOT_ENABLED, pstPort);
		return;
	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
		USHORT	usIndex = 0;
		if (JugAndAddMDDelayCorrectionPort(pstPort, &usIndex) == FALSE)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82000013);
		}
		else
		{
			SetMDDelayCorrectionPortIngress(pstPort, usIndex);
		}
		MDDReqRcv_WtFrDReq_1588(pstGbl, pstPort);
		SetMDDReqRcvStatus(MDDRQR_WAITING_FOR_DELAY_REQ, pstPort);
		return;
	}
	else
	{
	}
#endif

	MDDReqRcv_WtFrDReq_1588(pstGbl, pstPort);
	SetMDDReqRcvStatus(MDDRQR_WAITING_FOR_DELAY_REQ, pstPort);

	return;
}


VOID MDDelayReqReceiveSM_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDDReqRcv_NotEnable_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdDelayReq = FALSE;
	return TRUE;
}

BOOL MDDReqRcv_WtFrDReq_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdDelayReq = FALSE;

	if (SetMDDelayReqReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDDelayReqReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ConMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	if (pstSmGbl->blRcvdDelayReq == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_82001309);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdDelayReq == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM_1588, PTP_LOGVE_8200130A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConDlyReq_1588,
		&pstSmGbl->pstRcvdDelayReq->stDlyReq_1588, sizeof(pstPortMD->stConDlyReq_1588));

#ifdef	PTP_USE_TRANS

	tsn_Wrapper_MemCpy(&pstClockGD->stDlyCorctionClock.stConDlyReq_1588,
						&pstSmGbl->pstRcvdDelayReq->stDlyReq_1588,
						sizeof(pstClockGD->stDlyCorctionClock.stConDlyReq_1588));

#endif
	return TRUE;
}
BOOL SetMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDDELAYREQ*				pstDlyReqRcv = &pstPort->stPort_GD.stMdDelayReqRcv;
	PTPMSG_DELAY_REQ_1588*	pstRcvMsg	= &pstSmGbl->pstRcvdDelayReq->stDlyReq_1588;
	TIME_INTERVAL			stA_TInt= {0};

	tsn_Wrapper_MemSet(pstDlyReqRcv, 0, sizeof(MDDELAYREQ));

	pstDlyReqRcv->uchClockNumber			= pstRcvMsg->stHeader.uchDomainNumber;
	ptpAddTInt_TInt((TIME_INTERVAL*)&pstRcvMsg->stHeader.stCorrectionField, &stA_TInt,
				&pstDlyReqRcv->stCorrectionField	);

	pstDlyReqRcv->stSourcePortIdentity	= pstRcvMsg->stHeader.stSrcPortIdentity;
	pstDlyReqRcv->usSequenceId			= pstRcvMsg->stHeader.usSequenceId;
	pstDlyReqRcv->stOriginTimestamp		= pstRcvMsg->stOriginTimestamp;

	return TRUE;
}

BOOL TxMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PDRQRECEIVESM_1588_GD* pstMediaInd_GD = &pstPort->stUn_PSM_GD.stPsm1588_GD.stPDRQReceiveSM_1588_GD;
	pstMediaInd_GD->blRcvdMDDelayReq = TRUE;
	portDelayReqReceive_1588(PTP_EV_FOR_PDLRQRV_RCVMDDLRQ, pstPort);
	return TRUE;
}

#endif
