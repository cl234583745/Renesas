//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _SNMPV3_H
#define _SNMPV3_H

#define scompare(a, b) strcmp((const char *)a, (const char *)b)
#define sncompare(a, b, c) strncmp((const char *)a, (const char *)b, c)
#define slength(a) strlen((const char *)a)
#define scopy(a, b) strcpy((char *)a, (const char *)b)
#define sncopy(a, b, c) strncpy((char *)a, (const char *)b, c)


#include "config.h"

#include "snmpconf.h"

#ifndef USE_BSP
#define USE_BSP 0
#endif

#if USE_BSP == 0
typedef unsigned char uint8;

#ifndef RTOS_ID
#define RTOS_ID 0
#endif

#if !defined(RTOS_ID) || (RTOS_ID != RTOS_MT && RTOS_ID != RTOS_MT6 && RTOS_ID != RTOS_TT && RTOS_ID != RTOS_TT3)
typedef unsigned short uint16;
typedef unsigned long uint32;
typedef unsigned int uint;
#endif

typedef signed char sint8;
typedef signed short sint16;
typedef signed long sint32;
typedef signed int sint;
#ifndef Nprintf
#if defined(WIN32) || defined(UNIX)
#define Nprintf printf
#include <stdio.h>
#else
extern int Nprintf(char *, ...);
#endif
#endif
#endif

#define AUTHENTRAPSENABLED 1
#define AUTHENTRAPSDISABLED 2

#define COLDSTART 0
#define WARMSTART 1
#define LINKDOWN  2
#define LINKUP    3
#define AUTHENTICATIONFAILURE 4
#define EGPNEIGHBORLOSS       5
#define ENTERPRISESPECIFIC    6

#define Integer     0x02
#define String      0x04
#define Null        0x05
#define Identifier  0x06
#define OctetString 0x14
#define Sequence    0x30
#define IpAddress   0x40
#define Counter     0x41
#define Counter32   0x41
#define Gauge       0x42
#define Ticks       0x43
#ifdef USSW_LLDP_MIB 
#define Uinteger32  Gauge 
#else
#define Uinteger32  0x47
#endif

#define GetRequest      0xa0
#define GetNextRequest  0xa1
#define GetResponse     0xa2
#define TrapV1          0xa4
#define SetRequest      0xa3
#define GetBulkRequest  0xa5
#define Trap            0xa7
#define Report          0xa8

#define tooBig              1
#define noSuchName          2
#define badValue            3
#define readOnly            4
#define genErr              5
#define noAccess            6
#define wrongType           7
#define wrongLength         8
#define wrongEncoding       9
#define wrongValue          10
#define noCreation          11
#define inconsistentValue   12
#define resourceUnavailable 13
#define commitFailed        14
#define undoFailed          15
#define authorizationError  16
#define notWritable         17
#define inconsistentName    18

#define IMMED     0x01
#define IMMED2    0x02
#define BASE1     0x03
#define SCALAR    0x04
#define W         0x08
#define SX        0x10
#define NWORDER   0x20
#define CAR       0x40
#define CAW       0x80

#define CHOICE 0


#define noAuthNoPriv    0x00
#define authNoPriv      0x01
#define authPriv        0x03

#define accessAllowed   0
#define noSuchContext   1
#define noGroupName     2
#define noAccessEntry   3
#define noSuchView      4
#define notInView       5

#define AC_READ     0x00
#define AC_WRITE    0x01
#define AC_NOTIFY   0x02

struct COUNTER64
{
    uint32 hi, lo;
};

typedef struct
{
    uint8 nlen, name[MAXOID];
} OID;

typedef struct
{
    OID oid;
    uint8 nix;
    uint16 ix[MAXKEY];
    uint16 len;
} MIBTAB;

typedef struct
{
    OID oid;
#if CHOICE == 0
    uint8 opt;
#else
    uint16 opt;
#endif
    uint8 type;
    sint16 len;
    void *ptr;
} MIBVAR;

typedef struct
{
    const MIBVAR *mvp;
    sint16 (*numvars)(void);
    const MIBTAB *mtp;
    sint16 (*numtabs)(void);
    void (*get)(sint16 varix, sint16 tabix, uint8 **vvptr);
    sint16 (*set)(sint16 varix, sint16 tabix);
    sint16 (*index)(sint16 varix, sint16 index);
    void (*init)(uint16 type);
    sint16 (*check)(sint16 varix, sint16 tabix, const uint8 *inp);
} MIB;

typedef uint8 *TRAP_HOST;

typedef struct
{
    sint16 (*init)(uint8 *ip, uint32 *maxsize, uint8 *name);

    sint16 (*passive_open)(void);
    sint16 (*passive_read)(uint8 *buff, uint16 len);
    sint16 (*passive_write)(const uint8 *buff, uint16 len);
    sint16 (*passive_close)(void);

    sint16 (*active_open)(const uint8 *rhost);
    sint16 (*active_write)(const uint8 *buff, uint16 len);
    sint16 (*active_read)(uint8 *buff, uint16 len);
    sint16 (*active_close)(void);

    uint32 (*time)(void);
} TRANSPORT_MAPPING;

typedef struct
{
    const MIB **mibs;
    uint16 nummibs;
    const TRAP_HOST **thosts;
    uint16 numthosts;
    uint16 trapv, trapt;
    const TRANSPORT_MAPPING *tm;
} AGENT_CONTEXT;


extern sint8 snmp_sint8;
extern uint8 snmp_uint8;
extern sint16 snmp_sint16;
extern uint16 snmp_uint16;
extern sint32 snmp_sint32;
extern uint32 snmp_uint32;



void ussSNMPAgentTask(void);

sint16 ussSNMPAgentInit(const AGENT_CONTEXT *ac);
sint16 ussSNMPAgentCheck(void);
sint16 ussSNMPAgentShut(void);
sint16 ussSNMPAgentTrap(uint8 type, uint8 spec, const uint8 *contextName,
    const uint8 *vbs, uint16 len);

void snmpEncodeID(uint8 **pp, sint16 olen, uint32 val);
uint32 snmpDecodeID(const uint8 **inp);
void snmpEncodeIndex(uint8 **pp, const MIB *mibp, const MIBTAB *mtp,
    sint16 tabix);

sint32 snmpVCompare(const uint8 *op1, sint16 len1, const uint8 *op2, sint16 len2);

sint32 snmpFindOID(const uint8 **retp, const uint8 *base, sint16 osize,
    sint16 onum, const uint8 *valp, sint16 vlen);
sint32 snmpFindIndex(sint16 *tabixp, const MIBTAB *mtp,
    const MIB *mibp, const MIBVAR *mvp,
    const uint8 *reqixname, uint8 reqixlen, uint8 nflag);

sint16 snmpReadLength(const uint8 **pp, uint16 type);
sint16 snmpReadInt(uint32 *outp, sint16 olen, const uint8 **inp, uint16 type);
sint16 snmpReadVal(uint8 *outp, sint16 olen, const uint8 **inp, uint16 type);

void snmpRWriteLength(uint8 **pp, uint16 type, sint16 len);
void snmpRWriteInt(uint8 **pp, uint32 val, uint16 type, sint16 len);
void snmpRWriteVal(uint8 **pp, const uint8 *vp, uint16 type, sint16 len);

sint16 isAccessAllowed(const uint8 *securityName, uint16 securityLevel,
    uint8 type, const uint8 *contextName, const MIBVAR *mvp);

void usm_init(void);
sint16 usm_in(uint8 **outpp, uint16 olen, uint32 msgID,
    uint8 *sname, uint8 slevel, const uint8 **inpp, uint16 ilen,
    const uint8 *wmp, uint16 wmlen);
void usm_pout(uint8 **spdu, uint16 slen, uint8 slevel);
void usm_aout(const uint8 *wmp, uint16 wlen, uint8 *ap, uint8 slevel);

#endif

