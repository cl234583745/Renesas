/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDONESTPTXOPRSET_H__
#define __MDONESTPTXOPRSET_H__

#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID 	OneStepTxOperSettingSM(USHORT usEvent, PORTDATA* pstPort);

OSTOSETTINGSM_GD*	GetOneStpTxOprSetGlobal(PORTDATA* pstPort);
ONESTPTXOPRSET_EV	GetOneStpTxOprSetEvent(USHORT usEvent, PORTDATA* pstPort);
ONESTPTXOPRSET_ST	GetOneStpTxOprSetStatus(PORTDATA* pstPort);
VOID				SetOneStpTxOprSetStatus(ONESTPTXOPRSET_ST enSts, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
