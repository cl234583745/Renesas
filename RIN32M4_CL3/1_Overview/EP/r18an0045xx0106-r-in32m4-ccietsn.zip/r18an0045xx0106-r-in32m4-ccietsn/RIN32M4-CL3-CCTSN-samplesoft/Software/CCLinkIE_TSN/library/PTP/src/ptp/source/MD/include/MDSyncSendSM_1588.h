/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCSENDSM_1588_H__
#define __MDSYNCSENDSM_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDSyncSendSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDSyncSendSM_00_1588(PORTDATA* pstPort);
VOID MDSyncSendSM_01_1588(PORTDATA* pstPort);
VOID MDSyncSendSM_02_1588(PORTDATA* pstPort);
VOID MDSyncSendSM_03_1588(PORTDATA* pstPort);
VOID MDSyncSendSM_04_1588(PORTDATA* pstPort);
VOID MDSyncSendSM_NP_1588(PORTDATA* pstPort);

VOID MDSyncSendSM_02_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncSendSM_03_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncSendSM_04_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
VOID MDSyncSendSM_02_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncSendSM_03_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncSendSM_04_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL MDSynSnd_Initial_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_SyncTwoStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_FollowUp_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_SyncOneStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_StCrectionField_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL MDSynSnd_SyncTwoStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_FollowUp_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_SyncOneStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL SetSyncTwoStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetSyncOneStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL SetSyncTwoStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetSyncOneStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL TxSync_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetFollowUp_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL SetFollowUp_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL TxFollowUp_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
