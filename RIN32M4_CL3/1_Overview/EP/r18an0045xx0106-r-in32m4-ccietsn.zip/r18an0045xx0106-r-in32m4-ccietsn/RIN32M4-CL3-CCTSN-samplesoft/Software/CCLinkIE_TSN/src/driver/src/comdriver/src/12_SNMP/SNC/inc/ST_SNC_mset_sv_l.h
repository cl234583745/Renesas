/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_MSET_SV_L_H_INCLUDED__
#define __ST_SNC_MSET_SV_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_stk_l.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_mmng_sv_l.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_stk_l.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#else
#include "ST_SNC_stk_l.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_mmng_sv_l.h"
#endif
#endif

typedef enum ST_SNC_CounterType_TAG {
	ST_SNC_COUNTER_UCHAR,
	ST_SNC_COUNTER_USHORT,
	ST_SNC_COUNTER_ULONG,
} ST_SNC_CounterType;

typedef struct {
	ST_SNC_CounterType	eType;
	ST_SNC_Mibtype		eMibType;
	NX_ULONG				ulOfst;
	NX_ULONG				ulCountMax;
} ST_SNC_MibCntAttr;

typedef struct ST_SNC_MibAttr_TAG {
	NX_ULONG					ulOfst;
	NX_ULONG					ulSize;
	ST_SNC_MibCntAttr		stCnt;
} ST_SNC_MibAttr;

typedef struct  {
	ST_SNC_MibCntAttr* 		pstCnt;
	NX_VOID*					pvStart;
} ST_SNC_MibCounter;


extern NX_ULONG ulST_SNC_SetMibCntAttr(
	ST_SNC_MibCntAttr*	pstCntAttr,
	ST_SNC_Mibtype		eMibType,
	NX_ULONG				ulOfst,
	NX_ULONG				ulCntSize,
	NX_ULONG				ulCountMax
);

extern NX_ULONG ulST_SNC_CountupMibCnt(ST_SNC_MibCounter* pstCounter);
extern NX_ULONG ulST_SNC_CountdownMibCnt(ST_SNC_MibCounter* pstCounter);
extern NX_ULONG ulST_SNC_GetCounterMibCnt(const ST_SNC_MibCounter* pstCounter, NX_ULONG* pulCounter);

extern NX_ULONG ulST_SNC_SetNetworkConfig(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetDeviceDetail(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetOtherModule(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetStatisticalInfo(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetIpOverlapError(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetIpTopologyError(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetDatalinkError(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetCommTimingError(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
extern NX_ULONG ulST_SNC_SetCurrentError(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pAddr, NX_ULONG ulMibSize);
#ifdef SWPS
#endif

#endif
