/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCSENDSM_GD_H__
#define __MDSYNCSENDSM_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"


typedef enum tagMDSYNCSNDSM_ST {
	MDSYCS_NONE = 0,
	MDSYCS_INITIALIZING,
	MDSYCS_SEND_SYNC_TWO_STEP,
	MDSYCS_SEND_FOLLOW_UP,
	MDSYCS_SEND_SYNC_ONE_STEP,
	MDSYCS_SET_CORRECTION_FIELD,
	MDSYCS_STATUS_MAX

}	MDSYNCSNDSM_ST;
#define	DMDSYCS_STATUS_MAX			6
					
typedef enum tagMDSYNCSNDSM_EV {
	MDSYCS_E_BEGIN = 0,
	MDSYCS_E_FOR_MDSYNCSND_RCVDSYNC,
	MDSYCS_E_RCVD_MDTIMESTAMP_RCV,
	MDSYCS_E_CLOSE,
	MDSYCS_E_EVENT_MAX

}	MDSYNCSNDSM_EV;
#define	DMDSYCS_E_EVENT_MAX			4

typedef struct tagMDSSENDSM_GD
{
	MDSYNCSNDSM_ST		enStsMDSyncSend;
	
	BOOL				blRcvdMDSync;
	
	BOOL				blEgMDTimestampReceive;
	TIMESTAMP			stEgMDTimestampReceive;
#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stEgMDTimestampReceive_Frun;
#endif
	TIMESTAMP			stSyncEgTimestamp;
#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stSyncEgTimestamp_Frun;
#endif

	PTPMSG_SYNC_TWO_STEP_1AS	stTxSyncTwoAS;
	PTPMSG_SYNC_ONE_STEP_1AS	stTxSyncOneAS;
	PTPMSG_FOLLOWUP_1AS			stTxFollowUpAS;
	PTPMSG_SYNC_1588			stTxSync1588;
	PTPMSG_FOLLOWUP_1588		stTxFollowUp1588;



} MDSSENDSM_GD;

#define	MDSSENDSM_GD_SYNC_EG_SYNCTIME	0
#define	MDSSENDSM_GD_SYNC_EG_FREETIME	1

#endif
