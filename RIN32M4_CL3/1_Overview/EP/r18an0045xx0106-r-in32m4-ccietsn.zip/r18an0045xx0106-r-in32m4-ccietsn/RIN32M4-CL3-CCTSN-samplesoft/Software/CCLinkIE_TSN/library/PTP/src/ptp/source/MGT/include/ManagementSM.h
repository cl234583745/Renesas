/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MAGAGEMENTSM_H__
#define __MAGAGEMENTSM_H__

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"

#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"
#include "ptp_LCEntity.h"

#include "ManagementSM_1AS.h"
#include "ManagementSM_1588.h"

#include "ManagementAPI_1588.h"
#if 1
#define	RET_SAMEVAL		(99)
#endif
#define	HEXTOCHAR(a)				\
{									\
	if ((a) < 0xa){					\
		(a) += 0x30;				\
	}								\
	else{							\
		(a)  = ((a) - 0xa) + 0x41;	\
	}								\
};


#ifdef __cplusplus
extern "C" {
#endif

VOID ManagementSM(UCHAR* puchMsg, USHORT usMsgLen, UCHAR uchInterFaceNo);

INT  Management_AS( UCHAR  uchAction, 
					USHORT usParamId_AS, 
					UCHAR  uchDomainNumber, 
					USHORT usPortNumber, 
					UCHAR* puchInfo, 
					USHORT usInfoSize );



INT  Management_1588( UCHAR  uchAction, 
					  USHORT usParamId_1588, 
					  UCHAR  uchDomainNumber, 
					  USHORT usPortNumber, 
					  UCHAR* puchInfo, 
					  USHORT usInfoSize );
CLOCKDATA* GetMGTClockData( UCHAR uchDomainNumber );

PORTDATA*		 GetMGTPortData(CLOCKDATA* pstClockData, USHORT usPortNumber);
MANAGEMENTSM_GD* GetManagementSMGlobal(CLOCKDATA* pstClock);

VOID HextoCharChar(UCHAR* puchChar, UCHAR uchValue);
VOID HextoShortChar(UCHAR* puchChar, USHORT usValue);
VOID HextoLongChar(UCHAR* puchChar, ULONG ulValue);
#if 1
VOID SetDescriptionInfo(CLOCKDATA* pstClockData);
#endif
#ifdef __cplusplus
}
#endif

#endif
