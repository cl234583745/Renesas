/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_detection.h"
#include "nx_frame_common.h"
#include "NMG_ip_addr.h"
#include "ccienx_api.h"
#include "NMG_self_spec.h"
#include "cyclic_address.h"
#include "ccienx_api.h"
#include "tsn_common.h"
#include "USN_api.h"
#include "TSN_api.h"
#include "PHY_api.h"
#include "CYC_common.h"
#include "TXN_main.h"
#include "ccienx_app_supply.h"
#include "PHY_api.h"
#include "ACM_api.h"
#include "CYC_common.h"
#include "ccienx_const.h"

#define	PORTSTS_PORTSHIFT		((NX_UCHAR)4)
#define	PORTSTS_LINKUPMSK		((NX_UCHAR)0x07)
#define	PORTSTS_LINKDOWN		((NX_UCHAR)0x00)
#define	PORTSTS_10MBPS			((NX_UCHAR)0x01)
#define	PORTSTS_100MBPS			((NX_UCHAR)0x02)
#define	PORTSTS_1000MBPS		((NX_UCHAR)0x03)
#define	PORTSTS_FDX_FULL		((NX_UCHAR)0x00)
#define	PORTSTS_FDX_HALF		((NX_UCHAR)0x08)
#define	PORTSTS_FDX_HALF_MIB	((NX_UCHAR)0x04)
#define	PORTSTS_LOOPBACK_MIB	((NX_UCHAR)0x08)




#define	NMG_NEED_ACK_NONE		((NX_ULONG)0)
#define	NMG_NEED_ACK_SEND		((NX_ULONG)1)
#define	SYNC_TMSTMP_ACRCY_CLSB	((NX_ULONG)8)
#define	SYNC_TMSTMP_ACRCY_CLSA	((NX_ULONG)0)
#define MSK_L3BIT				((NX_ULONG)0x07)
#define MSK_L6BIT				((NX_ULONG)0x3F)


NX_ULONG ulNMG_UpdateIPAddress (NX_ULONG, NX_ULONG);
NX_VOID vNMG_ExtractDataFromDetection (NX_USHORT,  NX_VOID*, NX_UCHAR);
NX_VOID ulNMG_ExtDataFromDtc_Pv00 (NX_USHORT,  NX_VOID*);
NX_VOID vNMG_CreateDetectionAck (NX_UCHAR*, NX_USHORT, NX_VOID*, NX_UCHAR);
NX_VOID vNMG_ExtDataFromDtc_Pv01 (NX_USHORT,  NX_VOID*);
NX_VOID vNMG_CreateDetectionAck_Pv00 (NX_UCHAR*, NX_USHORT, NX_VOID*);
NX_VOID vNMG_CreateDetectionAck_Pv01 (NX_UCHAR*, NX_USHORT, NX_VOID*);
NX_VOID vNMG_TransNetSts_RcvDetection ( NX_VOID );
NX_ULONG ulNMG_DecideNeedDetectionAck (NX_USHORT, NX_VOID*, NX_UCHAR);
NX_ULONG ulNMG_DecideNeedDtcAck_Pv00 (NX_USHORT, NX_VOID*);
NX_ULONG ulNMG_DecideNeedDtcAck_Pv01 (NX_USHORT, NX_VOID*);
NX_VOID vNMG_DecideNeedDetectionAck_1 (FRM_DETECTION*, NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_2 (FRM_DETECTION*, NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_3 (NX_USHORT, FRM_DETECTION*, NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_4 (NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_5 (NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_6 (NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_7 (FRM_DETECTION*, NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_8 (NX_ULONG*);
NX_VOID vNMG_DecideNeedDetectionAck_9 (NX_ULONG*);

NX_VOID	vNMG_AnalyzeDetectionStack (NX_UCHAR*, NX_USHORT, NX_VOID*);
NX_VOID	vNMG_AnalyzeDetectionEng (NX_UCHAR*, NX_USHORT, NX_VOID*);

NX_VOID vNMG_AnalyzeDetection (
	NX_UCHAR	*puchSA,
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	FRM_DETECTION	*pstDetection;

	pstDetection = (FRM_DETECTION*)pData;

	if (DETECTION_SRC_STACK == pstDetection->stSendInfo.BIT.b01DetectionSrc) {
		vNMG_AnalyzeDetectionStack(puchSA, usPort, pData);
	}
	else {
		vNMG_AnalyzeDetectionEng(puchSA, usPort, pData);
	}

	return;
}

NX_VOID vNMG_AnalyzeDetectionStack (
	NX_UCHAR	*puchSA,
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	NX_ULONG			ulNeedAck			= (NX_ULONG)NX_OFF;
	FRM_DETECTION		*pstDetection;
	FRM_DETECTIONACK	*pstDetectionAck;
	NX_UCHAR			uchPortLinkSts		= (NX_UCHAR)NX_ZERO;
	NX_ULONG			ulIPAddress			= (NX_ULONG)NX_ZERO;
	NX_ULONG			ulSubnetMsk			= (NX_ULONG)NX_ZERO;
	NX_USHORT			usDuplicateIP_P1	= (NX_USHORT)NX_ZERO;
	NX_USHORT			usDuplicateIP_P2	= (NX_USHORT)NX_ZERO;
	NX_ULONG			ulLinkSts;
	NX_ULONG			ulIPUpdateResult;
	NX_ULONG			ulTsState			= (NX_ULONG)TSSTATE_DI;
	NX_USHORT			usAuthClass 		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	pstDetection = (FRM_DETECTION*)pData;
	if (PROTO_VER01 <= pstDetection->uchProtocolVer) {
		gstNM.stTrnBuf.pstDetectionAck->usDataSize = 
			(NX_USHORT)sizeof(FRM_DETECTIONACK_01) - gstNM.stTrnBuf.pstDetectionAck->usHeaderSize;
	}
	else {
		gstNM.stTrnBuf.pstDetectionAck->usDataSize = 
			(NX_USHORT)sizeof(FRM_DETECTIONACK) - gstNM.stTrnBuf.pstDetectionAck->usHeaderSize;
	}

	pstDetectionAck = (FRM_DETECTIONACK*)(gstNM.stTrnBuf.pstDetectionAck->auchData);

	if (( NETSTS_LINKDOWN		== gstNM.stNet.usNetSts )
	 || ( NETSTS_LINKDOWN_ENR	== gstNM.stNet.usNetSts )) {
		return;
	}

	vPHY_ForceUpdatePhyModeStsReg();
	vPHY_ForceUpdatePhySupCtrlStsReg();
	ulLinkSts = ulPHY_DetectLinkUp(usPort);
	vNMG_ChkLinkDown();

	if ( ulLinkSts == PHY_LINKDOWN ) {
		return;
	}

	ulTsState = ulTXN_GetTsState();
	if (NX_UL_ZERO != (ulTsState & TSSTATE_EXE_MSK)) {
		return;
	}

	if ((NX_ULONG)NX_ON == gstNM.stWaitInfo.ulDtRcvWaitFlg) {
		return;
	}

	if (NM_IP_ADDR_SW_FF != gstAppInfo.stCieNetInfo.usIpSw) {
		if (NM_IP_ADDR_SW_00 != gstAppInfo.stCieNetInfo.usIpSw) {
			ulIPAddress = ulNX_CnvEndianLong(pstDetection->ulIPv4Add_BgEd);
			ulSubnetMsk = ulNX_CnvEndianLong(pstDetection->ulIPv4Subnet_BgEd);
			ulIPAddress = (ulIPAddress & NX_BIT08_31);
			ulIPAddress |= ((NX_ULONG)gstAppInfo.stCieNetInfo.usIpSw & NX_BIT00_07);
			ulIPUpdateResult = ulNMG_UpdateIPAddress(ulIPAddress, ulSubnetMsk);
			if (NX_UL_OK == ulIPUpdateResult) {
				return;
			}
		}
		else {
			ulIPAddress = gstNET.stSelf.ulIPAddress;
			ulSubnetMsk = ulNX_CnvEndianLong(pstDetection->ulIPv4Subnet_BgEd);
			ulIPUpdateResult = ulNMG_UpdateIPAddress(ulIPAddress, ulSubnetMsk);
			if (NX_UL_OK == ulIPUpdateResult) {
				return;
			}
		}
	}
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		if ((NETSTS_INITIAL != gstNM.stNet.usNetSts) && (NETSTS_DLINK != gstNM.stNet.usNetSts)) {
			if (((NETSTS_RCVD_CYCCFG == gstNM.stNet.usNetSts)
			  || (NETSTS_START_CYCSND == gstNM.stNet.usNetSts))
			 && ((NX_ULONG)TSSTATE_EN == ulTsState)) {
				vNX_InitSeqDisconnect();
				gstNM.stNet.usNetSts = NETSTS_LINKDOWN_ENR;
				vCYC_DeactivateCyclicRcv();
				ulTXN_ChangeReqTsState(TSREQ_DI_REQ);
				return;
			}
			else if (FIN_RCVD_NWCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_NWCFG)) {
				vNX_InitSeqDisconnect();
				gstNM.stNet.usNetSts = NETSTS_LINKDOWN_ENR;
				vTsn_StopReq();
				return;
			}
			else {
				vNMG_NetStsInitEnroute();
				gstNM.stNet.usNetSts = NETSTS_INITIAL;
			}
		}
	}
	else {
		
		if ((NETSTS_INITIAL != gstNM.stNet.usNetSts) && (NETSTS_DLINK != gstNM.stNet.usNetSts)) {
			
			if ( (NETSTS_RCVD_CYCCFG == gstNM.stNet.usNetSts)
			  || (NETSTS_START_CYCSND == gstNM.stNet.usNetSts) ) {
				vCYC_DeactivateCyclicClassA();
			}
			vNMG_NetStsInitEnroute();
			gstNM.stNet.usNetSts = NETSTS_INITIAL;
		}
	}

	usDuplicateIP_P1 = usUSN_DuplicatIP((NX_USHORT)NX_PORT1);
	usDuplicateIP_P2 = usUSN_DuplicatIP((NX_USHORT)NX_PORT2);

	if ((NX_US_NG == usDuplicateIP_P1)
	 || (NX_US_NG == usDuplicateIP_P2)) {
		gstNM.uchDuplicateIPFlg = (NX_UCHAR)NX_ON;
	}
	else {
		gstNM.uchDuplicateIPFlg = (NX_UCHAR)NX_OFF;
	}

	ulNeedAck = ulNMG_DecideNeedDetectionAck(usPort, pData, pstDetection->uchProtocolVer);

	if (NMG_NEED_ACK_SEND == ulNeedAck) {
		vNMG_ExtractDataFromDetection(usPort, pData, pstDetection->uchProtocolVer);
		vNMG_CreateDetectionAck(puchSA, usPort, pData, pstDetection->uchProtocolVer);
		uchPortLinkSts = pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_0];
		if ((((NX_USHORT)NX_PORT1 == usPort) && (PORTSTS_LINKDOWN == (uchPortLinkSts & PORTSTS_LINKUPMSK)))
		 || (((NX_USHORT)NX_PORT2 == usPort) && (PORTSTS_LINKDOWN == ((uchPortLinkSts >> PORTSTS_PORTSHIFT) & PORTSTS_LINKUPMSK))))
		{
			return;
		}
		gstNM.stTrnBuf.pstDetectionAck->usPort = usPort;
		vNMG_ReqTrnDetectionAck();
	}
	else {
		vNMG_ExtractDataFromDetection(usPort, pData, pstDetection->uchProtocolVer);
	}

	vNMG_TransNetSts_RcvDetection();

	return;
}

NX_VOID vNMG_AnalyzeDetectionEng (
	NX_UCHAR	*puchSA,
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	FRM_DETECTION		*pstDetection;
	FRM_DETECTIONACK	*pstDetectionAck;
	NX_UCHAR			uchPortLinkSts		= (NX_UCHAR)NX_ZERO;
	NX_USHORT			usDuplicateIP_P1	= (NX_USHORT)NX_ZERO;
	NX_USHORT			usDuplicateIP_P2	= (NX_USHORT)NX_ZERO;
	NX_ULONG			ulLinkSts;

	pstDetection = (FRM_DETECTION*)pData;
	if (PROTO_VER01 <= pstDetection->uchProtocolVer) {
		gstNM.stTrnBuf.pstDetectionAck->usDataSize = 
			(NX_USHORT)sizeof(FRM_DETECTIONACK_01) - gstNM.stTrnBuf.pstDetectionAck->usHeaderSize;
	}
	else {
		gstNM.stTrnBuf.pstDetectionAck->usDataSize = 
			(NX_USHORT)sizeof(FRM_DETECTIONACK) - gstNM.stTrnBuf.pstDetectionAck->usHeaderSize;
	}

	pstDetectionAck = (FRM_DETECTIONACK*)(gstNM.stTrnBuf.pstDetectionAck->auchData);

	vPHY_ForceUpdatePhyModeStsReg();
	vPHY_ForceUpdatePhySupCtrlStsReg();
	ulLinkSts = ulPHY_DetectLinkUp(usPort);
	vNMG_ChkLinkDown();

	if ( ulLinkSts == PHY_LINKDOWN ) {
		return;
	}

	usDuplicateIP_P1 = usUSN_DuplicatIP((NX_USHORT)NX_PORT1);
	usDuplicateIP_P2 = usUSN_DuplicatIP((NX_USHORT)NX_PORT2);

	if ((NX_US_NG == usDuplicateIP_P1)
	 || (NX_US_NG == usDuplicateIP_P2)) {
		gstNM.uchDuplicateIPFlg = (NX_UCHAR)NX_ON;
	}
	else {
		gstNM.uchDuplicateIPFlg = (NX_UCHAR)NX_OFF;
	}

	vNMG_CreateDetectionAck(puchSA, usPort, pData, pstDetection->uchProtocolVer);
	uchPortLinkSts = pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_0];
	if ((((NX_USHORT)NX_PORT1 == usPort) && (PORTSTS_LINKDOWN == (uchPortLinkSts & PORTSTS_LINKUPMSK)))
	 || (((NX_USHORT)NX_PORT2 == usPort) && (PORTSTS_LINKDOWN == ((uchPortLinkSts >> PORTSTS_PORTSHIFT) & PORTSTS_LINKUPMSK))))
	{
		return;
	}
	gstNM.stTrnBuf.pstDetectionAck->usPort = usPort;
	vNMG_ReqTrnDetectionAck();

	return;
}

NX_ULONG ulNMG_UpdateIPAddress (
	NX_ULONG	ulIPAddressMngMst,
	NX_ULONG	ulSubnetMaskMngMst
)
{
	NX_IPADDR_INFO	stIPAddrInfo;
	NX_ULONG	ulIPAddressNew	=	NX_ZERO;
	NX_ULONG	ulSubnetMaskNew	=	NX_ZERO;
	NX_ULONG	ulNeedUpdate	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulChkResult		=	NX_UL_NG;
	
	ulIPAddressNew = ulIPAddressMngMst;
	
	ulSubnetMaskNew = ulSubnetMaskMngMst;
	
	if (   (gstNET.stSelf.ulIPAddress != ulIPAddressNew)
		|| (gstNET.stSelf.ulSubnetMask != ulSubnetMaskNew) ) {
		
		ulNeedUpdate = (NX_ULONG)NX_ON;
		
	}
	
	if (ulNeedUpdate == (NX_ULONG)NX_ON) {
		
		ulChkResult = ulNX_ChkIpAddress(ulIPAddressNew, ulSubnetMaskNew);
		if (ulChkResult == NX_IP_OK) {
			
			gstNET.stSelf.ulIPAddress = ulIPAddressNew;
			gstNET.stSelf.ulSubnetMask = ulSubnetMaskNew;
			vUSN_ReInit();
			stIPAddrInfo.ulIPAddress = ulIPAddressNew;
			stIPAddrInfo.ulSubnetMask = ulSubnetMaskNew;
			vNX_UpdateIPAddress(&stIPAddrInfo);
		}
		else {
			vNMG_SetNmgErrDt(EVENTCODE_SET_IP_ERR, (NX_USHORT*)&DetailErrorTbl_Detection[NMG_IDX_ERR_PARAM_000]);
		}
	}
	
	return ulChkResult;
}

NX_VOID vNMG_ExtractDataFromDetection (
	NX_USHORT		usPort,
	NX_VOID			*pvData,
	NX_UCHAR		uchProtcolVer
)
{
	ulNMG_ExtDataFromDtc_Pv00(usPort, pvData);
	if (PROTO_VER01 <= uchProtcolVer) {
		vNMG_ExtDataFromDtc_Pv01(usPort, pvData);
	}
	
	return;
}

NX_VOID ulNMG_ExtDataFromDtc_Pv00 (
	NX_USHORT		usPort,
	NX_VOID	*pData
)
{
	FRM_DETECTION	*pstDetection;
	NX_USHORT		usHopCount;
	
	pstDetection = (FRM_DETECTION*)pData;
	vNX_CopyMemory(gstNET.stMngMst.auchMacAddr, pstDetection->auchMngMac, NX_MAC_ADDR_SIZE);
	
	gstNET.stMngMst.ulIPAddress = ulNX_CnvEndianLong(pstDetection->ulIPv4Add_BgEd);
	
	vNX_CopyMemory(gstNM.stDetection[usPort].auchMacAddrPrevSnd, pstDetection->auchPreviousNodeMac, NX_MAC_ADDR_SIZE);
	
	gstNM.stDetection[usPort].usPortPrevSnd = (NX_USHORT)(pstDetection->uchPreviousNodePort - (NX_UCHAR)NX_ONE);
	
	usHopCount = usNX_CnvEndianShort(pstDetection->usHopCount_BgEd);
	vNMG_SetHopCount(usPort, usHopCount);

	gstNET.stMngMst.usFixed		= (NX_USHORT)NX_ON;
	
	return;
}

NX_VOID vNMG_ExtDataFromDtc_Pv01 (
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	return;
}

NX_UCHAR uchNMG_CreatePortLinkStsData (
	NX_USHORT	usForceUpdate
)
{
	NX_UCHAR	uchRet				=	NX_ZERO;
	NX_USHORT	usPort				=	(NX_USHORT)NX_PORT1;
	NX_UCHAR	auchData[NX_PORT_SIZE];
	NX_ULONG	ulSupCtrl_Sts		=	NX_ZERO;
	NX_ULONG	ulLinkSts			=	NX_ZERO;
	NX_ULONG	ulFDX				=	NX_ZERO;
	NX_ULONG	ulSpeed				=	NX_ZERO;
	
	if ((NX_USHORT)NX_ON == usForceUpdate) {
		vPHY_ForceUpdatePhyModeStsReg();
		vPHY_ForceUpdatePhySupCtrlStsReg();
	}
	
	for (usPort = (NX_USHORT)NX_PORT1; usPort < (NX_USHORT)NX_PORT_SIZE; usPort++) {
		
		auchData[usPort] = NX_ZERO;
		
		ulSupCtrl_Sts = gstNET.stPhyReg[usPort].ulSupCtrl_Sts;
		
		ulLinkSts	=	ulPHY_DetectLinkUp(usPort);
		ulFDX		=	ulSupCtrl_Sts & PHYREG_SUPCTRLSTS_BIT_FDX;
		ulSpeed		=	ulSupCtrl_Sts & PHYREG_SUPCTRLSTS_BIT_SPEED;
		if (ulLinkSts == PHY_LINKDOWN) {
			
			auchData[usPort] |= PORTSTS_LINKDOWN;
		}
		else {
			
			if (ulSpeed == PHYREG_SUPCTRLSTS_SPEED_1000BASE_T) {
				auchData[usPort] |= PORTSTS_1000MBPS;
			}
			else if (ulSpeed == PHYREG_SUPCTRLSTS_SPEED_100BASE_TX) {
				auchData[usPort] |= PORTSTS_100MBPS;
			}
			else {
				auchData[usPort] |= PORTSTS_10MBPS;
			}
			
			if (ulFDX == PHYREG_SUPCTRLSTS_FDX_FULL) {
				auchData[usPort] |= PORTSTS_FDX_FULL;
			}
			else {
				auchData[usPort] |= PORTSTS_FDX_HALF;
			}
			
		}
	}
	
	uchRet = (auchData[NX_PORT2] << PORTSTS_PORTSHIFT) | auchData[NX_PORT1];
	
	return uchRet;
}

NX_UCHAR uchNMG_CreatePortLinkStsData_Mib (
	NX_USHORT	usForceUpdate
)
{
	NX_UCHAR	uchRet				=	NX_ZERO;
	NX_USHORT	usPort				=	(NX_USHORT)NX_PORT1;
	NX_UCHAR	auchData[NX_PORT_SIZE];
	NX_ULONG	ulSupCtrl_Sts		=	NX_ZERO;
	NX_ULONG	ulLinkSts			=	NX_ZERO;
	NX_ULONG	ulFDX				=	NX_ZERO;
	NX_ULONG	ulSpeed				=	NX_ZERO;
	NX_ULONG	ulTopology			=	(NX_ULONG)NX_ZERO;
	
	if ((NX_USHORT)NX_ON == usForceUpdate) {
		vPHY_ForceUpdatePhyModeStsReg();
		vPHY_ForceUpdatePhySupCtrlStsReg();
	}
	
	for (usPort = (NX_USHORT)NX_PORT1; usPort < (NX_USHORT)NX_PORT_SIZE; usPort++) {
		
		auchData[usPort] = NX_ZERO;
		
		ulSupCtrl_Sts = gstNET.stPhyReg[usPort].ulSupCtrl_Sts;
		
		ulLinkSts	=	ulPHY_DetectLinkUp(usPort);
		ulFDX		=	ulSupCtrl_Sts & PHYREG_SUPCTRLSTS_BIT_FDX;
		ulSpeed		=	ulSupCtrl_Sts & PHYREG_SUPCTRLSTS_BIT_SPEED;
		
		if (ulLinkSts == PHY_LINKDOWN) {
			ulTopology = ulNX_GetTopology();
			if (ulTopology == NX_TOPOLOGY_RING) {
				auchData[usPort] |= PORTSTS_LOOPBACK_MIB;
			}
			auchData[usPort] |= PORTSTS_LINKDOWN;
		}
		else {
			
			if (ulSpeed == PHYREG_SUPCTRLSTS_SPEED_1000BASE_T) {
				auchData[usPort] |= PORTSTS_1000MBPS;
			}
			else if (ulSpeed == PHYREG_SUPCTRLSTS_SPEED_100BASE_TX) {
				auchData[usPort] |= PORTSTS_100MBPS;
			}
			else {
				auchData[usPort] |= PORTSTS_10MBPS;
			}
			
			if (ulFDX == PHYREG_SUPCTRLSTS_FDX_FULL) {
				auchData[usPort] |= PORTSTS_FDX_FULL;
			}
			else {
				auchData[usPort] |= PORTSTS_FDX_HALF_MIB;
			}
		}
	}
	
	uchRet = (auchData[NX_PORT2] << PORTSTS_PORTSHIFT) | auchData[NX_PORT1];
	
	return uchRet;
}

NX_VOID vNMG_CreateDetectionAck (
	NX_UCHAR		*puchSA,
	NX_USHORT		usPort,
	NX_VOID			*pvData,
	NX_UCHAR		uchProtocolVer
)
{
	vNMG_CreateDetectionAck_Pv00(puchSA, usPort, pvData);
	if (PROTO_VER01 <= uchProtocolVer) {
		vNMG_CreateDetectionAck_Pv01(puchSA, usPort, pvData);
	}
	return;
}

NX_VOID vNMG_CreateDetectionAck_Pv00 (
	NX_UCHAR		*puchSA,
	NX_USHORT		usPort,
	NX_VOID			*pData
)
{
	FRM_DETECTIONACK	*pstDetectionAck;
	NX_UCHAR			uchRelaySetting;
	ACK_TSN_INFO		stTsnInfo;
	FRM_DETECTION		*pstDetection;
	NX_UCHAR			uchDetectionSrc;
	NX_USHORT			usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	pstDetection = (FRM_DETECTION*)pData;
	uchDetectionSrc = pstDetection->stSendInfo.BIT.b01DetectionSrc;
	
	pstDetectionAck = (FRM_DETECTIONACK*)(gstNM.stTrnBuf.pstDetectionAck->auchData);
	
	vTSN_getACKINFO(&stTsnInfo);
	vNX_CopyMemory(	pstDetectionAck->auchDA,
					puchSA,
					NX_MAC_ADDR_SIZE);
	
	vNX_CopyMemory(	pstDetectionAck->auchSA,
					gstAppInfo.stEthInfo.auchMacAddress,
					NX_MAC_ADDR_SIZE);
	
	pstDetectionAck->usEtherType_BgEd = ETHERTYPE_CCIE_BGED;
	
	pstDetectionAck->uchFrameType = FRAMETYPE_DETECTIONACK;
	
	pstDetectionAck->stNodeType.uchNodeType = NX_ZERO;
	pstDetectionAck->stNodeType.BIT.b04StationKind = gstAppInfo.stCieDevInfo.uchStationType;
	pstDetectionAck->stNodeType.BIT.b01EquipFunc   = NX_OFF;
	
	pstDetectionAck->uchDetectionAckVer = DETECTIONACK_VER00;
	
	pstDetectionAck->uchProtocolVer = PROTOCOL_VER;
	
	if ( NM_IP_ADDR_SW_FF == gstAppInfo.stCieNetInfo.usIpSw ) {
		pstDetectionAck->uchIPaddr4Oct = (NX_UCHAR)NX_ZERO;
	}
	else {
		pstDetectionAck->uchIPaddr4Oct = (NX_UCHAR)(gstAppInfo.stCieNetInfo.usIpSw & (NX_USHORT)NX_BIT00_07);
	}
	
	vNX_CopyMemory(	pstDetectionAck->auchSrcMACAdd,
					gstAppInfo.stEthInfo.auchMacAddress,
					NX_MAC_ADDR_SIZE);
	
	if (DETECTION_SRC_STACK == uchDetectionSrc) {
		vNX_CopyMemory(	pstDetectionAck->auchPreviousNodeMac,
						gstNM.stDetection[usPort].auchMacAddrPrevSnd,
						NX_MAC_ADDR_SIZE);
	}
	else {
		vNX_CopyMemory(	pstDetectionAck->auchPreviousNodeMac,
						pstDetection->auchPreviousNodeMac,
						NX_MAC_ADDR_SIZE);
	}
	
	if (DETECTION_SRC_STACK == uchDetectionSrc) {
		pstDetectionAck->uchPreviousNodePort = (NX_UCHAR)(gstNM.stDetection[usPort].usPortPrevSnd + (NX_USHORT)NX_ONE);
	}
	else {
		pstDetectionAck->uchPreviousNodePort = pstDetection->uchPreviousNodePort;
	}
	
	pstDetectionAck->uchDetectRcvPort = (NX_UCHAR)(usPort + (NX_USHORT)NX_ONE);
	
	pstDetectionAck->uchMyPorts = gstAppInfo.stCieDevInfo.uchNumberOfPort;
	
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		pstDetectionAck->uchAuthenticationClass = AUTHENTICATION_CLASS_B;
	}
	else {
		pstDetectionAck->uchAuthenticationClass = AUTHENTICATION_CLASS_A;
	}

	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_0] = uchNMG_CreatePortLinkStsData((USHORT)NX_OFF);
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_1] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_2] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_3] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_4] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_5] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_6] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_7] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_8] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_9] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_10] = NX_ZERO;
	pstDetectionAck->auchMyPortLinkStatus[NX_MY_PORT_LINK_STATUS_IDX_11] = NX_ZERO;
	
	uchRelaySetting = (NX_UCHAR)((gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1 << NX_SHIFT0)
						+ (gstNM.stNetworkConfigMain.stRelaySetting.b01LoopPort1 << NX_SHIFT2)
						+ (gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2 << NX_SHIFT4)
						+ (gstNM.stNetworkConfigMain.stRelaySetting.b01LoopPort2 << NX_SHIFT6));
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_0] = uchRelaySetting;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_1] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_2] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_3] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_4] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_5] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_6] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_7] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_8] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_9] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_10] = NX_ZERO;
	pstDetectionAck->auchMyPortFilterStatus[NX_MY_PORT_FILTER_STATUS_IDX_11] = NX_ZERO;
	
	vNX_CopyMemory(	pstDetectionAck->auchCurrentManager,
					gstNET.stMngMst.auchMacAddr,
					NX_MAC_ADDR_SIZE);
	
	pstDetectionAck->ulIPv4Add_BgEd = ulNX_CnvEndianLong(gstNET.stSelf.ulIPAddress);
	pstDetectionAck->ulIPv4Subnet_BgEd = ulNX_CnvEndianLong(gstNET.stSelf.ulSubnetMask);
	pstDetectionAck->ulIPv4Gateway_BgEd = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Add_BgEd[NX_IPV6_IDX_0] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Add_BgEd[NX_IPV6_IDX_1] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Add_BgEd[NX_IPV6_IDX_2] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Add_BgEd[NX_IPV6_IDX_3] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Gateway_BgEd[NX_IPV6_IDX_0] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Gateway_BgEd[NX_IPV6_IDX_1] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Gateway_BgEd[NX_IPV6_IDX_2] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->aulIPv6Gateway_BgEd[NX_IPV6_IDX_3] = ulNX_CnvEndianLong(NX_ZERO);
	pstDetectionAck->uchIPv6SubPfx = NX_ZERO;
	
	pstDetectionAck->stPerformance.BIT.b01ThroughPut = THROUGHPUT;
	pstDetectionAck->stPerformance.BIT.b01IpAddDup = gstNM.uchDuplicateIPFlg;
	
	pstDetectionAck->uchPriority1 = gstAppInfo.stPtpInfo.uchPriority1;
	
	pstDetectionAck->ulClockQuality_BgEd = ulNX_CnvEndianLong(gstAppInfo.stPtpInfo.stClockQuality.ulData);
	
	pstDetectionAck->uchPriority2 = gstAppInfo.stPtpInfo.uchPriority2;
	
	pstDetectionAck->stSyncType.uchSyncType = stTsnInfo.uchSyncType;
	
	pstDetectionAck->chPdelayResTime = stTsnInfo.chPdealyResTime;
	
	pstDetectionAck->chDelaySetTime = stTsnInfo.chDelaySetTime;
	
	pstDetectionAck->chAnnounceRelayTime = stTsnInfo.chAnnounceRelayTime;
	
	pstDetectionAck->usDeviceVer_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usDeviceVersion);
	
	pstDetectionAck->usVendorCode_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usVendorCode);
	
	pstDetectionAck->ulModelCode_BgEd = ulNX_CnvEndianLong(gstAppInfo.stCieDevInfo.ulModelCode);
	
	pstDetectionAck->usExpansionModelCode_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usExModelCode);
	
	pstDetectionAck->usDeviceType_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usDeviceType);
	
	if ((NX_LIB_MODE_FASTIO2 == gstAppInfo.stLibInfo.usLibMode) ||
		(NX_LIB_MODE_FASTIO3 == gstAppInfo.stLibInfo.usLibMode)) {
		pstDetectionAck->ulMemAddBitStoM_BgEd = ulNX_CnvEndianLong(gaulMemAdd_RX[NX_LIB_MODE_FASTIO]);
	}
	else {
		pstDetectionAck->ulMemAddBitStoM_BgEd = ulNX_CnvEndianLong(gaulMemAdd_RX[gstAppInfo.stLibInfo.usLibMode]);
	}
	pstDetectionAck->ulMemAddWordStoM_BgEd = ulNX_CnvEndianLong(MEMADD_RWR);
#ifdef SAFETY_PDU_ENABLE
	pstDetectionAck->ulMemAddSafeStoM = ulNX_CnvEndianLong(MEMADD_SPDUX);
#endif

	pstDetectionAck->ulMemAddBitMtoS_BgEd = ulNX_CnvEndianLong(gaulMemAdd_RY[gstAppInfo.stLibInfo.usLibMode]);
	pstDetectionAck->ulMemAddWordMtoS_BgEd = ulNX_CnvEndianLong(MEMADD_RWW);
#ifdef SAFETY_PDU_ENABLE
	pstDetectionAck->ulMemAddSafeMtoS = ulNX_CnvEndianLong(MEMADD_SPDUY);
#endif
	pstDetectionAck->ulMemAddStateNotif = ulNX_CnvEndianLong(MEMADD_STSW);

	pstDetectionAck->usCycSizeBitStoM_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeRX);
	pstDetectionAck->usCycSizeWordStoM_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeRWr);
#ifdef SAFETY_PDU_ENABLE
	pstDetectionAck->usCycSizeSafeStoM = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeSpdux);
#endif
	pstDetectionAck->usCycSizeBitMtoS_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeRY);
	pstDetectionAck->usCycSizeWordMtoS_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeRWw);
#ifdef SAFETY_PDU_ENABLE
	pstDetectionAck->usCycSizeSafeMtoS = usNX_CnvEndianShort(gstAppInfo.stCieNetInfo.usDefaultSizeSpduy);
#endif
	pstDetectionAck->usCycSizeStateNotif = usNX_CnvEndianShort(NX_STSW_DATA_SIZE);
	
	pstDetectionAck->auchRsv1[0]	= NX_ZERO;
	pstDetectionAck->auchRsv3[0]	= NX_ZERO;
	pstDetectionAck->auchRsv3[1]	= NX_ZERO;
	pstDetectionAck->auchRsv4[0]	= NX_ZERO;
	pstDetectionAck->auchRsv4[1]	= NX_ZERO;
	pstDetectionAck->auchRsv5[0]	= NX_ZERO;
	pstDetectionAck->auchRsv5[1]	= NX_ZERO;
	pstDetectionAck->auchRsv6[0]	= NX_ZERO;
	pstDetectionAck->auchRsv6[1]	= NX_ZERO;
	pstDetectionAck->auchRsv7[0]	= NX_ZERO;
	pstDetectionAck->auchRsv8[0]	= NX_ZERO;
	pstDetectionAck->auchRsv9[0]	= NX_ZERO;
	pstDetectionAck->auchRsv9[1]	= NX_ZERO;
	pstDetectionAck->auchRsv10[0]	= NX_ZERO;
	pstDetectionAck->auchRsv10[1]	= NX_ZERO;
	
	pstDetectionAck->stFunction.uchFunction = gstNM.uchSelfFunction & (NX_UCHAR)MSK_L6BIT;
	
	pstDetectionAck->stOptionInfo.uchOptionInfo = gstAppInfo.stCieDevInfo.uchOption & (NX_UCHAR)MSK_L3BIT;

	pstDetectionAck->usStationSubIdNum = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usNumOfSubID);
	
	pstDetectionAck->usStationMode_BgEd = usNX_CnvEndianShort(gstAppInfo.stCieDevInfo.usStationMode);
	
	pstDetectionAck->ulBlank = NX_ZERO;
	
	return;
}

NX_VOID vNMG_CreateDetectionAck_Pv01 (
	NX_UCHAR		*puchSA,
	NX_USHORT		usPort,
	NX_VOID			*pData
)
{
	FRM_DETECTIONACK_01	*pstDetectionAck;
	FRM_DETECTION_01	*pstDetection;
	ACK_TSN_INFO		stTsnInfo;
	NX_USHORT			usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	pstDetectionAck = (FRM_DETECTIONACK_01*)(gstNM.stTrnBuf.pstDetectionAck->auchData);

	pstDetectionAck->uchDetectionAckVer = DETECTIONACK_VER01;

	pstDetectionAck->uchProtocolVer = PROTOCOL_VER;
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		pstDetectionAck->uchTimeSlotNum = (NX_UCHAR)NX_TIMESLOT_SIZE;
	}
	else {
		pstDetectionAck->uchTimeSlotNum = (NX_UCHAR)NX_ZERO;
	}
	
	pstDetectionAck->stPerformance.BIT.b01FullRate = NX_ON;
	pstDetectionAck->stPerformance.BIT.b01Error = NX_OFF;
	
	pstDetectionAck->uchCyclicTokenResponseTime = (NX_UCHAR)gstAppInfo.stAuthInfo.usCycResTime;
	
	vTSN_getACKINFO_VER1(&stTsnInfo);
	pstDetectionAck->stSyncType.uchSyncType = stTsnInfo.uchSyncType;
	
	pstDetectionAck->chPdelayResTime = stTsnInfo.chPdealyResTime;
	
	pstDetectionAck->chDelaySetTime = stTsnInfo.chDelaySetTime;
	
	pstDetectionAck->chAnnounceRelayTime = stTsnInfo.chAnnounceRelayTime;

	pstDetectionAck->stFunction.uchFunction = gstNM.uchSelfFunction;

	pstDetectionAck->stOptionInfo.uchOptionInfo = gstAppInfo.stCieDevInfo.uchOption;

	pstDetectionAck->stFunction2.uchFunction2 = gstNM.uchSelfFunction2;

	pstDetectionAck->stRelayInfo.uchRelayInfo = RELAY_INFO;
	pstDetectionAck->usRelayBufSize = usNX_CnvEndianShort(RELAY_BUF_SIZE);
	
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		pstDetectionAck->ulSyncTimeAcc_BgEd = ulNX_CnvEndianLong(SYNC_TMSTMP_ACRCY_CLSB);
	}
	else{
		pstDetectionAck->ulSyncTimeAcc_BgEd = ulNX_CnvEndianLong(SYNC_TMSTMP_ACRCY_CLSA);
	}
	
	pstDetection = (FRM_DETECTION_01*)(pData);
	vNX_CopyMemory(&pstDetectionAck->auchOriginMac[0], &pstDetection->auchOriginMac, NX_MAC_ADDR_SIZE);
	
	pstDetectionAck->auchOriginSenderPort = pstDetection->auchOriginSenderPort;
	
	pstDetectionAck->auchRsv12[0] = (NX_UCHAR)NX_ZERO;
	return;
}

NX_VOID vNMG_TransNetSts_RcvDetection ( NX_VOID )
{
	if (gstNM.stNet.usNetSts == NETSTS_INITIAL) {
		
		gstNM.stNet.usStatusFinish |= FIN_RCVD_DETECTION;
		gstNM.stNet.usNetSts = NETSTS_RCVD_DETECTION;
		vNMG_ClrNmgErr();
	}
	
	return;
}

NX_ULONG ulNMG_DecideNeedDetectionAck (
	NX_USHORT		usPort,
	NX_VOID			*pvData,
	NX_UCHAR		uchProtocolVer
)
{
	NX_ULONG	ulNeed	=	NMG_NEED_ACK_NONE;
	NX_ULONG	ulNeed_Pv01	=	NMG_NEED_ACK_NONE;
	
	ulNeed = ulNMG_DecideNeedDtcAck_Pv00(usPort, pvData);
	if (PROTO_VER01 <= uchProtocolVer) {
		ulNeed_Pv01 = ulNMG_DecideNeedDtcAck_Pv01(usPort, pvData);
		
		if ( ulNeed_Pv01 > ulNeed ) {
			ulNeed = ulNeed_Pv01;
		}
	}
	
	return ulNeed;
}

NX_ULONG ulNMG_DecideNeedDtcAck_Pv00 (
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	FRM_DETECTION	*pstDetection;
	NX_ULONG		ulNeed	=	NMG_NEED_ACK_NONE;
	
	pstDetection = (FRM_DETECTION*)pData;
	
	vNMG_DecideNeedDetectionAck_7(pstDetection, &ulNeed);
	
	vNMG_DecideNeedDetectionAck_1(pstDetection, &ulNeed);
	
	vNMG_DecideNeedDetectionAck_2(pstDetection, &ulNeed);
	
	vNMG_DecideNeedDetectionAck_3(usPort, pstDetection, &ulNeed);
	
	vNMG_DecideNeedDetectionAck_4(&ulNeed);
	
	vNMG_DecideNeedDetectionAck_5(&ulNeed);
	
	vNMG_DecideNeedDetectionAck_6(&ulNeed);
	
	vNMG_DecideNeedDetectionAck_8(&ulNeed);
	
	vNMG_DecideNeedDetectionAck_9(&ulNeed);
	
	return ulNeed;
}

NX_ULONG ulNMG_DecideNeedDtcAck_Pv01 (
	NX_USHORT	usPort,
	NX_VOID		*pData
)
{
	return NMG_NEED_ACK_NONE;
}

NX_VOID vNMG_DecideNeedDetectionAck_1 (
	FRM_DETECTION	*pstDetection,
	NX_ULONG		*pulNeed
)
{
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		if (gstNET.stMngMst.usFixed == (NX_USHORT)NX_OFF) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_2 (
	FRM_DETECTION	*pstDetection,
	NX_ULONG		*pulNeed
)
{
	NX_LONG	lCompareResult	=	NX_NG;
	
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		lCompareResult = lNX_CompareMemory(	pstDetection->auchMngMac,
											gstNET.stMngMst.auchMacAddr,
											NX_MAC_ADDR_SIZE);
		
		if (lCompareResult == NX_NG) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_3 (
	NX_USHORT			usPort,
	FRM_DETECTION		*pstDetection,
	NX_ULONG			*pulNeed
)
{
	NX_LONG	lCompareResult	=	NX_NG;
	
	if ( NX_NOTIFY_FLG_ON == gstNM.ausNotifyLinkDownFlg[usPort])	{
		vNX_FillMemory((NX_VOID *)gstNM.stDetection[usPort].auchMacAddrPrevSnd, (NX_CHAR)NX_ZERO, (NX_ULONG)NX_MAC_ADDR_SIZE);
		gstNM.stDetection[usPort].usPortPrevSnd = NX_US_ZERO;
		gstNM.ausNotifyLinkDownFlg[usPort] = NX_NOTIFY_FLG_OFF;
	}
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		lCompareResult = lNX_CompareMemory(	gstNM.stDetection[usPort].auchMacAddrPrevSnd,
											pstDetection->auchPreviousNodeMac,
											NX_MAC_ADDR_SIZE);
		if (lCompareResult == NX_NG) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
		
		if (gstNM.stDetection[usPort].usPortPrevSnd != (NX_USHORT)(pstDetection->uchPreviousNodePort - (NX_UCHAR)NX_ONE)) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_4 (
	NX_ULONG			*pulNeed
)
{
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_5 (
	NX_ULONG		*pulNeed
)
{
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		if (gstNET.stCtrlMst.usFixed == (NX_USHORT)NX_OFF) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_6 (
	NX_ULONG		*pulNeed
)
{
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		if (gstNM.stNet.usNetSts == NETSTS_INITIAL) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_7 (
	FRM_DETECTION	*pstDetection,
	NX_ULONG		*pulNeed
)
{
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		if (FORCEACKTRN_EN == pstDetection->stOptionFlag.BIT.b01ForceAckTrnFlg) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_8 (
	NX_ULONG		*pulNeed
)
{
	NX_ULONG	ulLinkSts_P1	=	PHY_LINKDOWN;
	NX_ULONG	ulLinkSts_P2	=	PHY_LINKDOWN;
	
	ulLinkSts_P1 = ulPHY_DetectLinkUp((NX_USHORT)NX_PORT1);
	ulLinkSts_P2 = ulPHY_DetectLinkUp((NX_USHORT)NX_PORT2);
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		if ((gstNM.stPrevValue.ulLinkUpSts_P1 != ulLinkSts_P1) ||
			(gstNM.stPrevValue.ulLinkUpSts_P2 != ulLinkSts_P2)) {
			*pulNeed = (NX_ULONG)NX_ON;
		}
	}
	else {
	}
	gstNM.stPrevValue.ulLinkUpSts_P1 = ulLinkSts_P1;
	gstNM.stPrevValue.ulLinkUpSts_P2 = ulLinkSts_P2;

	return;
}

NX_VOID vNMG_DecideNeedDetectionAck_9 (
	NX_ULONG		*pulNeed
)
{
	
	if (NMG_NEED_ACK_NONE == *pulNeed) {
		
		if (gstNM.uchDuplicateIPFlg != gstNM.stPrevValue.uchDuplicateIPFlg) {
			*pulNeed = NMG_NEED_ACK_SEND;
		}
	}
	else {
	}
	gstNM.stPrevValue.uchDuplicateIPFlg = gstNM.uchDuplicateIPFlg;
	
	return;
}




#ifdef SAFETY_PDU_ENABLE
#endif
#ifdef SAFETY_PDU_ENABLE
#endif
#ifdef SAFETY_PDU_ENABLE
#endif
#ifdef SAFETY_PDU_ENABLE
#endif











/*[EOF]*/
