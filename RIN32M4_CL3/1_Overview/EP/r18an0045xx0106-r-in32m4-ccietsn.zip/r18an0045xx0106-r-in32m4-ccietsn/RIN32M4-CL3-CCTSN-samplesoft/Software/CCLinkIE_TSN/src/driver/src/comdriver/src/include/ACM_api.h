/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ACM_API_H_INCLUDE__
#define __ACM_API_H_INCLUDE__

#include "nx_common.h"

NX_VOID		vACM_Init(NX_VOID);
NX_USHORT	usACM_GetAuthenticationClass (NX_VOID);

typedef struct tagACM_CLSA_INFO {
	NX_ULONG		ulNonRcvCnt;
	NX_ULONG		ulNonRcvTimeOutCnt;
	NX_USHORT		usDiscEnableNum;
	NX_USHORT		usRsv2;
	NX_ULONG		ulReadEnableSide;
	NX_ULONG		ulLatestWriteSide;
	NX_USHORT		usDescriptor0;
	NX_USHORT		usDescriptor1;
} ACM_CLSA_INFO;

NX_EXTERN	ACM_CLSA_INFO	gstClassAInfo;

#endif
/*[EOF]*/
