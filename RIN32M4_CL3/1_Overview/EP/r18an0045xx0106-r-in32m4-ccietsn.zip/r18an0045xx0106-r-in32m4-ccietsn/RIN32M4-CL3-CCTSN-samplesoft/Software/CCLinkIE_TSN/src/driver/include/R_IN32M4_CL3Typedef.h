/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3TYPEDEF_H__
#define __R_IN32M4_CL3TYPEDEF_H__

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
/* Data type and size */
typedef int					ERRCODE;

#define	VOID				void

/* typedef for callback fucntion */
typedef	unsigned long (* R_IN_IP_FILTERING_FUNCTION)(unsigned long ulIPAddress);
typedef unsigned long (* R_IN_CALLBACK_FUNCTION)(unsigned long ulParam1, unsigned long ulParam2);

#endif

/*** EOF ***/
