/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "CYC_common.h"
#include "ccienx_api.h"
#include "nx_frame_common.h"
#include "nx_frame_cyclic.h"
#include "CYC_api.h"
#include "cyclic_address.h"
#include "ccienx_app_supply.h"
#include "networkram.h"
#include "NMG_common.h"

#define	TMCNT_SWSD	((NX_ULONG)(1000 - 1))
#define	TMCNT_SWSD2	((NX_ULONG)(13000 - 1))

NX_VOID vCYC_InitCyclicData_COM (NM_TRN_SPLD*, SPHEAD_SS_S*, NX_USHORT);

NX_VOID vCYC_Init ( NX_VOID )
{
	vNX_FillMemory32(&gstCycCtrl, NX_ZERO, sizeof(CYC_CTRL) / sizeof(NX_ULONG));
	vNX_FillMemory16(&gstPreCycTrnAddr, NX_ZERO, sizeof(CYC_TRN_ADDR) / sizeof(NX_USHORT));
	vNX_FillMemory16(&gstCycTrnAddr,    NX_ZERO, sizeof(CYC_TRN_ADDR) / sizeof(NX_USHORT));
	vNX_FillMemory16(&gstCycRcvAddr,    NX_ZERO, sizeof(CYC_RCV_ADDR) / sizeof(NX_USHORT));

	vCYC_InitStsW();
	
	vNX_timer_set(TMID_CYC_RX_SWSD,	TMCK_10NS,		TMCNT_SWSD);
	
	vNX_timer_set(TMID_CYC_RX_SWSD2,	TMCK_10NS,		TMCNT_SWSD2);
	
	return;
}

NX_VOID vCYC_InitCyclicData_EthHead (
	NX_USHORT			usDiscNo,
	NM_TRN_SPLD			*pstInfo,
	NX_USHORT			usFrameNum
)
{
	CYC_SS_HEAD			*pstHead		= (CYC_SS_HEAD*)AUTOTRNHEAD_AHBADDR_BASE;
	CYC_SS_HEAD			*pstHead2;
	NX_USHORT			usFrmLoop		= NX_ZERO;
	CYC_SS_HEAD_VLAN	*pstHeadVlan2	= (CYC_SS_HEAD_VLAN*)AUTOTRNHEAD_AHBADDR_BASE;
	CYC_SS_HEAD_VLAN	*pstHeadVlan	= (CYC_SS_HEAD_VLAN*)AUTOTRNHEAD_AHBADDR_BASE;
	NX_ULONG			ulVlanResult;
	NX_ULONG			ulVlanFlg;
	
	ulVlanResult = ulNMG_GetVlanTag(&ulVlanFlg);
	if (NX_UL_VLAN_OK == ulVlanResult) {
		if ( TRNDISC_NO0 == usDiscNo ) {
			pstHeadVlan		= (CYC_SS_HEAD_VLAN*)ETHRHEADAD_CYCSNDDISC_NO0;
		}
		else {
			pstHeadVlan		= (CYC_SS_HEAD_VLAN*)ETHRHEADAD_CYCSNDDISC_NO1;
		}
		
		vNX_CnvEndian6Byte(&pstHeadVlan->stEth.auchMacDA[0], &pstInfo->auchDestFrame[0]);
		vNX_CopyMemory((NX_VOID*)&pstHeadVlan->stEth.auchMacSA[0], (NX_VOID*)&gstAppInfo.stEthInfo.auchMacAddress[0], (NX_ULONG)NX_MAC_ADDR_SIZE);
		
		pstHeadVlan->stEth.usEtherType		= ETHERTYPE_CCIE_BGED;
		
		pstHeadVlan->stCcie.uchFrameType	= FRAMETYPE_CYC_SS;
		pstHeadVlan->stCcie.uchCycNum		= (NX_UCHAR)NX_ZERO;
		if ((NX_UCHAR)NX_ON == pstInfo->uchCycleIgnoreBit) {
			pstHeadVlan->stCcie.uchCycNum	|= CYC_IGNORE_MSK_ON;
		}
		else {
			pstHeadVlan->stCcie.uchCycNum	&= CYC_IGNORE_MSK_OFF;
		}
		pstHeadVlan->stCcie.uchDesIP3		= pstInfo->uchDestSubPayload3;
		pstHeadVlan->stCcie.uchDesIP4		= pstInfo->uchDestSubPayload4;
		pstHeadVlan->stCcie.usRsv			= (NX_USHORT)NX_ZERO;
		pstHeadVlan->stEth.ulVlanTag		= ulNX_CnvEndianLong(ulVlanFlg);

		for (usFrmLoop = NX_ONE; usFrmLoop<usFrameNum; usFrmLoop++) {
			pstHeadVlan2 = (CYC_SS_HEAD_VLAN*)((ULONG)pstHeadVlan + (NX_CYCDATAZISE_HEAD * usFrmLoop));

			vNX_CopyMemory(pstHeadVlan2, pstHeadVlan, sizeof(CYC_SS_HEAD_VLAN));
		}
	}
	else {

	if ( TRNDISC_NO0 == usDiscNo ) {
		pstHead		= (CYC_SS_HEAD*)ETHRHEADAD_CYCSNDDISC_NO0;
	}
	else {
		pstHead		= (CYC_SS_HEAD*)ETHRHEADAD_CYCSNDDISC_NO1;
	}
	
	vNX_CnvEndian6Byte(&pstHead->stEth.auchMacDA[0], &pstInfo->auchDestFrame[0]);
	vNX_CopyMemory((NX_VOID*)&pstHead->stEth.auchMacSA[0], (NX_VOID*)&gstAppInfo.stEthInfo.auchMacAddress[0], (NX_ULONG)NX_MAC_ADDR_SIZE);
	
	pstHead->stEth.usEtherType		= ETHERTYPE_CCIE_BGED;
	
	pstHead->stCcie.uchFrameType	= FRAMETYPE_CYC_SS;
	pstHead->stCcie.uchCycNum		= (NX_UCHAR)NX_ZERO;
	if ((NX_UCHAR)NX_ON == pstInfo->uchCycleIgnoreBit) {
		pstHead->stCcie.uchCycNum	|= CYC_IGNORE_MSK_ON;
	}
	else {
		pstHead->stCcie.uchCycNum	&= CYC_IGNORE_MSK_OFF;
	}
	pstHead->stCcie.uchDesIP3		= pstInfo->uchDestSubPayload3;
	pstHead->stCcie.uchDesIP4		= pstInfo->uchDestSubPayload4;
	pstHead->stCcie.usRsv			= (NX_USHORT)NX_ZERO;

	for (usFrmLoop = NX_ONE; usFrmLoop<usFrameNum; usFrmLoop++) {
		pstHead2 = (CYC_SS_HEAD*)((ULONG)pstHead + (NX_CYCDATAZISE_HEAD * usFrmLoop));

		vNX_CopyMemory(pstHead2, pstHead, sizeof(CYC_SS_HEAD));
	}
	}

	return;
}

NX_VOID vCYC_InitCyclicData_COM (
	NM_TRN_SPLD		*pstInfo,
	SPHEAD_SS_S	*pstSpdHead,
	NX_USHORT	usAppDataLen
)
{
	CYC_SPHEAD_INFO		stInfo;
	
	
	vNX_FillMemory32(pstSpdHead, NX_ZERO, sizeof(SPHEAD_SS_S) / sizeof(NX_ULONG));
	
	pstSpdHead->uchSrcIP3			= (NX_UCHAR)((gstNET.stSelf.ulIPAddress & NX_BIT08_15) >> NX_SHIFT8);
	pstSpdHead->uchSrcIP4			= (NX_UCHAR)(gstNET.stSelf.ulIPAddress & NX_BIT00_07);
	
	stInfo.usData = NX_ZERO;

	stInfo.BITS.b01CtrlFlg			= (NX_USHORT)NX_ON;

	stInfo.BITS.b01TimingErr		= NX_ZERO;
	
	stInfo.BITS.b11AppDataLength	= usAppDataLen;
	
	pstSpdHead->usInfo_BgEd			= usNX_CnvEndianShort(stInfo.usData);
	
	pstSpdHead->stTxAppErr.BITS.uchTranTxInfo	= (NX_UCHAR)NX_ZERO;
	
	pstSpdHead->stTxAppErr.BITS.usSeqNum_BgEd	= usNX_CnvEndianShort(pstInfo->usSeqNum);
	
	pstSpdHead->stTxAppErr.BITS.uchAppErrStateFW = (NX_UCHAR)NX_ZERO;
	
	pstSpdHead->ucHotLineInfo[0]	= (NX_UCHAR)NX_ZERO;
	pstSpdHead->ucHotLineInfo[1]	= (NX_UCHAR)NX_ZERO;
	pstSpdHead->ucHotLineInfo[2]	= (NX_UCHAR)NX_ZERO;

	return;
}

NX_VOID vCYC_InitCyclicData (
	NM_TRN_SPLD		*pstInfo
)
{
	NX_USHORT		usIndex		= NX_ZERO;
	SPHEAD_SS_S		stSpdHead;

	if (pstInfo->uchDataExist == (NX_UCHAR)NX_ON) {
		vCYC_InitCyclicData_COM(pstInfo, &stSpdHead, pstInfo->usSize);
		stSpdHead.ulMemoryAddress_BgEd = ulNX_CnvEndianLong(pstInfo->ulRcvMemmoryAddr);

		for (usIndex = (NX_USHORT)TRN_SIDE_A; usIndex < TRN_SIDE_SIZE; usIndex++) {
			
			vNX_CopyMemory32(	(NX_VOID*)(gaulBaseAddrTbl[usIndex] + pstInfo->ulSndDataAddr),
								(NX_VOID*)&stSpdHead,
								sizeof(SPHEAD_SS_S) / sizeof(NX_ULONG)
							);
			
		}
	}

	return;
}

/*[EOF]*/
