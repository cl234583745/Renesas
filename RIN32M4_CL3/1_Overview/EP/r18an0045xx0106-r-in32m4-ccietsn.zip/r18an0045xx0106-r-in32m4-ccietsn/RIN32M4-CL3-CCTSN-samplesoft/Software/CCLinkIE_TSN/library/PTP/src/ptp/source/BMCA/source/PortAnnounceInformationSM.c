/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_bmca.h"

#include "ptp_tsn_Wrapper.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"
#include "ptp_LogRecord.h"

#include "PortAnnounceCountSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortStateSelectionSM.h"
#include "PortAnnounceTransmitSM.h"
#include "PortAnnounceReceiveSM.h"
#include "PortAnnounceInformationExtSM.h"

#include "ptp_PSSSend.h"

#define D_FUNC	0

#ifdef	PTP_USE_BMCA

VOID (*const PortAnnoInfSM_Matrix[PAINFORMATIONSM_ST_MAX][PAINFORMATIONSM_EV_MAX] )(PORTDATA * pstPortData) =
{
	{&PortAnnounceInformation_01,  &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01,  &PortAnnounceInformation_02,  &PortAnnounceInformation_03,	&PortAnnounceInformation_nop,
		&PortAnnounceInformation_15,  &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01,  &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_04, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_11,	&PortAnnounceInformation_nop, &PortAnnounceInformation_04,
		&PortAnnounceInformation_09,  &PortAnnounceInformation_09,	&PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_12,
			&PortAnnounceInformation_13,  &PortAnnounceInformation_14,	&PortAnnounceInformation_08 , &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00},
	{&PortAnnounceInformation_01, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, 
		&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop,
			&PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_nop, &PortAnnounceInformation_00}
};

PAINFORMATIONSM_EV	enAnnEvent;
VOID	portAnnounceInformationSM(USHORT usEvent, PORTDATA *pstPort)
{
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstSMGlb = &(pstPort->stPAInformationSM_GD);

	enAnnEvent = GetportAnnInformationEvent(usEvent);

	if (enAnnEvent < PINF_EV_EVENT_MAX)
	{
		if (enAnnEvent == PINF_EV_SYNCRECEIPTTIMEOUT)
		{
			if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
			{
				return;
			}
			if (pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_SLAVE)
			{
				return;
			}


		}
		if (pstSMGlb->enStatus < PINFSM_STATUS_MAX)
		{
			if(enAnnEvent == PINF_EV_ANNOUNCERECEIPTTIMEOUT)
			{
				pstPort->stPortBMC_GD.pstTOAnnounceReceipt = NULL;

				if((pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_SLAVE) &&
					(pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_PASSIVE))
				{
					if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
					{
						if(pstSMGlb->enStatus != PINFSM_DISABLED)
						{
							return;
						}
					}
					else
					{
						return;
					}
				}


			}
			(*PortAnnoInfSM_Matrix[pstSMGlb->enStatus][enAnnEvent])(pstPort);
			return;
		}
	}
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000003);
	return;
}

PAINFORMATIONSM_EV	GetportAnnInformationEvent(USHORT usEvent)
{
	PAINFORMATIONSM_EV	enEvt;
	switch (usEvent)
	{
		case (USHORT)PTP_EV_BEGIN:
			enEvt = PINF_EV_BEGIN;
			break;
		case (USHORT)PTP_EV_PER_PORT_RCVDMSG:
			enEvt = PINF_EV_PER_PORT_RCVDMSG;
			break;
		case (USHORT)PTP_EV_ASCAPABLE:
			enEvt = PINF_EV_ASCAPABLE;
			break;
		case (USHORT)PTP_EV_SELECTED_PORT:
			enEvt = PINF_EV_SELECTED_PORT;
			break;
		case (USHORT)PTP_EV_ANNOUNCERECEIPTTIMEOUT:
			enEvt = PINF_EV_ANNOUNCERECEIPTTIMEOUT;
			break;
		case (USHORT)PTP_EV_SYNCRECEIPTTIMEOUT:
			enEvt = PINF_EV_SYNCRECEIPTTIMEOUT;
			break;
		case (USHORT)PTP_EV_QUALIFICATIONTIMEOUT:
			enEvt = PINF_EV_QUALIFICATIONTIMEOUT;
			break;
		case (USHORT)PTP_EV_RCVDINFO_SUPERMASTERINFO:
			enEvt = PINF_EV_RCVDINFO_SUPERMASTER;
			break;
		case (USHORT)PTP_EV_RCVDINFO_REPEDMASTERINFO:
			enEvt = PINF_EV_RCVDINFO_REPEDMASTER;
			break;
		case (USHORT)PTP_EV_RCVINF_INFERIORMASTERINF:
			enEvt = PINF_EV_RCVINF_INFERIORMASTER;
			break;
		case (USHORT)PTP_EV_RCVDINFO_OTHERINF:
			enEvt = PINF_EV_RCVDINFO_OTHERINF;
			break;
		case (USHORT)PTP_EV_CLOSE:
			enEvt = PINF_EV_CLOSE;
			break;
		default:
			enEvt = PINF_EV_EVENT_MAX;
		break;
	}
	return(enEvt);
}

VOID	PortAnnounceInformation_00(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	USHORT			usPortNumber;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PortAnnounceInformation_00+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	pstPortBmcGd->blRcvdMsg  = FALSE;
	pstPortBmcGd->enInfoIs = DISABLED;
	pstBmcGd->blReselect[usPortNumber] = FALSE;
	pstBmcGd->blSelected[usPortNumber] = FALSE;

	pstSMGlb->enStatus = PINFSM_NONE;

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInformation_00::-\n") );

	return;
}

VOID	PortAnnounceInformation_01(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	USHORT			usPortNumber;
	PORT_1AS_DS*	port1ASDS;
	USCALEDNS		stCurrentTime;

#ifdef	PTP_USE_IEEE1588
	USCALEDNS		stTimeoutTimeWork;
	USCALEDNS		stTimeoutTimeWork2;
	CHAR			chA;
	BOOL			blRet;
#endif

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInformation_01::+\n") );

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);
	port1ASDS	 = &(pstPort->stPort_1AS_DS);

	tsn_Wrapper_MemSet (&pstPortBmcGd->stMasterPriority,0xFF,sizeof(PRIORITY_VECT));
	tsn_Wrapper_MemSet (&pstPortBmcGd->stPortPriority,0xFF,sizeof(PRIORITY_VECT));

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		tsn_Wrapper_MemSet (&stTimeoutTimeWork,0,sizeof(USCALEDNS));
		stTimeoutTimeWork.ulNsec_lsb = CONST10_9;
		chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;
		blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &stTimeoutTimeWork2);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}
		tsn_Wrapper_MemCpy (&pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &stTimeoutTimeWork2, sizeof(USCALEDNS));

		if (!IS_OD_BC_1588(pstPort->pstClockData))
		{
			ptp_dbg_msg( D_FUNC, ("PortAnnounceInformation_01::-\n") );
			return;
		}
		else
		{
			if (!(pstBmcGd->blExternalPortConfiguration))
			{
				pstPortBmcGd->blRcvdMsg  = FALSE;
				pstSMGlb->stAnnounceReceiptTimeoutTime = stCurrentTime; 
				pstPortBmcGd->enInfoIs = DISABLED;
				pstBmcGd->blReselect[usPortNumber] = TRUE;
				pstBmcGd->blSelected[usPortNumber] = FALSE;

				pstSMGlb->enStatus = PINFSM_DISABLED;
				if (pstPort->stPort_GD.blPortValid == TRUE)
				{
					pstPort->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_DESIGNATED_ENABLED; 
				}

				PortStateSelection_03(pstPort);

				pstSMGlb->enStatus = PINFSM_DISABLED;

				if (pstPort->stPort_GD.blPortValid == TRUE)
				{

				if (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)
				{
					makeSystemPrioVector(pstPort);
					PortAnnounceInformation_15(pstPort);
				}
				else
				{
					set_announce_tmo_1588(pstPort);
					makeSystemPrioVector(pstPort);
				}
				}
			}

			ptp_dbg_msg( D_FUNC, ("PortAnnounceInformation_01::-\n") );

			return;
		}
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE802_1
		makeSystemPrioVector(pstPort);
		if (!(pstBmcGd->blExternalPortConfiguration))
		{
			pstPortBmcGd->blRcvdMsg  = FALSE;
			pstSMGlb->stAnnounceReceiptTimeoutTime = stCurrentTime; 
			pstPortBmcGd->enInfoIs = DISABLED;
			pstBmcGd->blReselect[usPortNumber] = TRUE;
			pstBmcGd->blSelected[usPortNumber] = FALSE;

			pstSMGlb->enStatus = PINFSM_DISABLED;

			PortStateSelection_03(pstPort);

			if(port1ASDS->blAsCapable)
			{
				pstBmcGd->blReselect[usPortNumber] = TRUE;
				pstBmcGd->blSelected[usPortNumber] = FALSE;
				pstSMGlb->enStatus = PINFSM_AGED;
				pstPortBmcGd->enInfoIs = AGED;
				PortStateSelection_03(pstPort);

				if((pstBmcGd->blSelected[usPortNumber])&&(pstPortBmcGd->blUpdtInfo==TRUE))
				{
					PortAnnounceInformation_04(pstPort);
				}

				exec_PortAnnInfo04_allPort(pstPort);
			}
		}
#endif
	}

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInformation_01::-\n") );

	return;
}

VOID	PortAnnounceInformation_02(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	USHORT			usPortNumber;
	USCALEDNS		stCurrentTime;


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if (!(pstBmcGd->blExternalPortConfiguration))
	{
		pstPortBmcGd->blRcvdMsg  = FALSE;
		pstSMGlb->stAnnounceReceiptTimeoutTime = stCurrentTime; 
		pstPortBmcGd->enInfoIs = DISABLED;
		pstBmcGd->blReselect[usPortNumber] = TRUE;
		pstBmcGd->blSelected[usPortNumber] = FALSE;


		PortStateSelection_03(pstPort);

		exec_PortAnnInfo04_allPort(pstPort);

	}
	return;
}

VOID	PortAnnounceInformation_03(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	USHORT			usPortNumber;
	USCALEDNS		stCurrentTime;


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if (!(pstBmcGd->blExternalPortConfiguration))
	{
		pstPortBmcGd->blRcvdMsg  = FALSE;
		pstSMGlb->stAnnounceReceiptTimeoutTime = stCurrentTime; 
		pstPortBmcGd->enInfoIs = DISABLED;
		pstBmcGd->blReselect[usPortNumber] = TRUE;
		pstBmcGd->blSelected[usPortNumber] = FALSE;

		if ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) && (IS_OD_BC_1588(pstPort->pstClockData)))
		{
#ifdef	PTP_USE_IEEE1588
			pstSMGlb->enStatus = PINFSM_AGED;

			pstPortBmcGd->enInfoIs = AGED;

			PortStateSelection_03(pstPort);

			exec_PortAnnInfo04_allPort(pstPort);
#endif
		}
		else
		{
			if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
			{
#ifdef	PTP_USE_IEEE802_1
				if(pstPort->stPort_1AS_DS.blAsCapable==TRUE)
				{
					pstSMGlb->enStatus = PINFSM_AGED;

					pstPortBmcGd->enInfoIs = AGED;

					PortStateSelection_03(pstPort);

					exec_PortAnnInfo04_allPort(pstPort);
				}
#endif
			}
		}
	}
	return;
}

VOID	PortAnnounceInformation_04(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	if (pstPortBmcGd->blUpdtInfo == TRUE)
	{

		if ((pstSMGlb->enStatus == PINFSM_CURRENT) || (pstSMGlb->enStatus == PINFSM_AGED))
		{
			pstSMGlb->enStatus = PINFSM_UPDATE;

			PortAnnounceInformation_05(pstPort);
		}

	}
	return;
}

VOID	PortAnnounceInformation_05(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);
	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);

	pstPortBmcGd->stPortPriority = pstPortBmcGd->stMasterPriority;
	pstPortBmcGd->usPortStepsRemoved = pstBmcGd->usMasterStepsRemoved;

	pstPortBmcGd->blUpdtInfo = FALSE;
	pstPortBmcGd->enInfoIs = MINE;
	pstPortBmcGd->blNewInfo = TRUE;

	pstSMGlb->enStatus = PINFSM_CURRENT;

	if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		set_announce_tmo_1588(pstPort);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE802_1
		set_announce_tmo_AS(pstPort);
#endif
	}

	PortAnnounceTransmit_05(pstPort);

	return;
}

VOID	PortAnnounceInformation_06(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;
	PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr;

	USHORT		usPortNumber;

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	pstRcvdAnnouncePtr = pstPortBmcGd->pstRcvdAnnouncePtr;

	pstPortBmcGd->stPortPriority = pstSMGlb->stMessagePriority;
	pstPortBmcGd->usPortStepsRemoved = pstRcvdAnnouncePtr->usStepsRemoved;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	recordOtherAnnounceInfo(pstPortBmcGd);

	if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		set_announce_tmo_1588(pstPort);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE802_1
		set_announce_tmo_AS(pstPort);
		set_sync_tmo_AS(pstPort);
#endif
	}

	pstPortBmcGd->enInfoIs = RECEIVED;
	pstBmcGd->blReselect[usPortNumber] = TRUE;
	pstBmcGd->blSelected[usPortNumber] = FALSE;
	pstPortBmcGd->blRcvdMsg = FALSE;
	pstPortBmcGd->pstRcvdAnnouncePtr = NULL;

	PortStateSelection_03(pstPort);
	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		updateTimepropertiesDS_AS(pstPort);
#endif
	}

	pstSMGlb->enStatus = PINFSM_CURRENT;
	exec_PortAnnInfo04_allPort(pstPort);

	return;
}

VOID	PortAnnounceInformation_07(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;
	USCALEDNS	stCurrentTime;
#ifdef	PTP_USE_IEEE802_1
	BOOL		blRet;
#endif


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	recordOtherAnnounceInfo(pstPortBmcGd);

	if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		set_announce_tmo_1588(pstPort);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE802_1
		blRet = ptpAddUSNs_USNs( &stCurrentTime, &pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &pstSMGlb->stAnnounceReceiptTimeoutTime);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

		if (pstPortBmcGd->pstTOAnnounceReceipt)
		{
			blRet = (BOOL)ptp_TimeOut_Can(pstPortBmcGd->pstTOAnnounceReceipt);
			if (blRet)
			{
				PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000023);
			}
			pstPortBmcGd->pstTOAnnounceReceipt = NULL;
		}

		pstPortBmcGd->pstTOAnnounceReceipt = ptp_TimeOut_Req(
								(USHORT)PTP_EV_ANNOUNCERECEIPTTIMEOUT,
								(VOID*)pstPort,
								pstSMGlb->stAnnounceReceiptTimeoutTime,
								(CallBackFunc)&portAnnounceInformationSM);
		if (pstPortBmcGd->pstTOAnnounceReceipt == NULL)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000021);
		}
		
		updateTimepropertiesDS_AS(pstPort);
#endif
	}

	pstPortBmcGd->blRcvdMsg = FALSE;
	pstPortBmcGd->pstRcvdAnnouncePtr = FALSE;

	pstSMGlb->enStatus = PINFSM_CURRENT;

	return;
}

VOID	PortAnnounceInformation_08(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	pstPortBmcGd->blRcvdMsg = FALSE;
	pstPortBmcGd->pstRcvdAnnouncePtr = NULL;

	pstSMGlb->enStatus = PINFSM_CURRENT;

	return;
}

VOID	PortAnnounceInformation_09(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	CLOCK_GD	*pstClockGd;
	USHORT		usPortNumber;
	BMC_1588_GD	*pstBmc1588Gd;

	pstClockGd = &(pstPort->pstClockData->stClock_GD);
	pstBmc1588Gd = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if ((pstPortBmcGd->enInfoIs == RECEIVED) 
		&& (pstClockGd->blGmPresent) 
			&& (pstPortBmcGd->blUpdtInfo == FALSE) 
				&& (pstPortBmcGd->blRcvdMsg == FALSE))
	{
		if (pstClockGd->enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
		{
#ifdef	PTP_USE_IEEE1588
			if ((pstBmc1588Gd->uchExtSelectedState[usPortNumber] != PS_EX_PRE_MASTER) &&
								 (pstBmc1588Gd->uchExtSelectedState[usPortNumber] != PS_EX_MASTER))
			{
				releaseAnnounceForForeignMaster(pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstForeignBestClock);
				pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstForeignBestClock->usAnnMsgCnt = 0U;
				IncPortAnnReceiptTimeoutCount(enAnnEvent, pstPort);
				pstPortBmcGd->enInfoIs = AGED;
				pstBmcGd->blReselect[usPortNumber] = TRUE;
				pstBmcGd->blSelected[usPortNumber] = FALSE;
				pstPort->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_ANNOUNCE_RECEIPT_TIMEOUT_EXPIRES;
				PortStateSelection_03(pstPort);
				exec_PortAnnInfo04_allPort(pstPort);
			}
			set_announce_tmo_1588(pstPort);
#endif
		}
		else
		{
			IncPortAnnReceiptTimeoutCount(enAnnEvent, pstPort);
			pstPortBmcGd->enInfoIs = AGED;
			pstBmcGd->blReselect[usPortNumber] = TRUE;
			pstBmcGd->blSelected[usPortNumber] = FALSE;

			PortStateSelection_03(pstPort);
			exec_PortAnnInfo04_allPort(pstPort);
			if (enAnnEvent == PINF_EV_SYNCRECEIPTTIMEOUT)
			{
				set_sync_tmo_AS(pstPort);
			}
			else
			{
				set_announce_tmo_AS(pstPort);
			}

		}
	}
	else
	{
		if(pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == ENUM_PORTSTATE_SLAVE)
		{
			IncPortAnnReceiptTimeoutCount(enAnnEvent, pstPort);
		}
	}
	return;
}

VOID	PortAnnounceInformation_10(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	CLOCK_GD	*pstClockGd;
	BMC_1588_GD	*pstBmc1588Gd;
	USHORT		usPortNumber;

	pstClockGd = &(pstPort->pstClockData->stClock_GD);
	pstBmc1588Gd = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if (pstClockGd->enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		if (pstBmc1588Gd->uchExtSelectedState[usPortNumber] != PS_EX_PRE_MASTER)
		{
			pstPortBmcGd->enInfoIs = AGED;
			pstBmcGd->blReselect[usPortNumber] = TRUE;
			pstBmcGd->blSelected[usPortNumber] = FALSE;

			PortStateSelection_03(pstPort);
			exec_PortAnnInfo04_allPort(pstPort);

		}
#endif
	}
	return;
}

VOID	PortAnnounceInformation_11(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;
#ifdef	PTP_USE_IEEE1588
	BOOL		blRet;
	PORTDATA*	pstPortWork;
#endif

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	if (pstPortBmcGd->blUpdtInfo == FALSE)
	{
		pstSMGlb->uchRcvdInfo = rcvInfo(pstPort->stPortBMC_GD.pstRcvdAnnouncePtr, pstPort);

		pstSMGlb->enStatus = PINFSM_RECEIVE;
	}
	else
	{
		return;
	}


	if ( (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) &&
				(pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER) )
	{
#ifdef	PTP_USE_IEEE1588
		blRet = cmpPortRcvAndGm(pstPort);

		if(blRet == TRUE)
		{
			for (pstPortWork = pstPort->pstClockData->pstPortData; pstPortWork; pstPortWork = pstPortWork->pstNextPortDataPtr)
			{
				pstPortWork->stPortBMC_GD.blUpdtInfo = TRUE;
			}
		}
#endif
	}

	if (pstSMGlb->uchRcvdInfo == RCVINF_RT_SuperiorMasterInfo)
	{
		PortAnnounceInformation_12(pstPort);
	}
	else if (pstSMGlb->uchRcvdInfo == RCVINF_RT_RepeatedMasterInfo)
	{
		PortAnnounceInformation_13(pstPort);
	}
	else
	{
		PortAnnounceInformation_14(pstPort);
	}
	pstPortBmcGd->blRcvdMsg = FALSE;
	pstPortBmcGd->pstRcvdAnnouncePtr = FALSE;
	return;
}

VOID	PortAnnounceInformation_12(PORTDATA *pstPort)
{
	PORT_GD		*pstPordGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPordGd	 = &(pstPort->stPort_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	if(pstPordGd->blAsymmetryMeasurementMode == FALSE)
	{
		if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
		{
#ifdef	PTP_USE_IEEE802_1
			pstSMGlb->enStatus = PINFSM_SUPERIOR_MASTER_PORT;

			IncPortAnnGmChangeCount(pstPort);
			IncPortAnnTimOfLstGmChgEvt(pstPort);
			IncPortAnnTimOfLstGmPhaseChgEvt(pstPort);
			IncPortAnnTimOfLstGmFreqChgEvt(pstPort);
#endif
		}
		PortAnnounceInformation_06(pstPort);

	}

	return;
}

VOID	PortAnnounceInformation_13(PORTDATA *pstPort)
{
	PORT_GD		*pstPordGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPordGd	 = &(pstPort->stPort_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	if(pstPordGd->blAsymmetryMeasurementMode == FALSE)
	{
		pstSMGlb->enStatus = PINFSM_REPEATED_MASTER_PORT;

		PortAnnounceInformation_07(pstPort);
	}

	return;
}

VOID	PortAnnounceInformation_14(PORTDATA *pstPort)
{
	PORT_GD		*pstPordGd;
	PAINFORMATIONSM_GD	*pstSMGlb;

	pstPordGd	 = &(pstPort->stPort_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	if(pstPordGd->blAsymmetryMeasurementMode == FALSE)
	{
		pstSMGlb->enStatus = PINFSM_INFERIOR_MASTER_OR_OTHER;

		IncPortAnnGmChangeCount(pstPort);
		IncPortAnnTimOfLstGmChgEvt(pstPort);
		IncPortAnnTimOfLstGmPhaseChgEvt(pstPort);
		IncPortAnnTimOfLstGmFreqChgEvt(pstPort);

		PortAnnounceInformation_08(pstPort);
	}

	return;
}

VOID	PortAnnounceInformation_15(PORTDATA *pstPort)
{
	PAINFORMATIONSM_GD	*pstSMGlb;
	PORT_1AS_DS*	pstPort1AsDs;

	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);
	pstPort1AsDs = &(pstPort->stPort_1AS_DS);

	if ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) && (IS_OD_BC_1588(pstPort->pstClockData)))
	{
#ifdef	PTP_USE_IEEE1588
		if(pstPort1AsDs->blAsCapable)
		{
			if (pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == PS_EX_LISTENING)
			{
				pstSMGlb->enStatus = PINFSM_AGED;
				pstPort->stPortBMC_GD.enInfoIs = AGED;
				pstPort->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_ANNOUNCE_RECEIPT_TIMEOUT_EXPIRES;
				PortStateSelection_03(pstPort);
				if ((pstPort->pstClockData->stBMC_GD.blSelected[pstPort->stPortDS.stPortIdentity.usPortNumber]) && (pstPort->stPortBMC_GD.blUpdtInfo == TRUE))	
				{
					PortAnnounceInformation_04(pstPort);
				}
				exec_PortAnnInfo04_allPort(pstPort);
			}
		}
#endif
	}

	return;
}

#endif

VOID	recordOtherAnnounceInfo (PORTBMC_GD *pstPortBmcGd)
{
	PTPMSG_ANNOUNCE *pstAnnounce;

	pstAnnounce = pstPortBmcGd->pstRcvdAnnouncePtr;

    pstPortBmcGd->blAnnLeap61                = MPTPMSG_H_GET_FLAGS1_LEAP61( &pstAnnounce->stHeader );
    pstPortBmcGd->blAnnLeap59                = MPTPMSG_H_GET_FLAGS1_LEAP59( &pstAnnounce->stHeader );
    pstPortBmcGd->blAnnCurrentUtcOffsetValid = MPTPMSG_H_GET_FLAGS1_CRNT_UTCOFSVAL( &pstAnnounce->stHeader );
    pstPortBmcGd->blAnnPtpTimescale          = MPTPMSG_H_GET_FLAGS1_PTPTIMESCALE( &pstAnnounce->stHeader );
    pstPortBmcGd->blAnnTimeTraceable         = MPTPMSG_H_GET_FLAGS1_TMTRACEABLE( &pstAnnounce->stHeader );
    pstPortBmcGd->blAnnFrequencyTraceable    = MPTPMSG_H_GET_FLAGS1_FQTRACEABLE( &pstAnnounce->stHeader );

	pstPortBmcGd->sAnnCurrentUtcOffset = pstAnnounce->sCurrentUtcOffset;
	pstPortBmcGd->uchAnnTimeSource = pstAnnounce->uchTimeSource;

	return;
}

#ifdef	PTP_USE_BMCA

#define	RCVINF_RT_RepeatedMasterInfo	0U
#define	RCVINF_RT_SuperiorMasterInfo	1U
#define	RCVINF_RT_InferiorMasterInfo	2U
#define	RCVINF_RT_OtherInfo				3U
UCHAR	rcvInfo (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort)
{
	CLOCK_GD	*pstClockGd;
	UCHAR		uchRet;

	pstClockGd	= &(pstPort->pstClockData->stClock_GD);

	if(pstClockGd->enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		uchRet = rcvInfo_AS (pstRcvdAnnouncePtr, pstPort);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE1588
		uchRet = rcvInfo_1588 (pstRcvdAnnouncePtr, pstPort);
#endif
	}
	return uchRet;
}

#ifdef	PTP_USE_IEEE802_1
UCHAR	rcvInfo_AS (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort)
{
	PRIORITY_VECT	stMessagePriorityVector;
	PAINFORMATIONSM_GD	*pstSMGlb;
	USHORT		usPortNumber;
	PORTBMC_GD	*pstPortBmcGd;
	LONG		lCmpRet;
	UCHAR		uchRet;

	pstSMGlb	= &(pstPort->stPAInformationSM_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;


	makeMessagePriorityVector (pstRcvdAnnouncePtr, usPortNumber, &stMessagePriorityVector);

	tsn_Wrapper_MemCpy (&(pstSMGlb->stMessagePriority), &stMessagePriorityVector, sizeof(PRIORITY_VECT));

	pstPortBmcGd->usMessageStepsRemoved = pstRcvdAnnouncePtr->usStepsRemoved;

	lCmpRet = compVector (&(pstSMGlb->stMessagePriority), &(pstPortBmcGd->stPortPriority));

		if (lCmpRet)
		{
			if (lCmpRet < 0)
			{
				uchRet = (UCHAR)RCVINF_RT_SuperiorMasterInfo;
			}
			else
			{
				uchRet = (UCHAR)RCVINF_RT_InferiorMasterInfo;
			}
		}
		else
		{
			uchRet = RCVINF_RT_RepeatedMasterInfo;
		}
	return uchRet;
}
#endif

#ifdef	PTP_USE_IEEE1588
UCHAR	rcvInfo_1588 (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort)
{
	UCHAR		uchRet;


#if 1
	uchRet = (UCHAR)RCVINF_RT_SuperiorMasterInfo;
#endif
	return uchRet;
}
#endif

#endif

VOID	makeMessagePriorityVector(PTPMSG_ANNOUNCE *pstSrcAnnounce, USHORT usPortNumber, PRIORITY_VECT *pstMessagePriorityVector)
{
	tsn_Wrapper_MemSet(pstMessagePriorityVector,0,sizeof(PRIORITY_VECT));
	pstMessagePriorityVector->stRootSystemIdentity.uchPriority1 = pstSrcAnnounce->uchGrandmasterPriority1;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stRootSystemIdentity.stClockQuality, 
										&pstSrcAnnounce->stGrandmasterClockQuality, sizeof(CLOCKQUALITY));
	pstMessagePriorityVector->stRootSystemIdentity.uchPriority2 = pstSrcAnnounce->uchGrandmasterPriority2;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stRootSystemIdentity.stClockIdentity,
										&pstSrcAnnounce->stGrandmasterIdentity, sizeof(CLOCKIDENTITY));
	pstMessagePriorityVector->usStepsRemoved = pstSrcAnnounce->usStepsRemoved;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stSourcePortIdentity, &pstSrcAnnounce->stHeader.stSrcPortIdentity, sizeof(PORTIDENTITY));

	pstMessagePriorityVector->usPortNumber = usPortNumber;

	return;
}

VOID	makeMessagePriorityVector2(BMCA_CMP_INF_DATA *pstBmcaCmpInfo, USHORT usPortNumber, PRIORITY_VECT *pstMessagePriorityVector)
{
	tsn_Wrapper_MemSet(pstMessagePriorityVector,0,sizeof(PRIORITY_VECT));
	pstMessagePriorityVector->stRootSystemIdentity.uchPriority1 = pstBmcaCmpInfo->uchPriority1;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stRootSystemIdentity.stClockQuality, 
										&pstBmcaCmpInfo->stClockQuality, sizeof(CLOCKQUALITY));
	pstMessagePriorityVector->stRootSystemIdentity.uchPriority2 = pstBmcaCmpInfo->uchPriority2;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stRootSystemIdentity.stClockIdentity,
										&pstBmcaCmpInfo->stClockIdentity, sizeof(CLOCKIDENTITY));
	pstMessagePriorityVector->usStepsRemoved = pstBmcaCmpInfo->usStepsRemoved;

	tsn_Wrapper_MemCpy (&pstMessagePriorityVector->stSourcePortIdentity, &pstBmcaCmpInfo->stSenderPort, sizeof(PORTIDENTITY));

	pstMessagePriorityVector->usPortNumber = usPortNumber;

	return;
}

#ifdef	PTP_USE_BMCA

VOID	PortAnnounceInformation_nop(PORTDATA *pstPort)
{
	return;
}


#ifdef	PTP_USE_IEEE1588
VOID	set_announce_tmo_1588(PORTDATA *pstPort)
{
	ULONG		ulRandom;
	USCALEDNS	stTimeoutTimeWork;
	USCALEDNS	stTimeoutTimeWork2;
	CHAR		chA;
	BOOL		blRet;
	PORTBMC_GD	*pstPortBmcGd;
	PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr;
	PAINFORMATIONSM_GD	*pstSMGlb;
	USCALEDNS		stCurrentTime;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAInformationSM_GD);

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstRcvdAnnouncePtr = pstPortBmcGd->pstRcvdAnnouncePtr;

	tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
	stTimeoutTimeWork.ulNsec_lsb = CONST10_9;

	if(pstRcvdAnnouncePtr==NULL)
	{
		chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;
	}
	else
	{
		chA = pstRcvdAnnouncePtr->stHeader.chLogMsgInterVal;
	}

	blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &stTimeoutTimeWork2);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}


	blRet = ptpMultUSNs_ULONG(&stTimeoutTimeWork2, (ULONG)pstPort->stPortDS.uchAnnounceReceiptTimeout+1 , &stTimeoutTimeWork);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt = stTimeoutTimeWork;

	ulRandom = (ULONG)tsn_Wrapper_Rand();
	ulRandom = (ulRandom % (ULONG)S_MIN_8000) + 1UL;

	ulRandom = ulRandom >> CONS_SHIFT15;

	if(ulRandom)
	{
		blRet = ptpAddUSNs_USNs (&stTimeoutTimeWork2, &pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &stTimeoutTimeWork);
		if (!blRet)
		{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}
	}

	tsn_Wrapper_MemCpy (&pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &stTimeoutTimeWork, sizeof(USCALEDNS));

	blRet = ptpAddUSNs_USNs( &stCurrentTime, &pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &pstSMGlb->stAnnounceReceiptTimeoutTime);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	if (pstPortBmcGd->pstTOAnnounceReceipt)
	{
		blRet = (BOOL)ptp_TimeOut_Can(pstPortBmcGd->pstTOAnnounceReceipt);
		if (blRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000023);
		}
		pstPortBmcGd->pstTOAnnounceReceipt = NULL;
	}

	pstPortBmcGd->pstTOAnnounceReceipt = ptp_TimeOut_Req(
							(USHORT)PTP_EV_ANNOUNCERECEIPTTIMEOUT,
							(VOID*)pstPort,
							pstSMGlb->stAnnounceReceiptTimeoutTime,
							(CallBackFunc)&portAnnounceInformationSM);
	if (pstPortBmcGd->pstTOAnnounceReceipt == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000021);
	}
}
#endif

VOID	set_announce_tmo_AS(PORTDATA *pstPort)
{
	USCALEDNS	stTimeoutTimeWork;
	USCALEDNS	stTimeoutTimeWork2;
	CHAR		chA;
	BOOL		blRet;
	PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr;
	PORTBMC_GD	*pstPortBmcGd;
	PAINFORMATIONSM_GD	*pstSMGlb;
	USCALEDNS	stCurrentTime;

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstSMGlb	= &(pstPort->stPAInformationSM_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);


	pstRcvdAnnouncePtr = pstPort->stPortBMC_GD.pstRcvdAnnouncePtr;


	tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
	stTimeoutTimeWork.ulNsec_lsb = CONST10_9;
	if(pstRcvdAnnouncePtr != NULL)
	{
		chA = pstRcvdAnnouncePtr->stHeader.chLogMsgInterVal;

	}
	else
	{
		chA = pstPort->stPort_1AS_DS.chCurrentLogAnnounceInterval;
	}

	blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &stTimeoutTimeWork2);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	blRet = ptpMultUSNs_ULONG(&stTimeoutTimeWork2, (ULONG)pstPort->stPortDS.uchAnnounceReceiptTimeout+1,
																 &pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	blRet = ptpAddUSNs_USNs( &stCurrentTime, &pstPortBmcGd->stAnnounceReceiptTimeoutTimeInt, &pstSMGlb->stAnnounceReceiptTimeoutTime);
	if (!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	if (pstPortBmcGd->pstTOAnnounceReceipt)
	{
		blRet = (BOOL)ptp_TimeOut_Can(pstPortBmcGd->pstTOAnnounceReceipt);
		if (blRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000023);
		}
		pstPortBmcGd->pstTOAnnounceReceipt = NULL;
	}

	pstPortBmcGd->pstTOAnnounceReceipt = ptp_TimeOut_Req(
							(USHORT)PTP_EV_ANNOUNCERECEIPTTIMEOUT,
							(VOID*)pstPort,
							pstSMGlb->stAnnounceReceiptTimeoutTime,
							(CallBackFunc)&portAnnounceInformationSM);
	if (pstPortBmcGd->pstTOAnnounceReceipt == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000021);
	}
}

#ifdef	PTP_USE_IEEE1588
VOID	set_qualification_tmo_1588(PORTDATA *pstPort)
{
	USCALEDNS	stTimeoutTimeWork;
	USCALEDNS	stTimeoutTimeWork2;
	CHAR		chA;
	BOOL		blRet;
	PORTBMC_1588_GD* pstPortBmc1588Gd;
	USCALEDNS		stCurrentTime;

	pstPortBmc1588Gd = &pstPort->stUn_Port_GD.stPortBMC_1588_GD;
	if (pstPortBmc1588Gd->pstTOQualification)
	{
		return;
	}
	else
	{
		ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

		tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
		stTimeoutTimeWork.ulNsec_lsb = CONST10_9;
		chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;

		blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &stTimeoutTimeWork2);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

		blRet = ptpMultUSNs_ULONG(&stTimeoutTimeWork2, (ULONG)(pstPort->pstClockData->stCurrentDS.usStepsRemoved + 1),
																	 &stTimeoutTimeWork);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

		blRet = ptpAddUSNs_USNs( &stCurrentTime, &stTimeoutTimeWork, &stTimeoutTimeWork2);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}


		pstPortBmc1588Gd->pstTOQualification = ptp_TimeOut_Req(
								0,
								(VOID*)pstPort,
								stTimeoutTimeWork2,
								(CallBackFunc)&qualificationTimeout_1588);
		if (pstPortBmc1588Gd->pstTOQualification == NULL)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000021);
		}
	}
}

VOID	qualificationTimeout_1588(USHORT usEvent,PORTDATA *pstPort)
{
	pstPort->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_QUALIFICATION_TIME_OUT_EXPIRES;
	pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstTOQualification = NULL;
	updtStatesTree(pstPort);
}
#endif

VOID	exec_PortAnnInfo04_allPort(PORTDATA *pstPort)
{
	PORTDATA *pstPortWork;

	for( pstPortWork = pstPort->pstClockData->pstPortData;
											pstPortWork != NULL;
														pstPortWork = pstPortWork->pstNextPortDataPtr)
	{
		PortAnnounceInformation_04(pstPortWork);
	}
}

#endif

VOID	makeSystemPrioVector(PORTDATA*	pstPort)
{	
	tsn_Wrapper_MemSet(&pstPort->pstClockData->stBMC_GD.stSystemPriority,0,sizeof(PRIORITY_VECT));

	pstPort->pstClockData->stBMC_GD.stSystemPriority.stRootSystemIdentity.uchPriority1 = pstPort->pstClockData->stDefaultDS.uchPriority1;
	pstPort->pstClockData->stBMC_GD.stSystemPriority.stRootSystemIdentity.uchPriority2 = pstPort->pstClockData->stDefaultDS.uchPriority2;
	tsn_Wrapper_MemCpy (&pstPort->pstClockData->stBMC_GD.stSystemPriority.stRootSystemIdentity.stClockIdentity,&pstPort->pstClockData->stDefaultDS.stClockIdentity,sizeof(CLOCKIDENTITY));
	tsn_Wrapper_MemCpy (&pstPort->pstClockData->stBMC_GD.stSystemPriority.stRootSystemIdentity.stClockQuality,&pstPort->pstClockData->stDefaultDS.stClockQuality,sizeof(CLOCKQUALITY));
	tsn_Wrapper_MemCpy (&pstPort->pstClockData->stBMC_GD.stSystemPriority.stSourcePortIdentity,&pstPort->pstClockData->stDefaultDS.stClockIdentity,sizeof(CLOCKIDENTITY));
	pstPort->pstClockData->stBMC_GD.stSystemPriority.stSourcePortIdentity.usPortNumber = 0U;
	pstPort->pstClockData->stBMC_GD.stSystemPriority.usPortNumber = 0U;
	pstPort->pstClockData->stBMC_GD.stSystemPriority.usStepsRemoved = 0U;
}

VOID	set_sync_tmo_AS(PORTDATA*	pstPort)
{
	USCALEDNS				stA_USNs					= {0};
	USCALEDNS				stSyncReceiptTimeoutTimeInt	= {0};
	ULONG					ulC_msb						= 0U;
	ULONG					ulC_lsb						= 0U;
	CHAR					chA							= 0;

	PSSSENDSM_GD*	pstPSSSGlb			= GetPSSSendSM_GD(pstPort);
	USHORT			usSSTimeEvent		= PTP_EV_SYNCRECEIPTTIMEOUT;
	USCALEDNS		stCurrentTime		= { 0 };
	USCALEDNS		stUSNs = { 0 };


	BOOL			blRet;

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);


	(VOID)ptpMultUL_UL((ULONG)(pstPort->stPort_1AS_DS.uchSyncReceiptTimeout + 1),
						(ULONG)CONST10_9,
						&ulC_msb,
						&ulC_lsb);
	stA_USNs.usFrcNsec	= (USHORT)(ulC_lsb & (ULONG)MASK_FFFF);
	stA_USNs.ulNsec_lsb	= ((ulC_msb & (ULONG)MASK_FFFF) << CONS_SHIFT16) + (ulC_lsb >> CONS_SHIFT16);
	stA_USNs.ulNsec_2nd = (ulC_msb >> CONS_SHIFT16);

	chA = CONS_SHIFT16 + pstPort->stPort_1AS_DS.chCurrentLogSyncInterval;

	(VOID)ptpShiftUSNs_CHAR(&stA_USNs,
								chA,
								&stSyncReceiptTimeoutTimeInt);

	pstPort->stPort_1AS_DS.stSyncReceiptTimeoutTimeInterval = stSyncReceiptTimeoutTimeInt;

	if (pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime));

		pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;
	}

	usSSTimeEvent = PTP_EV_SYNCRECEIPTTIMEOUT;

	blRet = ptpAddUSNs_USNs(&stCurrentTime,
		&stSyncReceiptTimeoutTimeInt,
		&stUSNs);
	if (blRet == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, PTP_LOGVE_OVERFLOW);
	}

	pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = ptp_TimeOut_Req(usSSTimeEvent,
													pstPort,
													stUSNs,
													(CallBackFunc)&portSyncSyncSend);

}
