/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNM_get_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include <snmp.h>
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#include "ST_UTI.h"
#else
#include <common.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mset_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#include <28_NPS/Include/ST_UTI.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif


#ifdef MASTER
#else
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
#endif




#ifdef MASTER
#else
#define offsetof(type, mem) (NX_ULONG)&(((type *)0) -> mem)
#endif


#define ST_MEMBER_SIZE(type, member)       sizeof(((type *)0)->member)

#define ST_NWCFG_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibNetworkConfig,        member)
#define ST_NWCFG_MST_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibMasterStation,        member)
#define ST_NWCFG_CON_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibConnectedStation,     member)
#define ST_NWCFG_ADJ_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N3MibAdjacentStation,      member)

#define ST_DVDTL_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibDeviceDetail,         member)
#define ST_DVDTL_IDT_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibIdentifierInfo,       member)
#define ST_DVDTL_STS_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibStatusInfo,           member)
#define ST_DVDTL_STSBAS_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibStatusInfoBase,       member)
#define ST_DVDTL_STSMST_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibStatusMaster,         member)
#define ST_DVDTL_STSLED_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibLed,                  member)
#define ST_DVDTL_STSPORT_SIZE(member)      ST_MEMBER_SIZE(ST_SNC_N3MibPort,                 member)

#define ST_OTMDL_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibOtherModule,          member)
#define ST_OTMDL_CNTL_SIZE(member)         ST_MEMBER_SIZE(ST_SNC_N2MibController,           member)
#define ST_OTMDL_OPT_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibOptionInfo,           member)

#define ST_STAT_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibStatisticalInfo,      member)

#define ST_OVR_SIZE(member)                ST_MEMBER_SIZE(ST_SNC_N1MibIpOverlapError,       member)
#define ST_OVR_REG_SIZE(member)            ST_MEMBER_SIZE(ST_SNC_N2MibIpOverlapReg,         member)

#define ST_TOPO_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibIpTopologyError,      member)
#define ST_TOPO_REG_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibTopologyReg,          member)



#define ST_DATL_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibDatalinkError,        member)
#define ST_DATL_REG_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibDatalinkErrorReg,     member)

#define ST_COMT_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibCommTimingError,      member)

#define ST_CUER_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibCurrentError,         member)
#define ST_CUER_ERR_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibErrorReg,             member)
#define ST_CUER_ERR_DTL_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibErrorDetailReg,       member)
#define ST_CUER_OPT_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibCurrentErrorOptionInfo,  member)
#define ST_CUER_OPT_ERR_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibOptionInfoErrorReg,      member)
#define ST_CUER_OPT_ERR_DTL_SIZE(member)   ST_MEMBER_SIZE(ST_SNC_N4MibOptionInfoErrorDetailReg,member)



#define ST_NWCFG_OFST(member)                                                     offsetof(ST_SNC_N1MibNetworkConfig,        member)
#define ST_NWCFG_MST_OFST(member)                                                 offsetof(ST_SNC_N2MibMasterStation,        member)
#define ST_NWCFG_CON_OFST(member)        (ST_NWCFG_OFST(astConnected)           + offsetof(ST_SNC_N2MibConnectedStation,     member))
#define ST_NWCFG_ADJ_OFST(member)        (ST_NWCFG_CON_OFST(astAdjacent)        + offsetof(ST_SNC_N3MibAdjacentStation,      member))

#define ST_DVDTL_OFST(member)                                                     offsetof(ST_SNC_N1MibDeviceDetail,         member)
#define ST_DVDTL_IDT_OFST(member)        (ST_DVDTL_OFST(stIdentifier)           + offsetof(ST_SNC_N2MibIdentifierInfo,       member))
#define ST_DVDTL_STS_OFST(member)        (ST_DVDTL_OFST(stStatus)               + offsetof(ST_SNC_N2MibStatusInfo,           member))
#define ST_DVDTL_STSBAS_OFST(member)     (ST_DVDTL_STS_OFST(stStatusInfoBase)   + offsetof(ST_SNC_N3MibStatusInfoBase,       member))
#define ST_DVDTL_STSMST_OFST(member)     (ST_DVDTL_STS_OFST(astMasterTable)     + offsetof(ST_SNC_N3MibStatusMaster,         member))
#define ST_DVDTL_STSLED_OFST(member)     (ST_DVDTL_STS_OFST(astLedTable)        + offsetof(ST_SNC_N3MibLed,                  member))
#define ST_DVDTL_STSPORT_OFST(member)    (ST_DVDTL_STS_OFST(astPortTable)       + offsetof(ST_SNC_N3MibPort,                 member))

#define ST_OTMDL_OFST(member)                                                     offsetof(ST_SNC_N1MibOtherModule,          member)
#define ST_OTMDL_CNTL_OFST(member)       (ST_OTMDL_OFST(stController)           + offsetof(ST_SNC_N2MibController,           member))
#define ST_OTMDL_OPT_OFST(member)        (ST_OTMDL_OFST(astOptTable)            + offsetof(ST_SNC_N2MibOptionInfo,           member))

#define ST_STAT_OFST(member)                                                      offsetof(ST_SNC_N1MibStatisticalInfo,      member)

#define ST_OVR_OFST(member)                                                       offsetof(ST_SNC_N1MibIpOverlapError,       member)
#define ST_OVR_REG_OFST(member)          (ST_OVR_OFST(astRegTable)               + offsetof(ST_SNC_N2MibIpOverlapReg,         member))

#define ST_TOPO_OFST(member)                                                      offsetof(ST_SNC_N1MibIpTopologyError,      member)
#define ST_TOPO_REG_OFST(member)         (ST_TOPO_OFST(astRegTable)              + offsetof(ST_SNC_N2MibTopologyReg,          member))


#define ST_DATL_OFST(member)                                                      offsetof(ST_SNC_N1MibDatalinkError,        member)
#define ST_DATL_REG_OFST(member)         (ST_DATL_OFST(astErrorTable)           + offsetof(ST_SNC_N2MibDatalinkErrorReg,     member))

#define ST_COMT_OFST(member)                                                      offsetof(ST_SNC_N1MibCommTimingError,      member)

#define ST_CUER_OFST(member)                                                      offsetof(ST_SNC_N1MibCurrentError,         member)
#define ST_CUER_ERR_OFST(member)         (ST_CUER_OFST(astErrorTable)            + offsetof(ST_SNC_N2MibErrorReg,             member))
#define ST_CUER_ERR_DTL_OFST(member)     (ST_CUER_ERR_OFST(astDetailTable)       + offsetof(ST_SNC_N3MibErrorDetailReg,       member))
#define ST_CUER_OPT_OFST(member)         (ST_CUER_OFST(astOptTable)              + offsetof(ST_SNC_N2MibCurrentErrorOptionInfo,  member))
#define ST_CUER_OPT_ERR_OFST(member)     (ST_CUER_OPT_OFST(astErrorTable)        + offsetof(ST_SNC_N3MibOptionInfoErrorReg,      member))
#define ST_CUER_OPT_ERR_DTL_OFST(member) (ST_CUER_OPT_ERR_OFST(astDetailTable)   + offsetof(ST_SNC_N4MibOptionInfoErrorDetailReg,member))



#define ST_ERR_MEMBER_OFSZ               {ST_SNM_VALUE_NONE, ST_SNM_VALUE_NONE}

#define ST_NWCFG_OFSZ(member)            {ST_NWCFG_OFST(member),            ST_NWCFG_SIZE(member)            }
#define ST_NWCFG_MST_OFSZ(member)        {ST_NWCFG_MST_OFST(member),        ST_NWCFG_MST_SIZE(member)        }
#define ST_NWCFG_CON_OFSZ(member)        {ST_NWCFG_CON_OFST(member),        ST_NWCFG_CON_SIZE(member)        }
#define ST_NWCFG_ADJ_OFSZ(member)        {ST_NWCFG_ADJ_OFST(member),        ST_NWCFG_ADJ_SIZE(member)        }

#define ST_DVDTL_OFSZ(member)            {ST_DVDTL_OFST(member),            ST_DVDTL_SIZE(member)            }
#define ST_DVDTL_IDT_OFSZ(member)        {ST_DVDTL_IDT_OFST(member),        ST_DVDTL_IDT_SIZE(member)        }
#define ST_DVDTL_STS_OFSZ(member)        {ST_DVDTL_STS_OFST(member),        ST_DVDTL_STS_SIZE(member)        }
#define ST_DVDTL_STSBAS_OFSZ(member)     {ST_DVDTL_STSBAS_OFST(member),     ST_DVDTL_STSBAS_SIZE(member)     }
#define ST_DVDTL_STSMST_OFSZ(member)     {ST_DVDTL_STSMST_OFST(member),     ST_DVDTL_STSMST_SIZE(member)     }
#define ST_DVDTL_STSLED_OFSZ(member)     {ST_DVDTL_STSLED_OFST(member),     ST_DVDTL_STSLED_SIZE(member)     }
#define ST_DVDTL_STSPORT_OFSZ(member)    {ST_DVDTL_STSPORT_OFST(member),    ST_DVDTL_STSPORT_SIZE(member)    }

#define ST_OTMDL_OFSZ(member)            {ST_OTMDL_OFST(member),            ST_OTMDL_SIZE(member)            }
#define ST_OTMDL_CNTL_OFSZ(member)       {ST_OTMDL_CNTL_OFST(member),       ST_OTMDL_CNTL_SIZE(member)       }
#define ST_OTMDL_OPT_OFSZ(member)        {ST_OTMDL_OPT_OFST(member),        ST_OTMDL_OPT_SIZE(member)        }

#define ST_STAT_OFSZ(member)             {ST_STAT_OFST(member),             ST_STAT_SIZE(member)             } 

#define ST_OVR_OFSZ(member)              {ST_OVR_OFST(member),              ST_OVR_SIZE(member)              }
#define ST_OVR_REG_OFSZ(member)          {ST_OVR_REG_OFST(member),          ST_OVR_REG_SIZE(member)          }

#define ST_TOPO_OFSZ(member)             {ST_TOPO_OFST(member),             ST_TOPO_SIZE(member)             }
#define ST_TOPO_REG_OFSZ(member)         {ST_TOPO_REG_OFST(member),         ST_TOPO_REG_SIZE(member)         }


#define ST_DATL_OFSZ(member)             {ST_DATL_OFST(member),             ST_DATL_SIZE(member)             }
#define ST_DATL_REG_OFSZ(member)         {ST_DATL_REG_OFST(member),         ST_DATL_REG_SIZE(member)         }


#define ST_COMT_OFSZ(member)             {ST_COMT_OFST(member),             ST_COMT_SIZE(member)             }

#define ST_CUER_OFSZ(member)             {ST_CUER_OFST(member),             ST_CUER_SIZE(member)             }
#define ST_CUER_ERR_OFSZ(member)         {ST_CUER_ERR_OFST(member),         ST_CUER_ERR_SIZE(member)         }
#define ST_CUER_ERR_DTL_OFSZ(member)     {ST_CUER_ERR_DTL_OFST(member),     ST_CUER_ERR_DTL_SIZE(member)     }
#define ST_CUER_OPT_OFSZ(member)         {ST_CUER_OPT_OFST(member),         ST_CUER_OPT_SIZE(member)         }
#define ST_CUER_OPT_ERR_OFSZ(member)     {ST_CUER_OPT_ERR_OFST(member),     ST_CUER_OPT_ERR_SIZE(member)     }
#define ST_CUER_OPT_ERR_DTL_OFSZ(member) {ST_CUER_OPT_ERR_DTL_OFST(member), ST_CUER_OPT_ERR_DTL_SIZE(member) }





#ifdef SWPS
#endif
static NX_ULONG ulST_SNM_ExtMib_UpdateAddr(NX_VOID);

static NX_ULONG ulST_SNM_ExtMib_GetItem(ST_SNM_GetItem* pstItem);
#ifdef SWPS
#endif
static NX_ULONG ulST_SNM_ExtMib_Oidmap2Mibtype(NX_USHORT usOidmap, NX_ULONG bForce, ST_SNC_Mibtype* peMibType);
static NX_ULONG ulST_SNM_ExtMib_Oidmap2MibAttr(NX_USHORT usOidmap, NX_UCHAR uchIdxAryInf, ST_SNC_MibAttr* pstAttr);
#ifdef SWPS

#endif

static NX_VOID* gpvST_SNM_Mib[ST_SNC_MIBTYPE_EXTMIB_MAX] = {
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
};



#ifdef SWPS
#endif


static ST_SNM_MibEntry gaST_SNM_MibTbl[ST_SNC_MAP_MAX] = {
#ifdef SWPS
	{{4, {1,1,1,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNetworkNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,2,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usTotalStations)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,3,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usConfigurationPriodSeconds)                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,4,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulConfigurationPriodNanoLiw)                         },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,5,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchSyncType)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,6,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(usNumberOfConnectedStation)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,7,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usPriodSeconds)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,8,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulPriodNanoLiw)                                      },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,9,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usErrorStations)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,10,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchGrandMasterIpAddress)                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,11,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usUpdateSequenceNumber)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,12,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,13,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,14,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,15,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,16,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usNetworkType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,17,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,18,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,19,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,20,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,21,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,22,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,23,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,24,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchFunction)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,25,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,26,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortCondition)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,27,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortComSpeed)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,28,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchDiagnosisInfo)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,29,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchParameterErrorInfo)                               },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,30,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchHotLineInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,31,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStatusFlag)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,32,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchAlias)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,33,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchComment)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,34,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usModeStatus)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,2,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usNetworkType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,6    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,7    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,8    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,9    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,10   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,11   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,12   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,13   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,14   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchFunction)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,15   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,16   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortCondition)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,17   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortComSpeed)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,18   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationSpecificMode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,19   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchTransmitCycle)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,20   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchDiagnosisInfo)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,21   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchParameterErrorInfo)                               },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,22   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchHotLineInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,23   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchCyclicStatus)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,24   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStatusFlag)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,25   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfAdjacentStation)                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,26   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchAlias)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,27   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchComment)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,3,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionReceivePortNumber)                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchBeforeDetectionTransmissionPortNumber)            },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(auchBeforeNodeMacAddress)                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionResponseReceivePortNumber)               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {2,1,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchNetworkNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usFwVersion)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,9,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchHwVersion)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,10,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {2,1,12,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,13,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,14,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchDeviceModelName)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,15,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchVendorName)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,16,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchSerialNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,17,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,18,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationSpecificMode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,19,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchUnitIdentifier)                                  },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchPortCondition)                                },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchErrorFrameReceptionStatus)                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchDiagnosisInfo)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchHotLineInfo)                                  },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfMasterTable)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchCyclicStopInfo)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfLedTable)                                 },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{5, {2,2,9,1,1  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,9,1,2  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSMST_OFSZ(auchMacAddress)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,10,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedColor)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,3 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedStatus)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{4, {2,2,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchCorrespondingFunction)                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{5, {2,2,12,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,      ST_SNM_IDX_DEVDTL_PORT        },
	{{5, {2,2,12,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSPORT_OFSZ(usPortLinkDownCnt)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_PORT        },
	{{4, {2, 2,13,0  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchAppInfo)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,1,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchDeviceVersion)                                   },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,2,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchFwVersion)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,3,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchHwVersion)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,4,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usDeviceType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,5,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(ulDeviceModelCode)                                  },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {3,1,6,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usExpansionModelCode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,7,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usVendorCode)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,8,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchDeviceModelName)                                },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,9,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchVendorName)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,10,0   }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchSerialNumber)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{3, {3,2,0      }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(usNumberOfTable)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,3,1,1    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,2    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(uchDeviceVersion)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,3    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,4    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,5    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,6    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchDeviceModelName)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,7    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchVendorName)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,8    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchSerialNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{3, {4,1,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveCounter)                                   },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,2,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveDiscardCounter)                            },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,3,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicFrameReceiveCounter)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,4,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveCounter)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,5,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveDiscardCounter)                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,6,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfHecErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,7,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfDcsErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,8,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFcsErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,9,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSdcrcErrorFrame)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,10,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfShortPacketFrame)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,11,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfJumboPacketFrame)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,12,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLongPacketFrame)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,13,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFailedCcLinkIePduSize)                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,14,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFlagmentErrorFrame)                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,15,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfPriorityControlFrame)                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,16,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIpFrame)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,17,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIeee802or1588Frame)                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,18,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLldpFrame)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,19,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSyncFrame)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {5,1,0      }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_OFSZ(usNumberOfTable)                                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {5,2,1,1    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,2    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchPortIdentifier)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,3    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchStatus)                                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,4    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchMacAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,5    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchIpAddress)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_IPOVERLAP_REG      },
	{{3, {6,1,0      }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {6,2,1,1    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,2    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchType)                                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,3    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchCause)                                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,4    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchMacAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,5    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchIpAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,6    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchStationType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,7    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usVendorCode)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,8    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(ulDeviceModelCode)                                    },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,9    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usDeviceType)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{3, {9,1,0      }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {9,2,1,1    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,2    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchType)                                             },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,3    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchNetworkNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,4    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,5    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchIpAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DATALINK_REG       },
	{{3, {10,1,0     }}, {ST_SNC_MIBTYPE_COMTIMING, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_COMTIMING],  ST_COMT_OFSZ(uchTimeslotNumber)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {11,1,0     }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {11,2,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorCode)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,4   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ullOccurrenceTimeSeconds)                             },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,5   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ulOccurrenceTimeNanoLiw)                              },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,6   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sUtcOffset)                                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,7   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sSummerTimeOffset)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,8   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(uchNumberOfTable)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,3,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{4, {11,3,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_DTL_OFSZ(usDetailInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(stMaster)                                                 }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      {ST_NWCFG_OFST(astConnected),sizeof(ST_SNC_N2MibConnectedStation)      }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NWCFG_CONTED       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_OFSZ(stIdentifier)                                             }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(stStatusInfoBase)                                     }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astMasterTable),sizeof(ST_SNC_N3MibStatusMaster)    }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_MASTER      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astLedTable),sizeof(ST_SNC_N3MibLed)                }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_LED         },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astPortTable),sizeof(ST_SNC_N3MibPort)              }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_PORT        },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(stController)                                             }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      {ST_OTMDL_OFST(astOptTable),sizeof(ST_SNC_N2MibOptionInfo)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_OTMDL_OPT          },
	{{0, {0}          }, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  {ST_OVR_OFST(astRegTable),sizeof(ST_SNC_N2MibIpOverlapReg)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_IPOVERLAP_REG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   {ST_TOPO_OFST(astRegTable),sizeof(ST_SNC_N2MibTopologyReg)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_TOPOLOGY_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   {ST_DATL_OFST(astErrorTable),sizeof(ST_SNC_N2MibDatalinkErrorReg)      }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DATALINK_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astErrorTable),sizeof(ST_SNC_N2MibErrorReg)              }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_CURERR_ERRREG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NONE,      ST_SNC_OIDMAP_NG,  NULL,                                      ST_ERR_MEMBER_OFSZ                                                      }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
#else
	{{4, {1,1,1,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNetworkNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,2,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usTotalStations)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,3,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usConfigurationPriodSeconds)                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,4,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulConfigurationPriodNanoLiw)                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,5,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchSyncType)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,6,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(usNumberOfConnectedStation)                              },  ST_SNM_IDX_NONE               },
	{{4, {1,1,7,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usPriodSeconds)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,8,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulPriodNanoLiw)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,9,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usErrorStations)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,10,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchGrandMasterIpAddress)                            },  ST_SNM_IDX_NONE               },
	{{4, {1,1,11,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usUpdateSequenceNumber)                              },  ST_SNM_IDX_NONE               },
	{{4, {1,1,12,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,13,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,14,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,15,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NONE               },
	{{4, {1,1,16,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usNetworkType)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,17,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,18,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,19,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NONE               },
	{{4, {1,1,20,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NONE               },
	{{4, {1,1,21,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,1,22,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchOption)                                           },  ST_SNM_IDX_NONE               },
	{{4, {1,1,23,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,1,24,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchFunction)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,25,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,26,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortCondition)                                   },  ST_SNM_IDX_NONE               },
	{{4, {1,1,27,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortComSpeed)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,28,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchDiagnosisInfo)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,29,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchParameterErrorInfo)                               },  ST_SNM_IDX_NONE               },
	{{4, {1,1,30,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchHotLineInfo)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,31,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStatusFlag)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,32,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchAlias)                                           },  ST_SNM_IDX_NONE               },
	{{4, {1,1,33,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchComment)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,34,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usModeStatus)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,2,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usNetworkType)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,6    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,7    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,8    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,9    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,10   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,11   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,12   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchOption)                                           },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,13   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,14   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchFunction)                                         },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,15   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,16   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortCondition)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,17   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortComSpeed)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,18   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationSpecificMode)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,19   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchTransmitCycle)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,20   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchDiagnosisInfo)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,21   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchParameterErrorInfo)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,22   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchHotLineInfo)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,23   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchCyclicStatus)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,24   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStatusFlag)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,25   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfAdjacentStation)                          },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,26   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchAlias)                                           },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,27   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchComment)                                         },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,3,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionReceivePortNumber)                       },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchBeforeDetectionTransmissionPortNumber)            },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(auchBeforeNodeMacAddress)                            },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionResponseReceivePortNumber)               },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {2,1,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,1,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchNetworkNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {2,1,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NONE               },
	{{4, {2,1,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NONE               },
	{{4, {2,1,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,1,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usFwVersion)                                         },  ST_SNM_IDX_NONE               },
	{{4, {2,1,9,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchHwVersion)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,10,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NONE               },
	{{4, {2,1,12,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,1,13,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,14,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchDeviceModelName)                                 },  ST_SNM_IDX_NONE               },
	{{4, {2,1,15,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchVendorName)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,16,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchSerialNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {2,1,17,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchOption)                                           },  ST_SNM_IDX_NONE               },
	{{4, {2,1,18,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationSpecificMode)                               },  ST_SNM_IDX_NONE               },
	{{4, {2,1,19,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchUnitIdentifier)                                  },  ST_SNM_IDX_NONE               },
	{{4, {2,2,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,2,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchPortCondition)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,2,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchErrorFrameReceptionStatus)                    },  ST_SNM_IDX_NONE               },
	{{4, {2,2,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchDiagnosisInfo)                                 },  ST_SNM_IDX_NONE               },
	{{4, {2,2,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchHotLineInfo)                                  },  ST_SNM_IDX_NONE               },
	{{4, {2,2,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfMasterTable)                              },  ST_SNM_IDX_NONE               },
	{{4, {2,2,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchCyclicStopInfo)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,2,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfLedTable)                                 },  ST_SNM_IDX_NONE               },
	{{5, {2,2,9,1,1  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,9,1,2  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSMST_OFSZ(auchMacAddress)                                   },  ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,10,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedColor)                                      },  ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,3 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedStatus)                                     },  ST_SNM_IDX_DEVDTL_LED         },
	{{4, {2,2,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchCorrespondingFunction)                        },  ST_SNM_IDX_NONE               },
	{{5, {2,2,12,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },   ST_SNM_IDX_DEVDTL_PORT        },
	{{5, {2,2,12,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSPORT_OFSZ(usPortLinkDownCnt)                               },  ST_SNM_IDX_DEVDTL_PORT        },
	{{4, {2, 2,13,0  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchAppInfo)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,1,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchDeviceVersion)                                   },  ST_SNM_IDX_NONE               },
	{{4, {3,1,2,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchFwVersion)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,3,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchHwVersion)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,4,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usDeviceType)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,5,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(ulDeviceModelCode)                                  },  ST_SNM_IDX_NONE               },
	{{4, {3,1,6,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usExpansionModelCode)                               },  ST_SNM_IDX_NONE               },
	{{4, {3,1,7,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usVendorCode)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,8,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchDeviceModelName)                                },  ST_SNM_IDX_NONE               },
	{{4, {3,1,9,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchVendorName)                                     },  ST_SNM_IDX_NONE               },
	{{4, {3,1,10,0   }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchSerialNumber)                                   },  ST_SNM_IDX_NONE               },
	{{3, {3,2,0      }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(usNumberOfTable)                                         },  ST_SNM_IDX_NONE               },
	{{4, {3,3,1,1    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,2    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(uchDeviceVersion)                                    },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,3    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,4    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,5    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,6    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchDeviceModelName)                                 },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,7    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchVendorName)                                      },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,8    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchSerialNumber)                                    },  ST_SNM_IDX_OTMDL_OPT          },
	{{3, {4,1,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveCounter)                                   },  ST_SNM_IDX_NONE               },
	{{3, {4,2,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveDiscardCounter)                            },  ST_SNM_IDX_NONE               },
	{{3, {4,3,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicFrameReceiveCounter)                              },  ST_SNM_IDX_NONE               },
	{{3, {4,4,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveCounter)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,5,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveDiscardCounter)                         },  ST_SNM_IDX_NONE               },
	{{3, {4,6,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfHecErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,7,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfDcsErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,8,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFcsErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,9,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSdcrcErrorFrame)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,10,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfShortPacketFrame)                               },  ST_SNM_IDX_NONE               },
	{{3, {4,11,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfJumboPacketFrame)                               },  ST_SNM_IDX_NONE               },
	{{3, {4,12,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLongPacketFrame)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,13,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFailedCcLinkIePduSize)                          },  ST_SNM_IDX_NONE               },
	{{3, {4,14,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFlagmentErrorFrame)                             },  ST_SNM_IDX_NONE               },
	{{3, {4,15,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfPriorityControlFrame)                           },  ST_SNM_IDX_NONE               },
	{{3, {4,16,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIpFrame)                                        },  ST_SNM_IDX_NONE               },
	{{3, {4,17,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIeee802or1588Frame)                             },  ST_SNM_IDX_NONE               },
	{{3, {4,18,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLldpFrame)                                      },  ST_SNM_IDX_NONE               },
	{{3, {4,19,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSyncFrame)                                      },  ST_SNM_IDX_NONE               },
	{{3, {5,1,0      }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_OFSZ(usNumberOfTable)                                           },  ST_SNM_IDX_NONE               },
	{{4, {5,2,1,1    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,2    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchPortIdentifier)                                     },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,3    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchStatus)                                             },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,4    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchMacAddress)                                        },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,5    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchIpAddress)                                         },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{3, {6,1,0      }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {6,2,1,1    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,2    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchType)                                              },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,3    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchCause)                                            },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,4    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchMacAddress)                                       },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,5    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchIpAddress)                                        },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,6    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchStationType)                                       },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,7    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usVendorCode)                                         },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,8    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(ulDeviceModelCode)                                    },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,9    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usDeviceType)                                         },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{3, {9,1,0      }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {9,2,1,1    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,2    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchType)                                             },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,3    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchNetworkNumber)                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,4    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchStationNumber)                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,5    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchIpAddress)                                        },  ST_SNM_IDX_DATALINK_REG       },
	{{3, {10,1,0     }}, {ST_SNC_MIBTYPE_COMTIMING, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_COMTIMING],  ST_COMT_OFSZ(uchTimeslotNumber)                                        },  ST_SNM_IDX_NONE               },
	{{3, {11,1,0     }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {11,2,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorCode)                                          },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,3   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorOccurrenceOrderNo)                             },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,4   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ullOccurrenceTimeSeconds)                             },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,5   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ulOccurrenceTimeNanoLiw)                              },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,6   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sUtcOffset)                                           },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,7   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sSummerTimeOffset)                                    },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,8   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(uchNumberOfTable)                                     },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,3,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{4, {11,3,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_DTL_OFSZ(usDetailInfo)                                     },  ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{3, {11,4,0     }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OFSZ(usNumberOfOptTable)                                       },  ST_SNM_IDX_NONE               },
	{{4, {11,5,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_OPT         },
	{{4, {11,5,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_OFSZ(usNumberOfTable)                                      },  ST_SNM_IDX_CURERR_OPT         },
	{{4, {11,6,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(usErrorCode)                                      },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,3   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(usErrorOccurrenceOrderNo)                         },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,4   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(ullOccurrenceTimeSeconds)                         },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,5   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(ulOccurrenceTimeNanoLiw)                          },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,6   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(sUtcOffset)                                       },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,7   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(sSummerTimeOffset)                                },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,6,1,8   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_OFSZ(uchNumberOfTable)                                 },  ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{4, {11,7,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_OPT_ERRDTLREG   },
	{{4, {11,7,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OPT_ERR_DTL_OFSZ(usDetailInfo)                                 },  ST_SNM_IDX_CURERR_OPT_ERRDTLREG   },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(stMaster)                                                 }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      {ST_NWCFG_OFST(astConnected),sizeof(ST_SNC_N2MibConnectedStation)      }}, ST_SNM_IDX_NWCFG_CONTED       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_OFSZ(stIdentifier)                                             }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(stStatusInfoBase)                                     }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astMasterTable),sizeof(ST_SNC_N3MibStatusMaster)    }}, ST_SNM_IDX_DEVDTL_MASTER      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astLedTable),sizeof(ST_SNC_N3MibLed)                }}, ST_SNM_IDX_DEVDTL_LED         },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astPortTable),sizeof(ST_SNC_N3MibPort)              }}, ST_SNM_IDX_DEVDTL_PORT        },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(stController)                                             }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      {ST_OTMDL_OFST(astOptTable),sizeof(ST_SNC_N2MibOptionInfo)             }}, ST_SNM_IDX_OTMDL_OPT          },
	{{0, {0}          }, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  {ST_OVR_OFST(astRegTable),sizeof(ST_SNC_N2MibIpOverlapReg)             }}, ST_SNM_IDX_IPOVERLAP_REG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   {ST_TOPO_OFST(astRegTable),sizeof(ST_SNC_N2MibTopologyReg)             }}, ST_SNM_IDX_TOPOLOGY_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   {ST_DATL_OFST(astErrorTable),sizeof(ST_SNC_N2MibDatalinkErrorReg)      }}, ST_SNM_IDX_DATALINK_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astErrorTable),sizeof(ST_SNC_N2MibErrorReg)              }}, ST_SNM_IDX_CURERR_ERRREG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astOptTable),sizeof(ST_SNC_N2MibCurrentErrorOptionInfo)  }}, ST_SNM_IDX_CURERR_OPT         },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astErrorTable),sizeof(ST_SNC_N3MibOptionInfoErrorReg)    }}, ST_SNM_IDX_CURERR_OPT_ERRREG  },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NONE,      ST_SNC_OIDMAP_NG,  NX_NULL,                                   ST_ERR_MEMBER_OFSZ                                                      }, ST_SNM_IDX_NONE               },
#endif
};


static const ST_SNM_Index gaST_SNM_IdxTbl[ST_SNM_IDX_TYPE_MAX] = {
	{ST_SNM_IDX_0,   {{0,                                      0,                                                   0,                        0                                      }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_NWCFG_CONTED_INDEX,          ST_SNC_MAP_NWCFG_MASTER_NUMBER_OF_CONNECTED_STATION, ST_SNC_NWCFG_CONSTN_MAX,  sizeof(ST_SNC_N2MibConnectedStation)   }}},
	{ST_SNM_IDX_2,   {{ST_SNC_MAP_NWCFG_CONTED_INDEX,          ST_SNC_MAP_NWCFG_MASTER_NUMBER_OF_CONNECTED_STATION, ST_SNC_NWCFG_CONSTN_MAX,  sizeof(ST_SNC_N2MibConnectedStation)   },
                      {ST_SNC_MAP_NWCFG_ADJACENT_INDEX,        ST_SNC_MAP_NWCFG_CONTED_NUMBER_OF_ADJACENT,          ST_SNC_NWCFG_ADJACENT_MAX,sizeof(ST_SNC_N3MibAdjacentStation)    }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_MASTAB_INDEX, ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_MASTAB,          ST_SNC_DEVDTL_MASTER_MAX, sizeof(ST_SNC_N3MibStatusMaster)       }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_LEDTAB_INDEX, ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_LEDTAB,          ST_SNC_DEVDTL_LED_MAX,    sizeof(ST_SNC_N3MibLed)                }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_PORTTAB_INDEX,ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_PORT,            ST_SNC_DEVDTL_PORT_MAX,   sizeof(ST_SNC_N3MibPort)               }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_OTMDL_OPT_INDEX,             ST_SNC_MAP_OTMDL_NUMBER_OF_OPT,                      ST_SNC_OTHER_OPT_MAX,     sizeof(ST_SNC_N2MibOptionInfo)         }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_IPOVERLAP_REG_INDEX,         ST_SNC_MAP_IPOVERLAP_NUMBER_OF_REG,                  ST_SNC_IPOVLAP_ERR_MAX,   sizeof(ST_SNC_N2MibIpOverlapReg)       }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_TOPOLOGY_REG_INDEX,          ST_SNC_MAP_TOPOLOGY_NUMBER_OF_REG,                   ST_SNC_TOPOLOGY_ERR_MAX,  sizeof(ST_SNC_N2MibTopologyReg)        }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DATALINK_REG_INDEX,          ST_SNC_MAP_DATALINK_NUMBER_OF_REG,                   ST_SNC_DATALINK_ERR_MAX,  sizeof(ST_SNC_N2MibDatalinkErrorReg)   }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_CURERR_ERRREG_INDEX,         ST_SNC_MAP_CURERR_NUMBER_OF_ERRREG,                  ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N2MibErrorReg)           }}},
	{ST_SNM_IDX_2,   {{ST_SNC_MAP_CURERR_ERRREG_INDEX,         ST_SNC_MAP_CURERR_NUMBER_OF_ERRREG,                  ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N2MibErrorReg)           },
				      {ST_SNC_MAP_CURERR_ERRDTLREG_INDEX,      ST_SNC_MAP_CURERR_ERRREG_NUMBER_OF_ERRDTLREG,        ST_SNC_ERRDTLREG_MAX,     sizeof(ST_SNC_N3MibErrorDetailReg)     }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_CURERR_OPT_INDEX,            ST_SNC_MAP_CURERR_NUMBER_OF_OPT,                     ST_SNC_ERRREG_OPT_MAX,    sizeof(ST_SNC_N2MibCurrentErrorOptionInfo)  }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_CURERR_OPT_ERRREG_INDEX,     ST_SNC_MAP_CURERR_OPT_NUMBER_OF_ERRREG,              ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N3MibOptionInfoErrorReg)      }}},
	{ST_SNM_IDX_2,   {{ST_SNC_MAP_CURERR_OPT_ERRREG_INDEX,     ST_SNC_MAP_CURERR_OPT_NUMBER_OF_ERRREG,              ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N3MibOptionInfoErrorReg)      },
				      {ST_SNC_MAP_CURERR_OPT_ERRDTLREG_INDEX,  ST_SNC_MAP_CURERR_OPT_ERRREG_NUMBER_OF_ERRDTLREG,    ST_SNC_ERRDTLREG_MAX,     sizeof(ST_SNC_N4MibOptionInfoErrorDetailReg)}}},
};


static ST_SNM_MibTblSet gST_SNM_ExtMibTbls = {
	ST_SNC_MAP_NWCFG_MASTER,
	gaST_SNM_MibTbl,
	ST_SNM_IDX_TYPE_MAX,
	gaST_SNM_IdxTbl,
#ifdef SWPS
	ST_SNM_ExtMib_GetAsnPrefix,
	bST_SNM_ExtMib_CheckAsnPrefix,
#endif
	ulST_SNM_ExtMib_UpdateAddr,
	ulST_SNM_ExtMib_GetItem,
#ifdef SWPS
	ulST_SNM_ExtMib_Get,
	ulST_SNM_ExtMib_Index,
	ulST_SNM_ExtMib_GetIdxNumFromEntry,
	ulST_SNM_ExtMib_FromIndexToOid,
	ulST_SNM_ExtMib_FromOidToIndex,
#endif
};





#ifdef SWPS


#endif

NX_VOID ST_SNM_GetExtMibTbl(
	ST_SNM_MibTblSet**	pstTblSet
)
{
	*pstTblSet = &gST_SNM_ExtMibTbls;
}




static NX_ULONG ulST_SNM_ExtMib_UpdateAddr(NX_VOID)
{
	NX_ULONG 	ulRet = ST_SNC_OK;
	NX_UCHAR	ucCnt = 0;

	for(ucCnt=0; ucCnt<ST_SNC_MIBTYPE_EXTMIB_MAX; ucCnt++) {

		ulRet = ulST_SNC_MibGetAddr((ST_SNC_Mibtype)ucCnt, ST_SNC_MEMORY_READ, &gpvST_SNM_Mib[ucCnt]);
		if(ST_SNC_OK != ulRet) {
			break;
		}
		else {
			DBGTRACE("%s gpvST_SNM_Mib[%d]=0x%x", __FUNCTION__, ucCnt, gpvST_SNM_Mib[ucCnt] );
		}
	}

	return ulRet;
}

NX_ULONG ulST_SNM_ExtMib_UpdateAddrForMibType(NX_UCHAR uchMibType)
{
	NX_ULONG ulRet = ST_SNC_OK;

	ulRet = ulST_SNC_MibGetAddrNolock((ST_SNC_Mibtype)uchMibType, ST_SNC_MEMORY_READ, &gpvST_SNM_Mib[uchMibType]);
	if(ST_SNC_OK == ulRet){
		DBGTRACE("%s gpvST_SNM_Mib[%d]=0x%x", __FUNCTION__, uchMibType, gpvST_SNM_Mib[uchMibType] );
	}
	else {
		;
	}
	return ulRet;
}


#ifdef SWPS
#endif


static NX_ULONG ulST_SNM_ExtMib_Oidmap2Mibtype(
	NX_USHORT			usOidmap,
	NX_ULONG			bForce,
	ST_SNC_Mibtype*	peMibType
)
{
		if(TRUE == bForce) {
			*peMibType = (ST_SNC_Mibtype)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucMibType;
		}
		else {
			if(ST_SNC_OIDMAP_OK == gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucOperable) {
				*peMibType = (ST_SNC_Mibtype)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucMibType;
			}
			else{
				return ST_SNC_NG_PARAM_FORBID;
			}
		}
	DBGTRACE("%s END(oid=%d bForce=%d type=%d)",__FUNCTION__, usOidmap, bForce, *peMibType);
	return ST_SNC_OK;
}


#ifdef SWPS
#endif


static NX_ULONG ulST_SNM_ExtMib_Oidmap2MibAttr(
	NX_USHORT				usOidMap,
	NX_UCHAR				uchIdxAryInf,
	ST_SNC_MibAttr*		pstAttr
)
{
	NX_ULONG				ulRet			= ST_SNC_OK;
	NX_USHORT				usArrayEntry	= 0;
	NX_UCHAR				ucIdxTblIdx		= 0;
	ST_SNC_Mibtype 		eMibType 		= ST_SNC_MIBTYPE_NONE;

		pstAttr->ulOfst = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].stMib.stAttr.ulOfst;
		pstAttr->ulSize = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].stMib.stAttr.ulSize;


		ucIdxTblIdx = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].ucIdx;

		if(ST_SNM_IDX_NONE != ucIdxTblIdx){

			usArrayEntry = gaST_SNM_IdxTbl[ ucIdxTblIdx ].astInf[uchIdxAryInf].usAryEntryOidmap;

			
			ulRet = ulST_SNM_ExtMib_Oidmap2Mibtype(usArrayEntry, TRUE, &eMibType);
			if(ST_SNC_OK == ulRet) {

				ulRet = ulST_SNC_SetMibCntAttr(
							&pstAttr->stCnt,
							eMibType,
							gST_SNM_ExtMibTbls.pstMibTbl[ usArrayEntry ].stMib.stAttr.ulOfst,
							gST_SNM_ExtMibTbls.pstMibTbl[ usArrayEntry ].stMib.stAttr.ulSize,
							gST_SNM_ExtMibTbls.pstIdxTbl[ ucIdxTblIdx  ].astInf[ uchIdxAryInf ].usAryMax
							);
			}
			else {
				;
			}
		}
		else {
			ulRet = ST_SNC_NG_MEMCNT;
		}
	return ulRet;
}


static NX_ULONG ulST_SNM_ExtMib_GetItem(ST_SNM_GetItem* pstItem)
{
#ifdef SWPS
	AsnObjectIdentifier*	pstOid;
	AsnObjectIdentifier		asnOidCopy;
#endif
	ST_SNM_Oid				stOid;
	NX_ULONG					ulRet			= ST_SNC_OK;
	NX_USHORT					usOidmapMax		= 0;

	if(	NX_NULL == pstItem			||
		NX_NULL == pstItem->pObj	) {
		ulRet = ST_SNC_NG_PARAM_ADDR;
	}
	else {
		if(TRUE == pstItem->bCallSnmpReq) {

			usOidmapMax = gST_SNM_ExtMibTbls.usMibTblSize;
		}
		else {

			usOidmapMax = (NX_USHORT)sizeof(gaST_SNM_MibTbl)/sizeof(gaST_SNM_MibTbl[0]);
		}

		if (usOidmapMax <= pstItem->usOidmap){
			ulRet = ST_SNC_NG_PARAM_RANGE;
		}
		else {

			switch(pstItem->uchItemType) {
#ifdef SWPS
			case ST_SNM_MIBENTRY_OID:
				
				ulRet = ulST_SNM_ExtMib_Oidmap2Oid(pstItem->usOidmap, &stOid);
				if(ST_SNC_OK == ulRet) {


					asnOidCopy.idLength = stOid.uiLen;
					asnOidCopy.ids = stOid.auiOid;
					pstOid = (AsnObjectIdentifier*)pstItem->pObj;
					SnmpUtilOidCpy(pstOid, &asnOidCopy);
				}
				else {
					;
				}
				break;
#endif
			case ST_SNM_MIBENTRY_TYPE:
				ulRet = ulST_SNM_ExtMib_Oidmap2Mibtype(pstItem->usOidmap, FALSE, (ST_SNC_Mibtype*)pstItem->pObj);
				break;
			case ST_SNM_MIBENTRY_ATTR:
				ulRet = ulST_SNM_ExtMib_Oidmap2MibAttr(pstItem->usOidmap, pstItem->uchIdxAryInf, (ST_SNC_MibAttr*)pstItem->pObj);
				break;
			default:
				ulRet = ST_SNC_NG_PARAM_RANGE;
			}
		}
	}

	return ulRet;
}


#ifdef SWPS

















#endif
