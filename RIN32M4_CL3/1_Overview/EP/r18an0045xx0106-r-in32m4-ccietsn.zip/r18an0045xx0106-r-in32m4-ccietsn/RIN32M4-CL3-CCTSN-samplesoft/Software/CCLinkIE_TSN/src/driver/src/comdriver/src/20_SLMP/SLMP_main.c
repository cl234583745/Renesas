/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_frame.h"
#include "ccienx_api.h"
#include "SLMP_api.h"
#include "USN_api.h"
#include "TOOL_api.h"
#include "NMG_api.h"
#include "NMG_common.h"
#include "ccienx_app_supply.h"
#include "ACM_api.h"

#define	SLMP_BUFFER_SIZE				(1948)
#define	SLMP_ERRRESDSIZE_3E_SIZE		(11)
#define	SLMP_ERRRESDSIZE_4E_SIZE		(11)
#define	SLMP_ERRRESDSIZE_5E_SIZE		(6)
#define	SLMP_ERRRESDSIZE_6E_SIZE		(20)
#define	SLMP_ERRRESBUF_3E_SIZE			(20)
#define	SLMP_ERRRESBUF_4E_SIZE			(24)
#define	SLMP_ERRRESBUF_5E_SIZE			(26)
#define	SLMP_ERRRESBUF_6E_SIZE			(36)

#define	SLMP_BUFFER_ID					(2)
#define	SLMP_BUFFER_IDX_NMG				(0)
#define	SLMP_BUFFER_IDX_APP				(1)

#define	SLMP_BUFFER_NO_USE				(0)
#define	SLMP_BUFFER_APP					(1)
#define	SLMP_BUFFER_CMN					(2)
#define	SLMP_BUFFER_ERR					(0xFFFF)

#define	SLMP_FRAME_OK					(NX_USHORT)0
#define	SLMP_FRAME_NG					(NX_USHORT)1
#define	SLMP_FRAME_DISCARD				(NX_USHORT)2


#define	CMM_SLMP_NET_NO					((NX_UCHAR)0x00)
#define	CMM_SLMP_STA_NO					((NX_UCHAR)0xFF)
#define	CMM_SLMP_IO_NO	 				((NX_USHORT)0x03FF)

#define	CMM_RQ_FTYPE_3E_REQ_HEADER_SIZE	(9)
#define	CMM_RQ_FTYPE_4E_REQ_HEADER_SIZE	(13)
#define	CMM_RQ_FTYPE_5E_REQ_HEADER_SIZE	(20)
#define	CMM_RQ_FTYPE_6E_REQ_HEADER_SIZE	(16)
#define	CMM_RS_FTYPE_3E_RES_HEADER_SIZE	(9)
#define	CMM_RS_FTYPE_4E_RES_HEADER_SIZE	(13)
#define	CMM_RS_FTYPE_5E_RES_HEADER_SIZE	(20)
#define	CMM_RS_FTYPE_6E_RES_HEADER_SIZE	(16)

#define	CMM_RQ_FTYPE_3E_REQ_DATA_LEN_MIN	(6)
#define	CMM_RQ_FTYPE_4E_REQ_DATA_LEN_MIN	(6)
#define	CMM_RQ_FTYPE_5E_REQ_DATA_LEN_MIN	(4)
#define	CMM_RQ_FTYPE_6E_REQ_DATA_LEN_MIN	(6)
#define	CMM_RS_FTYPE_3E_RES_DATA_LEN_MIN	(2)
#define	CMM_RS_FTYPE_4E_RES_DATA_LEN_MIN	(2)
#define	CMM_RS_FTYPE_5E_RES_DATA_LEN_MIN	(6)
#define	CMM_RS_FTYPE_6E_RES_DATA_LEN_MIN	(6)

#define	MANAGE_MASTER_MCAST_IPADDR		((NX_ULONG)0xEFFF64FA)

typedef struct tagSLMP_RCV_BUF {
	NX_USHORT	usBufId;
	NX_ULONG	ulSrcIp;
	NX_USHORT	usSrcPort;
	NX_USHORT	usPhysicalPort;
	NX_USHORT	usRxFlameSize;
	NX_UCHAR	auchSlmpBuf[SLMP_BUFFER_SIZE];
} SLMP_RCV_BUF;

NX_STATIC	SLMP_RCV_BUF	gastSlmpRcvBuf[SLMP_BUFFER_ID];

typedef struct tagSLMP_SND_BUF {
	NX_ULONG	ulDstIp;
	NX_USHORT	usDstPort;
	NX_USHORT	usTxFlameSize;
	NX_UCHAR	auchSlmpBuf[SLMP_ERRRESBUF_6E_SIZE];
	NX_USHORT	usPhysicalPort;
	NX_USHORT	usRsv;
} SLMP_SND_BUF;

NX_STATIC	SLMP_SND_BUF	gstSlmpSndBuf;

typedef struct tagSLMP_FRAME_CHK {
	NX_USHORT	usFrameType;
	NX_UCHAR	uchNetNo;
	NX_UCHAR	uchStNo;
	NX_USHORT	usUtIONo;
	NX_UCHAR	uchMultiDropStNo;
	NX_UCHAR	uchRsv;
	NX_USHORT	usDataBSize;
} SLMP_FRAME_CHK;

NX_STATIC	TX_INFO_USNET	gstSndData;

NX_STATIC	NX_USHORT	gusFinCode;

NX_VOID		vSLMP_ReInitCheck (NX_VOID);
NX_VOID		vSLMP_RcvSlmpFrame (NX_VOID);
NX_VOID		vSLMP_RcvSlmpCmnFrame (NX_VOID);
NX_VOID		vSLMP_RcvSlmpAppFrame (NX_VOID);
NX_USHORT	usSLMP_ChkSlmpFrame (NX_USHORT, NX_RECOG_SLMP_INFO*);
NX_USHORT	usSLMP_CheckSlmpFrame (SLMP_FRAME_CHK* pstReq, NX_USHORT usFrameSize, NX_USHORT usHeaderSize, NX_USHORT usDataLenMin);
NX_USHORT	usSLMP_SetErrResData (NX_USHORT);

NX_VOID vSLMP_Init (NX_VOID)
{
	NX_ULONG	ulRet	= NX_UL_NG;

	ulRet = ulSLMP_OpenSocket();
	if (ulRet == NX_UL_NG) {
	}

	vNX_FillMemory32((NX_VOID*)&gastSlmpRcvBuf, NX_ZERO, (((NX_ULONG)sizeof(SLMP_RCV_BUF) * (NX_ULONG)SLMP_BUFFER_ID) / (NX_ULONG)sizeof(NX_ULONG)));

	vNX_FillMemory32((NX_VOID*)&gstSlmpSndBuf, NX_ZERO, (sizeof(SLMP_SND_BUF) / sizeof(NX_ULONG)));

	vNX_FillMemory32((NX_VOID*)&gstSndData, NX_ZERO, (sizeof(TX_INFO_USNET) / sizeof(NX_ULONG)));

	gusFinCode = NX_ZERO;
	
	return;
}

NX_VOID vSLMP_Main (NX_VOID)
{
	vSLMP_ReInitCheck();
	vSLMP_RcvSlmpFrame();

	return;
}

NX_VOID vSLMP_ReInitCheck (NX_VOID)
{
	NX_ULONG	ulResult		= NX_UL_NG;
	NX_USHORT	usReInitFlg_Nw	= USN_REINIT_OFF;
	NX_USHORT	usReInitFlg_App	= USN_REINIT_OFF;
	
	usReInitFlg_Nw = usUSN_GetReInitFlg(SOCKET_TYPE_SLMP_NW);
	usReInitFlg_App = usUSN_GetReInitFlg(SOCKET_TYPE_SLMP_APP);
	if ((USN_REINIT_ON == usReInitFlg_Nw) || (USN_REINIT_ON == usReInitFlg_App)) {
		ulResult = ulSLMP_OpenSocket();
		if (ulResult == NX_UL_NG) {
		}
		vUSN_ClearReInitFlg(SOCKET_TYPE_SLMP_NW);
		vUSN_ClearReInitFlg(SOCKET_TYPE_SLMP_APP);
	}
	return;
}

NX_VOID vSLMP_RcvSlmpFrame (NX_VOID)
{
	if ((NX_USHORT)SLMP_BUFFER_NO_USE == gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId) {
		vSLMP_RcvSlmpCmnFrame();
	}
	else {
	}
	
	if ((NX_USHORT)SLMP_BUFFER_NO_USE == gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId) {
		vSLMP_RcvSlmpAppFrame();
	}
	else {
	}

	return;
}

NX_VOID vSLMP_RcvSlmpCmnFrame (NX_VOID)
{
	NX_USHORT				usChkResult	= SLMP_FRAME_NG;
	NX_ULONG				ulGetResult	= NX_UL_NG;
	NX_USHORT				usChkFrame	= SLMP_FRAME_NG;
	NX_USHORT				usChkCmnd	= SLMP_FRAME_NG;
	RX_INFO_USNET			stRxInfoUsnet;
	NX_RECOG_SLMP_INFO		stFrmChkInfo;

	vNX_FillMemory((NX_VOID*)&stRxInfoUsnet, NX_ZERO, sizeof(RX_INFO_USNET));
	vNX_FillMemory((NX_VOID*)&stFrmChkInfo, NX_ZERO, sizeof(NX_RECOG_SLMP_INFO));

	usChkResult = usUSN_ChkRxFrame(SOCKET_TYPE_SLMP_NW);

	if (SLMP_FRAME_OK == usChkResult) {
		stRxInfoUsnet.puchRxAddr	= (NX_UCHAR*)gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].auchSlmpBuf;
		stRxInfoUsnet.usRxDataSize	= (NX_USHORT)SLMP_BUFFER_SIZE;

		ulGetResult = ulUSN_GetRxFrame(SOCKET_TYPE_SLMP_NW, &stRxInfoUsnet);

		if (NX_UL_OK == ulGetResult) {
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].ulSrcIp			= stRxInfoUsnet.ulSrcIp;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usSrcPort		= stRxInfoUsnet.usSrcPort;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usPhysicalPort	= stRxInfoUsnet.usPhysicalPort;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usRxFlameSize	= stRxInfoUsnet.usRxFlameSize;

			usChkFrame = usSLMP_ChkSlmpFrame(SLMP_BUFFER_IDX_NMG, &stFrmChkInfo);

			switch (usChkFrame) {
			case SLMP_FRAME_OK:
				usChkCmnd = usNMG_RecognizeSlmpCmd(stFrmChkInfo.usSubHeader,
													stFrmChkInfo.usCmd,
													stFrmChkInfo.usSubCmd);

				switch (usChkCmnd) {
				case NX_SLMP_FRAME_USE:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_CMN;
					break;

				case NX_SLMP_FRAME_NO_USE:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_ERR;
					gusFinCode	= CMM_SLMP_MISS_COMMAND;
					(NX_VOID)usSLMP_SetErrResData((NX_USHORT)SLMP_BUFFER_IDX_NMG);
					break;

				case NX_SLMP_FRAME_FAULT:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_ERR;
					gusFinCode	= CMM_SLMP_MISS_REQDATA;
					(NX_VOID)usSLMP_SetErrResData((NX_USHORT)SLMP_BUFFER_IDX_NMG);
					break;

				default:
					break;
				}
				break;

			case SLMP_FRAME_NG:
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_ERR;
				(NX_VOID)usSLMP_SetErrResData((NX_USHORT)SLMP_BUFFER_IDX_NMG);
				break;

			case SLMP_FRAME_DISCARD:
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].ulSrcIp			= (NX_ULONG)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usSrcPort		= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usPhysicalPort	= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usRxFlameSize	= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_NO_USE;
				break;

			default:
				break;
			}
		}
		else {
		}
	}
	else {
	}

	return;
}

NX_VOID vSLMP_RcvSlmpAppFrame (NX_VOID)
{
	NX_USHORT				usChkResult	= SLMP_FRAME_NG;
	NX_ULONG				ulGetResult	= NX_UL_NG;
	NX_USHORT				usChkFrame	= SLMP_FRAME_NG;
	NX_USHORT				usChkCmnd	= NX_SLMP_FRAME_FAULT;
	RX_INFO_USNET			stRxInfoUsnet;
	NX_RECOG_SLMP_INFO		stFrmChkInfo;
	NX_SLMP_TRAN_RECOG_INFO	stAppIFInfo;
	NX_SLMP_REQU_TOP_6E_T*	pstReq		= NX_NULL;

	vNX_FillMemory((NX_VOID*)&stRxInfoUsnet, NX_ZERO, sizeof(RX_INFO_USNET));
	vNX_FillMemory((NX_VOID*)&stFrmChkInfo, NX_ZERO, sizeof(NX_RECOG_SLMP_INFO));
	vNX_FillMemory((NX_VOID*)&stAppIFInfo, NX_ZERO, sizeof(NX_SLMP_TRAN_RECOG_INFO));

	usChkResult = usUSN_ChkRxFrame(SOCKET_TYPE_SLMP_APP);

	if (SLMP_FRAME_OK == usChkResult) {
		stRxInfoUsnet.puchRxAddr	= (NX_UCHAR*)gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].auchSlmpBuf;
		stRxInfoUsnet.usRxDataSize	= (NX_USHORT)SLMP_BUFFER_SIZE;

		ulGetResult = ulUSN_GetRxFrame(SOCKET_TYPE_SLMP_APP, &stRxInfoUsnet);

		if (NX_UL_OK == ulGetResult) {
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].ulSrcIp			= stRxInfoUsnet.ulSrcIp;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usSrcPort		= stRxInfoUsnet.usSrcPort;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usPhysicalPort	= stRxInfoUsnet.usPhysicalPort;
			gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usRxFlameSize	= stRxInfoUsnet.usRxFlameSize;

			usChkFrame = usSLMP_ChkSlmpFrame((NX_USHORT)SLMP_BUFFER_IDX_APP, &stFrmChkInfo);

			switch (usChkFrame) {
			case SLMP_FRAME_OK:

				stAppIFInfo.usSubHeader	= stFrmChkInfo.usSubHeader;
				stAppIFInfo.usCmd		= stFrmChkInfo.usCmd;
				stAppIFInfo.usSubCmd	= stFrmChkInfo.usSubCmd;

				if ((NX_SLMP_FTYPE_4E_REQ == stAppIFInfo.usSubHeader) || (NX_SLMP_FTYPE_6E_REQ == stAppIFInfo.usSubHeader)
					|| (NX_SLMP_FTYPE_4E_RES == stAppIFInfo.usSubHeader) || (NX_SLMP_FTYPE_6E_RES == stAppIFInfo.usSubHeader)) {

					pstReq = (NX_SLMP_REQU_TOP_6E_T*)stRxInfoUsnet.puchRxAddr;
					stAppIFInfo.usSerialNo	= pstReq->stSubH.usSerialNo;
				}

				usChkCmnd = usNX_RecognizeSlmpCmd(&stAppIFInfo);

				switch (usChkCmnd) {
				case NX_SLMP_FRAME_USE:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = SLMP_BUFFER_APP;
					break;

				case NX_SLMP_FRAME_NO_USE:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].ulSrcIp			= (NX_ULONG)NX_ZERO;
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usSrcPort		= (NX_USHORT)NX_ZERO;
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usPhysicalPort	= (NX_USHORT)NX_ZERO;
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usRxFlameSize	= (NX_USHORT)NX_ZERO;
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = (NX_USHORT)SLMP_BUFFER_NO_USE;
					break;
				case NX_SLMP_FRAME_FAULT:
					gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = (NX_USHORT)SLMP_BUFFER_ERR;
					gusFinCode	= CMM_SLMP_MISS_COMMAND;
					(NX_VOID)usSLMP_SetErrResData((NX_USHORT)SLMP_BUFFER_IDX_APP);
					break;

				default:
					break;
				}
				break;

			case SLMP_FRAME_NG:
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = (NX_USHORT)SLMP_BUFFER_ERR;
				(NX_VOID)usSLMP_SetErrResData((NX_USHORT)SLMP_BUFFER_IDX_APP);
				break;

			case SLMP_FRAME_DISCARD:
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].ulSrcIp			= (NX_ULONG)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usSrcPort		= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usPhysicalPort	= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usRxFlameSize	= (NX_USHORT)NX_ZERO;
				gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = (NX_USHORT)SLMP_BUFFER_NO_USE;
				break;

			default:
				break;
			}
		}
		else {
		}
	}
	else {
	}

	return;
}

NX_USHORT usNX_GetSlmpAppFrame (
	NX_TRN_RCV_INFO* pstSlmpRcvInfo
)
{
	NX_USHORT	usGetResult	= NX_SLMP_FRAME_NONE;
	NX_USHORT	usChkBuf	= NX_SLMP_FRAME_NONE;

	if ((NX_USHORT)SLMP_BUFFER_APP == gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId) {
		pstSlmpRcvInfo->ulSrcIp			= gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].ulSrcIp;
		pstSlmpRcvInfo->usSrcPort		= gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usSrcPort;
		pstSlmpRcvInfo->usPhysicalPort	= gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usPhysicalPort;
		pstSlmpRcvInfo->puchFrameAdr	= (NX_UCHAR*)(gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].auchSlmpBuf);
		pstSlmpRcvInfo->usFrameSize		= gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usRxFlameSize;
		usChkBuf = NX_SLMP_FRAME_EXSI;
	}
	else {
	}

	usGetResult = usChkBuf;

	return usGetResult;
}

NX_USHORT usSLMP_GetSlmpCmnFrame (
	NX_TRN_RCV_INFO* pstSlmpRcvInfo
)
{
	NX_USHORT	usGetResult	= NX_SLMP_FRAME_NONE;
	NX_USHORT	usChkBuf	= NX_SLMP_FRAME_NONE;

	if ((NX_USHORT)SLMP_BUFFER_CMN == gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId) {
		pstSlmpRcvInfo->ulSrcIp			= gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].ulSrcIp;
		pstSlmpRcvInfo->usSrcPort		= gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usSrcPort;
		pstSlmpRcvInfo->usPhysicalPort	= gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usPhysicalPort;
		pstSlmpRcvInfo->puchFrameAdr	= (NX_UCHAR*)(gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].auchSlmpBuf);
		pstSlmpRcvInfo->usFrameSize		= gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usRxFlameSize;
		usChkBuf = NX_SLMP_FRAME_EXSI;
	}
	else {
	}

	usGetResult = usChkBuf;

	return usGetResult;
}

NX_USHORT usNX_ReleaseSlmpAppFrame (NX_VOID)
{
	NX_USHORT	usRlsResult	= NX_US_NG;

	if ((NX_USHORT)SLMP_BUFFER_APP == gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId) {
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].ulSrcIp			= (NX_ULONG)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usSrcPort		= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usPhysicalPort	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usRxFlameSize	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_APP].usBufId = (NX_USHORT)SLMP_BUFFER_NO_USE;

		usRlsResult = NX_US_OK;
	}
	else {
		usRlsResult = NX_US_NG;
	}

	return usRlsResult;
}

NX_USHORT usSLMP_ReleaseSlmpCmnFrame (NX_VOID)
{
	NX_USHORT	usRlsResult	= NX_US_NG;

	if ((NX_USHORT)SLMP_BUFFER_CMN == gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId) {
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].ulSrcIp			= (NX_ULONG)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usSrcPort		= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usPhysicalPort	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usRxFlameSize	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[SLMP_BUFFER_IDX_NMG].usBufId = (NX_USHORT)SLMP_BUFFER_NO_USE;

		usRlsResult = NX_US_OK;
	}
	else {
		usRlsResult = NX_US_NG;
	}

	return usRlsResult;
}

NX_USHORT usNX_SetSlmpFrame (
	NX_TRN_SND_INFO* pstSlmpSndInfo
)
{
	NX_USHORT		usRet		= NX_US_NG;
	NX_USHORT		usChkResult	= SLMP_FRAME_NG;
	NX_USHORT		usSocket	= SOCKET_TYPE_SLMP_NW;
	NX_ULONG		ulSndResult	= NX_UL_NG;
	TX_INFO_USNET	stSndData;

	if ( SLMP_PORT_NW == pstSlmpSndInfo->usDstPort ) {
		usSocket = SOCKET_TYPE_SLMP_NW;
	}
	else {
		usSocket = SOCKET_TYPE_SLMP_APP;
	}
	usChkResult = usUSN_ChkTxFrame(usSocket);

	if (SLMP_FRAME_OK == usChkResult) {
		stSndData.puchTxData	= pstSlmpSndInfo->puchFrameAdr;
		stSndData.usTxDataSize	= pstSlmpSndInfo->usFrameSize;
		stSndData.ulDstIp		= pstSlmpSndInfo->ulDstIp;
		stSndData.usDstPort		= pstSlmpSndInfo->usDstPort;
		stSndData.usPhysicalPort	= pstSlmpSndInfo->usPhysicalPort;

		ulSndResult = ulUSN_SetTxFrame(usSocket, &stSndData);

		if (NX_UL_OK == ulSndResult) {
			usRet = NX_US_OK;
		}
		else {
			usRet = NX_US_NG;
		}
	}
	else {
		usRet = NX_US_NG;
	}

	return usRet;
}

NX_USHORT usSLMP_ChkSlmpFrame (
	NX_USHORT				usBufId,
	NX_RECOG_SLMP_INFO*	pstFrmChkInfo
)
{
	NX_SLMP_REQU_TOP_3E_T*	pstReq_3E		= NX_NULL;
	NX_SLMP_REQU_TOP_4E_T*	pstReq_4E		= NX_NULL;
	NX_SLMP_REQU_TOP_5E_T*	pstReq_5E		= NX_NULL;
	NX_SLMP_REQU_TOP_6E_T*	pstReq_6E		= NX_NULL;
	NX_SLMP_RESP_TOP_3E_T*	pstRes_3E		= NX_NULL;
	NX_SLMP_RESP_TOP_4E_T*	pstRes_4E		= NX_NULL;
	NX_SLMP_RESP_TOP_5E_T*	pstRes_5E		= NX_NULL;
	NX_SLMP_RESP_TOP_6E_T*	pstRes_6E		= NX_NULL;
	SLMP_FRAME_CHK		stSlmpFrmChk;
	NX_USHORT 			usCmdWork		= NX_ZERO;
	NX_USHORT 			usSubCmdWork	= NX_ZERO;
	NX_USHORT 			usChkResult		= SLMP_FRAME_NG;
	NX_USHORT 			usFlmChkResult	= CMM_SLMP_SUCCESS;
	NX_USHORT			usFrameSize		= NX_ZERO;
	NX_USHORT			usFrameType		= NX_ZERO;
	NX_USHORT			usHeaderSize	= NX_ZERO;
	NX_USHORT			usDataLenMin	= NX_ZERO;

	usFrameSize = gastSlmpRcvBuf[usBufId].usRxFlameSize;
	usFrameType = *(NX_USHORT*)&gastSlmpRcvBuf[usBufId].auchSlmpBuf[NX_ZERO];

	if ( (NX_USHORT)SLMP_BUFFER_SIZE < usFrameSize ) {
		usChkResult = SLMP_FRAME_DISCARD;
	}
	else {
		if (NX_SLMP_FTYPE_3E_REQ == usFrameType) {
			pstReq_3E = (NX_SLMP_REQU_TOP_3E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			stSlmpFrmChk.uchNetNo			= pstReq_3E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstReq_3E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstReq_3E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstReq_3E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstReq_3E->stSubH.usDataBSize;
			usCmdWork						= pstReq_3E->stCmdData.usCmd;
			usSubCmdWork					= pstReq_3E->stCmdData.usSubCmd;
			
			usHeaderSize	= CMM_RQ_FTYPE_3E_REQ_HEADER_SIZE;
			usDataLenMin					= CMM_RQ_FTYPE_3E_REQ_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_4E_REQ == usFrameType) {
			pstReq_4E = (NX_SLMP_REQU_TOP_4E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstReq_4E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstReq_4E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstReq_4E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstReq_4E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstReq_4E->stSubH.usDataBSize;
			usCmdWork						= pstReq_4E->stCmdData.usCmd;
			usSubCmdWork					= pstReq_4E->stCmdData.usSubCmd;
			
			usHeaderSize	= CMM_RQ_FTYPE_4E_REQ_HEADER_SIZE;
			usDataLenMin					= CMM_RQ_FTYPE_4E_REQ_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_5E_REQ == usFrameType) {
			pstReq_5E = (NX_SLMP_REQU_TOP_5E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstReq_5E->stSubH.uchNetNo_Dst;
			stSlmpFrmChk.uchStNo			= pstReq_5E->stSubH.uchStNo_Dst;
			stSlmpFrmChk.usUtIONo			= pstReq_5E->stSubH.usUtIONo_Dst;
			stSlmpFrmChk.usDataBSize		= pstReq_5E->stSubH.usDataBSize;
			usCmdWork						= pstReq_5E->stCmdData.usCmd;
			usSubCmdWork					= pstReq_5E->stCmdData.usSubCmd;
			
			usHeaderSize	= CMM_RQ_FTYPE_5E_REQ_HEADER_SIZE;
			usDataLenMin					= CMM_RQ_FTYPE_5E_REQ_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_6E_REQ == usFrameType) {
			pstReq_6E = (NX_SLMP_REQU_TOP_6E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstReq_6E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstReq_6E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstReq_6E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstReq_6E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstReq_6E->stSubH.usDataBSize;
			usCmdWork						= pstReq_6E->stCmdData.usCmd;
			usSubCmdWork					= pstReq_6E->stCmdData.usSubCmd;
			
			usHeaderSize	= CMM_RQ_FTYPE_6E_REQ_HEADER_SIZE;
			usDataLenMin					= CMM_RQ_FTYPE_6E_REQ_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_3E_RES == usFrameType) {
			pstRes_3E = (NX_SLMP_RESP_TOP_3E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstRes_3E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstRes_3E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstRes_3E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstRes_3E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstRes_3E->stSubH.usDataBSize;
			usCmdWork						= (NX_USHORT)NX_ZERO;
			usSubCmdWork					= (NX_USHORT)NX_ZERO;
			
			usHeaderSize	= CMM_RS_FTYPE_3E_RES_HEADER_SIZE;
			usDataLenMin					= CMM_RS_FTYPE_3E_RES_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_4E_RES == usFrameType) {
			pstRes_4E = (NX_SLMP_RESP_TOP_4E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstRes_4E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstRes_4E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstRes_4E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstRes_4E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstRes_4E->stSubH.usDataBSize;
			usCmdWork						= (NX_USHORT)NX_ZERO;
			usSubCmdWork					= (NX_USHORT)NX_ZERO;
			
			usHeaderSize	= CMM_RS_FTYPE_4E_RES_HEADER_SIZE;
			usDataLenMin					= CMM_RS_FTYPE_4E_RES_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_5E_RES == usFrameType) {
			pstRes_5E = (NX_SLMP_RESP_TOP_5E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstRes_5E->stSubH.uchNetNo_Dst;
			stSlmpFrmChk.uchStNo			= pstRes_5E->stSubH.uchStNo_Dst;
			stSlmpFrmChk.usUtIONo			= pstRes_5E->stSubH.usUtIONo_Dst;
			stSlmpFrmChk.usDataBSize		= pstRes_5E->stSubH.usDataBSize;
			usCmdWork						= pstRes_5E->usCmd;
			usSubCmdWork					= pstRes_5E->usSubCmd;
			
			usHeaderSize	= CMM_RS_FTYPE_5E_RES_HEADER_SIZE;
			usDataLenMin					= CMM_RS_FTYPE_5E_RES_DATA_LEN_MIN;
		}
		else if (NX_SLMP_FTYPE_6E_RES == usFrameType) {
			pstRes_6E = (NX_SLMP_RESP_TOP_6E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
			
			stSlmpFrmChk.uchNetNo			= pstRes_6E->stSubH.uchNetNo;
			stSlmpFrmChk.uchStNo			= pstRes_6E->stSubH.uchStNo;
			stSlmpFrmChk.usUtIONo			= pstRes_6E->stSubH.usUtIONo;
			stSlmpFrmChk.uchMultiDropStNo	= pstRes_6E->stSubH.uchMultiDropStNo;
			stSlmpFrmChk.usDataBSize		= pstRes_6E->stSubH.usDataBSize;
			usCmdWork						= pstRes_6E->usCmd;
			usSubCmdWork					= pstRes_6E->usSubCmd;
			
			usHeaderSize	= CMM_RS_FTYPE_6E_RES_HEADER_SIZE;
			usDataLenMin					= CMM_RS_FTYPE_6E_RES_DATA_LEN_MIN;
		}
		else {
			usChkResult = SLMP_FRAME_DISCARD;
		}
		
		if (SLMP_FRAME_DISCARD != usChkResult) {
			stSlmpFrmChk.usFrameType = usFrameType;
			usFlmChkResult = usSLMP_CheckSlmpFrame( &stSlmpFrmChk, gastSlmpRcvBuf[usBufId].usRxFlameSize, usHeaderSize ,usDataLenMin );
			if ( (NX_USHORT)CMM_SLMP_SUCCESS != usFlmChkResult ) {
				gusFinCode = usFlmChkResult;
				usChkResult = SLMP_FRAME_NG;
			}
			else {
				pstFrmChkInfo->usSubHeader	= usFrameType;
				pstFrmChkInfo->usCmd		= usCmdWork;
				pstFrmChkInfo->usSubCmd		= usSubCmdWork;
				usChkResult = SLMP_FRAME_OK;
			}
		}
	}

	return usChkResult;
}

NX_USHORT usSLMP_CheckSlmpFrame (
	SLMP_FRAME_CHK*	pstReq,
	NX_USHORT		usFrameSize,
	NX_USHORT		usHeaderSize,
	NX_USHORT		usDataLenMin
)
{
	NX_USHORT	usCode			= CMM_SLMP_MISS_REQDATA;
	NX_USHORT	usFrameSizeMin	= NX_ZERO;
	
	if ((pstReq->uchNetNo == CMM_SLMP_NET_NO)
	 && (pstReq->uchStNo  == CMM_SLMP_STA_NO)
	 && (pstReq->usUtIONo  == CMM_SLMP_IO_NO)
	) {
		if ((usHeaderSize + pstReq->usDataBSize) == usFrameSize) {


			usFrameSizeMin = usDataLenMin + usHeaderSize;

			if (usFrameSizeMin <= usFrameSize) {
				usCode = CMM_SLMP_SUCCESS;
			}
			else {
				usCode = CMM_SLMP_MISS_REQDATA;
			}
		}
		else {
			usCode = CMM_SLMP_DIFFERENT_DATA;
		}
	}
	else {
		usCode = CMM_SLMP_MISS_REQDATA;
	}
	
	return usCode;
}

NX_USHORT usSLMP_SetErrResData (
	NX_USHORT		usBufId
)
{
	NX_SLMP_REQU_TOP_3E_T*		pstReq_3E		= NX_NULL;
	NX_SLMP_REQU_TOP_4E_T*		pstReq_4E		= NX_NULL;
	NX_SLMP_REQU_TOP_5E_T*		pstReq_5E		= NX_NULL;
	NX_SLMP_REQU_TOP_6E_T*		pstReq_6E		= NX_NULL;
	NX_SLMP_RESP_TOP_3E_T*		pstRes_3E		= NX_NULL;
	NX_SLMP_RESP_TOP_4E_T*		pstRes_4E		= NX_NULL;
	NX_SLMP_RESP_TOP_5E_T*		pstRes_5E		= NX_NULL;
	NX_SLMP_RESP_TOP_6E_T*		pstRes_6E		= NX_NULL;
	NX_SLMP_RESP_ERROR_T*		pstErrResData	= NX_NULL;
	NX_SLMP_RESP_ERROR_6E_T*	pstErrResData6E	= NX_NULL;
	
	NX_USHORT	usRet		 = NX_US_NG;
	NX_USHORT	usFrameType  = NX_ZERO;
	NX_USHORT	usTxDataSize = NX_ZERO;
	NX_USHORT	usChkResult	 = SLMP_FRAME_NG;
	NX_USHORT	usSocket	= SOCKET_TYPE_SLMP_NW;
	NX_ULONG	ulSndResult	 = NX_UL_NG;
	
	usFrameType = *(NX_USHORT*)&gastSlmpRcvBuf[usBufId].auchSlmpBuf[NX_ZERO];
	
	vNX_FillMemory((NX_VOID*)&gstSlmpSndBuf, NX_ZERO, sizeof(SLMP_SND_BUF));
	
	if ( SLMP_PORT_NW == gastSlmpRcvBuf[usBufId].usSrcPort ) {
		usSocket = SOCKET_TYPE_SLMP_NW;
	}
	else {
		usSocket = SOCKET_TYPE_SLMP_APP;
	}

	if (NX_SLMP_FTYPE_3E_REQ == usFrameType) {
		pstReq_3E = (NX_SLMP_REQU_TOP_3E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
		pstRes_3E = (NX_SLMP_RESP_TOP_3E_T*)gstSlmpSndBuf.auchSlmpBuf;
		
		pstRes_3E->stSubH.usFixPtn					= NX_SLMP_FTYPE_3E_RES;
		pstRes_3E->stSubH.uchNetNo					= pstReq_3E->stSubH.uchNetNo;
		pstRes_3E->stSubH.uchStNo					= pstReq_3E->stSubH.uchStNo;
		pstRes_3E->stSubH.usUtIONo					= pstReq_3E->stSubH.usUtIONo;
		pstRes_3E->stSubH.uchMultiDropStNo			= pstReq_3E->stSubH.uchMultiDropStNo;
		pstRes_3E->stSubH.usDataBSize				= SLMP_ERRRESDSIZE_3E_SIZE;
		pstRes_3E->usFixFinCode						= gusFinCode;
		
		pstErrResData = (NX_SLMP_RESP_ERROR_T*)(&pstRes_3E->auchData[NX_ZERO]);
		pstErrResData->uchNetNo						= pstReq_3E->stSubH.uchNetNo;
		pstErrResData->uchStNo						= pstReq_3E->stSubH.uchStNo;
		pstErrResData->usUtIONo						= pstReq_3E->stSubH.usUtIONo;
		pstErrResData->uchMultiDropStNo				= pstReq_3E->stSubH.uchMultiDropStNo;
		pstErrResData->usCmd						= pstReq_3E->stCmdData.usCmd;
		pstErrResData->usSubCmd						= pstReq_3E->stCmdData.usSubCmd;
		
		usTxDataSize = SLMP_ERRRESBUF_3E_SIZE;
	}
	else if (NX_SLMP_FTYPE_4E_REQ == usFrameType) {
		pstReq_4E = (NX_SLMP_REQU_TOP_4E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
		pstRes_4E = (NX_SLMP_RESP_TOP_4E_T*)gstSlmpSndBuf.auchSlmpBuf;
		
		pstRes_4E->stSubH.usFixPtn					= NX_SLMP_FTYPE_4E_RES;
		pstRes_4E->stSubH.usSerialNo				= pstReq_4E->stSubH.usSerialNo;
		pstRes_4E->stSubH.uchNetNo					= pstReq_4E->stSubH.uchNetNo;
		pstRes_4E->stSubH.uchStNo					= pstReq_4E->stSubH.uchStNo;
		pstRes_4E->stSubH.usUtIONo					= pstReq_4E->stSubH.usUtIONo;
		pstRes_4E->stSubH.uchMultiDropStNo			= pstReq_4E->stSubH.uchMultiDropStNo;
		pstRes_4E->stSubH.usDataBSize				= SLMP_ERRRESDSIZE_4E_SIZE;
		pstRes_4E->usFixFinCode						= gusFinCode;
		
		pstErrResData = (NX_SLMP_RESP_ERROR_T*)(&pstRes_4E->auchData[NX_ZERO]);
		pstErrResData->uchNetNo						= pstReq_4E->stSubH.uchNetNo;
		pstErrResData->uchStNo						= pstReq_4E->stSubH.uchStNo;
		pstErrResData->usUtIONo						= pstReq_4E->stSubH.usUtIONo;
		pstErrResData->uchMultiDropStNo				= pstReq_4E->stSubH.uchMultiDropStNo;
		pstErrResData->usCmd						= pstReq_4E->stCmdData.usCmd;
		pstErrResData->usSubCmd						= pstReq_4E->stCmdData.usSubCmd;
		
		usTxDataSize = SLMP_ERRRESBUF_4E_SIZE;
	}
	else if (NX_SLMP_FTYPE_5E_REQ == usFrameType) {
		pstReq_5E = (NX_SLMP_REQU_TOP_5E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
		pstRes_5E = (NX_SLMP_RESP_TOP_5E_T*)gstSlmpSndBuf.auchSlmpBuf;
		
		pstRes_5E->stSubH.usFixPtn					= NX_SLMP_FTYPE_5E_RES;
		pstRes_5E->stSubH.usSerialNo				= pstReq_5E->stSubH.usSerialNo;
		pstRes_5E->stSubH.uchNetNo_Dst				= pstReq_5E->stSubH.uchNetNo_Dst;
		pstRes_5E->stSubH.uchStNo_Dst				= pstReq_5E->stSubH.uchStNo_Dst;
		pstRes_5E->stSubH.usUtIONo_Dst				= pstReq_5E->stSubH.usUtIONo_Dst;
		pstRes_5E->stSubH.uchNetNo_Src				= pstReq_5E->stSubH.uchNetNo_Src;
		pstRes_5E->stSubH.uchStNo_Src				= pstReq_5E->stSubH.uchStNo_Src;
		pstRes_5E->stSubH.usUtIONo_Src				= pstReq_5E->stSubH.usUtIONo_Src;
		pstRes_5E->stSubH.uchPacketTyp				= pstReq_5E->stSubH.uchPacketTyp;
		pstRes_5E->stSubH.usSplitInfo				= pstReq_5E->stSubH.usSplitInfo;
		pstRes_5E->stSubH.usDataBSize				= SLMP_ERRRESDSIZE_5E_SIZE;
		pstRes_5E->usFixFinCode						= gusFinCode;
		pstRes_5E->usCmd							= pstReq_5E->stCmdData.usCmd;
		pstRes_5E->usSubCmd							= pstReq_5E->stCmdData.usSubCmd;
		
		usTxDataSize = SLMP_ERRRESBUF_5E_SIZE;
	}
	else if (NX_SLMP_FTYPE_6E_REQ == usFrameType) {
		pstReq_6E = (NX_SLMP_REQU_TOP_6E_T*)gastSlmpRcvBuf[usBufId].auchSlmpBuf;
		pstRes_6E = (NX_SLMP_RESP_TOP_6E_T*)gstSlmpSndBuf.auchSlmpBuf;
		
		pstRes_6E->stSubH.usFixPtn					= NX_SLMP_FTYPE_6E_RES;
		pstRes_6E->stSubH.usSerialNo				= pstReq_6E->stSubH.usSerialNo;
		pstRes_6E->stSubH.uchNetNo					= pstReq_6E->stSubH.uchNetNo;
		pstRes_6E->stSubH.uchStNo					= pstReq_6E->stSubH.uchStNo;
		pstRes_6E->stSubH.usUtIONo					= pstReq_6E->stSubH.usUtIONo;
		pstRes_6E->stSubH.uchMultiDropStNo			= pstReq_6E->stSubH.uchMultiDropStNo;
		pstRes_6E->stSubH.usExStNo					= pstReq_6E->stSubH.usExStNo;
		pstRes_6E->stSubH.usDataBSize				= SLMP_ERRRESDSIZE_6E_SIZE;
		pstRes_6E->usFixFinCode						= gusFinCode;
		pstRes_6E->usCmd							= pstReq_6E->stCmdData.usCmd;
		pstRes_6E->usSubCmd							= pstReq_6E->stCmdData.usSubCmd;
		pstRes_6E->uchMsgId							= (UCHAR)NX_ZERO;
		pstRes_6E->usDivisionTotalNum				= (USHORT)NX_ZERO;
		pstRes_6E->usDivisionId						= (USHORT)NX_ZERO;
		
		pstErrResData6E = (NX_SLMP_RESP_ERROR_6E_T*)(&pstRes_6E->auchData[NX_ZERO]);
		pstErrResData6E->uchNetNo					= pstReq_6E->stSubH.uchNetNo;
		pstErrResData6E->uchStNo					= pstReq_6E->stSubH.uchStNo;
		pstErrResData6E->usUtIONo					= pstReq_6E->stSubH.usUtIONo;
		pstErrResData6E->uchMultiDropStNo			= pstReq_6E->stSubH.uchMultiDropStNo;
		pstErrResData6E->usExStNo					= pstReq_6E->stSubH.usExStNo;
		
		usTxDataSize = SLMP_ERRRESBUF_6E_SIZE;
	}
	else {
		gastSlmpRcvBuf[usBufId].ulSrcIp			= (NX_ULONG)NX_ZERO;
		gastSlmpRcvBuf[usBufId].usSrcPort		= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[usBufId].usPhysicalPort	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[usBufId].usRxFlameSize	= (NX_USHORT)NX_ZERO;
		gastSlmpRcvBuf[usBufId].usBufId			= (NX_USHORT)SLMP_BUFFER_NO_USE;
		gastSlmpRcvBuf[usBufId].usPhysicalPort	= (NX_USHORT)NX_ZERO;
		return NX_US_NG;
	}
	
	gstSndData.puchTxData	= (NX_UCHAR*)gstSlmpSndBuf.auchSlmpBuf;
	gstSndData.usTxDataSize	= usTxDataSize;
	gstSndData.ulDstIp		= gastSlmpRcvBuf[usBufId].ulSrcIp;
	gstSndData.usDstPort	= gastSlmpRcvBuf[usBufId].usSrcPort;
	gstSndData.usPhysicalPort	= gastSlmpRcvBuf[usBufId].usPhysicalPort;
	
	gstSlmpSndBuf.ulDstIp		= gastSlmpRcvBuf[usBufId].ulSrcIp;
	gstSlmpSndBuf.usDstPort		= gastSlmpRcvBuf[usBufId].usSrcPort;
	gstSlmpSndBuf.usPhysicalPort	= gastSlmpRcvBuf[usBufId].usPhysicalPort;
	gstSlmpSndBuf.usTxFlameSize	= usTxDataSize;

	usChkResult = usUSN_ChkTxFrame(usSocket);
	if (SLMP_FRAME_OK == usChkResult) {
		ulSndResult = ulUSN_SetTxFrame(usSocket, &gstSndData);
	}
	else {
		ulSndResult = NX_UL_NG;
	}
	
	gastSlmpRcvBuf[usBufId].ulSrcIp			= (NX_ULONG)NX_ZERO;
	gastSlmpRcvBuf[usBufId].usSrcPort		= (NX_USHORT)NX_ZERO;
	gastSlmpRcvBuf[usBufId].usPhysicalPort	= (NX_USHORT)NX_ZERO;
	gastSlmpRcvBuf[usBufId].usRxFlameSize	= (NX_USHORT)NX_ZERO;
	gastSlmpRcvBuf[usBufId].usBufId			= (NX_USHORT)SLMP_BUFFER_NO_USE;
	gastSlmpRcvBuf[usBufId].usPhysicalPort	= (NX_USHORT)NX_ZERO;

	if (NX_UL_OK == ulSndResult) {
		usRet = NX_US_OK;
	}
	else {
		usRet = NX_US_NG;
	}
	
	return usRet;
}

NX_ULONG ulSLMP_OpenSocket (NX_VOID)
{
	SOCKET_INFO_USNET	stSocketInfoUsnet_Nw;
	SOCKET_INFO_USNET	stSocketInfoUsnet_App;
	NX_ULONG			ulRet		= NX_UL_NG;
	NX_ULONG			ulRet_Nw	= NX_UL_NG;
	NX_ULONG			ulRet_App	= NX_UL_NG;
	
	vNX_FillMemory32(&stSocketInfoUsnet_Nw, NX_L_ZERO, sizeof(SOCKET_INFO_USNET) / sizeof(NX_ULONG));
	stSocketInfoUsnet_Nw.usMyPort = (NX_USHORT)SLMP_PORT_NW;
	ulRet_Nw = ulUSN_OpenSocket(PROTOCOL_UDP, SOCKET_TYPE_SLMP_NW, &stSocketInfoUsnet_Nw);
	vNX_FillMemory32(&stSocketInfoUsnet_App, NX_L_ZERO, sizeof(SOCKET_INFO_USNET) / sizeof(NX_ULONG));
	stSocketInfoUsnet_App.usMyPort = (NX_USHORT)SLMP_PORT_APP;
	ulRet_App = ulUSN_OpenSocket(PROTOCOL_UDP, SOCKET_TYPE_SLMP_APP, &stSocketInfoUsnet_App);

	if ((NX_UL_NG == ulRet_Nw) || (NX_UL_NG == ulRet_App)) {
		ulRet	= NX_UL_NG;
	}
	else {
		ulRet	= NX_UL_OK;
	}

	return ulRet;
}

NX_VOID vSLMP_EntryMulticastAddress ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		vUSN_AddMulticast(SOCKET_TYPE_SLMP_APP, MANAGE_MASTER_MCAST_IPADDR);
	}
}

