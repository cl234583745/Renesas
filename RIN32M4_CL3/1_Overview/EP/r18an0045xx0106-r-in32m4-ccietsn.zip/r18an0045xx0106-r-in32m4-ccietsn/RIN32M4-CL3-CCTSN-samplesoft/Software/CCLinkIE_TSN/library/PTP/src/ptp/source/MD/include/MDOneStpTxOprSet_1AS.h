/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDONESTPTXOPRSET_1AS_H__
#define __MDONESTPTXOPRSET_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID OneStepTxOperSetSM_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID OneStepTxOperSetSM_00_1AS(PORTDATA* pstPort);
VOID OneStepTxOperSetSM_01_1AS(PORTDATA* pstPort);
VOID OneStepTxOperSetSM_02_1AS(PORTDATA* pstPort);
VOID OneStepTxOperSetSM_03_1AS(PORTDATA* pstPort);
VOID OneStepTxOperSetSM_NP_1AS(PORTDATA* pstPort);

BOOL OneStepTxOpSet_NotEnabled_1AS(OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID OneStepTxOpSet_Initialize_1AS (OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID OneStepTxOpSet_SetOneStep_1AS(OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
