/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_tsn_Wrapper.h"
#include "ptp_CommonFunction.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"

#include "PTP_GlobalData.h"
#include "ptp_bmca.h"

#include "mdtransinterface.h"

#include "MDSyncReceiveSM.h"
#include "MDPdelayReq.h"
#include "MDPdelayResp.h"
#include "PortAnnounceReceiveSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "ManagementSM.h"
#include "AnnounceIntvalSet.h"
#include "MDSyncIntvalSet.h"
#include "MDLkDlyIntvalSet.h"
#include "MDOneStpTxOprSet.h"

#ifdef	PTP_USE_IEEE802_1
#include "gptpCapableReceiveSM.h"
#include "gptpCapableIntSetSM.h"
#endif

#define D_DUMP	0

static void dump_msg_signal( PORTDATA *pstPort, PTPMSG_SIGNALING_1AS *msg );



VOID	ptp_Mdl_recv_Sync_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP  *pstTimeStamp)
{

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_SYNC_AS, PTP_LOGVE_85000005);
		return;
	}


	if((pstPort->stPort_1AS_DS.blAsCapable==TRUE) && (pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == SlavePort))
	{
		pstPort->stMDSReceiveSM_GD.blRcvdSync = TRUE;

		{
			BOOL	blConvRet;

			blConvRet = ptpConvETS_TS(pstTimeStamp, &pstPort->stMDSReceiveSM_GD.stIngMDTimestampReceive);
			if (blConvRet != TRUE)
			{
				PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
			}
#ifdef	PTP_USE_ME_HW_ASSIST
			blConvRet = ptpConvETS_TS(pstTimeStamp + 1, &pstPort->stMDSReceiveSM_GD.stIngMDTimestampReceive_Frun);
			if (blConvRet != TRUE)
			{
				PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
			}
#endif
		}

		pstPort->stMDSReceiveSM_GD.pstRcvdSync	 = (PTPMSG*)ulMdtrMsgBuff;


		{
			PORTDATA*	pstPort_Delay;

			pstPort_Delay = gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].pstExecuteCmldsPortPtr;

			if ( tsn_Wrapper_MemCmp(&pstPort->stMDSReceiveSM_GD.pstRcvdSync->stSyncTwo_1AS.stHeader.stSrcPortIdentity.stClockIdentity,
						&pstPort_Delay->stPort_GD.pstPdlyIntStackMan->stStackClockIdentity, sizeof(CLOCKIDENTITY)) )
			{
				
				tsn_Wrapper_MemSet(&pstPort_Delay->stPort_GD.pstPdlyIntStackMan->stStackClockIdentity, 0U, sizeof(CLOCKIDENTITY));

				pstPort_Delay->stPort_GD.pstPdlyIntStackMan->uchStackCountSameClock = 0U;
				pstPort_Delay->stPort_GD.pstPdlyIntStackMan->uchMaxStackCount = 0U;
			}
		}

		MDSyncReceiveSM(PTP_EV_FOR_MDSYN_RCVSM_RCVDSYNC, pstPort);
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_SYNC_AS, PTP_LOGVE_8500001A);
	}
}

VOID	ptp_Mdl_recv_Pdelay_Req_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLYREQ_AS, PTP_LOGVE_85000005);
		return;
	}


	pstPort->stMDPRespSM_GD.blRcvdPdelayReq = TRUE;

	pstPort->stMDPRespSM_GD.pstRcvdPdelayReq = (PTPMSG*)ulMdtrMsgBuff;

	tsn_Wrapper_MemCpy(
		&pstPort->stMDPRespSM_GD.stIngMDTimestampReceive, pstTimeStamp, sizeof(TIMESTAMP));

	MDPdelayResp(PTP_EV_RCVDPDELAYREQ, pstPort);
}

VOID	ptp_Mdl_recv_Pdelay_Resp_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLYRESP_AS, PTP_LOGVE_85000005);
		return;
	}


	pstPort->stMDPReqSM_GD.blRcvdPdelayResp = TRUE;
	pstPort->stMDPReqSM_GD.pstRcvdPdelayResp = (PTPMSG*)ulMdtrMsgBuff;

	tsn_Wrapper_MemCpy(
		&pstPort->stMDPReqSM_GD.stIngMDTimestampReceive, pstTimeStamp, sizeof(TIMESTAMP));

	MDPdelayReq(PTP_EV_RCVDPDELAYRESP, pstPort);
}

VOID	ptp_Mdl_recv_FollowUp_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_FOLLOWUP_AS, PTP_LOGVE_85000005);
		return;
	}


	if((pstPort->stPort_1AS_DS.blAsCapable==TRUE) && (pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == SlavePort))
	{
		pstPort->stMDSReceiveSM_GD.blRcvdFollowUp = TRUE;
		pstPort->stMDSReceiveSM_GD.pstRcvdFollowUp = (PTPMSG*)ulMdtrMsgBuff;

		MDSyncReceiveSM(PTP_EV_RCVDFOLLOWUP, pstPort);
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_FOLLOWUP_AS, PTP_LOGVE_8500001A);
	}
}

VOID	ptp_Mdl_recv_Pdly_Rsp_Fup_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{


	pstPort->stMDPReqSM_GD.blRcvdPdelayRespFollowUp = TRUE;

	pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp	 = (PTPMSG*)ulMdtrMsgBuff;


	MDPdelayReq(PTP_EV_RCVDPDELAYRESPFOLLOWUP, pstPort);
}

VOID	ptp_Mdl_recv_Announce_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{



	if(pstPort->stPort_1AS_DS.blAsCapable==TRUE)
	{
		pstPort->stPAReceiveSM_GD.blRcvdAnnounce = TRUE;

		pstPort->stPortBMC_GD.pstRcvdAnnouncePtr	 = (PTPMSG_ANNOUNCE*)ulMdtrMsgBuff;

		if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE)
		{

#ifdef	PTP_USE_BMCA
			portAnnounceReceiveSM(PTP_EV_RCVDANNOUNCE, pstPort);
#endif

		}
		else
		{
			portAnnounceInformationExtSM(PTP_EV_RCVDANNOUNCE, pstPort);
		}
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_ANNOUNCE_AS, PTP_LOGVE_8500001A);
	}
}

#ifdef	PTP_USE_IEEE802_1
#ifdef	PTP_USE_MANAGEMENT
VOID	ptp_Mdl_recv_Manage_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	PTPMSG_HEADER	*pstPtpmsgHdr;
	INT				nCmpRet = 0;
	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	pstPtpmsgHdr = (PTPMSG_HEADER *)ulMdtrMsgBuff;

	nCmpRet = tsn_Wrapper_MemCmp (&pstPtpmsgHdr->stSrcPortIdentity, &pstPort->stPortDS.stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));

	if(!nCmpRet)
	{
		ManagementSM((UCHAR *)ulMdtrMsgBuff, usMsgLen, (UCHAR)usPortNumber);
	}
	else
	{
		ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
		return;
	}
}
#endif
#endif


static void dump_msg_signal( PORTDATA *pstPort, PTPMSG_SIGNALING_1AS *msg )
{

	ptp_dbg_msg( D_DUMP, 
		         ("recv signaling packet  domain,port = %d,%d\n", 
				  pstPort->pstClockData->stDefaultDS.uchDomainNumber,
				  pstPort->stPortDS.stPortIdentity.usPortNumber) );
	
	ptp_dbg_msg( D_DUMP, ("stHeader.byMjSdoIdAndMsgTyp                   = 0x%02x\n", msg->stHeader.byMjSdoIdAndMsgTyp) );
	ptp_dbg_msg( D_DUMP, ("stHeader.byMiVerAndVerPTP                     = 0x%02x\n", msg->stHeader.byMiVerAndVerPTP) );
	ptp_dbg_msg( D_DUMP, ("stHeader.usMegLength                          = %d\n", msg->stHeader.usMegLength) );
	ptp_dbg_msg( D_DUMP, ("stHeader.uchDomainNumber                      = 0x%02x\n", msg->stHeader.uchDomainNumber) );

	ptp_dbg_msg( D_DUMP, ("stHeader.uchMinorSdoId                        = 0x%02x\n", msg->stHeader.uchMinorSdoId) );
	ptp_dbg_msg( D_DUMP, ("stHeader.byFlags0                             = 0x%02x\n", msg->stHeader.byFlags0) );
	ptp_dbg_msg( D_DUMP, ("stHeader.byFlags1                             = 0x%02x\n", msg->stHeader.byFlags1) );

	ptp_dbg_msg( D_DUMP, ("stHeader.stCorrectionField                    = %04x.%08x.%04x\n", 
						  msg->stHeader.stCorrectionField.sNsec_msb,
						  msg->stHeader.stCorrectionField.ulNsec_lsb,
						  msg->stHeader.stCorrectionField.usFrcNsec) );
	
	ptp_dbg_msg( D_DUMP, ("stHeader.uchMsgTypSpecific                    = 0x%02x%02x%02x%02x\n", 
	                      msg->stHeader.uchMsgTypSpecific[0],
	                      msg->stHeader.uchMsgTypSpecific[1],
	                      msg->stHeader.uchMsgTypSpecific[2],
	                      msg->stHeader.uchMsgTypSpecific[3]) );
	ptp_dbg_msg( D_DUMP, ("stHeader.stSrcPortIdentity.stClockIdentity    = 0x0x%02x%02x%02x%02x%02x%02x%02x%02x\n", 
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[0],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[1],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[2],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[3],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[4],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[5],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[6],
	                      msg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[7]) );
	ptp_dbg_msg( D_DUMP, ("stHeader.stSrcPortIdentity.usPortNumber       = 0x%04x\n", msg->stHeader.stSrcPortIdentity.usPortNumber) );


	ptp_dbg_msg( D_DUMP, ("stHeader.usSequenceId                         = %d\n", msg->stHeader.usSequenceId) );
	ptp_dbg_msg( D_DUMP, ("stHeader.uchControl                           = 0x%02x\n", msg->stHeader.uchControl) );
	ptp_dbg_msg( D_DUMP, ("stHeader.chLogMsgInterVal                     = %d\n", msg->stHeader.chLogMsgInterVal) );

	ptp_dbg_msg( D_DUMP, ("stTargetPortIdentity.stClockIdentity          = 0x0x%02x%02x%02x%02x%02x%02x%02x%02x\n", 
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[0],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[1],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[2],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[3],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[4],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[5],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[6],
	                      msg->stTargetPortIdentity.stClockIdentity.uchId[7]) );
	ptp_dbg_msg( D_DUMP, ("stTargetPortIdentity.usPortNumber             = 0x%04x\n", msg->stTargetPortIdentity.usPortNumber) );

	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.usTLVType                       = 0x%04x\n", msg->stGptpCap_TLV.usTLVType) );
	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.usLengthField                   = %d\n", msg->stGptpCap_TLV.usLengthField) );


	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.uchOrganizationID               = %02x-%02x-%02x\n", 
						  msg->stGptpCap_TLV.uchOrganizationID[0],
						  msg->stGptpCap_TLV.uchOrganizationID[1],
						  msg->stGptpCap_TLV.uchOrganizationID[2]) );


	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.uchOrganizationSubType          = 0x%02x%02x%02x\n", 
						  msg->stGptpCap_TLV.uchOrganizationSubType[0],
						  msg->stGptpCap_TLV.uchOrganizationSubType[1],
						  msg->stGptpCap_TLV.uchOrganizationSubType[2]) );

	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.chlogGptpCapableMessageInterval = %d\n", msg->stGptpCap_TLV.chlogGptpCapableMessageInterval) );
	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.byFlags                         = 0x%02x\n", msg->stGptpCap_TLV.byFlags) );
	ptp_dbg_msg( D_DUMP, ("stGptpCap_TLV.uchReserved                     = 0x%02x%02x%02x%02x\n", 
						  msg->stGptpCap_TLV.uchReserved[0],
						  msg->stGptpCap_TLV.uchReserved[1],
						  msg->stGptpCap_TLV.uchReserved[2],
						  msg->stGptpCap_TLV.uchReserved[3]) );
	return ;
}

VOID	ptp_Mdl_recv_Signal_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	PTPMSG_SIGNALING_1AS *pstPtpMsgSignal;
	USHORT			usPortCnt;
	USHORT			usLoopCnt;
	PORTDATA		*pstDstPort;
	INT				nCmpRet;
	INT				nCmpRet2;

	static			PTPMSG_SIGNALING_1AS	stSignal_AS;


	if(pstPort->stPort_GD.blPortOper == FALSE)
	{
		return;
	}

	usPortCnt = pstPort->pstClockData->stDefaultDS.usNumberPorts;
	pstDstPort = pstPort->pstClockData->pstPortData;


	tsn_Wrapper_MemCpy ((VOID *)&stSignal_AS, (const VOID *)&ulMdtrMsgBuff, sizeof(stSignal_AS));
	pstPtpMsgSignal = &stSignal_AS;


	dump_msg_signal( pstPort, pstPtpMsgSignal );

	for(usLoopCnt=0; usLoopCnt < usPortCnt; usLoopCnt++)
	{

		nCmpRet2 = checkBroadCastSingnal(&pstPtpMsgSignal->stTargetPortIdentity);
		nCmpRet = tsn_Wrapper_MemCmp(&pstDstPort->stPortDS.stPortIdentity, &pstPtpMsgSignal->stTargetPortIdentity, sizeof(PORTIDENTITY));
		if ((!nCmpRet) || (nCmpRet2))
		{
			callSignalSM_AS(pstDstPort, (UCHAR *)&stSignal_AS, usMsgLen, pstPort);
		}
		pstDstPort = pstDstPort->pstNextPortDataPtr;
	}
}

VOID	callSignalSM_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, PORTDATA* pstRcvPort)
{
	PTPMSG_SIGNALING_1AS *pstPtpMsgSignal;
	UINT unSubType;

	pstPtpMsgSignal = (PTPMSG_SIGNALING_1AS *)puchMsgPtr;

	unSubType  = (UINT)pstPtpMsgSignal->stIntervalReq_TLV.uchOrganizationSubType[0] << 16;
	unSubType += (UINT)pstPtpMsgSignal->stIntervalReq_TLV.uchOrganizationSubType[1] << 8;
	unSubType += (UINT)pstPtpMsgSignal->stIntervalReq_TLV.uchOrganizationSubType[2];

	switch( unSubType )
	{
#ifdef	PTP_USE_SIGNALING
	case PTPMSG_TLV_ORGSUBTYPE_INTERVAL:
	
	pstPort->stAISSettingM_GD.blRcvdSignalingMsg2 = TRUE;
	pstPort->stAISSettingM_GD.pstRcvdSignaling = (PTPMSG*)puchMsgPtr;
	AnnounceIntervalSettingSM(PTP_EV_RCVDSIGNALINGMSG2, pstPort);

	pstPort->stSISettingSM_GD.blRcvdSignalingMsg1 = TRUE;
	pstPort->stSISettingSM_GD.pstRcvdSignaling = (PTPMSG*)puchMsgPtr;
	SyncIntervalSettingSM(PTP_EV_RCVDSIGNALINGMSG1,pstPort);

	pstPort->stLDISettingSM_GD.blRcvdSignalingMsg1 = TRUE;
	pstPort->stLDISettingSM_GD.pstRcvdSignaling = (PTPMSG*)puchMsgPtr;
	LinkDelayIntervalSettingSM(PTP_EV_F_LNKDLINTSET_RVDSIGMSG1,pstPort);

	pstPort->stOSTOSettingSM_GD.blRcvdSignalingMsg4 = TRUE;
	pstPort->stOSTOSettingSM_GD.pstRcvdSignaling = (PTPMSG*)puchMsgPtr;
	OneStepTxOperSettingSM(PTP_EV_RCVDSIGNALINGMSG4, pstPort);

		break;
#endif
#ifdef	PTP_USE_IEEE802_1
	case PTPMSG_TLV_ORGSUBTYPE_GPTPCAP:
		pstPort->stGPTPCapRecvSM_GD.pstRcvdSignalingMsgPtr = (PTPMSG_SIGNALING_1AS *)puchMsgPtr;
		if (pstPort == pstRcvPort)
		{
			gptpCapableReceiveSM(PTP_EV_RCVDGPTPCAPTLV, pstPort );
		}
		break;
	case PTPMSG_TLV_ORGSUBTYPE_GPTPCAPINT:
		pstPort->stGPTPCapIntSetSM_GD.pstRcvdSignalingPtrGIS = (PTPMSG_SIGNALING_1AS *)puchMsgPtr;
		gptpCapableIntSetSM(PTP_EV_RCVDSIGNALINGMSG4CP, pstPort );
		break;
#endif
	default:
		break;
	}

	return;
}

BOOL	checkBroadCastSingnal(PORTIDENTITY* pstPortIdentity)
{
	ULONG	ulCount;

	for(ulCount=0;ulCount<sizeof(CLOCKIDENTITY);ulCount++)
	{
		if(pstPortIdentity->stClockIdentity.uchId[ulCount] != 0xFF)
		{
			return FALSE;
		}
	}

	if(pstPortIdentity->usPortNumber!=0xFFFF)
	{
		return FALSE;
	}
	return TRUE;
}
