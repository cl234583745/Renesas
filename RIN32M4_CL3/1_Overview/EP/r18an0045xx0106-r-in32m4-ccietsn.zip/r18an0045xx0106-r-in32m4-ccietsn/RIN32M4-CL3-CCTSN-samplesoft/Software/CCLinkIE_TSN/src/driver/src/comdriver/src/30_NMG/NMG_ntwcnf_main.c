/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_networkconfig_main.h"
#include "SLMP_api.h"
#include "NGN_ASIC.h"
#include "tsn.h"
#include "tsn_common.h"
#include "TSN_api.h"
#include "ccienx_app_supply.h"
#include "ccienx_event.h"
#include "ccienx_api.h"
#include "ACM_api.h"

#define	RELAYSETTING_PORT12							(0)
#define	RELAYSETTING_CHK							(3)
#define	TSLT_MGNF_CHK_S								(0)
#define	TSLT_MGNF_CHK_E								(10)
#define	TIME_SYNC_METHOD_CHK						(2)
#define	TIME_SYNC_METHOD_CHK_CLASSA					(0xFF)
#define	SINGLE_DOMAIN_NO_CHK						(0)
#define	MULTI_DOMAIN_NO_CHK							(128)
#define	WINDOW_SETTING_CHK							(1000000000)
#define	TSLT_MGNF_10								(0x0A)
#define	PROP_DELAY_MEAS_METHOD_SIZE					(3)
#define	GM_ID_SIZE									(8)
#define	MS_NODE_TIME_SIZE							(10)
#define	RESERVE_SIZE								(3)
#define	PROP_DELAY_P12_MSK							(0x03)
#define	MST_NODETIME_IDX_NS							((NX_ULONG)0)
#define	MST_NODETIME_IDX_SEC						((NX_ULONG)4)
#define	MST_NODETIME_SIZE_NS						((NX_ULONG)4)
#define	MST_NODETIME_SIZE_SEC						((NX_ULONG)6)
#define	MST_NODETIME_SIZE_SEC_MAX					((NX_ULONGLONG)0x00000000FFFFFFFF)
#define	MST_NODETIME_SIZE_NS_MAX					((NX_ULONG)(0x3B9AC9FF))
#define	TIME_MASTER_SLAVE_CONF_CHK					(3)
#define	DTCT_TOPOLOGY_NORING						(0)
NX_VOID		vNMG_ChkNetworkConfigMainReq ( FRM_NC_MAIN_REQ*, NX_ULONG* );
NX_VOID		vNMG_Extract_NwCfgMainReq ( FRM_NC_MAIN_REQ*, NX_USHORT );
NX_VOID		vNMG_SetRelayFilter ( FRM_NC_MAIN_REQ* );
NX_VOID		vNMG_SetPortRole( FRM_NC_MAIN_REQ*, NX_USHORT );
NX_VOID		vNMG_StartTsn ( FRM_NC_MAIN_REQ* );
NX_VOID		vNMG_CreateNwCfgMainRespNrml ( FRM_NC_MAIN_REQ*, NX_ULONG );
NX_VOID		vNMG_CreateNwCfgMainRespFault ( FRM_NC_MAIN_REQ*, NX_USHORT );
NX_VOID		vNMG_TrnsNetStsRcvNwCfgMainReq ( NX_VOID );

NX_VOID vNMG_AnalyzeNetworkConfigMainReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_NC_MAIN_REQ	*pstFrm;
	NX_ULONG		ulChkResult		= RESP_ERR;
	NX_ULONG		ulCompareResult	= NX_UL_NG;
	
	pstFrm = (FRM_NC_MAIN_REQ*)pData;
	
	vNMG_ChkNetworkConfigMainReq(pstFrm, &ulChkResult);
	
	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_NwCfgMainReq(pstFrm, usPort);
		
		ulCompareResult	= NX_UL_OK;
		
		vNMG_CreateNwCfgMainRespNrml(pstFrm, ulCompareResult);
		vNMG_ReqTrnNetworkConfigMainResp();
		vNMG_InitTxPhysicalPort(NX_MASTER_MANAGE ,ulIPAddress, usPort);
		
		vSLMP_EntryMulticastAddress();
		
		if (ulCompareResult == NX_UL_OK) {
			vNMG_TrnsNetStsRcvNwCfgMainReq();
		}
		else {
		}
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateNwCfgMainRespFault(pstFrm, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnNetworkConfigMainResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateNwCfgMainRespFault(pstFrm, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnNetworkConfigMainResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_ChkNetworkConfigMainReq (
	FRM_NC_MAIN_REQ		*pstFrm,
	NX_ULONG			*pulChkResult
)
{
	NX_ULONG		ulNs_Temp		= (NX_ULONG)NX_ZERO;
	NX_ULONGLONG	ullSec_Temp		= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
		(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
		(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
		if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
			*pulChkResult	= RESP_DIV_ERR;
		}
		else {
			*pulChkResult = RESP_DESTRUCT;
		}
	}
	else {
		if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter1 == (NX_UCHAR)RELAYSETTING_CHK) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_005]);
			*pulChkResult	= RESP_ERR;
			return;
		}
		if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter2 == (NX_UCHAR)RELAYSETTING_CHK) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_008]);
			*pulChkResult	= RESP_ERR;
			return;
		}

		if (((NX_UCHAR)TSLT_MGNF_CHK_S != pstFrm->uchTimeslotMagnification) &&
			((NX_UCHAR)TSLT_MGNF_CHK_E != pstFrm->uchTimeslotMagnification)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_001]);
			*pulChkResult	= RESP_ERR;
			return;
		}
		if (pstFrm->uchTimeMasterSlaveConf >= (NX_UCHAR)TIME_MASTER_SLAVE_CONF_CHK) {	
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_043]);
			*pulChkResult	= RESP_ERR;
			return;
		}
		else {
		}
		usAuthClass = usACM_GetAuthenticationClass();
	
		if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		}
		else {
			if (pstFrm->uchDetectedTopology != (NX_UCHAR)DTCT_TOPOLOGY_NORING) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_004]);
				*pulChkResult	= RESP_ERR;
				return;
			}
		}
		if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
			if (pstFrm->stTimeSynchronization.uchTimeSynchronizationMethod >= (NX_UCHAR)TIME_SYNC_METHOD_CHK) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_014]);
				*pulChkResult	= RESP_ERR;
				return;
			}
			if (pstFrm->stTimeSynchronization.uchTimeSynchronizationMethod == (NX_UCHAR)TSN_IEEE1588) {
				
				if (pstFrm->stTimeSynchronization.uchDomainNo != (NX_UCHAR)SINGLE_DOMAIN_NO_CHK) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_015]);
					*pulChkResult	= RESP_ERR;
					return;
				}
				else {
				}
			}
			else {
				if ((pstFrm->stTimeSynchronization.uchDomainNo == (NX_UCHAR)SINGLE_DOMAIN_NO_CHK)
				||(pstFrm->stTimeSynchronization.uchDomainNo == (NX_UCHAR)MULTI_DOMAIN_NO_CHK)) {
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_015]);
					*pulChkResult	= RESP_ERR;
					return;
				}
			}
		}
		else {
			if (pstFrm->stTimeSynchronization.uchTimeSynchronizationMethod != (NX_UCHAR)TIME_SYNC_METHOD_CHK_CLASSA) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_014]);
				*pulChkResult	= RESP_ERR;
				return;
			}
		}
		vNX_CopyMemory(&ulNs_Temp,
						&(pstFrm->stTimeSynchronization.auchMasterNodeTime[MST_NODETIME_IDX_NS]),
						MST_NODETIME_SIZE_NS);
		vNX_CopyMemory(&ullSec_Temp,
						&(pstFrm->stTimeSynchronization.auchMasterNodeTime[MST_NODETIME_IDX_SEC]),
						MST_NODETIME_SIZE_SEC);

		if ((ullSec_Temp	> MST_NODETIME_SIZE_SEC_MAX) ||
			(ulNs_Temp		> MST_NODETIME_SIZE_NS_MAX)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_025]);
			*pulChkResult	= RESP_ERR;
			return;
		}

		if (pstFrm->usReceiveMulticastGroupSettingNum > MULCAST_GP_SIZE_MAX) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgMain[NMG_IDX_ERR_PARAM_026]);
			*pulChkResult	= RESP_ERR;
			return;
		}
		*pulChkResult	= RESP_NORMAL;
	}
	return;
}

NX_VOID vNMG_Extract_NwCfgMainReq (
	FRM_NC_MAIN_REQ	*pstFrm,
	NX_USHORT	usPort
)
{
	NX_USHORT	usIndex = (NX_USHORT)NX_ZERO;
	

	if ((pstFrm->astRelaySetting[RELAYSETTING_PORT12].b01TSMagnification1 == (NX_UCHAR)NX_ON) &&
		(pstFrm->uchTimeslotMagnification == (NX_UCHAR)TSLT_MGNF_10)) {
		NGN_CN_TS_P1_REG->R_TCPXMAGN.BITS.b01ZTSMagConfig = (NX_ULONG)NX_ON;
	}
	else {
		NGN_CN_TS_P1_REG->R_TCPXMAGN.BITS.b01ZTSMagConfig = (NX_ULONG)NX_OFF;
	}
	
	gstNM.stNetworkConfigMain.stIefMixSetting.uchData = pstFrm->uchMasterNodeInfo;
	
	gstNM.stNetworkConfigMain.stDtctTopology.uchData = pstFrm->uchDetectedTopology;
	
	vNMG_SetRelayFilter(pstFrm);
	vNMG_SetPortRole(pstFrm, usPort);
	
	
	gstNM.stNetworkConfigMain.uchTrnForbidTime = pstFrm->uchTrnForbidTime;

	vNMG_StartTsn(pstFrm);
	
	for (usIndex = (NX_USHORT)NX_ZERO; usIndex < pstFrm->usReceiveMulticastGroupSettingNum; usIndex++) {
		NGN_CN_REG->R_REGRPNO[usIndex].BITS.b10ZGroupNo = pstFrm->stRcvMulcastGp[usIndex].usRcvMulcastGp;
	}
	for (usIndex = pstFrm->usReceiveMulticastGroupSettingNum; usIndex < MULCAST_GP_SIZE_MAX; usIndex++) {
		NGN_CN_REG->R_REGRPNO[usIndex].BITS.b10ZGroupNo = NX_ZERO;
	}
	
	return;
}

NX_VOID vNMG_SetRelayFilter (
	FRM_NC_MAIN_REQ	*pstFrm
)
{
	
	if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter1 == NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN) {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt = (NX_ULONG)NX_ON;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2IEFFilt = (NX_ULONG)NX_OFF;
	}
	else if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter1 == NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN) {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt = (NX_ULONG)NX_OFF;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2IEFFilt = (NX_ULONG)NX_ON;
	}
	else {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt = (NX_ULONG)NX_OFF;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort2IEFFilt = (NX_ULONG)NX_OFF;
	}
	
	if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter2 == NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN) {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt = (NX_ULONG)NX_ON;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1IEFFilt = (NX_ULONG)NX_OFF;
	}
	else if (pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter2 == NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN) {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt = (NX_ULONG)NX_OFF;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1IEFFilt = (NX_ULONG)NX_ON;
	}
	else {
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt = (NX_ULONG)NX_OFF;
		NGN_RC_REG->R_RCRLYVL.BITS.b01ZPort1IEFFilt = (NX_ULONG)NX_OFF;
	}
	
	vNMG_UpdateRelaySettingChkRslt(pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter1,
								   pstFrm->astRelaySetting[RELAYSETTING_PORT12].b02Filter2);
	
	return;
}

NX_VOID vNMG_SetPortRole (
	FRM_NC_MAIN_REQ	*pstFrm,
	NX_USHORT	usPort
)
{
	if ((NX_RELAYSETTING_LOOPPORT_EXIST == pstFrm->astRelaySetting[RELAYSETTING_PORT12].b01LoopPort1)
	 && (NX_RELAYSETTING_LOOPPORT_EXIST == pstFrm->astRelaySetting[RELAYSETTING_PORT12].b01LoopPort2)) {
		gstNET.stPort[NX_PORT1].usPortRole = NGN_PORTROLE_LOOP;
		gstNET.stPort[NX_PORT2].usPortRole = NGN_PORTROLE_LOOP;
	}
	else {
		if ( (NX_USHORT)NX_PORT1 == usPort ) {
			gstNET.stPort[NX_PORT1].usPortRole = NGN_PORTROLE_UP;
			gstNET.stPort[NX_PORT2].usPortRole = NGN_PORTROLE_DOWN;
		}
		else {
			gstNET.stPort[NX_PORT1].usPortRole = NGN_PORTROLE_DOWN;
			gstNET.stPort[NX_PORT2].usPortRole = NGN_PORTROLE_UP;
		}
	}
		
	gstNM.stNetworkConfigMain.stRelaySetting.b01LoopPort1 = pstFrm->astRelaySetting[RELAYSETTING_PORT12].b01LoopPort1;
	gstNM.stNetworkConfigMain.stRelaySetting.b01LoopPort2 = pstFrm->astRelaySetting[RELAYSETTING_PORT12].b01LoopPort2;
	
	return;
}

NX_VOID vNMG_StartTsn (
	FRM_NC_MAIN_REQ	*pstFrm
)
{
	NX_USHORT		usGMIDIndex		= (NX_USHORT)NX_ZERO;
	NX_USHORT		usDelayIndex	= (NX_USHORT)NX_ZERO;
	NX_USHORT		usMSTimeIndex	= (NX_USHORT)NX_ZERO;
	gstNM.stNetworkConfigMain.stNcfTsn.uchTimeMasterSlaveConf				= pstFrm->uchTimeMasterSlaveConf;
	for (usGMIDIndex = (NX_USHORT)NX_ZERO; usGMIDIndex < (NX_USHORT)GM_ID_SIZE; usGMIDIndex++) {
		gstNM.stNetworkConfigMain.stNcfTsn.auchGrandMasterClockIdentity[usGMIDIndex]	= pstFrm->auchGrandMasterClockIdentity[usGMIDIndex];
	}

	gstNM.stNetworkConfigMain.stNcfTsn.uchTimeSynchronizationMethod			= pstFrm->stTimeSynchronization.uchTimeSynchronizationMethod;

	gstNM.stNetworkConfigMain.stNcfTsn.uchDomainNo							= pstFrm->stTimeSynchronization.uchDomainNo;

	gstNM.stNetworkConfigMain.stNcfTsn.chSyncTransmitCycle					= (NX_CHAR)pstFrm->stTimeSynchronization.uchSyncTransmitCycle;

	gstNM.stNetworkConfigMain.stNcfTsn.uchSyncReceiveTimeout				= pstFrm->stTimeSynchronization.uchSyncReceiveTimeout;

	gstNM.stNetworkConfigMain.stNcfTsn.chAnnounceTransmitCycle				= (NX_CHAR)pstFrm->stTimeSynchronization.uchAnnounceTransmitCycle;

	gstNM.stNetworkConfigMain.stNcfTsn.uchAnnounceReceiveTimeout			= pstFrm->stTimeSynchronization.uchAnnounceReceiveTimeout;

	gstNM.stNetworkConfigMain.stNcfTsn.chPropagationDelayTransmitCycle		= pstFrm->stTimeSynchronization.chPropagationDelayTransmitCycle;

	gstNM.stNetworkConfigMain.stNcfTsn.chDelayRespTimer						= pstFrm->stTimeSynchronization.chDelayRespRcvTimer;

	for (usDelayIndex = (NX_USHORT)NX_ZERO; usDelayIndex < (NX_USHORT)PROP_DELAY_MEAS_METHOD_SIZE; usDelayIndex++) {
		if (usDelayIndex == (NX_USHORT)NX_ZERO) {
			gstNM.stNetworkConfigMain.stNcfTsn.auchPropagationDelayMeasureMethod[usDelayIndex]	= pstFrm->stTimeSynchronization.auchPropagationDelayMeasureMethod[usDelayIndex] & PROP_DELAY_P12_MSK;
		}
		else {
			gstNM.stNetworkConfigMain.stNcfTsn.auchPropagationDelayMeasureMethod[usDelayIndex]	= (NX_UCHAR)NX_ZERO;
		}
	}

	gstNM.stNetworkConfigMain.stNcfTsn.uchThresholdOfConsecutiveOutliers	= pstFrm->stTimeSynchronization.uchThresholdOfConsecutiveOutliers;

	if (pstFrm->stTimeSynchronization.ulWindowSetting >= (NX_ULONG)WINDOW_SETTING_CHK) {
		gstNM.stNetworkConfigMain.stNcfTsn.ulWindowSetting					= (NX_ULONG)(WINDOW_SETTING_CHK - NX_ONE);
	}
	else {
		gstNM.stNetworkConfigMain.stNcfTsn.ulWindowSetting					= pstFrm->stTimeSynchronization.ulWindowSetting;
	}

	for (usMSTimeIndex = (NX_USHORT)NX_ZERO; usMSTimeIndex < (NX_USHORT)MS_NODE_TIME_SIZE; usMSTimeIndex++) {
		gstNM.stNetworkConfigMain.stNcfTsn.auchMasterNodeTime[usMSTimeIndex]	= pstFrm->stTimeSynchronization.auchMasterNodeTime[usMSTimeIndex];
	}

	gstPtpCtrl.uchPtpProto = (NX_UCHAR)TSN_IEEE802_1_AS;
	
	return;
}

NX_VOID vNMG_CreateNwCfgMainRespNrml (
	FRM_NC_MAIN_REQ		*pstReq,
	NX_ULONG			ulCompareResult
)
{
	FRM_NC_MAIN_RESP_NORMAL	*pstResp;
	NX_USHORT				usRsvIndex	= (NX_USHORT)NX_ZERO;
	
	pstResp = (FRM_NC_MAIN_RESP_NORMAL*)gstNM.stTrnBuf.puchNetworkConfigMainResp;
	
	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_NC_MAIN_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);
	
	pstResp->uchFixedZero		=	(NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId			=	(NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum	=	(NX_USHORT)NX_ZERO;
	pstResp->usDivisionId		=	(NX_USHORT)NX_ZERO;
	
	if (ulCompareResult == NX_UL_OK) {
		pstResp->uchNetworkConfigResult = NC_RESP_RESULT_MATCH;
	}
	else {
		pstResp->uchNetworkConfigResult = NC_RESP_RESULT_MISSMATCH;
	}
	
	for (usRsvIndex = (NX_USHORT)NX_ZERO; usRsvIndex < (NX_USHORT)RESERVE_SIZE; usRsvIndex++) {
		pstResp->auchFixedZero[usRsvIndex]	= (NX_UCHAR)NX_ZERO;
	}

	return;
}

NX_VOID vNMG_CreateNwCfgMainRespFault (
	FRM_NC_MAIN_REQ		*pstReq,
	NX_USHORT			usFinCode
)
{
	FRM_NC_MAIN_RESP_ERR	*pstResp;

	pstResp = (FRM_NC_MAIN_RESP_ERR*)gstNM.stTrnBuf.puchNetworkConfigMainResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						usFinCode,
						sizeof(FRM_NC_MAIN_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= (NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId						= (NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum				= (NX_USHORT)NX_ZERO;
	pstResp->usDivisionId					= (NX_USHORT)NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsNetStsRcvNwCfgMainReq ( NX_VOID )
{
	NX_UCHAR	uchTsltNo = TSLT_TS0;
	NX_USHORT	usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	if (gstNM.stNet.usNetSts == NETSTS_RCVD_DETECTION) {
		
		usAuthClass = usACM_GetAuthenticationClass();
		if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
			vTsn_SetTime(gstNM.stNetworkConfigMain.stNcfTsn.auchMasterNodeTime);
		}

		gstNM.stNet.usStatusFinish |= FIN_RCVD_NWCFG_MAIN;
		
		if (FIN_RCVD_NWCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_NWCFG)) {
			for (uchTsltNo = TSLT_TS0; uchTsltNo < gstNM.stNetworkConfigTslt.uchTsltNum; uchTsltNo++) {
				vNMG_SetTsltTimeOffset(uchTsltNo, &gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo]);
			}
			
			if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
				vTsn_Start(&gstNM.stNetworkConfigMain.stNcfTsn);
			}
			gstNM.stNet.usNetSts = NETSTS_RCVD_NWCFG;
		}
	}
	return;
}

/*[EOF]*/
