/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "ccienx_api.h"

#define	IP_MIN					(0x00000001)
#define	IP_MAX					(0xDFFFFFFE)
#define	IP_TSN_BAN				(0x0000FFFF)
#define	SUBNETMASK_MIN			(0x00000001)
#define	SUBNETMASK_MAX			(0xFFFFFFFF)
#define	SUBNETMASK_NUM			(31)

NX_ULONG	ulNX_ChkIpAddress (
	NX_ULONG	ulIPAddress,
	NX_ULONG	ulSubnetMask
)
{
	NX_USHORT	usSubnetMaskCount;
	NX_ULONG	ulSubnetMaskTemp;
	NX_ULONG	ulResult;
	
	ulResult = NX_IP_OK;
	ulSubnetMaskTemp = (NX_ULONG)NX_ZERO;
	
	if ((ulIPAddress < (NX_ULONG)IP_MIN) ||
		(ulIPAddress > (NX_ULONG)IP_MAX)) {
		ulResult = NX_IP_NG_IP_RNG;
	}
	if ((ulSubnetMask >= (NX_ULONG)SUBNETMASK_MIN) &&
		(ulSubnetMask <= (NX_ULONG)SUBNETMASK_MAX)) {
	}
	else {
		ulResult = NX_IP_NG_SUBNET_RNG;
	}
	for (usSubnetMaskCount = (NX_USHORT)SUBNETMASK_NUM; usSubnetMaskCount > (NX_USHORT)NX_ZERO; usSubnetMaskCount--) {
		if ((ulSubnetMask & (NX_ULONG)((NX_USHORT)NX_ON << usSubnetMaskCount)) != (NX_ULONG)NX_OFF) {
			ulSubnetMaskTemp |= (NX_ULONG)((NX_USHORT)NX_ON << usSubnetMaskCount);
		}
		else {
			break;
		}
	}
	if (ulSubnetMaskTemp != ulSubnetMask) {
		ulResult = NX_IP_NG_SUBNET_VAL;
	}
	if ((ulIPAddress & ~ulSubnetMask) == ~ulSubnetMask ) {
		ulResult = NX_IP_NG_BROAD;
	}
	else if ((ulIPAddress & ~ulSubnetMask) == (NX_ULONG)NX_OFF) {
		ulResult = NX_IP_NG_IP_ZERO;
	}
	else {
		if ((ulIPAddress & NX_BIT00_15) == (NX_ULONG)IP_TSN_BAN) {
			ulResult = NX_IP_NG_TSN_BAN;
		}
	}
	
	return ulResult;
}

/*[EOF]*/
