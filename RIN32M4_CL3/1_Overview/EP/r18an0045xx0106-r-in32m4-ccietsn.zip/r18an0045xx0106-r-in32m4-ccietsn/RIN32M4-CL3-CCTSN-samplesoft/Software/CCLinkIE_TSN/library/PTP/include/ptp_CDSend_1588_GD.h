/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CDSEND_1588_GD_H__
#define __PTP_CDSEND_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_CDS {
	ST_CDS_NONE	= 0,
	ST_CDS_INITIALIZING,
	ST_CDS_WAITING,
	ST_CDS_SEND_DELAYREQ_INDICATION,
	ST_CDS_SEND_DELAYRESP_INDICAT,
	ST_CDS_MAX
} EN_ST_CDS;


typedef	enum	tagEN_EV_CDS {
	EV_CDS_BEGIN = 0,
	EV_CDS_DELAYREQ_SENDTIME_1588,
	EV_CDS_DELAYREQ_SEND_1588,
	EV_CDS_DELAYRESP_SEND_1588,
	EV_CDS_CLOSE_1588,
	EV_CDS_EVENT_MAX
} EN_EV_CDS;


typedef	struct tagCDSENDSM_1588_GD
{
	EN_ST_CDS			enStatusCDS;
	BOOL				blRcvdMDDelayReq;
	BOOL				blRcvdMDDelayResp;
	BOOL				blDReqSendTO;
	MDDELAYREQ*			pstRcvdMDDReqRcvPtr;
	MDDELAYREQ*			pstTxMDDReqSndPtr;
	USHORT				usRcvdMDDReqRcvPNumber;
	USHORT				usRcvdMDDRespRcvPNumber;
	MDDELAYRESP*		pstRcvdMDDRespRcvPtr;
	MDDELAYRESP*		pstTxMDDRespSndPtr;
	USCALEDNS			stDelayReqSendTime;
	TMO_MANAGE_INF_BLK*	pstTMO_DelayReqSendTime;
} CDSENDSM_1588_GD;	




#endif

