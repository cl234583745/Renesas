/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "ccienx_struct.h"
#include "ccienx_app_supply.h"
#include "NGN_ASIC.h"
#include "TOOL_api.h"
#include "INIT_commonip.h"
#include "INIT_jade.h"
#include "ETH_api.h"
#include "PHY_api.h"
#include "USN_api.h"
#include "SLMP_api.h"
#include "GDN_api.h"
#include "NMG_api.h"
#include "CYC_api.h"
#include "RXN_api.h"
#include "TXN_api.h"
#include "TSN_api.h"
#include "DRV_api.h"
#include "INTR_api.h"
#include "ccienx_api.h"
#include "SNMP_api.h"
#include "LOG_api.h"
#include "LSM_api.h"
#include "SYNC_api.h"
#include "ACM_api.h"

NX_VOID vINIT_IntervalTimerInit ( NX_VOID );

#define	TMCNT_DRIVER_PERIODIC	((NX_ULONG)31250 - 1)
#define	TMCNT_IPCOM				((NX_ULONG)3125 - 1)
#define	TMCNT_NCYC_TX			((NX_ULONG)1563 - 1)
#define	TMCNT_NCYC_RX			((NX_ULONG)1563 - 1)
#define	TMCNT_TSN				((NX_ULONG)6250 - 1)
#if 1	/* Modification for R-IN32M4 */
#define	TMCNT_LED				((NX_ULONG)62500 - 1)
#endif

NX_VOID vINIT_IntervalTimerInit ( NX_VOID )
{
	NX_USHORT	usClassASetting;
	usClassASetting = usACM_GetAuthenticationClass();

	
	vNX_timer_set(TMID_DRIVER_PERIODIC,	TMCK_320NS,		TMCNT_DRIVER_PERIODIC);
	
	vNX_timer_set(TMID_IPCOM,	TMCK_320NS,		TMCNT_IPCOM);
	
	vNX_timer_set(TMID_NCYC_TX,	TMCK_320NS,		TMCNT_NCYC_TX);

	vNX_timer_set(TMID_NCYC_RX,	TMCK_320NS,		TMCNT_NCYC_RX);
	
	vNX_timer_set(TMID_TSN,	TMCK_320NS,	TMCNT_TSN);

#if 1	/* Modification for R-IN32M4 */
	vNX_timer_set(TMID_LED,	TMCK_320NS,	TMCNT_LED);
#endif

	vNX_timer_start ( TMID_DRIVER_PERIODIC );
	vNX_timer_start ( TMID_IPCOM );
	if (NX_AUTHENTICATION_CLS_A == usClassASetting) {
	}
	else {
		vNX_timer_start ( TMID_NCYC_TX );
	}
	vNX_timer_start ( TMID_NCYC_RX );
	if (NX_AUTHENTICATION_CLS_A == usClassASetting) {
	}
	else {
		vNX_timer_start ( TMID_TSN );
	}
#if 1	/* Modification for R-IN32M4 */
	vNX_timer_start ( TMID_LED );
#endif

	return;
}

NX_VOID vNX_CcienxInit ( NX_VOID )
{
	NX_USHORT usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	vNX_FillMemory32((NX_VOID*)&gstNET, 0x00000000, sizeof(NET_INFO) / sizeof(NX_ULONG));

	vINIT_jade_sys();
	
	vACM_Init();
	
	vINIT_commonip_cn();
	vINIT_commonip_ir();
	vINIT_commonip_rg();
	vINIT_commonip_es();
	vINIT_commonip_rc();
	vINIT_commonip_wd();
	vINIT_commonip_ts();
	vINIT_commonip_sn();
	vINIT_commonip_sc();
	vINIT_commonip_md();
	vINIT_commonip_ax();
	vINIT_commonip_em();
	vINIT_commonip_cr();
	vINIT_commonip_gm();
	vINIT_commonip_rf();
	vINIT_commonip_txdisc();
	vINIT_commonip_tx();
	vINIT_commonip_rx();
	
	vLSM_Init();
	vINTR_Init();
	vRXN_Init();
	usAuthClass = usACM_GetAuthenticationClass();
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		vTXN_Init();
	}
	else {
		vTXN_Init_ClassA();
	}
	vETH_Init();
	vPHY_Init();
	vINIT_commonip_rcrlyvl();
	vDRV_Init();
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		vTSN_Init();
	}
	vTOOL_Init();
	vNMG_Init();
	vUSN_Init();
	vSLMP_Init();
	vCYC_Init();
	vSNMP_Init();
	vLOG_Init();
	vSYNC_Init();
	
	vINIT_IntervalTimerInit();
	
	NGN_SN_REG->R_SNCTR.DATA		=	(NX_ULONG)0x00000003;

#if NX_HWTEST_ES2 == 1
	gstAppInfo.stLibInfo.usRsv1 = 1;
#endif
#if REC_TSN_INF == 1
	gstAppInfo.stLibInfo.usRsv1 = 2;
#endif
	
	return;
}
/*[EOF]*/
