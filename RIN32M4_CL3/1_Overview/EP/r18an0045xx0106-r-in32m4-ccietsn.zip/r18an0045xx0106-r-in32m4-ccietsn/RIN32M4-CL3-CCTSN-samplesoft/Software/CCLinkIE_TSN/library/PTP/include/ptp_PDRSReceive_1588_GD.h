/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRSRECEIVE_1588_GD_H__
#define __PTP_PDRSRECEIVE_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#define		CHSHIFT_m1		(-1)


typedef	enum	tagEN_ST_PDRSR {
	ST_PDRSR_NONE	= 0,
	ST_PDRSR_DISCARD,
	ST_PDRSR_RECEIVED_DELAYRESP,
	ST_PDRSR_MAX
} EN_ST_PDRSR;


typedef	enum	tagEN_EV_PDRSR {
	EV_PDRSR_BEGIN = 0,
	EV_PDRSR_FOR_PDLRSRV_RCVMDDLRS,
	EV_PDRSR_CLOSE,
	EV_PDRSR_EVENT_MAX
} EN_EV_PDRSR;


typedef	struct tagPDRSRECEIVESM_1588_GD
{
	EN_ST_PDRSR		enStatusPDRSR;
	BOOL			blRcvdMDDelayResp;
	MDDELAYRESP*	pstRcvdMDDRespRcvPtr;
	MDDELAYRESP*	pstTxMDDRespSndPtr;
} PDRSRECEIVESM_1588_GD;	




#endif


