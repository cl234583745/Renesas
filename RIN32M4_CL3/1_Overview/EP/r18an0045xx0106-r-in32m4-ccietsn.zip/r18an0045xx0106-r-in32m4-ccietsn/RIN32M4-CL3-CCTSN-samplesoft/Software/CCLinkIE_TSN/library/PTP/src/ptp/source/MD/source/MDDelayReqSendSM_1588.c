/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "PTP_GlobalData.h"
#include "MDDelayCommonSM.h"
#include "MDDelayReqSendSM.h"
#include "MDDelayReqSendSM_1588.h"


#define D_FUNC		0
#define D_DREQTO	0

VOID (*const MDDelayReqSendSM_1588_Matrix[DMDDRQS_STATUS_MAX][DMDDRQS_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDDelayReqSendSM_01_1588, &MDDelayReqSendSM_NP_1588, &MDDelayReqSendSM_NP_1588, &MDDelayReqSendSM_NP_1588},
	{&MDDelayReqSendSM_01_1588, &MDDelayReqSendSM_02_1588, &MDDelayReqSendSM_NP_1588, &MDDelayReqSendSM_00_1588},
	{&MDDelayReqSendSM_01_1588, &MDDelayReqSendSM_02_1588, &MDDelayReqSendSM_NP_1588, &MDDelayReqSendSM_00_1588},
	{&MDDelayReqSendSM_01_1588, &MDDelayReqSendSM_02_1588, &MDDelayReqSendSM_03_1588, &MDDelayReqSendSM_00_1588}
};

VOID MDDelayReqSendSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDDREQSNDSM_EV	enEvt = MDDRQS_E_EVENT_MAX;
	MDDREQSNDSM_ST	enSts = MDDRQS_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDDReqSndEvent(usEvent, pstPort);
	enSts = GetMDDReqSndStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDDelayReqSendSM_1588    ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDDRQS_STATUS_MAX) && (enEvt != MDDRQS_E_EVENT_MAX))
	{
		(*MDDelayReqSendSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDDReqSndStatus(pstPort);
	printf ("<END  > [%02d]MDDelayReqSendSM_1588    ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDDelayReqSendSM_00_1588(PORTDATA* pstPort)
{
	MDDREQSDSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDDelayReqSendSM_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
	SetMDDReqSndStatus(MDDRQS_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDDelayReqSendSM_00_1588::-\n") );

	return;
}

VOID MDDelayReqSendSM_01_1588(PORTDATA* pstPort)
{
	MDDREQSDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
	SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);
	return;
}

VOID MDDelayReqSendSM_02_1588(PORTDATA* pstPort)
{
	MDDREQSDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	if (pstGbl->blRcvdMDDelayReq == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82003103);
		MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);
		return;
	}

#ifdef	PTP_USE_TRANS
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		PTP_NOTICE_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000012);
		MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);
		return;
	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
		MDDReqSnd_SntDRqWtFrTS_1588_TC(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_SNT_DREQ_WAIT_FOR_TMSTMP, pstPort);
		return;
	}
	else
	{
	}
#endif

	MDDReqSnd_SntDRqWtFrTmStmp_1588(pstGbl, pstPort);
	SetMDDReqSndStatus(MDDRQS_SNT_DREQ_WAIT_FOR_TMSTMP, pstPort);
	return;
}

VOID MDDelayReqSendSM_03_1588(PORTDATA* pstPort)
{
	INT nIndex;

	MDDREQSDSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::+\n"));

	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	if ( (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_DREQ) == 0 )
	{
		nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
		
		if ( gstDreqTmoManage[nIndex].pstDreqSendPort == pstPort )
		{
			ptp_dbg_msg( D_DREQTO, 
			             ("domain(%d)::del dreq timeout timer. port=[%d]\n", 
							 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
							 pstPort->stPort_GD.usThisPort) );

			tsn_Wrapper_MemSet( (VOID *)&gstDreqTmoManage[nIndex], 
								0, 
								sizeof(DREQTMOMAN) );
		}
	}


	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_8200230C);
		MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::-\n"));
		return;
	}
	if (SetMDDlyReqEvEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_8200230B);
		MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::-\n"));
		return;
	}

#ifdef	PTP_USE_TRANS
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		PTP_NOTICE_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000012);
		MDDReqSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::-\n"));
		return;
	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
		USHORT	index = 0U;
		if (JugMDDelayCorrectionPort(pstPort, &index) == FALSE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000013);
		}
		else
		{
			SetMDDelayCorrectionPortEgress(pstPort, index);
		}
		MDDReqSnd_WtSndDReq_1588(pstGbl, pstPort);
		SetMDDReqSndStatus(MDDRQS_WAIT_SND_DREQ, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::-\n"));
		return;
	}
	else
	{
	}
#endif

	MDDReqSnd_WtSndDReq_1588(pstGbl, pstPort);
	SetMDDReqSndStatus(MDDRQS_WAIT_SND_DREQ, pstPort);

	ptp_dbg_msg(D_FUNC, ("MDDelayReqSendSM_03_1588::-\n"));
	return;
}


VOID MDDelayReqSendSM_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDDReqSnd_NotEnable_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayReq = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	pstSmGbl->usDelayReqSequenceId = (USHORT)tsn_Wrapper_Rand();
	return TRUE;
}

BOOL MDDReqSnd_WtSndDReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayReq = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	return TRUE;
}

BOOL MDDReqSnd_SntDRqWtFrTmStmp_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*	pstPortMD = &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDDelayReq = FALSE;

	if (SetDelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	tsn_Wrapper_MemSet(&pstPort->stPort_GD.stDelayReqEgressTimestamp, 0L, sizeof(TIMESTAMP));
	if (TxDelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	pstPortMD->usTxDlySequenceId = pstSmGbl->usDelayReqSequenceId;

	pstPortMD->blTxDlySequencdIdChg = TRUE;

	pstSmGbl->usDelayReqSequenceId++;

	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL MDDReqSnd_SntDRqWtFrTS_1588_TC(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayReq = FALSE;

	if (SetDelayReqTC_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxDelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}
#endif

BOOL SetDelayReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*	pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*	pstClkDefaultDS	= &pstClockDT->stDefaultDS;
	PORT_DS*	pstPortDS			= &pstPort->stPortDS;

	PTPMSG_DELAY_REQ_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxDelayReq1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_DELAY_REQ );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0U;

	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstSmGbl->usDelayReqSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_DLY_REQ;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemSet(&pstMsg->stOriginTimestamp, 0, sizeof(pstMsg->stOriginTimestamp));
	GetPTPMSG_DELAY_REQ_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL SetDelayReqTC_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{


	MDDELAYREQ*	pstDlyReqSnd			= &pstPort->stPort_GD.stMdDelayReqSnd;

	CLOCKDATA*	pstClockDT			= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD		= &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	PTPMSG_DELAY_REQ_1588*	pstRcvMsg	= &pstClockGD->stDlyCorctionClock.stConDlyReq_1588;

	PTPMSG_DELAY_REQ_1588*	pstMsg		= NULL;
	pstMsg = &pstSmGbl->stTxDelayReq1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	tsn_Wrapper_MemCpy(pstMsg, pstRcvMsg, sizeof(*pstMsg));

	pstMsg->stHeader.usMegLength		= 0;

	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stCorrectionField, &pstDlyReqSnd->stCorrectionField,
		sizeof(pstMsg->stHeader.stCorrectionField));
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);


	GetPTPMSG_DELAY_REQ_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}
#endif

BOOL TxDelayReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{

	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDDelayReqSendSM;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxDelayReq1588,
		pstSmGbl->stTxDelayReq1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82002308);
		return FALSE;
	}
	return TRUE;
}

#endif
