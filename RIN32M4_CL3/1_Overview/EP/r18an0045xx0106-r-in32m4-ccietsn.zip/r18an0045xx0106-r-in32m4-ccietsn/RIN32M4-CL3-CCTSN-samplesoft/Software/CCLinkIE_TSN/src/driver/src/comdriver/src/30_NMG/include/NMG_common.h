/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __NMG_COMMON_H_INCLUDE__
#define __NMG_COMMON_H_INCLUDE__

#include "nx_common.h"
#include "nx_frame_common.h"
#include "TXN_api.h"
#include "RXN_api.h"
#include "tsn_common.h"
#include "ccienx_event.h"
#include "NMG_detail_err.h"
#include "NMG_api.h"
#include "ccienx_const_ex.h"


#define	NETSTS_INITIAL					((NX_USHORT)0)
#define	NETSTS_RCVD_DETECTION			((NX_USHORT)1)
#define	NETSTS_RCVD_NWCFG				((NX_USHORT)2)
#define	NETSTS_RCVD_SLCFG				((NX_USHORT)3)
#define	NETSTS_RCVD_CYCCFG				((NX_USHORT)4)
#define	NETSTS_START_CYCSND				((NX_USHORT)5)
#define	NETSTS_DLINK					((NX_USHORT)6)
#define	NETSTS_LINKDOWN					((NX_USHORT)7)
#define	NETSTS_LINKDOWN_ENR				((NX_USHORT)8)

#define	FIN_INITIAL						((NX_USHORT)0x0001)
#define	FIN_RCVD_DETECTION				((NX_USHORT)0x0002)
#define	FIN_RCVD_NWCFG_MAIN				((NX_USHORT)0x0004)
#define	FIN_RCVD_NWCFG_TSLT				((NX_USHORT)0x0008)
#define	FIN_RCVD_SLCFG					((NX_USHORT)0x0010)
#define	FIN_RCVD_CYCCFG_MAIN			((NX_USHORT)0x0020)
#define	FIN_RCVD_CYCCFG_TRNSPD			((NX_USHORT)0x0040)
#define	FIN_RCVD_CYCCFG_RCVSPD			((NX_USHORT)0x0080)
#define	FIN_RCVD_CYCCFG_SRC_INFO		((NX_USHORT)0x0100)
#define	FIN_TIMESYNC_CMP				((NX_USHORT)0x0200)
#define	FIN_DLINK						((NX_USHORT)0x0400)

#define	FIN_RCVD_NWCFG					((NX_USHORT)0x000C)
#define	FIN_RCVD_CYCCFG					((NX_USHORT)0x01E0)
#define	FIN_RCVD_CYCCFG_TIMECMP			((NX_USHORT)0x03E0)

#define	NET_100MENBLSTS_INIT			((NX_USHORT)0)
#define	NET_100MENBLSTS_WAITCYCCMP		((NX_USHORT)1)
#define	NET_100MENBLSTS_WAITCYCSW		((NX_USHORT)2)
#define	NET_100MENBLSTS_CMP				((NX_USHORT)3)

#define	NM_STS_WAIT_RCV					((NX_USHORT)0)
#define	NM_STS_WAIT_TRN					((NX_USHORT)1)

#define	RESP_NORMAL						((NX_ULONG)0)
#define	RESP_ERR						((NX_ULONG)1)
#define	RESP_DESTRUCT					((NX_ULONG)2)
#define	RESP_DIV_ERR					((NX_ULONG)3)
#define	RESP_NOTHING					((NX_ULONG)4)

#define	SLMP_FINISHCODE_NORMAL			((NX_USHORT)0x0000)

#define	SLMP_FRAMETYPE_REQ_6E			((NX_USHORT)0x0068)
#define	SLMP_FRAMETYPE_RESP_6E			((NX_USHORT)0x00E8)

#define	SLMP_CMD_0E90					((NX_USHORT)0x0E90)
#define	SLMP_CMD_0E92					((NX_USHORT)0x0E92)
#define	SLMP_CMD_0E93					((NX_USHORT)0x0E93)
#define	SLMP_CMD_0E94					((NX_USHORT)0x0E94)
#define	SLMP_SUBCMD_0000				((NX_USHORT)0x0000)
#define	SLMP_SUBCMD_0001				((NX_USHORT)0x0001)
#define	SLMP_SUBCMD_0002				((NX_USHORT)0x0002)
#define	SLMP_SUBCMD_0003				((NX_USHORT)0x0003)

#define	NTF_CODE_RELAYSET				((NX_USHORT)0x0001)
#define	NTF_CODE_BMCA_CMP				((NX_USHORT)0x0100)
#define	NTF_CODE_TIMESYNC_CMP			((NX_USHORT)0x0101)
#define	NTF_CODE_TOPOLOGY				((NX_USHORT)0x0202)


#define	MULCAST_GP_SIZE_MAX				((NX_USHORT)16)

#define	SIZE_ETHERTYPE					((NX_USHORT)2)
#define	SIZE_ETHERNET_HEADER_DA			((NX_ULONG)6)
#define	SIZE_ETHERNET_HEADER_SA			((NX_ULONG)6)



#define	NX_UC_RECV_NECESSITY_NG_2_OR_MORE	((NX_UCHAR)2)
#define	NX_US_VID_NG_0000					((NX_USHORT)0x0000)
#define	NX_US_VID_NG_0FFF					((NX_USHORT)0x0FFF)

#define	NX_SPLD_NUM_MAX_OVER_SND			((NX_USHORT)(NX_TRN_SPLD_NUM+1))
#define	NX_SPLD_NUM_MAX_OVER_RCV			((NX_USHORT)(NX_RCV_SPLD_NUM+1))

#define NX_FRAME_NGN_NONCYC			((NX_USHORT)0x0001)
#define NX_FRAME_NGN_CYC_BOND		((NX_USHORT)0x0003)

#define NX_VLAN_DISABLE				((NX_USHORT)0)
#define NX_VLAN_ENABLE				((NX_USHORT)1)

#define	NX_RECV_DATA_SIZE_0			((NX_USHORT)0x0000)
#define	NX_STSW_DATA_SIZE			((NX_USHORT)0x0008)

#define	NX_CYCLENUM_MSK				((NX_ULONGLONG)(0x00000000FFFFFFFF))

#define	NX_RELAYSETTING_LOOPPORT_EXIST				((NX_UCHAR)0x01)
#define	NX_RELAYSETTING_FILTER_NONE					((NX_UCHAR)0x00)
#define	NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN		((NX_UCHAR)0x01)
#define	NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN	((NX_UCHAR)0x02)

#define	NX_NOTIFY_FLG_OFF							((NX_USHORT)0x0000)
#define	NX_NOTIFY_FLG_ON							((NX_USHORT)0x0001)

#define	NX_SPLD_ENBLPTN_STSW						((NX_USHORT)0x0001)
#define	NX_SPLD_ENBLPTN_RX							((NX_USHORT)0x0002)
#define	NX_SPLD_ENBLPTN_RWR							((NX_USHORT)0x0004)
#define	NX_SPLD_INDX_STSW							((NX_USHORT)0)
#define	NX_SPLD_INDX_RX								((NX_USHORT)1)
#define	NX_SPLD_INDX_RWR							((NX_USHORT)2)
#define	NX_SPLD_ENBLPTN_NUM							((NX_USHORT)7)

#define	NX_DLINKERR_CYCLESETTING_OVER				((NX_UCHAR)0x04)
#define	DLINKERR_CYCLESETTING_ZERO					((NX_UCHAR)0x00)

#define	NX_NTWCNF_MAC_SETTING_NUM_MAX				((NX_UCHAR)16)
#define	NX_NTWCNF_VLAN_SETTING_NUM_MAX				((NX_UCHAR)16)

#define	AUTHENTICATION_CLASS_A						((NX_UCHAR)0x00)
#define	AUTHENTICATION_CLASS_B						((NX_UCHAR)0x01)

#define	NM_IP_ADDR_SW_00							((NX_USHORT)0x0000)
#define	NM_IP_ADDR_SW_FF							((NX_USHORT)0x00FF)
#define	NM_CYCACTWAIT								((NX_USHORT)2)

#define	NX_MAC_UNICAST								((NX_ULONG)0)
#define	NX_MAC_BRDMLTCAST							((NX_ULONG)1)
#define	NX_UL_NO_VLAN								((NX_ULONG)0x00000000)
#define	NX_UL_VLAN_OK								((NX_ULONG)0x00000001)
#define	NX_UL_VLAN_NG								((NX_ULONG)0xFFFFFFFF)
#define	NX_UL_NO_VLAN_TAG							((NX_ULONG)0x00000000)

typedef struct tagNM_NET {
	NX_USHORT	usNetSts;
	NX_USHORT	usStatusFinish;
	NX_USHORT	usCycCnt100MEnbSts;
	NX_USHORT	usRsv;
	NX_ULONG	ulTimeSetFlg;
} NM_NET;

typedef struct tagNM_DETECTION {
	NX_UCHAR	auchMacAddrPrevSnd[6];
	NX_USHORT	usPortPrevSnd;
	union {
		struct {
			NX_UCHAR	b01DetectionSrc:	1;
			NX_UCHAR	b01Phase		:	1;
			NX_UCHAR	b06Dummy1:			6;
		} BIT;
		NX_UCHAR		uchSendInfo;
	} stSendInfo;
	NX_UCHAR			auchRsv[3];
} NM_DETECTION;

typedef struct tagNM_TESTDATA {
	NX_UCHAR	auchMacAddrPrevSnd[6];
	NX_USHORT	usPortPrevSnd;
} NM_TESTDATA;

typedef struct tagNM_NWCFG_MAIN {
	union {
		struct {
			NX_UCHAR	b01IefMix:			1;
			NX_UCHAR	b07Rsv1:			7;
		} stBits;
		NX_UCHAR		uchData;
	} stIefMixSetting;
	DETECT_TOPOLOGY		stDtctTopology;
	NX_UCHAR			uchTSNum;
	RELAY_SETTING		stRelaySetting;
	NX_UCHAR			uchTrnForbidTime;
	NX_UCHAR			uchRsv[3];
	NCF_TSN_INFO		stNcfTsn;
	NCF_COMCYC_INFO		stNcfComCyc;
} NM_NWCFG_MAIN;

typedef struct tagTSLT_OFFSET {
	NX_ULONG	ulStartOffset_ns;
	NX_USHORT	usStartOffset_s;
	NX_ULONG	ulEndOffset_ns;
	NX_USHORT	usEndOffset_s;
	NX_USHORT	usRelayBanUse;
	NX_ULONG	ulRelayBanOffset_ns;
	NX_USHORT	usRelayBanOffset_s;
} TSLT_OFFSET;

typedef struct tagVLAN_SET {
	NX_USHORT	usVid;
	NX_USHORT	usPcp;
	NX_UCHAR	uchTsltNo;
	NX_UCHAR	auchRsv[3];
} VLAN_SET; 

typedef struct tagVLAN_CONFIG {
	NX_USHORT	usVlanNum;
	NX_USHORT	usRsv;
	VLAN_SET	astVlan[16];
} VLAN_CONFIG;

typedef struct tagNM_NWCFG_TSLT {
	TSLT_OFFSET			astTsltOffset[TS_SIZE];
	NX_UCHAR			uchTsltNum;
	NX_UCHAR			auchRsv[3];
	VLAN_CONFIG			astVlanConfig[2];
} NM_NWCFG_TSLT;

typedef struct tagNM_NOTIFICATION {
	NX_USHORT			usFailResponseExStNo;
	NX_UCHAR			auchRsv[2];
} NM_NOTIFICATION;

typedef struct tagNM_SLVCFG {
	NX_USHORT			usWdcFuncSts;
	NX_USHORT			usRsv;
} NM_SLVCFG;

typedef struct tagNM_CYCCFG_MAIN {
	NX_USHORT			usEmgGroupSetting;
	union {
		struct {
			NX_UCHAR	b04GofGroupSetting:	4;
			NX_UCHAR	b04Rsv1:			4;
		} stBits;
		NX_UCHAR		uchData;
	} stGofGroupSetting;
	NX_UCHAR			auchRsv[1];
	NX_ULONG			ulVlanNo;
} NM_CYCCFG_MAIN;

typedef struct tagNM_TRNBUF {
	NCYC_TX_FRAME	*pstDetectionAck;
	NCYC_TX_FRAME	*pstTestDataAck;
	NX_UCHAR		*puchNetworkConfigMainResp;
	NX_UCHAR		*puchNetworkConfigTsltResp;
	NX_UCHAR		*puchSlaveConfigResp;
	NX_UCHAR		*puchCyclicConfigMainResp;
	NX_UCHAR		*puchCyclicConfigTrnSubPayloadResp;
	NX_UCHAR		*puchCyclicConfigRcvSubPayloadResp;
	NX_UCHAR		*puchCyclicConfigRcvSrcInfoResp;
	NX_UCHAR		*puchNotificationReq;
	NX_UCHAR		*puchNotificationResp;
} NM_TRNBUF;

typedef struct tagNM_WCH_NTF_RESP {
	NX_USHORT	usSndSerial;
	NX_USHORT	usRsv;
} NM_WCH_NTF_RESP;

typedef struct tagNM_PREV_VALUE {
	NX_ULONG			ulLinkUpSts_P1;
	NX_ULONG			ulLinkUpSts_P2;
	NX_UCHAR			uchDuplicateIPFlg;
	NX_UCHAR			uchDuplicateIPPeriodic;
	NX_UCHAR			auchRsv[2];
} NM_PREV_VALUE;

typedef struct tagNM_WAIT_INFO {
	NX_ULONG			ulDtRcvWaitFlg;
	NX_ULONG			ulDtRcvWaitStartTime;
	NX_ULONG			ulDtRcvWaitTimeout;
} NM_WAIT_INFO;

typedef struct tagNM_CTRL {
	NM_NET				stNet;
	NM_DETECTION		stDetection[NX_PORT_SIZE];
	NM_TESTDATA			stTestData[NX_PORT_SIZE];
	NM_NWCFG_MAIN		stNetworkConfigMain;
	NM_NWCFG_TSLT		stNetworkConfigTslt;
	NM_NOTIFICATION		stNotification;
	NM_SLVCFG			stSlaveConfig;
	NM_CYCCFG_MAIN		stCyclicConfigMain;
	NM_WCH_NTF_RESP		stWchNtfResp;
	NM_TRNBUF			stTrnBuf;
	NM_WAIT_INFO		stWaitInfo;
	NX_USHORT			usBMCARcvPort;
	NX_USHORT			usNotifyTslTimeCmpFlg;
	NX_USHORT			usNotifyDLinkErrFlg;
	NX_USHORT			ausNotifyLinkDownFlg[NX_PORT_SIZE];
	NX_ULONG			aulLinkUpStsPre[NX_PORT_SIZE];
	NX_UCHAR			uchDuplicateIPFlg;
	NX_UCHAR			uchDuplicateIPPeriodic;
	NM_PREV_VALUE		stPrevValue;
	NX_USHORT			usCycActWaitCnt;
	NX_UCHAR			uchSelfFunction;
	NX_UCHAR			uchSelfFunction2;
	NX_USHORT			usFixSyncModeFlag;
	NX_USHORT			usPrvSyncMode;
} NM_CTRL;

typedef struct tagCYC_PRM {
	NX_USHORT	usSizeRX;
	NX_USHORT	usSizeRWr;
	NX_USHORT	usSizeRY;
	NX_USHORT	usSizeRWw;
	NX_USHORT	usSizeStsW;
} CYC_PRM;

typedef struct tagRCV_CYC_ADDR {
	NX_ULONG	ulAddrRY_A;
	NX_ULONG	ulAddrRWw_A;
	NX_ULONG	ulAddrRY_B;
	NX_ULONG	ulAddrRWw_B;
	NX_ULONG	ulAddrRY_C;
	NX_ULONG	ulAddrRWw_C;
} RCV_CYC_ADDR;

typedef struct tagTRN_CYC_ADDR {
	NX_ULONG	ulAddrRX_A;
	NX_ULONG	ulAddrRWr_A;
	NX_ULONG	ulAddrRX_B;
	NX_ULONG	ulAddrRWr_B;
	NX_ULONG	ulAddrRX_C;
	NX_ULONG	ulAddrRWr_C;
} TRN_CYC_ADDR;


NX_EXTERN	NM_CTRL	gstNM;

NX_VOID		vNMG_InitCieNetMngDt ( NX_VOID );
NX_VOID		vNMG_RcvDtMain ( NX_VOID );
NX_VOID		vNMG_ReqTrnDetectionAck ( NX_VOID );
NX_VOID		vNMG_CallbackTrnDetectionAck (NX_ULONG, NX_ULONG);

NX_VOID		vNMG_CallbackTrnTestDataAck (NX_ULONG, NX_ULONG);
NX_VOID		vNMG_NotifyFirstCycRcvCmp ( NX_VOID );
NX_VOID		vNMG_UpdateRsvSta ( NX_USHORT );
NX_VOID		vNMG_NotifyDLinkErr( NX_VOID );
NX_ULONG	ulNMG_CtrlMstMacAddr ( NX_UCHAR* pauchMacAddr );
NX_VOID		vNMG_SaveIPAddress (NX_ULONG,NX_ULONG);

NX_VOID		vNMG_AnalyzeDetection (NX_UCHAR*, NX_USHORT, NX_VOID*);
NX_VOID		vNMG_AnalyzeNetworkConfigMainReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeNetworkConfigTsltReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeSlaveConfigReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeCyclicConfigMainReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeCycCfgRcvSpdReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeCycCfgTrnSpdReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeCycCfgRcvReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeNotificationReq (NX_USHORT, NX_ULONG, NX_VOID*);
NX_VOID		vNMG_AnalyzeNotificationResp (NX_USHORT, NX_ULONG, NX_VOID*);

NX_VOID		vNMG_SetSlmpRespHead6E (SLMP_REQUEST_6E*, SLMP_RESPONSE_6E*, NX_USHORT, NX_USHORT);

NX_VOID		vNMG_PreparSndNotificationReq ( NX_USHORT );

NX_VOID		vNMG_InitCieNetMngSlmp ( NX_VOID );
NX_VOID		vNMG_RcvCmnSlmpMain ( NX_VOID );
NX_VOID		vNMG_ReqTrnNetworkConfigMainResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnNetworkConfigTsltResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnSlaveConfigResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnCyclicConfigMainResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnCycCfgTrnSpdResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnCycCfgRcvSpdResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnCycCfgRcvResp ( NX_VOID );
NX_VOID		vNMG_ReqTrnNotificationReq ( NX_VOID );
NX_VOID		vNMG_ReqTrnNotificationResp ( NX_VOID );
NX_USHORT	usNMG_RecognizeSlmpCmd ( NX_USHORT, NX_USHORT, NX_USHORT );
NX_VOID		vNMG_InitSlmpReqFinFlg ( NX_VOID );

NX_VOID		vNMG_NetStsInit ( NX_VOID );
NX_VOID		vNMG_NetStsInitEnroute ( NX_VOID );
NX_VOID		vNMG_RetryNotificationSend ( NX_VOID );

NX_VOID		vNMG_SetHopCount ( NX_USHORT, NX_USHORT);
NX_VOID		vNMG_ClearHopCount (NX_VOID);

NX_VOID		vNMG_AdjustTsnTimeCmp ( NX_VOID );
NX_VOID		vNMG_ComCycEnable ( NX_VOID );
NX_VOID		vNMG_ActivateTimeslot ( NX_VOID );
NX_VOID		vNMG_DeactivateTimeslot ( NX_VOID );
NX_VOID		vNMG_DataLinkDownCmp ( NX_VOID );

NX_VOID		vNMG_SetTsltTimeOffset ( NX_UCHAR, TSLT_OFFSET* );

NX_UCHAR	uchNMG_CreatePortLinkStsData ( NX_USHORT );
NX_VOID		vSetCycActWaitCnt ( NX_USHORT );
NX_USHORT	usGetCycActWaitCnt ( NX_VOID );

NX_VOID		vNMG_SetNmgErr (NX_USHORT, NX_USHORT*);
NX_VOID		vNMG_ClrNmgErr ( NX_VOID );
NX_VOID		vNMG_SetNmgErrDt (NX_USHORT, NX_USHORT*);
NX_VOID		vNMG_ClrNmgErrDt ( NX_VOID );
NX_VOID		vNMG_ClrNmgLastErr ( NX_VOID );
NX_VOID		vNMG_NotifyNmgErr ( NX_VOID );

NX_VOID		vNMG_ClearTxPhysicalPort (NX_ULONG);
NX_VOID		vNMG_InitTxPhysicalPort (NX_ULONG, NX_ULONG, NX_USHORT);

NX_ULONG	vNMG_ChkMacAddrBrdMlt_LtEd ( NX_UCHAR* );

NX_VOID		vNMG_UpdateRelaySettingChkRslt (NX_UCHAR, NX_UCHAR);
NX_VOID		vNMG_ChkLinkDown ( NX_VOID );
NX_USHORT	usNMG_ChkCyclicSnd (NX_UCHAR, NX_UCHAR);
NX_VOID		vNMG_GetPortSndDescriptor (NX_UCHAR, NX_UCHAR, NX_USHORT*, NX_USHORT*, NX_USHORT*);
NX_VOID		vNMG_RelayRamClr ( NX_VOID );
NX_VOID		vNMG_ChkRelayRamOverflow ( NX_ULONG );
NX_ULONG    ulNMG_GetVlanTag ( 	NX_ULONG* );

#endif
/*[EOF]*/
