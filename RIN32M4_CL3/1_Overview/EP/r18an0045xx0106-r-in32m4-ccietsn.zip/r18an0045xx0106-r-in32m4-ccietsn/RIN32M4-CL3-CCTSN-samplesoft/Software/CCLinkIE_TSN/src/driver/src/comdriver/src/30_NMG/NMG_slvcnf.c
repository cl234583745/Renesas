/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_slaveconfig.h"
#include "NMG_self_spec.h"
#include "SLMP_api.h"
#include "NGN_ASIC.h"
#include "cyclic_address.h"
#include "ccienx_app_supply.h"
#include "ACM_api.h"

#define MSK_FUNC_WDCOFF		((NX_UCHAR)0xFB)


NX_VOID	vNMG_ChkSlaveConfigReq ( FRM_SC_REQ*, NX_ULONG*, NX_ULONG*, NX_ULONG );
NX_VOID	vNMG_CreateSlaveConfigRespNrml ( FRM_SC_REQ*, NX_ULONG );
NX_VOID	vNMG_CreateSlaveConfigRespFault ( FRM_SC_REQ* );
NX_VOID	vNMG_Extract_SlaveCfgReq ( FRM_SC_REQ* );
NX_VOID	vNMG_TrnsStsRcvSlaveCfgReq ( NX_VOID );

NX_VOID vNMG_AnalyzeSlaveConfigReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_SC_REQ	*pstFrm;
	NX_ULONG	ulChkResult	= NX_ZERO;
	NX_ULONG	ulVerificationResult = NX_UL_OK;

	pstFrm = (FRM_SC_REQ*)pData;
	
	
	vNMG_ChkSlaveConfigReq(pstFrm, &ulChkResult, &ulVerificationResult, ulIPAddress);
	
	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_SlaveCfgReq(pstFrm);
		
		vNMG_CreateSlaveConfigRespNrml(pstFrm, ulVerificationResult);
		vNMG_ReqTrnSlaveConfigResp();
		
		vNMG_TrnsStsRcvSlaveCfgReq();
		vNMG_InitTxPhysicalPort(NX_MASTER_CONTROL ,ulIPAddress, usPort);
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateSlaveConfigRespFault(pstFrm);
		vNMG_ReqTrnSlaveConfigResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_ChkSlaveConfigReq (
	FRM_SC_REQ	*pstFrm,
	NX_ULONG	*pulChkResult,
	NX_ULONG	*pulVerificationResult,
	NX_ULONG	ulIPAddeess
)
{
	*pulVerificationResult = NX_UL_OK;

	if (pstFrm->usStationMode != gstAppInfo.stCieDevInfo.usStationMode) {
		*pulVerificationResult = NX_UL_NG;
	}

	if ((NX_USHORT)NX_OFF == gstNET.stCtrlMst.usFixed) {
		gstNET.stCtrlMst.usFixed		= (NX_USHORT)NX_ON;
		gstNET.stCtrlMst.ulIPAddress	= ulIPAddeess;
		if ((USHORT)NX_OFF == gstNM.usFixSyncModeFlag) {
			*pulChkResult = RESP_NORMAL;
		}
		else {
			if (gstNM.usPrvSyncMode == pstFrm->stCommonSetting.stBits.b01NetSyncSetting) {
				*pulChkResult = RESP_NORMAL;
			}
			else {
				gstNET.stCtrlMst.usFixed	= (NX_USHORT)NX_OFF;
				*pulChkResult				= RESP_ERR;
				vNMG_SetNmgErr(EVENTCODE_SYNC_CHANGE_ERR, (NX_USHORT*)&DetailErrorTbl_SlvCfg[NMG_IDX_ERR_PARAM_001]);
			}
		}
	}
	else {
		if (ulIPAddeess == gstNET.stCtrlMst.ulIPAddress) {
				*pulChkResult = RESP_NORMAL;
		}
		else {
			*pulChkResult = RESP_DESTRUCT;
		}
	}

	return;
}

NX_VOID vNMG_CreateSlaveConfigRespNrml (
	FRM_SC_REQ	*pstReq,
	NX_ULONG	ulVerificationResult
)
{
	FRM_SC_RESP_NORMAL	*pstResp;
	NX_UCHAR	uchSelfFunction = (NX_UCHAR)NX_ZERO;
	NX_USHORT	usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_USHORT	usSyncMode;
	NX_USHORT	usWdcFuncSts;
	
	pstResp = (FRM_SC_RESP_NORMAL*)gstNM.stTrnBuf.puchSlaveConfigResp;
	
	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_SC_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);
	
	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;
	
	pstResp->stDevice.usDeviceVersion		= gstAppInfo.stCieDevInfo.usDeviceVersion;
	
	pstResp->stDevice.usVendorCode			= gstAppInfo.stCieDevInfo.usVendorCode;
	
	pstResp->stDevice.ulModelCode			= gstAppInfo.stCieDevInfo.ulModelCode;
	
	pstResp->stDevice.usExModelCode			= gstAppInfo.stCieDevInfo.usExModelCode;
	
	pstResp->stDevice.usDeviceType			= gstAppInfo.stCieDevInfo.usDeviceType;
	
	if ((NX_LIB_MODE_FASTIO2 == gstAppInfo.stLibInfo.usLibMode) ||
		(NX_LIB_MODE_FASTIO3 == gstAppInfo.stLibInfo.usLibMode)) {
		pstResp->stDevice.ulMemAddBitStoM	= gaulMemAdd_RX[NX_LIB_MODE_FASTIO];
	}
	else {
		pstResp->stDevice.ulMemAddBitStoM	= gaulMemAdd_RX[gstAppInfo.stLibInfo.usLibMode];
	}
	pstResp->stDevice.ulMemAddWordStoM		= MEMADD_RWR;
#ifdef SAFETY_PDU_ENABLE
	pstResp->stDevice.ulMemAddSafeStoM		= MEMADD_SPDUX;
#endif
	pstResp->stDevice.ulMemAddBitMtoS		= gaulMemAdd_RY[gstAppInfo.stLibInfo.usLibMode];
	pstResp->stDevice.ulMemAddWordMtoS		= MEMADD_RWW;
#ifdef SAFETY_PDU_ENABLE
	pstResp->stDevice.ulMemAddSafeMtoS		= MEMADD_SPDUY;
#endif
	pstResp->stDevice.ulMemAddStateNotif	= MEMADD_STSW;

	pstResp->stDevice.usCycSizeBitStoM		= gstAppInfo.stCieNetInfo.usDefaultSizeRX;
	pstResp->stDevice.usCycSizeWordStoM		= gstAppInfo.stCieNetInfo.usDefaultSizeRWr;
#ifdef SAFETY_PDU_ENABLE
	pstResp->stDevice.usCycSizeSafeStoM		= gstAppInfo.stCieNetInfo.usDefaultSizeSpdux;
#endif
	pstResp->stDevice.usCycSizeBitMtoS		= gstAppInfo.stCieNetInfo.usDefaultSizeRY;
	pstResp->stDevice.usCycSizeWordMtoS		= gstAppInfo.stCieNetInfo.usDefaultSizeRWw;
#ifdef SAFETY_PDU_ENABLE
	pstResp->stDevice.usCycSizeSafeMtoS		= gstAppInfo.stCieNetInfo.usDefaultSizeSpduy;
#endif
	pstResp->stDevice.usCycSizeStateNotif	= NX_STSW_DATA_SIZE;
	
	pstResp->stDevice.auchFixedZero1[0]		= NX_ZERO;
	usAuthClass = usACM_GetAuthenticationClass();
	
	if(NX_AUTHENTICATION_CLS_B == usAuthClass) {
		if ((gstNET.stApp.usSyncMode 	== SYNCMODE_UNSYNC) ||
			((gstNET.stApp.usSyncMode 	== SYNCMODE_SYNC) && (gstAppInfo.stFuncInfo.uchNwSyncEnableFlg == (NX_UCHAR)NX_ON))) {
			pstResp->stDevice.stUnitVeriResult.stBits.b01UnitVeriResult = (NX_UCHAR)NX_OFF;
		}
		else {
			pstResp->stDevice.stUnitVeriResult.stBits.b01UnitVeriResult	= (NX_UCHAR)NX_ON;
			vNMG_SetNmgErr(EVENTCODE_SYNCSETTING, (NX_USHORT*)&DetailErrorTbl_SlvCfg[NMG_IDX_ERR_PARAM_001]);
		}
	}
	else {
		if(SYNCMODE_UNSYNC == gstNET.stApp.usSyncMode) {
			pstResp->stDevice.stUnitVeriResult.stBits.b01UnitVeriResult = (NX_UCHAR)NX_OFF;
		}
		else {
			pstResp->stDevice.stUnitVeriResult.stBits.b01UnitVeriResult	= (NX_UCHAR)NX_ON;
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_SlvCfg[NMG_IDX_ERR_PARAM_001]);
		}
	}
	uchSelfFunction = gstNM.uchSelfFunction;
	usSyncMode = gstNET.stApp.usSyncMode;
	
	usWdcFuncSts = usNX_GetWdcFuncSts(usSyncMode);
	
	if ( NX_WDCFUNC_DSBL == usWdcFuncSts ) {
		uchSelfFunction = (uchSelfFunction & MSK_FUNC_WDCOFF);
		gstNM.stSlaveConfig.usWdcFuncSts = NX_WDCFUNC_DSBL;
	}
	else {
		gstNM.stSlaveConfig.usWdcFuncSts = NX_WDCFUNC_ENBL;
	}
	pstResp->stDevice.stFunction.uchData = uchSelfFunction;
	
	pstResp->stDevice.stOptionInfo.uchData	= NX_ZERO;
	pstResp->stDevice.stOptionInfo.uchData	= gstAppInfo.stCieDevInfo.uchOption;
	
	pstResp->stDevice.usStationSubIdNum		= gstAppInfo.stCieDevInfo.usNumOfSubID;
	
	pstResp->stVerificationResult.uchData	= NX_ZERO;
	if (ulVerificationResult == NX_UL_OK) {
		pstResp->stVerificationResult.stBits.b01VerificationResult	= SC_RESP_STAMODE_MATCH;
	}
	else {
		pstResp->stVerificationResult.stBits.b01VerificationResult	= SC_RESP_STAMODE_MISSMATCH;
	}
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		pstResp->uchAuthenticationClass			= AUTHENTICATION_CLASS_B;
	}
	else {
		pstResp->uchAuthenticationClass			= AUTHENTICATION_CLASS_A;
	}
	
	return;
}

NX_VOID vNMG_CreateSlaveConfigRespFault (
	FRM_SC_REQ		*pstReq
)
{
	FRM_SC_RESP_ERR	*pstResp;

	pstResp = (FRM_SC_RESP_ERR*)gstNM.stTrnBuf.puchSlaveConfigResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						CMM_SLMP_MISS_REQDATA,
						sizeof(FRM_SC_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo	;

	return;
}

NX_VOID vNMG_Extract_SlaveCfgReq (
	FRM_SC_REQ	*pstFrm
)
{
	
	if (pstFrm->stCommonSetting.stBits.b01NetSyncSetting == SC_REQ_APPSYNC_EN) {
		gstNET.stApp.usSyncMode = SYNCMODE_SYNC;
	}
	else {
		gstNET.stApp.usSyncMode = SYNCMODE_UNSYNC;
	}
	
	return;
}

NX_VOID vNMG_TrnsStsRcvSlaveCfgReq ( NX_VOID )
{
	if (gstNM.stNet.usNetSts == NETSTS_RCVD_NWCFG) {
		
		gstNM.stNet.usStatusFinish |= FIN_RCVD_SLCFG;
		gstNM.stNet.usNetSts = NETSTS_RCVD_SLCFG;
	}
	
	return;
}

/*[EOF]*/
