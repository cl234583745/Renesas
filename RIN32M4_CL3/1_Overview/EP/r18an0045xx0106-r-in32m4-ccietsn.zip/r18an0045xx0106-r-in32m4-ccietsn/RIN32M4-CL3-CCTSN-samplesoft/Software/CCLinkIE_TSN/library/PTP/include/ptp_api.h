/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTPAPI_H__
#define __PTPAPI_H__
#include <ptp_type.h>
#include <ptp_ddt.h>
#include <ptp_api_netipv6.h>
#define	RET_ENOERR			(0)
#define	RET_EINVAL			(1)
#define	RET_ESTATE			(2)
#define	RET_ENOMEM			(3)
#define	RET_ETRANS			(4)
#define	RET_ETMO			(5)
#define RET_ETCPIP			(6)
#define	RET_EWRAP			(7)
typedef enum tagCLOCKKIND
{
	CLK_KIND_BOUND_ORDI =0,
	CLK_KIND_TRANSPARENT
} CLOCKKIND;

typedef enum tagCLKPROTO
{
	PROTOCOL_IEEE1588 = 0,
	PROTOCOL_IEEE802_1_AS
} CLOCKPROTO;


typedef enum tagCLOCKTRANS
{
	CLK_TRANS_IEEE802_1_AS = 0,
	CLK_TRANS_IEEE1588_L2,
	CLK_TRANS_IEEE1588_L4_IPV4,
	CLK_TRANS_IEEE1588_L4_IPV6
} CLOCKTRANS;

typedef struct tagCLOCKKNDINF
{
	CLOCKPROTO		enClockPtpProtcol;
	CLOCKKIND		enClockKind;
	CLOCKTRANS		enClockTrpProtocol;
	UCHAR			uchInterfaceNum;
	UCHAR			uchDomainNum;
	CLOCKIDENTITY	stClockIdentity;
} CLOCKKNDINF;

typedef struct tagPTPINFSET
{
	CLOCKKNDINF *pstClockKndInfo;
	VOID		*pvTransAdrInfo;
	VOID		*pvClockInfo;
	VOID		*pvPortInfo;
	ULONG		ulME_extend;
} PTPINFSET;
#define	USE_ME_EXTEND_1588_STR_MASTER	1U
#define	USE_ME_EXTEND_1588_SYNC_LOCKED	2U
#define	USE_ME_EXTEND_1588_DREQ			4U
#define	USE_ME_EXTEND_AS_GPTP_CAPABLE_1	8U
#define	USE_ME_EXTEND_AS_GPTP_CAPABLE_2	16U


typedef struct tagIPV6ADDR {
	struct ptp_in6_addr	stSrcIpv6Addr;
	UINT				unInterfaceId;
	struct ptp_in6_addr	stDstIpv6Addr;
} IPV6ADDR;

typedef struct tagIEEE1588_L4V6 {
	INT				nPrefixLen;
	IPV6ADDR		*pstV6addr;
} IEEE1588_L4V6;

typedef struct tagIPV4ADDR {
	ULONG		ulSrcIpv4Addr;
	ULONG		ulDstIpv4Addr;
} IPV4ADDR;

typedef struct tagIEEE1588_L4V4 {
	ULONG		ulNetMask;
	IPV4ADDR	*pstMyIpAdd;
} IEEE1588_L4V4;

typedef struct tagMACADDR {
	UCHAR		uchMac[6];
} MACADDR;

typedef struct tagIEEE1588_L2 {
	MACADDR		*pstMacAdd;
} IEEE1588_L2;

typedef struct tagCLOCKINFSET
{
	UCHAR		uchDomainNum;
	BOOL		blTwoStepFlag;
	CLOCKQUALITY stClockQuality;
	UCHAR		uchPriority1;
	UCHAR		uchPriority2;
	BOOL		blSlaveOnly;
	BOOL		blExternalPortConfiguration;
	USCALEDNS	stAveDelayTrash;
	UCHAR		uchRateCalDatNum;
	ULONG		ulSyncSendHoldTime;
	ULONG		ulDReqSendHoldTime;
	ULONG		ulDelayRespTimeout;
	ULONG		ulSyncTransTimeout;

} CLOCKINFSET;

typedef enum tagCLKDELAY
{
	DELAY_E2E=1,
	DELAY_P2P=2,
	DELAY_DISABLED=0xFE
}CLOCKDELAY;

typedef struct tagTRANSPARENT_CLOCKINFSET
{	CLOCKIDENTITY stClockIdentity;
	CLOCKDELAY	enDelayMechanism;
	BOOL		blTwoStepFlag;
	USCALEDNS	stAveDelayTrash;
} TRANSPARENT_CLOCKINFSET;

typedef struct tagCLOCKASINFSET
{
	UCHAR	   uchDomainNum;
	CLOCKQUALITY stClockQuality;
	UCHAR	uchPriority1;
	UCHAR	uchPriority2;
	BOOL	blGmCapable;
	BOOL	blExternalPortConfiguration;
	USCALEDNS	stAveDelayTrash;
	ULONG		ulSyncTransTimeout;
	ULONG		ulSyncSendHoldTime;
	UCHAR		uchRateCalDatNum;
} CLOCKASINFSET;

#define	STACK_N_MIN	2
#define	STACK_N_MAX	255

typedef enum tagPORTSTATE
{
	DisabledPort = 3,
	MasterPort = 6,
	PassivePort = 7,
	SlavePort = 9
} PORTSTATE;


typedef struct tagPORTINFSET
{
	BOOL	blPortValid;
	CHAR	chInitialLogAnnounceInt;
	UCHAR	uchAnnounceReceiptTimeout;
	CHAR	chInitialLogSyncInt;
	CHAR	chLogMinDelayReqInt;
	CLOCKDELAY enDelayMechanism;
	CHAR	chLogMinPdelayReqInt;
	PORTSTATE enPortState;
	BOOL	blUnicast;
} PORTINFSET;


typedef struct tagTRANSPARENT_PORTINFSET
{
	BOOL  	blPortValid;
	
	CHAR	chLogMinPdelayReqInt;
	BOOL	blUnicast;
} TRANSPARENT_PORTINFSET;

typedef struct tagPORTASINFSET
{
	BOOL  	blPortValid;
	CHAR	chInitialLogAnnounceInt;
	BOOL	blUseMgtSettableLogAnnounceInt;
	CHAR	chMgtSettableLogAnnounceInt;
	CHAR	chInitialLogSyncInt;
	BOOL	blUseMgtSettableLogSyncInt;
	CHAR	chMgtSettableLogSyncInt;
	UCHAR	uchAnnounceReceiptTimeout;
	UCHAR 	uchSyncReceiptTimeout;
	BOOL	blOneStepTransmit;
	BOOL	blInitialOneStepTxOper;
	BOOL	blUseMgtSettableOneStepTxOper;
	BOOL	blMgtSettableOneStepTxOper;
	CHAR	chInitialLogPdelayReqInt;
	BOOL	blUseMgtSettableLogPdelayReqInt;
	CHAR	chMgtSettableLogPdelayReqInt;
	USHORT	usAllowedLostResponses;
	USHORT	usAllowedFaults;
	PORTSTATE enPortState;
	CHAR	chLogGptpCapMsgInt;
	UCHAR	uchGptpCapReceiptTimeout;
} PORTASINFSET;


#ifndef	_SENDTIMESCB_
#define _SENDTIMESCB_

typedef	void	(* SENDTIMESCB)(
	INT					nErrorCode,
	UCHAR				uchPort,
	EXTENDEDTIMESTAMP *	pstTimeStamp,
	VOID *				pvLinkId);

#endif


#ifdef __cplusplus
extern "C" {
#endif

INT	ptp_init(
			void);

INT	ptp_config(
			PTPINFSET *pstPtpInfSet);

INT	ptp_open(
			void);

INT	ptp_close(
			void);

INT	ptp_get_para_AS(
			USHORT	usParamId_AS,
		    UCHAR  uchDomainNumber,
			UCHAR	uchPortNum,
			UCHAR*	puchInfo,
			USHORT	usInfoBufSize);

INT	ptp_set_para_AS(
			USHORT	usParamId_AS,
		    UCHAR  uchDomainNumber,
			UCHAR	uchPortNum,
			UCHAR*	puchInfo,
			USHORT	usInfoBufSize);

INT	ptp_get_para_1588( USHORT usParamId_1588,
					   UCHAR  uchDomainNumber,
					   UCHAR  uchPortNum,
					   UCHAR *puchInfo,
					   USHORT usInfoBufSize );
INT	ptp_set_para_1588( USHORT usParamId_1588,
					   UCHAR  uchDomainNumber,
					   UCHAR  uchPortNum,
					   UCHAR *puchInfo,
					   USHORT usInfoBufSize );

INT	ptp_uninit(
			void);

#ifdef __cplusplus
}
#endif

#endif
