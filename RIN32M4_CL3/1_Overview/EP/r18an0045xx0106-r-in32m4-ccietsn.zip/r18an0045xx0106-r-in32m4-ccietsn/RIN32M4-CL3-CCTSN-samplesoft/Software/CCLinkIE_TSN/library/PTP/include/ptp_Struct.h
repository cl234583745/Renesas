/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_STRUCT_H__
#define __PTP_STRUCT_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "PTP_Message.h"
#include "ptp_api.h"

#include "MDPdelayReq_GD.h"

typedef struct	tagDELAYINFO_E2E	{
	TIMESTAMP	stSyncOriginTimeStamp;
	FRAC_NSEC64 stSyncCorrectionField;
	TIMESTAMP	stSyncReceiveTime;
	TIMESTAMP	stDelayReqSendTime;
	TIMESTAMP	stDelayRespOriginTime;
	FRAC_NSEC64 stDelayRespCorrectionField;
} DELAYINFO_E2E;


typedef struct	tagDELAYINFO_P2P	{
	TIMESTAMP	stSyncOriginTimeStamp;
	FRAC_NSEC64 stSyncCorrectionField;
	TIMESTAMP	stSyncReceiveTime;
	TIMESTAMP	stPdlyReqSendtime;
	TIMESTAMP	stPdlyRespReqRecpTimeStamp;
	FRAC_NSEC64 stPdlyRespCorrectionField;
	TIMESTAMP	stPdlyRespFupReqRecpTimeStamp;
	FRAC_NSEC64 stPdlyRespFupCorrectionField;
	TIMESTAMP	stPdlyRespReceiveTime;
	BOOL		blClockRateValid;
} DELAYINFO_P2P;

typedef union	tagDELAYTIMEINFO	{
	DELAYINFO_E2E	stDelayInfo_E2E;
	DELAYINFO_P2P	stDelayInfo_P2P;
} DELAYTIMEINFO;


typedef struct	tagDELAYINFO	{
	CLOCKDELAY		enClockDelay;
	DELAYTIMEINFO	stDelayTimeInfo;
	USHORT			usSlavePortNumber;
} DELAYINFO;



typedef	enum	tagENUM_DELAYMECHANISM
{
	ENUM_DELAYMECHANISM_E2E			=	0x01,
	ENUM_DELAYMECHANISM_P2P			=	0x02,
	ENUM_DELAYMECHANISM_DISABLED	=	0xFE

}	ENUM_DELAYMECHANISM;




#define	PDELAYTTARRAY_SIZE	(MAX_PORT)


typedef enum tagENUM_SUPPORTPTPTYPE {
	ENUM_SUPPORTPTPTYPE_IEEE802_1AS,
	ENUM_SUPPORTPTPTYPE_IEEE1588
} ENUM_SUPPORTPTPTYPE;


typedef enum tagENUM_PORTSTATE
{
	ENUM_PORTSTATE_DISABLED	=	0x03,
	ENUM_PORTSTATE_MASTER	=	0x06,
	ENUM_PORTSTATE_PASSIVE	=	0x07,
	ENUM_PORTSTATE_SLAVE	=	0x09
} ENUM_PORTSTATE;

typedef	ENUM_PORTSTATE		ENUM_SELECTEDSTATE;


typedef	enum tagENUM_CLOCKSUPPORTTYPE_1588
{
	ENUM_CSTYPE_ORDINARYCLOCK_1588 = 0,
	ENUM_CSTYPE_BOUNDARYCLOCK_1588,
	ENUM_CSTYPE_TRANSCLOCKE2E_1588,
	ENUM_CSTYPE_TRANSCLOCKP2P_1588,
	ENUM_CSTYPE_MANAGEMENT_1588

}	ENUM_CLOCKSUPPORTTYPE_1588;


typedef	struct tagACCEPTABLEMASTER
{
	PORTIDENTITY	stAcceptblPortIdentity;
	UCHAR			uchAlternatePriority1;
}	ACCEPTABLEMASTER;

typedef void (*TMSCB_FUNC_PTR)(USHORT ,VOID*);

typedef struct tagTIMESTAMP_CALLBK_INF
{
	BOOL		*pblTimeStampFlag;
	TIMESTAMP	*pstTimeStamp;
	TMSCB_FUNC_PTR	pfnCall;
	UCHAR		uchTimeStampType;
	USHORT		usEvent;
	struct tagPORTDATA	*pstPortData;

} TIMESTAMP_CALLBK_INF;


typedef	struct	tagMDSYNCSEND
{
	UCHAR			uchClockNumber;
	SCALEDNS		stFollowUpCorrectionField;
	PORTIDENTITY	stSourcePortIdentity;
	CHAR			chLogMessageInterval;
	TIMESTAMP		stPreciseOriginTimestamp;
	USCALEDNS		stUpstreamTxTime;
	DOUBLE			dbRateRatio;
	USHORT			usGmTimeBaseIndicator;
	SCALEDNS		stLastGmPhaseChange;
	DOUBLE			dbLastGmFreqChange;

}	MDSYNCSEND;


typedef	struct	tagMDSYNCRECEIVE
{
	UCHAR			uchClockNumber;
	SCALEDNS		stFollowUpCorrectionField;
	PORTIDENTITY	stSourcePortIdentity;
	CHAR			chLogMessageInterval;
	TIMESTAMP		stPreciseOriginTimestamp;
	USCALEDNS		stUpstreamTxTime;
	DOUBLE			dbRateRatio;
	USHORT			usGmTimeBaseIndicator;
	SCALEDNS		stLastGmPhaseChange;
	DOUBLE			dbLastGmFreqChange;

}	MDSYNCRECEIVE;


typedef	struct	tagPORTSYNCSYNC
{
	UCHAR			uchClockNumber;
	USHORT			usLocalPortNumber;
	USCALEDNS		stSyncReceiptTimeoutTime;
	SCALEDNS		stFollowUpCorrectionField;
	PORTIDENTITY	stSourcePortIdentity;
	CHAR			chLogMessageInterval;
	TIMESTAMP		stPreciseOriginTimestamp;
	USCALEDNS		stUpstreamTxTime;
	DOUBLE			dbRateRatio;
	USHORT			usGmTimeBaseIndicator;
	SCALEDNS		stLastGmPhaseChange;
	DOUBLE			dbLastGmFreqChange;

}	PORTSYNCSYNC;


typedef	struct	tagMDDELAYREQ
{
	UCHAR			uchClockNumber;
	SCALEDNS		stCorrectionField;
	PORTIDENTITY	stSourcePortIdentity;
	USHORT			usSequenceId;
	TIMESTAMP		stOriginTimestamp;
	PTPMSG_DELAY_REQ_1588  stConDlyReq_1588;
	PTPMSG_DELAY_RESP_1588 stConDlyResp_1588;
}	MDDELAYREQ;


typedef	struct	tagMDDELAYRESP
{
	UCHAR			uchClockNumber;
	SCALEDNS		stCorrectionField;
	PORTIDENTITY	stSourcePortIdentity;
	USHORT			usSequenceId;
	CHAR			chLogMessageInterval;
	TIMESTAMP		stReceiveTimestamp;
	PORTIDENTITY	stRequestPortIdentity;

}	MDDELAYRESP;


#define	MDDELAYCRRCTION_ADDMAX	10
typedef struct	tagMDDELAYCORRCTIONINFO
{
	UCHAR			uchCrrctionCount;
	PORTIDENTITY	stCrrctionPortIdentity[MDDELAYCRRCTION_ADDMAX];

}	MDDELAYCORRCTIONINFO;

typedef	struct	tagMDCORRCTIONPORT
{
	BOOL			blFlg;
	PORTIDENTITY	stPortIdentity;
	USHORT			usSequenceId;
	TIMESTAMP		stIngressTimestamp;
	TIMESTAMP		stEgressTimestamp;
}	MDCORRCTIONPORT;

typedef struct	tagMDDELAYCORRCTION
{
	UCHAR			uchCrrctionCount;
	UCHAR			uchCrrctionLocation;
	MDCORRCTIONPORT	stCrrctionPort[MDDELAYCRRCTION_ADDMAX];
	PTPMSG_DELAY_REQ_1588	stConDlyReq_1588;
	PTPMSG_DELAY_RESP_1588	stConDlyResp_1588;

}	MDDELAYCORRCTION;


typedef struct	tagMDSYNCCORRCTION
{
	UCHAR			uchCrrctionCount;
	MDCORRCTIONPORT	stCrrctionPort;
	PTPMSG_SYNC_1588	 stConSync_1588;
	PTPMSG_FOLLOWUP_1588 stConFollowUp_1588;
}	MDSYNCCORRCTION;




typedef	struct	tagDEFAULT_DS
{
	CLOCKIDENTITY	stClockIdentity;
	USHORT			usNumberPorts;
	CLOCKQUALITY	stClockQuality;
	UCHAR			uchPriority1;
	UCHAR			uchPriority2;
	UCHAR			uchDomainNumber;
}DEFAULT_DS;


typedef	struct	tagCURRENT_DS
{
	USHORT			usStepsRemoved;
	TIME_INTERVAL	stOffsetFromMaster;

}	CURRENT_DS;


typedef	struct	tagPARENT_DS
{
	PORTIDENTITY	stParentPortIdentity;
	CLOCKIDENTITY	stGrandmasterIdentity;
	CLOCKQUALITY	stGrandmasterClockQuality;
	UCHAR			uchGrandmasterPriority1;
	UCHAR			uchGrandmasterPriority2;

}	PARENT_DS;

#define	TIMESOURCE_ATOMIC_CLOCK			0x10
#define	TIMESOURCE_GPS					0x20
#define	TIMESOURCE_TERRESTRIAL_RADIO	0x30
#define	TIMESOURCE_PTP					0x40
#define	TIMESOURCE_NTP					0x50
#define	TIMESOURCE_HAND_SET				0x60
#define	TIMESOURCE_OTHER				0x90
#define	TIMESOURCE_INTREVAL_OSCILLATOR	0xA0

typedef	struct	tagTIMEPROPERTIES_DS
{
	SHORT		sCurrentUtcOffset;
	BOOL		blCurrentUtcOffsetValid;
	BOOL		blLeap59;
	BOOL		blLeap61;
	BOOL		blTimeTraceable;
	BOOL		blFrequencyTraceable;
	BOOL		blPtpTimescale;
	UCHAR		uchTimeSource;

}	TIMEPROPERTIES_DS;




typedef	struct	tagDEFAULT_1AS_DS
{
	BOOL		blGmCapable;
	SHORT		sCurrentUtcOffset;
	BOOL		blCurrentUtcOffsetValid;
	BOOL		blLeap59;
	BOOL		blLeap61;
	BOOL		blTimeTraceable;
	BOOL		blFrequencyTraceable;
	BOOL		blPtpTimescale;
	UCHAR		uchTimeSource;
	USHORT		usSdoId;
	BOOL		blExternalPortConfiguration;
	BOOL		blInstanceEnable;

}	DEFAULT_1AS_DS;


typedef	struct	tagCURRENT_1AS_DS
{
	SCALEDNS	stLastGmPhaseChange;
	DOUBLE		dbLastGmFreqChange;
	USHORT		usGmTimebaseIndicator;
	ULONG		ulGmChangeCount;
	ULONG		ulTimeOfLastGmChangeEvent;
	ULONG		ulTimeOfLastGmPhaseChangeEvent;
	ULONG		ulTimeOfLastGmFreqChangeEvent;
}	CURRENT_1AS_DS;


typedef	struct	tagPARENT_1AS_DS
{
	LONG		lCumulativeRateRatio;
}	PARENT_1AS_DS;


typedef	struct	tagPATHTRACE_1AS_DS
{
	CLOCKIDENTITY		stList[1];
	BOOL				blEnable;

}	PATHTRACE_1AS_DS;



typedef	struct	tagCMLDSDEFAULT_1AS_DS
{
	CLOCKIDENTITY	stClockIdentity;
	USHORT			usNumberPorts;
	USHORT			usSdoId;

}	CMLDSDEFAULT_1AS_DS;



typedef	struct	tagDEFAULT_1588_DS
{
	BOOL		blTwoStepFlag;
	BOOL		blSlaveOnly;

}	DEFAULT_1588_DS;


typedef	struct	tagCURRENT_1588_DS
{
	TIME_INTERVAL		stMeanPathDelay;

}	CURRENT_1588_DS;


#define	OFFSETSCALEDLOGVALIANCE_MAX			0xFFFFU

typedef	struct	tagPARENT_1588_DS
{
	BOOL		blParentStats;
	USHORT		usObservedPOSLogVariance;
	ULONG		ulObservedPCPhChangeRate;
}	PARENT_1588_DS;


typedef	struct	tagTCDEFAULT_1588_DS
{
	CLOCKIDENTITY		stClockIdentity;
	USHORT				usNumberPorts;
	ENUM_DELAYMECHANISM enDdelayMechanism;
	UCHAR				uchPprimaryDomain;

}	TCDEFAULT_1588_DS;





typedef	struct	tagPORT_DS
{
	PORTIDENTITY	stPortIdentity;
	ENUM_PORTSTATE	enPortState;
	UCHAR			uchAnnounceReceiptTimeout;
	BYTE			byVersionNumber;

}	PORT_DS;




typedef	struct	tagPORT_1AS_DS
{
	BOOL		blPtpPortEnabled;
	BOOL		blAsCapable;
	CHAR		chInitialLogAnnounceInterval;
	CHAR		chCurrentLogAnnounceInterval;
	BOOL		blUseMgtSetLogAnnounceInterval;
	CHAR		chMgtSettableLogAnnounceInterval;
	CHAR		chInitialLogSyncInterval;
	CHAR		chCurrentLogSyncInterval;
	BOOL		blUseMgtSettableLogSyncInterval;
	CHAR		chMgtSettableLogSyncInterval;
	UCHAR		uchSyncReceiptTimeout;
	USCALEDNS	stSyncReceiptTimeoutTimeInterval;

	CHAR		chInitialLogGptpCapMsgInt;
	CHAR		chCurrentLogGptpCapMsgInt;
	BOOL		blUseMgtSettableLogGptpCapMsgInt;
	CHAR		chMgtSettableLogGptpCapMsagInt;
	CHAR		chLogGptpCapMsgInt;

	UCHAR		uchGPtpCapableReceiptTimeout;
	BOOL		blOneStepTxOper;
	BOOL		blOneStepReceive;
	BOOL		blOneStepTransmit;
	BOOL		blInitialOneStepTxOper;
	BOOL		blCurrentOneStepTxOper;
	BOOL		blUseMgtSettableOneStepTxOper;
	BOOL		blMgtSettableOneStepTxOper;
	BOOL		blSyncLocked;
	BYTE		byMinorVersionNumber;

}	PORT_1AS_DS;


typedef	struct	tagPORTSTATISTICS_1AS_DS
{
	ULONG		ulRxSyncCount;
	ULONG		ulRxOneStepSyncCount;
	ULONG		ulRxFollowUpCount;
	ULONG		ulRxAnnounceCount;
	ULONG		ulRxPTPPacketDiscardCount;
	ULONG		ulSyncReceiptTimeoutCount;
	ULONG		ulAnnounceReceiptTimeoutCount;
	ULONG		ulTxSyncCount;
	ULONG		ulTxOneStepSyncCount;
	ULONG		ulTxFollowUpCount;
	ULONG		ulTxAnnounceCount;

	ULONG		ulTxMessageErrorCount;
}	PORTSTATISTICS_1AS_DS;


typedef	struct	tagDESCRIPTIONPORT_1AS_DS
{
	OCTET6		stProfileIdentifier;

}	DESCRIPTIONPORT_1AS_DS;


typedef	struct	tagACCEPTABLE_M_PORT_1AS_DS
{
	BOOL		blAcceptableMasterTableEnabled;

}	ACCEPTABLE_M_PORT_1AS_DS;


typedef	struct	tagCMLDSPORT_1AS_DS
{
	PORTIDENTITY	stPortIdentity;
	BOOL			blCmldsPortEnabled;
	BOOL			blIsMeasuringDelay;
	BOOL			blAsCapableAcrossDomains;
	USCALEDNS		stNeighborPropDelay;
	USCALEDNS		stNeighborPropDelayThresh;
	SCALEDNS		stDelayAsymmetry;
	LONG			lNeighborRateRatio;
	CHAR			chInitialLogPdelayReqInterval;
	CHAR			chCurrentLogPdelayReqInterval;
	BOOL			blUseMgtSttblLogPdReqInterval;
	CHAR			chMgtSttblLogPdReqInterval;
	USHORT			usAllowedLostResponses;
	USHORT			usAllowedFaults;
	BYTE			byVersionNumber;

}	CMLDSPORT_1AS_DS;


typedef	struct	tagCMLDSASYMMSR_1AS_DS
{
	BOOL	blAasymmetryMeasurementMode;

}	CMLDSASYMMSR_1AS_DS;


typedef	struct	tagCMLDSDSCRPORT_1AS_DS
{
	OCTET6		stProfileIdentifier;

}	CMLDSDSCRPORT_1AS_DS;


typedef	struct	tagCMLDSPORTSTATISTICS_1AS_DS
{
	ULONG		ulRxPdelayRequestCount;
	ULONG		ulRxPdelayResponseCount;
	ULONG		ulRxPdelayResponseFollowUpCount;
	ULONG		ulRxPTPPacketDiscardCount;
	ULONG		ulPdelayAllwLostRespExcdCount;
	ULONG		ulTxPdelayRequestCount;
	ULONG		ulTxPdelayResponseCount;
	ULONG		ulTxPdelayResponseFollowUpCount;

}	CMLDSPORTSTATISTICS_1AS_DS;





typedef	struct	tagPORT_1588_DS
{
	CHAR				chLogMinDelayReqInterval;
	TIME_INTERVAL		stPeerMeanPathDelay;
	CHAR				chLogAnnounceInterval;
	CHAR				chLogSyncInterval;
	ENUM_DELAYMECHANISM	enDelayMechanism;
	CHAR				chLogMinPdelayReqInterval;

}	PORT_1588_DS;


typedef	struct	tagTRANSPARENTCLOCKPORT_1588_DS
{
	PORTIDENTITY	stPortIdentity;
	CHAR			chLogMinPdelayReqInterval;
	BOOL			blFaultyFlag;
	TIME_INTERVAL	stPeerMeanPathDelay;
}	TRANSPARENTCLOCKPORT_1588_DS;

typedef	struct tagCLOCK_GD
{
	BOOL				blBEGIN;
	USCALEDNS			stClockMasterSyncInterval;
	CHAR				chClockMasterLogSyncInterval;
	EXTENDEDTIMESTAMP	stSyncReceiptTime;
	USCALEDNS			stSyncReceiptLocalTime;

	BOOL				blGmPresent;
	USHORT				usCurMasterTimeBaseIndicator;
	SCALEDNS			stCurMasterLastPhaseChange;
	SCALEDNS			stCurMasterLastPhaseChangeForGM;
	DOUBLE				dbCurMasterLastFreqChange;
	DOUBLE				dbCurMasterLastFreqChangeForGM;

	ENUM_SELECTEDSTATE	enSelectedState[MAX_PORT+1];

	DOUBLE				dbRateRatio;

	USCALEDNS			stSyncReceiptCMTime;


	CLOCKIDENTITY		stThisClock;
	BOOL				blInstanceEnable;
	ENUM_SUPPORTPTPTYPE	enSupportPTPType;

	DELAYINFO			stDelayInfo;
	USCALEDNS			stAveDelayTrash;
	ULONG				ulME_extend;

#ifdef	PTP_USE_ME_HW_ASSIST

#endif

	UCHAR				uchRateCalDatNum;

	USCALEDNS			stSyncSendHoldTime;

	USCALEDNS		stSyncTransTimeout;


} CLOCK_GD;

typedef struct tagCLOCK_1AS_GD
{

	BOOL	blgPTPCapableExecFlag;

}	CLOCK_1AS_GD;

typedef	struct tagCLOCK_1588_GD
{
	ENUM_CLOCKSUPPORTTYPE_1588	enClockSupportType_1588;
	USCALEDNS					stBoundaryClockSyncInterval_1588;
	CHAR						chBCLogSyncInterval_1588;
	USCALEDNS					stClockDelayReqInterval;
	CHAR						chClockLogDelayReqInterval;

#ifdef	PTP_USE_TRANS
	MDDELAYCORRCTIONINFO		stDlyCorrctionInfo;
	MDDELAYCORRCTION			stDlyCorctionClock;
#endif

	MDSYNCCORRCTION				stSynCorctionClock;
	USCALEDNS					stDelayRespTimeout;
	USCALEDNS					stDReqSendHoldTime;

}	CLOCK_1588_GD;


typedef union tagTRANSADRINFO {
	IPV6ADDR	stIpv6Addr;
	IPV4ADDR	stIpv4Addr;
	MACADDR		stMacAdd;
} TRANSADRINFO;


typedef struct tagPORTADDRDATA
{
	TRANSADRINFO	stPortAddr[MAX_PORT+1];
}	PORTADDRDATA;


typedef	struct tagPORT_GD
{
	BOOL			blAsymmetryMeasurementMode;
	CHAR			chCurrentLogSyncInterval;
	CHAR			chInitialLogSyncInterval;
	USCALEDNS		stSyncInterval;
	DOUBLE			dbNeighborRateRatio;
	USCALEDNS		stNeighborPropDelay;
	SCALEDNS		stDelayAsymmetry;
	BOOL			blComputeNeighborRateRatio;
	BOOL			blComputeNeighborPropDelay;
	BOOL			blPortOper;
	USHORT			usThisPort;
	BOOL			blSyncLocked;
	BOOL			blNeighborGptpCapable;
	BOOL			blSyncSlowdown;
	USCALEDNS		stOldAnnounceInterval;
	MDSYNCSEND		stMdSyncSend;
	MDSYNCRECEIVE	stMdSyncReceive;
	MDDELAYREQ		stMdDelayReqRcv;
	MDDELAYREQ		stMdDelayReqSnd;
	MDDELAYRESP		stMdDelayRespRcv;
	MDDELAYRESP		stMdDelayRespSnd;
	TIMESTAMP		stSyncEventEgressTimestamp;
	TIMESTAMP		stSyncEventIngressTimestamp;

#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP		stSyncEventIngressTimestamp_Frun;
#endif

	TIMESTAMP		stSyncMsgEgressTimestamp;
	TIMESTAMP		stDelayReqIngressTimestamp;

#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP		stDelayReqIngressTimestamp_Frun;
#endif

	TIMESTAMP		stDelayReqEgressTimestamp;
#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP		stDelayReqEgressTimestamp_Frun;
#endif

	FRAC_NSEC64		stSyncCorrectionField;
	FRAC_NSEC64		stDelayRespCorrectionField;
	TIMESTAMP_CALLBK_INF stTimeStampCallbkInf_SYNC;
	TIMESTAMP_CALLBK_INF stTimeStampCallbkInf_DREQ;
	TIMESTAMP_CALLBK_INF stTimeStampCallbkInf_PDREQ;
	TIMESTAMP_CALLBK_INF stTimeStampCallbkInf_PDRESP;
	USCALEDNS		stOldSyncInterval;
	SCALEDNS		stD3_DelayTime;
	CHAR			chParentLogSyncInterval;
	BOOL			blUnicast;
	TIMESTAMP		stPdlyReqSendtime;
	TIMESTAMP		stPdlyRespReqRecpTimeStamp;
	FRAC_NSEC64		stPdlyRespCorrectionField;
	TIMESTAMP		stPdlyRespFupReqRecpTimeStamp;
	FRAC_NSEC64		stPdlyRespFupCorrectionField;
	TIMESTAMP		stPdlyRespReceiveTime;
	ULONG			ulPropDelayNumber;
	USCALEDNS		stAveDelayTime;
	ULONG			ulAsCapableChangeONCnt;
	ULONG			ulAsCapableChangeOFFCnt;

	LONG						lCmldsPortNumber;
	BOOL						blPdelayExecFlag;
	BOOL						blPortValid;
	MDPDLYREQSM_STACK_MANAGE*	pstPdlyIntStackMan;

}	PORT_GD;


typedef	struct tagPORTMD_GD
{
	CHAR		chCurrentLogPdelayReqInterval;
	CHAR		chInitialLogPdelayReqInterval;
	USCALEDNS	stPdelayReqInterval;
	USHORT		usSyncSequenceId;
	USHORT		usTxSyncSequenceId;
	USHORT		usTxDlySequenceId;
	BOOL		blTxDlySequencdIdChg;
	USHORT		usTxPdlySequenceId;

	BOOL		blPdelayFlag;

	TIMESTAMP	stPdlyReqEventEgressTimestamp;
	TIMESTAMP	stPdlyRespEventIngressTimestamp;
	TIMESTAMP	stPdlyReqMsgIngressTimestamp;
	TIMESTAMP	stPdlyRespMsgEgressTimestamp;
	FRAC_NSEC64	stPdlyReqMsgIngressCorrection;
	FRAC_NSEC64	stPdlyRespMsgEgressCorrection;
	TIMESTAMP	stPdlyReqEventIngressTimestamp;
	TIMESTAMP	stPdlyRespEventEgressTimestamp;

	MDDELAYCORRCTION	stDlyCorctionPortInfo;
	TIME_INTERVAL		stDlyCorrctionField;

	PTPMSG_ANNOUNCE						stConAnnounce;

	PTPMSG_SYNC_TWO_STEP_1AS			stConSyncTwo_1AS;
	PTPMSG_SYNC_ONE_STEP_1AS			stConSyncOne_1AS;
	PTPMSG_FOLLOWUP_1AS					stConFollowUp_1AS;
	PTPMSG_PDELAY_REQ_1AS				stConPdlyReq_1AS;
	PTPMSG_PDELAY_RESP_1AS				stConPdlyResp_1AS;
	PTPMSG_PDRESP_FOLLOWUP_1AS			stConPDRespFlwUp_1AS;

	PTPMSG_SYNC_1588					stConSync_1588;
	PTPMSG_FOLLOWUP_1588				stConFollowUp_1588;
	PTPMSG_DELAY_REQ_1588				stConDlyReq_1588;
	PTPMSG_DELAY_RESP_1588				stConDlyResp_1588;
	PTPMSG_PDELAY_REQ_1588				stConPdlyReq_1588;
	PTPMSG_PDELAY_RESP_1588				stConPdlyResp_1588;
	PTPMSG_PDRESP_FOLLOWUP_1588			stConPDRespFlwUp_1588;
	USHORT								usSignalingSequenceId;
}	PORTMD_GD;




typedef struct tagPORT_1AS_GD
{
	USCALEDNS	stOldGptpCapMsgInt;
	USCALEDNS	stGptpCapMsgInt;
	BOOL		blGptpCapMsgSlowdown;
} PORT_1AS_GD;



typedef struct tagPORT_1588_GD
{
	CMLDSPORT_1AS_DS* 			pstCmldsPortDs;
	CMLDSPORTSTATISTICS_1AS_DS*	pstCmldsPortStatDs;
}PORT_1588_GD;







typedef enum tagGPTPCAPTRSM_ST
{
	GPTPCAPTRSM_NONE  = 0,
	GPTPCAPTRSM_TRANSMIT_TLV,
	GPTPCAPTRSM_STATUS_MAX
}GPTPCAPTRSM_ST;

typedef	enum tagGPTPCAPTRSM_EV
{
	GPTPCAPTRSM_EV_BEGIN = 0,
	GPTPCAPTRSM_EV_GPTPCAPBLE_SENDTIME,
	GPTPCAPTRSM_EV_CLOSE,
	GPTPCAPTRSM_EV_EVENT_MAX
}GPTPCAPTRSM_EV;


typedef struct tagGPTPCAPTRANSSM_GD
{
	GPTPCAPTRSM_ST 			enStsgptpCapableTransmit;
	USCALEDNS 				stGptpSendIntervalTimer;
	PTPMSG_SIGNALING_1AS	stTxSignalingMsg;
	UCHAR 					uchNumGptpCapMsgTransmissions;
	USHORT 					usSignalingSequenceNum;
	TMO_MANAGE_INF_BLK* 	pstTMO_GPtpCapableTransmit;
}GPTPCAPTRANSSM_GD;



typedef enum tagGPTPCAPRCVSM_ST
{
	GPTPCAPRCVSM_NONE         = 0,
	GPTPCAPRCVSM_INITIALIZE,
	GPTPCAPRCVSM_RECEIVED_TLV,
	GPTPCAPRCVSM_STATUS_MAX
}GPTPCAPRCVSM_ST;

typedef	enum tagGPTPCAPRCVSM_EV
{
	GPTPCAPRCVSM_EV_BEGIN = 0,
	GPTPCAPRCVSM_EV_RCVDGPTPCAPTLV,
	GPTPCAPRCVSM_EV_RCVDGPTPCAPTLV_TMO,
	GPTPCAPRCVSM_EV_CLOSE,
	GPTPCAPRCVSM_EV_EVENT_MAX
}GPTPCAPRCVSM_EV;

typedef struct tagGPTPCAPRECVSM_GD
{
	GPTPCAPTRSM_ST 			enStsgptpCapableRecv;
	USCALEDNS 			  	stIntervalTimer;
	PTPMSG_SIGNALING_1AS*	pstRcvdSignalingMsgPtr;
	USCALEDNS 				stGptpCapReceiptTimeoutTimeInt;
	USCALEDNS				stGptpCapReceiptTimeoutTime;
	TMO_MANAGE_INF_BLK* 	pstTMO_GPtpCapableReceipt;
}GPTPCAPRECVSM_GD;


typedef enum tagGPTPCINTSETSM
{
	GPTPCINTSETSM_NONE         = 0,
	GPTPCINTSETSM_NOT_ENABLED,
	GPTPCINTSETSM_INITIALIZE,
	GPTPCINTSETSM_SET_INTERVAL,
	GPTPCINTSETSM_STATUS_MAX
}GPTPCINTSETSM_ST;

typedef	enum tagGPTPCINTSETSM_EV
{
	GPTPCINTSETSM_EV_BEGIN = 0,
	GPTPCINTSETSM_EV_USEMGTSETABLELOGGPTP_ON,
	GPTPCINTSETSM_EV_USEMGTSETABLELOGGPTP_OFF,
	GPTPCINTSETSM_EV_RCVDSIGNALINGMSG,
	GPTPCINTSETSM_EV_CLOSE,
	GPTPCINTSETSM_EV_EVENT_MAX
}GPTPCINTSETSM_EV;


typedef struct tagGPTPCAPINTSETSM_GD
{
	
	GPTPCINTSETSM_ST 		enStsgptpCapableIntSet;
	PTPMSG_SIGNALING_1AS *	pstRcvdSignalingPtrGIS;
	CHAR					chLogSupGptpCapMsgIntMax;
	CHAR					chLogSupClsLgrGptpCapMsgInt;
	CHAR					chComputedLogGptpCapMsgInt;
}GPTPCAPINTSETSM_GD;




#define LIM_MAX_ALLOW_GPTCAPINT		24
#define LIM_MIN_ALLOW_GPTCAPINT		-24
#define USR_MAX_ALLOW_GPTCAPINT		24
#define USR_MIN_ALLOW_GPTCAPINT		-24
#define GPTCAPINT_INT_VAL_INIT		126
#define GPTCAPINT_INT_VAL_STOP		127
#define GPTCAPINT_INT_VAL_NONE		-128






#endif
