/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTP_ADDRINFO_H__
#define __PTP_ADDRINFO_H__
#include "ptp_api.h"
typedef union  tagPORTADDRINFO_SUB
{
	INT 	nPrefixLen;
	ULONG	ulNetMask;
} PORTADDRINFO_SUB;

typedef	struct	tagPORTADDRINFO
{
	CLOCKTRANS			enClockTrans;
	PORTADDRINFO_SUB	stPortAdrInfSub;
	VOID*				pvAddrInfo			;
}	PORTADDRINFO;

#endif
