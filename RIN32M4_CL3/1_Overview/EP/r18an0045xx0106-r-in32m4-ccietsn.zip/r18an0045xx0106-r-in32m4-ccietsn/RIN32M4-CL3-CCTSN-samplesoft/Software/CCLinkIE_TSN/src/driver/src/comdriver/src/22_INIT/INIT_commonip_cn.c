/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"






NX_VOID vINIT_commonip_cn ( NX_VOID )
{
	NGN_CN_REG->R_REMACA[0].BITS.b08ZMacAddress1	=	gstAppInfo.stEthInfo.auchMacAddress[0];
	NGN_CN_REG->R_REMACA[0].BITS.b08ZMacAddress2	=	gstAppInfo.stEthInfo.auchMacAddress[1];
	NGN_CN_REG->R_REMACA[1].BITS.b08ZMacAddress1	=	gstAppInfo.stEthInfo.auchMacAddress[2];
	NGN_CN_REG->R_REMACA[1].BITS.b08ZMacAddress2	=	gstAppInfo.stEthInfo.auchMacAddress[3];
	NGN_CN_REG->R_REMACA[2].BITS.b08ZMacAddress1	=	gstAppInfo.stEthInfo.auchMacAddress[4];
	NGN_CN_REG->R_REMACA[2].BITS.b08ZMacAddress2	=	gstAppInfo.stEthInfo.auchMacAddress[5];
	
	NGN_CN_REG->R_REIPSET.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_RESSCMD.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_RELNSPD.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REMLTCCNT.DATA	=	(NX_ULONG)0x00000003;
	NGN_CN_REG->R_RESTCCLR.DATA		=	(NX_ULONG)0x00000001;
	NGN_CN_REG->R_RELUNUM.DATA		=	(NX_USHORT)0x00000000;
	
	
	NGN_CN_REG->R_REETYP0.DATA		=	(NX_ULONG)0x0000890F;
	NGN_CN_REG->R_REETYP1.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REETYP2.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REETYP3.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REETYP4.DATA		=	(NX_ULONG)0x0000890F;
	NGN_CN_REG->R_REETYP5.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REETYP6.DATA		=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REETYP7.DATA		=	(NX_ULONG)0x00000000;

	NGN_CN_REG->R_REETYPE1.DATA		=	(NX_ULONG)0x88F7890F;
	NGN_CN_REG->R_REETYPE2.DATA		=	(NX_ULONG)0x080088CC;
	NGN_CN_REG->R_REETYPE3.DATA		=	(NX_ULONG)0x00008100;
	NGN_CN_REG->R_REETYPE4.DATA		=	(NX_ULONG)0x00000000;
	
	NGN_CN_REG->R_REFTYP1.DATA		=	(NX_ULONG)0xC3C2C1C0;
	NGN_CN_REG->R_REFTYP2.DATA		=	(NX_ULONG)0xC7C6C5C4;
	NGN_CN_REG->R_REFTYP3.DATA		=	(NX_ULONG)0x000000C8;
	
	NGN_CN_REG->R_REGRPNO[0].DATA	=	(NX_ULONG)0x00000000;
	NGN_CN_REG->R_REGTYP[0].DATA = 0x08068035;
	NGN_CN_REG->R_REGTYP[1].DATA = 0x88CC0800;
	NGN_CN_REG->R_REGTYP[2].DATA = 0x08000800;
	NGN_CN_REG->R_REGTYP[3].DATA = 0x08000800;
	return;
}

/*[EOF]*/
