/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_FRAME_H_INCLUDE__
#define __CCIENX_FRAME_H_INCLUDE__

#include "ccienx_type.h"

#pragma pack(1)
typedef struct tagNX_SLMP_CMD {
	NX_USHORT				usCmd;
	NX_USHORT				usSubCmd;
} NX_SLMP_CMD_T;


typedef struct tagNX_SLMP_RESP_ERROR {
	NX_UCHAR				uchNetNo;
	NX_UCHAR				uchStNo;
	NX_USHORT				usUtIONo;
	NX_UCHAR				uchMultiDropStNo;
	NX_USHORT				usCmd;
	NX_USHORT				usSubCmd;
} NX_SLMP_RESP_ERROR_T;


typedef struct tagNX_SLMP_RESP_ERROR_6E {
	NX_UCHAR				uchNetNo;
	NX_UCHAR				uchStNo;
	NX_USHORT				usUtIONo;
	NX_UCHAR				uchMultiDropStNo;
	NX_UCHAR				uchRsv;
	NX_USHORT				usExStNo;
} NX_SLMP_RESP_ERROR_6E_T;


typedef struct tagNX_SLMP_SUBH_3E {
	NX_USHORT				usFixPtn;
	NX_UCHAR				uchNetNo;
	NX_UCHAR				uchStNo;
	NX_USHORT				usUtIONo;
	NX_UCHAR				uchMultiDropStNo;
	NX_USHORT				usDataBSize;
} NX_SLMP_SUBH_3E_T;

typedef struct tagNX_SLMP_REQU_TOP_3E {
	NX_SLMP_SUBH_3E_T		stSubH;
	NX_USHORT				usWatchTime;
	NX_SLMP_CMD_T			stCmdData;
	NX_UCHAR				auchData[1];
} NX_SLMP_REQU_TOP_3E_T;

typedef struct tagNX_SLMP_RESP_TOP_3E {
	NX_SLMP_SUBH_3E_T		stSubH;
	NX_USHORT				usFixFinCode;
    NX_UCHAR				auchData[1];
} NX_SLMP_RESP_TOP_3E_T;


typedef struct tagNX_SLMP_SUBH_4E {
	NX_USHORT				usFixPtn;
	NX_USHORT				usSerialNo;
	NX_USHORT				usReserved;
	NX_UCHAR				uchNetNo;
	NX_UCHAR				uchStNo;
	NX_USHORT				usUtIONo;
	NX_UCHAR				uchMultiDropStNo;
	NX_USHORT				usDataBSize;
} NX_SLMP_SUBH_4E_T;

typedef struct tagNX_SLMP_REQU_TOP_4E {
	NX_SLMP_SUBH_4E_T		stSubH;
	NX_USHORT				usWatchTime;
	NX_SLMP_CMD_T			stCmdData;
	NX_UCHAR				auchData[1];
} NX_SLMP_REQU_TOP_4E_T;

typedef struct tagNX_SLMP_RESP_TOP_4E {
	NX_SLMP_SUBH_4E_T		stSubH;
	NX_USHORT				usFixFinCode;
    NX_UCHAR				auchData[1];
} NX_SLMP_RESP_TOP_4E_T;


typedef struct tagNX_SLMP_SUBH_5E {
	NX_USHORT				usFixPtn;
	NX_USHORT				usSerialNo;
	NX_USHORT				usReserved;
	NX_UCHAR				uchNetNo_Dst;
	NX_UCHAR				uchStNo_Dst;
	NX_USHORT				usUtIONo_Dst;
	NX_UCHAR				uchNetNo_Src;
	NX_UCHAR				uchStNo_Src;
	NX_USHORT				usUtIONo_Src;
	NX_UCHAR				uchPacketTyp;
	NX_UCHAR				uchRsv;
	NX_USHORT				usSplitInfo;
	NX_USHORT				usDataBSize;
} NX_SLMP_SUBH_5E_T;

typedef struct tagNX_SLMP_REQU_TOP_5E {
	NX_SLMP_SUBH_5E_T		stSubH;
	NX_SLMP_CMD_T			stCmdData;
	NX_UCHAR				auchData[1];
} NX_SLMP_REQU_TOP_5E_T;

typedef struct tagNX_SLMP_RESP_TOP_5E {
	NX_SLMP_SUBH_5E_T		stSubH;
	NX_USHORT				usCmd;
	NX_USHORT				usSubCmd;
	NX_USHORT				usFixFinCode;
    NX_UCHAR				auchData[1];
} NX_SLMP_RESP_TOP_5E_T;


typedef struct tagNX_SLMP_SUBH_6E {
	NX_USHORT				usFixPtn;
	NX_USHORT				usSerialNo;
	NX_USHORT				usRsv1;
	NX_UCHAR				uchNetNo;
	NX_UCHAR				uchStNo;
	NX_USHORT				usUtIONo;
	NX_UCHAR				uchMultiDropStNo;
	NX_UCHAR				uchRsv2;
	NX_USHORT				usExStNo;
	NX_USHORT				usDataBSize;
} NX_SLMP_SUBH_6E_T;

typedef struct tagNX_SLMP_REQU_TOP_6E {
	NX_SLMP_SUBH_6E_T		stSubH;
	NX_USHORT				usWatchTime;
	NX_SLMP_CMD_T			stCmdData;
	NX_UCHAR				uchRsv1;
	NX_UCHAR				uchMsgId;
	NX_USHORT				usDivisionTotalNum;
	NX_USHORT				usDivisionId;
	NX_UCHAR				auchData[1];
} NX_SLMP_REQU_TOP_6E_T;

typedef struct tagNX_SLMP_RESP_TOP_6E {
	NX_SLMP_SUBH_6E_T		stSubH;
	NX_USHORT				usFixFinCode;
	NX_USHORT				usCmd;
	NX_USHORT				usSubCmd;
	NX_UCHAR				uchRsv1;
	NX_UCHAR				uchMsgId;
	NX_USHORT				usDivisionTotalNum;
	NX_USHORT				usDivisionId;
    NX_UCHAR				auchData[1];
} NX_SLMP_RESP_TOP_6E_T;
#pragma pack()


#endif
/*[EOF]*/
