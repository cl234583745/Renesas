/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"





NX_VOID vINIT_commonip_md ( NX_VOID )
{
	NGN_MD_REG->R_MDCMD.DATA	= (NX_ULONG)0x00000000;	

	NGN_MD_REG->R_MDPHYADR.DATA	= (NX_ULONG)0x00000000;		

	NGN_MD_REG->R_MDPHYRAD.DATA	= (NX_ULONG)0x00000000;

	NGN_MD_REG->R_MDPHYWD.DATA	= (NX_ULONG)0x00000000;


	NGN_MD_REG->R_MDCLKSET.DATA	= (NX_ULONG)0x00000000;
	
	NGN_MD_REG->R_MDACCENB.DATA	= (NX_ULONG)0x00000001;

	NGN_MD_REG->R_MDCLKSEL.DATA	= (NX_ULONG)0x00000000;

	NGN_MD_REG->R_CLKENB.DATA	= (NX_ULONG)0x00000001;

	return;
}

/*[EOF]*/
