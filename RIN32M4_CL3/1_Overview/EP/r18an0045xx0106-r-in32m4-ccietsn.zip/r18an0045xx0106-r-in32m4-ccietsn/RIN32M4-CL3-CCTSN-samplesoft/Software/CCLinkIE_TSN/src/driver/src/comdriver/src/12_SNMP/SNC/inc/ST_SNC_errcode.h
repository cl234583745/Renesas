/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __ST_SNC_ERRCODE_H_INCLUDED__
#define __ST_SNC_ERRCODE_H_INCLUDED__

#define ST_SNC_OK                               (0)
#define ST_SNC_NG                               (0x00000001U)
#define ST_SNC_NG_PARAM_ADDR                    (0x00000003U)
#define ST_SNC_NG_PARAM_RANGE                   (0x00000004U)
#define ST_SNC_NG_PARAM_FORBID                  (0x00000006U)
#define ST_SNC_NG_MTX_CREATE                    (0x00000008U)
#define ST_SNC_NG_MTX_EXIST                     (0x0000000DU)
#define ST_SNC_NG_MTX_NOCRE                     (0x0000000EU)
#define ST_SNC_NG_PIPE_OPEN                     (0x00000010U)
#define ST_SNC_NG_WRITE                         (0x00000012U)
#define ST_SNC_NG_READ                          (0x00000013U)
#define ST_SNC_NG_HEAD                          (0x00000014U)
#define ST_SNC_NG_HEAD_ST                       (0x00000015U)
#define ST_SNC_NG_HEAD_TY                       (0x00000016U)
#define ST_SNC_NG_HEAD_DT                       (0x00000017U)
#define ST_SNC_NG_INSUFFICIENT_MEM              (0x00000018U)
#define ST_SNC_NG_SEQUENCE                      (0x00000019U)
#define ST_SNC_NG_ADD_MAX                       (0x0000001AU)
#define ST_SNC_NG_DEL_MIN                       (0x0000001BU)
#define ST_SNC_NG_MEMCNT                        (0x0000001CU)
#define ST_SNC_NG_MEMCNT_INTERNAL               (0x0000001DU)
#define ST_SNC_NG_MEMCNT_USED                   (0x0000001EU)
#define ST_SNC_NG_EVENT_WAIT                    (0x00000020U)
#define ST_SNC_NG_CREATE_EVENT                  (0x00000023U)
#define ST_SNC_NG_SET_EVENT                     (0x00000025U)
#define ST_SNC_NG_STATE                         (0x00000027U)
#define ST_SNC_NG_EVENT                         (0x00000028U)
#define ST_SNC_NG_BEGINTHREAD                   (0x00000029U)
#define ST_SNC_NG_MIB_INDEX_REGNUM              (0x0000002AU)
#define ST_SNC_NG_IGNORE                        (0x0000002FU)
#define ST_SNC_NG_SERVICE_NOT_STARTED           (0x00000030U)
#define ST_SNC_NG_PIPE_MAX_INSTANCE             (0x00000031U)
#define ST_SNC_NG_INDEX_REG_RANGE               (0x00000032U)

#endif
