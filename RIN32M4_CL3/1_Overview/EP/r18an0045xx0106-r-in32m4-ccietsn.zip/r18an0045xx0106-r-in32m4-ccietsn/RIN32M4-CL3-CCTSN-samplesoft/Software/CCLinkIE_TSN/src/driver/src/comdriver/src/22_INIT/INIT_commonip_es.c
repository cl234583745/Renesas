/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"





NX_VOID vINIT_commonip_es ( NX_VOID )
{
	NGN_ES_REG->R_ESPREDET.DATA		= (NX_ULONG)0x00000004;
	
	
	NGN_ES_REG->R_ESPREDETGBE.DATA	= (NX_ULONG)0x00000007;
	

	return;
}

/*[EOF]*/
