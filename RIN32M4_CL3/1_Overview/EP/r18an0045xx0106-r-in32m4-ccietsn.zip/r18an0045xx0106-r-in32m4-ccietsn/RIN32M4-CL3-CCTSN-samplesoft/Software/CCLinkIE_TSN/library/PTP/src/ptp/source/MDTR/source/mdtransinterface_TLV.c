/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Type.h"
#include "ptpwrap_Proto.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"

#include "ManagementSM_1588.h"

#include "mdtransinterface.h"
#include "mdtransinterface_msg.h"

#define		MD_TRANS_IFTBL_SIZE			40

struct MD_TRANS_IFSEL_TBL_1588 {
	UCHAR	uchManagement_NM[60];
	USHORT	usManagementID;
	USHORT (*pFunc_ntoh)(UCHAR* net, MGT_DATAFIELD* host, USHORT usSize);
	USHORT (*pFunc_hton)(UCHAR* net, MGT_DATAFIELD* host);
};
const struct MD_TRANS_IFSEL_TBL_1588	stMdTransInterface_TLV[MD_TRANS_IFTBL_SIZE] = {
	{MGT_MNM_NULL_MANAGEMENT, 		PTPM_MGT_NULL_MANAGEMENT,		&ptp_Mdl_ntoh_MgtId_0000,	&ptp_Mdl_hton_MgtId_0000},
	{MGT_MNM_CLOCK_DESCRIPTION,		PTPM_MGT_CLOCK_DESCRIPTION,		&ptp_Mdl_ntoh_MgtId_0001,	&ptp_Mdl_hton_MgtId_0001},
	{MGT_MNM_USER_DESCRIPTION,		PTPM_MGT_USER_DESCRIPTION,		&ptp_Mdl_ntoh_MgtId_0002,	&ptp_Mdl_hton_MgtId_0002},
	{MGT_MNM_INITIALIZE,			PTPM_MGT_INITIALIZE,			&ptp_Mdl_ntoh_MgtId_0005,	&ptp_Mdl_hton_MgtId_0005},
	{MGT_MNM_FAULT_LOG,				PTPM_MGT_FAULT_LOG,				&ptp_Mdl_ntoh_MgtId_0006,	&ptp_Mdl_hton_MgtId_0006},
	{MGT_MNM_FAULT_LOG_RESET,		PTPM_MGT_FAULT_LOG_RESET,		&ptp_Mdl_ntoh_MgtId_0007,	&ptp_Mdl_hton_MgtId_0007},
	{MGT_MNM_DEFAULT_DATA_SET,		PTPM_MGT_DEFAULT_DATA_SET,		&ptp_Mdl_ntoh_MgtId_2000,	&ptp_Mdl_hton_MgtId_2000},
	{MGT_MNM_CURRENT_DATA_SET,		PTPM_MGT_CURRENT_DATA_SET,		&ptp_Mdl_ntoh_MgtId_2001,	&ptp_Mdl_hton_MgtId_2001},
	{MGT_MNM_PARENT_DATA_SET,		PTPM_MGT_PARENT_DATA_SET,		&ptp_Mdl_ntoh_MgtId_2002,	&ptp_Mdl_hton_MgtId_2002},
	{MGT_MNM_TIME_PROPERT_DATA_SET,	PTPM_MGT_TIME_PROPERT_DATA_SET,	&ptp_Mdl_ntoh_MgtId_2003,	&ptp_Mdl_hton_MgtId_2003},
	{MGT_MNM_PORT_DATA_SET,			PTPM_MGT_PORT_DATA_SET,			&ptp_Mdl_ntoh_MgtId_2004,	&ptp_Mdl_hton_MgtId_2004},
	{MGT_MNM_PRIORITY1,				PTPM_MGT_PRIORITY1,				&ptp_Mdl_ntoh_MgtId_2005,	&ptp_Mdl_hton_MgtId_2005},
	{MGT_MNM_PRIORITY2,				PTPM_MGT_PRIORITY2,				&ptp_Mdl_ntoh_MgtId_2006,	&ptp_Mdl_hton_MgtId_2006},
	{MGT_MNM_DOMAIN,				PTPM_MGT_DOMAIN,				&ptp_Mdl_ntoh_MgtId_2007,	&ptp_Mdl_hton_MgtId_2007},
	{MGT_MNM_SLAVE_ONLY,			PTPM_MGT_SLAVE_ONLY,			&ptp_Mdl_ntoh_MgtId_2008,	&ptp_Mdl_hton_MgtId_2008},
	{MGT_MNM_LOG_ANNOUNCE_INTERVAL,	PTPM_MGT_LOG_ANNOUNCE_INTERVAL,	&ptp_Mdl_ntoh_MgtId_2009,	&ptp_Mdl_hton_MgtId_2009},
	{MGT_MNM_ANNOUNCE_RECEIPT_TMOUT,PTPM_MGT_ANNOUNCE_RECEIPT_TMOUT,&ptp_Mdl_ntoh_MgtId_200A,	&ptp_Mdl_hton_MgtId_200A},
	{MGT_MNM_LOG_SYNC_INTERVAL,		PTPM_MGT_LOG_SYNC_INTERVAL,		&ptp_Mdl_ntoh_MgtId_200B,	&ptp_Mdl_hton_MgtId_200B},
	{MGT_MNM_VERSION_NUMBER,		PTPM_MGT_VERSION_NUMBER,		&ptp_Mdl_ntoh_MgtId_200C,	&ptp_Mdl_hton_MgtId_200C},
	{MGT_MNM_ENABLE_PORT,			PTPM_MGT_ENABLE_PORT,			&ptp_Mdl_ntoh_MgtId_200D,	&ptp_Mdl_hton_MgtId_200D},
	{MGT_MNM_DISABLE_PORT,			PTPM_MGT_DISABLE_PORT,			&ptp_Mdl_ntoh_MgtId_200E,	&ptp_Mdl_hton_MgtId_200E},
	{MGT_MNM_TIME,					PTPM_MGT_TIME,					&ptp_Mdl_ntoh_MgtId_200F,	&ptp_Mdl_hton_MgtId_200F},
	{MGT_MNM_CLOCK_ACCURACY,		PTPM_MGT_CLOCK_ACCURACY,		&ptp_Mdl_ntoh_MgtId_2010,	&ptp_Mdl_hton_MgtId_2010},
	{MGT_MNM_UTC_PROPERTIES,		PTPM_MGT_UTC_PROPERTIES,		&ptp_Mdl_ntoh_MgtId_2011,	&ptp_Mdl_hton_MgtId_2011},
	{MGT_MNM_TRACEABILITY_PROPERT,	PTPM_MGT_TRACEABILITY_PROPERT,	&ptp_Mdl_ntoh_MgtId_2012,	&ptp_Mdl_hton_MgtId_2012},
	{MGT_MNM_TIMESCALE_PROPERTIES,	PTPM_MGT_TIMESCALE_PROPERTIES,	&ptp_Mdl_ntoh_MgtId_2013,	&ptp_Mdl_hton_MgtId_2013},
	{MGT_MNM_UNICAST_NEGOTI_ENABLE,	PTPM_MGT_UNICAST_NEGOTI_ENABLE,	&ptp_Mdl_ntoh_MgtId_2014,	&ptp_Mdl_hton_MgtId_2014},
	{MGT_MNM_PATH_TRACE_LIST,		PTPM_MGT_PATH_TRACE_LIST,		&ptp_Mdl_ntoh_MgtId_2015,	&ptp_Mdl_hton_MgtId_2015},
	{MGT_MNM_PATH_TRACE_ENABLE,		PTPM_MGT_PATH_TRACE_ENABLE,		&ptp_Mdl_ntoh_MgtId_2016,	&ptp_Mdl_hton_MgtId_2016},
	{MGT_MNM_GM_CLUSTER_TBL,		PTPM_MGT_GM_CLUSTER_TBL,		&ptp_Mdl_ntoh_MgtId_2017,	&ptp_Mdl_hton_MgtId_2017},
	{MGT_MNM_UNICAST_MSTR_TBL,		PTPM_MGT_UNICAST_MSTR_TBL,		&ptp_Mdl_ntoh_MgtId_2018,	&ptp_Mdl_hton_MgtId_2018},
	{MGT_MNM_UNICAST_MSTR_MAX_TBLSZ,PTPM_MGT_UNICAST_MSTR_MAX_TBLSZ,&ptp_Mdl_ntoh_MgtId_2019,	&ptp_Mdl_hton_MgtId_2019},
	{MGT_MNM_PORT_STAT_COUNT,		PTPM_MGT_PORT_STAT_COUNT,		&ptp_Mdl_ntoh_MgtId_2100,	&ptp_Mdl_hton_MgtId_2100},
	{MGT_MNM_CMLD_PORT_STAT_COUNT,	PTPM_MGT_CMLD_PORT_STAT_COUNT,	&ptp_Mdl_ntoh_MgtId_2101,	&ptp_Mdl_hton_MgtId_2101},
	{MGT_MNM_PORT_STAT_ERRCOUNT,	PTPM_MGT_PORT_STAT_ERRCOUNT,	&ptp_Mdl_ntoh_MgtId_2102,	&ptp_Mdl_hton_MgtId_2102},
	{MGT_MNM_TCLK_DEFAULT_DATA_SET,	PTPM_MGT_TCLK_DEFAULT_DATA_SET,	&ptp_Mdl_ntoh_MgtId_4000,	&ptp_Mdl_hton_MgtId_4000},
	{MGT_MNM_TCLK_PORT_DATA_SET,	PTPM_MGT_TCLK_PORT_DATA_SET,	&ptp_Mdl_ntoh_MgtId_4001,	&ptp_Mdl_hton_MgtId_4001},
	{MGT_MNM_PRIMARY_DOMAIN,		PTPM_MGT_PRIMARY_DOMAIN,		&ptp_Mdl_ntoh_MgtId_4002,	&ptp_Mdl_hton_MgtId_4002},
	{MGT_MNM_DELAY_MECHANISM,		PTPM_MGT_DELAY_MECHANISM,		&ptp_Mdl_ntoh_MgtId_6000,	&ptp_Mdl_hton_MgtId_6000},
	{MGT_MNM_LOG_MIN_PDREQ_INTERVAL,PTPM_MGT_LOG_MIN_PDREQ_INTERVAL,&ptp_Mdl_ntoh_MgtId_6001,	&ptp_Mdl_hton_MgtId_6001}
};

USHORT ptp_Mdl_ntohMsgManagTLV(UCHAR* puchMsgPtr, PTPMSG_MANAGEMENT_TLV* pstPtpmsg, USHORT usTLVLen)
{
	PTPMSG_MANAGEMENT_ERRSTA_TLV*	pstPtpmsgErr = (PTPMSG_MANAGEMENT_ERRSTA_TLV*)pstPtpmsg;

	USHORT	usDTFieldSize = 0;
	SHORT	sLoopNum		= sizeof(stMdTransInterface_TLV) / sizeof(stMdTransInterface_TLV[0]);

	USHORT	usLoop = 0;

	USHORT	usRetSize;

	if(usTLVLen < PTPMSG_MGTTLV_TLVTYPE_SZ)
	{
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
		return 0;
	}

	mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsg->usTLVType);

	switch (pstPtpmsg->usTLVType)
	{
	case PTPMSG_MGTTLV_MANAGEMENT:

		if(usTLVLen < (PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTTLV_MANAGEMENTID_SZ))
		{
			PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return 0;
		}

		usDTFieldSize += (PTPMSG_MGTTLV_TLVTYPE_SZ);
		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsg->usLengthField);
		usDTFieldSize += (PTPMSG_MGTTLV_TLVLENGTH_SZ);

		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsg->usManagementId);
		usDTFieldSize += (PTPMSG_MGTTLV_MANAGEMENTID_SZ);

		if (pstPtpmsg->usLengthField > 2)
		{
			for (usLoop = 0; usLoop < sLoopNum; usLoop++)
			{
				if(stMdTransInterface_TLV[usLoop].usManagementID == pstPtpmsg->usManagementId)
				{
					usRetSize	   = (*stMdTransInterface_TLV[usLoop].pFunc_ntoh)
						((puchMsgPtr + usDTFieldSize), &pstPtpmsg->stDataField, usTLVLen - usDTFieldSize);

					if (usRetSize == PTP_MDTR_TLV_ERROR)
					{
						PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
						return 0;
					}
					usDTFieldSize += usRetSize;
					break;
				}
			}
			if (usLoop == sLoopNum)
			{
				usDTFieldSize += pstPtpmsg->usLengthField - (PTPMSG_MGTTLV_MANAGEMENTID_SZ);
			}
		}
		if (pstPtpmsg->usLengthField < 2)
		{
			usDTFieldSize -= (2 - pstPtpmsg->usLengthField);
		}
		break;

	case PTPMSG_MGTTVL_MANAGEMENT_ERRORS:

		if(usTLVLen < (PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTERSTTLV_MANAGEMENTERRID_SZ + PTPMSG_MGTTLV_MANAGEMENTID_SZ + PTPMSG_MGTERSTTLV_PTPTEXTDISP_SZ))
		{
			PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return 0;
		}

		usDTFieldSize += (PTPMSG_MGTTLV_TLVTYPE_SZ);
		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsgErr->usLengthField);
		usDTFieldSize += (PTPMSG_MGTERSTTLV_TLVLENGTH_SZ);

		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsgErr->usManagementErrorId);
		usDTFieldSize += (PTPMSG_MGTERSTTLV_MANAGEMENTERRID_SZ);

		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsgErr->usManagementId);
		usDTFieldSize += (PTPMSG_MGTERSTTLV_MANAGEMENTID_SZ);

		pstPtpmsgErr->stDisplayData.uchTextLength = (*(puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTERSTTLV_PTPTEXTDISP_SZ);

		if(usTLVLen < (PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTERSTTLV_MANAGEMENTERRID_SZ + PTPMSG_MGTTLV_MANAGEMENTID_SZ + PTPMSG_MGTERSTTLV_PTPTEXTDISP_SZ) + pstPtpmsgErr->stDisplayData.uchTextLength)
		{
			PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return 0;
		}

		tsn_Wrapper_MemCpy(pstPtpmsgErr->stDisplayData.uchTextField, (puchMsgPtr + usDTFieldSize),
		(pstPtpmsgErr->stDisplayData.uchTextLength));
		usDTFieldSize += (pstPtpmsgErr->stDisplayData.uchTextLength);
		break;
	default:
		if (usTLVLen < (PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTTLV_MANAGEMENTID_SZ))
		{
			PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return 0;
		}
		usDTFieldSize += (PTPMSG_MGTTLV_TLVTYPE_SZ);

		mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsg->usLengthField);
		usDTFieldSize += (PTPMSG_MGTTLV_TLVLENGTH_SZ);

		if (pstPtpmsg->usLengthField >= PTPMSG_MGTTLV_MANAGEMENTID_SZ)
		{
			mdtra_ntoh_us((puchMsgPtr + usDTFieldSize), &pstPtpmsg->usManagementId);
			usDTFieldSize += (PTPMSG_MGTTLV_MANAGEMENTID_SZ);
		}
		else
		{
			usDTFieldSize = usDTFieldSize + pstPtpmsg->usLengthField;
		}
		break;
	}

	return usDTFieldSize;
}

USHORT ptp_Mdl_htonMsgManagTLV(UCHAR* puchMsgPtr, PTPMSG_MANAGEMENT_TLV* pstPtpmsg)
{
	PTPMSG_MANAGEMENT_ERRSTA_TLV*	pstPtpmsgErr = (PTPMSG_MANAGEMENT_ERRSTA_TLV*)pstPtpmsg;

	USHORT	usDTFieldSize = 0;
	SHORT	sLoopNum		  = sizeof(stMdTransInterface_TLV) / sizeof(stMdTransInterface_TLV[0]);

	USHORT	usLoop = 0;

	USHORT	usSize = 0xFFFF;

	mdtra_hton_us(pstPtpmsg->usTLVType, (puchMsgPtr + usDTFieldSize));

	switch (pstPtpmsg->usTLVType)
	{
	case PTPMSG_MGTTLV_MANAGEMENT:
		usDTFieldSize += (PTPMSG_MGTTLV_TLVTYPE_SZ);

		mdtra_hton_us(pstPtpmsg->usLengthField, (puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTTLV_TLVLENGTH_SZ);

		mdtra_hton_us(pstPtpmsg->usManagementId, (puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTTLV_MANAGEMENTID_SZ);

		if (pstPtpmsg->usLengthField >= 2)
		{
			for (usLoop = 0; usLoop < sLoopNum; usLoop++)
			{
				if(stMdTransInterface_TLV[usLoop].usManagementID == pstPtpmsg->usManagementId)
				{
					usSize = (*stMdTransInterface_TLV[usLoop].pFunc_hton)
						((puchMsgPtr + usDTFieldSize), &pstPtpmsg->stDataField);
					usSize = usSize + PTPMSG_MGTTLV_MANAGEMENTID_SZ;

					mdtra_hton_us(usSize, (puchMsgPtr + PTPMSG_MGTTLV_TLVTYPE_SZ));

					usSize += PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTTLV_TLVTYPE_SZ;
					break;
				}
			}
		}
		break;
	case PTPMSG_MGTTVL_MANAGEMENT_ERRORS:
		usDTFieldSize += (PTPMSG_MGTTLV_TLVTYPE_SZ);
		mdtra_hton_us(pstPtpmsgErr->usLengthField, (puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTERSTTLV_TLVLENGTH_SZ);

		mdtra_hton_us(pstPtpmsgErr->usManagementErrorId, (puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTERSTTLV_MANAGEMENTERRID_SZ);

		mdtra_hton_us(pstPtpmsgErr->usManagementId, (puchMsgPtr + usDTFieldSize));
		usDTFieldSize += (PTPMSG_MGTERSTTLV_MANAGEMENTID_SZ);

		tsn_Wrapper_MemCpy((puchMsgPtr + usDTFieldSize), &pstPtpmsgErr->uchReserved[0], sizeof(pstPtpmsgErr->uchReserved));
		usDTFieldSize += sizeof(pstPtpmsgErr->uchReserved);

		(*(puchMsgPtr + usDTFieldSize)) = pstPtpmsgErr->stDisplayData.uchTextLength;
		usDTFieldSize += (PTPMSG_MGTERSTTLV_PTPTEXTDISP_SZ);
		tsn_Wrapper_MemCpy((puchMsgPtr + usDTFieldSize), pstPtpmsgErr->stDisplayData.uchTextField,
		(pstPtpmsgErr->stDisplayData.uchTextLength));
		usDTFieldSize += (pstPtpmsgErr->stDisplayData.uchTextLength);

		if (usDTFieldSize%2)
		{
			(*(puchMsgPtr + usDTFieldSize)) = 0;
			usDTFieldSize += 1;
		}
		usSize = usDTFieldSize;
		break;
	default:
		GetPTPMSG_MANAGEMENT_TLV(*pstPtpmsg, usDTFieldSize);
		break;
	}

	return usSize;
}



USHORT ptp_Mdl_ntoh_MgtId_0000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return	usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_0001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_CLOCK_DESCRIPTION*	pstTlvDtFld = &pstPtpmsg->stClockDescription;
	UCHAR	uchPtptext_len = 0;
	USHORT	usRet = PTP_MDTR_TLV_ERROR;
	USHORT	usDtFld = 0;
	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_CLK_DESCRIPTION_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( pstTlvDtFld->byClockType, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byClockType) );
	usDtFld += sizeof(pstTlvDtFld->byClockType);


	uchPtptext_len = (*(puchTomsg + usDtFld)) + 1;

	usSizeChkSrc += (uchPtptext_len - 1);
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stPhyLyrProtocol, (puchTomsg + usDtFld), uchPtptext_len);
	usDtFld  += uchPtptext_len;

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usPhyAddressLength);
	usDtFld  += usRet;

	usSizeChkSrc += pstTlvDtFld->usPhyAddressLength;
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(pstTlvDtFld->uchPhyAddress, (puchTomsg + usDtFld),
		pstTlvDtFld->usPhyAddressLength);
	usDtFld  += pstTlvDtFld->usPhyAddressLength;

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stProtocolAddress.usNetworkProtcol);
	usDtFld  += usRet;

	mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stProtocolAddress.usAddressLength);
	usDtFld  += usRet;

	usSizeChkSrc += pstTlvDtFld->stProtocolAddress.usAddressLength;
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(pstTlvDtFld->stProtocolAddress.uchAddressField, (puchTomsg + usDtFld),
		pstTlvDtFld->stProtocolAddress.usAddressLength);
	usDtFld  += pstTlvDtFld->stProtocolAddress.usAddressLength;


	usSizeChkSrc += (USHORT)(*(puchTomsg + usDtFld));
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(pstTlvDtFld->uchManufacturerIdentity, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchManufacturerIdentity));
	usDtFld  += sizeof(pstTlvDtFld->uchManufacturerIdentity);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	pstTlvDtFld->stProductDescription.uchTextLength = (*(puchTomsg + usDtFld));
	uchPtptext_len = pstTlvDtFld->stProductDescription.uchTextLength + 1;

	usSizeChkSrc += pstTlvDtFld->stProductDescription.uchTextLength;
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stProductDescription, (puchTomsg + usDtFld), uchPtptext_len);
	usDtFld  += uchPtptext_len;

	pstTlvDtFld->stRevisionData.uchTextLength = (*(puchTomsg + usDtFld));
	uchPtptext_len = pstTlvDtFld->stRevisionData.uchTextLength + 1;

	usSizeChkSrc += pstTlvDtFld->stRevisionData.uchTextLength;
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stRevisionData, (puchTomsg + usDtFld), uchPtptext_len);
	usDtFld  += uchPtptext_len;

	pstTlvDtFld->stUserDescription.uchTextLength = (*(puchTomsg + usDtFld));
	uchPtptext_len = pstTlvDtFld->stUserDescription.uchTextLength + 1;

	usSizeChkSrc += pstTlvDtFld->stUserDescription.uchTextLength;
	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stUserDescription, (puchTomsg + usDtFld), uchPtptext_len);
	usDtFld  += uchPtptext_len;

	tsn_Wrapper_MemCpy(pstTlvDtFld->uchProfileIdentity, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchProfileIdentity));
	usDtFld  += sizeof(pstTlvDtFld->uchProfileIdentity);


	return (usDtFld + (usDtFld % 2));
}
USHORT ptp_Mdl_ntoh_MgtId_0002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_USER_DESCRIPTION*	pstTlvDtFld = &pstPtpmsg->stUserDescription;
	UCHAR	uchPtptext_len = 0;
	USHORT	usDtFld = 0;

	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_USR_DESCRIPTION_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->stUserDescription.uchTextLength = (*(puchTomsg + usDtFld));
	uchPtptext_len = pstTlvDtFld->stUserDescription.uchTextLength + 1;

	usSizeChkSrc += pstTlvDtFld->stUserDescription.uchTextLength;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

#if 1
	tsn_Wrapper_MemCpy(&pstTlvDtFld->stUserDescription, (puchTomsg + usDtFld), uchPtptext_len);
#endif
	usDtFld  += uchPtptext_len;


	return (usDtFld + (usDtFld % 2));
}
USHORT ptp_Mdl_ntoh_MgtId_0005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return	usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_0006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_0007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_DEFAULT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stDefaultDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_DEFAULT_DS_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += (sizeof(pstTlvDtFld->byFlags));

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usNumPorts);
	usDtFld  += usRet;

	pstTlvDtFld->uchPriority1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPriority1);

	usRet = mdtra_ntoh_CLKQLTY((puchTomsg + usDtFld), &pstTlvDtFld->stClockQuality);
	usDtFld  += usRet;

	pstTlvDtFld->uchPriority2 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPriority2);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stClockIdentity, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->stClockIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stClockIdentity);

	pstTlvDtFld->uchDomainNum = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchDomainNum);

	pstTlvDtFld->uchReserved2 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved2);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_CURRENT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stCurrentDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_CURRENT_DS_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usStepsRemoved);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_TInt((puchTomsg + usDtFld), &pstTlvDtFld->stOffsetFromMaster);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_TInt((puchTomsg + usDtFld), &pstTlvDtFld->stMeanPathDelay);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_PARENT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stParentDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PARENT_DS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_PortID((puchTomsg + usDtFld), &pstTlvDtFld->stPrntPortIdentity);
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usObsPrentOfsetScalLogVrnc);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), (ULONG*)&pstTlvDtFld->lObsPrentClockPhsChngRate);
	usDtFld  += usRet;

	pstTlvDtFld->uchGMasterPriority1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchGMasterPriority1);

	usRet = mdtra_ntoh_CLKQLTY((puchTomsg + usDtFld), &pstTlvDtFld->stGMasterClockQuality);
	usDtFld  += usRet;

	pstTlvDtFld->uchGMasterPriority2 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchGMasterPriority2);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stGMasterIdentity, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->stGMasterIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stGMasterIdentity);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2003(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_TIME_PROPERTIES_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTimePropertiesDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TIMEPRPRTS_DS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), (USHORT*)&pstTlvDtFld->sCrentUtcOffset);
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchTimeSource, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchTimeSource));
	usDtFld  += sizeof(pstTlvDtFld->uchTimeSource);
	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2004(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_PORT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stPortDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PORT_DS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_PortID((puchTomsg + usDtFld), &pstTlvDtFld->stPortIdentity);
	usDtFld  += usRet;

	pstTlvDtFld->uchPortState = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPortState);

	pstTlvDtFld->chLogMinDReqInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogMinDReqInterval);

	usRet = mdtra_ntoh_TInt((puchTomsg + usDtFld), &pstTlvDtFld->stPerMeanPathDelay);
	usDtFld  += usRet;

	pstTlvDtFld->chLogAnounceInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogAnounceInterval);

	pstTlvDtFld->uchAnounceRcptTimeout = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchAnounceRcptTimeout);

	pstTlvDtFld->chLogSyncInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogSyncInterval);

	pstTlvDtFld->uchDelayMechanism = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	pstTlvDtFld->chLogMinPDReqInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPDReqInterval);

	pstTlvDtFld->byVerNum = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->byVerNum);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_PRIORITY1*	pstTlvDtFld = &pstPtpmsg->stPriority1;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PRIORITY1_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchPriority1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPriority1);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_PRIORITY2*	pstTlvDtFld = &pstPtpmsg->stPriority2;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PRIORITY2_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchPriority2 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPriority2);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*		puchTomsg		=  puchMsgPtr;
	MGT_DOMAIN*	pstTlvDtFld = &pstPtpmsg->stDomain;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_DOMAIN_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchDomainNum = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchDomainNum);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2008(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_SLAVE_ONLY*	pstTlvDtFld = &pstPtpmsg->stSlaveOnly;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_SLAVE_ONLY_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);


	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2009(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_LOG_ANNOUNCE_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogAnnounceIntv;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_LOG_ANNOUINTVAL_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->chLogAnounceInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogAnounceInterval);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200A(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT*	pstTlvDtFld = &pstPtpmsg->stAnnounceReceiptTout;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_ANNOU_RCPTTMOUT_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchAnounceRcptTimeout = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchAnounceRcptTimeout);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200B(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_LOG_SYNC_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogSyncInterval;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_LOG_SYNCINTVAL_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->chLogSyncInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogSyncInterval);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200C(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_VERSION_NUMBER*	pstTlvDtFld = &pstPtpmsg->stVersionNum;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_VERSION_NUM_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->byVerNum = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->byVerNum);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200D(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200E(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_200F(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*		puchTomsg		=  puchMsgPtr;
	MGT_TIME*	pstTlvDtFld = &pstPtpmsg->stTime;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TIME_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_TS((puchTomsg + usDtFld), &pstTlvDtFld->stTime);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2010(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_CLOCK_ACCURACY*	pstTlvDtFld = &pstPtpmsg->stClockAccuracy;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_CLKACC_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchClockAccuracy = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchClockAccuracy);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2011(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_UTC_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stUTC_Properties;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_UTC_PROPERTIES_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), (USHORT*)&pstTlvDtFld->sCrentUtcOffset);
	usDtFld  += usRet;


	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2012(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_TRACEABILITY_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stTrcebltyProperties;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TRACEBLTY_PRPRTS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);


	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2013(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_TIMESCALE_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stTimScaleProperties;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TMSCALE_PRPRTS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchTimeSource, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchTimeSource));
	usDtFld += sizeof(pstTlvDtFld->uchTimeSource);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2014(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICAST_NEGO_ENABLE*	pstTlvDtFld = &pstPtpmsg->stUCastNegoEnable;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TMSCALE_PRPRTS_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2015(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2016(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_PATH_TRACE_ENABLE*	pstTlvDtFld = &pstPtpmsg->stPathTraceEnable;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PATH_TRACEENABLE_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy(&pstTlvDtFld->uchReserved1, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2017(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_GRANDMS_CLUSTER_TABLE*	pstTlvDtFld = &pstPtpmsg->stGM_ClusterTbl;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;
	USHORT	usLoop = 0;

	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_GRANDMS_CLUSTER_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->chLogQueryInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogQueryInterval);

	pstTlvDtFld->uchTableSize = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchTableSize);

	for (usLoop = 0; usLoop < pstTlvDtFld->uchTableSize; usLoop++)
	{
		usSizeChkSrc += sizeof(USHORT) + sizeof(USHORT);
		if (usTLVLen < usSizeChkSrc)
		{
			return	PTP_MDTR_TLV_ERROR;
		}

		usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stGMClusterMembers[usLoop].usNetworkProtcol);
		usDtFld  += usRet;
		usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength);
		usDtFld  += usRet;

		usSizeChkSrc += pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength;
		if (usTLVLen < usSizeChkSrc)
		{
			return	PTP_MDTR_TLV_ERROR;
		}

		tsn_Wrapper_MemCpy(pstTlvDtFld->stGMClusterMembers[usLoop].uchAddressField, (puchTomsg + usDtFld),
			pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength);
		usDtFld  += pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength;
	}

	return (usDtFld + (usDtFld%2));
}
USHORT ptp_Mdl_ntoh_MgtId_2018(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICAST_MASTER_TABLE*	pstTlvDtFld = &pstPtpmsg->stUCastMasterTbl;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;
	USHORT	usLoop = 0;

	USHORT	usSizeChkSrc = 0;

	usSizeChkSrc = MGT_UNICAST_MASTER_SZ;

	if (usTLVLen < usSizeChkSrc)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->chLogQueryInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogQueryInterval);

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usTableSize);
	usDtFld += usRet;

	for (usLoop = 0; usLoop < pstTlvDtFld->usTableSize; usLoop++)
	{

		usSizeChkSrc += sizeof(USHORT) + sizeof(USHORT);
		if (usTLVLen < usSizeChkSrc)
		{
			return	PTP_MDTR_TLV_ERROR;
		}

		usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stUnicastMasterTable[usLoop].usNetworkProtcol);
		usDtFld  += usRet;
		usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength);
		usDtFld  += usRet;

		usSizeChkSrc += pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength;
		if (usTLVLen < usSizeChkSrc)
		{
			return	PTP_MDTR_TLV_ERROR;
		}

		tsn_Wrapper_MemCpy(pstTlvDtFld->stUnicastMasterTable[usLoop].uchAddressField, (puchTomsg + usDtFld),
			pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength);
		usDtFld  += pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength;
	}
	return (usDtFld + (usDtFld%2));
}
USHORT ptp_Mdl_ntoh_MgtId_2019(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICASTMS_MAX_TABLE_SZ*	pstTlvDtFld = &pstPtpmsg->stUCastMasterMaxTblSZ;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_UNICASTMS_MAX_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usMaxTableSize);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2100(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_PORT_STATISTICS_COUNT*	pstTlvDtFld = &pstPtpmsg->stPortStatisticsCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PORT_STAT_CNT_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxSyncCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxOneStepSyncCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxFollowUpCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxAnnounceCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxPTPPacketDiscardCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulSyncReceiptTimeoutCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulAnnounceReceiptTimeoutCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxSyncCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxOneStepSyncCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxFollowUpCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxAnnounceCount);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2101(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_CMLD_PORT_STATIS_COUNT*	pstTlvDtFld = &pstPtpmsg->stCMLD_PortStatisticsCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_CMLDPORT_STAT_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxPDReqCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxPDRespCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxPDRespFollowUpCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulRxPTPPacketDiscardCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulPDAllowedLostRespExceedCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxPDReqCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxPDRespCount);
	usDtFld  += usRet;

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxPDRespFollowUpCount);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_2102(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_PORT_STATISTICS_ERRCOUNT*	pstTlvDtFld = &pstPtpmsg->stPortStatisticsErrCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PORT_STAI_ERCNT_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_ul((puchTomsg + usDtFld), &pstTlvDtFld->ulTxMessageErrCount);
	usDtFld  += usRet;

	return usDtFld;
}

USHORT ptp_Mdl_ntoh_MgtId_4000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_TCLK_DEFAULT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTCLK_DefaultDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TCLK_DEF_DATA_SET_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	tsn_Wrapper_MemCpy(&pstTlvDtFld->stClockIdentity, (puchTomsg + usDtFld),
		sizeof(pstTlvDtFld->stClockIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stClockIdentity);

	usRet = mdtra_ntoh_us((puchTomsg + usDtFld), &pstTlvDtFld->usNumberPorts);
	usDtFld  += usRet;

	pstTlvDtFld->uchDelayMechanism = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	pstTlvDtFld->uchPrimaryDomain = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPrimaryDomain);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_4001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_TCLK_PORT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTCLK_PortDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_TCLK_DEF_DATA_SET_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	usRet = mdtra_ntoh_PortID((puchTomsg + usDtFld), &pstTlvDtFld->stPortIdentity);
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( &pstTlvDtFld->byFlags, 
	                    (puchTomsg + usDtFld),
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	pstTlvDtFld->chLogMinPdelayReqInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPdelayReqInterval);

	usRet = mdtra_ntoh_TInt((puchTomsg + usDtFld), &pstTlvDtFld->stPeerMeanPathDelay);
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_4002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_PRIMARY_DOMAIN*	pstTlvDtFld = &pstPtpmsg->stPrimaryDomain;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_PRIMARY_DOMAIN_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchPrimaryDomain = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchPrimaryDomain);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_6000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_DELAY_MECHANISM*	pstTlvDtFld = &pstPtpmsg->stDelayMechanism;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_DELAY_MECHANISM_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->uchDelayMechanism = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_ntoh_MgtId_6001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_LOG_MIN_PDREQ_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogMinPdelayReqIntv;
	USHORT	usDtFld = 0;

	if (usTLVLen < MGT_LG_MIN_PDR_INT_SZ)
	{
		return	PTP_MDTR_TLV_ERROR;
	}

	pstTlvDtFld->chLogMinPdelayReqInterval = (CHAR)(*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPdelayReqInterval);

	pstTlvDtFld->uchReserved1 = (*(puchTomsg + usDtFld));
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}


USHORT ptp_Mdl_hton_MgtId_0000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	USHORT	usDtFld = 0;
	return	usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_0001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_CLOCK_DESCRIPTION*	pstTlvDtFld = &pstPtpmsg->stClockDescription;
	UCHAR	uchPtptext_len = 0;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    pstTlvDtFld->byClockType,
		                sizeof(pstTlvDtFld->byClockType) );
	usDtFld  += sizeof(pstTlvDtFld->byClockType);

	uchPtptext_len = pstTlvDtFld->stPhyLyrProtocol.uchTextLength + 1;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stPhyLyrProtocol, uchPtptext_len);
	usDtFld  += uchPtptext_len;

	usRet = mdtra_hton_us(pstTlvDtFld->usPhyAddressLength, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->uchPhyAddress,
		pstTlvDtFld->usPhyAddressLength);
	usDtFld  += pstTlvDtFld->usPhyAddressLength;

	usRet = mdtra_hton_us(pstTlvDtFld->stProtocolAddress.usNetworkProtcol, (puchTomsg + usDtFld));
	usDtFld  += usRet;
	mdtra_hton_us(pstTlvDtFld->stProtocolAddress.usAddressLength, (puchTomsg + usDtFld));
	usDtFld  += usRet;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->stProtocolAddress.uchAddressField,
		pstTlvDtFld->stProtocolAddress.usAddressLength);
	usDtFld  += pstTlvDtFld->stProtocolAddress.usAddressLength;

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->uchManufacturerIdentity,
		sizeof(pstTlvDtFld->uchManufacturerIdentity));
	usDtFld  += sizeof(pstTlvDtFld->uchManufacturerIdentity);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	uchPtptext_len = pstTlvDtFld->stProductDescription.uchTextLength + 1;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stProductDescription, uchPtptext_len);
	usDtFld  += uchPtptext_len;

	uchPtptext_len = pstTlvDtFld->stRevisionData.uchTextLength + 1;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stRevisionData, uchPtptext_len);
	usDtFld  += uchPtptext_len;

	uchPtptext_len = pstTlvDtFld->stUserDescription.uchTextLength + 1;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stUserDescription, uchPtptext_len);
	usDtFld  += uchPtptext_len;

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->uchProfileIdentity,
		sizeof(pstTlvDtFld->uchProfileIdentity));
	usDtFld  += sizeof(pstTlvDtFld->uchProfileIdentity);

	if ((usDtFld % 2))
	{
		(*(puchTomsg + usDtFld)) = 0;
		usDtFld += 1;
	}
	return (usDtFld);
}
USHORT ptp_Mdl_hton_MgtId_0002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_USER_DESCRIPTION*	pstTlvDtFld = &pstPtpmsg->stUserDescription;
	UCHAR	uchPtptext_len = 0;
	USHORT	usDtFld = 0;

	uchPtptext_len = pstTlvDtFld->stUserDescription.uchTextLength + 1;
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stUserDescription, uchPtptext_len);
	usDtFld  += uchPtptext_len;

	if ((usDtFld % 2))
	{
		(*(puchTomsg + usDtFld)) = 0;
		usDtFld += 1;
	}

	return (usDtFld);
}
USHORT ptp_Mdl_hton_MgtId_0005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	USHORT	usDtFld = 0;
	return	usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_0006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_FAULT_LOG*		pstTlvDtFld = &pstPtpmsg->stFaultLog;
	USHORT	usPtptext_len;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;
	USHORT	usLoop;
	USHORT	numRecord;

	usRet = mdtra_hton_us(pstTlvDtFld->usNumOfFaultRecords, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	numRecord = pstTlvDtFld->usNumOfFaultRecords;
	if (pstTlvDtFld->usNumOfFaultRecords>30)
	{
		numRecord = 30;
	}
	for (usLoop = 0; usLoop < numRecord; usLoop++)
	{
		usRet = mdtra_hton_us(pstTlvDtFld->stFaultRecords[usLoop].usFaultRecordLength,(puchTomsg + usDtFld));
		usDtFld  += usRet;
		usRet = mdtra_hton_TS(&pstTlvDtFld->stFaultRecords[usLoop].stFaultTimestamp, (puchTomsg + usDtFld));
		usDtFld  += usRet;
		(*(puchTomsg + usDtFld)) = pstTlvDtFld->stFaultRecords[usLoop].uchSeverityCode;
		usDtFld  += 1;
		pstTlvDtFld->stFaultRecords[usLoop].stFaultName.uchTextLength = 4;
		usPtptext_len = pstTlvDtFld->stFaultRecords[usLoop].stFaultName.uchTextLength;
		tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stFaultRecords[usLoop].stFaultName.uchTextLength,
			(usPtptext_len + 1));
		usDtFld  += (usPtptext_len + 1);
		pstTlvDtFld->stFaultRecords[usLoop].stFaultValue.uchTextLength = 8;
		usPtptext_len = pstTlvDtFld->stFaultRecords[usLoop].stFaultValue.uchTextLength;
		tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stFaultRecords[usLoop].stFaultValue.uchTextLength,
			(usPtptext_len + 1));
		usDtFld  += (usPtptext_len + 1);
		pstTlvDtFld->stFaultRecords[usLoop].stFaultDescription.uchTextLength = 0;
		usPtptext_len = pstTlvDtFld->stFaultRecords[usLoop].stFaultDescription.uchTextLength;
		tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stFaultRecords[usLoop].stFaultDescription.uchTextLength,
			(usPtptext_len + 1));
		usDtFld  += (usPtptext_len + 1);
	}

	if ((usDtFld % 2))
	{
		(*(puchTomsg + usDtFld)) = 0;
		usDtFld += 1;
	}

	return (usDtFld);
}
USHORT ptp_Mdl_hton_MgtId_0007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_DEFAULT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stDefaultDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	usRet = mdtra_hton_us(pstTlvDtFld->usNumPorts, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPriority1;
	usDtFld  += sizeof(pstTlvDtFld->uchPriority1);

	usRet = mdtra_hton_CLKQLTY(&pstTlvDtFld->stClockQuality, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPriority2;
	usDtFld  += sizeof(pstTlvDtFld->uchPriority2);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stClockIdentity,
		sizeof(pstTlvDtFld->stClockIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stClockIdentity);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchDomainNum;
	usDtFld  += sizeof(pstTlvDtFld->uchDomainNum);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved2;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved2);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_CURRENT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stCurrentDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_us(pstTlvDtFld->usStepsRemoved, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_TInt(&pstTlvDtFld->stOffsetFromMaster, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_TInt(&pstTlvDtFld->stMeanPathDelay, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_PARENT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stParentDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_PortID(&pstTlvDtFld->stPrntPortIdentity, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	usRet = mdtra_hton_us(pstTlvDtFld->usObsPrentOfsetScalLogVrnc, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul((ULONG)pstTlvDtFld->lObsPrentClockPhsChngRate, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchGMasterPriority1;
	usDtFld  += sizeof(pstTlvDtFld->uchGMasterPriority1);

	usRet = mdtra_hton_CLKQLTY(&pstTlvDtFld->stGMasterClockQuality, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchGMasterPriority2;
	usDtFld  += sizeof(pstTlvDtFld->uchGMasterPriority2);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stGMasterIdentity,
		sizeof(pstTlvDtFld->stGMasterIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stGMasterIdentity);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2003(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_TIME_PROPERTIES_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTimePropertiesDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_us((USHORT)pstTlvDtFld->sCrentUtcOffset, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchTimeSource,
		sizeof(pstTlvDtFld->uchTimeSource));
	usDtFld += sizeof(pstTlvDtFld->uchTimeSource);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2004(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_PORT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stPortDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_PortID(&pstTlvDtFld->stPortIdentity, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPortState;
	usDtFld  += sizeof(pstTlvDtFld->uchPortState);

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogMinDReqInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogMinDReqInterval);

	usRet = mdtra_hton_TInt(&pstTlvDtFld->stPerMeanPathDelay, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogAnounceInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogAnounceInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchAnounceRcptTimeout;
	usDtFld  += sizeof(pstTlvDtFld->uchAnounceRcptTimeout);

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogSyncInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogSyncInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchDelayMechanism;
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogMinPDReqInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPDReqInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->byVerNum;
	usDtFld  += sizeof(pstTlvDtFld->byVerNum);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_PRIORITY1*	pstTlvDtFld = &pstPtpmsg->stPriority1;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPriority1;
	usDtFld  += sizeof(pstTlvDtFld->uchPriority1);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_PRIORITY2*	pstTlvDtFld = &pstPtpmsg->stPriority2;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPriority2;
	usDtFld  += sizeof(pstTlvDtFld->uchPriority2);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*		puchTomsg		=  puchMsgPtr;
	MGT_DOMAIN*	pstTlvDtFld = &pstPtpmsg->stDomain;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchDomainNum;
	usDtFld  += sizeof(pstTlvDtFld->uchDomainNum);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2008(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*			puchTomsg		=  puchMsgPtr;
	MGT_SLAVE_ONLY*	pstTlvDtFld = &pstPtpmsg->stSlaveOnly;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);
		

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2009(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_LOG_ANNOUNCE_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogAnnounceIntv;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogAnounceInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogAnounceInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200A(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT*	pstTlvDtFld = &pstPtpmsg->stAnnounceReceiptTout;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchAnounceRcptTimeout;
	usDtFld  += sizeof(pstTlvDtFld->uchAnounceRcptTimeout);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200B(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_LOG_SYNC_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogSyncInterval;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogSyncInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogSyncInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200C(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_VERSION_NUMBER*	pstTlvDtFld = &pstPtpmsg->stVersionNum;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->byVerNum;
	usDtFld  += sizeof(pstTlvDtFld->byVerNum);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200D(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200E(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	USHORT	usDtFld = 0;
	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_200F(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*		puchTomsg		=  puchMsgPtr;
	MGT_TIME*	pstTlvDtFld = &pstPtpmsg->stTime;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_TS(&pstTlvDtFld->stTime, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2010(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_CLOCK_ACCURACY*	pstTlvDtFld = &pstPtpmsg->stClockAccuracy;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchClockAccuracy;
	usDtFld  += sizeof(pstTlvDtFld->uchClockAccuracy);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2011(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_UTC_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stUTC_Properties;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_us((USHORT)pstTlvDtFld->sCrentUtcOffset, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->uchReserved1,
		                sizeof(pstTlvDtFld->uchReserved1) );
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2012(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_TRACEABILITY_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stTrcebltyProperties;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags));
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2013(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_TIMESCALE_PROPERTIES*	pstTlvDtFld = &pstPtpmsg->stTimScaleProperties;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchTimeSource,
		sizeof(pstTlvDtFld->uchTimeSource));
	usDtFld += sizeof(pstTlvDtFld->uchTimeSource);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2014(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICAST_NEGO_ENABLE*	pstTlvDtFld = &pstPtpmsg->stUCastNegoEnable;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);


	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2015(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_PATH_TRACE_LIST*	pstTlvDtFld = &pstPtpmsg->stPathTraceList;
	USHORT	usDtFld = 0;
	USHORT	len   = pstTlvDtFld->usPathSequenceNum * sizeof(pstTlvDtFld->stPathSequence[0]);
	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stPathSequence, len);
	usDtFld += len;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2016(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_PATH_TRACE_ENABLE*	pstTlvDtFld = &pstPtpmsg->stPathTraceEnable;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->uchReserved1,
		sizeof(pstTlvDtFld->uchReserved1));
	usDtFld += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2017(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_GRANDMS_CLUSTER_TABLE*	pstTlvDtFld = &pstPtpmsg->stGM_ClusterTbl;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;
	USHORT	usLoop = 0;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogQueryInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogQueryInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchTableSize;
	usDtFld  += sizeof(pstTlvDtFld->uchTableSize);

	for (usLoop = 0; usLoop < pstTlvDtFld->uchTableSize; usLoop++)
	{
		usRet = mdtra_hton_us(pstTlvDtFld->stGMClusterMembers[usLoop].usNetworkProtcol, (puchTomsg + usDtFld));
		usDtFld  += usRet;
		usRet = mdtra_hton_us(pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength, (puchTomsg + usDtFld));
		usDtFld  += usRet;
		tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->stGMClusterMembers[usLoop].uchAddressField,
			pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength);
		usDtFld  += pstTlvDtFld->stGMClusterMembers[usLoop].usAddressLength;
	}
	if ((usDtFld % 2))
	{
		(*(puchTomsg + usDtFld)) = 0;
		usDtFld += 1;
	}

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2018(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICAST_MASTER_TABLE*	pstTlvDtFld = &pstPtpmsg->stUCastMasterTbl;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;
	USHORT	usLoop = 0;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogQueryInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogQueryInterval);

	usRet = mdtra_hton_us(pstTlvDtFld->usTableSize, (puchTomsg + usDtFld));
	usDtFld += usRet;

	for (usLoop = 0; usLoop < pstTlvDtFld->usTableSize; usLoop++)
	{
		usRet = mdtra_hton_us(pstTlvDtFld->stUnicastMasterTable[usLoop].usNetworkProtcol, (puchTomsg + usDtFld));
		usDtFld  += usRet;
		usRet = mdtra_hton_us(pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength, (puchTomsg + usDtFld));
		usDtFld  += usRet;
		tsn_Wrapper_MemCpy((puchTomsg + usDtFld), pstTlvDtFld->stUnicastMasterTable[usLoop].uchAddressField,
			pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength);
		usDtFld  += pstTlvDtFld->stUnicastMasterTable[usLoop].usAddressLength;
	}
	if ((usDtFld % 2))
	{
		(*(puchTomsg + usDtFld)) = 0;
		usDtFld += 1;
	}

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2019(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_UNICASTMS_MAX_TABLE_SZ*	pstTlvDtFld = &pstPtpmsg->stUCastMasterMaxTblSZ;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_us(pstTlvDtFld->usMaxTableSize, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2100(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_PORT_STATISTICS_COUNT*	pstTlvDtFld = &pstPtpmsg->stPortStatisticsCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxSyncCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxOneStepSyncCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxFollowUpCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxAnnounceCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxPTPPacketDiscardCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulSyncReceiptTimeoutCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulAnnounceReceiptTimeoutCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxSyncCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxOneStepSyncCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxFollowUpCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxAnnounceCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2101(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_CMLD_PORT_STATIS_COUNT*	pstTlvDtFld = &pstPtpmsg->stCMLD_PortStatisticsCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxPDReqCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxPDRespCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxPDRespFollowUpCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulRxPTPPacketDiscardCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulPDAllowedLostRespExceedCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxPDReqCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxPDRespCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxPDRespFollowUpCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_2102(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*							puchTomsg		=  puchMsgPtr;
	MGT_PORT_STATISTICS_ERRCOUNT*	pstTlvDtFld = &pstPtpmsg->stPortStatisticsErrCnt;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_ul(pstTlvDtFld->ulTxMessageErrCount, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}

USHORT ptp_Mdl_hton_MgtId_4000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_TCLK_DEFAULT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTCLK_DefaultDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	tsn_Wrapper_MemCpy((puchTomsg + usDtFld), &pstTlvDtFld->stClockIdentity,
		sizeof(pstTlvDtFld->stClockIdentity));
	usDtFld  += sizeof(pstTlvDtFld->stClockIdentity);

	usRet = mdtra_hton_us(pstTlvDtFld->usNumberPorts, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchDelayMechanism;
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPrimaryDomain;
	usDtFld  += sizeof(pstTlvDtFld->uchPrimaryDomain);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_4001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_TCLK_PORT_DATA_SET*	pstTlvDtFld = &pstPtpmsg->stTCLK_PortDS;
	USHORT	usRet = 0;
	USHORT	usDtFld = 0;

	usRet = mdtra_hton_PortID(&pstTlvDtFld->stPortIdentity, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	tsn_Wrapper_MemCpy( (puchTomsg + usDtFld), 
	                    &pstTlvDtFld->byFlags,
		                sizeof(pstTlvDtFld->byFlags) );
	usDtFld  += sizeof(pstTlvDtFld->byFlags);

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogMinPdelayReqInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPdelayReqInterval);

	usRet = mdtra_hton_TInt(&pstTlvDtFld->stPeerMeanPathDelay, (puchTomsg + usDtFld));
	usDtFld  += usRet;

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_4002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*				puchTomsg		=  puchMsgPtr;
	MGT_PRIMARY_DOMAIN*	pstTlvDtFld = &pstPtpmsg->stPrimaryDomain;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchPrimaryDomain;
	usDtFld  += sizeof(pstTlvDtFld->uchPrimaryDomain);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_6000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*					puchTomsg		=  puchMsgPtr;
	MGT_DELAY_MECHANISM*	pstTlvDtFld = &pstPtpmsg->stDelayMechanism;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchDelayMechanism;
	usDtFld  += sizeof(pstTlvDtFld->uchDelayMechanism);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
USHORT ptp_Mdl_hton_MgtId_6001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg)
{
	UCHAR*						puchTomsg		=  puchMsgPtr;
	MGT_LOG_MIN_PDREQ_INTERVAL*	pstTlvDtFld = &pstPtpmsg->stLogMinPdelayReqIntv;
	USHORT	usDtFld = 0;

	(*(puchTomsg + usDtFld)) = (UCHAR)pstTlvDtFld->chLogMinPdelayReqInterval;
	usDtFld  += sizeof(pstTlvDtFld->chLogMinPdelayReqInterval);

	(*(puchTomsg + usDtFld)) = pstTlvDtFld->uchReserved1;
	usDtFld  += sizeof(pstTlvDtFld->uchReserved1);

	return usDtFld;
}
