/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "ccienx_app_supply.h"
#include "ccienx_event.h"
#include "INTR_api.h"

#define	INTR_AXIE_TX		((NX_ULONG)0x00000001)
#define	INTR_AXIE_RX		((NX_ULONG)0x00000004)
#define	INTR_AXIE_REG		((NX_ULONG)0x00000008)
#define INTR_AXIE_ALL		(INTR_AXIE_TX | INTR_AXIE_RX | INTR_AXIE_REG)



NX_ULONG gulIntAxiBusErr = NX_OFF;



NX_VOID ulINTR_CheckIntAxiBusErr (NX_VOID)
{
	NX_ULONG	ulFactor;
	
	if (gulIntAxiBusErr == NX_OFF) {
		ulFactor = NGN_CN_REG->R_REBERR.DATA & INTR_AXIE_ALL;
		if (ulFactor != 0) {
			vNX_SetEvent(EVENTCODE_AXI_BUS_ERR, NX_NULL);
			gulIntAxiBusErr = NX_ON;
			
		}
	}
	else {
	}
	
	return;
}
