/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NMG_common.h"

#define	NX_HOP_COUNT_INITIAL		((NX_USHORT)0xFFFF)
#define	NX_HOP_COUNT_PORT_INITIAL	((NX_USHORT)0x0000)

typedef struct tagDD_CTRL {
	NX_USHORT	usMinHopCount;
	NX_USHORT	usMinHopCountPort;
} DD_CTRL;

NX_STATIC	DD_CTRL	gstDD;




NX_VOID vNMG_SetHopCount ( 
	NX_USHORT usPort,
	NX_USHORT usHopCount
)
{
	if ( gstDD.usMinHopCount > usHopCount ) {
		gstDD.usMinHopCount = usHopCount;
		gstDD.usMinHopCountPort = usPort;
	}

	return;
}

NX_VOID vNMG_ClearHopCount (NX_VOID)
{
	gstDD.usMinHopCount		= NX_HOP_COUNT_INITIAL;
	gstDD.usMinHopCountPort	= NX_HOP_COUNT_PORT_INITIAL;

	return;
}

/*[EOF]*/
