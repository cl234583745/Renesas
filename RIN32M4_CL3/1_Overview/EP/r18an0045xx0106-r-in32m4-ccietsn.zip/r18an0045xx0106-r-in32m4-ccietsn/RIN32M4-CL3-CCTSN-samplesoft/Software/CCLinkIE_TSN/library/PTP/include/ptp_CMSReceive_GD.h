/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSRECEIVE_GD_H__
#define __PTP_CMSRECEIVE_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#define	COMPUTEGRRATIO_N		(10)


typedef	enum	tagEN_ST_CMSR {
	ST_CMSR_NONE	= 0,
	ST_CMSR_INITIALIZING,
	ST_CMSR_WAITING,
	ST_CMSR_RECEIVE_SOURCE_TIME,
	ST_CMSR_MAX
} EN_ST_CMSR;

typedef	enum	tagEN_EV_CMSR {
	EV_CMSR_BEGIN = 0,
	EV_CMSR_RCVDCLOCKSOURCEREQ,
	EV_CMSR_FOR_CLKMSYNRV_RVLOCTICK,
	EV_CMSR_CLOSE,
	EV_CMSR_EVENT_MAX
} EN_EV_CMSR;


typedef	struct tagCOMPUGRRSTACK
{
	EXTENDEDTIMESTAMP	stSourceTime;
	USCALEDNS			stLocalTime;
} COMPUGRRSTACK;
 
typedef	struct tagCMSRECEIVESM_GD
{
	EN_ST_CMSR			enStatusCMSR;
	BOOL				blRcvdClockSourceReq;
	CLKSOURCETIME*		pstRcvdClockSourceReqPtr;
	CLKSOURCETIME		stRcvdClockSourceReq;
	BOOL				blRcvdLocalClockTick;
	COMPUGRRSTACK		stComputeGRRatioStack[COMPUTEGRRATIO_N + 1];
	UCHAR				uchStackCount;
	UCHAR				uchCompareCount;
	UCHAR				uchMaxStackCount;
} CMSRECEIVESM_GD;	




#endif


