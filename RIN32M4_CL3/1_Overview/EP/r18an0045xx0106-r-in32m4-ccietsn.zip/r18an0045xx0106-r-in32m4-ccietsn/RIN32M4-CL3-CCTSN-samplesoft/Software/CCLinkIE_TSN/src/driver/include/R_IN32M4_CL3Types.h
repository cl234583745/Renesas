/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3TYPES_H__
#define __R_IN32M4_CL3TYPES_H__


/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "common.h"
#include "kernel_id.h"
#include "R_IN32M4_CL3Typedef.h"


/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
/* Other definitions */
#define R_IN_TRUE			(1)
#define R_IN_FALSE			(0)
#define R_IN_ON				(1)
#define R_IN_OFF			(0)


/* Error code definition */
#define R_IN_OK				( 0)							/* Normal															*/
#define R_IN_BUSY			( 1)							/* Processing														*/
#define R_IN_ERR			(-1)							/* Abnormal end														*/
#define R_IN_ERR_OTHER		(-2)							/* Abnormal end (An error occurred in the driver in the library.)	*/
#define R_IN_ERR_OUTOFRANGE	(-3)							/* Out of range														*/
#define R_IN_ERR_EMPTY		(-4)							/* Empty															*/
#define R_IN_ERR_OVERFLOW	(-5)							/* Overflow															*/
#define R_IN_ERR_NOENTRY	(-6)							/* There are no entries												*/
#define R_IN_ERR_NOPERMIT	(-7)							/* Not allowed														*/
#define R_IN_ERR_NODATA		(-8)							/* No data															*/
#define R_IN_ERR_STSW		(-9)							/* No valid StsW													*/
#define R_IN_ERR_BOUNDARY	(-10)							/* Boundary specification violation									*/
#define	R_IN_ERR_SEMAPHORE	(-11)							/* Semaphore acquisition failure									*/
#define	R_IN_ERR_FATAL		(-12)							/* Fatal error occurred												*/
#define	R_IN_ERR_TIMEOUT	(-13)							/* Timeout															*/

/* Shift value */
#define R_IN_SHIFT0			(0)
#define R_IN_SHIFT1			(1)
#define R_IN_SHIFT2			(2)
#define R_IN_SHIFT3			(3)
#define R_IN_SHIFT4			(4)
#define R_IN_SHIFT5			(5)
#define R_IN_SHIFT6			(6)
#define R_IN_SHIFT7			(7)
#define R_IN_SHIFT8			(8)
#define R_IN_SHIFT9			(9)
#define R_IN_SHIFT10		(10)
#define R_IN_SHIFT11		(11)
#define R_IN_SHIFT12		(12)
#define R_IN_SHIFT13		(13)
#define R_IN_SHIFT14		(14)
#define R_IN_SHIFT15		(15)
#define R_IN_SHIFT16		(16)
#define R_IN_SHIFT17		(17)
#define R_IN_SHIFT18		(18)
#define R_IN_SHIFT19		(19)
#define R_IN_SHIFT20		(20)
#define R_IN_SHIFT21		(21)
#define R_IN_SHIFT22		(22)
#define R_IN_SHIFT23		(23)
#define R_IN_SHIFT24		(24)
#define R_IN_SHIFT25		(25)
#define R_IN_SHIFT26		(26)
#define R_IN_SHIFT27		(27)
#define R_IN_SHIFT28		(28)
#define R_IN_SHIFT29		(29)
#define R_IN_SHIFT30		(30)
#define R_IN_SHIFT31		(31)
#define R_IN_SHIFT32		(32)

/* Bit position */
#define R_IN_BIT0			(0x00000001)
#define R_IN_BIT1			(0x00000002)
#define R_IN_BIT2			(0x00000004)
#define R_IN_BIT3			(0x00000008)
#define R_IN_BIT4			(0x00000010)
#define R_IN_BIT5			(0x00000020)
#define R_IN_BIT6			(0x00000040)
#define R_IN_BIT7			(0x00000080)
#define R_IN_BIT8			(0x00000100)
#define R_IN_BIT9			(0x00000200)
#define R_IN_BIT10			(0x00000400)
#define R_IN_BIT11			(0x00000800)
#define R_IN_BIT12			(0x00001000)
#define R_IN_BIT13			(0x00002000)
#define R_IN_BIT14			(0x00004000)
#define R_IN_BIT15			(0x00008000)
#define R_IN_BIT16			(0x00010000)
#define R_IN_BIT17			(0x00020000)
#define R_IN_BIT18			(0x00040000)
#define R_IN_BIT19			(0x00080000)
#define R_IN_BIT20			(0x00100000)
#define R_IN_BIT21			(0x00200000)
#define R_IN_BIT22			(0x00400000)
#define R_IN_BIT23			(0x00800000)
#define R_IN_BIT24			(0x01000000)
#define R_IN_BIT25			(0x02000000)
#define R_IN_BIT26			(0x04000000)
#define R_IN_BIT27			(0x08000000)
#define R_IN_BIT28			(0x10000000)
#define R_IN_BIT29			(0x20000000)
#define R_IN_BIT30			(0x40000000)
#define R_IN_BIT31			(0x80000000)

/* MAC address length */
#define R_IN_MACADR_SZ		(6)								/* MAC address size										*/

/* Byte position */
#define R_IN_BYTE1			(0x000000FF)
#define R_IN_BYTE2			(0x0000FF00)
#define R_IN_BYTE3			(0x00FF0000)
#define R_IN_BYTE4			(0xFF000000)

/* LED lighting control */
#define R_IN_LED_OFF							(0)			/* LED off												*/
#define R_IN_LED_ON								(1)			/* LED on												*/
#define R_IN_LED_BLINK_1000						(2)			/* LED blinking (blink interval: 1 sec)					*/
#define R_IN_LED_BLINK_500						(3)			/* LED blinking (blink interval: 500 msec)				*/
#define R_IN_LED_BLINK_200						(4)			/* LED blinking (blink interval: 200 msec)				*/
#define R_IN_LEDMODE_SD_RD						(0)			/* Lighting mode: SD/RD									*/
#define R_IN_LEDMODE_SDRD1_SDRD2				(1)			/* Lighting mode: SDRD1/SDRD2							*/

/* NetworkRAM size */
#define R_IN_NETRAM_SND_CYCLIC_AREA_SIZE		(2560)		/* Data area size for cyclic transmission (2.5KB)		*/
#define R_IN_NETRAM_SND_NONCYCLIC_AREA_SIZE		(20480)		/* Data area size for non-cyclic transmission (20KB)	*/
#define R_IN_NETRAM_RCV_NONCYCLIC_AREA_SIZE		(45056)		/* Data area size for non-cyclic reception (44KB)		*/
#define R_IN_NETRAM_RCV_CYCLIC_AREA_SIZE		(2560)		/* Data area size for cyclic reception (2.5KB)			*/

/* Port information */
#define R_IN_PORT1								(0)			/* Port1												*/
#define R_IN_PORT2								(1)			/* Port2												*/
#define R_IN_MAX_PORT_NUMBER					(2)			/* Number of ports										*/

/* Module information related */
#define R_IN_MODEL_NAME_LENGTH					(20)		/* Maximum length of model name							*/
#define R_IN_VENDOR_NAME_LENGTH					(32)		/* Maximum length of vendor name						*/
#define R_IN_SERIAL_NUMBER_LENGTH				(32)		/* Maximum length of serial number						*/
#define R_IN_MAX_STATION_SUBID_NUMBER			(4096)		/* Maximum of station sub ID number						*/

/* Application details error status initial value */
#define R_IN_ERRSTS_NONE						(0)			/* No error												*/
#define R_IN_ERRSTS_WARNING						(1)			/* Minor error											*/
#define R_IN_ERRSTS_ERROR						(2)			/* Moderate error										*/
#define R_IN_ERRSTS_FATALERROR					(3)			/* Major error											*/

/* Node type */
#define R_IN_NODE_MASTER						(0x00)		/* Node type: master station							*/
#define R_IN_NODE_SLAVE							(0x01)		/* Node type: slave station								*/
#define R_IN_NODE_HUB							(0x02)		/* Node type: intelligent HUB							*/
#define R_IN_NODE_SSCNET						(0x03)		/* Node type: SSCNET III/H Gateway						*/
#define R_IN_NODE_SUBMASTER						(0x04)		/* Node type: submaster station							*/


/* Cyclic communication status */
#define	R_IN_CYCLIC_STATUS_NORMAL									(0x00)			/* Normal communication or power on					*/
#define	R_IN_CYCLIC_STATUS_TIMEUP									(0x02)			/* Monitoring time time-up							*/
#define	R_IN_CYCLIC_STATUS_RESERVATION_STATION						(0x12)			/* Own reserved station setting						*/
#define	R_IN_CYCLIC_STATUS_STATION_NUMBER_DUPLICATION				(0x13)			/* Own station number is duplicated					*/

/* Fatal error */
#define R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR					(0x0000D52A)	/* Error waiting for MDIO command					*/
#define R_IN_FATALERROR_LOOPBACKTEST_SEND_ERROR						(0x0000D530)
#define R_IN_FATALERROR_LOOPBACKTEST_RECEIVE_FRAME_ERROR			(0x0000D531)
#define R_IN_FATALERROR_LOOPBACKTEST_RECEIVE_COUNT_ERROR			(0x0000D532)
#define R_IN_FATALERROR_LOOPBACKTEST_RECEIVE_DISCARD_COUNT_ERROR	(0x0000D533)
#define R_IN_FATALERROR_SYNCMODE_CHANGE								(0x10000001)	/* Synchronous communication mode redefinition		*/

/* Define Callback Function */
#define R_IN_FUNCTIONTYPE_TIMESYNC_COMPLETE						(0)	/* Time synchronization completion processing		*/
#define R_IN_FUNCTIONTYPE_CYCLICDATA_INITIALIZE					(1) /* Cyclic send data initialization processing at the start of cyclic transmission */
#define R_IN_FUNCTIONTYPE_CYCLIC_START							(2)	/* Cyclic start processing							*/
#define R_IN_FUNCTIONTYPE_DISCONNECT_PARTWAY_THROUGH			(3) /* Processing for disconnection part way through	*/
#define R_IN_FUNCTIONTYPE_COMCYLCE_DEFINITION					(4) /* Communication cycle judgment processing			*/
#define R_IN_FUNCTIONTYPE_SYNC_CYCLIC_COM						(5)	/* Synchronous cyclic communication processing		*/

/* Error information */
#define R_IN_ERROR_DETAIL_SIZE					(10)				/* Error information detail size					*/


/* Speed */
#define R_IN_SPEED_1G							(0)					/* 1Gbps											*/
#define R_IN_SPEED_100M							(1)					/* 100Mbps											*/
#define R_IN_SPEED_10M							(2)					/* 10Mbps											*/

/* CC-Link IE TSN Class */
#define R_IN_CCIETSN_CLASS_A					(0)					/* CC-Link IE TSN Class A							*/
#define R_IN_CCIETSN_CLASS_B					(1)					/* CC-Link IE TSN Class B							*/

/* Time-managed polling method maximum response time*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_NON		(0)					/* Time-managed polling method unused				*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_256US		(8)					/*       256us	(2^8us)								*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_512US		(9)					/*       512us	(2^9us)								*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_1024US	(10)				/*     1,024us	(2^10us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_2048US	(11)				/*     2,048us	(2^11us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_4096US	(12)				/*     4,096us	(2^12us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_8192US	(13)				/*     8,192us	(2^13us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_16384US	(14)				/*    16,384us	(2^14us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_32768US	(15)				/*    32,768us	(2^15us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_65536US	(16)				/*    65,536us	(2^16us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_131072US	(17)				/*   131,072us	(2^17us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_262144US	(18)				/*   262,144us	(2^18us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_524288US	(19)				/*   524,288us	(2^19us)							*/
#define	R_IN_CYCLIC_MAX_RESPONSE_TIME_1048576US	(20)				/* 1,048,576us	(2^20us)							*/

/* WDC check result */
#define R_IN_WDC_OK								(0)					/* WDC normal								*/
#define R_IN_WDC_NOT_COMP						(1)					/* WDC error (end without comparison)		*/
#define R_IN_WDC_NG_LESS						(2)					/* WDC error (within threshold)				*/
#define R_IN_WDC_NG_OVER						(3)					/* WDC error (out of range of threshold)	*/
/* Maximum number of time slots */
#define R_IN_TIMESLOT_MAX						(8)					/* Maximum number of time slots				*/


#ifdef MCUIF_ENABLE
/* I/F between MCU */
#define R_IN_CSIH_CH_SELECT						(R_IN_CSIH_UNUSED)	/* Inter-MCU I/F serial communication Ch specification 0: CSIH not used, 1: CSIH0 used, 2: CSIH1 used	*/
#define R_IN_CSIH0								(1)					/* CSIH0 used		*/
#define R_IN_CSIH1								(2)					/* CSIH1 used		*/
#define R_IN_CSIH_UNUSED						(0)					/* CSIH not used	*/


/* Monitoring timer */
#define R_IN_MCU_IF_RESPONSE_TIME				(20)				/* GPIO communication response reception monitoring time (2000us)	*/

/* Execution function when serial communication is completed */
typedef VOID	(* R_IN_MCU_IF_RTDMA_RESERVED_FUNCTION)(VOID);		/* Execution function (receive) when serial communication is completed	*/
typedef VOID	(* R_IN_MCU_IF_RTDMA_SEND_FUNCTION)(VOID);			/* Execution function (send) when serial communication is completed		*/

/* Execution function when receiving GPIO communication request / response */
typedef VOID	(* R_IN_MCU_IF_REQUEST_FUNCTION)(VOID);				/* Execution function when receiving GPIO communication request		*/
typedef VOID	(* R_IN_MCU_IF_RESPONSE_FUNCTION)(ULONG ulRet);		/* Execution function when receiving GPIO communication response	*/

/* GPIO operation */
typedef VOID	(* R_IN_MCU_IF_ACK_GPIO_SET_FUNCTION)(UCHAR* puchEventKind,UCHAR* puchEventCode);	/* GPIO communication reception function		*/
typedef VOID	(* R_IN_MCU_IF_ACK_GPIO_CLEAR_FUNCTION)(VOID);										/* GPIO communication reception clear function	*/
typedef ERRCODE	(* R_IN_MCU_IF_REQUEST_GPIO_SET_FUNCTION)(UCHAR uchEventKind,UCHAR uchEventCode);	/* GPIO communication IO setting function		*/

#endif
#endif

/*** EOF ***/
