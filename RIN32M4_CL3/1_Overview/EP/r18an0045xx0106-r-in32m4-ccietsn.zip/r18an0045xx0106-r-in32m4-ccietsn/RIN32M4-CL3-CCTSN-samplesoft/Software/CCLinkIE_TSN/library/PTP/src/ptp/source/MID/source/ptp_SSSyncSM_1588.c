/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588

#include "ptp_CSSync_1588.h"
#include "ptp_PSSSend.h"
#include "ptp_SSSync_1588.h"

#define D_FUNC	0
#define D_DBG	0


SSSYNCSM_1588_GD*		GetSSSyncSM_1588_GD(CLOCKDATA*	pstClockData);
EN_EV_SSS_1588			GetSSSyncSM_1588_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsSSSyncSM_1588_Status(CLOCKDATA*	pstClockData);
VOID	SSSync_1588_00(CLOCKDATA*	pstClockData);
VOID	SSSync_1588_01(CLOCKDATA*	pstClockData);
VOID	SSSync_1588_02(CLOCKDATA*	pstClockData);
VOID	txPSSyncAll(CLOCKDATA*	pstClockData);
PORTSYNCSYNC*  setPSSyncSend(PORTSYNCSYNC*	pstRcvdPSSyncPtr, CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
VOID	txPSSync(PORTSYNCSYNC*	pstTxPSSyncPtr, PORTDATA*	pstPortData);
VOID	txPSSyncToCSS(PORTSYNCSYNC*	pstTxPSSyncPtr, CLOCKDATA*	pstClockData);





VOID (*const pfnSSSync_1588_Matrix[ST_SSS_1588_MAX][EV_SSS_1588_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&SSSync_1588_01, &SSSync_1588_01, &SSSync_1588_01, &SSSync_1588_00},
	{&SSSync_1588_01, &SSSync_1588_02, &SSSync_1588_02, &SSSync_1588_00},
	{&SSSync_1588_01, &SSSync_1588_02, &SSSync_1588_02, &SSSync_1588_00}
};



VOID	siteSyncSync_1588(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_SSS_1588	enEvt = EV_SSS_1588_EVENT_MAX;
	BOOL 			blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("SSSyncSM_1588   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.enStatusSSS_1588);
}
#endif
		enEvt = GetSSSyncSM_1588_Event(usEvent, pstClockData);
		if (enEvt >= EV_SSS_1588_EVENT_MAX)
		{
			if((pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.blRcvdPSSync == FALSE) &&
							((enEvt != EV_SSS_1588_BEGIN) && (enEvt != EV_SSS_1588_CLOSE)))
			{
				pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.blRcvdPSSync		= FALSE;
				pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.blRcvdPSSync_1588	= FALSE;
				return;
			}
		}

		blSts = IsSSSyncSM_1588_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_SSS_1588_EVENT_MAX))
		{
			(*pfnSSSync_1588_Matrix[pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.enStatusSSS_1588][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_SSSYNCSM_1588, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.blRcvdPSSync		= FALSE;
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.blRcvdPSSync_1588	= FALSE;
		}

	}
}




SSSYNCSM_1588_GD*	GetSSSyncSM_1588_GD(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD);
	return pstSSSGlb;
}




EN_EV_SSS_1588	GetSSSyncSM_1588_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb			= GetSSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	EN_EV_SSS_1588		enEvt					= EV_SSS_1588_EVENT_MAX;


	pstRcvdPSSyncPtr = pstSSSGlb->pstRcvdPSSyncPtr;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_SSS_1588_BEGIN;
			break;

		case PTP_EV_FOR_STSYNSYN_RCVSYNC:
		case PTP_EV_FOR_STSYNSYN_RCVSYNC_1588:
			if (IS_OD_BC_1588(pstClockData))
			{
				if (((pstSSSGlb->blRcvdPSSync) &&
					((pstClockData->stClock_GD.enSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber] == ENUM_PORTSTATE_SLAVE) ||
					(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber]
																									== (UCHAR)PS_EX_UNCALIBRATED)) &&
					 (pstClockData->stClock_GD.blGmPresent)) ||
					((pstSSSGlb->blRcvdPSSync) &&
					 (pstClockData->stClock_GD.enSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber] == ENUM_PORTSTATE_PASSIVE)) ||
					((pstSSSGlb->blRcvdPSSync_1588) &&
					((pstClockData->stClock_GD.enSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber] == ENUM_PORTSTATE_SLAVE) ||
					(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber]
																									== (UCHAR)PS_EX_UNCALIBRATED))
					))
				{
					enEvt = EV_SSS_1588_FOR_STSYNSYN_RCVSYN;
				}
				else
				{
					if (pstRcvdPSSyncPtr->usLocalPortNumber != 0)
					{
						PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_SSSYNCSM_1588, PTP_LOGVE_84000004);
					}
					pstSSSGlb->blRcvdPSSync	= FALSE;
				}
			}
			else
			{
				enEvt = EV_SSS_1588_FOR_STSYNSYN_RCVSYN;

			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_SSS_1588_CLOSE;
			break;

		default:
			enEvt = EV_SSS_1588_EVENT_MAX;
			break;
	}

	return	enEvt;
}

BOOL	IsSSSyncSM_1588_Status(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb	= GetSSSyncSM_1588_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstSSSGlb->enStatusSSS_1588 < ST_SSS_1588_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	SSSync_1588_00(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb = GetSSSyncSM_1588_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "SSSync_1588_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstSSSGlb->blRcvdPSSync			= FALSE;
	pstSSSGlb->blRcvdPSSync_1588	= FALSE;
	pstSSSGlb->enStatusSSS_1588		= ST_SSS_1588_NONE;

	ptp_dbg_msg( D_FUNC, ("SSSync_1588_00::-\n") );
}




VOID	SSSync_1588_01(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb = GetSSSyncSM_1588_GD(pstClockData);


	pstSSSGlb->blRcvdPSSync			= FALSE;
	pstSSSGlb->blRcvdPSSync_1588	= FALSE;
	pstSSSGlb->enStatusSSS_1588		= ST_SSS_1588_INITIALIZING;
}




VOID	SSSync_1588_02(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb			= GetSSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= NULL;
	PORTSYNCSYNC*		pstTxPSSyncPtr		= NULL;

	ptp_dbg_msg(D_FUNC,
		("%s::domain=[%d]\n",
			"SSSync_1588_02+",
			pstClockData->stDefaultDS.uchDomainNumber
			));

	pstRcvdPSSyncPtr = pstSSSGlb->pstRcvdPSSyncPtr;
	if (pstSSSGlb->blRcvdPSSync)
	{
		txPSSyncAll(pstClockData);
	}

	if (IS_OD_BC_1588(pstClockData))
	{
		if (((pstSSSGlb->blRcvdPSSync) &&
			  (pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)) ||
			(pstSSSGlb->blRcvdPSSync_1588))
		{
			pstPortData = NULL;
			pstTxPSSyncPtr = setPSSyncSend(pstRcvdPSSyncPtr, pstClockData, pstPortData);
			txPSSyncToCSS(pstTxPSSyncPtr, pstClockData);
		}
	}
	pstSSSGlb->blRcvdPSSync			= FALSE;
	pstSSSGlb->blRcvdPSSync_1588	= FALSE;
	pstSSSGlb->enStatusSSS_1588		= ST_SSS_1588_RECEIVING_SYNC;

	ptp_dbg_msg(D_FUNC, ("SSSync_1588_02::-\n"));

}




VOID	txPSSyncAll(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb			= GetSSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= NULL;
	PORTSYNCSYNC*		pstTxPSSyncPtr		= NULL;

	ptp_dbg_msg(D_FUNC, ("txPSSyncAll::+\n"));

	pstRcvdPSSyncPtr = pstSSSGlb->pstRcvdPSSyncPtr;

	for (pstPortData = pstClockData->pstPortData;
			pstPortData != NULL;
			pstPortData = pstPortData->pstNextPortDataPtr)
	{
		ptp_dbg_msg(D_DBG,
			("port=[%d] blPortValid=[%d] stat={%d]\n",
				pstPortData->stPortDS.stPortIdentity.usPortNumber,
				pstPortData->stPort_GD.blPortValid,
				pstClockData->stClock_GD.enSelectedState[pstPortData->stPortDS.stPortIdentity.usPortNumber]
				));

		if (pstPortData->stPort_GD.blPortValid == TRUE)
		{
			if (!IS_OD_BC_1588(pstClockData))
			{
				pstTxPSSyncPtr = setPSSyncSend(pstRcvdPSSyncPtr, pstClockData, pstPortData);
				pstPortData->stPort_GD.chParentLogSyncInterval = pstTxPSSyncPtr->chLogMessageInterval;
				txPSSync(pstTxPSSyncPtr, pstPortData);
			}
			else if (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER)
			{
				pstTxPSSyncPtr = setPSSyncSend(pstRcvdPSSyncPtr, pstClockData, pstPortData);
				pstPortData->stPort_GD.chParentLogSyncInterval = pstTxPSSyncPtr->chLogMessageInterval;
				txPSSync(pstTxPSSyncPtr, pstPortData);
			}
			else
			{
			}
		}
	}
	ptp_dbg_msg(D_FUNC, ("txPSSyncAll::-\n"));
}




PORTSYNCSYNC*  setPSSyncSend(
	PORTSYNCSYNC*	pstRcvdPSSyncPtr,
	CLOCKDATA*		pstClockData,
	PORTDATA*		pstPortData)
{
	SSSYNCSM_1588_GD*	pstSSSGlb		= NULL;
	PORTSYNCSYNC*		pstTxPSSyncPtr	= NULL;


	pstSSSGlb = GetSSSyncSM_1588_GD(pstClockData);
	if (pstPortData == NULL)
	{
		pstTxPSSyncPtr = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD.stRcvdPSSyncDat);
		if (pstSSSGlb->blRcvdPSSync_1588)
		{
			pstTxPSSyncPtr->usLocalPortNumber	  = pstRcvdPSSyncPtr->usLocalPortNumber;
		}
		else
		{
			pstTxPSSyncPtr->usLocalPortNumber	  = PORT_NO_0;
		}
	}
	else
	{
		pstTxPSSyncPtr						= &(pstPortData->stPSSSendSM_GD.stRcvdPSSync);
		pstTxPSSyncPtr->usLocalPortNumber	= pstRcvdPSSyncPtr->usLocalPortNumber;
	}

	pstTxPSSyncPtr->uchClockNumber				= pstRcvdPSSyncPtr->uchClockNumber;
	pstTxPSSyncPtr->stSyncReceiptTimeoutTime	= pstRcvdPSSyncPtr->stSyncReceiptTimeoutTime;
	pstTxPSSyncPtr->stFollowUpCorrectionField	= pstRcvdPSSyncPtr->stFollowUpCorrectionField;
	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdPSSyncPtr->stSourcePortIdentity;
	pstTxPSSyncPtr->chLogMessageInterval		= pstRcvdPSSyncPtr->chLogMessageInterval;
	pstTxPSSyncPtr->stPreciseOriginTimestamp	= pstRcvdPSSyncPtr->stPreciseOriginTimestamp;
	pstTxPSSyncPtr->stUpstreamTxTime			= pstRcvdPSSyncPtr->stUpstreamTxTime;
	pstTxPSSyncPtr->dbRateRatio					= pstRcvdPSSyncPtr->dbRateRatio;
	pstTxPSSyncPtr->usGmTimeBaseIndicator		= pstRcvdPSSyncPtr->usGmTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange			= pstRcvdPSSyncPtr->stLastGmPhaseChange;
	pstTxPSSyncPtr->dbLastGmFreqChange			= pstRcvdPSSyncPtr->dbLastGmFreqChange;
	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdPSSyncPtr->stSourcePortIdentity;

	return pstTxPSSyncPtr;

}




VOID  txPSSync(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	PORTDATA*		pstPortData)
{
	USHORT		usEvent = PTP_EV_BASE;

	ptp_dbg_msg(D_FUNC, ("txPSSync::+\n"));

	pstPortData->stPSSSendSM_GD.pstRcvdPSSyncPtr = pstTxPSSyncPtr;
	pstPortData->stPSSSendSM_GD.blRcvdPSSync	 = TRUE;

	usEvent = PTP_EV_FOR_PORTSYNSYNSD_RVPSYNC;
	portSyncSyncSend(usEvent, pstPortData);

	ptp_dbg_msg(D_FUNC, ("txPSSync::-\n"));
}




VOID	txPSSyncToCSS(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	CLOCKDATA*		pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSyncSM_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD);
	USHORT				usEvent				= PTP_EV_BASE;


	pstCSSyncSM_1588_GD->pstRcvdPSSyncPtr	= pstTxPSSyncPtr;
	pstCSSyncSM_1588_GD->blRcvdPSSync		= TRUE;


	usEvent = PTP_EV_FOR_CLKSLVSYN_RVPSYNC;
	clockSlaveSync_1588(usEvent, pstClockData);

}



#endif

