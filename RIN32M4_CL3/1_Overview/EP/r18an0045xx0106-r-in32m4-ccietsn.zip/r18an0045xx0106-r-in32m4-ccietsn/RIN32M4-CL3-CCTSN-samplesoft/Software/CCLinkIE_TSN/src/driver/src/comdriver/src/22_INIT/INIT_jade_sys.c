/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "JADE.h"
#include "INIT_jade.h"

#define		R_MACPHY_RST_RP_MASK	(0x00000002)

NX_VOID vINIT_jade_sys ( NX_VOID )
{
	
	if ((NX_JADE_SYS->R_MACPHY_RST & R_MACPHY_RST_RP_MASK) != NX_OFF){
		gstNET.ulStartUpProcess = STARTUP_POWER_ON;
	}
	else{
		gstNET.ulStartUpProcess = STARTUP_REMOTE_RESET;
	}
	
	NX_JADE_SYS->R_MACPHY_RST	=	0x0000001F;
	
	NX_JADE_SYS->R_HRESETZ_MSK	=	0x00000003;
	NX_JADE_SYS->R_PROTSEL		=	0x00000000;
	NX_JADE_SYS->R_MICON		=	0x00000000;
	NX_JADE_SYS->R_SYNCCNT		=	0x00000001;
	NX_JADE_SYS->R_WDTMSK		=	0x00007AB7;
												
	NX_JADE_SYS->R_ERRDET		=	0x00000007;
	NX_JADE_SYS->R_ERRHLD		=	0x00000000;
	NX_JADE_SYS->R_ERRRST		=	0x80000000;
	NX_JADE_SYS->R_BYPASSEN		=	0x00000000;
	NX_JADE_SYS->R_BYPASSCNT	=	0x000001F4;
	
	NX_JADE_SYS->R_WDTCNT		=	0x00000000;
	NX_JADE_SYS->R_WDTSET		=	0x00000000;
	
	NX_JADE_SYS->R_LEDCNT1		=	0x00000000;
	NX_JADE_SYS->R_LEDCNT2		=	0x00000145;
	NX_JADE_SYS->R_LEDMASK		=	0x00000000;
	NX_JADE_SYS->R_LEDHWEN		=	0x0000000E;
	NX_JADE_SYS->R_LEDSDRDDET	=	0x00000000;
	
	NX_JADE_SYS->R_WDTINTMSK	=	0x00000000;
	NX_JADE_SYS->R_WDTINL_MSK	=	0x00000000;
	
	NX_JADE_SYS->R_TESTLED		=	0x00000000;
	
	NX_JADE_SYS->R_MACPHY_RST	=	0x00000001;
	
	return;
}
/*[EOF]*/
