/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MANAGEMENT_TLV_H__
#define __PTP_MANAGEMENT_TLV_H__

#include "PTP_Management_DTF.h"

#define PTPM_MGTBDY_LENGTH_FIX			(sizeof(PTPMSG_MANAGEMENT_1588) - 4)
#define	PTPM_MGTBDY_TVLLENGTH_FIXMIN	(4)
#define	PTPM_MGTTVL_LENGTH_FIXMIN		(2)

#define PTPMSG_MGTTLV_MANAGEMENT		(0x0001U)
#define PTPMSG_MGTTVL_MANAGEMENT_ERRORS	(0x0002U)

#define	PTPM_MGT_ACTION_GET				(0x00)
#define	PTPM_MGT_ACTION_SET				(0x01)
#define	PTPM_MGT_ACTION_RES				(0x02)
#define	PTPM_MGT_ACTION_CMD				(0x03)
#define	PTPM_MGT_ACTION_ACK				(0x04)

#define	PTPM_MGT_NULL_MANAGEMENT		(0x0000U)
#define	PTPM_MGT_CLOCK_DESCRIPTION		(0x0001U)
#define	PTPM_MGT_USER_DESCRIPTION		(0x0002U)
#define	PTPM_MGT_INITIALIZE				(0x0005U)
#define	PTPM_MGT_FAULT_LOG				(0x0006U)
#define	PTPM_MGT_FAULT_LOG_RESET		(0x0007U)
#define	PTPM_MGT_DEFAULT_DATA_SET		(0x2000U)
#define	PTPM_MGT_CURRENT_DATA_SET		(0x2001U)
#define	PTPM_MGT_PARENT_DATA_SET		(0x2002U)
#define	PTPM_MGT_TIME_PROPERT_DATA_SET	(0x2003U)
#define	PTPM_MGT_PORT_DATA_SET			(0x2004U)
#define	PTPM_MGT_PRIORITY1				(0x2005U)
#define	PTPM_MGT_PRIORITY2				(0x2006U)
#define	PTPM_MGT_DOMAIN					(0x2007U)
#define	PTPM_MGT_SLAVE_ONLY				(0x2008U)
#define	PTPM_MGT_LOG_ANNOUNCE_INTERVAL	(0x2009U)
#define	PTPM_MGT_ANNOUNCE_RECEIPT_TMOUT	(0x200AU)
#define	PTPM_MGT_LOG_SYNC_INTERVAL		(0x200BU)
#define	PTPM_MGT_VERSION_NUMBER			(0x200CU)
#define	PTPM_MGT_ENABLE_PORT			(0x200DU)
#define	PTPM_MGT_DISABLE_PORT			(0x200EU)
#define	PTPM_MGT_TIME					(0x200FU)
#define	PTPM_MGT_CLOCK_ACCURACY			(0x2010U)
#define	PTPM_MGT_UTC_PROPERTIES			(0x2011U)
#define	PTPM_MGT_TRACEABILITY_PROPERT	(0x2012U)
#define	PTPM_MGT_TIMESCALE_PROPERTIES	(0x2013U)
#define	PTPM_MGT_UNICAST_NEGOTI_ENABLE	(0x2014U)
#define	PTPM_MGT_PATH_TRACE_LIST		(0x2015U)
#define	PTPM_MGT_PATH_TRACE_ENABLE		(0x2016U)
#define	PTPM_MGT_GM_CLUSTER_TBL			(0x2017U)
#define	PTPM_MGT_UNICAST_MSTR_TBL		(0x2018U)
#define	PTPM_MGT_UNICAST_MSTR_MAX_TBLSZ	(0x2019U)
#define	PTPM_MGT_PORT_STAT_COUNT		(0x2100U)
#define	PTPM_MGT_CMLD_PORT_STAT_COUNT	(0x2101U)
#define	PTPM_MGT_PORT_STAT_ERRCOUNT		(0x2102U)
#define	PTPM_MGT_TCLK_DEFAULT_DATA_SET	(0x4000U)
#define	PTPM_MGT_TCLK_PORT_DATA_SET		(0x4001U)
#define	PTPM_MGT_PRIMARY_DOMAIN			(0x4002U)
#define	PTPM_MGT_DELAY_MECHANISM		(0x6000U)
#define	PTPM_MGT_LOG_MIN_PDREQ_INTERVAL	(0x6001U)

#define	PTPM_MGTER_RESPONSE_TOO_BIG		(0x0001U)
#define	PTPM_MGTER_NO_SUCH_ID			(0x0002U)
#define	PTPM_MGTER_WRONG_LENGTH			(0x0003U)
#define	PTPM_MGTER_WRONG_VALUE			(0x0004U)
#define	PTPM_MGTER_NOT_SETABLE			(0x0005U)
#define	PTPM_MGTER_NOT_SUPPORTED		(0x0006U)
#define	PTPM_MGTER_GENERAL_ERROR		(0xFFFEU)

typedef struct tagPTPMSG_MANAGEMENT_TLV{
	USHORT				usTLVType;
	USHORT				usLengthField;
	USHORT				usManagementId;
	MGT_DATAFIELD		stDataField;
}	PTPMSG_MANAGEMENT_TLV;
#define	GetPTPMSG_MANAGEMENT_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).usManagementId));	\
			DEBUG_PRINT("GetPTPMSG_MANAGEMENT_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_MANAGEMENT_TLV));	\
		}
#define PTPMSG_MGTTLV_TLVTYPE_SZ			2U
#define PTPMSG_MGTTLV_TLVLENGTH_SZ			2U
#define PTPMSG_MGTTLV_MANAGEMENTID_SZ		2U

typedef struct tagPTPMSG_MANAGEMENT_ERRSTA_TLV{
	USHORT				usTLVType;
	USHORT				usLengthField;
	USHORT				usManagementErrorId;
	USHORT				usManagementId;
	UCHAR				uchReserved[4];
	PTPTEXT				stDisplayData;
	UCHAR				uchPad[1];
}	PTPMSG_MANAGEMENT_ERRSTA_TLV;
#define	GetPTPMSG_MANAGEMENT_ERRSTA_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).usManagementErrorId))	\
				+	(sizeof((a).usManagementId))		\
				+	(sizeof((a).stPathSequence.uchId));	\
			DEBUG_PRINT("GetPTPMSG_MANAGEMENT_ERRSTA_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_MANAGEMENT_ERRSTA_TLV));	\
		}
#define PTPMSG_MGTERSTTLV_TLVTYPE_SZ			2U
#define PTPMSG_MGTERSTTLV_TLVLENGTH_SZ			2U
#define PTPMSG_MGTERSTTLV_MANAGEMENTERRID_SZ	2U
#define PTPMSG_MGTERSTTLV_MANAGEMENTID_SZ		2U
#define PTPMSG_MGTERSTTLV_PTPTEXTDISP_SZ		1U
#define PTPMSG_MGTERSTTLV_PAD_SZ				1U


#endif
