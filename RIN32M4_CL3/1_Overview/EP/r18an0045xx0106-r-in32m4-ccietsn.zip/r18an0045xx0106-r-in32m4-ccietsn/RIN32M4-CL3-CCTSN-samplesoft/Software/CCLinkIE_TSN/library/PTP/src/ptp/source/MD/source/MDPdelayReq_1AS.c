/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "MDCommonSM.h"


#include "MDPdelayReq.h"
#include "MDPdelayReq_1AS.h"

#include "PortAnnounceInformationSM.h"
#include "PortStateSelectionSM.h"
#include "PortAnnounceInformationExtSM.h"

#include "ptp_tsn_Wrapper.h"

#include "PTP_GlobalData.h"
#include "MDLkDlyIntvalSet_1AS.h"

#define	D_FUNC		0
#define D_STATE		0
#define D_UPDATE	0
#define D_DBG		0

#if D_DBG
#include	"PTP_GlobalData.h"
#endif

#ifdef	OFFSET_DEBUG

#define	OFFSET_LOG_TYPE1
#define	OFFSET_LOG_TYPE2
#define	OFFSET_LOG_TYPE3
#define	OFFSET_LOG_TYPE4
#define	OFFSET_LOG_TYPE5
#define	OFFSET_LOG_TYPE6
#define	OFFSET_LOG_TYPE7
#define	OFFSET_LOG_TYPE8

extern	void	setFrameEgTimeStamp(TIMESTAMP* pstTimestamp, USHORT usPort, UCHAR uchFrType);

extern	USHORT	usCorrectiontLogCount;

#define	MAX_PTPOFSETLOG	64

typedef	struct	tagPTPOFSETLOG	{
	ULONG		ulType;
	TIMESTAMP	stPdlyRespEventIngressTimestamp;
	TIMESTAMP	stPdlyReqEventEgressTimestamp;
	TIMESTAMP	stPdlyRespMsgEgressTimestamp;
	TIMESTAMP	stPdlyReqMsgIngressTimestamp;
	DOUBLE		dbNeighborRateRatio;
	USCALEDNS	stNeighborPropDelay;
	USCALEDNS	stSyncReceiptCMTime;
	TIMESTAMP	stPreciseOriginTimestamp;
	SCALEDNS	stFollowUpCorrectionField;
	SCALEDNS	stSyncESubInSNs;
	DOUBLE		dbCMFrecRateCand;

	DOUBLE		dbRateRatio;

	UCHAR		uchDomainNumber;

	TIMESTAMP	stSyncEventEgressTimestamp;
	FRAC_NSEC64	stSyncCorrectionField;
	USHORT		usCorrectiontLogCount;
	USHORT		usPdelayReqSequenceId;
	USHORT		usPortNumber;
	TIMESTAMP	stSyncEventIngressTimestamp_Frun_TS;
	USHORT		usPtpDebugLogCount;
	UCHAR		uchStackCountSameClock;
	BOOL		blCumulativeRateRatioValid;
	CLOCKIDENTITY	stStackClockIdentity;
	BOOL		blClockRateValid;
}	PTPOFFSETLOG;

extern	PTPOFFSETLOG	stPtpOfsetLog[MAX_PTPOFSETLOG];

extern	USHORT	usPtpDebugLogCount;
extern	BOOL	blPtpOffsetUnder50Flag;
extern	BOOL	blPtpOffsetUpper500Flag;

#endif

#ifdef	PTP_USE_IEEE802_1
static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData );
static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData );
static BOOL checkAsCapable( PORTDATA* pstPortData );
static PORTDATA* findPortData( CLOCKDATA* pstClock, USHORT usPortNumber );
VOID updateAsCapableAll( PORTDATA* pstPdelayPort );

VOID (*const MDPdelayReq_1AS_Matrix[DMDPDRQ_STATUS_MAX][DMDPDRQ_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDPdelayReq_01_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS},
	{&MDPdelayReq_01_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_03_1AS,&MDPdelayReq_04_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_04_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_03_1AS,&MDPdelayReq_04_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_05_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_06_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_07_1AS,&MDPdelayReq_08_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_06_1AS,&MDPdelayReq_00_1AS},
	{&MDPdelayReq_02_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_NP_1AS,&MDPdelayReq_04_1AS,&MDPdelayReq_00_1AS}
};
static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData )
{
	CMLDSPORT_1AS_DS *pstCmldsPortDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPort_1AS_DS;

	return pstCmldsPortDS;
}

static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData )
{
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatisticsDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortStatisticsDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPortStatistics_1AS_DS;

	return pstCmldsPortStatisticsDS;
}
static BOOL checkAsCapable( PORTDATA* pstPortData )
{
	CMLDSPORT_1AS_DS* pstCmldsPortDS;
	
	pstCmldsPortDS = GetCmldsPortDS( pstPortData );

	if ( pstCmldsPortDS->blAsCapableAcrossDomains == FALSE )
	{
		return FALSE;
	}
	if (( pstPortData->stPortMD_GD.blPdelayFlag == FALSE ) &&
			(pstPortData->pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag == TRUE))
	{
		if ( pstPortData->stPort_GD.blNeighborGptpCapable == FALSE )
		{
			return FALSE;
		}
	}
	return TRUE;
}
VOID updateAsCapable( PORTDATA* pstPortData )
{
	USHORT  usPtpEvent[2]={ PTP_EV_CLOSE, PTP_EV_BEGIN };
	BOOL    blAsCapable;
	BMC_GD* pstBMC_GD;

	blAsCapable = checkAsCapable( pstPortData );

    ptp_dbg_msg( D_STATE, 
    			 ("%s::AsCapable state =  %d -> %d\n", 
    			  "updateAsCapable",
    			  pstPortData->stPort_1AS_DS.blAsCapable,
    			  blAsCapable) );
	
	if( pstPortData->stPort_1AS_DS.blAsCapable == blAsCapable )
	{
		return ;
	}
	pstPortData->stPort_1AS_DS.blAsCapable = blAsCapable;

	pstBMC_GD = &pstPortData->pstClockData->stBMC_GD;

#ifdef	PTP_USE_BMCA
	if ( pstBMC_GD->blExternalPortConfiguration == FALSE )
	{
		portAnnounceInformationSM( usPtpEvent[blAsCapable], pstPortData );
	}
	else
#endif
	{
		portAnnounceInformationExtSM( usPtpEvent[blAsCapable], pstPortData );
	}

	if ( blAsCapable == TRUE )
	{
		pstPortData->stPort_GD.ulAsCapableChangeONCnt ++;
	}
	else
	{
		pstPortData->stPort_GD.ulAsCapableChangeOFFCnt ++;

#ifdef	PTP_USE_BMCA
		if ( pstBMC_GD->blExternalPortConfiguration == FALSE )
		{
			pstPortData->stPortBMC_GD.enInfoIs = DISABLED;
			
			pstBMC_GD->blReselect[pstPortData->stPortDS.stPortIdentity.usPortNumber] = TRUE;
			pstBMC_GD->blSelected[pstPortData->stPortDS.stPortIdentity.usPortNumber] = FALSE;
			
			portStateSelectionSM( PTP_EV_RESELECT_PORT, pstPortData );
		}
#endif
	}

	return;
}

static PORTDATA* findPortData( CLOCKDATA* pstClock, USHORT usPortNumber )
{
	PORTDATA*  pstPort;
	
	if ( pstClock == NULL )
	{
		return NULL;
	}
	for ( pstPort  = pstClock->pstPortData;
		  pstPort != NULL;
		  pstPort  = pstPort->pstNextPortDataPtr )
	{
		if ( pstPort->stPortDS.stPortIdentity.usPortNumber == usPortNumber )
		{
			break;
		}
	}
	return pstPort;
}
VOID updateAsCapableAll( PORTDATA* pstPdelayPort )
{
	
	CLOCKDATA* pstClock;
	PORTDATA*  pstPort;
	
	ptp_dbg_msg(D_FUNC, ("updateAsCapableAll::+\n"));

	for ( pstClock  = gpstClockDataHPtr;
		  pstClock != NULL;
		  pstClock  = pstClock->pstNextClockDataPtr )
	{
		pstPort = findPortData( pstClock, pstPdelayPort->stPortDS.stPortIdentity.usPortNumber );
		if ( pstPort != NULL )
		{
			ptp_dbg_msg( D_UPDATE, 
			            ("%s::call updateAsCapable.  domain, port = [%d,%d]\n", 
			             "updateAsCapableAll",
					     pstClock->stDefaultDS.uchDomainNumber,
					     pstPort->stPortDS.stPortIdentity.usPortNumber) );
			updateAsCapable( pstPort );
		}
	}

	ptp_dbg_msg(D_FUNC, ("updateAsCapableAll::-\n"));

	return ;
}

VOID MDPdelayReq_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYREQ_EV	enEvt = MDPDRQ_E_EVENT_MAX;
	MDPDELAYREQ_ST	enSts = MDPDRQ_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82080001);

	enEvt = GetMDPdelayReqEvent(usEvent, pstPort);

	enSts = GetMDPdelayReqStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDPdelayReq_1AS          ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDPDRQ_STATUS_MAX) && (enEvt != MDPDRQ_E_EVENT_MAX))
	{
		(*MDPdelayReq_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDPdelayReqStatus(pstPort);
	printf ("<END  > [%02d]MDPdelayReq_1AS          ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDPdelayReq_00_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	CMLDSPORT_1AS_DS*			pstCmldsPortDs;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDPdelayReq_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstCmldsPortDs = GetCmldsPortDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);
	(VOID)MDPdelayTimeStop( pstGbl, pstPort, pstCmldsPortDs );

	MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_NONE, pstPort);

	ptp_dbg_msg( D_DBG,  ("uchMaxStackCount = [%d]\n", pstPort->stPort_GD.pstPdlyIntStackMan->uchMaxStackCount) );
	ptp_dbg_msg( D_FUNC, ("MDPdelayReq_00_1AS::-\n") );

	return;
}

VOID MDPdelayReq_01_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	BOOL			blRet = FALSE;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	blRet = MDPdlyReq_IntSndPDReq_1AS(pstGbl, pstPort);
	if (blRet)
	{
		MDPdelayTimeStart(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_INITIAL_SEND_PDREQ, pstPort);
	}
	else
	{
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
	}

	return;
}

VOID MDPdelayReq_02_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	BOOL			blRet;
	CMLDSPORT_1AS_DS*	pstCmldsPortDs;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_02_1AS::+\n"));

	pstCmldsPortDs = GetCmldsPortDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	(VOID)MDPdelayTimeStop( pstGbl, pstPort, pstCmldsPortDs );

	blRet = MDPdlyReq_IntSndPDReq_1AS(pstGbl, pstPort);
	if (blRet)
	{
		MDPdelayTimeStart(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_INITIAL_SEND_PDREQ, pstPort);
	}
	else
	{
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
	}

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_02_1AS::-\n"));

	return;
}

VOID MDPdelayReq_03_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_8200250C);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
		return;
	}

#ifdef	OFFSET_DEBUG
	setFrameEgTimeStamp(&pstGbl->stEgMDTimestampReceive, pstPort->stPortDS.stPortIdentity.usPortNumber, (UCHAR)PTPM_MSGTYPE_PDELAY_REQ);
#endif

	if (SetMDPdlyReqEvEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_8200250B);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
		return;
	}

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE5
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 5;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp = pstPort->stPortMD_GD.stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPortNumber                  = pstPort->stPortDS.stPortIdentity.usPortNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				= pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPdelayReqSequenceId			= pstPort->stMDPReqSM_GD.stTxPdelayReq.stTxPdelayReq_1AS.stHeader.usSequenceId;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			= usPtpDebugLogCount;
			usPtpDebugLogCount++;
		}
#endif
#endif

	MDPdlyReq_WtFrPDResp_1AS(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDRESP, pstPort);
	return;
}

VOID MDPdelayReq_04_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	MDPdlyReq_SndPDReq_1AS(pstGbl, pstPort);
	MDPdelayTimeStart(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_SEND_PDELAY_REQ, pstPort);
	return;
}

VOID MDPdelayReq_05_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)ulRxPdelayResponseCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseCount));

	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayResp_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001608);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1AS::-\n"));

		return;
	}

	IncMDPDlyReqRxPDlyRespCount( pstCmldsPortStatDs );

	if (SetMDPdlyRespEvIngresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_8200160B);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1AS::-\n"));

		return;
	}

	if (JugMDPdlyReq_PDResp_1AS(pstGbl))
	{
		SetMDPdlyReqMgIngresTmstmp_1AS(pstGbl, pstPort);
		MDPdlyReq_WtFrPDRpFollowUp_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDRESP_FOLLOWUP, pstPort);

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE6
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 6;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp   = pstPort->stPortMD_GD.stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp    = pstPort->stPortMD_GD.stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPort->stPortMD_GD.stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPortNumber                    = pstPort->stPortDS.stPortIdentity.usPortNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				  = pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPdelayReqSequenceId			  = pstPort->stMDPReqSM_GD.pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.usSequenceId;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			= usPtpDebugLogCount;
			tsn_Wrapper_MemCpy(&stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stStackClockIdentity,
				&pstPort->stMDPReqSM_GD.pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity ,sizeof(CLOCKIDENTITY));
			usPtpDebugLogCount++;
		}
#endif
#endif

	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001600);
		MDPdlyReq_Reset_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);
	}

	ptp_dbg_msg(D_DBG, ("(A)ulRxPdelayResponseCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseCount));
	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1AS::-\n"));

	return;
}

VOID MDPdelayReq_06_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_06_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("--domain=[%d] port=[%d]\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber, pstPort->stPortDS.stPortIdentity.usPortNumber));
	ptp_dbg_msg(D_DBG , ("(B)ulRxPTPPacketDiscardCount=[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPTPPacketDiscardCount));

	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	MDPdlyReq_Reset_1AS(pstGbl, pstPort);

	IncMDPDlyReqRxPTPPcktDscrdCount( pstCmldsPortStatDs );

	MDPdlyReq_SndPDReq_1AS(pstGbl, pstPort);
	MDPdelayTimeStart(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_SEND_PDELAY_REQ, pstPort);

	ptp_dbg_msg(D_DBG,  ("(A)ulRxPTPPacketDiscardCount=[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPTPPacketDiscardCount));
	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_06_1AS::+\n"));

	return;
}

VOID MDPdelayReq_07_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_07_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("--domain=[%d] port=[%d]\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber, pstPort->stPortDS.stPortIdentity.usPortNumber));
	ptp_dbg_msg(D_DBG , ("(B)ulRxPdelayResponseCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseCount));

	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayResp_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001608);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_07_1AS::-\n"));

		return;
	}

	IncMDPDlyReqRxPDlyRespCount( pstCmldsPortStatDs );

	if (JugMDPdlyReq_PDResp_1AS(pstGbl))
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001700);
		MDPdlyReq_Reset_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001600);
	}

	ptp_dbg_msg(D_DBG, ("(A)ulRxPdelayResponseCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseCount));
	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_07_1AS::-\n"));

	return;
}

VOID MDPdelayReq_08_1AS(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("--domain=[%d] port=[%d]\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber, pstPort->stPortDS.stPortIdentity.usPortNumber));
	ptp_dbg_msg(D_DBG , ("(B)ulRxPdelayResponseFollowUpCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseFollowUpCount));

	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayRespFollowUp_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001708);
		MDPdlyReq_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1AS::-\n"));

		return;
	}

	IncMDPDlyReqRxPDRpFollowUpCount( pstCmldsPortStatDs );

	if (JugMDPdlyReq_PDRespFollowUp_1AS(pstGbl))
	{
		SetMDPdlyRespMgEgresTmstmp_1AS(pstGbl, pstPort);

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE7
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 7;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp   = pstPort->stPortMD_GD.stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp    = pstPort->stPortMD_GD.stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPort->stPortMD_GD.stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespMsgEgressTimestamp    = pstPort->stPortMD_GD.stPdlyRespMsgEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPortNumber                    = pstPort->stPortDS.stPortIdentity.usPortNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				  = pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPdelayReqSequenceId			  = pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS.stHeader.usSequenceId;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			  = usPtpDebugLogCount;
			tsn_Wrapper_MemCpy(&stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stStackClockIdentity,
				&pstPort->stPort_GD.pstPdlyIntStackMan->stStackClockIdentity, sizeof(CLOCKIDENTITY));
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchStackCountSameClock = pstPort->stPort_GD.pstPdlyIntStackMan->uchStackCountSameClock;

			usPtpDebugLogCount++;
		}
#endif
#endif

		MDPdlyReq_WtFrPDlyInterval_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDELAY_INTV_TM, pstPort);

	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001600);
		MDPdlyReq_Reset_1AS(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);
	}

	ptp_dbg_msg(D_DBG , ("(A)ulRxPdelayResponseFollowUpCount[%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulRxPdelayResponseFollowUpCount));
	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1AS::-\n"));

	return;
}

VOID MDPdelayReq_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82000007);
	return;
}

BOOL MDPdlyReq_NotEnable_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_NotEnable_1AS::+\n"));

	pstSmGbl->blRcvdPdelayResp = FALSE;
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	pstPort->stPort_GD.pstPdlyIntStackMan->uchMaxStackCount = 0U;


	ptp_dbg_msg(D_DBG , ("uchMaxStackCount = [%d]\n", pstPort->stPort_GD.pstPdlyIntStackMan->uchMaxStackCount));
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_NotEnable_1AS::-\n"));

	return TRUE;
}

BOOL MDPdlyReq_IntSndPDReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*			pstCmldsPortDS;
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	PORT_1AS_DS*		pstPort1ASDS	= &pstPort->stPort_1AS_DS;
	PORT_GD*			pstPortGD		= &pstPort->stPort_GD;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)ulTxPdelayRequestCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));

	pstCmldsPortDS     = GetCmldsPortDS( pstPort );
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstSmGbl->blInitPdelayRespReceived = FALSE;

	pstSmGbl->blRcvdPdelayResp = FALSE;
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	pstPortGD->dbNeighborRateRatio = 1.0;
	pstCmldsPortDS->lNeighborRateRatio = 0;

	if (pstCmldsPortDS->blCmldsPortEnabled == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}

	if (pstPort->stPort_GD.blPdelayExecFlag == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}
	pstSmGbl->usPdelayReqSequenceId = (USHORT)tsn_Wrapper_Rand();

#ifndef PTP_USE_SIGNALING
	lnkDlyIntSet_1AS(pstPort);
#endif

	if (SetPdelayReq_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayReq_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyReqTxPDlyReqCount( pstCmldsPortStatDs );

	pstSmGbl->usLostResponses = 0;
	pstSmGbl->usDelectedFaults = 0;

	pstCmldsPortDS->blIsMeasuringDelay = FALSE;
	pstCmldsPortDS->blAsCapableAcrossDomains = FALSE;

	updateAsCapableAll( pstPort );

	ptp_dbg_msg(D_DBG, ("lNeighborRateRatio        = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.lNeighborRateRatio));
	ptp_dbg_msg(D_DBG, ("blAsCapableAcrossDomains  = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blAsCapableAcrossDomains));
	ptp_dbg_msg(D_DBG, ("(A)ulTxPdelayRequestCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));
	ptp_dbg_msg(D_DBG, ("blAsCapable              = [%d]\n", pstPort->stPort_1AS_DS.blAsCapable));
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1AS::-\n"));

	return TRUE;
}

BOOL MDPdlyReq_Reset_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*			pstCmldsPortDS;
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;

	PORT_1AS_DS*		pstPort1ASDS	= &pstPort->stPort_1AS_DS;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_Reset_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)usLostResponses               = (%d)+\n", pstSmGbl->usLostResponses));
	ptp_dbg_msg(D_DBG , ("(B)ulPdelayAllwLostRespExcdCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulPdelayAllwLostRespExcdCount));
	ptp_dbg_msg(D_DBG , ("(B)blAsCapableAcrossDomains      = [%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blAsCapableAcrossDomains));

	pstCmldsPortDS     = GetCmldsPortDS( pstPort );
	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstSmGbl->blInitPdelayRespReceived = FALSE;

	pstSmGbl->blRcvdPdelayResp = FALSE;

	if( pstSmGbl->usLostResponses <= pstCmldsPortDS->usAllowedLostResponses)
	{
		pstSmGbl->usLostResponses++;
		ptp_dbg_msg(D_DBG, ("pstSmGbl->usLostResponses = (%d)+\n", pstSmGbl->usLostResponses));
	}
	else
	{
		ptp_dbg_msg(D_DBG, ("pstSmGbl->usLostResponses > pstCmldsPortDS->usAllowedLostResponses::+\n"));

		pstCmldsPortDS->blIsMeasuringDelay = FALSE;
		pstCmldsPortDS->blAsCapableAcrossDomains = FALSE;
		IncMDPDlyReqLostRespExcdCount( pstCmldsPortStatDs );
	}

	updateAsCapableAll( pstPort );

	ptp_dbg_msg(D_DBG , ("(A)usLostResponses               = (%d)+\n", pstSmGbl->usLostResponses));
	ptp_dbg_msg(D_DBG , ("(A)ulPdelayAllwLostRespExcdCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulPdelayAllwLostRespExcdCount));
	ptp_dbg_msg(D_DBG , ("(A)blAsCapableAcrossDomains      = [%d]\n", gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blAsCapableAcrossDomains));
	ptp_dbg_msg(D_DBG , ("   blIsMeasuringDelay            = [%d]\n",
	gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blIsMeasuringDelay));
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_Reset_1AS::-\n"));

	return TRUE;
}

BOOL MDPdlyReq_SndPDReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)ulTxPdelayRequestCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));

	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstSmGbl->usPdelayReqSequenceId++;

	if (SetPdelayReq_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("(A)ulTxPdelayRequestCount = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1AS::-\n"));
		return FALSE;
	}
	if (TxPdelayReq_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("(A)ulTxPdelayRequestCount = [%d]\n"
			, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1AS::-\n"));
		return FALSE;
	}

	IncMDPDlyReqTxPDlyReqCount( pstCmldsPortStatDs );

	ptp_dbg_msg(D_DBG , ("(A)ulTxPdelayRequestCount = [%d]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPortStatistics_1AS_DS.ulTxPdelayRequestCount));
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1AS::-\n"));
	return TRUE;
}

BOOL MDPdlyReq_WtFrPDResp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	return TRUE;
}

BOOL MDPdlyReq_WtFrPDRpFollowUp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blInitPdelayRespReceived = TRUE;

	pstSmGbl->blRcvdPdelayResp = FALSE;
	return TRUE;
}

BOOL MDPdlyReq_WtFrPDlyInterval_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*		pstCmldsPortDS;

	PORT_GD*				pstPortGD		= &pstPort->stPort_GD;
	PORT_DS*				pstPortDS		= &pstPort->stPortDS;
	PORT_1AS_DS*			pstPort1ASDS	= &pstPort->stPort_1AS_DS;
	CHAR					chCmpAB		= 0;

	BOOL					blRet			= FALSE;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_WtFrPDlyInterval_1AS::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)usDelectedFaults                             = (%d)\n", pstSmGbl->usDelectedFaults));
	ptp_dbg_msg(D_DBG , ("(B)pstCmldsPortDS->usAllowedFaults              = (%d)\n",
		gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.usAllowedFaults));
	ptp_dbg_msg(D_DBG , ("(B)blAsCapableAcrossDomains                     = (%d)\n",
		gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blAsCapableAcrossDomains
		));
	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	pstSmGbl->blInitPdelayRespReceived = TRUE;

	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;

	pstSmGbl->usLostResponses = 0;


	if (pstPortGD->blComputeNeighborRateRatio)
	{
		pstSmGbl->blNeighborRateRatioValid = computeMDPdelayRateRatio_1AS(pstSmGbl, pstPort);
	}
	if (pstPortGD->blComputeNeighborPropDelay)
	{
		blRet = computeMDPdelayPropTime_1AS(pstSmGbl, pstPort);
	}
	pstCmldsPortDS->blIsMeasuringDelay = FALSE;

	pstCmldsPortDS->stNeighborPropDelay = pstPort->stPort_GD.stNeighborPropDelay;


	if (!pstPortGD->blComputeNeighborPropDelay)
	{
		chCmpAB = ptpCompUSNs_USNs(&pstCmldsPortDS->stNeighborPropDelay, &pstCmldsPortDS->stNeighborPropDelayThresh);
		if ((chCmpAB == COMP_EQUAL) || (chCmpAB == COMP_A_LESS))
		{
			blRet = TRUE;
		}
	}
	if (blRet &&
		(pstSmGbl->blNeighborRateRatioValid) &&
		(tsn_Wrapper_MemCmp (&pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId
			,&pstPortDS->stPortIdentity.stClockIdentity.uchId, sizeof(pstPortDS->stPortIdentity.stClockIdentity.uchId)))
		)
	{
		pstCmldsPortDS->blAsCapableAcrossDomains = TRUE;
		pstSmGbl->usDelectedFaults = 0;
	}
	else if ( tsn_Wrapper_MemCmp( &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId, 
	                              &pstPortDS->stPortIdentity.stClockIdentity.uchId, 
	                              sizeof(pstPortDS->stPortIdentity.stClockIdentity.uchId)) != 0 )
	{
		pstCmldsPortDS->blAsCapableAcrossDomains = FALSE;
		pstCmldsPortDS->blIsMeasuringDelay = FALSE;
		pstSmGbl->usDelectedFaults = 0U;
	}
	else if(pstSmGbl->usDelectedFaults <= pstCmldsPortDS->usAllowedFaults)
	{
		pstSmGbl->usDelectedFaults++;
	}
	else
	{
		pstCmldsPortDS->blAsCapableAcrossDomains = FALSE;
		pstCmldsPortDS->blIsMeasuringDelay = FALSE;
		pstSmGbl->usDelectedFaults = 0U;
	}
	updateAsCapableAll(pstPort);
	ptp_dbg_msg(D_DBG, ("(A)pstSmGbl->blNeighborRateRatioValid          = [%d]\n", pstSmGbl->blNeighborRateRatioValid));
	ptp_dbg_msg(D_DBG, ("(A)stHeader.stSrcPortIdentity.stClockIdentity  = [%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x]\n"
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[0]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[1]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[2]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[3]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[4]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[5]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[6]
		, pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS.stHeader.stSrcPortIdentity.stClockIdentity.uchId[7]
	) );
	ptp_dbg_msg(D_DBG, ("(A)pstPortDS->stPortIdentity.stClockIdentity   = [%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x]\n"
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[0]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[1]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[2]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[3]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[4]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[5]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[6]
		, pstPortDS->stPortIdentity.stClockIdentity.uchId[7]
		) );
	ptp_dbg_msg(D_DBG, ("(A)pstPortGD->blComputeNeighborPropDelay        = [%d]\n", pstPort->stPort_GD.blComputeNeighborPropDelay));
	ptp_dbg_msg(D_DBG, ("(A)stCmldsPort_1AS_DS.stNeighborPropDelayThresh = [%04x:%08x:%08x:%04x]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelayThresh.usNsec_msb
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelayThresh.ulNsec_2nd
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelayThresh.ulNsec_lsb
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelayThresh.usFrcNsec
		));
	ptp_dbg_msg(D_DBG , ("(A)blRet                                       = [%d]\n", blRet));
	ptp_dbg_msg(D_DBG , ("(A)blIsMeasuringDelay                          = [%d]\n",
		gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blIsMeasuringDelay));
	ptp_dbg_msg(D_DBG , ("(A)stCmldsPort_1AS_DS.stNeighborPropDelay      = [%04x:%08x:%08x:%04x]\n"
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelay.usNsec_msb
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelay.ulNsec_2nd
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelay.ulNsec_lsb
		, gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.stNeighborPropDelay.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("(A)stPort_GD.stNeighborPropDelay                = [%04x:%08x:%08x:%04x]\n"
		, pstPort->stPort_GD.stNeighborPropDelay.usNsec_msb
		, pstPort->stPort_GD.stNeighborPropDelay.ulNsec_2nd
		, pstPort->stPort_GD.stNeighborPropDelay.ulNsec_lsb
		, pstPort->stPort_GD.stNeighborPropDelay.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("(A)usDelectedFaults                             = (%d)\n", pstSmGbl->usDelectedFaults));
	ptp_dbg_msg(D_DBG, ("(A)blAsCapableAcrossDomains                     = (%d)\n",
		gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.blAsCapableAcrossDomains
	) );
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_WtFrPDlyInterval_1AS::-\n"));

	return TRUE;
}

BOOL JugMDPdlyReq_PDResp_1AS(MDPREQSM_GD* pstSmGbl)
{
	PTPMSG_PDELAY_RESP_1AS*	pstMsgPdelayResp = &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS;
	PTPMSG_PDELAY_REQ_1AS*	pstMsgPdelayReq = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1AS;
	if (pstMsgPdelayResp->stHeader.usSequenceId != pstMsgPdelayReq->stHeader.usSequenceId)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgPdelayResp->stReqPortIdentity.stClockIdentity,
		&pstMsgPdelayReq->stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgPdelayResp->stReqPortIdentity.usPortNumber
		!= pstMsgPdelayReq->stHeader.stSrcPortIdentity.usPortNumber)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL JugMDPdlyReq_PDRespFollowUp_1AS(MDPREQSM_GD* pstSmGbl)
{
	PTPMSG_PDRESP_FOLLOWUP_1AS*	pstMsgPdelayRespFollowUp
											= &pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS;
	PTPMSG_PDELAY_RESP_1AS*		pstMsgPdelayResp
											= &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS;
	PTPMSG_PDELAY_REQ_1AS*	pstMsgPdelayReq = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1AS;

	if (pstMsgPdelayRespFollowUp->stHeader.usSequenceId != pstMsgPdelayReq->stHeader.usSequenceId)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgPdelayRespFollowUp->stHeader.stSrcPortIdentity.stClockIdentity,
		&pstMsgPdelayResp->stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgPdelayRespFollowUp->stHeader.stSrcPortIdentity.usPortNumber
		!= pstMsgPdelayResp->stHeader.stSrcPortIdentity.usPortNumber)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ConMDPdelayResp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayResp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001609);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayResp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_8200160A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPdlyResp_1AS,
		&pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS, sizeof(pstPortMD->stConPdlyResp_1AS));

	return TRUE;
}

BOOL ConMDPdelayRespFollowUp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayRespFollowUp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82001709);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayRespFollowUp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_8200170A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPDRespFlwUp_1AS,
		&pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS, sizeof(pstPortMD->stConPDRespFlwUp_1AS));
	return TRUE;
}

VOID SetMDPdlyReqMgIngresTmstmp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_PDELAY_RESP_1AS*	pstMsgPdelayResp
		= &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1AS;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqMsgIngressTimestamp,
		&pstMsgPdelayResp->stReqRcptTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqMsgIngressCorrection,
		&pstMsgPdelayResp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

VOID SetMDPdlyRespMgEgresTmstmp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_PDRESP_FOLLOWUP_1AS*	pstMsgPdelayRespFollowUp
		= &pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespMsgEgressTimestamp,
		&pstMsgPdelayRespFollowUp->stRespOrgnTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespMsgEgressCorrection,
		&pstMsgPdelayRespFollowUp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL SetPdelayReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_DS*				pstPortDS		= &pstPort->stPortDS;
	CMLDSPORT_1AS_DS*		pstCmldsPortDS;

	PTPMSG_PDELAY_REQ_1AS*	pstMsg = NULL;

	ptp_dbg_msg(D_FUNC, ("SetPdelayReq_1AS::+\n"));

	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	pstMsg = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1AS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));

	if (!(pstPort->stPortMD_GD.blPdelayFlag))
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_2 );
	}
	else
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	}
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDELAY_REQ );
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	pstMsg->stHeader.uchDomainNumber	= PTPM_DOMAIN_NUMBER_0;
	pstMsg->stHeader.usMegLength		= 0U;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;

	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_PDELAY_REQ,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstSmGbl->usPdelayReqSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_REQ;
	pstMsg->stHeader.chLogMsgInterVal	= pstCmldsPortDS->chCurrentLogPdelayReqInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemSet(&pstMsg->uchReserved1, 0, sizeof(pstMsg->uchReserved1));
	tsn_Wrapper_MemSet(&pstMsg->uchReserved2, 0, sizeof(pstMsg->uchReserved2));
	GetPTPMSG_PDELAY_REQ_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	ptp_dbg_msg(D_DBG , ("stHeader.chLogMsgInterVal                                  = (%d)\n", pstMsg->stHeader.chLogMsgInterVal));
	ptp_dbg_msg(D_DBG , ("stCmldsPortStatistics_1AS_DS.chCurrentLogPdelayReqInterval = (%d)\n", 
		gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS.chCurrentLogPdelayReqInterval));
	ptp_dbg_msg(D_FUNC, ("SetPdelayReq_1AS::-\n"));

	return TRUE;
}

BOOL TxPdelayReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDPdelayReq;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayReq,
		pstSmGbl->stTxPdelayReq.stTxPdelayReq_1AS.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_82002508);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL computeMDPdelayRateRatio_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD*			pstPortGD;
	CMLDSPORT_1AS_DS*	pstCmldsPortDS;

	DOUBLE		dbRatio = 1.0;
	BOOL		blRet	= FALSE;

	ptp_dbg_msg(D_FUNC, ("computeMDPdelayRateRatio_1AS::+\n"));

	pstPortGD	   = &pstPort->stPort_GD;
	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	if ( tsn_Wrapper_MemCmp(&pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS.stHeader.stSrcPortIdentity.stClockIdentity,
				&pstPortGD->pstPdlyIntStackMan->stStackClockIdentity, sizeof(CLOCKIDENTITY)) )
	{
		pstPortGD->pstPdlyIntStackMan->uchStackCountSameClock = 0U;
		pstPortGD->pstPdlyIntStackMan->uchMaxStackCount = 0U;

		tsn_Wrapper_MemCpy(&pstPortGD->pstPdlyIntStackMan->stStackClockIdentity,
			&pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS.stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE8
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 8;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp   = pstPort->stPortMD_GD.stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp    = pstPort->stPortMD_GD.stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPort->stPortMD_GD.stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespMsgEgressTimestamp    = pstPort->stPortMD_GD.stPdlyRespMsgEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPortNumber                    = pstPort->stPortDS.stPortIdentity.usPortNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				  = pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPdelayReqSequenceId			  = pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1AS.stHeader.usSequenceId;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			  = usPtpDebugLogCount;
			tsn_Wrapper_MemCpy(&stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stStackClockIdentity,
				&pstPort->stPort_GD.pstPdlyIntStackMan->stStackClockIdentity, sizeof(CLOCKIDENTITY));
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchStackCountSameClock = pstPort->stPort_GD.pstPdlyIntStackMan->uchStackCountSameClock;
			usPtpDebugLogCount++;
		}
#endif
#endif

	}

	if (pstPortGD->pstPdlyIntStackMan->uchStackCountSameClock < pstPort->pstClockData->stClock_GD.uchRateCalDatNum)
	{
		pstPortGD->pstPdlyIntStackMan->uchStackCountSameClock++;
	}

	if ( pstPortGD->pstPdlyIntStackMan->uchMaxStackCount == 0U )
	{
		pstPortGD->pstPdlyIntStackMan->uchStackCount   = 0U;
		pstPortGD->pstPdlyIntStackMan->uchCompareCount = 0U;

		SetCmptMDPdlyRatioStack_1AS( pstPortGD->pstPdlyIntStackMan, pstPort );

		pstPortGD->pstPdlyIntStackMan->uchMaxStackCount += 1U;
		blRet = TRUE;
	}
	else if ( pstPortGD->pstPdlyIntStackMan->uchMaxStackCount <= (UCHAR)(pstPort->pstClockData->stClock_GD.uchRateCalDatNum - 1U) )
	{
		pstPortGD->pstPdlyIntStackMan->uchStackCount += 1U;
		pstPortGD->pstPdlyIntStackMan->uchCompareCount = 0U;

		SetCmptMDPdlyRatioStack_1AS( pstPortGD->pstPdlyIntStackMan, pstPort );

		pstPortGD->pstPdlyIntStackMan->uchMaxStackCount += 1U;
		blRet = CalMDPdlyRateRatio_1AS( pstPortGD->pstPdlyIntStackMan, pstPort, &dbRatio );
	}
	else
	{
		pstPortGD->pstPdlyIntStackMan->uchStackCount = pstPortGD->pstPdlyIntStackMan->uchCompareCount;

		SetCmptMDPdlyRatioStack_1AS( pstPortGD->pstPdlyIntStackMan, pstPort );

		if ( pstPortGD->pstPdlyIntStackMan->uchCompareCount >= (UCHAR)(pstPort->pstClockData->stClock_GD.uchRateCalDatNum - 1U) )
		{
			pstPortGD->pstPdlyIntStackMan->uchCompareCount = 0U;
		}
		else
		{
			pstPortGD->pstPdlyIntStackMan->uchCompareCount += 1U;
		}
		blRet = CalMDPdlyRateRatio_1AS( pstPortGD->pstPdlyIntStackMan, pstPort, &dbRatio );
	}

	if (blRet)
	{
#if 1
		if ((dbRatio > DBCONST_RATE_MIN) &&
			(dbRatio < DBCONST_RATE_MAX))
		{
#endif
			pstPortGD->dbNeighborRateRatio = dbRatio;
			pstCmldsPortDS->lNeighborRateRatio = (LONG)((pstPortGD->dbNeighborRateRatio - DBCONST1_0) * DBCONST2_41);
		}
	}
	ptp_dbg_msg(D_DBG,  ("dbRatio        =[%f]\n", dbRatio));
	ptp_dbg_msg(D_FUNC, ("computeMDPdelayRateRatio_1AS::-\n"));

	return blRet;
}

VOID SetCmptMDPdlyRatioStack_1AS( MDPDLYREQSM_STACK_MANAGE*	pstPdlyIntStackMan, 
								  PORTDATA*                 pstPort )
{
	MDPDLYREQSM_STACK *pstRatioStack;

	EXTENDEDTIMESTAMP	stA_ETInt;



	{
		BOOL	blRet;

		blRet = ptpAddTS_TInt(
			&pstPort->stPortMD_GD.stConPDRespFlwUp_1AS.stRespOrgnTimestamp,
			&pstPort->stPortMD_GD.stConPDRespFlwUp_1AS.stHeader.stCorrectionField,
			&stA_ETInt);
		if (blRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1AS, PTP_LOGVE_OVERFLOW);
		}
	}

	pstRatioStack = &pstPdlyIntStackMan->stCmptMDPdlyRatioStack[ pstPdlyIntStackMan->uchStackCount ];
	
	(VOID)ptpConvETS_USNs( &stA_ETInt, &pstRatioStack->stCrrctEvTimestamp );

	(VOID)ptpConvTS_USNs( &pstPort->stPortMD_GD.stPdlyRespEventIngressTimestamp, 
	                	  &pstRatioStack->stIngressTimestamp );

	return;
}

#endif

BOOL CalMDPdlyRateRatio_1AS( MDPDLYREQSM_STACK_MANAGE*	pstPdlyIntStackMan, 
							 PORTDATA*                  pstPort, 
							 DOUBLE*                    dbRateRatio )
{
	SCALEDNS			stA_SNs	={0};
	SCALEDNS			stB_SNs	={0};
	BOOL				blRet = FALSE;

	ptp_dbg_msg(D_FUNC, ("CalMDPdlyRateRatio_1AS::+\n"));


	(VOID)ptpSubUSNs_USNs( &pstPdlyIntStackMan->stCmptMDPdlyRatioStack[pstPdlyIntStackMan->uchStackCount].stCrrctEvTimestamp,
						   &pstPdlyIntStackMan->stCmptMDPdlyRatioStack[pstPdlyIntStackMan->uchCompareCount].stCrrctEvTimestamp,
						   &stA_SNs);
	(VOID)ptpSubUSNs_USNs( &pstPdlyIntStackMan->stCmptMDPdlyRatioStack[pstPdlyIntStackMan->uchStackCount].stIngressTimestamp,
						   &pstPdlyIntStackMan->stCmptMDPdlyRatioStack[pstPdlyIntStackMan->uchCompareCount].stIngressTimestamp,
						   &stB_SNs );

	blRet = ptpDivSNs_SNs(&stA_SNs, &stB_SNs, dbRateRatio);

	ptp_dbg_msg(D_FUNC, ("CalMDPdlyRateRatio_1AS::-\n"));

	return blRet;
}

#ifdef	PTP_USE_IEEE802_1

BOOL computeMDPdelayPropTime_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD*	pstPortGD	= &pstPort->stPort_GD;
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;
	BOOL		blRet	= FALSE;
	SCALEDNS	stA_Ns;
	SCALEDNS	stB_Ns;
	SCALEDNS	stC_Ns;
	SCALEDNS	stD_Ns;
	SCALEDNS	stE_Ns;
	USCALEDNS	stTemp_UNs;
	USCALEDNS	stTemp_UNs2;
	TIME_INTERVAL	stF_TInt;
	TIME_INTERVAL	stG_TInt;
#if 1
	CHAR					chCmpAB		= 0;
#endif
	CMLDSPORT_1AS_DS*	pstCmldsPortDs;

	ptp_dbg_msg(D_FUNC, ("computeMDPdelayPropTime_1AS::�{\n"));

	pstCmldsPortDs = GetCmldsPortDS( pstPort );
	ptpSubTS_TS(
		&pstPortMD->stPdlyRespEventIngressTimestamp,
		&pstPortMD->stPdlyReqEventEgressTimestamp,
		&stA_Ns);
	ptpSubTS_TS(
		&pstPortMD->stPdlyRespMsgEgressTimestamp,
		&pstPortMD->stPdlyReqMsgIngressTimestamp,
		&stB_Ns);
	ptpMultSNs_Doub(&stA_Ns, pstPortGD->dbNeighborRateRatio, &stD_Ns);
#if 1
	chCmpAB = ptpCompSNs_SNs(&stD_Ns, &stB_Ns);
	if (chCmpAB == COMP_A_LESS)
	{

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE4
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 4;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPortMD->stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp = pstPortMD->stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespMsgEgressTimestamp 	= pstPortMD->stPdlyRespMsgEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp 	= pstPortMD->stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbNeighborRateRatio			= pstPortGD->dbNeighborRateRatio;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				= pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			= usPtpDebugLogCount;
			usPtpDebugLogCount++;
		}
#endif
#endif

#ifdef	RZT1_SOFT_TEST

		blRet = TRUE;
		return blRet;
#else
		ptp_dbg_msg(D_FUNC, ("computeMDPdelayPropTime_1AS::-\n"));
		return blRet;
#endif
	}
#endif
	ptpSubSNs_SNs(&stD_Ns, &stB_Ns, &stC_Ns);

	ptpAddTInt_SNs (&pstPortMD->stPdlyReqMsgIngressCorrection, &stC_Ns, &stF_TInt);
	ptpSubTInt_TInt (&stF_TInt, &pstPortMD->stPdlyRespMsgEgressCorrection, &stG_TInt);
	tsn_Wrapper_MemSet(&stF_TInt, 0, sizeof(TIME_INTERVAL));
	ptpAddTInt_TInt(&stG_TInt, &stF_TInt, &stC_Ns);

	ptpShiftSNs_CHAR(&stC_Ns, (CHAR)(-1), &stE_Ns);

	chCmpAB = ptpCompUSNs_SNs( &pstCmldsPortDs->stNeighborPropDelayThresh, &stE_Ns );
	if ((chCmpAB == COMP_EQUAL) || (chCmpAB == COMP_A_GREAT))
	{
#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE1
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 1;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPortMD->stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp = pstPortMD->stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespMsgEgressTimestamp 	= pstPortMD->stPdlyRespMsgEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp 	= pstPortMD->stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbNeighborRateRatio			= pstPortGD->dbNeighborRateRatio;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				= pstPort->pstClockData->stDefaultDS.uchDomainNumber;
		}
#endif
#endif

		blRet = TRUE;

		chCmpAB = ptpCompUSNs_SNs(&pstPort->pstClockData->stClock_GD.stAveDelayTrash, &stE_Ns);
		if (chCmpAB != COMP_A_LESS)
		{

			if (pstPortGD->ulPropDelayNumber == 0)
			{
				blRet |= ptpConvSNs_USNs(&stE_Ns, &pstPortGD->stAveDelayTime);
				pstPortGD->stNeighborPropDelay = pstPortGD->stAveDelayTime;
				pstPortGD->ulPropDelayNumber ++;
			}
			else
			{
				blRet |= ptpConvSNs_USNs(&stE_Ns, &stTemp_UNs);

				blRet |= ptpAddUSNs_USNs(&stTemp_UNs, &pstPortGD->stAveDelayTime, &stTemp_UNs2);
				ptpShiftUSNs_CHAR(&stTemp_UNs2, (CHAR)-1, &pstPortGD->stAveDelayTime);
				pstPortGD->stNeighborPropDelay = pstPortGD->stAveDelayTime;


				if ((pstPortGD->ulPropDelayNumber + 1) != 0)
				{
					pstPortGD->ulPropDelayNumber ++;
				}
			}

		}

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE1
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stNeighborPropDelay			= pstPortGD->stNeighborPropDelay;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			= usPtpDebugLogCount;
			usPtpDebugLogCount++;
		}
#endif
#endif

	}
#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE3
	else
	{
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 3;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespEventIngressTimestamp = pstPortMD->stPdlyRespEventIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqEventEgressTimestamp = pstPortMD->stPdlyReqEventEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyRespMsgEgressTimestamp 	= pstPortMD->stPdlyRespMsgEgressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPdlyReqMsgIngressTimestamp 	= pstPortMD->stPdlyReqMsgIngressTimestamp;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbNeighborRateRatio			= pstPortGD->dbNeighborRateRatio;
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber				= pstPort->pstClockData->stDefaultDS.uchDomainNumber;
			ptpConvSNs_USNs(&stE_Ns,&stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stNeighborPropDelay);
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount			= usPtpDebugLogCount;
			usPtpDebugLogCount++;
		}
	}
#endif
#endif


	SetMDPdelayTimestampInfo(pstSmGbl, pstPort);

	ptp_dbg_msg(D_FUNC, ("computeMDPdelayPropTime_1AS::-\n"));
	return blRet;
}

#endif

#ifndef PTP_USE_SIGNALING
VOID lnkDlyIntSet_1AS(PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS* pstCmldsPortDS;
	USCALEDNS		  stA_USNs = { 0 };

	pstCmldsPortDS = GetCmldsPortDS(pstPort);

	if (pstCmldsPortDS->blUseMgtSttblLogPdReqInterval)
	{
		pstCmldsPortDS->chCurrentLogPdelayReqInterval
			= pstCmldsPortDS->chMgtSttblLogPdReqInterval;

		pstPort->stMDPReqSM_GD.blNeighborRateRatioValid = TRUE;

		pstPort->stPort_GD.dbNeighborRateRatio = 1.0;

		pstCmldsPortDS->lNeighborRateRatio = 0;
	}
	else
	{
		pstCmldsPortDS->chCurrentLogPdelayReqInterval
			= pstCmldsPortDS->chInitialLogPdelayReqInterval;

		pstPort->stPort_GD.blComputeNeighborRateRatio = TRUE;

		pstPort->stPort_GD.blComputeNeighborPropDelay = TRUE;
	}

	stA_USNs.ulNsec_lsb = CONST10_9;

	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstCmldsPortDS->chCurrentLogPdelayReqInterval,
		&pstPort->stPortMD_GD.stPdelayReqInterval);

}
#endif
