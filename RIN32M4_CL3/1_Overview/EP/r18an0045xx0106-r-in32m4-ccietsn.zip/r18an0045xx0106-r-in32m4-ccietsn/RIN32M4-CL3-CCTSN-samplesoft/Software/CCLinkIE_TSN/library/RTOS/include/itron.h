/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef	ITRON_H__
#define	ITRON_H__

#ifdef	__IASMARM__
#ifndef	_ASM_
#define	_ASM_
#endif
#endif

#ifndef	_ASM_
#include <stddef.h>
#endif

#ifndef	_ASM_
typedef signed char		B;
typedef signed short	H;
typedef signed long		W;
typedef unsigned char	UB;
typedef unsigned short	UH;
typedef unsigned long	UW;

typedef char			VB;
typedef short			VH;
typedef long			VW;

typedef void			*VP;
typedef void			(*FP)(void);

typedef signed int		ROS_INT;
typedef unsigned int	ROS_UINT;
typedef ROS_INT			ROS_BOOL;

typedef ROS_INT			FN;
typedef ROS_INT			ER;
typedef ROS_INT			ID;
typedef ROS_UINT		ATR;
typedef ROS_UINT		STAT;
typedef ROS_UINT		MODE;
typedef ROS_INT			PRI;
typedef ROS_UINT		SIZE;

typedef ROS_INT			TMO;
typedef ROS_UINT		RELTIM;
typedef ROS_UINT		SYSTIM;

typedef VP				VP_INT;

typedef ER				ER_BOOL;
typedef ER				ER_ID;
typedef ER				ER_UINT;

typedef ROS_UINT        FLGPTN;

typedef	struct t_msg {
	struct t_msg	*next;
} T_MSG;

typedef	struct t_msg_pri {
	T_MSG		msgque;
	PRI			msgpri;
} T_MSG_PRI;

typedef ROS_UINT        INHNO;
typedef ROS_UINT        INTNO;

#ifndef	NULL
#define	NULL		0
#endif

#define	ROS_TRUE		1
#define	ROS_FALSE		0

#endif

#define	E_OK		0


#define	E_SYS		(-5)

#define	E_NOSPT		(-9)
#define	E_RSFN		(-10)
#define	E_RSATR		(-11)

#define	E_PAR		(-17)
#define	E_ID		(-18)

#define	E_CTX		(-25)
#define	E_MACV		(-26)
#define	E_OACV		(-27)
#define	E_ILUSE		(-28)

#define	E_NOMEM		(-33)
#define	E_NOID		(-34)

#define	E_OBJ		(-41)
#define	E_NOEXS		(-42)
#define	E_QOVR		(-43)

#define	E_RLWAI		(-49)
#define	E_TMOUT		(-50)
#define	E_DLT		(-51)
#define	E_CLS		(-52)

#define	E_WBLK		(-57)
#define	E_BOVR		(-58)

#define	E_UNKNOWN	(-99)

#define	TA_NULL		0

#define	TMO_POL		0
#define	TMO_FEVR	(-1)
#define	TMO_NBLK	(-2)


#endif
