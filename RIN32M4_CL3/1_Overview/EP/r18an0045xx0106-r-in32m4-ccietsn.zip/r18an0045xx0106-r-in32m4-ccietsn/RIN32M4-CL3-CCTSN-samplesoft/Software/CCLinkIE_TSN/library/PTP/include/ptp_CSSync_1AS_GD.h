/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CSSYNC_1AS_GD_H__
#define __PTP_CSSYNC_1AS_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_CSS {
	ST_CSS_NONE	= 0,
	ST_CSS_INITIALIZING,
	ST_CSS_SEND_SYNC_INDICATION,
	ST_CSS_MAX
} EN_ST_CSS;

typedef	enum	tagEN_EV_CSS {
	EV_CSS_BEGIN = 0,
	EV_CSS_FOR_CLKSLVSYN_RVPSYNC,
	EV_CSS_FOR_CLKSLVSYN_RVLCLKTICK,
	EV_CSS_CLOSE,
	EV_CSS_EVENT_MAX
} EN_EV_CSS;

typedef	struct tagCSSYNCSM_1AS_GD
{
	EN_ST_CSS		enStatusCSS;
	BOOL			blRcvdPSSync;
	BOOL			blRcvdLocalClockTick;
	PORTSYNCSYNC	stRcvdPSSyncDat;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr;

	USCALEDNS			stCurrentMasterTimeFO;
	USCALEDNS			stCurrentMasterTimeFOOld;
	EXTENDEDTIMESTAMP	stCMSyncReceiptTimeFO;
	EXTENDEDTIMESTAMP	stCMSyncReceiptTimeFOOld;
	BOOL				blCMFOffsetOld;
	DOUBLE				dbCMFreqOffsetCand;
	SCALEDNS			stCMPhaseOffsetCand;
	ENUM_PORTSTATE		enSelectedState0_Old;
} CSSYNCSM_1AS_GD;	




#endif


