/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "CYC_common.h"
#include "cyclic_address.h"
#include "NGN_ASIC.h"

CYC_CTRL	gstCycCtrl;
NX_STATIC	NX_ULONG	gulDummy = NX_ZERO;

NX_CONST	NX_ULONG	gaulMemAdd_RX[NX_LIB_MODE_SIZE] = {
	MEMADD_RX_NORMAL,
	MEMADD_RX_FASTIO,
	MEMADD_RX_NORMAL,
	MEMADD_RX_NORMAL,
};

NX_CONST	NX_ULONG	gaulMemAdd_RY[NX_LIB_MODE_SIZE] = {
	MEMADD_RY_NORMAL,
	MEMADD_RY_FASTIO,
	MEMADD_RY_FASTIO,
	MEMADD_RY_FASTIO3,
};

NX_CONST	NX_ULONG	gaulRyAddrTbl[NX_LIB_MODE_SIZE][RCV_SIDE_SIZE] = {
	{RY_NORMAL_AHBADD_BASE_A,	RY_NORMAL_AHBADD_BASE_B, RY_NORMAL_AHBADD_BASE_C,	RY_NORMAL_AHBADD_BASE_A	},
	{RY_FASTIO_AHBADD_BASE_A,	RY_FASTIO_AHBADD_BASE_B, RY_FASTIO_AHBADD_BASE_C,	RY_FASTIO_AHBADD_BASE_A	},
	{RY_FASTIO_AHBADD_BASE_A,	RY_FASTIO_AHBADD_BASE_B, RY_FASTIO_AHBADD_BASE_C,	RY_FASTIO_AHBADD_BASE_A	},
	{RY_FASTIO3_AHBADD_BASE_A,	RY_FASTIO3_AHBADD_BASE_B, RY_FASTIO3_AHBADD_BASE_C,	RY_FASTIO3_AHBADD_BASE_A },
};

NX_CONST	NX_ULONG	gaulRWwAddrTbl[RCV_SIDE_SIZE] = {
	RWW_AHBADD_BASE_A,		RWW_AHBADD_BASE_B,		RWW_AHBADD_BASE_C,	RWW_AHBADD_BASE_A
};

#ifdef SAFETY_PDU_ENABLE
NX_CONST	NX_ULONG	gaulSpduyAddrTbl[RCV_SIDE_SIZE] = {
	SPDUY_AHBADD_BASE_A,		SPDUY_AHBADD_BASE_B,		SPDUY_AHBADD_BASE_C,	SPDUY_AHBADD_BASE_A
};
#endif

NX_CONST	NX_ULONG	gaulRxAddrTbl[NX_LIB_MODE_SIZE][TRN_SIDE_SIZE] = {
	{RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_B,	RX_NORMAL_AHBADD_BASE_C},
	{RX_FASTIO_AHBADD_BASE_A,	RX_FASTIO_AHBADD_BASE_A,	RX_FASTIO_AHBADD_BASE_B,	RX_FASTIO_AHBADD_BASE_C},
	{RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_B,	RX_NORMAL_AHBADD_BASE_C},
	{RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_A,	RX_NORMAL_AHBADD_BASE_B,	RX_NORMAL_AHBADD_BASE_C},
};

NX_CONST	NX_ULONG	gaulRWrAddrTbl[TRN_SIDE_SIZE] = {
	RWR_AHBADD_BASE_A,		RWR_AHBADD_BASE_A,	RWR_AHBADD_BASE_B,	RWR_AHBADD_BASE_C
};

#ifdef SAFETY_PDU_ENABLE
NX_CONST	NX_ULONG	gaulSpduxAddrTbl[TRN_SIDE_SIZE] = {
	SPDUX_AHBADD_BASE_A,		SPDUX_AHBADD_BASE_A,	SPDUX_AHBADD_BASE_B,	SPDUX_AHBADD_BASE_C
};
#endif

NX_CONST	NX_ULONG	gaulStsWAddrTbl[TRN_SIDE_SIZE] = {
	STSW_AHBADD_BASE_A,		STSW_AHBADD_BASE_A,	STSW_AHBADD_BASE_B,	STSW_AHBADD_BASE_C
};

NX_CONST	NX_ULONG	gaulBaseAddrTbl[TRN_SIDE_SIZE] = {
	TRNBUF_AHBADD_BASE_A,	TRNBUF_AHBADD_BASE_A,	TRNBUF_AHBADD_BASE_B,	TRNBUF_AHBADD_BASE_C
};

NX_CONST	NX_ULONG	gaulRxSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_RX]	= {	MEMADD_RX_NORMAL	};
NX_CONST	NX_ULONG	gaulRyRcvDataAddrTbl[NX_SPLD_ADDR_NUM_RY]			= {	MEMADD_RY_NORMAL	};

NX_CONST	NX_ULONG	gaulRWrSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_RWR] = {
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR,

#ifdef TSN_CAN_ENABLE
#if (2 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT1,
#endif
#if (3 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT2,
#endif
#if (4 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT3,
#endif
#if (5 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT4,
#endif
#if (6 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT5,
#endif
#if (7 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT6,
#endif
#if (8 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWR_EXT7,
#endif
#endif
};

NX_CONST	NX_ULONG	gaulRWwRcvDataAddrTbl[NX_SPLD_ADDR_NUM_RWW] = {
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW,

#ifdef TSN_CAN_ENABLE
#if (2 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT1,
#endif
#if (3 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT2,
#endif
#if (4 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT3,
#endif
#if (5 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT4,
#endif
#if (6 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT5,
#endif
#if (7 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT6,
#endif
#if (8 <= R_IN_CAN_MAX_ODTABLE_NUM)
	(NX_ULONG)R_IN_MEMORY_ADDRESS_RWW_EXT7,
#endif
#endif
};

NX_CONST	NX_USHORT	gusRxSndDataStorageAddrTblSize	= sizeof(gaulRxSndDataStorageAddrTbl) / sizeof(NX_ULONG);
NX_CONST	NX_USHORT	gusRyRcvDataAddrTblSize			= sizeof(gaulRyRcvDataAddrTbl) / sizeof(NX_ULONG);
NX_CONST	NX_USHORT	gusRWrSndDataStorageAddrTblSize	= sizeof(gaulRWrSndDataStorageAddrTbl) / sizeof(NX_ULONG);
NX_CONST	NX_USHORT	gusRWwRcvDataAddrTblSize		= sizeof(gaulRWwRcvDataAddrTbl) / sizeof(NX_ULONG);
#ifdef SAFETY_PDU_ENABLE
NX_CONST	NX_ULONG	gaulSpduxSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_SPDUX]	= {	MEMADD_SPDUX	};
NX_CONST	NX_ULONG	gaulSpduyRcvDataAddrTbl[NX_SPLD_ADDR_NUM_SPDUY]			= {	MEMADD_SPDUY	};

NX_CONST	NX_USHORT	gusSpduxSndDataStorageAddrTblSize	= sizeof(gaulSpduxSndDataStorageAddrTbl) / sizeof(NX_ULONG);
NX_CONST	NX_USHORT	gusSpduyRcvDataAddrTblSize			= sizeof(gaulSpduyRcvDataAddrTbl) / sizeof(NX_ULONG);
#endif


NX_CONST	NX_ULONG	aulUnusedSideTbl[TRN_SIDE_SIZE][TRN_SIDE_SIZE]	=	{
	{	TRN_SIDE_A,	TRN_SIDE_B,	TRN_SIDE_A,	TRN_SIDE_A		},
	{	TRN_SIDE_B,	TRN_SIDE_B,	TRN_SIDE_C,	TRN_SIDE_B		},
	{	TRN_SIDE_A,	TRN_SIDE_C,	TRN_SIDE_A,	TRN_SIDE_A		},
	{	TRN_SIDE_A,	TRN_SIDE_B,	TRN_SIDE_A,	TRN_SIDE_A		}
};

NX_CONST	NX_ULONG	gaulSideMsk[TS_SIZE_EXCEPT_TS0]	=	{	0x00000003,	0x0000000C,
																0x00000030,	0x000000C0,
																0x00000300,	0x00000C00,
																0x00003000
															};

NX_CONST	NX_USHORT	gausSideShift[TS_SIZE_EXCEPT_TS0]	=	{0,	2,	4,	6,	8,	10,	12};

volatile	NX_ULONG*	gpaulCycRevFlg[RCV_SIDE_SIZE]	=	{
	&(NGN_RN_CycRcvFlg->ulCycRcvFlg2A),
	&(NGN_RN_CycRcvFlg->ulCycRcvFlg2B),
	&(NGN_RN_CycRcvFlg->ulCycRcvFlg2C),
	&gulDummy
};

volatile	NX_ULONG*	gpaulCycAlive[RCV_SIDE_SIZE]	=	{
	&(NGN_RN_Alive->ulCycAlive2A),
	&(NGN_RN_Alive->ulCycAlive2B),
	&(NGN_RN_Alive->ulCycAlive2C),
	&gulDummy
};

NX_CONST	NX_UCHAR	gauchDiagErrInfo[ERR_STS_SIZE] = {
	0x00,			0x02,			0x03,			0x03
};

/*[EOF]*/
