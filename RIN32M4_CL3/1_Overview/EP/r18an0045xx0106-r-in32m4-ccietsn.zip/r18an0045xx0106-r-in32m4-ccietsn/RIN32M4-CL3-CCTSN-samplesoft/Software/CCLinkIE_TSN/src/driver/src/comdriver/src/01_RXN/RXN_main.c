/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "itron.h"
#include "kernel.h"
#include "TOOL_api.h"
#include "RXN_buf.h"
#include "networkram.h"
#include "INTR_api.h"
#include "ccienx_task.h"
#include "DATA_log_api.h"
#include "ccienx_api.h"
#include "ACM_api.h"

#define	ETHERTYPE_NGN				((NX_USHORT)0x890F)
#define	ETHERTYPE_IEEE				((NX_USHORT)0x88F7)

#define	FRAMESIZE_DES				((NX_USHORT)0x0006)
#define	FRAMESIZE_SRC				((NX_USHORT)0x0006)
#define	FRAMESIZE_ETHERTYPE			((NX_USHORT)0x0002)

#define	MASK_R_RNDIS_OWN			((NX_ULONG)0x00000001)
#define	MASK_R_RNDIS_SIZE			((NX_ULONG)0x0007FF00)
#define	MASK_R_RNDIS_SHIFT			((NX_ULONG)0x00000008)
#define	MASK_SIZEMAX				((NX_ULONG)0x000003FF)
#define	DIS_MASK_READ				((NX_ULONG)0x00000FFF)
#define	DIS_MASK_WRITE				((NX_ULONG)0x0FFF0000)
#define	DIS_SHIFT_WRITE				((NX_ULONG)16)

#define	CLR_R_RNRDPCLR				(0x00000002 | 0x00000001)

#define	SET_R_RNRDPSET				(0x00000001)

#define	DMA_WAITTIMEUP				(10)

typedef struct tagNCYC_RX_INFO_LIST {
	NX_ULONG		ulDiscNo;
	NCYC_RX_FRAME*	pstRxFrame;
} NCYC_RX_INFO;

typedef struct tagNCYC_RX_DMA_ADDR {
	NX_ULONG		ulStaAdd;
	NX_ULONG		ulEndAdd;
} NCYC_RX_DMA_ADDR;


NX_STATIC NX_CONST NX_ULONG CheckParityBit[2] = {INTR_RXE_DIS_PARITY_PORT1, INTR_RXE_DIS_PARITY_PORT2};

NX_STATIC NX_CONST NCYC_RX_DMA_ADDR RAMAddrData[2] = 
	{{(NX_ULONG)&gauchNCycBuffPort1[NX_ZERO], (NX_ULONG)&gauchNCycBuffPort1[NX_RXN_NCYC_BUFF_SIZE - NX_ONE]},
	{(NX_ULONG)&gauchNCycBuffPort2[NX_ZERO], (NX_ULONG)&gauchNCycBuffPort2[NX_RXN_NCYC_BUFF_SIZE - NX_ONE]}};

NX_STATIC NX_ULONG ulRXN_RxNonCycFrame (NX_ULONG);
NX_STATIC NX_VOID vRXN_SendData (NX_ULONG, NX_ULONG, NX_ULONG, DMA_ITEM*, NCYC_RX_INFO*);
NX_STATIC NX_VOID vRXN_MakeDmaList(NX_ULONG, DMA_ITEM*, NX_ULONG, NX_ULONG, NX_ULONG, NX_ULONG*);
NX_STATIC NX_VOID vRXN_SendMailNonCycRxFrame (NX_ULONG, NCYC_RX_INFO*, NX_ULONG);
NX_STATIC NX_ULONG ulRXN_AsicGetNCycRcvReadDisIdx (NX_ULONG, NX_ULONG*, NX_ULONG*);
NX_STATIC NX_USHORT usRXN_GetEtherOffset(NX_UCHAR*, NX_USHORT*);


NX_VOID vRXN_Init ( NX_VOID )
{
	vRXN_InitNonCycRxBuf();
	
	return;
}

NX_VOID vNX_Task_RxNonCycFrame ( NX_VOID )
{
	NX_ULONG		ulPortNo = (NX_ULONG)NX_ZERO;
	NX_ULONG		ulResult = (NX_ULONG)NX_OFF;
	
	while (NX_ONE) {
		slp_tsk();
		
		ulResult = ulRXN_RxNonCycFrame(ulPortNo);
		ulPortNo ^= (NX_ULONG)NX_ONE;
		if (ulResult == (NX_ULONG)NX_OFF) {
			(NX_VOID)ulRXN_RxNonCycFrame(ulPortNo);
			ulPortNo ^= (NX_ULONG)NX_ONE;
		}
	}
	
	return;
}

NX_STATIC NX_ULONG ulRXN_RxNonCycFrame (
	NX_ULONG		ulPortNo
)
{
	DMA_ITEM		astDmaList[NCYC_RX_NUM_S + NCYC_RX_NUM_L + 2];
	NCYC_RX_INFO	astRxInfoList[NCYC_RX_NUM_S+NCYC_RX_NUM_L];
	NCYC_RX_FRAME* 	pstRxFrame = NULL;
	NX_ULONG		ulReadRet;
	NX_ULONG		ulReadIdx;
	NX_ULONG		ulWriteIdx;
	NX_ULONG		ulRcvSize;
	NX_ULONG		ulCheckFlgResult;
	NX_ULONG		ulDmaCnt;
	NX_ULONG		ulRxCnt;
	NX_ULONG		ulRndis;
	NX_ULONG		ulCheckIntrResult;
	NX_ULONG		ulOwnBit;
	NX_ULONG		ulResult;
	NX_UCHAR		*puchSrcAddr;
	
	ulDmaCnt = (NX_ULONG)NX_ZERO;
	ulRxCnt  = (NX_ULONG)NX_ZERO;
	
	ulReadRet = ulRXN_AsicGetNCycRcvReadDisIdx(ulPortNo, &ulReadIdx, &ulWriteIdx);
	if ((NX_ULONG)NX_ZERO == ulReadRet) {
		ulResult = (NX_ULONG)NX_OFF;
	}
	else {
		while (NX_ONE) {
			ulRndis = NGN_RN_DIS->R_RNDIS[ulPortNo][ulReadIdx].R_RNDIS1.DATA;
			ulOwnBit = ulRndis & MASK_R_RNDIS_OWN;
			ulRcvSize = (ulRndis & MASK_R_RNDIS_SIZE) >> MASK_R_RNDIS_SHIFT;		
			puchSrcAddr = (NX_UCHAR *)NGN_RN_DIS->R_RNDIS[ulPortNo][ulReadIdx].R_RNDIS2;
			ulCheckIntrResult = ulINTR_CheckIntHighRx(CheckParityBit[ulPortNo]);
			if (ulCheckIntrResult == (NX_ULONG)NX_ON) {
				NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNRDPCLR.DATA = CLR_R_RNRDPCLR;
				NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNDISEN.DATA = SET_R_RNRDPSET;
				vINTR_ClearIntHighRx(CheckParityBit[ulPortNo]);
				break;
			}
			
			if (ulOwnBit == (NX_ULONG)NX_ZERO) {
				break;
			}
			ulCheckFlgResult = ulRXN_AllocNonCycRxBuf((NX_USHORT)ulRcvSize, &pstRxFrame);
			
			if (ulCheckFlgResult != NX_UL_NG) {
				pstRxFrame->usPort = (NX_USHORT)ulPortNo;
				pstRxFrame->usSize = (NX_USHORT)ulRcvSize;
				vRXN_MakeDmaList(ulPortNo,
								 astDmaList,
								 ulRcvSize,
								 (NX_ULONG)puchSrcAddr,
								 (NX_ULONG)pstRxFrame->auchData,
								 &ulDmaCnt);
				astRxInfoList[ulRxCnt].ulDiscNo		= ulReadIdx;
				astRxInfoList[ulRxCnt].pstRxFrame	= pstRxFrame;
				ulRxCnt++;
				ulReadIdx = (ulReadIdx + (NX_ULONG)NX_ONE) & MASK_SIZEMAX;
				if (ulReadIdx == ulWriteIdx) {
					break;
				}
			}
			else {
				break;
			}
		}
		vRXN_SendData(ulPortNo, ulRxCnt, ulDmaCnt, astDmaList, astRxInfoList);
		
		ulResult = (NX_ULONG)NX_ON;
	}

	return ulResult;
}

NX_VOID vRXN_SendData (
	NX_ULONG		ulPortNo,
	NX_ULONG		ulRxCnt,
	NX_ULONG		ulDmaCnt,
	DMA_ITEM		astDmaList[],
	NCYC_RX_INFO	astRxInfoList[]
)
{
	FLGPTN		flgDummy;
	NX_ULONG	ulCnt;
	NX_SHORT	sWaitResult;
	
	if (ulRxCnt > (NX_ULONG)NX_ZERO) {
		astDmaList[ulDmaCnt - NX_ONE].ulHeader |= (NX_ULONG)DMA_HEADER_END;
		astDmaList[ulDmaCnt - NX_ONE].ulNext   = (NX_ULONG)NX_ZERO;
		astDmaList[ulDmaCnt - NX_ONE].ulConfig = (NX_ULONG)DMA_CONFIG_DMS +
												 (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
												 (NX_ULONG)DMA_CONFIG_AM2 +
												 (NX_ULONG)DMA_CONFIG_REQD;
		
		clr_flg(EVFLGID_NX_DMACOMP02, (FLGPTN)(~FLGP_DMACOMP));
		vNX_ExecDmaLinkMode(DMA_CHANNEL_2, astDmaList);
		sWaitResult = (NX_SHORT)twai_flg(EVFLGID_NX_DMACOMP02, FLGP_DMACOMP, TWF_ANDW, &flgDummy, DMA_WAITTIMEUP);
		if (sWaitResult != (NX_SHORT)E_OK) {
			for (ulCnt = (NX_ULONG)NX_ZERO; ulCnt < ulRxCnt; ulCnt++) {
				vRXN_ReleaseNonCycRxBuf(astRxInfoList[ulCnt].pstRxFrame->usBuffId);
			}
		}
		else {
			vRXN_SendMailNonCycRxFrame(ulPortNo, astRxInfoList, ulRxCnt);
		}
	}
	else {
	}
	return;
}


NX_STATIC NX_VOID vRXN_MakeDmaList (
	NX_ULONG		ulPortNo,
	DMA_ITEM		astDmaList[],
	NX_ULONG		ulSize,
	NX_ULONG		ulSrc,
	NX_ULONG		ulDst,
	NX_ULONG*		pulIndex
)
{
	NX_ULONG	ulStaAdd;
	NX_ULONG	ulEndAdd;
	NX_ULONG	ulSize1;
	NX_ULONG	ulSize2;
	
	ulStaAdd = RAMAddrData[ulPortNo].ulStaAdd;
	ulEndAdd = RAMAddrData[ulPortNo].ulEndAdd;
	
	if ((ulSrc + ulSize - (NX_ULONG)NX_ONE) <= ulEndAdd) {
		astDmaList[*pulIndex].ulHeader	= (NX_ULONG)DMA_HEADER_DEF;
		astDmaList[*pulIndex].ulSize	= ulSize;
		astDmaList[*pulIndex].ulSrc		= ulSrc;
		astDmaList[*pulIndex].ulDst		= ulDst;
		astDmaList[*pulIndex].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
										  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
										  (NX_ULONG)DMA_CONFIG_DEM +
										  (NX_ULONG)DMA_CONFIG_TCM +
										  (NX_ULONG)DMA_CONFIG_AM2 +
										  (NX_ULONG)DMA_CONFIG_REQD;
		astDmaList[*pulIndex].ulInterval	= (NX_ULONG)NX_ZERO;
		astDmaList[*pulIndex].ulNext	= (NX_ULONG)&astDmaList[*pulIndex + (NX_ULONG)NX_ONE];
		*pulIndex += (NX_ULONG)NX_ONE;
	}
	else {
		ulSize1 = ulEndAdd - ulSrc + (NX_ULONG)NX_ONE;
		ulSize2 = ulSize - ulSize1;
		astDmaList[*pulIndex].ulHeader	= (NX_ULONG)DMA_HEADER_DEF;
		astDmaList[*pulIndex].ulSize	= ulSize1;
		astDmaList[*pulIndex].ulSrc		= ulSrc;
		astDmaList[*pulIndex].ulDst		= ulDst;
		astDmaList[*pulIndex].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
										  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
										  (NX_ULONG)DMA_CONFIG_DEM +
										  (NX_ULONG)DMA_CONFIG_TCM +
										  (NX_ULONG)DMA_CONFIG_AM2 +
										  (NX_ULONG)DMA_CONFIG_REQD;
		astDmaList[*pulIndex].ulInterval	= (NX_ULONG)NX_ZERO;
		astDmaList[*pulIndex].ulNext	= (NX_ULONG)&astDmaList[*pulIndex + (NX_ULONG)NX_ONE];
		*pulIndex += (NX_ULONG)NX_ONE;
		astDmaList[*pulIndex].ulHeader	= (NX_ULONG)DMA_HEADER_DEF;
		astDmaList[*pulIndex].ulSize	= ulSize2;
		astDmaList[*pulIndex].ulSrc		= ulStaAdd;
		astDmaList[*pulIndex].ulDst		= ulDst + ulSize1;
		astDmaList[*pulIndex].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
										  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
										  (NX_ULONG)DMA_CONFIG_DEM +
										  (NX_ULONG)DMA_CONFIG_TCM +
										  (NX_ULONG)DMA_CONFIG_AM2 +
										  (NX_ULONG)DMA_CONFIG_REQD;
		astDmaList[*pulIndex].ulInterval	= (NX_ULONG)NX_ZERO;
		astDmaList[*pulIndex].ulNext	= (NX_ULONG)&astDmaList[*pulIndex + (NX_ULONG)NX_ONE];
		*pulIndex += (NX_ULONG)NX_ONE;
	}
	
	return;
}


NX_STATIC NX_VOID vRXN_SendMailNonCycRxFrame (
	NX_ULONG		ulPortNo,
	NCYC_RX_INFO	astRxInfoList[],
	NX_ULONG		ulListNum
)
{
	NX_ULONG	aulRxDisBit[2] = {INTR_RXE_NCYC_FIFOEMPTY_1, INTR_RXE_NCYC_FIFOEMPTY_2};
	NX_ULONG	aulFifoEmptyIdx[2] = {INTIDX_RXE_NCYC_FIFOEMPTY_1, INTIDX_RXE_NCYC_FIFOEMPTY_2};
	NX_ULONG	ulCnt;
	NX_ULONG	ulParityResult;
	NX_ULONG	ulEmptyResult;
	NX_USHORT	usEtherType;
	NX_USHORT	usAuthClass;
	
	for (ulCnt = (NX_ULONG)NX_ZERO; ulCnt < ulListNum; ulCnt++) {
		
		astRxInfoList[ulCnt].pstRxFrame->usEtherOffset = usRXN_GetEtherOffset(
															&astRxInfoList[ulCnt].pstRxFrame->auchData[0], 
															&usEtherType);
		
		switch (usEtherType) {
		case ETHERTYPE_IEEE:
			usAuthClass = usACM_GetAuthenticationClass();
			if (usAuthClass == (NX_USHORT)NX_AUTHENTICATION_CLS_B) {
				(NX_VOID)snd_mbx(MBXID_NX_RECEIVE_IEEE, (T_MSG*)(astRxInfoList[ulCnt].pstRxFrame));
			}
			else {
				vRXN_ReleaseNonCycRxBuf(astRxInfoList[ulCnt].pstRxFrame->usBuffId);
			}
			break;
		case ETHERTYPE_NGN:
			(NX_VOID)snd_mbx(MBXID_NX_RECEIVE_NGN, (T_MSG*)(astRxInfoList[ulCnt].pstRxFrame));
			break;
		default:
			vRXN_ReleaseNonCycRxBuf(astRxInfoList[ulCnt].pstRxFrame->usBuffId);
			break;
		}
	}
	for (ulCnt = (NX_ULONG)NX_ZERO; ulCnt < ulListNum; ulCnt++) {
		ulEmptyResult = ulINTR_CheckIntHigh(aulRxDisBit[ulPortNo]);
		if (ulEmptyResult == (NX_ULONG)NX_ON) {
		}
		NGN_RN_DIS->R_RNDIS[ulPortNo][astRxInfoList[ulCnt].ulDiscNo].R_RNDIS1.BITS.b01ZOWNBit = NX_ZERO;
		ulParityResult = ulINTR_CheckIntHighRx(CheckParityBit[ulPortNo]);
		NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNDISEN.DATA = SET_R_RNRDPSET;
		if (ulParityResult == (NX_ULONG)NX_ON) {
			NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNRDPCLR.DATA = CLR_R_RNRDPCLR;
			NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNDISEN.DATA = SET_R_RNRDPSET;
			vINTR_ClearIntHighRx(CheckParityBit[ulPortNo]);
			break;
		}
	}
	return;
}

NX_STATIC NX_ULONG ulRXN_AsicGetNCycRcvReadDisIdx (
	NX_ULONG ulPortNo,
	NX_ULONG *pulReadDisIdx,
	NX_ULONG *pulWriteDisIdx
)
{
	NX_ULONG	ulRetReadEnable = (NX_ULONG)NX_OFF;
	NX_ULONG	ulDisData;
	NX_ULONG	ulReadIdx;
	NX_ULONG	ulWriteIdx;
	
	*pulReadDisIdx = (NX_ULONG)NX_ZERO;

	ulDisData =  NGN_RN_NCyc->astNCycPortDatas[ulPortNo].R_RNDISPTR.DATA;
	ulReadIdx =  DIS_MASK_READ & ulDisData;
	ulWriteIdx = (DIS_MASK_WRITE & ulDisData) >> DIS_SHIFT_WRITE;
	
	if (ulReadIdx != ulWriteIdx) {
		ulRetReadEnable = (NX_ULONG)NX_ON;
		*pulReadDisIdx  = ulReadIdx;
		*pulWriteDisIdx = ulWriteIdx;
	}
	else {
	}
	return ulRetReadEnable;
}

NX_USHORT usRXN_GetEtherOffset (
	NX_UCHAR*	puchData,
	NX_USHORT*	pusEtherType
)
{
	NX_USHORT	usEtherOffset 	= (NX_USHORT)NX_ZERO;
	NX_USHORT	usVlanSize 		= (NX_USHORT)NX_ZERO;
	
	
	if (NX_ZERO) {
		
	}
	else {
		usVlanSize = (NX_USHORT)NX_ZERO;
	}
	
	vNX_CopyMemory(pusEtherType, (puchData + (FRAMESIZE_DES + FRAMESIZE_SRC + usVlanSize)), FRAMESIZE_ETHERTYPE);
	
	*pusEtherType = usNX_CnvEndianShort(*pusEtherType);
	
	usEtherOffset = (NX_USHORT)FRAMESIZE_DES + (NX_USHORT)FRAMESIZE_SRC + usVlanSize;
	
	return usEtherOffset;
}
