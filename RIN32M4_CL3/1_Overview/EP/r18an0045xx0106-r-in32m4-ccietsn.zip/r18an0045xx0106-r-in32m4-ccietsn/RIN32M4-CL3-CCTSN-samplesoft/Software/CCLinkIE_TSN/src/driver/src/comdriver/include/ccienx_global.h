/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_GLOBAL_H_INCLUDE__
#define __CCIENX_GLOBAL_H_INCLUDE__

#include "ccienx_struct.h"

NX_EXTERN NX_APP_INFO gstAppInfo;

#endif
/*[EOF]*/
