/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3MEMORYADDRESS_H__
#define __R_IN32M4_CL3MEMORYADDRESS_H__
#ifdef TSN_CAN_ENABLE
#include "R_IN32M4_CL3CanConst.h"
#endif

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
#ifndef TSN_CAN_ENABLE
/* Cyclic received data address																							*/
/* The offset address from the top of the cyclic reception data area must match the CSP+ configuration information		*/
/* 																														*/
/* [CSP+ configuration information]			: [cyclic received data address]											*/
/* *R_B_Address (received bit data address)	: R_IN_MEMORY_ADDRESS_RY													*/
/* *R_W_Address (received word data address)	: R_IN_MEMORY_ADDRESS_RWW												*/
/* 																														*/
/* *Make sure that the areas used in the range of 0x00000000 (0) to 0x000009FF (2559) bytes do not overlap				*/
#define R_IN_MEMORY_ADDRESS_RY			(0x00000000)		/* RY memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWW			(0x00000200)		/* RWw memory address (2byte alignment)		*/

#ifdef SAFETY_PDU_ENABLE
#define R_IN_MEMORY_ADDRESS_RSPDU		(0x00000700)		/* RSPDU memory address (2byte alignment)	*/
#endif

/* Cyclic send data address																								*/
/* The offset address from the top of the cyclic send data area must match the CSP+ configuration information			*/
/* 																														*/
/* [CSP+ configuration information]					: [cyclic send data address]										*/
/* *S_B_Address (transmission bit data address)		: R_IN_MEMORY_ADDRESS_RX											*/
/* *S_W_Address (transmission word data address)		: R_IN_MEMORY_ADDRESS_RWR										*/
/* *StsW_Address (state notification device address)	: R_IN_MEMORY_ADDRESS_STSW										*/
/* 																														*/
/* *The sub-payload header information of 0x00000010 (16) bytes is added to each cyclic communication data, so set the	*/
/*  top address 16 bytes apart																							*/
/* *Make sure that the areas used in the range of 0x00000000 (0) to 0x000009FF (2559) bytes do not overlap				*/
#define R_IN_MEMORY_ADDRESS_RX			(0x00000010)		/* RX memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWR			(0x00000210)		/* RWr memory address (2byte alignment)		*/
#ifdef SAFETY_PDU_ENABLE
#define R_IN_MEMORY_ADDRESS_SSPDU		(0x00000710)		/* SSPDU memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_STSW		(0x00000810)		/* StsW memory address (2byte alignment)	*/
#else
#define R_IN_MEMORY_ADDRESS_STSW		(0x00000710)		/* StsW memory address (2byte alignment)	*/
#endif


#else
#ifdef TSN_CAN_MULTIAXIS_ENABLE
#endif
/* When to use the CC-Link IE TSN CAN																					*/
/* Cyclic send data address and received data address																	*/
/* The offset address from the top of the cyclic data area must match the CSP+ configuration information and 			*/
/* Memory Address (SubIndex4) of PDO Config Object (Index1C00h to 1CFFh) of Object Dictionary.							*/
/* 																														*/
/* Basic Module(Axis 1) setting																							*/
/* [CSP+ configuration information]					: [Cyclic send data address and received data address]				*/
/* *PDOConfigMemoryAddress1							: R_IN_MEMORY_ADDRESS_RWW											*/
/* *PDOConfigMemoryAddress2							: R_IN_MEMORY_ADDRESS_RWR											*/
/* *StsW_Address(state notification device address)	: R_IN_MEMORY_ADDRESS_STSW											*/
#ifdef TSN_CAN_MULTIAXIS_ENABLE
/* 																														*/
/* Expansion Module(Axis 2 to 8) setting																				*/
/* (Definition is not required if the expansion unit is not used.)														*/
/* [CSP+ configuration information]					: [Cyclic send data address and received data address]				*/
/* *EXTx_RPDOConfigMemoryAddress						: R_IN_MEMORY_ADDRESS_RWW_EXTx									*/
/* *EXTx_RPDOConfigMemoryAddress						: R_IN_MEMORY_ADDRESS_RWR_EXTx									*/
/* ("x" in "EXTx" indicates the number of the expansion module.)														*/
/* ex) EXT1�FExpansion module 1(Axis 2)																					*/
#endif
#define R_IN_MEMORY_ADDRESS_RY			(0x00000000)		/* RY memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RX			(0x00000010)		/* RX memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWW			(0x00000200)		/* RWw memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWR			(0x00000210)		/* RWr memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_STSW		(0x00000710)		/* StsW memory address (2byte alignment)	*/

#ifdef TSN_CAN_MULTIAXIS_ENABLE
#if (2 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT1	(0x00000300)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT1	(0x00000310)		/* RWr memory address (2byte alignment)	*/
#endif

#if (3 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT2	(0x00000380)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT2	(0x00000390)		/* RWr memory address (2byte alignment)	*/
#endif

#if (4 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT3	(0x00000400)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT3	(0x00000410)		/* RWr memory address (2byte alignment)	*/
#endif

#if (5 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT4	(0x00000480)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT4	(0x00000490)		/* RWr memory address (2byte alignment)	*/
#endif

#if (6 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT5	(0x00000500)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT5	(0x00000510)		/* RWr memory address (2byte alignment)	*/
#endif

#if (7 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT6	(0x00000580)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT6	(0x00000590)		/* RWr memory address (2byte alignment)	*/
#endif

#if (8 <= R_IN_CAN_MAX_ODTABLE_NUM)
#define R_IN_MEMORY_ADDRESS_RWW_EXT7	(0x00000600)		/* RWw memory address (2byte alignment)	*/
#define R_IN_MEMORY_ADDRESS_RWR_EXT7	(0x00000610)		/* RWr memory address (2byte alignment)	*/
#endif
#endif
#endif
#endif
/*** EOF ***/
