//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _USS_NET_H_
#define _USS_NET_H_


#include "config6.h"

#include <string.h>
#ifdef  INET6
#include "net6.h"
#endif

#define LITTLE

#define IP 1
#define ICMP 2
#define ARP 3
#define RARP 4
#define UDP 5
#define TCP 6



#define LHDRSZ 14
#define TOUT_READ 20000UL
#define REASSTOUT 60000UL
#define ARPTOUT 60000UL
#define MAXWACK 4
#define MAXWIND 4
#define MAXOUTQLEN 4



#define ASCII 0
#define IMAGE 1

#define QUEUE_EMPTY(ptr, qname) (ptr->qname.mhead == ptr->qname.mtail)
#define QUEUE_FULL(ptr, qname) \
        (ptr->qname.mhead == ((ptr->qname.mtail + 1) & \
            ((sizeof(ptr->qname.mp)/sizeof(ptr->qname.mp[0]))-1)))
#define QUEUE_IN(ptr, qname, mess) \
        ptr->qname.mp[ptr->qname.mtail] = mess; \
        ptr->qname.mtail = (ptr->qname.mtail + 1) & \
            ((sizeof(ptr->qname.mp)/sizeof(ptr->qname.mp[0]))-1);
#define QUEUE_OUT(ptr, qname, mess) \
        mess = ptr->qname.mp[ptr->qname.mhead]; \
        ptr->qname.mhead = (ptr->qname.mhead + 1) & \
            ((sizeof(ptr->qname.mp)/sizeof(ptr->qname.mp[0]))-1);
#define MESS_OUT(ptr, mess) \
        mess = ptr->first; \
        if ((ptr->first = mess->next) == 0) \
            ptr->last = (MESS *)&ptr->first; \
        ptr->ninque--; \

#ifndef FARDEF
#define FAR
#define Nfarcpy memcpy
#else
#define FAR FARDEF
void            Nfarcpy(char FAR *, char FAR *, int);
#endif


#define Eid_SZ 6
struct Eid {
    unsigned char   c[Eid_SZ];
};
#define Iid_SZ 4
typedef union {
    unsigned char   c[Iid_SZ];
    unsigned short  s[Iid_SZ / 2];
    unsigned long   l;
}               Iid;
typedef union {
    unsigned char   b[4];
    unsigned long   l;
}               IPaddr;
#define EQIID(id1, id2) (*(long *)&id1 == *(long *)&id2)
#define Ihdr_SZ 20

#ifdef LITTLE
#define USS_ISCLASSD(iidl) ((iidl & 0xF0UL) == 0xe0UL)
#else
#define USS_ISCLASSD(iidl) ((iidl & 0xF0000000UL) == 0xe0000000UL)
#endif

#define ussBroadcastIndex 255
#define ussMulticastIndex 254

#define ussDfltMcNetno 0

#define ussLinkIndex    0
#define ussDriverIndex  1
#define ussAdapterIndex 2

enum ioctlreq { ussIdentE,
                ussDevBaudSetE,
                ussLinkIsUpE,
                ussLinkIsDownE,
                ussLinkBringUpE,
                ussLinkBringDownE,
                ussInterfaceBringUpE,
                ussInterfaceBringDownE,
                ussPPPUserIdSetE,
                ussPPPUserIdGetE,
                ussPPPPasswordSetE,
                ussPPPPasswordGetE,
                ussPPPDialEnableE,
                ussPPPDialDisableE,
                ussPPPHostAddressGetE,
                ussPPPHostAddressSetE,
                ussPPPRemoteAddressGetE,
                ussPPPRemoteAddressSetE,
                ussMcastGroupJoinE,
                ussMcastGroupLeaveE
              };

struct MESSH {
    struct MESSH   *next;
    unsigned long   timems;
    unsigned long   target;
    unsigned long   retry;
    unsigned short  mlen;
    unsigned char   netno;
    unsigned char   offset;
    unsigned char   confix;
    char            conno;
    short           id;
    short           portno;
#ifdef  INET6
    struct MESSH6   ipv6;
#endif
};
typedef struct MESSH MESS;

#define bFUTURE 0x7777
#define bFREE 0x7676
#define bALLOC 0x7575
#define bWACK 0x7474
#define bSACK 0x7473
#define bRELEASE 0x7373
#define boRELEASED 0xff
#define boTXDONE   0xfd

#define PTABLE const struct P_tab
struct P_tab {
    char            name[14];
    int             (*init) (int, char *);
    void            (*shut) (int);
    int             (*screen) (MESS *);
    int             (*opeN) (int, int);
    int             (*closE) (int);
    MESS           *(*reaD) (int);
    int             (*writE) (int, MESS *);
    int             (*ioctl) (void *, enum ioctlreq, void *, size_t);
    int             Eprotoc;
    unsigned char   hdrsiz;
};


extern PTABLE   ussEthernetTable;
extern PTABLE   ussARCNETTable;
extern PTABLE   ussSLIPTable;
extern PTABLE   ussPPPTable;
extern PTABLE   ussPPPoETable;

#define Ethernet &ussEthernetTable
#define ARCNET   &ussARCNETTable
#define SLIP     &ussSLIPTable
#define PPP      &ussPPPTable
#define PPPOE    &ussPPPoETable


extern PTABLE ussPCITable;
extern PTABLE ussPCMCIA1Table;
extern PTABLE ussPCMCIA2Table;

#define PCI      &ussPCITable
#define PCMCIA1  &ussPCMCIA1Table
#define PCMCIA2  &ussPCMCIA2Table


extern PTABLE uss3C503Table;
extern PTABLE uss3C509Table;
extern PTABLE uss3C900Table;
extern PTABLE ussAM186ESTable;
extern PTABLE ussAM7990Table;
extern PTABLE ussAMD85C30Table;
extern PTABLE ussAMD961Table;
extern PTABLE ussCL7XTable;
extern PTABLE ussCS8900Table;
extern PTABLE ussDC21040Table;
extern PTABLE ussDC21140Table;
extern PTABLE ussD2681Table;
extern PTABLE ussEN302Table;
extern PTABLE ussEN360Table;
extern PTABLE ussEXP16Table;
extern PTABLE ussH64180Table;
extern PTABLE ussHC11SCITable;
extern PTABLE ussHC16SCITable;
extern PTABLE ussI8250Table;
extern PTABLE ussI82557Table;
extern PTABLE ussI82595Table;
extern PTABLE ussI82596Table;
extern PTABLE ussKS32CTable;
extern PTABLE ussKS32CSERTable;
extern PTABLE ussMB86960Table;
extern PTABLE ussNDISTable;
extern PTABLE ussNE1000Table;
extern PTABLE ussNE2000Table;
extern PTABLE ussNE2100Table;
extern PTABLE ussNS16550Table;
extern PTABLE ussNS8390Table;
extern PTABLE ussNS83902Table;
extern PTABLE ussODITable;
extern PTABLE ussPPC860Table;
extern PTABLE ussPPC860TTable;
extern PTABLE ussPPSMSCITable;
extern PTABLE ussPPSMUARTTable;
extern PTABLE ussRTELAN32Table;
extern PTABLE ussS167Table;
extern PTABLE ussSH7604Table;
extern PTABLE ussSH7708Table;
extern PTABLE ussSM83C790Table;
extern PTABLE ussSMC91C92Table;
extern PTABLE ussWD8003Table;
extern PTABLE ussWrapTable;
extern PTABLE ussSWrapTable;
extern PTABLE ussSH7616ETable;
extern PTABLE ussSH7618ETable;
extern PTABLE ussNetDrvTable;

#define _3C503   &uss3C503Table
#define _3C509   &uss3C509Table
#define _3C900   &uss3C900Table
#define AM186    &ussAM186ESTable
#define AM186ES  &ussAM186ESTable
#define AM7990   &ussAM7990Table
#define AMD85C30 &ussAMD85C30Table
#define AMD961   &ussAMD961Table
#define CL7X     &ussCL7XTable
#define CS8900   &ussCS8900Table
#define DC21040  &ussDC21040Table
#define DC21140  &ussDC21140Table
#define D2681    &ussD2681Table
#define EN302    &ussEN302Table
#define EN360    &ussEN360Table
#define EXP16    &ussEXP16Table
#define H64180   &ussH64180Table
#define HC11SCI  &ussHC11SCITable
#define HC16SCI  &ussHC16SCITable
#define I8250    &ussI8250Table
#define I82557   &ussI82557Table
#define I82595   &ussI82595Table
#define I82596   &ussI82596Table
#define KS32C    &ussKS32CTable
#define KS32CSER &ussKS32CSERTable
#define MB86960  &ussMB86960Table
#define NDIS     &ussNDISTable
#define NE1000   &ussNE1000Table
#define NE2000   &ussNE2000Table
#define NE2100   &ussNE2100Table
#define NS16550  &ussNS16550Table
#define NS8390   &ussNS8390Table
#define NS83902  &ussNS83902Table
#define ODI      &ussODITable
#define PPC860   &ussPPC860Table
#define PPC860T  &ussPPC860TTable
#define PPSMSCI  &ussPPSMSCITable
#define PPSMUART &ussPPSMUARTTable
#define RTELAN32 &ussRTELAN32Table
#define S167     &ussS167Table
#define SH7604   &ussSH7604Table
#define SH7708   &ussSH7708Table
#define SM83C790 &ussSM83C790Table
#define SMC91C92 &ussSMC91C92Table
#define WD8003   &ussWD8003Table
#define WRAP     &ussWrapTable
#define NETDRV     &ussNetDrvTable
#define SWRAP    &ussSWrapTable
#define SH7616E  &ussSH7616ETable
#define SH7618E  &ussSH7618ETable

struct FIFOQ8 {
    MESS           *mp[8];
    int             mhead,
                    mtail;
};
struct FIFOQ16 {
    MESS           *mp[16];
    int             mhead,
                    mtail;
};

struct NETDATA {
    char           *name;
    char           *pname;
    struct {
        unsigned char   c[Iid_SZ];
    }
                    Imask, Iaddr;
    struct Eid      Eaddr;
    short           flags;
    PTABLE         *lprotoc;
    PTABLE         *dprotoc;
    PTABLE         *adapter;
    char           *params;
#ifdef  INET6
    struct NETDATA6 *ipv6;
#endif
};
#define NOTUSED    0x0001
#define BOOTSERVER 0x0002
#define TIMESERVER 0x0004
#define ROUTER     0x0008
#define LOCALHOST  0x0010
#define NODE       0x0020
#define DIAL       0x0040
#define DNSVER     0x0080
#define PROXYARP   0x0100
#define NATLOCAL   0x0200

#define IPADDR  0x0100
#ifdef  INET6
#define IP6ADDR 0x0200
#endif



#ifdef EBADF
#undef EBADF
#endif

#define NE_PARAM        -10
#define EHOSTUNREACH    -11
#define ETIMEDOUT       -12
#define NE_HWERR        -13
#define ECONNABORTED    -14
#define ENOBUFS         -15
#define EBADF           -16
#define EFAULT          -17
#define EWOULDBLOCK     -18
#define EMSGSIZE        -19
#define ENOPROTOOPT     -20
#define ussErrInval -21
#define EWINZERO    -22
#define EDHCPROUTER -2

#define NE_NOTCONF EHOSTUNREACH
#define NE_TIMEOUT ETIMEDOUT
#define NE_NOBUFS ENOBUFS
#define NE_PROTO ECONNABORTED


void            Ninitbuf(int size, int count);
void            Nclearbuf(int size, int count, int netno);
MESS           *Ngetbuf(void);
MESS           *NgetbufIR(void);
void            Nrelbuf(MESS * bufptr);
void            NrelbufIR(MESS * bufptr);
void            Ncntbuf(void);
int             BuildRoutes(void);
int             GetHostData(unsigned long iid, int addflag, unsigned char netno);
void            ussHostAcquire( int confix );
void            ussHostRelease( int confix );
int             ussHostUsed( int confix );
int             Ninit(void);
int             Nterm(void);
int             Portinit(char *port);
int             Portterm(char *port);
int             Nopen(char *to, char *protoc, int myport, int herport, int flags);
int             Nclose(int conno);
int             Nwrite(int conno, char *mess, int len);
int             Nread(int conno, char *mess, int len);
void            TFTPserv(void);
int             TFTPput(char *host, char *file, int mode);
int             TFTPget(char *host, char *file, int mode);
void            FTPserv(void);
int             FTPgetput(char *host, char *file, int mode);
#define FTPget(host, file, mode) FTPgetput(host, file, mode)
#define FTPput(host, file, mode) FTPgetput(host, file, mode+2)
int             getEid(unsigned long iid);
int             pppTimeout(int netno);
int             ussHostGroupJoin(Iid iid, int netno);
int             ussHostGroupLeave(Iid iid, int netno);
void            ussChecksumAdjust(unsigned char *,
                   unsigned char *, int,
                   unsigned char *, int);
#ifdef	INET6
void            TFTP6serv(void);
int             TFTP6put(char *host, char *file, int mode);
int             TFTP6get(char *host, char *file, int mode);
void            FTP6serv(void);
int             FTP6getput(char *host, char *file, int mode);
int             _FTPgetput(char *host, char *file, int mode, char *p);
#define FTP6get(host, file, mode) FTP6getput(host, file, mode)
#define FTP6put(host, file, mode) FTP6getput(host, file, mode+2)
#endif
#endif

