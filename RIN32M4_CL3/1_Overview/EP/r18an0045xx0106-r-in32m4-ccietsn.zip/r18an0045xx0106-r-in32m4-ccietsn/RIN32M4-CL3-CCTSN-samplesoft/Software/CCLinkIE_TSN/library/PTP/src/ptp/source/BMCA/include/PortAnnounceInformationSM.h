/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTANNOUNCEINFORMATIONSM_H__
#define __PORTANNOUNCEINFORMATIONSM_H__
#include <ptp_type.h>
#include <ptp_Struct_Port.h>
#include <PortAnnounceInformationSMGD.h>


#ifdef __cplusplus
extern "C" {
#endif

VOID	portAnnounceInformationSM(USHORT usEvent, PORTDATA *pstPort);
PAINFORMATIONSM_EV	GetportAnnInformationEvent(USHORT usEvent);
VOID	PortAnnounceInformation_00(PORTDATA *pstPort);
VOID	PortAnnounceInformation_01(PORTDATA *pstPort);
VOID	PortAnnounceInformation_02(PORTDATA *pstPort);
VOID	PortAnnounceInformation_03(PORTDATA *pstPort);
VOID	PortAnnounceInformation_04(PORTDATA *pstPort);
VOID	PortAnnounceInformation_05(PORTDATA *pstPort);
VOID	PortAnnounceInformation_06(PORTDATA *pstPort);
VOID	PortAnnounceInformation_07(PORTDATA *pstPort);
VOID	PortAnnounceInformation_08(PORTDATA *pstPort);
VOID	PortAnnounceInformation_09(PORTDATA *pstPort);
VOID	PortAnnounceInformation_10(PORTDATA *pstPort);
VOID	PortAnnounceInformation_11(PORTDATA *pstPort);
VOID	PortAnnounceInformation_12(PORTDATA *pstPort);
VOID	PortAnnounceInformation_13(PORTDATA *pstPort);
VOID	PortAnnounceInformation_14(PORTDATA *pstPort);
VOID	PortAnnounceInformation_15(PORTDATA *pstPort);
VOID	PortAnnounceInformation_16(PORTDATA *pstPort);
VOID	PortAnnounceInformation_17(PORTDATA *pstPort);
VOID	PortAnnounceInformation_nop(PORTDATA *pstPort);
VOID	recordOtherAnnounceInfo (PORTBMC_GD *pstPortBmcGd);
UCHAR	rcvInfo (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort);
VOID	makeMessagePriorityVector(PTPMSG_ANNOUNCE *pstSrcAnnounce, USHORT usPortNumber, PRIORITY_VECT *pstMessagePriorityVector);
VOID	set_announce_tmo_1588(PORTDATA *pstPort);
VOID	set_announce_tmo_AS(PORTDATA *pstPort);
VOID	recordOtherAnnounceInfo (PORTBMC_GD *pstPortBmcGd);
VOID	makeMessagePriorityVector(PTPMSG_ANNOUNCE *pstSrcAnnounce, USHORT usPortNumber, PRIORITY_VECT *pstMessagePriorityVector);
VOID	qualificationTimeout_1588(USHORT usEvent,PORTDATA *pstPort);
VOID	set_qualification_tmo_1588(PORTDATA *pstPort);
UCHAR	rcvInfo_AS (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort);
UCHAR	rcvInfo_1588 (PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr, PORTDATA *pstPort);
VOID	exec_PortAnnInfo04_allPort(PORTDATA *pstPort);
VOID	makeSystemPrioVector(PORTDATA *pstPort);
VOID	set_sync_tmo_AS(PORTDATA*	pstPort);

VOID	makeMessagePriorityVector2(BMCA_CMP_INF_DATA *pstBmcaCmpInfo, USHORT usPortNumber, PRIORITY_VECT *pstMessagePriorityVector);

#ifdef __cplusplus
}
#endif

#endif
