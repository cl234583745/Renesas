/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 CANopen sample                                                   */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3CANCONST_H__
#define __R_IN32M4_CL3CANCONST_H__

#ifdef TSN_CAN_ENABLE

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
/*-------------------------------------------------------------------------------*/
/* Object Dictionary                                                             */
/*-------------------------------------------------------------------------------*/
#ifdef TSN_CAN_MULTIAXIS_ENABLE
#define	R_IN_CAN_MAX_ODTABLE_NUM							(3)						/* Maximum number of Object Dictionary (1 to 8)			*/
#else
#define	R_IN_CAN_MAX_ODTABLE_NUM							(1)						/* Maximum number of Object Dictionary (1 Fixed)		*/
#endif

/* PDO Setting in Object Dictionary unit */
#define R_IN_CAN_PDO_CONFIG_OBJECT_NUM						(2)						/* Number of PDO Config Object(1C00h-1C01h)				*/
#define R_IN_CAN_RPDO_MAPPING_OBJECT_NUM					(2)						/* Number of RPDO Mapping Object(1600h-1601h)			*/
#define R_IN_CAN_RPDO_APPLICATION_OBJECT_NUM				(32)					/* Number of RPDO Application Object(Subindex00-32)		*/
#define R_IN_CAN_TPDO_MAPPING_OBJECT_NUM					(2)						/* Number of TPDO Mapping Object(1A00h-1A01h)			*/
#define R_IN_CAN_TPDO_APPLICATION_OBJECT_NUM				(32)					/* Number of TPDO Application Object(Subindex00-32)		*/


/*-------------------------------------------------------------------------------*/
/* ABORTCODE                                                                     */
/*-------------------------------------------------------------------------------*/
/* Abort code detected at Object Dictionary registration */
#define	R_IN_CAN_ABORT_INDEX_UNSORTED						(0x06090030)			/* Index Non-sort / Duplicate / 0x0000-0x0FFF			*/
#define	R_IN_CAN_ABORT_MAXSUBINDEX_VALUE_INVALID			(0x06090030)			/* Invalid MaxSubIndex setting value					*/
#define	R_IN_CAN_ABORT_OBJECTCODE_VALUE_INVALID				(0x06090030)			/* Invalid Object code setting value					*/
#define	R_IN_CAN_ABORT_OBJECTDATAPTR_IS_NULL				(0x06090030)			/* Object Data address is set to NULL					*/
#define	R_IN_CAN_ABORT_NAMEPTR_IS_NULL						(0x06090030)			/* Name address is set to NULL							*/
#define	R_IN_CAN_ABORT_DATATYPE_VALUE_INVALID				(0x06090030)			/* Invalid Data type setting value						*/
#define	R_IN_CAN_ABORT_BITLENGTH_VALUE_INVALID				(0x06090030)			/* Invalid Bit length setting value						*/
#define	R_IN_CAN_ABORT_UNITTYPE_VALUE_INVALID				(0x06090030)			/* Invalid Unit type setting value						*/
#define	R_IN_CAN_ABORT_DEFAULT_VALUE_INVALID				(0x06090030)			/* Invalid Default value setting value					*/
#define	R_IN_CAN_ABORT_MIN_VALUE_INVALID					(0x06090030)			/* Invalid Minimum value setting value					*/
#define	R_IN_CAN_ABORT_MAX_VALUE_INVALID					(0x06090030)			/* Invalid Maximum value setting value					*/
#define	R_IN_CAN_ABORT_VALUEPTR_IS_NULL						(0x06090030)			/* Storage variable address is set to NULL				*/


#endif
#endif

/*** EOF ***/
