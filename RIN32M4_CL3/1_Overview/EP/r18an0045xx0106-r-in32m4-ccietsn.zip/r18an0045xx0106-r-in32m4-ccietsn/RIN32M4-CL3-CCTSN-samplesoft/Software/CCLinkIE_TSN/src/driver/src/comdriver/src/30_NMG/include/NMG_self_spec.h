/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __NMG_SELF_SPEC_H_INCLUDE__
#define __NMG_SELF_SPEC_H_INCLUDE__

#define	PROTO_VER			((NX_UCHAR)0)
#define	PROTO_VER01			((NX_UCHAR)1)

#define	DETECTIONACK_VER00	((NX_UCHAR)0)
#define	DETECTIONACK_VER01	((NX_UCHAR)1)
#define	PROTOCOL_VER		((NX_UCHAR)0x20)
#define	THROUGHPUT			((NX_UCHAR)1)
#define	RELAY_INFO			((NX_UCHAR)0x01)
#define	RELAY_BUF_SIZE		((NX_USHORT)2048)

#endif
/*[EOF]*/
