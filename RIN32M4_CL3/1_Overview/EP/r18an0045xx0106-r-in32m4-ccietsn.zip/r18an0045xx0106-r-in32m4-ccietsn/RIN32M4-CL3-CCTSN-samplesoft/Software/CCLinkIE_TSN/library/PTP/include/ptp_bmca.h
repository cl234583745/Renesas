/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include <ptp_type.h>
#include <ptp_ddt.h>
#include <ptp_Message.h>
#include <ptp_Struct_Port.h>
#include <ptp_Macro.h>

#ifndef __BMCA_H__
#define __BMCA_H__

#define	FOREIGN_MASTER_THRESHOLD	2
#define	FOREIGN_MASTER_TIME_WINDOWS	4

#define	ALLOWED_STEPSREMOVED	255

#define	LOWEST_PRI_FOR_BMCA		255
#define	HIEST_PRI_FOR_BMCA1		0

typedef struct	tagSYSTEMIDENTITY
{
	UCHAR	uchPriority1;
	CLOCKQUALITY stClockQuality;
	UCHAR	uchPriority2;
	CLOCKIDENTITY stClockIdentity;
} SYSTEMIDENTITY;

typedef	struct	tagPRIORITY_VECT
{
	SYSTEMIDENTITY stRootSystemIdentity;
	USHORT		usStepsRemoved;
	PORTIDENTITY stSourcePortIdentity;
	USHORT		usPortNumber;
} PRIORITY_VECT;

typedef	struct tagBMCA_CMP_INF_DATA
{
	UCHAR		uchPriority1;
	CLOCKIDENTITY stClockIdentity;
	CLOCKQUALITY stClockQuality;
	UCHAR		uchPriority2;
	USHORT		usStepsRemoved;
	PORTIDENTITY stSenderPort;
	PORTIDENTITY stReceiverPort;
} BMCA_CMP_INF_DATA;

typedef	struct tagANNO_CMP_INF_DATA
{
	BMCA_CMP_INF_DATA	stBmcaCmpInfoData;
	TIMESTAMP			stAnnoRecvTime;
	SHORT				sCurrentUtcOffset;
	UCHAR				chLogMsgInterVal;
	BYTE				byFlags0;
	BYTE				byFlags1;
	UCHAR				uchTimeSource;
}	ANNO_CMP_INF_DATA;

typedef	struct tagANNOUNCE_CHAIN
{
	struct tagANNOUNCE_CHAIN	*pstAnnounceChain_Foreword;
	struct tagANNOUNCE_CHAIN	*pstAnnounceChain_Backword;
} ANNOUNCE_CHAIN;

typedef	struct tagANNOUNCE_CHAIN_BLOCK
{
	ANNOUNCE_CHAIN				stAnnounceChain;
	ANNO_CMP_INF_DATA			stAnnoCmpInfoData;
} ANNOUNCE_CHAIN_BLOCK;

typedef	struct tagANNOUNCE_INFO
{
	ANNOUNCE_CHAIN				stAnnounceChain;
	ANNO_CMP_INF_DATA			stAnnoCmpInfoData;
} ANNOUNCE_INFO;

typedef	struct tagFOREIGN_MASTER_CHAIN
{
	struct tagFOREIGN_MASTER_CHAIN	*pstForeignMaster_next;
	struct tagFOREIGN_MASTER_CHAIN	*pstForeignMaster_back;
} FOREIGN_MASTER_CHAIN;


typedef	struct tagFOREIGN_MASTER_INFO
{
	FOREIGN_MASTER_CHAIN stForeignMasterChain;
	ANNOUNCE_CHAIN stAnnounceMessageChain;
	USHORT		usAnnMsgCnt;
	struct	tagPORTDATA	*pstPortData;
	BMCA_CMP_INF_DATA stBmcaCmpDat;
} FOREIGN_MASTER_INFO;

typedef	struct tagBMC_GD
{
 	BOOL		blReselect[PTP_MAX_PORT_NUMBER+1];
	BOOL		blSelected[PTP_MAX_PORT_NUMBER+1];
	USHORT		usMasterStepsRemoved;
	BOOL		blLeap61;
	BOOL		blLeap59;
	BOOL		blCurrentUtcOffsetValid;
	BOOL		blPtpTimescale;
	BOOL		blTimeTraceable;
	BOOL		blFrequencyTraceable;
	SHORT		sCurrentUtcOffset;
	UCHAR		uchTimeSource;
	BOOL		blSysLeap61;
	BOOL		blSysLeap59;
	BOOL		blSysCurrentUTCOffsetValid;
	BOOL		blSysPtpTimescale;
	BOOL		blSysTimeTraceable;
	BOOL		blSysFrequencyTraceable;
	SHORT		sSysCurrentUtcOffset;
	UCHAR		uchSysTimeSource;
	PRIORITY_VECT stSystemPriority;
	PRIORITY_VECT stGmPriority;
	PRIORITY_VECT stLastGmPriority;
	BOOL		blPathTraceEnable;
	UCHAR		uchPathTraceCount;

	CLOCKIDENTITY stPathTrace[ALLOWED_STEPSREMOVED];

	BOOL		blExternalPortConfiguration;
	ULONG		ulLastAnnouncePort;

} BMC_GD;

#define	PS_EX_INITIALIZING						1U
#define	PS_EX_FAULTY							2U
#define	PS_EX_DISABLED							3U
#define	PS_EX_LISTENING							4U
#define	PS_EX_PRE_MASTER						5U
#define	PS_EX_MASTER							6U
#define	PS_EX_PASSIVE							7U
#define	PS_EX_UNCALIBRATED						8U
#define	PS_EX_SLAVE								9U
#define	PS_EX_MAX_NORM_STAT						(PS_EX_SLAVE)
#define	PS_EX_BAD								255U


typedef	enum   tagBMCA_1588_EVT
{
	EXT_EV_DESIGNATED_DISABLED =0,
	EXT_EV_DESIGNATED_ENABLED,
	EXT_EV_FAULT_CLEARED,
	EXT_EV_FAULT_DETECTED,
	EXT_EV_QUALIFICATION_TIME_OUT_EXPIRES,
	EXT_EV_ANNOUNCE_RECEIPT_TIMEOUT_EXPIRES,
	EXT_EV_RS_MASTER,
	EXT_EV_RS_SLAVE,
	EXT_EV_RS_PASSIVE,
	EXT_EV_MASTER_SELECTED,
	EXT_EV_MAX
} BMCA_1588_EVT;


typedef	struct tagBMC_1588_GD
{
	UCHAR		uchExtSelectedState[PTP_MAX_PORT_NUMBER+1];
	FOREIGN_MASTER_INFO *pstClkForeignBestClock;
} BMC_1588_GD;


typedef	enum   tagBMCA_INFOIS
{
	DISABLED = 0,
	AGED,
	MINE,
	RECEIVED
} BMCA_INFOIS;

typedef	struct tagPORTBMC_GD
{
	USCALEDNS	stAnnounceReceiptTimeoutTimeInt;
	BOOL		blAnnounceSlowdown;
	USCALEDNS	stOldAnnounceInterval;
	BMCA_INFOIS	enInfoIs;
	PRIORITY_VECT stMasterPriority;
	CHAR		chCurrentLogAnnounceInterval;
	CHAR		chInitialLogAnnounceInterval;
	USCALEDNS	stAnnounceInterval;
	USHORT		usMessageStepsRemoved;
	BOOL		blNewInfo;
	PRIORITY_VECT stPortPriority;
	USHORT		usPortStepsRemoved;
	PTPMSG_ANNOUNCE *pstRcvdAnnouncePtr;
	BOOL		blRcvdMsg;
	BOOL		blUpdtInfo;
	BOOL		blAnnLeap61;
	BOOL		blAnnLeap59;
	BOOL		blAnnCurrentUtcOffsetValid;
	BOOL		blAnnPtpTimescale;
	BOOL		blAnnTimeTraceable;
	BOOL		blAnnFrequencyTraceable;
	SHORT		sAnnCurrentUtcOffset;
	UCHAR		uchAnnTimeSource;
	USHORT		usAnnounceSequenceId;
	TMO_MANAGE_INF_BLK* pstTOAnnounceReceipt;
	PRIORITY_VECT stGmPathPriority;
} PORTBMC_GD;

typedef	struct	tagPORTBMC_1588_GD
{
	FOREIGN_MASTER_CHAIN	stForeignMasterChain;
	FOREIGN_MASTER_INFO		*pstForeignBestClock;
	BMCA_1588_EVT 			enBmca1588Evnet;
	TMO_MANAGE_INF_BLK*		pstTOQualification;
} PORTBMC_1588_GD;


#define EQUAL			0
#define A_B_EQUAL		0
#define A_BETTER_TOPO	1
#define A_BETTER		2
#define B_BETTER		3
#define B_BETTER_TOPO	4

#endif
