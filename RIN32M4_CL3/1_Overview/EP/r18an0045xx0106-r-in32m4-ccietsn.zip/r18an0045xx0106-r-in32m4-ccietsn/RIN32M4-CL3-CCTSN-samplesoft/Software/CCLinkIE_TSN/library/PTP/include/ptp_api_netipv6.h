/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTPAPI_NETIPV6_H__
#define __PTPAPI_NETIPV6_H__

#include <ptp_type.h>

struct ptp_in6_addr
{
	union
	{
#define s6By_addr	ip6Addr.ip6U8
#define s6LAddr 	ip6Addr.ip6U32
#define s6SAddr		ip6Addr.ip6U16
		UCHAR		ip6U8[16];
		USHORT		ip6U16[8];
		ULONG		ip6U32[4];
	} ip6Addr;
};

#define tm_6_ip_copy(srcIpAddrPtr, destIpAddrPtr) \
{ \
	(destIpAddrPtr)->s6LAddr[0] = (srcIpAddrPtr)->s6LAddr[0]; \
	(destIpAddrPtr)->s6LAddr[1] = (srcIpAddrPtr)->s6LAddr[1]; \
	(destIpAddrPtr)->s6LAddr[2] = (srcIpAddrPtr)->s6LAddr[2]; \
	(destIpAddrPtr)->s6LAddr[3] = (srcIpAddrPtr)->s6LAddr[3]; \
}

#define tm_6_ip_copy_structs(srcIpAddr, destIpAddr) \
{ \
	(destIpAddr).s6LAddr[0] = (srcIpAddr).s6LAddr[0]; \
	(destIpAddr).s6LAddr[1] = (srcIpAddr).s6LAddr[1]; \
	(destIpAddr).s6LAddr[2] = (srcIpAddr).s6LAddr[2]; \
	(destIpAddr).s6LAddr[3] = (srcIpAddr).s6LAddr[3]; \
}
#endif
