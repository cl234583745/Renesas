/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRQSEND_1588_GD_H__
#define __PTP_PDRQSEND_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PDRQS {
	ST_PDRQS_NONE	= 0,
	ST_PDRQS_TRANSMIT_INIT,
	ST_PDRQS_SEND_MD_DELAYREQ,
	ST_PDRQS_MAX
} EN_ST_PDRQS;


typedef	enum	tagEN_EV_PDRQS {
	EV_PDRQS_BEGIN = 0,
	EV_PDRQS_FOR_PDLRQSND_RCVMDDLRQ,
	EV_PDRQS_CLOSE,
	EV_PDRQS_EVENT_MAX
} EN_EV_PDRQS;


typedef	struct tagPDRQSENDSM_1588_GD
{
	EN_ST_PDRQS		enStatusPDRQS;
	BOOL			blRcvdMDDelayReq;
	MDDELAYREQ*		pstRcvdMDDReqRcvPtr;
	MDDELAYREQ*		pstTxMDDReqSndPtr;
} PDRQSENDSM_1588_GD;	



#endif


