/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "ccienx_api.h"
#include "CYC_common.h"
#include "nx_frame_cyclic.h"
#include "SNMP_mib_api.h"
#include "ccienx_app_supply.h"

#define	INIT_SELFSTSW_VER		((NX_UCHAR)(0x00))
#define	INIT_SELFSTSW_SET		((NX_UCHAR)(0x03))
#define	BIT_SELFSTSW_APPINFO	((NX_UCHAR)NX_BIT3)

#define	BIT_STSW_CYC_CYCSTOP	((NX_UCHAR)0x01)
#define	BIT_STSW_CYC_DLINKSTOP	((NX_UCHAR)0x08)
#define	BIT_STSW_CYC_RSVSTA		((NX_UCHAR)0x10)

#define	BIT_ERR_APPERR			((NX_UCHAR)0x03)

NX_USHORT usCYC_GetSelfStsW_Cyc ( NX_VOID );
NX_UCHAR uchCYC_GetSelfStsW_Err ( NX_VOID );
NX_UCHAR uchCYC_GetSelfStsW_Set ( NX_VOID );
NX_UCHAR uchCYC_GetSelfStsW_AppInfo ( NX_VOID );

NX_VOID vCYC_InitStsW ( NX_VOID )
{
	
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_VER] = INIT_SELFSTSW_VER;
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_SET] = INIT_SELFSTSW_SET;
	
	return;
}

NX_USHORT usCYC_GetSelfStsW_Cyc ( NX_VOID )
{
	NX_UCHAR	uchCyc		=	NX_ZERO;
	
	
	if ((gstNET.stCyc.usRsvSta == NX_ON) || (gstNET.stCyc.usStopDLink == NX_ON)) {
		uchCyc	|=	BIT_STSW_CYC_CYCSTOP;
	}
	
	
	
	if (gstNET.stCyc.usStopDLink == NX_ON) {
		uchCyc	|=	BIT_STSW_CYC_DLINKSTOP;
	}
	
	if (gstNET.stCyc.usRsvSta == NX_ON) {
		uchCyc	|=	BIT_STSW_CYC_RSVSTA;
	}
	
	return uchCyc;
}

NX_UCHAR uchCYC_GetSelfStsW_Err ( NX_VOID )
{
	NX_UCHAR	uchErr			=	NX_ZERO;
	
	uchErr	|=	(NX_UCHAR)(gstCycCtrl.ulAppErrSts & BIT_ERR_APPERR);
	
	
	return uchErr;
}


NX_VOID vCYC_UpdateSelfStsW ( NX_VOID )
{
	NX_UN_USHORT	stCyc;
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_SET]		=	uchCYC_GetSelfStsW_Set();
	
	stCyc.us	=	NX_ZERO;
	
	stCyc.us										=	usCYC_GetSelfStsW_Cyc();
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_CYC_L]	=	stCyc.uc.l;
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_CYC_H]	=	stCyc.uc.h;
	
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_ERR]		=	uchCYC_GetSelfStsW_Err();
	
	
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_APPINFO]	= uchCYC_GetSelfStsW_AppInfo();
	
	return;
}

NX_VOID vCYC_SetSelfStsW (
	NX_ULONG	ulTrnSide
)
{
	NX_ULONG	ulBaseAddr = gaulBaseAddrTbl[ulTrnSide];
	NX_UCHAR	*puchData;
	NX_USHORT	usPduNum = NX_ZERO;
	NX_USHORT	usLoop   = NX_ZERO;
	NX_USHORT	usDataNo = NX_ZERO;

	for (usPduNum = NX_ZERO; usPduNum<gstCycTrnAddr.usStswNum; usPduNum++) {
		puchData = (NX_UCHAR*)(ulBaseAddr + gstCycTrnAddr.stStsW[usPduNum].ulAddr);

		for (usLoop = NX_ZERO; usLoop<gstCycTrnAddr.stStsW[usPduNum].usSize; usLoop++) {
			puchData[usLoop] = gstCycCtrl.auchSelfStsW[usDataNo];
			usDataNo++;
		}
	}
}


NX_VOID vCYC_ForceWdtErrStsW ( NX_VOID )
{
	NX_ULONG	ulTrnSide	=	(NX_ULONG)NX_ZERO;
	
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_ERR]		=	(NX_UCHAR)usNX_GetWdtErrSts();
	
	vCYC_SetSelfStsW(TRN_SIDE_A);
	vCYC_SetSelfStsW(TRN_SIDE_B);
	vCYC_SetSelfStsW(TRN_SIDE_C);
	
	return;
}

NX_UCHAR uchCYC_GetSelfStsW_Set ( NX_VOID )
{
	NX_UCHAR	uchInfoSetEnable;
	NX_USHORT	usAppInfoEnable;
	
	uchInfoSetEnable		= INIT_SELFSTSW_SET;
	
	usAppInfoEnable			= usNX_GetAppInfoEnable();
	if (NX_APPINFO_ENBL == usAppInfoEnable) {
		uchInfoSetEnable	|= BIT_SELFSTSW_APPINFO;
	}
	else {
	}
	
	return uchInfoSetEnable;
}

NX_UCHAR uchCYC_GetSelfStsW_AppInfo ( NX_VOID )
{
	NX_UCHAR	uchAppInfo	=	NX_UC_ZERO;
	NX_UCHAR	uchAppInfoSyncSts;
	
	uchAppInfoSyncSts		= uchNX_GetAppInfo_SyncSts();
	if (NX_APPINFO_SYNC == uchAppInfoSyncSts) {
		uchAppInfo			|= BIT_APPINFO_NWSYNC;
	}
	else {
	}
	
	return uchAppInfo;
}
/*[EOF]*/
