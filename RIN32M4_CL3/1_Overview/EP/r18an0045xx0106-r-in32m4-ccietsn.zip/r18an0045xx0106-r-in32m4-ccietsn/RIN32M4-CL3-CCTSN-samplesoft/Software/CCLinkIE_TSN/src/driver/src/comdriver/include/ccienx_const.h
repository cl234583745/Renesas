/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_CONST_H_INCLUDE__
#define __CCIENX_CONST_H_INCLUDE__
#include "ccienx_type.h"


#define	NX_ASIC_ES2				(1)

#define	NX_HWTEST_ES2			(0)

#define	REC_TSN_INF				(0)

#define	TSN_LOG_ADJUST			(0)

#define	TSN_LOG_FRAME			(0)
#define	GENERAL_PURPOSE_DATASAVE	(0)

#define	NX_NULL					((NX_VOID*)0)
#define	NX_ZERO					(0)
#define	NX_ONE					(1)
#define	NX_TWO					(2)
#define	NX_THREE				(3)
#define	NX_MINUS_ONE			(-1)
#define	NX_ON					(1)
#define	NX_OFF					(0)
#define	NX_OK					((NX_LONG)0)
#define	NX_NG					((NX_LONG)-1)
#define	NX_C_ZERO				((NX_CHAR)0x00)
#define	NX_S_ZERO				((NX_SHORT)0x0000)
#define	NX_L_ZERO				((NX_LONG)0x00000000)
#define	NX_UC_ZERO				((NX_UCHAR)0x00)
#define	NX_US_ZERO				((NX_USHORT)0x0000)
#define	NX_UL_ZERO				((NX_ULONG)0x00000000)
#define	NX_UL_OK				((NX_ULONG)0)
#define	NX_UL_NG				((NX_ULONG)0xFFFFFFFF)
#define	NX_US_OK				((NX_USHORT)0)
#define	NX_US_NG				((NX_USHORT)0xFFFF)
#define	NX_ENABLE				(1)

#define	NX_SHIFT0				(0)
#define	NX_SHIFT1				(1)
#define	NX_SHIFT2				(2)
#define	NX_SHIFT3				(3)
#define	NX_SHIFT4				(4)
#define	NX_SHIFT5				(5)
#define	NX_SHIFT6				(6)
#define	NX_SHIFT7				(7)
#define	NX_SHIFT8				(8)
#define	NX_SHIFT9				(9)
#define	NX_SHIFT11				(11)
#define	NX_SHIFT13				(13)
#define	NX_SHIFT16				(16)
#define	NX_SHIFT17				(17)
#define	NX_SHIFT24				(24)
#define	NX_SHIFT32				(32)

#define	NX_BIT0					(0x00000001U)
#define	NX_BIT1					(0x00000002U)
#define	NX_BIT2					(0x00000004U)
#define	NX_BIT3					(0x00000008U)
#define	NX_BIT4					(0x00000010U)
#define	NX_BIT5					(0x00000020U)
#define	NX_BIT6					(0x00000040U)
#define	NX_BIT7					(0x00000080U)
#define	NX_BIT8					(0x00000100U)
#define	NX_BIT10				(0x00000400U)
#define	NX_BIT12				(0x00001000U)
#define	NX_BIT14				(0x00004000U)
#define	NX_BIT30				(0x40000000U)
#define	NX_BIT31				(0x80000000U)

#define	NX_BIT00_07				((NX_ULONG)0x000000FFU)
#define	NX_BIT08_15				((NX_ULONG)0x0000FF00U)
#define	NX_BIT00_15				((NX_ULONG)0x0000FFFFU)
#define	NX_BIT08_31				((NX_ULONG)0xFFFFFF00U)
#define	NX_BIT00_02				((NX_ULONG)0x00000007U)
#define NX_BIT03_29				((NX_ULONG)0x3FFFFFF8U)
#define	NX_BIT00_46				(0x00007FFFFFFFFFFFULL)

#define	NX_REMAIND_0			(0)
#define	NX_REMAIND_2			(2)
#define	NX_REMAIND_4			(4)

#define	NX_APPMODE_UNSYNC		((USHORT)0)
#define	NX_APPMODE_SYNC			((USHORT)1)

#define	NX_LED_OFF				((NX_USHORT)0)
#define	NX_LED_ON				((NX_USHORT)1)
#define	NX_LED_BLINK_1S			((NX_USHORT)2)
#define	NX_LED_BLINK_500MS		((NX_USHORT)3)
#define	NX_LED_BLINK_200MS		((NX_USHORT)4)

#define	NX_SLMP_FRAME_EXSI		((NX_USHORT)0)
#define	NX_SLMP_FRAME_NONE		((NX_USHORT)1)

#define	NX_SLMP_FRAME_USE		((NX_USHORT)0)
#define	NX_SLMP_FRAME_NO_USE	((NX_USHORT)1)
#define	NX_SLMP_FRAME_FAULT		((NX_USHORT)2)

#define	NX_SLMP_FTYPE_3E_REQ	((NX_USHORT)(0x0050))
#define	NX_SLMP_FTYPE_4E_REQ	((NX_USHORT)(0x0054))
#define	NX_SLMP_FTYPE_5E_REQ	((NX_USHORT)(0x0055))
#define	NX_SLMP_FTYPE_6E_REQ	((NX_USHORT)(0x0068))
#define	NX_SLMP_FTYPE_3E_RES	((NX_USHORT)(0x00D0))
#define	NX_SLMP_FTYPE_4E_RES	((NX_USHORT)(0x00D4))
#define	NX_SLMP_FTYPE_5E_RES	((NX_USHORT)(0x00D5))
#define	NX_SLMP_FTYPE_6E_RES	((NX_USHORT)(0x00E8))

#define	NX_PORTCONNECT_STRAIGHT	((NX_USHORT)0)
#define	NX_PORTCONNECT_CROSS	((NX_USHORT)1)


#define	NX_RESET_ON				(0x0001)


#define	NX_IP_OK				((NX_ULONG)0)
#define	NX_IP_NG_IP_RNG			((NX_ULONG)1)
#define	NX_IP_NG_SUBNET_RNG		((NX_ULONG)2)
#define	NX_IP_NG_SUBNET_VAL		((NX_ULONG)3)
#define	NX_IP_NG_BROAD			((NX_ULONG)4)
#define	NX_IP_NG_IP_ZERO		((NX_ULONG)5)
#define	NX_IP_NG_TSN_BAN		((NX_ULONG)6)
#define	NX_LINKSPD_STA_1G		((NX_USHORT)0)
#define	NX_LINKSPD_STA_100M		((NX_USHORT)1)

#define	NX_LINKSPD_CONF_1G_AUTO	((NX_ULONG)0)
#define	NX_LINKSPD_CONF_100M	((NX_ULONG)1)

#define	NX_AUTHENTICATION_CLS_B		((NX_USHORT)0)
#define	NX_AUTHENTICATION_CLS_A		((NX_USHORT)1)

#define	NX_LIB_MODE_NORMAL		((NX_USHORT)0)
#define	NX_LIB_MODE_FASTIO		((NX_USHORT)1)
#define	NX_LIB_MODE_FASTIO2		((NX_USHORT)2)
#define	NX_LIB_MODE_FASTIO3		((NX_USHORT)3)
#define	NX_LIB_MODE_SIZE		((NX_USHORT)4)
#define	NX_TIMESLOT_SIZE			(8)
#define	NX_WDC_UL_OFFSET_NOCHECK	(0xFFFFU)
#define	NX_WDC_DL_OFFSET_NOCHECK	(0xFFFFU)
#define	NX_TOPOLOGY_UNKNOWN		((NX_ULONG)0)
#define	NX_TOPOLOGY_NOT_RING  	((NX_ULONG)1)
#define	NX_TOPOLOGY_RING      	((NX_ULONG)2)
#define CONVERT_NS_TO_MS	((NX_ULONGLONG)1000000)
#define	NX_WDCFUNC_DSBL      	((NX_USHORT)0)
#define	NX_WDCFUNC_ENBL      	((NX_USHORT)1)

#define NX_SND_REG_NO_STSW		((NX_USHORT)0)
#define NX_SND_REG_NO_RX		((NX_USHORT)1)
#define NX_SND_REG_NO_RWR		((NX_USHORT)2)
#ifdef SAFETY_PDU_ENABLE
#define NX_SND_REG_NO_SPDUX		((NX_USHORT)3)
#endif

#define NX_RCV_REG_NO_RY		((NX_USHORT)0)
#define NX_RCV_REG_NO_RWW		((NX_USHORT)1)
#ifdef SAFETY_PDU_ENABLE
#define NX_RCV_REG_NO_SPDUY		((NX_USHORT)2)
#endif

#define	NX_APPINFO_DSBL			((NX_USHORT)0)
#define	NX_APPINFO_ENBL			((NX_USHORT)1)

#define	NX_APPINFO_UNSYNC		((NX_UCHAR)0)
#define	NX_APPINFO_SYNC			((NX_UCHAR)1)

#define	NX_MASTER_MANAGE		((NX_ULONG)0)
#define	NX_MASTER_CONTROL		((NX_ULONG)1)
#define	NX_SENDERINFO_NUM		((NX_ULONG)2)

#define	NX_TIMESYNC_NOCHK		((NX_ULONG)0)
#define	NX_TIMESYNC_CHK_OK		((NX_ULONG)1)
#define	NX_TIMESYNC_CHK_NG		((NX_ULONG)2)

#define	NX_APPSYNCSIG_DS		((NX_ULONG)0)
#define	NX_APPSYNCSIG_EN		((NX_ULONG)1)

#endif
/*[EOF]*/
