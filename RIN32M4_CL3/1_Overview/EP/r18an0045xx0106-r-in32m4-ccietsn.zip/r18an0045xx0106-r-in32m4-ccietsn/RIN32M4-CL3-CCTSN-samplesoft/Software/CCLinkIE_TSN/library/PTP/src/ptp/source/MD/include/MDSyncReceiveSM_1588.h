/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCRECEIVESM_1588_H__
#define __MDSYNCRECEIVESM_1588_H__

#define IsDecMDSyncTwoStep_1588(a)	MPTPMSG_H_GET_FLAGS0_TWOSTEP(&a->stSync_1588.stHeader)

#ifdef __cplusplus
extern "C" {
#endif

VOID MDSyncReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDSyncReceiveSM_00_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_01_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_02_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_03_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_04_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_05_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_06_1588(PORTDATA* pstPort);
VOID MDSyncReceiveSM_NP_1588(PORTDATA* pstPort);

VOID MDSyncReceiveSM_03_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncReceiveSM_04_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncReceiveSM_05_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
VOID MDSyncReceiveSM_03_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncReceiveSM_04_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID MDSyncReceiveSM_05_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL MDSynRcv_Discard_1588     (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynRcv_WtFrFollowUp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynRcv_WtFrSyncTwo_1588 (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynRcv_WtFrSyncOne_1588 (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDSync_1588    (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL ConMDFollowUp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

VOID SetMDTwoSyncMgEgresTmstmp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetMDOneSyncMgEgresTmstmp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

VOID computeMDSyncRateRatio_1588 (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetCmptMDSyncRatioStack_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL CalMDSyncRateRatio_1588     (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort, DOUBLE* pdbRateRatio);

BOOL SetMDSyncTwoReceive_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetMDSyncOneReceive_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxMDSyncReceive_1588    (MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
