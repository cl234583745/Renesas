/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"





NX_VOID vINIT_commonip_wd ( NX_VOID )
{
	NGN_WDT_REG->R_RE_WDTCOUNT	= (NX_ULONG)0xFFFFFFFF;

	NGN_WDT_REG->R_RE_WDTCNT	= (NX_ULONG)0x00000000;

	NGN_WDT_REG->R_RE_WDTRST	= (NX_ULONG)0x00000001;

	return;
}

/*[EOF]*/
