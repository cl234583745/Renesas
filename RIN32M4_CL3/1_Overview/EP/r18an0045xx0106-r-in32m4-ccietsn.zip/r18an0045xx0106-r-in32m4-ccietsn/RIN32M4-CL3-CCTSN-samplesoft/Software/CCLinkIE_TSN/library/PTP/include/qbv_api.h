/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

 
#ifndef QBV_API_H
#define QBV_API_H
 
#include "ptp_type.h"
#include "ptp_Macro.h"
#include "ptp_ddt.h"
#include "ptp_ClockTarget_API.h"
#include "qbv_Macro.h"

typedef void(*QBV_USER_FAILEDCB)(INT nErrorCode, UCHAR uchPort, UCHAR uchGateIdNo);
typedef void(*QBV_USER_GOPENCB)(UCHAR uchPort, UCHAR uchGateIdNo);
#ifndef	_SENDTIMESCB_
#define _SENDTIMESCB_
typedef void(*SENDTIMESCB)(INT nErrorCode, UCHAR uchPort, EXTENDEDTIMESTAMP* pstTimeStamp, VOID* pvLinkId);
#endif
typedef struct tagTIME_EXTENTION {
	LONG		lHighTimeBit;
	ULONG		ulLowTimeBit;
}TIME_EXTENTION;

typedef struct tagQUE_MAXSDU {
	ULONG		ulQueMaxSDU;
	ULONG		ulTransOverrun;
}QUE_MAXSDU;

typedef struct tagGATE_CONTENT {
	BYTE				byGateState;
	BYTE				byReserve;
	TIME_EXTENTION		stTimeInterval;
}GATE_CONTENT;

typedef struct tagGATE_PARATBL {
	QUE_MAXSDU				stQueMaxSDU[MAX_TRAFFIC_CLASS];
	BOOL					blGateEnabled;
	BYTE					byAdmGateStates;
	BYTE					byOpeGateStates;
	ULONG					ulAdmContListLen;
	ULONG					ulOpeContListLen;
	GATE_CONTENT			stAdmGateCont[MAX_GATE_ENTRY];
	GATE_CONTENT			stOpeGateCont[MAX_GATE_ENTRY];
	TIME_EXTENTION			stAdmCycleTime;
	TIME_EXTENTION			stOpeCycleTime;
	ULONG					ulAdmCycleTimeExt;
	ULONG					ulOpeCycleTimeExt;
	EXTENDEDTIMESTAMP		stAdmBaseTime;
	EXTENDEDTIMESTAMP		stOpeBaseTime;
	BOOL					blConfigChange;
	EXTENDEDTIMESTAMP		stConfChangTime;
	LONG					lTickGranul;
	EXTENDEDTIMESTAMP		stCurrentTime;
	BOOL					blConfigPending;
	LONG					lConfChangErr;
	LONG					lSupportListMax;
	ULONG					ulMaxFrameTransTime;
	BOOL					blCycleStart;
	BOOL					blCycleExec;
	EXTENDEDTIMESTAMP		stCycleStartTime;
	TIME_EXTENTION			stExitTimer;
	LONG					lListPointer;
	BOOL					lNewConfigCT;
	EXTENDEDTIMESTAMP		stBeforeTime;
	QBV_USER_GOPENCB		stUserGOpenCB[MAX_GATE_ENTRY];
	INT						nSendCompWaitCT;
	USHORT					usListConfStat;
	USHORT					usCycleTimeStat;
	USHORT					usListExecStat;
	
	USHORT					usClassQueMax[MAX_TRAFFIC_CLASS];
}GATE_PARATBL;

typedef struct tagTRACLS_ENTRY {
	struct tagTRACLS_ENTRY*		pstTraClsNext;
	UCHAR						uchPort;
	UCHAR						uchTraClsNo;
	UCHAR*						puchFramPtr;
	USHORT						usFramLen;
	VOID*						pvPacketId;
	SENDTIMESCB					stSendCBFunc;
	VOID*						pvLinkId;
}TRACLS_ENTRY;

typedef struct tagTRACLS_QUEUE {
	struct tagTRACLS_ENTRY*		pstTraClsNext;
	struct tagTRACLS_ENTRY*		pstTraClsTail;
	ULONG						ulTotalDataSize;
} TRACLS_QUEUE;

typedef struct tagQBV_INFTBL {
	ULONG				ulMagicNo;
	USHORT				usMaxPort;
	QBV_USER_FAILEDCB	stUserFailedCB;
} QBV_INFTBL;

typedef struct tagQBV_SENDPAR {
	UCHAR			uchPort;
	UCHAR 			uchTraClsNo;
	UCHAR*			puchFramPtr;
	USHORT			usFramLen;
	VOID*			pvPacketId;
	SENDTIMESCB		stSendCBFunc;
	VOID*			pvLinkId;
}QBV_SENDPAR;

INT qbv_init(USHORT usMaxPort);
INT qbv_set_gatepar(UCHAR uchPort, USHORT usParID, const VOID* puchParValuePtr, USHORT usParLength);
INT qbv_get_gatepar(UCHAR uchPort, USHORT usParID, VOID* puchParValuePtr, USHORT* pusParLength);
INT qbv_open(void);
INT qbv_close(void);
INT qbv_send(UCHAR uchPort, UCHAR uchTraClsNo, UCHAR* puchFramPtr, USHORT usFrameLen,
										VOID* pvPacketId, SENDTIMESCB stSendCBFunc, VOID* pvLinkId);
INT qbv_multi_send(QBV_SENDPAR* pstSendPar, USHORT* pusParLen);
INT qbv_RegisterFailedCB(QBV_USER_FAILEDCB pstUserFailedCB);
INT qbv_queue_clear(UCHAR uchPort, UCHAR uchTraClsNo);
INT qbv_RegisterGateOpenCB(UCHAR uchPort, UCHAR uchGateIdNo, QBV_USER_GOPENCB pstUserGateOpenCB);

VOID qbv_Tick(void);

VOID qbv_SendComp(UCHAR uchPort);
INT ethwrap_send(UCHAR uchPort, UCHAR* puchFramPtr, USHORT usFramLen);

#endif
