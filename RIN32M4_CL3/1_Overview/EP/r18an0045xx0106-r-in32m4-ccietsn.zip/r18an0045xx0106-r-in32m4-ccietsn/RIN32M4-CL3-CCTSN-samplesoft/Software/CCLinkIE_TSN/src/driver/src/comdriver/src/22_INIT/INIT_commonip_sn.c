/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"







NX_VOID vINIT_commonip_sn ( NX_VOID )
{
	NGN_SN_REG->R_SNTM0				=	(NX_ULONG)0x00000000;
	NGN_SN_REG->R_SNTM1				=	(NX_ULONG)0x00000000;
	NGN_SN_REG->R_SNINTM.DATA		=	0x3FF37F7F;
	NGN_SN_REG->R_SNINT.DATA		=	0x3FF37F7F;
	NGN_SN_REG->R_SNSDMN.DATA		=	0x00000080;
	



	

	
	NGN_SN_REG->R_SNRLYCTR.DATA		=	(NX_ULONG)0x00000003;

	return;
}

/*[EOF]*/
