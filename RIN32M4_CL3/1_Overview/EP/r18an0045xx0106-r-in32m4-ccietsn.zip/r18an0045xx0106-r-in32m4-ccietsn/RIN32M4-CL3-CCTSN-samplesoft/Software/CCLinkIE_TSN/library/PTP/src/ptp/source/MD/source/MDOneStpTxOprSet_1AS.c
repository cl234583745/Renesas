/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING
#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0

#ifdef	PTP_USE_IEEE802_1

#include "MDOneStpTxOprSet.h"
#include "MDOneStpTxOprSet_1AS.h"

VOID (*const OneStepTxOperSetSM_1AS_Matrix[DMDOSTO_STATUS_MAX][DMDOSTO_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_NP_1AS},
	{&OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_02_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_00_1AS},
	{&OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_02_1AS, &OneStepTxOperSetSM_03_1AS, &OneStepTxOperSetSM_00_1AS},
	{&OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_01_1AS, &OneStepTxOperSetSM_NP_1AS, &OneStepTxOperSetSM_03_1AS, &OneStepTxOperSetSM_00_1AS}
};

VOID OneStepTxOperSetSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	ONESTPTXOPRSET_EV	enEvt = MDOSTO_E_EVENT_MAX;
	ONESTPTXOPRSET_ST	enSts = MDOSTO_STATUS_MAX;
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET_1AS, PTP_LOGVE_82080001);
	enEvt = GetOneStpTxOprSetEvent(usEvent, pstPort);

	enSts = GetOneStpTxOprSetStatus(pstPort);

	if ((enSts != MDOSTO_STATUS_MAX) && (enEvt != MDOSTO_E_EVENT_MAX))
	{
		(*OneStepTxOperSetSM_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET_1AS, PTP_LOGVE_82000006);
	}
	return;
}

VOID OneStepTxOperSetSM_00_1AS(PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "OneStepTxOperSetSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	OneStepTxOpSet_NotEnabled_1AS(pstGbl, pstPort);
	SetOneStpTxOprSetStatus(MDOSTO_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("OneStepTxOperSetSM_00_1AS::-\n") );

	return;
}

VOID OneStepTxOperSetSM_01_1AS(PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;
	BOOL				blRet;
	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	blRet = OneStepTxOpSet_NotEnabled_1AS(pstGbl, pstPort);
	if (blRet)
	{
		SetOneStpTxOprSetStatus(MDOSTO_NOT_ENABLED, pstPort);
	}
	else
	{
		OneStepTxOpSet_Initialize_1AS(pstGbl, pstPort);
		SetOneStpTxOprSetStatus(MDOSTO_INITIALIZE, pstPort);
	}
	return;
}

VOID OneStepTxOperSetSM_02_1AS(PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	OneStepTxOpSet_Initialize_1AS(pstGbl, pstPort);
	SetOneStpTxOprSetStatus(MDOSTO_INITIALIZE, pstPort);
	return;
}

VOID OneStepTxOperSetSM_03_1AS(PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	if (pstGbl->blRcvdSignalingMsg4 == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET_1AS, PTP_LOGVE_82000009);
		OneStepTxOpSet_NotEnabled_1AS(pstGbl, pstPort);
		SetOneStpTxOprSetStatus(MDOSTO_NOT_ENABLED, pstPort);
		return;
	}
	if (pstGbl->pstRcvdSignaling == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET_1AS, PTP_LOGVE_8200000A);
		OneStepTxOpSet_NotEnabled_1AS(pstGbl, pstPort);
		SetOneStpTxOprSetStatus(MDOSTO_NOT_ENABLED, pstPort);
		return;
	}

	OneStepTxOpSet_SetOneStep_1AS(pstGbl, pstPort);
	SetOneStpTxOprSetStatus(MDOSTO_SET_ONE_STEP_OPER, pstPort);
	return;
}

VOID OneStepTxOperSetSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET_1AS, PTP_LOGVE_82000007);
	return;
}


BOOL OneStepTxOpSet_NotEnabled_1AS(OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS* pstPortDS = &pstPort->stPort_1AS_DS;

	if (pstPortDS->blUseMgtSettableOneStepTxOper)
	{
		pstPortDS->blCurrentOneStepTxOper
			= pstPortDS->blMgtSettableOneStepTxOper;
		pstPortDS->blOneStepTxOper
			= ((pstPortDS->blCurrentOneStepTxOper) && (pstPortDS->blOneStepTransmit));
	}

	pstSmGbl->blRcvdSignalingMsg4 = FALSE;

	return pstPortDS->blUseMgtSettableOneStepTxOper;
}

VOID OneStepTxOpSet_Initialize_1AS(OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS* pstPortDS = &pstPort->stPort_1AS_DS;

	pstPortDS->blCurrentOneStepTxOper
		= pstPortDS->blInitialOneStepTxOper;

	pstPortDS->blOneStepTxOper
		= ((pstPortDS->blCurrentOneStepTxOper) && (pstPortDS->blOneStepTransmit));

	pstSmGbl->blRcvdSignalingMsg4 = FALSE;
	return;
}

VOID OneStepTxOpSet_SetOneStep_1AS(OSTOSETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS* pstPortDS = &pstPort->stPort_1AS_DS;

	PTPMSG_SIGNALING_1AS* pstMsg = &pstSmGbl->pstRcvdSignaling->stSignaling_1AS;


	if ( MPTPM_ISFLAG_INTERVAL_ONESTEP(&pstMsg->stIntervalReq_TLV) )
	{
		pstPortDS->blCurrentOneStepTxOper = TRUE;
	}else{
		pstPortDS->blCurrentOneStepTxOper = FALSE;
	}

	pstPortDS->blOneStepTxOper
		= ((pstPortDS->blCurrentOneStepTxOper) && (pstPortDS->blOneStepTransmit));

	pstSmGbl->blRcvdSignalingMsg4 = FALSE;
	return;
}

#endif
#endif
