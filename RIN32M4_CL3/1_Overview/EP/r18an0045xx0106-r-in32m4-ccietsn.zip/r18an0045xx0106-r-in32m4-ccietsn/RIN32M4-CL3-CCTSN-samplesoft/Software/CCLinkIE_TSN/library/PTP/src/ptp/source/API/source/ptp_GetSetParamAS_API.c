/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"
#include "ptp_tsn_Wrapper.h"

#include "PTP_GlobalData.h"
#include "ptp_api.h"
#include "ptp_MemManage.h"

#include "ManagementSM.h"


#define		PTP_PARA_BUFF_SIZE		32






INT	ptp_get_para_AS( USHORT usParamId_AS, 
		    		 UCHAR  uchDomainNumber,
					 UCHAR  uchPortNum, 
					 UCHAR *puchInfo, 
					 USHORT usInfoBufSize )
{
	CLOCKDATA*	pstClockData	= gpstClockDataHPtr;
	INT			nRet = RET_ENOERR;
	UCHAR		uchInfo[PTP_PARA_BUFF_SIZE];

#if 1
	if (!IS_PTP_STARTUP())
	{
		return RET_ESTATE;
	}
#endif
	if (pstClockData == NULL)
	{
		return RET_ESTATE;
	}
	if (usInfoBufSize > PTP_PARA_BUFF_SIZE)
	{
		return RET_EINVAL;
	}
	if (pstClockData->stClock_GD.enSupportPTPType != ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		return RET_ESTATE;
	}
	nRet = ptp_SystemSemLockWait(pstClockData);
	if (nRet != RET_ENOERR)
	{
		return RET_ESTATE;
	}

	nRet = Management_AS( MGTAS_ACTION_GET, 
						  usParamId_AS, 
						  uchDomainNumber, 
						  (USHORT)uchPortNum, 
						  uchInfo, 
						  usInfoBufSize );
	if ((nRet == RET_ENOERR))
	{
		tsn_Wrapper_MemCpy( puchInfo, uchInfo, (size_t)usInfoBufSize );
	}

	(VOID)ptp_SystemSemUnLock(pstClockData);

	return nRet;
}

#ifndef	PTP_RESTRICT_GETSET
INT	ptp_set_para_AS( USHORT usParamId_AS, 
		    		 UCHAR  uchDomainNumber,
					 UCHAR  uchPortNum, 
					 UCHAR *puchInfo, 
					 USHORT usInfoBufSize )
{
	CLOCKDATA*	pstClockData	= gpstClockDataHPtr;
	INT			nRet;

#if 1
	if (!IS_PTP_STARTUP())
	{
		return RET_ESTATE;
	}
#endif
	if (pstClockData == NULL)
	{
		return RET_ESTATE;
	}
	if (usInfoBufSize > PTP_PARA_BUFF_SIZE)
	{
		return RET_EINVAL;
	}
	if (pstClockData->stClock_GD.enSupportPTPType != ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		return RET_ESTATE;
	}
	nRet = ptp_SystemSemLockWait(pstClockData);
	if (nRet != RET_ENOERR)
	{
		return RET_ESTATE;
	}

	nRet = Management_AS( MGTAS_ACTION_SET, 
						  usParamId_AS, 
						  uchDomainNumber, 
						  (USHORT)uchPortNum, 
						  (UCHAR*)puchInfo, 
						  usInfoBufSize );

	(VOID)ptp_SystemSemUnLock(pstClockData);

	return nRet;
}
#endif
