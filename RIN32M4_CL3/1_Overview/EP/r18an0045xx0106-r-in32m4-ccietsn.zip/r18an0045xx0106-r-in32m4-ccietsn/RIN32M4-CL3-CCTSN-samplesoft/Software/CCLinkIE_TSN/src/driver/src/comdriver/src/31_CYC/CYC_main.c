/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "ccienx_api.h"
#include "NGN_ASIC.h"
#include "nx_frame_cyclic.h"
#include "nx_mpu_common.h"
#include "NMG_common.h"
#include "CYC_common.h"
#include "cyclic_address.h"
#include "ccienx_app_supply.h"
#include "INTR_api.h"
#include "nx_common_const.h"
#include "USN_api.h"
#include "TSN_api.h"
#include "NMG_api.h"
#include "LSM_api.h"
#include "SYNC_api.h"
#include "PHY_api.h"
#include "CYC_api.h"
#include "ACM_api.h"
#include "ccienx_const_ex.h"

#define	SWITCH_SWRD_HWWRCMP			(NX_ULONG)(0x00000001)
#define	CYCRCVFLG_ALLOFF			(NX_ULONG)(0x00000000)
#define	CYCALIVE_ALLOFF				(NX_ULONG)(0x00000000)
#define	RNAPERF2_1_ALLCLR			(NX_ULONG)(0x000000FF)
#define	RNAPERF2_2_ALLCLR			(NX_ULONG)(0x00000000)
															

#define	RNCBKHMD_ALL_MANUAL			(NX_ULONG)(0x00000000)
#define	RNCBKHMD_ALL_AUTO			(NX_ULONG)(0x000000AA)

#define	BIT_APPERR_CYCDATADIS		(NX_ULONG)(0x00000010)
#define	BIT_APPERR_LINKDOWN			(NX_ULONG)(0x00000020)
#define	BIT_APPERR_CYCSTOP			(NX_ULONG)(0x00000008)
#define	BIT_APPERR_WDTERR			(NX_ULONG)(0x00000080)
#define	BIT_APPERR_APPRUN			(NX_ULONG)(0x00000001)
#define	BIT_APPERR_RSVSTA			(NX_ULONG)(0x00000020)
#define	FASTIO_APPERR_TRN_MSK		(NX_ULONG)(0x00000000)
#define	BIT_APPERR_RCV_VALID		(BIT_APPERR_APPRUN | BIT_APPERR_CYCDATADIS | BIT_APPERR_WDTERR)
#define	APPERR_EXT_STA1				((NX_ULONG)0x000000FF)
#define	MSK_ALVERRCNT				((NX_ULONG)0x0000000F)

NX_STATIC NX_ULONG		gulSwSucceed;
NX_STATIC NX_ULONG		gulSyncNoRcvCnt;
NX_STATIC NX_ULONG		gulErrCycle;

NX_ULONG ulCYC_DetectComEst ( NX_VOID );
NX_ULONG ulCYC_DetectComEstSync ( NX_ULONG );
NX_ULONG ulCYC_DetectAliveErr ( NX_VOID );
NX_ULONG ulCYC_DetectAliveErrSync ( NX_ULONG );
NX_ULONG ulCYC_SwitchSwReadSide ( NX_ULONG* );
NX_ULONG ulCYC_ChkCycRcvSync (NX_ULONG, NX_ULONG);
NX_ULONG ulCYC_ChkCycRcvFlg (NX_ULONG );
NX_ULONG ulCYC_ChkCycAlive ( NX_ULONG );
NX_VOID vCYC_ClrAllCycFlg ( NX_VOID );
NX_ULONG ulCYC_ReadClrAppErrFW ( NX_VOID );
NX_VOID vCYC_AnalyzeAppErrFW ( NX_VOID );
NX_STATIC NX_VOID vCYC_ExecGetCyclicRcvSts ( NX_CYC_RCV_STS* );

NX_ULONG ulCYC_SelectUnusedSide ( NX_VOID );
NX_VOID vCYC_UpdateSubPayloadHeader (NX_ULONG, NX_UCHAR);
NX_VOID vCYC_UpdateWriteLatestSide ( NX_VOID );
NX_VOID vCYC_UpdateAllSubPayloadHeader ( NX_ULONG );

ULONG gulCYC_MstAppErr;

CYC_TRN_ADDR	gstPreCycTrnAddr;
CYC_TRN_ADDR	gstCycTrnAddr;
CYC_RCV_ADDR	gstCycRcvAddr;

NX_VOID vNX_GetCyclicRcvSts (
	NX_CYC_RCV_STS *pstSts
)
{
	
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		
		vCYC_ExecGetCyclicRcvSts(pstSts);
	}
	else {
		
		vCYC_ExecGetCyclicRcvStsClassA(pstSts);
	}
	return;
}

NX_ULONG ulCYC_DetectComEst ( NX_VOID )
{
	ULONG	ulResult	=	NX_ON;
	ULONG	ulIpErr		=	NX_OFF;
	ULONG	ulAliveErr	=	NX_OFF;
	ULONG	ulPtpErr	=	NX_OFF;
#ifdef TSN_CAN_ENABLE
	ULONG	ulInitDetect =	NX_OFF;
#endif
	
	
	
	if ((gstNM.stNet.usNetSts == NETSTS_START_CYCSND) || (gstNM.stNet.usNetSts == NETSTS_DLINK)) {
		
		if (gstNM.stNet.usNetSts == NETSTS_DLINK) {
			
			
			ulIpErr	=	ulCYC_DetectIpErr();
			if (ulIpErr == NX_ON) {
				ulResult	=	NX_OFF;
			}
			
			ulAliveErr	=	ulCYC_DetectAliveErr();
			if (ulAliveErr == NX_ON) {
				ulResult	=	NX_OFF;
			}

#ifdef TSN_CAN_ENABLE
			ulInitDetect	=	ulNX_DetectDisconnect();
			if (NX_ON == ulInitDetect) {
				ulResult	=	NX_OFF;
			}
#endif
			
			
		}
		
		if (ulResult == NX_OFF) {
			
			vTsn_GetLinkDownFrun();
			vTsn_StopTsnLogging();
			vCYC_DeactivateCyclicRcv();
			if (SYNCMODE_SYNC == gstNET.stApp.usSyncMode) {
				vSYNC_AppSyncSigClear();
			}
			vNX_NotifyDLinkErr();
			vNMG_NotifyDLinkErr();
			
		}
		
	}
	else {
		
		
		ulResult	=	NX_OFF;
	}
	
	return(ulResult);
}

NX_ULONG ulCYC_DetectComEstSync (
	NX_ULONG ulCycRcv
)
{
	NX_ULONG	ulResult	=	(NX_ULONG)NX_ON;
	NX_ULONG	ulIpErr		=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulAliveErr	=	(NX_ULONG)NX_OFF;
	
	
	if ((gstNM.stNet.usNetSts == NETSTS_START_CYCSND) || (gstNM.stNet.usNetSts == NETSTS_DLINK)) {
		
		if (gstNM.stNet.usNetSts == NETSTS_DLINK) {
			
			
			ulIpErr	=	ulCYC_DetectIpErr();
			if (ulIpErr == (NX_ULONG)NX_ON) {
				ulResult	=	(NX_ULONG)NX_OFF;
			}
			
			ulAliveErr	=	ulCYC_DetectAliveErrSync(ulCycRcv);
			if (ulAliveErr == (NX_ULONG)NX_ON) {
				ulResult	=	(NX_ULONG)NX_OFF;
			}

		}
		
		if (ulResult == (NX_ULONG)NX_OFF) {
			
			vTsn_GetLinkDownFrun();
			vTsn_StopTsnLogging();
			vCYC_DeactivateCyclicRcv();
			vSYNC_AppSyncSigClear();
			
			vNX_NotifyDLinkErr();
			vNMG_NotifyDLinkErr();
			
		}
		
	}
	else {
		
		
		ulResult	=	(NX_ULONG)NX_OFF;
	}
	
	return(ulResult);
}

NX_ULONG ulCYC_DetectIpErr ( NX_VOID )
{
	NX_ULONG	ulErr		=	(NX_ULONG)NX_OFF;
	NX_USHORT	usIpErrP1	=	NX_US_OK;
	NX_USHORT	usIpErrP2	=	NX_US_OK;
	
	usIpErrP1 = usUSN_DuplicatIP((NX_USHORT)NX_PORT1);
	usIpErrP2 = usUSN_DuplicatIP((NX_USHORT)NX_PORT2);
	
	if ((usIpErrP1 == NX_US_NG) || (usIpErrP2 == NX_US_NG) ){
		
		ulErr	=	(NX_ULONG)NX_ON;
		
	}
	else {
		
		ulErr	=	(NX_ULONG)NX_OFF;
		
	}
	
	return ulErr;
}

NX_ULONG ulCYC_DetectAliveErr ( NX_VOID )
{
	NX_ULONG	ulResult	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulAliveErr	=	(NX_ULONG)NX_ZERO;
	
	ulAliveErr	=	NGN_RN->ulR_RNCALV2ESTS;
	ulAliveErr	&=	(NX_ULONG)RCVFLGADDR_UNI;
	
	if (ulAliveErr == RCVFLGADDR_UNI) {
		
		ulResult	=	(NX_ULONG)NX_ON;
	}
	else {
		
		ulResult	=	(NX_ULONG)NX_OFF;
	}
	
	return(ulResult);
}

NX_ULONG ulCYC_DetectAliveErrSync (
	NX_ULONG ulCycRcv
)
{
	NX_ULONG	ulResult	=	(NX_ULONG)NX_OFF;
	
	if ((NX_ULONG)NX_OFF == ulCycRcv) {
		gulSyncNoRcvCnt++;
	}
	else {
		gulSyncNoRcvCnt = (NX_ULONG)NX_ZERO;
	}
	
	if (gulSyncNoRcvCnt >= gulErrCycle) {
		gulSyncNoRcvCnt = (NX_ULONG)NX_ZERO;
		ulResult	=	(NX_ULONG)NX_ON;
	}
	else {
		ulResult	=	(NX_ULONG)NX_OFF;
	}
	
	return (ulResult);
}

NX_VOID vCYC_ChkFirstCyclicRcv (
	NX_ULONG	ulCycRcv
)
{
	if ((gstNM.stNet.usNetSts == NETSTS_START_CYCSND) && (ulCycRcv == NX_ON)) {
		
		NGN_RN->ulR_RNCALV2ESTS			=	RCVFLGADDR_UNI;
		gulSyncNoRcvCnt					=	(NX_ULONG)NX_ZERO;
		
		vNMG_NotifyFirstCycRcvCmp();
	}
	
	return;
}

NX_ULONG ulCYC_SwitchSwReadSide (
	NX_ULONG		*pulSucceed
)
{
	NX_ULONG	ulCurSwReadSide	=	RCV_SIDE_A;
	NX_ULONG	ulSwCmp			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulTimeout		=	NX_UL_NG;
	
	*pulSucceed	=	(NX_ULONG)NX_ON;
	
	NGN_RN->R_RNCBKSW.DATA	=	SWITCH_SWRD_HWWRCMP;
	
	vNX_timer_start(TMID_CYC_RX_SWSD);
	do {
		
		ulSwCmp = ulINTR_CheckIntLowRx(INTR_RXL_SWREAD_AREA0);
		
		ulTimeout = ulNX_timer_check(TMID_CYC_RX_SWSD);
		if (ulTimeout == NX_UL_OK) {
			
			ulSwCmp = ulINTR_CheckIntLowRx(INTR_RXL_SWREAD_AREA0);
			if (ulSwCmp == (NX_ULONG)NX_ON) {
				
			}
			else {
				
				*pulSucceed	=	(NX_ULONG)NX_OFF;
			}
			
			break;
			
		}
		else {
		}
		
	} while (ulSwCmp == (NX_ULONG)NX_OFF);
	
	vNX_timer_stop(TMID_CYC_RX_SWSD);
	
	vINTR_ClearIntLowRx(INTR_RXL_SWREAD_AREA0);
	
	if (*pulSucceed == (NX_ULONG)NX_ON) {
		
		ulCurSwReadSide	=	NGN_RN->R_RNCBKSTS.BITS.b02ZCycSWReadSideSts_Area00;
	}
	else {
		
		ulCurSwReadSide	=	RCV_SIDE_A;
	}
	
	return ulCurSwReadSide;
}

NX_ULONG ulCYC_ChkCycRcv (
	NX_ULONG	ulCurSwReadSide
)
{
	NX_ULONG	ulCycSizeZero	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcv		=	(NX_ULONG)NX_OFF;
	
	
	
	ulCycSizeZero = ulNX_ChkCycRcvNoData();
	
	if (ulCycSizeZero == (NX_ULONG)NX_ON) {
		
		ulCycRcv = ulCYC_ChkCycAlive(ulCurSwReadSide);
	}
	else {
		
		ulCycRcv = ulCYC_ChkCycRcvFlg(ulCurSwReadSide);
	}
	
	return ulCycRcv;
}

NX_ULONG ulCYC_ChkCycRcvSync (
	NX_ULONG	ulCycRcvFlg,
	NX_ULONG	ulCycAlive
)
{
	NX_ULONG	ulCycSizeZero	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcv		=	(NX_ULONG)NX_OFF;
	
	
	ulCycSizeZero = ulNX_ChkCycRcvNoData();
	
	if (ulCycSizeZero == (NX_ULONG)NX_ON) {
		
		ulCycRcv = ulCycAlive;
	}
	else {
		
		ulCycRcv = ulCycRcvFlg;
	}
	
	return ulCycRcv;
}

NX_ULONG ulCYC_ChkCycRcvFlg (
	NX_ULONG	ulCurSwReadSide
)
{
	NX_ULONG	ulChkResult	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcvFlg	=	(NX_ULONG)NX_ZERO;
	
	ulCycRcvFlg	=	*(gpaulCycRevFlg[ulCurSwReadSide]);
	ulCycRcvFlg	&=	RCVFLGADDR_UNI;
	
	if (ulCycRcvFlg != CYCRCVFLG_ALLOFF) {
		
		ulChkResult	=	(NX_ULONG)NX_ON;
	
		*(gpaulCycRevFlg[ulCurSwReadSide])	=	RCVFLGADDR_UNI;
	}
	else {
		
		ulChkResult	=	(NX_ULONG)NX_OFF;
	}
	return ulChkResult;
}


NX_ULONG ulCYC_ChkCycAlive (
	NX_ULONG	ulCurSwReadSide
)
{
	NX_ULONG	ulChkResult	=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycAlive	=	(NX_ULONG)NX_ZERO;
	
	ulCycAlive	=	*(gpaulCycAlive[ulCurSwReadSide]);
	ulCycAlive	&=	RCVFLGADDR_UNI;
	
	if (ulCycAlive != CYCALIVE_ALLOFF) {
		
		ulChkResult	=	(NX_ULONG)NX_ON;
	
		*(gpaulCycAlive[ulCurSwReadSide])	=	RCVFLGADDR_UNI;
	
	}
	else {
		
		ulChkResult	=	(NX_ULONG)NX_OFF;
	}
	
	return ulChkResult;
}

NX_VOID vCYC_UpdateAppErrFW (
	NX_ULONG	ulCycRcv
)
{
	NX_ULONG	ulAppErrCur		=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulAppErrTotal	=	(NX_ULONG)NX_ZERO;

	
	if (ulCycRcv == NX_ON) {
		
		vCYC_AnalyzeAppErrFW();
		
	}
	else {
		
	}
	
	return;
}

NX_ULONG ulCYC_ReadClrAppErrFW ( NX_VOID )
{
	NX_ULONG	ulAppErr1	=	(NX_ULONG)NX_ZERO;
	
	ulAppErr1	=	NGN_RN_APLERR->R_RNAPERF2[0].DATA;
	
	NGN_RN_APLERR->R_RNAPERF2[0].DATA	=	ulAppErr1;
	
	ulAppErr1	=	(ulAppErr1 & APPERR_EXT_STA1);
	
	return ulAppErr1;
}

NX_VOID vCYC_AnalyzeAppErrFW ( NX_VOID )
{
	NX_ULONG	ulAppErr	=	(NX_ULONG)NX_ZERO;
	NX_USHORT	usRsvSta	=	(NX_USHORT)NX_OFF;
	
	ulAppErr	=	ulCYC_ReadClrAppErrFW();
	
	gulCYC_MstAppErr = ulAppErr;

	ulAppErr	=	(ulAppErr & BIT_APPERR_RCV_VALID);
	if (gstNET.stCyc.usRsvStaBase == NX_ON) {
		ulAppErr	=	(ulAppErr | BIT_APPERR_RSVSTA);
	}

	if (((ulAppErr & BIT_APPERR_CYCSTOP) == BIT_APPERR_CYCSTOP)
		|| ((ulAppErr & BIT_APPERR_RSVSTA) == BIT_APPERR_RSVSTA)) {
		
		if ((ulAppErr & BIT_APPERR_CYCSTOP) == BIT_APPERR_CYCSTOP) {
			
			gstNET.stCyc.usStopDLink	=	(NX_USHORT)NX_ON;
			
		}
		if ((ulAppErr & BIT_APPERR_RSVSTA) == BIT_APPERR_RSVSTA) {
			
			usRsvSta					=	(NX_USHORT)NX_ON;
			
		}
		
		gstCycCtrl.stAppErr.usHldClrEn			=	(NX_USHORT)NX_ON;
		gstCycCtrl.stAppErr.usRcvCycDataDis		=	(NX_USHORT)NX_ON;
		
		vCYC_ClrAllCycFlg();
	}
	else {
		
		gstNET.stCyc.usStopDLink	=	(NX_USHORT)NX_OFF;
		usRsvSta					=	(NX_USHORT)NX_OFF;
		
		if ((ulAppErr & BIT_APPERR_WDTERR) == BIT_APPERR_WDTERR) {
			
			gstCycCtrl.stAppErr.usHldClrEn		=	(NX_USHORT)NX_ON;
			gstCycCtrl.stAppErr.usRcvCycDataDis	=	(NX_USHORT)NX_ON;
			
			vCYC_ClrAllCycFlg();
		}
		else if ((ulAppErr & BIT_APPERR_CYCDATADIS) == BIT_APPERR_CYCDATADIS) {
			
			gstCycCtrl.stAppErr.usHldClrEn		=	(NX_USHORT)NX_ON;
			gstCycCtrl.stAppErr.usRcvCycDataDis	=	(NX_USHORT)NX_ON;
			
			vCYC_ClrAllCycFlg();
		}
		else if ((ulAppErr & BIT_APPERR_APPRUN) == BIT_APPERR_APPRUN) {
			
			gstCycCtrl.stAppErr.usHldClrEn		=	(NX_USHORT)NX_ON;
			gstCycCtrl.stAppErr.usRcvCycDataDis	=	(NX_USHORT)NX_OFF;
			
			vCYC_ClrAllCycFlg();
		}
		else {
			
			gstCycCtrl.stAppErr.usHldClrEn		=	(NX_USHORT)NX_OFF;
			gstCycCtrl.stAppErr.usRcvCycDataDis	=	(NX_USHORT)NX_OFF;
			
		}
	}
	
	vNMG_UpdateRsvSta(usRsvSta);
	
	return;
}


NX_VOID vCYC_ClrAllCycFlg ( NX_VOID )
{
	*(gpaulCycRevFlg[RCV_SIDE_A])	=	RCVFLGADDR_UNI;
	*(gpaulCycRevFlg[RCV_SIDE_B])	=	RCVFLGADDR_UNI;
	*(gpaulCycRevFlg[RCV_SIDE_C])	=	RCVFLGADDR_UNI;
	
	*(gpaulCycAlive[RCV_SIDE_A])	=	RCVFLGADDR_UNI;
	*(gpaulCycAlive[RCV_SIDE_B])	=	RCVFLGADDR_UNI;
	*(gpaulCycAlive[RCV_SIDE_C])	=	RCVFLGADDR_UNI;
	
	return;
}

NX_VOID vNX_GetCyclicTrnSts (
	NX_CYC_TRN_STS *pstSts
)
{
	NX_USHORT	usRxAddrTblIndex = (NX_USHORT)NX_ZERO;
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	NX_ULONG	ulBaseAddr = NX_ZERO;
	NX_USHORT	usLoop = NX_ZERO;

	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass){
		gstCycCtrl.ulTrnSide = ulCYC_SelectUnusedSide();
	}
	else {
		gstCycCtrl.ulTrnSide = ulCYC_SelectUnusedSideClassA();
	}
	
	ulBaseAddr = gaulBaseAddrTbl[gstCycCtrl.ulTrnSide];

	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RX; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRxNum) {
			pstSts->stRX[usLoop].ulAddr		= ulBaseAddr + gstCycTrnAddr.stRX[usLoop].ulAddr;
			pstSts->stRX[usLoop].usSize		= gstCycTrnAddr.stRX[usLoop].usSize;
		}
		else {
			pstSts->stRX[usLoop].ulAddr		= NX_ZERO;
			pstSts->stRX[usLoop].usSize		= NX_ZERO;
		}
	}

	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RWR; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRWrNum) {
			pstSts->stRWr[usLoop].ulAddr	= ulBaseAddr + gstCycTrnAddr.stRWr[usLoop].ulAddr;
			pstSts->stRWr[usLoop].usSize	= gstCycTrnAddr.stRWr[usLoop].usSize;
		}
		else {
			pstSts->stRWr[usLoop].ulAddr	= NX_ZERO;
			pstSts->stRWr[usLoop].usSize	= NX_ZERO;
		}
	}

#ifdef SAFETY_PDU_ENABLE
	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_SPDUX; usLoop++) {
		if (usLoop < gstCycTrnAddr.usSpduxNum) {
			pstSts->stSpdux[usLoop].ulAddr		= ulBaseAddr + gstCycTrnAddr.stSpdux[usLoop].ulAddr;
			pstSts->stSpdux[usLoop].usSize		= gstCycTrnAddr.stSpdux[usLoop].usSize;
		}
		else {
			pstSts->stSpdux[usLoop].ulAddr		= NX_ZERO;
			pstSts->stSpdux[usLoop].usSize		= NX_ZERO;
		}
	}

	pstSts->usSpduxNum		= gstCycTrnAddr.usSpduxNum;
#endif

	pstSts->usRxNum		= gstCycTrnAddr.usRxNum;
	pstSts->usRWrNum	= gstCycTrnAddr.usRWrNum;
	return;
}

NX_ULONG ulCYC_SelectUnusedSide ( NX_VOID )
{
	NX_ULONG	ulMsk					=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulShift					=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulLatestWriteSide		=	TRN_SIDE_A;
	NX_ULONG	ulReadEnableSide		=	TRN_SIDE_A;
	NX_ULONG	ulSelectedUnusedSide	=	TRN_SIDE_A;
	
	ulMsk	=	gaulSideMsk[gstNET.stCyc.usTsltCycSnd];
	ulShift	=	gausSideShift[gstNET.stCyc.usTsltCycSnd];
	
	ulLatestWriteSide	=	NGN_CN_TN1_REG->R_TNTURN.DATA;
	ulLatestWriteSide	&=	ulMsk;
	ulLatestWriteSide	>>=	ulShift;
	
	ulReadEnableSide	=	NGN_CN_TN1_REG->R_TNRDBANK.DATA;
	ulReadEnableSide	&=	ulMsk;
	ulReadEnableSide	>>=	ulShift;
	
	ulSelectedUnusedSide	=	aulUnusedSideTbl[ulLatestWriteSide][ulReadEnableSide];
	
	return ulSelectedUnusedSide;
}

NX_VOID vNX_UpdateDiagnosisData (
	NX_USHORT	usErrSts
)
{
	NX_UCHAR	uchSelfDiagData	=	(NX_UCHAR)NX_ZERO;
	NX_ULONG	ulLinkStsP1;
	NX_ULONG	ulLinkStsP2;
	
	gstCycCtrl.ulAppErrSts	=	usErrSts;
	
	
	uchSelfDiagData	|=	gauchDiagErrInfo[usErrSts];
	
	
	
	if ((gstNET.stCyc.usStopDLink == NX_ON) || (gstNET.stCyc.usRsvSta == NX_ON)) {
		uchSelfDiagData	|=	BIT_APPERR_CYCDATADIS;
	}
	
	ulLinkStsP1 = ulPHY_DetectLinkUp(0);
	ulLinkStsP2 = ulPHY_DetectLinkUp(1);
	if ((ulLinkStsP1 == PHY_LINKDOWN) || (ulLinkStsP2 == PHY_LINKDOWN)) {
		uchSelfDiagData |= ((NX_UCHAR)BIT_APPERR_LINKDOWN);
	}

	
	
	
	gstCycCtrl.uchSelfDiagData = uchSelfDiagData;
	
	return;
}

NX_VOID	 vNX_FinishTrnCycData ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_USHORT	usSendCycTmg = (USHORT)NX_OFF;

	vCYC_UpdateSelfStsW();
	vCYC_SetSelfStsW(gstCycCtrl.ulTrnSide);
	vCYC_UpdateAllSubPayloadHeader(gstCycCtrl.ulTrnSide);
	
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass){
		vCYC_UpdateWriteLatestSide();
	}
	else {
		gstClassAInfo.ulLatestWriteSide = gstCycCtrl.ulTrnSide;
	}
	return;
}

NX_VOID vCYC_UpdateAllSubPayloadHeader (
	NX_ULONG	ulTrnSide
)
{
	NX_USHORT	usRxAddrTblIndex = (NX_USHORT)NX_ZERO;
	NX_UCHAR	uchAppErrStateFW		=	(NX_UCHAR)NX_ZERO;
	NX_ULONG	ulBaseAddr;
	NX_USHORT	usLoop;
	
	uchAppErrStateFW = gstCycCtrl.uchSelfDiagData;
	
	if (gstAppInfo.stLibInfo.usLibMode == NX_LIB_MODE_NORMAL) {
		ulBaseAddr = gaulBaseAddrTbl[ulTrnSide];

		for (usLoop = NX_ZERO; usLoop<gstCycTrnAddr.usStswNum; usLoop++) {
			vCYC_UpdateSubPayloadHeader(ulBaseAddr + gstCycTrnAddr.stStsW[usLoop].ulAddr - (NX_ULONG)sizeof(SPHEAD_SS_S),
										uchAppErrStateFW
										);
		}

		for (usLoop = NX_ZERO; usLoop<gstCycTrnAddr.usRxNum; usLoop++) {
			vCYC_UpdateSubPayloadHeader(ulBaseAddr + gstCycTrnAddr.stRX[usLoop].ulAddr - (NX_ULONG)sizeof(SPHEAD_SS_S),
										uchAppErrStateFW
										);
		}

		for (usLoop = NX_ZERO; usLoop<gstCycTrnAddr.usRWrNum; usLoop++) {
			vCYC_UpdateSubPayloadHeader(ulBaseAddr + gstCycTrnAddr.stRWr[usLoop].ulAddr - (NX_ULONG)sizeof(SPHEAD_SS_S),
										uchAppErrStateFW
										);
		}
#ifdef SAFETY_PDU_ENABLE
		for (usLoop = NX_ZERO; usLoop<gstCycTrnAddr.usSpduxNum; usLoop++) {
			vCYC_UpdateSubPayloadHeader(ulBaseAddr + gstCycTrnAddr.stSpdux[usLoop].ulAddr - (NX_ULONG)sizeof(SPHEAD_SS_S),
										uchAppErrStateFW
										);
		}
#endif

	}
	else {
		
		vCYC_UpdateSubPayloadHeader(gaulStsWAddrTbl[ulTrnSide],
									uchAppErrStateFW
									);
		vCYC_UpdateSubPayloadHeader(gaulRWrAddrTbl[ulTrnSide],
									uchAppErrStateFW
									);
		if ((NX_LIB_MODE_FASTIO2 == gstAppInfo.stLibInfo.usLibMode) ||
			(NX_LIB_MODE_FASTIO3 == gstAppInfo.stLibInfo.usLibMode)) {
			usRxAddrTblIndex = usCYC_GetRxAddrTblIdx_IoMode2_3();
			vCYC_UpdateSubPayloadHeader(gaulRxAddrTbl[usRxAddrTblIndex][ulTrnSide],
										(uchAppErrStateFW & FASTIO_APPERR_TRN_MSK)
										);
		}
		else {
			vCYC_UpdateSubPayloadHeader(gaulRxAddrTbl[gstAppInfo.stLibInfo.usLibMode][ulTrnSide],
										(uchAppErrStateFW & FASTIO_APPERR_TRN_MSK)
										);
		}
	}
	
	return;
}

NX_VOID vCYC_UpdateSubPayloadHeader (
	NX_ULONG	ulSpdAddr,
	NX_UCHAR	uchAppErrStateFW
)
{
	SPHEAD_SS_S				*pstSpdHeader		=	(SPHEAD_SS_S*)ulSpdAddr;
	CYC_TX_APPERR			stTxAppErr;
	CYC_TX_APPERR			stTxAppErrBackup;
	CYC_SPHEAD_INFO			stInfo;
	CYC_SPHEAD_INFO			stInfoBackup;
	
	stTxAppErr.ulData		=	(NX_ULONG)NX_ZERO;
	stTxAppErrBackup.ulData	=	(NX_ULONG)NX_ZERO;
	stInfo.usData			=	(NX_USHORT)NX_ZERO;
	stInfoBackup.usData		=	(NX_USHORT)NX_ZERO;
	
	
	stInfoBackup.usData = usNX_CnvEndianShort(pstSpdHeader->usInfo_BgEd);
	
	stInfo.BITS.b01CtrlFlg	=	stInfoBackup.BITS.b01CtrlFlg;
	
	stInfo.BITS.b01TimingErr	=	stInfoBackup.BITS.b01TimingErr;
	
	stInfo.BITS.b11AppDataLength	=	stInfoBackup.BITS.b11AppDataLength;
	
	
	stTxAppErrBackup.ulData		=	pstSpdHeader->stTxAppErr.ulData;
	
	stTxAppErr.BITS.uchTranTxInfo	=	stTxAppErrBackup.BITS.uchTranTxInfo;
	
	stTxAppErr.BITS.usSeqNum_BgEd		=	stTxAppErrBackup.BITS.usSeqNum_BgEd;
	
	stTxAppErr.BITS.uchAppErrStateFW	=	uchAppErrStateFW;
	
	pstSpdHeader->usInfo_BgEd			=	usNX_CnvEndianShort(stInfo.usData);
	pstSpdHeader->stTxAppErr.ulData		=	stTxAppErr.ulData;
	
	return;
}

NX_VOID vCYC_UpdateWriteLatestSide ( NX_VOID )
{
	NX_ULONG	ulRegData	=	(NX_ULONG)NX_ZERO;
	
	ulRegData	=	NGN_CN_TN1_REG->R_TNTURN.DATA;
	ulRegData	&=	~(gaulSideMsk[gstNET.stCyc.usTsltCycSnd]);
	ulRegData	|=	(gstCycCtrl.ulTrnSide << (NX_ULONG)gausSideShift[gstNET.stCyc.usTsltCycSnd]);
	NGN_CN_TN1_REG->R_TNTURN.DATA	=	ulRegData;
	
	return;
}

NX_VOID vCYC_ActivateCyclic ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	vCYC_ClrAllCycFlg();
	
	NGN_RN->ulR_RNCALV2ESTS			=	RCVFLGADDR_UNI;
	gulSyncNoRcvCnt					=	(NX_ULONG)NX_ZERO;
	
	NGN_RN_APLERR->R_RNAPERF2[0].DATA	=	RNAPERF2_1_ALLCLR;
	NGN_RN_APLERR->R_RNAPERF2[1].DATA	=	RNAPERF2_2_ALLCLR;

	NGN_RN->R_RNCTRL.BITS.b01ZCycRcvCtrlFuncEnable	=	NX_BIT0;
	
	
	usAuthClass = usACM_GetAuthenticationClass();

	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		NGN_CN_TN1_REG->R_TSLOT[gstNET.stCyc.usTsltCycSnd].ASIC_rtslot1.BITS.b01ZCycleSndStartFlag		=	NX_BIT0;
	}
	else {
	}

	return;
}

NX_VOID vCYC_InitCyclicStart ( NX_VOID )
{
	NX_USHORT		usLibMd;
	NX_USHORT		usRxAddrTblIndex = (NX_USHORT)NX_ZERO;
	NX_CYC_PRM		stCycPrm;
	NX_RCV_CYC_ADDR	stRcvCycbuffAddr;
	NX_TRN_CYC_ADDR	stTrnCycbuffAddr;
	NX_USHORT		usErrSts 	=	(NX_USHORT)NX_ZERO;
	NX_USHORT		usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_USHORT		usLoop		=	(NX_USHORT)NX_ZERO;
	NX_ULONG		ulAddrRX	=	(NX_ULONG)NX_ZERO;
	NX_ULONG		ulAddrRWr	=	(NX_ULONG)NX_ZERO;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG		ulAddrSpdux	=	(NX_ULONG)NX_ZERO;
#endif
	
	NGN_CN_TN1_REG->R_TNTURN.DATA	=	((NX_ULONG)NX_BIT0 << (NX_ULONG)gausSideShift[gstNET.stCyc.usTsltCycSnd]);

	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
	}
	else {
		gstClassAInfo.ulLatestWriteSide = TRN_SIDE_A;
	}
	
	if ((SYNCMODE_SYNC == gstNET.stApp.usSyncMode) && (SYNCWDC_USE == gstNET.stApp.usUseWDC)) {
		NGN_RN->R_RNCBKHMD.DATA		=	RNCBKHMD_ALL_MANUAL;
	}
	else {
		if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
			NGN_RN->R_RNCBKHMD.DATA		=	RNCBKHMD_ALL_AUTO;
		}
		else {
			NGN_RN->R_RNCBKHMD.DATA		=	RNCBKHMD_ALL_MANUAL;
		}
	}

	usLibMd = gstAppInfo.stLibInfo.usLibMode;
	stCycPrm.usSizeRX = gstNET.stCyc.usSizeRX;
	stCycPrm.usSizeRY = gstNET.stCyc.usSizeRY;
	stCycPrm.usSizeRWr = gstNET.stCyc.usSizeRWr;
	stCycPrm.usSizeRWw = gstNET.stCyc.usSizeRWw;
#ifdef SAFETY_PDU_ENABLE
	stCycPrm.usSizeSpdux = gstNET.stCyc.usSizeSpdux;
	stCycPrm.usSizeSpduy = gstNET.stCyc.usSizeSpduy;
#endif
	
	vNX_PrepareDLink(&stCycPrm);

	stRcvCycbuffAddr.ulAddrRWw_A =	gaulRWwAddrTbl[RCV_SIDE_A];
	stRcvCycbuffAddr.ulAddrRWw_B =	gaulRWwAddrTbl[RCV_SIDE_B];
	stRcvCycbuffAddr.ulAddrRWw_C =	gaulRWwAddrTbl[RCV_SIDE_C];
	stRcvCycbuffAddr.ulAddrRY_A =	gaulRyAddrTbl[usLibMd][RCV_SIDE_A];
	stRcvCycbuffAddr.ulAddrRY_B =	gaulRyAddrTbl[usLibMd][RCV_SIDE_B];
	stRcvCycbuffAddr.ulAddrRY_C =	gaulRyAddrTbl[usLibMd][RCV_SIDE_C];
#ifdef SAFETY_PDU_ENABLE
	stRcvCycbuffAddr.ulAddrSpduy_A =	gaulSpduyAddrTbl[RCV_SIDE_A];
	stRcvCycbuffAddr.ulAddrSpduy_B =	gaulSpduyAddrTbl[RCV_SIDE_B];
	stRcvCycbuffAddr.ulAddrSpduy_C =	gaulSpduyAddrTbl[RCV_SIDE_C];
#endif
	
	vNX_InitRcvCycData(&stRcvCycbuffAddr);
	
	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RX; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRxNum) {
			ulAddrRX = gstCycTrnAddr.stRX[usLoop].ulAddr;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[0]		= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[1]		= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[2]		= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].usSize		= gstCycTrnAddr.stRX[usLoop].usSize;
		}
		else {
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[0]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[1]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[2]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].usSize		= NX_ZERO;
		}
	}

	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RWR; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRWrNum) {
			ulAddrRWr = gstCycTrnAddr.stRWr[usLoop].ulAddr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[0]	= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[1]	= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[2]	= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].usSize		= gstCycTrnAddr.stRWr[usLoop].usSize;
		}
		else {
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[0]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[1]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[2]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].usSize		= NX_ZERO;
		}
	}

#ifdef SAFETY_PDU_ENABLE
	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_SPDUX; usLoop++) {
		if (usLoop < gstCycTrnAddr.usSpduxNum) {
			ulAddrSpdux = gstCycTrnAddr.stSpdux[usLoop].ulAddr;
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[0]	= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrSpdux;
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[1]	= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrSpdux;
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[2]	= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrSpdux;
			stTrnCycbuffAddr.stSpdux[usLoop].usSize		= gstCycTrnAddr.stSpdux[usLoop].usSize;
		}
		else {
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[0]	= NX_ZERO;
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[1]	= NX_ZERO;
			stTrnCycbuffAddr.stSpdux[usLoop].ulAddr[2]	= NX_ZERO;
			stTrnCycbuffAddr.stSpdux[usLoop].usSize		= NX_ZERO;
		}
	}
	stTrnCycbuffAddr.usSpduxNum	= gstCycTrnAddr.usSpduxNum;
#endif

	stTrnCycbuffAddr.usRxNum	= gstCycTrnAddr.usRxNum;
	stTrnCycbuffAddr.usRWrNum	= gstCycTrnAddr.usRWrNum;

	vNX_InitTrnCycData(&stTrnCycbuffAddr, &usErrSts);
	
	vNX_UpdateDiagnosisData(usErrSts);
	
	vCYC_UpdateSelfStsW();
	gstCycCtrl.auchSelfStsW[ADDR_SELFSTSW_APPINFO]	&= (~BIT_APPINFO_NWSYNC);
	vCYC_SetSelfStsW(TRN_SIDE_A);
	vCYC_SetSelfStsW(TRN_SIDE_B);
	vCYC_SetSelfStsW(TRN_SIDE_C);
	
	vCYC_UpdateAllSubPayloadHeader(TRN_SIDE_A);
	vCYC_UpdateAllSubPayloadHeader(TRN_SIDE_B);
	vCYC_UpdateAllSubPayloadHeader(TRN_SIDE_C);

	gulSyncNoRcvCnt		= (NX_ULONG)NX_ZERO;
	gulErrCycle = (NGN_RN->ulR_RNCALVECNT & MSK_ALVERRCNT);

	return;
}

NX_VOID vCYC_DeactivateCyclicSnd ( NX_VOID )
{
	vNX_vDisableDispatch();
	NGN_CN_TS_P1_REG->R_TCPXTXON.DATA	=	(NX_ULONG)0;
	NGN_CN_TS_P1_REG->R_TCPXTXOS.DATA	=	(NX_ULONG)0;
	vNX_vEnableDispatch();
	
	NGN_CN_TN1_REG->R_TSLOT[gstNET.stCyc.usTsltCycSnd].ASIC_rtslot1.BITS.b01ZCycleSndStartFlag	= (NX_ULONG)NX_ZERO;
	
	return;
}

NX_VOID vCYC_DeactivateCyclicRcv ( NX_VOID )
{
	NGN_RN->R_RNCTRL.BITS.b01ZCycRcvCtrlFuncEnable	= (NX_ULONG)NX_ZERO;
	
	return;
}

NX_VOID vCYC_WriteWdtSts ( NX_VOID )
{
	NX_USHORT		usLibMd;
	NX_USHORT		usRxAddrTblIndex = (NX_USHORT)NX_ZERO;
	NX_TRN_CYC_ADDR	stTrnCycbuffAddr;
	NX_ULONG		ulAddrRX	= (NX_ULONG)NX_ZERO;
	NX_ULONG		ulAddrRWr	= (NX_ULONG)NX_ZERO;
	NX_USHORT		usLoop		= (NX_USHORT)NX_ZERO;

	vCYC_ForceWdtErrStsW();
	
	
	usLibMd = gstAppInfo.stLibInfo.usLibMode;
	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RX; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRxNum) {
			ulAddrRX = gstCycTrnAddr.stRX[usLoop].ulAddr;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[0]		= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[1]		= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[2]		= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRX;
			stTrnCycbuffAddr.stRX[usLoop].usSize		= gstCycTrnAddr.stRX[usLoop].usSize;
		}
		else {
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[0]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[1]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].ulAddr[2]		= NX_ZERO;
			stTrnCycbuffAddr.stRX[usLoop].usSize		= NX_ZERO;
		}
	}

	for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RWR; usLoop++) {
		if (usLoop < gstCycTrnAddr.usRWrNum) {
			ulAddrRWr = gstCycTrnAddr.stRWr[usLoop].ulAddr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[0]	= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[1]	= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[2]	= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRWr;
			stTrnCycbuffAddr.stRWr[usLoop].usSize		= gstCycTrnAddr.stRWr[usLoop].usSize;
		}
		else {
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[0]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[1]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].ulAddr[2]	= NX_ZERO;
			stTrnCycbuffAddr.stRWr[usLoop].usSize		= NX_ZERO;
		}
	}

	stTrnCycbuffAddr.usRxNum	= gstCycTrnAddr.usRxNum;
	stTrnCycbuffAddr.usRWrNum	= gstCycTrnAddr.usRWrNum;
	vNX_SetWdtTrnCyclic(&stTrnCycbuffAddr);
	
	return;
}

NX_USHORT usNX_CheckCycExeTmg (NX_VOID)
{
	NX_USHORT		usRet			= (NX_USHORT)NX_OFF;
	NX_ULONGLONG	ullCycCnt		= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usRptCnt		= NX_US_ZERO;
	NX_USHORT		usSwTmg			= NX_US_ZERO;
	NX_USHORT		usChkSwTmg		= NX_US_ZERO;
	NX_USHORT		usLinkSpdSta	= NX_LINKSPD_STA_1G;

	vNX_vDisableDispatch();

	usLinkSpdSta	= usLSM_GetLinkSpd();

	if (usLinkSpdSta == NX_LINKSPD_STA_1G) {
		ullCycCnt	= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSC0 << NX_SHIFT32;
		ullCycCnt	|= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSC1;
	}
	else {
		ullCycCnt	= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSSC0 << NX_SHIFT32;
		ullCycCnt	|= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSSC1;
	}

	vNMG_GetSendCycle(&usRptCnt, &usSwTmg);

	usChkSwTmg		= (NX_USHORT)(ullCycCnt % usRptCnt) + (NX_USHORT)NX_ONE;

	if (usChkSwTmg == usSwTmg) {
		usRet	= (NX_USHORT)NX_ON;
	}
	else {
		usRet	= (NX_USHORT)NX_OFF;
	}

	vNX_vEnableDispatch();

	return usRet;
}

NX_VOID vNX_SyncSwitchSwReadSide ( NX_VOID )
{
	NX_ULONG	ulRcvSide	= (NX_ULONG)RCV_SIDE_A;
	NX_ULONG	ulSwSucceed	= (NX_ULONG)NX_OFF;

	gulSwSucceed	= (NX_ULONG)NX_ON;


	ulRcvSide = ulCYC_SwitchSwReadSide2(&ulSwSucceed);
	
	if ((NX_ULONG)NX_OFF == ulSwSucceed) {
		gulSwSucceed = (NX_ULONG)NX_OFF;
	}

	return;
}

NX_VOID vNX_GetSyncCyclicRcvSts (
	NX_CYC_RCV_STS *pstSts
)
{
	NX_ULONG	ulComEst	= (NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcv	= (NX_ULONG)NX_OFF;
	NX_ULONG	ulRcvSide	= (NX_ULONG)RCV_SIDE_A;

	NX_ULONG	ulCycRcvFlg	= (NX_ULONG)NX_OFF;
	NX_ULONG	ulCycAlive	= (NX_ULONG)NX_OFF;

	ulRcvSide	= NGN_RN->R_RNCBKSTS.BITS.b02ZCycSWReadSideSts_Area00;
	
	ulCycRcvFlg	= ulCYC_ChkCycRcvFlg(ulRcvSide);
	ulCycAlive	= ulCYC_ChkCycAlive(ulRcvSide);
	
	if (gulSwSucceed == (NX_ULONG)NX_OFF) {
		ulCycRcvFlg	= (NX_ULONG)NX_OFF;
		ulCycAlive	= (NX_ULONG)NX_OFF;
	}
	
	ulComEst = ulCYC_DetectComEstSync(ulCycAlive);
	if (ulComEst == NX_OFF) {
		pstSts->usEstCom	= (NX_USHORT)NX_OFF;
		pstSts->usCycRcv	= (NX_USHORT)NX_OFF;
		pstSts->ulAddrRY	= gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
		pstSts->ulAddrRWw	= gaulRWwAddrTbl[RCV_SIDE_A];
		pstSts->usHldClrSts	= (NX_USHORT)NX_ON;
	}
	else {
		if (gulSwSucceed == (NX_ULONG)NX_OFF) {
			pstSts->usEstCom	= (NX_USHORT)NX_ON;
			pstSts->usCycRcv	= (NX_USHORT)NX_OFF;
			pstSts->ulAddrRY	= gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
			pstSts->ulAddrRWw	= gaulRWwAddrTbl[RCV_SIDE_A];
			pstSts->usHldClrSts	= gstCycCtrl.usHldClrStsPre;
		}
		else {

			ulCycRcv = ulCYC_ChkCycRcvSync(ulCycRcvFlg, ulCycAlive);
			vCYC_UpdateAppErrFW(ulCycRcv);
			
			vCYC_ChkFirstCyclicRcv(ulCycRcv);
			
			if (gstCycCtrl.stAppErr.usRcvCycDataDis == (NX_USHORT)NX_ON) {
				pstSts->usEstCom	= (NX_USHORT)NX_ON;
				pstSts->usCycRcv	= (NX_USHORT)NX_OFF;
				pstSts->ulAddrRY	= gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
				pstSts->ulAddrRWw	= gaulRWwAddrTbl[RCV_SIDE_A];
				pstSts->usHldClrSts	= (NX_USHORT)NX_ON;
			}
			else {
				if (ulCycRcv == (NX_ULONG)NX_ON) {
					pstSts->usEstCom	= (NX_USHORT)NX_ON;
					pstSts->usCycRcv	= (NX_USHORT)NX_ON;
					pstSts->ulAddrRY	= gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][ulRcvSide];
					pstSts->ulAddrRWw	= gaulRWwAddrTbl[ulRcvSide];
					pstSts->usHldClrSts	= gstCycCtrl.stAppErr.usHldClrEn;
				}
				else {
					pstSts->usEstCom	= (NX_USHORT)NX_ON;
					pstSts->usCycRcv	= (NX_USHORT)NX_OFF;
					pstSts->ulAddrRY	= gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
					pstSts->ulAddrRWw	= gaulRWwAddrTbl[RCV_SIDE_A];
					pstSts->usHldClrSts	= gstCycCtrl.usHldClrStsPre;
				}
			}
		}
	}

	gstCycCtrl.usHldClrStsPre = pstSts->usHldClrSts;

	return;
}

NX_USHORT usCYC_GetRxAddrTblIdx_IoMode2_3 ( NX_VOID )
{
	NX_USHORT	usIndex = (NX_USHORT)NX_ZERO;
	
	if ( NX_WDCFUNC_ENBL == gstNM.stSlaveConfig.usWdcFuncSts ) {
		usIndex = NX_LIB_MODE_NORMAL;
	}
	else {
		usIndex = NX_LIB_MODE_FASTIO;
	}
	
	return usIndex;
}

NX_STATIC NX_VOID vCYC_ExecGetCyclicRcvSts (
	NX_CYC_RCV_STS *pstSts
)
{
	NX_ULONG	ulComEst			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcv			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulSwSucceed			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulRcvSide			=	(NX_ULONG)RCV_SIDE_A;
	
	ulComEst	=	ulCYC_DetectComEst();
	if (ulComEst == NX_OFF) {
		
		pstSts->usEstCom = (NX_USHORT)NX_OFF;
		pstSts->usCycRcv = (NX_USHORT)NX_OFF;
		pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
		pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
		pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
		pstSts->usHldClrSts = (NX_USHORT)NX_ON;
	}
	else {
			
		ulRcvSide = ulCYC_SwitchSwReadSide(&ulSwSucceed);
		
		if (ulSwSucceed == (NX_ULONG)NX_OFF) {
			
			pstSts->usEstCom = (NX_USHORT)NX_ON;
			pstSts->usCycRcv = (NX_USHORT)NX_OFF;
			pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
			pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
			pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
			pstSts->usHldClrSts = gstCycCtrl.usHldClrStsPre;
		}
		else {
			
			ulCycRcv = ulCYC_ChkCycRcv(ulRcvSide);
			
			vCYC_UpdateAppErrFW(ulCycRcv);
			
			
			vCYC_ChkFirstCyclicRcv(ulCycRcv);
			
			if (gstCycCtrl.stAppErr.usRcvCycDataDis == (NX_USHORT)NX_ON) {
				
				pstSts->usEstCom = (NX_USHORT)NX_ON;
				pstSts->usCycRcv = (NX_USHORT)NX_OFF;
				pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
				pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
				pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
				pstSts->usHldClrSts = (NX_USHORT)NX_ON;
				
			}
			else {
				
				if (ulCycRcv == (NX_ULONG)NX_ON) {
					
					pstSts->usEstCom = (NX_USHORT)NX_ON;
					pstSts->usCycRcv = (NX_USHORT)NX_ON;
					pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][ulRcvSide];
					pstSts->ulAddrRWw = gaulRWwAddrTbl[ulRcvSide];
#ifdef SAFETY_PDU_ENABLE
					pstSts->ulAddrSpduy = gaulSpduyAddrTbl[ulRcvSide];
#endif
					pstSts->usHldClrSts = gstCycCtrl.stAppErr.usHldClrEn;
				}
				else {
					
					pstSts->usEstCom = (NX_USHORT)NX_ON;
					pstSts->usCycRcv = (NX_USHORT)NX_OFF;
					pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
					pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
					pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
					pstSts->usHldClrSts = gstCycCtrl.usHldClrStsPre;
				}
			}
		}
	}
	
	gstCycCtrl.usHldClrStsPre = pstSts->usHldClrSts;
	
	return;
}



NX_ULONG ulCYC_SwitchSwReadSide2 (
	NX_ULONG		*pulSucceed
)
{
	NX_ULONG	ulSwCmp		= (NX_ULONG)NX_OFF;
	NX_ULONG	ulTimeout	= NX_UL_NG;
	NX_ULONG	ulCurSwReadSide	=	RCV_SIDE_A;
	
	*pulSucceed	= (NX_ULONG)NX_ON;
	
	NGN_RN->R_RNCBKSW2.DATA	= SWITCH_SWRD_HWWRCMP2;
	
	vNX_timer_start(TMID_CYC_RX_SWSD2);
	
	do {
		ulSwCmp = ulINTR_CheckIntLowRx(INTR_RXL_SWREAD_AREA0);
		
		ulTimeout = ulNX_timer_check(TMID_CYC_RX_SWSD2);
		if (NX_UL_OK == ulTimeout) {
			ulSwCmp = ulINTR_CheckIntLowRx(INTR_RXL_SWREAD_AREA0);
			if ((NX_ULONG)NX_ON == ulSwCmp) {
			}
			else {
				*pulSucceed	= (NX_ULONG)NX_OFF;
			}
			break;
		}
		else {
		}
	} while ((NX_ULONG)NX_OFF == ulSwCmp);
	
	vNX_timer_stop(TMID_CYC_RX_SWSD2);

	vINTR_ClearIntLowRx(INTR_RXL_SWREAD_AREA0);
	
	if ((NX_ULONG)NX_ON == *pulSucceed) {
		
		ulCurSwReadSide	=	NGN_RN->R_RNCBKSTS.BITS.b02ZCycSWReadSideSts_Area00;
		
	}
	else {
		
		ulCurSwReadSide	=	RCV_SIDE_A;
	}
	
	return ulCurSwReadSide;
}

NX_VOID vCYC_GetTrnSpldType (
	NX_ULONG	ulSpldMemaddr,
	NX_ULONG	ulPreSpldEndaddr,
	NX_UCHAR	uchPreSpldType,
	NX_UCHAR	uchPreSpldDivNo,
	NX_UCHAR	*puchSpldType,
	NX_UCHAR	*puchSpldDivNo
)
{
	NX_USHORT	usLoop			= NX_ZERO;
	NX_UCHAR	uchSpldType		= SPLD_TYPE_NONE;
	NX_UCHAR	uchSpldDivNo	= NX_ZERO;

	if (MEMADD_STSW == ulSpldMemaddr) {
		uchSpldType = SPLD_TYPE_STSW;
	}

	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusRxSndDataStorageAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulRxSndDataStorageAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_RX;
				break;
			}
		}
	}

	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusRWrSndDataStorageAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulRWrSndDataStorageAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_RWR;
				break;
			}
		}
	}

#ifdef SAFETY_PDU_ENABLE
	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusSpduxSndDataStorageAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulSpduxSndDataStorageAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_SPDUX;
				break;
			}
		}
	}
#endif

	if (SPLD_TYPE_NONE == uchSpldType) {
		if (ulPreSpldEndaddr == ulSpldMemaddr) {
			uchSpldType	 = uchPreSpldType;
			uchSpldDivNo = uchPreSpldDivNo + 1;
		}
	}

	*puchSpldType	= uchSpldType;
	*puchSpldDivNo	= uchSpldDivNo;

	return;
}


NX_VOID vCYC_GetRcvSpldType (
	NX_ULONG	ulSpldMemaddr,
	NX_ULONG	ulPreSpldEndaddr,
	NX_UCHAR	uchPreSpldType,
	NX_UCHAR	uchPreSpldDivNo,
	NX_UCHAR	*puchSpldType,
	NX_UCHAR	*puchSpldDivNo
)
{
	NX_USHORT	usLoop			= NX_ZERO;
	NX_UCHAR	uchSpldType		= SPLD_TYPE_NONE;
	NX_UCHAR	uchSpldDivNo	= NX_ZERO;

	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusRyRcvDataAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulRyRcvDataAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_RY;
				break;
			}
		}
	}

	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusRWwRcvDataAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulRWwRcvDataAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_RWW;
				break;
			}
		}
	}

#ifdef SAFETY_PDU_ENABLE
	if (SPLD_TYPE_NONE == uchSpldType) {
		for (usLoop = NX_ZERO; usLoop < gusSpduyRcvDataAddrTblSize; usLoop++) {
			if(ulSpldMemaddr == gaulSpduyRcvDataAddrTbl[usLoop]) {
				uchSpldType = SPLD_TYPE_SPDUY;
				break;
			}
		}
	}
#endif

	if (SPLD_TYPE_NONE == uchSpldType) {
		if (ulPreSpldEndaddr == ulSpldMemaddr) {
			uchSpldType	 = uchPreSpldType;
			uchSpldDivNo = uchPreSpldDivNo + 1;
		}
	}

	*puchSpldType	= uchSpldType;
	*puchSpldDivNo	= uchSpldDivNo;

	return;
}


NX_VOID vCYC_SetTrnAddrInfo (
	NM_TRN_SPLD		*pstInfo
)
{
	NX_USHORT usLoop = NX_ZERO;

	vNX_FillMemory16(&gstCycTrnAddr, NX_ZERO, sizeof(CYC_TRN_ADDR)/sizeof(NX_USHORT));

	for (usLoop = NX_ZERO; usLoop < TRN_SPLD_NUM; usLoop++) {
		if ((NX_UCHAR)NX_ON == pstInfo[usLoop].uchDataExist) {
			switch (pstInfo[usLoop].uchType) {
				case SPLD_TYPE_STSW:
					gstCycTrnAddr.stStsW[gstCycTrnAddr.usStswNum].ulAddr	= pstInfo[usLoop].ulSndDataAddr + (NX_ULONG)sizeof(SPHEAD_SS_S);
					gstCycTrnAddr.stStsW[gstCycTrnAddr.usStswNum].usSize	= pstInfo[usLoop].usSize;
					gstCycTrnAddr.usStswNum++;
					break;
				case SPLD_TYPE_RX:
					gstCycTrnAddr.stRX[gstCycTrnAddr.usRxNum].ulAddr		= pstInfo[usLoop].ulSndDataAddr + (NX_ULONG)sizeof(SPHEAD_SS_S);
					gstCycTrnAddr.stRX[gstCycTrnAddr.usRxNum].usSize		= pstInfo[usLoop].usSize;
					gstCycTrnAddr.usRxNum++;
					break;
				case SPLD_TYPE_RWR:
					gstCycTrnAddr.stRWr[gstCycTrnAddr.usRWrNum].ulAddr		= pstInfo[usLoop].ulSndDataAddr + (NX_ULONG)sizeof(SPHEAD_SS_S);
					gstCycTrnAddr.stRWr[gstCycTrnAddr.usRWrNum].usSize		= pstInfo[usLoop].usSize;
					gstCycTrnAddr.usRWrNum++;
					break;
#ifdef SAFETY_PDU_ENABLE
				case SPLD_TYPE_SPDUX:
					gstCycTrnAddr.stSpdux[gstCycTrnAddr.usSpduxNum].ulAddr	= pstInfo[usLoop].ulSndDataAddr + (NX_ULONG)sizeof(SPHEAD_SS_S);
					gstCycTrnAddr.stSpdux[gstCycTrnAddr.usSpduxNum].usSize	= pstInfo[usLoop].usSize;
					gstCycTrnAddr.usSpduxNum++;
					break;
#endif
				default:
					break;
			}
		}
		else {
			break;
		}
	}

	return;
}

NX_VOID vCYC_SetRcvAddrInfo (
	NM_RCV_SPLD	*pstInfo
)
{
	NX_USHORT usSpldLoop = NX_ZERO;

	vNX_FillMemory16(&gstCycRcvAddr, NX_ZERO, sizeof(CYC_RCV_ADDR)/sizeof(NX_USHORT));

	for (usSpldLoop = NX_ZERO; usSpldLoop < RCV_SPLD_NUM; usSpldLoop++) {
		if ((NX_UCHAR)NX_ON == pstInfo[usSpldLoop].uchDataExist) {
			switch (pstInfo[usSpldLoop].uchType) {
				case SPLD_TYPE_RY:
					gstCycRcvAddr.stRY[gstCycRcvAddr.usRyNum].ulAddr = pstInfo[usSpldLoop].ulRcvDataAddr;
					gstCycRcvAddr.stRY[gstCycRcvAddr.usRyNum].usSize = pstInfo[usSpldLoop].usSize;
					gstCycRcvAddr.usRyNum++;
					break;
				case SPLD_TYPE_RWW:
					gstCycRcvAddr.stRWw[gstCycRcvAddr.usRWwNum].ulAddr = pstInfo[usSpldLoop].ulRcvDataAddr;
					gstCycRcvAddr.stRWw[gstCycRcvAddr.usRWwNum].usSize = pstInfo[usSpldLoop].usSize;
					gstCycRcvAddr.usRWwNum++;
					break;
#ifdef SAFETY_PDU_ENABLE
				case SPLD_TYPE_SPDUY:
					gstCycRcvAddr.stSpduy[gstCycRcvAddr.usSpduyNum].ulAddr	= pstInfo[usSpldLoop].ulRcvDataAddr;
					gstCycRcvAddr.stSpduy[gstCycRcvAddr.usSpduyNum].usSize	= pstInfo[usSpldLoop].usSize;
					gstCycRcvAddr.usSpduyNum++;
					break;
#endif
				default:
					break;
			}
		}
		else {
			break;
		}
	}

	return;
}

NX_VOID vCYC_PreInitTrnCycData ( NX_VOID )
{
	NX_TRN_CYC_ADDR	stCurTrnCycbuffAddr;
	NX_TRN_CYC_ADDR	stPreTrnCycbuffAddr;
	CYC_TRN_ADDR	*pstSrc;
	NX_TRN_CYC_ADDR	*pstDst;
	NX_ULONG		ulAddrRX;
	NX_ULONG		ulAddrRWr;
	NX_USHORT		usLoopStru;
	NX_USHORT		usLoop;

	for (usLoopStru=NX_ZERO; usLoopStru<2; usLoopStru++) {
		if (NX_ZERO==usLoopStru) {
			pstSrc = &gstCycTrnAddr;
			pstDst = &stCurTrnCycbuffAddr;
		}
		else {
			pstSrc = &gstPreCycTrnAddr;
			pstDst = &stPreTrnCycbuffAddr;
		}

		for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RX; usLoop++) {
			if (usLoop < pstSrc->usRxNum) {
				ulAddrRX = pstSrc->stRX[usLoop].ulAddr;
				pstDst->stRX[usLoop].ulAddr[0]	= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRX;
				pstDst->stRX[usLoop].ulAddr[1]	= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRX;
				pstDst->stRX[usLoop].ulAddr[2]	= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRX;
				pstDst->stRX[usLoop].usSize		= pstSrc->stRX[usLoop].usSize;
			}
			else {
				pstDst->stRX[usLoop].ulAddr[0]	= NX_ZERO;
				pstDst->stRX[usLoop].ulAddr[1]	= NX_ZERO;
				pstDst->stRX[usLoop].ulAddr[2]	= NX_ZERO;
				pstDst->stRX[usLoop].usSize		= NX_ZERO;
			}
		}

		for (usLoop=NX_ZERO; usLoop<NX_SPLD_NUM_RWR; usLoop++) {
			if (usLoop < pstSrc->usRWrNum) {
				ulAddrRWr = pstSrc->stRWr[usLoop].ulAddr;
				pstDst->stRWr[usLoop].ulAddr[0]	= gaulBaseAddrTbl[TRN_SIDE_A] + ulAddrRWr;
				pstDst->stRWr[usLoop].ulAddr[1]	= gaulBaseAddrTbl[TRN_SIDE_B] + ulAddrRWr;
				pstDst->stRWr[usLoop].ulAddr[2]	= gaulBaseAddrTbl[TRN_SIDE_C] + ulAddrRWr;
				pstDst->stRWr[usLoop].usSize	= pstSrc->stRWr[usLoop].usSize;
			}
			else {
				pstDst->stRWr[usLoop].ulAddr[0]	= NX_ZERO;
				pstDst->stRWr[usLoop].ulAddr[1]	= NX_ZERO;
				pstDst->stRWr[usLoop].ulAddr[2]	= NX_ZERO;
				pstDst->stRWr[usLoop].usSize	= NX_ZERO;
			}
		}

		pstDst->usRxNum		= pstSrc->usRxNum;
		pstDst->usRWrNum	= pstSrc->usRWrNum;
	}

	vNX_PreInitTrnCycData(&stPreTrnCycbuffAddr, &stCurTrnCycbuffAddr);

	vNX_CopyMemory16((NX_VOID*)&gstPreCycTrnAddr, (NX_VOID*)&gstCycTrnAddr, sizeof(CYC_TRN_ADDR)/sizeof(NX_USHORT));

	return;
}
/*[EOF]*/
