/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MESSAGE_TLV_H__
#define __PTP_MESSAGE_TLV_H__

#include "ptp_macro.h"

#define PTPM_TLVTYP_MANAGEMENT				(0x0001U)
#define PTPM_TLVTYP_MANAGEMENT_ERR_STAT		(0x0002U)
#define PTPM_TLVTYP_ORGANIZATION_EXTEN		(0x0003U)
#define PTPM_TLVTYP_ANNOUNCE				(0x0008U)

#define PTPM_TLV_ORGANIZATION_ID1			(0x00U)
#define PTPM_TLV_ORGANIZATION_ID2			(0x80U)
#define	PTPM_TLV_ORGANIZATION_ID3			(0xC2U)
#define	PTPM_TLV_ORGANIZATION_ID(a)			(a[0]=PTPM_TLV_ORGANIZATION_ID1);\
											(a[1]=PTPM_TLV_ORGANIZATION_ID2);\
											(a[2]=PTPM_TLV_ORGANIZATION_ID3)
#define PTPM_TLV_ORGANIZATION_SUBTYP1		(0U)
#define PTPM_TLV_ORGANIZATION_SUBTYP2		(0U)
#define PTPM_TLV_ORGANIZATION_SUBTYP3		(1U)
#define PTPM_TLV_ORGANIZATION_SUBTYP(a)		(a[0]=PTPM_TLV_ORGANIZATION_SUBTYP1);\
											(a[1]=PTPM_TLV_ORGANIZATION_SUBTYP2);\
											(a[2]=PTPM_TLV_ORGANIZATION_SUBTYP3)
#define	PTPM_TLV_LINK_DELAY_INTVAL_STOP		(127)
#define	PTPM_TLV_LINK_DELAY_INTVAL_INIT		(126)
#define	PTPM_TLV_LINK_DELAY_INTVAL_NCHG		(-128)
#define	PTPM_TLV_TIME_SYNC_INTVAL_STOP		(127)
#define	PTPM_TLV_TIME_SYNC_INTVAL_INIT		(126)
#define	PTPM_TLV_TIME_SYNC_INTVAL_NCHG		(-128)
#define	PTPM_TLV_ANNOUNCE_INTVAL_STOP		(127)
#define	PTPM_TLV_ANNOUNCE_INTVAL_INIT		(126)
#define	PTPM_TLV_ANNOUNCE_INTVAL_NCHG		(-128)

#define MPTPM_ISFLAG_INTERVAL_ONESTEP(tlv)	PTP_GET_BITS(&(tlv)->byFlags, 2, 2)
#define MPTPM_ISFLAG_CNEIGHBORPROP(tlv)		PTP_GET_BITS(&(tlv)->byFlags, 1, 1)
#define MPTPM_ISFLAG_CNEIGHBORRATE(tlv)	    PTP_GET_BITS(&(tlv)->byFlags, 0, 0)



typedef struct tagPTPMSG_FOLLOWUP_TLV{
	USHORT				usTLVType;
	USHORT				usLengthField;
	UCHAR				uchOrganizationID[3];
	UCHAR				uchOrganizationSubType[3];
	LONG				lCmltvScaledRateOffset;
	USHORT				usGMTmBaseIndicator;
	SCALEDNS			stLstGMPhsChange;
	LONG				lScaledLstGMFrqChange;

}	PTPMSG_FOLLOWUP_TLV;

#define	GetPTPMSG_FOLLOWUP_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).uchOrganizationID))		\
				+	(sizeof((a).uchOrganizationSubType))	\
				+	(sizeof((a).lCmltvScaledRateOffset))	\
				+	(sizeof((a).usGMTmBaseIndicator))		\
				+	(sizeof((a).stLstGMPhsChange.sNsec_msb))	\
				+	(sizeof((a).stLstGMPhsChange.ulNsec_2nd))	\
				+	(sizeof((a).stLstGMPhsChange.ulNsec_lsb))	\
				+	(sizeof((a).stLstGMPhsChange.usFrcNsec))	\
				+	(sizeof((a).lScaledLstGMFrqChange));	\
			DEBUG_PRINT("GetPTPMSG_FOLLOWUP_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_FOLLOWUP_TLV));	\
		}

#define PTPMSG_FOLLOWUP_TLV_SZ				32U
#define PTPMSG_FLWUPT_TLVTYPE_SZ			2U
#define PTPMSG_FLWUPT_TLVLENGTH_SZ			2U
#define PTPMSG_FLWUPT_ORGANIZATIONID_SZ		3U
#define PTPMSG_FLWUPT_ORGSUBTYPE_SZ			3U
#define PTPMSG_FLWUPT_CMSCLDRATEOFS_SZ		4U
#define PTPMSG_FLWUPT_GMTMBASEINDCTR_SZ		2U
#define PTPMSG_FLWUPT_LSTGMPHSCHG_SZ		12U
#define PTPMSG_FLWUPT_SCLDLSTGMFRQCHG_SZ	4U


typedef struct tagPTPMSG_INTERVAL_TLV{
	USHORT				usTLVType;
	USHORT				usLengthField;
	UCHAR				uchOrganizationID[3];
	UCHAR				uchOrganizationSubType[3];
	CHAR				chLinkDelayInterval;
	CHAR				chTimeSyncInterval;
	CHAR				chAnnounceInterval;
	BYTE	            byFlags;

	UCHAR				uchReserved[2];

}	PTPMSG_INTERVAL_TLV;



#define	GetPTPMSG_INTERVAL_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).uchOrganizationID))		\
				+	(sizeof((a).uchOrganizationSubType))	\
				+	(sizeof((a).chLinkDelayInterval))	\
				+	(sizeof((a).chTimeSyncInterval))	\
				+	(sizeof((a).chAnnounceInterval))	\
				+	(sizeof((a).byFlags))		\
				+	(sizeof((a).uchReserved));	\
			DEBUG_PRINT("GetPTPMSG_INTERVAL_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_INTERVAL_TLV));	\
		}
#define PTPMSG_INTVL_TVLTYPE_SZ			2U
#define PTPMSG_INTVL_TLVLENGTH_SZ		2U
#define PTPMSG_INTVL_ORGANIZATIONID_SZ	3U
#define PTPMSG_INTVL_ORGSUBTYPE_SZ		3U
#define PTPMSG_INTVL_LKDLYINTVAL_SZ		1U
#define PTPMSG_INTVL_TMSYNINTVAL_SZ		1U
#define	PTPMSG_INTVL_ANUNCINTVAL_SZ		1U
#define	PTPMSG_INTVL_FLAGS_SZ			1U
#define	PTPMSG_INTVL_RESERVED_SZ		2U





typedef struct tagPTPMSG_GPTPCAPABLE_TLV
{
	USHORT	usTLVType;
	USHORT	usLengthField;
	UCHAR	uchOrganizationID[3];
	UCHAR	uchOrganizationSubType[3];
	CHAR	chlogGptpCapableMessageInterval;
	BYTE	byFlags;
	UCHAR	uchReserved[4];
}PTPMSG_GPTPCAPABLE_TLV;

#define	GetPTPMSG_GPTPCAPABLE_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).uchOrganizationID))		\
				+	(sizeof((a).uchOrganizationSubType))	\
				+	(sizeof((a).chlogGptpCapableMessageInterval))	\
				+	(sizeof((a).byFlags))		\
				+	(sizeof((a).uchReserved));	\
			DEBUG_PRINT("GetPTPMSG_GPTPCAPABLE_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_GPTPCAPABLE_TLV));	\
		}

#define PTPMSG_GPTPCAP_TVLTYPE_SZ			2U
#define PTPMSG_GPTPCAP_TLVLENGTH_SZ			2U
#define PTPMSG_GPTPCAP_ORGANIZATIONID_SZ	3U
#define PTPMSG_GPTPCAP_ORGSUBTYPE_SZ		3U
#define PTPMSG_GPTPCAP_LOGGPTPCAPMSGINT_SZ	1U
#define	PTPMSG_GPTPCAP_FLAGS_SZ				1U
#define	PTPMSG_GPTPCAP_RESERVED_SZ			4U


typedef struct tagPTPMSG_GPTPCAPABLE_INT_TLV
{
	USHORT	usTLVType;
	USHORT	usLengthField;
	UCHAR	uchOrganizationID[3];
	UCHAR	uchOrganizationSubType[3];
	CHAR	chlogGptpCapableMessageInterval;
	UCHAR	uchReserved[3];
}PTPMSG_GPTPCAPABLE_INT_TLV;


#define	GetPTPMSG_GPTPCAPABLE_INT_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).uchOrganizationID))		\
				+	(sizeof((a).uchOrganizationSubType))	\
				+	(sizeof((a).chlogGptpCapableMessageInterval))	\
				+	(sizeof((a).uchReserved));	\
			DEBUG_PRINT("GetPTPMSG_GPTPCAPABLE_INT_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_GPTPCAPABLE_INT_TLV));	\
		}

#define PTPMSG_GPTPCAPINT_TVLTYPE_SZ			2U
#define PTPMSG_GPTPCAPINT_TLVLENGTH_SZ			2U
#define PTPMSG_GPTPCAPINT_ORGANIZATIONID_SZ		3U
#define PTPMSG_GPTPCAPINT_ORGSUBTYPE_SZ			3U
#define PTPMSG_GPTPCAPINT_LOGGPTPCAPMSGINT_SZ	1U
#define	PTPMSG_GPTPCAPINT_RESERVED_SZ			4U


#define PTPMSG_TLV_ORGSUBTYPE_INTERVAL		2U
#define PTPMSG_TLV_ORGSUBTYPE_GPTPCAP		4U
#define PTPMSG_TLV_ORGSUBTYPE_GPTPCAPINT	5U



typedef struct tagPTPMSG_ANNOUNCE_TLV{
	USHORT				usTLVType;
	USHORT				usLengthField;
	CLOCKIDENTITY		stPathSequence[PTP_MAX_PATHTRACE];
}	PTPMSG_ANNOUNCE_TLV;

#define	GetPTPMSG_ANNOUNCE_TLV(a,b) \
		{	\
			(b) +=	(sizeof((a).usTLVType))		\
				+	(sizeof((a).usLengthField))	\
				+	(sizeof((a).stPathSequence[0].uchId));	\
			DEBUG_PRINT("GetPTPMSG_ANNOUNCE_TLV = %d sizeof(%d) \n",(b), sizeof(PTPMSG_ANNOUNCE_TLV));	\
		}

#define PTPMSG_ANNUNCETLV_TLVTYPE_SZ			2U
#define PTPMSG_ANNUNCETLV_TLVLENGTH_SZ			2U

#endif
