/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3TYPESSLMP_H__
#define __R_IN32M4_CL3TYPESSLMP_H__


/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "common.h"
#include "R_IN32M4_CL3Types.h"
#include "R_IN32M4_CL3Environment.h"


/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
/* SLMP Frame */
#define	R_IN_SLMP_FRAME_TYPE_3E_REQ							(0x0050)		/* ST(3E) request frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_3E_RES							(0x00D0)		/* ST(3E) response frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_4E_REQ							(0x0054)		/* MT(4E) request frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_4E_RES							(0x00D4)		/* MT(4E) response frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_5E_REQ							(0x0055)		/* EMT(5E) request frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_5E_RES							(0x00D5)		/* EMT(5E) response frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_6E_REQ							(0x0068)		/* LMT(6E) request frame type											*/
#define	R_IN_SLMP_FRAME_TYPE_6E_RES							(0x00E8)		/* LMT(6E) response frame type											*/
#define	R_IN_SLMP_FRAME_HEAD_3E_REQ_SIZE					(15)			/* ST(3E) request header frame byte size								*/
#define	R_IN_SLMP_FRAME_HEAD_3E_RES_SIZE					(11)			/* ST(3E) response header frame byte size								*/
#define	R_IN_SLMP_FRAME_HEAD_4E_REQ_SIZE					(19)			/* MT(4E) request header frame byte size								*/
#define	R_IN_SLMP_FRAME_HEAD_4E_RES_SIZE					(15)			/* MT(4E) response header frame byte size								*/
#define	R_IN_SLMP_FRAME_HEAD_6E_SIZE						(28)			/* LMT(6E) request,response header frame byte size						*/
#define	R_IN_SLMP_FRAME_HEAD_3E4E_WATCH_TIMER_SUBCOM_SIZE	(6)				/* Sub command size from ST(3E),MT(4E) frame timer						*/
#define	R_IN_SLMP_FRAME_HEAD_3E4E_FIN_SIZE					(2)				/* ST(3E),MT(4E) frame finish code size									*/
#define	R_IN_SLMP_FRAME_HEAD_6E_WATCH_TIMER_SPLIT_SIZE		(12)			/* Size between LMT(6E) request frame timer and division number			*/
#define	R_IN_SLMP_FRAME_HEAD_6E_FIN_SPLIT_SIZE				(12)			/* Size between LMT(6E) response frame finish code and division number	*/
#define	R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX	(361)			/* LMT(6E) request,response data size (double word)						*/
#define R_IN_SLMP_SPLIT_FRAME_NUM							(3)				/* Maximum number of frames for split transmission						*/

/* SLMP finish code */
#define	R_IN_SLMP_FIN_CODE_NORMAL										(0x0000)		/* Request completed successfully														*/
#define	R_IN_SLMP_FIN_CODE_ERR_SQ										(0xC059)		/* A command other than the specified sequence was received								*/
#define	R_IN_SLMP_FIN_CODE_ERR_REQ										(0xC05C)		/* There is an error in the request														*/
#define	R_IN_SLMP_FIN_CODE_ERR_EXCLUSIVE								(0xCEE0)		/* Request cannot be processed because another request is in progress					*/
#define	R_IN_SLMP_FIN_CODE_ERR_NO_PARAMETER								(0xCF30)		/* Specified parameter ID does not exist												*/
#ifdef TSN_CAN_ENABLE
#define	R_IN_SLMP_FIN_CODE_ERR_CANNOT_READ_OR_SAVE_AS_STATE				(0xCCC7)		/* Accessing the object under conditions where access to the object is not permitted	*/
#define	R_IN_SLMP_FIN_CODE_ERR_NO_READ_OBJECT							(0xCCC8)		/* Read access to a write-only object													*/
#define	R_IN_SLMP_FIN_CODE_ERR_NO_WRITE_OBJECT							(0xCCC9)		/* Write access to a read-only object													*/
#define	R_IN_SLMP_FIN_CODE_ERR_OBJECT_NOT_EXISTING						(0xCCCA)		/* Index not defined in OD is specified													*/
#define	R_IN_SLMP_FIN_CODE_ERR_PDO_MAPPING_DISAPPROVAL					(0xCCCB)		/* You mapped an object for which PDO mapping is not allowed							*/
#define	R_IN_SLMP_FIN_CODE_ERR_PDO_MAPPING_DATA_LENGTH					(0xCCCC)		/* The total number of data and data length for PDO mapping exceeds the value defined by the application etc.	*/
#define	R_IN_SLMP_FIN_CODE_ERR_SUBINDEX_NOT_EXISTING					(0xCCD3)		/* SubIndex not defined in OD is specified												*/
#define	R_IN_SLMP_FIN_CODE_ERR_NO_PARAM									(0xCCD4)		/* Request parameter out of range														*/
#define	R_IN_SLMP_FIN_CODE_ERR_VALUE_TOO_GREAT							(0xCCD5)		/* Set a value larger than the parameter range											*/
#define	R_IN_SLMP_FIN_CODE_ERR_VALUE_TOO_SMALL							(0xCCD6)		/* Set a value smaller than the parameter range											*/
#define	R_IN_SLMP_FIN_CODE_ERR_CANNOT_TRANSFER_OR_STORE					(0xCCDA)		/* Application cannot transfer or store data											*/
#define	R_IN_SLMP_FIN_CODE_ERR_CAN_ERROR								(0xCCFF)		/* CAN application error																*/
#endif

/* Receive SLMP frame type specification */
#define	R_IN_SLMP_FRAME_TYPE_3E								(0x0001)		/* ST(3E) frame specification											*/
#define	R_IN_SLMP_FRAME_TYPE_4E								(0x0002)		/* MT(4E) frame specification											*/
#define	R_IN_SLMP_FRAME_TYPE_6E								(0x0008)		/* LMT(6E) frame specification											*/
#define	R_IN_SLMP_FRAME_TYPE_3E4E6E							(R_IN_SLMP_FRAME_TYPE_3E | R_IN_SLMP_FRAME_TYPE_4E | R_IN_SLMP_FRAME_TYPE_6E)
																			/* ST(3E),MT(4E),LMT(6E) frame specification							*/
/* SLMP received result  */
#define	R_IN_SLMP_RECEIVED_RESULT_NORMAL					(0x0000)		/* No error																*/
#define	R_IN_SLMP_RECEIVED_RESULT_ERR_DATALEN				(0x0100)		/* Data length error detected											*/

/* Time-out execution function */
typedef	VOID (* R_IN_TIMEOUT_FUNCTION)(VOID);


/*********************************************************************************/
/* Structures                                                                    */
/*********************************************************************************/
/* Request data (received) additional information */
typedef struct R_IN_SLMP_RECEIVE_INFORMATION_TAG {
	USHORT	usRequestDataSize;												/* Request data size									*/
	USHORT	usFType;														/* Frame type											*/
	USHORT	usSerialNo;														/* Serial number										*/
	USHORT	usReserved2;													/* For future expansion									*/
	USHORT	usDstProcNo;													/* Request destination processor number					*/
	UCHAR	uchMultiDropNo;													/* Multidrop station number								*/
	UCHAR	uchReserved3;													/* For future expansion									*/
	USHORT	usLargeNodeNo;													/* Request destination Extended station number			*/
	USHORT	usTimer;														/* Timer												*/
	UCHAR	uchReserved4;													/* For future expansion									*/
	UCHAR	uchReqDataId;													/* Message identification value							*/
	USHORT	usDataDevideNum;												/* Total divisions										*/
	USHORT	usDataNumber;													/* Division number										*/
	ULONG	ulIPAddress;													/* IP address											*/
	USHORT	usPhysicalPort;													/* Physical port number									*/
	USHORT	usReceivedResult;												/* Slmp received result									*/
} R_IN_SLMP_RECEIVE_INFORMATION_T;

/* Response data (send) additional information */
typedef struct R_IN_SLMP_SEND_INFORMATION_TAG {
	USHORT	usResponseDataSize;												/* Response data size									*/
	USHORT	usFinishCode;													/* Finish code											*/
} R_IN_SLMP_SEND_INFORMATION_T;

/* Response data (received) additional information */
typedef struct R_IN_SLMP_RECEIVE_RESPONSE_INFORMATION_TAG {
	USHORT	usResponseDataSize;												/* Response data size									*/
	USHORT	usFType;														/* Frame type											*/
	USHORT	usSerialNo;														/* Serial number										*/
	USHORT	usReserved2;													/* For future expansion									*/
	USHORT	usDstProcNo;													/* Request destination processor number					*/
	UCHAR	uchMultiDropNo;													/* Multidrop station number								*/
	UCHAR	uchReserved3;													/* For future expansion									*/
	USHORT	usLargeNodeNo;													/* Request destination Extended station number			*/
	USHORT	usFinishCode;													/* Finish code											*/
	UCHAR	uchReserved4;													/* For future expansion									*/
	UCHAR	uchResDataId;													/* Message identification value							*/
	USHORT	usDataDevideNum;												/* Total divisions										*/
	USHORT	usDataNumber;													/* Division number										*/
	ULONG	ulIPAddress;													/* IP address											*/
	USHORT	usPhysicalPort;													/* Physical port number									*/
	USHORT	usReceivedResult;												/* Slmp received result									*/
} R_IN_SLMP_RECEIVE_RESPONSE_INFORMATION_T;


/* Receive response command execution function */
typedef	VOID (* R_IN_SLMP_RESPONSE_FUNCTION)(const VOID* pvResponseDataOffset, R_IN_SLMP_RECEIVE_RESPONSE_INFORMATION_T* pstReceiveResponseInformation);

/* Receive request command execution function */
typedef	ERRCODE (* R_IN_SLMP_REQUEST_FUNCTION)(VOID* pvRequestData, R_IN_SLMP_RECEIVE_INFORMATION_T* pstRequestInformation, VOID* pvReceiveData ,R_IN_SLMP_SEND_INFORMATION_T* pstReceiveInformation);

/* SLMP request execution functions table structure */
typedef struct R_IN_SLMP_FUNCTION_REQUEST_TBL_TAG {
	USHORT	usCommand;														/* SLMP command											*/
	USHORT	usSubCommand;													/* SLMP subcommand										*/
	R_IN_SLMP_REQUEST_FUNCTION	fperFunction;								/* Command function pointer								*/
	BOOL	blBroadCastSend;												/* Broadcast sent or not								*/
	ULONG	ulFrameType;													/* Frame type specification								*/
	BOOL	blFrameTypeErrorSuppression;									/* Error response suppression when frame type specification mismatch */
	USHORT	usDataLengthErrorFincode;										/* Exit code when request data length is abnormal		*/
} R_IN_SLMP_FUNCTION_REQUEST_TBL_T;


/* SLMP response execution functions table structure */
typedef struct R_IN_SLMP_FUNCTION_RESPONSE_TBL_TAG {
	USHORT	usCommand;														/* SLMP command											*/
	USHORT	usSubCommand;													/* SLMP subcommand										*/
	R_IN_SLMP_RESPONSE_FUNCTION	fpvFunction;								/* Command function pointer								*/
	ULONG	ulFrameType;													/* Frame type specification								*/
	BOOL	blDataLengthErrorDetection;										/* Settings when response data length is abnormal		*/
} R_IN_SLMP_FUNCTION_RESPONSE_TBL_T;


/* SLMP receive execution functions table structure */
typedef struct R_IN_SLMP_EXECUTION_RECEIVE_TBL_TAG {
	USHORT								usRequestNumber;					/* Number of registered request commands				*/
	USHORT								usResponseNumber;					/* Number of registered response commands				*/
	R_IN_SLMP_FUNCTION_REQUEST_TBL_T*	pstRequest;							/* Request command execution function table pointer		*/
	R_IN_SLMP_FUNCTION_RESPONSE_TBL_T*	pstResponse;						/* Response command execution function table pointer	*/
	R_IN_SLMP_RESPONSE_FUNCTION			fpv3EFunction;						/* ST(3E) response frame reception function pointer		*/
} R_IN_SLMP_EXECUTION_RECEIVE_TBL_T;


#pragma pack(1)
/* SLMP ST(3E) frame structure */
typedef struct R_IN_SLMP_3E_FRAME_HEAD_TAG {
	USHORT	usFrameType;													/* Frame type											*/
	UCHAR	uchNetworkNumber;												/* Request destination network number					*/
	UCHAR	uchStationNumber;												/* Request destination station number					*/
	USHORT	usProcessorNumber;												/* Request destination processor number					*/
	UCHAR	uchMultiDropNo;													/* Multidrop station number								*/
} R_IN_SLMP_3E_FRAME_HEAD_T;


/* SLMP ST(3E) request frame structure */
typedef struct R_IN_SLMP_3E_FRAME_REQUEST_TAG {
	R_IN_SLMP_3E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usByteSize;														/* Request data length									*/
	USHORT	usTimer;														/* Timer												*/
	USHORT	usCommand;														/* Commands												*/
	USHORT	usSubCommand;													/* Subcommands											*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Request data											*/
} R_IN_SLMP_3E_FRAME_REQUEST_T;


/* SLMP ST(3E) response frame structure */
typedef struct R_IN_SLMP_3E_FRAME_RESPONSE_TAG {
	R_IN_SLMP_3E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usByteSize;														/* Response data length									*/
	USHORT	usFinishCode;													/* Finish code											*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Response data										*/
} R_IN_SLMP_3E_FRAME_RESPONSE_T;

/* SLMP MT(4E) frame structure */
typedef struct R_IN_SLMP_4E_FRAME_HEAD_TAG {
	USHORT	usFrameType;													/* Frame type											*/
	USHORT	usSerialNumber;													/* Serial number										*/
	USHORT	usReserve1;														/* For future expansion									*/
	UCHAR	uchNetworkNumber;												/* Request destination network number					*/
	UCHAR	uchStationNumber;												/* Request destination station number					*/
	USHORT	usProcessorNumber;												/* Request destination processor number					*/
	UCHAR	uchMultiDropNo;													/* Multidrop station number								*/
} R_IN_SLMP_4E_FRAME_HEAD_T;


/* SLMP MT(4E) request frame structure */
typedef struct R_IN_SLMP_4E_FRAME_REQUEST_TAG {
	R_IN_SLMP_4E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usByteSize;														/* Request data length									*/
	USHORT	usTimer;														/* Timer												*/
	USHORT	usCommand;														/* Command												*/
	USHORT	usSubCommand;													/* Subcommand											*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Request data											*/
} R_IN_SLMP_4E_FRAME_REQUEST_T;


/* SLMP MT(4E) response frame structure */
typedef struct R_IN_SLMP_4E_FRAME_RESPONSE_TAG {
	R_IN_SLMP_4E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usByteSize;														/* Response data length									*/
	USHORT	usFinishCode;													/* Finish code											*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Response data										*/
} R_IN_SLMP_4E_FRAME_RESPONSE_T;


/* SLMP LMT(6E) frame structure */
typedef struct R_IN_SLMP_6E_FRAME_HEAD_TAG {
	USHORT	usFrameType;													/* Frame type											*/
	USHORT	usSerialNumber;													/* Serial number										*/
	USHORT	usReserve1;														/* For future expansion									*/
	UCHAR	uchNetworkNumber;												/* Request destination network number					*/
	UCHAR	uchStationNumber;												/* Request destination station number					*/
	USHORT	usProcessorNumber;												/* Request destination processor number					*/
	UCHAR	uchMultiDropNo;													/* Multidrop station number								*/
	UCHAR	uchReserve3;													/* For future expansion									*/
} R_IN_SLMP_6E_FRAME_HEAD_T;


/* SLMP LMT(6E) request frame structure */
typedef struct R_IN_SLMP_6E_FRAME_REQUEST_TAG {
	R_IN_SLMP_6E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usExtendedStationNumber;										/* Request destination Extended station number			*/
	USHORT	usByteSize;														/* Request data length									*/
	USHORT	usTimer;														/* Timer												*/
	USHORT	usCommand;														/* Command												*/
	USHORT	usSubCommand;													/* Subcommand											*/
	UCHAR	uchReserve;														/* For future expansion									*/
	UCHAR	uchDataId;														/* Message identification value							*/
	USHORT	usDataDevideNum;												/* Total divisions										*/
	USHORT	usDataNumber;													/* Division number										*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Request data											*/
} R_IN_SLMP_6E_FRAME_REQUEST_T;


/* SLMP LMT(6E) response frame structure */
typedef struct R_IN_SLMP_6E_FRAME_RESPONSE_TAG {
	R_IN_SLMP_6E_FRAME_HEAD_T	stSlmpHead;									/* SLMP header information								*/
	USHORT	usExtendedStationNumber;										/* Request destination Extended station number			*/
	USHORT	usByteSize;														/* Response data length									*/
	USHORT	usFinishCode;													/* Finish code											*/
	USHORT	usCommand;														/* Command												*/
	USHORT	usSubCommand;													/* Subcommand											*/
	UCHAR	uchReserve;														/* For future expansion									*/
	UCHAR	uchDataId;														/* Message identification value							*/
	USHORT	usDataDevideNum;												/* Total divisions										*/
	USHORT	usDataNumber;													/* Division number										*/
	ULONG	aulDataArea[R_IN_SLMP_FRAME_REQUEST_RESPONSE_D_WORD_SIZE_MAX];	/* Response data										*/
} R_IN_SLMP_6E_FRAME_RESPONSE_T;
#pragma pack()


#endif

/*** EOF ***/
