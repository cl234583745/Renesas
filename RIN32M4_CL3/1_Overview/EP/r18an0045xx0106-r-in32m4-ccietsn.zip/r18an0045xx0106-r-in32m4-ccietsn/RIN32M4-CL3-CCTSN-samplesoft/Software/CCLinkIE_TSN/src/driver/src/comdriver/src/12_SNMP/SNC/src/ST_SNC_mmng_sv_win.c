/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNC_mib.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_UTI.h"
#include <winsock2.h>
#include <Windows.h>
#include "msw_lldp.h"
#include "lldpd.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#else
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mset_sv_l.h>
#include <28_NPS/Include/ST_UTI.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ccienx_api.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNM_mibentry_sv_l.h"

#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#include "ST_SNC_errcode.h"
#endif

#define _OK_		1
#define _NG_		0

#ifdef MASTER
#else
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
#endif
#define ST_SNC_MEMCNT_NOUSE         0
#define ST_SNC_MEMCNT_USED          1

#ifdef SWPS
typedef struct ST_SNC_MemoryCountObject_TAG {
	const NX_UCHAR					ucUse;
	NX_UCHAR						ucPadding[3];
	ST_SNC_MemoryCount			eRead;
	ST_SNC_MemoryCount			eWrite;
} ST_SNC_MemoryCountObject;


typedef struct ST_SNC_MemoryObject_TAG {
	ST_SNC_MemoryCountObject	stCnt;
	ST_SNC_ExecObj*				pstObj[ST_SNC_MEMCNT_MAX];
	NX_VOID*						pvMib[ST_SNC_MEMCNT_MAX];
	NX_ULONG						ulSize;
} ST_SNC_MemoryObject;
#endif


typedef struct ST_SNC_MemoryObjectManage_TAG {
	ST_SNC_MemoryObject*		pstObj;
} ST_SNC_MemoryObjectManage;


typedef struct ST_SNC_MemoryObjectFunction_TAG {
	NX_ULONG (*alloc  )(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pObj);
	NX_ULONG (*free   )(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pObj);
	NX_ULONG (*clear  )(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pObj, ST_SNC_MemoryCount eMemCount);
	NX_ULONG (*getaddr)(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pObj, ST_SNC_MemoryCount eMemCount, NX_VOID** pAddr);
	NX_ULONG (*set    )(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pObj, const ST_SNC_MibMng* pstMib, const NX_VOID* pData);
} ST_SNC_MemoryObjectFunction;

typedef struct ST_SNC_MemoryFunction_TAG {
	NX_ULONG (*alloc  )(ST_SNC_MemoryCount eCnt, NX_VOID** pvAddr);
	NX_VOID  (*free   )(NX_VOID** pvAddr);
	NX_VOID  (*clear  )(NX_VOID*  pvAddr);
	NX_ULONG  (*getaddr)(NX_VOID* pvMib, NX_VOID** pvAddr);
	NX_ULONG (*set    )(const ST_SNC_MibMng* pstMib, const NX_VOID* pData, NX_VOID* pvAddr, NX_ULONG ulSize);
	NX_ULONG (*commit )(ST_SNC_Mibtype eMibType);
} ST_SNC_MemoryFunction;

static NX_ULONG ulST_SNC_SwitchMemcntObjct(ST_SNC_MemoryCountObject *pstObj);

static NX_ULONG ulST_SNC_MibAllocMemoryObjectNetworkConfig(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
static NX_ULONG ulST_SNC_MibAllocMemoryObjectDeviceDetail(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
static NX_ULONG ulST_SNC_MibAllocMemoryObject(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
#ifdef SWPS
#endif


static NX_ULONG ulST_SNC_MibAllocNetworkConfig(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocDeviceDetail(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocOtherModule(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocStatisticalInfo(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocIpOverlapError(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocIpTopologyError(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocDatalinkError(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocCommTimingError(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibAllocCurrentError(ST_SNC_MemoryCount eCnt, NX_VOID** pAddr);
#ifdef SWPS
#endif


static NX_ULONG ulST_SNC_MibFreeMemoryObjectNetworkConfig(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
static NX_ULONG ulST_SNC_MibFreeMemoryObjectDeviceDetail(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
static NX_ULONG ulST_SNC_MibFreeMemoryObject(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject* pstObj);
#ifdef SWPS
#endif

static NX_VOID ST_SNC_MibFreeAddr(NX_VOID** pAddr);

static NX_ULONG ulST_SNC_MibAllClearNetConfDevDtl(NX_VOID);
static NX_ULONG ulST_SNC_MibAllClearOther(NX_VOID);
static NX_ULONG ulST_SNC_MibClearMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj,
	ST_SNC_MemoryCount		eCount
);
static NX_VOID ST_SNC_MibClearNetworkConfig(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearDeviceDetail(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearOtherModule(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearStatisticalInfo(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearIpOverlapError(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearIpTopologyError(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearDatalinkError(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearCommTimingError(NX_VOID* pAddr);
static NX_VOID ST_SNC_MibClearCurrentError(NX_VOID* pAddr);
#ifdef SWPS
#endif

static NX_ULONG ulST_SNC_MibGetAddrMemoryObject(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject *pstObj, ST_SNC_MemoryCount eMemCount, NX_VOID** pAddr);
static NX_ULONG ulST_SNC_MibGetAddrMemory(NX_VOID *pMib, NX_VOID** pAddr);

static NX_ULONG ulST_SNC_MibSetMemoryObject(ST_SNC_Mibtype eMibType, ST_SNC_MemoryObject *pstObj, const ST_SNC_MibMng* pstMib, const NX_VOID* pData);
#ifdef SWPS
extern NX_ULONG ulST_SNC_MibCommit(ST_SNC_Mibtype eMibType);
#else
static NX_ULONG ulST_SNC_MibCommit(ST_SNC_Mibtype eMibType);
#endif
static NX_ULONG ulST_SNC_CommitMib(ST_SNC_Mibtype eMibType);


#ifdef SWPS
LLDPD_MIB_T                       lldpdMib;
LLDPD_REM_TBL_T                   rem_tbl[LLDPD_REM_TBL_NUM];

void (*usswLldpdLockFunc)(void) = NX_NULL;
void (*usswLldpdUnLockFunc)(void) = NX_NULL;
#endif

ST_SNC_N1MibNetworkConfig         gaST_SNC_MibNetCnf[ST_SNC_MEMCNT_MAX];
ST_SNC_N1MibDeviceDetail          gaST_SNC_MibDevDtl[ST_SNC_MEMCNT_MAX];
ST_SNC_N1MibOtherModule           gST_SNC_MibOthMod;
ST_SNC_N1MibStatisticalInfo       gST_SNC_MibStaInf;
ST_SNC_N1MibIpOverlapError        gST_SNC_MibOvrErr;
ST_SNC_N1MibIpTopologyError       gST_SNC_MibTopErr;
ST_SNC_N1MibDatalinkError         gST_SNC_MibDatErr;
ST_SNC_N1MibCommTimingError       gST_SNC_MibComErr;
ST_SNC_N1MibCurrentError          gST_SNC_MibCurErr;

NX_USHORT 	gusST_SNC_ErrorOccurrenceOrderNo;
#ifdef CURERR_OPTIONINFO_ENABLE
NX_USHORT 	gusST_SNC_OptErrorOccurrenceOrderNo[ST_SNC_ERRREG_OPT_MAX];
#endif


static ST_SNC_MemoryObjectManage gST_SNC_Manage ={
	NX_NULL
};


#ifdef SWPS
static CRITICAL_SECTION			gaST_SNC_MemLockObj[ST_SNC_MIBTYPE_MAX][ST_SNC_MEMCNT_MAX];
#else
static NX_ULONG					gaST_SNC_MemLockObj[ST_SNC_MIBTYPE_MAX][ST_SNC_MEMCNT_MAX];
#endif
static ST_SNC_ExecObj			gaST_SNC_ExecObj[ST_SNC_MIBTYPE_MAX][ST_SNC_MEMCNT_MAX] = {
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_NWCFG      ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_00, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_NWCFG      ][ST_SNC_MEMCNT_2ND], ST_SNC_EXECNO_01, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_DEVDTL     ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_02, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_DEVDTL     ][ST_SNC_MEMCNT_2ND], ST_SNC_EXECNO_03, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_OTMDL      ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_04, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_OTMDL      ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_05, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_STATS      ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_06, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_STATS      ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_07, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_IPOVERLAP  ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_08, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_IPOVERLAP  ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_09, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_TOPOLOGY   ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_10, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_TOPOLOGY   ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_11, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_DATALINK   ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_16, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_DATALINK   ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_17, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_COMTIMING  ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_18, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_COMTIMING  ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_19, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_CURERR     ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_20, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_CURERR     ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_21, {0}}},
#ifdef SWPS
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP       ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_22, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP       ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_23, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_AGENT ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_24, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_AGENT ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_25, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_LOCAL ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_26, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_LOCAL ][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_27, {0}}},
	{{&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_REMOTE][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_28, {0}}, {&gaST_SNC_MemLockObj[ ST_SNC_MIBTYPE_LLDP_REMOTE][ST_SNC_MEMCNT_1ST], ST_SNC_EXECNO_29, {0}}},
#endif
	{{NX_NULL,                                                                 ST_SNC_EXECNO_30, {0}}, {NX_NULL,                                                                 ST_SNC_EXECNO_31, {0}}},
};

#ifdef SWPS
static ST_SNC_MemoryObject		gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_MAX] = {
#else
ST_SNC_MemoryObject				gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_MAX] = {
#endif
	{ {ST_SNC_MEMCNT_USED , {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_2ND}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_NWCFG      ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_NWCFG      ][ST_SNC_MEMCNT_2ND]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibNetworkConfig)         },
	{ {ST_SNC_MEMCNT_USED , {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_2ND}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_DEVDTL     ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_DEVDTL     ][ST_SNC_MEMCNT_2ND]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibDeviceDetail)          },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_OTMDL      ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_OTMDL      ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibOtherModule)           },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_STATS      ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_STATS      ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibStatisticalInfo)       },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_IPOVERLAP  ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_IPOVERLAP  ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibIpOverlapError)        },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_TOPOLOGY   ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_TOPOLOGY   ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibIpTopologyError)       },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_DATALINK   ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_DATALINK   ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibDatalinkError)         },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_COMTIMING  ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_COMTIMING  ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibCommTimingError)       },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_CURERR     ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_CURERR     ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, sizeof(ST_SNC_N1MibCurrentError)          },
#ifdef SWPS
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP       ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP       ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, 0                                         },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_AGENT ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_AGENT ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, 0                                         },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_LOCAL ][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_LOCAL ][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, 0                                         },
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {&gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_REMOTE][ST_SNC_MEMCNT_1ST], &gaST_SNC_ExecObj[ ST_SNC_MIBTYPE_LLDP_REMOTE][ST_SNC_MEMCNT_1ST]}, {NX_NULL, NX_NULL}, 0                                         },
#endif
	{ {ST_SNC_MEMCNT_NOUSE, {0}, ST_SNC_MEMCNT_1ST, ST_SNC_MEMCNT_1ST}, {NX_NULL,                                                              NX_NULL                                          }, {NX_NULL, NX_NULL}, 0                                         },
};

static const ST_SNC_MemoryObjectFunction	gaST_SNC_MemObjFuncTbl[ST_SNC_MIBTYPE_MAX] = {
	{ ulST_SNC_MibAllocMemoryObjectNetworkConfig, ulST_SNC_MibFreeMemoryObjectNetworkConfig, ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObjectDeviceDetail,  ulST_SNC_MibFreeMemoryObjectDeviceDetail,  ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        ulST_SNC_MibGetAddrMemoryObject,        ulST_SNC_MibSetMemoryObject       },
#ifdef SWPS
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        NX_NULL,                                   ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObjectLldpAgent,     ulST_SNC_MibFreeMemoryObjectLldpAgent,     ulST_SNC_MibClearMemoryObject,        NX_NULL,                                   ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        NX_NULL,                                   ulST_SNC_MibSetMemoryObject       },
	{ ulST_SNC_MibAllocMemoryObject,              ulST_SNC_MibFreeMemoryObject,              ulST_SNC_MibClearMemoryObject,        NX_NULL,                                   ulST_SNC_MibSetMemoryObject       },
#endif
	{ NX_NULL,                                       NX_NULL,                                      NX_NULL,                                 NX_NULL,                                   NX_NULL                              },
};

static const ST_SNC_MemoryFunction	gaST_SNC_MemFuncTbl[ST_SNC_MIBTYPE_MAX] = {
	{ ulST_SNC_MibAllocNetworkConfig,             ST_SNC_MibFreeAddr,                        ST_SNC_MibClearNetworkConfig,         ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetNetworkConfig,         ulST_SNC_CommitMib },
	{ ulST_SNC_MibAllocDeviceDetail,              ST_SNC_MibFreeAddr,                        ST_SNC_MibClearDeviceDetail,          ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetDeviceDetail,          ulST_SNC_CommitMib },
	{ ulST_SNC_MibAllocOtherModule,               ST_SNC_MibFreeAddr,                        ST_SNC_MibClearOtherModule,           ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetOtherModule,           NX_NULL               },
	{ ulST_SNC_MibAllocStatisticalInfo,           ST_SNC_MibFreeAddr,                        ST_SNC_MibClearStatisticalInfo,       ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetStatisticalInfo,       NX_NULL               },
	{ ulST_SNC_MibAllocIpOverlapError,            ST_SNC_MibFreeAddr,                        ST_SNC_MibClearIpOverlapError,        ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetIpOverlapError,        NX_NULL               },
	{ ulST_SNC_MibAllocIpTopologyError,           ST_SNC_MibFreeAddr,                        ST_SNC_MibClearIpTopologyError,       ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetIpTopologyError,       NX_NULL               },
	{ ulST_SNC_MibAllocDatalinkError,             ST_SNC_MibFreeAddr,                        ST_SNC_MibClearDatalinkError,         ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetDatalinkError,         NX_NULL               },
	{ ulST_SNC_MibAllocCommTimingError,           ST_SNC_MibFreeAddr,                        ST_SNC_MibClearCommTimingError,       ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetCommTimingError,       NX_NULL               },
	{ ulST_SNC_MibAllocCurrentError,              ST_SNC_MibFreeAddr,                        ST_SNC_MibClearCurrentError,          ulST_SNC_MibGetAddrMemory,        ulST_SNC_SetCurrentError,          NX_NULL               },
#ifdef SWPS
	{ ulST_SNC_MibAllocLldp,                      ST_SNC_MibFreeAddr,                        ST_SNC_MibClearLldp,                  NX_NULL,                             ulST_SNC_SetLldp,                  NX_NULL               },
	{ ulST_SNC_MibAllocLldpAgent,                 ST_SNC_MibFreeAddr,                        NX_NULL,                                 NX_NULL,                             ulST_SNC_SetLldp,                  NX_NULL               },
	{ ulST_SNC_MibAllocLldpLocal,                 ST_SNC_MibFreeAddr,                        ST_SNC_MibClearLldpLocal,             NX_NULL,                             ulST_SNC_SetLldp,                  NX_NULL               },
	{ ulST_SNC_MibAllocLldpRemote,                ST_SNC_MibFreeAddr,                        ST_SNC_MibClearLldpRemote,            NX_NULL,                             ulST_SNC_SetLldp,                  NX_NULL               },
#endif
	{ NX_NULL,                                       NX_NULL,                                      NX_NULL,                                 NX_NULL,                             NX_NULL,                              NX_NULL               },
};

const NX_SHORT	gsST_SNC_OptMax = R_IN_OPTIONTABLE_ENTRY_SIZE;


static NX_ULONG ulST_SNC_SwitchMemcntObjct(
	ST_SNC_MemoryCountObject*	pstObj
)
{
	NX_UCHAR	ucCombi[ST_SNC_MEMCNT_MAX][ST_SNC_MEMCNT_MAX] = {
		{ _NG_, _OK_ },
		{ _OK_, _NG_ },
	};
	ST_SNC_MemoryCount		eWork	= ST_SNC_MEMCNT_1ST;
	NX_ULONG					ulRet	= ST_SNC_OK;

	switch(pstObj->ucUse) {
	case ST_SNC_MEMCNT_NOUSE:
		break;

	case ST_SNC_MEMCNT_USED:

		if((ST_SNC_MEMCNT_MAX > pstObj->eRead)  &&
		   (ST_SNC_MEMCNT_MAX > pstObj->eWrite) ) {

			if(_OK_ == ucCombi[ pstObj->eRead ][ pstObj->eWrite ]){
				eWork          = pstObj->eRead;
				pstObj->eRead  = pstObj->eWrite;
				pstObj->eWrite = eWork;
			}
			else {
				ulRet = ST_SNC_NG_MEMCNT_INTERNAL;
			}

		}
		else {
			ulRet = ST_SNC_NG_MEMCNT;
		}
		break;

	default:
		ulRet = ST_SNC_NG_PARAM_RANGE;
		break;
	}

	return ulRet;

}



NX_ULONG ulST_SNC_MibAlloc(NX_VOID)
{
	NX_ULONG		ulRet	= ST_SNC_OK;
	NX_UCHAR		uchCnt	= 0;

	if(NX_NULL == gST_SNC_Manage.pstObj) {

		for(uchCnt=0; uchCnt<ST_SNC_MIBTYPE_MAX; uchCnt++) {

			if( NX_NULL != gaST_SNC_MemObjFuncTbl[uchCnt].alloc ) {

				ulRet = gaST_SNC_MemObjFuncTbl[uchCnt].alloc((ST_SNC_Mibtype)uchCnt, &gaST_SNC_MemObjTbl[uchCnt]);
				if(ST_SNC_OK != ulRet) {
					break;
				}
				else {
					;
				}

			}
			else {
				;
			}
		}

	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}


	if(ST_SNC_MIBTYPE_MAX == uchCnt) {

		gST_SNC_Manage.pstObj = gaST_SNC_MemObjTbl;

	}
	else {

		for(uchCnt=ST_SNC_MIBTYPE_MAX; uchCnt > ST_SNC_MIBTYPE_NWCFG; uchCnt--) {

			if( NX_NULL != gaST_SNC_MemObjFuncTbl[uchCnt - 1].free ) {
				gaST_SNC_MemObjFuncTbl[uchCnt - 1].free((ST_SNC_Mibtype)(uchCnt - 1), &gaST_SNC_MemObjTbl[uchCnt - 1]);
			}
			else {
				;
			}
		}

	}

	return ulRet;
}

static NX_ULONG ulST_SNC_MibAllocMemoryObjectNetworkConfig(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG		ulRet		= ST_SNC_OK;
	NX_UCHAR		uchCnt		= 0;

	if(ST_SNC_MEMCNT_USED == pstObj->stCnt.ucUse) {

		if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].alloc) {

			for(uchCnt=0; uchCnt<ST_SNC_MEMCNT_MAX; uchCnt++) {

				ulRet = ulST_SNC_ExecCreate(pstObj->pstObj[uchCnt]);
				if(ST_SNC_OK == ulRet) {

					ulRet = gaST_SNC_MemFuncTbl[eMibType].alloc((ST_SNC_MemoryCount)uchCnt, &pstObj->pvMib[uchCnt]);
					if(ST_SNC_OK == ulRet) {
						;
					}
					else {
						break;
					}
				}
				else {
					break;
				}
			}
		}
		else {
			ulRet = ST_SNC_NG_PARAM_RANGE;
		}

	}
	else {
		ulRet = ST_SNC_NG_MEMCNT_USED;
	}

	if(ST_SNC_OK != ulRet) {

		if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].free) {
			gaST_SNC_MemObjFuncTbl[eMibType].free(eMibType, pstObj);
		}
		else {
			;
		}

	}
	else {
		;
	}

	return ulRet;
}

static NX_ULONG ulST_SNC_MibAllocMemoryObjectDeviceDetail(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG		ulRet		= ST_SNC_OK;
	NX_UCHAR		uchCnt		= 0;

	if(ST_SNC_MEMCNT_USED == pstObj->stCnt.ucUse) {

		pstObj->pstObj[ST_SNC_MEMCNT_1ST] = gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_NWCFG].pstObj[ST_SNC_MEMCNT_1ST];
		pstObj->pstObj[ST_SNC_MEMCNT_2ND] = gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_NWCFG].pstObj[ST_SNC_MEMCNT_2ND];

		if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].alloc) {

			for(uchCnt=0; uchCnt<ST_SNC_MEMCNT_MAX; uchCnt++) {
				ulRet = gaST_SNC_MemFuncTbl[eMibType].alloc((ST_SNC_MemoryCount)uchCnt, &pstObj->pvMib[uchCnt]);
				if(ST_SNC_OK != ulRet) {
					break;
				}
				else {
					;
				}
			}

		}
		else {
			ulRet = ST_SNC_NG_PARAM_RANGE;
		}

	}
	else {
		ulRet = ST_SNC_NG_MEMCNT_USED;
	}

	if(ST_SNC_OK != ulRet) {

		if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].free) {
			gaST_SNC_MemObjFuncTbl[eMibType].free(eMibType, pstObj);
		}
		else {
			;
		}


	}
	else {
		;
	}

	return ulRet;
}


static NX_ULONG ulST_SNC_MibAllocMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG		ulRet		= ST_SNC_OK;

	if(ST_SNC_MEMCNT_NOUSE == pstObj->stCnt.ucUse) {

		ulRet = ulST_SNC_ExecCreate(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
		if(ST_SNC_OK == ulRet) {

			if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].alloc) {

				ulRet = gaST_SNC_MemFuncTbl[eMibType].alloc(ST_SNC_MEMCNT_1ST, &pstObj->pvMib[ST_SNC_MEMCNT_1ST]);

			}
			else {
				ulRet = ST_SNC_NG_PARAM_RANGE;
			}

		}
		else {
			;
		}

	}
	else {
		ulRet = ST_SNC_NG_MEMCNT_USED;
	}

	if(ST_SNC_OK != ulRet){

		if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].free) {
			gaST_SNC_MemObjFuncTbl[eMibType].free(eMibType, pstObj);
		}
		else {
			;
		}

	}
	else {
		;
	}
	return ulRet;
}


#ifdef SWPS
#endif


static NX_ULONG ulST_SNC_MibAllocNetworkConfig(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibNetworkConfig*	pvData		= NX_NULL;

	if(eCnt < ST_SNC_MEMCNT_MAX) {
		pvData = &gaST_SNC_MibNetCnf[eCnt];
	}
	else {
		return ST_SNC_NG_PARAM_RANGE;
	}

	ST_SNC_MibClearNetworkConfig(pvData);
	*pAddr = (NX_VOID*)pvData;
	DBGTRACE(" [size] ST_SNC_N1MibNetworkConfig        = %d", sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibMasterStation        = %d", sizeof(ST_SNC_N2MibMasterStation));
	DBGTRACE(" [size] ST_SNC_N2MibConnectedStation     = %d", sizeof(ST_SNC_N2MibConnectedStation));
	DBGTRACE(" [size] ST_SNC_N3MibAdjacentStation      = %d", sizeof(ST_SNC_N3MibAdjacentStation));
	return ST_SNC_OK;
}


static NX_ULONG ulST_SNC_MibAllocDeviceDetail(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibDeviceDetail*	pvData		= NX_NULL;

	if(eCnt < ST_SNC_MEMCNT_MAX) {
		pvData = &gaST_SNC_MibDevDtl[eCnt];
	}
	else {
		return ST_SNC_NG_PARAM_RANGE;
	}

	ST_SNC_MibClearDeviceDetail(pvData);
	*pAddr = (NX_VOID*)pvData;


	DBGTRACE(" [size] ST_SNC_N1MibDeviceDetail         = %d", sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibIdentifierInfo       = %d", sizeof(ST_SNC_N2MibIdentifierInfo));
	DBGTRACE(" [size] ST_SNC_N3MibStatusInfoBase       = %d", sizeof(ST_SNC_N3MibStatusInfoBase));
	DBGTRACE(" [size] ST_SNC_N3MibStatusMaster         = %d", sizeof(ST_SNC_N3MibStatusMaster));
	DBGTRACE(" [size] ST_SNC_N3MibLed                  = %d", sizeof(ST_SNC_N3MibLed));

	return ST_SNC_OK;
}

static NX_ULONG ulST_SNC_MibAllocOtherModule(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibOtherModule*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibOthMod;
	ST_SNC_MibClearOtherModule(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibOtherModule          = %d",  sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibController           = %d",  sizeof(ST_SNC_N2MibController));
	DBGTRACE(" [size] ST_SNC_N2MibOptionInfo           = %d",  sizeof(ST_SNC_N2MibOptionInfo));

	return ST_SNC_OK;
}

static NX_ULONG ulST_SNC_MibAllocStatisticalInfo(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibStatisticalInfo*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibStaInf;
	ST_SNC_MibClearStatisticalInfo(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibStatisticalInfo      = %d",  sizeof(*pvData));

	return ST_SNC_OK;
}

static NX_ULONG ulST_SNC_MibAllocIpOverlapError(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibIpOverlapError*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibOvrErr;
	ST_SNC_MibClearIpOverlapError(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibIpOverlapError       = %d",  sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibIpOverlapReg         = %d",  sizeof(ST_SNC_N2MibIpOverlapReg));
	
	return ST_SNC_OK;
}

static NX_ULONG ulST_SNC_MibAllocIpTopologyError(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibIpTopologyError*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibTopErr;
	ST_SNC_MibClearIpTopologyError(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibIpTopologyError      = %d",  sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibTopologyReg          = %d",  sizeof(ST_SNC_N2MibTopologyReg));
	
	return ST_SNC_OK;
}




	


static NX_ULONG ulST_SNC_MibAllocDatalinkError(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibDatalinkError*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibDatErr;
	ST_SNC_MibClearDatalinkError(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibDatalinkError        = %d",  sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibDatalinkErrorReg     = %d",  sizeof(ST_SNC_N2MibDatalinkErrorReg));
	
	return ST_SNC_OK;
}

static NX_ULONG ulST_SNC_MibAllocCommTimingError(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibCommTimingError*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibComErr;
	ST_SNC_MibClearCommTimingError(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibCommTimingError      = %d",  sizeof(*pvData));
	
	return ST_SNC_OK;
}


static NX_ULONG ulST_SNC_MibAllocCurrentError(
	ST_SNC_MemoryCount	eCnt,
	NX_VOID**				pAddr
)
{
	ST_SNC_N1MibCurrentError*	pvData		= NX_NULL;

	(NX_VOID)eCnt;
	pvData = &gST_SNC_MibCurErr;
	ST_SNC_MibClearCurrentError(pvData);
	*pAddr = (NX_VOID*)pvData;

	DBGTRACE(" [size] ST_SNC_N1MibCurrentError         = %d",  sizeof(*pvData));
	DBGTRACE(" [size] ST_SNC_N2MibErrorReg             = %d",  sizeof(ST_SNC_N2MibErrorReg));
	DBGTRACE(" [size] ST_SNC_N3MibErrorDetailReg       = %d",  sizeof(ST_SNC_N3MibErrorDetailReg));
#ifdef CURERR_OPTIONINFO_ENABLE
	DBGTRACE(" [size] ST_SNC_N2MibCurrentErrorOptionInfo   = %d",  sizeof(ST_SNC_N2MibCurrentErrorOptionInfo));
	DBGTRACE(" [size] ST_SNC_N3MibOptionInfoErrorReg       = %d",  sizeof(ST_SNC_N3MibOptionInfoErrorReg));
	DBGTRACE(" [size] ST_SNC_N4MibOptionInfoErrorDetailReg = %d",  sizeof(ST_SNC_N4MibOptionInfoErrorDetailReg));
#endif
	return ST_SNC_OK;
}


#ifdef SWPS






#endif


NX_ULONG ulST_SNC_MibFree(NX_VOID)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;
	NX_UCHAR					uchCnt	= 0;

	if(NX_NULL != gST_SNC_Manage.pstObj) {

		pMemObj = gST_SNC_Manage.pstObj;

		for(uchCnt=ST_SNC_MIBTYPE_MAX; uchCnt > ST_SNC_MIBTYPE_NWCFG; uchCnt--) {

			if( NX_NULL != gaST_SNC_MemObjFuncTbl[uchCnt - 1].free ) {
				gaST_SNC_MemObjFuncTbl[uchCnt - 1].free((ST_SNC_Mibtype)(uchCnt - 1), &pMemObj[uchCnt - 1]);
			}
			else {
				;
			}
		}

		gST_SNC_Manage.pstObj = NX_NULL;

	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	return ulRet;
}

static NX_ULONG ulST_SNC_MibFreeMemoryObjectNetworkConfig(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG			ulRet	= ST_SNC_OK;
	NX_UCHAR			uchCnt	= 0;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].free) {

		for(uchCnt=0; uchCnt<ST_SNC_MEMCNT_MAX; uchCnt++) {

			ulRet = ulST_SNC_ExecLock(pstObj->pstObj[uchCnt]);
			if(ST_SNC_OK == ulRet) {

				gaST_SNC_MemFuncTbl[eMibType].free(&pstObj->pvMib[uchCnt]);

				ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[uchCnt]);
				if(ST_SNC_OK == ulRet) {
					ulRet = ulST_SNC_ExecFinal(pstObj->pstObj[uchCnt]);

				}
				else {
					ulST_SNC_ExecFinal(pstObj->pstObj[uchCnt]);
				}
			}
			else {
				;
			}
		}

	}
	else{
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}

static NX_ULONG ulST_SNC_MibFreeMemoryObjectDeviceDetail(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG			ulRet	= ST_SNC_OK;
	NX_UCHAR			uchCnt	= 0;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].free) {

		for(uchCnt=0; uchCnt<ST_SNC_MEMCNT_MAX; uchCnt++) {

			ulRet = ulST_SNC_ExecLock(pstObj->pstObj[uchCnt]);
			if(ST_SNC_OK == ulRet) {

				gaST_SNC_MemFuncTbl[eMibType].free(&pstObj->pvMib[uchCnt]);

				ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[uchCnt]);
				if(ST_SNC_OK == ulRet) {
					;
				}
				else {
					;
				}
			}
			else {
				;
			}
		}

	}
	else {
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}


static NX_ULONG ulST_SNC_MibFreeMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj
)
{
	NX_ULONG			ulRet = ST_SNC_OK;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].free) {

		ulRet = ulST_SNC_ExecLock(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
		if(ST_SNC_OK == ulRet) {

			gaST_SNC_MemFuncTbl[eMibType].free(&pstObj->pvMib[ST_SNC_MEMCNT_1ST]);

			ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
			if(ST_SNC_OK != ulRet) {
				ulST_SNC_ExecFinal(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
			}
			else {
				ulRet = ulST_SNC_ExecFinal(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
			}

		}
		else {
			ulST_SNC_ExecFinal(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
		}
	}
	else{
		ulRet = ulST_SNC_ExecFinal(pstObj->pstObj[ST_SNC_MEMCNT_1ST]);
	}

	return ulRet;
}


#ifdef SWPS
#endif


static NX_VOID ST_SNC_MibFreeAddr(
	NX_VOID**	pAddr
)
{
	if((NX_NULL != pAddr) && (NX_NULL != *pAddr)) {
		*pAddr = NX_NULL;
	}
	else {
		;
	}
	return;
}



static NX_ULONG ulST_SNC_MibAllClearNetConfDevDtl(NX_VOID)
{
	ST_SNC_MemoryObject*	pMemObj		= NX_NULL;
	NX_ULONG					ulRet		= ST_SNC_OK;
	NX_UCHAR					uchCnt		= 0;
	NX_UCHAR					uchMemCnt	= 0;
	ST_SNC_Mibtype			eMibType	= ST_SNC_MIBTYPE_NWCFG;

	if(NX_NULL != gST_SNC_Manage.pstObj) {

		pMemObj = gST_SNC_Manage.pstObj;

		ulRet = ulST_SNC_ObjLock(eMibType, ST_SNC_MEMCNT_1ST);
		if(ST_SNC_OK == ulRet) {

			ulRet = ulST_SNC_ObjLock(eMibType, ST_SNC_MEMCNT_2ND);
			if(ST_SNC_OK == ulRet) {

				for(uchCnt=ST_SNC_MIBTYPE_NWCFG; uchCnt<ST_SNC_MIBTYPE_OTMDL; uchCnt++) {

					if(NX_NULL != gaST_SNC_MemFuncTbl[uchCnt].clear){

						if(ST_SNC_MEMCNT_USED == pMemObj[uchCnt].stCnt.ucUse) {
							for(uchMemCnt=0; uchMemCnt<ST_SNC_MEMCNT_MAX; uchMemCnt++) {

								gaST_SNC_MemFuncTbl[uchCnt].clear(pMemObj[uchCnt].pvMib[uchMemCnt]);
							}
						}
						else {
							ulRet = ST_SNC_NG_MEMCNT_INTERNAL;
							break;
						}
					}
					else {
						ulRet = ST_SNC_NG_PARAM_RANGE;
						break;
					}
				}

				if(ST_SNC_OK == ulRet) {

					ulRet = ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_2ND);
					if(ST_SNC_OK == ulRet) {

						ulRet = ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
						if(ST_SNC_OK == ulRet) {
							;
						}
						else {
						}
					}
					else {
						ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
					}

				}
				else {
					ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_2ND);
					ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
				}

			}
			else {
				ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
			}
		}
		else {
		}
	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	if(ST_SNC_OK == ulRet) {
		DBGTRACE("%s End(%d)", __FUNCTION__, ulRet);
	}
	else {
	}
	return ulRet;
}

static NX_ULONG ulST_SNC_MibAllClearOther(NX_VOID)
{
	ST_SNC_MemoryObject*	pMemObj		= NX_NULL;
	NX_ULONG					ulRet		= ST_SNC_OK;
	NX_UCHAR					uchCnt		= 0;
	NX_UCHAR					uchMemCnt	= 0;

	if(NX_NULL != gST_SNC_Manage.pstObj) {

		pMemObj = gST_SNC_Manage.pstObj;

		for(uchCnt=ST_SNC_MIBTYPE_OTMDL; uchCnt<ST_SNC_MIBTYPE_MAX; uchCnt++) {

			if(NX_NULL != gaST_SNC_MemObjFuncTbl[uchCnt].clear){

				if(ST_SNC_MEMCNT_USED == pMemObj[uchCnt].stCnt.ucUse) {

					for(uchMemCnt=0; uchMemCnt<ST_SNC_MEMCNT_MAX; uchMemCnt++) {

						ulRet = gaST_SNC_MemObjFuncTbl[uchCnt].clear((ST_SNC_Mibtype)uchCnt, &pMemObj[uchCnt], (ST_SNC_MemoryCount)uchMemCnt);
						if (ST_SNC_OK == ulRet) {
							;
						}
						else {
							break;
						}
					}

				}
				else {

					ulRet = gaST_SNC_MemObjFuncTbl[uchCnt].clear((ST_SNC_Mibtype)uchCnt, &pMemObj[uchCnt], ST_SNC_MEMCNT_1ST);
					if (ST_SNC_OK == ulRet) {
						;
					}
					else {
						break;
					}
				}
			}
			else {
				;
			}
		}

	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	if(ST_SNC_OK == ulRet) {
		DBGTRACE("%s End(%d)", __FUNCTION__, ulRet);
	}
	else {
	}

	return ulRet;
}

NX_ULONG ulST_SNC_MibAllClear(NX_VOID)
{
	NX_ULONG					ulRet		= ST_SNC_OK;


	ulRet = ulST_SNC_MibAllClearNetConfDevDtl();
	if(ST_SNC_OK == ulRet) {

		ulRet = ulST_SNC_MibAllClearOther();
	}
	else {
		;
	}

	return ulRet;
}

NX_ULONG ulST_SNC_MibClearMemory(
	ST_SNC_Mibtype	eMibType
)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	if( (ST_SNC_MIBTYPE_NWCFG >  eMibType) ||
		(ST_SNC_MIBTYPE_MAX   <= eMibType) ){
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}
	else {

		if(NX_NULL != gST_SNC_Manage.pstObj) {

			if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].clear) {

				pMemObj = gST_SNC_Manage.pstObj + eMibType;

				ulRet = gaST_SNC_MemObjFuncTbl[eMibType].clear(eMibType, pMemObj, pMemObj->stCnt.eWrite);

			}
			else {
				;
			}
		}
		else {
			ulRet = ST_SNC_NG_SEQUENCE;
		}
	}

	return ulRet;
}


static NX_ULONG ulST_SNC_MibClearMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj,
	ST_SNC_MemoryCount		eCount
)
{
	NX_ULONG					ulRet	= ST_SNC_OK;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].clear) {

		ulRet = ulST_SNC_ExecLock(pstObj->pstObj[eCount]);
		if(ST_SNC_OK == ulRet) {

			gaST_SNC_MemFuncTbl[eMibType].clear(pstObj->pvMib[eCount]);

			ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[eCount]);
		}
		else {
			;
		}
	}
	else {
		;
	}

	return ulRet;
}


static NX_VOID ST_SNC_MibClearNetworkConfig(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibNetworkConfig* pBase = (ST_SNC_N1MibNetworkConfig*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}


static NX_VOID ST_SNC_MibClearDeviceDetail(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibDeviceDetail* pBase = (ST_SNC_N1MibDeviceDetail*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}

static NX_VOID ST_SNC_MibClearOtherModule(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibOtherModule* pBase = (ST_SNC_N1MibOtherModule*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}

static NX_VOID ST_SNC_MibClearStatisticalInfo(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibStatisticalInfo* pBase = (ST_SNC_N1MibStatisticalInfo*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}

static NX_VOID ST_SNC_MibClearIpOverlapError(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibIpOverlapError* pBase = (ST_SNC_N1MibIpOverlapError*)pAddr;
#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}

static NX_VOID ST_SNC_MibClearIpTopologyError(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibIpTopologyError* pBase = (ST_SNC_N1MibIpTopologyError*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}







static NX_VOID ST_SNC_MibClearDatalinkError(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibDatalinkError* pBase = (ST_SNC_N1MibDatalinkError*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}


static NX_VOID ST_SNC_MibClearCommTimingError(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibCommTimingError* pBase = (ST_SNC_N1MibCommTimingError*)pAddr;

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif

	return;
}



static NX_VOID ST_SNC_MibClearCurrentError(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibCurrentError*	pBase = (ST_SNC_N1MibCurrentError*)pAddr;
#ifdef CURERR_OPTIONINFO_ENABLE
	NX_USHORT usOptCount;
#endif

#ifdef MASTER
	gpST_UTI_Memset(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#else
	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));
#endif
	ST_SNC_SetCounterErrOccurOdrNo(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN);

#ifdef CURERR_OPTIONINFO_ENABLE
	for(usOptCount = NX_ZERO; usOptCount < ST_SNC_ERRREG_OPT_MAX; usOptCount++) {
		ST_SNC_SetCounterOptionErrOccurOdrNo(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN,usOptCount);
	}
#endif

	return;
}

#ifdef CURERR_OPTIONINFO_ENABLE
NX_VOID ST_SNC_MibClearCurrentErrorController(
	NX_VOID*	pAddr
)
{
	ST_SNC_N1MibCurrentError*	pBase = (ST_SNC_N1MibCurrentError*)pAddr;

	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, (sizeof(pBase->usNumberOfTable) + sizeof(pBase->usPadding) + sizeof(pBase->astErrorTable)));

	ST_SNC_SetCounterErrOccurOdrNo(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN);

	return;
}

NX_VOID ST_SNC_MibClearCurrentErrorOption(
	NX_VOID*	pAddr,
	NX_USHORT	usOptNum
)
{
	ST_SNC_N2MibCurrentErrorOptionInfo*	pBase = (ST_SNC_N2MibCurrentErrorOptionInfo*)pAddr;

	vNX_FillMemory(pBase, ST_SNC_ZEROPAD, sizeof(*pBase));

	ST_SNC_SetCounterOptionErrOccurOdrNo(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN,usOptNum);

	return;
}
#endif

#ifdef SWPS





#endif


NX_ULONG ulST_SNC_MibGetAddr(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryRWType		eMemType,
	NX_VOID**					pAddr
)
{
	ST_SNC_MemoryObject*	pMemObj	  = NX_NULL;
	NX_ULONG					ulRet	  = ST_SNC_OK;
	ST_SNC_MemoryCount 		eMemCount = ST_SNC_MEMCNT_1ST;

	if((ST_SNC_MIBTYPE_NWCFG >  eMibType) ||
		(ST_SNC_MIBTYPE_MAX  <= eMibType) ){
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}
	if(	ST_SNC_MEMORY_READ   != eMemType &&
		ST_SNC_MEMORY_WRITE  != eMemType ){
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	if(NX_NULL != gST_SNC_Manage.pstObj) {

		if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].getaddr) {

			pMemObj = gST_SNC_Manage.pstObj + eMibType;

			if(ST_SNC_MEMORY_READ == eMemType) {
				eMemCount = pMemObj->stCnt.eRead;
			}
			else {
				eMemCount = pMemObj->stCnt.eWrite;
			}

			ulRet = gaST_SNC_MemObjFuncTbl[eMibType].getaddr(eMibType, pMemObj, eMemCount, pAddr);
		}
		else {
			;
		}
	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	return ulRet;
}


NX_ULONG ulST_SNC_MibGetAddrNolock(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryRWType		eMemType,
	NX_VOID**					pAddr
)
{
	ST_SNC_MemoryObject*	pstObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;
	ST_SNC_MemoryCount 		eMemCount = ST_SNC_MEMCNT_1ST;

	pstObj = gST_SNC_Manage.pstObj + eMibType;

	if(ST_SNC_MEMORY_READ == eMemType) {
		eMemCount = pstObj->stCnt.eRead;
	}
	else {
		eMemCount = pstObj->stCnt.eWrite;
	}


	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].getaddr) {

		gaST_SNC_MemFuncTbl[eMibType].getaddr(
			pstObj->pvMib[eMemCount],
			pAddr
			);
	}
	else {
		;
	}

	return ulRet;
}


static NX_ULONG ulST_SNC_MibGetAddrMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj,
	ST_SNC_MemoryCount		eMemCount,
	NX_VOID**					pAddr
)
{
	NX_ULONG					ulRet	= ST_SNC_OK;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].getaddr) {

		ulRet = ulST_SNC_ExecLock(pstObj->pstObj[eMemCount]);
		if(ST_SNC_OK == ulRet) {
			gaST_SNC_MemFuncTbl[eMibType].getaddr(pstObj->pvMib[eMemCount], pAddr);

			ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[eMemCount]);
		}
		else {
			;
		}

	}
	else {
		;
	}

	return ulRet;
}

static NX_ULONG ulST_SNC_MibGetAddrMemory(
	NX_VOID*	pMib,
	NX_VOID**	pAddr
)
{
	*pAddr = pMib;
	return ST_SNC_OK;
}


#ifdef SWPS
#endif


NX_ULONG ulST_SNC_ObjLock(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryCount		eMemCount
)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	if( (ST_SNC_MIBTYPE_NONE  == eMibType) ||
		(ST_SNC_MIBTYPE_NWCFG >  eMibType) ||
		(ST_SNC_MIBTYPE_MAX   <= eMibType) ){

		ulRet =  ST_SNC_NG_PARAM_RANGE;

	}
	else {

		if(ST_SNC_MEMCNT_MAX > eMemCount) {

			if(NX_NULL != gST_SNC_Manage.pstObj) {

				pMemObj = gST_SNC_Manage.pstObj + eMibType;

				ulRet = ulST_SNC_ExecLock(pMemObj->pstObj[eMemCount]);

			}
			else {
				ulRet = ST_SNC_NG_SEQUENCE;
			}
		}
		else {
			ulRet =  ST_SNC_NG_PARAM_RANGE;
		}
	}
	return ulRet;
}






#ifdef SWPS
#endif


NX_ULONG ulST_SNC_ObjUnlock(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryCount		eMemCount
)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	if( (ST_SNC_MIBTYPE_NONE  == eMibType) ||
		(ST_SNC_MIBTYPE_NWCFG >  eMibType) ||
		(ST_SNC_MIBTYPE_MAX   <= eMibType) ){

		ulRet = ST_SNC_NG_PARAM_RANGE;

	}
	else {

		if(ST_SNC_MEMCNT_MAX > eMemCount) {

			if(NX_NULL != gST_SNC_Manage.pstObj) {

				pMemObj = gST_SNC_Manage.pstObj + eMibType;

				ulRet = ulST_SNC_ExecUnlock(pMemObj->pstObj[eMemCount]);

			}
			else {
				ulRet = ST_SNC_NG_SEQUENCE;
			}
		}
		else {
			ulRet = ST_SNC_NG_PARAM_RANGE;
		}

	}
	return ulRet;
}


NX_ULONG ulST_SNC_MibSetMemory(
	ST_SNC_Mibtype			eMibType,
	const ST_SNC_MibMng*	pstMib,
	const NX_VOID*				pData
)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	if((NX_NULL == pstMib) || (NX_NULL == pData)){
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	DBGTRACE("%s Start",__FUNCTION__);

	if( (ST_SNC_MIBTYPE_NWCFG >  eMibType) ||
		(ST_SNC_MIBTYPE_MAX   <= eMibType) ){
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	if(NX_NULL != gST_SNC_Manage.pstObj) {

		if(NX_NULL != gaST_SNC_MemObjFuncTbl[eMibType].set) {

			pMemObj = gST_SNC_Manage.pstObj + eMibType;

			ulRet = gaST_SNC_MemObjFuncTbl[eMibType].set(eMibType, pMemObj, pstMib, pData);

		}
		else {
			;
		}

	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	DBGTRACE("%s End(%d)",__FUNCTION__, ulRet);

	return ulRet;
}


static NX_ULONG ulST_SNC_MibSetMemoryObject(
	ST_SNC_Mibtype			eMibType,
	ST_SNC_MemoryObject*	pstObj,
	const ST_SNC_MibMng*	pstMib,
	const NX_VOID*				pData
)
{
	NX_ULONG					ulRet	= ST_SNC_OK;

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].set) {
		
		DBGTRACE("%s Start",__FUNCTION__);

		ulRet = ulST_SNC_ExecLock(pstObj->pstObj[pstObj->stCnt.eWrite]);
		if(ST_SNC_OK == ulRet) {

			ulRet = gaST_SNC_MemFuncTbl[eMibType].set(pstMib, pData, pstObj->pvMib[pstObj->stCnt.eWrite], pstObj->ulSize);
			if(ST_SNC_OK == ulRet) {
				ulRet = ulST_SNC_ExecUnlock(pstObj->pstObj[pstObj->stCnt.eWrite]);
			}
			else {
				ulST_SNC_ExecUnlock(pstObj->pstObj[pstObj->stCnt.eWrite]);
			}
		}
		else {
			;
		}
	}
	else {
		;
	}

	DBGTRACE("%s End(%d)",__FUNCTION__,ulRet);
	return ulRet;
}

NX_ULONG ulST_SNC_MibAllCommit(NX_VOID)
{
	NX_ULONG			ulRet			= ST_SNC_OK;
	NX_UCHAR			auchMibType[]	= { ST_SNC_MIBTYPE_NWCFG,
		 							    ST_SNC_MIBTYPE_DEVDTL};
	ST_SNC_Mibtype	eMibType		= ST_SNC_MIBTYPE_NWCFG;
	NX_UCHAR			uchCount		= 0;


	DBGTRACE("%s", __FUNCTION__);

	ulRet = ulST_SNC_ObjLock(eMibType, ST_SNC_MEMCNT_1ST);
	if(ST_SNC_OK == ulRet) {
		;
	}
	else {
		return ulRet;
	}

	ulRet = ulST_SNC_ObjLock(eMibType, ST_SNC_MEMCNT_2ND);
	if(ST_SNC_OK == ulRet) {
		;
	}
	else {
		ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
		return ulRet;
	}


	for(uchCount = 0; uchCount < sizeof(auchMibType)/sizeof(auchMibType[0]); uchCount++ ) {

		ulRet = ulST_SNC_MibCommit((ST_SNC_Mibtype)auchMibType[uchCount]);
		if(ST_SNC_OK == ulRet){

			ulRet = ulST_SNM_ExtMib_UpdateAddrForMibType(auchMibType[uchCount]);
			if(ST_SNC_OK == ulRet){
				;
			}
			else {
				DBGTRACE("%s MIB add failed (rc=%d MibType=%d)", __FUNCTION__, ulRet, auchMibType[uchCount]);
				break;
			}
		}
		else {
			DBGTRACE("%s MIB commit failed (rc=%d MibType=%d)", __FUNCTION__, ulRet, auchMibType[uchCount]);
			break;
		}
	}

	if(ST_SNC_OK == ulRet) {
		ulRet = ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_2ND);
		if(ST_SNC_OK == ulRet){
			
			ulRet = ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);

		}
		else {
			ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
		}
	}
	else {
		ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_2ND);
		ulST_SNC_ObjUnlock(eMibType, ST_SNC_MEMCNT_1ST);
	}

	return ulRet;
}


static NX_ULONG ulST_SNC_MibCommit(ST_SNC_Mibtype	eMibType)
{
	NX_ULONG					ulRet	= ST_SNC_OK;

	if(NX_NULL != gST_SNC_Manage.pstObj) {
		;
	}
	else {
		return ST_SNC_NG_SEQUENCE;
	}

	if( ST_SNC_MIBTYPE_NWCFG  == eMibType  ||
		ST_SNC_MIBTYPE_DEVDTL == eMibType ) {
		;
	}
	else {
		return ST_SNC_NG_PARAM_RANGE;
	}

	if(NX_NULL != gaST_SNC_MemFuncTbl[eMibType].commit) {

		DBGTRACE("%s Start",__FUNCTION__);
		ulRet = gaST_SNC_MemFuncTbl[eMibType].commit(eMibType);

	}
	else {
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	DBGTRACE("%s End(%d)",__FUNCTION__, ulRet);
	return ulRet;
}


static NX_ULONG ulST_SNC_CommitMib(ST_SNC_Mibtype eMibType)
{
	ST_SNC_MemoryObject*	pMemObj	= NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	pMemObj = gST_SNC_Manage.pstObj + eMibType;

	if(ST_SNC_MEMCNT_USED == pMemObj->stCnt.ucUse) {

		ulRet = ulST_SNC_SwitchMemcntObjct(&pMemObj->stCnt);
		if(ST_SNC_OK == ulRet) {

#ifdef MASTER
			gpST_UTI_Memcpy(
				pMemObj->pvMib[pMemObj->stCnt.eWrite],
				pMemObj->pvMib[pMemObj->stCnt.eRead ],
				pMemObj->ulSize);
#else
			vNX_CopyMemory(
				pMemObj->pvMib[pMemObj->stCnt.eWrite],
				pMemObj->pvMib[pMemObj->stCnt.eRead ],
				pMemObj->ulSize);
#endif

		}
		else {
			;
		}
	}
	else {
		ulRet = ST_SNC_NG_MEMCNT_INTERNAL;
	}

	return ulRet;
}
NX_USHORT ST_SNC_GetCounterErrOccurOdrNo(NX_VOID)
{
	return gusST_SNC_ErrorOccurrenceOrderNo;
}

NX_VOID ST_SNC_SetCounterErrOccurOdrNo(NX_USHORT usErrOccurOdrNo)
{
	gusST_SNC_ErrorOccurrenceOrderNo = usErrOccurOdrNo;
	return;
}

NX_VOID ST_SNC_CountUpErrOccurOdrNo(NX_VOID)
{
	if(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX <= gusST_SNC_ErrorOccurrenceOrderNo){
		gusST_SNC_ErrorOccurrenceOrderNo = ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN;
	}
	else {
		gusST_SNC_ErrorOccurrenceOrderNo++;
	}

	return;
}
#ifdef CURERR_OPTIONINFO_ENABLE
NX_USHORT ST_SNC_GetCounterOptionErrOccurOdrNo(NX_USHORT usOptNum )
{
	return gusST_SNC_OptErrorOccurrenceOrderNo[usOptNum];
}

NX_VOID ST_SNC_SetCounterOptionErrOccurOdrNo(NX_USHORT usErrOccurOdrNo, NX_USHORT usOptNum)
{
	gusST_SNC_OptErrorOccurrenceOrderNo[usOptNum] = usErrOccurOdrNo;
	return;
}

NX_VOID ST_SNC_CountUpOptionErrOccurOdrNo(NX_USHORT usOptNum)
{
	if(ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX <= gusST_SNC_OptErrorOccurrenceOrderNo[usOptNum]){
		gusST_SNC_OptErrorOccurrenceOrderNo[usOptNum] = ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN;
	}
	else {
		gusST_SNC_OptErrorOccurrenceOrderNo[usOptNum]++;
	}

	return;
}
#endif
