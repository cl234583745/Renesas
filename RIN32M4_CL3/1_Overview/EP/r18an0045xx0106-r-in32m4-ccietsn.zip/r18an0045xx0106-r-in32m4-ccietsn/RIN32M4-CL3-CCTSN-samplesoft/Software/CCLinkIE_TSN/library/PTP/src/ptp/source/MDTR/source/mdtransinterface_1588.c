/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_tsn_Wrapper.h"
#include "ptp_CommonFunction.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"

#include "PTP_GlobalData.h"
#include "ptp_bmca.h"

#include "mdtransinterface.h"

#include "MDSyncReceiveSM.h"
#include "MDDelayReqReceiveSM.h"
#include "MDDelayRespReceiveSM.h"
#include "MDPdelayReq.h"
#include "MDPdelayResp.h"
#include "PortAnnounceReceiveSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "ManagementSM.h"

#ifdef	PTP_USE_IEEE1588

VOID ptp_Mdl_recv_Sync_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_SYNC_1588, PTP_LOGVE_85000005);
		return;
	}

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_UNCALIBRATED) ||
			(uchPortState == PS_EX_SLAVE))
		{
		}
		else
		{
			return;
		}
	}
	pstPort->stMDSReceiveSM_GD.blRcvdSync = TRUE;

	{
		BOOL	blConvRet;

		blConvRet = ptpConvETS_TS(pstTimeStamp, &pstPort->stMDSReceiveSM_GD.stIngMDTimestampReceive);
		if (blConvRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
		}
#ifdef	PTP_USE_ME_HW_ASSIST
		blConvRet = ptpConvETS_TS(pstTimeStamp + 1, &pstPort->stMDSReceiveSM_GD.stIngMDTimestampReceive_Frun);
		if (blConvRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
		}
#endif
	}

	pstPort->stMDSReceiveSM_GD.pstRcvdSync	 = (PTPMSG*)ulMdtrMsgBuff;

	MDSyncReceiveSM(PTP_EV_FOR_MDSYN_RCVSM_RCVDSYNC, pstPort);
}

VOID	ptp_Mdl_recv_Delay_Req_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_DLREQ_1588, PTP_LOGVE_85000005);
		return;
	}

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if (uchPortState != PS_EX_MASTER)
		{

			return;
		}
		if(pstPort->stPort_1588_DS.enDelayMechanism != ENUM_DELAYMECHANISM_E2E)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_DLREQ_1588, PTP_LOGVE_85000031);
			return;
		}
	}
	else
	{
		if(enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588)
		{
			return;
		}
	}
	pstPort->stMDDReqRcvSM_GD.blRcvdDelayReq = TRUE;

	pstPort->stMDDReqRcvSM_GD.pstRcvdDelayReq	 = (PTPMSG*)ulMdtrMsgBuff;

	{
		BOOL	blConvRet;

		blConvRet = ptpConvETS_TS(pstTimeStamp, &pstPort->stMDDReqRcvSM_GD.stIngMDTimestampReceive);
		if (blConvRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
		}
#ifdef	PTP_USE_ME_HW_ASSIST
		blConvRet = ptpConvETS_TS(pstTimeStamp + 1, &pstPort->stMDDReqRcvSM_GD.stIngMDTimestampReceive_Frun);
		if (blConvRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_OVERFLOW);
		}
#endif
	}

	MDDelayReqReceiveSM(PTP_EV_RCVD_DELAY_REQ, pstPort);
}

VOID	ptp_Mdl_recv_Delay_Resp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
	   (enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState != PS_EX_SLAVE) &&
			(uchPortState != PS_EX_UNCALIBRATED))
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_DLRSP_1588, PTP_LOGVE_85000028);
			return;
		}
		if(pstPort->stPort_1588_DS.enDelayMechanism != ENUM_DELAYMECHANISM_E2E)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_DLRSP_1588, PTP_LOGVE_85000032);
			return;
		}
	}
	else
	{
		if(enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_DLRSP_1588, PTP_LOGVE_85000033);
			return;
		}
	}
	pstPort->stMDDRespRcvSM_GD.blRcvdDelayResp = TRUE;

	pstPort->stMDDRespRcvSM_GD.pstRcvdDelayResp	 = (PTPMSG*)ulMdtrMsgBuff;

	MDDelayRespReceiveSM(PTP_EV_RCVD_DELAY_RESP, pstPort);
}


VOID	ptp_Mdl_recv_Pdelay_Req_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLREQ_1588, PTP_LOGVE_85000005);
		return;
	}

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_FAULTY) ||
			(uchPortState == PS_EX_DISABLED))
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLREQ_1588, PTP_LOGVE_85000012);
			return;
		}

		if(pstPort->stPort_1588_DS.enDelayMechanism != ENUM_DELAYMECHANISM_P2P)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLREQ_1588, PTP_LOGVE_85000034);
			return;
		}
	}
	else
	{
		if(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588)
		{
			ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
			return;
		}
	}

	pstPort->stMDPRespSM_GD.blRcvdPdelayReq = TRUE;

	pstPort->stMDPRespSM_GD.pstRcvdPdelayReq	 = (PTPMSG*)ulMdtrMsgBuff;

	tsn_Wrapper_MemCpy(
		&pstPort->stMDPRespSM_GD.stIngMDTimestampReceive, pstTimeStamp, sizeof(TIMESTAMP));

	MDPdelayResp(PTP_EV_RCVDPDELAYREQ, pstPort);
}

VOID	ptp_Mdl_recv_Pdelay_Resp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	if(pstTimeStamp==NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLRESP_1588, PTP_LOGVE_85000005);
		return;
	}

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_FAULTY) ||
			(uchPortState == PS_EX_DISABLED))
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLRESP_1588, PTP_LOGVE_85000013);
			return;
		}

		if(pstPort->stPort_1588_DS.enDelayMechanism != ENUM_DELAYMECHANISM_P2P)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLRESP_1588, PTP_LOGVE_85000014);
			return;
		}
	}
	else
	{
		if(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588)
		{
			ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
			return;
		}
	}

	pstPort->stMDPReqSM_GD.blRcvdPdelayResp = TRUE;

	pstPort->stMDPReqSM_GD.pstRcvdPdelayResp	 = (PTPMSG*)ulMdtrMsgBuff;

	tsn_Wrapper_MemCpy(
		&pstPort->stMDPReqSM_GD.stIngMDTimestampReceive, pstTimeStamp, sizeof(TIMESTAMP));

	MDPdelayReq(PTP_EV_RCVDPDELAYRESP, pstPort);
}

VOID	ptp_Mdl_recv_FollowUp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_UNCALIBRATED) ||
			(uchPortState == PS_EX_SLAVE))
		{


		}
		else
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_FUP_1588, PTP_LOGVE_85000029);
		}
	}
	pstPort->stMDSReceiveSM_GD.blRcvdFollowUp = TRUE;

	pstPort->stMDSReceiveSM_GD.pstRcvdFollowUp	= (PTPMSG*)ulMdtrMsgBuff;

	MDSyncReceiveSM(PTP_EV_RCVDFOLLOWUP, pstPort);
}

VOID	ptp_Mdl_recv_Pdly_Rsp_Fup_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if ((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) &&
		(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if (uchPortState == PS_EX_DISABLED)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLYRSPFUP_1588, PTP_LOGVE_85000016);
			return;
		}

		if(pstPort->stPort_1588_DS.enDelayMechanism != ENUM_DELAYMECHANISM_P2P)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_PDLYRSPFUP_1588, PTP_LOGVE_85000015);
			return;
		}
	}
	else
	{
		if(enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588)
		{
			ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
			return;
		}
	}

	pstPort->stMDPReqSM_GD.blRcvdPdelayRespFollowUp = TRUE;

	pstPort->stMDPReqSM_GD.pstRcvdPdelayRespFollowUp = (PTPMSG*)ulMdtrMsgBuff;

	MDPdelayReq(PTP_EV_RCVDPDELAYRESPFOLLOWUP, pstPort);
}

VOID	ptp_Mdl_recv_Announce_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) && (enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_FAULTY) || (uchPortState == PS_EX_DISABLED))
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_ANNOUNCE_1588, PTP_LOGVE_85000017);
			return;
		}
	}
	else
	{
		ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
		return;
	}

	pstPort->stPAReceiveSM_GD.blRcvdAnnounce = TRUE;

	pstPort->stPortBMC_GD.pstRcvdAnnouncePtr	 = (PTPMSG_ANNOUNCE*)ulMdtrMsgBuff;

	if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE)
	{
#ifdef	PTP_USE_BMCA
		portAnnounceReceiveSM(PTP_EV_RCVDANNOUNCE, pstPort);
#endif
	}
	else
	{
		portAnnounceInformationExtSM(PTP_EV_RCVDANNOUNCE, pstPort);
	}
}

#ifdef	PTP_USE_MANAGEMENT
VOID	ptp_Mdl_recv_Manage_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;
	PTPMSG_MANAGEMENT_1588	*pstPtpMsg;
	PTPMSG_HEADER			*pstPtpMsgHdr;
	INT						nCmpRet;

	USHORT			usPortCnt;
	USHORT			usLoopCnt;
	INT				nCmpRet2;
	PORTDATA		*pstDstPort;

	usPortCnt = pstPort->pstClockData->stDefaultDS.usNumberPorts;


	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) && (enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if (uchPortState == PS_EX_FAULTY)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_MANAGE_1588, PTP_LOGVE_85000018);
			return;
		}
	}

		pstPtpMsgHdr = (PTPMSG_HEADER *)ulMdtrMsgBuff;
		pstPtpMsg	 = (PTPMSG_MANAGEMENT_1588*)ulMdtrMsgBuff;


	pstDstPort = pstPort->pstClockData->pstPortData;

	for(usLoopCnt=0; usLoopCnt < usPortCnt; usLoopCnt++, pstDstPort=pstDstPort->pstNextPortDataPtr)
	{

		if (ptp_Mdl_ntohMsgHeader(puchMsgPtr, pstPtpMsgHdr) == FALSE)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_MANAGE_1588, PTP_LOGVE_8500001D);
			return;
		}

		ptp_Mdl_ntohMsgManagement(puchMsgPtr, (PTPMSG*)ulMdtrMsgBuff);

		nCmpRet2 = checkBroadCastSingnal(&pstPtpMsg->stTargetPortIdentity);

		nCmpRet = tsn_Wrapper_MemCmp (

			&pstPtpMsg->stTargetPortIdentity,


			&pstDstPort->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));


		if ((!nCmpRet) || (nCmpRet2))
		{
			pstDstPort->pstClockData->stManagementSM_GD.puchMgtRxMsg = (UCHAR *)ulMdtrMsgBuff;
			pstDstPort->pstClockData->stManagementSM_GD.usMgtRxMsgLen = usMsgLen;


			tsn_Wrapper_MemCpy (&pstPtpMsg->stTargetPortIdentity,
										 &pstDstPort->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));
			ManagementSM((UCHAR *)ulMdtrMsgBuff, usMsgLen, (UCHAR)usPortNumber);
		}
		
	}
	ptp_trns_an_port_manage(pstPort, puchMsgPtr, usMsgLen);
}
#endif

#ifdef	PTP_USE_SIGNALING
VOID	ptp_Mdl_recv_Signal_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp)
{
	USHORT			usPortNumber;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockType;
	UCHAR			uchPortState;
	PTPMSG_SIGNALING_1AS *pstPtpMsgSignal;
	USHORT			usPortCnt;
	USHORT			usLoopCnt;
	PORTDATA		*pstDstPort;
	INT				nCmpRet;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	enClockType = pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;

	if((enClockType != ENUM_CSTYPE_TRANSCLOCKE2E_1588) && (enClockType != ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		uchPortState = pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber];

		if ((uchPortState == PS_EX_FAULTY) || (uchPortState == PS_EX_DISABLED))
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_RCV_SIGNAL_1588, PTP_LOGVE_85000019);
			return;
		}

	}

	else
	{
		ptp_trns_an_port(pstPort, puchMsgPtr, usMsgLen);
		return;
	}

	usPortCnt = pstPort->pstClockData->stDefaultDS.usNumberPorts;
	pstDstPort = pstPort->pstClockData->pstPortData;

	pstPtpMsgSignal = (PTPMSG_SIGNALING_1AS*)ulMdtrMsgBuff;

	for(usLoopCnt = 0; usLoopCnt < usPortCnt; usLoopCnt++)
	{
		nCmpRet = tsn_Wrapper_MemCmp(&pstDstPort->stPortDS.stPortIdentity, &pstPtpMsgSignal->stTargetPortIdentity, sizeof(PORTIDENTITY));
		if(!nCmpRet)
		{
			callSignalSM_1588();
		}
		pstDstPort = pstDstPort->pstNextPortDataPtr;
	}
}

VOID	callSignalSM_1588(VOID)
{
	return;
}

#endif

#endif
