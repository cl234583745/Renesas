/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_Macro.h"
#ifdef	PTP_USE_IEEE802_1
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"
#include "gptpCapableIntSetSM.h"

#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0

static VOID gptpCapableIntSet_NP( PORTDATA* pstPort );
static VOID gptpCapableIntSet_00( PORTDATA* pstPort );
static VOID gptpCapableIntSet_01( PORTDATA* pstPort );
static VOID gptpCapableIntSet_02( PORTDATA* pstPort );
static VOID gptpCapableIntSet_03( PORTDATA* pstPort );

static BOOL gptpCapableIntSet_NotEnabled( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort );
static VOID gptpCapableIntSet_Initialize( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort );
static VOID gptpCapableIntSet_SetInterval( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort );
static CHAR computeLogGptpCapableMsgInt( CHAR chLogGptpCapableMessageInterval );
static GPTPCAPTRSM_EV getGptpCapableIntSetEvt( USHORT usEvent );
static GPTPCAPTRSM_ST getGptpCapableIntSetStatus( PORTDATA* pstPort );
static VOID setGptpCapableIntSetStatus( PORTDATA* pstPort, GPTPCINTSETSM_ST enSts );

static VOID (*const pfnGptpCapableIntSetMatrix[GPTPCINTSETSM_STATUS_MAX][GPTPCINTSETSM_EV_EVENT_MAX])(PORTDATA* pstPort) = 
{
	{&gptpCapableIntSet_01, &gptpCapableIntSet_NP, &gptpCapableIntSet_NP, gptpCapableIntSet_NP, gptpCapableIntSet_00},
	{&gptpCapableIntSet_01, &gptpCapableIntSet_NP, &gptpCapableIntSet_02, gptpCapableIntSet_NP, gptpCapableIntSet_00},
	{&gptpCapableIntSet_01, &gptpCapableIntSet_01, &gptpCapableIntSet_NP, gptpCapableIntSet_03, gptpCapableIntSet_00},
	{&gptpCapableIntSet_01, &gptpCapableIntSet_01, &gptpCapableIntSet_NP, gptpCapableIntSet_03, gptpCapableIntSet_00}
};

static BOOL gptpCapableIntSet_NotEnabled( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort )
{
	PORT_1AS_GD	*pstPort1AsGd;
	PORT_1AS_DS	*pstPort1AsDs;
	USCALEDNS 	 stUSNs={0};
	
	pstPort1AsGd = &pstPort->stPort_1AS_GD;
	pstPort1AsDs = &pstPort->stPort_1AS_DS;
	
	if ( pstPort1AsDs->blUseMgtSettableLogGptpCapMsgInt == FALSE )
	{
		return FALSE;
	}
	pstPort1AsDs->chCurrentLogGptpCapMsgInt = pstPort1AsDs->chMgtSettableLogGptpCapMsagInt;
	
	stUSNs.ulNsec_lsb = CONST10_9;

	(VOID)ptpShiftUSNs_CHAR( &stUSNs,
					   		 pstPort1AsDs->chCurrentLogGptpCapMsgInt,
					    	 &pstPort1AsGd->stGptpCapMsgInt );

	
	return TRUE;
}
static VOID gptpCapableIntSet_Initialize( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort )
{
	PORT_1AS_GD	*pstPort1AsGd;
	PORT_1AS_DS	*pstPort1AsDs;
	USCALEDNS 	 stUSNs={0};

	pstPort1AsGd = &pstPort->stPort_1AS_GD;
	pstPort1AsDs = &pstPort->stPort_1AS_DS;

	pstPort1AsDs->chCurrentLogGptpCapMsgInt = pstPort1AsDs->chInitialLogGptpCapMsgInt;
	
	stUSNs.ulNsec_lsb = CONST10_9;

	(VOID)ptpShiftUSNs_CHAR( &stUSNs,
		               		 pstPort1AsDs->chInitialLogGptpCapMsgInt,
					   		 &pstPort1AsGd->stGptpCapMsgInt );

	pstPort1AsGd->stOldGptpCapMsgInt = pstPort1AsGd->stGptpCapMsgInt;
	
	pstPort1AsGd->blGptpCapMsgSlowdown = FALSE;

	
	return ;
}
static CHAR computeLogGptpCapableMsgInt( CHAR chLogGptpCapableMessageInterval )
{
	CHAR chLimit;


	if (   (chLogGptpCapableMessageInterval >= GPTCAPINT_INT_VAL_INIT)
        || (chLogGptpCapableMessageInterval <= GPTCAPINT_INT_VAL_NONE) )
	{
		return chLogGptpCapableMessageInterval;
	}

	chLimit = LIM_MAX_ALLOW_GPTCAPINT;
	if ( chLimit > USR_MAX_ALLOW_GPTCAPINT )
	{
		chLimit = USR_MAX_ALLOW_GPTCAPINT;
	}
	if ( chLogGptpCapableMessageInterval >= chLimit )
	{
		return chLimit;
	}
	
	chLimit = LIM_MIN_ALLOW_GPTCAPINT;
	if ( chLimit < USR_MIN_ALLOW_GPTCAPINT )
	{
		chLimit = USR_MIN_ALLOW_GPTCAPINT;
	}
	if ( chLogGptpCapableMessageInterval<= chLimit )
	{
		return chLimit;
	}
	return chLogGptpCapableMessageInterval;
}

static VOID gptpCapableIntSet_SetInterval( GPTPCAPINTSETSM_GD* pstSmGbl, PORTDATA* pstPort )
{
	
	PORT_1AS_GD	*pstPort1AsGd;
	PORT_1AS_DS	*pstPort1AsDs;
	USCALEDNS 	 stUSNs={0};

	CHAR chLog;
	CHAR chRet;

	pstPort1AsGd = &pstPort->stPort_1AS_GD;
	pstPort1AsDs = &pstPort->stPort_1AS_DS;
	
	if ( pstPort1AsDs->blUseMgtSettableLogGptpCapMsgInt == FALSE )
	{
		chLog = pstSmGbl->pstRcvdSignalingPtrGIS->stGptpCap_TLV.chlogGptpCapableMessageInterval;
		pstSmGbl->chComputedLogGptpCapMsgInt = computeLogGptpCapableMsgInt(chLog);
		
		switch ( pstSmGbl->chComputedLogGptpCapMsgInt )
		{
			case GPTCAPINT_INT_VAL_NONE:
				break;
			case GPTCAPINT_INT_VAL_INIT:
				pstPort1AsDs->chCurrentLogGptpCapMsgInt = pstPort1AsDs->chInitialLogGptpCapMsgInt;

				stUSNs.ulNsec_lsb = CONST10_9;
				(VOID)ptpShiftUSNs_CHAR( &stUSNs,
					               		 pstPort1AsDs->chInitialLogGptpCapMsgInt,
					               		 &pstPort1AsGd->stGptpCapMsgInt );
				break;
			default:
				pstPort1AsDs->chCurrentLogGptpCapMsgInt = pstSmGbl->chComputedLogGptpCapMsgInt;

				stUSNs.ulNsec_lsb = CONST10_9;
				(VOID)ptpShiftUSNs_CHAR( &stUSNs,
					               		 pstSmGbl->chComputedLogGptpCapMsgInt,
					               		 &pstPort1AsGd->stGptpCapMsgInt );
				break;
		}
		chRet = ptpCompUSNs_USNs( &pstPort1AsGd->stGptpCapMsgInt, &pstPort1AsGd->stOldGptpCapMsgInt );
		if ( chRet == COMP_A_LESS )
		{
			pstPort1AsGd->blGptpCapMsgSlowdown = TRUE;
		}
		else
		{
			pstPort1AsGd->blGptpCapMsgSlowdown = FALSE;
		}
	}

	return;
}

static GPTPCAPTRSM_EV getGptpCapableIntSetEvt( USHORT usEvent )
{

	GPTPCAPTRSM_EV enEvt;
	
	enEvt = GPTPCINTSETSM_EV_EVENT_MAX;
	
	switch ( usEvent )
	{
		case PTP_EV_BEGIN:
			enEvt = GPTPCINTSETSM_EV_BEGIN;
			break;
		case PTP_EV_USEMGTSETABLELOGGPTP_ON:
			enEvt = GPTPCINTSETSM_EV_USEMGTSETABLELOGGPTP_ON;
			break;
		case PTP_EV_USEMGTSETABLELOGGPTP_OFF:
			enEvt = GPTPCINTSETSM_EV_USEMGTSETABLELOGGPTP_OFF;
			break;
		case PTP_EV_RCVDSIGNALINGMSG4CP:
			enEvt = GPTPCINTSETSM_EV_RCVDSIGNALINGMSG;
			break;
		case PTP_EV_CLOSE:
			enEvt = GPTPCINTSETSM_EV_CLOSE;
			break;
		default:
	        ptp_dbg_msg( D_ERR, 
	        			 ("%s::unknown ptp event. event=[%d]\n", 
	                      "getGptpCapableIntSetEvt",
	                      usEvent) );
			break;
	}
	
	return enEvt;
}
static GPTPCAPTRSM_ST getGptpCapableIntSetStatus( PORTDATA* pstPort )
{
	GPTPCAPTRSM_ST enSts;
	
	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "getGptpCapableIntSetStatus") );
		return GPTPCINTSETSM_STATUS_MAX;
	}
	enSts = pstPort->stGPTPCapIntSetSM_GD.enStsgptpCapableIntSet;
	
	return enSts;
}
static VOID setGptpCapableIntSetStatus( PORTDATA* pstPort, GPTPCINTSETSM_ST enSts )
{

	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "setGptpCapableIntSetStatus") );
		return ;
	}
    ptp_dbg_msg( D_STATE, 
    			 ("%s::state %d->%d \n", 
                  "setGptpCapableIntSetStatus",
                  pstPort->stGPTPCapIntSetSM_GD.enStsgptpCapableIntSet,
                  enSts) );

	pstPort->stGPTPCapIntSetSM_GD.enStsgptpCapableIntSet = enSts;

	return ;
}
static VOID gptpCapableIntSet_NP( PORTDATA* pstPort )
{
	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_NP::+\n") );

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_NP::-\n") );

	return ;
}
static VOID gptpCapableIntSet_00( PORTDATA* pstPort )
{
	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_00::+\n") );

	(VOID)gptpCapableIntSet_NotEnabled( &pstPort->stGPTPCapIntSetSM_GD, pstPort );

	setGptpCapableIntSetStatus( pstPort, GPTPCINTSETSM_NONE );

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_00::-\n") );

	return ;
}

static VOID gptpCapableIntSet_01( PORTDATA* pstPort )
{
	BOOL blRet;
	GPTPCINTSETSM_ST enSts;

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_01::+\n") );

	if (pstPort->pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag == TRUE)
	{

		blRet = gptpCapableIntSet_NotEnabled( &pstPort->stGPTPCapIntSetSM_GD, pstPort );
		if ( blRet == TRUE )
		{
			enSts = GPTPCINTSETSM_NOT_ENABLED;
		}
		else
		{
			gptpCapableIntSet_Initialize( &pstPort->stGPTPCapIntSetSM_GD, pstPort );

			enSts = GPTPCINTSETSM_INITIALIZE;
		}
		setGptpCapableIntSetStatus( pstPort, enSts );

	}

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_01::-\n") );

	return ;
}
static VOID gptpCapableIntSet_02( PORTDATA* pstPort )
{
	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_02::+\n") );

	gptpCapableIntSet_Initialize( &pstPort->stGPTPCapIntSetSM_GD, pstPort );

	setGptpCapableIntSetStatus( pstPort, GPTPCINTSETSM_INITIALIZE );

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_02::-\n") );

	return ;
}
static VOID gptpCapableIntSet_03( PORTDATA* pstPort )
{

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_03::+\n") );

	if ( pstPort->stGPTPCapIntSetSM_GD.pstRcvdSignalingPtrGIS == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::don't have recvice packet..\n", 
                      "gptpCapableIntSet_03") );
		return ;
	}
	gptpCapableIntSet_SetInterval( &pstPort->stGPTPCapIntSetSM_GD, pstPort );

	setGptpCapableIntSetStatus( pstPort, GPTPCINTSETSM_SET_INTERVAL );

	ptp_dbg_msg( D_FUNC, ("gptpCapableIntSet_03::-\n") );

	return ;
}
VOID gptpCapableIntSetSM( USHORT usEvent, PORTDATA* pstPort )
{

	GPTPCAPRCVSM_EV enEvt;
	GPTPCINTSETSM_ST enSts;

	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "gptpCapableIntSetSM") );
		return ;
	}

	enEvt = getGptpCapableIntSetEvt( usEvent );
	enSts = getGptpCapableIntSetStatus( pstPort );
	
	if (   (enEvt >= GPTPCINTSETSM_EV_EVENT_MAX)
        || (enSts >= GPTPCINTSETSM_STATUS_MAX) )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::unknown event ro status. event=[%d], status=[%d]\n", 
                      "gptpCapableIntSetSM",
                      enEvt,
                      enSts) );
		return ;
	}

	pfnGptpCapableIntSetMatrix[enSts][enEvt]( pstPort );
	
	return ;
}
#endif
