/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCINTVALSET_H__
#define __MDSYNCINTVALSET_H__

#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID SyncIntervalSettingSM(USHORT usEvent, PORTDATA* pstPort);

SISETTINGSM_GD*	GetSyncIntvSetGlobal(PORTDATA* pstPort);
SYNCINTVSET_EV	GetSyncIntvSetEvent(USHORT usEvent, PORTDATA* pstPort);
SYNCINTVSET_ST	GetSyncIntvSetStatus(PORTDATA* pstPort);
VOID			SetSyncIntvSetStatus(SYNCINTVSET_ST enSts, PORTDATA* pstPort);

VOID computeSyncInterval_1AS(PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
