/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_MemManage.h"

#include "ptp_CMSReceive.h"
#include "ptp_ClockSource_API.h"










VOID	txRcvdClockSourceReq(CLOCKDATA*	pstClockData);


INT	ptp_clockSourceSetTime(
	CLKSOURCETIME*	pstClkSrcTime)
{
	INT					nRetCode			= RET_EINVAL;

#ifdef	PTP_USE_GM

	CLOCKDATA*			pstClockData		= gpstClockDataHPtr;
	CMSRECEIVESM_GD*	pstCMSReceiveSM_GD	= NULL;
	LONG				lRet				= RET_ENOERR;


	if (pstClkSrcTime == NULL)
	{
		return nRetCode;
	}
	
	if (pstClkSrcTime->uchDomainNumber != 0)
	{
		return nRetCode;
	}
	
	if (pstClockData == NULL)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}
	if (gblStartUpConfig == FALSE)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}

	lRet = ptp_SystemSemLockWait(pstClockData);
	if (lRet != RET_ENOERR)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}

	pstCMSReceiveSM_GD								= &(pstClockData->stCMSReceiveSM_GD);
	pstCMSReceiveSM_GD->stRcvdClockSourceReq		= *pstClkSrcTime;
	pstCMSReceiveSM_GD->pstRcvdClockSourceReqPtr	= &(pstCMSReceiveSM_GD->stRcvdClockSourceReq);

	txRcvdClockSourceReq(pstClockData);

	(VOID)ptp_SystemSemUnLock(pstClockData);
	
	nRetCode = RET_ENOERR;

#endif
	
	return nRetCode;
}





VOID	txRcvdClockSourceReq(
	CLOCKDATA*	pstClockData)
{
#ifdef	PTP_USE_GM
	USHORT				usEvent				= PTP_EV_BASE;
	CMSRECEIVESM_GD*	pstCMSRECEIVESM_GD	= &(pstClockData->stCMSReceiveSM_GD);

	
	pstCMSRECEIVESM_GD->blRcvdClockSourceReq = TRUE;

	usEvent = PTP_EV_RCVDCLOCKSOURCEREQ;
	clockMasterSyncReceive(usEvent, pstClockData);

#endif
}






INT	ptp_clockSourceSetInfo( CLKSOURCEINFO*	pstClkSrcInfo )
{
	INT		nRetCode = RET_EINVAL;


#ifdef	PTP_USE_GM
	CLOCKDATA*	pstClockData;
	LONG		lRet = RET_ENOERR;

	if ( pstClkSrcInfo == NULL )
	{
		return nRetCode;
	}
	
	if ( pstClkSrcInfo->uchDomainNumber != 0U )
	{
		return nRetCode;
	}
	
	if ( gblStartUpConfig == FALSE )
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}
	
	lRet = ptp_SystemSemLockWait( gpstClockDataHPtr );
	if ( lRet != RET_ENOERR )
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}
	
	
	for ( pstClockData  = gpstClockDataHPtr;
		  pstClockData != NULL;
		  pstClockData  = pstClockData->pstNextClockDataPtr  )
	{
		pstClockData->stBMC_GD.blSysLeap61					= pstClkSrcInfo->blLeap61;
		pstClockData->stBMC_GD.blSysLeap59					= pstClkSrcInfo->blLeap59;
		pstClockData->stBMC_GD.blSysCurrentUTCOffsetValid	= pstClkSrcInfo->blCurrentUtcOffsetValid;
		pstClockData->stBMC_GD.blSysPtpTimescale			= pstClkSrcInfo->blPtpTimescale;
		pstClockData->stBMC_GD.blSysTimeTraceable			= pstClkSrcInfo->blTimeTraceable;
		pstClockData->stBMC_GD.blSysFrequencyTraceable		= pstClkSrcInfo->blFrecuencyTraceable;
		pstClockData->stBMC_GD.sSysCurrentUtcOffset			= pstClkSrcInfo->sCurrentUtcOffset;
		pstClockData->stBMC_GD.uchSysTimeSource				= pstClkSrcInfo->uchTimeSource;

		if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
		{
			if(pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)
			{
				pstClockData->stTimePropertiesDS.sCurrentUtcOffset
															= pstClkSrcInfo->sCurrentUtcOffset;
				pstClockData->stTimePropertiesDS.uchTimeSource
															= pstClkSrcInfo->uchTimeSource;
				pstClockData->stTimePropertiesDS.blFrequencyTraceable
															= pstClkSrcInfo->blFrecuencyTraceable;
				pstClockData->stTimePropertiesDS.blTimeTraceable
															= pstClkSrcInfo->blTimeTraceable;
				pstClockData->stTimePropertiesDS.blPtpTimescale
															= pstClkSrcInfo->blPtpTimescale;
				pstClockData->stTimePropertiesDS.blLeap61	= pstClkSrcInfo->blLeap61;
				pstClockData->stTimePropertiesDS.blLeap59	= pstClkSrcInfo->blLeap59;
				pstClockData->stTimePropertiesDS.blCurrentUtcOffsetValid = pstClkSrcInfo->blCurrentUtcOffsetValid;
			}
		}
		else
		{
			pstClockData->stDefault_1AS_DS.blLeap61 			 	= pstClkSrcInfo->blLeap61;
			pstClockData->stDefault_1AS_DS.blLeap59				 	= pstClkSrcInfo->blLeap59;
			pstClockData->stDefault_1AS_DS.blTimeTraceable			= pstClkSrcInfo->blTimeTraceable;
			pstClockData->stDefault_1AS_DS.blCurrentUtcOffsetValid	= pstClkSrcInfo->blCurrentUtcOffsetValid;
			pstClockData->stDefault_1AS_DS.blPtpTimescale			= pstClkSrcInfo->blPtpTimescale;
			pstClockData->stDefault_1AS_DS.blFrequencyTraceable		= pstClkSrcInfo->blFrecuencyTraceable;
		}
	}
	(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );

	nRetCode = RET_ENOERR;
	
#endif

	return nRetCode;
}



