/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "PortAnnounceTransmitSM.h"
#include "PortAnnounceTransmitSMGD.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_tsn_Wrapper.h"
#include "ptp_LCEntity.h"
#include "ptp_LogRecord.h"
#include "mdtransinterface.h"
#include "PortAnnounceCountSM.h"

#define D_FUNC	0

#define	ALLOW_MAX_PATHTRACE_CNT	((1500-PTPMSG_ANUNC_SZ-PTPMSG_ANNUNCETLV_TLVTYPE_SZ-PTPMSG_ANNUNCETLV_TLVLENGTH_SZ)/sizeof(CLOCKIDENTITY))

VOID (*const PortAnnounceTransmitSM_Matrix[PATRANSMITSM_ST_MAX][PATRANSMITSM_EV_MAX] )(PORTDATA * pstPortData) =
{
	{&PortAnnounceTransmit_01,	&PortAnnounceTransmit_nop, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_00},
	{&PortAnnounceTransmit_01, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_00},
	{&PortAnnounceTransmit_01,	&PortAnnounceTransmit_02,  &PortAnnounceTransmit_05,  &PortAnnounceTransmit_00},
	{&PortAnnounceTransmit_01, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_00},
	{&PortAnnounceTransmit_01, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_nop, &PortAnnounceTransmit_00}
};

VOID	portAnnounceTransmitSM(USHORT usEvent, PORTDATA *pstPort)
{
	PATRANSMITSM_GD	*pstSMGlb;
	PATRANSMITSM_EV	enEvt;

	pstSMGlb = &(pstPort->stPATransmitSM_GD);

	enEvt =	GetportAnnTransmitEvent(usEvent);

	if (enEvt < PATRAN_EV_EVENT_MAX)
	{
		if (pstSMGlb->enStatus < PATRANSM_STATUS_MAX)
		{
			if(enEvt == PATRAN_EV_ANNOUNCESENDTIME)
			{
				pstSMGlb->pstTOAnnounceTransmit = NULL;
			}
			(*PortAnnounceTransmitSM_Matrix[pstSMGlb->enStatus][enEvt])(pstPort);
			return;
		}
	}
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000003);
	return;
}

PATRANSMITSM_EV	GetportAnnTransmitEvent(USHORT usEvent)
{
	PATRANSMITSM_EV		enEvt;
	switch (usEvent)
	{
		case (USHORT)PTP_EV_BEGIN:
			enEvt = PATRAN_EV_BEGIN;
			break;
		case (USHORT)PTP_EV_ANNOUNCESENDTIME:
			enEvt = PATRAN_EV_ANNOUNCESENDTIME;
			break;
		case (USHORT)PTP_EV_NEWINFO:
			enEvt = PATRAN_EV_NEWINFO;
			break;
		case (USHORT)PTP_EV_CLOSE:
			enEvt = PATRAN_EV_CLOSE;
			break;
		default:
			enEvt = PATRAN_EV_EVENT_MAX;
		break;
	}
	return(enEvt);
}

VOID	PortAnnounceTransmit_00(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PATRANSMITSM_GD	*pstSMGlb;
	BOOL		blRet;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PortAnnounceTransmit_00+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPATransmitSM_GD);


	pstPortBmcGd->blAnnounceSlowdown = FALSE;
	pstSMGlb->uchNumberAnnounceTransmissions = 0;

	pstSMGlb->enStatus = PATRANSM_TRANSMIT_INIT;

	if (pstSMGlb->pstTOAnnounceTransmit != NULL)
	{
		blRet = (BOOL)ptp_TimeOut_Can(pstSMGlb->pstTOAnnounceTransmit);
		if (blRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000023);
		}
		pstSMGlb->pstTOAnnounceTransmit = NULL;
	}

	ptp_dbg_msg( D_FUNC, ("PortAnnounceTransmit_00::-\n") );

	return;
}

VOID	PortAnnounceTransmit_01(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PATRANSMITSM_GD	*pstSMGlb;

#ifdef PTP_USE_IEEE1588
	CHAR		chA;
	BOOL		blRet;
	USCALEDNS	stTimeoutTimeWork;
#endif


	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb = &(pstPort->stPATransmitSM_GD);

	pstPortBmcGd->usAnnounceSequenceId = (USHORT)tsn_Wrapper_Rand();

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
		stTimeoutTimeWork.ulNsec_lsb = CONST10_9;
		chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;

		blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &pstPortBmcGd->stAnnounceInterval);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}
#endif
	}
	else
	{
#ifndef PTP_USE_SIGNALING
		anuncIntSet_1AS(pstPort);
#endif
	}

		pstPortBmcGd->blAnnounceSlowdown = FALSE;
		pstSMGlb->uchNumberAnnounceTransmissions = 0;
		pstSMGlb->stInterval2 = pstPortBmcGd->stAnnounceInterval;
		pstSMGlb->enStatus = PATRANSM_TRANSMIT_INIT;

		PortAnnounceTransmit_03(pstPort);

	return;
}

VOID	PortAnnounceTransmit_02(PORTDATA *pstPort)
{
	CLOCK_GD	*pstClockGd;
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PATRANSMITSM_GD	*pstSMGlb;

	USHORT			usPortNumber;

	pstClockGd 	 = &(pstPort->pstClockData->stClock_GD);
	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPATransmitSM_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

#ifdef	TMO_DGB
	printf("Anounce Tx Domain = %d\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber);
#endif


	if( ((pstBmcGd->blSelected[usPortNumber]) && (!pstPortBmcGd->blUpdtInfo))
													 || (pstBmcGd->blExternalPortConfiguration) )
	{
		if (!pstPortBmcGd->blNewInfo)
		{
			if(pstClockGd->enSelectedState[usPortNumber] == ENUM_PORTSTATE_MASTER)
			{
				pstPortBmcGd->blNewInfo = TRUE;
			}
			else
			{
			}
		}

		pstSMGlb->enStatus = PATRANSM_TRANSMIT_PERIODIC;

		PortAnnounceTransmit_03(pstPort);
	}
	else
	{

#ifdef	TMO_DGB
		printf("[02]AnnounceTX Timer Start[Domain=%d]\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber);
#endif
		SetTxAnnouceTimer(pstPort);
	}
}
VOID	PortAnnounceTransmit_03(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	USCALEDNS	stCurrentTime;


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstPortBmcGd = &(pstPort->stPortBMC_GD);

#ifdef	TMO_DGB
	printf("[03]AnnounceTX Timer Start[Domain=%d]\n", pstPort->pstClockData->stDefaultDS.uchDomainNumber);
#endif
	SetTxAnnouceTimer(pstPort);


	if (pstPortBmcGd->blNewInfo)
	{
		PortAnnounceTransmit_05(pstPort);
	}
}

VOID	PortAnnounceTransmit_04(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PORT_DS		*pstPortDs;
	PATRANSMITSM_GD	*pstSMGlb;
	BOOL		blRet;
	USCALEDNS	stCurrentTime;


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstSMGlb	 = &(pstPort->stPATransmitSM_GD);
	pstPortDs	 = &(pstPort->stPortDS);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	pstPortBmcGd->blNewInfo = FALSE;


	if (pstPort->stPort_1AS_DS.blAsCapable)
	{

		txAnnounce(pstPort);

	}
	if (pstPortBmcGd->blAnnounceSlowdown)
	{
		if(pstSMGlb->uchNumberAnnounceTransmissions >= pstPortDs->uchAnnounceReceiptTimeout)
		{
			pstSMGlb->stInterval2 = pstPortBmcGd->stAnnounceInterval;
			pstSMGlb->uchNumberAnnounceTransmissions = 0;
			pstPortBmcGd->blAnnounceSlowdown = FALSE;
		}
		else
		{
			pstSMGlb->stInterval2 = pstPortBmcGd->stOldAnnounceInterval;
			pstSMGlb->uchNumberAnnounceTransmissions++;
		}
		
	}
	else
	{
		pstSMGlb->stInterval2 = pstPortBmcGd->stAnnounceInterval;
		pstSMGlb->uchNumberAnnounceTransmissions = 0;
	}

	blRet = ptpAddUSNs_USNs (&stCurrentTime, &pstSMGlb->stInterval2, &pstSMGlb->stAnnounceSendTime);
	if(!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	pstSMGlb->enStatus = PATRANSM_IDLE;

	if (pstSMGlb->pstTOAnnounceTransmit != NULL)
	{
		blRet = (BOOL)ptp_TimeOut_Can(pstSMGlb->pstTOAnnounceTransmit);
		if (blRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000023);
		}
		pstSMGlb->pstTOAnnounceTransmit = NULL;
	}

#ifdef	TMO_DGB
	printf ("[04]AnnounceTX Timer Start[Domain=%d]\n",pstPort->pstClockData->stDefaultDS.uchDomainNumber);
#endif
	pstSMGlb->pstTOAnnounceTransmit = ptp_TimeOut_Req(
							(USHORT)PTP_EV_ANNOUNCESENDTIME,
							(VOID*)pstPort,
							pstSMGlb->stAnnounceSendTime,
							(CallBackFunc)&portAnnounceTransmitSM);
	if (pstSMGlb->pstTOAnnounceTransmit == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000021);
	}

}

VOID	PortAnnounceTransmit_05(PORTDATA *pstPort)
{
	CLOCK_GD	*pstClockGd;
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PATRANSMITSM_GD	*pstSMGlb;
	CHAR		chCmpRet;

	USHORT			usPortNumber;
	USCALEDNS		stCurrentTime;


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstClockGd 	 = &(pstPort->pstClockData->stClock_GD);
	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPATransmitSM_GD);

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if(pstClockGd->enSelectedState[usPortNumber] == ENUM_PORTSTATE_MASTER)
	{
		
		chCmpRet = ptpCompUSNs_USNs(&stCurrentTime, &pstSMGlb->stAnnounceSendTime);
		if(chCmpRet<0)
		{
			if( ((pstBmcGd->blSelected[usPortNumber]) && (!pstPortBmcGd->blUpdtInfo))
													 || (pstBmcGd->blExternalPortConfiguration) )
			{
				{
					pstSMGlb->enStatus = PATRANSM_IDLE;

					PortAnnounceTransmit_04(pstPort);

					pstSMGlb->enStatus = PATRANSM_IDLE;

				}
			}
			else
			{
			}
		}
	}
}

VOID	txAnnounce(struct tagPORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PTPMSG_ANNOUNCE *pstSendAnnounce;
	INT			nRet;
	TIMESTAMP_CALLBK_INF stCallback ={0};

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSendAnnounce = &(pstPort->stPortMD_GD.stConAnnounce);


	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		txAnnounce_1588(pstPort);
#endif
	}
	else
	{
		txAnnounce_AS(pstPort);
	}

	pstPortBmcGd->usAnnounceSequenceId += 1;

	pstSendAnnounce->stHeader.usSequenceId = pstPortBmcGd->usAnnounceSequenceId;


	stCallback.pstPortData = pstPort;

	nRet = MD_ptp_send(
				(UCHAR*)&(pstPort->stPortMD_GD.stConAnnounce),
				pstPort->stPortMD_GD.stConAnnounce.stHeader.usMegLength,
				&stCallback);
	if(nRet == RET_ENOERR)
	{
		IncPortAnnTxAnnounceCount(pstPort);
	}
	else
	{
	}

}

VOID	txAnnounce_1588(struct tagPORTDATA *pstPort)
{
	PTPMSG_ANNOUNCE 	*pstSendAnnounce;
	BMC_GD				*pstBmcGd;
	PORT_DS				*pstPortDs;
	TIMEPROPERTIES_DS	*pstTimePropDs;
	PARENT_DS			*pstParentDs;
	CURRENT_DS			*pstCurrentDs;
	USCALEDNS			stCurrentMasterTime;

	pstParentDs = &(pstPort->pstClockData->stParentDS);
	pstTimePropDs = &(pstPort->pstClockData->stTimePropertiesDS);
	pstCurrentDs = &(pstPort->pstClockData->stCurrentDS);

	pstBmcGd = &(pstPort->pstClockData->stBMC_GD);
	pstPortDs = &(pstPort->stPortDS);

	pstSendAnnounce = &(pstPort->stPortMD_GD.stConAnnounce);


	MPTPMSG_H_SET_VER_PTP( &pstSendAnnounce->stHeader, pstPortDs->byVersionNumber );
    MPTPMSG_H_SET_MINOR_VER( &pstSendAnnounce->stHeader, 0 );

    MPTPMSG_H_SET_MSG_TYPE( &pstSendAnnounce->stHeader, PTPM_MSGTYPE_ANNOUNCE );
    MPTPMSG_H_SET_MAJORSDO_ID( &pstSendAnnounce->stHeader, 0 );

	pstSendAnnounce->stHeader.uchDomainNumber = pstPort->pstClockData->stDefaultDS.uchDomainNumber;

	if (pstBmcGd->blPathTraceEnable)
	{
		if (pstBmcGd->uchPathTraceCount <= ALLOW_MAX_PATHTRACE_CNT)
		{
			pstSendAnnounce->stAnnounce_TLV.usTLVType = PTPM_TLVTYP_ANNOUNCE;
			pstSendAnnounce->stAnnounce_TLV.usLengthField = (pstBmcGd->uchPathTraceCount * sizeof(CLOCKIDENTITY));

			tsn_Wrapper_MemCpy(&pstSendAnnounce->stAnnounce_TLV.stPathSequence[0],
				&pstBmcGd->stPathTrace[0], pstSendAnnounce->stAnnounce_TLV.usLengthField);

			GetPTPMSG_HEADER(pstSendAnnounce->stHeader, pstSendAnnounce->stHeader.usMegLength);
			GetPTPMSG_ANNOUNCE(*pstSendAnnounce, pstSendAnnounce->stHeader.usMegLength);
			pstSendAnnounce->stHeader.usMegLength += PTPMSG_ANNUNCETLV_TLVTYPE_SZ + PTPMSG_ANNUNCETLV_TLVLENGTH_SZ + (sizeof(CLOCKIDENTITY) * pstBmcGd->uchPathTraceCount);

		}
		else
		{
			GetPTPMSG_HEADER(pstSendAnnounce->stHeader, pstSendAnnounce->stHeader.usMegLength);
			GetPTPMSG_ANNOUNCE(*pstSendAnnounce, pstSendAnnounce->stHeader.usMegLength);
		}
	}
	else
	{
		GetPTPMSG_HEADER(pstSendAnnounce->stHeader, pstSendAnnounce->stHeader.usMegLength);
		GetPTPMSG_ANNOUNCE(*pstSendAnnounce, pstSendAnnounce->stHeader.usMegLength);
	}

	pstSendAnnounce->stHeader.stCorrectionField.sNsec_msb = 0;
	pstSendAnnounce->stHeader.stCorrectionField.ulNsec_lsb = 0;
	pstSendAnnounce->stHeader.stCorrectionField.usFrcNsec = 0;

	pstSendAnnounce->stHeader.uchControl = PTPM_CONTROL_ANNOUNCE;

	pstSendAnnounce->uchGrandmasterPriority1 = pstParentDs->uchGrandmasterPriority1;
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stGrandmasterClockQuality,
		&pstParentDs->stGrandmasterClockQuality, sizeof(CLOCKQUALITY));
	pstSendAnnounce->uchGrandmasterPriority2 = pstParentDs->uchGrandmasterPriority2;
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stGrandmasterIdentity,
		&pstParentDs->stGrandmasterIdentity, sizeof(CLOCKIDENTITY));

	pstSendAnnounce->usStepsRemoved = pstCurrentDs->usStepsRemoved;
	if (pstPort->pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_PASSIVE)
	{
		pstSendAnnounce->usStepsRemoved = pstSendAnnounce->usStepsRemoved + 1;
	}
	pstSendAnnounce->sCurrentUtcOffset = pstTimePropDs->sCurrentUtcOffset;

    MPTPMSG_H_SET_FLAGS1_LEAP61( &pstSendAnnounce->stHeader, pstTimePropDs->blLeap61 );
    MPTPMSG_H_SET_FLAGS1_LEAP59( &pstSendAnnounce->stHeader, pstTimePropDs->blLeap59 );
    MPTPMSG_H_SET_FLAGS1_CRNT_UTCOFSVAL( &pstSendAnnounce->stHeader, pstTimePropDs->blCurrentUtcOffsetValid );
    MPTPMSG_H_SET_FLAGS1_PTPTIMESCALE( &pstSendAnnounce->stHeader, pstTimePropDs->blPtpTimescale );
    MPTPMSG_H_SET_FLAGS1_TMTRACEABLE( &pstSendAnnounce->stHeader, pstTimePropDs->blTimeTraceable );
    MPTPMSG_H_SET_FLAGS1_FQTRACEABLE( &pstSendAnnounce->stHeader, pstTimePropDs->blFrequencyTraceable );

	pstSendAnnounce->uchTimeSource = pstTimePropDs->uchTimeSource;

	ptp_GetCurrentMasterTime(pstPort->pstClockData, &stCurrentMasterTime);
	
	ptpConvUSNs_TS(&stCurrentMasterTime, &pstSendAnnounce->stOriginTimestamp);
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stHeader.stSrcPortIdentity.stClockIdentity,
								&pstPort->stPortDS.stPortIdentity.stClockIdentity,sizeof(CLOCKIDENTITY));
	pstSendAnnounce->stHeader.stSrcPortIdentity.usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;
	pstSendAnnounce->stHeader.chLogMsgInterVal = pstPort->stPort_1588_DS.chLogAnnounceInterval;
}

VOID	txAnnounce_AS(struct tagPORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PTPMSG_ANNOUNCE *pstSendAnnounce;
	BMC_GD		*pstBmcGd;


	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	if (pstPort->pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)
	{
		pstBmcGd->blLeap61			   = pstPort->pstClockData->stDefault_1AS_DS.blLeap61;
		pstBmcGd->blLeap59			   = pstPort->pstClockData->stDefault_1AS_DS.blLeap59;
		pstBmcGd->blTimeTraceable	   = pstPort->pstClockData->stDefault_1AS_DS.blTimeTraceable;
		pstBmcGd->blCurrentUtcOffsetValid = pstPort->pstClockData->stDefault_1AS_DS.blCurrentUtcOffsetValid;
		pstBmcGd->blPtpTimescale	   = pstPort->pstClockData->stDefault_1AS_DS.blPtpTimescale;
		pstBmcGd->blFrequencyTraceable = pstPort->pstClockData->stDefault_1AS_DS.blFrequencyTraceable;

		pstBmcGd->blSysLeap61			  = pstPort->pstClockData->stDefault_1AS_DS.blLeap61;
		pstBmcGd->blSysLeap59			  = pstPort->pstClockData->stDefault_1AS_DS.blLeap59;
		pstBmcGd->blSysTimeTraceable	  = pstPort->pstClockData->stDefault_1AS_DS.blTimeTraceable;
		pstBmcGd->blSysCurrentUTCOffsetValid = pstPort->pstClockData->stDefault_1AS_DS.blCurrentUtcOffsetValid;
		pstBmcGd->blSysPtpTimescale 	  = pstPort->pstClockData->stDefault_1AS_DS.blPtpTimescale;
		pstBmcGd->blSysFrequencyTraceable = pstPort->pstClockData->stDefault_1AS_DS.blFrequencyTraceable;

	}

	pstSendAnnounce = &(pstPort->stPortMD_GD.stConAnnounce);

    MPTPMSG_H_SET_MAJORSDO_ID( &pstSendAnnounce->stHeader, PTPM_MAJOR_SDOID_1 );
    MPTPMSG_H_SET_MINOR_VER( &pstSendAnnounce->stHeader, PTPM_MINOR_VER_PTP_1 );

	pstSendAnnounce->stAnnounce_TLV.usTLVType = PTPM_TLVTYP_ANNOUNCE;
	pstSendAnnounce->stAnnounce_TLV.usLengthField = (pstBmcGd->uchPathTraceCount * sizeof(CLOCKIDENTITY));

	if (pstBmcGd->uchPathTraceCount <= ALLOW_MAX_PATHTRACE_CNT)
	{

		tsn_Wrapper_MemCpy (&pstSendAnnounce->stAnnounce_TLV.stPathSequence[0],
								&pstBmcGd->stPathTrace[0], pstSendAnnounce->stAnnounce_TLV.usLengthField);
										
		GetPTPMSG_HEADER(pstSendAnnounce->stHeader, pstSendAnnounce->stHeader.usMegLength);
		GetPTPMSG_ANNOUNCE(*pstSendAnnounce, pstSendAnnounce->stHeader.usMegLength);
		pstSendAnnounce->stHeader.usMegLength += PTPMSG_ANNUNCETLV_TLVTYPE_SZ + PTPMSG_ANNUNCETLV_TLVLENGTH_SZ+ (sizeof(CLOCKIDENTITY) * pstBmcGd->uchPathTraceCount);

	}
	else
	{
		GetPTPMSG_HEADER(pstSendAnnounce->stHeader, pstSendAnnounce->stHeader.usMegLength);
		GetPTPMSG_ANNOUNCE(*pstSendAnnounce, pstSendAnnounce->stHeader.usMegLength);
	}

    MPTPMSG_H_SET_MSG_TYPE( &pstSendAnnounce->stHeader, PTPM_MSGTYPE_ANNOUNCE );
    MPTPMSG_H_SET_VER_PTP( &pstSendAnnounce->stHeader, PTPM_VER_PTP_2 );

	pstSendAnnounce->stHeader.uchDomainNumber = pstPort->pstClockData->stDefaultDS.uchDomainNumber;

	pstSendAnnounce->stHeader.stCorrectionField.sNsec_msb = 0;
	pstSendAnnounce->stHeader.stCorrectionField.ulNsec_lsb = 0;
	pstSendAnnounce->stHeader.stCorrectionField.usFrcNsec = 0;

	pstSendAnnounce->stHeader.uchControl = PTPM_CONTROL_ANNOUNCE;

	pstSendAnnounce->uchGrandmasterPriority1 = pstPortBmcGd->stMasterPriority.stRootSystemIdentity.uchPriority1;
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stGrandmasterClockQuality,
								&pstPortBmcGd->stMasterPriority.stRootSystemIdentity.stClockQuality, sizeof(CLOCKQUALITY));
	pstSendAnnounce->uchGrandmasterPriority2 = pstPortBmcGd->stMasterPriority.stRootSystemIdentity.uchPriority2;
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stGrandmasterIdentity,
								&pstPortBmcGd->stMasterPriority.stRootSystemIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));

	pstSendAnnounce->usStepsRemoved = pstBmcGd->usMasterStepsRemoved;
	pstSendAnnounce->sCurrentUtcOffset = pstBmcGd->sCurrentUtcOffset;
    MPTPMSG_H_SET_FLAGS1_LEAP61( &pstSendAnnounce->stHeader, pstBmcGd->blLeap61 );
    MPTPMSG_H_SET_FLAGS1_LEAP59( &pstSendAnnounce->stHeader, pstBmcGd->blLeap59 );
    MPTPMSG_H_SET_FLAGS1_CRNT_UTCOFSVAL( &pstSendAnnounce->stHeader, pstBmcGd->blCurrentUtcOffsetValid );
    MPTPMSG_H_SET_FLAGS1_PTPTIMESCALE( &pstSendAnnounce->stHeader, pstBmcGd->blPtpTimescale );
    MPTPMSG_H_SET_FLAGS1_TMTRACEABLE( &pstSendAnnounce->stHeader, pstBmcGd->blTimeTraceable );
    MPTPMSG_H_SET_FLAGS1_FQTRACEABLE( &pstSendAnnounce->stHeader, pstBmcGd->blFrequencyTraceable );

	pstSendAnnounce->uchTimeSource = pstBmcGd->uchTimeSource;
	
	tsn_Wrapper_MemCpy(&pstSendAnnounce->stHeader.stSrcPortIdentity.stClockIdentity,
								&pstPort->stPortDS.stPortIdentity.stClockIdentity,sizeof(CLOCKIDENTITY));
	pstSendAnnounce->stHeader.stSrcPortIdentity.usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	pstSendAnnounce->stHeader.chLogMsgInterVal = pstPort->stPort_1AS_DS.chCurrentLogAnnounceInterval;

}

VOID PortAnnounceTransmit_nop(PORTDATA *pstPort)
{
	return;
}

VOID SetTxAnnouceTimer(PORTDATA *pstPort)
{
	PATRANSMITSM_GD	*pstSMGlb;
	BOOL		blRet;
	PORTBMC_GD	*pstPortBmcGd;
	USCALEDNS	stCurrentTime;

#ifdef	PTP_USE_IEEE1588
	CHAR		chA;
	USCALEDNS	stTimeoutTimeWork;
#endif


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	pstSMGlb	 = &(pstPort->stPATransmitSM_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
		stTimeoutTimeWork.ulNsec_lsb = CONST10_9;
		chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;

		blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &pstPortBmcGd->stAnnounceInterval);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_OVERFLOW);
		}
		pstSMGlb->stInterval2 = pstPortBmcGd->stAnnounceInterval;
#endif
	}

	blRet = ptpAddUSNs_USNs (&stCurrentTime, &pstSMGlb->stInterval2, &pstSMGlb->stAnnounceSendTime);

	if(!blRet)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_OVERFLOW);
	}

	pstSMGlb->enStatus = PATRANSM_IDLE;

	if (pstSMGlb->pstTOAnnounceTransmit != NULL)
	{
		blRet = (BOOL)ptp_TimeOut_Can(pstSMGlb->pstTOAnnounceTransmit);
		if (blRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000023);
		}
		pstSMGlb->pstTOAnnounceTransmit = NULL;
	}

	pstSMGlb->pstTOAnnounceTransmit = ptp_TimeOut_Req(
							(USHORT)PTP_EV_ANNOUNCESENDTIME,
							(VOID*)pstPort,
							pstSMGlb->stAnnounceSendTime,
							(CallBackFunc)&portAnnounceTransmitSM);
	if (pstSMGlb->pstTOAnnounceTransmit == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PATRANSMITSM, (ULONG)PTP_LOGVE_81000021);
	}
}

#ifndef PTP_USE_SIGNALING
VOID anuncIntSet_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS;
	USCALEDNS		stA_USNs = { 0 };

	pstPortDS = &pstPort->stPort_1AS_DS;

	if (pstPortDS->blUseMgtSetLogAnnounceInterval)
	{
		pstPortDS->chCurrentLogAnnounceInterval
			= pstPortDS->chMgtSettableLogAnnounceInterval;
	}
	else
	{
		pstPortDS->chCurrentLogAnnounceInterval
			= pstPortDS->chInitialLogAnnounceInterval;
	}

	stA_USNs.ulNsec_lsb = CONST10_9;

	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstPortDS->chCurrentLogAnnounceInterval,
		&pstPort->stPortBMC_GD.stAnnounceInterval);

	return;
}

#endif
