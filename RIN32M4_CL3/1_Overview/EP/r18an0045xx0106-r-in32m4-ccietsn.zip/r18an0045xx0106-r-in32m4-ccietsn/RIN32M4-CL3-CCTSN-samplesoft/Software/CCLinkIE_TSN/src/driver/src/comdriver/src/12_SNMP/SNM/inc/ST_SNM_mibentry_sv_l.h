/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNP_MIBENTRY_SV_L_H_INCLUDED__
#define __ST_SNP_MIBENTRY_SV_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_mib.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#else
#include "ST_SNC_mib.h"
#include "ST_SNC_mset_sv_l.h"
#endif
#endif

#define ST_SNM_VALUE_NONE    0xFFFFFFFF

typedef enum { 
	ST_SNM_IDX_0,
	ST_SNM_IDX_1,
	ST_SNM_IDX_2,
	ST_SNM_IDX_3,
	ST_SNM_IDX_4,
	ST_SNM_IDX_5,
	ST_SNM_IDX_6,
	ST_SNM_IDX_MAX,
} ST_SNM_IndexNum;

#define ST_SNM_INDEXLEN				(7)


typedef enum {
	ST_SNM_MIBENTRY_OID,
	ST_SNM_MIBENTRY_TYPE,
	ST_SNM_MIBENTRY_ATTR,
} ST_SNM_MibEtnryItem;

typedef enum ST_SNM_MibClass_TAG {
	ST_SNM_MIBCLASS_EXT,
#ifdef SWPS
	ST_SNM_MIBCLASS_LLDP,
#endif
	ST_SNM_MIBCLASS_MAX
} ST_SNM_MibClass;



typedef struct ST_SNM_MibAddr_TAG {
	NX_ULONG					ulOfst;
	NX_ULONG					ulSize;
} ST_SNM_MibAttr;


typedef struct ST_SNM_Mib_TAG {
	NX_UCHAR					ucMibType;
	NX_UCHAR					ucOperable;
	NX_VOID**					pvAddr;
	ST_SNM_MibAttr			stAttr;
} ST_SNM_Mib;

typedef struct ST_SNM_Oid_TAG {
	NX_ULONG	uiLen;
	NX_ULONG	auiOid[ST_SNM_INDEXLEN];
} ST_SNM_Oid;

typedef struct ST_SNM_MibEntry_TAG {
	ST_SNM_Oid				stOid;
	ST_SNM_Mib				stMib;
#ifdef SWPS
	UINT					uiAcc;
	NX_UCHAR					ucType;
#endif
	NX_UCHAR					ucIdx;
} ST_SNM_MibEntry;

typedef struct ST_SNM_ArrayInf_TAG {
	NX_USHORT					usIdxAryNum;
	NX_USHORT					usAryEntryOidmap;
	NX_USHORT					usAryMax;
	NX_ULONG					ulStructSize;
} ST_SNM_ArrayInf;

typedef struct ST_SNM_Index_TAG {
	ST_SNM_IndexNum			eNum;
	ST_SNM_ArrayInf			astInf[ST_SNM_INDEXLEN];
} ST_SNM_Index;

typedef struct ST_SNM_GetItem_TAG {
	NX_UCHAR					uchItemType;
	NX_USHORT 					usOidmap;
	NX_UCHAR					uchIdxAryInf;
	NX_ULONG					bCallSnmpReq;
	NX_VOID*					pObj;
} ST_SNM_GetItem;

typedef struct ST_SNM_MibTblSet_TAG {
	NX_USHORT				usMibTblSize;
	ST_SNM_MibEntry*	pstMibTbl;
	NX_USHORT				usIdxTblSize;
	const ST_SNM_Index*	pstIdxTbl;
#ifdef SWPS
	NX_VOID				(*getOidPre)(NX_VOID* pAsn, NX_ULONG bFree);
	NX_ULONG				(*checkOidPre)(NX_VOID* pAsn);
#endif
	NX_ULONG				(*updateAddr)(NX_VOID);
	NX_ULONG				(*getItem)(ST_SNM_GetItem* pstItem);
#ifdef SWPS
	NX_ULONG				(*get)(NX_USHORT usOidmap, NX_USHORT usTabix, NX_UCHAR** puchPtr, NX_ULONG bIndex);
	NX_ULONG				(*index)(NX_USHORT usOidmap, NX_USHORT usTabix);
	NX_ULONG				(*getIdxNum)(NX_USHORT usOidmap, NX_UCHAR* puchNum);
	NX_ULONG				(*idx2oid)(NX_UCHAR uchIdx, NX_ULONG ulIndex, NX_VOID* pvOidSuffix);
	NX_ULONG				(*oid2idx)(NX_UCHAR uchIdx, const NX_VOID* pvOidSuffix, NX_ULONG* pulIndex);
#endif
} ST_SNM_MibTblSet;


typedef struct ST_SNM_TblLoop_TAG {
	NX_USHORT 	usCounterInit;
	NX_USHORT	usCounterMax;
} ST_SNM_TblLoop;

typedef struct ST_SNM_SearchTbl_TAG {
	ST_SNM_Oid 		stOid;
	NX_UCHAR			ucMibType;
} ST_SNM_Suffix;


#ifdef MASTER
struct ST_SNC_MibAttr_TAG;
typedef struct ST_SNC_MibAttr_TAG ST_SNC_MibAttr;
#endif
#ifdef SWPS
extern NX_VOID ST_SNM_LldpMib_GetAsnPrefix(NX_VOID* pAsn, NX_ULONG bFree);
#endif
extern NX_ULONG ulST_SNM_GetAddr(NX_UCHAR uchMibClass);
extern NX_ULONG ulST_SNM_Oidmap2Mibtype(NX_UCHAR uchMibClass, NX_USHORT usOidmap, ST_SNC_Mibtype* peMibType);
extern NX_ULONG ulST_SNM_Oidmap2MibAttr(NX_UCHAR uchMibClass, NX_USHORT usOidmap, NX_UCHAR uchIdxArayInf, ST_SNC_MibAttr* pstAttr);
extern NX_VOID ST_SNM_SetGetItem(
	ST_SNM_GetItem* 	pstItem,
	NX_UCHAR				uchItemType,
	NX_USHORT				usOidmap,
	NX_UCHAR				uchIdxAryInf,
	NX_ULONG				bCallSnmpReq,
	NX_VOID*				pObj
);


#endif
