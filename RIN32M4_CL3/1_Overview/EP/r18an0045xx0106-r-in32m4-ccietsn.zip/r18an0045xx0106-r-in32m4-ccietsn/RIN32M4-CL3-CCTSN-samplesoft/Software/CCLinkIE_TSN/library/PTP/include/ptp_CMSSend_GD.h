/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSSEND_GD_H__
#define __PTP_CMSSEND_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_CMSS {
	ST_CMSS_NONE	= 0,
	ST_CMSS_INITIALIZING,
	ST_CMSS_SEND_SYNC_INDICATION,
	ST_CMSS_MAX
} EN_ST_CMSS;

typedef	enum	tagEN_EV_CMSS {
	EV_CMSS_BEGIN = 0,
	EV_CMSS_SYNC_SENDTIME,
	EV_CMSS_CLOSE,
	EV_CMSS_EVENT_MAX
} EN_EV_CMSS;

typedef	struct tagCMSSENDSM_GD
{
	EN_ST_CMSS		enStatusCMSS;
	USCALEDNS		stSyncSendTime;
	PORTSYNCSYNC*	pstTxPSSyncPtr;
	TMO_MANAGE_INF_BLK*		pstTMO_SyncSendTime	;
} CMSSENDSM_GD;	




#endif


