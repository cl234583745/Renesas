/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __NGN_ASIC_CN_H_INCLUDED__
#define __NGN_ASIC_CN_H_INCLUDED__
typedef struct _ASIC_RREMACA_Bits {
	NX_ULONG	b08ZMacAddress1:						8;
	NX_ULONG	b08ZMacAddress2:						8;
	NX_ULONG	b10ZReserved1:							16;
} ASIC_RREMACA_Bits;
typedef struct _ASIC_RREIPSET_Bits {
	NX_ULONG	b01ZMode:								1;
	NX_ULONG	b01ZTimeSyncMode:						1;
	NX_ULONG	b1EZReserved1:							30;
} ASIC_RREIPSET_Bits;
typedef struct _ASIC_RRESSCMD_Bits {
	NX_ULONG	b01ZSscnetFullCompatibleFlag:			1;
	NX_ULONG	b1FZReserved1:							31;
} ASIC_RRESSCMD_Bits;
typedef struct _ASIC_RRELNSPD_Bits {
	NX_ULONG	b01ZLineSpeedPORT1:						1;
	NX_ULONG	b0FZReserved1:							15;
	NX_ULONG	b01ZLineSpeedPORT2:						1;
	NX_ULONG	b0FZReserved2:							15;
} ASIC_RRELNSPD_Bits;
typedef struct _ASIC_RREMLTCCNT_Bits {
	NX_ULONG	b01ZPort1MultiCycleFlag:				1;
	NX_ULONG	b01ZPort2MultiCycleFlag:				1;
	NX_ULONG	b1EZReserved1:							30;
} ASIC_RREMLTCCNT_Bits;
typedef struct	_ASIC_RRESTCCLR_Bits {
	NX_ULONG	b01ZCounterClear:						1;
	NX_ULONG	b1FZReserved1:							31;
} ASIC_RRESTCCLR_Bits;
typedef struct _ASIC_RRESTANO_Bits {
	NX_ULONG	b10ZMyStationNo:						16;
	NX_ULONG	b10ZReserved1:							16;
} ASIC_RRESTANO_Bits;
typedef struct _ASIC_RREIEAD_Bits {
	NX_ULONG	b10ZMacAddIEEE1588:						16;
	NX_ULONG	b10ZReserved1:							16;
} ASIC_RREIEAD_Bits;
typedef struct _ASIC_RREETYP0_Bits {
	NX_ULONG	b10ZEtherTypeOddTs:						16;
	NX_ULONG	b10ZEtherTypeEvenTs:					16;
} ASIC_RREETYP0_Bits;
typedef ASIC_RREETYP0_Bits	ASIC_RREETYP1_Bits;
typedef ASIC_RREETYP0_Bits	ASIC_RREETYP2_Bits;
typedef struct _ASIC_RREETYP3_Bits {
	NX_ULONG	b10ZEtherTypeTs:						16;
	NX_ULONG	b10ZReserved1:							16;
} ASIC_RREETYP3_Bits;
typedef ASIC_RREETYP0_Bits	ASIC_RREETYP4_Bits;
typedef ASIC_RREETYP0_Bits	ASIC_RREETYP5_Bits;
typedef ASIC_RREETYP0_Bits	ASIC_RREETYP6_Bits;
typedef ASIC_RREETYP3_Bits	ASIC_RREETYP7_Bits;
typedef struct _ASIC_RREETYPE1_Bits {
	NX_ULONG	b10ZEtherTypeCCLINKIE:					16;
	NX_ULONG	b10ZEtherTypeTimeSync:					16;
} ASIC_RREETYPE1_Bits;
typedef struct _ASIC_RREETYPE2_Bits {
	NX_ULONG	b10ZEtherTypeLLDP:						16;
	NX_ULONG	b10ZEtherTypeIP:						16;
} ASIC_RREETYPE2_Bits;
typedef struct _ASIC_RREETYPE3_Bits {
	NX_ULONG	b10ZOptiontag1:							16;
	NX_ULONG	b10ZOptiontag2:							16;
} ASIC_RREETYPE3_Bits;
typedef struct _ASIC_RREETYPE4_Bits {
	NX_ULONG	b10ZOptiontag3:							16;
	NX_ULONG	b10ZOptiontag4:							16;
} ASIC_RREETYPE4_Bits;
typedef struct _ASIC_RREFTYP1_Bits {
	NX_ULONG	b08ZFTypePriority:						8;
	NX_ULONG	b08ZFTypeDetection:						8;
	NX_ULONG	b08ZFTypeDetectionAck:					8;
	NX_ULONG	b08ZFTypeTransient:						8;
} ASIC_RREFTYP1_Bits;
typedef struct _ASIC_RREFTYP2_Bits {
	NX_ULONG	b08ZFTypeCyclicSeparation:				8;
	NX_ULONG	b08ZFTypeCyclicUnion:					8;
	NX_ULONG	b08ZFTypeCyclicDown:					8;
	NX_ULONG	b08ZFTypeCyclicUp:						8;
} ASIC_RREFTYP2_Bits;
typedef struct _ASIC_RREFTYP3_Bits {
	NX_ULONG	b08ZFTypeCapsule:						8;
	NX_ULONG	b18ZReserved1:							24;
} ASIC_RREFTYP3_Bits;
typedef struct _ASIC_RREFTYP5_Bits {
	NX_ULONG	b08ZFTypeDummy:							8;
	NX_ULONG	b18ZReserved1:							24;
} ASIC_RREFTYP5_Bits;
typedef struct _ASIC_RREFTYP6_Bits {
	NX_ULONG	b08ZFTypePersuasion:					8;
	NX_ULONG	b08ZFTypeTestData:						8;
	NX_ULONG	b08ZFTypeTestDataAck:					8;
	NX_ULONG	b08ZFTypeSetup:							8;
} ASIC_RREFTYP6_Bits;
typedef struct _ASIC_RREFTYP7_Bits {
	NX_ULONG	b08ZFTypeSetupAck:						8;
	NX_ULONG	b08ZFTypeToken:							8;
	NX_ULONG	b08ZFTypeTestData2:						8;
	NX_ULONG	b08ZFTypeTestData2Ack:					8;
} ASIC_RREFTYP7_Bits;
typedef struct _ASIC_RREFTYP8_Bits {
	NX_ULONG	b08ZFTypeTimer:							8;
	NX_ULONG	b08ZFTypeMyStatus:						8;
	NX_ULONG	b08ZFTypeCyclicDataW:					8;
	NX_ULONG	b08ZFTypeCyclicDataB:					8;
} ASIC_RREFTYP8_Bits;
typedef struct _ASIC_RREFTYP9_Bits {
	NX_ULONG	b08ZFTypeCyclicDataLY1:					8;
	NX_ULONG	b08ZFTypeCyclicDataLY2:					8;
	NX_ULONG	b08ZFTypeCyclicDataLX1:					8;
	NX_ULONG	b08ZFTypeCyclicDataLX2:					8;
} ASIC_RREFTYP9_Bits;
typedef struct _ASIC_RREFTYPA_Bits {
	NX_ULONG	b08ZFTypeCyclicRWw:						8;
	NX_ULONG	b08ZFTypeCyclicRY:						8;
	NX_ULONG	b08ZFTypeCyclicRWr:						8;
	NX_ULONG	b08ZFTypeCyclicRX:						8;
} ASIC_RREFTYPA_Bits;
typedef struct _ASIC_RREFTYPB_Bits {
	NX_ULONG	b08ZFTypeTransient1:					8;
	NX_ULONG	b08ZFTypeTransientAck:					8;
	NX_ULONG	b08ZFTypeTransient2:					8;
	NX_ULONG	b08ZFTypeParamCheck:					8;
} ASIC_RREFTYPB_Bits;
typedef struct _ASIC_RREFTYPC_Bits {
	NX_ULONG	b08ZFTypeParameter:						8;
	NX_ULONG	b08ZFTypeIPTransient:					8;
	NX_ULONG	b08ZFTypeTransientFree:					8;
	NX_ULONG	b08ZFTypeMeasure:						8;
} ASIC_RREFTYPC_Bits;
typedef struct _ASIC_RREFTYPD_Bits {
	NX_ULONG	b08ZFTypeMeasureAck:					8;
	NX_ULONG	b08ZFTypeOffset:						8;
	NX_ULONG	b08ZFTypeUpdate:						8;
	NX_ULONG	b08ZFTypeSync:							8;
} ASIC_RREFTYPD_Bits;
typedef struct _ASIC_RREFTYPE_Bits {
	NX_ULONG	b04ZFTypeSyncIEEE:						4;
	NX_ULONG	b04ZFTypeDelayReqIEEE:					4;
	NX_ULONG	b04ZFTypePdelayReqIEEE:					4;
	NX_ULONG	b04ZFTypePdelayRespIEEE:				4;
	NX_ULONG	b04ZFTypeFollowUpIEEE:					4;
	NX_ULONG	b04ZFTypeDelayRespIEEE:					4;
	NX_ULONG	b04ZFTypePdelayRespFollowUpIEEE:		4;
	NX_ULONG	b04ZReserved1:							4;
} ASIC_RREFTYPE_Bits;
typedef struct _ASIC_RREFTYPF_Bits {
	NX_ULONG	b08ZFTypeTestDataAckExt:				8;
	NX_ULONG	b08ZFTypeSetupExt:						8;
	NX_ULONG	b08ZFTypeSetupAckExt:					8;
	NX_ULONG	b08ZFTypeParameterExt:					8;
} ASIC_RREFTYPF_Bits;
typedef struct _ASIC_RREFTYPG_Bits {
	NX_ULONG	b08ZFTypeParamCheckExt:					8;
	NX_ULONG	b08ZFTypeParamCheckAckExt:				8;
	NX_ULONG	b08ZFTypeSubloop:						8;
	NX_ULONG	b08ZReserved1:							8;
} ASIC_RREFTYPG_Bits;
typedef struct _ASIC_RREGRPNO_Bits {
	NX_ULONG	b10ZGroupNo:							16;
	NX_ULONG	b10ZReserved1:							16;
} ASIC_RREGRPNO_Bits;
typedef struct _ASIC_RREGTYP_Bits {
	NX_ULONG	b10ZEtherTypeGbEterMAC:					16;
	NX_ULONG	b10ZEtherTypeGbEterMAC1:				16;
} ASIC_RREGTYP_Bits;
typedef struct _ASIC_RREHINT_Bits {
	NX_ULONG	b01ZSndHiPriorityIntReqPort1:			1;
	NX_ULONG	b01ZSndHiPriorityIntReqPort2:			1;
	NX_ULONG	b01ZRcvHiPriorityIntReq:				1;
	NX_ULONG	b01ZPriorityFramePort1:					1;
	NX_ULONG	b01ZPriorityFramePort2:					1;
	NX_ULONG	b01ZSyncHiPriorityIntReq:				1;
	NX_ULONG	b01ZESBufOvrUdrIntReqPort1:				1;
	NX_ULONG	b01ZESErrIntReqPort1:					1;
	NX_ULONG	b01ZESBufOvrUdrIntReqPort2:				1;
	NX_ULONG	b01ZESErrIntReqPort2:					1;
	NX_ULONG	b01ZESBufOvrUdrIntReqGbEPort1:			1;
	NX_ULONG	b01ZESErrIntReqGbEPort1:				1;
	NX_ULONG	b01ZESBufOvrUdrIntReqGbEPort2:			1;
	NX_ULONG	b01ZESErrIntReqGbEPort2:				1;
	NX_ULONG	b01ZGMIIMIIBufOvrUdrIntReqPortA:		1;
	NX_ULONG	b01ZGMIIMIIBufOvrUdrIntReqPortB:		1;
	NX_ULONG	b01ZGMIIMIIBufOvrUdrIntReqGbEPort1:		1;
	NX_ULONG	b01ZGMIIMIIBufOvrUdrIntReqGbEPort2:		1;
	NX_ULONG	b01ZWdtErr:								1;
	NX_ULONG	b0DZReserved1:							13;
} ASIC_RREHINT_Bits;
typedef struct _ASIC_RRELINT_Bits {
	NX_ULONG	b01ZSndLowPriorityIntReqPort1:			1;
	NX_ULONG	b01ZSndLowPriorityIntReqPort2:			1;
	NX_ULONG	b01ZRcvLowPriorityIntReq:				1;
	NX_ULONG	b01ZMDIOLowPriorityIntReq:				1;
	NX_ULONG	b01ZCycleCntSwIntReqPort1:				1;
	NX_ULONG	b01ZCycleCntCorrIntReqPort1:			1;
	NX_ULONG	b01ZCycleCntSwIntReqPort2:				1;
	NX_ULONG	b01ZCycleCntCorrIntReqPort2:			1;
	NX_ULONG	b01ZSyncLowPriorityIntReq:				1;
	NX_ULONG	b01ZReserved1:							1;
	NX_ULONG	b01ZTsIntReqPort1:						1;
	NX_ULONG	b01ZTsIntReqPort2:						1;
	NX_ULONG	b01ZPreambleIntReqPort1:				1;
	NX_ULONG	b01ZPreambleIntReqPort2:				1;
	NX_ULONG	b01ZPreambleIntReqGbEPort1:				1;
	NX_ULONG	b01ZPreambleIntReqGbEPort2:				1;
	NX_ULONG	b01ZGbEMACCngeCtrlIntReqPort1:			1;
	NX_ULONG	b01ZGbEMACCngeCtrlIntReqPort2:			1;
	NX_ULONG	b01CycleCntSwIntReq100MPort1:			1;
	NX_ULONG	b01CycleCntSwIntReq100MPort2:			1;
	NX_ULONG	b0CZReserved2:							12;
} ASIC_RRELINT_Bits;
typedef struct _ASIC_RREBERR_Bits {
	NX_ULONG	b01ZSndAXIBusErrIntReqPort1:			1;
	NX_ULONG	b01ZSndAXIBusErrIntReqPort2:			1;
	NX_ULONG	b01ZRcvAXIBusErrIntReq:					1;
	NX_ULONG	b01ZREAXIBusErrIntReq:					1;
	NX_ULONG	b1CZReserved1:							28;
} ASIC_RREBERR_Bits;
typedef struct _ASIC_RREHINTM_Bits {
	NX_ULONG	b01ZSndHiPriorityIntReqMskPort1:		1;
	NX_ULONG	b01ZSndHiPriorityIntReqMskPort2:		1;
	NX_ULONG	b01ZRcvHiPriorityIntReqMsk:				1;
	NX_ULONG	b01ZPriorityFrameIntReqMskPort1:		1;
	NX_ULONG	b01ZPriorityFrameIntReqMskPort2:		1;
	NX_ULONG	b01ZSyncHiPriorityIntReqMsk:			1;
	NX_ULONG	b01ZEsBufOvrUdrIntReqMskPort1:			1;
	NX_ULONG	b01ZEsErrIntReqMskPort1:				1;
	NX_ULONG	b01ZEsBufOvrUdrIntReqMskPort2:			1;
	NX_ULONG	b01ZEsErrIntReqMskPort2:				1;
	NX_ULONG	b01ZEsBufOvrUdrIntReqMskGbEPort1:		1;
	NX_ULONG	b01ZEsErrIntReqMskGbEPort1:				1;
	NX_ULONG	b01ZEsBufOvrUdrIntReqMskGbEPort2:		1;
	NX_ULONG	b01ZEsErrIntReqMskGbEPort2:				1;
	NX_ULONG	b01ZGmiiMiiBufOvrUdrIntReqMskPortA:		1;
	NX_ULONG	b01ZGmiiMiiBufOvrUdrIntReqMskPortB:		1;
	NX_ULONG	b01ZGmiiMiiBufOvrUdrIntReqMskGbEPort1:	1;
	NX_ULONG	b01ZGmiiMiiBufOvrUdrIntReqMskGbEPort2:	1;
	NX_ULONG	b01ZMskWdtErr:							1;
	NX_ULONG	b0DZReserved1:							13;
} ASIC_RREHINTM_Bits;
typedef struct _ASIC_RRELINTM_Bits {
	NX_ULONG	b01ZSndLowPriorityIntReqMskPort1:		1;
	NX_ULONG	b01ZSndLowPriorityIntReqMskPort2:		1;
	NX_ULONG	b01ZRcvLowPriorityIntReqMsk:			1;
	NX_ULONG	b01ZMDIOLowPriorityIntReqMsk:			1;
	NX_ULONG	b01CycleCntSwIntReqMskPort1:			1;
	NX_ULONG	b01CycleCntCorrIntReqMskPort1:			1;
	NX_ULONG	b01CycleCntSwIntReqMskPort2:			1;
	NX_ULONG	b01CycleCntCorrIntReqMskPort2:			1;
	NX_ULONG	b01ZSyncLowPriorityIntReqMsk:			1;
	NX_ULONG	b01ZReserved1:							1;
	NX_ULONG	b01ZTsIntReqMskPort1:					1;
	NX_ULONG	b01ZTsIntReqMskPort2:					1;
	NX_ULONG	b01ZPreambleIntReqMskPort1:				1;
	NX_ULONG	b01ZPreambleIntReqMskPort2:				1;
	NX_ULONG	b01ZPreambleIntReqMskGbEPort1:			1;
	NX_ULONG	b01ZPreambleIntReqMskGbEPort2:			1;
	NX_ULONG	b01ZGbEMACCngeCtrlIntReqMskPort1:		1;
	NX_ULONG	b01ZGbEMACCngeCtrlIntReqMskPort2:		1;
	NX_ULONG	b01ZCycleCntSwIntReqMsk100MPort1:		1;
	NX_ULONG	b01ZCycleCntSwIntReqMsk100MPort2:		1;
	NX_ULONG	b0CZReserved1:							12;
} ASIC_RRELINTM_Bits;
typedef struct _ASIC_RREBERRM_Bits {
	NX_ULONG	b01ZSndPort1AXIBusErrIntReqMsk:			1;
	NX_ULONG	b01ZSndPort2AXIBusErrIntReqMsk:			1;
	NX_ULONG	b01ZRcvAXIBusErrIntReqMsk:				1;
	NX_ULONG	b01ZREAXIBusErrIntReqMsk:				1;
	NX_ULONG	b1CZReserved1:							28;
} ASIC_RREBERRM_Bits;
typedef struct _NGN_CN_REG_TAG {
	union {
		NX_ULONG				DATA;
		ASIC_RREMACA_Bits	BITS;
	} R_REMACA[NGN_ASIC_MAC_ADD_MAX];
	union {
		NX_ULONG				DATA;
		ASIC_RREIPSET_Bits	BITS;
	} R_REIPSET;
	union {
		NX_ULONG				DATA;
		ASIC_RRESSCMD_Bits	BITS;
	} R_RESSCMD;
	union {
		NX_ULONG				DATA;
		ASIC_RRELNSPD_Bits	BITS;
	} R_RELNSPD;
	union {
		NX_ULONG				DATA;
		ASIC_RREMLTCCNT_Bits	BITS;
	} R_REMLTCCNT;
	union {
		NX_ULONG				DATA;
		ASIC_RRESTCCLR_Bits	BITS;
	} R_RESTCCLR;
	union {
		NX_ULONG				DATA;
		ASIC_RRESTANO_Bits	BITS;
	} R_RELUNUM;
	NX_ULONG					ulZReserved0024[(0x0030-0x0024)/4];
	union {
		NX_ULONG				DATA;
		ASIC_RREIEAD_Bits	BITS;
	} R_REIEAD[NGN_ASIC_IEEE1588_MAC_ADD_MAX];
	NX_ULONG					ulZReserved003C[(0x0040-0x003C)/4];
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP0_Bits	BITS;
	} R_REETYP0;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP1_Bits	BITS;
	} R_REETYP1;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP2_Bits	BITS;
	} R_REETYP2;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP3_Bits	BITS;
	} R_REETYP3;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP4_Bits	BITS;
	} R_REETYP4;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP5_Bits	BITS;
	} R_REETYP5;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP6_Bits	BITS;
	} R_REETYP6;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYP7_Bits	BITS;
	} R_REETYP7;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYPE1_Bits	BITS;
	} R_REETYPE1;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYPE2_Bits	BITS;
	} R_REETYPE2;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYPE3_Bits	BITS;
	} R_REETYPE3;
	union {
		NX_ULONG				DATA;
		ASIC_RREETYPE4_Bits	BITS;
	} R_REETYPE4;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP1_Bits	BITS;
	} R_REFTYP1;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP2_Bits	BITS;
	} R_REFTYP2;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP3_Bits	BITS;
	} R_REFTYP3;
	NX_ULONG					ulZReserved007C[(0x0080-0x007C)/4];
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP5_Bits	BITS;
	} R_REFTYP5;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP6_Bits	BITS;
	} R_REFTYP6;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP7_Bits	BITS;
	} R_REFTYP7;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP8_Bits	BITS;
	} R_REFTYP8;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYP9_Bits	BITS;
	} R_REFTYP9;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPA_Bits	BITS;
	} R_REFTYPA;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPB_Bits	BITS;
	} R_REFTYPB;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPC_Bits	BITS;
	} R_REFTYPC;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPD_Bits	BITS;
	} R_REFTYPD;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPE_Bits	BITS;
	} R_REFTYPE;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPF_Bits	BITS;
	} R_REFTYPF;
	union {
		NX_ULONG				DATA;
		ASIC_RREFTYPG_Bits	BITS;
	} R_REFTYPG;
	union {
		NX_ULONG				DATA;
		ASIC_RREGRPNO_Bits	BITS;
	} R_REGRPNO[NGN_ASIC_MULTICAST_ADD_GROUP_MAX];
	union {
		NX_ULONG				DATA;
		ASIC_RREGTYP_Bits	BITS;
	} R_REGTYP[NGN_ASIC_GIGA_ETHER_MAC_MAX];
	union {
		NX_ULONG				DATA;
		ASIC_RREHINT_Bits	BITS;
	} R_REHINT;
	union {
		NX_ULONG				DATA;
		ASIC_RRELINT_Bits	BITS;
	} R_RELINT;
	union {
		NX_ULONG				DATA;
		ASIC_RREBERR_Bits	BITS;
	} R_REBERR;
	NX_ULONG					ulZReserved010C;
	union {
		NX_ULONG				DATA;
		ASIC_RREHINTM_Bits	BITS;
	} R_REHINTM;
	union {
		NX_ULONG				DATA;
		ASIC_RRELINTM_Bits	BITS;
	} R_RELINTM;
	union {
		NX_ULONG				DATA;
		ASIC_RREBERRM_Bits	BITS;
	} R_REBERRM;

} NGN_CN_REG_TAG;
#endif

