/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "INIT_commonip.h"




NX_VOID vINIT_commonip_rc ( NX_VOID )
{
	
	NGN_RC_REG->R_RCRLSEL.DATA				=	(NX_ULONG)0x00000001;
	
	
	NGN_RC_REG->R_RCGBETS.DATA				=	(NX_ULONG)0x00000000;
	NGN_RC_REG->R_RCTS0POS.DATA				=	(NX_ULONG)0x00000003;
	NGN_RC_REG->R_RCDOCK.DATA				=	(NX_ULONG)0x00000001;
	
	
	NGN_RC_REG->R_RCSTBYT1[0].DATA			=	(NX_ULONG)0x001E0048;
	NGN_RC_REG->R_RCSTBYT1[1].DATA			=	(NX_ULONG)0x001E001E;
	NGN_RC_REG->R_RCSTBYT1[2].DATA			=	(NX_ULONG)0x001E001E;
	NGN_RC_REG->R_RCSTBYT1[3].DATA			=	(NX_ULONG)0x001E001E;
	
	NGN_RC_REG->R_RCSTBYT2[0].DATA			=	(NX_ULONG)0x001E0048;
	NGN_RC_REG->R_RCSTBYT2[1].DATA			=	(NX_ULONG)0x001E001E;
	NGN_RC_REG->R_RCSTBYT2[2].DATA			=	(NX_ULONG)0x001E001E;
	NGN_RC_REG->R_RCSTBYT2[3].DATA			=	(NX_ULONG)0x001E001E;
	
	
	return;
}

NX_VOID vINIT_commonip_rcrlyvl ( NX_VOID )
{
	NGN_RC_REG->R_RCRLYVL.DATA				=	(NX_ULONG)0x0000430C;
	return;
}

/*[EOF]*/
