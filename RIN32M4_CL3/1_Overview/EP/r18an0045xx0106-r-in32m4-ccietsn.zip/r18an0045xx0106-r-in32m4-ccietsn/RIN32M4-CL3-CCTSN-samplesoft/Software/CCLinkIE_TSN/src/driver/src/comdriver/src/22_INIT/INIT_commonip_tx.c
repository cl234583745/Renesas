/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "networkram.h"
#include "cyclic_address.h"
#include "ACM_api.h"


typedef struct NX_TXN_SND_BUFFADD_TAG_ {
	NX_ULONG			ulTxnHeadBuffAdd;
	NX_ULONG			ulTxnSndBuffAdd;
} NX_TXN_SND_BUFFADD;

NX_TXN_SND_BUFFADD gstTXNSndNonCyclicBuffAdd[64];

NX_VOID vINIT_TxirptInit (NX_VOID);

NX_VOID vINIT_commonip_txdisc ( NX_VOID )
{
	NX_USHORT	usSetCount;
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_ULONG	ulBaseAdr	= (NX_ULONG)NX_ZERO;
	
	for (usSetCount = 0; usSetCount < NX_DISNUM_NOCYC; usSetCount++) {
		NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.DATA = 0x00000000;
		NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu1.DATA = 0x00000000;
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis1.DATA = 0x00000000;
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis2.DATA = 0x00000000;
	}
	
	for (usSetCount = NX_DISCNO_STA_SYNC_S; usSetCount <= NX_DISCNO_END_SYNC_S; usSetCount++) {
		gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnHeadBuffAdd = (NX_ULONG)&uchTXN_NonCycSndHeadBuff_Sync_S[usSetCount - NX_DISCNO_STA_SYNC_S][0];
	}
	for (usSetCount = NX_DISCNO_STA_SYNC_L; usSetCount <= NX_DISCNO_END_SYNC_L; usSetCount++) {
		gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnHeadBuffAdd = (NX_ULONG)&uchTXN_NonCycSndHeadBuff_Sync_L[usSetCount - NX_DISCNO_STA_SYNC_L][0];
	}
	for (usSetCount = NX_DISCNO_STA_S; usSetCount <= NX_DISCNO_END_S; usSetCount++) {
		gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnHeadBuffAdd = (NX_ULONG)&uchTXN_NonCycSndHeadBuff_S[usSetCount - NX_DISCNO_STA_S][0];
	}
	for (usSetCount = NX_DISCNO_STA_L; usSetCount <= NX_DISCNO_END_L; usSetCount++) {
		gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnHeadBuffAdd = (NX_ULONG)&uchTXN_NonCycSndHeadBuff_L[usSetCount - NX_DISCNO_STA_L][0];
	}
	NGN_CN_TN1_REG->R_TNMUHD = (NX_ULONG)(NX_NETWORKADD_NOCYC_HEADER & 0x000FFFFF);
	
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		for (usSetCount = NX_DISCNO_STA_SYNC_S; usSetCount <= NX_DISCNO_END_SYNC_S; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[usSetCount - NX_DISCNO_STA_SYNC_S][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0];
		}
		for (usSetCount = NX_DISCNO_STA_SYNC_L; usSetCount <= NX_DISCNO_END_SYNC_L; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_L[usSetCount - NX_DISCNO_STA_SYNC_L][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0];
		}
		for (usSetCount = NX_DISCNO_STA_S; usSetCount <= NX_DISCNO_END_S; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_S[usSetCount - NX_DISCNO_STA_S][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0];
		}
		for (usSetCount = NX_DISCNO_STA_L; usSetCount <= NX_DISCNO_END_L; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_L[usSetCount - NX_DISCNO_STA_L][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0];
		}
		NGN_CN_TN1_REG->R_TNMUAD = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0] & 0x000FFFFF;
	}
	else {
		ulBaseAdr = TRNBUF_AHBADD_BASE_A;
		for (usSetCount = NX_DISCNO_STA_SYNC_S; usSetCount <= NX_DISCNO_END_SYNC_S; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[usSetCount - NX_DISCNO_STA_SYNC_S][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - ulBaseAdr;
		}
		for (usSetCount = NX_DISCNO_STA_SYNC_L; usSetCount <= NX_DISCNO_END_SYNC_L; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_L[usSetCount - NX_DISCNO_STA_SYNC_L][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - ulBaseAdr;
		}
		for (usSetCount = NX_DISCNO_STA_S; usSetCount <= NX_DISCNO_END_S; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_S[usSetCount - NX_DISCNO_STA_S][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - ulBaseAdr;
		}
		for (usSetCount = NX_DISCNO_STA_L; usSetCount <= NX_DISCNO_END_L; usSetCount++) {
			gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd = (NX_ULONG)&uchTXN_NonCycSndBuff_L[usSetCount - NX_DISCNO_STA_L][0];
			NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu2.BITS.b1AZSndDataAddr = gstTXNSndNonCyclicBuffAdd[usSetCount].ulTxnSndBuffAdd - ulBaseAdr;
		}
		NGN_CN_TN1_REG->R_TNMUAD =	ulBaseAdr &  (NX_ULONG)0x000FFFFF;
	}
	
	for (usSetCount = 0; usSetCount < NX_DISNUM_NOCYC; usSetCount++) {
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis1.DATA = 0;
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis2.DATA = 0;
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis1.BITS.b0BZSndDiscriptTopNo = usSetCount;
		NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu1.BITS.b0BZPayloadDiscriptNextNo = 0x00000000 + 1;
		NGN_CN_TNDIS_REG->R_TNDIS[usSetCount].ASIC_rtndis1.BITS.b01ZSndDiscriptEndFlag = 0;
		NGN_CN_TNDIS_REG->R_TNPDU[usSetCount].ASIC_rtnpdu1.BITS.b01ZPayloadDiscriptEndFlag = 1;
	}

	return;
}

NX_VOID vINIT_commonip_tx ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	NGN_CN_TN1_REG->R_TNSTOP.DATA		=	0x00000002;
	
	NGN_CN_TN1_REG->R_TNBUFFER.DATA		=	0x00000028;

	
	NGN_CN_TN1_REG->R_TNERMAKE.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNPTSEL.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNBUFCLR			=	0x00000001;
	NGN_CN_TN1_REG->R_TNBUFCLR			=	0x00000000;

	vINIT_TxirptInit();
	
	NGN_CN_TN1_REG->R_TNAUST.DATA		=	0x0000FEFE;
	
	
	NGN_CN_TN1_REG->R_TNMUST.DATA		=	0x0000FFFF;
	
	
	NGN_CN_TN1_REG->R_TNBKCTL.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNRDCNT.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNBKSTS.DATA		=	0x0000007F;
	
	NGN_CN_TN1_REG->R_TNTMSTMP			=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRMEN.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET1			=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET2.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET3.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET4			=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET5.DATA		=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET6			=	0x00000000;
	NGN_CN_TN1_REG->R_TNFRSET7			=	0x00000000;
	
	NGN_CN_TN1_REG->R_TNAD[0].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	NGN_CN_TN1_REG->R_TNAD[1].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;				
	NGN_CN_TN1_REG->R_TNAD[2].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	NGN_CN_TN1_REG->R_TNAD[3].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	NGN_CN_TN1_REG->R_TNAD[4].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	NGN_CN_TN1_REG->R_TNAD[5].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	NGN_CN_TN1_REG->R_TNAD[6].r_tnad_a		=	TRNBUF_AXIADD_BASE_A;
	
	NGN_CN_TN1_REG->R_TNAD[0].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;	
	NGN_CN_TN1_REG->R_TNAD[1].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	NGN_CN_TN1_REG->R_TNAD[2].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	NGN_CN_TN1_REG->R_TNAD[3].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	NGN_CN_TN1_REG->R_TNAD[4].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	NGN_CN_TN1_REG->R_TNAD[5].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	NGN_CN_TN1_REG->R_TNAD[6].r_tnad_b		=	TRNBUF_AXIADD_BASE_B;
	
	NGN_CN_TN1_REG->R_TNAD[0].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[1].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[2].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[3].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[4].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[5].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	NGN_CN_TN1_REG->R_TNAD[6].r_tnad_c		=	TRNBUF_AXIADD_BASE_C;
	
	NGN_CN_TN1_REG->R_TNHEAD[0]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[1]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[2]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[3]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[4]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[5]		=	AUTOTRNHEAD_AXIADDR_BASE;
	NGN_CN_TN1_REG->R_TNHEAD[6]		=	AUTOTRNHEAD_AXIADDR_BASE;
	
	NGN_CN_TN1_REG->R_TNMUHD = (NX_ULONG)(NX_NETWORKADD_NOCYC_HEADER & 0x000FFFFF);
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
		
		NGN_CN_TN1_REG->R_TNMUAD = (NX_ULONG)&uchTXN_NonCycSndBuff_Sync_S[0][0] & 0x000FFFFF;
	}
	else {
		
		NGN_CN_TN1_REG->R_TNMUAD =  (NX_ULONG)TRNBUF_AXIADD_BASE_A;
	}
	
	
	
	
	
	
	return;
}

NX_VOID vINIT_TxirptInit (NX_VOID)
{
	NX_USHORT	usClassASetting;
	NGN_CN_TN1_REG->R_TNINTH.DATA		=	0x00001FFF;
	NGN_CN_TN1_REG->R_TNINTL.DATA		=	0x00000037;



	usClassASetting = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_A == usClassASetting) {

	}
	else {
		NGN_CN_TN1_REG->R_TNINTHMSK.BITS.b01ZSndAbnormalEndMsk			= 0;

		NGN_CN_TN1_REG->R_TNINTLMSK.BITS.b01ZNonCyclicSndEndTS1_7Msk	= 0;
		NGN_CN_TN1_REG->R_TNINTLMSK.BITS.b01ZNonCyclicSndEndTS0Msk		= 0;
		NGN_CN_TN1_REG->R_TNINTLMSK.BITS.b01ZDiscriptHWMenChgEnd		= 0;
	}
	return;
}
/*[EOF]*/
