/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_CONST_EX_H_INCLUDE__
#define __CCIENX_CONST_EX_H_INCLUDE__
#include "R_IN32M4_CL3CanConst.h"


#ifndef TSN_CAN_ENABLE
#define	NX_SPLD_ADDR_NUM_RX		(1)
#define	NX_SPLD_ADDR_NUM_RY		(1)
#define	NX_SPLD_ADDR_NUM_RWR	(1)
#define	NX_SPLD_ADDR_NUM_RWW	(1)
#define	NX_SPLD_ADDR_NUM_STSW	(1)
#ifdef SAFETY_PDU_ENABLE
#define	NX_SPLD_ADDR_NUM_SPDUX	(1)
#define	NX_SPLD_ADDR_NUM_SPDUY	(1)
#endif

#else
#define	NX_SPLD_ADDR_NUM_RX		(1)
#define	NX_SPLD_ADDR_NUM_RY		(1)
#define	NX_SPLD_ADDR_NUM_RWR	(R_IN_CAN_MAX_ODTABLE_NUM)
#define	NX_SPLD_ADDR_NUM_RWW	(R_IN_CAN_MAX_ODTABLE_NUM)
#define	NX_SPLD_ADDR_NUM_STSW	(1)
#endif

#define	NX_SPLD_NUM_RX			(NX_SPLD_ADDR_NUM_RX + 1)
#define	NX_SPLD_NUM_RWR			(NX_SPLD_ADDR_NUM_RWR + 1)
#define	NX_SPLD_NUM_STSW		(NX_SPLD_ADDR_NUM_STSW + 1)
#define	NX_SPLD_NUM_RY			(NX_SPLD_ADDR_NUM_RY + 1)
#define	NX_SPLD_NUM_RWW			(NX_SPLD_ADDR_NUM_RWW+ 1)
#ifdef SAFETY_PDU_ENABLE
#define	NX_SPLD_NUM_SPDUX		(NX_SPLD_ADDR_NUM_SPDUX + 1)
#define	NX_SPLD_NUM_SPDUY		(NX_SPLD_ADDR_NUM_SPDUY + 1)
#endif

#ifdef SAFETY_PDU_ENABLE
#define NX_TRN_SPLD_NUM			(NX_SPLD_ADDR_NUM_RX + NX_SPLD_ADDR_NUM_RWR + NX_SPLD_ADDR_NUM_STSW + NX_SPLD_ADDR_NUM_SPDUX + 1)
#define NX_RCV_SPLD_NUM			(NX_SPLD_ADDR_NUM_RY + NX_SPLD_ADDR_NUM_RWW + NX_SPLD_ADDR_NUM_SPDUY + 1)
#else
#define NX_TRN_SPLD_NUM			(NX_SPLD_ADDR_NUM_RX + NX_SPLD_ADDR_NUM_RWR + NX_SPLD_ADDR_NUM_STSW + 1)
#define NX_RCV_SPLD_NUM			(NX_SPLD_ADDR_NUM_RY + NX_SPLD_ADDR_NUM_RWW + 1)
#endif

#endif
/*[EOF]*/
