/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "networkram.h"
#include "R_IN32M4_CL3Environment.h"


NONCYC_RX_DATA_P1			NX_UCHAR gauchNCycBuffPort1[NX_RXN_NCYC_BUFF_SIZE];
NONCYC_RX_DATA_P2			NX_UCHAR gauchNCycBuffPort2[NX_RXN_NCYC_BUFF_SIZE];
NONCYC_TX_HEADER_L			NX_UCHAR uchTXN_NonCycSndHeadBuff_L[NX_NCYC_TX_NUM_L][NX_TX_DISC_HEADSIZE];
NONCYC_TX_HEADER_S			NX_UCHAR uchTXN_NonCycSndHeadBuff_S[NX_NCYC_TX_NUM_S][NX_TX_DISC_HEADSIZE];
NONCYC_TX_HEADER_SYNC_L		NX_UCHAR uchTXN_NonCycSndHeadBuff_Sync_L[NX_NCYC_TX_SYNC_NUM_L][NX_TX_DISC_HEADSIZE];
NONCYC_TX_HEADER_SYNC_S		NX_UCHAR uchTXN_NonCycSndHeadBuff_Sync_S[NX_NCYC_TX_SYNC_NUM_S][NX_TX_DISC_HEADSIZE];
NONCYC_TX_DATA_L			NX_UCHAR uchTXN_NonCycSndBuff_L[NX_NCYC_TX_NUM_L][NX_NCYC_TX_FRAME_SIZE_L];
NONCYC_TX_DATA_S			NX_UCHAR uchTXN_NonCycSndBuff_S[NX_NCYC_TX_NUM_S][NX_NCYC_TX_FRAME_SIZE_S];
NONCYC_TX_DATA_SYNC_L		NX_UCHAR uchTXN_NonCycSndBuff_Sync_L[NX_NCYC_TX_SYNC_NUM_L][NX_NCYC_TX_FRAME_SIZE_L];
NONCYC_TX_DATA_SYNC_S		NX_UCHAR uchTXN_NonCycSndBuff_Sync_S[NX_NCYC_TX_SYNC_NUM_S][NX_NCYC_TX_FRAME_SIZE_S];

/*[EOF]*/
