/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_SSSYNC_1588_H__
#define __PTP_SSSYNC_1588_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif

VOID	siteSyncSync_1588(USHORT usEvent, CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


