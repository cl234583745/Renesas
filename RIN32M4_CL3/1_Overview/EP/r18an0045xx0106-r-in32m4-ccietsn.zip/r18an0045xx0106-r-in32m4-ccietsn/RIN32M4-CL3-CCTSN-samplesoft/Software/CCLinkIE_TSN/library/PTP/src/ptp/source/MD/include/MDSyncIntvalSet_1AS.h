/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCINTVALSET_1AS_H__
#define __MDSYNCINTVALSET_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID SyncIntvalSetSM_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID SyncIntvalSetSM_00_1AS(PORTDATA* pstPort);
VOID SyncIntvalSetSM_01_1AS(PORTDATA* pstPort);
VOID SyncIntvalSetSM_02_1AS(PORTDATA* pstPort);
VOID SyncIntvalSetSM_03_1AS(PORTDATA* pstPort);
VOID SyncIntvalSetSM_NP_1AS(PORTDATA* pstPort);

BOOL SyncIntSet_NotEnabled_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SyncIntSet_Initialize_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SyncIntSet_SetInterval_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
