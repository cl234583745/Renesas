/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSOFFSET_1AS_GD_H__
#define __PTP_CMSOFFSET_1AS_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_CMSO {
	ST_CMSO_NONE	= 0,
	ST_CMSO_INITIALIZING,
	ST_CMSO_SEND_SYNC_INDICATION,
	ST_CMSO_MAX
} EN_ST_CMSO;

typedef	enum	tagEN_EV_CMSO {
	EV_CMSO_BEGIN = 0,
	EV_CMSO_RCVDSYNCRECEIPTTIME,
	EV_CMSO_CLOSE,
	EV_CMSO_EVENT_MAX
} EN_EV_CMSO;

typedef	struct tagCMSOFFSETSM_1AS_GD
{
	EN_ST_CMSO			enStatusCMSO;
	BOOL				blRcvdSyncReceiptTime;
	EXTENDEDTIMESTAMP	stMasterTimeFO;
	EXTENDEDTIMESTAMP	stMasterTimeFOOld;
	EXTENDEDTIMESTAMP	stSyncReceiptTimeFO;
	EXTENDEDTIMESTAMP	stSyncReceiptTimeFOOld;
	BOOL				blCSFOffsetOld;
	DOUBLE				dbClockSourceFreqOffsetCand;
	SCALEDNS			stClockSourcePhaseOffsetCand;
	BOOL				blNoGMFlag;

} CMSOFFSETSM_1AS_GD;




#endif

