/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#include "MDSyncIntvalSet.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDSyncIntvalSet_1AS.h"
#endif


VOID SyncIntervalSettingSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET, PTP_LOGVE_82080001);
#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		SyncIntvalSetSM_1AS(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET, PTP_LOGVE_82000002);
	return;
}

SISETTINGSM_GD* GetSyncIntvSetGlobal(PORTDATA* pstPort)
{
	return &pstPort->stSISettingSM_GD;
}

SYNCINTVSET_EV GetSyncIntvSetEvent(USHORT usEvent, PORTDATA* pstPort)
{
	SYNCINTVSET_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDSYCI_E_BEGIN;
		break;
		case PTP_EV_USEMGTSETTABLELOGSYNINT_ON:
			enEvt = MDSYCI_E_USEMGTSETLOGSYNINT_ON;
		break;
		case PTP_EV_USEMGTSETTABLELOGSYNINT_OF:
			enEvt = MDSYCI_E_USEMGTSETLOGSYNINT_OF;
		break;
		case PTP_EV_RCVDSIGNALINGMSG1:
			enEvt = MDSYCI_E_RCVDSIGNALINGMSG1;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDSYCI_E_CLOSE;
		break;

		default:
			enEvt = MDSYCI_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

SYNCINTVSET_ST GetSyncIntvSetStatus(PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;
	SYNCINTVSET_ST	enSts = MDSYCI_STATUS_MAX;

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	if (pstGbl->enStsSyncIntvalSet < MDSYCI_STATUS_MAX)
	{
		enSts = pstGbl->enStsSyncIntvalSet;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetSyncIntvSetStatus(SYNCINTVSET_ST enSts, PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	pstGbl->enStsSyncIntvalSet = enSts;
	return;
}
#endif
