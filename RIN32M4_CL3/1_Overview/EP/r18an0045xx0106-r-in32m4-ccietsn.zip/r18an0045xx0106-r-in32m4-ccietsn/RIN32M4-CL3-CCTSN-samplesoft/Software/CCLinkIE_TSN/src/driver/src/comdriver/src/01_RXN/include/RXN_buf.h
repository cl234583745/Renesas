/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __RXN_BUF_H_INCLUDE__
#define __RXN_BUF_H_INCLUDE__
#include "nx_common.h"
#include "RXN_api.h"

#define	BUFFID_NCYC_RX_BUF_S		(0x0000 << 12 | 0x0000 << 8 | 0x0000)
#define	BUFFID_NCYC_RX_BUF_L		(0x0000 << 12 | 0x0001 << 8 | 0x0000)

#define	BUFFIDMASK_INDEX			((NX_USHORT)0x00FF)
#define	BUFFIDMASK_SIZE				((NX_USHORT)0x0F00)
#define	BUFFIDMASK_FRAME			((NX_USHORT)0xF000)

#define	NCYC_RX_FRAME_SIZE_S		((NX_USHORT)256)
#define	NCYC_RX_FRAME_SIZE_L		((NX_USHORT)2048)

#define	NCYC_RX_NUM_S				((NX_USHORT)32)
#define	NCYC_RX_NUM_L				((NX_USHORT)8)

#define	NCYC_RX_NUM_S_BIT			((NX_ULONG)0x00000000)
#define	NCYC_RX_NUM_L_BIT			((NX_ULONG)0xFFFFFF00)

typedef struct NCYC_RX_FRAME_S_TAG {
	T_MSG	stMsg;
	NX_USHORT	usBuffId;
	NX_USHORT	usRsv;
	NX_USHORT	usPort;
	NX_USHORT	usSize;
	NX_USHORT	usEtherOffset;
	NX_USHORT	usRsv1;
	NX_UCHAR	auchData[NCYC_RX_FRAME_SIZE_S];
} NCYC_RX_FRAME_S;

typedef struct NCYC_RX_FRAME_L_TAG {
	T_MSG	stMsg;
	NX_USHORT	usBuffId;
	NX_USHORT	usRsv;
	NX_USHORT	usPort;
	NX_USHORT	usSize;
	NX_USHORT	usEtherOffset;
	NX_USHORT	usRsv1;
	NX_UCHAR	auchData[NCYC_RX_FRAME_SIZE_L];
} NCYC_RX_FRAME_L;

typedef struct NCYC_RX_BUF_S_TAG {
	NX_ULONG				ulUsedFlg;
	NCYC_RX_FRAME_S			astFrame[NCYC_RX_NUM_S];
} NCYC_RX_BUF_S;

typedef struct NCYC_RX_BUF_L_TAG {
	NX_ULONG				ulUsedFlg;
	NCYC_RX_FRAME_L			astFrame[NCYC_RX_NUM_L];
} NCYC_RX_BUF_L;

NX_EXTERN	NCYC_RX_BUF_S			gstNonCycRxBufS;
NX_EXTERN	NCYC_RX_BUF_L			gstNonCycRxBufL;

NX_VOID vRXN_InitNonCycRxBuf(NX_VOID);
NX_ULONG ulRXN_AllocNonCycRxBuf(NX_USHORT, NCYC_RX_FRAME**);
NX_VOID vRXN_ReleaseNonCycRxBuf(NX_USHORT);
#endif
/*[EOF]*/
