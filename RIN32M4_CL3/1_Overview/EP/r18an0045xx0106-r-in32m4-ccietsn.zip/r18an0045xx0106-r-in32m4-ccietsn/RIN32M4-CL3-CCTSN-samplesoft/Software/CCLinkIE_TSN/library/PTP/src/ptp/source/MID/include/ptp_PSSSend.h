/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PSSSEND_H__
#define __PTP_PSSSEND_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	portSyncSyncSend(USHORT usEvent, PORTDATA* pstPortData);

PSSSENDSM_GD*	GetPSSSendSM_GD(PORTDATA* pstPortData);
EN_EV_PSSS		GetPSSSendSM_Event(USHORT usEvent, PORTDATA* pstPortData);
EN_EV_PSSS		GetPSSSendSM_Event_1588(USHORT usEvent, PORTDATA* pstPortData);
BOOL			IsPSSSendSM_Status(PORTDATA*	pstPortData);

#ifdef __cplusplus
}
#endif


#endif


