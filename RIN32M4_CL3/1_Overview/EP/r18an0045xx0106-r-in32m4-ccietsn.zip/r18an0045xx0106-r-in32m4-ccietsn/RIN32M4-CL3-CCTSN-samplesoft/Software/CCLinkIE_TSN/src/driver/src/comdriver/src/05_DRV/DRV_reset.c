/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "JADE.h"
#include "R_IN32M4_CL3.h"
#include "nx_mpu_common.h"

#define	SYSRST_ON				((NX_USHORT)0)
#define	SYSRST_OFF				((NX_USHORT)1)

NX_VOID vNX_CtrlSystemReset (
	NX_USHORT usResetValue
)
{
	NX_USHORT	usSet	= (NX_USHORT)NX_ZERO;

	if ((NX_USHORT)NX_RESET_ON == usResetValue) {
		usSet = SYSRST_ON;
	}
	else {
		usSet = SYSRST_OFF;
	}

	NX_SYSTEMPROTECT_UNLOCK();
	RIN_SYS->SYSRESET = usSet;
	NX_SYSTEMPROTECT_LOCK();

	return;
}




