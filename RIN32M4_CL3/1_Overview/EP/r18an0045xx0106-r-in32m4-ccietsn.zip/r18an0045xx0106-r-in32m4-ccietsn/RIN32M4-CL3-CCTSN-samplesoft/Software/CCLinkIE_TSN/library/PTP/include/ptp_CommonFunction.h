/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTP_COMMONFUNCTION_H__
#define __PTP_COMMONFUNCTION_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"



#define	CONST_1			(1)
#define	CONST10_9		((ULONG)1000000000UL)
#define	CONST10_7		((ULONG)10000000UL)
#define	CONST10_6		((ULONG)1000000UL)
#define	CONST10_3		((ULONG)1000UL)
#define	CONST10_2		((ULONG)100UL)

#define	UCHCONST_1		((UCHAR)1)
#define	USCONST_1		((USHORT)1)
#define	ULCONST_1		((ULONG)1UL)

#define	DBCONST0_0		((DOUBLE)0.0)
#define	DBCONST1_0		((DOUBLE)1.0)
#define	DBCONST2_0		((DOUBLE)2.0)
#define	DBCONST10_9		((DOUBLE)1000000000.0)
#define	DBCONST2_16		((DOUBLE)65536.0)
#define	DBCONST_USMAX	((DOUBLE)65535.0)
#define	DBCONST_SMAX	((DOUBLE)32767.0)
#define	DBCONST_SMIN	((DOUBLE)-32768.0)
#define	DBCONST2_32		((DOUBLE)4294967296.0)
#define	DBCONST2_48		((DOUBLE)281474976710656.0)
#define	DBCONST2_8		((DOUBLE)256.0)
#define	DBCONST0_5		((DOUBLE)0.5)
#define	DBCONST1_5		((DOUBLE)1.5)
#define	DBCONST_RATE_MIN	((DOUBLE)0.9)
#define	DBCONST_RATE_MAX	((DOUBLE)1.1)

#define	SCONST_12		((SHORT)12)
#define	SCONST_6		((SHORT)6)
#define	DBCONST2_31		((DOUBLE)2147483647.0)
#define	DBCONST2_31M	((DOUBLE)-2147483647.0)
#define	CONST2_31		(0x7FFFFFFF)
#define	CONST2_31M		(0x80000000)

#define	DBCONST2_M41	((DOUBLE)4.5474735088646411895751953125e-13)
#define	DBCONST2_41		((DOUBLE)2199023255552.0)

#define	PTP_EPSILON		((DOUBLE)1.26217744835362e-29)

#define	CLOCK_NUM_0	(0U)
#define	PORT_NO_0	(0)

#define		CONS_SHIFT1			(1)
#define		CONS_SHIFT8			(8)
#define		CONS_SHIFT15		(15)
#define		CONS_SHIFT16		(16)
#define		CONS_SHIFT32		(32)
#define		CONS_SHIFT41		(41)
#define		CONS_SHIFT48		(48)
#define		CONS_SHIFT64		(64)
#define		CONS_SHIFT80		(80)
#define		CONS_SHIFT96		(96)
#define		CONS_USHORT16		(16)
#define		CONS_ULONG32		(32)
#define		CONS_SMAX			((SHORT)32767)
#define		CONS_SMIN			((SHORT)-32768)
#define		MASK_7FFF			((USHORT)0x7FFFU)
#define		MASK_FFFF			((USHORT)0xFFFFU)
#define		US_MAX_FFFF			((USHORT)0xFFFFU)
#define		S_MAX_7FFF			(0x7FFF)
#define		S_MIN_8000			(0x8000)
#define		UL_MAX_FFFFFFFF		(0xFFFFFFFFUL)
#define		UL_MASK_FFFF8000	(0xFFFF8000UL)
#define		UL_MASK_FFFF0000	(0xFFFF0000UL)
#define		UL_MASK_0000FFFF	(0x0000FFFFUL)
#define		L_MAX_7FFFFFFF		(0x7FFFFFFFUL)
#define		L_MIN_80000000		(0x80000000)
#define		UL_DIVMIN_10000		(0x00010000UL)


#define		GPOS_USNS_00		((USHORT)0)
#define		GPOS_USNS_16		((USHORT)16)
#define		GPOS_USNS_48		((USHORT)48)
#define		GPOS_USNS_80		((USHORT)80)




#define	SET_USCALEDNS(stUSNs, usm, ul2, ul1, usf)	{	\
	(stUSNs).usNsec_msb = (usm);		\
	(stUSNs).ulNsec_2nd = (ul2); 	\
	(stUSNs).ulNsec_lsb = (ul1); 	\
	(stUSNs).usFrcNsec = (usf);		\
}


#define	SET_SCALEDNS(stSNs, sm, ul2, ul1, usf)	{	\
	(stSNs).sNsec_msb = (sm);		\
	(stSNs).ulNsec_2nd = (ul2); 	\
	(stSNs).ulNsec_lsb = (ul1); 	\
	(stSNs).usFrcNsec = (usf);		\
}

#define	SET_TIMESTAMP(stTS, usm, ull, uln)	{	\
	(stTS).stSeconds.usSec_msb = (usm);			\
	(stTS).stSeconds.ulSec_lsb = (ull);			\
	(stTS).ulNanoseconds = (uln);		\
}

	
#define	SET_ETIMESTAMP(stETS, usm, ull, uln, usf)	{	\
	(stETS).stSec.usSec_msb = (usm);		\
	(stETS).stSec.ulSec_lsb = (ull);		\
	(stETS).stNsec.ulNsec = (uln);		 	\
	(stETS).stNsec.usFrcNsec = (usf);	 	\
}


#define	SET_TIME_INTERVAL(stTI, sm, ull, usf)	{	\
	(stTI).sNsec_msb	= (sm);	\
	(stTI).ulNsec_lsb	= (ull);	\
	(stTI).usFrcNsec	= (usf);	\
}



#define	PTP_ADDUS_US(usAA, usBB, ulCC)	{	\
	(ulCC) = (ULONG)((ULONG)(usAA) + (ULONG)(usBB));	\
}


#define	PTP_MULTUS_US(usAA, usBB, ulCC)	{	\
	(ulCC) = (ULONG)((ULONG)usAA * (ULONG)usBB);	\
}


#define	PTP_DIVUL_US(ulAA, usBB, ulCC, usDD, blR)	{	\
	if (usBB == 0)										\
	{													\
		blR = FALSE;									\
	}													\
	else												\
	{													\
		(ulCC) = (ulAA) / (ULONG)(usBB);				\
		(usDD) = (USHORT)((ulAA) % (ULONG)(usBB));		\
		blR = TRUE;										\
	}													\
}




#define	PTP_CONVUSNS_TINT(stUS, stTI, blR)	{			\
	if ((stUS).usNsec_msb == 0 &&						\
		(stUS).ulNsec_2nd <= S_MAX_7FFF)				\
	{													\
		(stTI).sNsec_msb	= (SHORT)((stUS).ulNsec_2nd);	\
		(stTI).ulNsec_lsb	= (stUS).ulNsec_lsb;		\
		(stTI).usFrcNsec	= (stUS).usFrcNsec;			\
		blR = TRUE;										\
	}													\
	else												\
	{													\
		blR = FALSE;									\
	}													\
}




#define	IS_PORTOK(pstPD)	(	\
					(pstPD->stPort_GD.blPortOper) && 			\
					(pstPD->stPort_1AS_DS.blPtpPortEnabled) &&	\
					(pstPD->stPort_1AS_DS.blAsCapable)			\
)


#define	IS_SCALEDNS_0(stS)	(	\
	((stS).sNsec_msb  == 0) &&	\
	((stS).ulNsec_2nd == 0) &&	\
	((stS).ulNsec_lsb == 0) &&	\
	((stS).usFrcNsec  == 0)		\
)




#define	IS_USCALEDNS_0(stUS)	(	\
	((stUS).usNsec_msb == 0) &&	\
	((stUS).ulNsec_2nd == 0) &&	\
	((stUS).ulNsec_lsb == 0) &&	\
	((stUS).usFrcNsec  == 0)		\
)




#define	IS_TIMESTAMP_0(stTS)	(	\
	((stTS).stSeconds.usSec_msb == 0) &&	\
	((stTS).stSeconds.ulSec_lsb == 0) &&	\
	((stTS).ulNanoseconds		== 0)		\
)




#define	IS_EPSILON0_0(dbEps)	(	\
	((dbEps) < PTP_EPSILON) &&		\
	((dbEps) > -PTP_EPSILON)		\
)




#define	IS_OD_BC_1588(pstCD)	(	\
	(pstCD->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 == ENUM_CSTYPE_ORDINARYCLOCK_1588) || 	\
	(pstCD->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 == ENUM_CSTYPE_BOUNDARYCLOCK_1588)		\
)







BOOL	ptpAddUL_UL(ULONG ulA, ULONG ulB, ULONG* pulC_msb, ULONG* pulC_lsb);

BOOL	ptpMultUL_UL(ULONG ulA, ULONG ulB, ULONG* pulC_msb, ULONG* pulC_lsb);

BOOL	ptp2sComplementSNs(SCALEDNS*	pstA_SNs, SCALEDNS*	pstB_SNs);

BOOL	ptp2sComplementUSNs(USCALEDNS*	pstA_USNs, USCALEDNS*	pstB_USNs, LONG*	pl4);

BOOL	ptpDivSec48_UL(SEC48* pstA_Sec48, ULONG ulB, ULONG* pulC_Div, ULONG* pulC_Mod);

BOOL	setDbToUSNs(
		DOUBLE		dbDouble,
		USHORT		usGPos,
		USCALEDNS*	pstAnsUScaledNs);

BOOL	setDbToSNs(
		DOUBLE		dbDouble,
		USHORT		usGPos,

		SCALEDNS*	pstAnsScaledNs);

BOOL	setDbToTInt(
		DOUBLE		dbDouble,
		USHORT		usGPos,
		TIME_INTERVAL*	pstAnsTime_Interval);



BOOL	ptpConvETS_USNs(
	EXTENDEDTIMESTAMP*	pstETimestamp,
	USCALEDNS*			pstUScaledNs	);

BOOL	ptpConvUSNs_ETS(
	USCALEDNS*			pstUScaledNs,
	EXTENDEDTIMESTAMP*	pstETimestamp);

BOOL	ptpConvETS_TS(
	EXTENDEDTIMESTAMP*	pstETimestamp,
	TIMESTAMP*			pstTimestamp	);


BOOL	ptpConvTS_USNs(
	TIMESTAMP*	pstTimestamp,
	USCALEDNS*	pstUScaledNs	);

BOOL	ptpConvUSNs_TS(
	USCALEDNS*	pstUScaledNs,
	TIMESTAMP*	pstTimestamp);

BOOL	ptpConvUSNs_SNs(
	USCALEDNS*	pstA_UScaledNs,
	SCALEDNS*	pstB_ScaledNs);

BOOL	ptpConvSNs_USNs( 
	SCALEDNS*	pstA_ScaledNs,
	USCALEDNS*	pstB_UScaledNs);

BOOL	ptpConvSNs_Dbl(
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE*				pdbAnsDouble);

BOOL	ptpConvSNs_TInt(
	SCALEDNS*		pstA_ScaledNs,
	TIME_INTERVAL*	pstB_Time_Interval);



BOOL	ptpAddETS_USNs(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddETS_SNs(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddETS_TInt(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIME_INTERVAL*		pstB_Time_Interval,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddTS_USNs(
	TIMESTAMP*			pstA_Timestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddTS_SNs(
	TIMESTAMP*			pstA_Timestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddTS_TInt(
	TIMESTAMP*			pstA_Timestamp,
	TIME_INTERVAL*		pstB_Time_Interval,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpAddUSNs_USNs(
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpAddUSNs_SNs(
	USCALEDNS*			pstA_UScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpAddUSNs_TInt(
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpAddSNs_SNs(
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpAddTInt_USNs(
	TIME_INTERVAL*		pstA_Time_Interval,
	USCALEDNS*			pstB_UScaledNs,
	TIME_INTERVAL*		pstAnsTime_Interval);


BOOL	ptpAddTInt_SNs(
	TIME_INTERVAL*		pstA_Time_Interval,
	SCALEDNS*			pstB_ScaledNs,
	TIME_INTERVAL*		pstAnsTime_Interval);


BOOL	ptpAddTInt_TInt(
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubETS_USNs(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpSubETS_USNs_SNs(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubETS_SNs(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp);


BOOL	ptpSubETS_ETS(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	EXTENDEDTIMESTAMP*	pstB_ETimestamp,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubETS_TS(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIMESTAMP*			pstB_Timestamp,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubTS_TS(
	TIMESTAMP*			pstA_Timestamp,
	TIMESTAMP*			pstB_Timestamp,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubUSNs_USNs(
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubSNs_SNs(
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubSNs_TInt(
	SCALEDNS*			pstA_ScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpSubTInt_TInt(
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval,
	TIME_INTERVAL*		pstAnsTime_Interval);





BOOL	ptpMultUSNs_ULONG(
	USCALEDNS*			pstA_UScaledNs,
	ULONG				ulB_Long,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpMultUSNs_Doub(
	USCALEDNS*			pstA_UScaledNs,
	DOUBLE				dbB_Double,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpMultSNs_Doub(
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE				dbB_Double,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpMultTInt_Doub(
	TIME_INTERVAL*		pstA_Time_Interval,
	DOUBLE				dbB_Double,
	TIME_INTERVAL*		pstAnsTime_Interval);


BOOL	ptpShiftUSNs_CHAR(
	USCALEDNS*			pstA_UScaledNs,
	CHAR				chB_Shift,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpShiftSNs_CHAR(
	SCALEDNS*			pstA_ScaledNs,
	CHAR				chB_Shift,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpDivUSNs_Doub(
	USCALEDNS*			pstA_UScaledNs,
	DOUBLE				dbB_Double,
	USCALEDNS*			pstAnsUScaledNs);


BOOL	ptpDivSNs_Doub(
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE				dbB_Double,
	SCALEDNS*			pstAnsScaledNs);


BOOL	ptpDivTInt_Doub(
	TIME_INTERVAL*		pstA_Time_Interval,
	DOUBLE				dbB_Double,
	TIME_INTERVAL*		pstAnsTime_Interval);


BOOL	ptpDivSNs_SNs(
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	DOUBLE*				pdbAnsDouble);



 
#define		COMP_A_GREAT	((CHAR)1)
#define		COMP_EQUAL		((CHAR)0)
#define		COMP_A_LESS		((CHAR)-1)

CHAR	ptpCompETS_ETS(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	EXTENDEDTIMESTAMP*	pstB_ETimestamp);


CHAR	ptpCompETS_TS(
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIMESTAMP*			pstB_Timestamp);


CHAR	ptpCompTS_TS(
	TIMESTAMP*			pstA_Timestamp,
	TIMESTAMP*			pstB_Timestamp);


CHAR	ptpCompUSNs_USNs(
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs);


CHAR	ptpCompUSNs_SNs(
	USCALEDNS*			pstA_UScaledNs,
	SCALEDNS*			pstB_ScaledNs);


CHAR	ptpCompUSNs_TInt(
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval);


CHAR	ptpCompSNs_SNs(
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs);


CHAR	ptpCompSNs_TInt(
	SCALEDNS*			pstA_ScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval);


CHAR	ptpCompTInt_TInt(
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval);


#define PTP_SET_BITS(p, low, high, val) ( *(p) = (*(p) & (~(((1<<((high)-(low)+1))-1)<<(low)))) | ((val) << (low)) )
#define PTP_GET_BITS(p, low, high)      ( (*(p) >> (low)) & ((1<<((high)-(low)+1))-1) )


#endif
