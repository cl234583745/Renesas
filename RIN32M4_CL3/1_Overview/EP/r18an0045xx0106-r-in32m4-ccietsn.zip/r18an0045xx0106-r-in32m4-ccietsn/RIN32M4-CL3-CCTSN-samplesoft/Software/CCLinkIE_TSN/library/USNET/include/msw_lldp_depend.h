//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _MSW_LLDP_DEPEND_H_
#define _MSW_LLDP_DEPEND_H_


#define MSW_NSTACK_USNET        0
#define MSW_NSTACK_LINUX        1

#define MSW_NSTACK              MSW_NSTACK_USNET

#define MSW_RTOS_NONE           0
#define MSW_RTOS_TT3            1
#define MSW_RTOS_LINUX          2

#define MSW_RTOS                MSW_RTOS_TT3



#if NTRACE > 0
#define  MSW_LOG
#endif
#if (MSW_NSTACK == MSW_NSTACK_USNET)
unsigned short  htons(unsigned short);
#define ntohs(val) htons(val)
unsigned long   htonl(unsigned long);
#define ntohl(val) htonl(val)
#else
#include <arpa/inet.h>
#endif

#ifdef MSW_LOG
extern long msw_lldp_log;
#define LLDP_LOG_FLG_OFF        0x00000000
#define LLDP_LOG_FLG_ERR        0x00000001
#define LLDP_LOG_FLG_INF        0x00000002
#define LLDP_LOG_FLG_TRC        0x00000004
#define LLDP_LOG_FLG_DBG        0x00000008
#define LLDPD_LOG_FLG_ERR       0x00000010
#define LLDPD_LOG_FLG_INF       0x00000020
#define LLDPD_LOG_FLG_TRC       0x00000040
#define LLDPD_LOG_FLG_DBG       0x00000080
#define LLDPMIB_LOG_FLG_ERR     0x00000100
#define LLDPMIB_LOG_FLG_INF     0x00000200
#define LLDPMIB_LOG_FLG_TRC     0x00000400
#define LLDPMIB_LOG_FLG_DBG     0x00000800
#define LLDP_LOG_FLG_DMP        0x10000000
#define LLDPD_LOG_FLG_DMP       0x20000000
#define LLDPMIB_LOG_FLG_DMP     0x40000000
#define LLDP_LOG_FLG_ALL        0xffffffff

#if (MSW_NSTACK == MSW_NSTACK_USNET)
int Nsprintf(char *buffer, char *format,...);
int Nprintf(char *format,...);
#define LLDP_PRINTF    Nprintf
#define LLDP_SPRINTF   Nsprintf
#else
#define LLDP_PRINTF    printf
#define LLDP_SPRINTF   sprintf
#endif
#define LLDP_LOG_ERR(x) \
    {if (msw_lldp_log & LLDP_LOG_FLG_ERR) LLDP_PRINTF x;}
#define LLDP_LOG_INF(x) \
    {if (msw_lldp_log & LLDP_LOG_FLG_INF) LLDP_PRINTF x;}
#define LLDP_LOG_TRC(x) \
    {if (msw_lldp_log & LLDP_LOG_FLG_TRC) LLDP_PRINTF x;}
#define LLDP_LOG_DBG(x) \
    {if (msw_lldp_log & LLDP_LOG_FLG_DBG) LLDP_PRINTF x;}
#define LLDP_LOG_DMP(x, y) \
    {if (msw_lldp_log & LLDP_LOG_FLG_DMP) mswLldpDump(x, y);}
#define LLDPD_LOG_ERR(x) \
    {if (msw_lldp_log & LLDPD_LOG_FLG_ERR) LLDP_PRINTF x;}
#define LLDPD_LOG_INF(x) \
    {if (msw_lldp_log & LLDPD_LOG_FLG_INF) LLDP_PRINTF x;}
#define LLDPD_LOG_TRC(x) \
    {if (msw_lldp_log & LLDPD_LOG_FLG_TRC) LLDP_PRINTF x;}
#define LLDPD_LOG_DBG(x) \
    {if (msw_lldp_log & LLDPD_LOG_FLG_DBG) LLDP_PRINTF x;}
#define LLDPD_LOG_DMP(x, y) \
    {if (msw_lldp_log & LLDPD_LOG_FLG_DMP) mswLldpDump(x, y);}
#define LLDPMIB_LOG_ERR(x) \
    {if (msw_lldp_log & LLDPMIB_LOG_FLG_ERR) LLDP_PRINTF x;}
#define LLDPMIB_LOG_INF(x) \
    {if (msw_lldp_log & LLDPMIB_LOG_FLG_INF) LLDP_PRINTF x;}
#define LLDPMIB_LOG_TRC(x) \
    {if (msw_lldp_log & LLDPMIB_LOG_FLG_TRC) LLDP_PRINTF x;}
#define LLDPMIB_LOG_DBG(x) \
    {if (msw_lldp_log & LLDPMIB_LOG_FLG_DBG) LLDP_PRINTF x;}
#define LLDPMIB_LOG_DMP(x, y) \
    {if (msw_lldp_log & LLDPMIB_LOG_FLG_DMP) mswLldpDump(x, y);}
#else
#define LLDP_LOG_ERR(x)
#define LLDP_LOG_INF(x)
#define LLDP_LOG_TRC(x)
#define LLDP_LOG_DBG(x)
#define LLDP_LOG_DMP(x, y)
#define LLDPD_LOG_ERR(x)
#define LLDPD_LOG_INF(x)
#define LLDPD_LOG_TRC(x)
#define LLDPD_LOG_DBG(x)
#define LLDPD_LOG_DMP(x, y)
#define LLDPMIB_LOG_ERR(x)
#define LLDPMIB_LOG_INF(x)
#define LLDPMIB_LOG_TRC(x)
#define LLDPMIB_LOG_DBG(x)
#define LLDPMIB_LOG_DMP(x, y)
#endif

#endif
