/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PORTANNOUNCEINFORMEXTGD_H__
#define __PORTANNOUNCEINFORMEXTGD_H__
#include <ptp_type.h>
#include <ptp_bmca.h>


typedef	enum tagPAIEXTSM_ST
{
	PIEXSM_NONE = 0,
	PIEXSM_INITIALIZE,
	PIEXSM_RECEIVE,
	PIEXSM_STATUS_MAX
} PAIEXTSM_ST;
#define	PAIEXTSM_ST_MAX	3

typedef enum tagPAIEXTSM_EV {
	PIEX_EV_BEGIN = 0,
	PIEX_EV_RCVDANNOUNCE,
	PIEX_EV_CLOSE,
	PIEX_EV_ASCAPABLE,
	PIEX_EV_EVENT_MAX
} PAIEXTSM_EV;
#define	PAIEXTSM_EV_MAX	4

typedef struct tagPAIEXTSM_GD
{
	BOOL			blRcvdAnnounce;
	PAIEXTSM_ST		enStatus;
	PRIORITY_VECT	stMessagePriority;
	ENUM_PORTSTATE	enPortStateInd;
} PAIEXTSM_GD;

#endif
