/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYREQ_H__
#define __MDPDELAYREQ_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_LCEntity.h"
#include "ptp_LogRecord.h"


#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDPdelayReq(USHORT usEvent, PORTDATA* pstPort);

MDPREQSM_GD*	GetMDPdelayReqGlobal(PORTDATA* pstPort);
MDPDELAYREQ_EV	GetMDPdelayReqEvent(USHORT usEvent, PORTDATA* pstPort);
MDPDELAYREQ_ST	GetMDPdelayReqStatus(PORTDATA* pstPort);
VOID			SetMDPdelayReqStatus(MDPDELAYREQ_ST enSts, PORTDATA* pstPort);


VOID	IncMDPDlyReqRxPDlyRespCount(CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs);
VOID	IncMDPDlyReqRxPDRpFollowUpCount(CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs);
VOID	IncMDPDlyReqRxPTPPcktDscrdCount(CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs);
VOID	IncMDPDlyReqTxPDlyReqCount(CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs);
VOID	IncMDPDlyReqLostRespExcdCount(CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs);


BOOL	MDPdelayTimeStart(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL	MDPdelayTimeStop( MDPREQSM_GD*      pstSmGbl, 
						  PORTDATA*         pstPort, 
						  CMLDSPORT_1AS_DS* pstCmldsPortDs );
VOID	MDPdelayTimeClear(PORTDATA* pstPort);

BOOL	SetMDPdlyReqEvEgresTimestamp(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL	SetMDPdlyRespEvIngresTimestamp(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID	SetMDPdelayTimestampInfo(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
