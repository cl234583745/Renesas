/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "networkram.h"
#include "cyclic_address.h"



NX_VOID vINIT_RxirptInit (NX_VOID);


NX_VOID vINIT_commonip_rx ( NX_VOID )
{
	vINIT_RxirptInit();
	NGN_RN->R_RNBKSEL.DATA	=	0x00000000;
	
	NGN_RN->ulR_RNCBADA	=	RCVBUF_AXIADD_BASE_A;
	NGN_RN->ulR_RNCBADB	=	RCVBUF_AXIADD_BASE_B;
	NGN_RN->ulR_RNCBADC	=	RCVBUF_AXIADD_BASE_C;
	
	NGN_RN->ulR_RNCSIZ0		=	NX_RXN_CYC_BUFF_AREA_SIZE;
	NGN_RN->ulR_RNCSIZ1		=	0;
	NGN_RN->ulR_RNCSIZ2		=	0;
	
	NGN_RN->R_RNCBKHMD.DATA		=	0x000000AA;
	
	NGN_RN->R_RNCBKPRD0.DATA	=	0x00000000;
	
	NGN_RN->astR_RNFLGAD[0].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[1].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[2].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[3].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[4].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[5].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[6].DATA[0]	=	0x00000000;
	NGN_RN->astR_RNFLGAD[7].DATA[0]	=	0x00000000;
	
	NGN_RN->ulR_RNCALVECNT		=	0x00000001;
	NGN_RN->aulR_RNCALVESTS[0]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[1]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[2]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[3]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[4]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[5]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[6]	=	0xFFFFFFFF;
	NGN_RN->aulR_RNCALVESTS[7]	=	0xFFFFFFFF;
	NGN_RN->ulR_RNCALV2ESTS		=	0x000000FF;
	NGN_RN->R_RNCA2SS.DATA		=	0x00000000;
	NGN_RN->R_RNCALV2CTRL		=	0x00000001;
	NGN_RN->R_RNFLGCLR			=	0x00001FFF;
	NGN_RN->R_RNAPERCLR			=	0x0000003F;
	
	
	NGN_RN->R_RNCCTRL.DATA		=	0x0000000F;
	
	NGN_RN_NCyc->astNCycPortDatas[0].ulR_RNNBAD		=	(NX_ULONG)&gauchNCycBuffPort1[0] & 0x000FFFFF;
	NGN_RN_NCyc->astNCycPortDatas[0].ulR_RNNEAD		=	(NX_ULONG)&gauchNCycBuffPort1[NX_RXN_NCYC_BUFF_SIZE - 1] & 0x000FFFFF;
	NGN_RN_NCyc->astNCycPortDatas[0].ulR_RNNMBAD	=	(NX_ULONG)&gauchNCycBuffPort1[0];
	NGN_RN_NCyc->astNCycPortDatas[0].R_RNRDPCLR.DATA	=	0x00000003;
	NGN_RN_NCyc->astNCycPortDatas[0].R_RNRDPCLR.DATA	=	0x00000000;
	
	NGN_RN_NCyc->astNCycPortDatas[1].ulR_RNNBAD		=	(NX_ULONG)&gauchNCycBuffPort2[0] & 0x000FFFFF;
	NGN_RN_NCyc->astNCycPortDatas[1].ulR_RNNEAD		=	(NX_ULONG)&gauchNCycBuffPort2[NX_RXN_NCYC_BUFF_SIZE - 1] & 0x000FFFFF;
	NGN_RN_NCyc->astNCycPortDatas[1].ulR_RNNMBAD	=	(NX_ULONG)&gauchNCycBuffPort2[0];
	NGN_RN_NCyc->astNCycPortDatas[1].R_RNRDPCLR.DATA	=	0x00000003;
	NGN_RN_NCyc->astNCycPortDatas[1].R_RNRDPCLR.DATA	=	0x00000000;
	
	
	NGN_RN_Alive->ulCycAlive2A	=	0x000000FF;
	NGN_RN_Alive->ulCycAlive2B	=	0x000000FF;
	NGN_RN_Alive->ulCycAlive2C	=	0x000000FF;
	NGN_RN_CTJT->ulR_RNCTJTCLR	=	0x000000FF;
	NGN_RN_CycRcvFlg->ulCycRcvFlg2A	=	0x000000FF;
	NGN_RN_CycRcvFlg->ulCycRcvFlg2B	=	0x000000FF;
	NGN_RN_CycRcvFlg->ulCycRcvFlg2C	=	0x000000FF;
	
	
	
	NGN_RN_APLERR->R_RNAPERF2[0].DATA	=	0xFFFFFFFF;
	NGN_RN_APLERR->R_RNAPERF2[1].DATA	=	0xFFFFFFFF;
	
	NGN_RN_APLERR->R_RNTMGERR2			=	0x000000FF;
	
	NGN_RN_APLERR->R_RNCNERF2			=	0x000000FF;
	
	NGN_RN->R_RNTBLSW					=	0x00000001;
	
	NGN_RN_NCyc->astNCycPortDatas[0].R_RNDISEN.DATA	=	0x00000001;
	NGN_RN_NCyc->astNCycPortDatas[1].R_RNDISEN.DATA	=	0x00000001;
	NGN_RN->R_RNCTRL.DATA	=	0x0000000C;
	
	return;
}

NX_VOID vINIT_RxirptInit (NX_VOID)
{
	NGN_RN->R_RNINTE.DATA	=	0x79FFFFFF;
	NGN_RN->R_RNINT.DATA	=	0x001FFF37;
	





	return;
}
/*[EOF]*/
