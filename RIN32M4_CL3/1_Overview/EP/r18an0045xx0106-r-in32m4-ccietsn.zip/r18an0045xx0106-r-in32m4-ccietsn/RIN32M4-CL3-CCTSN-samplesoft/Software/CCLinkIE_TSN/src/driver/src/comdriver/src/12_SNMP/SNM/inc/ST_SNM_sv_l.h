/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNM_SV_L_H_INCLUDED__
#define __ST_SNM_SV_L_H_INCLUDED__

#ifdef SWPS
#include <winsock2.h>
#include <snmp.h>
#endif





#ifdef SWPS
extern INT nST_SNM_CalcEncodeGetResponseLen(
	const SnmpVarBind* pVarBind,
	NX_ULONG uiNumberOfVarBind,
	NX_ULONG* puiSize);
#endif
#ifdef SWPS
#else
NX_ULONG ulST_SNM_Start(NX_VOID);
NX_ULONG ulST_SNM_Stop(NX_VOID);
#endif

#endif
