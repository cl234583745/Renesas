/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __NGN_ASIC_AXI_H_INCLUDED__
#define __NGN_ASIC_AXI_H_INCLUDED__
#define		NX_ASIC_RMDCMD_RW_WRITE					(NX_ULONG)0x0
#define		NX_ASIC_RMDCMD_RW_READ					(NX_ULONG)0x1
#define		NX_ASIC_RMDCMD_MDIOCMD_W_DC				(NX_ULONG)0x0
#define		NX_ASIC_RMDCMD_MDIOCMD_W_RUN			(NX_ULONG)0x1
#define		NX_ASIC_RMDCMD_MDIOCMD_R_STOP			(NX_ULONG)0x0
#define		NX_ASIC_RMDCMD_MDIOCMD_R_RUN			(NX_ULONG)0x1
#define		NX_ASIC_RMDCLKSET_CLCK0					(NX_ULONG)0x0
#define		NX_ASIC_RMDCLKSET_CLCK1					(NX_ULONG)0x1
#define		NX_ASIC_RMDCLKSET_CLCK2					(NX_ULONG)0x2
typedef struct _ASIC_RRGELFERR_Bits {
	NX_ULONG	b01ZARIDErr:							1;
	NX_ULONG	b01ZARLENErr:							1;
	NX_ULONG	b01ZARSIZEErr:							1;
	NX_ULONG	b01ZARADDRErr:							1;
	NX_ULONG	b01ZAWIDErr:							1;
	NX_ULONG	b01ZAWLENErr:							1;
	NX_ULONG	b01ZAWSIZEErr:							1;
	NX_ULONG	b01ZAWADDRErr:							1;
	NX_ULONG	b01ZWIDErr:								1;
	NX_ULONG	b01ZWriteDataTrnsLngthErr:				1;
	NX_ULONG	b01ZReserved1:							1;
	NX_ULONG	b01ZReserved2:							1;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b01ZReserved4:							1;
	NX_ULONG	b01ZReserved5:							1;
	NX_ULONG	b01ZReserved6:							1;
	NX_ULONG	b01ZReserved7:							1;
	NX_ULONG	b01ZReserved8:							1;
	NX_ULONG	b0EZReserved9:							14;
} ASIC_RRGELFERR_Bits;
typedef struct _ASIC_RRGELAERR_Bits {
	NX_ULONG	b01ZARIDErr:							1;
	NX_ULONG	b01ZARLENErr:							1;
	NX_ULONG	b01ZARSIZEErr:							1;
	NX_ULONG	b01ZARADDRErr:							1;
	NX_ULONG	b01ZAWIDErr:							1;
	NX_ULONG	b01ZAWLENErr:							1;
	NX_ULONG	b01ZAWSIZEErr:							1;
	NX_ULONG	b01ZAWADDRErr:							1;
	NX_ULONG	b01ZWIDErr:								1;
	NX_ULONG	b01ZWriteDataTrnsLngthErr:				1;
	NX_ULONG	b01ZReserved1:							1;
	NX_ULONG	b01ZReserved2:							1;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b01ZReserved4:							1;
	NX_ULONG	b01ZReserved5:							1;
	NX_ULONG	b01ZReserved6:							1;
	NX_ULONG	b01ZReserved7:							1;
	NX_ULONG	b01ZReserved8:							1;
	NX_ULONG	b0EZReserved9:							14;
} ASIC_RRGELAERR_Bits;
typedef struct _ASIC_RRGERMSK_Bits {
	NX_ULONG	b03ZReserved1:							3;
	NX_ULONG	b01ZARADDRErr:							1;
	NX_ULONG	b03ZReserved2:							3;
	NX_ULONG	b01ZAWADDRErr:							1;
	NX_ULONG	b07ZReserved3:							7;
	NX_ULONG	b01ZRdTmout:							1;
	NX_ULONG	b01ZWrtTmout:							1;
	NX_ULONG	b09ZReserved4:							9;
	NX_ULONG	b01ZRdTgtErrAnsMsk:						1;
	NX_ULONG	b01ZWrtTgtErrAnsMsk:					1;
	NX_ULONG	b04ZReserved5:							4;
} ASIC_RRGERMSK_Bits;
typedef struct _ASIC_RRGEIMSK_Bits {
	NX_ULONG	b01ZARIDErr:							1;
	NX_ULONG	b01ZARLENErr:							1;
	NX_ULONG	b01ZARSIZEErr:							1;
	NX_ULONG	b01ZARADDRErr:							1;
	NX_ULONG	b01ZAWIDErr:							1;
	NX_ULONG	b01ZAWLENErr:							1;
	NX_ULONG	b01ZAWSIZEErr:							1;
	NX_ULONG	b01ZAWADDRErr:							1;
	NX_ULONG	b01ZWIDErr:								1;
	NX_ULONG	b01ZWriteDataTrnsLngthErr:				1;
	NX_ULONG	b01ZReserved1:							1;
	NX_ULONG	b01ZReserved2:							1;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b01ZReserved4:							1;
	NX_ULONG	b01ZReserved5:							1;
	NX_ULONG	b01ZReserved6:							1;
	NX_ULONG	b01ZReserved7:							1;
	NX_ULONG	b01ZSlvErrResp:							1;
	NX_ULONG	b0EZReserved8:							14;
} ASIC_RRGEIMSK_Bits;
typedef struct _ASIC_RRGEMSKC_Bits {
	NX_ULONG	b01ZAcsSrc_Req:							1;
	NX_ULONG	b0FZReserved1:							15;
	NX_ULONG	b01ZAcsSrc_Ans:							1;
	NX_ULONG	b0FZReserved2:							15;
} ASIC_RRGEMSKC_Bits;
typedef struct _ASIC_RRGMOD_Bits {
	NX_ULONG	b01ZWrtDatQueTxStrTim:					1;
	NX_ULONG	b01ZRdDatQueTxStrTim:					1;
	NX_ULONG	b02ZReserved1:							2;
	NX_ULONG	b01ZReserved2:							1;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b0EZReserved4:							14;
	NX_ULONG	b01ZRdBypFncEnb:						1;
	NX_ULONG	b01ZRdPasFncEnb:						1;
	NX_ULONG	b01ZRdPriFncEnb:						1;
	NX_ULONG	b01ZReserved5:							1;
	NX_ULONG	b01ZReserved6:							1;
	NX_ULONG	b07ZReserved7:							7;
} ASIC_RRGMOD_Bits;
typedef struct _ASIC_RRGEXLASRCMD_Bits {
	NX_ULONG	b0CZReserved1:							12;
	NX_ULONG	b02ZRdOutAdrBrstTyp:					2;
	NX_ULONG	b02ZReserved2:							2;
	NX_ULONG	b03ZRdOutAdrDatSize:					3;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b04ZRdOutAdrBrstLen:					4;
	NX_ULONG	b06ZRdOutAdrID:							6;
	NX_ULONG	b01ZReserved4:							1;
	NX_ULONG	b01ZRdEnbBit:							1;
} ASIC_RRGEXLASRCMD_Bits;
typedef struct _ASIC_RRGEXLASRRSP_Bits {
	NX_ULONG	b02ZRdOutDat1stRsp:						2;
	NX_ULONG	b16ZReserved1:							22;
	NX_ULONG	b07ZRdOutDatID:							7;
	NX_ULONG	b01ZReserved2:							1;
} ASIC_RRGEXLASRRSP_Bits;
typedef struct _ASIC_RRGEXLASWCMD_Bits {
	NX_ULONG	b0CZReserved1:							12;
	NX_ULONG	b02ZWrtAdrBrstTyp:						2;
	NX_ULONG	b02ZReserved2:							2;
	NX_ULONG	b03ZWrtAdrDatSize:						3;
	NX_ULONG	b01ZReserved3:							1;
	NX_ULONG	b04ZWrtAdrBrstLen:						4;
	NX_ULONG	b06ZWrtAdrID:							6;
	NX_ULONG	b01ZReserved4:							1;
	NX_ULONG	b01ZRdEnbBit:							1;
} ASIC_RRGEXLASWCMD_Bits;
typedef struct _ASIC_RRGEXLASWRSP_Bits {
	NX_ULONG	b02ZWrtDat1stRsp:						2;
	NX_ULONG	b16ZReserved1:							22;
	NX_ULONG	b06ZWrtDatID:							6;
	NX_ULONG	b02ZReserved2:							2;
} ASIC_RRGEXLASWRSP_Bits;
typedef struct _NGN_CN_AXI_TAG {
	union {
		NX_ULONG				DATA;
		ASIC_RRGELFERR_Bits	BITS;
	} R_RGELFERR;
	union {
		NX_ULONG				DATA;
		ASIC_RRGELAERR_Bits	BITS;
	} R_RGELAERR;
	union {
		NX_ULONG				DATA;
		ASIC_RRGERMSK_Bits	BITS;
	} R_RGERMSK;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEIMSK_Bits	BITS;
	} R_RGEIMSK;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEMSKC_Bits	BITS;
	} R_RGEMSKC;
	union {
		NX_ULONG				DATA;
		ASIC_RRGMOD_Bits	BITS;
	} R_RGMOD;
	NX_ULONG					ulZReserved0018[(0x0038-0x0018)/4];
	NX_ULONG					R_RGEXLASRAD;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEXLASRCMD_Bits	BITS;
	} R_RGEXLASRCMD;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEXLASRRSP_Bits	BITS;
	} R_RGEXLASRRSP;
	NX_ULONG					R_RGEXLASWAD;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEXLASWCMD_Bits	BITS;
	} R_RGEXLASWCMD;
	union {
		NX_ULONG				DATA;
		ASIC_RRGEXLASWRSP_Bits	BITS;
	} R_RGEXLASWRSP;
	NX_ULONG					ulZReserved0050[(0x0090-0x0050)/4];
	NX_ULONG					R_RGEXLASRC0A;
	NX_ULONG					R_RGEXLASRC0C;
	NX_ULONG					R_RGEXLASRC1A;
	NX_ULONG					R_RGEXLASRC1C;
	NX_ULONG					R_RGEXLASRC2A;
	NX_ULONG					R_RGEXLASRC2C;
	NX_ULONG					R_RGEXLASRC3A;
	NX_ULONG					R_RGEXLASRC3C;
	NX_ULONG					R_RGEXLASWC0A;
	NX_ULONG					R_RGEXLASWC0C;
	NX_ULONG					R_RGEXLASWC1A;
	NX_ULONG					R_RGEXLASWC1C;
	NX_ULONG					R_RGEXLASWC2A;
	NX_ULONG					R_RGEXLASWC2C;
	NX_ULONG					R_RGEXLASWC3A;
	NX_ULONG					R_RGEXLASWC3C;
} NGN_CN_AXI_TAG;

#endif

