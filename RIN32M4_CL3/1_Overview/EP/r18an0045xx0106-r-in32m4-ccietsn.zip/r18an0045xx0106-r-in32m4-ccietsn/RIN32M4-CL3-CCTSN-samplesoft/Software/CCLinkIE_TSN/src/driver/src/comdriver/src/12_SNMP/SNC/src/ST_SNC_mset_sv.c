/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNC.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_UTI.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "msw_lldp.h"
#include "lldpd.h"
#include "ST_SNC_debug_com_l.h"
#else
#include <common.h>
#include <28_NPS/Include/ST_SNC.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mset_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_UTI.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ccienx_api.h"
#include "ST_SNC.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif


#ifdef MASTER
#else
#ifndef OK
#define OK					(0U)
#endif
#ifndef NG
#define NG					(-1)
#endif
#endif

typedef struct ST_SNC_MemAttr_TAG {
	NX_VOID*					pvAddr;
	NX_ULONG					ulSize;
} ST_SNC_MemAttr;

static NX_ULONG ulST_SNC_MibArraySet(
	NX_UCHAR					ucType,
	ST_SNC_MemAttr*			pstDst,
	const ST_SNC_MemAttr*	pstSrc,
	ST_SNC_MibCounter*		pstCounter
);
static NX_ULONG ulST_SNC_SetCommon(
	ST_SNC_Mibtype 			eMibType,
	const ST_SNC_MibMng* 	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
);





#ifdef SWPS
#else
int	iSNCmemmove_s( void *pDst, NX_ULONG ulDstSize, void *pSrc, NX_ULONG ulSrcSize ){
	int		iRst = NG;
	int		iI;
	NX_UCHAR	*puchS,*puchD;
	if( ulDstSize >= ulSrcSize ){
		if( pDst < pSrc ){
			puchD = ((NX_UCHAR*)pDst);
			puchS = ((NX_UCHAR*)pSrc);
			for( iI = 0 ; iI < ulSrcSize ; ++iI, ++puchD, ++puchS ){
				*puchD = *puchS;
			}
		}
		else{
			puchD = ((NX_UCHAR*)pDst) + ulSrcSize - 1;
			puchS = ((NX_UCHAR*)pSrc) + ulSrcSize - 1;
			for( iI = 0 ; iI < ulSrcSize ; ++iI, --puchD, --puchS ){
				*puchD = *puchS;
			}
		}
		iRst = OK;
	}
	else{
	}
	return( iRst );
}
NX_ULONGLONG	ullSNChtonll( NX_ULONGLONG ullHostVal ){
	int		iI;
	NX_UCHAR	*puchS,*puchD;
	NX_ULONGLONG	ullNetVal;
	puchS = ((NX_UCHAR*)(&(ullHostVal))) + sizeof(ullHostVal) - 1;
	puchD = ((NX_UCHAR*)(&(ullNetVal )));
	for( iI = 0 ; sizeof( ullHostVal ) > iI ; ++iI, ++puchD, --puchS ){
		*puchD = *puchS;
	}
	return( ullNetVal );
}
#endif
static NX_ULONG ulST_SNC_MibArraySet(
	NX_UCHAR					ucType,
	ST_SNC_MemAttr*			pstDst,
	const ST_SNC_MemAttr*	pstSrc,
	ST_SNC_MibCounter*		pstCounter
)
{
	NX_ULONG	ulRet = ST_SNC_OK;

	switch(ucType)	{
	case ST_SNC_ARRAY_NON :
		break;
	case ST_SNC_ARRAY_ADD :

#ifdef MASTER
		gpST_UTI_Memcpy(pstDst->pvAddr, pstSrc->pvAddr, pstDst->ulSize);
#else
		vNX_CopyMemory(pstDst->pvAddr, (NX_VOID*)pstSrc->pvAddr, pstDst->ulSize);
#endif
	
		ulRet = ulST_SNC_CountupMibCnt(pstCounter);
		break;

	case ST_SNC_ARRAY_MOD :

#ifdef MASTER
		gpST_UTI_Memcpy(pstDst->pvAddr, pstSrc->pvAddr, pstDst->ulSize);
#else
		vNX_CopyMemory(pstDst->pvAddr, (NX_VOID*)pstSrc->pvAddr, pstDst->ulSize);
#endif
		break;

	case ST_SNC_ARRAY_DEL :

#ifdef SWPS
		memmove_s(pstDst->pvAddr, pstDst->ulSize, pstSrc->pvAddr, pstSrc->ulSize);
#else
		(NX_VOID)iSNCmemmove_s( pstDst->pvAddr, pstDst->ulSize, pstSrc->pvAddr, pstSrc->ulSize );
#endif

		ulRet = ulST_SNC_CountdownMibCnt(pstCounter);
		break;

	default :
		return ST_SNC_NG_PARAM_RANGE;
	}
	
	return ST_SNC_OK;
}


static NX_ULONG ulST_SNC_CheckArrayControlMaxMin(
	NX_UCHAR	ucType,
	NX_USHORT	usIndex,
	NX_ULONG	ulMax,
	NX_ULONG	ulMin,
	NX_ULONG	ulCounter
)
{
	NX_ULONG		ulRet = ST_SNC_OK;

	switch(ucType)	{
	case ST_SNC_ARRAY_ADD :

		if(usIndex == ulCounter) {

			if (ulMax <= ulCounter) {
				ulRet = ST_SNC_NG_ADD_MAX;
			}
			else {
				;
			}
		}
		else {
			ulRet = ST_SNC_NG_INDEX_REG_RANGE;
		}
		break;

	case ST_SNC_ARRAY_DEL :

		if(usIndex < ulCounter) {

			if ( ulMin >= ulCounter) {
				ulRet = ST_SNC_NG_DEL_MIN;
			}
			else {
				;
			}
		}
		else {
			ulRet = ST_SNC_NG_INDEX_REG_RANGE;
		}
		break;

	case ST_SNC_ARRAY_NON :
		break;
	case ST_SNC_ARRAY_MOD :
		if(usIndex < ulCounter) {
			;
		}
		else {
			ulRet = ST_SNC_NG_INDEX_REG_RANGE;
		}
		break;
	default :
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	DBGTRACE(" %s [Rc/Typ/Idx/Cnt]=[%d/%d/%d/%d]", (ulRet==ST_SNC_OK?"OK":"NG"), ulRet, ucType, usIndex, ulCounter);
	return ulRet;
}

NX_ULONG ulST_SNC_SetMibCntAttr(
	ST_SNC_MibCntAttr*	pstCntAttr,
	ST_SNC_Mibtype		eMibType,
	NX_ULONG				ulOfst,
	NX_ULONG				ulCntSize,
	NX_ULONG				ulCountMax
)
{
	NX_ULONG		ulRet = ST_SNC_OK;

	switch(ulCntSize) {
	case sizeof(NX_UCHAR):
		pstCntAttr->eType       = ST_SNC_COUNTER_UCHAR;
		break;
	case sizeof(NX_USHORT):
		pstCntAttr->eType       = ST_SNC_COUNTER_USHORT;
		break;
	case sizeof(NX_ULONG):
		pstCntAttr->eType       = ST_SNC_COUNTER_ULONG;
		break;
	default:
		ulRet = ST_SNC_NG_MIB_INDEX_REGNUM;
	}

	if(ST_SNC_OK == ulRet){
		pstCntAttr->eMibType   = eMibType;
		pstCntAttr->ulOfst     = ulOfst;
		pstCntAttr->ulCountMax = ulCountMax;
	}
	else {
		;
	}

	return ulRet;
}

NX_ULONG ulST_SNC_CountupMibCnt(ST_SNC_MibCounter* pstCounter)
{
	NX_ULONG	ulRet = ST_SNC_OK;
	NX_VOID* 	pvCounter = NX_NULL;

	pvCounter = (NX_UCHAR*)pstCounter->pvStart + pstCounter->pstCnt->ulOfst;
	switch(pstCounter->pstCnt->eType) {
	case ST_SNC_COUNTER_UCHAR:
		(*(NX_UCHAR*)pvCounter)++;
		break;
	case ST_SNC_COUNTER_USHORT:
		(*(NX_USHORT*)pvCounter)++;
		break;
	case ST_SNC_COUNTER_ULONG:
		(*(NX_ULONG*)pvCounter)++;
		break;
	default :
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}
	return ulRet;
}

NX_ULONG ulST_SNC_CountdownMibCnt(ST_SNC_MibCounter* pstCounter)
{
	NX_ULONG	ulRet = ST_SNC_OK;
	NX_VOID* 	pvCounter = NX_NULL;

	pvCounter = (NX_UCHAR*)pstCounter->pvStart + pstCounter->pstCnt->ulOfst;

	switch(pstCounter->pstCnt->eType) {
	case ST_SNC_COUNTER_UCHAR:
		(*(NX_UCHAR*)pvCounter)--;
		break;
	case ST_SNC_COUNTER_USHORT:
		(*(NX_USHORT*)pvCounter)--;
		break;
	case ST_SNC_COUNTER_ULONG:
		(*(NX_ULONG*)pvCounter)--;
		break;
	default :
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}
	return ulRet;
}

NX_ULONG ulST_SNC_GetCounterMibCnt(const ST_SNC_MibCounter* pstCounter, NX_ULONG* pulCounter)
{
	NX_ULONG	ulRet = ST_SNC_OK;
	NX_VOID* 	pvCounter = NX_NULL;

	pvCounter = (NX_UCHAR*)pstCounter->pvStart + pstCounter->pstCnt->ulOfst;

	switch(pstCounter->pstCnt->eType) {
	case ST_SNC_COUNTER_UCHAR :
		*pulCounter = *(NX_UCHAR*)pvCounter;
		break;
	case ST_SNC_COUNTER_USHORT:
		*pulCounter = *(NX_USHORT*)pvCounter;
		break;
	case ST_SNC_COUNTER_ULONG:
		*pulCounter = *(NX_ULONG*)pvCounter;
		break;
	default :
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}



static NX_ULONG ulST_SNC_SetCommon(
		ST_SNC_Mibtype			eMibType,
		const ST_SNC_MibMng*	pstMng,
		const NX_VOID*				pvData,
		NX_VOID*					pvMib,
		NX_ULONG					ulMibSize
)
{
	ST_SNC_MibAttr		stAttr;
	ST_SNC_MibCounter	stCounter;
	ST_SNC_MemAttr		stMibAddr;
	ST_SNC_MemAttr		stSrcAddr;
	NX_ULONG				ulRet = ST_SNC_OK;
	NX_ULONG				ulCurrentCount = 0;
	NX_UCHAR				uchIdxAryInf = 0;

	DBGTRACE("%s Start(%d:%d)", __FUNCTION__, eMibType, pstMng->usOidmap);
#ifdef MASTER
	gpST_UTI_Memset(&stCounter, ST_SNC_ZEROPAD, sizeof(ST_SNC_MibCounter));
#else
	vNX_FillMemory(&stCounter, ST_SNC_ZEROPAD, sizeof(ST_SNC_MibCounter));
#endif

	if((NX_NULL == pstMng) || (NX_NULL == pvMib)) {

		ulRet = ST_SNC_NG_PARAM_ADDR;

	}
	else {
#ifdef MASTER
		gpST_UTI_Memset(&stMibAddr, ST_SNC_ZEROPAD, sizeof(stMibAddr));
#else
		vNX_FillMemory(&stMibAddr, ST_SNC_ZEROPAD, sizeof(stMibAddr));
#endif

		ulRet = ulST_SNM_Oidmap2MibAttr(ST_SNM_MIBCLASS_EXT, pstMng->usOidmap, uchIdxAryInf, &stAttr);
		if(ST_SNC_OK == ulRet){
			if( (ST_SNM_VALUE_NONE == stAttr.ulOfst) &&
				(ST_SNM_VALUE_NONE == stAttr.ulSize) )
			{
				ulRet = ST_SNC_NG_PARAM_RANGE;
			}
			else{
				ulRet = ulST_SNC_MibGetAddrNolock(stAttr.stCnt.eMibType, ST_SNC_MEMORY_WRITE, &stCounter.pvStart);
				if(ST_SNC_OK == ulRet){
					stCounter.pstCnt = &stAttr.stCnt;
#ifdef CURERR_OPTIONINFO_ENABLE
					if(ST_SNC_MAP_CURERR_OPT_REG == pstMng->usOidmap) {
						stCounter.pstCnt->ulOfst = (NX_UCHAR*)pvMib - (NX_UCHAR*)stCounter.pvStart;
					}
					else{
						;
					}
#endif
					stMibAddr.pvAddr = (NX_UCHAR*)pvMib + stAttr.ulOfst;
					stMibAddr.ulSize = stAttr.ulSize;


				}
				else {
					DBGTRACE("  [ERROR]ulST_SNC_MibGetAddrNolock(type=%d r/w=%d rc=%d)",stAttr.stCnt.eMibType, ST_SNC_MEMORY_WRITE, ulRet);
				}
			}
		}
		else if(ST_SNC_NG_MEMCNT == ulRet) {
			stMibAddr.pvAddr = (NX_UCHAR*)pvMib + stAttr.ulOfst;
			stMibAddr.ulSize = stAttr.ulSize;
			ulRet = ST_SNC_OK;

		}
		else{
			DBGTRACE("  [ERROR]ulST_SNM_Oidmap2MibAttr(class=%d oidmap=%d idx=%d rc=%d)",ST_SNM_MIBCLASS_EXT, pstMng->usOidmap, uchIdxAryInf, ulRet);
		}

		if(ST_SNC_OK == ulRet)	{

			switch(pstMng->stIdx.ucType)	{
			case ST_SNC_ARRAY_MOD :
			case ST_SNC_ARRAY_DEL :
			case ST_SNC_ARRAY_ADD :
				ulRet = ulST_SNC_GetCounterMibCnt(&stCounter, &ulCurrentCount);
				break;
			case ST_SNC_ARRAY_NON :
				break;
			default :
				ulRet = ST_SNC_NG_PARAM_RANGE;
				break;
			}
		}
		else {
			;
		}

		if(ST_SNC_OK == ulRet) {

			switch(pstMng->stIdx.ucType)	{
			case ST_SNC_ARRAY_NON :
#ifdef MASTER
				gpST_UTI_Memcpy(stMibAddr.pvAddr, pvData, stMibAddr.ulSize);
#else
				vNX_CopyMemory(stMibAddr.pvAddr, (NX_VOID*)pvData, stMibAddr.ulSize);
#endif
				break;
			case ST_SNC_ARRAY_DEL :
				ulRet = ulST_SNC_CheckArrayControlMaxMin(
							pstMng->stIdx.ucType,
							pstMng->stIdx.usIdx,
							stCounter.pstCnt->ulCountMax,
							0,
							ulCurrentCount);
				if(ST_SNC_OK == ulRet) {

					stSrcAddr.pvAddr = (NX_UCHAR*)stMibAddr.pvAddr + stMibAddr.ulSize * (pstMng->stIdx.usIdx + 1);
					stMibAddr.pvAddr = (NX_UCHAR*)stMibAddr.pvAddr + stMibAddr.ulSize * pstMng->stIdx.usIdx;
					stSrcAddr.ulSize = ulMibSize - (NX_ULONG)((NX_UCHAR*)stSrcAddr.pvAddr - (NX_UCHAR*)pvMib);
					stMibAddr.ulSize = ulMibSize - (NX_ULONG)((NX_UCHAR*)stMibAddr.pvAddr - (NX_UCHAR*)pvMib);
					ulRet = ulST_SNC_MibArraySet(
								pstMng->stIdx.ucType,
								&stMibAddr,
								&stSrcAddr,
								&stCounter);
				}
				else {
					;
				}

				break;
			case ST_SNC_ARRAY_MOD :

				ulRet = ulST_SNC_CheckArrayControlMaxMin(
							pstMng->stIdx.ucType,
							pstMng->stIdx.usIdx,
							stCounter.pstCnt->ulCountMax,
							0,
							ulCurrentCount);
				if(ST_SNC_OK == ulRet) {

					stSrcAddr.pvAddr = (NX_VOID*)pvData;
					stSrcAddr.ulSize = stMibAddr.ulSize;
#ifdef SWPS
					(NX_UCHAR*)stMibAddr.pvAddr += (stMibAddr.ulSize * pstMng->stIdx.usIdx);
#else
					stMibAddr.pvAddr = (NX_VOID*)(((NX_UCHAR*)stMibAddr.pvAddr) + (stMibAddr.ulSize * pstMng->stIdx.usIdx));
#endif
					ulRet = ulST_SNC_MibArraySet(
								pstMng->stIdx.ucType,
								&stMibAddr,
								&stSrcAddr,
								&stCounter);
				}
				else {
					;
				}

				break;
			case ST_SNC_ARRAY_ADD :

				ulRet = ulST_SNC_CheckArrayControlMaxMin(
							pstMng->stIdx.ucType,
							pstMng->stIdx.usIdx,
							stCounter.pstCnt->ulCountMax,
							0,
							ulCurrentCount);
				if(ST_SNC_OK == ulRet) {

					stSrcAddr.pvAddr = (NX_VOID*)pvData;
					stSrcAddr.ulSize = stMibAddr.ulSize;
#ifdef SWPS
					(NX_UCHAR*)stMibAddr.pvAddr += (stMibAddr.ulSize * ulCurrentCount);
#else
					stMibAddr.pvAddr = (NX_VOID*)(((NX_UCHAR*)stMibAddr.pvAddr) + (stMibAddr.ulSize * ulCurrentCount));
#endif
					ulRet = ulST_SNC_MibArraySet(
								pstMng->stIdx.ucType,
								&stMibAddr,
								&stSrcAddr,
								&stCounter);

				}
				else {
					;
				}

				break;
			default :
				ulRet = ST_SNC_NG_PARAM_RANGE;
				break;
			}
		}
		else {
			;
		}
	}

	if(NX_NULL != stCounter.pvStart  &&  NX_NULL != stCounter.pstCnt){
		DBGTRACE("%s End(%d:%d:%d:%d)", __FUNCTION__, eMibType, pstMng->usOidmap, *(NX_ULONG*)((NX_UCHAR*)stCounter.pvStart + stCounter.pstCnt->ulOfst), ulRet);
	}
	else {
		DBGTRACE("%s End(%d:%d:%d)", __FUNCTION__, eMibType, pstMng->usOidmap, 0, ulRet);
	}

	return ulRet;
}

NX_ULONG ulST_SNC_SetNetworkConfig(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_NWCFG, pstMng, pvData, pvMib, ulMibSize);
}

NX_ULONG ulST_SNC_SetDeviceDetail(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_DEVDTL, pstMng, pvData, pvMib,	ulMibSize);
}

NX_ULONG ulST_SNC_SetOtherModule(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_OTMDL, pstMng, pvData, pvMib, ulMibSize);
}


NX_ULONG ulST_SNC_SetStatisticalInfo(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_STATS, pstMng, pvData, pvMib, ulMibSize);
}


NX_ULONG ulST_SNC_SetIpOverlapError(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_IPOVERLAP, pstMng, pvData, pvMib, ulMibSize);
}

NX_ULONG ulST_SNC_SetIpTopologyError(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_TOPOLOGY, pstMng, pvData, pvMib, ulMibSize);
}


NX_ULONG ulST_SNC_SetDatalinkError(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_DATALINK, pstMng, pvData, pvMib, ulMibSize);
}


NX_ULONG ulST_SNC_SetCommTimingError(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	return ulST_SNC_SetCommon(ST_SNC_MIBTYPE_COMTIMING, pstMng, pvData, pvMib, ulMibSize);
}

NX_STATIC NX_VOID SR_SNC_FindOldestErrorOccurOrderNo(
	ST_SNC_N1MibCurrentError*	pstCurError,
	NX_USHORT*						pusIndex
)
{
	ST_SNC_N2MibErrorReg*	pstN2Reg				= NX_NULL;
	NX_USHORT					usIndexMin 				= NX_ZERO;
	NX_USHORT					usIndexMinLOver			= NX_ZERO;
	NX_USHORT					usCounter				= NX_ZERO;
	NX_USHORT					usErrOcrOdrNo 			= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMin		= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMinLOver	= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMax		= NX_ZERO;


	usErrOcrOdrNo = ST_SNC_GetCounterErrOccurOdrNo();

	usErrOcrOdrNoMin		= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX;
	usErrOcrOdrNoMinLOver	= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX;
	usErrOcrOdrNoMax		= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN;

	for(usCounter=NX_ZERO; usCounter<pstCurError->usNumberOfTable; usCounter++) {

		pstN2Reg = &pstCurError->astErrorTable[usCounter];

		if( usErrOcrOdrNoMin > pstN2Reg->usErrorOccurrenceOrderNo ) {

			usErrOcrOdrNoMin = pstN2Reg->usErrorOccurrenceOrderNo;
			usIndexMin = usCounter;
		}
		else {
		}

		if( usErrOcrOdrNo < pstN2Reg->usErrorOccurrenceOrderNo ) {

			if( usErrOcrOdrNoMinLOver >= pstN2Reg->usErrorOccurrenceOrderNo ) {
				usErrOcrOdrNoMinLOver = pstN2Reg->usErrorOccurrenceOrderNo;
				usIndexMinLOver = usCounter;
			}
			else {
			}
		}
		else {
		}


		if( usErrOcrOdrNoMax < pstN2Reg->usErrorOccurrenceOrderNo ) {

			usErrOcrOdrNoMax = pstN2Reg->usErrorOccurrenceOrderNo;
		}
		else {
		}
	}


	if( ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX == usErrOcrOdrNoMax ) {

		*pusIndex = usIndexMinLOver;
	}
	else {
		*pusIndex = usIndexMin;
	}
	
	return;
}

#ifdef CURERR_OPTIONINFO_ENABLE
NX_STATIC NX_VOID SR_SNC_FindOldestOptionErrorOccurOrderNo(
	ST_SNC_N2MibCurrentErrorOptionInfo*	pstCurErrorOpt,
	NX_USHORT*						pusIndex,
	NX_USHORT						usOptNum
)
{
	ST_SNC_N3MibOptionInfoErrorReg*	pstN3OptReg			= NX_NULL;
	NX_USHORT					usIndexMin 				= NX_ZERO;
	NX_USHORT					usIndexMinLOver			= NX_ZERO;
	NX_USHORT					usCounter				= NX_ZERO;
	NX_USHORT					usErrOcrOdrNo 			= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMin		= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMinLOver	= NX_ZERO;
	NX_USHORT					usErrOcrOdrNoMax		= NX_ZERO;


	usErrOcrOdrNo = ST_SNC_GetCounterOptionErrOccurOdrNo( usOptNum );

	usErrOcrOdrNoMin		= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX;
	usErrOcrOdrNoMinLOver	= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX;
	usErrOcrOdrNoMax		= ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN;

	for(usCounter=NX_ZERO; usCounter<pstCurErrorOpt->usNumberOfTable; usCounter++) {

		pstN3OptReg = &pstCurErrorOpt->astErrorTable[usCounter];

		if( usErrOcrOdrNoMin > pstN3OptReg->usErrorOccurrenceOrderNo ) {

			usErrOcrOdrNoMin = pstN3OptReg->usErrorOccurrenceOrderNo;
			usIndexMin = usCounter;
		}
		else {
		}

		if( usErrOcrOdrNo < pstN3OptReg->usErrorOccurrenceOrderNo ) {

			if( usErrOcrOdrNoMinLOver >= pstN3OptReg->usErrorOccurrenceOrderNo ) {
				usErrOcrOdrNoMinLOver = pstN3OptReg->usErrorOccurrenceOrderNo;
				usIndexMinLOver = usCounter;
			}
			else {
			}
		}
		else {
		}


		if( usErrOcrOdrNoMax < pstN3OptReg->usErrorOccurrenceOrderNo ) {

			usErrOcrOdrNoMax = pstN3OptReg->usErrorOccurrenceOrderNo;
		}
		else {
		}
	}


	if( ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX == usErrOcrOdrNoMax ) {

		*pusIndex = usIndexMinLOver;
	}
	else {
		*pusIndex = usIndexMin;
	}

	return;
}
#endif

NX_ULONG ulST_SNC_SetCurrentError(
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pvData,
	NX_VOID*					pvMib,
	NX_ULONG					ulMibSize
)
{
	ST_SNC_MibMng 				stMng;
	NX_ULONGLONG 				ullValue			= 0;
	NX_ULONG					ulRet				= ST_SNC_OK;
	ST_SNC_N1MibCurrentError*	pstCurError 		= NX_NULL;
	ST_SNC_N2MibErrorReg*		pstN2Reg			= NX_NULL;
	NX_USHORT					usAddIdxErrorInfo	= 0;
#ifdef CURERR_OPTIONINFO_ENABLE
	ST_SNC_N2MibCurrentErrorOptionInfo*	pstCurErrorOpt	= NX_NULL;
	ST_SNC_N3MibOptionInfoErrorReg*		pstN3OptReg		= NX_NULL;
	NX_ULONG							ulOptOfst		= NX_ZERO;
	NX_USHORT							usOptNum		= NX_ZERO;
#endif


	if(NX_NULL == pstMng) {
		return ST_SNC_NG_PARAM_ADDR;
	}
#ifdef CURERR_OPTIONINFO_ENABLE
	else if((ST_SNC_ARRAY_ADD != pstMng->stIdx.ucType)
		 && (ST_SNC_ARRAY_NON != pstMng->stIdx.ucType)) {
#else
	else if(ST_SNC_ARRAY_ADD != pstMng->stIdx.ucType) {
#endif
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
	}

#ifdef MASTER
	gpST_UTI_Memcpy(&stMng, pstMng, sizeof(stMng));
#else
	vNX_CopyMemory(&stMng, (NX_VOID*)pstMng, sizeof(stMng));
#endif

#ifdef CURERR_OPTIONINFO_ENABLE
	if(ST_SNC_MAP_CURERR_REG == stMng.usOidmap) {
		if(ST_SNC_ARRAY_ADD  == stMng.stIdx.ucType) {
#endif

			pstCurError = (ST_SNC_N1MibCurrentError*)pvMib;

			if(ST_SNC_ERRREG_MAX > pstCurError->usNumberOfTable) {

				stMng.stIdx.usIdx = pstCurError->usNumberOfTable;
			}
			else {

				SR_SNC_FindOldestErrorOccurOrderNo( pstCurError, &usAddIdxErrorInfo );

				stMng.stIdx.ucType = ST_SNC_ARRAY_MOD;
				stMng.stIdx.usIdx = usAddIdxErrorInfo; 
			}

			if(ST_SNC_OK == ulRet){

				ulRet = ulST_SNC_SetCommon(ST_SNC_MIBTYPE_CURERR, &stMng, pvData, pvMib, ulMibSize);
				if(ST_SNC_OK == ulRet){


					pstN2Reg = pstCurError->astErrorTable + stMng.stIdx.usIdx;

#ifdef SWPS
					ullValue = htonll(pstN2Reg->ullOccurrenceTimeSeconds);
#else
					ullValue = ullSNChtonll( pstN2Reg->ullOccurrenceTimeSeconds );
#endif
					pstN2Reg->ullOccurrenceTimeSeconds = ullValue;

					pstN2Reg->usErrorOccurrenceOrderNo = ST_SNC_GetCounterErrOccurOdrNo();
					ST_SNC_CountUpErrOccurOdrNo();
				}
				else {
					;
				}
			}
			else {
			}
#ifdef CURERR_OPTIONINFO_ENABLE
		}
		else if(ST_SNC_ARRAY_NON == stMng.stIdx.ucType) {

			ST_SNC_MibClearCurrentErrorController((ST_SNC_N1MibCurrentError*)pvMib);
		}
		else {
		}
	}
	else if(ST_SNC_MAP_CURERR_OPT == stMng.usOidmap) {
		if(ST_SNC_ARRAY_ADD == stMng.stIdx.ucType) {

			ulRet = ulST_SNC_SetCommon(ST_SNC_MIBTYPE_CURERR, &stMng, pvData, pvMib, ulMibSize);
		}
		else {
		}
	}
	else if(ST_SNC_MAP_CURERR_OPT_REG == stMng.usOidmap) {
		usOptNum = stMng.stIdx.usIdx;

		ulOptOfst = (NX_ULONG)&(((ST_SNC_N1MibCurrentError *)NX_ZERO) -> astOptTable) + ((NX_ULONG)sizeof(ST_SNC_N2MibCurrentErrorOptionInfo) * usOptNum);
		pstCurErrorOpt = (ST_SNC_N2MibCurrentErrorOptionInfo*)((NX_ULONG)pvMib + ulOptOfst);

		if(ST_SNC_ARRAY_ADD == stMng.stIdx.ucType) {

			if(ST_SNC_ERRREG_MAX > pstCurErrorOpt->usNumberOfTable) {

				stMng.stIdx.usIdx = pstCurErrorOpt->usNumberOfTable;
			}
			else {

				SR_SNC_FindOldestOptionErrorOccurOrderNo( pstCurErrorOpt, &usAddIdxErrorInfo, usOptNum );

				stMng.stIdx.ucType = ST_SNC_ARRAY_MOD;
				stMng.stIdx.usIdx = usAddIdxErrorInfo; 
			}

			if(ST_SNC_OK == ulRet){

				ulRet = ulST_SNC_SetCommon(ST_SNC_MIBTYPE_CURERR, &stMng, pvData, pstCurErrorOpt, ulMibSize);
				if(ST_SNC_OK == ulRet){


					pstN3OptReg = pstCurErrorOpt->astErrorTable + stMng.stIdx.usIdx;

					ullValue = ullSNChtonll( pstN3OptReg->ullOccurrenceTimeSeconds );

					pstN3OptReg->ullOccurrenceTimeSeconds = ullValue;

					pstN3OptReg->usErrorOccurrenceOrderNo = ST_SNC_GetCounterOptionErrOccurOdrNo( usOptNum );
					ST_SNC_CountUpOptionErrOccurOdrNo( usOptNum );
				}
				else {
					;
				}
			}
			else {
			}
		}
		else if(ST_SNC_ARRAY_NON == stMng.stIdx.ucType) {

			ST_SNC_MibClearCurrentErrorOption(pstCurErrorOpt, usOptNum);
		}
		else {
		}
	}
	else {
	}
#endif

	return ulRet;
}



#ifdef SWPS
#endif
