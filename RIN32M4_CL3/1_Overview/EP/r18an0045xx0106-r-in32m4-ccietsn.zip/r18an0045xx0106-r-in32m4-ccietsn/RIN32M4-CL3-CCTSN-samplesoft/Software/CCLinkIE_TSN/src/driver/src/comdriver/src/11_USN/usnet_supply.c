/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "kernel.h"
#include "ccienx_api.h"
#include "USN_api.h"
#include "msw_lldp.h"
#include "lldpd.h"
#include "TOOL_api.h"

NX_ULONG ulUSN_GetLifeTime (NX_VOID)
{
	NX_ULONG	ulResult;
	ulResult = ulNX_GetLifeTime();
	return ulResult;
}

NX_VOID vUSN_vDisableDispatch (NX_VOID)
{
	vNX_vDisableDispatch();
	return;
}


NX_VOID vUSN_vEnableDispatch (NX_VOID)
{
	vNX_vEnableDispatch();
	return;
}

NX_VOID vUSN_GetLinkSts (NX_USHORT usPhysicalPort, NX_ULONG* pulLinkSts)
{
	
	if (PHYREG_MODESTS_LINKUP == (gstNET.stPhyReg[usPhysicalPort].ulModeSts & PHYREG_MODESTS_BIT_LINKUPSTS)) {
		*pulLinkSts = PHYREG_MODESTS_LINKUP;
	}
	else {
		*pulLinkSts = PHYREG_MODESTS_LINKDOWN;
	}
	
	return;
}

NX_VOID vUSN_GetIpOverlapErrInfo (NX_USHORT usPhysicalPort, NX_USHORT usIpErrSts, NX_UCHAR* puchOtherMacAddr)
{
	IP_OVERLAP_ERR_CTRL stIpOverlapErrCtrl;	

	vUSN_GetGlbIpOverlapErrCtrl(usPhysicalPort, &stIpOverlapErrCtrl);
	
	stIpOverlapErrCtrl.usIpErrSts = usIpErrSts;

	vNX_CopyMemory(stIpOverlapErrCtrl.auchOtherMacAddr, puchOtherMacAddr, NX_MAC_ADDR_SIZE);
	
	vUSN_SetGlbIpOverlapErrCtrl(usPhysicalPort, &stIpOverlapErrCtrl);
	
	return;
}

NX_VOID vUSN_SetLldpSetting (LLDPD_SETTING_T* pstLldpSetting)
{
	NX_UCHAR	auchAsciiStrTmp[32];
	
	(NX_VOID)ulTOOL_NumToAscii((NX_UCHAR *)&gstAppInfo.stCieDevInfo.ulModelCode, sizeof(NX_ULONG), auchAsciiStrTmp);
	vNX_CopyMemory(pstLldpSetting->portDes, NX_CCLINK_IE_1, sizeof(NX_CCLINK_IE_1));
	vNX_CopyMemory((pstLldpSetting->portDes + (sizeof(NX_CCLINK_IE_1) - 1)), auchAsciiStrTmp, (sizeof(NX_ULONG) * 2));
	vNX_CopyMemory((pstLldpSetting->portDes + (sizeof(NX_CCLINK_IE_1) - 1)) + (sizeof(NX_ULONG) * 2), NX_CCLINK_IE_2, sizeof(NX_CCLINK_IE_2));
	
	vNX_CopyMemory(pstLldpSetting->sysName, gstAppInfo.stCieDevInfo.auchDeviceModelName, NX_MODEL_NAME_SIZE);
	
	(NX_VOID)ulTOOL_NumToAscii((NX_UCHAR *)&gstAppInfo.stCieDevInfo.usFwVersion, sizeof(NX_USHORT), auchAsciiStrTmp);
	vNX_CopyMemory(pstLldpSetting->sysDes, auchAsciiStrTmp, (sizeof(NX_USHORT) * 2));
	
	return;
}

NX_VOID vUSN_GetModelNameMib (NX_UCHAR* puchStrData)
{
	vNX_CopyMemory(puchStrData, gstAppInfo.stCieDevInfo.auchDeviceModelName, NX_MODEL_NAME_SIZE);
	
	return;
}

NX_VOID vUSN_GetCycSndSts (NX_ULONG* pulSndSts)
{
	*pulSndSts = ulNX_GetCycSendSts();
	return;
}

/*[EOF]*/
