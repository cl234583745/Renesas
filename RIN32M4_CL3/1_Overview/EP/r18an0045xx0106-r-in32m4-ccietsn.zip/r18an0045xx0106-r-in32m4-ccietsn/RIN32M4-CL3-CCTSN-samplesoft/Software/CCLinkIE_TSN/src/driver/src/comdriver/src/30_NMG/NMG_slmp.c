/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "ccienx_api.h"
#include "SLMP_api.h"
#include "TOOL_api.h"
#include "NGN_ASIC.h"
#include "CYC_api.h"
#include "nx_frame_cyclic.h"

#define RCV_FRMNUMBER_NC_MAIN_REQ		((NX_USHORT)0)
#define RCV_FRMNUMBER_NC_TSLT_REQ		((NX_USHORT)1)
#define RCV_FRMNUMBER_SC_REQ			((NX_USHORT)2)
#define RCV_FRMNUMBER_CC_MAIN_REQ		((NX_USHORT)3)
#define RCV_FRMNUMBER_CC_RCVSRC_REQ		((NX_USHORT)6)
#define RCV_FRMNUMBER_NTF_REQ			((NX_USHORT)7)
#define RCV_FRMNUMBER_NTF_RESP			((NX_USHORT)8)
#define RCV_FRMNUMBER_FIRST_SLMP		RCV_FRMNUMBER_NC_MAIN_REQ
#define RCV_FRMNUMBER_LAST_SLMP			RCV_FRMNUMBER_NTF_RESP
#define RCV_FRMNUMBER_UNKNOWN_SLMP		((NX_USHORT)RCV_FRMNUMBER_LAST_SLMP + (NX_USHORT)NX_ONE)
#define RCVFRM_KIND_SLMP				((NX_USHORT)9)

#define TRN_FRMNUMBER_NC_MAIN_RESP		((NX_USHORT)0)
#define TRN_FRMNUMBER_NC_TSLT_RESP		((NX_USHORT)1)
#define TRN_FRMNUMBER_SC_RESP			((NX_USHORT)2)
#define TRN_FRMNUMBER_CC_MAIN_RESP		((NX_USHORT)3)
#define TRN_FRMNUMBER_CC_TRNSPD_RESP	((NX_USHORT)4)
#define TRN_FRMNUMBER_CC_RCVSPD_RESP	((NX_USHORT)5)
#define TRN_FRMNUMBER_CC_RCVSRC_RESP	((NX_USHORT)6)
#define TRN_FRMNUMBER_NTF_REQ			((NX_USHORT)7)
#define TRN_FRMNUMBER_NTF_RESP			((NX_USHORT)8)

#define TRN_FRMNUMBER_FIRST				TRN_FRMNUMBER_NC_MAIN_RESP
#define TRNFRM_KIND_SLMP				((NX_USHORT)9)

#define	NWMNG_FRAME_USE					((NX_USHORT)0)
#define	NWMNG_FRAME_NO_USE				((NX_USHORT)1)
#define	NWMNG_FRAME_FAULT				((NX_USHORT)2)

typedef NX_VOID (* FRM_ANALYZE_PROC_SLMP)(NX_USHORT, NX_ULONG, NX_VOID*);

typedef struct tagSLMP_TBL {
	NX_USHORT				usFrameType;
	NX_USHORT				usCmd;
	NX_USHORT				usSubCmd;
	FRM_ANALYZE_PROC_SLMP	pFunc;
} SLMP_TBL;

typedef struct tagSLMP_CTRL {
	NX_USHORT	usSts;
	NX_USHORT	usTrnFrmNumber;
	NX_ULONG	aulReq[TRNFRM_KIND_SLMP];
	NX_ULONG	aulBufAddr[TRNFRM_KIND_SLMP];
	NX_ULONG	aulDstIp[TRNFRM_KIND_SLMP];
	NX_USHORT	ausDstPort[TRNFRM_KIND_SLMP];
	NX_USHORT	ausFrameSize[TRNFRM_KIND_SLMP];
	NX_USHORT	ausPhysicalPort[TRNFRM_KIND_SLMP];
} SLMP_CTRL;

typedef struct tagSENDPORT_INFO {
	NX_USHORT	usConfirmFlg;
	NX_USHORT	usPhysicalPort;
	NX_ULONG	ulSenderIp;
} SENDPORT_INFO;

NX_STATIC	SLMP_CTRL	gstSlmp;

NX_STATIC	NX_CONST	SLMP_TBL	gastSlmpTbl[RCVFRM_KIND_SLMP] = {
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E90,	SLMP_SUBCMD_0000,	vNMG_AnalyzeNetworkConfigMainReq},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E90,	SLMP_SUBCMD_0001,	vNMG_AnalyzeNetworkConfigTsltReq},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E92,	SLMP_SUBCMD_0000,	vNMG_AnalyzeSlaveConfigReq		},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E93,	SLMP_SUBCMD_0000,	vNMG_AnalyzeCyclicConfigMainReq	},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E93,	SLMP_SUBCMD_0001,	vNMG_AnalyzeCycCfgTrnSpdReq		},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E93,	SLMP_SUBCMD_0002,	vNMG_AnalyzeCycCfgRcvSpdReq		},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E93,	SLMP_SUBCMD_0003,	vNMG_AnalyzeCycCfgRcvReq		},
	{SLMP_FRAMETYPE_REQ_6E,		SLMP_CMD_0E94,	SLMP_SUBCMD_0000,	vNMG_AnalyzeNotificationReq		},
	{SLMP_FRAMETYPE_RESP_6E,	SLMP_CMD_0E94,	SLMP_SUBCMD_0000,	vNMG_AnalyzeNotificationResp	}
};

NX_STATIC 	SENDPORT_INFO	gstSenderPortInfo[NX_SENDERINFO_NUM];

NX_VOID		vNMG_RcvCmnSlmp ( NX_VOID );
NX_USHORT	usNMG_GetFrameKindSlmp ( NX_VOID* );
NX_USHORT	usNMG_DecideSlmpResp1st (NX_USHORT);
NX_VOID		vNMG_CheckFrmTrnReqSlmp ( NX_VOID );

NX_VOID vNMG_InitCieNetMngSlmp ( NX_VOID )
{
	vNX_FillMemory32(&gstSlmp, NX_ZERO, sizeof(SLMP_CTRL) / sizeof(NX_ULONG));
	vNX_FillMemory32(&gstSenderPortInfo[0], NX_ZERO, (sizeof(SENDPORT_INFO) / sizeof(NX_ULONG)) * NX_SENDERINFO_NUM);
	
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_NC_MAIN_RESP]		=	(NX_ULONG)gstNM.stTrnBuf.puchNetworkConfigMainResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_NC_TSLT_RESP]		=	(NX_ULONG)gstNM.stTrnBuf.puchNetworkConfigTsltResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_SC_RESP]			=	(NX_ULONG)gstNM.stTrnBuf.puchSlaveConfigResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_CC_MAIN_RESP]		=	(NX_ULONG)gstNM.stTrnBuf.puchCyclicConfigMainResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_CC_TRNSPD_RESP]	=	(NX_ULONG)gstNM.stTrnBuf.puchCyclicConfigTrnSubPayloadResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_CC_RCVSPD_RESP]	=	(NX_ULONG)gstNM.stTrnBuf.puchCyclicConfigRcvSubPayloadResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_CC_RCVSRC_RESP]	=	(NX_ULONG)gstNM.stTrnBuf.puchCyclicConfigRcvSrcInfoResp;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_NTF_REQ]			=	(NX_ULONG)gstNM.stTrnBuf.puchNotificationReq;
	gstSlmp.aulBufAddr[TRN_FRMNUMBER_NTF_RESP]			=	(NX_ULONG)gstNM.stTrnBuf.puchNotificationResp;
	
	vNMG_ClearHopCount();
	return;
}

NX_VOID vNMG_RcvCmnSlmpMain ( NX_VOID )
{
	if (gstSlmp.usSts == NM_STS_WAIT_RCV) {
		vNMG_RcvCmnSlmp();
		
		vNMG_CheckFrmTrnReqSlmp();
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_RcvCmnSlmp ( NX_VOID )
{
	NX_USHORT			usFinishCode	=	CMM_SLMP_SUCCESS;
	NX_USHORT			usFrmExist		=	NX_SLMP_FRAME_NONE;
	NX_TRN_RCV_INFO		stData;
	NX_USHORT			usFrmNumber		=	NX_ZERO;
	
	usFrmExist = usSLMP_GetSlmpCmnFrame(&stData);
	
	if (usFrmExist == NX_SLMP_FRAME_EXSI) {
		
		usFrmNumber = usNMG_GetFrameKindSlmp(stData.puchFrameAdr);
		
		if (RCV_FRMNUMBER_UNKNOWN_SLMP <= usFrmNumber) {
		}
		else {
			
			usFinishCode = usNMG_DecideSlmpResp1st(usFrmNumber);
			
			if (usFinishCode == (NX_USHORT)CMM_SLMP_SUCCESS) {
				
				gstSlmp.aulDstIp[usFrmNumber]	= stData.ulSrcIp;
				gstSlmp.ausDstPort[usFrmNumber]	= stData.usSrcPort;
				gstSlmp.ausPhysicalPort[usFrmNumber]	= stData.usPhysicalPort;
				
				gastSlmpTbl[usFrmNumber].pFunc(stData.usPhysicalPort, stData.ulSrcIp, (NX_VOID*)stData.puchFrameAdr);
			}
			else {
			}
			
		}
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}
	
	return;
}

NX_USHORT usNMG_GetFrameKindSlmp (
	NX_VOID*	pstData
)
{
	SLMP_REQUEST_6E	*pstHead;
	NX_USHORT		usFrmNumber	=	RCV_FRMNUMBER_UNKNOWN_SLMP;
	NX_USHORT		usIndex		=	RCV_FRMNUMBER_FIRST_SLMP;
	NX_USHORT		usFrameType	=	NX_ZERO;
	NX_USHORT		usCmd		=	NX_ZERO;
	NX_USHORT		usSubCmd	=	NX_ZERO;
	
	pstHead = (SLMP_REQUEST_6E*)pstData;
	
	usFrameType	= pstHead->usFrameType;
	usCmd		= pstHead->usCmd;
	usSubCmd	= pstHead->usSubCmd;
	
	for (usIndex = RCV_FRMNUMBER_FIRST_SLMP; usIndex <= RCV_FRMNUMBER_LAST_SLMP; usIndex++) {
		if (   (gastSlmpTbl[usIndex].usFrameType == usFrameType)
			&& (gastSlmpTbl[usIndex].usCmd == usCmd)
			&& (gastSlmpTbl[usIndex].usSubCmd == usSubCmd) ) {
			
			usFrmNumber = usIndex;
			
			break;
			
		}
		
	}
	
	
	return usFrmNumber;
}

NX_USHORT usNMG_DecideSlmpResp1st (
	NX_USHORT	usFrmNumber
)
{
	NX_USHORT	usResult	=	CMM_SLMP_MISS_COMMAND;
	
	if (   (usFrmNumber == RCV_FRMNUMBER_NTF_REQ)
		|| (usFrmNumber == RCV_FRMNUMBER_NTF_RESP)) {
		usResult = CMM_SLMP_SUCCESS;
	}
	else {
		switch (gstNM.stNet.usNetSts) {
		case NETSTS_RCVD_DETECTION:
			if ((RCV_FRMNUMBER_NC_MAIN_REQ == usFrmNumber) || (RCV_FRMNUMBER_NC_TSLT_REQ == usFrmNumber)) {
				usResult = CMM_SLMP_SUCCESS;
			}
			break;
		case NETSTS_RCVD_NWCFG:
			if (usFrmNumber <= RCV_FRMNUMBER_SC_REQ) {
				usResult = CMM_SLMP_SUCCESS;
			}
			break;
		case NETSTS_RCVD_SLCFG:
			if ((RCV_FRMNUMBER_SC_REQ <= usFrmNumber) && (usFrmNumber <= RCV_FRMNUMBER_CC_RCVSRC_REQ)) {
				usResult = CMM_SLMP_SUCCESS;
			}
			break;
		case NETSTS_RCVD_CYCCFG:
		case NETSTS_START_CYCSND:
			if ((RCV_FRMNUMBER_CC_MAIN_REQ <= usFrmNumber) && (usFrmNumber <= RCV_FRMNUMBER_CC_RCVSRC_REQ)) {
				usResult = CMM_SLMP_SUCCESS;
			}
			break;
		case NETSTS_INITIAL:
		case NETSTS_DLINK:
		case NETSTS_LINKDOWN:
		case NETSTS_LINKDOWN_ENR:
		default:
			break;
		}
	}
	
	
	return usResult;
}


NX_VOID vNMG_CheckFrmTrnReqSlmp ( NX_VOID )
{
	NX_TRN_SND_INFO		stSendInfo;
	NX_USHORT			usFrmNumber		= TRN_FRMNUMBER_FIRST;
	NX_USHORT			usSendResult	= NX_US_NG;
	
	for (usFrmNumber = TRN_FRMNUMBER_FIRST; usFrmNumber < TRNFRM_KIND_SLMP; usFrmNumber++) {
		
		if (gstSlmp.aulReq[usFrmNumber] == (NX_ULONG)NX_ON) {
			
			stSendInfo.ulDstIp		= gstSlmp.aulDstIp[usFrmNumber];
			stSendInfo.usDstPort	= gstSlmp.ausDstPort[usFrmNumber];
			stSendInfo.puchFrameAdr	= (NX_UCHAR*)gstSlmp.aulBufAddr[usFrmNumber];
			stSendInfo.usFrameSize	= gstSlmp.ausFrameSize[usFrmNumber];
			stSendInfo.usPhysicalPort	= gstSlmp.ausPhysicalPort[usFrmNumber];
			
			usSendResult = usNX_SetSlmpFrame(&stSendInfo);
			
			gstSlmp.usTrnFrmNumber = usFrmNumber;
			
			gstSlmp.usSts = NM_STS_WAIT_RCV;
			gstSlmp.aulReq[usFrmNumber] = (NX_ULONG)NX_OFF;
			break;
		}
		
	}
	
	return;
}

NX_VOID vNMG_ReqTrnNetworkConfigMainResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchNetworkConfigMainResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_NC_MAIN_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_NC_MAIN_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnNetworkConfigTsltResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchNetworkConfigTsltResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_NC_TSLT_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_NC_TSLT_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnSlaveConfigResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchSlaveConfigResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_SC_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_SC_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnCyclicConfigMainResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchCyclicConfigMainResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_CC_MAIN_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_CC_MAIN_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnCycCfgTrnSpdResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchCyclicConfigTrnSubPayloadResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_CC_TRNSPD_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_CC_TRNSPD_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnCycCfgRcvSpdResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchCyclicConfigRcvSubPayloadResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_CC_RCVSPD_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_CC_RCVSPD_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnCycCfgRcvResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchCyclicConfigRcvSrcInfoResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_CC_RCVSRC_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_CC_RCVSRC_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnNotificationReq ( NX_VOID )
{
	SLMP_REQUEST_6E*	pstReq;

	gstSlmp.aulDstIp[TRN_FRMNUMBER_NTF_REQ]		= gstNET.stMngMst.ulIPAddress;
	gstSlmp.ausDstPort[TRN_FRMNUMBER_NTF_REQ]	= SLMP_PORT_NW;
	gstSlmp.ausPhysicalPort[TRN_FRMNUMBER_NTF_REQ]	= gstNM.usBMCARcvPort;

	pstReq = (SLMP_REQUEST_6E*)gstNM.stTrnBuf.puchNotificationReq;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_NTF_REQ]	= pstReq->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_NTF_REQ] = (NX_ULONG)NX_ON;

	return;
}

NX_VOID vNMG_ReqTrnNotificationResp ( NX_VOID )
{
	SLMP_RESPONSE_6E*	pstResp;

	gstSlmp.aulDstIp[TRN_FRMNUMBER_NTF_RESP]	= gstSlmp.aulDstIp[TRN_FRMNUMBER_NTF_REQ];
	gstSlmp.ausDstPort[TRN_FRMNUMBER_NTF_RESP]	= gstSlmp.ausDstPort[TRN_FRMNUMBER_NTF_REQ];
	gstSlmp.ausPhysicalPort[TRN_FRMNUMBER_NTF_RESP]	= gstSlmp.ausPhysicalPort[TRN_FRMNUMBER_NTF_REQ];
	
	pstResp = (SLMP_RESPONSE_6E*)gstNM.stTrnBuf.puchNotificationResp;

	gstSlmp.ausFrameSize[TRN_FRMNUMBER_NTF_RESP]	= pstResp->usDataBSize + SLMP_SUBH_TO_DATALEN_SIZE;
	gstSlmp.aulReq[TRN_FRMNUMBER_NTF_RESP] = (NX_ULONG)NX_ON;

	return;
}

NX_USHORT usNMG_RecognizeSlmpCmd (
	NX_USHORT	usSubHead,
	NX_USHORT	usCmd,
	NX_USHORT	usSubCmd
)
{
	NX_USHORT	usRet		= NWMNG_FRAME_NO_USE;
	NX_USHORT	usLoop		= NX_ZERO;

	for (usLoop = NX_ZERO; usLoop <= RCV_FRMNUMBER_LAST_SLMP; usLoop++) {
		if ((gastSlmpTbl[usLoop].usFrameType	== usSubHead) &&
			(gastSlmpTbl[usLoop].usCmd			== usCmd) &&
			(gastSlmpTbl[usLoop].usSubCmd		== usSubCmd)) {
			usRet = NWMNG_FRAME_USE;
			break;
		}

		if ((gastSlmpTbl[usLoop].usFrameType	!= usSubHead) &&
			(gastSlmpTbl[usLoop].usCmd			== usCmd) &&
			(gastSlmpTbl[usLoop].usSubCmd		== usSubCmd)) {
			usRet = NWMNG_FRAME_FAULT;
		}
	}

	return usRet;
}

NX_VOID vNMG_InitSlmpReqFinFlg ( NX_VOID )
{
	NX_USHORT	usFrmNumber = TRN_FRMNUMBER_FIRST;
	
	for (usFrmNumber = TRN_FRMNUMBER_FIRST; usFrmNumber < TRNFRM_KIND_SLMP; usFrmNumber++) {
		gstSlmp.aulReq[usFrmNumber] = (NX_ULONG)NX_OFF;
	}
	return;
}

NX_ULONG ulNX_GetSndSpdNum (
	NX_USHORT*	pusSndSubPayLoadNum
)
{
	NX_ULONG	ulResult = NX_UL_NG;
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TRNSPD)) {
		if (NX_US_ZERO != gstNET.stCyc.usSndSubPayLoadNum) {
			*pusSndSubPayLoadNum	= gstNET.stCyc.usSndSubPayLoadNum;
			ulResult				= NX_UL_OK;
		}
		else {
		}
	}
	else {
	}
	
	return ulResult;
}

NX_ULONG ulNX_GetRcvSpdNum (
	NX_USHORT*	pusRcvSubPayLoadNum
)
{
	NX_ULONG	ulResult = NX_UL_NG;
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_RCVSPD)) {
		if (NX_US_ZERO != gstNET.stCyc.usRcvSubPayLoadNum) {
			*pusRcvSubPayLoadNum	= gstNET.stCyc.usRcvSubPayLoadNum;
			ulResult				= NX_UL_OK;
		}
		else {
		}
	}
	else {
	}
	
	return ulResult;
}

NX_ULONG ulNX_GetSndSpdInfo (
	NX_USHORT	usSpldNo,
	NX_UCHAR*	puchRegNo,
	NX_UCHAR*	puchDivNo,
	NX_USHORT*	pusDataSize,
	NX_ULONG*	pulRcvMemmoryAddr,
	NX_ULONG*	pulSndDataStorageAddr
)
{
	NX_ULONG	ulResult = NX_UL_NG;

	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TRNSPD)) {
		if (TRN_SPLD_NUM > usSpldNo) {
			if (NX_ON == gstNET.stCyc.stTrnSubPayL[usSpldNo].uchDataExist) {
				switch (gstNET.stCyc.stTrnSubPayL[usSpldNo].uchType) {
				case SPLD_TYPE_STSW:
					*puchRegNo = NX_SND_REG_NO_STSW;
					break;
				case SPLD_TYPE_RX:
					*puchRegNo = NX_SND_REG_NO_RX;
					break;
				case SPLD_TYPE_RWR:
					*puchRegNo = NX_SND_REG_NO_RWR;
					break;
#ifdef SAFETY_PDU_ENABLE
				case SPLD_TYPE_SPDUX:
					*puchRegNo = NX_SND_REG_NO_SPDUX;
					break;
#endif
				default:
					return ulResult;
					break;
				}
				*puchDivNo				= gstNET.stCyc.stTrnSubPayL[usSpldNo].uchDivNo;
				*pusDataSize			= gstNET.stCyc.stTrnSubPayL[usSpldNo].usSize;
				*pulRcvMemmoryAddr		= gstNET.stCyc.stTrnSubPayL[usSpldNo].ulRcvMemmoryAddr;
				*pulSndDataStorageAddr	= gstNET.stCyc.stTrnSubPayL[usSpldNo].ulSndDataAddr + (NX_ULONG)sizeof(SPHEAD_SS_S);
				ulResult				= NX_UL_OK;
			}
			else {
			}
		}
		else {
		}

	}
	else {
	}
	
	return ulResult;
}

NX_ULONG ulNX_GetRcvSpdInfo (
	NX_UCHAR	usSpldNo,
	NX_UCHAR*	puchRegNo,
	NX_UCHAR*	puchDivNo,
	NX_USHORT*	pusDataSize,
	NX_ULONG*	pulRcvDataAddr
)
{
	NX_ULONG	ulResult = NX_UL_NG;

	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_RCVSPD)) {
		if (RCV_SPLD_NUM > usSpldNo) {
			if (NX_ON == gstNET.stCyc.astRcvSubPayL[usSpldNo].uchDataExist) {
				switch (gstNET.stCyc.astRcvSubPayL[usSpldNo].uchType) {
				case SPLD_TYPE_RY:
					*puchRegNo = NX_RCV_REG_NO_RY;
					break;
				case SPLD_TYPE_RWW:
					*puchRegNo = NX_RCV_REG_NO_RWW;
					break;
#ifdef SAFETY_PDU_ENABLE
				case SPLD_TYPE_SPDUY:
					*puchRegNo = NX_RCV_REG_NO_SPDUY;
					break;
#endif
				default:
					return ulResult;
					break;
				}
				*puchDivNo		= gstNET.stCyc.astRcvSubPayL[usSpldNo].uchDivNo;
				*pusDataSize 	= gstNET.stCyc.astRcvSubPayL[usSpldNo].usSize;
				*pulRcvDataAddr	= gstNET.stCyc.astRcvSubPayL[usSpldNo].ulRcvDataAddr;
				ulResult		= NX_UL_OK;
			}
			else {
			}
		}
		else {
		}
	}
	else {
	}

	return ulResult;
}

NX_VOID vNMG_ClearTxPhysicalPort (
	NX_ULONG	ulTargetId
)
{
	if (ulTargetId < NX_SENDERINFO_NUM) {
		gstSenderPortInfo[ulTargetId].usConfirmFlg 	= (NX_USHORT)NX_OFF;
	}
	else {
	}

	return;
}

NX_VOID vNMG_InitTxPhysicalPort (
	NX_ULONG	ulTargetId,
	NX_ULONG	ulTargetIpAddress,
	NX_USHORT	usInitPhysicalPort
)
{
	if (ulTargetId < NX_SENDERINFO_NUM) {
		gstSenderPortInfo[ulTargetId].ulSenderIp 		= ulTargetIpAddress;
		gstSenderPortInfo[ulTargetId].usPhysicalPort 	= usInitPhysicalPort;
		gstSenderPortInfo[ulTargetId].usConfirmFlg 		= (NX_USHORT)NX_ON;
	}
	else {
	}
	return;
}

NX_VOID vNMG_UpdateTxPhysicalPort (
	NX_ULONG	ulSenderIpAddress,
	NX_USHORT	usRcvPhysicalPort
)
{
	NX_ULONG	ulTargetId;
	
	for (ulTargetId = (NX_ULONG)0; ulTargetId < NX_SENDERINFO_NUM; ulTargetId++) {
		if ((gstSenderPortInfo[ulTargetId].usConfirmFlg == (NX_USHORT)NX_ON) &&
			(gstSenderPortInfo[ulTargetId].ulSenderIp == ulSenderIpAddress)) {
			gstSenderPortInfo[ulTargetId].usPhysicalPort = usRcvPhysicalPort;
		}
		else {
		}
	}
	return;
}


/*[EOF]*/
