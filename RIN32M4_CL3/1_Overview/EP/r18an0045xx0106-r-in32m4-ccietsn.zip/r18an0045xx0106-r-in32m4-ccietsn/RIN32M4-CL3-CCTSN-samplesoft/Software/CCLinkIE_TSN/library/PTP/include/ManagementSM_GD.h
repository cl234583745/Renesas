/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MANAGEMENTSM_GD_H__
#define __MANAGEMENTSM_GD_H__

#include "ptp_type.h"
#include "ptp_ddt.h"

#define MGT_FRAME_BUFF_SIZE			1500

typedef enum tagMGT_FLTSEVRTYCD
{
	MGT_FLT_EMERGENCY =	0x00,
	MGT_FLT_ALERT,
	MGT_FLT_CRITICAL,
	MGT_FLT_ERROR,
	MGT_FLT_WARNING,
	MGT_FLT_NOTICE,
	MGT_FLT_INFORMATIONAL,
	MGT_FLT_DEBUG

}	MGT_FLTSVRTYCD;

typedef struct tagMGT_FAULTRECORD
{
	USHORT			usFaultRecordLength;
	TIMESTAMP		stFaultTimestamp;
	MGT_FLTSVRTYCD	enSeverityCode;
	LOGPTPTEXT_1	stFaultName;
	LOGPTPTEXT_2	stFaultValue;
	LOGPTPTEXT_3	stFaultDescription;

}	MGT_FAULTRECORD;

typedef	struct	tagMGD_CLOCK_DESCRIPTION
{
	BYTE			byClockType;
	FIXPTPTEXT		stPhyLayerPrtcl;
	USHORT			usPhyAddrLength;
	UCHAR			uchPhysAddress[16];
	FIXPORTADDRESS	stPrtclAddress;
	UCHAR			uchManufctrId[3];
	FIXPTPTEXT		stPrdctDscrption;
	FIXPTPTEXT		stRevisionData;
	FIXPTPTEXT		stUserDscrption;
	UCHAR			uchProfileId[6];

}	MGD_CLOCK_DESCRIPTION;

typedef struct tagMANAGEMENTSM_GD
{
	BYTE			byMgtAction;
	USHORT			usMgtRxMsgLen;
	UCHAR*			puchMgtRxMsg;
	PORTIDENTITY	stMgtTagetPortId;
	PORTIDENTITY	stMgtsourcePortId;
	UCHAR			uchMgtInterFaceNo;
	USHORT			usTxMgtMsgLen;
	ULONG			ulTxMgtMsg[(MGT_FRAME_BUFF_SIZE+sizeof(ULONG)-1)/sizeof(ULONG)];

	MGD_CLOCK_DESCRIPTION	stMGTClockDscrption;

} MANAGEMENTSM_GD;

#endif
