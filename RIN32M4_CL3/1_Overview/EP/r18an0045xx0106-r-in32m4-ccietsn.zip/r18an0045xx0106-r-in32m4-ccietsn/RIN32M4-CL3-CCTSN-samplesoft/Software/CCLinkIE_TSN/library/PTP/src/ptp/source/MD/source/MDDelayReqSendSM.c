/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDDelayReqSendSM.h"
#ifdef	PTP_USE_IEEE1588
#include "MDDelayReqSendSM_1588.h"
#endif


VOID MDDelayReqSendSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDDelayReqSendSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM, PTP_LOGVE_82000002);
	return;
}

MDDREQSDSM_GD* GetMDDReqSndSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDDReqSndSM_GD;
}

MDDREQSNDSM_EV GetMDDReqSndEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDDREQSNDSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDDRQS_E_BEGIN;
		break;
		case PTP_EV_FOR_MDDLRQSND_RCVDDLRQ:
			enEvt = MDDRQS_E_RCVD_MDDELAY_REQ;
		break;
		case PTP_EV_RCVDMDTIMESTAMPRECEIVE:
			enEvt = MDDRQS_E_RCVD_MDTIMESTAMP_RCV;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDDRQS_E_CLOSE;
		break;

		default:
			enEvt = MDDRQS_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDDREQSNDSM_ST GetMDDReqSndStatus(PORTDATA* pstPort)
{
	MDDREQSDSM_GD*	pstGbl = NULL;
	MDDREQSNDSM_ST	enSts = MDDRQS_STATUS_MAX;

	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	if (pstGbl->enStsMDDReqSnd < MDDRQS_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDDReqSnd;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDDReqSndStatus(MDDREQSNDSM_ST enSts, PORTDATA* pstPort)
{
	MDDREQSDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDReqSndSMGlobal(pstPort);

	pstGbl->enStsMDDReqSnd = enSts;
	return;
}

BOOL SetMDDlyReqEvEgresTimestamp(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stEgMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstPortGD->stDelayReqEgressTimestamp,
			&pstSmGbl->stEgMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
		tsn_Wrapper_MemSet(&pstPortGD->stDelayReqIngressTimestamp, 0L, sizeof(TIMESTAMP));
		tsn_Wrapper_MemSet(&pstPortGD->stDelayRespCorrectionField, 0L, sizeof(FRAC_NSEC48));
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortGD->stDelayReqEgressTimestamp, 0L, sizeof(TIMESTAMP));
	}
	return blRet;
}
