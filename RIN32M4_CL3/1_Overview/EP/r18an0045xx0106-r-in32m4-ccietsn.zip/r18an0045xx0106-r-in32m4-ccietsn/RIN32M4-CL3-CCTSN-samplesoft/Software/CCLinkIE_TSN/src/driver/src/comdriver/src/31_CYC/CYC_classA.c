/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "NMG_common.h"
#include "CYC_common.h"
#include "cyclic_address.h"
#include "ccienx_app_supply.h"
#include "ACM_api.h"
#include "ccienx_api.h"
#include "INTR_api.h"
#include "CYC_api.h"

#define	OFFSET_TRN_SIDE_A_CLSA	(0x00000000)
#define	OFFSET_TRN_SIDE_B_CLSA	(TRNBUF_AXIADD_BASE_B-TRNBUF_AXIADD_BASE_A)
#define	OFFSET_TRN_SIDE_C_CLSA	(TRNBUF_AXIADD_BASE_C-TRNBUF_AXIADD_BASE_A)

NX_STATIC	NX_CONST	NX_ULONG	gaulCycAddrTbl[TRN_SIDE_SIZE] = {
	OFFSET_TRN_SIDE_A_CLSA,		OFFSET_TRN_SIDE_A_CLSA,	OFFSET_TRN_SIDE_B_CLSA,	OFFSET_TRN_SIDE_C_CLSA
};

NX_STATIC NX_ULONG ulCYC_DetectSwitchSwReadSide ( NX_VOID );
NX_STATIC NX_ULONG ulCYC_DetectDisconnectionClassA ( NX_VOID );
NX_STATIC NX_ULONG ulCYC_CheckRecvCycClassA ( NX_VOID );


NX_VOID vCYC_ExecGetCyclicRcvStsClassA (
	NX_CYC_RCV_STS *pstSts
)
{
	NX_ULONG	ulCycRcv			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulSwSucceed			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulRcvSide			=	(NX_ULONG)RCV_SIDE_A;
	NX_ULONG	ulCycSendSts		=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulDiscnct			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulChkSwitchRslt		=	(NX_ULONG)NX_OFF;
	
	ulCycSendSts = ulNX_GetCycSendSts();
	
	if ((NX_ULONG)NX_OFF == ulCycSendSts) {
		
		pstSts->usEstCom = (NX_USHORT)NX_OFF;
		pstSts->usCycRcv = (NX_USHORT)NX_OFF;
		pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
		pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
		pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
		pstSts->usHldClrSts = (NX_USHORT)NX_ON;
		pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
	}
	else {
		
		
		ulChkSwitchRslt = ulCYC_DetectSwitchSwReadSide();
		
		if ((NX_ULONG)NX_OFF == ulChkSwitchRslt) {
			
			ulDiscnct = ulCYC_DetectDisconnectionClassA();
			
			if ((NX_ULONG)NX_ON == ulDiscnct) {
				
				pstSts->usEstCom = (NX_USHORT)NX_OFF;
				pstSts->usCycRcv = (NX_USHORT)NX_OFF;
				pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
				pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
				pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
				pstSts->usHldClrSts = (NX_USHORT)NX_ON;
				pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
			}
			else {
				
				pstSts->usEstCom = (NX_USHORT)NX_ON;
				pstSts->usCycRcv = (NX_USHORT)NX_OFF;
				pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
				pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
				pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
				pstSts->usHldClrSts = gstCycCtrl.usHldClrStsPre;
				pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
			}
		}
		else {
			
			ulRcvSide = ulCYC_SwitchSwReadSide2(&ulSwSucceed);
			
			if ((NX_ULONG)NX_OFF == ulSwSucceed) {
				ulDiscnct = ulCYC_DetectDisconnectionClassA();
				
				if ((NX_ULONG)NX_ON == ulDiscnct) {
					pstSts->usEstCom = (NX_USHORT)NX_OFF;
					pstSts->usCycRcv = (NX_USHORT)NX_OFF;
					pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
					pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
					pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
					pstSts->usHldClrSts = (NX_USHORT)NX_ON;
					pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
				}
				else {
					pstSts->usEstCom = (NX_USHORT)NX_ON;
					pstSts->usCycRcv = (NX_USHORT)NX_OFF;
					pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
					pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
					pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
					pstSts->usHldClrSts = gstCycCtrl.usHldClrStsPre;
					pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
				}
			}
			else {
				
				ulCycRcv = ulCYC_ChkCycRcv(ulRcvSide);
				
				vCYC_UpdateAppErrFW(ulCycRcv);
				
				vCYC_ChkFirstCyclicRcv(ulCycRcv);
				
				if ((NX_ULONG)NX_OFF == ulCycRcv) {
					
					ulDiscnct = ulCYC_DetectDisconnectionClassA();
					
					if ((NX_ULONG)NX_ON == ulDiscnct) {
						
						pstSts->usEstCom = (NX_USHORT)NX_OFF;
						pstSts->usCycRcv = (NX_USHORT)NX_OFF;
						pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
						pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
						pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
						pstSts->usHldClrSts = (NX_USHORT)NX_ON;
						pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
					}
					else {
						
						pstSts->usEstCom = (NX_USHORT)NX_ON;
						pstSts->usCycRcv = (NX_USHORT)NX_OFF;
						pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
						pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
						pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
						pstSts->usHldClrSts = gstCycCtrl.usHldClrStsPre;
						pstSts->usClassACycReq = (NX_USHORT)NX_OFF;
					}
				}
				else {
					gstClassAInfo.ulNonRcvCnt = gstClassAInfo.ulNonRcvTimeOutCnt;
					
					if ((NX_USHORT)NX_ON == gstCycCtrl.stAppErr.usRcvCycDataDis) {
						
						pstSts->usEstCom = (NX_USHORT)NX_ON;
						pstSts->usCycRcv = (NX_USHORT)NX_OFF;
						pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][RCV_SIDE_A];
						pstSts->ulAddrRWw = gaulRWwAddrTbl[RCV_SIDE_A];
#ifdef SAFETY_PDU_ENABLE
						pstSts->ulAddrSpduy = gaulSpduyAddrTbl[RCV_SIDE_A];
#endif
						pstSts->usHldClrSts = (NX_USHORT)NX_ON;
						pstSts->usClassACycReq = (NX_USHORT)NX_ON;
					}
					else {
						
						pstSts->usEstCom = (NX_USHORT)NX_ON;
						pstSts->usCycRcv = (NX_USHORT)NX_ON;
						pstSts->ulAddrRY = gaulRyAddrTbl[gstAppInfo.stLibInfo.usLibMode][ulRcvSide];
						pstSts->ulAddrRWw = gaulRWwAddrTbl[ulRcvSide];
#ifdef SAFETY_PDU_ENABLE
						pstSts->ulAddrSpduy = gaulSpduyAddrTbl[ulRcvSide];
#endif
						pstSts->usHldClrSts = gstCycCtrl.stAppErr.usHldClrEn;
						pstSts->usClassACycReq = (NX_USHORT)NX_ON;
					}
				}
			}
		}
	}
	gstCycCtrl.usHldClrStsPre = pstSts->usHldClrSts;
	
	return;
}

NX_STATIC NX_ULONG ulCYC_DetectDisconnectionClassA ( NX_VOID )
{
	ULONG	ulResult		=	(NX_ULONG)NX_OFF;
	ULONG	ulIpErr			=	(NX_ULONG)NX_OFF;
	ULONG	ulNotRcvdCycErr	=	(NX_ULONG)NX_OFF;
	
	
	if (NETSTS_DLINK == gstNM.stNet.usNetSts) {
		
		
		ulIpErr	=	ulCYC_DetectIpErr();
		
		if ((NX_ULONG)NX_ON == ulIpErr) {
			ulResult	=	(NX_ULONG)NX_ON;
		}
		
		ulNotRcvdCycErr	=	ulCYC_CheckRecvCycClassA();

		if ((NX_ULONG)NX_ON == ulNotRcvdCycErr) {
			ulResult	=	(NX_ULONG)NX_ON;
		}
	}
	
	if ((NX_ULONG)NX_ON == ulResult) {
		
		vCYC_DeactivateCyclicClassA();
		vNX_NotifyDLinkErr();
		vNMG_NotifyDLinkErr();
	}
	
	return(ulResult);
}

NX_ULONG ulCYC_SelectUnusedSideClassA ( NX_VOID )
{
	NX_ULONG	ulLatestWriteSide		=	TRN_SIDE_A;
	NX_ULONG	ulReadEnableSide		=	TRN_SIDE_A;
	NX_ULONG	ulSelectedUnusedSide	=	TRN_SIDE_A;
	
	ulLatestWriteSide = gstClassAInfo.ulLatestWriteSide;
	
	ulReadEnableSide = gstClassAInfo.ulReadEnableSide;
	
	ulSelectedUnusedSide	=	aulUnusedSideTbl[ulLatestWriteSide][ulReadEnableSide];
	
	return ulSelectedUnusedSide;
}


NX_STATIC NX_ULONG ulCYC_DetectSwitchSwReadSide ( NX_VOID )
{
	NX_ULONG	ulCycSizeZero		=	(NX_ULONG)NX_OFF;
	
	NX_ULONG	ulCycRcvA			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcvB			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulCycRcvC			=	(NX_ULONG)NX_OFF;
	NX_ULONG	ulSwitchSwReadSide	=	(NX_ULONG)NX_OFF;
	
	
	ulCycSizeZero = ulNX_ChkCycRcvNoData();
	
	if ((NX_ULONG)NX_ON == ulCycSizeZero) {
		ulCycRcvA = *(gpaulCycAlive[RCV_SIDE_A]);
		ulCycRcvA &= RCVFLGADDR_UNI;
		
		ulCycRcvB = *(gpaulCycAlive[RCV_SIDE_B]);
		ulCycRcvB &= RCVFLGADDR_UNI;
		
		ulCycRcvC = *(gpaulCycAlive[RCV_SIDE_C]);
		ulCycRcvC &= RCVFLGADDR_UNI;
	}
	else {
		ulCycRcvA	=	*(gpaulCycRevFlg[RCV_SIDE_A]);
		ulCycRcvA	&=	RCVFLGADDR_UNI;
		
		ulCycRcvB	=	*(gpaulCycRevFlg[RCV_SIDE_B]);
		ulCycRcvB	&=	RCVFLGADDR_UNI;
		
		ulCycRcvC	=	*(gpaulCycRevFlg[RCV_SIDE_C]);
		ulCycRcvC	&=	RCVFLGADDR_UNI;
	}
	
	if (((NX_ULONG)NX_ON == ulCycRcvA)
	 || ((NX_ULONG)NX_ON == ulCycRcvB)
	 || ((NX_ULONG)NX_ON == ulCycRcvC)
	) {
		ulSwitchSwReadSide	=	(NX_ULONG)NX_ON;
	}
	else {
		ulSwitchSwReadSide	=	(NX_ULONG)NX_OFF;
	}
	return ulSwitchSwReadSide;
}


NX_VOID vCYC_DeactivateCyclicClassA ( NX_VOID )
{
	NGN_RN->R_RNCTRL.BITS.b01ZCycRcvCtrlFuncEnable	= (NX_ULONG)NX_ZERO;
	
	
	return;
}

NX_VOID vCYC_SetCycDisClassA ( NX_VOID )
{
	ASIC_RTNDIS1_Bits*	pstTnDescNo0_1	= NX_NULL;
	ASIC_RTNDIS2_Bits*	pstTnDescNo0_2	= NX_NULL;
	ASIC_RTNDIS1_Bits*	pstTnDescNo1_1	= NX_NULL;
	ASIC_RTNDIS2_Bits*	pstTnDescNo1_2	= NX_NULL;

	ASIC_RTNDIS1_Bits*	pstPreTnDescNo0_1;
	ASIC_RTNDIS1_Bits*	pstPreTnDescNo1_1;
	ASIC_RTNPDU2_Bits*	pstPdDesc2;

	NX_ULONG			ulReadEnableSide;
	NX_ULONG			ulAddOffsetAddress = (NX_ULONG)NX_ZERO;
	NX_USHORT			usSndDiscNextNo;
	NX_ULONG			ulDiscEndFlg;
	NX_USHORT			usRxAddrTblIndex = (NX_USHORT)NX_ZERO;

	NX_USHORT			usLoop;
	NX_USHORT			usTrnDescNo;

	usSndDiscNextNo	=	TRNDISC_NO_NXT;
	ulDiscEndFlg	=	(NX_ULONG)NX_ON;

	gstClassAInfo.ulReadEnableSide = gstClassAInfo.ulLatestWriteSide;
	
	ulReadEnableSide = gstClassAInfo.ulReadEnableSide;
	
	ulAddOffsetAddress = gaulCycAddrTbl[ulReadEnableSide];

	for (usLoop = NX_ZERO; usLoop < TRN_SPLD_NUM; usLoop++) {
		if (NX_ON == gstNET.stCyc.stTrnSubPayL[usLoop].uchDataExist) {
			pstPdDesc2 = (ASIC_RTNPDU2_Bits*)&NGN_CN_TNDIS_REG->R_TNPDU[usLoop].ASIC_rtnpdu2.BITS;
			pstPdDesc2->b1AZSndDataAddr = ulAddOffsetAddress + gstNET.stCyc.stTrnSubPayL[usLoop].ulSndDataAddr;
		}
		else {
			break;
		}
	}

	vNMG_GetSettingValueSndDiscClassA();
	
	if ((NX_USHORT)NX_TWO == gstClassAInfo.usDiscEnableNum) {
		pstTnDescNo0_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
		pstTnDescNo0_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis2.BITS;
		pstTnDescNo1_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis1.BITS;
		pstTnDescNo1_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis2.BITS;
		
		pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO1;
		pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
		pstTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;
		
		if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor0) {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}
		
		pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)usSndDiscNextNo;
		pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= ulDiscEndFlg;
		pstTnDescNo1_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;
		
		if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor1) {
			pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}
		
	}
	else if ((NX_USHORT)NX_ONE == gstClassAInfo.usDiscEnableNum){
		pstTnDescNo0_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
		pstTnDescNo0_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis2.BITS;

		pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)usSndDiscNextNo;
		pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= ulDiscEndFlg;
		pstTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;
		
		if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor0) {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}
	}
	else {
	}

	pstTnDescNo0_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
	pstTnDescNo1_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis1.BITS;
	for (usTrnDescNo = (NX_USHORT)NX_TWO; usTrnDescNo < gstNET.stCyc.usTrnFrameNum; usTrnDescNo += (NX_USHORT)NX_TWO) {
		pstPreTnDescNo0_1 = pstTnDescNo0_1;
		pstPreTnDescNo1_1 = pstTnDescNo1_1;
		pstTnDescNo0_1    = (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0 + usTrnDescNo].ASIC_rtndis1.BITS;
		pstTnDescNo0_2    = (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0 + usTrnDescNo].ASIC_rtndis2.BITS;
		pstTnDescNo1_1    = (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1 + usTrnDescNo].ASIC_rtndis1.BITS;
		pstTnDescNo1_2    = (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1 + usTrnDescNo].ASIC_rtndis2.BITS;

		if ((NX_USHORT)NX_TWO == gstClassAInfo.usDiscEnableNum) {
			pstPreTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
			pstPreTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
			pstPreTnDescNo1_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

			pstTnDescNo0_1->b0BZSndDiscriptNextNo		= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo + NX_ONE);
			pstTnDescNo0_1->b01ZSndDiscriptEndFlag		= (NX_ULONG)NX_OFF;
			pstTnDescNo0_1->b01ZFrameFlag				= (NX_ULONG)NX_ON;

			if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor0) {
				pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
				pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
			}
			else {
				pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
				pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
			}

			pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
			pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
			pstTnDescNo1_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

			if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor1) {
				pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
				pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
			}
			else {
				pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
				pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
			}
		}
		else if ((NX_USHORT)NX_ONE == gstClassAInfo.usDiscEnableNum){
			pstPreTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
			pstPreTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
			pstPreTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

			pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
			pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
			pstTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

			if ((NX_USHORT)NX_PORT1 == gstClassAInfo.usDescriptor0) {
				pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
				pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
			}
			else {
				pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
				pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
			}
		}
		else {
		}
	}

	NGN_CN_TN1_REG->R_MUSLOTF.BITS.b0BZSndDiscriptTopNo = (NX_USHORT)TRNDISC_NO0;
	
	return;
}

NX_VOID vCYC_CycTxCompClassA (
	NX_ULONG ulTimeoutState
)
{
	ASIC_RTNDIS1_Bits*	pstTnDescNo0_1	= NX_NULL;
	ASIC_RTNDIS1_Bits*	pstTnDescNo1_1	= NX_NULL;
	
	pstTnDescNo0_1	= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
	pstTnDescNo1_1	= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis1.BITS;
	
	pstTnDescNo0_1->b01ZFrameFlag		= (NX_ULONG)NX_OFF;
	pstTnDescNo1_1->b01ZFrameFlag		= (NX_ULONG)NX_OFF;
	
	return;
}

NX_STATIC NX_ULONG ulCYC_CheckRecvCycClassA ( NX_VOID )
{
	NX_ULONG	ulResult		= (NX_ULONG)NX_OFF;
	
	if ((NX_ULONG)NX_ZERO < gstClassAInfo.ulNonRcvCnt) {
		gstClassAInfo.ulNonRcvCnt--;
		if ((NX_ULONG)NX_ZERO < gstClassAInfo.ulNonRcvCnt) {
		}
		else {
			ulResult = (NX_ULONG)NX_ON;
		}
	}
	else {
		ulResult = (NX_ULONG)NX_ON;
	}
	
	return ulResult;
}

NX_VOID vCYC_SetTimeoutSettingClassA (
	NX_ULONG	ulSettingTime
)
{
	NX_ULONG	ulTimeoutCount;
	
	ulTimeoutCount = (ulSettingTime / (NX_ULONG)gstAppInfo.stFuncInfo.usCycDataPeriodic) + (NX_ULONG)1;
	gstClassAInfo.ulNonRcvCnt 			= ulTimeoutCount;
	gstClassAInfo.ulNonRcvTimeOutCnt 	= ulTimeoutCount;
	
	return;
}

/*[EOF]*/
