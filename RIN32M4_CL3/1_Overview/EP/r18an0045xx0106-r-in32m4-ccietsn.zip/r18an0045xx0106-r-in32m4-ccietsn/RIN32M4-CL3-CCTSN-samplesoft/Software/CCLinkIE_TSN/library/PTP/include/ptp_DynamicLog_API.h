/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_DYNAMICLOG_H__
#define __PTP_DYNAMICLOG_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#define	PTP_LOGID_EMERG			(0)
#define	PTP_LOGID_ALERT			(1)
#define	PTP_LOGID_CRIT			(2)
#define	PTP_LOGID_ERROR			(3)
#define	PTP_LOGID_WARNING		(4)
#define	PTP_LOGID_NOTICE		(5)
#define	PTP_LOGID_INFO			(6)
#define	PTP_LOGID_DEBUG			(7)


typedef	enum tagLOGOPERATE {
	LOG_OPERATE_START = 0,
	LOG_OPERATE_STOP,
	LOG_OPERATE_MAX
} LOGOPERATE;

 typedef	struct	tagPTP_LOGRECORD
{
	USHORT		usLogLength;
	USHORT		usLogID;
	TIMESTAMP	stLogRcrdTime;
	UCHAR		uchDomainNum;
	UCHAR		ucReserve;
	USHORT		usLogNameID;
	ULONG		ulLogVal;
} PTP_LOGRECORD;


typedef void (* LOGCB)(
	PTP_LOGRECORD*		pstLogRecord);





#ifdef __cplusplus
extern "C" {
#endif

INT	ptp_LogOperate(USHORT usLogID, LOGOPERATE enOparate);


INT	ptp_SetLogCallBack(USHORT usLogID, LOGCB pfnLogCBFunc);


#ifdef __cplusplus
}
#endif


#endif


