/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __INIT_COMMONIP_H_INCLUDE__
#define __INIT_COMMONIP_H_INCLUDE__

#include "nx_common.h"

NX_VOID vINIT_commonip_cn ( NX_VOID );
NX_VOID vINIT_commonip_rc ( NX_VOID );
NX_VOID vINIT_commonip_rx ( NX_VOID );
NX_VOID vINIT_commonip_sn ( NX_VOID );
NX_VOID vINIT_commonip_ts ( NX_VOID );
NX_VOID vINIT_commonip_tx ( NX_VOID );
NX_VOID vINIT_commonip_txdisc ( NX_VOID );
NX_VOID vINIT_commonip_ax ( NX_VOID );
NX_VOID vINIT_commonip_cr ( NX_VOID );
NX_VOID vINIT_commonip_em ( NX_VOID );
NX_VOID vINIT_commonip_es ( NX_VOID );
NX_VOID vINIT_commonip_gm ( NX_VOID );
NX_VOID vINIT_commonip_ir ( NX_VOID );
NX_VOID vINIT_commonip_md ( NX_VOID );
NX_VOID vINIT_commonip_rf ( NX_VOID );
NX_VOID vINIT_commonip_rg ( NX_VOID );
NX_VOID vINIT_commonip_sc ( NX_VOID );
NX_VOID vINIT_commonip_wd ( NX_VOID );
NX_VOID vINIT_commonip_rcrlyvl ( NX_VOID );
#endif
/*[EOF]*/
