/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#define NX_GLOBAL_ENTITY
#include "nx_common.h"
#include "ccienx_global.h"

NX_APP_INFO gstAppInfo;

/*[EOF]*/
