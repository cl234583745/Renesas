/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_MMNG_SV_L_H_INCLUDED__
#define __ST_SNC_MMNG_SV_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_stk_l.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_stk_l.h>
#else
#include "ST_SNC_mib.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_stk_l.h"
#endif
#endif

#define  ST_SNC_ZEROPAD			('\0')

typedef enum  {
	ST_SNC_MEMORY_READ,
	ST_SNC_MEMORY_WRITE
} ST_SNC_MemoryRWType;

typedef enum {
	ST_SNC_MEMCNT_1ST,
	ST_SNC_MEMCNT_2ND,
	ST_SNC_MEMCNT_MAX,
} ST_SNC_MemoryCount;

#ifdef SWPS
#else
typedef struct ST_SNC_MemoryCountObject_TAG {
	const NX_UCHAR					ucUse;
	NX_UCHAR						ucPadding[3];
	ST_SNC_MemoryCount			eRead;
	ST_SNC_MemoryCount			eWrite;
} ST_SNC_MemoryCountObject;

typedef struct ST_SNC_MemoryObject_TAG {
	ST_SNC_MemoryCountObject	stCnt;
	ST_SNC_ExecObj*				pstObj[ST_SNC_MEMCNT_MAX];
	NX_VOID*						pvMib[ST_SNC_MEMCNT_MAX];
	NX_ULONG						ulSize;
} ST_SNC_MemoryObject;
#endif

extern NX_ULONG ulST_SNC_MibAlloc(NX_VOID);
extern NX_ULONG ulST_SNC_MibFree(NX_VOID);
extern NX_ULONG ulST_SNC_MibAllClear(NX_VOID);
#ifdef SWPS
#endif
extern NX_ULONG ulST_SNC_ObjLock(ST_SNC_Mibtype eMibType, ST_SNC_MemoryCount eMemCount);
extern NX_ULONG ulST_SNC_ObjUnlock(ST_SNC_Mibtype eMibType, ST_SNC_MemoryCount eMemCount);
extern NX_ULONG ulST_SNC_MibSetMemory(ST_SNC_Mibtype eMibType, const ST_SNC_MibMng* pstMib, const NX_VOID* pData);
extern NX_ULONG ulST_SNC_MibClearMemory(ST_SNC_Mibtype eMibType);
extern NX_ULONG ulST_SNC_MibGetAddr(ST_SNC_Mibtype eMibType, ST_SNC_MemoryRWType eMemType, NX_VOID** pAddr);
extern NX_ULONG ulST_SNC_MibGetAddrNolock(ST_SNC_Mibtype eMibType,	ST_SNC_MemoryRWType	eMemType, NX_VOID** pAddr);
extern NX_ULONG ulST_SNC_MibAllCommit(NX_VOID);
extern NX_USHORT ST_SNC_GetCounterErrOccurOdrNo(NX_VOID);
extern NX_VOID   ST_SNC_SetCounterErrOccurOdrNo(NX_USHORT usErrOccurOdrNo);
extern NX_VOID   ST_SNC_CountUpErrOccurOdrNo(NX_VOID);
#ifdef CURERR_OPTIONINFO_ENABLE
extern NX_VOID   ST_SNC_MibClearCurrentErrorController(NX_VOID*	pAddr);
extern NX_VOID   ST_SNC_MibClearCurrentErrorOption(NX_VOID*	pAddr, NX_USHORT usOptNum);
extern NX_USHORT ST_SNC_GetCounterOptionErrOccurOdrNo(NX_USHORT usOptNum);
extern NX_VOID   ST_SNC_SetCounterOptionErrOccurOdrNo(NX_USHORT usErrOccurOdrNo,NX_USHORT usOptNum);
extern NX_VOID   ST_SNC_CountUpOptionErrOccurOdrNo(NX_USHORT usOptNum);
#endif
#endif
