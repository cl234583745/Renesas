/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_STRUCT_H_INCLUDE__
#define __CCIENX_STRUCT_H_INCLUDE__

#include "ccienx_type.h"
#include "ccienx_const.h"
#include "ccienx_const_ex.h"

typedef struct tagNX_FUNC_INFO {
	NX_UCHAR	uchWdcEnableFlg;
	NX_UCHAR	uchNwSyncEnableFlg;
	NX_USHORT	usCycDataPeriodic;
} NX_FUNC_INFO;

typedef union tagNX_PTP_QLOCKQUALIRY_INFO {
	NX_ULONG	ulData;
	struct {
		NX_USHORT	usOffsetScaledLogVariance;
		NX_UCHAR	uchClockAccuracy;
		NX_UCHAR	uchClockClass;
	} mbr;
} NX_PTP_QLOCKQUALIRY_INFO;

typedef struct tagNX_PTP_INFO {
	NX_UCHAR					uchPriority1;
	NX_PTP_QLOCKQUALIRY_INFO	stClockQuality;
	NX_UCHAR					uchPriority2;
	NX_USHORT					usRsv1;
} NX_PTP_INFO;

typedef struct tagNX_CIEDEV_INFO {
	NX_USHORT	usDeviceVersion;
	NX_USHORT	usVendorCode;
	NX_ULONG	ulModelCode;
	NX_USHORT	usExModelCode;
	NX_USHORT	usDeviceType;
	NX_USHORT	usFwVersion;
	NX_USHORT	usHwVersion;
	NX_UCHAR	auchDeviceModelName[20];
	NX_UCHAR	auchVendorName[32];

	NX_UCHAR	auchSerialNumber[32];
	NX_UCHAR	auchCorresPondFunc[4];
	NX_UCHAR	uchNumberOfPort;
	NX_UCHAR	uchStationType;
	NX_UCHAR	uchOption;
	NX_UCHAR	uchReserved1;
	NX_USHORT	usNumOfSubID;
	NX_USHORT	usStationMode;
	NX_USHORT	usReserved2;
	NX_USHORT	usReserved1;
} NX_CIEDEV_INFO;

typedef struct tagNX_ETH_INFO {
	NX_UCHAR	auchMacAddress[6];
	NX_ULONG	ulIPAddressWup;
	NX_ULONG	ulSubnetMaskWup;
	NX_ULONG	ulIPAddress_Flash;
	NX_ULONG	ulSubnetMask_Flash;
	NX_USHORT	usRsv1;
	NX_ULONG	ulJadeRj45ConnectType;
	NX_ULONG	ulLinkSpd;
} NX_ETH_INFO;

typedef struct tagNX_CIENET_INFO {
	NX_USHORT	usMaxSizeRX;
	NX_USHORT	usMaxSizeRWr;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usMaxSizeSpdux;
#endif
	NX_USHORT	usMaxSizeRY;
	NX_USHORT	usMaxSizeRWw;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usMaxSizeSpduy;
#endif
	NX_USHORT	usDefaultSizeRX;
	NX_USHORT	usDefaultSizeRWr;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usDefaultSizeSpdux;
#endif
	NX_USHORT	usDefaultSizeRY;
	NX_USHORT	usDefaultSizeRWw;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usDefaultSizeSpduy;
#endif
	NX_USHORT	usIpSw;
	NX_USHORT	usRsv1;
	NX_ULONGLONG	ullComCycleMin;
	NX_ULONGLONG	ullComCycleMax;
} NX_CIENET_INFO;

typedef struct tagNX_LIB_INFO {
	NX_USHORT	usLibMode;
	NX_USHORT	usRsv1;
	NX_ULONG	ulFreeArea;
} NX_LIB_INFO;

typedef struct tagNX_TRN_SPLD_WDC_INFO {
	NX_USHORT				usWdcRegNo;
	NX_USHORT				usWdcOffset;
} NX_TRN_SPLD_WDC_INFO;

typedef struct tagNX_RCV_SPLD_WDC_INFO {
	NX_USHORT				usWdcRegNo;
	NX_USHORT				usWdcOffset;
} NX_RCV_SPLD_WDC_INFO;

typedef struct tagNX_WDC_INFO {
	NX_TRN_SPLD_WDC_INFO	stTrnSpldWdcInfo;
	NX_RCV_SPLD_WDC_INFO	stRcvSpldWdcInfo;
} NX_WDC_INFO;

typedef struct tagNX_ACM_INFO {
	NX_USHORT				usAuthClass;
	NX_USHORT				usCycResTime ;
} NX_ACM_INFO;

typedef struct tagNX_APP_INFO {
	NX_FUNC_INFO		stFuncInfo;
	NX_PTP_INFO			stPtpInfo;
	NX_CIEDEV_INFO		stCieDevInfo;
	NX_ETH_INFO			stEthInfo;
	NX_CIENET_INFO		stCieNetInfo;
	NX_LIB_INFO			stLibInfo;
	NX_WDC_INFO			stWdcInfo;
	NX_ACM_INFO			stAuthInfo;
} NX_APP_INFO;

typedef struct tagNX_CYC_RCV_STS {
	NX_USHORT	usEstCom;
	NX_USHORT	usCycRcv;
	NX_ULONG	ulAddrRY;
	NX_ULONG	ulAddrRWw;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG	ulAddrSpduy;
#endif
	NX_ULONG	ulAddrTest;
	NX_USHORT	usHldClrSts;
	NX_USHORT	usClassACycReq;
} NX_CYC_RCV_STS;

typedef struct tagNX_CYC_TRN_STS {
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRX[NX_SPLD_NUM_RX];
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRWr[NX_SPLD_NUM_RWR];
#ifdef SAFETY_PDU_ENABLE
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stSpdux[NX_SPLD_NUM_SPDUX];
#endif
	NX_USHORT		usRxNum;
	NX_USHORT		usRWrNum;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT		usSpduxNum;
#endif
} NX_CYC_TRN_STS;

typedef struct tagNX_TESTLED_SELECT	{
	NX_ULONG	ulRUNSel;
	NX_ULONG	ulDLINKSel;
	NX_ULONG	ulERRSel;
	NX_ULONG	ulLink1Sel;
	NX_ULONG	ulLink2Sel;
} NX_TESTLED_SELECT;

typedef struct tagNX_TESTLED_RUN	{
	NX_ULONG	ulRUNOnOff;
	NX_ULONG	ulDLINKOnOff;
	NX_ULONG	ulERROnOff;
	NX_ULONG	ulLink1OnOff;
	NX_ULONG	ulLink2OnOff;
} NX_TESTLED_RUN;

typedef struct tagNX_TRN_RCV_INFO {
	NX_ULONG	ulSrcIp;
	NX_USHORT	usSrcPort;
	NX_USHORT	usPhysicalPort;
	NX_USHORT	usRsv;
	NX_UCHAR*	puchFrameAdr;
	NX_USHORT	usFrameSize;
} NX_TRN_RCV_INFO;

typedef struct tagNX_TRN_SND_INFO {
	NX_ULONG	ulDstIp;
	NX_USHORT	usDstPort;
	NX_UCHAR*	puchFrameAdr;
	NX_USHORT	usFrameSize;
	NX_USHORT	usPhysicalPort;
	NX_USHORT	usRsv;
} NX_TRN_SND_INFO;

typedef struct tagNX_APP_MODE {
	NX_USHORT	usSyncMode;
	NX_USHORT	usUseWDC;
} NX_APP_MODE;

typedef struct tagNX_CYC_PRM {
	NX_USHORT	usSizeRX;
	NX_USHORT	usSizeRWr;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usSizeSpdux;
#endif
	NX_USHORT	usSizeRY;
	NX_USHORT	usSizeRWw;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT	usSizeSpduy;
#endif
} NX_CYC_PRM;

typedef struct tagNX_RCV_CYC_ADDR {
	NX_ULONG	ulAddrRY_A;
	NX_ULONG	ulAddrRWw_A;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG	ulAddrSpduy_A;
#endif
	NX_ULONG	ulAddrRY_B;
	NX_ULONG	ulAddrRWw_B;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG	ulAddrSpduy_B;
#endif
	NX_ULONG	ulAddrRY_C;
	NX_ULONG	ulAddrRWw_C;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG	ulAddrSpduy_C;
#endif
} NX_RCV_CYC_ADDR;

typedef struct tagNX_TRN_SPLD_INFO {
	NX_ULONG	ulAddr[3];
	NX_USHORT	usSize;
} NX_TRN_SPLD_INFO;

typedef struct tagNX_TRN_CYC_ADDR {
	NX_TRN_SPLD_INFO stRX[NX_SPLD_NUM_RX];
	NX_TRN_SPLD_INFO stRWr[NX_SPLD_NUM_RWR];
#ifdef SAFETY_PDU_ENABLE
	NX_TRN_SPLD_INFO stSpdux[NX_SPLD_NUM_SPDUX];
#endif

	NX_USHORT		usRxNum;
	NX_USHORT		usRWrNum;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT		usSpduxNum;
#endif
} NX_TRN_CYC_ADDR;

typedef struct tagNX_RECOG_SLMP_INFO {
	NX_USHORT	usSubHeader;
	NX_USHORT	usCmd;
	NX_USHORT	usSubCmd;
} NX_RECOG_SLMP_INFO;

typedef struct tagNX_SLMP_TRAN_RECOG_INFO {
	NX_USHORT	usSubHeader;
	NX_USHORT	usSerialNo;
	NX_USHORT	usCmd;
	NX_USHORT	usSubCmd;
} NX_SLMP_TRAN_RECOG_INFO;

typedef struct tagNX_IPADDR_INFO {
	NX_ULONG	ulIPAddress;
	NX_ULONG	ulSubnetMask;
} NX_IPADDR_INFO;



typedef struct tagNX_UNIX_TIME {
	NX_ULONG		ulUnixTime_ns;
	NX_ULONGLONG	ullUnixTime_s;
	NX_SHORT		sUtcOffsetMin;
	NX_SHORT		sSummerTimeOffsetMin;
} NX_UNIX_TIME;

typedef struct tagNX_UNIX_TIME_KEEP {
	NX_ULONG	ulUnixTime_ns;
	NX_ULONG	ulUnixTime_s;
} NX_UNIX_TIME_KEEP;

typedef struct tagNX_CALENDAR {
	NX_ULONG	ulYear;
	NX_ULONG	ulMonth;
	NX_ULONG	ulDay;
	NX_ULONG	ulHour;
	NX_ULONG	ulMinute;
	NX_ULONG	ulSecond;
	NX_UCHAR	ucDayOfTheWeek;
	NX_UCHAR	ucMilliSec_High;
	NX_UCHAR	ucMilliSec_Low;
	NX_UCHAR	ucAdjust;
	NX_ULONG	ulMicroSec;
	NX_ULONG	ulNanoSec;
} NX_CALENDAR;

#pragma pack(1)
typedef struct tagLED_STATUS {
	NX_UCHAR	uchColor;
	NX_UCHAR	uchStatus;
} NX_LED_STATUS;
#pragma pack()

typedef struct tagNX_SYNC_COMCYC_INFO {
	NX_UCHAR		uchTimeslotNum;
	NX_UCHAR		uchRsv;
	NX_USHORT		usRptCnt;
	NX_ULONGLONG	aullTsStartTime[NX_TIMESLOT_SIZE];
	NX_ULONGLONG	aullTsEndTime[NX_TIMESLOT_SIZE];
	NX_ULONGLONG	ullComCycle;
} NX_SYNC_COMCYC_INFO;

#endif
/*[EOF]*/
