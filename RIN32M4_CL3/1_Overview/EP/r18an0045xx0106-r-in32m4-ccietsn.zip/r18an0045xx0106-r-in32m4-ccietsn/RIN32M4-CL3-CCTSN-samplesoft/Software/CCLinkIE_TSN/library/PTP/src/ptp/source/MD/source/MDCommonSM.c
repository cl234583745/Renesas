/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "PTP_GlobalData.h"
#include "ptp_CommonFunction.h"
#include "MDCommonSM.h"
#include "ptp_CMSReceive.h"
#include "ptp_LCEntity.h"


#ifdef	PTP_USE_IEEE802_1
BOOL IsMDCOMSupportPTPTyp802_1AS(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;
	if (pstClock_DT == NULL)
	{
		return blRet;
	}
	if(pstClock_DT->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	return blRet;
}

#endif

#ifdef	PTP_USE_IEEE1588
BOOL IsMDCOMSupportPTPTyp1588(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;
	if (pstClock_DT == NULL)
	{
		return blRet;
	}
	if(pstClock_DT->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	
	return blRet;
}

BOOL IsMDCOMClockSupportTypOC(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;

	if(pstClock_DT->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588
		== ENUM_CSTYPE_ORDINARYCLOCK_1588){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	
	return blRet;
}

BOOL IsMDCOMClockSupportTypBC(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;

	if(pstClock_DT->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588
		== ENUM_CSTYPE_BOUNDARYCLOCK_1588){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	
	return blRet;
}

BOOL IsMDCOMClockSupportTypTC_E2E(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;

	if(pstClock_DT->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588
		== ENUM_CSTYPE_TRANSCLOCKE2E_1588){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	
	return blRet;
}

BOOL IsMDCOMClockSupportTypTC_P2P(PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	CLOCKDATA* pstClock_DT = pstPort->pstClockData;

	if(pstClock_DT->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588
		== ENUM_CSTYPE_TRANSCLOCKP2P_1588){
		blRet = TRUE;
	}else{
		blRet = FALSE;
	}
	
	return blRet;
}

#endif

#ifndef	PTP_USE_ME_HW_ASSIST
BOOL GetMDCOMClockTime(CLOCKDATA* pstClock, ENUM_MDCOM_TIMERTYPE enTMType, TIMESTAMP* pstTimestamp)
{
	BOOL	blRet = FALSE;
	BOOL	blConvRet = FALSE;


	EXTENDEDTIMESTAMP	stMasterTime	= {0};


	TIMESTAMP			stTimestamp;
	ptp_GetCurrentDriverTime(pstClock->stDefaultDS.uchDomainNumber, &stMasterTime);

	blConvRet = ptpConvETS_TS(&stMasterTime, &stTimestamp);
	if (blConvRet)
	{
		*pstTimestamp = stTimestamp;
		blRet = TRUE;
	}
	return blRet;
}
#endif

VOID GetMDCOMTimeStampNs(TIMESTAMP* pstA_TimeStamp, TIMESTAMP* pstB_TimeStamp)
{

	*pstB_TimeStamp = *pstA_TimeStamp;
	return;
}

VOID ClrMDCOMTimeStampNs(TIMESTAMP* pstA_TimeStamp, TIMESTAMP* pstB_TimeStamp)
{
	*pstB_TimeStamp = *pstA_TimeStamp;
	return;
}
