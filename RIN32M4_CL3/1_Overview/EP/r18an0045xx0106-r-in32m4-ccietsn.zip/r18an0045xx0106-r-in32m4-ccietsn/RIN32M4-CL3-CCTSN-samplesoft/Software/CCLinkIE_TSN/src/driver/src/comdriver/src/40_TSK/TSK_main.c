/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "itron.h"
#include "kernel.h"
#include "NMG_api.h"
#include "TSN_api.h"
#include "SLMP_api.h"
#include "GDN_api.h"
#include "PHY_api.h"
#include "USN_api.h"
#include "LOG_api.h"
#include "INTR_api.h"
#include "NMG_common.h"


#if 1	/* Modification for R-IN32M4 */
extern NX_VOID gvLedBlinkUserLed(NX_VOID);
#endif

NX_VOID vNX_Task_ComDriverPeriodic ( VP_INT exinf )
{
	while (1) {
		(NX_VOID)slp_tsk();
		vNMG_MngPeriodicMain();
		vPHY_UpdatePhySts();
		vUSN_UsnetPeriodic();
		vSLMP_Main();
		ulINTR_CheckIntAxiBusErr();
	}
}

NX_VOID vNX_Task_IpFrameComm ( VP_INT exinf )
{
	while (1) {
		(NX_VOID)slp_tsk();
		vUSN_IpFrameComm();
	}
}

NX_VOID vNX_Task_TSNPeriodic ( VP_INT exinf )
{
	while (1) {
		(NX_VOID)slp_tsk();
		vTsn_TsnPeriodicMain();
	}
}

NX_VOID vNX_Task_RelayRamClr ( VP_INT exinf )
{
	while (1) {
		vNMG_RelayRamClr();
	}
}

#if 1	/* Modification for R-IN32M4 */
NX_VOID vNX_Task_LEDPeriodic ( VP_INT exinf )
{
	while (1) {
		(NX_VOID)slp_tsk();
		gvLedBlinkUserLed();
	}
}
#endif
/*[EOF]*/
