/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_detection.h"
#include "TOOL_api.h"
#include "NGN_ASIC.h"
#include "cyclic_memmap.h"
#include "CYC_common.h"
#include "TXN_api.h"
#include "RXN_api.h"
#include "TSN_api.h"
#include "kernel.h"
#include "ccienx_api.h"
#include "ccienx_app_supply.h"
#include "ccienx_task.h"
#include "INTR_api.h"
#include "NMG_api.h"
#include "NMG_self_spec.h"
#include "CYC_api.h"
#include "USN_api.h"
#include "TXN_main.h"
#include "LSM_api.h"
#include "SYNC_api.h"
#include "PHY_api.h"
#include "ACM_api.h"

#define	CYC_ACT_MARGIN		((NX_ULONGLONG)2000)
#define	CYC_ACT_MARGIN_100M	((NX_ULONGLONG)5000)
#define	DETEC_WAIT_TIME		((NX_ULONG)5000)
#define	RNBKSEL_1G			((NX_ULONG)0x00000000)
#define	RNBKSEL_100M		((NX_ULONG)0x00000055)
#define	CNTEN_100M			((NX_ULONG)0x00000001)
#define	CNTDI_100M			((NX_ULONG)0x00000000)
#define	TSLTMAG_1G			((NX_ULONG)0x00000000)
#define	TSLTMAG_100M		((NX_ULONG)0x00000001)
#define	OFFSET_BORDER_TIMESLOT_18US		((NX_ULONGLONG)18000)
#define TSNENABLE_TBLSIZE	(TSLT_SIZE_MAX + 1)
#define RLYRAMINIT_TS012	((NX_ULONG)0x00070007)
#define RCRLYVL_RLYENBL		((NX_ULONG)0x00000003)
#define RCRLYVL_CYCRLYENBL	((NX_ULONG)0x00000C00)
#define RLYDISABLE_WAIT		((NX_ULONGLONG)3)

#define	P1_RLY_DI			((NX_ULONG)0x00000801)
#define	P2_RLY_DI			((NX_ULONG)0x00000402)
#define	P1_P2_RLY_DI		((NX_ULONG)0x00000003)
#define	P1_RLYRAM_CLR		((NX_ULONG)0x000000FF)
#define	P2_RLYRAM_CLR		((NX_ULONG)0x00FF0000)
#define	P1_P2_RLYRAM_CLR	((NX_ULONG)0x00FF00FF)

#define	FLGP_RLYRAMCLR_WAIT	(FLGP_LINKDOWN_P1 | FLGP_LINKDOWN_P2 | FLGP_RAMOVRFLW_P1 | FLGP_RAMOVRFLW_P2)

#define	TCPXTON_TS_EN	((NX_ULONG)(0x00000100))

#define	VLAN_TYPE	((NX_ULONG)(0x81000000))
#define	NWTIME_IDX_NS		((NX_ULONG)0)
#define	NWTIME_IDX_SEC		((NX_ULONG)4)
#define	NWTIME_SIZE_NS		((NX_ULONG)4)
#define	NWTIME_SIZE_SEC		((NX_ULONG)6)
#define	NWTIME_SIZE_SEC_MAX	((NX_ULONGLONG)0x00000000FFFFFFFF)
#define	NWTIME_SIZE_NS_MAX	((NX_ULONG)(0x3B9AC9FF))
#define	RLY_CLASSA_WAIT		((NX_ULONG)30)

NX_STATIC NX_CONST NX_ULONGLONG gaullNot8nsEnableTbl_8K[NX_NOT8NS_EN_TBL_NUM_8K][NX_CMN_IDX_SIZE_2] = {
	{NX_NSEC_31250		, (NX_ULONGLONG)NX_REMAIND_2	},
	{NX_NSEC_62500		, (NX_ULONGLONG)NX_REMAIND_4	}
};

NX_STATIC NX_CONST NX_ULONG gaulBitPatternTbl_8K[NX_BITPATTERN_8K_NUM] = {
	 NX_ZERO,
	 (NX_BIT8 | NX_BIT0),
	 (NX_BIT12 | NX_BIT8 | NX_BIT4 | NX_BIT0),
	 NX_ZERO,
	 (NX_BIT14 | NX_BIT12 | NX_BIT10 | NX_BIT8 | NX_BIT6 | NX_BIT4 | NX_BIT2 | NX_BIT0),
	 NX_ZERO,
	 NX_ZERO,
	 NX_ZERO
};



NX_STATIC NX_CONST NX_ULONG RelayRamRegTbl[16][NX_PORT_SIZE] = {
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{   P1_RLY_DI,		   P1_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{   P2_RLY_DI,		   P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR},
	{P1_P2_RLY_DI,		P1_P2_RLYRAM_CLR}
};

NX_STATIC NX_CONST volatile ASIC_RRE_FRMREG_TAG* FramePacketNumReg[NX_PORT_SIZE] = {
	&(NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1]),
	&(NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2])
};

NX_STATIC NX_CONST volatile ASIC_RRCRLFOV_Bits* RelayRamOverFlowFrameCntTsEn[NX_PORT_SIZE][TS_SIZE/2] = {
	{
	&(NGN_RC_REG->R_RCRLFOV1[0].BITS),
	&(NGN_RC_REG->R_RCRLFOV1[1].BITS),
	&(NGN_RC_REG->R_RCRLFOV1[2].BITS),
	&(NGN_RC_REG->R_RCRLFOV1[3].BITS)
	},
	{
	&(NGN_RC_REG->R_RCRLFOV2[0].BITS),
	&(NGN_RC_REG->R_RCRLFOV2[1].BITS),
	&(NGN_RC_REG->R_RCRLFOV2[2].BITS),
	&(NGN_RC_REG->R_RCRLFOV2[3].BITS)
	}
};

NX_STATIC NX_CONST volatile ASIC_RRCRLFOVC_Bits* RelayRamOverFlowFrameCntTsDi[NX_PORT_SIZE] = {
	&(NGN_RC_REG->R_RCRLFOVC1[0].BITS),
	&(NGN_RC_REG->R_RCRLFOVC2[0].BITS)
};

NX_STATIC NX_CONST FLGPTN	FLGP_RLYRAM_OVRFLW[NX_PORT_SIZE] = {
	FLGP_RAMOVRFLW_P1,
	FLGP_RAMOVRFLW_P2
};

typedef struct tagNM_SLMPBUF_ENTRY {
	NX_UCHAR	auchNetworkConfigMainResp[128];
	NX_UCHAR	auchNetworkConfigTsltResp[128];
	NX_UCHAR	auchSlaveConfigResp[128];
	NX_UCHAR	auchCyclicConfigMainResp[128];
	NX_UCHAR	auchCyclicConfigTrnSubPayloadResp[128];
	NX_UCHAR	auchCyclicConfigRcvSubPayloadResp[128];
	NX_UCHAR	auchCyclicConfigRcvSrcInfoResp[128];
	NX_UCHAR	auchNotificationReq[128];
	NX_UCHAR	auchNotificationResp[128];
} NM_SLMPBUF_ENTRY;

typedef struct ERR_FRAME_FLG_TAG {
	NX_ULONG	ulShortPacket;
	NX_ULONG	ulJumboFrame;
	NX_ULONG	ulRlyRamOvrFlwTs0;
	NX_ULONG	ulRlyRamOvrFlwTs1;
	NX_ULONG	ulRlyRamOvrFlwTs3;
	NX_ULONG	ulRlyRamOvrFlwTs4;
	NX_ULONG	ulRlyRamOvrFlwTs5;
	NX_ULONG	ulRlyRamOvrFlwTs6;
	NX_ULONG	ulRlyRamOvrFlwTs7;
} ERR_FRAME_FLG;

NX_STATIC	NX_CONST	NX_ULONG	gaulTnsEnableBitTbl[TSNENABLE_TBLSIZE] = {
	0x00000100,
	0x00000101,
	0x00000103,
	0x00000107,
	0x0000010F,
	0x0000011F,
	0x0000013F,
	0x0000017F,
	0x000001FF
};

NM_CTRL				gstNM;
NX_STATIC	NM_SLMPBUF_ENTRY	gstSlmpBufEntry;

NX_STATIC	NX_USHORT			gusDLinkLedLast;

NX_STATIC	CLOCK_OFFSET		gstClockOffset;

NX_STATIC	ERR_FRAME_FLG		gastErrFrameFlg[NX_PORT_SIZE];


NX_VOID		vNX_ChkNotifyFlg( NX_VOID );
NX_VOID		vNMG_UpdateDataLinkLed ( NX_VOID );
NX_VOID		vNX_ChkDuplicateIP ( NX_VOID );
NX_VOID		vNMG_DetectionWaitCheck ( NX_VOID );
NX_VOID		vNMG_CycleCnt100MEnable( NX_VOID );

NX_VOID vNMG_Init ( NX_VOID )
{
	NX_USHORT		usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NCYC_TX_FRAME	*pstFrameDetectionAck;
	NCYC_TX_FRAME	*pstFrameTestDataAck;
	
	vNX_FillMemory32((NX_VOID*)&gstNM, NX_ZERO, sizeof(NM_CTRL) / sizeof(NX_ULONG));
	
	vNX_FillMemory32((NX_VOID*)&gstSlmpBufEntry, NX_ZERO, sizeof(NM_SLMPBUF_ENTRY) / sizeof(NX_ULONG));
	
	vNMG_InitCieNetMngDt();
	
	gstNET.stSelf.ulIPAddress  = gstAppInfo.stEthInfo.ulIPAddressWup;
	gstNET.stSelf.ulSubnetMask = gstAppInfo.stEthInfo.ulSubnetMaskWup;
	
	usAuthClass 	= 	usACM_GetAuthenticationClass();	
	
	gstNM.uchSelfFunction   = gstAppInfo.stCieDevInfo.auchCorresPondFunc[0];

	gstNM.uchSelfFunction2  = ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT7) >> NX_SHIFT7);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT6) >> NX_SHIFT5);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT5) >> NX_SHIFT3);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT4) >> NX_SHIFT1);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT3) << NX_SHIFT1);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[2] & (NX_UCHAR)NX_BIT2) << NX_SHIFT3);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[3] & (NX_UCHAR)NX_BIT1) << NX_SHIFT5);
	gstNM.uchSelfFunction2 |= ((gstAppInfo.stCieDevInfo.auchCorresPondFunc[3] & (NX_UCHAR)NX_BIT0) << NX_SHIFT7);
	
	vNX_FillMemory32((NX_VOID*)&gstClockOffset, NX_L_ZERO, (sizeof(CLOCK_OFFSET) / sizeof(NX_ULONG)));
	gstClockOffset.sUtcOffsetMin		= DATE_DEFAULT_CLOCK_OFFSET;
	gstClockOffset.sSummerTimeOffsetMin	= DATE_DEFAULT_CLOCK_OFFSET;
	
	(NX_VOID)lTXN_AllocBuf_NonCycTx(NCYC_TXFRAME_TYPE_NOT_TSN,
							sizeof(FRM_DETECTIONACK_01),
							&(pstFrameDetectionAck)
							);
	gstNM.stTrnBuf.pstDetectionAck = pstFrameDetectionAck;
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		gstNM.stTrnBuf.pstDetectionAck->usTsNo = NCYC_TXFRAME_TS1;
	}
	else {
		gstNM.stTrnBuf.pstDetectionAck->usTsNo = NCYC_TXFRAME_TS0;
	}
	gstNM.stTrnBuf.pstDetectionAck->usFramFormat = NX_FRAME_NGN_NONCYC;
	gstNM.stTrnBuf.pstDetectionAck->usHeaderSize = (NX_USHORT)(SIZE_ETHERNET_HEADER_DA + SIZE_ETHERNET_HEADER_SA + SIZE_ETHERTYPE);
	gstNM.stTrnBuf.pstDetectionAck->pvCbfunc = (NCYC_TX_CALLBACK)vNMG_CallbackTrnDetectionAck;
	
	(NX_VOID)lTXN_AllocBuf_NonCycTx(NCYC_TXFRAME_TYPE_NOT_TSN,
							sizeof(FRM_TESTDATAACK),
							&pstFrameTestDataAck);
	gstNM.stTrnBuf.pstTestDataAck = pstFrameTestDataAck;
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		gstNM.stTrnBuf.pstTestDataAck->usTsNo = NCYC_TXFRAME_TS1;
	}
	else {
		gstNM.stTrnBuf.pstTestDataAck->usTsNo = NCYC_TXFRAME_TS0;
	}
	gstNM.stTrnBuf.pstTestDataAck->usFramFormat = NX_FRAME_NGN_NONCYC;
	gstNM.stTrnBuf.pstTestDataAck->usHeaderSize = (NX_USHORT)(SIZE_ETHERNET_HEADER_DA + SIZE_ETHERNET_HEADER_SA + SIZE_ETHERTYPE);
	gstNM.stTrnBuf.pstTestDataAck->usDataSize = (NX_USHORT)sizeof(FRM_TESTDATA) - gstNM.stTrnBuf.pstTestDataAck->usHeaderSize;
	gstNM.stTrnBuf.pstTestDataAck->pvCbfunc = (NCYC_TX_CALLBACK)vNMG_CallbackTrnTestDataAck;
	
	gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1 = NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN;
	gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2 = NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN;
	
	gstNM.stTrnBuf.puchNetworkConfigMainResp			=	(NX_UCHAR*)&(gstSlmpBufEntry.auchNetworkConfigMainResp);
	gstNM.stTrnBuf.puchNetworkConfigTsltResp			=	(NX_UCHAR*)&(gstSlmpBufEntry.auchNetworkConfigTsltResp);
	gstNM.stTrnBuf.puchSlaveConfigResp					=	(NX_UCHAR*)&(gstSlmpBufEntry.auchSlaveConfigResp);
	gstNM.stTrnBuf.puchCyclicConfigMainResp				=	(NX_UCHAR*)&(gstSlmpBufEntry.auchCyclicConfigMainResp);
	gstNM.stTrnBuf.puchCyclicConfigTrnSubPayloadResp	=	(NX_UCHAR*)&(gstSlmpBufEntry.auchCyclicConfigTrnSubPayloadResp);
	gstNM.stTrnBuf.puchCyclicConfigRcvSubPayloadResp	=	(NX_UCHAR*)&(gstSlmpBufEntry.auchCyclicConfigRcvSubPayloadResp);
	gstNM.stTrnBuf.puchCyclicConfigRcvSrcInfoResp		=	(NX_UCHAR*)&(gstSlmpBufEntry.auchCyclicConfigRcvSrcInfoResp);
	gstNM.stTrnBuf.puchNotificationReq					=	(NX_UCHAR*)&(gstSlmpBufEntry.auchNotificationReq);
	gstNM.stTrnBuf.puchNotificationResp					=	(NX_UCHAR*)&(gstSlmpBufEntry.auchNotificationResp);
	
	vNMG_InitCieNetMngSlmp();
	
	gstNM.stNet.usStatusFinish	= FIN_INITIAL;
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		gstNM.stNet.usStatusFinish	|=	FIN_TIMESYNC_CMP;
	}
	gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_INIT;

	gusDLinkLedLast	= NX_LED_OFF;

	vNX_FillMemory32((NX_VOID*)&gastErrFrameFlg, NX_L_ZERO, (sizeof(gastErrFrameFlg) / sizeof(NX_ULONG)));

	return;
}

NX_VOID vNMG_MngPeriodicMain ( NX_VOID )
{
	NX_USHORT usLinkSpdSta = NX_LINKSPD_STA_1G;
	
	vNMG_ChkLinkDown();
	vNX_ChkNotifyFlg();
	vNMG_RcvDtMain();
	vNMG_RcvCmnSlmpMain();
	vNMG_NotifyNmgErr();
	vNX_ChkDuplicateIP();
	vNMG_DetectionWaitCheck();
	vNMG_UpdateDataLinkLed();
	usLinkSpdSta = usLSM_GetLinkSpd();
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		vNMG_CycleCnt100MEnable();
	}

#ifdef TSN_CAN_ENABLE
	vNX_PostMngPeriodic();
#endif
	return;
}

NX_VOID vNX_ChkNotifyFlg ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	if (NX_NOTIFY_FLG_ON == gstNM.usNotifyTslTimeCmpFlg) {
		gstNM.usNotifyTslTimeCmpFlg	= NX_NOTIFY_FLG_OFF;
		vNMG_PreparSndNotificationReq(NTF_CODE_TIMESYNC_CMP);
		gstNM.stNet.usStatusFinish |= FIN_TIMESYNC_CMP;
		if ( FIN_RCVD_CYCCFG_TIMECMP == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TIMECMP) ) {
			
			vNMG_ComCycEnable();
		}
	}
	
	if (NX_NOTIFY_FLG_ON == gstNM.usNotifyDLinkErrFlg) {
		gstNM.usNotifyDLinkErrFlg	= NX_NOTIFY_FLG_OFF;

		usAuthClass = usACM_GetAuthenticationClass();

		if ( SYNCMODE_SYNC == gstNET.stApp.usSyncMode ) {
			if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
				vTsn_Notify_WatchAdjustStop();
			}
		}
		

		
		if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
			vTsn_ChkSyncErr();
			ulTXN_ChangeReqTsState(TSREQ_DI_REQ);
		}
		else {
			vNMG_NetStsInit();
			gstNM.stNet.usNetSts = NETSTS_INITIAL;
		}
	}
	return;
}

NX_VOID vNMG_NetStsInit ( NX_VOID )
{
	NX_USHORT	usIndex;
	NX_USHORT	usSpldLoop;
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	vNMG_InitSlmpReqFinFlg();
	vNMG_ClearHopCount();
	vSYNC_Init();
	vNMG_ClearTxPhysicalPort(NX_MASTER_MANAGE);
	vNMG_ClearTxPhysicalPort(NX_MASTER_CONTROL);
	
	gstNM.stNet.usStatusFinish = NX_ZERO;
	
	gstNET.stMngMst.usFixed		= (NX_USHORT)NX_OFF;
	vNX_FillMemory32((NX_VOID*)&gstNM.stPrevValue, NX_L_ZERO, (sizeof(NM_PREV_VALUE) / sizeof(NX_ULONG)));

	NGN_CN_TS_P1_REG->R_TCPXMAGN.BITS.b01ZTSMagConfig = (NX_ULONG)NX_OFF;
	gstNET.stPort[NX_PORT1].usPortRole = NGN_PORTROLE_INIT;
	gstNET.stPort[NX_PORT2].usPortRole = NGN_PORTROLE_INIT;
	for (usIndex = NX_ZERO; usIndex < MULCAST_GP_SIZE_MAX; usIndex++) {
		NGN_CN_REG->R_REGRPNO[usIndex].BITS.b10ZGroupNo = NX_ZERO;
	}
	vNX_FillMemory32((NX_VOID*)&gstNM.stNetworkConfigMain.stNcfComCyc, NX_L_ZERO, (sizeof(NCF_COMCYC_INFO) / sizeof(NX_ULONG)));
	gstNM.stNetworkConfigMain.stDtctTopology.uchData = NX_UC_ZERO;
	
	vNX_FillMemory32((NX_VOID*)&gstNM.stNetworkConfigTslt, NX_L_ZERO, (sizeof(NM_NWCFG_TSLT) / sizeof(NX_ULONG)));
	
	gstNET.stApp.usSyncMode = SYNCMODE_UNSYNC;
	gstNET.stCtrlMst.usFixed = (NX_USHORT)NX_OFF;
	gstNET.stCtrlMst.ulIPAddress = NX_UL_ZERO;
	
	gstNET.stCyc.usTsltCycSnd = NX_ZERO;
	gstNET.stCyc.usStopDLink = NX_ZERO;
	gstNET.stApp.usUseWDC = NX_ZERO;
	gstNET.stCyc.usRsvStaBase = (NX_USHORT)NX_OFF;
	gstNET.stCyc.usRsvSta = (NX_USHORT)NX_OFF;
	NGN_RN->ulR_RNCALVECNT = (NX_ULONG)NX_ONE;
	
	for (usSpldLoop = NX_US_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchCycleIgnoreBit		= NX_UC_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDownPortSnd		= NX_UC_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDestSubPayload3	= NX_UC_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDestSubPayload4	= NX_UC_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulRcvMemmoryAddr		= NX_UL_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchType				= NX_UL_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize				= NX_UL_ZERO;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulSndDataAddr			= NX_UL_ZERO;
	}

	for (usSpldLoop = NX_US_ZERO; usSpldLoop < RCV_SPLD_NUM; usSpldLoop++) {
		gstNET.stCyc.astRcvSubPayL[usSpldLoop].uchType				= NX_UL_ZERO;
		gstNET.stCyc.astRcvSubPayL[usSpldLoop].usSize				= NX_UL_ZERO;
		gstNET.stCyc.astRcvSubPayL[usSpldLoop].ulRcvDataAddr		= NX_UL_ZERO;
	}
	gstNET.stCyc.usTrnFrameNum	= NX_UL_ZERO;

	gstNET.stCyc.usSizeRX	= NX_US_ZERO;
 	gstNET.stCyc.usSizeRWr	= NX_US_ZERO;
	gstNET.stCyc.usSizeStsW	= NX_US_ZERO;
#ifdef SAFETY_PDU_ENABLE
 	gstNET.stCyc.usSizeSpdux	= NX_US_ZERO;
#endif
	gstNET.stCyc.uchRepeatCount		= NX_UC_ZERO;
	gstNET.stCyc.uchSwitchTiming	= NX_UC_ZERO;
	gstNET.stCyc.usSndSubPayLoadNum	= NX_US_ZERO;

	gstNET.stCyc.usSizeRY	= NX_US_ZERO;
 	gstNET.stCyc.usSizeRWw	= NX_US_ZERO;
#ifdef SAFETY_PDU_ENABLE
 	gstNET.stCyc.usSizeSpduy	= NX_US_ZERO;
#endif
	gstNET.stCyc.usRcvSubPayLoadNum	= NX_US_ZERO;

	
	gstNM.stNet.usStatusFinish = FIN_INITIAL;
	
	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		gstNM.stNet.usStatusFinish	|=	FIN_TIMESYNC_CMP;
	}
	
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_INIT;
		NGN_CN_TS_P1_REG->R_TCPXCNEN.DATA	=	CNTDI_100M;
	}
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if ( NX_AUTHENTICATION_CLS_A == usAuthClass ){
		
		vNX_FillMemory32(&gstClassAInfo, NX_L_ZERO, sizeof(ACM_CLSA_INFO) / sizeof(NX_ULONG));
	}
	
	return;
}

NX_VOID vNMG_NetStsInitEnroute ( NX_VOID )
{
	NX_USHORT	usIndex;
	NX_USHORT	usSpldLoop;
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	vNMG_InitSlmpReqFinFlg();
	vSYNC_Init();
	vNMG_ClearTxPhysicalPort(NX_MASTER_MANAGE);
	vNMG_ClearTxPhysicalPort(NX_MASTER_CONTROL);
	

	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_DETECTION)) {
		vNMG_ClearHopCount();
		gstNET.stMngMst.usFixed	= (NX_USHORT)NX_OFF;
		
		
		vNX_FillMemory32((NX_VOID*)&gstNM.stPrevValue, NX_L_ZERO, (sizeof(NM_PREV_VALUE) / sizeof(NX_ULONG)));
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_NWCFG_MAIN)) {
		NGN_CN_TS_P1_REG->R_TCPXMAGN.BITS.b01ZTSMagConfig = (NX_ULONG)NX_OFF;
		gstNET.stPort[NX_PORT1].usPortRole = NGN_PORTROLE_INIT;
		gstNET.stPort[NX_PORT2].usPortRole = NGN_PORTROLE_INIT;
		for (usIndex = NX_ZERO; usIndex < MULCAST_GP_SIZE_MAX; usIndex++) {
			NGN_CN_REG->R_REGRPNO[usIndex].BITS.b10ZGroupNo = NX_ZERO;
		}
		vNX_FillMemory32((NX_VOID*)&gstNM.stNetworkConfigMain.stNcfComCyc, NX_L_ZERO, (sizeof(NCF_COMCYC_INFO) / sizeof(NX_ULONG)));
		gstNM.stNetworkConfigMain.stDtctTopology.uchData = NX_UC_ZERO;
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_NWCFG_TSLT)) {
		vNX_FillMemory32((NX_VOID*)&gstNM.stNetworkConfigTslt, NX_L_ZERO, (sizeof(NM_NWCFG_TSLT) / sizeof(NX_ULONG)));
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_SLCFG)) {
		gstNET.stApp.usSyncMode = SYNCMODE_UNSYNC;
		gstNET.stCtrlMst.usFixed = (NX_USHORT)NX_OFF;
		gstNET.stCtrlMst.ulIPAddress = NX_UL_ZERO;
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_MAIN)) {
		gstNET.stCyc.usTsltCycSnd = NX_ZERO;
		gstNET.stCyc.usStopDLink = NX_ZERO;
		gstNET.stApp.usUseWDC = NX_ZERO;
		gstNET.stCyc.usRsvStaBase = (NX_USHORT)NX_OFF;
		gstNET.stCyc.usRsvSta = (NX_USHORT)NX_OFF;
		NGN_RN->ulR_RNCALVECNT = (NX_ULONG)NX_ONE;
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TRNSPD)) {
		for (usSpldLoop = NX_US_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchCycleIgnoreBit		= NX_UC_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDownPortSnd		= NX_UC_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDestSubPayload3	= NX_UC_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDestSubPayload4	= NX_UC_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulRcvMemmoryAddr		= NX_UL_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchType				= NX_UL_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize				= NX_UL_ZERO;
			gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulSndDataAddr			= NX_UL_ZERO;
		}

		for (usSpldLoop = NX_US_ZERO; usSpldLoop < RCV_SPLD_NUM; usSpldLoop++) {
			gstNET.stCyc.astRcvSubPayL[usSpldLoop].uchType				= NX_UL_ZERO;
			gstNET.stCyc.astRcvSubPayL[usSpldLoop].usSize				= NX_UL_ZERO;
			gstNET.stCyc.astRcvSubPayL[usSpldLoop].ulRcvDataAddr		= NX_UL_ZERO;
		}
		gstNET.stCyc.usTrnFrameNum	= NX_UL_ZERO;
		gstNET.stCyc.usSizeRX	= NX_US_ZERO;
	 	gstNET.stCyc.usSizeRWr	= NX_US_ZERO;
		gstNET.stCyc.usSizeStsW	= NX_US_ZERO;
#ifdef SAFETY_PDU_ENABLE
	 	gstNET.stCyc.usSizeSpdux	= NX_US_ZERO;
#endif
		gstNET.stCyc.uchRepeatCount		= NX_UC_ZERO;
		gstNET.stCyc.uchSwitchTiming	= NX_UC_ZERO;
		gstNET.stCyc.usSndSubPayLoadNum	= NX_US_ZERO;
	}
	
	if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_RCVSPD)) {
		gstNET.stCyc.usSizeRY	= NX_US_ZERO;
	 	gstNET.stCyc.usSizeRWw	= NX_US_ZERO;
#ifdef SAFETY_PDU_ENABLE
	 	gstNET.stCyc.usSizeSpduy	= NX_US_ZERO;
#endif
		gstNET.stCyc.usRcvSubPayLoadNum	= NX_US_ZERO;
	}
	
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		vNX_FillMemory32(&gstClassAInfo, NX_L_ZERO, sizeof(ACM_CLSA_INFO) / sizeof(NX_ULONG));
	}	
	
	gstNM.stNet.usStatusFinish = FIN_INITIAL;
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		gstNM.stNet.usStatusFinish	|=	FIN_TIMESYNC_CMP;
	}
	
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_INIT;
		NGN_CN_TS_P1_REG->R_TCPXCNEN.DATA	=	CNTDI_100M;
	}
	if (SYNCMODE_SYNC == gstNET.stApp.usSyncMode) {
		vSYNC_AppSyncSigClear();
	}
	
	vNX_NotifyDLinkErr_BeforeDlink();

	return;
}

NX_VOID vNMG_AdjustTsnTimeCmp (NX_VOID)
{
	gstNM.usNotifyTslTimeCmpFlg	= NX_NOTIFY_FLG_ON;
	
	return;
}

NX_ULONG ulNMG_ReqActivateCyclic (NX_VOID)
{
	NX_ULONGLONG	ullComCycleCnt		;
	NX_ULONGLONG	ullTs2StartOffset	;
	NX_ULONGLONG	ullTs2EndOffset		;
	NX_ULONGLONG	ullTs0EndOffset;
	NX_ULONGLONG	ullTs2Time;
	NX_ULONGLONG	ullEndOffset;
	NX_ULONG		ulComCycleCntNs		;
	NX_ULONG		ulComCycleCntS		;
	NX_ULONG		ulResult			= NX_NG;
	
	ullTs2StartOffset	= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsStartTime[2];

	ullTs2EndOffset		= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsEndTime[2];
	
	ullTs0EndOffset		= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsEndTime[0];
	
	ullTs2Time = ullTs2EndOffset - ullTs2StartOffset;
	

	if ( ullTs2Time >= OFFSET_BORDER_TIMESLOT_18US ) {
		ullEndOffset = ullTs2EndOffset;
	}
	else {
		ullEndOffset = ullTs0EndOffset;
	}
	
	vNX_vDisableDispatch();

	ulComCycleCntNs		= NGN_CN_TS_P1_REG->R_TCPXTCN.DATA;
	ulComCycleCntS		= NGN_CN_TS_P1_REG->R_TCPXTCS.DATA;
	ullComCycleCnt		= (NX_ULONGLONG)ulComCycleCntS * NX_DIV_NSTOS + (NX_ULONGLONG)ulComCycleCntNs;
	
	if ( (ullTs2StartOffset < ullComCycleCnt)
	   &&(ullComCycleCnt + CYC_ACT_MARGIN < ullEndOffset) ) {
		NGN_CN_REG->R_RELUNUM.DATA = gstNET.stSelf.ulIPAddress;
		
		vCYC_ActivateCyclic();
		vNX_vEnableDispatch();
		
		gstNM.stNet.usNetSts = NETSTS_START_CYCSND;
		
		ulResult = NX_OK;
	}
	else {
		vNX_vEnableDispatch();
	}
	
	return ulResult;
}

NX_ULONG ulNMG_ReqActivateCyclic_100M (NX_VOID)
{
	NX_ULONGLONG	ullComCycleCnt		;
	NX_ULONGLONG	ullTs2StartOffset	;
	NX_ULONGLONG	ullTs2EndOffset		;
	NX_ULONGLONG	ullTs0EndOffset;
	NX_ULONGLONG	ullTs2Time;
	NX_ULONGLONG	ullEndOffset;
	NX_ULONG		ulResult			= NX_NG;
	NX_ULONGLONG	ullTime_Start;
	NX_ULONG		ulTimeS_Start;
	NX_ULONG		ulTimeNs_Start;
	
	ullTs2StartOffset	= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsStartTime[2];

	ullTs2EndOffset		= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsEndTime[2];
	
	ullTs0EndOffset		= gstNM.stNetworkConfigMain.stNcfComCyc.ullTsEndTime[0];
	
	ullTs2Time = ullTs2EndOffset - ullTs2StartOffset;
	

	if ( ullTs2Time >= OFFSET_BORDER_TIMESLOT_18US ) {
		ullEndOffset = ullTs2EndOffset;
	}
	else {
		ullEndOffset = ullTs0EndOffset;
	}
	
	vNX_vDisableDispatch();

	ulTimeNs_Start	=	NGN_SN_REG->R_SNTM0;
	ulTimeS_Start	=	NGN_SN_REG->R_SNTM1;
	ullTime_Start	=	(NX_ULONGLONG)ulTimeS_Start * NX_DIV_NSTOS + (NX_ULONGLONG)ulTimeNs_Start;
	
	ullComCycleCnt		=  ullTime_Start % gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;

	if ( (ullTs2StartOffset < ullComCycleCnt)
	   &&(ullComCycleCnt + CYC_ACT_MARGIN_100M < ullEndOffset) ) {
		NGN_CN_REG->R_RELUNUM.DATA = gstNET.stSelf.ulIPAddress;
		
		vCYC_ActivateCyclic();
		vNX_vEnableDispatch();
		
		gstNM.stNet.usNetSts = NETSTS_START_CYCSND;
		ulResult = NX_OK;
	}
	else {
		vNX_vEnableDispatch();
	}
	
	return ulResult;
}

NX_VOID vNMG_ComCycEnable (NX_VOID)
{
	NX_ULONGLONG	ullComCycle;
	NX_ULONGLONG	ullTime_Start;
	NX_ULONG		ulTimeS_Start;
	NX_ULONG		ulTimeNs_Start;
	NX_ULONGLONG	ullCycNo_Target;
	NX_ULONGLONG	ullCycMul_Target;
	NX_ULONG		ulCycMulS_Target;
	NX_ULONG		ulCycMulNs_Target;
	NX_ULONGLONG	ullTime_Now;
	NX_ULONG		ulTimeS_Now;
	NX_ULONG		ulTimeNs_Now;
	NX_ULONG		ulTsState = (NX_ULONG)TSSTATE_DI;
	NX_USHORT		usLinkSpdSta = NX_LINKSPD_STA_1G;
	NX_APP_MODE		stAppMode;
	
	gstNM.stWaitInfo.ulDtRcvWaitStartTime = ulNX_GetLifeTime();
	gstNM.stWaitInfo.ulDtRcvWaitFlg = (NX_ULONG)NX_ON;
	gstNM.stWaitInfo.ulDtRcvWaitTimeout = DETEC_WAIT_TIME;

	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		ullComCycle	=	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle / TSLT_10TIMES;
		NGN_RN->R_RNBKSEL.DATA = RNBKSEL_100M;
		NGN_CN_TS_P1_REG->R_TCPXMAGN.DATA = TSLTMAG_100M;
	}
	else {
		ullComCycle	=	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
		NGN_RN->R_RNBKSEL.DATA = RNBKSEL_1G;
		NGN_CN_TS_P1_REG->R_TCPXMAGN.DATA = TSLTMAG_1G;
	}
	vNX_vDisableDispatch();

	ulTimeNs_Start	=	NGN_SN_REG->R_SNTM0;
	ulTimeS_Start	=	NGN_SN_REG->R_SNTM1;
	ullTime_Start	=	(NX_ULONGLONG)ulTimeS_Start * NX_DIV_NSTOS + (NX_ULONGLONG)ulTimeNs_Start;
	
	ullCycNo_Target = (ullTime_Start / ullComCycle) + 2;
	ullCycMul_Target = ullComCycle * (NX_ULONGLONG)ullCycNo_Target;
	ulCycMulS_Target = (NX_ULONG)(ullCycMul_Target / NX_NSEC_1000000000);
	ulCycMulNs_Target =(NX_ULONG)( ullCycMul_Target % NX_NSEC_1000000000);
	
	NGN_CN_TS_P1_REG->R_TCPXSS0 = (NX_ULONG)((ullCycNo_Target >> NX_SHIFT32) & NX_CYCLENUM_MSK);
	NGN_CN_TS_P1_REG->R_TCPXSS1 = (NX_ULONG)(ullCycNo_Target & NX_CYCLENUM_MSK);
	NGN_CN_TS_P1_REG->R_TCPXMUL0 = ulCycMulS_Target;
	NGN_CN_TS_P1_REG->R_TCPXMUL1 = ulCycMulNs_Target;
	
	vNX_ClearWdt();
	
	while (1) {
		ulTimeNs_Now	=	NGN_SN_REG->R_SNTM0;
		ulTimeS_Now		=	NGN_SN_REG->R_SNTM1;
		ullTime_Now = (NX_ULONGLONG)ulTimeS_Now * NX_DIV_NSTOS + (NX_ULONGLONG)ulTimeNs_Now;
		if (ullCycMul_Target <= ullTime_Now) {
			break;
		}
	}
	
	NGN_CN_TS_P1_REG->R_TCPXUPD.DATA	=	0x00000001;
	
	vNX_TimeSyncComplete();
	vNX_vEnableDispatch();

	stAppMode.usSyncMode	= gstNET.stApp.usSyncMode;
	stAppMode.usUseWDC		= gstNET.stApp.usUseWDC;

	(VOID)ulNX_SetAppMode(&stAppMode);
	gstNM.usPrvSyncMode		= stAppMode.usSyncMode;
	gstNM.usFixSyncModeFlag	= (NX_USHORT)NX_ON;

	vCYC_InitCyclicStart();

	if ( SYNCMODE_SYNC == gstNET.stApp.usSyncMode ) {
		vSYNC_SetSyncInit();
		vINTR_ClearIntTs(INTR_TS_START_TS1);
		vINTR_MaskClearIntTs(INTR_TS_START_TS1);
	}

	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_WAITCYCCMP;
	}
	else {
		ulTsState = ulTXN_GetTsState();
		if ( (TSSTATE_DI == ulTsState) || (TSSTATE_DI_REQ == ulTsState) ) {
			(NX_VOID)ulTXN_ChangeReqTsState(TSREQ_DITOEN_REQ);
		}
	}
	
	return;
}

NX_VOID vNMG_ActivateTimeslot ( NX_VOID )
{
	vNX_vDisableDispatch();
	NGN_CN_TS_P1_REG->R_TCPXTXON.DATA	=	(NX_ULONG)8;
	NGN_CN_TS_P1_REG->R_TCPXTXOS.DATA	=	(NX_ULONG)0;
	vNX_vEnableDispatch();
	
	NGN_CN_TS_P1_REG->R_TCPXTON.DATA = gaulTnsEnableBitTbl[gstNM.stNetworkConfigMain.uchTSNum];
	
	vSetCycActWaitCnt ( (NX_USHORT)NX_ZERO );
	vINTR_ClearIntTs(INTR_TS_START_TS2);
	vINTR_MaskClearIntTs(INTR_TS_START_TS2);
	
	return;
}

NX_VOID vNMG_DeactivateTimeslot ( NX_VOID )
{
	NX_ULONG		ulRlyDisableTime_ms;
	FLGPTN			flgPtn = (FLGPTN)NX_OFF;
	NX_ULONG		ulRelaySetting;
	NX_ULONG		ulRelaySetting_backup;
	NGN_CN_TS_P1_REG->R_TCPXTON.DATA = (NX_ULONG)NX_ZERO;
	if (( NETSTS_LINKDOWN == gstNM.stNet.usNetSts ) ||
		( NETSTS_LINKDOWN_ENR == gstNM.stNet.usNetSts ))
	{
		vTsn_StopReq();
	}
	if ( (NX_UCHAR)NX_ON == gstNM.stNetworkConfigMain.stDtctTopology.b01Topology ) {

		(NX_VOID)wai_sem(SEMID_NX_RLYRAMCLR);

		
		vNX_vDisableDispatch();
		ulRelaySetting_backup = (NX_ULONG)NGN_RC_REG->R_RCRLYVL.DATA;
		ulRelaySetting = ulRelaySetting_backup;
		ulRelaySetting |= RCRLYVL_RLYENBL;
		ulRelaySetting &= ~RCRLYVL_CYCRLYENBL;
		NGN_RC_REG->R_RCRLYVL.DATA = ulRelaySetting;
		vNX_vEnableDispatch();
		
		ulRlyDisableTime_ms = (NX_ULONG)(((gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle * RLYDISABLE_WAIT)
											+ (CONVERT_NS_TO_MS - (NX_ULONGLONG)1)) / CONVERT_NS_TO_MS);
		
		(NX_VOID)twai_flg(EVFLGID_NX_DUMMY, FLGP_DUMMY, TWF_ANDW, &flgPtn, (signed int)ulRlyDisableTime_ms);
		
		NGN_RC_REG->R_RCRLYRST.DATA = RLYRAMINIT_TS012;
		
		vNX_vDisableDispatch();
		ulRelaySetting = (NX_ULONG)NGN_RC_REG->R_RCRLYVL.DATA;
		ulRelaySetting &= ~(RCRLYVL_RLYENBL | RCRLYVL_CYCRLYENBL);
		ulRelaySetting_backup &= (RCRLYVL_RLYENBL | RCRLYVL_CYCRLYENBL);
		NGN_RC_REG->R_RCRLYVL.DATA = ulRelaySetting_backup | ulRelaySetting;
		vNX_vEnableDispatch();

		(NX_VOID)sig_sem(SEMID_NX_RLYRAMCLR);
	}
	
	return;
}

NX_VOID vNMG_DataLinkDownCmp ( NX_VOID )
{
	if (( NETSTS_LINKDOWN == gstNM.stNet.usNetSts ) ||
		( NETSTS_LINKDOWN_ENR == gstNM.stNet.usNetSts ))
	{
		if ((NX_USHORT)NX_OFF != (gstNM.stNet.usStatusFinish & FIN_DLINK)) {
			vNMG_NetStsInit();
		}
		else {
			vNMG_NetStsInitEnroute();
		}
		gstNM.stNet.usNetSts = NETSTS_INITIAL;
	}

	return;
}




NX_VOID vNMG_NotifyFirstCycRcvCmp ( NX_VOID )
{
	NX_USHORT	usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	gstNM.stNet.usStatusFinish |= FIN_DLINK;
	gstNM.stNet.usNetSts = NETSTS_DLINK;
	gstNET.stCyc.usEstComOnce = (NX_USHORT)NX_ON;
	gstNM.stWaitInfo.ulDtRcvWaitFlg = (NX_ULONG)NX_OFF;
	vNMG_ClrNmgErr();
	vNMG_ClrNmgLastErr();
	vNMG_SaveIPAddress(gstNET.stSelf.ulIPAddress, gstNET.stSelf.ulSubnetMask);

	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		vTsn_Notify_WatchAdjustStart();	
	}
	return;
}

NX_VOID vNMG_UpdateRsvSta (
	NX_USHORT	usRsvSta
)
{
	if ((NX_USHORT)NX_ON == gstNET.stCyc.usRsvStaBase) {
		gstNET.stCyc.usRsvSta = usRsvSta;
	}
	return;
}

NX_VOID vNMG_NotifyDLinkErr ( NX_VOID )
{
	gstNM.usNotifyDLinkErrFlg = NX_NOTIFY_FLG_ON;
	gstNM.stNet.usNetSts = NETSTS_LINKDOWN;
	return;
}


NX_VOID vNMG_UpdateDataLinkLed ( NX_VOID )
{
	return;
}

NX_ULONG ulNMG_CtrlMstMacAddr (
	NX_UCHAR* pauchMacAddr
)
{
	NX_ULONG	ulResult = NX_NG;
	NX_ULONG	ulCmpResult = NX_NG;
	NX_UCHAR	uchZeroData[6] = {0,0,0,0,0,0};
	
	ulCmpResult = lNX_CompareMemory(gstNET.stCtrlMst.auchMacAddr, uchZeroData, NX_MAC_ADDR_SIZE);
	if ((NX_ULONG)NX_NG == ulCmpResult) {
		vNX_CopyMemory(pauchMacAddr, gstNET.stCtrlMst.auchMacAddr, NX_MAC_ADDR_SIZE);
		ulResult = NX_OK;
	}
	else {
		ulResult = NX_NG;
	}
	
	return ulResult;
}

NX_VOID vNMG_SaveIPAddress (
	NX_ULONG	ulSaveIPAddress,
	NX_ULONG	ulSaveSubnetMask
)
{
	NX_IPADDR_INFO	stIPAddrInfo;
	NX_ULONG		ulChkResult = NX_UL_NG;
	
	if (NM_IP_ADDR_SW_FF != gstAppInfo.stCieNetInfo.usIpSw) {
		ulChkResult = ulNX_ChkIpAddress(ulSaveIPAddress, ulSaveSubnetMask);

		if ((NX_IP_OK == ulChkResult)
		 && ((ulSaveIPAddress != gstAppInfo.stEthInfo.ulIPAddress_Flash)
		  || (ulSaveSubnetMask != gstAppInfo.stEthInfo.ulSubnetMask_Flash))) {
			stIPAddrInfo.ulIPAddress = ulSaveIPAddress;
			stIPAddrInfo.ulSubnetMask = ulSaveSubnetMask;
			vNX_SetIPv4IPAddrForApp(&stIPAddrInfo);
			
			gstAppInfo.stEthInfo.ulIPAddress_Flash = ulSaveIPAddress;
			gstAppInfo.stEthInfo.ulSubnetMask_Flash = ulSaveSubnetMask;
		}
	}

	return;
}

NX_ULONG ulNX_ChkCycRcvNoData ( NX_VOID )
{
	NX_ULONG	ulResult = (NX_ULONG)NX_OFF;
	
#ifdef SAFETY_PDU_ENABLE
	if (((NX_USHORT)NX_ZERO == gstNET.stCyc.usSizeRY)
	 && ((NX_USHORT)NX_ZERO == gstNET.stCyc.usSizeRWw)
	 && ((NX_USHORT)NX_ZERO == gstNET.stCyc.usSizeSpduy)) {
#else
	if (((NX_USHORT)NX_ZERO == gstNET.stCyc.usSizeRY)
	 && ((NX_USHORT)NX_ZERO == gstNET.stCyc.usSizeRWw)) {
#endif
		ulResult = (NX_ULONG)NX_ON;
	}
	
	return ulResult;
}

NX_VOID vSetCycActWaitCnt (
	NX_USHORT usWaitCnt
)
{
	gstNM.usCycActWaitCnt = usWaitCnt;
	return;
}

NX_USHORT usGetCycActWaitCnt ( NX_VOID )
{
	return gstNM.usCycActWaitCnt;
}

NX_VOID vNX_ChkDuplicateIP ( NX_VOID )
{
	NX_USHORT	usDuplicateIP_P1 =	(NX_USHORT)NX_ZERO;
	NX_USHORT	usDuplicateIP_P2 =	(NX_USHORT)NX_ZERO;

	usDuplicateIP_P1 = usUSN_DuplicatIP((NX_USHORT)NX_PORT1);
	usDuplicateIP_P2 = usUSN_DuplicatIP((NX_USHORT)NX_PORT2);

	if ((NX_US_NG == usDuplicateIP_P1)
	 || (NX_US_NG == usDuplicateIP_P2)) {
		gstNM.uchDuplicateIPPeriodic = (NX_UCHAR)NX_ON;
		if (gstNM.stPrevValue.uchDuplicateIPPeriodic == (NX_UCHAR)NX_OFF) {
			vNX_SetEvent(EVENTCODE_DUPLICATIONIP, NX_NULL);
		}
	}
	else {
		gstNM.uchDuplicateIPPeriodic = (NX_UCHAR)NX_OFF;
	}

	gstNM.stPrevValue.uchDuplicateIPPeriodic =	gstNM.uchDuplicateIPPeriodic;

	return;
}


NX_VOID vNMG_DetectionWaitCheck ( NX_VOID )
{
	NX_ULONG	ulResult;

	if ((NX_ULONG)NX_ON == gstNM.stWaitInfo.ulDtRcvWaitFlg) {
		ulResult = ulNX_WaitLifeTime(gstNM.stWaitInfo.ulDtRcvWaitStartTime, gstNM.stWaitInfo.ulDtRcvWaitTimeout);

		if (NX_NG == ulResult) {
			gstNM.stWaitInfo.ulDtRcvWaitFlg = (NX_ULONG)NX_OFF;
		}
		else {
		}
	}

	return;
}

NX_VOID vNX_SetClockOffset (
	NX_LONGLONG		llOffsetSec,
	NX_LONG			lOffsetNsec,
	NX_SHORT		sUtcOffsetMin,
	NX_SHORT		sSummerTimeOffsetMin
)
{
	vNX_vDisableDispatch();
	
	gstClockOffset.llOffsetSec = llOffsetSec;
	gstClockOffset.lOffsetNsec = lOffsetNsec;
	gstClockOffset.sUtcOffsetMin = sUtcOffsetMin;
	gstClockOffset.sSummerTimeOffsetMin = sSummerTimeOffsetMin;
	
	vNX_vEnableDispatch();
	
	gstClockOffset.ulOffsetRecvFlag = (NX_ULONG)NX_ON;
	
	return;
}

NX_VOID vNX_GetClockOffset (
	NX_LONGLONG*	pllOffsetSec,
	NX_LONG*		plOffsetNsec,
	NX_SHORT*		psUtcOffsetMin,
	NX_SHORT*		psSummerTimeOffsetMin
)
{
	
	vNX_vDisableDispatch();
	
	*pllOffsetSec = gstClockOffset.llOffsetSec;
	*plOffsetNsec = gstClockOffset.lOffsetNsec;
	*psUtcOffsetMin = gstClockOffset.sUtcOffsetMin;
	*psSummerTimeOffsetMin = gstClockOffset.sSummerTimeOffsetMin;
	
	vNX_vEnableDispatch();
	
	return;
}

NX_ULONG ulNX_GetClockOffsetRecvFlag (NX_VOID)
{
	return gstClockOffset.ulOffsetRecvFlag;
}

NX_ULONG ulNX_GetCycSendSts (NX_VOID)
{
	NX_ULONG	ulCycSendSts	= NX_OFF;
	
	if (( NETSTS_START_CYCSND == gstNM.stNet.usNetSts )
	 || ( NETSTS_DLINK == gstNM.stNet.usNetSts ))
	{
		ulCycSendSts = (NX_ULONG)NX_ON;
	}
	else {
		ulCycSendSts = (NX_ULONG)NX_OFF;
	}
	
	return ulCycSendSts;
}

NX_VOID vNMG_CycleCnt100MEnable ( NX_VOID )
{
	NX_ULONG		ulCheckResult			= (NX_ULONG)NX_OFF;
	NX_ULONG		ulFactorInt				= (NX_ULONG)NX_OFF;
	NX_ULONG		ulTsState				= TSSTATE_DI;
	NX_ULONG		ulTimeS_Start			= (NX_ULONG)NX_ZERO;
	NX_ULONG		ulTimeNs_Start			= (NX_ULONG)NX_ZERO;
	NX_ULONGLONG	ullCycMul_Target		= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullComCycle_1G			= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullComCycle_100M		= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullCycNo_Target_100M	= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullCycNo_Init			= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ull100MCntStrt			= (NX_ULONGLONG)NX_ZERO;
	
	if ( NET_100MENBLSTS_WAITCYCCMP == gstNM.stNet.usCycCnt100MEnbSts ) {
		ulCheckResult = ulINTR_CheckIntLow(INTR_LOW_CYCLECOMPE_PORT1);
		
		if (ulCheckResult == (NX_ULONG)NX_ON) {
			vNX_vDisableDispatch();
			
			ullComCycle_1G		=	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle / TSLT_10TIMES;
			ullComCycle_100M	=	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
			
			ulTimeS_Start		= NGN_CN_TS_P1_REG->R_TCPXMUL0;
			ulTimeNs_Start		= NGN_CN_TS_P1_REG->R_TCPXMUL1;
			ullCycMul_Target	= (NX_ULONGLONG)ulTimeS_Start * NX_DIV_NSTOS + (NX_ULONGLONG)ulTimeNs_Start + (ullComCycle_1G * 2);
			
			ullCycNo_Target_100M	=	(ullCycMul_Target / ullComCycle_100M) + (NX_ULONGLONG)1;
			
			ullCycNo_Init = ullCycNo_Target_100M - (NX_ULONGLONG)1;
			NGN_CN_TS_P1_REG->R_TCPXSSH0 = (NX_ULONG)((ullCycNo_Init >> NX_SHIFT32) & NX_CYCLENUM_MSK);
			NGN_CN_TS_P1_REG->R_TCPXSSH1 = (NX_ULONG)(ullCycNo_Init & NX_CYCLENUM_MSK);
			
			ull100MCntStrt		=	ullCycNo_Target_100M * TSLT_10TIMES;
			
			NGN_CN_TS_P1_REG->R_TCPXSST0	=	(NX_ULONG)((ull100MCntStrt >> NX_SHIFT32) & NX_CYCLENUM_MSK);
			NGN_CN_TS_P1_REG->R_TCPXSST1	=	(NX_ULONG)(ull100MCntStrt & NX_CYCLENUM_MSK);
			
			NGN_CN_TS_P1_REG->R_TCPXCNEN.DATA	=	CNTEN_100M;
			
			vNX_vEnableDispatch();
			
			gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_WAITCYCSW;
		}
	}
	else if ( NET_100MENBLSTS_WAITCYCSW == gstNM.stNet.usCycCnt100MEnbSts ) {
		ulFactorInt = ulINTR_CheckIntLow(INTR_LOW_CYCLESWICH_PORT1_100);
		
		if ((NX_ULONG)NX_ON == ulFactorInt) {
			ulTsState = ulTXN_GetTsState();
			if ( (TSSTATE_DI == ulTsState) || (TSSTATE_DI_REQ == ulTsState) ) {
				gstNM.stNet.usCycCnt100MEnbSts = NET_100MENBLSTS_CMP;
				(NX_VOID)ulTXN_ChangeReqTsState(TSREQ_DITOEN_REQ);
			}
		}
	}
	else {
	}
	
	return;
}

NX_ULONGLONG ullNMG_GetComCycle (NX_VOID)
{
	return gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
}

NX_VOID vNMG_GetSendCycle (
	NX_USHORT* pusRepeatCount,
	NX_USHORT* pusSwitchTiming
)
{
	*pusRepeatCount		= (NX_USHORT)gstNET.stCyc.uchRepeatCount	+ (NX_USHORT)NX_ONE;
	*pusSwitchTiming	= (NX_USHORT)gstNET.stCyc.uchSwitchTiming	+ (NX_USHORT)NX_ONE;
	return;
}

NX_USHORT usNMG_GetRemainderBitPattern (
	NX_ULONGLONG	ullCycleTime_ns,
	NX_USHORT*		pusBitPatternSelect,
	NX_USHORT*		pusBitPattern
)
{
	NX_USHORT		usTblIdx		 = NX_US_ZERO;
	
	
	if ((NX_ULONGLONG)NX_REMAIND_0 == (ullCycleTime_ns & NX_BIT00_02)) {
		*pusBitPatternSelect		= NX_BITPATTERN_SEL_8K;
		*pusBitPattern				= NX_US_ZERO;
		return NX_US_OK;
	}
	else {
		for (usTblIdx = NX_US_ZERO; usTblIdx < (NX_USHORT)NX_NOT8NS_EN_TBL_NUM_8K; usTblIdx++) {
			if (gaullNot8nsEnableTbl_8K[usTblIdx][0] == ullCycleTime_ns) {
				break;
			}
		}
		if (usTblIdx < (NX_USHORT)NX_NOT8NS_EN_TBL_NUM_8K) {
			*pusBitPatternSelect	= NX_BITPATTERN_SEL_8K;
			*pusBitPattern			= (NX_USHORT)gaulBitPatternTbl_8K[gaullNot8nsEnableTbl_8K[usTblIdx][1]];
			return NX_US_OK;
		}
	}
	
	return  NX_US_NG;
}

NX_ULONG ulNX_GetTopology (NX_VOID)
{
	NX_ULONG ulTopology;
	
	if (NETSTS_DLINK != gstNM.stNet.usNetSts) {
		ulTopology = NX_TOPOLOGY_UNKNOWN;
	}
	else {
		if ( (NX_UCHAR)NX_ON == gstNM.stNetworkConfigMain.stDtctTopology.b01Topology ) {
			ulTopology = NX_TOPOLOGY_RING;
		}
		else {
			ulTopology = NX_TOPOLOGY_NOT_RING;
		}
	}
	
	return ulTopology;
}


NX_VOID vNMG_ChkLinkDown (NX_VOID)
{
	NX_ULONG	ulLinkUpSts	=	PHY_LINKDOWN;
	NX_USHORT	usPortLoop	=	(NX_USHORT)NX_PORT1;
	
	for (usPortLoop = (NX_USHORT)NX_PORT1; usPortLoop < (NX_USHORT)NX_PORT_SIZE; usPortLoop++) {
		ulLinkUpSts = ulPHY_DetectLinkUp(usPortLoop);
		
		if ((PHY_LINKUP == gstNM.aulLinkUpStsPre[usPortLoop]) && (PHY_LINKDOWN == ulLinkUpSts)) {
			gstNM.ausNotifyLinkDownFlg[usPortLoop] = NX_NOTIFY_FLG_ON;
			if (usPortLoop == (NX_USHORT)NX_PORT1) {
				(NX_VOID)set_flg(EVFLGID_NX_RLYRAMCLR, FLGP_LINKDOWN_P1);
			}
            else {
				(NX_VOID)set_flg(EVFLGID_NX_RLYRAMCLR, FLGP_LINKDOWN_P2);
			}
		}
		
		gstNM.aulLinkUpStsPre[usPortLoop] = ulLinkUpSts;
	}
	
	return;
}

NX_VOID vNMG_RelayRamClr ( NX_VOID )
{
	FLGPTN		flgPtn = (FLGPTN)NX_ZERO;
	NX_ULONG	ulRlyDisableTime_ms;
	NX_ULONG	ulRelaySetting;
	NX_ULONG	ulRelaySetting_backup;
	
	NX_ULONG	ulRCRLYVL_SetData;
	NX_ULONG	ulRCRLYRST_SetData;
	NX_USHORT	usAuthClass;
	

	(NX_VOID)wai_flg(EVFLGID_NX_RLYRAMCLR, (FLGPTN)FLGP_RLYRAMCLR_WAIT, TWF_ORW, &flgPtn);
	(NX_VOID)clr_flg(EVFLGID_NX_RLYRAMCLR, (FLGPTN)(~flgPtn));
	
	(NX_VOID)wai_sem(SEMID_NX_RLYRAMCLR);
	
	
	vNX_vDisableDispatch();
	
	ulRCRLYVL_SetData  = RelayRamRegTbl[flgPtn][0];
	ulRCRLYRST_SetData =  RelayRamRegTbl[flgPtn][1];
	
	ulRelaySetting_backup = (NX_ULONG)NGN_RC_REG->R_RCRLYVL.DATA;
	ulRelaySetting = ulRelaySetting_backup;
	ulRelaySetting &= ~(RCRLYVL_CYCRLYENBL | RCRLYVL_RLYENBL);
	ulRelaySetting |= ulRCRLYVL_SetData;
	NGN_RC_REG->R_RCRLYVL.DATA = ulRelaySetting;
	vNX_vEnableDispatch();
	
	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
	if ( (NX_ULONGLONG)NX_ZERO != gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle ) {
		ulRlyDisableTime_ms = (NX_ULONG)(((gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle * RLYDISABLE_WAIT)
											+ (CONVERT_NS_TO_MS - (NX_ULONGLONG)1)) / CONVERT_NS_TO_MS);
	}
	else {
		ulRlyDisableTime_ms = (NX_ULONG)(((gstAppInfo.stCieNetInfo.ullComCycleMax * RLYDISABLE_WAIT)
											+ (CONVERT_NS_TO_MS - (NX_ULONGLONG)1)) / CONVERT_NS_TO_MS);
	}
    }
	else {
		ulRlyDisableTime_ms = RLY_CLASSA_WAIT;
	}
	
	(NX_VOID)twai_flg(EVFLGID_NX_DUMMY, FLGP_DUMMY, TWF_ANDW, &flgPtn, (signed int)ulRlyDisableTime_ms);
	
	NGN_RC_REG->R_RCRLYRST.DATA = ulRCRLYRST_SetData;
	
	vNX_vDisableDispatch();
	ulRelaySetting = (NX_ULONG)NGN_RC_REG->R_RCRLYVL.DATA;
	ulRelaySetting &= ~(RCRLYVL_RLYENBL | RCRLYVL_CYCRLYENBL);
	ulRelaySetting_backup &= (RCRLYVL_RLYENBL | RCRLYVL_CYCRLYENBL);
	NGN_RC_REG->R_RCRLYVL.DATA = ulRelaySetting_backup | ulRelaySetting;
	vNX_vEnableDispatch();

	(NX_VOID)sig_sem(SEMID_NX_RLYRAMCLR);
	
	return;
}

NX_VOID vNMG_ChkRelayRamOverflow (
	NX_ULONG 	ulPort
)
{
	NX_ULONG	ulShortPacketNum;
	NX_ULONG	ulJumboFrameNum;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs0;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs1;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs3;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs4;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs5;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs6;
	NX_ULONG	ulRlyRamOvrFlwFrmCntTs7;
	
	ulShortPacketNum	= (NX_ULONG)FramePacketNumReg[ulPort]->R_RE_SHTP_JMBF.BITS.b10ZShortPacketNum;
	
	ulJumboFrameNum		= (NX_ULONG)FramePacketNumReg[ulPort]->R_RE_SHTP_JMBF.BITS.b10ZJumboFrameNum;
	
	if ((NGN_CN_TS_P1_REG->R_TCPXTON.DATA & TCPXTON_TS_EN) == TCPXTON_TS_EN) {
		ulRlyRamOvrFlwFrmCntTs0 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][0]->b10ZTSEvenNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs1 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][0]->b10ZTSOddNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs3 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][1]->b10ZTSOddNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs4 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][2]->b10ZTSEvenNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs5 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][2]->b10ZTSOddNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs6 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][3]->b10ZTSEvenNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs7 = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][3]->b10ZTSOddNoRlyRamOvrFlwFrmCnt;

	}
	else {
		ulRlyRamOvrFlwFrmCntTs0  = (NX_ULONG)RelayRamOverFlowFrameCntTsEn[ulPort][0]->b10ZTSEvenNoRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs0 += (NX_ULONG)RelayRamOverFlowFrameCntTsDi[ulPort]->b10ZTSEvenNoDisRlyRamOvrFlwFrmCnt;
		ulRlyRamOvrFlwFrmCntTs1 = NX_UL_ZERO;
		ulRlyRamOvrFlwFrmCntTs3 = NX_UL_ZERO;
		ulRlyRamOvrFlwFrmCntTs4 = NX_UL_ZERO;
		ulRlyRamOvrFlwFrmCntTs5 = NX_UL_ZERO;
		ulRlyRamOvrFlwFrmCntTs6 = NX_UL_ZERO;
		ulRlyRamOvrFlwFrmCntTs7 = NX_UL_ZERO;
	}
	
	if (ulShortPacketNum != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulShortPacket = (NX_ULONG)NX_ON;
	}
	
	if (ulJumboFrameNum != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulJumboFrame = (NX_ULONG)NX_ON;
	}
	
	if (ulRlyRamOvrFlwFrmCntTs0 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs0 = (NX_ULONG)NX_ON;
	}
	
	if (ulRlyRamOvrFlwFrmCntTs1 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs1 = (NX_ULONG)NX_ON;
	}

	if (ulRlyRamOvrFlwFrmCntTs3 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs3 = (NX_ULONG)NX_ON;
	}

	if (ulRlyRamOvrFlwFrmCntTs4 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs4 = (NX_ULONG)NX_ON;
	}

	if (ulRlyRamOvrFlwFrmCntTs5 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs5 = (NX_ULONG)NX_ON;
	}

	if (ulRlyRamOvrFlwFrmCntTs6 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs6 = (NX_ULONG)NX_ON;
	}

	if (ulRlyRamOvrFlwFrmCntTs7 != NX_UL_ZERO) {
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs7 = (NX_ULONG)NX_ON;
	}
	
	if (((gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs0 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs1 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs3 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs4 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs5 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs6 == (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs7 == (NX_ULONG)NX_ON))
	 && ((gastErrFrameFlg[ulPort].ulShortPacket 	== (NX_ULONG)NX_ON)
	  || (gastErrFrameFlg[ulPort].ulJumboFrame 		== (NX_ULONG)NX_ON))) {
		(NX_VOID)set_flg(EVFLGID_NX_RLYRAMCLR, FLGP_RLYRAM_OVRFLW[ulPort]);
		
		gastErrFrameFlg[ulPort].ulShortPacket		= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulJumboFrame		= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs0	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs1	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs3	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs4	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs5	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs6	= (NX_ULONG)NX_OFF;
		gastErrFrameFlg[ulPort].ulRlyRamOvrFlwTs7	= (NX_ULONG)NX_OFF;
	}
	
	return;
}

NX_VOID vNMG_PrepareDLinkClassA (NX_VOID)
{
	NX_APP_MODE		stAppMode;
	NX_ULONG	ulComCycle						=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulRepeatCount					=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulDataLinkErrCycleSet			=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulCycNoRcvTimer					=	(NX_ULONG)NX_ZERO;
	
	gstNM.stWaitInfo.ulDtRcvWaitStartTime = ulNX_GetLifeTime();
	gstNM.stWaitInfo.ulDtRcvWaitFlg = (NX_ULONG)NX_ON;
	gstNM.stWaitInfo.ulDtRcvWaitTimeout = (NX_ULONG)((gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle
											 + (NX_ULONGLONG)NX_DIV_NSTOS - (NX_ULONGLONG)NX_ONE)
											 / (NX_ULONGLONG)NX_DIV_NSTOS)
											 * (NX_ULONG)NX_MUL_USTONS
											 + DETEC_WAIT_TIME;
	
	stAppMode.usSyncMode	= gstNET.stApp.usSyncMode;
	stAppMode.usUseWDC		= gstNET.stApp.usUseWDC;
	
	(VOID)ulNX_SetAppMode(&stAppMode);
	
	ulComCycle				=	(NX_ULONG)(gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle / (NX_ULONG)NX_MUL_USTONS);
	ulRepeatCount			=	(NX_ULONG)gstNET.stCyc.uchRepeatCount + (NX_ULONG)NX_ONE;
	ulDataLinkErrCycleSet	=	NGN_RN->ulR_RNCALVECNT;
	ulCycNoRcvTimer			=	ulComCycle * ulRepeatCount * ulDataLinkErrCycleSet;
	vCYC_SetTimeoutSettingClassA(ulCycNoRcvTimer);
	vCYC_InitCyclicStart();
	
	vNX_vDisableDispatch();
	
	NGN_CN_REG->R_RELUNUM.DATA = gstNET.stSelf.ulIPAddress;
	
	vCYC_ActivateCyclic();
	
	vNX_vEnableDispatch();
	
	gstNM.stNet.usNetSts = NETSTS_START_CYCSND;
	
	return;
}
NX_ULONG ulNMG_GetVlanTag ( 
	NX_ULONG* ulVlanTag 
)
{
	NX_ULONG	ulVlanChk			=	(NX_ULONG)NX_UL_NO_VLAN;
	NX_ULONG	ulVlanNo_Local		=	(NX_ULONG)NX_ZERO;
	NX_USHORT	usVlanNum_Local		=	(NX_USHORT)NX_ZERO;
	NX_ULONG	ulVid_Local			=	(NX_ULONG)NX_ZERO;
	NX_ULONG	ulPcp_Local			=	(NX_ULONG)NX_ZERO;
	
	
	ulVlanNo_Local					=	gstNM.stCyclicConfigMain.ulVlanNo;
	usVlanNum_Local					=	gstNM.stNetworkConfigTslt.astVlanConfig[0].usVlanNum;
	
	if (ulVlanNo_Local != NX_UL_ZERO) {
		if (ulVlanNo_Local <= (NX_ULONG)usVlanNum_Local) {
			ulPcp_Local		=	(NX_ULONG)gstNM.stNetworkConfigTslt.astVlanConfig[0].astVlan[ulVlanNo_Local-(NX_ULONG)NX_ONE].usPcp;
			ulVid_Local		=	(NX_ULONG)gstNM.stNetworkConfigTslt.astVlanConfig[0].astVlan[ulVlanNo_Local-(NX_ULONG)NX_ONE].usVid;
			*ulVlanTag		=	VLAN_TYPE | (ulPcp_Local << NX_SHIFT13) | ulVid_Local;

			ulVlanChk		=	NX_UL_VLAN_OK;
		}
		else {
			*ulVlanTag	=	NX_UL_NO_VLAN_TAG;
			ulVlanChk	=	NX_UL_VLAN_NG;
		}
	}
	else {
		*ulVlanTag	=		NX_UL_NO_VLAN_TAG;
		ulVlanChk	=		NX_UL_NO_VLAN;
	}
	
	return ulVlanChk;
}
NX_VOID vNX_SetNetworkClock (
	NX_UCHAR* puchNwClock
)
{
	NX_USHORT		usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_ULONG		ulNs_Temp		= (NX_ULONG)NX_ZERO;
	NX_ULONGLONG	ullSec_Temp		= (NX_ULONGLONG)NX_ZERO;
	
	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		
		vNX_CopyMemory(&ulNs_Temp,	&(puchNwClock[NWTIME_IDX_NS]),  NWTIME_SIZE_NS);
		vNX_CopyMemory(&ullSec_Temp,&(puchNwClock[NWTIME_IDX_SEC]), NWTIME_SIZE_SEC);

		if ((ullSec_Temp	<= NWTIME_SIZE_SEC_MAX) &&
			(ulNs_Temp		<= NWTIME_SIZE_NS_MAX)) {
			vTsn_SetTime(puchNwClock);
		}
	}
	
	return;
}

/*[EOF]*/
