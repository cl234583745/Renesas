/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include <ptp_api.h>
#include <ptp_Event.h>
#include <ptp_bmca.h>
#include <PTP_GlobalData.h>
#include "ptp_CommonFunction.h"
#include "ptp_LogRecord.h"

#include "ptp_tsn_Wrapper.h"
#include "ptp_LCEntity.h"
#include "PortAnnounceCountSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortAnnounceReceiveSM.h"
#include "PortStateSelectionSM.h"
#include "ptp_MemManage.h"
#include "mdtransinterface.h"

#define D_FUNC	0

PARECEIVESM_EV	GetportAnnReceiveEvent(USHORT usEvent);

FOREIGN_MASTER_INFO *ptp_Get_ForeignMasterBlock(void);

#ifdef	PTP_USE_BMCA

VOID (*const portAnnounceReceiveSM_Matrix[PARECEIVESM_ST_MAX][PARECEIVESM_EV_MAX])(PORTDATA *pstPort) =
{
	{&PortAnnounceReceive_01, &PortAnnounceReceive_02 ,&PortAnnounceReceive_10},
	{&PortAnnounceReceive_01, &PortAnnounceReceive_03 ,&PortAnnounceReceive_10},
	{&PortAnnounceReceive_01, &PortAnnounceReceive_03 ,&PortAnnounceReceive_10}
};

VOID	portAnnounceReceiveSM(USHORT usEvent, PORTDATA *pstPort)
{
	PARECEIVESM_GD	*pstSMGlb;
	PARECEIVESM_EV	enEvt;

	pstSMGlb = &(pstPort->stPAReceiveSM_GD);

	enEvt =	GetportAnnReceiveEvent(usEvent);

	if (enEvt < PARV_EV_EVENT_MAX)
	{
		if (pstSMGlb->enStatus < PARVSM_STATUS_MAX)
		{
			(*portAnnounceReceiveSM_Matrix[pstSMGlb->enStatus][enEvt])(pstPort);
			return;
		}
	}
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_81000003);
	return;
}

PARECEIVESM_EV	GetportAnnReceiveEvent(USHORT usEvent)
{
	PARECEIVESM_EV	enEvt;
	switch (usEvent)
	{
		case (USHORT)PTP_EV_BEGIN:
			enEvt = PARV_EV_BEGIN;
		break;
		case (USHORT)PTP_EV_RCVDANNOUNCE:
			enEvt = PARV_EV_RCVDANNOUNCE;
		break;
		case (USHORT)PTP_EV_CLOSE:
			enEvt = PARV_EV_CLOSE;
		break;
		default:
			enEvt = PARV_EV_EVENT_MAX;
		break;
	}
	return(enEvt);
}

VOID	PortAnnounceReceive_01(PORTDATA *pstPort)
{
	BMC_GD				*pstBmcGd;
	PORTBMC_GD			*pstPortBmcGd;
	PARECEIVESM_GD		*pstSMGlb;

	ptp_dbg_msg( D_FUNC, ("PortAnnounceReceive_01::+\n") );

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb = &(pstPort->stPAReceiveSM_GD);

	if (!(pstBmcGd->blExternalPortConfiguration))
	{
		pstSMGlb->blRcvdAnnounce = FALSE;
		pstPortBmcGd->blRcvdMsg  = FALSE;
		pstSMGlb->enStatus		 = PARVSM_DISCARD;

	}

	if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		initForeignMaster(pstPort);
#endif
	}

	ptp_dbg_msg( D_FUNC, ("PortAnnounceReceive_01::-\n") );
	return;
}

VOID	PortAnnounceReceive_02(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PARECEIVESM_GD	*pstSMGlb;

	pstBmcGd 	 = &(pstPort->pstClockData->stBMC_GD);
	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAReceiveSM_GD);

	if (!IS_PORTOK(pstPort))
	{
		PortAnnounceReceive_01(pstPort);
	}
	else
	{
		if (!(pstBmcGd->blExternalPortConfiguration)) {
			pstSMGlb->blRcvdAnnounce = FALSE;
			pstPortBmcGd->blRcvdMsg = FALSE;
			pstSMGlb->enStatus = PARVSM_DISCARD;
		}
	}
	return;
}

VOID	PortAnnounceReceive_03(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PARECEIVESM_GD	*pstSMGlb;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAReceiveSM_GD);

	if (IS_PORTOK(pstPort))
	{
		pstSMGlb->blRcvdAnnounce = FALSE;
		pstPortBmcGd->blRcvdMsg  = qualifyAnnounce(pstPort);
		if (pstPortBmcGd->blRcvdMsg == FALSE)
		{
			IncPortAnnRxPTPPktDiscardCnt(pstPort);
		}
		pstSMGlb->enStatus		 = PARVSM_DISCARD;

		if (pstPortBmcGd->blRcvdMsg == TRUE)
		{
			portAnnounceInformationSM((USHORT)PTP_EV_PER_PORT_RCVDMSG, pstPort);
			IncPortAnnRxAnnounceCount(pstPort);
			pstSMGlb->enStatus		 = PARVSM_RECEIVE;
		}
	}
	else
	{
		PortAnnounceReceive_01(pstPort);
	}
	return;
}

VOID	PortAnnounceReceive_10(PORTDATA *pstPort)
{
	PORTBMC_GD			*pstPortBmcGd;
	PARECEIVESM_GD		*pstSMGlb;

	USHORT				usRet;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PortAnnounceReceive_10",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb = &(pstPort->stPAReceiveSM_GD);

	pstSMGlb->blRcvdAnnounce = FALSE;
	pstPortBmcGd->blRcvdMsg  = FALSE;
	pstSMGlb->enStatus		 = PARVSM_NONE;

	if (pstPortBmcGd->pstTOAnnounceReceipt != NULL)
	{
		usRet = ptp_TimeOut_Can(pstPortBmcGd->pstTOAnnounceReceipt);
		if (usRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_81000023);
		}
		pstPortBmcGd->pstTOAnnounceReceipt = NULL;
	}

	if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		releaseForeignAndAnnounce(pstPort);
#endif
	}

	ptp_dbg_msg( D_FUNC, ("PortAnnounceReceive_10::-\n") );

	return;
}


BOOL	qualifyAnnounce(PORTDATA *pstPort)
{
	PORTBMC_GD		*pstPortBmcGd;
	PTPMSG_ANNOUNCE	*pstPtpMsgAnnounce;
	CLOCKDATA		*pstClockData;
	CLOCKIDENTITY	*pstPathClockData;
	BOOL			blRet = FALSE;
	BOOL			blRet_1588 = TRUE;
	USHORT			usPathTraceCpySize;

#ifdef	PTP_USE_IEEE1588
	ANNOUNCE_INFO	*pstAnnounceInfo;
	PORTBMC_1588_GD	*pstPortBmc1588Gd;
	FOREIGN_MASTER_INFO *pstForeignPortBestInfo;
	BMC_1588_GD		*pstBmc1588Gd;
	UCHAR			*uchExtStatus;
	USHORT			usPortNumber;
#endif

	LONG			lCompResult;

	USHORT			usLoop;
	BMC_GD*			pstBmcGD;

	USHORT			usFrmChksize;

	pstPortBmcGd 	  = &(pstPort->stPortBMC_GD);
	pstPtpMsgAnnounce = pstPortBmcGd->pstRcvdAnnouncePtr;
	pstClockData	  = pstPort->pstClockData;
	pstBmcGD		  = &(pstClockData->stBMC_GD);

	if(pstPtpMsgAnnounce->usStepsRemoved >= ALLOWED_STEPSREMOVED)
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONSM, (ULONG)PTP_LOGVE_81000031);

	}
	else
	{

		if ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS) ||
			 ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) &&
			 	(IS_OD_BC_1588(pstPort->pstClockData)) && (pstBmcGD->blPathTraceEnable)))
		{
	
	
			lCompResult = tsn_Wrapper_MemCmp(&pstClockData->stDefaultDS.stClockIdentity,
					&pstPtpMsgAnnounce->stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
	
			if (lCompResult)
			{
					GetPTPMSG_HEADER(pstPtpMsgAnnounce->stHeader, usFrmChksize);
					GetPTPMSG_ANNOUNCE(*pstPtpMsgAnnounce, usFrmChksize);
					if(pstPtpMsgAnnounce->stHeader.usMegLength >= usFrmChksize)
					{
						if((USHORT)(pstPtpMsgAnnounce->stHeader.usMegLength - usFrmChksize) >= (USHORT)(pstPtpMsgAnnounce->stAnnounce_TLV.usLengthField+sizeof(USHORT)*2))
						{
							if(pstPtpMsgAnnounce->stAnnounce_TLV.usTLVType == PTPM_TLVTYP_ANNOUNCE)
							{
								pstPathClockData = &pstPtpMsgAnnounce->stAnnounce_TLV.stPathSequence[0];
	
								for (usLoop=0; usLoop< pstPtpMsgAnnounce->stAnnounce_TLV.usLengthField; usLoop+=sizeof(CLOCKIDENTITY))
								{
									lCompResult = tsn_Wrapper_MemCmp(&pstClockData->stDefaultDS.stClockIdentity, 
																							pstPathClockData, sizeof(CLOCKIDENTITY));
									if (!lCompResult)
									{
										break;
									}
									pstPathClockData++;
								}
								
								if (lCompResult)
								{
									if (pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == ENUM_PORTSTATE_SLAVE)
									{
										usPathTraceCpySize = pstPtpMsgAnnounce->stAnnounce_TLV.usLengthField;
										pstBmcGD->uchPathTraceCount = (UCHAR)(pstPtpMsgAnnounce->stAnnounce_TLV.usLengthField / sizeof(CLOCKIDENTITY));
										tsn_Wrapper_MemCpy (&pstBmcGD->stPathTrace[0], 
																		&pstPtpMsgAnnounce->stAnnounce_TLV.stPathSequence[0], (size_t)usPathTraceCpySize);
										tsn_Wrapper_MemCpy (pstBmcGD->stPathTrace[pstBmcGD->uchPathTraceCount].uchId, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
										pstBmcGD->uchPathTraceCount = pstBmcGD->uchPathTraceCount + 1U;
									}
									else
									{
										pstBmcGD->uchPathTraceCount = 0U;
										tsn_Wrapper_MemCpy (pstBmcGD->stPathTrace[pstBmcGD->uchPathTraceCount].uchId, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
										pstBmcGD->uchPathTraceCount = pstBmcGD->uchPathTraceCount + 1U;
									}
									blRet = TRUE;
									blRet_1588 = TRUE;
								}
								else
								{
									blRet_1588 = FALSE;
								}
							}
							else
							{
								blRet_1588 = FALSE;
							}
						}
						else
						{
							if (pstPtpMsgAnnounce->stAnnounce_TLV.usLengthField == 0)
							{
								blRet_1588 = TRUE;
								blRet = TRUE;
							}
							else
							{
								blRet_1588 = FALSE;
							}
	
						}
					}
					else
					{
						blRet_1588 = FALSE;
					}
			}
			else
			{
				blRet_1588 = FALSE;
			}
		}
		if ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) && (IS_OD_BC_1588(pstPort->pstClockData)) && blRet_1588)
		{
	#ifdef	PTP_USE_IEEE1588
			pstPortBmc1588Gd = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);
	
			blRet = FALSE;
	
			pstBmc1588Gd = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	
			uchExtStatus = &(pstBmc1588Gd->uchExtSelectedState[0]);
	
			usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;
	
			switch (uchExtStatus[usPortNumber])
			{
				case	PS_EX_FAULTY:
				case	PS_EX_DISABLED:
					break;
				case	PS_EX_LISTENING:
				case	PS_EX_PRE_MASTER:
				case	PS_EX_MASTER:
					blRet = addForeignMaster(pstPort);
					break;
				default:
	
	
					if (pstPortBmc1588Gd->pstForeignBestClock == NULL)
					{
						blRet = addForeignMaster(pstPort);
					}
					else
					{
	
						pstForeignPortBestInfo = (FOREIGN_MASTER_INFO*)(pstPortBmc1588Gd->pstForeignBestClock);
	
						lCompResult = tsn_Wrapper_MemCmp(&pstForeignPortBestInfo->stBmcaCmpDat.stSenderPort,
													&pstPtpMsgAnnounce->stHeader.stSrcPortIdentity, sizeof(PORTIDENTITY));
						if ( (lCompResult!=0) == TRUE)
						{
							blRet = addForeignMaster(pstPort);
						}
						else
						{
	
							if (uchExtStatus[usPortNumber] != PS_EX_PASSIVE)
							{
								set_announce_tmo_1588(pstPort);
								updateTimepropertiesDS_1588(pstPort);
							}
							else
							{
								set_announce_tmo_1588(pstPort);
							}
							pstPort->stPAInformationSM_GD.enStatus = PINFSM_CURRENT;
	
							oganaizeAnnounceForForeign(pstForeignPortBestInfo, pstPort);
							pstForeignPortBestInfo->usAnnMsgCnt ++;
							addAnnounceForForeign (pstForeignPortBestInfo, pstPtpMsgAnnounce, pstPort); 
	
							if (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)
							{
								blRet = TRUE;
							}
							else
							{
								if (pstForeignPortBestInfo->usAnnMsgCnt >= FOREIGN_MASTER_THRESHOLD)
								{
									pstAnnounceInfo = (ANNOUNCE_INFO*)pstForeignPortBestInfo->stAnnounceMessageChain.pstAnnounceChain_Foreword;
									pstAnnounceInfo = (ANNOUNCE_INFO*)pstAnnounceInfo->stAnnounceChain.pstAnnounceChain_Foreword;
	
									for (usLoop = 0U; usLoop < (USHORT)5U; usLoop++) {
										if (usLoop == 0U) {
											lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority1,
												&pstPtpMsgAnnounce->uchGrandmasterPriority1, sizeof(pstPtpMsgAnnounce->uchGrandmasterPriority1));
										}
										if (usLoop == (USHORT)1) {
											lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockQuality,
												&pstPtpMsgAnnounce->stGrandmasterClockQuality, sizeof(pstPtpMsgAnnounce->stGrandmasterClockQuality));
										}
										if (usLoop == (USHORT)2) {
											lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority2,
												&pstPtpMsgAnnounce->uchGrandmasterPriority2, sizeof(pstPtpMsgAnnounce->uchGrandmasterPriority2));
										}
										if (usLoop == (USHORT)3) {
											lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockIdentity,
												&pstPtpMsgAnnounce->stGrandmasterIdentity, sizeof(pstPtpMsgAnnounce->stGrandmasterIdentity));
										}
										if (usLoop == (USHORT)4) {
											lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.usStepsRemoved,
												&pstPtpMsgAnnounce->usStepsRemoved, sizeof(pstPtpMsgAnnounce->usStepsRemoved));
										}
										if (lCompResult != 0)
										{
											blRet = TRUE;
											break;
										}
									}
									
								}
							}
						}
					}
					break;
			}
			if (blRet == TRUE)
			{
				pstPort->stPAInformationSM_GD.enStatus = PINFSM_CURRENT;
				set_announce_tmo_1588(pstPort);
			}
	#endif
	
		}
	}
	return (blRet);
}

#ifdef	PTP_USE_IEEE1588
FOREIGN_MASTER_INFO	*searchClockFromForeignMaster(FOREIGN_MASTER_CHAIN *pstForeignChain, PORTIDENTITY *pstSerachPortIdentity)
{
	FOREIGN_MASTER_CHAIN	*pstForeignHdr;
	FOREIGN_MASTER_CHAIN	*pstForeignCur;
	FOREIGN_MASTER_INFO		*pstForeignInfoCur;
	FOREIGN_MASTER_INFO		*pstRetForeignInfo;
	LONG					lCompResult;

	pstRetForeignInfo = (FOREIGN_MASTER_INFO *)NULL;

	pstForeignHdr = pstForeignChain;

	pstForeignCur = pstForeignHdr->pstForeignMaster_next;

	while (pstForeignCur!=pstForeignHdr)
	{
		pstForeignInfoCur = (FOREIGN_MASTER_INFO *)pstForeignCur;

		lCompResult = tsn_Wrapper_MemCmp(&(pstForeignInfoCur->stBmcaCmpDat.stSenderPort), pstSerachPortIdentity, sizeof(PORTIDENTITY));

		if(!lCompResult)
		{
			pstRetForeignInfo = pstForeignInfoCur;
			break;
		}
		pstForeignCur = pstForeignCur->pstForeignMaster_next;
	}
	return pstRetForeignInfo;

}

BOOL	addForeignMaster(PORTDATA *pstPort)
{
	PORTBMC_GD		*pstPortBmcGd;
	PTPMSG_ANNOUNCE	*pstPtpMsgAnnounce;
	PORTBMC_1588_GD *pstPortBmc1588Gd;
	LONG			lCompResult;
	BOOL			blRet;
	FOREIGN_MASTER_INFO *pstForeignMaster;
	ANNOUNCE_INFO	*pstAnnounceInfo;
	USHORT			usLoop;
	BOOL			blThresholdFlag;

	blRet = FALSE;
	blThresholdFlag = FALSE;

	pstPortBmcGd 	  = &(pstPort->stPortBMC_GD);
	pstPtpMsgAnnounce = pstPortBmcGd->pstRcvdAnnouncePtr;
	pstPortBmc1588Gd  = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);

	pstForeignMaster = searchClockFromForeignMaster(&(pstPortBmc1588Gd->stForeignMasterChain),
																	&pstPtpMsgAnnounce->stHeader.stSrcPortIdentity);
	if (!pstForeignMaster)
	{
		pstForeignMaster = (FOREIGN_MASTER_INFO*)ptp_MMalloc(CLOCK_NUM_0, PTP_MM_FORE);
		if(!pstForeignMaster)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OUTOFMEMORY);
		}
		else
		{
			tsn_Wrapper_MemSet((VOID *)pstForeignMaster, 0, sizeof(FOREIGN_MASTER_INFO));
			tsn_Wrapper_MemCpy ((VOID *)&pstForeignMaster->stBmcaCmpDat.stSenderPort,
									&pstPtpMsgAnnounce->stHeader.stSrcPortIdentity, sizeof(PORTIDENTITY));
			pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_next->pstForeignMaster_back = (FOREIGN_MASTER_CHAIN*)pstForeignMaster;
			pstForeignMaster->stForeignMasterChain.pstForeignMaster_back = &pstPortBmc1588Gd->stForeignMasterChain; 
			pstForeignMaster->stForeignMasterChain.pstForeignMaster_next = pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_next;
			pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_next = &pstForeignMaster->stForeignMasterChain;

			pstForeignMaster->stAnnounceMessageChain.pstAnnounceChain_Foreword = &pstForeignMaster->stAnnounceMessageChain;
			pstForeignMaster->stAnnounceMessageChain.pstAnnounceChain_Backword = &pstForeignMaster->stAnnounceMessageChain;
			pstForeignMaster->pstPortData = pstPort;

			if (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)
			{
				pstForeignMaster->usAnnMsgCnt++;
				addAnnounceForForeign(pstForeignMaster, pstPtpMsgAnnounce, pstPort);
				blRet = TRUE;
			}

		}
	}
	else
	{
		oganaizeAnnounceForForeign(pstForeignMaster, pstPort);

		if (pstForeignMaster->usAnnMsgCnt == FOREIGN_MASTER_THRESHOLD - 1)
		{
			blThresholdFlag = TRUE;
		}

		pstForeignMaster->usAnnMsgCnt++;
		addAnnounceForForeign(pstForeignMaster, pstPtpMsgAnnounce, pstPort);

		if (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)
		{
			blRet = TRUE;
		}
		else
		{
			if (pstForeignMaster->usAnnMsgCnt >= FOREIGN_MASTER_THRESHOLD)
			{
				pstAnnounceInfo = (ANNOUNCE_INFO*)pstForeignMaster->stAnnounceMessageChain.pstAnnounceChain_Foreword;
				pstAnnounceInfo = (ANNOUNCE_INFO*)pstAnnounceInfo->stAnnounceChain.pstAnnounceChain_Foreword;

				for (usLoop = 0U; usLoop < (USHORT)5; usLoop++) {
					if (usLoop == 0U) {
						lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority1,
							&pstPtpMsgAnnounce->uchGrandmasterPriority1, sizeof(pstPtpMsgAnnounce->uchGrandmasterPriority1));
					}
					if (usLoop == (USHORT)1) {
						lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockQuality,
							&pstPtpMsgAnnounce->stGrandmasterClockQuality, sizeof(pstPtpMsgAnnounce->stGrandmasterClockQuality));
					}
					if (usLoop == (USHORT)2) {
						lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority2,
							&pstPtpMsgAnnounce->uchGrandmasterPriority2, sizeof(pstPtpMsgAnnounce->uchGrandmasterPriority2));
					}
					if (usLoop == (USHORT)3) {
						lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockIdentity,
							&pstPtpMsgAnnounce->stGrandmasterIdentity, sizeof(pstPtpMsgAnnounce->stGrandmasterIdentity));
					}
					if (usLoop == (USHORT)4) {
						lCompResult = tsn_Wrapper_MemCmp(&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.usStepsRemoved,
							&pstPtpMsgAnnounce->usStepsRemoved, sizeof(pstPtpMsgAnnounce->usStepsRemoved));
					}
					if (lCompResult != 0)
					{
						blRet = TRUE;
						break;
					}
				}
			}
		}
	}

	if (blThresholdFlag == TRUE)
	{
		blRet = TRUE;
	}

	return	blRet;
}

VOID		oganaizeAnnounceForForeign(FOREIGN_MASTER_INFO *pstForeignClock, PORTDATA *pstPort)
{
	ANNOUNCE_CHAIN	*pstAnnounceChain;

	BOOL			blRet;
	CHAR			chCompRet;
	ANNOUNCE_INFO*	pstAnnounceInfo;

	USCALEDNS		stUscaledOriginTimeStamp;
	USCALEDNS		stUscaledAnnounceReceiptTMO;
	USCALEDNS		stUscaledTMO;
	USCALEDNS		stUscaledTimeWindow;
	ULONG			ulTimeWindows;
	USCALEDNS		stCurrentTime;

	USCALEDNS	stTimeoutTimeWork2;
	USCALEDNS	stTimeoutTimeWork;
	CHAR		chA;

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);
	pstAnnounceChain = pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Backword;
	while (pstForeignClock->usAnnMsgCnt > FOREIGN_MASTER_THRESHOLD)
	{
		delAnnounceForForeign ((ANNOUNCE_INFO*)pstAnnounceChain);
		pstForeignClock->usAnnMsgCnt --;
		pstAnnounceChain = pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Backword;
	}

	pstAnnounceInfo = (ANNOUNCE_INFO*)pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Backword;


		tsn_Wrapper_MemSet((VOID *)&stTimeoutTimeWork, 0, sizeof(USCALEDNS));
		stTimeoutTimeWork.ulNsec_lsb = CONST10_9;

		if (!pstAnnounceInfo)
		{
			chA = pstPort->stPort_1588_DS.chLogAnnounceInterval;
		}
		else
		{
			chA = pstAnnounceInfo->stAnnoCmpInfoData.chLogMsgInterVal;
		}


		blRet = ptpShiftUSNs_CHAR(&stTimeoutTimeWork, chA, &stTimeoutTimeWork2);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

	while (pstAnnounceInfo != (ANNOUNCE_INFO*)&(pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Foreword))
	{
		blRet = ptpConvTS_USNs (&pstAnnounceInfo->stAnnoCmpInfoData.stAnnoRecvTime, &stUscaledOriginTimeStamp);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OVERFLOW);
		}
		
		tsn_Wrapper_MemSet( &stUscaledTimeWindow, 0, sizeof(USCALEDNS));

		ulTimeWindows = (ULONG)FOREIGN_MASTER_TIME_WINDOWS;
		blRet = ptpMultUSNs_ULONG (&stTimeoutTimeWork2, ulTimeWindows, &stUscaledAnnounceReceiptTMO);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

		blRet = ptpAddUSNs_USNs (&stUscaledOriginTimeStamp, &stUscaledAnnounceReceiptTMO, &stUscaledTMO);
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OVERFLOW);
		}

		chCompRet = ptpCompUSNs_USNs (&stCurrentTime, &stUscaledTMO);
		if (chCompRet > 0)
		{
			delAnnounceForForeign ((ANNOUNCE_INFO *)pstAnnounceInfo);
			pstForeignClock->usAnnMsgCnt --;
			pstAnnounceInfo = (ANNOUNCE_INFO*)(pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Backword);
		}
		else
		{
			break;
		}
	}
}

VOID	addAnnounceForForeign(FOREIGN_MASTER_INFO *pstForeignClock, PTPMSG_ANNOUNCE *pstAnnounce, PORTDATA* pstPort)
{
	ANNOUNCE_CHAIN			*pstAnnForeword;

	ANNOUNCE_INFO*			pstAnnoInfoBlk;

	pstAnnoInfoBlk = (ANNOUNCE_INFO*)ptp_MMalloc(CLOCK_NUM_0, PTP_MM_ANNO);

	if(pstAnnoInfoBlk)
	{
		pstAnnoInfoBlk->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority1 = pstAnnounce->uchGrandmasterPriority1;

		tsn_Wrapper_MemCpy(&pstAnnoInfoBlk ->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockQuality,
							&pstAnnounce->stGrandmasterClockQuality, sizeof(pstAnnounce->stGrandmasterClockQuality));

		pstAnnoInfoBlk ->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority2 = pstAnnounce->uchGrandmasterPriority2;

		tsn_Wrapper_MemCpy(&pstAnnoInfoBlk ->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockIdentity,
							&pstAnnounce->stGrandmasterIdentity, sizeof(pstAnnounce->stGrandmasterIdentity));

		pstAnnoInfoBlk ->stAnnoCmpInfoData.stBmcaCmpInfoData.usStepsRemoved = pstAnnounce->usStepsRemoved;

		pstAnnoInfoBlk->stAnnoCmpInfoData.byFlags0 = pstAnnounce->stHeader.byFlags0;
		pstAnnoInfoBlk->stAnnoCmpInfoData.byFlags1 = pstAnnounce->stHeader.byFlags1;
		pstAnnoInfoBlk->stAnnoCmpInfoData.uchTimeSource = pstAnnounce->uchTimeSource;

		tsn_Wrapper_MemCpy(&pstAnnoInfoBlk->stAnnoCmpInfoData.stBmcaCmpInfoData.stSenderPort, &pstAnnounce->stHeader.stSrcPortIdentity, sizeof(PORTIDENTITY));
		tsn_Wrapper_MemCpy(&pstAnnoInfoBlk->stAnnoCmpInfoData.stBmcaCmpInfoData.stReceiverPort, &pstPort->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));

		tsn_Wrapper_MemCpy(&pstAnnoInfoBlk->stAnnoCmpInfoData.stAnnoRecvTime,&pstAnnounce->stOriginTimestamp, sizeof(TIMESTAMP));
		pstAnnoInfoBlk->stAnnoCmpInfoData.sCurrentUtcOffset = pstAnnounce->sCurrentUtcOffset;
		pstAnnoInfoBlk->stAnnoCmpInfoData.chLogMsgInterVal  = pstAnnounce->stHeader.chLogMsgInterVal;


								 		
		pstAnnForeword = pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Foreword;

		pstForeignClock->stAnnounceMessageChain.pstAnnounceChain_Foreword = (ANNOUNCE_CHAIN *)&(pstAnnoInfoBlk->stAnnounceChain);
		pstAnnoInfoBlk->stAnnounceChain.pstAnnounceChain_Foreword = pstAnnForeword;
		pstAnnForeword->pstAnnounceChain_Backword = (ANNOUNCE_CHAIN *)&(pstAnnoInfoBlk->stAnnounceChain);
		pstAnnoInfoBlk->stAnnounceChain.pstAnnounceChain_Backword = &(pstForeignClock->stAnnounceMessageChain);
	}
}

VOID	delAnnounceForForeign(ANNOUNCE_INFO* pstAnnounceInfo)
{
	ANNOUNCE_CHAIN	*pstForeword;
	ANNOUNCE_CHAIN	*pstBackword;

	pstForeword = pstAnnounceInfo->stAnnounceChain.pstAnnounceChain_Foreword;
	pstBackword = pstAnnounceInfo->stAnnounceChain.pstAnnounceChain_Backword;

	pstForeword->pstAnnounceChain_Backword = pstBackword;
	pstBackword->pstAnnounceChain_Foreword = pstForeword;

	ptp_MMfree(CLOCK_NUM_0, PTP_MM_ANNO,(VOID*)pstAnnounceInfo);
}

VOID	releaseForeignAndAnnounce(PORTDATA* pstPort)
{
	PORTBMC_1588_GD *pstPortBmc1588Gd;
	FOREIGN_MASTER_INFO* pstForeignMaster;
	FOREIGN_MASTER_INFO* pstForeignMaster_Next;

	pstPortBmc1588Gd  = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);
	
	pstForeignMaster = (FOREIGN_MASTER_INFO *)pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_next;

	while (&pstPortBmc1588Gd->stForeignMasterChain != (FOREIGN_MASTER_CHAIN*)pstForeignMaster)
	{
		pstForeignMaster_Next = (FOREIGN_MASTER_INFO*)pstForeignMaster->stForeignMasterChain.pstForeignMaster_next;

		releaseAnnounceForForeignMaster(pstForeignMaster);
		delForForeignMaster(pstForeignMaster);

		pstForeignMaster = pstForeignMaster_Next;
	}
}

VOID	releaseAnnounceForForeignMaster(FOREIGN_MASTER_INFO* pstForeignMaster)
{
	ANNOUNCE_INFO*	pstAnnounceInfo;
	ANNOUNCE_INFO*	pstAnnounceInfo_next;

	pstAnnounceInfo_next = (ANNOUNCE_INFO *)pstForeignMaster->stAnnounceMessageChain.pstAnnounceChain_Foreword;
	
	while (pstAnnounceInfo_next != (ANNOUNCE_INFO*)&pstForeignMaster->stAnnounceMessageChain)
	{
		pstAnnounceInfo = pstAnnounceInfo_next;
		pstAnnounceInfo_next = (ANNOUNCE_INFO*)pstAnnounceInfo_next->stAnnounceChain.pstAnnounceChain_Foreword;
		delAnnounceForForeign(pstAnnounceInfo);
	}
}

VOID	initForeignMaster(PORTDATA* pstPort)
{
	PORTBMC_1588_GD *pstPortBmc1588Gd;

	pstPortBmc1588Gd  = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);

	pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_next = &pstPortBmc1588Gd->stForeignMasterChain;
	pstPortBmc1588Gd->stForeignMasterChain.pstForeignMaster_back = &pstPortBmc1588Gd->stForeignMasterChain;
}

VOID	delForForeignMaster(FOREIGN_MASTER_INFO *pstForeignMaster)
{
	pstForeignMaster->stForeignMasterChain.pstForeignMaster_back->pstForeignMaster_next = 
				pstForeignMaster->stForeignMasterChain.pstForeignMaster_next;
	pstForeignMaster->stForeignMasterChain.pstForeignMaster_next->pstForeignMaster_back = 
				pstForeignMaster->stForeignMasterChain.pstForeignMaster_back;

	ptp_MMfree(CLOCK_NUM_0, PTP_MM_FORE,(VOID*)pstForeignMaster);
}
#endif

#endif
