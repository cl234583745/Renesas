/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "ETH_api.h"
#include "ETH_sw.h"
#include "LSM_api.h"
#define ETHER_SW_PORT_SIZE		(NX_USHORT)3

#define GMAC_ETHMODE			(NX_ULONG)0xC0000000

#define MAX_FRM_LENGTH			(NX_USHORT)1522

#define BCAST_MSK				(NX_ULONG)0x00000004

#define MCAST_MSK				(NX_ULONG)0x00000004

#define UCAST_MSK				(NX_ULONG)0x00000000

#define ETHSW_MG_CONFIG			(NX_ULONG)0x00000002

#define VLAN_PRIORITY0_7		(NX_ULONG)0x006DB688
#define VLAN_EN					(NX_ULONG)0x00000001

#define BUSYINIT				(NX_ULONG)0x00000001

#define MINCELLS				(NX_ULONG)0x00000008
#define OUTQUEUE_PRIORITY		(NX_ULONG)0x08040201

#define MAC_CONFIG				(NX_ULONG)0x05800013

#define TX_MODE_LPTXEN			(NX_ULONG)0x40000000
#define TX_MODE_SF				(NX_ULONG)0x20000000

#define SYSPCMD1				(NX_ULONG)0x000000A5
#define SYSPCMD2				(NX_ULONG)0x00000001
#define SYSPCMD3				(NX_ULONG)0x0000FFFE
#define SYSPCMD4				(NX_ULONG)0x00000001
#define SYSPCMD5				(NX_ULONG)0x00000000

#define ETHSWMODE_1G			(NX_ULONG)0x00000005
#define ETHSWMODE_100M			(NX_ULONG)0x00000000

#define ETHSW_PORT_ENA			(NX_ULONG)0x00000007

#define ETHSW_TAG_CTRL			(NX_ULONG)0x8000E001

#define ETHSW_LUT_S_PORT0		((NX_UCHAR)1)
#define ETHSW_LUT_S_PORT1		((NX_UCHAR)2)
#define ETHSW_LUT_S_PORT2		((NX_UCHAR)4)
#define LUT_REC_INVALID			((NX_UCHAR)0)
#define LUT_REC_VALID			((NX_UCHAR)1)
#define LUT_RECTYPE_STATIC		((NX_UCHAR)1)

#define ETHSW_LUT_SIZE			((NX_USHORT)2048)
#define ETHSW_LUT_BLK_ENTRIES	((NX_USHORT)8)

#define BIT_NUM					((NX_USHORT)8)

#define	ETHSW_TSM_ATIME_INC		((NX_ULONG)0x00000008)
#define	ETHSW_DLR_CTRL			((NX_ULONG)0x00006400)

typedef	struct tagRECORD_INFO {
	NX_ULONG	ulMaclo;
	struct {
		NX_USHORT	usMachi;
		NX_USHORT	bRec_valid:1;
		NX_USHORT	bRec_type:1;
		NX_USHORT	bPriority:3;
		NX_USHORT	bPort0msk:1;
		NX_USHORT	bPort1msk:1;
		NX_USHORT	bPort2msk:1;
		NX_USHORT	bReserved:8;
	} sthi;
} RECORD_INFO;

NX_CONST NX_UCHAR gauchLLDPMultiMac[MAC_ADDR_SIZE] = {
	0x01, 0x80, 0xc2, 0x00, 0x00, 0x0E
};

NX_VOID vETH_SetStaticRecord(NX_UCHAR* puchMacAddr, NX_UCHAR uchPort);
NX_VOID vETH_UpdateMaclut(RECORD_INFO* pstRecordInfo, NX_UCHAR uchHash);
NX_UCHAR uchETH_GetCRC8 (NX_UCHAR* puchAddr, NX_USHORT usSize);


NX_VOID vETH_EtherSwInit (NX_VOID)
{
	NX_ULONG	ulLoop;
	NX_UCHAR	auchMacAddr[MAC_ADDR_SIZE];
	NX_ULONG*	pulMacAdrReg;
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
	
	RIN_SYS->SYSPCMD = SYSPCMD1;
	RIN_SYS->SYSPCMD = SYSPCMD2;
	RIN_SYS->SYSPCMD = SYSPCMD3;
	RIN_SYS->SYSPCMD = SYSPCMD4;
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		RIN_SYS->ETHSWMD = ETHSWMODE_100M;
	}
	else {
		RIN_SYS->ETHSWMD = ETHSWMODE_1G;
	}
	RIN_SYS->ETHSWMTC = ETHSW_TAG_CTRL;
	RIN_SYS->SYSPCMD = SYSPCMD5;

	
	RIN_ETH->GMAC_MODE = GMAC_ETHMODE;
	
	for (ulLoop = NX_ZERO; ulLoop < ETHER_SW_PORT_SIZE; ulLoop++) {
		RIN_ETHSW->SWCFG.VLAN_PRIORITY[ulLoop] =VLAN_PRIORITY0_7;
		RIN_ETHSW->SWCFG.PRIORITY_CFG[ulLoop] = VLAN_EN;
	}
	
	RIN_ETHSW->SWCFG.BCAST_DEFAULT_MASK = BCAST_MSK;
	RIN_ETHSW->SWCFG.MCAST_DEFAULT_MASK = MCAST_MSK;
	RIN_ETHSW->SWCFG.UCAST_DEFAULT_MASK = UCAST_MSK;
	RIN_ETHSW->SWCFG.MGMT_CONFIG        = ETHSW_MG_CONFIG;
	
	vNX_FillMemory32((void *)&RIN_ETHSW->LUT.ADR_TABLE[0], NX_L_ZERO, ETHSW_LUT_SIZE / sizeof(NX_ULONG));
	
	vNX_CopyMemory(&auchMacAddr[0], &gstAppInfo.stEthInfo.auchMacAddress[0], MAC_ADDR_SIZE);
	vETH_SetStaticRecord(&auchMacAddr[0], ETHSW_LUT_S_PORT2);
	
	RIN_ETHSW->SWCFG.PORT_ENA = ETHSW_PORT_ENA;
	
	while ( (RIN_ETHSW->SWCFG.OQMGR_STATUS & BUSYINIT) != NX_ZERO) {
	}
	
	RIN_ETHSW->SWCFG.QMGR_MINCELLS = MINCELLS;
	RIN_ETHSW->SWCFG.OQMGR_STATUS = NX_UL_ZERO;
	RIN_ETHSW->SWCFG.QMGR_ST_MINCELLS = NX_UL_ZERO;
	RIN_ETHSW->SWCFG.QMGR_WEIGHTS  = OUTQUEUE_PRIORITY;
	
	for (ulLoop = NX_ZERO; ulLoop < NX_PORT_SIZE; ulLoop++) {
		RIN_ETHSW->MAC[ulLoop].FRM_LENGTH  = MAX_FRM_LENGTH;
		RIN_ETHSW->MAC[ulLoop].COMMAND_CONFIG = MAC_CONFIG;
	}
	
	pulMacAdrReg = (NX_ULONG*)&RIN_ETH->GMAC_ADR0A;
	
	*pulMacAdrReg = (((NX_ULONG)auchMacAddr[3] << NX_SHIFT24) |
					((NX_ULONG)auchMacAddr[2] << NX_SHIFT16) |
					((NX_ULONG)auchMacAddr[1] << NX_SHIFT8) |
					((NX_ULONG)auchMacAddr[0] << NX_SHIFT0));
	*(pulMacAdrReg + 1) = (0x00FF0000 |
					((NX_ULONG)auchMacAddr[5] << NX_SHIFT8) |
					((NX_ULONG)auchMacAddr[4] << NX_SHIFT0));
	*(pulMacAdrReg + 2) = 
				   (((NX_ULONG)gauchLLDPMultiMac[3] << NX_SHIFT24) |
					((NX_ULONG)gauchLLDPMultiMac[2] << NX_SHIFT16) |
					((NX_ULONG)gauchLLDPMultiMac[1] << NX_SHIFT8) |
					((NX_ULONG)gauchLLDPMultiMac[0] << NX_SHIFT0));
	*(pulMacAdrReg + 3) = (0x00FF0000 |
					((NX_ULONG)gauchLLDPMultiMac[5] << NX_SHIFT8) |
					((NX_ULONG)gauchLLDPMultiMac[4] << NX_SHIFT0));
	RIN_ETH->GMAC_TXMODE |= (TX_MODE_LPTXEN | TX_MODE_SF);

	RIN_ETHSW->TSM.ATIME_INC = ETHSW_TSM_ATIME_INC;
	RIN_ETHSW->DLR.DLR_CONTROL = ETHSW_DLR_CTRL;
	
	return;
}

NX_VOID vETH_SetStaticRecord (
	NX_UCHAR*	puchMacAddr,
	NX_UCHAR	uchPort
)
{
	NX_UCHAR	uchHash;
	RECORD_INFO	stRecordInfo;
	
	vNX_FillMemory32(&stRecordInfo, NX_L_ZERO, sizeof(RECORD_INFO) / sizeof(NX_ULONG));
	
	stRecordInfo.ulMaclo			= (((NX_ULONG)puchMacAddr[3] << NX_SHIFT24) |
									  ((NX_ULONG)puchMacAddr[2] << NX_SHIFT16)  |
									  ((NX_ULONG)puchMacAddr[1] << NX_SHIFT8)   |
									  ((NX_ULONG)puchMacAddr[0] << NX_SHIFT0));
	stRecordInfo.sthi.usMachi		= (((NX_USHORT)puchMacAddr[5] << NX_SHIFT8) |
									  ((NX_USHORT)puchMacAddr[4] << NX_SHIFT0));
	
	
	if ((uchPort & ETHSW_LUT_S_PORT0) == ETHSW_LUT_S_PORT0) {
		stRecordInfo.sthi.bPort0msk = NX_ON;
	}
	if ((uchPort & ETHSW_LUT_S_PORT1) == ETHSW_LUT_S_PORT1) {
		stRecordInfo.sthi.bPort1msk = NX_ON;
	}
	if ((uchPort & ETHSW_LUT_S_PORT2) == ETHSW_LUT_S_PORT2) {
		stRecordInfo.sthi.bPort2msk = NX_ON;
	}

	stRecordInfo.sthi.bPriority = NX_ZERO;
	stRecordInfo.sthi.bRec_type = LUT_RECTYPE_STATIC;
	stRecordInfo.sthi.bRec_valid = LUT_REC_VALID;
	
	uchHash = uchETH_GetCRC8(puchMacAddr, MAC_ADDR_SIZE);
	
	vETH_UpdateMaclut(&stRecordInfo, uchHash);
	
	return;
}

NX_VOID vETH_UpdateMaclut (
	RECORD_INFO*	pstRecordInfo,
	NX_UCHAR		uchHash
)
{
	NX_USHORT		usAddrTblBlockEnd;
	NX_USHORT		usLoop;
	RECORD_INFO*	pstRecordInfoTmp;
	
	usAddrTblBlockEnd = uchHash + ETHSW_LUT_BLK_ENTRIES;
	
	pstRecordInfoTmp = (RECORD_INFO *)&RIN_ETHSW->LUT.ADR_TABLE[0];
	
	for (usLoop = uchHash; usLoop < usAddrTblBlockEnd; usLoop++) {
		if ((pstRecordInfoTmp->ulMaclo == pstRecordInfo->ulMaclo)
			&& (pstRecordInfoTmp->sthi.usMachi == pstRecordInfo->sthi.usMachi)) {
			break;
		}
		else if (pstRecordInfoTmp->sthi.bRec_type == LUT_REC_INVALID) {
			pstRecordInfoTmp[usLoop] = *pstRecordInfo;
			break;
		}
		else {
		}
	}
	
	return;
}

NX_UCHAR uchETH_GetCRC8 (
	NX_UCHAR* puchAddr,
	NX_USHORT usSize
)
{
	NX_USHORT	usCrc;
	NX_USHORT	usByteLoop;
	NX_USHORT	usBitLoop;
	NX_USHORT	usData;
	
	usCrc = 0x12;
	
	for (usByteLoop = NX_ZERO; usByteLoop < usSize; usByteLoop++) {
		usData = (NX_USHORT)(puchAddr[usByteLoop]) << NX_SHIFT8;
		usCrc |= usData;
		for (usBitLoop = NX_ZERO; usBitLoop < BIT_NUM; usBitLoop++) {
			if ((usCrc & (NX_USHORT)NX_BIT0) == (NX_USHORT)NX_BIT0) {
				usCrc ^= 0x01c0;
			}
			usCrc >>= NX_SHIFT1;
		}
	}
	
	return (NX_UCHAR)usCrc;
}


