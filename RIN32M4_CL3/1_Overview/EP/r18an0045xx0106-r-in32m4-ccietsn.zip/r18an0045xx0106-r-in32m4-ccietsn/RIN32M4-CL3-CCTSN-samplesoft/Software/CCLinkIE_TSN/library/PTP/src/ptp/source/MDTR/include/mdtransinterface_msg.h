/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDTRANSINTERFACE_MSG_H__
#define __MDTRANSINTERFACE_MSG_H__


#ifdef __cplusplus
extern "C" {
#endif

USHORT mdtra_ntoh_us(UCHAR* puchMsgPtr, USHORT* pusVal);
USHORT mdtra_ntoh_ul(UCHAR* puchMsgPtr, ULONG* pulVal);
USHORT mdtra_ntoh_FracN64(UCHAR* puchMsgPtr, FRAC_NSEC64* pstVal);
USHORT mdtra_ntoh_TInt(UCHAR* puchMsgPtr, TIME_INTERVAL* pstVal);
USHORT mdtra_ntoh_TS(UCHAR* puchMsgPtr, TIMESTAMP* pstVal);
USHORT mdtra_ntoh_SNs(UCHAR* puchMsgPtr, SCALEDNS* pstVal);
USHORT mdtra_ntoh_PortID(UCHAR* puchMsgPtr, PORTIDENTITY* pstVal);
USHORT mdtra_ntoh_CLKQLTY(UCHAR* puchMsgPtr, CLOCKQUALITY* pstVal);
USHORT mdtra_hton_us(USHORT usVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_ul(ULONG ulVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_FracN64(FRAC_NSEC64* pstVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_TInt(TIME_INTERVAL* pstVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_TS(TIMESTAMP* pstVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_SNs(SCALEDNS* pstVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_PortID(PORTIDENTITY* pstVal, UCHAR* puchMsgPtr);
USHORT mdtra_hton_CLKQLTY(CLOCKQUALITY* pstVal, UCHAR* puchMsgPtr);


USHORT ptp_Mdl_ntohMsgManagTLV(UCHAR* puchMsgPtr, PTPMSG_MANAGEMENT_TLV* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_0007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2003(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2004(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2008(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2009(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200A(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200B(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200C(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200D(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200E(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_200F(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2010(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2011(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2012(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2013(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2014(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2015(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2016(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2017(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2018(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2019(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2100(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2101(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_2102(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_4000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_4001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_4002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_6000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);
USHORT ptp_Mdl_ntoh_MgtId_6001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg, USHORT usTLVLen);

USHORT ptp_Mdl_htonMsgManagTLV(UCHAR* puchMsgPtr, PTPMSG_MANAGEMENT_TLV* pstPtpmsg);

USHORT ptp_Mdl_hton_MgtId_0000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_0001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_0002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_0005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_0006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_0007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2003(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2004(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2005(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2006(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2007(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2008(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2009(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200A(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200B(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200C(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200D(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200E(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_200F(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2010(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2011(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2012(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2013(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2014(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2015(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2016(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2017(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2018(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2019(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2100(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2101(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_2102(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_4000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_4001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_4002(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_6000(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);
USHORT ptp_Mdl_hton_MgtId_6001(UCHAR* puchMsgPtr, MGT_DATAFIELD* pstPtpmsg);

#ifdef __cplusplus
}
#endif

#endif
