/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_IEEE1588

#include "MDPdelayReq.h"
#include "MDPdelayReq_1588.h"

#ifdef	PTP_USE_ME_HW_ASSIST
#include "MDPdelayReq_1AS.h"
#endif

#define D_FUNC	0
#define D_DBG	0

VOID (*const MDPdelayReq_1588_Matrix[DMDPDRQ_STATUS_MAX][DMDPDRQ_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDPdelayReq_01_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588},
	{&MDPdelayReq_01_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_03_1588, &MDPdelayReq_04_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_04_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_03_1588, &MDPdelayReq_04_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_05_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_06_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_07_1588, &MDPdelayReq_08_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_06_1588, &MDPdelayReq_00_1588},
	{&MDPdelayReq_02_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_NP_1588, &MDPdelayReq_04_1588, &MDPdelayReq_00_1588}
};

VOID MDPdelayReq_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYREQ_EV	enEvt = MDPDRQ_E_EVENT_MAX;
	MDPDELAYREQ_ST	enSts = MDPDRQ_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82080001);

	enEvt = GetMDPdelayReqEvent(usEvent, pstPort);

	enSts = GetMDPdelayReqStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDPdelayReq_1588         ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDPDRQ_STATUS_MAX) && (enEvt != MDPDRQ_E_EVENT_MAX))
	{
		(*MDPdelayReq_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDPdelayReqStatus(pstPort);
	printf ("<END  > [%02d]MDPdelayReq_1588         ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDPdelayReq_00_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDPdelayReq_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	(VOID)MDPdelayTimeStop( pstGbl, pstPort,pstPort->stPort_1588_GD.pstCmldsPortDs );

	MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDPdelayReq_00_1588::-\n") );
	return;
}

VOID MDPdelayReq_01_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	BOOL			blRet = FALSE;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	blRet = MDPdlyReq_IntSndPDReq_1588(pstGbl, pstPort);
	if (blRet)
	{
		MDPdelayTimeStart(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_INITIAL_SEND_PDREQ, pstPort);
	}
	else
	{
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
	}
	return;
}

VOID MDPdelayReq_02_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	BOOL			blRet;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_02_1588::+\n"));

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	(VOID)MDPdelayTimeStop( pstGbl, pstPort, pstPort->stPort_1588_GD.pstCmldsPortDs );

	blRet = MDPdlyReq_IntSndPDReq_1588(pstGbl, pstPort);
	if (blRet)
	{
		MDPdelayTimeStart(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_INITIAL_SEND_PDREQ, pstPort);
	}
	else
	{
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
	}

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_02_1588::-\n"));

	return;
}

VOID MDPdelayReq_03_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_8200250C);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
		return;
	}

	if (SetMDPdlyReqEvEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_8200250B);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
		return;
	}

	MDPdlyReq_WtFrPDResp_1588(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDRESP, pstPort);
	return;
}

VOID MDPdelayReq_04_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	MDPdlyReq_SndPDReq_1588(pstGbl, pstPort);
	MDPdelayTimeStart(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_SEND_PDELAY_REQ, pstPort);
	return;
}

VOID MDPdelayReq_05_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1588::+\n"));
	ptp_dbg_msg(D_DBG , ("(B)ulRxPdelayResponseCount[%d]\n", pstPort->stPort_1588_GD.pstCmldsPortStatDs->ulRxPdelayResponseCount));

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayResp_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001608);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1588::-\n"));

		return;
	}

	IncMDPDlyReqRxPDlyRespCount(pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	if (SetMDPdlyRespEvIngresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_8200160B);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1588::-\n"));

		return;
	}

	if (JugMDPdlyReq_PDRsp_1588(pstGbl) == FALSE)
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001600);
		MDPdlyReq_Reset_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1588::-\n"));

		return;
	}

	SetMDPdlyReqMgIngresTmstmp_1588(pstGbl, pstPort);

	if (IsDecMDPdelayTwoStep_1588(pstGbl->pstRcvdPdelayResp))
	{
		MDPdlyReq_WtFrPDRpFollowUp_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDRESP_FOLLOWUP, pstPort);
	}
	else
	{
		MDPdlyReq_OneWtFrPDlyIntvl_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDELAY_INTV_TM, pstPort);
	}

	ptp_dbg_msg(D_DBG , ("(A)ulRxPdelayResponseCount[%d]\n", pstPort->stPort_1588_GD.pstCmldsPortStatDs->ulRxPdelayResponseCount));
	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_05_1588::-\n"));

	return;
}

VOID MDPdelayReq_06_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_06_1588::+\n"));

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	MDPdlyReq_Reset_1588(pstGbl, pstPort);

	IncMDPDlyReqRxPTPPcktDscrdCount( pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	MDPdlyReq_SndPDReq_1588(pstGbl, pstPort);
	MDPdelayTimeStart(pstGbl, pstPort);
	SetMDPdelayReqStatus(MDPDRQ_SEND_PDELAY_REQ, pstPort);

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_06_1588::+\n"));
	return;
}

VOID MDPdelayReq_07_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_07_1588::+\n"));

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayResp_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001608);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);
		return;
	}

	IncMDPDlyReqRxPDlyRespCount(pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	if (JugMDPdlyReq_PDRsp_1588(pstGbl))
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001700);
		MDPdlyReq_Reset_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001600);
	}

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_07_1588::-\n"));

	return;
}

VOID MDPdelayReq_08_1588(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1588::+\n"));

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	if (ConMDPdelayRespFollowUp_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001708);
		MDPdlyReq_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1588::-\n"));

		return;
	}

	IncMDPDlyReqRxPDRpFollowUpCount(pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	if (JugMDPdlyReq_PDRspFollowUp_1588(pstGbl))
	{
		SetMDPdlyRespMgEgresTmstmp_1588(pstGbl, pstPort);
		MDPdlyReq_TwoWtFrPDlyIntvl_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_WAIT_FOR_PDELAY_INTV_TM, pstPort);
	}
	else
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001600);
		MDPdlyReq_Reset_1588(pstGbl, pstPort);
		SetMDPdelayReqStatus(MDPDRQ_RESET, pstPort);
	}

	ptp_dbg_msg(D_FUNC, ("MDPdelayReq_08_1588::-\n"));

	return;
}

VOID MDPdelayReq_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDPdlyReq_NotEnable_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS*		pstPort1ASDS	= &pstPort->stPort_1AS_DS;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_NotEnable_1588::+\n"));

	pstPort1ASDS->blAsCapable = TRUE;
	pstSmGbl->blRcvdPdelayResp = FALSE;
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	
	ptp_dbg_msg(D_DBG , ("uchMaxStackCount = [%d]\n", pstPort->stPort_GD.pstPdlyIntStackMan->uchMaxStackCount));
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_NotEnable_1588::-\n"));

	return TRUE;
}

BOOL MDPdlyReq_IntSndPDReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD*		pstPortGD		= &pstPort->stPort_GD;
	PORT_1AS_DS*	pstPort1ASDS	= &pstPort->stPort_1AS_DS;
	CMLDSPORT_1AS_DS*	pstCmldsPortDS = pstPort->stPort_1588_GD.pstCmldsPortDs;

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1588::+\n"));

	pstSmGbl->blInitPdelayRespReceived = FALSE;

	pstSmGbl->blRcvdPdelayResp = FALSE;
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	pstPortGD->dbNeighborRateRatio = 1.0;
	pstCmldsPortDS->lNeighborRateRatio = 0;
	pstPort1ASDS->blAsCapable = TRUE;

	if (pstCmldsPortDS->blCmldsPortEnabled == FALSE)
	{
		ptp_dbg_msg(D_DBG , ("lNeighborRateRatio       = [%d]\n"
			, pstPort->stPort_1588_GD.pstCmldsPortDs->lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	pstSmGbl->usPdelayReqSequenceId = (USHORT)tsn_Wrapper_Rand();

	if (SetPdelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, pstPort->stPort_1588_GD.pstCmldsPortDs->lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_DBG, ("lNeighborRateRatio       = [%d]\n"
			, pstPort->stPort_1588_GD.pstCmldsPortDs->lNeighborRateRatio));
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyReqTxPDlyReqCount( pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	pstSmGbl->usLostResponses = 0;
	pstSmGbl->usDelectedFaults = 0;




	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_IntSndPDReq_1588::-\n"));

	return TRUE;
}

BOOL MDPdlyReq_Reset_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdPdelayResp = FALSE;
	return TRUE;
}

BOOL MDPdlyReq_SndPDReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1588::+\n"));


	if (pstPort->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	pstSmGbl->usPdelayReqSequenceId++;

	if (SetPdelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayReq_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyReqTxPDlyReqCount( pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	ptp_dbg_msg(D_FUNC, ("MDPdlyReq_SndPDReq_1588::-\n"));
	return TRUE;
}

BOOL MDPdlyReq_WtFrPDResp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	return TRUE;
}

BOOL MDPdlyReq_WtFrPDRpFollowUp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdPdelayResp = FALSE;
	return TRUE;
}

BOOL MDPdlyReq_TwoWtFrPDlyIntvl_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;

	if (computeMDPdelayRateRatio_1588(pstSmGbl, pstPort))
	{
		computeMDPdelayPropTime_1588(TRUE, pstSmGbl, pstPort);
	}
	return TRUE;
}

BOOL MDPdlyReq_OneWtFrPDlyIntvl_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdPdelayRespFollowUp = FALSE;

	if (computeMDPdelayRateRatio_1588(pstSmGbl, pstPort))
	{
		computeMDPdelayPropTime_1588(FALSE, pstSmGbl, pstPort);
	}
	return TRUE;
}

BOOL JugMDPdlyReq_PDRsp_1588(MDPREQSM_GD* pstSmGbl)
{
	PTPMSG_PDELAY_RESP_1588*	pstMsgPdelayResp = &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1588;
	PTPMSG_PDELAY_REQ_1588*		pstMsgPdelayReq = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1588;

	if (pstMsgPdelayResp->stHeader.usSequenceId != pstMsgPdelayReq->stHeader.usSequenceId)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgPdelayResp->stReqPortIdentity.stClockIdentity,
		&pstMsgPdelayReq->stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgPdelayResp->stReqPortIdentity.usPortNumber
		!= pstMsgPdelayReq->stHeader.stSrcPortIdentity.usPortNumber)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL JugMDPdlyReq_PDRspFollowUp_1588(MDPREQSM_GD* pstSmGbl)
{
	PTPMSG_PDRESP_FOLLOWUP_1588*	pstMsgPdelayRespFollowUp
											= &pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1588;
	PTPMSG_PDELAY_RESP_1588*		pstMsgPdelayResp
											= &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1588;
	PTPMSG_PDELAY_REQ_1588*		pstMsgPdelayReq = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1588;
	if (pstMsgPdelayRespFollowUp->stHeader.usSequenceId != pstMsgPdelayReq->stHeader.usSequenceId)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgPdelayRespFollowUp->stHeader.stSrcPortIdentity.stClockIdentity,
		&pstMsgPdelayResp->stHeader.stSrcPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgPdelayRespFollowUp->stHeader.stSrcPortIdentity.usPortNumber
		!= pstMsgPdelayResp->stHeader.stSrcPortIdentity.usPortNumber)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ConMDPdelayResp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayResp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001609);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayResp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_8200160A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPdlyResp_1588,
		&pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1588, sizeof(pstPortMD->stConPdlyResp_1588));

	return TRUE;
}

BOOL ConMDPdelayRespFollowUp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayRespFollowUp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82001709);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayRespFollowUp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_8200170A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPDRespFlwUp_1588,
		&pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1588, sizeof(pstPortMD->stConPDRespFlwUp_1588));

	return TRUE;
}

VOID SetMDPdlyReqMgIngresTmstmp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_PDELAY_RESP_1588*	pstMsgPdelayResp
		= &pstSmGbl->pstRcvdPdelayResp->stPdlyResp_1588;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqMsgIngressTimestamp,
		&pstMsgPdelayResp->stReqRcptTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqMsgIngressCorrection,
		&pstMsgPdelayResp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

VOID SetMDPdlyRespMgEgresTmstmp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_PDRESP_FOLLOWUP_1588*	pstMsgPdelayRespFollowUp
		= &pstSmGbl->pstRcvdPdelayRespFollowUp->stPDRespFlwUp_1588;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespMsgEgressTimestamp,
		&pstMsgPdelayRespFollowUp->stRespOrgnTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespMsgEgressCorrection,
		&pstMsgPdelayRespFollowUp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL SetPdelayReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*	pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*	pstClkDefaultDS	= &pstClockDT->stDefaultDS;
	PORT_DS*	pstPortDS			= &pstPort->stPortDS;

	PTPMSG_PDELAY_REQ_1588*	pstMsg = NULL;

	pstMsg = &pstSmGbl->stTxPdelayReq.stTxPdelayReq_1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDELAY_REQ );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;

	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstSmGbl->usPdelayReqSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_REQ;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemSet(&pstMsg->stOriginTimestamp, 0, sizeof(pstMsg->stOriginTimestamp));
	tsn_Wrapper_MemSet(&pstMsg->uchReserved, 0, sizeof(pstMsg->uchReserved));
	GetPTPMSG_PDELAY_REQ_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL TxPdelayReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDPdelayReq;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayReq.stTxPdelayReq_1588,
		pstSmGbl->stTxPdelayReq.stTxPdelayReq_1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_82002508);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL computeMDPdelayRateRatio_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD*	pstPortGD	= &pstPort->stPort_GD;
	CMLDSPORT_1AS_DS*	pstCmldsPortDS = pstPort->stPort_1588_GD.pstCmldsPortDs;

	DOUBLE	dbRatio = 0.0;
	BOOL	blRet	= FALSE;

	blRet = CalMDPdlyRateRatio_1588(pstSmGbl, pstPort, &dbRatio);
	if (blRet)
	{
		pstPortGD->dbNeighborRateRatio		= dbRatio;
		dbRatio = ((pstPortGD->dbNeighborRateRatio - DBCONST1_0) * DBCONST2_41);
		if (dbRatio >= DBCONST2_32)
		{
			dbRatio = (DBCONST2_32 - 1);
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ_1588, PTP_LOGVE_OVERFLOW);
		}
		pstCmldsPortDS->lNeighborRateRatio = (LONG)dbRatio;

	}
	return blRet;
}

BOOL CalMDPdlyRateRatio_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort, DOUBLE* pdbRateRatio)
{
	*pdbRateRatio = 1.0;
	return TRUE;
}

BOOL computeMDPdelayPropTime_1588(BOOL blTwoStepFlag, MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*						pstPortMD	= &pstPort->stPortMD_GD;

	CURRENT_1588_DS*				pstCurrentDS = &pstPort->pstClockData->stCurrent_1588_DS;
	PORT_1588_DS*					pstPortDS	= &pstPort->stPort_1588_DS;

	BOOL			blRet	= FALSE;
	SCALEDNS		stA_Ns;
	SCALEDNS		stB_Ns;
	SCALEDNS		stC_Ns;
	SCALEDNS		stD_Ns;
	SCALEDNS		stE_Ns;
	SCALEDNS		stF_Ns;

	CHAR			chCmpAB		= 0;
	USCALEDNS		stTemp_UNs;

	if (blTwoStepFlag)
	{
		ptpSubTS_TS(
			&pstPortMD->stPdlyRespEventIngressTimestamp,
			&pstPortMD->stPdlyReqEventEgressTimestamp,
			&stA_Ns);
		ptpSubTS_TS(
			&pstPortMD->stPdlyRespMsgEgressTimestamp,
			&pstPortMD->stPdlyReqMsgIngressTimestamp,
			&stB_Ns);
		ptpAddTInt_TInt(&pstPortMD->stConPdlyResp_1588.stHeader.stCorrectionField,
						&pstPortMD->stConPDRespFlwUp_1588.stHeader.stCorrectionField,
						&stF_Ns);


#ifndef	PTP_USE_ME_HW_ASSIST

		ptpSubSNs_SNs(&stA_Ns, &stB_Ns, &stC_Ns);
		ptpSubSNs_SNs (&stC_Ns, &stF_Ns, &stD_Ns);
		blRet = ptpShiftSNs_CHAR(&stD_Ns, (CHAR)(-1), &stE_Ns);

#else
		ptpDivSNs_Doub (&stF_Ns, pstPort->pstClockData->stClock_GD.dbRateRatio, &stD_Ns);
		ptpDivSNs_Doub (&stB_Ns, pstPort->pstClockData->stClock_GD.dbRateRatio, &stE_Ns);

		ptpSubSNs_SNs(&stA_Ns, &stD_Ns, &stC_Ns);
		ptpSubSNs_SNs(&stC_Ns, &stE_Ns, &stD_Ns);

		blRet = ptpShiftSNs_CHAR(&stD_Ns, (CHAR)(-1), &stC_Ns);

		ptpMultSNs_Doub (&stC_Ns, pstPort->pstClockData->stClock_GD.dbRateRatio, &stE_Ns);

#endif
	}
	else
	{
		ptpSubTS_TS(
			&pstPortMD->stPdlyRespEventIngressTimestamp,
			&pstPortMD->stPdlyReqEventEgressTimestamp,
			&stA_Ns);

#ifndef	PTP_USE_ME_HW_ASSIST
		ptpSubSNs_TInt(&stA_Ns,
			&pstPortMD->stConPdlyResp_1588.stHeader.stCorrectionField, &stD_Ns);
		blRet = ptpShiftSNs_CHAR(&stD_Ns, (CHAR)(-1), &stE_Ns);
#else
		{
			FRAC_NSEC64	stTint_A ={0};

			ptpAddTInt_TInt(&pstPortMD->stConPdlyResp_1588.stHeader.stCorrectionField, &stTint_A, &stC_Ns);
			ptpDivSNs_Doub (&stC_Ns, pstPort->stPort_GD.dbNeighborRateRatio, &stE_Ns);
			ptpSubSNs_SNs (&stA_Ns, &stE_Ns, &stD_Ns);
			blRet = ptpShiftSNs_CHAR(&stD_Ns, (CHAR)(-1), &stC_Ns);

			ptpMultSNs_Doub (&stC_Ns, pstPort->pstClockData->stClock_GD.dbRateRatio, &stE_Ns);
		}
#endif

	}

	if (stE_Ns.sNsec_msb < 0)
	{
		return FALSE;
	}

	chCmpAB = ptpCompUSNs_SNs(&pstPort->pstClockData->stClock_GD.stAveDelayTrash, &stE_Ns);
	if (chCmpAB != COMP_A_LESS)
	{

		if (pstPort->stPort_GD.ulPropDelayNumber == 0)
		{
			ptpConvSNs_USNs (&stE_Ns, &pstPort->stPort_GD.stAveDelayTime);
			ptpConvSNs_TInt (&stE_Ns, &pstCurrentDS->stMeanPathDelay);
			pstPortDS->stPeerMeanPathDelay = pstCurrentDS->stMeanPathDelay;
			
			pstPort->stPort_GD.ulPropDelayNumber ++;
		}
		else
		{

			ptpAddUSNs_SNs(&pstPort->stPort_GD.stAveDelayTime, &stE_Ns, &stTemp_UNs);
			ptpShiftUSNs_CHAR(&stTemp_UNs, (CHAR)-1, &pstPort->stPort_GD.stAveDelayTime);
			ptpConvUSNs_SNs(&pstPort->stPort_GD.stAveDelayTime, &stE_Ns);
			ptpConvSNs_TInt(&stE_Ns, &pstCurrentDS->stMeanPathDelay);

			pstPortDS->stPeerMeanPathDelay = pstCurrentDS->stMeanPathDelay;


			if ((pstPort->stPort_GD.ulPropDelayNumber + 1) != 0)
			{
				pstPort->stPort_GD.ulPropDelayNumber ++;
			}
		}

	}
	else
	{
		ptpConvUSNs_SNs(&pstPort->stPort_GD.stAveDelayTime, &stE_Ns);
		ptpConvSNs_TInt(&stE_Ns, &pstCurrentDS->stMeanPathDelay);
		pstPortDS->stPeerMeanPathDelay = pstCurrentDS->stMeanPathDelay;
	}

	SetMDPdelayTimestampInfo(pstSmGbl, pstPort);
	return blRet;
}

#endif
