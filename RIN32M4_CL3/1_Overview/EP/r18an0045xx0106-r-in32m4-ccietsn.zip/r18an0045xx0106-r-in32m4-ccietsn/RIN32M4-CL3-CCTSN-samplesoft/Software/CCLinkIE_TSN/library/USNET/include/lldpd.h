//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _LLDPD_H_
#define _LLDPD_H_


#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif

#ifndef TVLS_TX_EN_PORTDES
#define TVLS_TX_EN_PORTDES      (1 << 0)
#endif
#ifndef TVLS_TX_EN_SYSNAME
#define TVLS_TX_EN_SYSNAME      (1 << 1)
#endif
#ifndef TVLS_TX_EN_SYSDES
#define TVLS_TX_EN_SYSDES       (1 << 2)
#endif
#ifndef TVLS_TX_EN_SYSCAP
#define TVLS_TX_EN_SYSCAP       (1 << 3)
#endif

#define LLDPD_PORT_NUM          MSW_LLDP_PORT_NUM
#define LLDPD_MC_NUM            1
#define LLDPD_MANADDR_NUM       MSW_LLDP_MNGTLV_NUM
#define LLDPD_REM_TBL_NUM       16
#define LLDPD_UNKOWN_TLV_SIZE   LLDPD_MAX_TLV_SZ
#define LLDPD_ORGDEF_TLV_SIZE   LLDPD_MAX_TLV_SZ
#define LLDPD_FRAME_LENGTH      1514
#define LLDPD_TIMER_PERIOD      1000

#define LLDPD_DEF_TX_CREDIT_MAX     5
#define LLDPD_DEF_TX_FAST_INIT      4
#define LLDPD_DEF_REINIT_DELAY      2
#define LLDPD_DEF_TX_HOLD           4
#define LLDPD_DEF_TX_INTERVAL       30

#define LLDPD_DEF_FAST_TX_INTERVAL  1
#define LLDPD_DEF_NOTIFIY_INTERVAL  5

#define LLDPD_MIN_TX_CREDIT_MAX     1
#define LLDPD_MAX_TX_CREDIT_MAX     10
#define LLDPD_MIN_TX_FAST_INIT      1
#define LLDPD_MAX_TX_FAST_INIT      8
#define LLDPD_MIN_REINIT_DELAY      1
#define LLDPD_MAX_REINIT_DELAY      10
#define LLDPD_MIN_TX_HOLD           1
#define LLDPD_MAX_TX_HOLD           100
#define LLDPD_MIN_TX_INTERVAL       1
#define LLDPD_MAX_TX_INTERVAL       3600
#define LLDPD_MIN_FAST_TX_INTERVAL  1
#define LLDPD_MAX_FAST_TX_INTERVAL  3600
#define LLDPD_MIN_NOTIFIY_INTERVAL  5
#define LLDPD_MAX_NOTIFIY_INTERVAL  3600

#define LLDPD_REMDATA_NOUSE         0
#define LLDPD_REMDATA_INUSE         1

#define LLDPD_NEAREST_BRIDGE_BM             (RX_NEAREST_BRIDGE | \
                                             TX_NEAREST_BRIDGE | \
                                             ACCEPT_DEF_MCBITMAP)
#define LLDPD_NEAREST_NONTPMR_BRIDGE_BM     (RX_NEAREST_NONTPMR_BRIDGE | \
                                             TX_NEAREST_NONTPMR_BRIDGE | \
                                             ACCEPT_DEF_MCBITMAP)
#define LLDPD_NEAREST_CUSTOMER_BRIDGE_BM    (RX_NEAREST_CUSTOMER_BRIDGE | \
                                             TX_NEAREST_CUSTOMER_BRIDGE | \
                                             ACCEPT_DEF_MCBITMAP)

#define usswLldpdLock()   { if (usswLldpdLockFunc != NULL)   usswLldpdLockFunc(); }
#define usswLldpdUnLock() { if (usswLldpdUnLockFunc != NULL) usswLldpdUnLockFunc(); }

#define LLDPD_SETTING_NUM_MAX	2

typedef struct LLDPD_SETTING_MADDR {
    unsigned char status;
    unsigned char mAddrSubtype;
    unsigned char mAddr[Max_SZMNG_ADDR];
    unsigned char ifNumSubtype;
    MSW_TLV_MNGOBJ_T oid;
} LLDPD_SETTING_MADDR_T;

typedef struct LLDPD_SETTING {
    char ifname[MSW_LLDP_IFNAME_LEN];
    char ifname2[MSW_LLDP_IFNAME_LEN];
    unsigned char portEnabled;
    unsigned short sysCap;
    unsigned short enblCap;

    unsigned char mcBitmap;
    unsigned char adminStatus;
    unsigned long msgTxInterval;
    unsigned long msgTxHold;
    unsigned long reinitDelay;
    unsigned long notifiyInterval;
    unsigned long txCreditMax;
    unsigned long msgFastTx;
    unsigned long txFastInit;
    unsigned char notifiyEnableV2;
    unsigned char tLVsTxEnableV2;

    unsigned char chassisSubtype;
    unsigned char chassisId[Max_SZCHASSIS_INFO];

    unsigned char portSubtype;
    unsigned char portId[Max_SZPORTID_INFO];


    unsigned char portDes[Max_SZPORTDES_INFO];

    unsigned char sysName[Max_SZSYSNAME_INFO];

    unsigned char sysDes[Max_SZSYSDES_INFO];


    LLDPD_SETTING_MADDR_T maddrTlv[MSW_LLDP_MNGTLV_NUM];
} LLDPD_SETTING_T;

enum {
    TX_TIMER_BEGIN,
    TX_TIMER_INITIALIZE,
    TX_TIMER_IDLE,
    TX_TICK,
    TX_FAST_START,
    TX_TIMER_EXPIRES,
    SIGNAL_TX
};

enum {
    LLDP_WAIT_PORT_OPERATIONAL,
    DELETE_AGED_INFO,
    RX_LLDP_INITIALIZE,
    RX_WAIT_FOR_FRAME,
    RX_FRAME,
    UPDATE_INFO,
    DELETE_INFO
};

enum {
    TX_BEGIN,
    TX_LLDP_INITIALIZE,
    TX_IDLE,
    TX_INFO_FRAME, 
    TX_SHUTDOWN_FRAME
};

typedef struct LLDPD_TX_TIM_STATE {
    int state;
    unsigned char txTick;
    unsigned short txTTR;
} LLDPD_TX_TIM_STATE_T;

typedef struct LLDPD_RX_STATE {
    int state;
    unsigned char inFrame[LLDPD_FRAME_LENGTH];
    MSW_TLVS_T tlvs;
    int frameLen;
    unsigned char newNghbr;
    unsigned char rxInfoAge;
    unsigned char rcvFrame;
    unsigned char badFrame;
    unsigned short rxTTL;
    unsigned char rxChanges;
    unsigned char remoteChange;
    unsigned char tooManyNghbrs;
    unsigned short tooManyNghbrsTimer;
} LLDPD_RX_STATE_T;

typedef struct LLDPD_TX_STATE {
    int state;
    unsigned char  outFrame[LLDPD_FRAME_LENGTH];
    int frameLen;
    unsigned char  localChange;
    unsigned char  txNow;
    unsigned short txFast;
    unsigned short txCredit;
    unsigned short txShutdownWhile;
    int txShutdownSend;
    unsigned short txTTL;
} LLDPD_TX_STATE_T;



typedef struct LLDPD_CONFIG {
    unsigned long msgTxInterval;
    unsigned long msgTxHold;
    unsigned long reinitDelay;
    unsigned long notifiyInterval;
    unsigned long txCreditMax;
    unsigned long msgFastTx;
    unsigned long txFastInit;
    int notifiyEnableV2;
    unsigned char tLVsTxEnableV2;
} LLDPD_CONFIG_T;



typedef struct LLDPD_STAT {
    MSW_INFO_T statInfo;
    unsigned long rxAgeoutsTotal;
} LLDPD_STAT_T;



typedef struct LLDPD_REM_TBL {
    struct LLDPD_REM_TBL *next;
    struct LLDPD_REM_TBL *prev;
    int state;
    unsigned long remIndex;
    MSW_TLVS_T tlvs;
    unsigned short  rxinfoTTL;
    char remUnknownTLV[LLDPD_UNKOWN_TLV_SIZE];
    unsigned char orgDefInfo[LLDPD_ORGDEF_TLV_SIZE];
} LLDPD_REM_TBL_T;

typedef struct LLDPD_AGENT {
    int agentEnabled;
    unsigned char mcBitmap;
    LLDPD_TX_TIM_STATE_T txTimState;
    LLDPD_TX_STATE_T txState;
    LLDPD_RX_STATE_T rxState;
    LLDPD_CONFIG_T lldpdConfig;
    LLDPD_STAT_T lldpdStat;
    LLDPD_REM_TBL_T *pLldpdRemData;
    void *port;
} LLDPD_AGENT_T;


typedef struct LLDPD_PORT {
    int portEnabled;
    int prePortEnabled;
    int netno;
    short portno;

    LLDPD_AGENT_T lldpdAgent[LLDPD_MC_NUM];
} LLDPD_PORT_T;


typedef struct LLDPD_MIB {
    unsigned long msgTxInterval;
    unsigned long msgTxHoldMult;
    unsigned long reinitDelay;
    unsigned long notifiyInterval;
    unsigned long txCreditMax;
    unsigned long msgFastTx;
    unsigned long txFastInit;
    unsigned short locSysCapSup;
    unsigned short locSysCapEna;

    unsigned long tblLastChangeTime;
    unsigned long remTblInserts;
    unsigned long remTblDeletes;
    unsigned long remTblDrops;
    unsigned long remTblAgeouts;

    LLDPD_PORT_T lldpdPort[LLDPD_PORT_NUM];

    void (*somethingChangedRemoteCb)(void *);
} LLDPD_MIB_T;

typedef struct LLDPD_HWPORT {
    int netno;
    char ifname[MSW_LLDP_IFNAME_LEN];
} LLDPD_HWPORT_T;

extern LLDPD_REM_TBL_T rem_tbl[LLDPD_REM_TBL_NUM];
extern LLDPD_MIB_T lldpdMib;

extern LLDPD_HWPORT_T lldpdhwport[LLDPD_PORT_NUM];


extern int lldpdRun(void);
void lldpdPortReset(void);
void lldpdPortEnable(int netno);
void lldpdPortDisable(int netno);
extern int lldpdSetLockFunc(void *func);
extern int lldpdSetUnLockFunc(void *func);
extern int lldpdStop(void);

extern void lldpdTimerFlagSet(int flag);
extern void lldpdTimer(int netno);
extern void lldpdLstChgTimSet(LLDPD_AGENT_T *agent);
extern int lldpdAdminStatusGet(char *ifname, unsigned char mcBitmap, 
                unsigned char *adminStatus);
#ifdef LLDPD_DEBUG
extern void lldpdTlvDump(MSW_TLVS_T *tlv);
extern void lldpdInfoDump(LLDPD_STAT_T *lldpdStat);
extern void lldpdRemDataShow(int pix, int mix, int flag);
#endif
extern LLDPD_REM_TBL_T *lldpdRemDataGet(void);
extern void lldpdRemDataRel(LLDPD_REM_TBL_T *remTbl);
extern LLDPD_REM_TBL_T *lldpdRemTblAdd(LLDPD_AGENT_T *agent);
extern int lldpdRemTblDel(LLDPD_AGENT_T *agent, MSW_TLVS_T *tlvs);
extern LLDPD_REM_TBL_T *lldpdRemTblGet(LLDPD_AGENT_T *agent, MSW_TLVS_T *tlvs);
extern void lldpdRxFrameCb(unsigned char *inframe, unsigned short len, 
                const MSW_LLDP_LOCAL_INFO_T *info);
extern void somethingChangedRemoteCbSet(void (*func)(void *));

extern void lldpdTxUpdateTimer(LLDPD_AGENT_T *agent);
extern void lldpdTxTimSmInit(LLDPD_AGENT_T *agent);
extern void lldpdTxTimSmRun(LLDPD_AGENT_T *agent);

extern void lldpdTxSmInit(LLDPD_AGENT_T *agent);
extern void lldpdTxSmRun(LLDPD_AGENT_T *agent);
extern void somethingChangedLocal(LLDPD_AGENT_T *agent);

extern void lldpdRxUpdateTimer(LLDPD_AGENT_T *agent);
extern void lldpdRxSmInit(LLDPD_AGENT_T *agent);
extern void lldpdRxSmRun(LLDPD_AGENT_T *agent);

extern void (*usswLldpdLockFunc)(void);
extern void (*usswLldpdUnLockFunc)(void);

extern void snmplldpdTask(int netno);
extern void ussLLDPAgentTrap(void *param);

#endif
