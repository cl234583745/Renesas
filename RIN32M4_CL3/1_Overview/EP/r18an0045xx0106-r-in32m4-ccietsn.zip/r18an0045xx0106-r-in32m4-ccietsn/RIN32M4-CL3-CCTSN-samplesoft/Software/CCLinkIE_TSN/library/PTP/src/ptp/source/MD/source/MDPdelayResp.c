/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDPdelayResp.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDPdelayResp_1AS.h"
#endif
#ifdef	PTP_USE_IEEE1588
#include "MDPdelayResp_1588.h"
#endif


VOID MDPdelayResp(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}


	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		MDPdelayResp_1AS(usEvent, pstPort);
		return;
	}
#endif
#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDPdelayResp_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP, PTP_LOGVE_82000002);
	return;
}

MDPRESPSM_GD* GetMDPdelayRespGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDPRespSM_GD;
}

MDPDELAYRESP_EV GetMDPdelayRespEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYRESP_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDPDRP_E_BEGIN;
		break;
		case PTP_EV_RCVDPDELAYREQ:
			enEvt = MDPDRP_E_RCVDPDELAYREQ;
		break;
		case PTP_EV_RCVDMDTIMESTAMPRECEIVE:
			enEvt = MDPDRP_E_RCVD_MDTIMESTAMP_RCV;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDPDRP_E_CLOSE;
		break;

		default:
			enEvt = MDPDRP_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDPDELAYRESP_ST GetMDPdelayRespStatus(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;
	MDPDELAYRESP_ST	enSts = MDPDRP_STATUS_MAX;

	pstGbl = GetMDPdelayRespGlobal(pstPort);
	if (pstGbl->enStsMDPdelayResp < MDPDRP_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDPdelayResp;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDPdelayRespStatus(MDPDELAYRESP_ST enSts, PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	pstGbl->enStsMDPdelayResp = enSts;

	return;
}
VOID IncMDPDlyRespRxPDlyReqCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if ( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulRxPdelayRequestCount++;
	}
	return;
}

VOID IncMDPDlyRespTxPDlyRespCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if ( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulTxPdelayResponseCount++;
	}
	return;
}

VOID IncMDPDlyRespTxPDRpFllwUpCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if ( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulTxPdelayResponseFollowUpCount++;
	}
	return;
}

BOOL SetMDPdlyReqEvIngresTimestamp(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive) == FALSE)
	{
#ifdef DEBUG_TIMESTAMP_MD
		printf(" [Set:  ]Pdelay_Req  IngresTimestamp   [ 0x%04x % 10d:% 10d ]\n",
						pstSmGbl->stIngMDTimestampReceive.stSeconds.usSec_msb,
						pstSmGbl->stIngMDTimestampReceive.stSeconds.ulSec_lsb,
						pstSmGbl->stIngMDTimestampReceive.ulNanoseconds);
#endif
		tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqEventIngressTimestamp,
			&pstSmGbl->stIngMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortMD->stPdlyReqEventIngressTimestamp, 0L, sizeof(TIMESTAMP));
	}
	return blRet;
}

BOOL SetMDPdlyRespEvEgresTimestamp(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stEgMDTimestampReceive) == FALSE)
	{
#ifdef DEBUG_TIMESTAMP_MD
		printf(" [Set:  ]Pdelay_Resp EgresTimestamp    [ 0x%04x % 10d:% 10d ]\n",
						pstSmGbl->stEgMDTimestampReceive.stSeconds.usSec_msb,
						pstSmGbl->stEgMDTimestampReceive.stSeconds.ulSec_lsb,
						pstSmGbl->stEgMDTimestampReceive.ulNanoseconds);
#endif
		tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespEventEgressTimestamp,
			&pstSmGbl->stEgMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortMD->stPdlyRespEventEgressTimestamp, 0L, sizeof(TIMESTAMP));
	}
	return blRet;
}
