/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_cyclicconfig_main.h"
#include "ccienx_frame.h"
#include "SLMP_api.h"
#include "NGN_ASIC.h"
#include "ACM_api.h"
#include "NMG_api.h"
#include "ccienx_app_supply.h"


NX_VOID	vNMG_ChkCyclicConfigMainReq ( FRM_CC_MAIN_REQ*, NX_ULONG*, NX_ULONG );
NX_VOID	vNMG_Extract_CycCfgMainReq ( FRM_CC_MAIN_REQ* );
NX_VOID	vNMG_CreateCycCfgMainRespNrml ( FRM_CC_MAIN_REQ* );
NX_VOID	vNMG_CreateCycCfgMainRespFault ( FRM_CC_MAIN_REQ* );
NX_VOID	vNMG_TrnsStsRcvCycCfgMainReq ( NX_VOID );

NX_VOID vNMG_AnalyzeCyclicConfigMainReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_CC_MAIN_REQ	*pstFrm;
	NX_ULONG		ulChkResult		= NX_ZERO;

	pstFrm = (FRM_CC_MAIN_REQ*)pData;

	
	vNMG_ChkCyclicConfigMainReq(pstFrm, &ulChkResult, ulIPAddress);

	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_CycCfgMainReq(pstFrm);

		vNMG_CreateCycCfgMainRespNrml(pstFrm);
		vNMG_ReqTrnCyclicConfigMainResp();

		vNMG_TrnsStsRcvCycCfgMainReq();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateCycCfgMainRespFault(pstFrm);
		vNMG_ReqTrnCyclicConfigMainResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}

	return;
}

NX_VOID vNMG_ChkCyclicConfigMainReq (
	FRM_CC_MAIN_REQ		*pstFrm,
	NX_ULONG			*pulChkResult,
	NX_ULONG			ulIPAddress
)
{
	NX_UCHAR	uchAppWdc	= (NX_UCHAR)NX_OFF;
	NX_UCHAR	uchReqWdc	= (NX_UCHAR)NX_OFF;
	NX_USHORT	usAuthClass	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_ULONG	ulRespRslt;
	NX_UCHAR	uchVLANNo;
	NX_UCHAR	uchCycCom;
	
	ulRespRslt = ulNX_ChkCyclicConfigResp(gstNET.stApp.usSyncMode,gstNM.stSlaveConfig.usWdcFuncSts);
	uchAppWdc	= gstNM.stSlaveConfig.usWdcFuncSts;
	

	uchReqWdc	= pstFrm->stCommonSetting.stBits.b01WdtCntDsign;
	uchCycCom	= pstFrm->stCommonSetting.stBits.b01CycComMeth;
	uchVLANNo	= pstFrm->uchVLANNo;


	if (gstNET.stCtrlMst.ulIPAddress == ulIPAddress) {
		usAuthClass = usACM_GetAuthenticationClass();
		if (((NX_UCHAR)NX_ZERO == pstFrm->uchSndTslt) && (NX_AUTHENTICATION_CLS_B == usAuthClass)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_001]);
			*pulChkResult	= RESP_ERR;
		}
		else if ((NX_UCHAR)TS_SIZE <= pstFrm->uchSndTslt) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_001]);
			*pulChkResult	= RESP_ERR;
		}
		else if ((DLINKERR_CYCLESETTING_ZERO == pstFrm->uchDataLinkErrCycleSet)
			  || (NX_DLINKERR_CYCLESETTING_OVER <= pstFrm->uchDataLinkErrCycleSet)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_008]);
			*pulChkResult	= RESP_ERR;
		}
		else if ( ( SYNCMODE_SYNC == gstNET.stApp.usSyncMode )
			   && ( (((NX_UCHAR)NX_OFF == uchAppWdc) && ((NX_UCHAR)NX_ON  == uchReqWdc))
			     || (((NX_UCHAR)NX_ON  == uchAppWdc) && ((NX_UCHAR)NX_OFF == uchReqWdc)) )
			) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_003]);
			*pulChkResult	= RESP_ERR;
		}
		else if ( (SYNCMODE_UNSYNC == gstNET.stApp.usSyncMode)
			   && ((NX_UCHAR)NX_ON  == uchReqWdc) ) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_003]);
			*pulChkResult	= RESP_ERR;
		}
		else if (((uchCycCom == CYCCONF_CYCCOM_TOKEN)     && (NX_AUTHENTICATION_CLS_B == usAuthClass)) ||
				 ((uchCycCom == CYCCONF_CYCCOM_TIMESPLIT) && (NX_AUTHENTICATION_CLS_A == usAuthClass))) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_009]);
			*pulChkResult	= RESP_ERR;
		}
		else if (uchVLANNo > (NX_UCHAR)NX_NTWCNF_VLAN_SETTING_NUM_MAX) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_010]);
			*pulChkResult	= RESP_ERR;
		}
		else if (uchVLANNo > (NX_UCHAR)gstNM.stNetworkConfigTslt.astVlanConfig[NX_PORT1].usVlanNum) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgMain[NMG_IDX_ERR_PARAM_010]);
			*pulChkResult	= RESP_ERR;
		}
		else {
			*pulChkResult = RESP_NORMAL;
		}
	}
	else {
		*pulChkResult = RESP_DESTRUCT;
	}
	
	if ( RESP_NORMAL == *pulChkResult ) {
		if (NX_UL_NG == ulRespRslt) {
			*pulChkResult = RESP_ERR;
		}
	}

	return;
}

NX_VOID vNMG_Extract_CycCfgMainReq (
	FRM_CC_MAIN_REQ		*pstFrm
)
{
	NX_USHORT	usAuthClass	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;


	usAuthClass = usACM_GetAuthenticationClass();
	
	if(NX_AUTHENTICATION_CLS_B == usAuthClass){
		gstNET.stCyc.usTsltCycSnd = ((NX_USHORT)pstFrm->uchSndTslt - (NX_USHORT)NX_ONE);
	}
	else {
		gstNET.stCyc.usTsltCycSnd = (NX_USHORT)NX_ZERO;
	}

	gstNET.stCyc.usRsvStaBase = (NX_USHORT)pstFrm->stCommonSetting.stBits.b01RsvStaSet;
	gstNET.stCyc.usRsvSta = (NX_USHORT)pstFrm->stCommonSetting.stBits.b01RsvStaSet;

	gstNET.stApp.usUseWDC = (NX_USHORT)pstFrm->stCommonSetting.stBits.b01WdtCntDsign;

	NGN_RN->R_RNCCTRL.BITS.b01ZWarrantyValid_Area0 = (NX_ULONG)NX_ON;
	NGN_RN->R_RNCCTRL.BITS.b01ZWarrantyValid_Area1 = (NX_ULONG)NX_ON;
	NGN_RN->R_RNCCTRL.BITS.b01ZWarrantyValid_Area2 = (NX_ULONG)NX_ON;
	NGN_RN->R_RNCCTRL.BITS.b01ZWarrantyValid_Area3 = (NX_ULONG)NX_ON;

	gstNET.stCyc.usCycCmmOnProp	= (NX_USHORT)pstFrm->stCommonSetting.stBits.b01CycCmmOnProp;

	NGN_RN->ulR_RNCALVECNT = (NX_ULONG)(NX_ONE << pstFrm->uchDataLinkErrCycleSet);

	gstNM.stCyclicConfigMain.usEmgGroupSetting = pstFrm->stTimeSynchronization.usEmgGroupSetting;

	gstNM.stCyclicConfigMain.stGofGroupSetting.stBits.b04GofGroupSetting = pstFrm->stTimeSynchronization.stGofGroupSetting.stBits.b04GofGroupSetting;
	
	gstNM.stCyclicConfigMain.ulVlanNo = (NX_ULONG)pstFrm->uchVLANNo;

	return;
}

NX_VOID vNMG_CreateCycCfgMainRespNrml (
	FRM_CC_MAIN_REQ		*pstReq
)
{
	FRM_CC_MAIN_RESP_NORMAL	*pstResp;

	pstResp = (FRM_CC_MAIN_RESP_NORMAL*)gstNM.stTrnBuf.puchCyclicConfigMainResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_CC_MAIN_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero			= NX_ZERO;
	pstResp->uchMsgId				= NX_ZERO;
	pstResp->usDivisionTotalNum		= NX_ZERO;
	pstResp->usDivisionId			= NX_ZERO;

	return;
}

NX_VOID vNMG_CreateCycCfgMainRespFault (
	FRM_CC_MAIN_REQ		*pstReq
)
{
	FRM_CC_MAIN_RESP_ERR	*pstResp;

	pstResp = (FRM_CC_MAIN_RESP_ERR*)gstNM.stTrnBuf.puchCyclicConfigMainResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						CMM_SLMP_MISS_REQDATA,
						sizeof(FRM_CC_MAIN_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsStsRcvCycCfgMainReq ( NX_VOID )
{
	NX_USHORT	usAuthClass	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	if (gstNM.stNet.usNetSts == NETSTS_RCVD_SLCFG) {

		gstNM.stNet.usStatusFinish |= FIN_RCVD_CYCCFG_MAIN;
		
		if (FIN_RCVD_CYCCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG)) {
			gstNM.stNet.usNetSts = NETSTS_RCVD_CYCCFG;
			if ( FIN_RCVD_CYCCFG_TIMECMP == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TIMECMP) ) {
				usAuthClass = usACM_GetAuthenticationClass();
				
				if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
					vNMG_ComCycEnable();
				}
				else {
					vNMG_PrepareDLinkClassA();
				}
			}
		}
	}

	return;
}

/*[EOF]*/
