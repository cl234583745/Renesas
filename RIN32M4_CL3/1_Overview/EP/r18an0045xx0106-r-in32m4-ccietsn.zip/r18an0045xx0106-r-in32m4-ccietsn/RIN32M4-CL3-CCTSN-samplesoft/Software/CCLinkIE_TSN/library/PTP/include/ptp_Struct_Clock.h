/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTP_STRUCT_CLOCK_H__
#define __PTP_STRUCT_CLOCK_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Event.h"
#include "ptp_Macro.h"

#include "ptp_Struct.h"

#include "ptp_LCEntity_GD.h"
#include "ptp_ClockSource_API_GD.h"
#include "PTP_Management_DTF.h"
#include "PTP_Management_TLV.h"
#include "PTP_Message.h"
#include "PTP_Message_TLV.h"
#include "ptp_bmca.h"
#include "PortAnnounceReceiveSMGD.h"
#include "MDDelayReqReceiveSM_GD.h"
#include "MDDelayReqSendSM_GD.h"
#include "MDDelayRespReceiveSM_GD.h"
#include "MDDelayRespSendSM_GD.h"
#include "MDLkDlyIntvalSet_GD.h"
#include "MDOneStpTxOprSet_GD.h"
#include "MDPdelayReq_GD.h"
#include "MDPdelayResp_GD.h"
#include "MDSyncIntvalSet_GD.h"
#include "MDSyncReceiveSM_GD.h"
#include "MDSyncSendSM_GD.h"
#include "ptp_BCSSend_1588_GD.h"
#include "ptp_CDSend_1588_GD.h"
#include "ptp_CMSOffset_1AS_GD.h"
#include "ptp_CMSReceive_GD.h"
#include "ptp_CMSSend_GD.h"
#include "ptp_CSSync_1AS_GD.h"
#include "ptp_CSSync_1588_GD.h"
#include "ptp_PDRQReceive_1588_GD.h"
#include "ptp_PDRQSend_1588_GD.h"
#include "ptp_PDRSReceive_1588_GD.h"
#include "ptp_PDRSSend_1588_GD.h"
#include "ptp_PSSReceive_1AS_GD.h"
#include "ptp_PSSReceive_1588_GD.h"
#include "ptp_PSSSend_GD.h"
#include "ptp_SSSync_1AS_GD.h"
#include "ptp_SSSync_1588_GD.h"
#include "ManagementSM_GD.h"
#include "ptp_LogRecord_GD.h"
#include "ptp_MemManage_GD.h"
#include "ptp_Struct_Port.h"
#include "ptp_addrinfo.h"
typedef	union tagUN_CLOCK_GD
{
	CLOCK_1AS_GD	stClock_1AS_GD;
	CLOCK_1588_GD	stClock_1588_GD;

}	UN_CLOCK_GD;

typedef	struct	tagCSM1AS_GD
{
	SSSYNCSM_1AS_GD		stSSSyncSM_1AS_GD;
	CMSOFFSETSM_1AS_GD	stCMSOffsetSM_1AS_GD;
	CSSYNCSM_1AS_GD 	stCSSyncSM_1AS_GD;

}	CSM1AS_GD;


typedef	struct	tagCSM1588_GD
{
	SSSYNCSM_1588_GD	stSSSyncSM_1588_GD;
	CSSYNCSM_1588_GD	stCSSyncSM_1588_GD;
	BCSSENDSM_1588_GD	stBCSSendSM_1588_GD;
	BMC_1588_GD			stBMC_1588_GD;
	CDSENDSM_1588_GD	stCDSendSM_1588_GD;

}	CSM1588_GD;


typedef	union tagUN_CSM_GD
{
	CSM1AS_GD		stCsm1as_GD;
	CSM1588_GD		stCsm1588_GD;

}	UN_CSM_GD;


typedef	struct tagCLOCKDATA
{
	struct tagCLOCKDATA*		pstNextClockDataPtr;
	struct tagCLOCKDATA*		pstPrevClockDataPtr;

	CLOCK_GD			stClock_GD;

	UN_CLOCK_GD			stUn_Clock_GD;

	CMSSENDSM_GD		stCMSSendSM_GD;
	CMSRECEIVESM_GD		stCMSReceiveSM_GD;
	LCENTITYSM_GD		stLCEntitySM_GD;
	MANAGEMENTSM_GD		stManagementSM_GD;
	BMC_GD				stBMC_GD;

	UN_CSM_GD			stUn_CSM_GD;

	struct	tagPORTDATA*		pstPortData;

	DEFAULT_DS			stDefaultDS;
	CURRENT_DS			stCurrentDS;
	PARENT_DS			stParentDS;
	TIMEPROPERTIES_DS	stTimePropertiesDS;

	DEFAULT_1AS_DS		stDefault_1AS_DS;
	CURRENT_1AS_DS		stCurrent_1AS_DS;
	PARENT_1AS_DS		stParent_1AS_DS;
	PATHTRACE_1AS_DS	stPathTrace_1AS_DS;

	DEFAULT_1588_DS		stDefault_1588_DS;
	CURRENT_1588_DS		stCurrent_1588_DS;
	PARENT_1588_DS		stParent_1588_DS;
#ifdef	PTP_USE_TRANS
	TCDEFAULT_1588_DS	stTCDefault_1588_DS;
#endif

	PORTADDRINFO*		pstPortAddrInfo;


}	CLOCKDATA;

#endif

