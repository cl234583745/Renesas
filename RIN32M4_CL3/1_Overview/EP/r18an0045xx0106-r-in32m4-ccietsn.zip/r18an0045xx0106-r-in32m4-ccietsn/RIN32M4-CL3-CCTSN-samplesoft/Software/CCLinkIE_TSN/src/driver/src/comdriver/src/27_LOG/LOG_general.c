/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#include "nx_common.h"
#include "LOG_api.h"
#include "ccienx_api.h"

#if GENERAL_PURPOSE_DATASAVE
#define	GENERAL_LOG_RECORD_SIZE	(100)
typedef struct tagGPDS_SAVEAREA {
	NX_ULONGLONG	ullSaveFlg;
	NX_ULONGLONG	ullRecordAreaOver;
	NX_ULONGLONG	aullReg[GENERAL_LOG_RECORD_SIZE];
} GPDS_SAVEAREA;




#endif
