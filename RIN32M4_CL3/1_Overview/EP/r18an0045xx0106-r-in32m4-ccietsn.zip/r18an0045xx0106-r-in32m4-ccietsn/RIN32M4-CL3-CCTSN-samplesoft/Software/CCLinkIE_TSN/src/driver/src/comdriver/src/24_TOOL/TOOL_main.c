/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "kernel.h"
#include "nx_mpu_common.h"
#include "TOOL_api.h"
#include "tsn_common.h"
#include "TSN_api.h"
#include "NMG_common.h"
#include "ccienx_api.h"
#include "ACM_api.h"
#include "kernel_id.h"
#include "R_IN32M4_CL3Typedef.h"
#include "platformctrl_ex.h"

#define 	SHIFT56							(56)
#define 	SHIFT40							(40)
#define 	SHIFT24							(24)
#define 	SHIFT8							(8)
#define 	BIT00_07						((NX_ULONG)0x000000FFu)
#define 	BIT08_15						((NX_ULONG)0x0000FF00u)
#define 	BIT16_23						((NX_ULONG)0x00FF0000u)
#define 	BIT24_31						((NX_ULONG)0xFF000000u)

#define		BIT32_39						((NX_ULONGLONG)0x000000FF00000000)
#define		BIT40_47						((NX_ULONGLONG)0x0000FF0000000000)
#define		BIT48_55						((NX_ULONGLONG)0x00FF000000000000)
#define		BIT56_63						((NX_ULONGLONG)0xFF00000000000000)
#define 	BIT00_03						((NX_UCHAR)0x0Fu)

#define	DMA_CONTROL_STSRST		(0x00000008)
#define	DMA_CONTROL_TRANSTRG	(0x00000004)
#define	DMA_CONTROL_ENINT		(0x00000001)

#define		DATE_MANAGEMENT_THURSDAY	((NX_ULONG)4)
#define		DATE_MANAGEMENT_FRIDAY		((NX_ULONG)5)
#define		DATE_MANAGEMENT_WEEK		((NX_ULONG)7)

#define		DATE_MANAGEMENT_CONV_MILLI		((NX_ULONG)1000000)
#define		DATE_MANAGEMENT_CONV_MICRO		((NX_ULONG)1000)
#define		DATE_MANAGEMENT_CONV_HIGHLOW	((NX_ULONG)100)

#define		DATE_YEAR_IDX_NORMAL		((NX_ULONG)0)
#define		DATE_YEAR_IDX_LEAP			((NX_ULONG)1)
#define		DATE_YEAR_IDX_SIZE			((NX_ULONG)2)

#define		DATE_LEAP_YEAR_4			((NX_ULONG)4)
#define		DATE_LEAP_YEAR_100			((NX_ULONG)100)
#define		DATE_LEAP_YEAR_400			((NX_ULONG)400)

#define		C_YEAR_LIMIT_9999			((NX_ULONG)9999)
#define		C_MONTH_LIMIT_12			((NX_ULONG)12)
#define		C_DAY_LIMIT_31				((NX_ULONG)31)
#define		C_HOUR_LIMIT_23				((NX_ULONG)23)
#define		C_MINUTE_LIMIT_59			((NX_ULONG)59)
#define		C_SECOND_LIMIT_59			((NX_ULONG)59)
#define		C_MILLISEC_LIMIT_999		((NX_ULONG)999)
#define		C_MICROSEC_LIMIT_999		((NX_ULONG)999)
#define		C_NANOSEC_LIMIT_999			((NX_ULONG)999)
#define		DATE_SECONDS_LIMIT_SINCE1970	((NX_LONGLONG)0x3AFFF4417F)

#define		C_TODAY_1					((NX_ULONG)1)
#define		C_DAYS_719162				((NX_ULONG)719162)
#define		LOG2TBL_SIZE				(NX_USHORT)(9)

#define		TOOL_STR_0					(NX_UCHAR)('0')
#define		TOOL_STR_A					(NX_UCHAR)('A')

#define		TOOL_NUM_10					(NX_UCHAR)(10)

NX_CONST	NX_USHORT	gausLog2Tbl[LOG2TBL_SIZE] = {
	1,
	2,
	4,
	8,
	16,
	32,
	64,
	128,
	256
};

NX_STATIC NX_VOID vTOOL_SetClockOffset (NX_ULONGLONG*, NX_ULONG*);
NX_STATIC NX_UCHAR uchTOOL_SetClockOffset_UTC (NX_ULONGLONG*, NX_UNIX_TIME*);
NX_VOID	vNX_GetUnixTime_TsnRunning (NX_ULONG*, NX_ULONG*);
NX_VOID	vNX_GetUnixTime_TsnDiscnct (NX_ULONG*, NX_ULONG*);
NX_VOID	vNX_GetUnixTime_Initial (NX_ULONG*, NX_ULONG*);

NX_USHORT	gusDispCnt	= NX_ZERO;
NX_USHORT	gusItrptCnt	= NX_ZERO;

RIN_DMAC_TypeDef* NX_CONST DMA_REG[4] = {
	RIN_DMAC0,
	RIN_DMAC1,
	RIN_DMAC2,
	RIN_DMAC3
};

NX_VOID vTOOL_Init (NX_VOID)
{
	gusDispCnt	= NX_ZERO;
	gusItrptCnt	= NX_ZERO;

	return;
}

NX_USHORT usNX_CnvEndianShort (
	NX_USHORT usVal
)
{
	NX_USHORT usRet = (NX_USHORT)(((usVal >> SHIFT8) & BIT00_07)
									   | ((usVal << SHIFT8) & BIT08_15));
	
	return (usRet);
}

NX_ULONG ulNX_CnvEndianLong (
	NX_ULONG ulVal
)
{
	NX_ULONG	ulRet = (((ulVal >> SHIFT24) & BIT00_07) | ((ulVal >> SHIFT8)  & BIT08_15)
						   | ((ulVal << SHIFT8)  & BIT16_23) | ((ulVal << SHIFT24) & BIT24_31));
	
	return (ulRet);
}

NX_ULONGLONG ullNX_CnvEndianLongLong (
	NX_ULONGLONG ullVal
)
{
	NX_ULONGLONG	ullRet = ((	(ullVal	>> SHIFT56)	& BIT00_07)
							|	((ullVal >> SHIFT40) & BIT08_15)
							|	((ullVal >> SHIFT24) & BIT16_23)
							|	((ullVal >> SHIFT8)  & BIT24_31)
							|	((ullVal << SHIFT8)  & BIT32_39)
							|	((ullVal << SHIFT24) & BIT40_47)
							|	((ullVal << SHIFT40) & BIT48_55)
							|	((ullVal << SHIFT56) & BIT56_63));
	
	return (ullRet);
}

NX_VOID vNX_CnvEndian6Byte (
	NX_UCHAR* puchVal_Ed,
	NX_UCHAR* puchVal
)
{
	puchVal_Ed[0] = puchVal[5];
	puchVal_Ed[1] = puchVal[4];
	puchVal_Ed[2] = puchVal[3];
	puchVal_Ed[3] = puchVal[2];
	puchVal_Ed[4] = puchVal[1];
	puchVal_Ed[5] = puchVal[0];
	
	return;
}

NX_LONG lNX_CompareMemory (
	NX_VOID*		pvDataA,
	NX_VOID*		pvDataB,
	NX_ULONG		ulSize
)
{
	NX_CHAR*	pchDataA;
	NX_CHAR*	pchDataB;
	NX_ULONG	ulLoop;
	NX_LONG	lResult = NX_OK;
	
	pchDataA = (NX_CHAR*)pvDataA;
	pchDataB = (NX_CHAR*)pvDataB;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		if (*pchDataA != *pchDataB) {
			lResult = NX_NG;
			break;
		}
		pchDataA++;
		pchDataB++;
	}
	
	return lResult;
}

NX_VOID vNX_CopyMemory (
	NX_VOID*		pvDst,
	NX_VOID*		pvSrc,
	NX_ULONG		ulSize
)
{
	NX_CHAR*	pchDst;
	NX_CHAR*	pchSrc;
	NX_ULONG	ulLoop;
	
	pchDst = (NX_CHAR*)pvDst;
	pchSrc = (NX_CHAR*)pvSrc;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*pchDst = *pchSrc;
		
		pchDst++;
		pchSrc++;
	}

	return;
}

NX_VOID vNX_CopyMemory16 (
	NX_VOID*		pvDst,
	NX_VOID*		pvSrc,
	NX_ULONG		ulSize
)
{
	NX_SHORT*	psDst;
	NX_SHORT*	psSrc;
	NX_ULONG	ulLoop;
	
	psDst = (NX_SHORT*)pvDst;
	psSrc = (NX_SHORT*)pvSrc;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*psDst = *psSrc;
		
		psDst++;
		psSrc++;
	}

	return;
}

NX_VOID vNX_CopyMemory32 (
	NX_VOID*		pvDst,
	NX_VOID*		pvSrc,
	NX_ULONG		ulSize
)
{
	NX_LONG*	plDst;
	NX_LONG*	plSrc;
	NX_ULONG	ulLoop;
	
	plDst = (NX_LONG*)pvDst;
	plSrc = (NX_LONG*)pvSrc;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*plDst = *plSrc;
		
		plDst++;
		plSrc++;
	}

	return;
}

NX_VOID vNX_FillMemory (
	NX_VOID*		pvDst,
	NX_CHAR			chData,
	NX_ULONG		ulSize
)
{
	NX_CHAR*	pchDst;
	NX_ULONG	ulLoop;
	
	pchDst = (NX_CHAR*)pvDst;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*pchDst = chData;
		
		pchDst++;
	}

	return;
}

NX_VOID vNX_FillMemory16 (
	NX_VOID*		pvDst,
	NX_SHORT		sData,
	NX_ULONG		ulSize
)
{
	NX_SHORT*	psDst;
	NX_ULONG	ulLoop;
	
	psDst = (NX_SHORT*)pvDst;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*psDst = sData;
		
		psDst++;
	}

	return;
}

NX_VOID vNX_FillMemory32 (
	NX_VOID*		pvDst,
	NX_LONG			lData,
	NX_ULONG		ulSize
)
{
	NX_LONG*	plDst;
	NX_ULONG	ulLoop;
	
	plDst = (NX_LONG*)pvDst;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*plDst = lData;
		
		plDst++;
	}

	return;
}

NX_VOID vNX_vDisableDispatch (NX_VOID)
{
	if (gusDispCnt == NX_ZERO) {
		dis_dsp();
	}
	else {
	}

	gusDispCnt++;

	return;
}

NX_VOID vNX_vEnableDispatch (NX_VOID)
{
	gusDispCnt--;

	if (gusDispCnt == NX_ZERO) {
		ena_dsp();
	}
	else {
	}

	return;
}

NX_VOID vNX_vDisableInterrupt (NX_VOID)
{
	if (gusItrptCnt == NX_ZERO) {
		NX_DI();
	}
	else {
	}

	gusItrptCnt++;

	return;
}

NX_VOID vNX_vEnableInterrupt (NX_VOID)
{
	gusItrptCnt--;

	if (gusItrptCnt == (NX_USHORT)NX_ZERO) {
		NX_EI();
	}
	else {
	}

	return;
}


NX_VOID vNX_ExecDmaLinkMode (
	NX_ULONG	ulCh,
	DMA_ITEM*	pstDmaList
)
{
	DMA_REG[ulCh]->NXLA		= (NX_ULONG)pstDmaList;
	DMA_REG[ulCh]->CHCFG	= DMA_CONFIG_DMS + DMA_CONFIG_BLOCKTRANS;
	DMA_REG[ulCh]->CHCTRL	= DMA_CONTROL_STSRST;
	DMA_REG[ulCh]->CHCTRL	= DMA_CONTROL_TRANSTRG + DMA_CONTROL_ENINT;
	
	return;
}

NX_ULONG ulNX_GetLifeTime (NX_VOID)
{
	SYSTIM		systim;
	
	get_tim(&systim);
	
	return (NX_ULONG)systim;
}

NX_ULONG ulNX_WaitLifeTime (
	NX_ULONG	ulStartTime,
	NX_ULONG	ulWaitTime
)
{
	SYSTIM		systim;
	NX_ULONG	ulResult;
	
	get_tim(&systim);
	
	if (((NX_ULONG)systim - ulStartTime) >= ulWaitTime) {
		ulResult = NX_NG;
	}
	else {
		ulResult = NX_OK;
	}
	return ulResult;
}

NX_VOID vNX_GetUnixTime (
	NX_UNIX_TIME*		pstTime
)
{
	NX_ULONG		ulNSec = NX_UL_ZERO;
	NX_ULONGLONG	ullSec = (NX_ULONGLONG)NX_ZERO;
	
	NX_LONGLONG		llNotUse1 = (NX_LONGLONG)NX_ZERO;
	NX_LONG			lNotUse2 = NX_L_ZERO;
	NX_SHORT		sUTCMinuteTemp = NX_S_ZERO;
	NX_SHORT		sSummerTimeMinuteTemp = NX_S_ZERO;
	NX_ULONG		ulOffsetRecvFlag;
	NX_ULONG		ulSetClockOffset = (NX_ULONG)NX_OFF;
	NX_USHORT		usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	pstTime->sUtcOffsetMin = DATE_DEFAULT_CLOCK_OFFSET;
	pstTime->sSummerTimeOffsetMin = DATE_DEFAULT_CLOCK_OFFSET;
	
	ulOffsetRecvFlag = ulNX_GetClockOffsetRecvFlag();
	
	if ((NX_ULONG)NX_OFF == ulOffsetRecvFlag) {
	}
	else {
		usAuthClass = usACM_GetAuthenticationClass();
		if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		if (gstNET.stPtp.ulPtpSts == PTPSTS_RUNNING) {
			vNX_GetUnixTime_TsnRunning((NX_ULONG*)&ullSec, &ulNSec);
			ulSetClockOffset = (NX_ULONG)NX_ON;
		}
		else {
			if (gstNM.stNet.ulTimeSetFlg == (NX_ULONG)NX_OFF) {
				vNX_GetUnixTime_Initial((NX_ULONG*)&ullSec, &ulNSec);
			}
			else {
				vNX_GetUnixTime_TsnDiscnct((NX_ULONG*)&ullSec, &ulNSec);
				ulSetClockOffset = (NX_ULONG)NX_ON;
			}
		}
		}
		else {
			if (gstNM.stNet.ulTimeSetFlg == (NX_ULONG)NX_OFF) {
				vNX_GetUnixTime_Initial((NX_ULONG*)&ullSec, &ulNSec);
			}
			else {
				vNX_GetUnixTime_TsnRunning((NX_ULONG*)&ullSec, &ulNSec);
				ulSetClockOffset = (NX_ULONG)NX_ON;
			}
		}
		if ((NX_ULONG)NX_ON == ulSetClockOffset) {
			vTOOL_SetClockOffset(&ullSec, &ulNSec);
			
			if ((NX_ULONGLONG)NX_ZERO != ullSec) {
				vNX_GetClockOffset(&llNotUse1, &lNotUse2, &sUTCMinuteTemp, &sSummerTimeMinuteTemp);
				pstTime->sUtcOffsetMin = sUTCMinuteTemp;
				pstTime->sSummerTimeOffsetMin = sSummerTimeMinuteTemp;
			}
		}
	}
	
	pstTime->ulUnixTime_ns	= ulNSec;
	pstTime->ullUnixTime_s	= ullSec;

	return;
}

NX_VOID	vNX_GetUnixTime_TsnRunning (
	NX_ULONG*	pulCnt_S,
	NX_ULONG*	pulCnt_NS
)
{
	gulTSN_GetTimeCnt(NX_ON, pulCnt_S, pulCnt_NS);
	
	return;
}

NX_VOID	vNX_GetUnixTime_TsnDiscnct (
	NX_ULONG*	pulCnt_S,
	NX_ULONG*	pulCnt_NS
)
{
	NX_ULONG	ulCnt_S_Stop_Time;
	NX_ULONG	ulCnt_NS_Stop_Time;
	NX_ULONG	ulCnt_S_Stop_Free;
	NX_ULONG	ulCnt_NS_Stop_Free;
	NX_ULONG	ulCnt_S_Now_Free;
	NX_ULONG	ulCnt_NS_Now_Free;
	NX_ULONG	ulCnt_S_Div_Free;
	NX_ULONG	ulCnt_NS_Div_Free;
	
	vTSN_GetTimerCounter(TSN_TIMCNT_STOP_TIME, &ulCnt_S_Stop_Time, &ulCnt_NS_Stop_Time);
	vTSN_GetTimerCounter(TSN_TIMCNT_STOP_FREE, &ulCnt_S_Stop_Free, &ulCnt_NS_Stop_Free);
	gulTSN_GetFreeRunCnt(NX_ON, &ulCnt_S_Now_Free, &ulCnt_NS_Now_Free);
	
	if (ulCnt_NS_Now_Free >= ulCnt_NS_Stop_Free) {
		ulCnt_NS_Div_Free = ulCnt_NS_Now_Free - ulCnt_NS_Stop_Free;
		ulCnt_S_Div_Free = ulCnt_S_Now_Free - ulCnt_S_Stop_Free;
	}
	else {
		ulCnt_NS_Div_Free =  NX_NSEC_1000000000- ulCnt_NS_Stop_Free + ulCnt_NS_Now_Free;
		ulCnt_S_Div_Free = ulCnt_S_Now_Free - ulCnt_S_Stop_Free - 1;
	}
	
	if ((ulCnt_NS_Stop_Time + ulCnt_NS_Div_Free) < NX_NSEC_1000000000) {
		*pulCnt_NS = ulCnt_NS_Stop_Time + ulCnt_NS_Div_Free;
		*pulCnt_S = ulCnt_S_Stop_Time + ulCnt_S_Div_Free;
	}
	else {
		*pulCnt_NS = ulCnt_NS_Stop_Time + ulCnt_NS_Div_Free - NX_NSEC_1000000000;
		*pulCnt_S = ulCnt_S_Stop_Time + ulCnt_S_Div_Free + 1;
	}
	
	return;
}

NX_VOID	vNX_GetUnixTime_Initial (
	NX_ULONG*	pulCnt_S,
	NX_ULONG*	pulCnt_NS
)
{
	*pulCnt_NS = NX_UL_ZERO;
	*pulCnt_S = NX_UL_ZERO;
	
	return;
}

VOID vNX_CnvUnixTimeToCalendar (
	NX_UNIX_TIME *	pstUnixTime,
	NX_CALENDAR *	pstCalendar
)
{
	NX_STATIC NX_CONST NX_ULONG aulDaysTable[DATE_YEAR_IDX_SIZE][C_MONTHS_12] = {
		{ C_DAYS_31, C_DAYS_28, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_30, C_DAYS_31 },
		{ C_DAYS_31, C_DAYS_29, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_31, C_DAYS_30, C_DAYS_31, C_DAYS_30, C_DAYS_31 }
	};
	
	NX_ULONG	ulElapsedDays;
	NX_ULONG	ulTotalDays;
	NX_ULONG	ulRealTotalDays;
	NX_ULONG	ulLastYearDays;
	NX_ULONG	ulThisYearDays;
	NX_ULONG	ulThisYear;
	NX_ULONG	ulThisMonth;
	NX_ULONG	ulThisDay;
	NX_ULONG	ulTempDays;
	NX_ULONG	ulIndex;
	NX_ULONG	ulTotalSec;
	NX_ULONGLONG	ullSecond;
	NX_ULONG	ulMilliSec;
	NX_ULONG	ulMicroSec;
	NX_ULONG	ulNanoSec;
	NX_ULONG	ulIdxMonth = NX_UL_ZERO;
	NX_UCHAR	uchCalcExeFlag = (NX_UCHAR)NX_OFF;

	ulNanoSec	= pstUnixTime->ulUnixTime_ns;
	ullSecond	= pstUnixTime->ullUnixTime_s;

	if ((NX_ULONGLONG)NX_ZERO != ullSecond) {
		uchCalcExeFlag = uchTOOL_SetClockOffset_UTC(&ullSecond, pstUnixTime);
	}
	else {
	}

	if ((NX_UCHAR)NX_ON == uchCalcExeFlag) {

		ulElapsedDays	= (NX_ULONG)((ullSecond / (C_SECONDS_3600 * C_HOURS_24)) + C_DAYS_719162);
		ulTotalDays		= (NX_ULONG)(ulElapsedDays + C_TODAY_1);
		ulRealTotalDays	= (NX_ULONG)(ullSecond / (C_SECONDS_3600 * C_HOURS_24));

		ulThisYear = (NX_ULONG)(ulTotalDays / C_DAYS_365);
		while (1) {
			ulLastYearDays = (NX_ULONG)(( ulThisYear * C_DAYS_365 )
						   + ( ulThisYear / DATE_LEAP_YEAR_4 )
						   - ( ulThisYear / DATE_LEAP_YEAR_100 )
						   + ( ulThisYear / DATE_LEAP_YEAR_400 ));
			if (ulLastYearDays >= ulTotalDays) {
				ulThisYear--;
			}
			else {
				ulThisYear++;
				break;
			}
		}

		ulThisYearDays = (NX_ULONG)(ulTotalDays - ulLastYearDays);

		if (((( ulThisYear % DATE_LEAP_YEAR_4   ) == NX_UL_ZERO ) &&
			 (( ulThisYear % DATE_LEAP_YEAR_100 ) != NX_UL_ZERO )) ||
			 (( ulThisYear % DATE_LEAP_YEAR_400 ) == NX_UL_ZERO )) {
			ulIndex = DATE_YEAR_IDX_LEAP;
		}
		else {
			ulIndex = DATE_YEAR_IDX_NORMAL;
		}

		ulTempDays = NX_UL_ZERO;
		for (ulIdxMonth = NX_UL_ZERO; (ulTempDays < ulThisYearDays) && (ulIdxMonth < C_MONTHS_12); ulIdxMonth++) {
			ulTempDays += aulDaysTable[ulIndex][ulIdxMonth];
		}
		if (NX_UL_ZERO != ulIdxMonth) {
			ulThisMonth = ulIdxMonth;
			ulIdxMonth--;
		}
		else {
			ulThisMonth = (NX_ULONG)NX_ONE;
		}

		ulThisDay = ulThisYearDays - (ulTempDays - aulDaysTable[ulIndex][ulIdxMonth]);

		ulTotalSec = ullSecond % (C_SECONDS_3600 * C_HOURS_24);

		pstCalendar->ulHour		= (ulTotalSec / C_SECONDS_3600);
		pstCalendar->ulMinute	= ((ulTotalSec % C_SECONDS_3600) / C_SECONDS_60);
		pstCalendar->ulSecond	= ((ulTotalSec % C_SECONDS_3600) % C_SECONDS_60);
		pstCalendar->ulYear		= ulThisYear;
		pstCalendar->ulMonth	= ulThisMonth;
		pstCalendar->ulDay		= ulThisDay;

		pstCalendar->ucDayOfTheWeek = (NX_UCHAR)((ulRealTotalDays + DATE_MANAGEMENT_THURSDAY) % DATE_MANAGEMENT_WEEK);

		ulMicroSec	= (ULONG)(ulNanoSec / DATE_MANAGEMENT_CONV_MICRO);
		ulMilliSec	= (ULONG)(ulNanoSec / DATE_MANAGEMENT_CONV_MILLI);

		pstCalendar->ulNanoSec			= ulNanoSec;
		pstCalendar->ulMicroSec			= ulMicroSec;
		pstCalendar->ucMilliSec_High	= (NX_UCHAR)(ulMilliSec / DATE_MANAGEMENT_CONV_HIGHLOW);
		pstCalendar->ucMilliSec_Low		= (NX_UCHAR)(ulMilliSec % DATE_MANAGEMENT_CONV_HIGHLOW);
	}
	else if ((NX_ULONGLONG)NX_ZERO == ullSecond) {
		vNX_FillMemory32(pstCalendar, NX_L_ZERO, (sizeof(NX_CALENDAR) / sizeof(NX_ULONG)));
	}
	else {
		pstCalendar->ulYear					= C_YEAR_LIMIT_9999;
		pstCalendar->ulMonth				= C_MONTH_LIMIT_12;
		pstCalendar->ulDay					= C_DAY_LIMIT_31;
		pstCalendar->ucDayOfTheWeek			= (NX_UCHAR)DATE_MANAGEMENT_FRIDAY;
		pstCalendar->ulHour					= C_HOUR_LIMIT_23;
		pstCalendar->ulMinute				= C_MINUTE_LIMIT_59;
		pstCalendar->ulSecond				= C_SECOND_LIMIT_59;
		pstCalendar->ucMilliSec_High		= (NX_UCHAR)(C_MILLISEC_LIMIT_999 / DATE_MANAGEMENT_CONV_HIGHLOW);
		pstCalendar->ucMilliSec_Low			= (NX_UCHAR)(C_MILLISEC_LIMIT_999 % DATE_MANAGEMENT_CONV_HIGHLOW);
		pstCalendar->ulMicroSec				= C_MICROSEC_LIMIT_999;
		pstCalendar->ulNanoSec				= C_NANOSEC_LIMIT_999;
	}
	return;
}

NX_STATIC NX_VOID vTOOL_SetClockOffset (
	NX_ULONGLONG *	pullSecond,
	NX_ULONG *		pulNanoSec
)
{
	NX_LONGLONG	llSecondTemp;
	NX_LONG		lNanoSecTemp;
	NX_LONGLONG	llSecondOffset;
	NX_LONG		lNanoSecOffset;
	NX_LONG		lCarry;
	
	NX_SHORT	sNotUse3 = NX_S_ZERO;
	NX_SHORT	sNotUse4 = NX_S_ZERO;
	
	llSecondTemp = (NX_LONGLONG)*pullSecond;
	lNanoSecTemp = (NX_LONG)*pulNanoSec;
	
	vNX_GetClockOffset(&llSecondOffset, &lNanoSecOffset, &sNotUse3, &sNotUse4);
	
	if (lNanoSecOffset < ((NX_LONG)NX_MINUS_ONE * (NX_LONG)NX_NSEC_999999999)) {
		lNanoSecOffset = ((NX_LONG)NX_MINUS_ONE * (NX_LONG)NX_NSEC_999999999);
	} else if ((NX_LONG)NX_NSEC_999999999 < lNanoSecOffset) {
		lNanoSecOffset = (NX_LONG)NX_NSEC_999999999;
	}
	else {
	}
	
	lNanoSecTemp -= lNanoSecOffset;
	if (lNanoSecTemp < NX_L_ZERO) {
		lCarry = (NX_LONG)NX_MINUS_ONE;
		lNanoSecTemp += (NX_LONG)NX_NSEC_1000000000;
	}
	else if ((NX_LONG)NX_NSEC_1000000000 <= lNanoSecTemp) {
		lCarry = (NX_LONG)NX_ONE;
		lNanoSecTemp -= (NX_LONG)NX_NSEC_1000000000;
	}
	else {
		lCarry = NX_L_ZERO;
	}
	
	llSecondTemp = llSecondTemp - llSecondOffset + (NX_LONGLONG)lCarry;
	if (llSecondTemp < (NX_LONGLONG)NX_ZERO) {
		llSecondTemp = (NX_LONGLONG)NX_ZERO;
		lNanoSecTemp = NX_L_ZERO;
	}
	else if ((NX_LONGLONG)NX_BIT00_46 < llSecondTemp) {
		llSecondTemp = (NX_LONGLONG)NX_BIT00_46;
		lNanoSecTemp = (NX_LONG)NX_NSEC_999999999;
	}
	else if (DATE_SECONDS_LIMIT_SINCE1970 < llSecondTemp) {
		
	}
	else {
	}
	
	*pullSecond = (NX_ULONGLONG)llSecondTemp;
	*pulNanoSec = (NX_ULONG)lNanoSecTemp;
	
	return;
}

NX_STATIC NX_UCHAR uchTOOL_SetClockOffset_UTC (
	NX_ULONGLONG *	pullSecond,
	NX_UNIX_TIME *	pstUnixTime
)
{
	NX_LONGLONG		llSecondTemp;
	NX_LONGLONG		llUTCMinuteTemp = (NX_LONGLONG)NX_ZERO;
	NX_LONGLONG		llSummerTimeMinuteTemp = (NX_LONGLONG)NX_ZERO;
	NX_UCHAR		uchResultInRangeFlag = (NX_UCHAR)NX_OFF;
	
	NX_LONGLONG		llNotUse1 = (NX_LONGLONG)NX_ZERO;
	NX_LONG			lNotUse2 = NX_L_ZERO;
	
	llSecondTemp = (NX_LONGLONG)*pullSecond;
	
	if (DATE_DEFAULT_CLOCK_OFFSET != pstUnixTime->sUtcOffsetMin) {
		llUTCMinuteTemp = (NX_LONGLONG)pstUnixTime->sUtcOffsetMin;
	}
	if (DATE_DEFAULT_CLOCK_OFFSET != pstUnixTime->sSummerTimeOffsetMin) {
		llSummerTimeMinuteTemp = (NX_LONGLONG)pstUnixTime->sSummerTimeOffsetMin;
	}
	
	llSecondTemp += (llUTCMinuteTemp * (NX_LONGLONG)C_SECONDS_60) + 
					(llSummerTimeMinuteTemp * (NX_LONGLONG)C_SECONDS_60);
	
	if (llSecondTemp <= (NX_LONGLONG)NX_ZERO) {
		llSecondTemp = (NX_LONGLONG)NX_ZERO;
	}
	else if ((NX_LONGLONG)NX_BIT00_46 < llSecondTemp) {
		llSecondTemp = (NX_LONGLONG)NX_BIT00_46;
	}
	else if (DATE_SECONDS_LIMIT_SINCE1970 < llSecondTemp) {
		
	}
	else {
		uchResultInRangeFlag = (NX_UCHAR)NX_ON;
	}
	
	*pullSecond = (NX_ULONGLONG)llSecondTemp;
	
	return uchResultInRangeFlag;
}

NX_ULONG ulTOOL_calcLog2 (
	NX_USHORT	usValue,
	NX_UCHAR	*pucResult
)
{
	USHORT	usIndex	=	(NX_USHORT)NX_ZERO;
	USHORT	usFind	=	(NX_USHORT)NX_OFF;
	
	*pucResult		=	(NX_UCHAR)NX_ZERO;
	
	for (usIndex = 0; usIndex <LOG2TBL_SIZE; usIndex++) {
		
		if (usValue == gausLog2Tbl[usIndex]) {
			
			*pucResult = usIndex;
			
			usFind	=	(NX_USHORT)NX_ON;
			
			break;
		}
		
	}
	
	return usFind;
}

NX_ULONG ulTOOL_NumToAscii (
	NX_UCHAR* puchNumPtr,
	NX_USHORT usDataSize,
	NX_UCHAR* puchGetData
)
{
	NX_ULONG	ulRet = NX_UL_NG;
	NX_ULONG	ulLoop = NX_ZERO;
	NX_UCHAR	uchTmpValHi = NX_ZERO;
	NX_UCHAR	uchTmpValLow = NX_ZERO;
	NX_UCHAR*	puchNumData = NX_NULL;
	NX_ULONG	ulSize = NX_ZERO;
	
	
	if (NX_ZERO < usDataSize) {

		puchNumData = puchNumPtr;
		ulSize = (NX_ULONG)(usDataSize * 2);

		while (ulLoop < ulSize) {
			
			uchTmpValLow = (*puchNumData & BIT00_03);
			if (uchTmpValLow < TOOL_NUM_10) {
				puchGetData[ulSize - ulLoop - 1] = uchTmpValLow + TOOL_STR_0;
			}
			else {
				puchGetData[ulSize - ulLoop - 1] = uchTmpValLow - TOOL_NUM_10 + TOOL_STR_A;
			}
			ulLoop++;
			
			uchTmpValHi = ((*puchNumData >> NX_SHIFT4) & BIT00_03);
			if (uchTmpValHi < TOOL_NUM_10) {
				puchGetData[ulSize - ulLoop - 1] = uchTmpValHi + TOOL_STR_0;
			}
			else {
				puchGetData[ulSize - ulLoop - 1] = uchTmpValHi - TOOL_NUM_10 + TOOL_STR_A;
			}
			
			ulLoop++;
			puchNumData++;
		}
		ulRet = NX_UL_OK;
	}
	
	return ulRet;
}




/*[EOF]*/
