/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "JADE.h"
#include "R_IN32M4_CL3.h"
#include "TOOL_api.h"
#include "DRV_common.h"





#define LED_INT_MASK			(0x00000003)

typedef union tagTYPE_R_LEDCNT1	{
	NX_ULONG	DATA;
	struct {
		NX_ULONG	ulRUN		:	3;
		NX_ULONG	ulMODE		:	3;
		NX_ULONG	ulRsv1		:	3;
		NX_ULONG	ulERR		:	3;
		NX_ULONG	ulRsv2		:	3;
		NX_ULONG	ulREM		:	3;
		NX_ULONG	ulDLINK		:	3;
		NX_ULONG	ulRsv3		:	4;
		NX_ULONG	ulLER1		:	1;
		NX_ULONG	ulLER2		:	1;
		NX_ULONG	ulRsv4		:	3;
		NX_ULONG	ulIETYPE	:	2;
	} BITS;
} TYPE_R_LEDCNT1;

typedef struct tagLED_CTRL {
	TYPE_R_LEDCNT1	stLedCtrl;
} LED_CTRL;

typedef union tagTYPE_R_TESTLED	{
	NX_ULONG	DATA;
	struct {
		NX_ULONG	ulRUNSel		:	1;
		NX_ULONG	ulMODESel		:	1;
		NX_ULONG	ulREMSel		:	1;
		NX_ULONG	ulDLINKSel		:	1;
		NX_ULONG	ulERRSel		:	1;
		NX_ULONG	ulSDRD1Sel		:	1;
		NX_ULONG	ulSDRD2Sel		:	1;
		NX_ULONG	ulLER1Sel		:	1;
		NX_ULONG	ulLER2Sel		:	1;
		NX_ULONG	ulIETYPESel		:	1;
		NX_ULONG	ulRsv7			:	6;
		NX_ULONG	ulRUNOnOff		:	1;
		NX_ULONG	ulMODEOnOff		:	1;
		NX_ULONG	ulREMOnOff		:	1;
		NX_ULONG	ulDLINKOnOff	:	1;
		NX_ULONG	ulERROnOff		:	1;
		NX_ULONG	ulSDRD1OnOff	:	1;
		NX_ULONG	ulSDRD2OnOff	:	1;
		NX_ULONG	ulLER1OnOff		:	1;
		NX_ULONG	ulLER2OnOff		:	1;
		NX_ULONG	ulIETYPEOnOff	:	1;
		NX_ULONG	ulRsv15			:	6;
	} BITS;
} TYPE_R_TESTLED;

typedef struct tagTESTLED_CTRL {
	TYPE_R_TESTLED	stLedCtrl;
} TESTLED_CTRL;

typedef struct tagSLMP_RCV_INFO {
	NX_UCHAR	uchRP1B;
	NX_UCHAR	uchRPFC1B;
	NX_UCHAR	uchRPFCE1B;
	NX_UCHAR	uchRPMC1B;
	NX_UCHAR	uchRPM1B;
	NX_ULONG	ulDRCTLRP1L;
	NX_ULONG	ulDRCTLRP1H;
} PORT_BK_INFO;

typedef union tagTYPE_R_LEDMON {
	NX_ULONG	DATA;
	struct {
		NX_ULONG	ulRUN		:	1;
		NX_ULONG	ulMODE		:	1;
		NX_ULONG	ulRsv1		:	1;
		NX_ULONG	ulERR		:	1;
		NX_ULONG	ulRsv2		:	1;
		NX_ULONG	ulREM		:	1;
		NX_ULONG	ulDLINK		:	1;
		NX_ULONG	ulRsv3		:	2;
		NX_ULONG	ulLER1		:	1;
		NX_ULONG	ulLER2		:	1;
		NX_ULONG	ulRsv4		:	1;
		NX_ULONG	ulIETPYPE	:	1;
		NX_ULONG	ulSDRD1		:	1;
		NX_ULONG	ulSDRD2		:	1;
		NX_ULONG	ulRsv5		:	17;
	} BITS;
} TYPE_R_LEDMON;

typedef union tagTYPE_R_LEDMASK {
	NX_ULONG	DATA;
	struct {
		NX_ULONG	ulRUN		:	1;
		NX_ULONG	ulMODE		:	1;
		NX_ULONG	ulRsv1		:	1;
		NX_ULONG	ulERR		:	1;
		NX_ULONG	ulRsv2		:	1;
		NX_ULONG	ulREM		:	1;
		NX_ULONG	ulDLINK		:	1;
		NX_ULONG	ulRsv3		:	2;
		NX_ULONG	ulLER1		:	1;
		NX_ULONG	ulLER2		:	1;
		NX_ULONG	ulRsv4		:	1;
		NX_ULONG	ulIETYPE	:	1;
		NX_ULONG	ulRsv5		:	19;
	} BITS;
} TYPE_R_LEDMASK;

NX_STATIC	PORT_BK_INFO	gstPortBack;
NX_STATIC	NX_ULONG	gulRunLed;
NX_STATIC	NX_ULONG	gulDlinkLed;
NX_STATIC	NX_ULONG	gulErrLed;

NX_VOID vDRV_InitLedDriver (NX_VOID)
{
	vNX_FillMemory((NX_VOID*)&gstPortBack, NX_ZERO, sizeof(PORT_BK_INFO));
	gulRunLed = NX_LED_ON;
	gulDlinkLed = NX_LED_OFF;
	gulErrLed = NX_LED_OFF;
	
	return;
}

NX_VOID vNX_SetRunLed (
	NX_USHORT usParam
)
{
	switch (usParam) {
	case NX_LED_OFF:
	case NX_LED_ON:
	case NX_LED_BLINK_1S:
	case NX_LED_BLINK_500MS:
	case NX_LED_BLINK_200MS:
		gulRunLed = (NX_ULONG)usParam;
		break;
	default:
		break;
	}

	return;
}

NX_VOID vNX_SetDlinkLed (
	NX_USHORT usParam
)
{
	switch (usParam) {
	case NX_LED_OFF:
	case NX_LED_ON:
	case NX_LED_BLINK_1S:
	case NX_LED_BLINK_500MS:
	case NX_LED_BLINK_200MS:
		gulDlinkLed = (NX_ULONG)usParam;
		break;
	default:
		break;
	}

	return;
}

NX_VOID vNX_SetErrLed (
	NX_USHORT usParam
)
{
	switch (usParam) {
	case NX_LED_OFF:
	case NX_LED_ON:
	case NX_LED_BLINK_1S:
	case NX_LED_BLINK_500MS:
	case NX_LED_BLINK_200MS:
		gulErrLed = (NX_ULONG)usParam;
		break;
	default:
		break;
	}

	return;
}

NX_VOID vNX_UpdateLed (NX_VOID)
{
	TYPE_R_LEDCNT1	stLedCnt;
	stLedCnt.DATA = NX_JADE_SYS->R_LEDCNT1;

	stLedCnt.BITS.ulRUN		= gulRunLed;
	stLedCnt.BITS.ulDLINK	= gulDlinkLed;
	stLedCnt.BITS.ulERR		= gulErrLed;
	
	NX_JADE_SYS->R_LEDCNT1 = stLedCnt.DATA;

	return;
}

NX_ULONG lNX_GetRunLedStatus (NX_VOID) 
{
	TYPE_R_LEDCNT1	stLedSts;
	TYPE_R_TESTLED	stTestLed;
	TYPE_R_LEDMASK  stLedMask;
	NX_ULONG		ulWdtInt;
	NX_ULONG		ulLedStatus;

	stTestLed.DATA = NX_JADE_SYS->R_TESTLED;
	if (NX_ON == stTestLed.BITS.ulRUNSel) {
		if (NX_ON == stTestLed.BITS.ulRUNOnOff) {
			ulLedStatus = (NX_ULONG)NX_LED_ON;
		}
		else {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
	}
	else {
		stLedMask.DATA = NX_JADE_SYS->R_LEDMASK;
		if (NX_ON == stLedMask.BITS.ulRUN) {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
		else {
			ulWdtInt = NX_JADE_SYS->R_AERRDB & LED_INT_MASK;
			if (NX_ZERO != ulWdtInt) {
				ulLedStatus = (NX_ULONG)NX_LED_OFF;
			}
			else {
				stLedSts.DATA	= NX_JADE_SYS->R_LEDCNT1;
				ulLedStatus = stLedSts.BITS.ulRUN;
			}
		}
	}
	
	return ulLedStatus;
	
}

NX_ULONG lNX_GetErrLedStatus (NX_VOID) 
{
	TYPE_R_LEDCNT1	stLedSts;
	TYPE_R_TESTLED	stTestLed;
	TYPE_R_LEDMASK  stLedMask;
	NX_ULONG		ulWdtInt;
	NX_ULONG		ulLedStatus;

	stTestLed.DATA = NX_JADE_SYS->R_TESTLED;
	if (NX_ON == stTestLed.BITS.ulERRSel) {
		if (NX_ON == stTestLed.BITS.ulERROnOff) {
			ulLedStatus = (NX_ULONG)NX_LED_ON;
		}
		else {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
	}
	else {
		stLedMask.DATA = NX_JADE_SYS->R_LEDMASK;
		if (NX_ON == stLedMask.BITS.ulERR) {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
		else {
			ulWdtInt = NX_JADE_SYS->R_AERRDB & LED_INT_MASK;
			if (NX_ZERO != ulWdtInt) {
				ulLedStatus = (NX_ULONG)NX_LED_ON;
			}
			else {
				stLedSts.DATA	= NX_JADE_SYS->R_LEDCNT1;
				ulLedStatus = stLedSts.BITS.ulERR;
			}
		}
	}
	
	return ulLedStatus;

}

NX_ULONG lNX_GetDlinkLedStatus (NX_VOID) 
{
	TYPE_R_LEDCNT1	stLedSts;
	TYPE_R_TESTLED	stTestLed;
	TYPE_R_LEDMASK  stLedMask;
	NX_ULONG		ulWdtInt;
	NX_ULONG		ulLedStatus;

	stTestLed.DATA = NX_JADE_SYS->R_TESTLED;
	if (NX_ON == stTestLed.BITS.ulDLINKSel) {
		if (NX_ON == stTestLed.BITS.ulDLINKOnOff) {
			ulLedStatus = (NX_ULONG)NX_LED_ON;
		}
		else {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
	}
	else {
		stLedMask.DATA = NX_JADE_SYS->R_LEDMASK;
		if (NX_ON == stLedMask.BITS.ulDLINK) {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
		else {
			ulWdtInt = NX_JADE_SYS->R_AERRDB & LED_INT_MASK;
			if (NX_ZERO != ulWdtInt) {
				ulLedStatus = (NX_ULONG)NX_LED_OFF;
			}
			else {
				stLedSts.DATA	= NX_JADE_SYS->R_LEDCNT1;
				ulLedStatus = stLedSts.BITS.ulDLINK;
			}
		}
	}
	
	return ulLedStatus;

}
NX_ULONG lNX_GetUser1LedStatus (NX_VOID)
{

	TYPE_R_LEDCNT1	stLedSts;
	TYPE_R_TESTLED	stTestLed;
	TYPE_R_LEDMASK  stLedMask;
	NX_ULONG		ulWdtInt;
	NX_ULONG		ulLedStatus;

	stTestLed.DATA = NX_JADE_SYS->R_TESTLED;
	if (NX_ON == stTestLed.BITS.ulREMSel) {
		if (NX_ON == stTestLed.BITS.ulREMOnOff) {
			ulLedStatus = (NX_ULONG)NX_LED_ON;
		}
		else {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
	}
	else {
		stLedMask.DATA = NX_JADE_SYS->R_LEDMASK;
		if (NX_ON == stLedMask.BITS.ulREM) {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
		else {
			ulWdtInt = NX_JADE_SYS->R_AERRDB & LED_INT_MASK;
			if (NX_ZERO != ulWdtInt) {
				ulLedStatus = (NX_ULONG)NX_LED_OFF;
			}
			else {
				stLedSts.DATA	= NX_JADE_SYS->R_LEDCNT1;
				ulLedStatus = stLedSts.BITS.ulREM;
			}
		}
	}
	
	return ulLedStatus;

}

NX_ULONG lNX_GetUser2LedStatus (NX_VOID)
{

	TYPE_R_LEDCNT1	stLedSts;
	TYPE_R_TESTLED	stTestLed;
	TYPE_R_LEDMASK  stLedMask;
	NX_ULONG		ulWdtInt;
	NX_ULONG		ulLedStatus;

	stTestLed.DATA = NX_JADE_SYS->R_TESTLED;
	if (NX_ON == stTestLed.BITS.ulMODESel) {
		if (NX_ON == stTestLed.BITS.ulMODEOnOff) {
			ulLedStatus = (NX_ULONG)NX_LED_ON;
		}
		else {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
	}
	else {
		stLedMask.DATA = NX_JADE_SYS->R_LEDMASK;
		if (NX_ON == stLedMask.BITS.ulMODE) {
			ulLedStatus = (NX_ULONG)NX_LED_OFF;
		}
		else {
			ulWdtInt = NX_JADE_SYS->R_AERRDB & LED_INT_MASK;
			if (NX_ZERO != ulWdtInt) {
				ulLedStatus = (NX_ULONG)NX_LED_OFF;
			}
			else {
				stLedSts.DATA	= NX_JADE_SYS->R_LEDCNT1;
				ulLedStatus = stLedSts.BITS.ulMODE;
			}
		}
	}
	
	return ulLedStatus;
	
}

NX_ULONG lNX_GetSdSdrd1LedStatus (NX_VOID)
{
	TYPE_R_LEDMON	stLedMon;

	stLedMon.DATA	= NX_JADE_SYS->R_LEDMON;

	return stLedMon.BITS.ulSDRD1;
}

NX_ULONG lNX_GetRdSdrd2LedStatus (NX_VOID)
{
	TYPE_R_LEDMON	stLedMon;

	stLedMon.DATA	= NX_JADE_SYS->R_LEDMON;

	return stLedMon.BITS.ulSDRD2;
}

NX_ULONG lNX_GetLER1LedStatus (NX_VOID)
{
	TYPE_R_LEDMON	stLedMon;

	stLedMon.DATA	= NX_JADE_SYS->R_LEDMON;

	return stLedMon.BITS.ulLER1;
}

NX_ULONG lNX_GetLER2LedStatus (NX_VOID)
{
	TYPE_R_LEDMON	stLedMon;

	stLedMon.DATA	= NX_JADE_SYS->R_LEDMON;

	return stLedMon.BITS.ulLER2;
}




