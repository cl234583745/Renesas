/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_networkconfig_tslt.h"
#include "SLMP_api.h"
#include "NGN_ASIC.h"
#include "TSN_api.h"
#include "ccienx_app_supply.h"
#include "LSM_api.h"
#include "TOOL_api.h"
#include "NMG_api.h"
#include "ACM_api.h"
#include "NGN_ASIC_RE.h"
#include "ccienx_api.h"

#define	RELAYBANOFFSET_EN				((NX_UCHAR)1)

#define	TSLTDISTINCT_SET_PORTCMN_DIS	((NX_UCHAR)0)

#define	TSLT_ODD						((NX_UCHAR)0)
#define	TSLT_EVEN						((NX_UCHAR)1)

#define	TSLTDISTINCT_ETHERTYPE_EN		((NX_UCHAR)1)

#define	ASIC_ETHERTYPE_CLR				((NX_USHORT)0x0000)

#define	COMMUNI_CYCLE_0NS				((NX_ULONGLONG)(0x00000000))
#define	COMMUNI_CYCLE_15STONS			((NX_ULONGLONG)(0x37E11D600))
#define	COMMUNI_CYCLE_999999999NS		((NX_ULONG)(0x3B9AC9FF))
#define	COMMUNI_CYCLE_80NS_100M			((NX_ULONG)80)

#define	RESERVE_SIZE					(3)

#define	TSLT_ADD_NUM					((NX_USHORT)3)

#define	ASIC_OPC_ENABLED_VID_AREA				((NX_ULONG)8)
#define	ASIC_OPC_ENABLED_VLANTAG_TSLT_AREA		((NX_ULONG)16)
#define	OPC_VID_INIT					((NX_ULONG)(0x00000000))
#define	OPC_VLAN_TS_INIT				((NX_ULONG)(0x00000000))
#define	VID_MASK						((NX_USHORT)0x0FFF)
#define	PCP_MASK						((NX_USHORT)0x0007)
#define	VIDPCP_NONSET					((NX_USHORT)0xFFFF)
#define	OPC_PCP_SAME_TSNO_BASE			((NX_ULONG)0x11111111)

typedef struct tagRE_ETYP_TBLREC {
	NX_USHORT	usOddEven;
	NX_ULONG	ulRegAddr;
} RE_ETYP_TBLREC;

typedef struct tagVLAN_SETTING_INFO {
	NX_ULONG	ulVlanNum;
	NX_USHORT	ausVlanList[16];
} VLAN_SETTING_INFO;

NX_STATIC NX_CONST RE_ETYP_TBLREC	gstRE_ETYPTbl[NX_PORT_SIZE][TS_SIZE_EXCEPT_TS0] = {
	{	{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP0)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP0)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP1)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP1)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP2)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP2)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP3)}
	},
	{	{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP4)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP4)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP5)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP5)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP6)},
		{TSLT_EVEN,	(NX_ULONG)&(NGN_CN_REG->R_REETYP6)},
		{TSLT_ODD,	(NX_ULONG)&(NGN_CN_REG->R_REETYP7)}
	}
};

NX_STATIC NX_VOLATILE NX_ULONG* NX_CONST gaplOpcVidAsicTbl[NX_PORT_SIZE][ASIC_OPC_ENABLED_VID_AREA] = {
	{
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P1[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P1[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P1[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P1[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P1[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P1[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P1[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P1[3].DATA),
	},
	{
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P2[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P2[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P2[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID1_4_P2[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P2[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P2[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P2[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVID5_8_P2[3].DATA),
	}
};

NX_STATIC NX_VOLATILE NX_ULONG* NX_CONST gaplOpcVlanTsTbl[NX_PORT_SIZE][ASIC_OPC_ENABLED_VLANTAG_TSLT_AREA] = {
	{
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[4].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[5].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[6].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P1[7].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[4].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[5].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[6].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P1[7].DATA),
	},
	{
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[4].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[5].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[6].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS1_8_P2[7].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[0].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[1].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[2].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[3].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[4].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[5].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[6].DATA),
		(NX_ULONG*)&(NGN_CN_RE_REG->R_RE_OPCVLNTS9_16_P2[7].DATA),
	}
};

NX_STATIC	NX_USHORT	gusBitPattern;
NX_STATIC	NX_USHORT	gusBitPatternSelect;
NX_STATIC	VLAN_SETTING_INFO	gastVlanSettingInfo[NX_PORT_SIZE];

NX_VOID		vNMG_ChkNetworkConfigTsltReq ( FRM_NC_TSLT_REQ*, NX_ULONG* );
NX_ULONG	ulNMG_ChkRangeNwCfgTsltReq ( FRM_NC_TSLT_REQ* );
NX_VOID		vNMG_Extract_NwCfgTsltReq ( FRM_NC_TSLT_REQ* );
NX_VOID		vNMG_SetTslt ( NX_UCHAR, NX_ULONG, NX_USHORT, FRM_NCTSLTREQ_TSLT* );
NX_VOID		vNMG_SetTsltDistinction ( FRM_NCTSLTREQ_PORTCMN* );
NX_VOID		vNMG_SetPortTsltDistinctEthrType ( NX_USHORT, FRM_NCTSLTREQ_ETHERTYPE_CMN* );
NX_VOID		vNMG_SetAsicTsltDistinctEthrType ( NX_USHORT, NX_USHORT, NX_USHORT );
NX_VOID		vNMG_CreateNwCfgTsltRespNrml ( FRM_NC_TSLT_REQ* );
NX_VOID		vNMG_CreateNwCfgTsltRespFault ( FRM_NC_TSLT_REQ*, NX_USHORT );
NX_VOID		vNMG_TrnsNetStsRcvNwCfgTsltReq ( NX_VOID );
NX_STATIC NX_VOID	vNMG_SetPortAsicVlan( NX_USHORT, FRM_NCTSLTREQ_VLAN_CMN* );
NX_STATIC NX_ULONG ulNMG_GetVlanIndex (NX_USHORT, NX_USHORT);

NX_VOID vNMG_AnalyzeNetworkConfigTsltReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_NC_TSLT_REQ	*pstFrm;
	NX_ULONG		ulChkResult		= NX_ZERO;

	pstFrm = (FRM_NC_TSLT_REQ*)pData;
	
	vNMG_ChkNetworkConfigTsltReq(pstFrm, &ulChkResult);
	
	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_NwCfgTsltReq(pstFrm);
		
		vNMG_CreateNwCfgTsltRespNrml(pstFrm);
		vNMG_ReqTrnNetworkConfigTsltResp();
		
		vNMG_TrnsNetStsRcvNwCfgTsltReq();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateNwCfgTsltRespFault(pstFrm, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnNetworkConfigTsltResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateNwCfgTsltRespFault(pstFrm, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnNetworkConfigTsltResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_ChkNetworkConfigTsltReq (
	FRM_NC_TSLT_REQ		*pstFrm,
	NX_ULONG			*pulChkResult
)
{
	NX_ULONG	ulRangeChkResult	= NX_UL_NG;

	if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
		(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
		(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
		if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
			*pulChkResult	= RESP_DIV_ERR;
		}
		else {
			*pulChkResult = RESP_DESTRUCT;
		}
	}
	else {
		ulRangeChkResult = ulNMG_ChkRangeNwCfgTsltReq(pstFrm);

		if (NX_UL_OK == ulRangeChkResult) {
			*pulChkResult	= RESP_NORMAL;
		}
		else {
			*pulChkResult	= RESP_ERR;
		}
	}

	return;
}

NX_ULONG ulNMG_ChkRangeNwCfgTsltReq (
	FRM_NC_TSLT_REQ	*pstFrm
)
{
	NX_USHORT						usTsltLoop			= NX_ZERO;
	NX_USHORT						usPortLoop			= NX_ZERO;
	NX_USHORT						usMacLoop			= NX_ZERO;
	NX_USHORT						usVlanLoop			= NX_ZERO;
	NX_USHORT						usBitPatternResult;
	NX_USHORT						usTsltAddNum		= NX_ZERO;
	NX_ULONG						ulAddrTsltSetting	= NX_ZERO;
	NX_ULONG						ulAddrPortCmn		= NX_ZERO;
	NX_ULONG						ulAddrEtherCmn		= NX_ZERO;
	NX_ULONG						ulAddrEtherSetting	= NX_ZERO;
	NX_ULONG						ulAddrMacCmn		= NX_ZERO;
	NX_ULONG						ulAddrMacSetting	= NX_ZERO;
	NX_ULONG						ulAddrVlanCmn		= NX_ZERO;
	NX_ULONG						ulAddrVlanSetting	= NX_ZERO;
	NX_ULONG						ulCycleTimeChkRslt	= NX_ZERO;
	NX_ULONGLONG					ullCycleTime_ns		= NX_ZERO;
	NX_USHORT						usLinkSpdSta	    = NX_US_ZERO;
	NX_USHORT						usAuthClass			= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	FRM_NCTSLTREQ_TSLT*				pstTsltSetting;
	FRM_NCTSLTREQ_PORTCMN*			pstPortCmn;
	FRM_NCTSLTREQ_ETHERTYPE_CMN*	pstEtherCmn;
	FRM_NCTSLTREQ_ETHERTYPE*		pstEtherSetting;
	FRM_NCTSLTREQ_MAC_CMN*			pstMacCmn;
	FRM_NCTSLTREQ_MAC*				pstMacSetting;
	FRM_NCTSLTREQ_VLAN_CMN*			pstVlanCmn;
	FRM_NCTSLTREQ_VLAN*				pstVlanSetting;

	ulAddrTsltSetting	= (NX_ULONG)pstFrm + sizeof(FRM_NC_TSLT_REQ);
	pstTsltSetting		= (FRM_NCTSLTREQ_TSLT*)ulAddrTsltSetting;

	ulAddrPortCmn		= ulAddrTsltSetting + sizeof(FRM_NCTSLTREQ_TSLT) * pstFrm->uchTimeslotNum;
	pstPortCmn			= (FRM_NCTSLTREQ_PORTCMN*)ulAddrPortCmn;

	ulAddrEtherCmn		= ulAddrPortCmn + sizeof(FRM_NCTSLTREQ_PORTCMN);
	pstEtherCmn			= (FRM_NCTSLTREQ_ETHERTYPE_CMN*)ulAddrEtherCmn;

	ulAddrEtherSetting	= ulAddrEtherCmn + sizeof(FRM_NCTSLTREQ_ETHERTYPE_CMN);
	pstEtherSetting		= (FRM_NCTSLTREQ_ETHERTYPE*)ulAddrEtherSetting;

	ulAddrMacCmn		= ulAddrEtherSetting + sizeof(FRM_NCTSLTREQ_ETHERTYPE) * pstEtherCmn->uchDeterminationSettingNum;
	pstMacCmn			= (FRM_NCTSLTREQ_MAC_CMN*)ulAddrMacCmn;

	ulAddrMacSetting	= ulAddrMacCmn + sizeof(FRM_NCTSLTREQ_MAC_CMN);
	pstMacSetting		= (FRM_NCTSLTREQ_MAC*)ulAddrMacSetting;

	ulAddrVlanCmn		= ulAddrMacSetting + sizeof(FRM_NCTSLTREQ_MAC) * pstMacCmn->usDeterminationSettingNum;
	pstVlanCmn			= (FRM_NCTSLTREQ_VLAN_CMN*)ulAddrVlanCmn;

	ulAddrVlanSetting	= ulAddrVlanCmn + sizeof(FRM_NCTSLTREQ_VLAN_CMN);
	pstVlanSetting		= (FRM_NCTSLTREQ_VLAN*)ulAddrVlanSetting;

	ullCycleTime_ns = (NX_ULONGLONG)(pstFrm->ulCommunicationCycle_ns + (pstFrm->usCommunicationCycle_s * NX_DIV_NSTOS));
	usLinkSpdSta		= usLSM_GetLinkSpd();

	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		ulCycleTimeChkRslt	= ulNX_ChkCycleTimeVal(ullCycleTime_ns, usLinkSpdSta, usAuthClass);
		if (NX_UL_NG == ulCycleTimeChkRslt) {
			if (NX_LINKSPD_STA_1G == usLinkSpdSta) {
				vNMG_SetNmgErr(EVENTCODE_1G_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_001]);
				return NX_UL_NG;
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_100M_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_001]);
				return NX_UL_NG;
			}
		}
		if (NX_LINKSPD_STA_1G == usLinkSpdSta) {
			usBitPatternResult	= usNMG_GetRemainderBitPattern(pstFrm->ulCommunicationCycle_ns, &gusBitPatternSelect, &gusBitPattern);
			if (NX_US_NG == usBitPatternResult) {
				vNMG_SetNmgErr(EVENTCODE_1G_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_001]);
				return	NX_UL_NG;
			}
		}
		else {
			if ((NX_ULONG)NX_REMAIND_0 != (pstFrm->ulCommunicationCycle_ns % COMMUNI_CYCLE_80NS_100M)) {
				vNMG_SetNmgErr(EVENTCODE_100M_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_001]);
				return NX_UL_NG;
			}
		}
	}
	else {
	}


	if (((NX_ULONGLONG)(pstFrm->ulCommunicationCycle_ns + (pstFrm->usCommunicationCycle_s * NX_DIV_NSTOS)) == COMMUNI_CYCLE_0NS) ||
		((NX_ULONGLONG)(pstFrm->ulCommunicationCycle_ns + (pstFrm->usCommunicationCycle_s * NX_DIV_NSTOS)) > COMMUNI_CYCLE_15STONS) ||
		(pstFrm->ulCommunicationCycle_ns > COMMUNI_CYCLE_999999999NS)) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_001]);
		return NX_UL_NG;
	}
	if ((pstFrm->uchTimeslotNum == (NX_UCHAR)NX_ZERO) ||
		(pstFrm->uchTimeslotNum > (NX_UCHAR)(TS_SIZE))) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_002]);
		return NX_UL_NG;
	}

	for (usTsltLoop = NX_ZERO; usTsltLoop < pstFrm->uchTimeslotNum; usTsltLoop++) {
		if (((NX_ULONGLONG)(pstTsltSetting->ulStartOffset_ns + (pstTsltSetting->usStartOffset_s * NX_DIV_NSTOS)) > COMMUNI_CYCLE_15STONS) ||
			(pstTsltSetting->ulStartOffset_ns > COMMUNI_CYCLE_999999999NS)) {
			usTsltAddNum	= (NX_USHORT)NMG_IDX_ERR_PARAM_003 + (usTsltLoop * TSLT_ADD_NUM);
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[usTsltAddNum]);
			return NX_UL_NG;
		}
		if ((RELAYBANOFFSET_EN == pstTsltSetting->uchRelayBanUse) &&
			(((NX_ULONGLONG)(pstTsltSetting->ulRelayBanOffset_ns + (pstTsltSetting->usRelayBanOffset_s * NX_DIV_NSTOS)) > COMMUNI_CYCLE_15STONS) ||
			(pstTsltSetting->ulRelayBanOffset_ns > COMMUNI_CYCLE_999999999NS))) {
			usTsltAddNum	= (NX_USHORT)NMG_IDX_ERR_PARAM_005 + (usTsltLoop * TSLT_ADD_NUM);
			vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[usTsltAddNum]);
			return NX_UL_NG;
		}
		ulAddrTsltSetting	= ulAddrTsltSetting + sizeof(FRM_NCTSLTREQ_TSLT);
		pstTsltSetting		= (FRM_NCTSLTREQ_TSLT*)ulAddrTsltSetting;
	}
	for (usPortLoop = NX_ZERO; usPortLoop < (NX_USHORT)pstPortCmn->uchPortNum; usPortLoop++) {
		if (usPortLoop == (NX_USHORT)(NX_PORT_SIZE)) {
			break;
		}
		if (pstMacCmn->usDeterminationSettingNum > NX_NTWCNF_MAC_SETTING_NUM_MAX) {
			if (usPortLoop == (NX_USHORT)NX_ZERO) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_044]);
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_061]);
			}
			return NX_UL_NG;
		}
		else if (pstMacCmn->usDeterminationSettingNum	== (NX_USHORT)NX_ZERO) {
		}
		else {
			if (usPortLoop == (NX_USHORT)NX_ZERO) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_044]);
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_061]);
			}
			return NX_UL_NG;
		}
		for (usMacLoop = NX_ZERO; usMacLoop < pstMacCmn->usDeterminationSettingNum; usMacLoop++) {
			if (pstMacSetting->uchTimeslotNo >= (NX_UCHAR)TS_SIZE) {
				if (usPortLoop == (NX_USHORT)NX_ZERO) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_044]);
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_061]);
				}
				return NX_UL_NG;
			}
			if (pstMacSetting->uchReceiveNecessity >= NX_UC_RECV_NECESSITY_NG_2_OR_MORE) {
				if (usPortLoop == (NX_USHORT)NX_ZERO) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_044]);
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_061]);
				}
				return NX_UL_NG;
			}
			ulAddrMacSetting	= ulAddrMacSetting + sizeof(FRM_NCTSLTREQ_MAC);
			pstMacSetting		= (FRM_NCTSLTREQ_MAC*)ulAddrMacSetting;
		}
		
		if (pstVlanCmn->usDeterminationSettingNum > NX_NTWCNF_VLAN_SETTING_NUM_MAX) {
			if (usPortLoop == (NX_USHORT)NX_ZERO) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_045]);
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_062]);
			}
			return NX_UL_NG;
		}
		else {
		}

		for (usVlanLoop = NX_ZERO; usVlanLoop < pstVlanCmn->usDeterminationSettingNum; usVlanLoop++) {
			if ((pstVlanSetting->usVID != VIDPCP_NONSET) &&
				(((VID_MASK & pstVlanSetting->usVID) == NX_US_VID_NG_0000) ||
				 ((VID_MASK & pstVlanSetting->usVID) == NX_US_VID_NG_0FFF))) {
				if (usPortLoop == (NX_USHORT)NX_ZERO) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_045]);
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_062]);
				}
				return NX_UL_NG;
			}
			
			if (pstVlanSetting->uchTimeslotNo >= (NX_UCHAR)TS_SIZE) {
				if (usPortLoop == (NX_USHORT)NX_ZERO) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_045]);
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_NwCfgTslt[NMG_IDX_ERR_PARAM_062]);
				}
				return NX_UL_NG;
			}
			ulAddrVlanSetting	= ulAddrVlanSetting + sizeof(FRM_NCTSLTREQ_VLAN);
			pstVlanSetting		= (FRM_NCTSLTREQ_VLAN*)ulAddrVlanSetting;
		}

		if (usPortLoop < (NX_USHORT)(pstPortCmn->uchPortNum - (NX_UCHAR)NX_ONE)) {
			ulAddrEtherCmn		= ulAddrVlanSetting;
			pstEtherCmn			= (FRM_NCTSLTREQ_ETHERTYPE_CMN*)ulAddrEtherCmn;

			ulAddrEtherSetting	= ulAddrEtherCmn + sizeof(FRM_NCTSLTREQ_ETHERTYPE_CMN);
			pstEtherSetting		= (FRM_NCTSLTREQ_ETHERTYPE*)ulAddrEtherSetting;

			ulAddrMacCmn		= ulAddrEtherSetting + sizeof(FRM_NCTSLTREQ_ETHERTYPE) * pstEtherCmn->uchDeterminationSettingNum;
			pstMacCmn			= (FRM_NCTSLTREQ_MAC_CMN*)ulAddrMacCmn;

			ulAddrMacSetting	= ulAddrMacCmn + sizeof(FRM_NCTSLTREQ_MAC_CMN);
			pstMacSetting		= (FRM_NCTSLTREQ_MAC*)ulAddrMacSetting;

			ulAddrVlanCmn		= ulAddrMacSetting + sizeof(FRM_NCTSLTREQ_MAC) * pstMacCmn->usDeterminationSettingNum;
			pstVlanCmn			= (FRM_NCTSLTREQ_VLAN_CMN*)ulAddrVlanCmn;

			ulAddrVlanSetting	= ulAddrVlanCmn + sizeof(FRM_NCTSLTREQ_VLAN_CMN);
			pstVlanSetting		= (FRM_NCTSLTREQ_VLAN*)ulAddrVlanSetting;
		}
		else {
		}
	}

	return NX_UL_OK;
}

NX_VOID vNMG_Extract_NwCfgTsltReq (
	FRM_NC_TSLT_REQ	*pstFrm
)
{
	NX_ULONG	ulAddrTsltSetting		=	NX_ZERO;
	NX_ULONG	ulAddrTsltDistinction	=	NX_ZERO;
	NX_ULONGLONG  ullComCycle_SetASIC	=	(NX_ULONGLONG)NX_ZERO;
	NX_USHORT	usLinkSpdSta 			= 	NX_LINKSPD_STA_1G;
	NX_USHORT 	usAuthClass				=	NX_AUTHENTICATION_CLS_B;
	
	
	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle	=	((NX_ULONGLONG)pstFrm->usCommunicationCycle_s * NX_DIV_NSTOS) + (NX_ULONGLONG)pstFrm->ulCommunicationCycle_ns;
	
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		ullComCycle_SetASIC = gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle / TSLT_10TIMES;
		NGN_CN_TS_P1_REG->R_TCPXTSN.BITS.b1EZCycleTimeNs	=	(NX_ULONG)((ullComCycle_SetASIC % NX_NSEC_1000000000) & NX_BIT03_29);
		NGN_CN_TS_P1_REG->R_TCPXTSS.BITS.b04ZCycleTimeSec	=	(NX_ULONG)(ullComCycle_SetASIC / NX_NSEC_1000000000);
	}
	else {
		NGN_CN_TS_P1_REG->R_TCPXTSN.BITS.b1EZCycleTimeNs	=	(pstFrm->ulCommunicationCycle_ns & NX_BIT03_29);
		NGN_CN_TS_P1_REG->R_TCPXTSS.BITS.b04ZCycleTimeSec	=	(NX_UCHAR)pstFrm->usCommunicationCycle_s;
	}
	NGN_CN_TS_P1_REG->R_TCPXREVICE			= gusBitPattern;
	NGN_CN_TS_P1_REG->R_TCPXREVICE_BPSEL	= gusBitPatternSelect;
	NGN_CN_TS_P1_REG->R_TCPXREVICE_RST		= NX_ON;
	
	ulAddrTsltSetting	=	(NX_ULONG)pstFrm + sizeof(FRM_NC_TSLT_REQ);
	usAuthClass = usACM_GetAuthenticationClass();
	
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		vNMG_SetTslt(	pstFrm->uchTimeslotNum,
					pstFrm->ulCommunicationCycle_ns,
					pstFrm->usCommunicationCycle_s,
					(FRM_NCTSLTREQ_TSLT*)ulAddrTsltSetting
		);
		
		ulAddrTsltDistinction = ulAddrTsltSetting + sizeof(FRM_NCTSLTREQ_TSLT) * pstFrm->uchTimeslotNum;
		vNMG_SetTsltDistinction((FRM_NCTSLTREQ_PORTCMN*)ulAddrTsltDistinction);
		gstNM.stNetworkConfigMain.uchTSNum = pstFrm->uchTimeslotNum;
	}
	else {
		vNMG_SetTslt(	(NX_UCHAR)NX_ONE,
						pstFrm->ulCommunicationCycle_ns,
						pstFrm->usCommunicationCycle_s,
						(FRM_NCTSLTREQ_TSLT*)ulAddrTsltSetting
		);
		
		ulAddrTsltDistinction = ulAddrTsltSetting + sizeof(FRM_NCTSLTREQ_TSLT) * pstFrm->uchTimeslotNum;
		vNMG_SetTsltDistinction((FRM_NCTSLTREQ_PORTCMN*)ulAddrTsltDistinction);
		gstNM.stNetworkConfigMain.uchTSNum = (NX_UCHAR)NX_ONE;
	}
	return;
}

NX_VOID vNMG_SetTslt (
	NX_UCHAR				uchTimeslotNum,
	NX_ULONG				ulCommunicationCycle_ns,
	NX_USHORT				usCommunicationCycle_s,
	FRM_NCTSLTREQ_TSLT		*pstData
)
{
	NX_UCHAR		uchTsltNo		= (NX_UCHAR)NX_ZERO;
	NX_UCHAR		uchTsltNoNext	= (NX_UCHAR)NX_ZERO;
	NX_UCHAR		uchTsltLast		= (uchTimeslotNum - (NX_UCHAR)NX_ONE);
	
	gstNM.stNetworkConfigTslt.uchTsltNum	= uchTimeslotNum;
	
	
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulStartOffset_ns		=	pstData[TSLT_TS0].ulStartOffset_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usStartOffset_s		=	pstData[TSLT_TS0].usStartOffset_s;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulEndOffset_ns		=	ulCommunicationCycle_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usEndOffset_s		=	usCommunicationCycle_s;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanUse		=	(NX_USHORT)pstData[TSLT_TS0].uchRelayBanUse;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulRelayBanOffset_ns	=	pstData[TSLT_TS0].ulRelayBanOffset_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanOffset_s	=	pstData[TSLT_TS0].usRelayBanOffset_s;
	
	for (uchTsltNo = TSLT_TS1; uchTsltNo < uchTsltLast; uchTsltNo++) {
		uchTsltNoNext = (uchTsltNo + (NX_UCHAR)NX_ONE);
		
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulStartOffset_ns		=	pstData[uchTsltNo].ulStartOffset_ns;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usStartOffset_s		=	pstData[uchTsltNo].usStartOffset_s;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulEndOffset_ns		=	pstData[uchTsltNoNext].ulStartOffset_ns;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usEndOffset_s		=	pstData[uchTsltNoNext].usStartOffset_s;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanUse		=	(NX_USHORT)pstData[uchTsltNo].uchRelayBanUse;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulRelayBanOffset_ns	=	pstData[uchTsltNo].ulRelayBanOffset_ns;
		gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanOffset_s	=	pstData[uchTsltNo].usRelayBanOffset_s;
	}
	
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulStartOffset_ns		=	pstData[uchTsltLast].ulStartOffset_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usStartOffset_s		=	pstData[uchTsltLast].usStartOffset_s;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulEndOffset_ns		=	pstData[TSLT_TS0].ulStartOffset_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usEndOffset_s		=	pstData[TSLT_TS0].usStartOffset_s;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanUse		=	(NX_USHORT)pstData[uchTsltLast].uchRelayBanUse;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].ulRelayBanOffset_ns	=	pstData[uchTsltLast].ulRelayBanOffset_ns;
	gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo].usRelayBanOffset_s	=	pstData[uchTsltLast].usRelayBanOffset_s;
	
	return;
}

NX_VOID vNMG_SetTsltTimeOffset (
	NX_UCHAR		uchTslt,
	TSLT_OFFSET		*pstOffset
)
{
	NX_ULONG	ulActualRelayBanOffset_ns	= NX_ZERO;
	NX_USHORT	usActualRelayBanOffset_s	= NX_ZERO;
	NX_ULONG	ulProhibTime_ns		= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulStrOffsetCalc_s	= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulStrOffsetCalc_ns	= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulEndOffsetCalc_s	= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulEndOffsetCalc_ns	= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulTsStartTimeNs	= NX_ZERO;
	NX_ULONG	ulTsStartTimeS	= NX_ZERO;
	NX_ULONG	ulTsEndTimeNs	= NX_ZERO;
	NX_ULONG	ulTsEndTimeS	= NX_ZERO;
	NX_ULONG	ulComCycleNs	= NX_ZERO;
	NX_ULONG	ulComCycleS		= NX_ZERO;
	
	
	ulProhibTime_ns	= ((NX_ULONG)gstNM.stNetworkConfigMain.uchTrnForbidTime * NX_MUL_USTONS);
	ulStrOffsetCalc_s = (NX_ULONG)pstOffset->usStartOffset_s;
	ulStrOffsetCalc_ns = pstOffset->ulStartOffset_ns + ulProhibTime_ns;
	if (NX_NSEC_1000000000 <= ulStrOffsetCalc_ns) {
		ulStrOffsetCalc_s	=	ulStrOffsetCalc_s + (NX_ULONG)NX_ONE;
		ulStrOffsetCalc_ns	-=	NX_NSEC_1000000000;
	}
	else {
	}
	
	if ( pstOffset->ulEndOffset_ns < ulProhibTime_ns ) {
		if ( (NX_USHORT)NX_ZERO != pstOffset->usEndOffset_s ) {
			ulEndOffsetCalc_s	=	(NX_ULONG)(pstOffset->usEndOffset_s - (NX_USHORT)NX_ONE);
			ulEndOffsetCalc_ns	=	ulProhibTime_ns - pstOffset->ulEndOffset_ns;
		}
	}
	else {
		ulEndOffsetCalc_s		=	(NX_ULONG)pstOffset->usEndOffset_s;
		ulEndOffsetCalc_ns		=	pstOffset->ulEndOffset_ns - ulProhibTime_ns;
	}
	NGN_CN_TS_P1_REG->R_TCPXSOnN[uchTslt].DATA	=	(ulStrOffsetCalc_ns & NX_BIT03_29);
	NGN_CN_TS_P1_REG->R_TCPXSOnS[uchTslt].DATA	=	ulStrOffsetCalc_s;
	
	NGN_CN_TS_P1_REG->R_TCPXEOnN[uchTslt].DATA	=	(ulEndOffsetCalc_ns & NX_BIT03_29);
	NGN_CN_TS_P1_REG->R_TCPXEOnS[uchTslt].DATA	=	ulEndOffsetCalc_s;
	
	if (pstOffset->usRelayBanUse == RELAYBANOFFSET_EN) {
		ulActualRelayBanOffset_ns	=	pstOffset->ulRelayBanOffset_ns;
		usActualRelayBanOffset_s	=	pstOffset->usRelayBanOffset_s;
	}
	else {
		ulActualRelayBanOffset_ns	=	ulEndOffsetCalc_ns;
		usActualRelayBanOffset_s	=	ulEndOffsetCalc_s;
	}
	
	NGN_CN_TS_P1_REG->R_TCPXRCnN[uchTslt].DATA						=	ulActualRelayBanOffset_ns;
	NGN_CN_TS_P1_REG->R_TCPXRCnS[uchTslt].BITS.b08ZStartOffsetSec	=	(NX_ULONG)usActualRelayBanOffset_s;
	
	ulTsStartTimeNs		=	NGN_CN_TS_P1_REG->R_TCPXSOnN[uchTslt].DATA;
	ulTsStartTimeS		=	NGN_CN_TS_P1_REG->R_TCPXSOnS[uchTslt].DATA;
	ulTsEndTimeNs		=	NGN_CN_TS_P1_REG->R_TCPXEOnN[uchTslt].DATA;
	ulTsEndTimeS		=	NGN_CN_TS_P1_REG->R_TCPXEOnS[uchTslt].DATA;
	
	ulComCycleNs		=	NGN_CN_TS_P1_REG->R_TCPXTSN.DATA;
	ulComCycleS			=	NGN_CN_TS_P1_REG->R_TCPXTSS.DATA;
	
	gstNM.stNetworkConfigMain.stNcfComCyc.ullTsStartTime[uchTslt]	=	((NX_ULONGLONG)ulTsStartTimeS	*	NX_DIV_NSTOS) + (NX_ULONGLONG)ulTsStartTimeNs;
	gstNM.stNetworkConfigMain.stNcfComCyc.ullTsEndTime[uchTslt] 	=	((NX_ULONGLONG)ulTsEndTimeS		*	NX_DIV_NSTOS) + (NX_ULONGLONG)ulTsEndTimeNs;
	return;
}

NX_VOID vNMG_SetTsltDistinction (
	FRM_NCTSLTREQ_PORTCMN	*pstPortCmn
)
{
	NX_USHORT					usPort	= (NX_USHORT)NX_PORT1;
	FRM_NCTSLTREQ_ETHERTYPE_CMN	*pstEtherTypeCmn;
	FRM_NCTSLTREQ_MAC_CMN		*pstMacCmn;
	FRM_NCTSLTREQ_VLAN_CMN		*pstVlanCmn;
	
	pstEtherTypeCmn = (FRM_NCTSLTREQ_ETHERTYPE_CMN*)(
			(NX_ULONG)pstPortCmn +
			(NX_ULONG)sizeof(FRM_NCTSLTREQ_PORTCMN)
			);
	pstMacCmn = (FRM_NCTSLTREQ_MAC_CMN*)(
		(NX_ULONG)pstEtherTypeCmn +
		(NX_ULONG)sizeof(FRM_NCTSLTREQ_ETHERTYPE_CMN) +
		(NX_ULONG)sizeof(FRM_NCTSLTREQ_ETHERTYPE) * pstEtherTypeCmn->uchDeterminationSettingNum
		);
	pstVlanCmn = (FRM_NCTSLTREQ_VLAN_CMN*)(
		(NX_ULONG)pstMacCmn +
		(NX_ULONG)sizeof(FRM_NCTSLTREQ_MAC_CMN) +
		(NX_ULONG)sizeof(FRM_NCTSLTREQ_MAC) * pstMacCmn->usDeterminationSettingNum
		);
	
	for (usPort = (NX_USHORT)NX_PORT1; usPort < (NX_USHORT)pstPortCmn->uchPortNum; usPort++) {
		vNMG_SetPortTsltDistinctEthrType(usPort, pstEtherTypeCmn);
		
		
		vNMG_SetPortAsicVlan(usPort, pstVlanCmn);
		
		if ((pstPortCmn->uchPortCommonSetting == TSLTDISTINCT_SET_PORTCMN_DIS) &&
			(usPort < (NX_USHORT)(pstPortCmn->uchPortNum - (NX_UCHAR)NX_ONE))) {
			pstEtherTypeCmn = (FRM_NCTSLTREQ_ETHERTYPE_CMN*)(
				(NX_ULONG)pstVlanCmn +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_VLAN_CMN) +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_VLAN) * pstVlanCmn->usDeterminationSettingNum
				);
			pstMacCmn = (FRM_NCTSLTREQ_MAC_CMN*)(
				(NX_ULONG)pstEtherTypeCmn +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_ETHERTYPE_CMN) +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_ETHERTYPE) * pstEtherTypeCmn->uchDeterminationSettingNum
				);
			pstVlanCmn = (FRM_NCTSLTREQ_VLAN_CMN*)(
				(NX_ULONG)pstMacCmn +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_MAC_CMN) +
				(NX_ULONG)sizeof(FRM_NCTSLTREQ_MAC) * pstMacCmn->usDeterminationSettingNum
				);
		}
		else {
		}
	}
	
	return;
}

NX_VOID vNMG_SetPortTsltDistinctEthrType (
	NX_USHORT						usPort,
	FRM_NCTSLTREQ_ETHERTYPE_CMN		*pstCmn
)
{
	NX_UCHAR					uchTsltNo	=	NX_ZERO;
	NX_USHORT					usEtherType	=	NX_ZERO;
	FRM_NCTSLTREQ_ETHERTYPE		*pstTslt;
	
	pstTslt = (FRM_NCTSLTREQ_ETHERTYPE*)((NX_ULONG)pstCmn + sizeof(FRM_NCTSLTREQ_ETHERTYPE_CMN));
	
	for (uchTsltNo = NX_ZERO; uchTsltNo < pstCmn->uchDeterminationSettingNum; uchTsltNo++) {
		
		if (pstTslt->stDeterminationSetting.BIT.b01TsltEtherTypeSettingValid == TSLTDISTINCT_ETHERTYPE_EN) {
			usEtherType = pstTslt->usEtherType;
		}
		else {
			usEtherType = ASIC_ETHERTYPE_CLR;
		}
		
		vNMG_SetAsicTsltDistinctEthrType(usPort, uchTsltNo, usEtherType);
		
		pstTslt = (FRM_NCTSLTREQ_ETHERTYPE*)((NX_ULONG)pstTslt + sizeof(FRM_NCTSLTREQ_ETHERTYPE));
	}
	
	for (uchTsltNo = pstCmn->uchDeterminationSettingNum; uchTsltNo < (NX_UCHAR)TS_SIZE_EXCEPT_TS0; uchTsltNo++) {
		vNMG_SetAsicTsltDistinctEthrType(usPort, uchTsltNo, ASIC_ETHERTYPE_CLR);
	}
	
	return;
}

NX_VOID vNMG_SetAsicTsltDistinctEthrType (
	NX_USHORT	usPort,
	NX_USHORT	usTsltNo,
	NX_USHORT	usEtherType
)
{
	ASIC_RREETYP0_Bits	*pstReg;
	
	pstReg = (ASIC_RREETYP0_Bits*)gstRE_ETYPTbl[usPort][usTsltNo].ulRegAddr;
	
	if (gstRE_ETYPTbl[usPort][usTsltNo].usOddEven == TSLT_ODD) {
		pstReg->b10ZEtherTypeOddTs = usEtherType;
	}
	else {
		pstReg->b10ZEtherTypeEvenTs = usEtherType;
	}
	return;
}

NX_VOID vNMG_CreateNwCfgTsltRespNrml (
	FRM_NC_TSLT_REQ	*pstReq
)
{
	FRM_NC_TSLT_RESP_NORMAL	*pstResp;
	NX_USHORT	usRsvIndex	= (NX_USHORT)NX_ZERO;
	
	pstResp = (FRM_NC_TSLT_RESP_NORMAL*)gstNM.stTrnBuf.puchNetworkConfigTsltResp;
	
	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_NC_TSLT_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);
	
	pstResp->uchFixedZero		=	(NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId			=	(NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum	=	(NX_USHORT)NX_ZERO;
	pstResp->usDivisionId		=	(NX_USHORT)NX_ZERO;
	
	pstResp->uchNetworkConfigResult = NC_RESP_RESULT_MATCH;
	
	for (usRsvIndex = (NX_USHORT)NX_ZERO; usRsvIndex < (NX_USHORT)RESERVE_SIZE; usRsvIndex++) {
		pstResp->auchFixedZero[usRsvIndex]	= (NX_UCHAR)NX_ZERO;
	}

	return;
}

NX_VOID vNMG_CreateNwCfgTsltRespFault (
	FRM_NC_TSLT_REQ	*pstReq,
	NX_USHORT		usFinCode
)
{
	FRM_NC_TSLT_RESP_ERR	*pstResp;

	pstResp = (FRM_NC_TSLT_RESP_ERR*)gstNM.stTrnBuf.puchNetworkConfigTsltResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						usFinCode,
						sizeof(FRM_NC_TSLT_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= (NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId						= (NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum				= (NX_USHORT)NX_ZERO;
	pstResp->usDivisionId					= (NX_USHORT)NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsNetStsRcvNwCfgTsltReq ( NX_VOID )
{
	NX_UCHAR	uchTsltNo = TSLT_TS0;
	NX_USHORT	usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	if (gstNM.stNet.usNetSts == NETSTS_RCVD_DETECTION) {
		gstNM.stNet.usStatusFinish |= FIN_RCVD_NWCFG_TSLT;
		
		if (FIN_RCVD_NWCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_NWCFG)) {
			for (uchTsltNo = TSLT_TS0; uchTsltNo < gstNM.stNetworkConfigTslt.uchTsltNum; uchTsltNo++) {
				vNMG_SetTsltTimeOffset(uchTsltNo, &gstNM.stNetworkConfigTslt.astTsltOffset[uchTsltNo]);
			}
			
			usAuthClass = usACM_GetAuthenticationClass();
			if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
				vTsn_Start(&gstNM.stNetworkConfigMain.stNcfTsn);
			}
			gstNM.stNet.usNetSts = NETSTS_RCVD_NWCFG;
		}
	}
	
	return;
}

NX_VOID vNMG_GetOffsetTslt (
	NX_UCHAR			uchTsNo,
	NMG_OFFSET_TS_INFO	*pstOffsetTsInfo
)
{
	pstOffsetTsInfo->ulTSStartOffset_ns	= gstNM.stNetworkConfigTslt.astTsltOffset[uchTsNo].ulStartOffset_ns;
	pstOffsetTsInfo->ulTSStartOffset_s	= gstNM.stNetworkConfigTslt.astTsltOffset[uchTsNo].usStartOffset_s;
	pstOffsetTsInfo->ulTSEndOffset_ns	= gstNM.stNetworkConfigTslt.astTsltOffset[uchTsNo].ulEndOffset_ns;
	pstOffsetTsInfo->ulTSEndOffset_s	= gstNM.stNetworkConfigTslt.astTsltOffset[uchTsNo].usEndOffset_s;
	
	return;
}

NX_VOID vNMG_SetPortAsicVlan (
	NX_USHORT				usPort,
	FRM_NCTSLTREQ_VLAN_CMN* pstVlanCmn
)
{
	FRM_NCTSLTREQ_VLAN*	pstVlanSetting;
	NX_ULONG	ulIndex				= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulIndexVid			= (NX_ULONG)NX_ZERO;
	
	NX_ULONG	ulAddrVlanCmn		= (NX_ULONG)NX_ZERO;
	NX_ULONG	ulAddrVlanSetting	= (NX_ULONG)NX_ZERO;
	
	union {
		NX_ULONG			ulData;
		ASIC_RREOPCVID_Bits	stBits;
	}stOpcEnableVid;
	NX_ULONG	ulOpcVlanTs;
	NX_ULONG	ulSetVlanIndex		= (NX_ULONG)NX_ZERO;
	NX_USHORT	usAuthClass		= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	ulAddrVlanCmn 		= (NX_ULONG)pstVlanCmn;
	ulAddrVlanSetting	= ulAddrVlanCmn + sizeof(FRM_NCTSLTREQ_VLAN_CMN);
	pstVlanSetting		= (FRM_NCTSLTREQ_VLAN*)ulAddrVlanSetting;

	for (ulIndexVid = (NX_ULONG)NX_ZERO; ulIndexVid < ASIC_OPC_ENABLED_VID_AREA; ulIndexVid++) {
		*gaplOpcVidAsicTbl[usPort][ulIndexVid] = OPC_VID_INIT;
	}
	
	for (ulIndex = (NX_ULONG)NX_ZERO; ulIndex < ASIC_OPC_ENABLED_VLANTAG_TSLT_AREA; ulIndex++) {
		*gaplOpcVlanTsTbl[usPort][ulIndex] = OPC_VLAN_TS_INIT;
	}
	
	gstNM.stNetworkConfigTslt.astVlanConfig[usPort].usVlanNum = pstVlanCmn->usDeterminationSettingNum;
	
	usAuthClass = usACM_GetAuthenticationClass();
	if ((pstVlanCmn->usDeterminationSettingNum == (NX_USHORT)NX_ZERO) || (NX_AUTHENTICATION_CLS_A == usAuthClass)) {
		
		NGN_CN_RE_REG->R_RE_RJSET.BITS.b01ZFrmComTmgDscSlct = (NX_ULONG)NX_OFF;
	}
	else {
		NGN_CN_RE_REG->R_RE_RJSET.BITS.b01ZFrmComTmgDscSlct = (NX_ULONG)NX_ON;
	}

	vNX_FillMemory32((NX_VOID*)&gastVlanSettingInfo, (NX_LONG)NX_ZERO ,((NX_ULONG)sizeof(VLAN_SETTING_INFO) * (NX_ULONG)NX_PORT_SIZE) / sizeof(NX_ULONG));
	
	for (ulIndex = (NX_ULONG)NX_ZERO; ulIndex < (NX_ULONG)pstVlanCmn->usDeterminationSettingNum; ulIndex++) {
		stOpcEnableVid.ulData = (NX_ULONG)NX_ZERO;
		ulOpcVlanTs = (NX_ULONG)NX_ZERO;
		
		
		
			ulSetVlanIndex = ulNMG_GetVlanIndex(usPort, pstVlanSetting->usVID & VID_MASK);
			
			ulIndexVid	=	ulSetVlanIndex / (NX_ULONG)NX_TWO;

			if ((ulSetVlanIndex & NX_BIT0) == (NX_ULONG)NX_ZERO) {
				stOpcEnableVid.stBits.b0CZVIDVal1    = (NX_ULONG)(pstVlanSetting->usVID & VID_MASK);
				stOpcEnableVid.stBits.b01ZVIDEnable1 = (NX_ULONG)NX_ENABLE;
			}
			else {
				stOpcEnableVid.stBits.b0CZVIDVal2    = (NX_ULONG)(pstVlanSetting->usVID & VID_MASK);
				stOpcEnableVid.stBits.b01ZVIDEnable2 = (NX_ULONG)NX_ENABLE;
			}
			*gaplOpcVidAsicTbl[usPort][ulIndexVid] |= stOpcEnableVid.ulData;
		
		if (VIDPCP_NONSET != pstVlanSetting->usPCP) {
			ulOpcVlanTs = (NX_ULONG)pstVlanSetting->uchTimeslotNo << ((NX_ULONG)(pstVlanSetting->usPCP & PCP_MASK) * (NX_ULONG)NX_SHIFT4);
			
			*gaplOpcVlanTsTbl[usPort][ulSetVlanIndex] |= ulOpcVlanTs;
		}
		else {
			*gaplOpcVlanTsTbl[usPort][ulSetVlanIndex] = (NX_ULONG)pstVlanSetting->uchTimeslotNo * OPC_PCP_SAME_TSNO_BASE;
		}
		
		
		gstNM.stNetworkConfigTslt.astVlanConfig[usPort].astVlan[ulIndex].usVid = pstVlanSetting->usVID;
		gstNM.stNetworkConfigTslt.astVlanConfig[usPort].astVlan[ulIndex].usPcp = pstVlanSetting->usPCP;
		gstNM.stNetworkConfigTslt.astVlanConfig[usPort].astVlan[ulIndex].uchTsltNo = pstVlanSetting->uchTimeslotNo;
		
		ulAddrVlanSetting	= ulAddrVlanSetting + sizeof(FRM_NCTSLTREQ_VLAN);
		pstVlanSetting		= (FRM_NCTSLTREQ_VLAN*)ulAddrVlanSetting;
	}
	
	return;
}

NX_STATIC NX_ULONG ulNMG_GetVlanIndex (
	NX_USHORT	usPort,
	NX_USHORT	usVid
)
{
	NX_ULONG	ulIndex;
	NX_ULONG	ulExitstFlg;
	NX_ULONG	ulResultIndex;
	
	ulExitstFlg = (NX_ULONG)NX_OFF;
	for (ulIndex = (NX_ULONG)NX_ZERO; ulIndex < gastVlanSettingInfo[usPort].ulVlanNum; ulIndex++) {
		if (usVid == gastVlanSettingInfo[usPort].ausVlanList[ulIndex]) {
			ulExitstFlg = (NX_ULONG)NX_ON;
			break;
		}
	}
	
	if (ulExitstFlg == (NX_ULONG)NX_OFF) {
		ulResultIndex = gastVlanSettingInfo[usPort].ulVlanNum;
		gastVlanSettingInfo[usPort].ausVlanList[gastVlanSettingInfo[usPort].ulVlanNum] = usVid;
		gastVlanSettingInfo[usPort].ulVlanNum++;
	}
	else {
		ulResultIndex = ulIndex;
	}
	
	return ulResultIndex;
}
/*[EOF]*/
