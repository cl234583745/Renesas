/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTP_STRUCT_PORT_H__
#define __PTP_STRUCT_PORT_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct.h"
#include "ptp_Struct_Clock.h"


#include "MDSyncReceiveSM_GD.h"
#include "MDSyncSendSM_GD.h"
#include "MDDelayReqReceiveSM_GD.h"
#include "MDDelayRespReceiveSM_GD.h"
#include "MDDelayReqSendSM_GD.h"
#include "MDDelayRespSendSM_GD.h"
#include "MDPdelayReq_GD.h"
#include "MDPdelayResp_GD.h"
#include "AnnounceIntvalSet_GD.h"

#include "MDSyncIntvalSet_GD.h"
#include "MDLkDlyIntvalSet_GD.h"
#include "MDOneStpTxOprSet_GD.h"

#include "ptp_bmca.h"
#include "PortAnnounceReceiveSMGD.h"
#include "PortAnnounceInformationSMGD.h"
#include "PortAnnounceInformationExtSMGD.h"
#include "PortAnnounceTransmitSMGD.h"
#include "PortStateSelectionSMGD.h"

#include "ptp_LCEntity_GD.h"
#include "ptp_PDRQReceive_1588_GD.h"
#include "ptp_PDRQSend_1588_GD.h"
#include "ptp_PDRSReceive_1588_GD.h"
#include "ptp_PDRSSend_1588_GD.h"
#include "ptp_PSSReceive_1AS_GD.h"
#include "ptp_PSSReceive_1588_GD.h"
#include "ptp_PSSSend_GD.h"


typedef	union tagUN_PORT_GD
{
	PORTBMC_1588_GD			stPortBMC_1588_GD;

}	UN_PORT_GD;


typedef	struct	tagPSM1AS_GD
{
	PSSRECEIVESM_1AS_GD		stPSSReceiveSM_1AS_GD;
}	PSM1AS_GD;


typedef	struct	tagPSM1588_GD
{
	PSSRECEIVESM_1588_GD	stPSSReceiveSM_1588_GD;
	PDRQSENDSM_1588_GD		stPDRQSendSM_1588_GD;
	PDRSSENDSM_1588_GD		stPDRSSendSM_1588_GD;
	PDRQRECEIVESM_1588_GD	stPDRQReceiveSM_1588_GD;
	PDRSRECEIVESM_1588_GD	stPDRSReceiveSM_1588_GD;

}	PSM1588_GD;


typedef	union tagUN_PSM_GD
{
	PSM1AS_GD		stPsm1as_GD;

	PSM1588_GD		stPsm1588_GD;
}	UN_PSM_GD;



typedef	struct tagPORTDATA
{
	struct tagPORTDATA*			pstNextPortDataPtr;
	struct tagPORTDATA*			pstPrevPortDataPtr;
	
	PORT_GD						stPort_GD;
	PORTMD_GD					stPortMD_GD;
	PORTBMC_GD					stPortBMC_GD;
	UN_PORT_GD					stUn_Port_GD;

	PORT_1AS_GD					stPort_1AS_GD;
	PORT_1588_GD				stPort_1588_GD;

	PSSSENDSM_GD				stPSSSendSM_GD;
	MDSRECEIVESM_GD				stMDSReceiveSM_GD;
	MDSSENDSM_GD				stMDSSendSM_GD;
	MDPREQSM_GD					stMDPReqSM_GD;
	MDPRESPSM_GD				stMDPRespSM_GD;
	MDDREQRVSM_GD				stMDDReqRcvSM_GD;
	MDDRESPRVSM_GD				stMDDRespRcvSM_GD;
	MDDREQSDSM_GD				stMDDReqSndSM_GD;
	MDDRESPSDSM_GD				stMDDRespSndSM_GD;
	SISETTINGSM_GD				stSISettingSM_GD;
	LDISETTINGSM_GD				stLDISettingSM_GD;
	OSTOSETTINGSM_GD			stOSTOSettingSM_GD;
	PARECEIVESM_GD				stPAReceiveSM_GD;
	PAINFORMATIONSM_GD			stPAInformationSM_GD;
	PSSELECTIONSM_GD			stPSSelectionSM_GD;
	PAIEXTSM_GD					stPAIExtSM_GD;
	PATRANSMITSM_GD				stPATransmitSM_GD;
	AISSETTINGM_GD				stAISSettingM_GD;
	
	GPTPCAPTRANSSM_GD			stGPTPCapTransSM_GD;
	GPTPCAPRECVSM_GD			stGPTPCapRecvSM_GD;
	GPTPCAPINTSETSM_GD			stGPTPCapIntSetSM_GD;

	UN_PSM_GD					stUn_PSM_GD;
	
	
	PORT_DS						stPortDS;

	PORT_1AS_DS					stPort_1AS_DS;
	PORTSTATISTICS_1AS_DS		stPortStatistics_1AS_DS;
	DESCRIPTIONPORT_1AS_DS		stDescriptionPort_1AS_DS;
	ACCEPTABLE_M_PORT_1AS_DS	stAcceptableMasterPort_1AS_DS;

	PORT_1588_DS					stPort_1588_DS;
	TRANSPARENTCLOCKPORT_1588_DS	stTransparentClockPort_1588_DS;
	
	struct	tagCLOCKDATA*			pstClockData;

}	PORTDATA;


typedef struct tagDREQTMOMAN
{
	PORTDATA*	pstDreqSendPort;
	USCALEDNS 	stDreqCompWaitTimeoutTime;
}DREQTMOMAN;

typedef struct tagSYNCTMOMAN
{
	PORTDATA*	pstSyncSendPort;
	USCALEDNS 	stSyncTransTimeoutTime;
}SYNCTMOMAN;

#endif
