/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include <winsock2.h>
#include "ST_SNP_sv_l.h"
#include <Windows.h>
#include "ST_SNC_errcode.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_sync_sv_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNR_sv_l.h"
#include "ST_SNW_sv_l.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#else
#include <common.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_sync_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNP/inc/ST_SNP_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNP_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif

#ifdef SWPS
#define ST_SNP_MIB_BUFFERSIZE      (262144)
#endif

typedef struct {
#ifdef SWPS
	ST_SNR_Handle*			pstHandle;
	HANDLE					hStopEvent;
	ST_SNC_PmsgHeader*		pstHeader;
#else
	NX_USHORT					usType;
	const ST_SNC_MibMng*	pstMng;
	const NX_VOID*				pMsg;
	NX_ULONG					ulMsgSize;
	NX_ULONG*					pulDtlErrorCode;
#endif
} ST_SNP_ReqCntl;

#ifdef SWPS
#endif

static NX_ULONG ulST_SNP_StartInstruction(NX_VOID);
static NX_ULONG ulST_SNP_StopInstruction(NX_VOID);
static NX_ULONG ulST_SNP_ReqStart(ST_SNP_ReqCntl* pstReq);
static NX_ULONG ulST_SNP_ReqStop(ST_SNP_ReqCntl* pstReq);
static NX_ULONG ulST_SNP_ReqMibSet(ST_SNP_ReqCntl* pstReq);
static NX_ULONG ulST_SNP_ReqMibDel(ST_SNP_ReqCntl* pstReq);
static NX_ULONG ulST_SNP_ReqCommit(ST_SNP_ReqCntl* pstReq);
#ifdef SWPS
#endif

static NX_ULONG ulST_SNP_StartInstruction(NX_VOID)
{
	NX_ULONG ulRet = ST_SNC_OK;

#ifdef SWPS
	ulRet = ulST_SNW_SetStartEvent();
	if(ulRet == ST_SNC_OK) {
#endif
		ulRet = ulST_SNC_MibAllClear();
#ifdef SWPS
	}
	else {
		;
	}
#endif

	return ulRet;
}

static NX_ULONG ulST_SNP_StopInstruction(NX_VOID)
{
	NX_ULONG ulRet = ST_SNC_OK;

#ifdef SWPS
	ulRet = ulST_SNW_SetStopEvent();
	if(ulRet == ST_SNC_OK) {
#endif
		ulRet = ulST_SNC_MibAllClear();
#ifdef SWPS
	}
	else {
		;
	}
#endif
	return ulRet;
}

static NX_ULONG ulST_SNP_ReqStart(ST_SNP_ReqCntl* pstReq)
{
	NX_ULONG		ulRet	= ST_SNC_OK;
#ifdef SWPS
	NX_USHORT		usType	= ST_SNC_PMSG_TYPE_DUMY;

	usType = pstReq->pstHeader->usType & ST_SNC_PMSG_TYPE_MASK;

	ulRet = ulST_SNW_CheckAvailableRequestType(usType);
	if(ST_SNC_OK == ulRet) {
#endif

		ulRet = ulST_SNP_StartInstruction();
#ifdef SWPS
	}
	else {
		;
	}
#endif
	return ulRet;
}

static NX_ULONG ulST_SNP_ReqStop(ST_SNP_ReqCntl* pstReq)
{
#ifdef SWPS
	ST_SNC_PmsgHeader*	pstHeader	= NULL;
	ST_SNR_Handle*		pstHandle	= NULL;
#endif
	NX_ULONG				ulRet		= ST_SNC_OK;
#ifdef SWPS
	NX_USHORT				usType		= ST_SNC_PMSG_TYPE_DUMY;

	pstHeader = pstReq->pstHeader;
	pstHandle = pstReq->pstHandle;
	usType = pstHeader->usType & ST_SNC_PMSG_TYPE_MASK;

	ulRet = ulST_SNW_CheckAvailableRequestType(usType);
	if(ST_SNC_OK == ulRet) {

#endif
		ulRet = ulST_SNP_StopInstruction();
#ifdef SWPS
		if(ST_SNC_OK == ulRet) {

			ulRet = ulST_SNC_PipeResponse(
				pstHandle->hPipeOut,
				(ST_SNC_PMSG_SET_SV|usType),
				pstHeader->stMng.usOidmap,
				NULL,
				0);
		}
		else {
			;
		}
	}
	else {
		;
	}
#endif
	return ulRet;
}

static NX_ULONG ulST_SNP_ReqMibSet(ST_SNP_ReqCntl* pstReq)
{
#ifdef SWPS
	ST_SNC_PmsgHeader*	pstHeader	= NULL;
	ST_SNR_Handle*		pstHandle	= NULL;
#endif
	ST_SNC_Mibtype		eMibType	= ST_SNC_MIBTYPE_NONE;
	NX_ULONG				ulRet		= ST_SNC_OK;
	NX_USHORT				usType		= ST_SNC_PMSG_TYPE_DUMY;
	NX_UCHAR				uchMibClass = ST_SNM_MIBCLASS_EXT;
#ifdef SWPS
	DWORD				dwError		= 0;
#endif

#ifdef SWPS
	pstHeader = pstReq->pstHeader;
	pstHandle = pstReq->pstHandle;
	usType = pstHeader->usType & ST_SNC_PMSG_TYPE_MASK;
#else
	usType = pstReq->usType & ST_SNC_PMSG_TYPE_MASK;
#endif

#ifdef SWPS
	ulRet = ulST_SNC_PipeRecv(
				pstHandle->hPipeIn,
				pstReq->hStopEvent,
				gauchST_SNP_Buffer,
				pstHeader->ulMsgSize,
				__FUNCTION__,
				&dwError);
	if(ST_SNC_OK == ulRet) {


		ulRet = ulST_SNW_CheckAvailableRequestType(usType);
		if(ST_SNC_OK == ulRet) {
#endif

			if(ST_SNC_PMSG_TYPE_MIBSET == usType) {
				uchMibClass = ST_SNM_MIBCLASS_EXT;
			}
#ifdef SWPS
			else if(ST_SNC_PMSG_TYPE_LLDPMIBSET == usType) {
				uchMibClass = ST_SNM_MIBCLASS_LLDP;	
			}
#endif
			else {
				ulRet = ST_SNC_NG_PARAM_RANGE;
			}

			if(ST_SNC_OK == ulRet) {
				
#ifdef SWPS
				ulRet = ulST_SNM_Oidmap2Mibtype(uchMibClass, pstHeader->stMng.usOidmap, &eMibType);
#else
				ulRet = ulST_SNM_Oidmap2Mibtype(uchMibClass, pstReq->pstMng->usOidmap , &eMibType);
#endif
				if(ST_SNC_OK == ulRet) {

#ifdef SWPS
					ulRet = ulST_SNC_MibSetMemory(eMibType, &pstHeader->stMng, gauchST_SNP_Buffer);
#else
					ulRet = ulST_SNC_MibSetMemory(eMibType, pstReq->pstMng   , pstReq->pMsg      );
#endif
					if(ST_SNC_OK == ulRet) {
						;
					}
					else {
#ifdef SWPS
						DBGTRACE("%s MIB add failed (rc=%d omap=%d)", __FUNCTION__, ulRet, pstHeader->stMng.usOidmap);
#endif
					}

				}
				else {
#ifdef SWPS
					DBGTRACE("%s MIB type failed for add (rc=%d omap=%d)", __FUNCTION__, ulRet, pstHeader->stMng.usOidmap);
#endif
				}
			}
			else {
				;
			}
#ifdef SWPS
		}
		else {
			;
		}
	}
	else {
		DBGTRACE("%s  pipe received failed (%d)", __FUNCTION__, ulRet);
	}
#endif

	return ulRet;
}

static NX_ULONG ulST_SNP_ReqMibDel(ST_SNP_ReqCntl* pstReq)
{
#ifdef SWPS
	ST_SNC_PmsgHeader*	pstHeader	= NULL;
#endif
	ST_SNC_Mibtype		eMibType	= ST_SNC_MIBTYPE_NONE;
	NX_ULONG				ulRet		= ST_SNC_OK;
#ifdef SWPS
	NX_USHORT				usType		= ST_SNC_PMSG_TYPE_DUMY;
#endif

#ifdef SWPS
	pstHeader = pstReq->pstHeader;
	usType = pstHeader->usType & ST_SNC_PMSG_TYPE_MASK;

	ulRet = ulST_SNW_CheckAvailableRequestType(usType);
	if(ST_SNC_OK == ulRet) {
#endif

#ifdef SWPS
		ulRet = ulST_SNM_Oidmap2Mibtype(ST_SNM_MIBCLASS_EXT, pstHeader->stMng.usOidmap, &eMibType);
#else
		ulRet = ulST_SNM_Oidmap2Mibtype(ST_SNM_MIBCLASS_EXT, pstReq->pstMng->usOidmap , &eMibType);
#endif
		if(ST_SNC_OK == ulRet) {

			ulRet = ulST_SNC_MibClearMemory(eMibType);
			if(ST_SNC_OK == ulRet) {
				;
			}
			else {
#ifdef SWPS
				DBGTRACE("%s MIB del failed (rc=%d omap=%d)", __FUNCTION__, ulRet, pstHeader->stMng.usOidmap);
#endif
			}

		}
		else {
#ifdef SWPS
			DBGTRACE("%s MIB type failed for del (rc=%d omap=%d)", __FUNCTION__, ulRet, pstHeader->stMng.usOidmap);
#endif
		}
#ifdef SWPS
	}
	else {
		;
	}
#endif
	return ulRet;
}

static NX_ULONG ulST_SNP_ReqCommit(ST_SNP_ReqCntl* pstReq)
{
#ifdef SWPS
	ST_SNC_PmsgHeader*	pstHeader	= NULL;
#endif
	NX_ULONG				ulRet		= ST_SNC_OK;
#ifdef SWPS
	NX_USHORT				usType		= ST_SNC_PMSG_TYPE_DUMY;

	pstHeader = pstReq->pstHeader;
	usType = pstHeader->usType & ST_SNC_PMSG_TYPE_MASK;

	ulRet = ulST_SNW_CheckAvailableRequestType(usType);
	if(ST_SNC_OK == ulRet) {
#endif

		ulRet = ulST_SNC_MibAllCommit();
#ifdef SWPS
	}
	else {
		;
	}
#endif

	return ulRet;
}

#ifdef SWPS
#else
#endif
#ifdef SWPS
#else
NX_ULONG ulST_SNC_PipeSend(
	NX_USHORT					usType,
	const ST_SNC_MibMng*	pstMng,
	const NX_VOID*				pMsg,
	NX_ULONG					ulMsgSize,
	NX_ULONG*					pulDtlErrorCode
)
#endif
{
#ifdef SWPS
	ST_SNC_PmsgHeader				stHeader;
#endif
	ST_SNP_ReqCntl					stReq;
	NX_ULONG							ulRet		= ST_SNC_OK;
#ifdef SWPS
	DWORD							dwError		= 0;
	NX_USHORT							usType		= ST_SNC_PMSG_TYPE_DUMY;
#endif


#ifdef SWPS
	if(NULL != pstHandle) {

		DBGTRACE("%s(%d)", __FUNCTION__, pstHandle->hPipeIn);

		ZeroMemory(&stHeader, sizeof(stHeader));
		ZeroMemory(gauchST_SNP_Buffer, ST_SNP_MIB_BUFFERSIZE);

		ulRet = ulST_SNC_PipeRecv(
					pstHandle->hPipeIn,
					hStopEvent,
					&stHeader,
					sizeof(stHeader),
					__FUNCTION__,
					&dwError);
		if(ST_SNC_OK == ulRet) {

			ulRet = ulST_SNC_CheckHeader(&stHeader, ST_SNC_PMSG_SET_CL, ST_SNC_PMSG_TYPE_DUMY, ST_SNC_MAP_MAX);
			if(ST_SNC_OK == ulRet) {
#endif

#ifdef SWPS
				stReq.pstHandle = pstHandle;
				stReq.hStopEvent = hStopEvent;
				stReq.pstHeader  = &stHeader;

				usType = stHeader.usType & ST_SNC_PMSG_TYPE_MASK;
				DBGTRACE("Pipe Recv [%08x][%08x]", stHeader.usType, usType);
#else
				stReq.usType          = usType;
				stReq.pstMng          = pstMng;
				stReq.pMsg            = pMsg;
				stReq.ulMsgSize       = ulMsgSize;
				stReq.pulDtlErrorCode = pulDtlErrorCode;

				usType &= ST_SNC_PMSG_TYPE_MASK;
#endif


				switch(usType) {
				case ST_SNC_PMSG_TYPE_START:

					ulRet = ulST_SNP_ReqStart(&stReq);
					break;

				case ST_SNC_PMSG_TYPE_STOP:

					ulRet = ulST_SNP_ReqStop(&stReq);
					break;

				case ST_SNC_PMSG_TYPE_MIBSET:
#ifdef SWPS
				case ST_SNC_PMSG_TYPE_LLDPMIBSET:
#endif

					ulRet = ulST_SNP_ReqMibSet(&stReq);
					break;

				case ST_SNC_PMSG_TYPE_MIBDEL:

					ulRet = ulST_SNP_ReqMibDel(&stReq);
					break;

				case ST_SNC_PMSG_TYPE_MIBCOMMIT:

					ulRet = ulST_SNP_ReqCommit(&stReq);
					break;

				default :
					ulRet = ST_SNC_NG_PARAM_RANGE;
					break;
				}
#ifdef SWPS
			}
			else {
				DBGTRACE("%s Header Error %d [%08x][%08x]",__FUNCTION__, ulRet, stHeader.usType, usType);
			}
		}
		else {
			DBGTRACE("%s ulST_SNC_PipeRecv Error rc=%d", __FUNCTION__, ulRet);
		}

		DisconnectNamedPipe(pstHandle->hPipeOut);
		DisconnectNamedPipe(pstHandle->hPipeIn);
		CloseHandle(pstHandle->hPipeOut);
		CloseHandle(pstHandle->hPipeIn);
		DBGTRACE("CloseHandle(%d);", pstHandle->hPipeIn);

		SetEvent(pstHandle->hDisconnectEvent);

	}
	else {
		ulRet = ST_SNC_NG_PARAM_ADDR;
	}

	DBGTRACE("%s END(%d)", __FUNCTION__, ulRet);
#endif
	return ulRet;
}

#ifdef SWPS
#endif
