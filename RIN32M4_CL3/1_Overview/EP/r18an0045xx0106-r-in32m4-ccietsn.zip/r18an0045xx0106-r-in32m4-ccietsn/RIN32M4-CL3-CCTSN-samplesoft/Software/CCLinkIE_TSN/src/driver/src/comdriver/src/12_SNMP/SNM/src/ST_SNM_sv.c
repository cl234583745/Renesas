/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNM_get_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNR_sv_l.h"
#include "ST_SNP_sv_l.h"
#include "ST_SNW_sv_l.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_mmng_sv_l.h"

#include <Windows.h>
#include <process.h>
#include <snmp.h>
#include <tchar.h>
#include "ST_SNM_extmib_sv_l.h"

#include "ST_SNC_debug_com_l.h"
#ifdef SNC_DEBUG
#endif
#else
#include <common.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_sync_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNP/inc/ST_SNP_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNP_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif
#ifdef SWPS

typedef enum {
	ST_SNM_THRD_SNR,
	ST_SNM_THRD_SNP,
	ST_SNM_THRD_SNW,
	ST_SNM_THRD_MAX,
} ST_SNM_Thrdkind;

typedef struct ST_SNM_ThrdCntl_TAG {
	HANDLE		hHandle;
	unsigned	(WINAPI *pfunc)(NX_VOID* pvHandle);
} ST_SNM_ThrdCntl;
#endif

#ifdef SWPS
#endif
#ifdef SWPS
static NX_ULONG ulST_SNM_Start(NX_VOID);
static NX_ULONG ulST_SNM_Stop(NX_VOID);
#endif


#ifdef SWPS
#endif


#ifdef SWPS


#endif


#ifdef SWPS
static NX_ULONG ulST_SNM_Start(NX_VOID)
#else
NX_ULONG ulST_SNM_Start(NX_VOID)
#endif
{
#ifdef SWPS
	SECURITY_DESCRIPTOR		stDesc;
	SECURITY_ATTRIBUTES		stAttr;
#endif
	NX_ULONG					ulRet	= ST_SNC_OK;
#ifdef SWPS
	DWORD					dwError	= 0;
#endif
	NX_UCHAR					uchClass = 0;
#ifdef SWPS
	NX_UCHAR					uchThrdCount = 0;
#endif

#ifdef SWPS
	DBGTRACE("%s", __FUNCTION__);
	ST_SNC_SetSecAttr(&stDesc, &stAttr);
	ghST_SNM_ThrdEndEvt = CreateEvent(&stAttr, TRUE, FALSE, NX_NULL);
	if(NX_NULL == ghST_SNM_ThrdEndEvt){

		dwError = GetLastError();
		DBGTRACE("%s CreateEvent error (error=%d)", __FUNCTION__, dwError);
		ulRet = ST_SNC_NG_CREATE_EVENT;

	}
	else {
#endif

		ulRet = ulST_SNC_MibAlloc();
		if(ST_SNC_OK == ulRet) {

			for(uchClass=ST_SNM_MIBCLASS_EXT; uchClass<ST_SNM_MIBCLASS_MAX; uchClass++) {
				ulRet = ulST_SNM_GetAddr(uchClass);
				if(ST_SNC_OK != ulRet){
					DBGTRACE("%s ulST_SNM_GetAddr error (error=%d)", __FUNCTION__, ulRet);
					break;
				}
				else {
					;
				}
			}

#ifdef SWPS
			if(ST_SNC_OK == ulRet) {

				for(uchThrdCount=0; uchThrdCount<ST_SNM_THRD_MAX; uchThrdCount++ ) {

					gastST_SHM_ThrdTbl[uchThrdCount].hHandle = 
						(HANDLE)_beginthreadex(
							&stAttr,
							0,
							gastST_SHM_ThrdTbl[uchThrdCount].pfunc,
							ghST_SNM_ThrdEndEvt,
							0,
							NX_NULL);

					if(NX_NULL == gastST_SHM_ThrdTbl[uchThrdCount].hHandle) {

						DBGTRACE("request stanby thread_%d failed = %d", uchThrdCount, errno);
						ulRet = ST_SNC_NG_BEGINTHREAD;
						break;

					}
					else {
						;
					}
				}
			}
			else {
				;
			}
#endif
		}
		else {
			;
		}
#ifdef SWPS
	}
#endif

	if(ST_SNC_OK != ulRet) {
		ulST_SNM_Stop();
	}
	else {
		;
	}


	return  ulRet;
}

#ifdef SWPS
static NX_ULONG ulST_SNM_Stop(NX_VOID)
#else
NX_ULONG ulST_SNM_Stop(NX_VOID)
#endif
{
#ifdef SWPS
	HANDLE			ahHandle[ST_SNM_THRD_MAX];
#endif
	NX_ULONG			ulRet		= ST_SNC_OK;
#ifdef SWPS
	DWORD			dwObjs		= 0;
	DWORD			dwError		= 0;
	NX_ULONG			bRc			= TRUE;
	NX_UCHAR			ucCount		= 0;
	NX_UCHAR			ucHandle	= 0;
#endif

#ifdef SWPS
	DBGTRACE("%s", __FUNCTION__);
	if(NX_NULL != ghST_SNM_ThrdEndEvt) {

		bRc = SetEvent(ghST_SNM_ThrdEndEvt);
		if(TRUE == bRc) {
			
			DBGTRACE("%s SetEvent(%x)",__FUNCTION__, ghST_SNM_ThrdEndEvt);

			for(ucCount=0; ucCount<ST_SNM_THRD_MAX; ucCount++) {
				if(NX_NULL != gastST_SHM_ThrdTbl[ucCount].hHandle) {
					ahHandle[ucCount] = gastST_SHM_ThrdTbl[ucCount].hHandle;
					ucHandle++;
				}
				else {
					;
				}
			}

			if(0 < ucHandle) {

				DBGTRACE("%s --> WaitForMultipleObjects",__FUNCTION__);
				dwObjs = WaitForMultipleObjects(
							ucHandle,
							ahHandle,
							TRUE,
							INFINITE
							) - WAIT_OBJECT_0;
				DBGTRACE("%s <-- WaitForMultipleObjects(%d)",__FUNCTION__, dwObjs);
				if(dwObjs < ucHandle )	{

					for(ucCount=0; ucCount<ST_SNM_THRD_MAX; ucCount++) {

						if (NX_NULL != gastST_SHM_ThrdTbl[ucCount].hHandle) {
							CloseHandle(gastST_SHM_ThrdTbl[ucCount].hHandle);
						}
						else {
							;
						}
					}
#endif

					DBGTRACE("%s  --> ulST_SNC_MibAllClear",__FUNCTION__);
					ulRet = ulST_SNC_MibAllClear();
					DBGTRACE("%s  <-- ulST_SNC_MibAllClear(0x%x)",__FUNCTION__, ulRet);
					if(ST_SNC_OK == ulRet) {
						ulRet = ulST_SNC_MibFree();
					}
					else {
#ifdef SWPS
						DBGTRACE("%s(%d) failed rc=%d rs=%d",__FUNCTION__, __LINE__, ulRet, dwError);
#endif
						ulST_SNC_MibFree();
					}
#ifdef SWPS
				}
				else {
					dwError = GetLastError();
					ulRet = ST_SNC_NG_EVENT_WAIT;
				}

			}
			else {
			}

			CloseHandle(ghST_SNM_ThrdEndEvt);
			ghST_SNM_ThrdEndEvt = NX_NULL;

		}
		else {
			ulRet = ST_SNC_NG_SET_EVENT;
		}
	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	if(ST_SNC_OK != ulRet) {
		DBGTRACE("%s(%d) failed rc=%d rs=%d",__FUNCTION__, __LINE__, ulRet, dwError);
	}
	else {
		;
	}

	DBGTRACE("%s END", __FUNCTION__);
	DBGTRACECLOSE();
#endif

	return ulRet;
}


#ifdef SWPS


#endif

#ifdef SWPS
#endif



#ifdef SWPS





#endif


#ifdef SWPS










#endif
