/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MANAGEMENTSM_1AS_H__
#define __MANAGEMENTSM_1AS_H__

#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_managementid_as.h"

#define	MGTAS_ACTION_GET					(0U)
#define	MGTAS_ACTION_SET					(1U)
#define	MGTAS_ACTION_MAX	   (MGTAS_ACTION_SET)

typedef	enum	tagMID_APPLIES
{
	MID_APPLIES_CLOCK = 0,
	MID_APPLIES_PORT

}	MID_APPLIES;

typedef struct tagMGT_ACT_SEL_TBL_1AS
{
	UCHAR			uchManagementIdname[56];
	USHORT			usManagementId;
	MID_APPLIES		enTypeApplies;
	BOOL			(*pfnFunc[2])(VOID* pstData, UCHAR* puchInfo);
	USHORT			usMoldTypeSize;
}	MGT_ACT_SEL_TBL_1AS;


#ifdef __cplusplus
extern "C" {
#endif

	INT ManagementAPI_AS( UCHAR  uchAction, 
						  USHORT usParamId_AS, 
						  UCHAR  uchDomainNumber, 
						  USHORT usPortNumber, 
						  UCHAR* puchInfo, 
						  USHORT usInfoSize );

	INT	ManagementSM_1AS_API(UCHAR uchAction, USHORT usParamId_AS, CLOCKDATA* pstClockData, PORTDATA* pstPortData, UCHAR* puchInfo);
	BOOL GetManagementASParamId(USHORT usParamId_AS, USHORT* pusTblIndex, USHORT* pusSize);

	INT GetIe802AsDfltDSClockIdentity(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSNumberPorts(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSClockClass(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSClockAccuracy(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSOfsScaledLogVar(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSPriority1(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSPriority1(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSPriority2(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSPriority2(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSGmCapable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSCrntUtcOfs(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSCrntUtcOfsVal(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSLeap59(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSLeap59(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSLeap61(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSLeap61(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSTmTraceable(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSTmTraceable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSFrqTraceable(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsDfltDSFrqTraceable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsDfltDSTmSource(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSStepsRemoved(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSOfsFromMaster(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSLastGmPhsChg(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSLastGmFrqChg(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSGmTmbaseIndctr(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSGmChgCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSTmOfLsGmCgEv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSTmOfLsGmPhsCgEv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsCrntDSTmOfLsGmFrqCgEv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSPrntClkIdentity(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSPrntPortNumber(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSCumltvRateRatio(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMIdentity(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMClockClass(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMClockAccuracy(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMOfsScldLogVar(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMPriority1(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPrntDSGMPriority2(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSCrntUTCOfs(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSCrntUTCOfsVal(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSLeap59(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSLeap61(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSTmTraceable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSFrqTraceable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTmPropDSTmSource(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSClockIdentity(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSPortNumber(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSPortState(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSPortState(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSPtpPortEnabled(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSPtpPortEnabled(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSIsMeasuringDDly(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSAsCapable(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSNeighborPropDly(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSNeighbrPpDlyThr(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSNeighbrPpDlyThr(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSDlyAsymmetry(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSDlyAsymmetry(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSNeghbrRateRatio(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSInitLogAnncIntv(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSInitLogAnncIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSCrntLogAnncIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSAnnoceRecptTout(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSAnnoceRecptTout(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSInitLogSyncIntv(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSInitLogSyncIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSCrntLogSyncIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSSyncRecptTout(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSSyncRecptTout(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSSyncRecptTOTMIv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSInitLogPDRqIntv(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSInitLogPDRqIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSCrntLogPDRqIntv(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSAllowedLostResp(VOID* pstData, UCHAR* puchInfo);
	INT SetIe802AsPortDSAllowedLostResp(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPortDSVersionNumber(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxSyncCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxFollowUpCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxPDlyReqCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxPDlyRespCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxPDlyRespFllwUpCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxAnnoceCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsRxPTPPacketDscrdCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsSyncRecptToutCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsAnnoceRecptToutCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsPDlyAllwLstRpExcCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxSyncCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxFollowUpCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxPDlyReqCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxPDlyRespCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxPDlyRespFllwUpCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxAnnoceCount(VOID* pstData, UCHAR* puchInfo);
	INT GetIe802AsTxMessageErrorCount(VOID* pstData, UCHAR* puchInfo);
	INT NopIe802As_NOP(VOID* pstData, UCHAR* puchInfo);

#ifdef __cplusplus
}
#endif

#endif
