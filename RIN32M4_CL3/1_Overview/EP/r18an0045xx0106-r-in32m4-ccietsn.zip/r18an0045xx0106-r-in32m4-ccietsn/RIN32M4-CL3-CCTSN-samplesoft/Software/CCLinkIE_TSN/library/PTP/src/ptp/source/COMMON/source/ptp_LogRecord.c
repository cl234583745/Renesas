/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_LOGRECPRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"

#include "ptp_DynamicLog_API.h"
#include "ptp_LogRecord_GD.h"
#include "ptp_LogRecord.h"


LOGRECORD_GD*	GetLogRecord_GD(CLOCKDATA* 	pstClockData);
VOID	initDynamicLogInf(CLOCKDATA* pstClockData);









VOID	ptp_LogRecordInit(
	CLOCKDATA* 	pstClockData)
{

	if (gstLogRecord_GD.usLogRecordBufMax == 0U)
	{
		gstLogRecord_GD.usLogRecordBufMax	= LOGRECORDBUFMAX;
		gstLogRecord_GD.usLogRecordCount	= 0U;
		gstLogRecord_GD.usLogRecordNum		= 0U;
		initDynamicLogInf(pstClockData);
	}
	return ;

}



VOID	ptp_LogRecordReq(
	CLOCKDATA*	pstClockData,
	USHORT		usLogID,
	USHORT		usLogNameID,
	ULONG		ulLogVal)
{
	LOGRECORD_GD*	pstLRGlb = GetLogRecord_GD(pstClockData);
	USCALEDNS		stCMTime		= {0};
	TIMESTAMP		stLRTimestamp	= {0};
	PTP_LOGRECORD*	pstLogRecordPtr	= NULL;
	PTP_LOGRECORD	stLogRecordForEmerg = {0};
	EN_DYNAMICLOGINFID		enId;
	UCHAR uchDomainNum;
	
	uchDomainNum = 0U;
	if ( pstClockData != NULL )
	{
		uchDomainNum = pstClockData->stDefaultDS.uchDomainNumber;
	}

	if (usLogID == PTP_LOGID_EMERG)
	{
		pstLogRecordPtr = &stLogRecordForEmerg;

		pstLogRecordPtr->usLogLength	= sizeof(PTP_LOGRECORD);
		pstLogRecordPtr->usLogID		= usLogID;
		pstLogRecordPtr->uchDomainNum   = uchDomainNum;
		pstLogRecordPtr->ucReserve      = 0U;
		pstLogRecordPtr->usLogNameID	= usLogNameID;
		pstLogRecordPtr->ulLogVal		= ulLogVal;
		ptp_EmergLogCallBack (pstLogRecordPtr);
		return;
	}

	if (pstClockData != NULL)
	{
		if (usLogID > PTP_LOGID_DEBUG)
		{
			return;
		}
		enId = (EN_DYNAMICLOGINFID)usLogID;

		if (pstLRGlb->stDynamicLogInf[enId].enOperate == LOG_OPERATE_STOP)
		{
			return;
		}
		ptp_GetCurrentMasterTime(pstClockData, &stCMTime);
		(VOID)ptpConvUSNs_TS(&stCMTime, &stLRTimestamp);
	
		pstLogRecordPtr = &(pstLRGlb->stLogRecordBuf[pstLRGlb->usLogRecordCount]);
	
		pstLogRecordPtr->usLogLength	= sizeof(PTP_LOGRECORD);
		pstLogRecordPtr->usLogID		= usLogID;
		pstLogRecordPtr->stLogRcrdTime	= stLRTimestamp;
		pstLogRecordPtr->uchDomainNum   = uchDomainNum;
		pstLogRecordPtr->ucReserve      = 0U;
		pstLogRecordPtr->usLogNameID	= usLogNameID;
		pstLogRecordPtr->ulLogVal		= ulLogVal;

#ifdef	DEBUG_MID_LOGRECPRINT
{
		if (usLogID == PTP_LOGID_EMERG) {
			printf("PTP_LOGID_EMERG   (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_ALERT) {
			printf("PTP_LOGID_ALERT   (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_CRIT) {
			printf("PTP_LOGID_CRIT    (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_ERROR) {
			printf("PTP_LOGID_ERROR   (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_WARNING) {
			printf("PTP_LOGID_WARNING (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_NOTICE) {
			printf("PTP_LOGID_NOTICE  (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_INFO) {
			printf("PTP_LOGID_INFO    (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		} else if (usLogID == PTP_LOGID_DEBUG) {
			printf("PTP_LOGID_DEBUG   (0x%04x) (0x%08x)  %d %d : %d\n", usLogNameID, ulLogVal,
						stLRTimestamp.stSeconds.usSec_msb, stLRTimestamp.stSeconds.ulSec_lsb, stLRTimestamp.ulNanoseconds);
		}
}
#endif


		if (pstLRGlb->stDynamicLogInf[enId].pfnDLCBFunc != NULL)
		{
			pstLRGlb->stDynamicLogInf[enId].pfnDLCBFunc(pstLogRecordPtr);
		}

		pstLRGlb->usLogRecordCount	= pstLRGlb->usLogRecordCount + 1;
		if (pstLRGlb->usLogRecordCount >= pstLRGlb->usLogRecordBufMax)
		{
			pstLRGlb->usLogRecordCount = 0;
		}
	
		if (pstLRGlb->usLogRecordNum < pstLRGlb->usLogRecordBufMax)
		{
			pstLRGlb->usLogRecordNum	= pstLRGlb->usLogRecordNum + 1;
		}
	}
		
}




PTP_LOGRECORD*	ptp_GetLogRecord(
	CLOCKDATA*		pstClockData,
	USHORT*			pusLogRecordNum)
{
	LOGRECORD_GD*	pstLRGlb = GetLogRecord_GD(pstClockData);
	PTP_LOGRECORD*	pstLogRecord = NULL;

	pstLogRecord		= pstLRGlb->stLogRecordBuf;
	*pusLogRecordNum	= pstLRGlb->usLogRecordNum;
	
	return	pstLogRecord;
}




INT	ptp_LRSetLogOperate(
	USHORT		usLogID,
	LOGOPERATE	enOperate)
{
	INT					nRetCode			= RET_ENOERR;
	CLOCKDATA*			pstClockData		= gpstClockDataHPtr;
	EN_DYNAMICLOGINFID	enId				= LR_DLID_EMERG;
	LOGRECORD_GD*		pstLRGlb			= NULL;


	pstLRGlb = GetLogRecord_GD(pstClockData);

	enId = (EN_DYNAMICLOGINFID)usLogID;

	if(pstLRGlb->stDynamicLogInf[enId].enOperate != enOperate)
	{
		pstLRGlb->stDynamicLogInf[enId].enOperate	= enOperate;
	}
	else
	{
		nRetCode = RET_ESTATE;
	}
	
	return nRetCode;
}




INT	ptp_LRSetLogCallBack(
	USHORT		usLogID,
	LOGCB		pfnLogCBFunc)
{
	INT					nRetCode			= RET_ENOERR;
	CLOCKDATA*			pstClockData		= gpstClockDataHPtr;
	EN_DYNAMICLOGINFID	enId				= LR_DLID_EMERG;
	LOGRECORD_GD*		pstLRGlb			= NULL;


	pstLRGlb = GetLogRecord_GD(pstClockData);

	enId = (EN_DYNAMICLOGINFID)usLogID;

	if(pstLRGlb->stDynamicLogInf[enId].pfnDLCBFunc != pfnLogCBFunc)
	{
		pstLRGlb->stDynamicLogInf[enId].pfnDLCBFunc = pfnLogCBFunc;
	}
	else
	{
		nRetCode = RET_ESTATE;
	}

	return nRetCode;
}






LOGRECORD_GD*	GetLogRecord_GD(
	CLOCKDATA* 	pstClockData)
{
	LOGRECORD_GD*	pstLRGlb = &gstLogRecord_GD;

	return pstLRGlb;
}



VOID	initDynamicLogInf(
	CLOCKDATA* 	pstClockData)
{
	USHORT					usLogID;
	EN_DYNAMICLOGINFID		enId;
	LOGRECORD_GD*			pstLRGlb	= NULL;


	pstLRGlb = GetLogRecord_GD(pstClockData);
	
	for (enId = LR_DLID_EMERG;
			enId < LR_DLID_MAX;
			enId = (EN_DYNAMICLOGINFID)((INT)enId + 1))
	{
		usLogID = (USHORT)enId;
		pstLRGlb->stDynamicLogInf[enId].usLogID		= usLogID;
		pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_START;
		pstLRGlb->stDynamicLogInf[enId].pfnDLCBFunc	= NULL;
		
		switch (enId)  
		{
		case	LR_DLID_EMERG:
#ifdef	PTP_LOGID_EMERG_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
		
		case	LR_DLID_ALERT:
#ifdef	PTP_LOGID_ALERT_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
		
		case	LR_DLID_CRIT:
#ifdef	PTP_LOGID_CRIT_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;

		case	LR_DLID_ERROR:
#ifdef	PTP_LOGID_ERROR_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
		
		case	LR_DLID_WARNING:
#ifdef	PTP_LOGID_WARNING_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
			
		case	LR_DLID_NOTICE:
#ifdef	PTP_LOGID_NOTICE_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
			
		case	LR_DLII_INFO:
#ifdef	PTP_LOGID_INFO_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
			
		case	LR_DLID_EDEBUG:
#ifdef	PTP_LOGID_DEBUG_DLOGSTOP
			pstLRGlb->stDynamicLogInf[enId].enOperate	= LOG_OPERATE_STOP;
#endif
			break;
		
		default:
			break;
		}
	}
}



