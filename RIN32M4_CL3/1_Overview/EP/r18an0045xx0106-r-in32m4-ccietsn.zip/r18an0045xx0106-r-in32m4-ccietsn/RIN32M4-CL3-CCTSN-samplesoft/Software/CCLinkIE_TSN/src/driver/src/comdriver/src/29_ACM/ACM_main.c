/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "TOOL_api.h"
#include "ccienx_const.h"
#include "ccienx_api.h"
#include "NGN_ASIC.h"
#include "NMG_common.h"
#include "ACM_api.h"
#include "NMG_common.h"


NX_STATIC NX_VOID vACM_ApplyAuthenticationClass (NX_VOID);

typedef struct tagNX_ACM_CTRL {
	NX_USHORT	usAuthenticationClass;
	NX_USHORT	usRsv;
} NX_ACM_CTRL;

NX_STATIC NX_ACM_CTRL 			gstAuthCtrl;

ACM_CLSA_INFO					gstClassAInfo;

NX_VOID vACM_Init ( NX_VOID )
{	
	vNX_FillMemory16(&gstAuthCtrl, NX_S_ZERO, sizeof(NX_ACM_CTRL) / sizeof(NX_USHORT));
	
	vNX_FillMemory32(&gstClassAInfo, NX_L_ZERO, sizeof(ACM_CLSA_INFO) / sizeof(NX_ULONG));
	
	vACM_ApplyAuthenticationClass();
	
	return;
}

NX_STATIC NX_VOID vACM_ApplyAuthenticationClass ( NX_VOID )
{
	gstAuthCtrl.usAuthenticationClass = gstAppInfo.stAuthInfo.usAuthClass;
	
	return;
}

NX_USHORT usACM_GetAuthenticationClass ( NX_VOID )
{	
	return gstAuthCtrl.usAuthenticationClass;
}
/*[EOF]*/
