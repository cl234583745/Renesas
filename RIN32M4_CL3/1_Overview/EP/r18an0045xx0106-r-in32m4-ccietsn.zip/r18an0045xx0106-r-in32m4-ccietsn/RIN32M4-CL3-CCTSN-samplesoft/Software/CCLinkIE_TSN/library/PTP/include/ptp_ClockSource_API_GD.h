/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CS_API_GD_H__
#define __PTP_CS_API_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




 



 typedef	struct	tagCLKSOURCETIME 
{ 
	UCHAR				uchDomainNumber;
	EXTENDEDTIMESTAMP	stSourceTime;
	USHORT				usTimeBaseIndicator;
	SCALEDNS			stLastGmPhaseChange;
	DOUBLE				dbLastGmFreqChange;
} CLKSOURCETIME; 




typedef		struct	tagCLKSOURCEINFO
{
	UCHAR		uchDomainNumber;
	SHORT		sCurrentUtcOffset;
	BOOL		blLeap61;
	BOOL		blLeap59;
	BOOL		blCurrentUtcOffsetValid;
	BOOL		blPtpTimescale;
	BOOL		blTimeTraceable;
	BOOL		blFrecuencyTraceable;
	UCHAR		uchTimeSource;
} CLKSOURCEINFO;


#endif


