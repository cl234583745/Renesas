/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "MDSyncCommonSM.h"
#include "MDSyncReceiveSM.h"
#include "MDSyncReceiveSM_1588.h"

#include "ptp_PSSReceive_1588.h"

VOID (*const MDSyncReceiveSM_1588_Matrix[DMDSYCR_STATUS_MAX][DMDSYCR_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDSyncReceiveSM_01_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_NP_1588},
	{&MDSyncReceiveSM_01_1588 ,&MDSyncReceiveSM_03_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_00_1588},
	{&MDSyncReceiveSM_02_1588 ,&MDSyncReceiveSM_04_1588 ,&MDSyncReceiveSM_05_1588 ,&MDSyncReceiveSM_06_1588 ,&MDSyncReceiveSM_00_1588},
	{&MDSyncReceiveSM_01_1588 ,&MDSyncReceiveSM_03_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_NP_1588 ,&MDSyncReceiveSM_00_1588}
};

VOID MDSyncReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCRCVSM_EV	enEvt = MDSYCR_E_EVENT_MAX;
	MDSYNCRCVSM_ST	enSts = MDSYCR_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDSyncRcvEvent(usEvent, pstPort);
	enSts = GetMDSyncRcvStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDSyncReceiveSM_1588     ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDSYCR_STATUS_MAX) && (enEvt != MDSYCR_E_EVENT_MAX))
	{
		(*MDSyncReceiveSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDSyncRcvStatus(pstPort);
	printf ("<END  > [%02d]MDSyncReceiveSM_1588     ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDSyncReceiveSM_00_1588(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcvTimeStop(pstGbl, pstPort);
	MDSynRcv_Discard_1588(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_NONE, pstPort);
	return;
}

VOID MDSyncReceiveSM_01_1588(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcv_Discard_1588(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
	return;
}

VOID MDSyncReceiveSM_02_1588(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcvTimeStop(pstGbl, pstPort);
	MDSynRcv_Discard_1588(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
	return;
}

VOID MDSyncReceiveSM_03_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;

	MDSRECEIVESM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);
	if (ConMDSync_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82001108);
		MDSynRcv_Discard_1588(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	if (SetMDSyncEvIngresTimestampSM(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200110B);
		MDSynRcv_Discard_1588(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		tsn_Wrapper_MemSet ((VOID *)&pstPort->stPort_GD.stSyncEventEgressTimestamp, 0, sizeof(TIMESTAMP));
		tsn_Wrapper_MemSet ((VOID *)&pstPort->stPort_GD.stSyncCorrectionField, 0, sizeof(FRAC_NSEC64));

		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080011);
		MDSyncReceiveSM_03_1588_BC(pstGbl, pstPort);
	}

#ifdef	PTP_USE_TRANS
	blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
	blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080012);
		MDSyncReceiveSM_03_1588_TC(pstGbl, pstPort);
	}
#endif

	return;
}

VOID MDSyncReceiveSM_04_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;
	MDSRECEIVESM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);
	if (ConMDSync_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82001108);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1588(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	if (SetMDSyncEvIngresTimestampSM(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200110B);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1588(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		tsn_Wrapper_MemSet ((VOID *)&pstPort->stPort_GD.stSyncEventEgressTimestamp, 0, sizeof(TIMESTAMP));
		tsn_Wrapper_MemSet ((VOID *)&pstPort->stPort_GD.stSyncCorrectionField, 0, sizeof(FRAC_NSEC64));

		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080011);
		MDSyncReceiveSM_04_1588_BC(pstGbl, pstPort);
	}

#ifdef	PTP_USE_TRANS
	blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
	blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080012);
		MDSyncReceiveSM_04_1588_TC(pstGbl, pstPort);
	}
#endif

	return;
}

VOID MDSyncReceiveSM_05_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);
	if (ConMDFollowUp_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82001208);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1588(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080011);
		MDSyncReceiveSM_05_1588_BC(pstGbl, pstPort);
	}

#ifdef	PTP_USE_TRANS
	blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
	blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82080012);
		MDSyncReceiveSM_05_1588_TC(pstGbl, pstPort);
	}
#endif

	return;
}

VOID MDSyncReceiveSM_06_1588(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcv_Discard_1588(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
	return;
}

VOID MDSyncReceiveSM_03_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{

	IncMDSyncRcvRxSyncCount(pstPort);

	if (IsDecMDSyncTwoStep_1588(pstSmGbl->pstRcvdSync))
	{
		MDSynRcv_WtFrFollowUp_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_FOLLOW_UP, pstPort);
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);

		SetMDOneSyncMgEgresTmstmp_1588(pstSmGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstSmGbl, pstPort);

		computeMDSyncRateRatio_1588(pstSmGbl, pstPort);
		MDSynRcv_WtFrSyncOne_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	return;
}

VOID MDSyncReceiveSM_04_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{


	IncMDSyncRcvRxSyncCount(pstPort);

	if (IsDecMDSyncTwoStep_1588(pstSmGbl->pstRcvdSync))
	{
		MDSynRcvTimeStop(pstSmGbl, pstPort);
		MDSynRcv_WtFrFollowUp_1588(pstSmGbl, pstPort);
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);

		SetMDOneSyncMgEgresTmstmp_1588(pstSmGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstSmGbl, pstPort);

		computeMDSyncRateRatio_1588(pstSmGbl, pstPort);
		MDSynRcv_WtFrSyncOne_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	return;
}

VOID MDSyncReceiveSM_05_1588_BC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*			pstPortMD = &pstPort->stPortMD_GD;

	IncMDSyncRcvRxFollowUpCount(pstPort);

	if (pstSmGbl->pstRcvdFollowUp->stFollowUp_1588.stHeader.usSequenceId
		== pstPortMD->stConSync_1588.stHeader.usSequenceId)
	{
		SetMDTwoSyncMgEgresTmstmp_1588(pstSmGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstSmGbl, pstPort);

		computeMDSyncRateRatio_1588(pstSmGbl, pstPort);
		MDSynRcvTimeStop(pstSmGbl, pstPort);
		MDSynRcv_WtFrSyncTwo_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	else
	{
		pstSmGbl->blRcvdFollowUp = FALSE;
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200120B);
	}
	return;
}

#ifdef	PTP_USE_TRANS
VOID MDSyncReceiveSM_03_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{

	IncMDSyncRcvRxSyncCount(pstPort);

	SetMDSyncCorrectionPortIngress(pstSmGbl, pstPort);

	if (IsDecMDSyncTwoStep_1588(pstSmGbl->pstRcvdSync))
	{
		pstSmGbl->blRcvdSync = FALSE;
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_FOLLOW_UP, pstPort);
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);

#ifdef	PTP_USE_ME_HW_ASSIST
		SetMDOneSyncMgEgresTmstmp_1588(pstSmGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstSmGbl, pstPort);

		computeMDSyncRateRatio_1588(pstSmGbl, pstPort);
#endif

		MDSynRcv_WtFrSyncOne_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	return;
}

VOID MDSyncReceiveSM_04_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{

	IncMDSyncRcvRxSyncCount(pstPort);

	SetMDSyncCorrectionPortIngress(pstSmGbl, pstPort);

	if (IsDecMDSyncTwoStep_1588(pstSmGbl->pstRcvdSync))
	{
		pstSmGbl->blRcvdSync = FALSE;
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_FOLLOW_UP, pstPort);
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);
		MDSynRcv_WtFrSyncOne_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	return;
}

VOID MDSyncReceiveSM_05_1588_TC(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*			pstPortMD = &pstPort->stPortMD_GD;

	IncMDSyncRcvRxFollowUpCount(pstPort);

	if (pstSmGbl->pstRcvdFollowUp->stFollowUp_1588.stHeader.usSequenceId
		== pstPortMD->stConSync_1588.stHeader.usSequenceId)
	{

#ifdef	PTP_USE_ME_HW_ASSIST
		SetMDTwoSyncMgEgresTmstmp_1588(pstSmGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstSmGbl, pstPort);

		computeMDSyncRateRatio_1588(pstSmGbl, pstPort);
#endif

		SetMDSyncFollowUpCtPortIngress(pstPort);
		MDSynRcv_WtFrSyncTwo_1588(pstSmGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	else
	{
		pstSmGbl->blRcvdFollowUp = FALSE;
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200120B);
	}
	return;
}
#endif

VOID MDSyncReceiveSM_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDSynRcv_Discard_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;
	pstSmGbl->blRcvdFollowUp = FALSE;
	pstSmGbl->dbCmptRatio = 1.0;
	pstSmGbl->uchMaxStackCount = 0;
	return TRUE;
}

BOOL MDSynRcv_WtFrFollowUp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CHAR	chInterval = 0;


	tsn_Wrapper_MemSet(&pstPort->stPort_GD.stSyncEventEgressTimestamp, 0, sizeof(TIMESTAMP));
	tsn_Wrapper_MemSet(&pstPort->stPort_GD.stSyncCorrectionField, 0, sizeof(FRAC_NSEC64));

	pstSmGbl->blRcvdSync = FALSE;
	chInterval = pstSmGbl->pstRcvdSync->stSync_1588.stHeader.chLogMsgInterVal;
	if (cmptMDSyncFollowUpReceiptTime(pstSmGbl, pstPort, chInterval))
	{
		MDSynRcvTimeStart(pstSmGbl, pstPort);
	}
	return TRUE;
}

BOOL MDSynRcv_WtFrSyncTwo_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;
	pstSmGbl->blRcvdFollowUp = FALSE;

	if (SetMDSyncTwoReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDSyncReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL MDSynRcv_WtFrSyncOne_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;

	if (SetMDSyncOneReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDSyncReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

VOID SetMDTwoSyncMgEgresTmstmp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_FOLLOWUP_1588*	pstMsgSyncFollowUp
		= &pstSmGbl->pstRcvdFollowUp->stFollowUp_1588;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventEgressTimestamp,
		&pstMsgSyncFollowUp->stPrcsOrgnTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortGD->stSyncCorrectionField,
		&pstMsgSyncFollowUp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL ConMDSync_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdSync == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82001109);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdSync == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200110A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConSync_1588,
		&pstSmGbl->pstRcvdSync->stSync_1588, sizeof(pstPortMD->stConSync_1588));
	return TRUE;
}

BOOL ConMDFollowUp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdFollowUp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_82001209);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdFollowUp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_8200120A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConFollowUp_1588,
		&pstSmGbl->pstRcvdFollowUp->stFollowUp_1588, sizeof(pstPortMD->stConFollowUp_1588));
	return TRUE;
}

VOID SetMDOneSyncMgEgresTmstmp_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_SYNC_1588*	pstMsgSync
		= &pstSmGbl->pstRcvdSync->stSync_1588;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventEgressTimestamp,
		&pstMsgSync->stOriginTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortGD->stSyncCorrectionField,
		&pstMsgSync->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

VOID computeMDSyncRateRatio_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	DOUBLE	dbRatio = 1.0;
	BOOL	blRet	= FALSE;

	if (pstSmGbl->uchMaxStackCount == 0)
	{
		pstSmGbl->uchStackCount = 0;
		pstSmGbl->uchCompareCount = 0;

		SetCmptMDSyncRatioStack_1588(pstSmGbl, pstPort);

		pstSmGbl->uchMaxStackCount += 1;
	}
	else if (pstSmGbl->uchMaxStackCount <= pstPort->pstClockData->stClock_GD.uchRateCalDatNum - 1)
	{
		pstSmGbl->uchStackCount += 1;
		pstSmGbl->uchCompareCount = 0;

		SetCmptMDSyncRatioStack_1588(pstSmGbl, pstPort);

		pstSmGbl->uchMaxStackCount += 1;
		blRet = CalMDSyncRateRatio_1588(pstSmGbl, pstPort, &dbRatio);
	}
	else
	{
		pstSmGbl->uchStackCount = pstSmGbl->uchCompareCount;

		SetCmptMDSyncRatioStack_1588(pstSmGbl, pstPort);

		if (pstSmGbl->uchCompareCount >= pstPort->pstClockData->stClock_GD.uchRateCalDatNum - 1)
		{
			pstSmGbl->uchCompareCount = 0;
		}
		else
		{
			pstSmGbl->uchCompareCount += 1;
		}
		blRet = CalMDSyncRateRatio_1588(pstSmGbl, pstPort, &dbRatio);
	}
	if (blRet)
	{
		if ((dbRatio > DBCONST_RATE_MIN) &&
			(dbRatio < DBCONST_RATE_MAX))
		{

			pstSmGbl->dbCmptRatio = dbRatio;
			pstPort->stPort_GD.dbNeighborRateRatio = dbRatio;

		}
	}
	return;
}


VOID SetCmptMDSyncRatioStack_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	EXTENDEDTIMESTAMP	stA_ETInt;
#ifndef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stIngTimestamp	= pstPort->stPort_GD.stSyncEventIngressTimestamp;
#else
	TIMESTAMP			stIngTimestamp	= pstPort->stPort_GD.stSyncEventIngressTimestamp_Frun;
#endif

	TIMESTAMP		stCrrectTimestamp;
	TIME_INTERVAL	stCrrectCField;

	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(&pstPort->stPortMD_GD.stConSync_1588.stHeader) )
	{
		stCrrectTimestamp	= pstPort->stPortMD_GD.stConFollowUp_1588.stPrcsOrgnTimestamp;
		stCrrectCField	= pstPort->stPortMD_GD.stConFollowUp_1588.stHeader.stCorrectionField;
	}
	else
	{
		stCrrectTimestamp	= pstPort->stPortMD_GD.stConSync_1588.stOriginTimestamp;
		stCrrectCField	= pstPort->stPortMD_GD.stConSync_1588.stHeader.stCorrectionField;
	}
	ptpConvTS_USNs(&stIngTimestamp,
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchStackCount].stIngressTimestamp);
	{
		BOOL	blRet;

		blRet = ptpAddTS_TInt(&stCrrectTimestamp, &stCrrectCField, &stA_ETInt);
		if(blRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1588, PTP_LOGVE_OVERFLOW);
		}
	}
	ptpConvETS_USNs(
		&stA_ETInt,
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchStackCount].stCrrctEvTimestamp);

	return;
}

BOOL CalMDSyncRateRatio_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort, DOUBLE* pdbRateRatio)
{
	SCALEDNS			stCorrected_SNs	={0};
	SCALEDNS			stSyncEvent_SNs	={0};
	BOOL				blRet = FALSE;

	ptpSubUSNs_USNs(
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchStackCount].stIngressTimestamp,
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchCompareCount].stIngressTimestamp,
		&stSyncEvent_SNs);

	ptpSubUSNs_USNs(
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchStackCount].stCrrctEvTimestamp,
		&pstSmGbl->stCmptMDSyncRatioStack[pstSmGbl->uchCompareCount].stCrrctEvTimestamp,
		&stCorrected_SNs);

	blRet = ptpDivSNs_SNs(&stSyncEvent_SNs, &stCorrected_SNs, pdbRateRatio);

	return blRet;
}

BOOL SetMDSyncTwoReceive_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCRECEIVE*				pstSyncRcv = &pstPort->stPort_GD.stMdSyncReceive;
	PTPMSG_SYNC_1588*			pstMsgSync = &pstPort->stPortMD_GD.stConSync_1588;
	PTPMSG_FOLLOWUP_1588*		pstMsgFollow = &pstPort->stPortMD_GD.stConFollowUp_1588;

	pstSyncRcv->uchClockNumber = pstMsgSync->stHeader.uchDomainNumber;
	ptpAddTInt_TInt((TIME_INTERVAL*)&pstMsgSync->stHeader.stCorrectionField,
					(TIME_INTERVAL*)&pstMsgFollow->stHeader.stCorrectionField,
					&pstSyncRcv->stFollowUpCorrectionField);

	pstSyncRcv->stSourcePortIdentity		= pstMsgSync->stHeader.stSrcPortIdentity;
	pstSyncRcv->chLogMessageInterval		= pstMsgSync->stHeader.chLogMsgInterVal;
	pstSyncRcv->stPreciseOriginTimestamp	= pstMsgFollow->stPrcsOrgnTimestamp;

	pstSyncRcv->dbRateRatio = pstSmGbl->dbCmptRatio;

	return TRUE;
}

BOOL SetMDSyncOneReceive_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCRECEIVE*		pstSyncRcv = &pstPort->stPort_GD.stMdSyncReceive;
	PTPMSG_SYNC_1588*	pstMsgSync = &pstPort->stPortMD_GD.stConSync_1588;
	TIME_INTERVAL		stA_TInt= {0};

	pstSyncRcv->uchClockNumber = pstMsgSync->stHeader.uchDomainNumber;

	ptpAddTInt_TInt((TIME_INTERVAL*)&pstMsgSync->stHeader.stCorrectionField, &stA_TInt,
				&pstSyncRcv->stFollowUpCorrectionField);

	pstSyncRcv->stSourcePortIdentity		= pstMsgSync->stHeader.stSrcPortIdentity;
	pstSyncRcv->chLogMessageInterval		= pstMsgSync->stHeader.chLogMsgInterVal;
	pstSyncRcv->stPreciseOriginTimestamp	= pstMsgSync->stOriginTimestamp;

	pstSyncRcv->dbRateRatio = pstSmGbl->dbCmptRatio;

	return TRUE;
}

BOOL TxMDSyncReceive_1588(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PSSRECEIVESM_1588_GD*	pstPSSRcvSM_GD = &pstPort->stUn_PSM_GD.stPsm1588_GD.stPSSReceiveSM_1588_GD;

	pstPSSRcvSM_GD->blRcvdMDSync = TRUE;

	portSyncSyncReceive_1588(PTP_EV_FOR_PSYNSYNRV_RCVMDSYNC, pstPort);

	return	TRUE;
}

#endif
