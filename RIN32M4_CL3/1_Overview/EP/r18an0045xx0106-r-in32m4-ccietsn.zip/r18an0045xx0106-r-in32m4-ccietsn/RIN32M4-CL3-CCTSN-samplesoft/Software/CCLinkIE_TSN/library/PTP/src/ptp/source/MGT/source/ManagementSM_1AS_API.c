/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "PTP_GlobalData.h"

#include "ManagementSM.h"
#include "ManagementSM_1AS.h"

#include "PortStateSelectionSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "MDPdelayReq.h"


#ifndef	PTP_RESTRICT_GETSET
#define MGT_ACT_SEL_TBLSIZE		78
#else
#define MGT_ACT_SEL_TBLSIZE		2
#endif

static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData );
static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData );



static
const MGT_ACT_SEL_TBL_1AS	stMgt_Action[MGT_ACT_SEL_TBLSIZE] =
{
#ifndef	PTP_RESTRICT_GETSET
	{"ieee802AsDefaultDSClockIdentity",						MID_DEFAULTDS_CLOCKIDENTITIY,		MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSClockIdentity,		&NopIe802As_NOP},					sizeof(CLOCKIDENTITY)},
	{"ieee802AsDefaultDSNumberPorts",						MID_DEFAULTDS_NUMBERPORTS,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSNumberPorts,			&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsDefaultDSClockClass",						MID_DEFAULTDS_CLOCKCLASS,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSClockClass,			&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsDefaultDSClockAccuracy",						MID_DEFAULTDS_CLOCKACCURACY,		MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSClockAccuracy,		&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsDefaultDSOffsetScaledLogVariance",			MID_DEFAULTDS_OFSSCALEDLOGVAR,		MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSOfsScaledLogVar,		&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsDefaultDSPriority1",							MID_DEFAULTDS_PRIORITY1,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSPriority1,			&SetIe802AsDfltDSPriority1},		sizeof(UCHAR)},
	{"ieee802AsDefaultDSPriority2",							MID_DEFAULTDS_PRIORITY2,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSPriority2,			&SetIe802AsDfltDSPriority2},		sizeof(UCHAR)},
	{"ieee802AsDefaultDSGmCapable",							MID_DEFAULTDS_GMCAPABLE,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSGmCapable,			&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsDefaultDSCurrentUtcOffset",					MID_DEFAULTDS_CURUTCOFS,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSCrntUtcOfs,			&NopIe802As_NOP},					sizeof(SHORT)},
	{"ieee802AsDefaultDSCurrentUtcOffsetValid",				MID_DEFAULTDS_CURUTCOfSVAL,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSCrntUtcOfsVal,		&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsDefaultDSLeap59",							MID_DEFAULTDS_LEAP59,				MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSLeap59,				&SetIe802AsDfltDSLeap59},			sizeof(INT)},
	{"ieee802AsDefaultDSLeap61",							MID_DEFAULTDS_LEAP61,				MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSLeap61,				&SetIe802AsDfltDSLeap61},			sizeof(INT)},
	{"ieee802AsDefaultDSTimeTraceable",						MID_DEFAULTDS_TIMETRACABLE,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSTmTraceable,			&SetIe802AsDfltDSTmTraceable},		sizeof(INT)},
	{"ieee802AsDefaultDSFrequencyTraceable",				MID_DEFAULTDS_FREQTRACEABLE,		MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSFrqTraceable,			&SetIe802AsDfltDSFrqTraceable},		sizeof(INT)},
	{"ieee802AsDefaultDSTimeSource",						MID_DEFAULTDS_TIMESOURCE,			MID_APPLIES_CLOCK,	{&GetIe802AsDfltDSTmSource,				&NopIe802As_NOP},					sizeof(UCHAR)},
#endif
	{"ieee802AsCurrentDSStepsRemoved",						MID_CURRENTDS_STEPSREMOVED,			MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSStepsRemoved,			&NopIe802As_NOP},					sizeof(USHORT)},
#ifndef	PTP_RESTRICT_GETSET
	{"ieee802AsCurrentDSOffsetFromMaster",					MID_CURRENTDS_OFSFROMMASTER,		MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSOfsFromMaster,		&NopIe802As_NOP},					sizeof(TIME_INTERVAL)},
	{"ieee802AsCurrentDSLastGmPhaseChange",					MID_CURRENTDS_LASTGMPHASECHG,		MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSLastGmPhsChg,			&NopIe802As_NOP},					sizeof(SCALEDNS)},
	{"ieee802AsCurrentDSLastGmFreqChange",					MID_CURRENTDS_LASTGMFREQCHG,		MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSLastGmFrqChg,			&NopIe802As_NOP},					sizeof(DOUBLE)},
	{"ieee802AsCurrentDSGmTimebaseIndicator",				MID_CURRENTDS_LASTGMTIMBSIND,		MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSGmTmbaseIndctr,		&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsCurrentDSGmChangeCount",						MID_CURRENTDS_LASTGMCHGCNT,			MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSGmChgCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsCurrentDSTimeOfLastGmChangeEvent",			MID_CURRENTDS_TIMOFLASTGMCHGEVT,	MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSTmOfLsGmCgEv,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsCurrentDSTimeOfLastGmPhaseChangeEvent",		MID_CURRENTDS_TIMOFLSTGMPHCHGEVT,	MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSTmOfLsGmPhsCgEv	,	&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsCurrentDSTimeOfLastGmFreqChangeEvent",		MID_CURRENTDS_TIMOFLSTGMFRCHGEVT,	MID_APPLIES_CLOCK,	{&GetIe802AsCrntDSTmOfLsGmFrqCgEv,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsParentDSParentClockIdentity",				MID_PARENTDS_PARENTCLKID,			MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSPrntClkIdentity,		&NopIe802As_NOP},					sizeof(CLOCKIDENTITY)},
	{"ieee802AsParentDSParentPortNumber",					MID_PARENTDS_PARENTPORTNUMBER,		MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSPrntPortNumber,		&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsParentDSCumulativeRateRatio",				MID_PARENTDS_CUMULRATERATIO,		MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSCumltvRateRatio,		&NopIe802As_NOP},					sizeof(ULONG)},
#endif
	{"ieee802AsParentDSGrandmasterIdentity",				MID_PARENTDS_GRANDMASTERID,			MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMIdentity,			&NopIe802As_NOP},					sizeof(CLOCKIDENTITY)},
#ifndef	PTP_RESTRICT_GETSET
	{"ieee802AsParentDSGrandmasterClockClass",				MID_PARENTDS_GRANDMASTERCLKCLS,		MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMClockClass,			&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsParentDSGrandmasterClockAccuracy",			MID_PARENTDS_GRANDMASTERCLKACC,		MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMClockAccuracy,		&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsParentDSGrandmasterOffsetScaledLogVariance",	MID_PARENTDS_GMCOFSSCALLOGVAR,		MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMOfsScldLogVar,		&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsParentDSGrandmasterPriority1",				MID_PARENTDS_GMPRIORITY1,			MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMPriority1,			&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsParentDSGrandmasterPriority2",				MID_PARENTDS_GMPRIORITY2,			MID_APPLIES_CLOCK,	{&GetIe802AsPrntDSGMPriority2,			&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsTimePropertiesDSCurrentUTCOffset",			MID_TIMPROPDS_CURUTCOFS,			MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSCrntUTCOfs,			&NopIe802As_NOP},					sizeof(SHORT)},
	{"ieee802AsTimePropertiesDSCurrentUTCOffsetValid",		MID_TIMPROPDS_CURUTCOfSVAL,			MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSCrntUTCOfsVal,		&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsTimePropertiesDSLeap59",						MID_TIMPROPDS_LEAP59,				MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSLeap59,				&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsTimePropertiesDSLeap61",						MID_TIMPROPDS_LEAP61,				MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSLeap61,				&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsTimePropertiesDSTimeTraceable",				MID_TIMPROPDS_TIMETRACABLE,			MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSTmTraceable,		&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsTimePropertiesDSFrequencyTraceable",			MID_TIMPROPDS_FREQTRACEABLE,		MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSFrqTraceable,		&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsTimePropertiesDSTimeSource",					MID_TIMPROPDS_TIMESOURCE,			MID_APPLIES_CLOCK,	{&GetIe802AsTmPropDSTmSource,			&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsPortDSClockIdentity",						MID_PORTDS_CLOCKIDENTITIY,			MID_APPLIES_PORT,	{&GetIe802AsPortDSClockIdentity,		&NopIe802As_NOP},					sizeof(CLOCKIDENTITY)},
	{"ieee802AsPortDSPortNumber",							MID_PORTDS_PORTNUMBER,				MID_APPLIES_PORT,	{&GetIe802AsPortDSPortNumber,			&NopIe802As_NOP},					sizeof(USHORT)},
	{"ieee802AsPortDSPortState",							MID_PORTDS_PORTSTAT,				MID_APPLIES_PORT,	{&GetIe802AsPortDSPortState,			&SetIe802AsPortDSPortState},		sizeof(PORTSTATE)},
	{"ieee802AsPortDSPtpPortEnabled",						MID_PORTDS_PTPPORTENABLE,			MID_APPLIES_PORT,	{&GetIe802AsPortDSPtpPortEnabled,		&SetIe802AsPortDSPtpPortEnabled},	sizeof(INT)},
	{"ieee802AsPortDSIsMeasuringDdelay",					MID_PORTDS_ISMEASUREDDELAY,			MID_APPLIES_PORT,	{&GetIe802AsPortDSIsMeasuringDDly,		&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsPortDSAsCapable",							MID_PORTDS_ASCAPABLE,				MID_APPLIES_PORT,	{&GetIe802AsPortDSAsCapable,			&NopIe802As_NOP},					sizeof(INT)},
	{"ieee802AsPortDSNeighborPropDelay",					MID_PORTDS_NEIGHBORPROPDLY,			MID_APPLIES_PORT,	{&GetIe802AsPortDSNeighborPropDly,		&NopIe802As_NOP},					sizeof(USCALEDNS)},
	{"ieee802AsPortDSNeighborPropDelayThresh",				MID_PORTDS_NEIGHBORPROPDLYTHR,		MID_APPLIES_PORT,	{&GetIe802AsPortDSNeighbrPpDlyThr,		&SetIe802AsPortDSNeighbrPpDlyThr},	sizeof(USCALEDNS)},
	{"ieee802AsPortDSDelayAsymmetry",						MID_PORTDS_DELAYASYMMETRY,			MID_APPLIES_PORT,	{&GetIe802AsPortDSDlyAsymmetry,			&SetIe802AsPortDSDlyAsymmetry},		sizeof(USCALEDNS)},
	{"ieee802AsPortDSNeighborRateRatio",					MID_PORTDS_NEIGHBORRATERATIO,		MID_APPLIES_PORT,	{&GetIe802AsPortDSNeghbrRateRatio,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsPortDSInitialLogAnnounceInterval",			MID_PORTDS_INITLOGANNOINTVAL,		MID_APPLIES_PORT,	{&GetIe802AsPortDSInitLogAnncIntv,		&SetIe802AsPortDSInitLogAnncIntv},	sizeof(CHAR)},
	{"ieee802AsPortDSCurrentLogAnnounceInterval",			MID_PORTDS_CURLOGANNOINTVAL,		MID_APPLIES_PORT,	{&GetIe802AsPortDSCrntLogAnncIntv,		&NopIe802As_NOP},					sizeof(CHAR)},
	{"ieee802AsPortDSAnnounceReceiptTimeout",				MID_PORTDS_ANNORECPTIMEOUT,			MID_APPLIES_PORT,	{&GetIe802AsPortDSAnnoceRecptTout,		&SetIe802AsPortDSAnnoceRecptTout},	sizeof(UCHAR)},
	{"ieee802AsPortDSInitialLogSyncInterval",				MID_PORTDS_INITLOGSYNCINTVAL,		MID_APPLIES_PORT,	{&GetIe802AsPortDSInitLogSyncIntv,		&SetIe802AsPortDSInitLogSyncIntv},	sizeof(CHAR)},
	{"ieee802AsPortDSCurrentLogSyncInterval",				MID_PORTDS_CURLOGSYNCINTVAL,		MID_APPLIES_PORT,	{&GetIe802AsPortDSCrntLogSyncIntv,		&NopIe802As_NOP},					sizeof(CHAR)},
	{"ieee802AsPortDSSyncReceiptTimeout",					MID_PORTDS_SYNCRECPTIMEOUT,			MID_APPLIES_PORT,	{&GetIe802AsPortDSSyncRecptTout,		&SetIe802AsPortDSSyncRecptTout},	sizeof(UCHAR)},
	{"ieee802AsPortDSSyncReceiptTimeoutTimeInterval",		MID_PORTDS_SYNCRECPTIMOUTTIMINT,	MID_APPLIES_PORT,	{&GetIe802AsPortDSSyncRecptTOTMIv,		&NopIe802As_NOP},					sizeof(USCALEDNS)},
	{"ieee802AsPortDSInitialLogPdelayReqInterval",			MID_PORTDS_INITLOGPDLAYREQINT,		MID_APPLIES_PORT,	{&GetIe802AsPortDSInitLogPDRqIntv,		&SetIe802AsPortDSInitLogPDRqIntv},	sizeof(CHAR)},
	{"ieee802AsPortDSCurrentLogPdelayReqInterval",			MID_PORTDS_CRNTLOGPDLAYREQINT,		MID_APPLIES_PORT,	{&GetIe802AsPortDSCrntLogPDRqIntv,		&NopIe802As_NOP},					sizeof(CHAR)},
	{"ieee802AsPortDSAllowedLostResponses",					MID_PORTDS_ALLOWLOSTRESP,			MID_APPLIES_PORT,	{&GetIe802AsPortDSAllowedLostResp,		&SetIe802AsPortDSAllowedLostResp},	sizeof(USHORT)},
	{"ieee802AsPortDSVersionNumber",						MID_PORTDS_VERSIONNUMBER,			MID_APPLIES_PORT,	{&GetIe802AsPortDSVersionNumber,		&NopIe802As_NOP},					sizeof(UCHAR)},
	{"ieee802AsRxSyncCount",								MID_RXSYNCCOUNT,					MID_APPLIES_PORT,	{&GetIe802AsRxSyncCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxFollowUpCount",							MID_RXFOLLOWUPCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsRxFollowUpCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxPdelayRequestCount",						MID_RXPDELAYREQCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsRxPDlyReqCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxPdelayResponseCount",						MID_RXPDELAYRESPCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsRxPDlyRespCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxPdelayResponseFollowUpCount",				MID_RXPDELAYRESPFOLLOWUPCOUNT,		MID_APPLIES_PORT,	{&GetIe802AsRxPDlyRespFllwUpCount,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxAnnounceCount",							MID_RXANNOUNCECOUNT,				MID_APPLIES_PORT,	{&GetIe802AsRxAnnoceCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsRxPTPPacketDiscardCount",					MID_RXPTPPACKETDISCARDCOUNT,		MID_APPLIES_PORT,	{&GetIe802AsRxPTPPacketDscrdCount,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsSyncReceiptTimeoutCount",					MID_SYNCRECPTIMOUTCOUNT,			MID_APPLIES_PORT,	{&GetIe802AsSyncRecptToutCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsAnnounceReceiptTimeoutCount",				MID_ANNOUNCERECPTIMOUTCOUNT,		MID_APPLIES_PORT,	{&GetIe802AsAnnoceRecptToutCount,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsPdelayAllowedLostResponsesExceededCount",	MID_PDELAYALLOWLOSTRESPEXCDCNT,		MID_APPLIES_PORT,	{&GetIe802AsPDlyAllwLstRpExcCount,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxSyncCount",								MID_TXSYNCCOUNT,					MID_APPLIES_PORT,	{&GetIe802AsTxSyncCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxFollowUpCount",							MID_TXFOLLOWUPCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsTxFollowUpCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxPdelayRequestCount",						MID_TXPDELAYREQCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsTxPDlyReqCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxPdelayResponseCount",						MID_TXPDELAYRESPCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsTxPDlyRespCount,			&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxPdelayResponseFollowUpCount",				MID_TXPDELAYRESPFOLLOWUPCOUNT,		MID_APPLIES_PORT,	{&GetIe802AsTxPDlyRespFllwUpCount,		&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxAnnounceCount",							MID_TXANNOUNCECOUNT,				MID_APPLIES_PORT,	{&GetIe802AsTxAnnoceCount,				&NopIe802As_NOP},					sizeof(ULONG)},
	{"ieee802AsTxMessageErrorCount",						MID_TXMESSAGEERRCOUNT,				MID_APPLIES_PORT,	{&GetIe802AsTxAnnoceCount,				&NopIe802As_NOP},					sizeof(ULONG)}
#endif
};



static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData )
{
	CMLDSPORT_1AS_DS *pstCmldsPortDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPort_1AS_DS;

	return pstCmldsPortDS;
}

static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData )
{
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatisticsDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortStatisticsDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPortStatistics_1AS_DS;

	return pstCmldsPortStatisticsDS;
}



INT ManagementSM_1AS_API(UCHAR uchAction, USHORT usParamId_AS, CLOCKDATA* pstClockData, PORTDATA* pstPortData, UCHAR* puchInfo)
{
	INT		nRet	= RET_ENOERR;

	if (stMgt_Action[usParamId_AS].enTypeApplies == MID_APPLIES_CLOCK)
	{
		nRet = (*stMgt_Action[usParamId_AS].pfnFunc[uchAction])((VOID*)pstClockData, puchInfo);
	}
	else if ((stMgt_Action[usParamId_AS].enTypeApplies == MID_APPLIES_PORT)
			 && (pstPortData != NULL))
	{
		nRet = (*stMgt_Action[usParamId_AS].pfnFunc[uchAction])((VOID*)pstPortData, puchInfo);
	}
	else
	{
		nRet = RET_EINVAL;
	}
#if 1
	if((nRet == RET_SAMEVAL) && (uchAction == MGTAS_ACTION_SET))
	{
		nRet = RET_ENOERR;
	}
	else if ((nRet == RET_ENOERR) && (uchAction == MGTAS_ACTION_SET))
	{
		if (!IS_PTP_OPEN())
		{
			return nRet;
		}
		switch(usParamId_AS)
		{
		case MID_DEFAULTDS_PRIORITY1:
		case MID_DEFAULTDS_PRIORITY2:
			{
				portStateSelectionSM(PTP_EV_SYSTEMIDENTITYCHANGE, pstClockData->pstPortData);
			}
			break;

		case MID_PORTDS_PTPPORTENABLE:
			if (pstPortData->stPort_1AS_DS.blPtpPortEnabled == FALSE)
			{
#ifdef	PTP_USE_BMCA
				if ( pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
				{
					portAnnounceInformationSM( PTP_EV_CLOSE, pstPortData );

					pstPortData->stPortBMC_GD.enInfoIs = DISABLED;
					pstPortData->pstClockData->stBMC_GD.blReselect[pstPortData->stPortDS.stPortIdentity.usPortNumber] = TRUE;
					pstPortData->pstClockData->stBMC_GD.blSelected[pstPortData->stPortDS.stPortIdentity.usPortNumber] = FALSE;
					portStateSelectionSM(PTP_EV_RESELECT_PORT, pstPortData);

					exec_PortAnnInfo04_allPort(pstPortData);
				}
				else
#endif
				{
					portAnnounceInformationExtSM( PTP_EV_CLOSE, pstPortData );
				}
			}
			else
			{


#ifdef	PTP_USE_BMCA
				if ( pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
				{
					portAnnounceInformationSM( PTP_EV_BEGIN, pstPortData );
				}
				else
#endif
				{
					portAnnounceInformationExtSM( PTP_EV_BEGIN, pstPortData );
				}
			}
			break;

		case MID_PORTDS_PORTSTAT:
			if (pstPortData->pstClockData->stBMC_GD.blExternalPortConfiguration)
			{
				updtPortState(pstPortData);
			}
			break;

		default:
			break;
		}
	}
#endif
	return nRet;
}

BOOL GetManagementASParamId(USHORT usParamId_AS, USHORT* pusTblIndex, USHORT* pusSize)
{
	USHORT	usIndex;
	BOOL	blRet = FALSE;

	for (usIndex = 0; usIndex < MGT_ACT_SEL_TBLSIZE; usIndex++)
	{
		if (stMgt_Action[usIndex].usManagementId == usParamId_AS)
		{
			blRet = TRUE;
			break;
		}
	}
	if (blRet)
	{
		*pusTblIndex = usIndex;
		*pusSize = stMgt_Action[usIndex].usMoldTypeSize;
	}
	return blRet;
}

#ifndef	PTP_RESTRICT_GETSET
INT GetIe802AsDfltDSClockIdentity(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	CLOCKIDENTITY*	pstInfo			= (CLOCKIDENTITY*)puchInfo;

	DEFAULT_DS*	pstClockDS = &pstClockData->stDefaultDS;

	*pstInfo = pstClockDS->stClockIdentity;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSNumberPorts(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*pusInfo = pstClockDS->usNumberPorts;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSClockClass(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*puchInfo2 = pstClockDS->stClockQuality.uchClockClass;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSClockAccuracy(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*puchInfo2 = pstClockDS->stClockQuality.uchClockAccuracy;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSOfsScaledLogVar(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*pusInfo = pstClockDS->stClockQuality.usOffsetScaledLogVariance;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSPriority1(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*puchInfo2 = pstClockDS->uchPriority1;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSPriority1(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;
	UCHAR		oldPriority1;
	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	oldPriority1 = pstClockDS->uchPriority1;
	pstClockDS->uchPriority1 = *puchInfo2;
#if 1
	if (oldPriority1 == pstClockDS->uchPriority1)
	{
		return RET_SAMEVAL;
	}
#endif
	return RET_ENOERR;
}

INT GetIe802AsDfltDSPriority2(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	*puchInfo2 = pstClockDS->uchPriority2;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSPriority2(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;
	UCHAR		oldPriority2;
	DEFAULT_DS* pstClockDS = &pstClockData->stDefaultDS;

	oldPriority2 = pstClockDS->uchPriority2;
	pstClockDS->uchPriority2 = *puchInfo2;

#if 1
	if (oldPriority2 == pstClockDS->uchPriority2)
	{
		return RET_SAMEVAL;
	}
#endif
	return RET_ENOERR;
}

INT GetIe802AsDfltDSGmCapable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blGmCapable;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSCrntUtcOfs(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	SHORT*		psInfo			= (SHORT*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*psInfo = pstClockDS->sCurrentUtcOffset;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSCrntUtcOfsVal(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blCurrentUtcOffsetValid;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSLeap59(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blLeap59;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSLeap59(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	pstClockDS->blLeap59 = *pblInfo;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSLeap61(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blLeap61;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSLeap61(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	pstClockDS->blLeap61 = *pblInfo;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSTmTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blTimeTraceable;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSTmTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	pstClockDS->blTimeTraceable = *pblInfo;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSFrqTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*pblInfo = pstClockDS->blFrequencyTraceable;

	return RET_ENOERR;
}

INT SetIe802AsDfltDSFrqTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	pstClockDS->blFrequencyTraceable = *pblInfo;

	return RET_ENOERR;
}

INT GetIe802AsDfltDSTmSource(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	DEFAULT_1AS_DS* pstClockDS = &pstClockData->stDefault_1AS_DS;

	*puchInfo2 = pstClockDS->uchTimeSource;

	return RET_ENOERR;
}

#endif
INT GetIe802AsCrntDSStepsRemoved(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	CURRENT_DS* pstClockDS = &pstClockData->stCurrentDS;

	*pusInfo = pstClockDS->usStepsRemoved;

	return RET_ENOERR;
}

#ifndef	PTP_RESTRICT_GETSET
INT GetIe802AsCrntDSOfsFromMaster(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	TIME_INTERVAL*	pstInfo			= (TIME_INTERVAL*)puchInfo;

	CURRENT_DS* pstClockDS = &pstClockData->stCurrentDS;

	*pstInfo = pstClockDS->stOffsetFromMaster;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSLastGmPhsChg(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	SCALEDNS*	pstInfo			= (SCALEDNS*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pstInfo = pstClockDS->stLastGmPhaseChange;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSLastGmFrqChg(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	DOUBLE*		pdbInfo			= (DOUBLE*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pdbInfo = pstClockDS->dbLastGmFreqChange;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSGmTmbaseIndctr(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pusInfo = pstClockDS->usGmTimebaseIndicator;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSGmChgCount(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	ULONG*		pulInfo			= (ULONG*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pulInfo = pstClockDS->ulGmChangeCount;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSTmOfLsGmCgEv(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	ULONG*		pulInfo			= (ULONG*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pulInfo = pstClockDS->ulTimeOfLastGmChangeEvent;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSTmOfLsGmPhsCgEv(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	ULONG*		pulInfo			= (ULONG*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pulInfo = pstClockDS->ulTimeOfLastGmPhaseChangeEvent;

	return RET_ENOERR;
}

INT GetIe802AsCrntDSTmOfLsGmFrqCgEv(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	ULONG*		pulInfo			= (ULONG*)puchInfo;

	CURRENT_1AS_DS* pstClockDS = &pstClockData->stCurrent_1AS_DS;

	*pulInfo = pstClockDS->ulTimeOfLastGmFreqChangeEvent;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSPrntClkIdentity(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	CLOCKIDENTITY*	pstInfo			= (CLOCKIDENTITY*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*pstInfo = pstClockDS->stParentPortIdentity.stClockIdentity;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSPrntPortNumber(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*pusInfo = pstClockDS->stParentPortIdentity.usPortNumber;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSCumltvRateRatio(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	LONG*		plInfo			= (LONG*)puchInfo;

	PARENT_1AS_DS* pstClockDS = &pstClockData->stParent_1AS_DS;

	*plInfo = pstClockDS->lCumulativeRateRatio;

	return RET_ENOERR;
}

#endif
INT GetIe802AsPrntDSGMIdentity(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	CLOCKIDENTITY*	pstInfo			= (CLOCKIDENTITY*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*pstInfo = pstClockDS->stGrandmasterIdentity;

	return RET_ENOERR;
}

#ifndef	PTP_RESTRICT_GETSET
INT GetIe802AsPrntDSGMClockClass(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*puchInfo2 = pstClockDS->stGrandmasterClockQuality.uchClockClass;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSGMClockAccuracy(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*puchInfo2 = pstClockDS->stGrandmasterClockQuality.uchClockAccuracy;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSGMOfsScldLogVar(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	USHORT*		pusInfo			= (USHORT*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*pusInfo = pstClockDS->stGrandmasterClockQuality.usOffsetScaledLogVariance;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSGMPriority1(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*puchInfo2 = pstClockDS->uchGrandmasterPriority1;

	return RET_ENOERR;
}

INT GetIe802AsPrntDSGMPriority2(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	PARENT_DS* pstClockDS = &pstClockData->stParentDS;

	*puchInfo2 = pstClockDS->uchGrandmasterPriority2;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSCrntUTCOfs(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	SHORT*		psInfo			= (SHORT*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*psInfo = pstClockDS->sCurrentUtcOffset;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSCrntUTCOfsVal(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*pblInfo = pstClockDS->blCurrentUtcOffsetValid;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSLeap59(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*pblInfo = pstClockDS->blLeap59;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSLeap61(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*pblInfo = pstClockDS->blLeap61;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSTmTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*pblInfo = pstClockDS->blTimeTraceable;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSFrqTraceable(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	BOOL*		pblInfo			= (BOOL*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*pblInfo = pstClockDS->blFrequencyTraceable;

	return RET_ENOERR;
}

INT GetIe802AsTmPropDSTmSource(VOID* pvData, UCHAR* puchInfo)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	UCHAR*		puchInfo2			= (UCHAR*)puchInfo;

	TIMEPROPERTIES_DS* pstClockDS = &pstClockData->stTimePropertiesDS;

	*puchInfo2 = pstClockDS->uchTimeSource;

	return RET_ENOERR;
}


INT GetIe802AsPortDSClockIdentity(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*		pstPortData = (PORTDATA*)pvData;
	CLOCKIDENTITY*	pstInfo		= (CLOCKIDENTITY*)puchInfo;

	PORT_DS* pstPortDS = &pstPortData->stPortDS;

	*pstInfo = pstPortDS->stPortIdentity.stClockIdentity;

	return RET_ENOERR;
}

INT GetIe802AsPortDSPortNumber(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	USHORT*		pusInfo		= (USHORT*)puchInfo;

	PORT_DS* pstPortDS = &pstPortData->stPortDS;

	*pusInfo = pstPortDS->stPortIdentity.usPortNumber;

	return RET_ENOERR;
}

INT GetIe802AsPortDSPortState(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*		pstPortData = (PORTDATA*)pvData;
	CLOCK_GD*		pstClockGD	= &pstPortData->pstClockData->stClock_GD;
	ENUM_PORTSTATE*	penInfo		= (ENUM_PORTSTATE*)puchInfo;

	PORT_GD* pstPortGD = &pstPortData->stPort_GD;
	*penInfo = pstClockGD->enSelectedState[pstPortGD->usThisPort];

	return RET_ENOERR;
}

INT SetIe802AsPortDSPortState(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*		pstPortData = (PORTDATA*)pvData;
	ENUM_PORTSTATE*	penInfo		= (ENUM_PORTSTATE*)puchInfo;
	PAIEXTSM_GD*	pstSMGlb;

	pstSMGlb = &(pstPortData->stPAIExtSM_GD);


	pstSMGlb->enPortStateInd = *penInfo;
	return RET_ENOERR;
}

INT GetIe802AsPortDSPtpPortEnabled(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	BOOL*		pblInfo		= (BOOL*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pblInfo = pstPortDS->blPtpPortEnabled;

	return RET_ENOERR;
}

INT SetIe802AsPortDSPtpPortEnabled(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	BOOL*		pblInfo		= (BOOL*)puchInfo;
#if 1
	INT			nRet		= RET_ENOERR;
#endif
	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	if (pstPortDS->blPtpPortEnabled == *pblInfo)
	{
		nRet = RET_SAMEVAL;
	}

	pstPortDS->blPtpPortEnabled = *pblInfo;
	return nRet;
}

INT GetIe802AsPortDSIsMeasuringDDly(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	BOOL*		pblInfo		= (BOOL*)puchInfo;
	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}


	*pblInfo = pstPortDS->blIsMeasuringDelay;

	return RET_ENOERR;
}

INT GetIe802AsPortDSAsCapable(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	BOOL*		pblInfo		= (BOOL*)puchInfo;
	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pblInfo = pstPortDS->blAsCapable;

	return RET_ENOERR;
}

INT GetIe802AsPortDSNeighborPropDly(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	USCALEDNS*	pstInfo		= (USCALEDNS*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pstInfo = pstPortDS->stNeighborPropDelay;

	return RET_ENOERR;
}

INT GetIe802AsPortDSNeighbrPpDlyThr(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData	= (PORTDATA*)pvData;
	USCALEDNS*	pstInfo		= (USCALEDNS*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pstInfo = pstPortDS->stNeighborPropDelayThresh;

	return RET_ENOERR;
}

INT SetIe802AsPortDSNeighbrPpDlyThr(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData	= (PORTDATA*)pvData;
	USCALEDNS*	pstInfo		= (USCALEDNS*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	pstPortDS->stNeighborPropDelayThresh = *pstInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSDlyAsymmetry(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	SCALEDNS*	pstInfo		= (SCALEDNS*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pstInfo = pstPortDS->stDelayAsymmetry;

	return RET_ENOERR;
}

INT SetIe802AsPortDSDlyAsymmetry(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	SCALEDNS*	pstInfo		= (SCALEDNS*)puchInfo;
	CMLDSPORT_1AS_DS* pstPortDS;

	PORT_GD* 		  pstPortGD = &pstPortData->stPort_GD;

	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	pstPortDS->stDelayAsymmetry = *pstInfo;
	pstPortGD->stDelayAsymmetry = *pstInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSNeghbrRateRatio(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	LONG*		plInfo		= (LONG*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*plInfo = pstPortDS->lNeighborRateRatio;

	return RET_ENOERR;
}

INT GetIe802AsPortDSInitLogAnncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pchInfo = pstPortDS->chInitialLogAnnounceInterval;

	return RET_ENOERR;
}

INT SetIe802AsPortDSInitLogAnncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	pstPortDS->chInitialLogAnnounceInterval = *pchInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSCrntLogAnncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pchInfo = pstPortDS->chCurrentLogAnnounceInterval;

	return RET_ENOERR;
}

INT GetIe802AsPortDSAnnoceRecptTout(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	UCHAR*		puchInfo2		= (UCHAR*)puchInfo;

	PORT_DS* pstPortDS = &pstPortData->stPortDS;

	*puchInfo2 = pstPortDS->uchAnnounceReceiptTimeout;

	return RET_ENOERR;
}

INT SetIe802AsPortDSAnnoceRecptTout(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	UCHAR*		puchInfo2		= (UCHAR*)puchInfo;

	PORT_DS* pstPortDS = &pstPortData->stPortDS;

	pstPortDS->uchAnnounceReceiptTimeout = *puchInfo2;

	return RET_ENOERR;
}

INT GetIe802AsPortDSInitLogSyncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pchInfo = pstPortDS->chInitialLogSyncInterval;

	return RET_ENOERR;
}

INT SetIe802AsPortDSInitLogSyncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	pstPortDS->chInitialLogSyncInterval = *pchInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSCrntLogSyncIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*pchInfo = pstPortDS->chCurrentLogSyncInterval;

	return RET_ENOERR;
}

INT GetIe802AsPortDSSyncRecptTout(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	UCHAR*		puchInfo2		= (UCHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	*puchInfo2 = pstPortDS->uchSyncReceiptTimeout;

	return RET_ENOERR;
}

INT SetIe802AsPortDSSyncRecptTout(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	UCHAR*		puchInfo2		= (UCHAR*)puchInfo;

	PORT_1AS_DS* pstPortDS = &pstPortData->stPort_1AS_DS;

	pstPortDS->uchSyncReceiptTimeout = *puchInfo2;

	return RET_ENOERR;
}

INT GetIe802AsPortDSSyncRecptTOTMIv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	USCALEDNS*	pstInfo		= (USCALEDNS*)puchInfo;

	PORT_1AS_DS* pstPortDS	= &pstPortData->stPort_1AS_DS;

	*pstInfo = pstPortDS->stSyncReceiptTimeoutTimeInterval;

	return RET_ENOERR;
}

INT GetIe802AsPortDSInitLogPDRqIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pchInfo = pstPortDS->chInitialLogPdelayReqInterval;

	return RET_ENOERR;
}

INT SetIe802AsPortDSInitLogPDRqIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	pstPortDS->chInitialLogPdelayReqInterval = *pchInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSCrntLogPDRqIntv(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	CHAR*		pchInfo		= (CHAR*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pchInfo = pstPortDS->chCurrentLogPdelayReqInterval;

	return RET_ENOERR;
}

INT GetIe802AsPortDSAllowedLostResp(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	USHORT*		pusInfo		= (USHORT*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pusInfo = pstPortDS->usAllowedLostResponses;

	return RET_ENOERR;
}

INT SetIe802AsPortDSAllowedLostResp(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	USHORT*		pusInfo		= (USHORT*)puchInfo;

	CMLDSPORT_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	pstPortDS->usAllowedLostResponses = *pusInfo;

	return RET_ENOERR;
}

INT GetIe802AsPortDSVersionNumber(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	BYTE*		pbyInfo		= (BYTE*)puchInfo;

	PORT_DS*	pstPortDS = &pstPortData->stPortDS;

	*pbyInfo = pstPortDS->byVersionNumber;

	return RET_ENOERR;
}

INT GetIe802AsRxSyncCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulRxSyncCount;

	return RET_ENOERR;
}

INT GetIe802AsRxFollowUpCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulRxFollowUpCount;

	return RET_ENOERR;
}

INT GetIe802AsRxPDlyReqCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;
	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}
	
	*pulInfo = pstPortDS->ulRxPdelayRequestCount;

	return RET_ENOERR;
}

INT GetIe802AsRxPDlyRespCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulRxPdelayResponseCount;

	return RET_ENOERR;
}

INT GetIe802AsRxPDlyRespFllwUpCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulRxPdelayResponseFollowUpCount;

	return RET_ENOERR;
}

INT GetIe802AsRxAnnoceCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulRxAnnounceCount;

	return RET_ENOERR;
}

INT GetIe802AsRxPTPPacketDscrdCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulRxPTPPacketDiscardCount;

	return RET_ENOERR;
}

INT GetIe802AsSyncRecptToutCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulSyncReceiptTimeoutCount;

	return RET_ENOERR;
}

INT GetIe802AsAnnoceRecptToutCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulAnnounceReceiptTimeoutCount;

	return RET_ENOERR;
}

INT GetIe802AsPDlyAllwLstRpExcCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulPdelayAllwLostRespExcdCount;

	return RET_ENOERR;
}

INT GetIe802AsTxSyncCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulTxSyncCount;

	return RET_ENOERR;
}

INT GetIe802AsTxFollowUpCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulTxFollowUpCount;

	return RET_ENOERR;
}

INT GetIe802AsTxPDlyReqCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulTxPdelayRequestCount;

	return RET_ENOERR;
}

INT GetIe802AsTxPDlyRespCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulTxPdelayResponseCount;

	return RET_ENOERR;
}

INT GetIe802AsTxPDlyRespFllwUpCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	CMLDSPORTSTATISTICS_1AS_DS* pstPortDS;
	
	pstPortDS = GetCmldsPortStatisticsDS( pstPortData );
	if ( pstPortDS == NULL )
	{
		return RET_EINVAL;
	}

	*pulInfo = pstPortDS->ulTxPdelayResponseFollowUpCount;

	return RET_ENOERR;
}

INT GetIe802AsTxAnnoceCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulTxAnnounceCount;

	return RET_ENOERR;
}

INT GetIe802AsTxMessageErrorCount(VOID* pvData, UCHAR* puchInfo)
{
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ULONG*		pulInfo		= (ULONG*)puchInfo;

	PORTSTATISTICS_1AS_DS* pstPortDS = &pstPortData->stPortStatistics_1AS_DS;

	*pulInfo = pstPortDS->ulTxMessageErrorCount;

	return RET_ENOERR;
}
#endif
INT NopIe802As_NOP(VOID* pvData, UCHAR* puchInfo)
{
	return RET_EINVAL;
}
