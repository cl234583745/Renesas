/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE802_1

#include "MDPdelayResp.h"
#include "MDPdelayResp_1AS.h"

#include "PTP_GlobalData.h"

#define	D_FUNC		0
#define	D_DBG		0


static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData );
static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData );

VOID (*const MDPdelayResp_1AS_Matrix[DMDPDRP_STATUS_MAX][DMDPDRP_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDPdelayResp_01_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_NP_1AS},
	{&MDPdelayResp_01_1AS, &MDPdelayResp_02_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_00_1AS},
	{&MDPdelayResp_01_1AS, &MDPdelayResp_02_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_00_1AS},
	{&MDPdelayResp_01_1AS, &MDPdelayResp_02_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_00_1AS},
	{&MDPdelayResp_01_1AS, &MDPdelayResp_NP_1AS, &MDPdelayResp_03_1AS, &MDPdelayResp_00_1AS}
};
static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData )
{
	CMLDSPORT_1AS_DS *pstCmldsPortDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPort_1AS_DS;

	return pstCmldsPortDS;
}

static CMLDSPORTSTATISTICS_1AS_DS* GetCmldsPortStatisticsDS( PORTDATA* pstPortData )
{
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatisticsDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortStatisticsDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPortStatistics_1AS_DS;

	return pstCmldsPortStatisticsDS;
}
VOID MDPdelayResp_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYRESP_EV	enEvt = MDPDRP_E_EVENT_MAX;
	MDPDELAYRESP_ST	enSts = MDPDRP_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82080001);

	enEvt = GetMDPdelayRespEvent(usEvent, pstPort);
	enSts = GetMDPdelayRespStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDPdelayResp_1AS         ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDPDRP_STATUS_MAX) && (enEvt != MDPDRP_E_EVENT_MAX))
	{
		(*MDPdelayResp_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDPdelayRespStatus(pstPort);
	printf ("<END  > [%02d]MDPdelayResp_1AS         ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
}

VOID MDPdelayResp_00_1AS(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDPdelayResp_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	MDPdlyResp_NotEnable_1AS(pstGbl, pstPort);
	SetMDPdelayRespStatus(MDPDRP_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDPdelayResp_00_1AS::-\n") );

}

VOID MDPdelayResp_01_1AS(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;
	BOOL			blRet = FALSE;

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	blRet = MDPdlyResp_IntWtFrPDReq_1AS(pstGbl, pstPort);
	if (blRet)
	{
		SetMDPdelayRespStatus(MDPDRP_INITIAL_WAIT_FR_PDREQ, pstPort);
	}
	else
	{
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
	}

}

VOID MDPdelayResp_02_1AS(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;

	ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1AS::+\n"));

	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );
	
	pstGbl = GetMDPdelayRespGlobal(pstPort);

	if (ConMDPdelayReq_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82001508);
		MDPdlyResp_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1AS::-\n"));

		return;
	}

	IncMDPDlyRespRxPDlyReqCount( pstCmldsPortStatDs );

	if (SetMDPdlyReqEvIngresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_8200150B);
		MDPdlyResp_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1AS::-\n"));

		return;
	}

	MDPdlyResp_StPDRespWtFrTS_1AS(pstGbl, pstPort);
	SetMDPdelayRespStatus(MDPDRP_SENT_PDRESP_WAIT_FR_TMST, pstPort);

	ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1AS::-\n"));

}

VOID MDPdelayResp_03_1AS(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_8200260C);
		MDPdlyResp_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
		return;
	}

	if (SetMDPdlyRespEvEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_8200260B);
		MDPdlyResp_NotEnable_1AS(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
		return;
	}

	MDPdlyResp_WtFrPDReq_1AS(pstGbl, pstPort);
	SetMDPdelayRespStatus(MDPDRP_WAIT_FR_PDELAY_REQ, pstPort);
}

VOID MDPdelayResp_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82000007);
	return;
}

BOOL MDPdlyResp_NotEnable_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	return TRUE;
}

BOOL MDPdlyResp_IntWtFrPDReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*	pstCmldsPortDS;

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1AS::+\n"));

	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	pstSmGbl->blRcvdPdelayReq = FALSE;

	if (pstCmldsPortDS->blCmldsPortEnabled == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}

	if (pstPort->stPort_GD.blPdelayExecFlag == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1AS(FALSE)::-\n"));
		return FALSE;
	}

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1AS::-\n"));
	return TRUE;
}

BOOL MDPdlyResp_WtFrPDReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_WtFrPDReq_1AS::+\n"));

	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	pstSmGbl->blEgMDTimestampReceive = FALSE;

	if (SetPdelayRespFollowUp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxPdelayRespFollowUp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	IncMDPDlyRespTxPDRpFllwUpCount( pstCmldsPortStatDs );

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_WtFrPDReq_1AS::-\n"));
	return TRUE;
}

BOOL MDPdlyResp_StPDRespWtFrTS_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdPdelayReq = FALSE;
	CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs;
	
	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRespWtFrTS_1AS::+\n"));

	pstCmldsPortStatDs = GetCmldsPortStatisticsDS( pstPort );

	if (SetPdelayResp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRespWtFrTS_1AS(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayResp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRespWtFrTS_1AS(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyRespTxPDlyRespCount( pstCmldsPortStatDs );


	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRespWtFrTS_1AS::-\n"));
	return TRUE;
}

BOOL ConMDPdelayReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayReq == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82001509);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayReq == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_8200150A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPdlyReq_1AS,
		&pstSmGbl->pstRcvdPdelayReq->stPdlyReq_1AS, sizeof(pstPortMD->stConPdlyReq_1AS));
	if (   (MPTPMSG_H_GET_MAJORSDO_ID(&pstPortMD->stConPdlyReq_1AS.stHeader) == 1) 
	    && (pstPortMD->stConPdlyReq_1AS.stHeader.uchMinorSdoId == 0) 
	    && (pstPortMD->stConPdlyReq_1AS.stHeader.uchDomainNumber == 0) )
	{
		pstPortMD->blPdelayFlag = TRUE;
	}
	else if (   (MPTPMSG_H_GET_MAJORSDO_ID(&pstPortMD->stConPdlyReq_1AS.stHeader) == 2) 
	         && (pstPortMD->stConPdlyReq_1AS.stHeader.uchMinorSdoId == 0) 
	         && (pstPortMD->stConPdlyReq_1AS.stHeader.uchDomainNumber == 0) )
	{
		pstPortMD->blPdelayFlag = FALSE;
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}

BOOL SetPdelayResp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_DS*	pstPortDS			= &pstPort->stPortDS;
	PORTMD_GD*	pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_PDELAY_RESP_1AS* pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxPdelayRespAS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	if (!(pstPortMD->blPdelayFlag))
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_2 );
	}
	else
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );

	}
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDELAY_RESP );
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	pstMsg->stHeader.uchDomainNumber	= PTPM_DOMAIN_NUMBER_0;
	pstMsg->stHeader.usMegLength		= 0;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;
    MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, TRUE );


	pstMsg->stHeader.stCorrectionField.usFrcNsec = 0;
	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_PDELAY_RESP,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		=
		pstSmGbl->pstRcvdPdelayReq->stPdlyReq_1AS.stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_RESP;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stReqRcptTimestamp,
		&pstPortMD->stPdlyReqEventIngressTimestamp, sizeof(pstMsg->stReqRcptTimestamp));
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstSmGbl->pstRcvdPdelayReq->stPdlyReq_1AS.stHeader.stSrcPortIdentity, sizeof(pstMsg->stReqPortIdentity));
	GetPTPMSG_PDELAY_RESP_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL TxPdelayResp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDPdelayResp;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayRespAS,
		pstSmGbl->stTxPdelayRespAS.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82002608);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL SetPdelayRespFollowUp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_DS*	pstPortDS			= &pstPort->stPortDS;
	PORTMD_GD*	pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_PDRESP_FOLLOWUP_1AS* pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxPdelayRespFollowUpAS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	if (!(pstPortMD->blPdelayFlag))
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_2 );
	}
	else
	{
		MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	}

	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP );
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );
	pstMsg->stHeader.uchDomainNumber	= PTPM_DOMAIN_NUMBER_0;
	pstMsg->stHeader.usMegLength		= 0;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;

	pstMsg->stHeader.stCorrectionField.usFrcNsec = 0;

	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_PDRESP_FOLLOWUP,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		=
		pstSmGbl->stTxPdelayRespAS.stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_RESP_FOLLOWUP;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stRespOrgnTimestamp,
		&pstPortMD->stPdlyRespEventEgressTimestamp, sizeof(pstMsg->stRespOrgnTimestamp));
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstSmGbl->stTxPdelayRespAS.stReqPortIdentity, sizeof(pstMsg->stReqPortIdentity));
	GetPTPMSG_PDRESP_FOLLOWUP_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL TxPdelayRespFollowUp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayRespFollowUpAS,
		pstSmGbl->stTxPdelayRespFollowUpAS.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1AS, PTP_LOGVE_82002708);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

#endif
