/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __GETDETAILCURRENTTIME_H__
#define __GETDETAILCURRENTTIME_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif
void ptp_GetDetailCurrentTime(USCALEDNS* pstDetailCurTime);

#ifdef __cplusplus
}
#endif


#endif


