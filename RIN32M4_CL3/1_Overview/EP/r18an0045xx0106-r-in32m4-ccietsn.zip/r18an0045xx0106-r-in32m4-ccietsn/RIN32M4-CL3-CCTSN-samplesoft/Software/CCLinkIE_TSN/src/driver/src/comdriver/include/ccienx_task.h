/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef	CCIENX_TASK_H__
#define	CCIENX_TASK_H__

#include "kernel.h"

#define TSKID_NX_TOP			(32)
#define TSKID_NX_LOW_INT		(TSKID_NX_TOP + 1)
#define TSKID_NX_HIGH_INT		(TSKID_NX_TOP + 2)
#define TSKID_NX_NCYC_RX		(TSKID_NX_TOP + 3)
#define TSKID_NX_NCYC_TX		(TSKID_NX_TOP + 4)
#define TSKID_NX_PERIODIC		(TSKID_NX_TOP + 5)
#define TSKID_NX_IPCOMM			(TSKID_NX_TOP + 6)
#define TSKID_NX_TSN			(TSKID_NX_TOP + 7)
#define	TSKID_NX_RLYRAMCLR		(TSKID_NX_TOP + 8)
#if 1	/* Modification for R-IN32M4 */
#define TSKID_NX_LED			(TSKID_NX_TOP + 9)
#endif

#define SEMID_NX_TOP			(64)
#define SEMID_NX_TSN_1			(SEMID_NX_TOP + 1)
#define SEMID_NX_TSN_2			(SEMID_NX_TOP + 2)
#define SEMID_NX_PHYACCESS		(SEMID_NX_TOP + 3)
#define	SEMID_NX_RLYRAMCLR		(SEMID_NX_TOP + 4)

#define EVFLGID_NX_TOP			(32)
#define EVFLGID_NX_NOCYCTXCOMP	(EVFLGID_NX_TOP + 1)
#define EVFLGID_NX_DMACOMP00	(EVFLGID_NX_TOP + 2)
#define EVFLGID_NX_DMACOMP01	(EVFLGID_NX_TOP + 3)
#define EVFLGID_NX_DMACOMP02	(EVFLGID_NX_TOP + 4)
#define EVFLGID_NX_DMACOMP03	(EVFLGID_NX_TOP + 5)
#define EVFLGID_NX_TXDISC_UPD	(EVFLGID_NX_TOP + 6)
#define EVFLGID_NX_DUMMY		(EVFLGID_NX_TOP + 7)
#define	EVFLGID_NX_RLYRAMCLR	(EVFLGID_NX_TOP + 8)

#define MBXID_NX_TOP			(32)
#define MBXID_NX_RECEIVE_NGN	(MBXID_NX_TOP + 1)
#define MBXID_NX_RECEIVE_IEEE	(MBXID_NX_TOP + 2)
#define	MBXID_NX_SEND_TS0		(MBXID_NX_TOP + 3)
#define	MBXID_NX_SEND_TS1		(MBXID_NX_TOP + 4)
#define	MBXID_NX_SEND_TS2		(MBXID_NX_TOP + 5)
#define	MBXID_NX_SEND_TS3		(MBXID_NX_TOP + 6)
#define	MBXID_NX_SEND_TS4		(MBXID_NX_TOP + 7)
#define	MBXID_NX_SEND_TS5		(MBXID_NX_TOP + 8)
#define	MBXID_NX_SEND_TS6		(MBXID_NX_TOP + 9)
#define	MBXID_NX_SEND_TS7		(MBXID_NX_TOP + 10)

#define	FLGP_DMACOMP			(0x0001)
#define FLGP_TXDISC_UPD			(0x0001)
#define FLGP_DUMMY				(0x0001)
#define	FLGP_LINKDOWN_P1		(0x0001)
#define	FLGP_LINKDOWN_P2		(0x0002)
#define	FLGP_RAMOVRFLW_P1		(0x0004)
#define	FLGP_RAMOVRFLW_P2		(0x0008)

NX_VOID 		vNX_Task_CciefNx_High (NX_VOID);
NX_VOID 		vNX_Task_CciefNx_Low (NX_VOID);
NX_VOID			vNX_Task_TxNonCycFrame(NX_VOID);
NX_VOID			vNX_Task_RxNonCycFrame(NX_VOID);
NX_VOID			vNX_Task_ComDriverPeriodic(NX_VOID);
NX_VOID			vNX_Task_IpFrameComm (NX_VOID);
NX_VOID			vNX_Task_TSNPeriodic (NX_VOID);
NX_VOID			vNX_Task_RelayRamClr (NX_VOID);
#if 1	/* Modification for R-IN32M4 */
NX_VOID			vNX_Task_LEDPeriodic (NX_VOID);
#endif

#endif
