/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ManagementSM.h"

#ifdef	PTP_USE_MANAGEMENT

#include "ManagementSM_1588.h"


VOID ManagementSM_ERR(MANAGEMENTSM_GD* pstSmGbl, CLOCKDATA* pstClockData, PORTDATA* pstPortData)
{
	PTPMSG_MANAGEMENT_1588*	pstMsg			= (PTPMSG_MANAGEMENT_1588*)pstSmGbl->puchMgtRxMsg;
	PTPMSG_MANAGEMENT_TLV*	pstMsgTLV	= (PTPMSG_MANAGEMENT_TLV*)&pstMsg->stManagemant_TLV;

	PTPMSG_MANAGEMENT_1588*	pstOutMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;

	PTPMSG_MANAGEMENT_ERRSTA_TLV*	pstOutErrTLV = (PTPMSG_MANAGEMENT_ERRSTA_TLV*)&pstOutMsg->stManagemant_TLV;
	
	SetManagementErrorTLVInfo(pstMsgTLV, pstOutErrTLV, PTPM_MGTER_GENERAL_ERROR);
	SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV *)pstOutMsg, pstPortData);
	TxManagementMsg(pstSmGbl, pstClockData);

	return;
}
#endif
