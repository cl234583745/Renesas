/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __NGN_ASIC_CN_DEF_H_INCLUDED__
#define __NGN_ASIC_CN_DEF_H_INCLUDED__
#define		NGN_ASIC_CYCLIC_SND_TSMAX			(NX_ULONG)7
#define		NGN_ASIC_NONCYCLIC_SND_TSMAX		(NX_ULONG)7
#define		NGN_ASIC_SND_DISCRIPT_MAX			(NX_ULONG)1056
#define		NGN_ASIC_PAYLOAD_DISCRIPT_MAX		(NX_ULONG)1056
#define		NGN_ASIC_MULTICAST_ADD_GROUP_MAX	(NX_ULONG)16
#define		NGN_ASIC_TSMAX						(NX_ULONG)8
#define		NGN_ASIC_GIGA_ETHER_MAC_MAX			(NX_ULONG)4
#define		NGN_ASIC_MAC_ADD_MAX				(NX_ULONG)3
#define		NGN_ASIC_IEEE1588_MAC_ADD_MAX		(NX_ULONG)3
#endif
