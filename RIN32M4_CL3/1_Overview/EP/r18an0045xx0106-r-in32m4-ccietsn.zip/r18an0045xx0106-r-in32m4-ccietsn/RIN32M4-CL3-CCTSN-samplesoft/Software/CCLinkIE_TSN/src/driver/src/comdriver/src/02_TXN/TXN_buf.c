/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "TXN_buf.h"
#include "ccienx_api.h"

#define	ALL_USED				(0xFF)
#define	BYTEBITNUM				(8)
#define	SYNC_BUFF				(0)
#define	NSYNC_BUFF				(1)


NX_STATIC NCYC_TX_BUF_S			gastNonCycTxBufS[2];
NX_STATIC NCYC_TX_BUF_L			gastNonCycTxBufL[2];

NX_STATIC NX_ULONG ulTXN_UsedFlgSet_TX (NX_ULONG*, NX_ULONG*);


NX_EXTERN NX_CONST NX_UCHAR UnUsedFlgCheckTable[256];

NX_VOID vTXN_InitNonCycTxBuf (NX_VOID)
{
    NX_USHORT  usCount;
	
	vNX_FillMemory32(&gastNonCycTxBufS[SYNC_BUFF], NX_ZERO, (sizeof(NCYC_TX_BUF_S) / sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastNonCycTxBufS[NSYNC_BUFF], NX_ZERO, (sizeof(NCYC_TX_BUF_S) / sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastNonCycTxBufL[SYNC_BUFF], NX_ZERO, (sizeof(NCYC_TX_BUF_L) / sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastNonCycTxBufL[NSYNC_BUFF], NX_ZERO, (sizeof(NCYC_TX_BUF_L) / sizeof(NX_ULONG)));
	
	for (usCount = (NX_USHORT)NX_ZERO; usCount < (NX_USHORT)NCYC_TX_NUM_S; usCount++) {
		gastNonCycTxBufS[SYNC_BUFF].astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_TX_BUF_SYNC_S + usCount;
		gastNonCycTxBufS[NSYNC_BUFF].astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_TX_BUF_S + usCount;
	}
	for (usCount = (NX_USHORT)NX_ZERO; usCount < (NX_USHORT)NCYC_TX_NUM_L; usCount++) {
		gastNonCycTxBufL[SYNC_BUFF].astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_TX_BUF_SYNC_L + usCount;
		gastNonCycTxBufL[NSYNC_BUFF].astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_TX_BUF_L + usCount;
	}
	gastNonCycTxBufS[SYNC_BUFF].ulUsedFlg = (NX_ULONG)NCYC_TX_NUM_S_BIT;
	gastNonCycTxBufS[NSYNC_BUFF].ulUsedFlg = (NX_ULONG)NCYC_TX_NUM_S_BIT;
	gastNonCycTxBufL[SYNC_BUFF].ulUsedFlg = (NX_ULONG)NCYC_TX_NUM_L_BIT;
	gastNonCycTxBufL[NSYNC_BUFF].ulUsedFlg = (NX_ULONG)NCYC_TX_NUM_L_BIT;
	return;
}

NX_ULONG ulTXN_AllocTxNonCycBuf (
	NX_ULONG		ulFrameType,
	NX_USHORT		usSize,
	NCYC_TX_FRAME**	pstTxFrame
)
{
	NX_ULONG*		pulUsedFlgAdd;
	NX_ULONG		ulResult;
	NX_ULONG		ulBuffPoint;
	NX_ULONG		ulBuffAdd;
	NX_ULONG		ulBuffSize;
	
	ulResult = NX_UL_NG;
	
	if (usSize <= (NX_USHORT)NCYC_TX_FRAME_SIZE_S) {
		switch (ulFrameType) {
		case NCYC_TXFRAME_TYPE_TSN:
			pulUsedFlgAdd = (NX_ULONG*)&gastNonCycTxBufS[SYNC_BUFF];
			ulBuffAdd = (NX_ULONG)&gastNonCycTxBufS[SYNC_BUFF].astFrame[NX_ZERO];
			break;
		case NCYC_TXFRAME_TYPE_NOT_TSN:
		default:
			pulUsedFlgAdd = (NX_ULONG*)&gastNonCycTxBufS[NSYNC_BUFF];
			ulBuffAdd = (NX_ULONG)&gastNonCycTxBufS[NSYNC_BUFF].astFrame[NX_ZERO];
			break;
		}
		ulBuffSize = (NX_ULONG)sizeof(NCYC_TX_FRAME_S);
	}
	else {
		switch (ulFrameType) {
		case NCYC_TXFRAME_TYPE_TSN:
			pulUsedFlgAdd = (NX_ULONG*)&gastNonCycTxBufL[SYNC_BUFF];
			ulBuffAdd = (NX_ULONG)&gastNonCycTxBufL[SYNC_BUFF].astFrame[NX_ZERO];
			break;
		case NCYC_TXFRAME_TYPE_NOT_TSN:
		default:
			pulUsedFlgAdd = (NX_ULONG*)&gastNonCycTxBufL[NSYNC_BUFF];
			ulBuffAdd = (NX_ULONG)&gastNonCycTxBufL[NSYNC_BUFF].astFrame[NX_ZERO];
			break;
		}
		ulBuffSize = (NX_ULONG)sizeof(NCYC_TX_FRAME_L);
	}
	ulResult = ulTXN_UsedFlgSet_TX(pulUsedFlgAdd, &ulBuffPoint);
	if (ulResult != NX_UL_OK) {
	}
	else {
		*pstTxFrame = (NCYC_TX_FRAME*)(ulBuffAdd + (ulBuffSize * ulBuffPoint));
	}
	
	return ulResult;
}

NX_STATIC NX_ULONG ulTXN_UsedFlgSet_TX (
	NX_ULONG			*pulUsedFlgAdd,
	NX_ULONG			*pulBuffPoint
)
{
	NX_ULONG	ulResult = NX_UL_NG;
	NX_ULONG	ulWritePointer = (NX_ULONG)NX_ZERO;
	NX_USHORT	usCount;
	NX_UCHAR	uchUsedFlgIndex;
	NX_ULONG	ulFlg;
	
	vNX_vDisableDispatch();
	ulFlg = *pulUsedFlgAdd;
	
	for (usCount = NX_ZERO; usCount < (NX_USHORT)(sizeof(NX_ULONG)); usCount++) {
		uchUsedFlgIndex = (NX_UCHAR)(ulFlg & NX_BIT00_07);
		if (UnUsedFlgCheckTable[uchUsedFlgIndex] != (NX_UCHAR)ALL_USED) {
			ulWritePointer += UnUsedFlgCheckTable[uchUsedFlgIndex];
			*(NX_ULONG*)BITBAND_SRAM(pulUsedFlgAdd, ulWritePointer) = (NX_ULONG)NX_ON;
			*pulBuffPoint = ulWritePointer;
			ulResult = NX_UL_OK;
			break;
		}
		ulWritePointer += BYTEBITNUM;
		ulFlg >>= BYTEBITNUM;
	}
	vNX_vEnableDispatch();
	return ulResult;
}

NX_VOID vTXN_ReleaseNonCycTxBuf (
	NX_USHORT	usBuffId
)
{
	switch (usBuffId & (BUFFIDMASK_SIZE | BUFFIDMASK_FRAME)) {
	case BUFFID_NCYC_TX_BUF_SYNC_S:
		*(NX_ULONG*)BITBAND_SRAM(&gastNonCycTxBufS[SYNC_BUFF].ulUsedFlg, (usBuffId & BUFFIDMASK_INDEX)) = (NX_ULONG)NX_OFF;
		break;
	case BUFFID_NCYC_TX_BUF_SYNC_L:
		*(NX_ULONG*)BITBAND_SRAM(&gastNonCycTxBufL[SYNC_BUFF].ulUsedFlg, (usBuffId & BUFFIDMASK_INDEX)) = (NX_ULONG)NX_OFF;
		break;
	case BUFFID_NCYC_TX_BUF_S:
		*(NX_ULONG*)BITBAND_SRAM(&gastNonCycTxBufS[NSYNC_BUFF].ulUsedFlg, (usBuffId & BUFFIDMASK_INDEX)) = (NX_ULONG)NX_OFF;
		break;
	case BUFFID_NCYC_TX_BUF_L:
		*(NX_ULONG*)BITBAND_SRAM(&gastNonCycTxBufL[NSYNC_BUFF].ulUsedFlg, (usBuffId & BUFFIDMASK_INDEX)) = (NX_ULONG)NX_OFF;
		break;
	default:
		break;
	}
	return;
}
