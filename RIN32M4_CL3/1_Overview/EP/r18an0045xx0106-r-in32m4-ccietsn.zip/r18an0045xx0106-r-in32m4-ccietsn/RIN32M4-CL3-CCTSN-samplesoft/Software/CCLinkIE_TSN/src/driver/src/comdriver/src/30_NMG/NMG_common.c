/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "NMG_common.h"
#include "ccienx_app_supply.h"


NX_CONST NX_USHORT DetailErrorTbl_Detection[NMG_IDX_DETECTION_ERR_NUM] = {
	0x00FF
};
NX_CONST NX_USHORT DetailErrorTbl_NwCfgMain[NMG_IDX_NWCFGMAIN_ERR_NUM] = {
	0x0100,
	0x0101,
	0x0102,
	0x0103,
	0x0104,
	0x0105,
	0x0106,
	0x0107,
	0x0108,
	0x0109,
	0x010A,
	0x010B,
	0x010C,
	0x010D,
	0x010E,
	0x010F,
	0x0110,
	0x0111,
	0x0112,
	0x0113,
	0x0114,
	0x0115,
	0x0116,
	0x0117,
	0x0118,
	0x0119,
	0x011A,
	0x011B,
	0x011C,
	0x011D,
	0x011E,
	0x011F,
	0x0120,
	0x0121,
	0x0122,
	0x0123,
	0x0124,
	0x0125,
	0x0126,
	0x0127,
	0x0128,
	0x0129,
	0x012A,
	0x012B
};

NX_CONST NX_USHORT DetailErrorTbl_NwCfgTslt[NMG_IDX_NWCFGTSLT_ERR_NUM] = {
	0x0200,
	0x0201,
	0x0202,
	0x0203,
	0x0204,
	0x0205,
	0x0206,
	0x0207,
	0x0208,
	0x0209,
	0x020A,
	0x020B,
	0x020C,
	0x020D,
	0x020E,
	0x020F,
	0x0210,
	0x0211,
	0x0212,
	0x0213,
	0x0214,
	0x0215,
	0x0216,
	0x0217,
	0x0218,
	0x0219,
	0x021A,
	0x021B,
	0x021C,
	0x021D,
	0x021E,
	0x021F,
	0x0220,
	0x0221,
	0x0222,
	0x0223,
	0x0224,
	0x0225,
	0x0226,
	0x0227,
	0x0228,
	0x0229,
	0x022A,
	0x022B,
	0x022C,
	0x022D,
	0x022E,
	0x022F,
	0x0230,
	0x0231,
	0x0232,
	0x0233,
	0x0234,
	0x0235,
	0x0236,
	0x0237,
	0x0238,
	0x0239,
	0x023A,
	0x023B,
	0x023C,
	0x023D,
	0x023E,
};

NX_CONST NX_USHORT DetailErrorTbl_SlvCfg[NMG_IDX_SLVCFG_ERR_NUM] = {
	0x0300,
	0x0301
};

NX_CONST NX_USHORT DetailErrorTbl_CycCfgMain[NMG_IDX_CYCCFGMAIN_ERR_NUM] = {
	0x0400,
	0x0401,
	0x0402,
	0x0403,
	0x0404,
	0x0405,
	0x0406,
	0x0407,
	0x0408,
	0x0409,
	0x040A,
};

NX_CONST NX_USHORT DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_CYCCFGTRNSPD_ERR_NUM] = {
	0x0500,
	0x0501,
	0x0502,
	0x0503,
	0x0504,
	0x0505,
	0x0506,
	0x0507,
	0x0508,
	0x0509,
	0x050A,
	0x050B,
	0x050C,
	0x050D,
	0x050E,
	0x050F,
	0x0510,
	0x0511,
	0x0512,
	0x0513,
	0x0514,
	0x0515,
	0x0516,
	0x0517,
	0x0518,
	0x0519,
	0x051A,
	0x051B,
	0x051C,
	0x051D,
	0x051E,
	0x051F,
	0x05FE,
	0x05FF,
	0x05FC,
	0x05FD,
	0x05FB,
	0x05FA,
	0x05F9,
	0x05F8,
	0x0520,
	0x0521,
	0x0522,
	0x0523,
	0x0524,
	0x0525,
	0x0526,
	0x0527,
	0x0528,
	0x0529,
};

NX_CONST NX_USHORT DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_CYCCFGRCVSPD_ERR_NUM] = {
	0x0600,
	0x0601,
	0x0602,
	0x0603,
	0x0604,
	0x0605,
	0x06FF
};

NX_CONST NX_USHORT DetailErrorTbl_CycCfgRcvInfo[NMG_IDX_CYCCFGRCVINFO_ERR_NUM] = {
	0x0700,
	0x0701,
	0x0702,
	0x0703,
	0x0704,
	0x0705,
	0x0706,
	0x0707,
	0x0708,
	0x0709,
	0x070A,
	0x070B
};


NX_VOID vNMG_SetSlmpRespHead6E (
	SLMP_REQUEST_6E*	pstReq,
	SLMP_RESPONSE_6E*	pstRes,
	NX_USHORT			usFinCode,
	NX_USHORT			usDataSize
)
{
	pstRes->usFrameType			= NX_SLMP_FTYPE_6E_RES;
	pstRes->usSerialNo			= pstReq->usSerialNo;
	pstRes->usFixedZero1		= pstReq->auchRsv1[0];
	pstRes->usFixedZero1		|= pstReq->auchRsv1[1] << NX_SHIFT8;	
	pstRes->uchNetNo			= pstReq->uchNetNo;
	pstRes->uchStNo				= pstReq->uchStNo;
	pstRes->usUtIONo			= pstReq->usUtIONo;
	pstRes->uchMultiDropStNo	= pstReq->uchMultiDropStNo;
	pstRes->uchFixedZero2		= pstReq->auchRsv2[0];
	pstRes->usExStNo			= pstReq->usExStNo;
	pstRes->usDataBSize			= usDataSize;
	pstRes->usFinishCode		= usFinCode;
	pstRes->usCmd				= pstReq->usCmd;
	pstRes->usSubCmd			= pstReq->usSubCmd;

	return;
}

NX_VOID vNMG_SetNmgErr (
	NX_USHORT	usEventCode,
	NX_USHORT*	pusErrDetail
)
{
	NX_USHORT	usErrDetail;
	NX_USHORT	usCmdType;
	
	if ( NX_NULL != pusErrDetail ) {
		usErrDetail = *pusErrDetail;
	}
	else {
		usErrDetail = (NX_USHORT)NX_ZERO;
	}

	usCmdType = ( usErrDetail & (NX_USHORT)NMG_ERR_CMDTYPE_MSK );

	switch ( usCmdType ) {
	case NMG_ERR_CMDTYPE_NTCMAIN:
		gstNET.stErrInfo.ausEventCode[0] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[0] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_NTCTSLT:
		gstNET.stErrInfo.ausEventCode[1] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[1] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_SRVCNF:
		gstNET.stErrInfo.ausEventCode[2] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[2] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_CYCCNFMAIN:
		gstNET.stErrInfo.ausEventCode[3] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[3] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_CYCCNFTRN:
		gstNET.stErrInfo.ausEventCode[4] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[4] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_CYCCNFRCV:
		gstNET.stErrInfo.ausEventCode[5] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[5] = usErrDetail;
		break;
	case NMG_ERR_CMDTYPE_CYCCNFSRC:
		gstNET.stErrInfo.ausEventCode[6] = usEventCode;
		gstNET.stErrInfo.ausErrDetail[6] = usErrDetail;
		break;
	default:
		break;
	}
	
	return;
}

NX_VOID vNMG_ClrNmgErr ( NX_VOID )
{
	NX_USHORT	usLoop;
	
	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < NM_CNF_ERRSTS_NUM; usLoop++) {
		gstNET.stErrInfo.ausEventCode[usLoop] = (NX_USHORT)NX_ZERO;
		gstNET.stErrInfo.ausErrDetail[usLoop] = (NX_USHORT)NX_ZERO;
	}
	return;
}

NX_VOID vNMG_SetNmgErrDt (
	NX_USHORT	usEventCode,
	NX_USHORT*	pusErrDetail
)
{
	NX_USHORT	usErrDetail;
	NX_USHORT	usCmdType;
	
	if ( NX_NULL != pusErrDetail ) {
		usErrDetail = *pusErrDetail;
	}
	else {
		usErrDetail = (NX_USHORT)NX_ZERO;
	}

	gstNET.stErrInfo.usEventCodeDt = usEventCode;
	gstNET.stErrInfo.ausErrDetailDt[0] = usErrDetail;
	
	return;
}

NX_VOID vNMG_ClrNmgErrDt ( NX_VOID )
{
	gstNET.stErrInfo.usEventCodeDt = (NX_USHORT)NX_ZERO;
	gstNET.stErrInfo.ausErrDetailDt[0] = (NX_USHORT)NX_ZERO;
	return;
}

NX_VOID vNMG_ClrNmgLastErr ( NX_VOID )
{
	gstNET.stErrInfo.usLastErrDetail = (NX_USHORT)NX_ZERO;
	gstNET.stErrInfo.usLastEventCode = (NX_USHORT)NX_ZERO;
	
	return;
}

NX_VOID vNMG_NotifyNmgErr ( NX_VOID )
{
	NX_USHORT	usLoop;
	
	if ( (NX_USHORT)NX_ZERO != gstNET.stErrInfo.usEventCodeDt ) {
		if ((gstNET.stErrInfo.usLastEventCode != gstNET.stErrInfo.usEventCodeDt)
		 || (gstNET.stErrInfo.usLastErrDetail != gstNET.stErrInfo.ausErrDetailDt[0])) {
			vNX_SetEvent(gstNET.stErrInfo.usEventCodeDt, &gstNET.stErrInfo.ausErrDetailDt[0]);
			gstNET.stErrInfo.usLastEventCode = gstNET.stErrInfo.usEventCodeDt;	
			gstNET.stErrInfo.usLastErrDetail = gstNET.stErrInfo.ausErrDetailDt[0];
		}
	}
	else {
		for (usLoop = (NX_USHORT)NX_ZERO; usLoop < NM_CNF_ERRSTS_NUM; usLoop++) {
			if ( (NX_USHORT)NX_ZERO != gstNET.stErrInfo.ausEventCode[usLoop] ) {
				if ((gstNET.stErrInfo.usLastEventCode != gstNET.stErrInfo.ausEventCode[usLoop])
				 || (gstNET.stErrInfo.usLastErrDetail != gstNET.stErrInfo.ausErrDetail[usLoop])) {
					vNX_SetEvent(gstNET.stErrInfo.ausEventCode[usLoop], &gstNET.stErrInfo.ausErrDetail[usLoop]);
					gstNET.stErrInfo.usLastEventCode = gstNET.stErrInfo.ausEventCode[usLoop];	
					gstNET.stErrInfo.usLastErrDetail = gstNET.stErrInfo.ausErrDetail[usLoop];
				}
				break;
			}
		}
	}
	
	return;
}

NX_ULONG vNMG_ChkMacAddrBrdMlt_LtEd (
	NX_UCHAR* puchMacAddr_LtEd
)
{
	NX_ULONG	ulRslt = (NX_ULONG)NX_OFF;
	NX_UCHAR	uchMultiChk;

	uchMultiChk	= puchMacAddr_LtEd[5] & (NX_UCHAR)NX_BIT0;
	
	if ((NX_UCHAR)NX_BIT0 == uchMultiChk) {
		ulRslt = NX_MAC_BRDMLTCAST;
	}
	else {
		ulRslt = NX_MAC_UNICAST;
	}
	
	return ulRslt;
}


/*[EOF]*/
