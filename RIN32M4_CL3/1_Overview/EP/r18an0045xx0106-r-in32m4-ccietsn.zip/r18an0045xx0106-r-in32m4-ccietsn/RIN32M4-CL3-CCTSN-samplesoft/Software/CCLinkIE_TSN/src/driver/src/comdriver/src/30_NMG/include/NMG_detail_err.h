/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef	__NMG_DETAIL_ERR_H_INCLUDED__
#define	__NMG_DETAIL_ERR_H_INCLUDED__



#define	NMG_ERR_CMDTYPE_MSK				(0xFF00)
#define	NMG_ERR_CMDTYPE_NTCMAIN			(0x0100)
#define	NMG_ERR_CMDTYPE_NTCTSLT			(0x0200)
#define	NMG_ERR_CMDTYPE_SRVCNF			(0x0300)
#define	NMG_ERR_CMDTYPE_CYCCNFMAIN		(0x0400)
#define	NMG_ERR_CMDTYPE_CYCCNFTRN		(0x0500)
#define	NMG_ERR_CMDTYPE_CYCCNFRCV		(0x0600)
#define	NMG_ERR_CMDTYPE_CYCCNFSRC		(0x0700)

#define	NMG_IDX_DETECTION_ERR_NUM		(1)
#define	NMG_IDX_NWCFGMAIN_ERR_NUM		(44)
#define	NMG_IDX_NWCFGTSLT_ERR_NUM		(63)
#define	NMG_IDX_SLVCFG_ERR_NUM			(2)
#define	NMG_IDX_CYCCFGMAIN_ERR_NUM		(11)
#define	NMG_IDX_CYCCFGTRNSPD_ERR_NUM	(50)
#define	NMG_IDX_CYCCFGRCVSPD_ERR_NUM	(7)
#define	NMG_IDX_CYCCFGRCVINFO_ERR_NUM	(12)

#define	NMG_IDX_ERR_PARAM_000			(0)
#define	NMG_IDX_ERR_PARAM_001			(1)
#define	NMG_IDX_ERR_PARAM_002			(2)
#define	NMG_IDX_ERR_PARAM_003			(3)
#define	NMG_IDX_ERR_PARAM_004			(4)
#define	NMG_IDX_ERR_PARAM_005			(5)
#define	NMG_IDX_ERR_PARAM_006			(6)
#define	NMG_IDX_ERR_PARAM_007			(7)
#define	NMG_IDX_ERR_PARAM_008			(8)
#define	NMG_IDX_ERR_PARAM_009			(9)
#define	NMG_IDX_ERR_PARAM_010			(10)
#define	NMG_IDX_ERR_PARAM_011			(11)
#define	NMG_IDX_ERR_PARAM_012			(12)
#define	NMG_IDX_ERR_PARAM_013			(13)
#define	NMG_IDX_ERR_PARAM_014			(14)
#define	NMG_IDX_ERR_PARAM_015			(15)
#define	NMG_IDX_ERR_PARAM_016			(16)
#define	NMG_IDX_ERR_PARAM_017			(17)
#define	NMG_IDX_ERR_PARAM_021			(21)
#define	NMG_IDX_ERR_PARAM_022			(22)
#define	NMG_IDX_ERR_PARAM_023			(23)
#define	NMG_IDX_ERR_PARAM_025			(25)
#define	NMG_IDX_ERR_PARAM_026			(26)
#define	NMG_IDX_ERR_PARAM_027			(27)
#define	NMG_IDX_ERR_PARAM_031			(31)
#define	NMG_IDX_ERR_PARAM_032			(32)
#define	NMG_IDX_ERR_PARAM_033			(33)
#define	NMG_IDX_ERR_PARAM_034			(34)
#define	NMG_IDX_ERR_PARAM_035			(35)
#define	NMG_IDX_ERR_PARAM_036			(36)
#define	NMG_IDX_ERR_PARAM_037			(37)
#define	NMG_IDX_ERR_PARAM_039			(39)
#define	NMG_IDX_ERR_PARAM_040			(40)
#define	NMG_IDX_ERR_PARAM_041			(41)
#define	NMG_IDX_ERR_PARAM_043			(43)
#define	NMG_IDX_ERR_PARAM_044			(44)
#define	NMG_IDX_ERR_PARAM_045			(45)
#define	NMG_IDX_ERR_PARAM_049			(49)
#define	NMG_IDX_ERR_PARAM_061			(61)
#define	NMG_IDX_ERR_PARAM_062			(62)

NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_Detection[NMG_IDX_DETECTION_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_NwCfgMain[NMG_IDX_NWCFGMAIN_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_NwCfgTslt[NMG_IDX_NWCFGTSLT_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_SlvCfg[NMG_IDX_SLVCFG_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_CycCfgMain[NMG_IDX_CYCCFGMAIN_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_CYCCFGTRNSPD_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_CYCCFGRCVSPD_ERR_NUM];
NX_EXTERN NX_CONST NX_USHORT DetailErrorTbl_CycCfgRcvInfo[NMG_IDX_CYCCFGRCVINFO_ERR_NUM];


#endif
