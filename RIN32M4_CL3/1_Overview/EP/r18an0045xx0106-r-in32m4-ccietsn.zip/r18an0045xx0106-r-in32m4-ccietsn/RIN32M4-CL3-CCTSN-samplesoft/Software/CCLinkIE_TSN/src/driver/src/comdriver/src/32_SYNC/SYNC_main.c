/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "ccienx_app_supply.h"
#include "SYNC_api.h"
#include "JADE.h"
#include "NGN_ASIC.h"
#include "NMG_api.h"
#include "LSM_api.h"

#define	SET_SYNC_ACT_MARGIN		((NX_ULONGLONG)2000)

#define	SET_SYNCCNT				((NX_ULONG)0x00002001)

#define	SYNC_PULSE_WIDTH		((NX_ULONG)8)
#define	UNIT_8NS				((NX_ULONG)8)
#define	SYNC_OUTPUT_CYCLE		((NX_ULONG)2)
#define	LIMIT_SYNC_CYCLE		((NX_ULONGLONG)1000000000)

typedef struct tagSYNC_CTRL {
	NX_ULONGLONG	ullSyncCycle;
	NX_ULONG		ulSyncInterval;
	NX_USHORT		usBitPtnEnBit;
	NX_USHORT		usBitPtn;
	NX_USHORT		usSyncStatus;
	NX_USHORT		usAppSyncStopSts;
} SYNC_CTRL;

NX_STATIC	SYNC_CTRL	gstSyncCtrl;


NX_VOID vSYNC_Init (NX_VOID)
{
	vNX_FillMemory32(&gstSyncCtrl, NX_ZERO, (sizeof(SYNC_CTRL) / sizeof(NX_ULONG)));

	return;
}

NX_VOID vSYNC_SetSyncInit (NX_VOID)
{
	NX_JADE_SYS->R_SYNCCNT	= SET_SYNCCNT;

	return;
}

NX_USHORT usSYNC_SyncPreSetting (
	NX_USHORT usCount
)
{
	NX_USHORT		usRet				= SYNC_PRESET_CORRECT_NG;
	NX_ULONGLONG	ullComCycle			= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullCalcSyncTime		= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usCorrectRet		= NX_US_NG;
	NX_USHORT		usBitPtnEnBit		= NX_US_ZERO;
	NX_USHORT		usBitPtn			= NX_US_ZERO;

	ullComCycle		= ullNMG_GetComCycle();

	ullCalcSyncTime	= ullComCycle * usCount;

	if (ullCalcSyncTime <= LIMIT_SYNC_CYCLE ) {

		usCorrectRet	= usNMG_GetRemainderBitPattern(	ullCalcSyncTime,
														&usBitPtnEnBit,
														&usBitPtn
														);

		if (usCorrectRet == NX_US_OK) {
			gstSyncCtrl.ullSyncCycle	= ullCalcSyncTime;
			gstSyncCtrl.ulSyncInterval	= (NX_ULONG)(ullCalcSyncTime / UNIT_8NS);
			gstSyncCtrl.usBitPtnEnBit	= usBitPtnEnBit;
			gstSyncCtrl.usBitPtn		= usBitPtn;

			usRet	= SYNC_PRESET_OK;
		}
		else {
			usRet	= SYNC_PRESET_CORRECT_NG;
		}
	}
	else {
		usRet	= SYNC_PRESET_RANGE_NG;
	}

	return usRet;
}

NX_USHORT usSYNC_AppSyncSigSetting (NX_VOID)
{
	NX_USHORT		usRet				= SYNC_SIGSET_TIMENG_ERR;
	NX_ULONG		ulTimeCnt_s			= (NX_ULONG)NX_ZERO;
	NX_ULONG		ulTimeCnt_ns		= (NX_ULONG)NX_ZERO;
	NX_ULONG		ulSyncTime_s		= (NX_ULONG)NX_ZERO;
	NX_ULONG		ulSyncTime_ns		= (NX_ULONG)NX_ZERO;
	NX_ULONGLONG	ullSyncTime			= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullSyncSetCmpTime	= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usLinkSpdSta 		= NX_LINKSPD_STA_1G;
	NX_ULONGLONG	ullCycCnt			= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullCalcComStTime	= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usRptCnt			= NX_US_ZERO;
	NX_USHORT		usSwTmg				= NX_US_ZERO;
	NX_ULONGLONG	ullComCycle			= (NX_ULONGLONG)NX_ZERO;
	NX_USHORT		usCalcTmg			= NX_US_ZERO;

	if (gstSyncCtrl.usAppSyncStopSts == (NX_USHORT)NX_ON) {
		vNX_NotifyAppSyncSigEnable (NX_APPSYNCSIG_DS);
		return SYNC_SIGSET_STOP_ERR;
	}

	vNMG_GetSendCycle(&usRptCnt, &usSwTmg);
	ullComCycle		= ullNMG_GetComCycle();
	usLinkSpdSta	= usLSM_GetLinkSpd();

	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_1G) {
		ullCycCnt	= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSC0 << NX_SHIFT32;
		ullCycCnt	|= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSC1;
	}
	else {
		ullCycCnt	= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSSC0 << NX_SHIFT32;
		ullCycCnt	|= (NX_ULONGLONG)NGN_CN_TS_P1_REG->R_TCPXSSC1;
	}

	usCalcTmg	= (NX_USHORT)(ullCycCnt % usRptCnt);

	ullCalcComStTime	= ullComCycle * (ullCycCnt - usCalcTmg);

	ullSyncTime			= ullCalcComStTime + (gstSyncCtrl.ullSyncCycle * SYNC_OUTPUT_CYCLE);

	ulSyncTime_s	= (NX_ULONG)(ullSyncTime / NX_DIV_NSTOS);
	ulSyncTime_ns	= (NX_ULONG)(ullSyncTime % NX_DIV_NSTOS);

	NGN_SN_REG->R_SNSY1CTR.DATA	= (NX_ULONG)NX_ON;
	NGN_SN_REG->R_SNSY1OT0		= ulSyncTime_ns;
	NGN_SN_REG->R_SNSY1OT1		= ulSyncTime_s;
	NGN_SN_REG->R_SNSY1OI0.DATA	= gstSyncCtrl.ulSyncInterval;
	NGN_SN_REG->R_SNSY1OW		= SYNC_PULSE_WIDTH;

	NGN_SN_REG->R_SNREVICE.DATA			= (NX_ULONG)gstSyncCtrl.usBitPtn;
	NGN_SN_REG->R_SNREVICE_BPSEL.DATA	= (NX_ULONG)gstSyncCtrl.usBitPtnEnBit;
	NGN_SN_REG->R_SNREVICE_RST.DATA		= (NX_ULONG)NX_ON;

	ulTimeCnt_ns	= NGN_SN_REG->R_SNTM0;
	ulTimeCnt_s		= NGN_SN_REG->R_SNTM1;

	ullSyncSetCmpTime	= ((NX_ULONGLONG)ulTimeCnt_s * NX_NSEC_1000000000) + ((NX_ULONGLONG)ulTimeCnt_ns + SET_SYNC_ACT_MARGIN);

	if (ullSyncSetCmpTime < ullSyncTime) {
		NGN_SN_REG->R_SNSY1UPD.DATA		= (NX_ULONG)NX_ON;

		gstSyncCtrl.usSyncStatus		= (NX_USHORT)NX_ON;

		usRet	= SYNC_SIGSET_OK;
	}
	else {
		usRet	= SYNC_SIGSET_TIMENG_ERR;
	}

	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();

	if ( SYNC_SIGSET_OK == usRet ) {
		vNX_NotifyAppSyncSigEnable (NX_APPSYNCSIG_EN);
	}
	return usRet;
}

NX_VOID vSYNC_AppSyncSigClear (NX_VOID)
{
	gstSyncCtrl.usSyncStatus		= (NX_USHORT)NX_OFF;

	NGN_SN_REG->R_SNSY1CTR.DATA		= (NX_ULONG)NX_OFF;
	NGN_SN_REG->R_SNSY1UPD.DATA		= (NX_ULONG)NX_ON;

	return;
}

NX_USHORT usNX_StopAppSyncSig (NX_VOID)
{
	NX_USHORT	usRet	= NX_US_NG;

	if (gstSyncCtrl.usSyncStatus == (NX_USHORT)NX_ON) {
		vSYNC_AppSyncSigClear();
		gstSyncCtrl.usAppSyncStopSts = (NX_USHORT)NX_ON;
		usRet	= NX_US_OK;
	}
	else {
		usRet	= NX_US_NG;
	}

	return usRet;
}


