/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#include "nx_common.h"
#include "LOG_api.h"
#include "ccienx_api.h"

#if TSN_LOG_ADJUST

typedef struct ADJUSTLOG_ADJUST2_TAG {
	NX_ULONGLONG	ullResult;
	NX_LONGLONG		llOffsetHighestByte;
	NX_LONGLONG		llOffset;
	NX_ULONGLONG	ullFreqRate;
	NX_ULONGLONG	ullPriDomainNumber;
	NX_ULONGLONG	ullDomainNumber;
	NX_ULONGLONG	ullDelay;
} ADJUSTLOG_ADJUST2;

typedef struct ADJUSTLOG_AVERAGEPROC_TAG {
	NX_ULONGLONG	ullResult;
	NX_ULONGLONG	ullLatestSyncReceiveFreerunCounter;
	NX_ULONGLONG	ullLatestSyncReceiveTime;
	NX_ULONGLONG	ullLatestSyncSend;
	NX_ULONGLONG	ullSyncOriginTimeStamp;
	NX_ULONGLONG	ullCorrectionField;
} ADJUSTLOG_AVERAGEPROC;

typedef struct ADJUSTLOG_ADJUSTTIME_ONCE_TAG {
	NX_ULONGLONG	ullAsicSet_FrnCnt;
	NX_ULONGLONG	ullAsicSet_Time;
} ADJUSTLOG_ADJUSTTIME_ONCE;

typedef struct ADJUSTLOG_ADJUSTTIME_AVE_TAG {
	NX_ULONGLONG	ullAveSyncSend;
	NX_ULONGLONG	ullAveNeighborPropDelay;
	NX_ULONGLONG	ullAveSyncReceive_Frun;
	NX_ULONGLONG	ullAveFreqRate;
	NX_ULONGLONG	ullWindowCheck;
	NX_LONGLONG		llOffsetRaw;
	NX_LONGLONG		llOffsetWindow;
	NX_ULONGLONG	ullAsicSet_FrnCnt;
	NX_ULONGLONG	ullAsicSet_Time;
} ADJUSTLOG_ADJUSTTIME_AVE;

typedef struct ADJUSTLOG_RECORD_TAG {
	ADJUSTLOG_ADJUST2				stUserAdjust2;
	ADJUSTLOG_ADJUSTTIME_ONCE		stAdjustOnce;
	ADJUSTLOG_AVERAGEPROC			stAverageProc;
	ADJUSTLOG_ADJUSTTIME_AVE		stAdjustAve;
} ADJUSTLOG_RECORD;

typedef struct ADJUSTLOG_AREA_TAG {
	NX_ULONGLONG		ullLogExec;
	NX_ULONGLONG		ullLogStopReq;
	NX_ULONGLONG		ullLogStopRemainTimes;
	NX_ULONGLONG		ullNowWriteIndex;
	NX_ULONGLONG		ullRecordNum;
	NX_ULONGLONG		ullOffsetMax;
	ADJUSTLOG_RECORD	astReccord[ADJUSTLOG_RECORD_SIZE];
} ADJUSTLOG_AREA;








#endif
