/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_SYNC_COM_L_H_INCLUDED__
#define __ST_SNC_SYNC_COM_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_stk_l.h"
#include <Windows.h>
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_stk_l.h>
#else
#include "ST_SNC_stk_l.h"
#endif
#endif

#define ST_SNC_PIPE_CHECK_LEN		(8)
#define ST_SNC_PMSG_SET_SV			(0x10)
#define ST_SNC_PMSG_SET_CL			(0x20)
#define ST_SNC_PMSG_TYPE_START		(0x01)
#define ST_SNC_PMSG_TYPE_STOP		(0x02)
#define ST_SNC_PMSG_TYPE_MIBSET		(0x03)
#ifdef SWPS
#define ST_SNC_PMSG_TYPE_LLDPMIBSET	(0x04)
#endif
#define ST_SNC_PMSG_TYPE_MIBDEL		(0x05)
#define ST_SNC_PMSG_TYPE_MIBCOMMIT	(0x06)
#define ST_SNC_PMSG_TYPE_MASK		(0x0F)
#define ST_SNC_PMSG_TYPE_DUMY		(0x00)
#define ST_SNC_PMSG_CLMIBSET		(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_MIBSET)
#ifdef SWPS
#define ST_SNC_PMSG_CLLLDPMIBSET	(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_LLDPMIBSET)
#endif
#define ST_SNC_PMSG_CLMIBDEL		(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_MIBDEL)
#define ST_SNC_PMSG_CLMIBCOMMIT		(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_MIBCOMMIT)

#ifdef SWPS
typedef struct ST_SNC_PMSG_HEADER_TAG {
	CHAR				acCheck[ST_SNC_PIPE_CHECK_LEN];
	USHORT				usType;
	USHORT				usPadding;
	ST_SNC_MibMng		stMng;
	ULONG				ulMsgSize;
} ST_SNC_PmsgHeader;


extern VOID ST_SNC_SetSecAttr(SECURITY_DESCRIPTOR* pstDesc, SECURITY_ATTRIBUTES* pstAttr);

extern ULONG ulST_SNC_WrapperCreateMutex(LPCTSTR lpName, LPHANDLE lpHandle, LPDWORD pdwError);

extern ULONG ulST_SNC_CheckHeader(const ST_SNC_PmsgHeader *pstHeader, USHORT usSettingType, USHORT usMessageType, USHORT usOidmap);
#endif

#endif
