/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#include "PortAnnounceInformationExtSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortStateSelectionSM.h"

#include "PTP_GlobalData.h"

#define D_FUNC	0
#define D_VALID	0

static BOOL isBetterDomain( CLOCKDATA* pstDomain1, CLOCKDATA* pstDomain2 );

VOID (*const PortAnnoInfExtSM_Matrix[PAIEXTSM_ST_MAX][PAIEXTSM_EV_MAX] )(PORTDATA * pstPortData) =
{

	{&PortAnnounceInfoExt_01, &PortAnnounceInfoExt_nop, &PortAnnounceInfoExt_00, &PortAnnounceInfoExt_nop},
	{&PortAnnounceInfoExt_01, &PortAnnounceInfoExt_02,	&PortAnnounceInfoExt_00, &updtPortState},
	{&PortAnnounceInfoExt_01, &PortAnnounceInfoExt_02,	&PortAnnounceInfoExt_00, &updtPortState}
};

VOID	portAnnounceInformationExtSM(USHORT usEvent, PORTDATA *pstPort)
{
	PAIEXTSM_GD*	pstSMGlb;
	PAIEXTSM_EV		enEvt;

	pstSMGlb = &(pstPort->stPAIExtSM_GD);

	enEvt =	GetportAnnAnnInfExtEvt(usEvent);

	if (enEvt < PIEX_EV_EVENT_MAX)
	{
		if (pstSMGlb->enStatus < PIEXSM_STATUS_MAX)
		{
			(*PortAnnoInfExtSM_Matrix[pstSMGlb->enStatus][enEvt])(pstPort);
			return;
		}
	}
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONEXTSM, (ULONG)PTP_LOGVE_81000003);
	return;
}

PAIEXTSM_EV	GetportAnnAnnInfExtEvt(USHORT usEvent)
{
	PAIEXTSM_EV		enEvt;
	switch (usEvent)
	{
		case (USHORT)PTP_EV_BEGIN:
			enEvt = PIEX_EV_BEGIN;
			break;
		case (USHORT)PTP_EV_RCVDANNOUNCE:
			enEvt = PIEX_EV_RCVDANNOUNCE;
			break;
		case (USHORT)PTP_EV_CLOSE:
			enEvt = PIEX_EV_CLOSE;
			break;
		case (USHORT)PTP_EV_ASCAPABLE:
			enEvt = PIEX_EV_ASCAPABLE;
			break;
		default:
			enEvt = PIEX_EV_EVENT_MAX;
		break;
	}
	return(enEvt);
}


static BOOL isBetterDomain( CLOCKDATA* pstDomain1, CLOCKDATA* pstDomain2 )
{
	INT nRet;
	
	nRet = (INT)pstDomain1->stParentDS.uchGrandmasterPriority1 - (INT)pstDomain2->stParentDS.uchGrandmasterPriority1;
	if ( nRet != 0 )
	{
		if( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}
	nRet = tsn_Wrapper_MemCmp( (VOID *)&pstDomain1->stParentDS.stGrandmasterClockQuality,
							   (VOID *)&pstDomain2->stParentDS.stGrandmasterClockQuality,
							   sizeof(CLOCKQUALITY) );
	if ( nRet != 0 )
	{
		if( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}
	nRet = (INT)pstDomain1->stParentDS.uchGrandmasterPriority2 - (INT)pstDomain2->stParentDS.uchGrandmasterPriority2;
	if ( nRet != 0 )
	{
		if( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}
	nRet = tsn_Wrapper_MemCmp( (VOID *)&pstDomain1->stParentDS.stGrandmasterIdentity,
							   (VOID *)&pstDomain2->stParentDS.stGrandmasterIdentity,
							   sizeof(CLOCKIDENTITY) );
	if ( nRet != 0 )
	{
		if ( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}
	nRet = (INT)pstDomain1->stCurrentDS.usStepsRemoved - (INT)pstDomain2->stCurrentDS.usStepsRemoved;
	if ( nRet != 0 )
	{
		if ( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}
	nRet = tsn_Wrapper_MemCmp( (VOID *)&pstDomain1->stParentDS.stParentPortIdentity,
							   (VOID *)&pstDomain2->stParentDS.stParentPortIdentity,
							   sizeof(PORTIDENTITY) );
	if ( nRet != 0 )
	{
		if ( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}

	nRet = (INT)pstDomain1->stDefaultDS.uchDomainNumber - (INT)pstDomain2->stDefaultDS.uchDomainNumber;
	if ( nRet != 0 )
	{
		if ( nRet > 0 )
		{
			return TRUE;
		}
		return FALSE;
	}

	return FALSE;
}
VOID selBestDomain( VOID )
{
	
	CLOCKDATA*	pstDomain;
	CLOCKDATA*	pstBestDomain;
	BOOL blRet;

	ptp_dbg_msg( D_FUNC, ("selBestDomain::+\n") );
	
	if ( gpstClockDataHPtr == NULL )
	{
		return ;
	}
	pstBestDomain = gpstClockDataHPtr;
	
	for ( pstDomain  = pstBestDomain->pstNextClockDataPtr;
		  pstDomain != NULL;
		  pstDomain  = pstDomain->pstNextClockDataPtr )
	{
		blRet = isBetterDomain( pstBestDomain, pstDomain );
		if ( blRet == TRUE )
		{
			pstBestDomain = pstDomain;
		}
	}

	gpstBestDomain = pstBestDomain;

	ptp_dbg_msg( D_FUNC, ("selBestDomain::-\n") );
	
	return ;
}

VOID	PortAnnounceInfoExt_00(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAIEXTSM_GD	*pstSMGlb;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PortAnnounceInfoExt_00+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAIExtSM_GD);

	pstSMGlb->blRcvdAnnounce = FALSE;
	pstPortBmcGd->enInfoIs = DISABLED;
	pstPortBmcGd->blUpdtInfo = FALSE;

	pstSMGlb->enStatus = PIEXSM_NONE;

	updtPortState(pstPort);

	selBestDomain( );


	ptp_dbg_msg( D_FUNC, ("PortAnnounceInfoExt_00::-\n") );

	return;
}

VOID	PortAnnounceInfoExt_01(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAIEXTSM_GD	*pstSMGlb;

	pstPortBmcGd = &(pstPort->stPortBMC_GD);
	pstSMGlb	 = &(pstPort->stPAIExtSM_GD);

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInfoExt_01::+\n") );

	if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == TRUE)
	{

		pstSMGlb->blRcvdAnnounce = FALSE;
		pstPortBmcGd->enInfoIs = DISABLED;
		pstPortBmcGd->blUpdtInfo = FALSE;

		pstSMGlb->enStatus = PIEXSM_INITIALIZE;

		makeSystemPrioVector(pstPort);
		updtPortState(pstPort);

		selBestDomain( );

	}

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInfoExt_01::-\n") );

	return;
}

VOID	PortAnnounceInfoExt_02(PORTDATA *pstPort)
{
	PORTBMC_GD	*pstPortBmcGd;
	PAIEXTSM_GD*	pstSMGlb;
	USHORT		usPortNumber;
	PORTDATA*	pstPortWork;

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInfoExt_02::+\n") );

	pstSMGlb = &(pstPort->stPAIExtSM_GD);

	pstPortBmcGd = &(pstPort->stPortBMC_GD);

	rcvInfoExt(pstPort);
	pstSMGlb->blRcvdAnnounce = TRUE;

	recordOtherAnnounceInfo(&(pstPort->stPortBMC_GD));

	pstPortBmcGd->usPortStepsRemoved = pstPort->stPortBMC_GD.pstRcvdAnnouncePtr->usStepsRemoved +1U;

	usPortNumber   = pstPort->stPortDS.stPortIdentity.usPortNumber;
	if (pstPort->pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_PASSIVE)
	{
		if(pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
		{
			tsn_Wrapper_MemCpy(&pstPort->pstClockData->stBMC_GD.stGmPriority, &(pstPort->stPAIExtSM_GD.stMessagePriority), sizeof(PRIORITY_VECT));
			pstPortWork  = pstPort->pstClockData->pstPortData;
			while (pstPortWork != NULL)
			{
				if (pstPortWork->stPort_GD.blPortValid == TRUE)
				{
					tsn_Wrapper_MemCpy( (VOID *)&pstPortWork->stPortBMC_GD.stMasterPriority, 
					                    (VOID *)&pstPort->pstClockData->stBMC_GD.stGmPriority, 
					                    sizeof(PRIORITY_VECT) );
					tsn_Wrapper_MemCpy( (VOID *)&pstPortWork->stPortBMC_GD.stMasterPriority.stSourcePortIdentity, 
										(VOID *)&pstPortWork->stPortDS.stPortIdentity, 
										sizeof(PORTIDENTITY) );
				}
				pstPortWork = pstPortWork->pstNextPortDataPtr;
			}
			pstPort->pstClockData->stBMC_GD.usMasterStepsRemoved = pstPortBmcGd->usPortStepsRemoved;

			updateDsForslaveAS(pstPort);
		}
		else
		{
		}
	}
	else
	{
		if(pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_PASSIVE)
		{
			updateDsForGrandMasterAS(pstPort->pstClockData);
		}
		else
		{
		}
	}

	pstSMGlb->enStatus = PIEXSM_RECEIVE;

	selBestDomain( );

	ptp_dbg_msg( D_FUNC, ("PortAnnounceInfoExt_02::-\n") );

	return;
}

VOID	rcvInfoExt(PORTDATA *pstPort)
{
	PTPMSG_ANNOUNCE	*pstMsgAnnounce;
	BMC_GD		*pstBmcGd;
	PORTBMC_GD	*pstPortBmcGd;
	PORT_DS		*pstPortDs;
	CLOCK_GD	*pstClockGd;
	PTPMSG_ANNOUNCE_TLV *pstAnnounceTlv;
	USHORT		usPortNumber;
	USHORT		usTlvCnt;
	PAIEXTSM_GD*	pstSMGlb;

	pstSMGlb = &(pstPort->stPAIExtSM_GD);

	pstPortBmcGd   = &(pstPort->stPortBMC_GD);
	usPortNumber   = pstPort->stPortDS.stPortIdentity.usPortNumber;
	pstClockGd	   = &(pstPort->pstClockData->stClock_GD);
	pstMsgAnnounce = pstPortBmcGd->pstRcvdAnnouncePtr;
	pstPortDs	   = &(pstPort->stPortDS);
	pstBmcGd 	   = &(pstPort->pstClockData->stBMC_GD);


	makeMessagePriorityVector (pstMsgAnnounce, usPortNumber, &pstSMGlb->stMessagePriority);


	pstAnnounceTlv = &(pstMsgAnnounce->stAnnounce_TLV);

	if ((pstAnnounceTlv->usLengthField >= sizeof(CLOCKIDENTITY)))

	{
		if (pstClockGd->enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
		{
			usTlvCnt = pstAnnounceTlv->usLengthField / sizeof(CLOCKIDENTITY);
			tsn_Wrapper_MemCpy(&pstBmcGd->stPathTrace[0], &pstAnnounceTlv->stPathSequence[0], (size_t)(usTlvCnt*sizeof(CLOCKIDENTITY)));

			tsn_Wrapper_MemCpy(&pstBmcGd->stPathTrace[usTlvCnt], &pstPortDs->stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
			pstBmcGd->uchPathTraceCount = (UCHAR)(usTlvCnt+(USHORT)1);
		}
	}
}

VOID	PortAnnounceInfoExt_nop(PORTDATA *pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PAINFORMATIONEXTSM, (ULONG)PTP_LOGVE_81000005);
	return;
}

VOID	updtPortState(PORTDATA *pstPort)
{
	PORTDATA*	pstPortWork;
	PORTDATA*	pstPortSlave;
	BMC_GD*		pstBmcGd;
	CLOCKPROTO	enClockPtpProtcol;
	USHORT		usPortNumber;
	BOOL		blGmEqSystem;
	BMC_1588_GD	*pstBmc1588Gd;
	PAIEXTSM_GD*	pstSMGlb;
	PRIORITY_VECT *pstVector;

	pstSMGlb = &(pstPort->stPAIExtSM_GD);
	pstBmcGd = &(pstPort->pstClockData->stBMC_GD);
	pstBmc1588Gd = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);

	pstPortWork  = pstPort->pstClockData->pstPortData;
	pstPortSlave = NULL;

	enClockPtpProtcol = (CLOCKPROTO)pstPort->pstClockData->stClock_GD.enSupportPTPType;
	pstPort->pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_SLAVE;



	pstPortWork  = pstPort->pstClockData->pstPortData;
	while (pstPortWork != NULL)
	{
		if ( pstPortWork->stPort_GD.blPortValid == TRUE )
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;
			pstSMGlb = &(pstPortWork->stPAIExtSM_GD);

			if ((pstPortWork->stPort_1AS_DS.blAsCapable == FALSE) ||
				(pstPortWork->stPort_1AS_DS.blPtpPortEnabled == FALSE) ||
					(pstPortWork->stPort_GD.blPortOper == FALSE))
			{
				pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] = ENUM_PORTSTATE_DISABLED;
				if (enClockPtpProtcol == (CLOCKPROTO)ENUM_SUPPORTPTPTYPE_IEEE1588)
				{
#ifdef	PTP_USE_IEEE1588
					pstBmc1588Gd->uchExtSelectedState[usPortNumber] = DisabledPort;
#endif
				}
			}
			else if (pstPortWork->stPort_GD.blAsymmetryMeasurementMode == TRUE)
			{
				pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] = ENUM_PORTSTATE_PASSIVE;
				if (enClockPtpProtcol == (CLOCKPROTO)ENUM_SUPPORTPTPTYPE_IEEE1588)
				{
#ifdef	PTP_USE_IEEE1588
					pstBmc1588Gd->uchExtSelectedState[usPortNumber] = PassivePort;
#endif
				}
			}
			else
			{
				pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] = pstSMGlb->enPortStateInd;
				if (enClockPtpProtcol == (CLOCKPROTO)ENUM_SUPPORTPTPTYPE_IEEE1588)
				{
#ifdef	PTP_USE_IEEE1588
				pstBmc1588Gd->uchExtSelectedState[usPortNumber] = pstSMGlb->enPortStateInd;
#endif
				}
			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}
	pstPortWork  = pstPort->pstClockData->pstPortData;

	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(port0 SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

			if (pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
			{
				pstPort->pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_PASSIVE;
				pstPortSlave = pstPortWork;
				break;
			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}
	if (pstPortSlave != NULL)
	{
		pstBmcGd->blLeap61 = pstPortSlave->stPortBMC_GD.blAnnLeap61;
		pstBmcGd->blLeap59 = pstPortSlave->stPortBMC_GD.blAnnLeap59;
		pstBmcGd->blCurrentUtcOffsetValid = pstPortSlave->stPortBMC_GD.blAnnCurrentUtcOffsetValid;
		pstBmcGd->blPtpTimescale = pstPortSlave->stPortBMC_GD.blAnnPtpTimescale;
		pstBmcGd->blTimeTraceable = pstPortSlave->stPortBMC_GD.blAnnTimeTraceable;
		pstBmcGd->blFrequencyTraceable = pstPortSlave->stPortBMC_GD.blAnnFrequencyTraceable;
		pstBmcGd->sCurrentUtcOffset = pstPortSlave->stPortBMC_GD.sAnnCurrentUtcOffset;
		pstBmcGd->uchTimeSource = pstPortSlave->stPortBMC_GD.uchAnnTimeSource;

		pstBmcGd->usMasterStepsRemoved = pstPortSlave->stPortBMC_GD.usPortStepsRemoved;

		blGmEqSystem = FALSE;
	}
	else
	{
		pstBmcGd->blLeap61 = pstPort->pstClockData->stBMC_GD.blSysLeap61;
		pstBmcGd->blLeap59 = pstPort->pstClockData->stBMC_GD.blSysLeap59;
		pstBmcGd->blCurrentUtcOffsetValid = pstPort->pstClockData->stBMC_GD.blSysCurrentUTCOffsetValid;
		pstBmcGd->blPtpTimescale = pstPort->pstClockData->stBMC_GD.blSysPtpTimescale;
		pstBmcGd->blTimeTraceable = pstPort->pstClockData->stBMC_GD.blSysTimeTraceable;
		pstBmcGd->blFrequencyTraceable = pstPort->pstClockData->stBMC_GD.blSysFrequencyTraceable;
		pstBmcGd->sCurrentUtcOffset = pstPort->pstClockData->stBMC_GD.sSysCurrentUtcOffset;
		pstBmcGd->uchTimeSource = pstPort->pstClockData->stBMC_GD.uchSysTimeSource;

		pstBmcGd->usMasterStepsRemoved = 0U;

		blGmEqSystem = TRUE;
	}

	if(blGmEqSystem == FALSE)
	{
		if(pstPortSlave->stPAInformationSM_GD.stMessagePriority.stRootSystemIdentity.uchPriority1 < 255U)
		{
#ifdef	PTP_USE_IEEE802_1
			pstPortSlave->pstClockData->stClock_GD.blGmPresent = TRUE;
#endif
		}
		else
		{
#ifdef	PTP_USE_IEEE802_1
			pstPortSlave->pstClockData->stClock_GD.blGmPresent = FALSE;
#endif
		}
		if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
		{
#ifdef	PTP_USE_IEEE1588
			updateDsForslave(pstPort->pstClockData);
#endif
		}
		else
		{
#ifdef	PTP_USE_IEEE802_1
			updateDsForslaveAS(pstPort);
#endif
		}
	}
	else
	{
		if (pstPort->pstClockData->stBMC_GD.stSystemPriority.stRootSystemIdentity.uchPriority1 < 255U)
		{
			pstPort->pstClockData->stClock_GD.blGmPresent = TRUE;
		}
		else
		{
			pstPort->pstClockData->stClock_GD.blGmPresent = FALSE;
		}
		if(pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
		{
#ifdef	PTP_USE_IEEE1588
			updateDsForGrandMaster(pstPort->pstClockData);
#endif
		}
		else
		{
#ifdef	PTP_USE_IEEE802_1
			updateDsForGrandMasterAS(pstPort->pstClockData);
#endif
		}
	}



	pstVector = &pstBmcGd->stSystemPriority;

	for( pstPortWork  = pstPort->pstClockData->pstPortData; 
		 pstPortWork != NULL ;
		 pstPortWork  = pstPortWork->pstNextPortDataPtr )
	{
		if ( pstPortWork->stPort_GD.blPortValid == TRUE )
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(gmPriorityVector). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;
			if ( pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE )
			{
				if ( pstSMGlb->blRcvdAnnounce == TRUE )	
				{
					pstVector = &pstPortWork->stPAInformationSM_GD.stMessagePriority;
				}
				break;
			}
		}
	}
	tsn_Wrapper_MemCpy( &pstBmcGd->stGmPriority, pstVector, sizeof(PRIORITY_VECT) );


	pstPortWork  = pstPort->pstClockData->pstPortData;
	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(masterPriorityVector). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			tsn_Wrapper_MemCpy (&pstPortWork->stPortBMC_GD.stMasterPriority, &pstBmcGd->stGmPriority, sizeof(PRIORITY_VECT));
			tsn_Wrapper_MemCpy(&pstPortWork->stPortBMC_GD.stMasterPriority.stSourcePortIdentity, &pstPortWork->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	if ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS) ||
		 ((pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588) &&
		 	(pstBmcGd->blPathTraceEnable)))
	{
		if (pstPort->pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)
		{
			tsn_Wrapper_MemCpy(&pstBmcGd->stPathTrace[0], &pstPort->stPortDS.stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
			pstBmcGd->uchPathTraceCount = (UCHAR)1;
		}
	}
	
}
