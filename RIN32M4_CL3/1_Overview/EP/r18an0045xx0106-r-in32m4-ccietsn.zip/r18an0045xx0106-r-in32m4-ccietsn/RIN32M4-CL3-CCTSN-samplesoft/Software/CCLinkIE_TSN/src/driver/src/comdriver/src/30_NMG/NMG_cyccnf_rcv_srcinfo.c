/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_api.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_cyclicconfig_rcv_src_info.h"
#include "SLMP_api.h"
#include "nx_frame_notification.h"
#include "NGN_ASIC.h"
#include "ACM_api.h"
#include "ccienx_app_supply.h"

#define	SRC_TARGET_ADD_CHK		((NX_USHORT)2)
#define	SRC_FRMTYPE_CHK			((NX_UCHAR)0x0)
#define	ASIC_RRNFLGADN_SIZE		((NX_USHORT)8)

NX_VOID		vNMG_ChkCyclicConfigRcvSrcInfoReq ( FRM_CC_RCV_SRC_INFO_REQ*, NX_ULONG*, NX_ULONG );
NX_ULONG	ulNMG_ChkRangeCycCfgRcvReq ( FRM_CC_RCV_SRC_INFO_REQ* );
NX_VOID		vNMG_Extract_CycCfgRcvReq ( FRM_CC_RCV_SRC_INFO_REQ* );
NX_VOID		vNMG_CreateCycCfgRcvRespNrml ( FRM_CC_RCV_SRC_INFO_REQ* );
NX_VOID		vNMG_CreateCycCfgRcvRespFault ( FRM_CC_RCV_SRC_INFO_REQ*, NX_USHORT );
NX_VOID		vNMG_TrnsStsRcvCycCfgRcvReq ( NX_VOID );

NX_VOID vNMG_AnalyzeCycCfgRcvReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_CC_RCV_SRC_INFO_REQ	*pstFrm;
	NX_ULONG				ulChkResult		= NX_ZERO;

	pstFrm = (FRM_CC_RCV_SRC_INFO_REQ*)pData;

	vNMG_ChkCyclicConfigRcvSrcInfoReq(pstFrm, &ulChkResult, ulIPAddress);

	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_CycCfgRcvReq(pstFrm);

		vNMG_CreateCycCfgRcvRespNrml(pstFrm);
		vNMG_ReqTrnCycCfgRcvResp();

		vNMG_TrnsStsRcvCycCfgRcvReq();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateCycCfgRcvRespFault(pstFrm, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnCycCfgRcvResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateCycCfgRcvRespFault(pstFrm, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnCycCfgRcvResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}

	return;
}

NX_VOID vNMG_ChkCyclicConfigRcvSrcInfoReq (
	FRM_CC_RCV_SRC_INFO_REQ	*pstFrm,
	NX_ULONG				*pulChkResult,
	NX_ULONG				ulIPAddress
)
{
	NX_ULONG	ulRangeChkResult	= NX_UL_NG;

	if (ulIPAddress == gstNET.stCtrlMst.ulIPAddress) {
		if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
			(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
			(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
			if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
				*pulChkResult	= RESP_DIV_ERR;
			}
			else {
				*pulChkResult = RESP_DESTRUCT;
			}
		}
		else {
			ulRangeChkResult = ulNMG_ChkRangeCycCfgRcvReq(pstFrm);

			if (NX_UL_OK == ulRangeChkResult) {
				*pulChkResult	= RESP_NORMAL;
			}
			else {
				*pulChkResult	= RESP_ERR;
			}
		}
	}
	else {
		*pulChkResult	= RESP_ERR;
	}

	return;
}

NX_ULONG ulNMG_ChkRangeCycCfgRcvReq (
	FRM_CC_RCV_SRC_INFO_REQ	*pstFrm
)
{
	NX_ULONG			ulRangeChkResult	= NX_UL_NG;
	NX_USHORT			usAddrCntLoop		= NX_ZERO;
	NX_ULONG			ulAddrTargetInfo	= NX_ZERO;
	RCV_TARGET_INFO*	pstTargetInfo;
	NX_ULONG			ulRespRslt;
	
	ulRespRslt = ulNX_ChkCyclicConfigResp(gstNET.stApp.usSyncMode,gstNM.stSlaveConfig.usWdcFuncSts);

	if (SRC_TARGET_ADD_CHK <= pstFrm->usRcvTargetInfoNum) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvInfo[NMG_IDX_ERR_PARAM_001]);
		return NX_UL_NG;
	}

	ulAddrTargetInfo	= (NX_ULONG)pstFrm + sizeof(FRM_CC_RCV_SRC_INFO_REQ);
	pstTargetInfo		= (RCV_TARGET_INFO*)ulAddrTargetInfo;

	if (SRC_FRMTYPE_CHK != pstTargetInfo->stFrmSubPayloadSetting.uchData) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvInfo[NMG_IDX_ERR_PARAM_006]);
		ulRangeChkResult = NX_UL_NG;
	}
	else {
		ulRangeChkResult = NX_UL_OK;
	}
	
	if (NX_UL_OK == ulRangeChkResult) {
		if (NX_UL_NG == ulRespRslt) {
			return NX_UL_NG;
		}
	}
	
	return ulRangeChkResult;
}

NX_VOID vNMG_Extract_CycCfgRcvReq (
	FRM_CC_RCV_SRC_INFO_REQ	*pstFrm
)
{
	NX_USHORT			usLoop				= NX_ZERO;
	NX_ULONG			ulAddrTargetInfo	= NX_ZERO;
	RCV_TARGET_INFO*	pstTargetInfo;

	ulAddrTargetInfo	= (NX_ULONG)pstFrm + sizeof(FRM_CC_RCV_SRC_INFO_REQ);
	pstTargetInfo		= (RCV_TARGET_INFO*)ulAddrTargetInfo;



	for (usLoop = NX_ZERO; usLoop < pstFrm->usRcvTargetInfoNum; usLoop++) {
		NGN_RN->astR_RNFLGAD[usLoop].BITS.b10ZRnflgAddr = ((NX_ULONG)pstTargetInfo->uchSrcIpAddr3 << (NX_ULONG)NX_SHIFT8);
		NGN_RN->astR_RNFLGAD[usLoop].BITS.b10ZRnflgAddr |= (NX_USHORT)pstTargetInfo->uchSrcIpAddr4;
		NGN_RN->astR_RNFLGAD[usLoop].BITS.b01ZRnflgEn = (NX_ULONG)NX_ON;
		
		gstNET.stCyc.uchRcvCycleN	=	(NX_UCHAR)(pstTargetInfo->usRcvCycle & (USHORT)NX_BIT00_07);
		gstNET.stCyc.uchRcvCycleM	=	(NX_UCHAR)((pstTargetInfo->usRcvCycle & (USHORT)NX_BIT08_15) >> (USHORT)NX_SHIFT8);
		ulAddrTargetInfo	= ulAddrTargetInfo + sizeof(RCV_TARGET_INFO);
		pstTargetInfo		= (RCV_TARGET_INFO*)ulAddrTargetInfo;
	}

	for (usLoop = usLoop; usLoop < ASIC_RRNFLGADN_SIZE; usLoop++) {
		NGN_RN->astR_RNFLGAD[usLoop].BITS.b01ZRnflgEn = (NX_ULONG)NX_OFF;
	}


	return;
}

NX_VOID vNMG_CreateCycCfgRcvRespNrml (
	FRM_CC_RCV_SRC_INFO_REQ	*pstReq
)
{
	FRM_CC_RCV_SRC_INFO_RESP_NORMAL	*pstResp;

	pstResp = (FRM_CC_RCV_SRC_INFO_RESP_NORMAL*)gstNM.stTrnBuf.puchCyclicConfigRcvSrcInfoResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_CC_RCV_SRC_INFO_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero		 = NX_ZERO;
	pstResp->uchMsgId			 = NX_ZERO;
	pstResp->usDivisionTotalNum	 = NX_ZERO;
	pstResp->usDivisionId		 = NX_ZERO;

	return;
}

NX_VOID vNMG_CreateCycCfgRcvRespFault (
	FRM_CC_RCV_SRC_INFO_REQ		*pstReq,
	NX_USHORT					usFinCode
)
{
	FRM_CC_RCV_SRC_INFO_RESP_ERR	*pstResp;

	pstResp = (FRM_CC_RCV_SRC_INFO_RESP_ERR*)gstNM.stTrnBuf.puchCyclicConfigRcvSrcInfoResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						usFinCode,
						sizeof(FRM_CC_RCV_SRC_INFO_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsStsRcvCycCfgRcvReq ( NX_VOID )
{
	NX_USHORT	usAuthClass	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	
	if (gstNM.stNet.usNetSts == NETSTS_RCVD_SLCFG) {
		gstNM.stNet.usStatusFinish |= FIN_RCVD_CYCCFG_SRC_INFO;
		
		if (FIN_RCVD_CYCCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG)) {
			gstNM.stNet.usNetSts = NETSTS_RCVD_CYCCFG;
			if ( FIN_RCVD_CYCCFG_TIMECMP == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TIMECMP) ) {
				usAuthClass = usACM_GetAuthenticationClass();
				
				if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
					vNMG_ComCycEnable();
				}
				else {
					vNMG_PrepareDLinkClassA();
				}
			}
		}
	}

	return;
}
/*[EOF]*/
