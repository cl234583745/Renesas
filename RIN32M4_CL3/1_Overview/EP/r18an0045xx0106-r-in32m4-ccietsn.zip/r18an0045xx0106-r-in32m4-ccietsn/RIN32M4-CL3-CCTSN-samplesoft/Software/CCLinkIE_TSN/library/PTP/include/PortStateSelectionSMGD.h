/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTSTATESELECTIONGD_H__
#define __PORTSTATESELECTIONGD_H__

#include "ptp_Struct_Port.h"



typedef	enum tagPSSELECTIONSM_ST
{
	PSSE_NONE = 0,
	PSSE_INIT_BRIDGE,
	PSSE_STATE_SELECTION,
	PSSE_STATUS_MAX
} PSSELECTIONSM_ST;
#define	PSSELECTIONSM_ST_MAX	3

typedef enum tagPSSELECTIONSM_EV {
	PSSE_EV_BEGIN = 0,
	PSSE_EV_RESELECT_PORT,
	PSSE_EV_SYSTEMIDENTITYCHANGE,
	PSSE_EV_ASYMMETRYMESUREMODECHG,
	PSSE_EV_CLOSE,
	PSSE_EV_ASCAPABLE_ON,
	PSSE_EV_ASCAPABLE_OFF,
	PSSE_EV_EVENT_MAX
} PSSELECTIONSM_EV;
#define	PSSELECTIONSM_EV_MAX	7

typedef struct tagPSSELECTIONSM_GD
{
	BOOL		blSystemIdentityChange;
	BOOL		blAasymmetryMeasurModeChange;
	PSSELECTIONSM_ST enStatus;
} PSSELECTIONSM_GD;

#define	STATE_M1		0
#define	STATE_M2		1
#define	STATE_M3		2
#define	STATE_P1		3
#define	STATE_P2		4
#define	STATE_S1		5
#define STATE_L			6

#endif
