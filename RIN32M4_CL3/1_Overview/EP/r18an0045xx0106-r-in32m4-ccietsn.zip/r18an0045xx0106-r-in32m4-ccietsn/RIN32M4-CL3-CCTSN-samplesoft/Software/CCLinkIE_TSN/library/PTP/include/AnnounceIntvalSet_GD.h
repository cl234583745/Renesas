/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ANNOUNCEINTVALSET_GD_H__
#define __ANNOUNCEINTVALSET_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagANUNCINTVSET_ST {
	ANUNCI_NONE = 0,
	ANUNCI_NOT_ENABLED,
	ANUNCI_INITIALIZE,
	ANUNCI_SET_INTERVALS,
	ANUNCI_STATUS_MAX,

}	ANUNCINTVSET_ST;
#define	DANUNCI_STATUS_MAX		4

typedef enum tagANUNCINTVSET_EV {
	ANUNCI_E_BEGIN = 0,
	ANUNCI_E_USEMGTSETTLOGANNINT_ON,
	ANUNCI_E_USEMGTSETTLOGANNINT_OF,
	ANUNCI_E_RCVDSIGNALINGMSG2,
	ANUNCI_E_CLOSE,
	ANUNCI_E_EVENT_MAX

}	ANUNCINTVSET_EV;
#define	DANUNCI_E_EVENT_MAX		5

typedef struct tagAISSETTINGM_GD
{
	ANUNCINTVSET_ST		enStsAnnounceIntvalSet;
	
	BOOL				blRcvdSignalingMsg2;
	PTPMSG*				pstRcvdSignaling;

}	AISSETTINGM_GD;

#endif
