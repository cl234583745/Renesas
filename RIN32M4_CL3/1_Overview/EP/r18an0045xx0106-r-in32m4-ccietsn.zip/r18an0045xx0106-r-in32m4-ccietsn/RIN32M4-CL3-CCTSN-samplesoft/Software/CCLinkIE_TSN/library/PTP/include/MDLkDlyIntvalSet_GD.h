/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDLKDLYINTVALSET_GD_H__
#define __MDLKDLYINTVALSET_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagLDLYINTVSET_ST {
	MDLKDI_NONE = 0,
	MDLKDI_NOT_ENABLED,
	MDLKDI_INITIALIZE,
	MDLKDI_SET_INTERVAL,
	MDLKDI_STATUS_MAX

}	LDLYINTVSET_ST;
#define	DMDLKDI_STATUS_MAX			4


typedef enum tagLDLYINTVSET_EV {
	MDLKDI_E_BEGIN = 0,
	MDLKDI_E_UMGTSETLOGPDREQINT_ON,
	MDLKDI_E_UMGTSETLOGPDREQINT_OF,
	MDLKDI_E_F_LKDLINTST_RVDSGMSG1,
	MDLKDI_E_CLOSE,
	MDLKDI_E_EVENT_MAX

}	LDLYINTVSET_EV;
#define	DMDLKDI_E_EVENT_MAX			5

typedef struct tagLDISETTINGSM_GD
{
	LDLYINTVSET_ST		enStsLDlyIntvalSet;
	
	BOOL				blRcvdSignalingMsg1;
	PTPMSG*				pstRcvdSignaling;
	
}	LDISETTINGSM_GD;

#endif
