/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"





NX_VOID vINIT_commonip_ir ( NX_VOID )
{
	NGN_CN_REG->R_REHINT.DATA	= (NX_ULONG)0x0007FFFD;
	NGN_CN_REG->R_RELINT.DATA	= (NX_ULONG)0x000FFDFF;

	NGN_CN_REG->R_REHINTM.BITS.b01ZSndHiPriorityIntReqMskPort1			= 0;
	NGN_CN_REG->R_REHINTM.BITS.b01ZMskWdtErr							= 0;
	NGN_CN_REG->R_RELINTM.BITS.b01ZSndLowPriorityIntReqMskPort1			= 0;
	NGN_CN_REG->R_RELINTM.BITS.b01ZTsIntReqMskPort1						= 0;
	
	return;
}

/*[EOF]*/
