/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_cyclicconfig_trn_subpayload.h"
#include "SLMP_api.h"
#include "NGN_ASIC.h"
#include "cyclic_memmap.h"
#include "ccienx_api.h"
#include "CYC_api.h"
#include "cyclic_address.h"
#include "TOOL_api.h"
#include "SYNC_api.h"
#include "ccienx_app_supply.h"
#include "ACM_api.h"
#include "LSM_api.h"

#define	SEND_HEADER_FRM_SIZE	((NX_USHORT)0x18)
#define	SEND_HEADER_FRM_SIZE_VLAN	((NX_USHORT)0x1C)
#define	PDU_NUM_2				((NX_ULONG)2)
#define	PDU_NUM_3				((NX_ULONG)3)

#define	TRN_PDU_AREA_SIZE		((NX_USHORT)(1500 - 10 - 2))

#define	TRN_PDU_HEADER_SDCRC_SIZE ((NX_USHORT)(16 + 4))
#define	TRN_PDU_MAX_DATA_SIZE	((NX_USHORT)(TRN_PDU_AREA_SIZE - TRN_PDU_HEADER_SDCRC_SIZE))


#define	SEQNUM_ENDFLG			((NX_USHORT)0x8000)


typedef struct tagNET_SPLD_ENBL_PTN{
	NX_USHORT		usSpldEnablePtn;
	NX_USHORT		ausSeqNum[PDUDISC_NUM];
} SPLD_ENBL_PTN;

typedef	struct tagDESC_SET_PTN {
	NX_USHORT	usSpldEnablePtn;
	NX_USHORT	ausDiscNxtPtn[PDUDISC_NUM];
	NX_USHORT	ausDiscEndPtn[PDUDISC_NUM];
} DESC_SET_PTN;



NX_STATIC	NX_USHORT	gusSizeRX_Work;
NX_STATIC	NX_USHORT	gusSizeRWr_Work;
#ifdef SAFETY_PDU_ENABLE
NX_STATIC	NX_USHORT	gusSizeSpdux_Work;
#endif
NX_STATIC	NX_USHORT	gusSizeStsW_Work;

NX_VOID		vNMG_ChkCycCfgTrnSpdReq ( FRM_CC_TRN_SP_REQ*, NX_ULONG*, NX_ULONG );
NX_ULONG	ulNMG_ChkRangeCycCfgTrnSpdReq ( FRM_CC_TRN_SP_REQ* );
NX_VOID		vNMG_Extract_CycCfgTrnSpdReq ( FRM_CC_TRN_SP_REQ* );
NX_VOID		vNMG_SetRegCycleSndStart ( FRM_CC_TRN_SP_REQ* );
NX_VOID		vNMG_SetRegDescriptor ( NX_VOID );
NX_VOID		vNMG_SetCyclicFrameData ( NX_VOID );
NX_VOID		vNMG_CreateCycCfgTrnSpdRespNrml ( FRM_CC_TRN_SP_REQ* );
NX_VOID		vNMG_CreateCycCfgTrnSpdRespFault ( FRM_CC_TRN_SP_REQ*, NX_USHORT );
NX_VOID		vNMG_TrnsStsRcvCycCfgTrnSpdReq ( NX_VOID );
NX_VOID		vNMG_CycRcvMulCycleSetting (FRM_CC_TRN_SP_REQ* );
NX_ULONG	ulNMG_ChkSyncCycle ( NX_USHORT );
NX_STATIC NX_ULONG	ulNMG_ChkCycleTimeValClassA( NX_USHORT );

NX_VOID vNMG_AnalyzeCycCfgTrnSpdReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_CC_TRN_SP_REQ	*pstFrm;
	NX_ULONG			ulChkResult	= NX_ZERO;

	pstFrm = (FRM_CC_TRN_SP_REQ*)pData;

	vNMG_ChkCycCfgTrnSpdReq(pstFrm, &ulChkResult, ulIPAddress);

	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_CycCfgTrnSpdReq(pstFrm);

		vNMG_CreateCycCfgTrnSpdRespNrml(pstFrm);
		vNMG_ReqTrnCycCfgTrnSpdResp();

		vNMG_TrnsStsRcvCycCfgTrnSpdReq();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateCycCfgTrnSpdRespFault(pstFrm, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnCycCfgTrnSpdResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateCycCfgTrnSpdRespFault(pstFrm, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnCycCfgTrnSpdResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}

	return;
}

NX_VOID vNMG_ChkCycCfgTrnSpdReq (
	FRM_CC_TRN_SP_REQ	*pstFrm,
	NX_ULONG			*pulChkResult,
	NX_ULONG			ulIPAddress
)
{
	NX_ULONG				ulRangeChkResult	= NX_UL_NG;
	NX_USHORT				usSpldLoop			= (NX_USHORT)NX_ZERO;
	NX_USHORT				usSndCycleNum		= (NX_USHORT)NX_ZERO;
	NX_ULONG				ulAddrSndSpldInfo	= (NX_ULONG)NX_ZERO;
	TRN_SUBPAYLOAD_INFO*	pstSndSpldInfo;
	NX_USHORT				usCycSndPortResult	= NX_US_NG;
	NX_USHORT				usAuthClass			= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_ULONG				ulCycleTimeResult	= NX_UL_OK;

	ulAddrSndSpldInfo	= ((NX_ULONG)pstFrm + (NX_ULONG)sizeof(FRM_CC_TRN_SP_REQ));
	pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;

	if (ulIPAddress == gstNET.stCtrlMst.ulIPAddress) {
		if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
			(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
			(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
			if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
				*pulChkResult	= RESP_DIV_ERR;
			}
			else {
				*pulChkResult = RESP_DESTRUCT;
			}
		}
		else {
			ulRangeChkResult = ulNMG_ChkRangeCycCfgTrnSpdReq(pstFrm);
			if (NX_UL_OK == ulRangeChkResult) {
				*pulChkResult	= RESP_NORMAL;
				for (usSpldLoop = (NX_USHORT)NX_ZERO; usSpldLoop < pstFrm->usSndSubPayLoadNum; usSpldLoop++) {
					if ((NX_USHORT)NX_ZERO == usSpldLoop) {
						usSndCycleNum = pstSndSpldInfo->usSndCycle;
					}
					else {
						if (usSndCycleNum != pstSndSpldInfo->usSndCycle) {
							if ((NX_USHORT)NX_ONE == usSpldLoop) {
								if ((usSndCycleNum & (USHORT)NX_BIT00_07) != (pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07)) {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_015]);
								}
								else {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_016]);
								}
							}
							else if ((NX_USHORT)NX_TWO == usSpldLoop) {
								if ((usSndCycleNum & (USHORT)NX_BIT00_07) != (pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07)) {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_025]);
								}
								else {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_026]);
								}
							}
							else {
								if ((usSndCycleNum & (USHORT)NX_BIT00_07) != (pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07)) {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_043]);
								}
								else {
									vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_044]);
								}
							}
							*pulChkResult	= RESP_ERR;
							break;
						}
					}
					ulAddrSndSpldInfo	= (ulAddrSndSpldInfo + (NX_ULONG)sizeof(TRN_SUBPAYLOAD_INFO));
					pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
				}
				if (*pulChkResult == RESP_NORMAL) {
					if (gstNET.stApp.usSyncMode == SYNCMODE_SYNC) {
						ulAddrSndSpldInfo	= ((NX_ULONG)pstFrm + (NX_ULONG)sizeof(FRM_CC_TRN_SP_REQ));
						pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;

						*pulChkResult	= ulNMG_ChkSyncCycle((NX_USHORT)(pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07) + (NX_UCHAR)NX_ONE);
					}
					usCycSndPortResult	= usNMG_ChkCyclicSnd(gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1,
															 gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2);

					if (NX_US_NG == usCycSndPortResult) {
						vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_037]);
						*pulChkResult	= RESP_ERR;
					}
				}
				if (*pulChkResult == RESP_NORMAL) {
					usAuthClass = usACM_GetAuthenticationClass();
					
					if (usAuthClass == NX_AUTHENTICATION_CLS_A) {
						ulAddrSndSpldInfo	= ((NX_ULONG)pstFrm + (NX_ULONG)sizeof(FRM_CC_TRN_SP_REQ));
						pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
						ulCycleTimeResult	=	ulNMG_ChkCycleTimeValClassA((NX_USHORT)(pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07) + (NX_UCHAR)NX_ONE);

						if (ulCycleTimeResult == NX_UL_NG) {
							*pulChkResult	= RESP_ERR;
						}
					}
				}
			}
			else {
				*pulChkResult	= RESP_ERR;
			}
		}
	}
	else {
		*pulChkResult	= RESP_ERR;
	}

	return;
}

NX_ULONG ulNMG_ChkSyncCycle (
	NX_USHORT usCount
)
{
	NX_ULONG				ulChkResult			= RESP_DESTRUCT;
	NX_USHORT				usSyncPreSetResult	= SYNC_PRESET_CORRECT_NG;
	NX_ULONG				ulSyncCycleResult	= NX_UL_NG;
	NX_SYNC_COMCYC_INFO		stSyncCycleInfo;
	NX_ULONG				ulLoopIndex			= NX_UL_ZERO;

	usSyncPreSetResult	= usSYNC_SyncPreSetting(usCount);

	if (usSyncPreSetResult == SYNC_PRESET_RANGE_NG) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING1, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_034]);
		ulChkResult	= RESP_ERR;
	}
	else {
		stSyncCycleInfo.uchTimeslotNum	= gstNM.stNetworkConfigTslt.uchTsltNum;
		stSyncCycleInfo.usRptCnt		= usCount;
		for (ulLoopIndex = NX_UL_ZERO; ulLoopIndex < stSyncCycleInfo.uchTimeslotNum; ulLoopIndex++) {
			stSyncCycleInfo.aullTsStartTime[ulLoopIndex]	= ((NX_ULONGLONG)gstNM.stNetworkConfigTslt.astTsltOffset[ulLoopIndex].usStartOffset_s * NX_NSEC_1000000000)
															+ (NX_ULONGLONG)gstNM.stNetworkConfigTslt.astTsltOffset[ulLoopIndex].ulStartOffset_ns;
			stSyncCycleInfo.aullTsEndTime[ulLoopIndex]		= ((NX_ULONGLONG)gstNM.stNetworkConfigTslt.astTsltOffset[ulLoopIndex].usEndOffset_s * NX_NSEC_1000000000)
															+ (NX_ULONGLONG)gstNM.stNetworkConfigTslt.astTsltOffset[ulLoopIndex].ulEndOffset_ns;
		}
		for (; ulLoopIndex < (NX_ULONG)TSLT_SIZE_MAX; ulLoopIndex++) {
			stSyncCycleInfo.aullTsStartTime[ulLoopIndex]	= (NX_ULONGLONG)NX_ZERO;
			stSyncCycleInfo.aullTsEndTime[ulLoopIndex]		= (NX_ULONGLONG)NX_ZERO;
		}
		stSyncCycleInfo.ullComCycle		= gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;

		ulSyncCycleResult = ulNX_ChkSyncCycleInfoVal(&stSyncCycleInfo);

		if (NX_UL_NG == ulSyncCycleResult) {
			vNMG_SetNmgErr(EVENTCODE_SYNC_CYC_SETERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_036]);
			ulChkResult = RESP_ERR;
		}
		else {
			if (usSyncPreSetResult == SYNC_PRESET_CORRECT_NG) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_035]);
				ulChkResult	= RESP_ERR;
			}
			else {
				ulChkResult	= RESP_NORMAL;
			}
		}
	}

	return ulChkResult;
}

NX_ULONG ulNMG_ChkRangeCycCfgTrnSpdReq (
	FRM_CC_TRN_SP_REQ	*pstFrm
)
{
	NX_USHORT				usSpldLoop			= (NX_USHORT)NX_ZERO;
	NX_ULONG				ulStsWChk			= (NX_ULONG)NX_ZERO;
	NX_ULONG				ulRXChk				= (NX_ULONG)NX_ZERO;
	NX_ULONG				ulRWrChk			= (NX_ULONG)NX_ZERO;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG				ulSpduxChk			= (NX_ULONG)NX_ZERO;
#endif
	NX_ULONG				ulAddrSndSpldInfo	= (NX_ULONG)NX_ZERO;
	NX_UCHAR				auchSubPayMac[TRN_SPLD_NUM][NX_MAC_ADDR_SIZE];
	NX_LONG					lCmpRslt1			= (NX_LONG)NX_NG;
	TRN_SUBPAYLOAD_INFO*	pstSndSpldInfo;
	NX_USHORT				ausErrDetailList[4] = {
		(NX_USHORT)NMG_IDX_ERR_PARAM_011,
		(NX_USHORT)NMG_IDX_ERR_PARAM_021,
		(NX_USHORT)NMG_IDX_ERR_PARAM_031,
		(NX_USHORT)NMG_IDX_ERR_PARAM_049
	};
	NM_TRN_SPLD				*pstSubPayL			= NX_NULL;
	NX_ULONG				ulPreSpldEndaddr	= (NX_ULONG)NX_ZERO;
	NX_USHORT				usStswSpldNo		= (NX_USHORT)NX_ZERO;
	NX_UCHAR				uchSpldType			= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchSpldDivNo		= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchPreSpldType		= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchPreSpldDivNo		= (NX_UCHAR)NX_ZERO;

	NX_USHORT				ausMacErrDetailList[4] = {
		(NX_USHORT)NMG_IDX_ERR_PARAM_007,
		(NX_USHORT)NMG_IDX_ERR_PARAM_017,
		(NX_USHORT)NMG_IDX_ERR_PARAM_027,
		(NX_USHORT)NMG_IDX_ERR_PARAM_045
	};

	NX_USHORT				usAuthClass			= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_ULONG				ulRespRslt;

	gusSizeRX_Work	= (NX_USHORT)NX_ZERO;
	gusSizeRWr_Work	= (NX_USHORT)NX_ZERO;
#ifdef SAFETY_PDU_ENABLE
	gusSizeSpdux_Work	= (NX_USHORT)NX_ZERO;
#endif
 	gusSizeStsW_Work = (NX_USHORT)NX_ZERO;

	for (usSpldLoop = (NX_USHORT)NX_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDataExist		= (NX_UCHAR)NX_OFF;
		gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDataOrderNo	= NX_UC_ZERO;
	}

	ulRespRslt = ulNX_ChkCyclicConfigResp(gstNET.stApp.usSyncMode,gstNM.stSlaveConfig.usWdcFuncSts);

	ulAddrSndSpldInfo	= ((NX_ULONG)pstFrm + (NX_ULONG)sizeof(FRM_CC_TRN_SP_REQ));
	pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
	pstSubPayL			= &gstNET.stCyc.stTrnSubPayL[NX_ZERO];

	if (pstFrm->usSndSubPayLoadNum >= NX_SPLD_NUM_MAX_OVER_SND) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_001]);

		return NX_UL_NG;
	}

	if (NX_LIB_MODE_NORMAL != gstAppInfo.stLibInfo.usLibMode) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_001]);
		return NX_UL_NG;
	}

	gstNET.stCyc.usSndSubPayLoadNum	= pstFrm->usSndSubPayLoadNum;

	for (usSpldLoop = (NX_USHORT)NX_ZERO; usSpldLoop < pstFrm->usSndSubPayLoadNum; usSpldLoop++) {
		vNX_CopyMemory((NX_VOID*)&auchSubPayMac[usSpldLoop][0], (NX_VOID*)&pstSndSpldInfo->auchDestFrame[0], NX_MAC_ADDR_SIZE);

		vCYC_GetTrnSpldType(pstSndSpldInfo->ulSndDataStorageAddr, ulPreSpldEndaddr, uchPreSpldType, uchPreSpldDivNo, &uchSpldType, &uchSpldDivNo);

		if ((SPLD_TYPE_STSW == uchSpldType) &&
			(pstSndSpldInfo->usSndDataSize <= TRN_PDU_MAX_DATA_SIZE) &&
			!(pstSndSpldInfo->usSndDataSize & NX_BIT0)) {
			gusSizeStsW_Work += pstSndSpldInfo->usSndDataSize;
			ulStsWChk++;
			usStswSpldNo	  = usSpldLoop;
		}
		else if ((SPLD_TYPE_RX == uchSpldType) &&
				 (pstSndSpldInfo->usSndDataSize <= TRN_PDU_MAX_DATA_SIZE) &&
				!(pstSndSpldInfo->usSndDataSize & NX_BIT0)) {
			gusSizeRX_Work	+= pstSndSpldInfo->usSndDataSize;
			ulRXChk++;

			if (gstAppInfo.stCieNetInfo.usMaxSizeRX < gusSizeRX_Work) {
				if (3 < usSpldLoop) {
					usSpldLoop = 3;
				}
				vNMG_SetNmgErr(EVENTCODE_RXRY_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[ausErrDetailList[usSpldLoop]]);
				return NX_UL_NG;
			}
		}
		else if ((SPLD_TYPE_RWR == uchSpldType) &&
				 (pstSndSpldInfo->usSndDataSize <= TRN_PDU_MAX_DATA_SIZE) &&
				!(pstSndSpldInfo->usSndDataSize & NX_BIT0)) {
			gusSizeRWr_Work	+= pstSndSpldInfo->usSndDataSize;
			ulRWrChk++;

			if (gstAppInfo.stCieNetInfo.usMaxSizeRWr < gusSizeRWr_Work) {
				if (3 < usSpldLoop) {
					usSpldLoop = 3;
				}
				vNMG_SetNmgErr(EVENTCODE_RWRRWW_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[ausErrDetailList[usSpldLoop]]);
				return NX_UL_NG;
			}
		}
#ifdef SAFETY_PDU_ENABLE
		else if ((SPLD_TYPE_SPDUX == uchSpldType) &&
				 (pstSndSpldInfo->usSndDataSize <= TRN_PDU_MAX_DATA_SIZE) &&
				!(pstSndSpldInfo->usSndDataSize & NX_BIT0)) {
			gusSizeSpdux_Work	+= pstSndSpldInfo->usSndDataSize;
			ulSpduxChk++;

			if (gstAppInfo.stCieNetInfo.usMaxSizeSpdux < gusSizeSpdux_Work) {
				if (3 < usSpldLoop) {
					usSpldLoop = 3;
				}
				vNMG_SetNmgErr(EVENTCODE_SPDUXY_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[ausErrDetailList[usSpldLoop]]);
				return NX_UL_NG;
			}
		}
#endif
		else {
			if ((NX_USHORT)NX_ZERO == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_011]);
			}
			else if ((NX_USHORT)NX_ONE == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_021]);
			}
			else if ((NX_USHORT)NX_TWO == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_031]);
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_049]);
			}
			return NX_UL_NG;
		}

		pstSubPayL[usSpldLoop].uchDataExist			= (NX_UCHAR)NX_ON;
		pstSubPayL[usSpldLoop].uchDataOrderNo		= (NX_UCHAR)usSpldLoop;
		pstSubPayL[usSpldLoop].uchCycleIgnoreBit	= (NX_UCHAR)pstSndSpldInfo->stFrameSbPyldSetting.stBits.b01CycleIgnoreBit;
		pstSubPayL[usSpldLoop].uchDownPortSnd		= pstSndSpldInfo->stFrameSbPyldSetting.stBits.b01DownPortSnd;
		pstSubPayL[usSpldLoop].ulRcvMemmoryAddr		= pstSndSpldInfo->ulRcvMemmoryAddr;
		pstSubPayL[usSpldLoop].ulSndDataStorageAddr	= pstSndSpldInfo->ulSndDataStorageAddr;
		pstSubPayL[usSpldLoop].uchDestSubPayload3	= pstSndSpldInfo->auchDestSubPayload3;
		pstSubPayL[usSpldLoop].uchDestSubPayload4	= pstSndSpldInfo->auchDestSubPayload4;
		pstSubPayL[usSpldLoop].usSize				= pstSndSpldInfo->usSndDataSize;
		pstSubPayL[usSpldLoop].uchType				= uchSpldType;

		if (0 < uchSpldDivNo) {
			pstSubPayL[usSpldLoop-1].uchDivNo		= uchSpldDivNo;
			pstSubPayL[usSpldLoop].uchDivNo			= uchSpldDivNo + 1;
		}
		else {
			pstSubPayL[usSpldLoop].uchDivNo			= uchSpldDivNo;
		}

		vNX_CopyMemory(pstSubPayL[usSpldLoop].auchDestFrame, pstSndSpldInfo->auchDestFrame, NX_MAC_ADDR_SIZE);

		if (usSpldLoop == (pstFrm->usSndSubPayLoadNum - 1)) {
			pstSubPayL[usSpldLoop].usSeqNum			= usSpldLoop | SEQNUM_ENDFLG;
		}
		else {
			pstSubPayL[usSpldLoop].usSeqNum			= usSpldLoop;
		}

		usAuthClass = usACM_GetAuthenticationClass();

		if(NX_AUTHENTICATION_CLS_A == usAuthClass){
			if((NX_UCHAR)NX_ON != (NX_UCHAR)pstSndSpldInfo->stFrameSbPyldSetting.stBits.b01CycleIgnoreBit) {
				if ((NX_USHORT)NX_ZERO == usSpldLoop) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_003]);
				}
				else if ((NX_USHORT)NX_ONE == usSpldLoop) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_013]);
				}
				else if ((NX_USHORT)NX_TWO == usSpldLoop) {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_023]);
				}
				else {
					vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_041]);
				}
				return NX_UL_NG;
			}
		}

		if (pstSndSpldInfo->stFrameSbPyldSetting.stBits.b01EncapsulationBit == (NX_UCHAR)NX_ON) {
			if ((NX_USHORT)NX_ZERO == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_002]);
			}
			else if ((NX_USHORT)NX_ONE == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_012]);
			}
			else if ((NX_USHORT)NX_TWO == usSpldLoop) {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_022]);
			}
			else {
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_040]);
			}
			return NX_UL_NG;
		}

		uchPreSpldType		= uchSpldType;
		uchPreSpldDivNo		= uchSpldDivNo;
		ulPreSpldEndaddr	= pstSndSpldInfo->ulSndDataStorageAddr + pstSndSpldInfo->usSndDataSize;
		ulAddrSndSpldInfo	= ulAddrSndSpldInfo + sizeof(TRN_SUBPAYLOAD_INFO);
		pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
	}

	if ((gusSizeStsW_Work != NX_RECV_DATA_SIZE_0) &&
		(gusSizeStsW_Work != NX_STSW_DATA_SIZE)) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[ausErrDetailList[usStswSpldNo]]);
		return NX_UL_NG;
	}

	if ((SYNCMODE_SYNC == gstNET.stApp.usSyncMode) &&
		(NX_WDCFUNC_ENBL == gstNM.stSlaveConfig.usWdcFuncSts)) {
		if ((gusSizeRWr_Work < (gstAppInfo.stWdcInfo.stTrnSpldWdcInfo.usWdcOffset + (NX_USHORT)NX_TWO)) &&
			(NX_WDC_UL_OFFSET_NOCHECK != gstAppInfo.stWdcInfo.stTrnSpldWdcInfo.usWdcOffset)) {
			vNMG_SetNmgErr(EVENTCODE_RW_SETERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_011]);
			return NX_UL_NG;
		}
	}

#ifndef SAFETY_PDU_ENABLE
	if ((ulStsWChk	> (NX_ULONG)NX_SPLD_NUM_STSW) ||
		(ulRXChk	> (NX_ULONG)NX_SPLD_NUM_RX) ||
		(ulRWrChk	> (NX_ULONG)NX_SPLD_NUM_RWR)) {
#else
	if ((ulStsWChk	> (NX_ULONG)NX_SPLD_NUM_STSW) ||
		(ulRXChk	> (NX_ULONG)NX_SPLD_NUM_RX)   ||
		(ulRWrChk	> (NX_ULONG)NX_SPLD_NUM_RWR)  ||
		(ulSpduxChk > (NX_ULONG)NX_SPLD_NUM_SPDUX)) {
#endif
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_033]);
		return NX_UL_NG;
	}

	for (usSpldLoop = (NX_USHORT)NX_ONE; usSpldLoop < pstFrm->usSndSubPayLoadNum; usSpldLoop++) {
		lCmpRslt1 = lNX_CompareMemory((NX_VOID*)&auchSubPayMac[0][0], (NX_VOID*)&auchSubPayMac[usSpldLoop][0], NX_MAC_ADDR_SIZE);

		if (NX_NG == lCmpRslt1) {
			if (3 < usSpldLoop) {
				usSpldLoop = 3;
			}
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[ausMacErrDetailList[usSpldLoop]]);
			return NX_UL_NG;
		}
		else {
		}
	}


	if (NX_UL_NG == ulRespRslt) {
		return NX_UL_NG;
	}

	return NX_UL_OK;
}

NX_VOID vNMG_Extract_CycCfgTrnSpdReq (
	FRM_CC_TRN_SP_REQ	*pstFrm
)
{
	TRN_SUBPAYLOAD_INFO*	pstSndSpldInfo;
	NX_ULONG				ulAddrSndSpldInfo;
	NX_USHORT				usSpldLoop = NX_US_ZERO;



	ulAddrSndSpldInfo				= (NX_ULONG)pstFrm + sizeof(FRM_CC_TRN_SP_REQ);
	pstSndSpldInfo					= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
	gstNET.stCyc.uchRepeatCount		= (NX_UCHAR)(pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT00_07);
	gstNET.stCyc.uchSwitchTiming	= (NX_UCHAR)((pstSndSpldInfo->usSndCycle & (USHORT)NX_BIT08_15) >> (USHORT)NX_SHIFT8);
	
	gstNET.stCyc.usSizeRX = gusSizeRX_Work;
 	gstNET.stCyc.usSizeRWr = gusSizeRWr_Work;
 	gstNET.stCyc.usSizeStsW = gusSizeStsW_Work;
#ifdef SAFETY_PDU_ENABLE
	gstNET.stCyc.usSizeSpdux = gusSizeSpdux_Work;
#endif
	for (usSpldLoop = NX_US_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
		if ((NX_UCHAR)NX_ON == gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDataExist) {
			vNX_CopyMemory(gstNET.stCtrlMst.auchMacAddr, gstNET.stCyc.stTrnSubPayL[usSpldLoop].auchDestFrame, NX_MAC_ADDR_SIZE);
		}
	}

	vNMG_SetRegCycleSndStart(pstFrm);

	vNMG_SetRegDescriptor();

	vCYC_SetTrnAddrInfo(&gstNET.stCyc.stTrnSubPayL[NX_ZERO]);

	vCYC_PreInitTrnCycData();

	vNMG_SetCyclicFrameData();

	vNMG_CycRcvMulCycleSetting(pstFrm);

	return;
}

NX_VOID vNMG_CycRcvMulCycleSetting (
	FRM_CC_TRN_SP_REQ	*pstFrm
)
{
	NX_UCHAR	ucTrnRcvTiming		=	(NX_UCHAR)NX_ZERO;
	NX_UCHAR	ucRepeatTimesFrm		=	(NX_UCHAR)NX_ZERO;
	NX_USHORT	usSwitchTiming		=	(NX_USHORT)NX_ZERO;
	NX_UCHAR	ucRepeatTimesAsic	=	(NX_UCHAR)NX_ZERO;
	NX_USHORT	usRepeatTimes		=	(NX_USHORT)NX_ZERO;
	
	TRN_SUBPAYLOAD_INFO*	pstSndSpldInfo;
	NX_ULONG				ulAddrSndSpldInfo	= (NX_ULONG)NX_ZERO;
	
	
	ulAddrSndSpldInfo	= (NX_ULONG)pstFrm + sizeof(FRM_CC_TRN_SP_REQ);
	pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;
	
	ucTrnRcvTiming		=	(NX_UCHAR)((pstSndSpldInfo->usSndCycle & NX_BIT08_15) >> NX_SHIFT8);
	ucRepeatTimesFrm	=	(NX_UCHAR)(pstSndSpldInfo->usSndCycle & NX_BIT00_07);
	
	usRepeatTimes		=	(NX_USHORT)ucRepeatTimesFrm + (NX_USHORT)NX_ONE;
	
	(NX_VOID)ulTOOL_calcLog2(usRepeatTimes, &ucRepeatTimesAsic);
	
	usSwitchTiming	=	(NX_USHORT)ucTrnRcvTiming;
	
	NGN_RN->R_RNCBKPRD0.BITS.b04ZRepeatCount	=	(NX_ULONG)ucRepeatTimesAsic;
	NGN_RN->R_RNCBKPRD0.BITS.b08ZSwitchTiming	=	(NX_ULONG)usSwitchTiming;
	
	return;
}

NX_VOID vNMG_SetRegCycleSndStart (
	FRM_CC_TRN_SP_REQ	*pstFrm
)
{
	NX_ULONG				ulAddrSndSpldInfo	= (NX_ULONG)NX_ZERO;
	TRN_SUBPAYLOAD_INFO*	pstSndSpldInfo;
	ASIC_RTSLOT1_Bits*		pstCtrl1;
	ASIC_RTSLOT2_Bits*		pstCtrl2;
	ASIC_RTSLOT3_Bits*		pstCtrl3;
	NX_UCHAR	ucTrnRcvTiming		=	(NX_UCHAR)NX_ZERO;
	NX_UCHAR	ucRepeatTimesFrm		=	(NX_UCHAR)NX_ZERO;
	NX_UCHAR	ucRepeatTimesAsic	=	(NX_UCHAR)NX_ZERO;

	ulAddrSndSpldInfo	= (NX_ULONG)pstFrm + sizeof(FRM_CC_TRN_SP_REQ);
	pstSndSpldInfo		= (TRN_SUBPAYLOAD_INFO*)ulAddrSndSpldInfo;

	pstCtrl1	= (ASIC_RTSLOT1_Bits*)&NGN_CN_TN1_REG->R_TSLOT[gstNET.stCyc.usTsltCycSnd].ASIC_rtslot1.BITS;
	pstCtrl2	= (ASIC_RTSLOT2_Bits*)&NGN_CN_TN1_REG->R_TSLOT[gstNET.stCyc.usTsltCycSnd].ASIC_rtslot2.BITS;
	pstCtrl3	= (ASIC_RTSLOT3_Bits*)&NGN_CN_TN1_REG->R_TSLOT[gstNET.stCyc.usTsltCycSnd].ASIC_rtslot3.BITS;

	ucTrnRcvTiming		=	(NX_UCHAR)((pstSndSpldInfo->usSndCycle & NX_BIT08_15) >> NX_SHIFT8);
	ucRepeatTimesFrm	=	(NX_UCHAR)(pstSndSpldInfo->usSndCycle & NX_BIT00_07);
	
	(NX_VOID)ulTOOL_calcLog2(ucRepeatTimesFrm + (UCHAR)NX_ONE, &ucRepeatTimesAsic);

	pstCtrl1->b08ZSndCycleTiming		= ucTrnRcvTiming;
	pstCtrl1->b04ZBasicCycleRepeatCnt	= ucRepeatTimesAsic;
	pstCtrl1->b0BZSndDiscriptTopNo		= (NX_ULONG)TRNDISC_NO0;
	pstCtrl1->b01ZUnitModeKind			= (NX_ULONG)NX_OFF;

	pstCtrl2->b1EZDelayTime				= (NX_ULONG)NX_ZERO;
	pstCtrl2->b01ZDelaySndStart			= (NX_ULONG)NX_ZERO;

	pstCtrl3->b08ZDelayTime				= (NX_ULONG)NX_ZERO;

	return;
}

NX_VOID vNMG_SetRegDescriptor ( NX_VOID )
{
	ASIC_RTNDIS1_Bits*	pstTnDescNo0_1;
	ASIC_RTNDIS2_Bits*	pstTnDescNo0_2;
	ASIC_RTNDIS1_Bits*	pstTnDescNo1_1;
	ASIC_RTNDIS2_Bits*	pstTnDescNo1_2;
	ASIC_RTNPDU1_Bits*	pstPdDesc1;
	ASIC_RTNPDU2_Bits*	pstPdDesc2;
	ASIC_RTNDIS1_Bits*	pstPreTnDescNo0_1;
	ASIC_RTNDIS1_Bits*	pstPreTnDescNo1_1;
	ASIC_RTNPDU1_Bits*	pstPrePdDesc1;
	NX_USHORT			usSpldLoop		= (NX_USHORT)NX_ZERO;
	NX_USHORT			usTrnDescNo		= (NX_USHORT)NX_ZERO;
	NX_ULONG			ulSndDataAddr	= (NX_ULONG)NX_ZERO;
	NX_USHORT			usTotalDataSize	= (NX_USHORT)NX_ZERO;
	ASIC_RTNDIS_TAG		stRtndis[TRNDISC_NUM];
	ASIC_RTNPDU_TAG		stRtnpdu[PDUDISC_NUM];
	NX_USHORT			usDescriptor0	= NX_US_ZERO;
	NX_USHORT			usDescriptor1	= NX_US_ZERO;
	NX_USHORT			usEnableNum		= NX_US_ZERO;

	NX_USHORT			usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	NX_USHORT			usVlanEnaFlg;
	NX_ULONG			ulVlanTag;
	NX_ULONG			ulSendHeaderSize;
	NX_ULONG			ulResult;

	vNMG_GetPortSndDescriptor( gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1,
							   gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2,
							   &usDescriptor0,
							   &usDescriptor1,
							   &usEnableNum );

	usAuthClass = usACM_GetAuthenticationClass();
	
	if(NX_AUTHENTICATION_CLS_A == usAuthClass) {
		gstClassAInfo.usDescriptor0 = usDescriptor0;
		gstClassAInfo.usDescriptor1 = usDescriptor1;
		gstClassAInfo.usDiscEnableNum = usEnableNum;
	}

	vNX_FillMemory32(&stRtndis, (NX_ULONG)NX_ZERO, (sizeof(ASIC_RTNDIS_TAG)*TRNDISC_NUM)/sizeof(ULONG));
	vNX_FillMemory32(&stRtnpdu, (NX_ULONG)NX_ZERO, (sizeof(ASIC_RTNPDU_TAG)*PDUDISC_NUM)/sizeof(ULONG));


	pstTnDescNo0_1 = &stRtndis[NX_ZERO].ASIC_rtndis1.BITS;
	pstTnDescNo0_2 = &stRtndis[NX_ZERO].ASIC_rtndis2.BITS;
	pstTnDescNo1_1 = &stRtndis[NX_ONE].ASIC_rtndis1.BITS;
	pstTnDescNo1_2 = &stRtndis[NX_ONE].ASIC_rtndis2.BITS;

	ulResult = ulNMG_GetVlanTag(&ulVlanTag);
	if (ulResult == NX_UL_VLAN_OK) {
		usVlanEnaFlg 		= NX_VLAN_ENABLE;
		ulSendHeaderSize	= SEND_HEADER_FRM_SIZE_VLAN;
	}
	else {
		usVlanEnaFlg 		= NX_VLAN_DISABLE;		
		ulSendHeaderSize	= SEND_HEADER_FRM_SIZE;
	}

	if ((NX_USHORT)NX_TWO == usEnableNum) {
		pstTnDescNo0_1->b0BZSndDiscriptTopNo	= (NX_ULONG)PDUDISC_NO;
		pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO1;
		pstTnDescNo0_1->b03ZFrameFormat			= NX_FRAME_NGN_CYC_BOND;
		pstTnDescNo0_1->b01ZFrameConfigVLAN		= usVlanEnaFlg;

		pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
		pstTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

		pstTnDescNo1_1->b0BZSndDiscriptTopNo	= (NX_ULONG)PDUDISC_NO;
		pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
		pstTnDescNo1_1->b03ZFrameFormat			= NX_FRAME_NGN_CYC_BOND;
		pstTnDescNo1_1->b01ZFrameConfigVLAN		= usVlanEnaFlg;
		pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
		pstTnDescNo1_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;
	}
	else if ((NX_USHORT)NX_ONE == usEnableNum){
		pstTnDescNo0_1->b0BZSndDiscriptTopNo	= (NX_ULONG)PDUDISC_NO;
		pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
		pstTnDescNo0_1->b03ZFrameFormat			= NX_FRAME_NGN_CYC_BOND;
		pstTnDescNo0_1->b01ZFrameConfigVLAN		= usVlanEnaFlg;
		pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
		pstTnDescNo0_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;

		pstTnDescNo1_1->b0BZSndDiscriptTopNo	= (NX_ULONG)PDUDISC_NO;
		pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
		pstTnDescNo1_1->b03ZFrameFormat			= NX_FRAME_NGN_CYC_BOND;
		pstTnDescNo1_1->b01ZFrameConfigVLAN		= usVlanEnaFlg;
		pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
		pstTnDescNo1_1->b01ZFrameFlag			= (NX_ULONG)NX_ON;
	}
	else {
	}

	if ((NX_USHORT)NX_TWO == usEnableNum) {
		if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}

		if ((NX_USHORT)NX_PORT1 == usDescriptor1) {
			pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}
	}
	else if ((NX_USHORT)NX_ONE == usEnableNum){
		if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
		}
		else {
			pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
			pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
		}

	}
	else {
	}

	pstTnDescNo0_2->b07ZSendHeaderFrmSize		= ulSendHeaderSize;
	pstTnDescNo1_2->b07ZSendHeaderFrmSize		= ulSendHeaderSize;

	vNX_CopyMemory32(&stRtndis[(NX_TWO)], &stRtndis[NX_ZERO], (sizeof(ASIC_RTNDIS_TAG)*(TRNDISC_NUM-NX_TWO))/sizeof(ULONG));

	pstPreTnDescNo0_1 = pstTnDescNo0_1;
	pstPreTnDescNo1_1 = pstTnDescNo1_1;
	pstTnDescNo0_1    = &stRtndis[NX_TWO].ASIC_rtndis1.BITS;
	pstTnDescNo1_1    = &stRtndis[NX_THREE].ASIC_rtndis1.BITS;
	usTrnDescNo   = (NX_USHORT)NX_TWO;

	pstPrePdDesc1 = (ASIC_RTNPDU1_Bits*)&stRtnpdu[NX_ZERO].ASIC_rtnpdu1.BITS;

	for (usSpldLoop = NX_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
		if (gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDataExist == (NX_UCHAR)NX_ON) {
			pstPdDesc1 = (ASIC_RTNPDU1_Bits*)&stRtnpdu[usSpldLoop].ASIC_rtnpdu1.BITS;
			pstPdDesc2 = (ASIC_RTNPDU2_Bits*)&stRtnpdu[usSpldLoop].ASIC_rtnpdu2.BITS;

			pstPdDesc1->b0BZPayloadDiscriptNextNo = PDUDISC_NO + usSpldLoop + NX_ONE;

			if (gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSeqNum & SEQNUM_ENDFLG) {
				pstPdDesc1->b01ZPayloadDiscriptEndFlag	= NX_ON;
			}
			else {
				pstPdDesc1->b01ZPayloadDiscriptEndFlag	= NX_OFF;
			}
			pstPdDesc1->b0BZPayloadLen = gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize + sizeof(SPHEAD_SS_S);

			if ((0 == gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDivNo) || 
				(1 == gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDivNo)) {
				ulSndDataAddr = gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulSndDataStorageAddr - (NX_ULONG)sizeof(SPHEAD_SS_S);
			}

			gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulSndDataAddr = ulSndDataAddr;

			pstPdDesc2->b1AZSndDataAddr = gstNET.stCyc.stTrnSubPayL[usSpldLoop].ulSndDataAddr;

			ulSndDataAddr += gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize + TRN_PDU_HEADER_SDCRC_SIZE + 4;
			ulSndDataAddr &= ~((NX_ULONG)2);

			usTotalDataSize += gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize + TRN_PDU_HEADER_SDCRC_SIZE;

			if (TRN_PDU_AREA_SIZE < usTotalDataSize) {
				usTotalDataSize = gstNET.stCyc.stTrnSubPayL[usSpldLoop].usSize + TRN_PDU_HEADER_SDCRC_SIZE;

				if ((NX_USHORT)NX_TWO == usEnableNum) {
					pstPreTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
					pstPreTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
					pstPrePdDesc1->b01ZPayloadDiscriptEndFlag   = NX_ON;

					pstTnDescNo0_1->b0BZSndDiscriptTopNo	= (NX_ULONG)(PDUDISC_NO + usSpldLoop);
					pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo + NX_ONE);
					pstTnDescNo1_1->b0BZSndDiscriptTopNo	= (NX_ULONG)(PDUDISC_NO + usSpldLoop);
					pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO_NXT);

					pstPreTnDescNo0_1 = pstTnDescNo0_1;
					pstPreTnDescNo1_1 = pstTnDescNo1_1;
					usTrnDescNo+=(NX_USHORT)NX_TWO;
					pstTnDescNo0_1    = &stRtndis[usTrnDescNo].ASIC_rtndis1.BITS;
					pstTnDescNo1_1    = &stRtndis[usTrnDescNo+(NX_USHORT)NX_ONE].ASIC_rtndis1.BITS;
				}
				else if ((NX_USHORT)NX_ONE == usEnableNum){
					pstPreTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
					pstPreTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;
					pstPrePdDesc1->b01ZPayloadDiscriptEndFlag   = NX_ON;

					pstTnDescNo0_1->b0BZSndDiscriptTopNo	= (NX_ULONG)(PDUDISC_NO + usSpldLoop);
					pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO_NXT);
					pstTnDescNo1_1->b0BZSndDiscriptTopNo	= (NX_ULONG)(PDUDISC_NO + usSpldLoop);
					pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO_NXT);

					pstPreTnDescNo0_1 = pstTnDescNo0_1;
					pstPreTnDescNo1_1 = pstTnDescNo1_1;
					usTrnDescNo+=(NX_USHORT)NX_TWO;
					pstTnDescNo0_1    = &stRtndis[usTrnDescNo].ASIC_rtndis1.BITS;
					pstTnDescNo1_1    = &stRtndis[usTrnDescNo+(NX_USHORT)NX_ONE].ASIC_rtndis1.BITS;
				}
				else {
				}
			}

			pstPrePdDesc1 = pstPdDesc1;
		}
		else {
			break;
		}
	}

	vNX_CopyMemory32((NX_VOID*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0], &stRtndis, (sizeof(ASIC_RTNDIS_TAG)*TRNDISC_NUM)/sizeof(ULONG));
	vNX_CopyMemory32((NX_VOID*)&NGN_CN_TNDIS_REG->R_TNPDU[PDUDISC_NO], &stRtnpdu, (sizeof(ASIC_RTNPDU_TAG)*PDUDISC_NUM)/sizeof(ULONG));

	gstNET.stCyc.usTrnFrameNum = usTrnDescNo;
	return;
}

NX_VOID vNMG_SetCyclicFrameData ( NX_VOID )
{
	NX_USHORT			usSpldLoop			= (NX_USHORT)NX_ZERO;

	vCYC_InitCyclicData_EthHead(TRNDISC_NO0, &gstNET.stCyc.stTrnSubPayL[NX_ZERO], TRNDISC_NUM);

	for (usSpldLoop = NX_ZERO; usSpldLoop < TRN_SPLD_NUM; usSpldLoop++) {
		if (gstNET.stCyc.stTrnSubPayL[usSpldLoop].uchDataExist == (NX_UCHAR)NX_ON) {
			vCYC_InitCyclicData(&gstNET.stCyc.stTrnSubPayL[usSpldLoop]);
		}
		else {
			break;
		}
	}

	return;
}

NX_VOID vNMG_CreateCycCfgTrnSpdRespNrml (
	FRM_CC_TRN_SP_REQ	*pstReq
)
{
	FRM_CC_TRN_SP_RESP_NORMAL	*pstResp;

	pstResp = (FRM_CC_TRN_SP_RESP_NORMAL*)gstNM.stTrnBuf.puchCyclicConfigTrnSubPayloadResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_CC_TRN_SP_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero			= (NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId				= (NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum		= (NX_USHORT)NX_ZERO;
	pstResp->usDivisionId			= (NX_USHORT)NX_ZERO;

	return;
}

NX_VOID vNMG_CreateCycCfgTrnSpdRespFault (
	FRM_CC_TRN_SP_REQ		*pstReq,
	NX_USHORT				usFinCode
)
{
	FRM_CC_TRN_SP_RESP_ERR	*pstResp;

	pstResp = (FRM_CC_TRN_SP_RESP_ERR*)gstNM.stTrnBuf.puchCyclicConfigTrnSubPayloadResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						usFinCode,
						sizeof(FRM_CC_TRN_SP_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= (NX_UCHAR)NX_ZERO;
	pstResp->uchMsgId						= (NX_UCHAR)NX_ZERO;
	pstResp->usDivisionTotalNum				= (NX_USHORT)NX_ZERO;
	pstResp->usDivisionId					= (NX_USHORT)NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsStsRcvCycCfgTrnSpdReq ( NX_VOID )
{
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	if (gstNM.stNet.usNetSts == NETSTS_RCVD_SLCFG) {
		gstNM.stNet.usStatusFinish |= FIN_RCVD_CYCCFG_TRNSPD;
		
		if (FIN_RCVD_CYCCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG)) {
			gstNM.stNet.usNetSts = NETSTS_RCVD_CYCCFG;
			if ( FIN_RCVD_CYCCFG_TIMECMP == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TIMECMP) ) {
				
				usAuthClass = usACM_GetAuthenticationClass();
				
				if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
					
					vNMG_ComCycEnable();
				}
				else {
					
					vNMG_PrepareDLinkClassA();
				}
			}
		}
	}

	return;
}


NX_ULONG    ulNMG_ChkCycleTimeValClassA( 
	NX_USHORT usCount 
) 
{
	NX_ULONG			ulCheckResult;
	NX_ULONGLONG		ullComCycle;
	NX_ULONGLONG		ullComCycle_ClassA;
	NX_ULONG			ulResult;
	NX_USHORT			usLinkSpdSta;
	
	ulCheckResult		=	NX_UL_OK;
	
	ullComCycle			=	gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
	usLinkSpdSta		=	usLSM_GetLinkSpd();
	
	ullComCycle_ClassA	=	ullComCycle	*	(NX_ULONGLONG)usCount;
	
	ulResult			=	ulNX_ChkCycleTimeVal(ullComCycle_ClassA, usLinkSpdSta, NX_AUTHENTICATION_CLS_A);
	
	if (ulResult == NX_UL_OK) {
	}
	else {
		if (usLinkSpdSta == NX_LINKSPD_STA_1G) {
			vNMG_SetNmgErr(EVENTCODE_CLSA_1G_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_039]);
		}
		else{
			vNMG_SetNmgErr(EVENTCODE_CLSA_100M_COMCYCLE_ERR, (NX_USHORT*)&DetailErrorTbl_CycCfgTrnSpd[NMG_IDX_ERR_PARAM_039]);
		}
		ulCheckResult = NX_UL_NG;
	}
	
	return ulCheckResult;
}

/*[EOF]*/
