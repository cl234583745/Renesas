/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"
#include "ptp_MemManage.h"

#include "ptp_CMSReceive.h"
#include "ptp_ClockTarget_API.h"
#include "ptp_GetDetailCurrentTime.h"









INT	ptp_clockTargetGetCurrentTime(
	UCHAR uchDomainNumber,
	CLKTARGETCURTIME*	pstClkTrgCurTime)
{
	INT			nRetCode			= RET_EINVAL;
	CLOCKDATA*	pstClockData		= gpstClockDataHPtr;
	USCALEDNS	stCurrentMasterTime	= {0};
	USCALEDNS			stDetailCurTime	= {0};


	if (uchDomainNumber != 0)
	{
		return nRetCode;
	}

	if (pstClkTrgCurTime == NULL)
	{
		return nRetCode;
	}
	
#ifdef	PTP_CLK_TGT_USE_DETAIL



	if (pstClockData != NULL)
	{
		ptp_GetCurrentMasterTime(pstClockData, &stCurrentMasterTime);
		pstClkTrgCurTime->blGmPresent = pstClockData->stClock_GD.blGmPresent;
	}
	else
	{

		ptp_GetDetailCurrentTime(&stDetailCurTime);
		stCurrentMasterTime = stDetailCurTime;
		pstClkTrgCurTime->blGmPresent = FALSE;
	}

#else
	
	if (pstClockData != NULL)
	{
		lRet = ptp_TimerSemLockWait();
		if (lRet != RET_ENOERR)
		{
			nRetCode = RET_ESTATE;
			return nRetCode;
		}

		stCurrentMasterTime = pstClockData->stClock_GD.stCurrentMasterTime;

		(VOID)ptp_TimerSemUnLock();
		pstClkTrgCurTime->blGmPresent = pstClockData->stClock_GD.blGmPresent;
	}
	else
	{
		ptp_GetCurrentTime(pstClockData, &stCurrentMasterTime);
		pstClkTrgCurTime->blGmPresent = FALSE;
	}

#endif

	(VOID)ptpConvUSNs_ETS(&(stCurrentMasterTime),
								&(pstClkTrgCurTime->stCurrentTime));
	
	nRetCode = RET_ENOERR;
	
	return nRetCode;
}




