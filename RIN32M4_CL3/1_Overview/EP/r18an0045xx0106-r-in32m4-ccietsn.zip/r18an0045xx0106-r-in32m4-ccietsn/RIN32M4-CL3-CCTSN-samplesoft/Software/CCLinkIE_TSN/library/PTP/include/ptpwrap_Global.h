/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTPWRAP_GLOBAL_H__
#define __PTPWRAP_GLOBAL_H__

#ifdef __cplusplus
extern "C" {
#endif

#include	<ptp_Macro.h>


TM_WRAP_EXTERN	SENDCB_INF		gSendCBTbl[MAX_PORT][MAX_CLOCK][MAX_EMSGID];

TM_WRAP_EXTERN	RECVEVT_INF		gRecvEvtTbl;

TM_WRAP_EXTERN	RECVGEN_INF		gRecvGenTbl;

TM_WRAP_EXTERN	PTP_LOWWRAP_INF	gPtpLowWrapTbl;

TM_WRAP_EXTERN	SCOMP_PORT		gSCompPortTbl;

#ifdef __cplusplus
}
#endif

#endif
