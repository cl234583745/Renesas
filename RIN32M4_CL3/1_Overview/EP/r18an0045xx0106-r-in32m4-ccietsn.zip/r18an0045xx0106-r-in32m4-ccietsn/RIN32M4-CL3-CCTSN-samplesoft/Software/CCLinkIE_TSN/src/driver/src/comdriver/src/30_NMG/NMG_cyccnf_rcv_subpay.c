/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_cyclicconfig_rcv_subpayload.h"
#include "SLMP_api.h"
#include "cyclic_memmap.h"
#include "CYC_api.h"
#include "ACM_api.h"
#include "ccienx_app_supply.h"


NX_STATIC	NX_USHORT	gusSizeRY_Work;
NX_STATIC	NX_USHORT	gusSizeRWw_Work;
#ifdef SAFETY_PDU_ENABLE
NX_STATIC	NX_USHORT	gusSizeSpduy_Work;
#endif

NX_VOID		vNMG_ChkCycCfgRcvSpdReq ( FRM_CC_RCV_SP_REQ*, NX_ULONG*, NX_ULONG );
NX_ULONG	ulNMG_ChkRangeCycCfgRcvSpdReq ( FRM_CC_RCV_SP_REQ* );
NX_VOID		vNMG_Extract_CycCfgRcvSpdReq ( FRM_CC_RCV_SP_REQ* );
NX_VOID		vNMG_CreateCycCfgRcvSpdRespNrml ( FRM_CC_RCV_SP_REQ* );
NX_VOID		vNMG_CreateCycCfgRcvSpdRespFault ( FRM_CC_RCV_SP_REQ*, NX_USHORT );
NX_VOID		vNMG_TrnsStsRcvCycCfgRcvSpdReq ( NX_VOID );

NX_VOID vNMG_AnalyzeCycCfgRcvSpdReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	FRM_CC_RCV_SP_REQ	*pstFrm;
	NX_ULONG			ulChkResult	= NX_ZERO;

	pstFrm = (FRM_CC_RCV_SP_REQ*)pData;

	vNMG_ChkCycCfgRcvSpdReq(pstFrm, &ulChkResult, ulIPAddress);

	if (ulChkResult == RESP_NORMAL) {
		vNMG_Extract_CycCfgRcvSpdReq(pstFrm);

		vNMG_CreateCycCfgRcvSpdRespNrml(pstFrm);
		vNMG_ReqTrnCycCfgRcvSpdResp();

		vNMG_TrnsStsRcvCycCfgRcvSpdReq();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateCycCfgRcvSpdRespFault(pstFrm, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnCycCfgRcvSpdResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateCycCfgRcvSpdRespFault(pstFrm, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnCycCfgRcvSpdResp();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_ChkCycCfgRcvSpdReq (
	FRM_CC_RCV_SP_REQ	*pstFrm,
	NX_ULONG			*pulChkResult,
	NX_ULONG			ulIPAddress
)
{
	NX_ULONG	ulRangeChkResult	= NX_UL_NG;

	if (ulIPAddress == gstNET.stCtrlMst.ulIPAddress) {
		if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
			(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
			(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
			if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
				*pulChkResult	= RESP_DIV_ERR;
			}
			else {
				*pulChkResult = RESP_DESTRUCT;
			}
		}
		else {
			ulRangeChkResult = ulNMG_ChkRangeCycCfgRcvSpdReq(pstFrm);

			if (NX_UL_OK == ulRangeChkResult) {
				*pulChkResult	= RESP_NORMAL;
			}
			else {
				*pulChkResult	= RESP_ERR;
			}
		}
	}
	else {
		*pulChkResult	= RESP_ERR;
	}

	return;
}

NX_ULONG ulNMG_ChkRangeCycCfgRcvSpdReq (
	FRM_CC_RCV_SP_REQ	*pstFrm
)
{
	NX_USHORT				usSpldLoop			= NX_ZERO;
	NX_ULONG				ulRYChk				= NX_ZERO;
	NX_ULONG				ulRWwChk			= NX_ZERO;
#ifdef SAFETY_PDU_ENABLE
	NX_ULONG				ulSpduyChk			= NX_ZERO;
#endif
	NX_ULONG				ulAddrRcvSpldInfo	= NX_ZERO;
	NX_USHORT				usEvent				= NX_ZERO;
	NX_USHORT				usDetailIdx			= NX_ZERO;
	NX_ULONG				ulSizeChkRslt		= NX_UL_NG;
	RCV_SUBPAYLOAD_INFO*	pstRcvSpldInfo;
	NM_RCV_SPLD				*pstSubPayL			= NX_NULL;
	NX_UCHAR				uchSpldType			= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchSpldDivNo		= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchPreSpldType		= (NX_UCHAR)NX_ZERO;
	NX_UCHAR				uchPreSpldDivNo		= (NX_UCHAR)NX_ZERO;
	NX_ULONG				ulPreSpldEndAddr	= (NX_ULONG)NX_ZERO;
	NX_ULONG				ulRespRslt;

	gusSizeRY_Work	= NX_ZERO;
	gusSizeRWw_Work	= NX_ZERO;
#ifdef SAFETY_PDU_ENABLE
	gusSizeSpduy_Work	= NX_ZERO;
#endif

	for (usSpldLoop = (NX_USHORT)NX_ZERO; usSpldLoop < RCV_SPLD_NUM; usSpldLoop++) {
		gstNET.stCyc.astRcvSubPayL[usSpldLoop].uchDataExist   = (NX_UCHAR)NX_OFF;
		gstNET.stCyc.astRcvSubPayL[usSpldLoop].uchDataOrderNo = NX_UC_ZERO;
	}

	ulRespRslt = ulNX_ChkCyclicConfigResp(gstNET.stApp.usSyncMode,gstNM.stSlaveConfig.usWdcFuncSts);

	ulAddrRcvSpldInfo	= (NX_ULONG)pstFrm + sizeof(FRM_CC_RCV_SP_REQ);
	pstRcvSpldInfo		= (RCV_SUBPAYLOAD_INFO*)ulAddrRcvSpldInfo;
	pstSubPayL			= &gstNET.stCyc.astRcvSubPayL[NX_ZERO];

	if (pstFrm->usRcvSubPayLoadNum >= NX_SPLD_NUM_MAX_OVER_RCV) {
		vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_001]);
		return NX_UL_NG;
	}
	else {
		if (NX_LIB_MODE_NORMAL != gstAppInfo.stLibInfo.usLibMode) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_001]);
			return NX_UL_NG;
		}

		gstNET.stCyc.usRcvSubPayLoadNum	= pstFrm->usRcvSubPayLoadNum;

		for (usSpldLoop = NX_ZERO; usSpldLoop < pstFrm->usRcvSubPayLoadNum; usSpldLoop++) {

			vCYC_GetRcvSpldType(pstRcvSpldInfo->ulRcvDataStorageAddr, ulPreSpldEndAddr, uchPreSpldType, uchPreSpldDivNo, &uchSpldType, &uchSpldDivNo);

			if (SPLD_TYPE_RY == uchSpldType) {
				ulRYChk++;
				gusSizeRY_Work += pstRcvSpldInfo->usRcvDataSize;

				if (gstAppInfo.stCieNetInfo.usMaxSizeRY < gusSizeRY_Work) {
					if (2 < usSpldLoop) {
						usSpldLoop = 2;
					}
					vNMG_SetNmgErr(EVENTCODE_RXRY_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_003 + usSpldLoop]);
					return NX_UL_NG;
				}
			}
			else if (SPLD_TYPE_RWW == uchSpldType) {
				ulRWwChk++;
				gusSizeRWw_Work	+= pstRcvSpldInfo->usRcvDataSize;

				if (gstAppInfo.stCieNetInfo.usMaxSizeRWw < gusSizeRWw_Work) {
					if (2 < usSpldLoop) {
						usSpldLoop = 2;
					}
					vNMG_SetNmgErr(EVENTCODE_RWRRWW_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_003 + usSpldLoop]);
					return NX_UL_NG;
				}
			}
#ifdef SAFETY_PDU_ENABLE
			else if (SPLD_TYPE_SPDUY == uchSpldType) {
				ulSpduyChk++;
				gusSizeSpduy_Work += pstRcvSpldInfo->usRcvDataSize;

				if (gstAppInfo.stCieNetInfo.usMaxSizeSpduy < gusSizeSpduy_Work) {
					if (2 < usSpldLoop) {
						usSpldLoop = 2;
					}
					vNMG_SetNmgErr(EVENTCODE_SPDUXY_SIZEERR, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_003 + usSpldLoop]);
					return NX_UL_NG;
				}
			}
#endif
			else {
				if (2 < usSpldLoop) {
					usSpldLoop = 2;
				}
				vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_003 + usSpldLoop]);
				return NX_UL_NG;
			}

			pstSubPayL[usSpldLoop].uchDataExist	  = (NX_UCHAR)NX_ON;
			pstSubPayL[usSpldLoop].uchDataOrderNo = (NX_UCHAR)usSpldLoop;
			pstSubPayL[usSpldLoop].usSize		  = pstRcvSpldInfo->usRcvDataSize;
			pstSubPayL[usSpldLoop].uchType		  = uchSpldType;
			pstSubPayL[usSpldLoop].ulRcvDataAddr  = pstRcvSpldInfo->ulRcvDataStorageAddr;

			if (0 < uchSpldDivNo) {
				pstSubPayL[usSpldLoop-1].uchDivNo	= uchSpldDivNo;
				pstSubPayL[usSpldLoop].uchDivNo		= uchSpldDivNo + 1;
			}
			else {
				pstSubPayL[usSpldLoop].uchDivNo		= uchSpldDivNo;
			}

			uchPreSpldType		= uchSpldType;
			uchPreSpldDivNo		= uchSpldDivNo;
			ulPreSpldEndAddr	= pstRcvSpldInfo->ulRcvDataStorageAddr + pstRcvSpldInfo->usRcvDataSize;

			ulAddrRcvSpldInfo	= ulAddrRcvSpldInfo + sizeof(RCV_SUBPAYLOAD_INFO);
			pstRcvSpldInfo		= (RCV_SUBPAYLOAD_INFO*)ulAddrRcvSpldInfo;
		}

		if ((SYNCMODE_SYNC == gstNET.stApp.usSyncMode) &&
			(NX_WDCFUNC_ENBL == gstNM.stSlaveConfig.usWdcFuncSts)) {
			if ((gusSizeRWw_Work < (gstAppInfo.stWdcInfo.stRcvSpldWdcInfo.usWdcOffset + (NX_USHORT)NX_TWO)) &&
				(NX_WDC_DL_OFFSET_NOCHECK != gstAppInfo.stWdcInfo.stRcvSpldWdcInfo.usWdcOffset)) {
				vNMG_SetNmgErr(EVENTCODE_RW_SETERR, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_003]);
				return NX_UL_NG;
			}
		}

#ifndef SAFETY_PDU_ENABLE
		if ((ulRYChk	> (NX_ULONG)NX_SPLD_NUM_RY) ||
			(ulRWwChk	> (NX_ULONG)NX_SPLD_NUM_RWW)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_006]);
			return NX_UL_NG;
		}
#else
		if ((ulRYChk	> (NX_ULONG)NX_SPLD_NUM_RY) ||
			(ulRWwChk	> (NX_ULONG)NX_SPLD_NUM_RWW)||
			(ulSpduyChk	> (NX_ULONG)NX_SPLD_NUM_SPDUY)) {
			vNMG_SetNmgErr(EVENTCODE_NETSETTING2, (NX_USHORT*)&DetailErrorTbl_CycCfgRcvSpd[NMG_IDX_ERR_PARAM_006]);
			return NX_UL_NG;
		}
#endif
	}

	if (NX_UL_NG == ulRespRslt) {
		return NX_UL_NG;
	}

	return NX_UL_OK;
}

NX_VOID vNMG_Extract_CycCfgRcvSpdReq (
	FRM_CC_RCV_SP_REQ	*pstFrm
)
{

	gstNET.stCyc.usSizeRY = gusSizeRY_Work;
 	gstNET.stCyc.usSizeRWw = gusSizeRWw_Work;
#ifdef SAFETY_PDU_ENABLE
 	gstNET.stCyc.usSizeSpduy = gusSizeSpduy_Work;
#endif




	vCYC_SetRcvAddrInfo(&gstNET.stCyc.astRcvSubPayL[NX_ZERO]);

	return;
}

NX_VOID vNMG_CreateCycCfgRcvSpdRespNrml (
	FRM_CC_RCV_SP_REQ	*pstReq
)
{
	FRM_CC_RCV_SP_RESP_NORMAL	*pstResp;
	
	pstResp = (FRM_CC_RCV_SP_RESP_NORMAL*)gstNM.stTrnBuf.puchCyclicConfigRcvSubPayloadResp;
	
	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						SLMP_FINISHCODE_NORMAL,
						sizeof(FRM_CC_RCV_SP_RESP_NORMAL) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero		 = NX_ZERO;
	pstResp->uchMsgId			 = NX_ZERO;
	pstResp->usDivisionTotalNum	 = NX_ZERO;
	pstResp->usDivisionId		 = NX_ZERO;

	return;
}

NX_VOID vNMG_CreateCycCfgRcvSpdRespFault (
	FRM_CC_RCV_SP_REQ		*pstReq,
	NX_USHORT				usFinCode
)
{
	FRM_CC_RCV_SP_RESP_ERR	*pstResp;

	pstResp = (FRM_CC_RCV_SP_RESP_ERR*)gstNM.stTrnBuf.puchCyclicConfigRcvSubPayloadResp;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
						&pstResp->stSlmpHead,
						usFinCode,
						sizeof(FRM_CC_RCV_SP_RESP_ERR) - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_TrnsStsRcvCycCfgRcvSpdReq ( NX_VOID )
{
	NX_USHORT	usAuthClass	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	if (gstNM.stNet.usNetSts == NETSTS_RCVD_SLCFG) {
		gstNM.stNet.usStatusFinish |= FIN_RCVD_CYCCFG_RCVSPD;
		
		if (FIN_RCVD_CYCCFG == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG)) {
			gstNM.stNet.usNetSts = NETSTS_RCVD_CYCCFG;
			if ( FIN_RCVD_CYCCFG_TIMECMP == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TIMECMP) ) {
				
				usAuthClass = usACM_GetAuthenticationClass();
				
				if ( NX_AUTHENTICATION_CLS_B == usAuthClass ) {
					vNMG_ComCycEnable();
				}
				else {
					vNMG_PrepareDLinkClassA();
				}
			}
		}
	}
	
	return;
}


/*[EOF]*/
