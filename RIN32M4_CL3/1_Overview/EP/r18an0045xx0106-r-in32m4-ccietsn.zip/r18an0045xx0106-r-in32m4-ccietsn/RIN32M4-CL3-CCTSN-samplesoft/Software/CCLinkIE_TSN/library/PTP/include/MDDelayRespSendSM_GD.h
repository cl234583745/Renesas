/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPSENDSM_GD_H__
#define __MDDELAYRESPSENDSM_GD_H__

typedef enum tagMDDRESPSNDSM_ST {
	MDDRPS_NONE = 0,
	MDDRPS_NOT_ENABLED,
	MDDRPS_WAITING_SND_DRESP,
	MDDRPS_STATUS_MAX

}	MDDRESPSNDSM_ST;
#define	DMDDRPS_STATUS_MAX			3

typedef enum tagMDDRESPSNDSM_EV {
	MDDRPS_E_BEGIN = 0,
	MDDRPS_E_RCVD_MDDELAY_RESP,
	MDDRPS_E_CLOSE,
	MDDRPS_E_EVENT_MAX

}	MDDRESPSNDSM_EV;
#define	DMDDRPS_E_EVENT_MAX			3

typedef struct tagMDDRESPSDSM_GD
{
	MDDRESPSNDSM_ST		enStsMDDRespSnd;
	
	BOOL				blRcvdMDDelayResp;
	
	PTPMSG_DELAY_RESP_1588	stTxDelayResp1588;
		
}	MDDRESPSDSM_GD;

#endif
