//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _USS_MTMACRO_H_
#define _USS_MTMACRO_H_

#define MT 0


#define BLOCKPREE()		Ndisable()
#define RESUMEPREE()	Nenable()

#define YIELD() \
{ int wnetno; \
    for (wnetno=0; wnetno<NNETS; wnetno++) \
	NetTask(wnetno); \
}


#define SERV_PRIOR 100
#define CLIENT_PRIOR 100
#define NET_PRIOR 110

#define TASKFUNCTION void
#define RUNTASK(func, prior) 0, func()


#define EVBASE 0

#define WAITNOMORE(signo)
#define WAITNOMORE_IR(signo)

#define WAITFOR(condition, signo, msec, flag) \
{ unsigned long wwul1; \
    for (flag=0,wwul1=TimeMS(); !(condition); ) { \
	if (TimeMS()-wwul1 >= msec) { \
	    flag = ETIMEDOUT; \
	    break; \
	} \
	YIELD(); \
}   }

void Ninitchr(void);
void Nputchr (char);
char Ngetchr (void);
long Nchkchr (void);

unsigned long Nclock( void );
void Ndisable( void );
void Nenable( void );

void ForceNenable(void);

#endif
