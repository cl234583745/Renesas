/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayReqReceiveSM.h"
#include "MDDelayReqReceiveSM_1588.h"
#include "MDDelayReqSendSM.h"
#include "MDDelayReqSendSM_1588.h"
#include "MDDelayRespSendSM.h"
#include "MDDelayRespSendSM_1588.h"
#include "ptp_CDSend_1588.h"
#include "ptp_PDRQSend_1588.h"
#include "ptp_PDRSSend_1588.h"
#include "ptp_PDRQReceive_1588.h"

#define D_FUNC	0
#define D_DBG	0


VOID	PDRQReceive_1588_00(PORTDATA*	pstPortData);
VOID	PDRQReceive_1588_01(PORTDATA*	pstPortData);
VOID	PDRQReceive_1588_02(PORTDATA*	pstPortData);
MDDELAYRESP*  setMDDRSSend_PDRQR(MDDELAYREQ*	pstTxMDDReqRcvPtr, PORTDATA*	pstPortData);
VOID	txPDRSSend(MDDELAYRESP*	pstTxMDDRespSndPtr, PORTDATA*	pstPortData);
MDDELAYREQ*  setMDDRQSend(MDDELAYREQ*	pstTxMDDReqRcvPtr, PORTDATA*	pstPortData);
VOID  txCDSDRQSend(MDDELAYREQ*	pstTxMDDRQSendPtr, PORTDATA*	pstPortData);





VOID (*const pfnPDRQReceiveMatrix[ST_PDRQR_MAX][EV_PDRQR_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PDRQReceive_1588_01, &PDRQReceive_1588_01, &PDRQReceive_1588_00},
	{&PDRQReceive_1588_01, &PDRQReceive_1588_02, &PDRQReceive_1588_00},
	{&PDRQReceive_1588_01, &PDRQReceive_1588_02, &PDRQReceive_1588_00}
};



VOID	 portDelayReqReceive_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRQR	enEvt = EV_PDRQR_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("PDRQReceiveSM_1588   Evt=%d Sts=%d\n", usEvent, pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQReceiveSM_1588_GD.enStatusPDRQR);
}
#endif
		enEvt = GetPDRQReceiveSM_1588_Event(usEvent, pstPortData);

		blSts = IsPDRQReceiveSM_1588_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PDRQR_EVENT_MAX))
		{
			(*pfnPDRQReceiveMatrix[pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQReceiveSM_1588_GD.enStatusPDRQR][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PDRQRECEIVESM_1588, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQReceiveSM_1588_GD.blRcvdMDDelayReq	= FALSE;
		}

	}
}



PDRQRECEIVESM_1588_GD*	GetPDRQReceiveSM_1588_GD(
	PORTDATA*		pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb = &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQReceiveSM_1588_GD);
	return pstPDRQRGlb;
}




EN_EV_PDRQR	GetPDRQReceiveSM_1588_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRQR				enEvt				= EV_PDRQR_EVENT_MAX;
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb		= GetPDRQReceiveSM_1588_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PDRQR_BEGIN;
			break;

		case PTP_EV_FOR_PDLRQRV_RCVMDDLRQ:
			if ((pstPDRQRGlb->blRcvdMDDelayReq) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PDRQR_BEGIN;
			}
			else if (pstPDRQRGlb->enStatusPDRQR == ST_PDRQR_DISCARD)
			{
				if ((pstPDRQRGlb->blRcvdMDDelayReq) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PDRQR_FOR_PDLRQRV_RCVMDDLRQ;
				}
			}
			else if (pstPDRQRGlb->enStatusPDRQR == ST_PDRQR_RECEIVED_DELAYREQ)
			{
				if ((pstPDRQRGlb->blRcvdMDDelayReq) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PDRQR_FOR_PDLRQRV_RCVMDDLRQ;
				}
			}
			else
			{
			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PDRQR_CLOSE;
			break;

		default:
			enEvt = EV_PDRQR_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsPDRQReceiveSM_1588_Status(
	PORTDATA*	pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb = GetPDRQReceiveSM_1588_GD(pstPortData);
	BOOL					blRet			= FALSE;

	if (pstPDRQRGlb->enStatusPDRQR < ST_PDRQR_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	PDRQReceive_1588_00(
	PORTDATA*		pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb = GetPDRQReceiveSM_1588_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PDRQReceive_1588_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPDRQRGlb->blRcvdMDDelayReq	= FALSE;
	pstPDRQRGlb->enStatusPDRQR		= ST_PDRQR_NONE;

	ptp_dbg_msg( D_FUNC, ("PDRQReceive_1588_00::-\n") );
}




VOID	PDRQReceive_1588_01(
	PORTDATA*		pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb = GetPDRQReceiveSM_1588_GD(pstPortData);


	pstPDRQRGlb->blRcvdMDDelayReq	= FALSE;
	pstPDRQRGlb->enStatusPDRQR		= ST_PDRQR_DISCARD;
}




VOID	PDRQReceive_1588_02(
	PORTDATA*		pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb			= GetPDRQReceiveSM_1588_GD(pstPortData);
	CLOCKDATA*				pstClockData		= pstPortData->pstClockData;
	MDDELAYREQ*				pstRcvdMDDReqRcvPtr = &(pstPortData->stPort_GD.stMdDelayReqRcv);
	MDDELAYREQ*				pstTxMDDReqRcvPtr	= NULL;
	MDDELAYRESP*			pstTxMDDRespSndPtr	= NULL;

	ptp_dbg_msg(D_FUNC, ("PDRQReceive_1588_02::+\n"));

	pstPDRQRGlb->blRcvdMDDelayReq = FALSE;
	pstPDRQRGlb->pstRcvdMDDReqRcvPtr = pstRcvdMDDReqRcvPtr;

	if (IS_OD_BC_1588(pstClockData) &&
		(pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE))
	{
		ptp_dbg_msg(D_DBG, ("[E2E]\n"));
		if (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER)
		{
			pstTxMDDRespSndPtr = setMDDRSSend_PDRQR(pstRcvdMDDReqRcvPtr, pstPortData);

			txPDRSSend(pstTxMDDRespSndPtr, pstPortData);
		}
	}
	else if (pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 == ENUM_CSTYPE_TRANSCLOCKE2E_1588)
	{
		pstTxMDDReqRcvPtr = setMDDRQSend(pstRcvdMDDReqRcvPtr, pstPortData);

		txCDSDRQSend(pstTxMDDReqRcvPtr, pstPortData);
	}
	else
	{
		ptp_dbg_msg(D_DBG, ("[P2P]\n"));
	}

	pstPDRQRGlb->enStatusPDRQR	= ST_PDRQR_RECEIVED_DELAYREQ;

	ptp_dbg_msg(D_FUNC, ("PDRQReceive_1588_02::-\n"));
}




MDDELAYRESP*  setMDDRSSend_PDRQR(
	MDDELAYREQ*		pstTxMDDReqRcvPtr,
	PORTDATA*		pstPortData)
{
	MDDELAYRESP*			pstTxMDDRSSendPtr	= &(pstPortData->stPort_GD.stMdDelayRespSnd);


	pstTxMDDRSSendPtr->uchClockNumber        = pstTxMDDReqRcvPtr->uchClockNumber;
	pstTxMDDRSSendPtr->stCorrectionField     = pstTxMDDReqRcvPtr->stCorrectionField;
	pstTxMDDRSSendPtr->stRequestPortIdentity = pstTxMDDReqRcvPtr->stSourcePortIdentity;
	pstTxMDDRSSendPtr->usSequenceId          = pstTxMDDReqRcvPtr->usSequenceId;
	pstTxMDDRSSendPtr->stReceiveTimestamp    = pstTxMDDReqRcvPtr->stOriginTimestamp;
	pstTxMDDRSSendPtr->stSourcePortIdentity  = pstPortData->stPortDS.stPortIdentity;
	pstTxMDDRSSendPtr->chLogMessageInterval  = pstPortData->stPort_1588_DS.chLogMinDelayReqInterval;

	return pstTxMDDRSSendPtr;
}




VOID	txPDRSSend(
	MDDELAYRESP*	pstTxMDDRespSndPtr,
	PORTDATA*		pstPortData)
{

	USHORT				usEvent					= PTP_EV_BASE;
	PDRSSENDSM_1588_GD*	pstPDRSSendSM_1588_GD	= &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD);


	pstPDRSSendSM_1588_GD->pstRcvdMDDRespRcvPtr = pstTxMDDRespSndPtr;
	pstPDRSSendSM_1588_GD->blRcvdMDDelayResp	= TRUE;

	usEvent = PTP_EV_FOR_PDLRSSND_RCVMDDLRS;
	portDelayRespSend_1588(usEvent, pstPortData);

}




MDDELAYREQ*  setMDDRQSend(
	MDDELAYREQ*		pstTxMDDReqRcvPtr,
	PORTDATA*		pstPortData)
{
	PDRQRECEIVESM_1588_GD*	pstPDRQRGlb			= GetPDRQReceiveSM_1588_GD(pstPortData);
	MDDELAYREQ*				pstTxMDDRQSendPtr	= &(pstPortData->stPort_GD.stMdDelayReqSnd);


	*pstTxMDDRQSendPtr = *pstTxMDDReqRcvPtr;
	pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.usRcvdMDDReqRcvPNumber =
		pstPortData->stPort_GD.usThisPort;

	pstPDRQRGlb->pstTxMDDReqSndPtr = pstTxMDDRQSendPtr;

	return pstTxMDDRQSendPtr;
}



VOID  txCDSDRQSend(
	MDDELAYREQ*		pstTxMDDRQSendPtr,
	PORTDATA*		pstPortData)
{

	USHORT				usEvent				= PTP_EV_BASE;
	CLOCKDATA*			pstClockData		= pstPortData->pstClockData;
	CDSENDSM_1588_GD*	pstCDSendSM_1588_GD = NULL;


	pstCDSendSM_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD);

	pstCDSendSM_1588_GD->pstRcvdMDDReqRcvPtr	= pstTxMDDRQSendPtr;
	pstCDSendSM_1588_GD->blRcvdMDDelayReq	= TRUE;

	usEvent = PTP_EV_DELAYREQ_SEND_1588;
	clockDelaySend_1588(usEvent, pstClockData);

}



#endif

