/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifndef QBV_DEFINE_H
#define QBV_DEFINE_H

#define UNREF_PARA(x) ((void)(x))

#define START_PORT_NO		(1)
#define START_CLASS_NO		(1)
#define MINIMUM_SEND_SIZE	(60)
#define MAX_SEND_SIZE		(1514)


#define INIT_MASIC_NO		(0xA55AC33CUL)

#define QBVE_CONF_CHANHGE	(0)
#define QBVE_GATE_DISABLE	(1)
#define QBVE_SEND_REQUEST	(2)
#define QBVE_TICK			(3)
#define QBVE_SEND_COMPLET	(4)

#define RET_ESTATE			(2)
#define RET_ENOMEM			(3)
#define RET_EINTERNAL		(4)

#define GPARA_QMAX_SDU				((USHORT)1)
#define GPARA_GATE_ENABL			((USHORT)2)
#define GPARA_ADMI_GSTAT			((USHORT)3)
#define GPARA_OPER_GSTAT			((USHORT)4)
#define GPARA_ADMI_CNTLST_LEN		((USHORT)5)
#define GPARA_OPER_CNTLST_LEN		((USHORT)6)
#define GPARA_ADMI_CNT_LST			((USHORT)7)
#define GPARA_OPER_CNT_LST			((USHORT)8)
#define GPARA_ADMI_CYCL_TIME		((USHORT)9)
#define GPARA_OPER_CYCL_TIME		((USHORT)10)
#define GPARA_ADMI_CYCLT_EXT		((USHORT)11)
#define GPARA_OPER_CYCLT_EXT		((USHORT)12)
#define GPARA_ADMI_BASE_TIME		((USHORT)13)
#define GPARA_OPER_BASE_TIME		((USHORT)14)
#define GPARA_CONF_CHNG				((USHORT)15)
#define GPARA_CONFCHNG_TIME			((USHORT)16)
#define GPARA_TICK_GRANUL			((USHORT)17)
#define GPARA_CURR_TIME				((USHORT)18)
#define GPARA_CONF_PEND				((USHORT)19)
#define GPARA_CONFCHNG_ERR			((USHORT)20)
#define GPARA_SUPP_LISTMAX			((USHORT)21)
#define GPARA_MAXFRAM_TXTIME		((USHORT)22)
#define GPARA_CLASSQUE_MAX			((USHORT)23)

#define		QBVS_LCONF_IDLE		(0)
#define		QBVS_LCONF_TWAIT	(1)
#define		QBVS_CTIME_IDLE		(0)
#define		QBVS_CTIME_TWAIT	(1)
#define		QBVS_LEXEC_IDLE		(0)
#define		QBVS_LEXEC_CYCLE	(1)

#endif
