/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDCOMMONSM_H__
#define __MDCOMMONSM_H__

#include "ptp_Macro.h"

#include "ptp_tsn_Wrapper.h"
#include "mdtransinterface.h"
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_CommonFunction.h"

typedef enum tagENUM_MDCOM_TIMERTYPE
{
	MDCOM_TMTYPE_MASTER = 0,
	MDCOM_TMTYPE_LOCAL

} ENUM_MDCOM_TIMERTYPE;

#ifdef __cplusplus
extern "C" {
#endif

#ifdef	PTP_USE_IEEE802_1
BOOL	IsMDCOMSupportPTPTyp802_1AS(PORTDATA* pstPort);
#endif
#ifdef	PTP_USE_IEEE1588
BOOL	IsMDCOMSupportPTPTyp1588(PORTDATA* pstPort);

BOOL	IsMDCOMClockSupportTypOC(PORTDATA* pstPort);
BOOL	IsMDCOMClockSupportTypBC(PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL	IsMDCOMClockSupportTypTC_E2E(PORTDATA* pstPort);
BOOL	IsMDCOMClockSupportTypTC_P2P(PORTDATA* pstPort);
#endif
#endif
BOOL	GetMDCOMClockTime(CLOCKDATA* pstClock, ENUM_MDCOM_TIMERTYPE enTMType, TIMESTAMP* pstTimestamp);

VOID	GetMDCOMTimeStampNs(TIMESTAMP* pstA_TimeStamp, TIMESTAMP* pstB_TimeStamp);
VOID	ClrMDCOMTimeStampNs(TIMESTAMP* pstA_TimeStamp, TIMESTAMP* pstB_TimeStamp);


#ifdef __cplusplus
}
#endif

#endif
