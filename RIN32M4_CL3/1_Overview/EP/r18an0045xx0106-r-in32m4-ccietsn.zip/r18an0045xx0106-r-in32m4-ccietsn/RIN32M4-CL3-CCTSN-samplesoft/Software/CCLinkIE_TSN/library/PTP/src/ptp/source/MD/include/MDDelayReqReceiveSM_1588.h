/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYREQRECEIVESM_1588_H__
#define __MDDELAYREQRECEIVESM_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDDelayReqReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDDelayReqReceiveSM_00_1588(PORTDATA* pstPort);
VOID MDDelayReqReceiveSM_01_1588(PORTDATA* pstPort);
VOID MDDelayReqReceiveSM_02_1588(PORTDATA* pstPort);
VOID MDDelayReqReceiveSM_NP_1588(PORTDATA* pstPort);

BOOL MDDReqRcv_NotEnable_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDDReqRcv_WtFrDReq_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxMDDelayReqReceive_1588(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
