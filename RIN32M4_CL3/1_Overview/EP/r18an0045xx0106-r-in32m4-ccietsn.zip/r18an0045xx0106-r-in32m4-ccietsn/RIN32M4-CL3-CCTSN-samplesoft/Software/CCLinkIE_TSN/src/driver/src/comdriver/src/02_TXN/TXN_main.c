/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "itron.h"
#include "kernel.h"
#include "TOOL_api.h"
#include "networkram.h"
#include "TXN_api.h"
#include "TXN_buf.h"
#include "INTR_api.h"
#include "TXN_main.h"
#include "ccienx_api.h"
#include "ccienx_task.h"
#include "NMG_common.h"
#include "LSM_api.h"
#include "NMG_api.h"
#include "CYC_common.h"
#include "ACM_api.h"


#define	TXN_TS_NO_FOR_TSN			(2)
#define	TXN_TXNCT_TS0				(1)
#define	TXN_TXNCT_NOT_TS0_TSN		(1)
#define	TXN_NCYC_DELAY_START_CNT	((NX_ULONGLONG)2)

#define	SHIFT_SNDDISCRIPTNEXTNO		(8)
#define	SHIFT_FRAMEFORMAT			(4)
#define	SHIFT_FRAMECONFIGVLAN		(3)
#define	SHIFT_FRAMEFLAG				(0)
#define	SHIFT_LASTFLG				(1)
#define	SHIFT_SNDFRAMEPORT1			(11)
#define	SHIFT_SNDFRAMEPORT2			(12)
#define	SHIFT_SENDHEADERFRMSIZE		(0)
#define	SHIFT_DATASIZE				(0)
#define	SHIFT_SENDSTART				(3)

#define	MASK_DIS1_PDUTOPNO			(0x7FF00000)
#define	MASK_PDU_NEXT				(0x07FF0000)
#define	MASK_PDU_LAST				(0x00001000)

#define	DIS_UPDATE_ON				(0x00000001)

#define	ONCYCLESNDTMGCTRLEN			((NX_ULONG)0x00004000)
#define	ONCYCLESNDSTARTFLAG			((NX_ULONG)0x00000001)

#define	RESULT_ERR					(0xFFFFFFFF)
#define	ERRBITPOINT					(0x00000100)

#define	WAITTIME_DMA				(16)
#define	WAITTIME_HWCHANGE			(15000 * 2)
#define	WAITTIME_COMP				(15000 * 4)
#define	WAIITIME_AUTOSEND			((NX_ULONGLONG)2)
#define	WAITTIME_SEND_CLASSA		(2)

#define	SENDSTATE_TS0_OK		((NX_ULONG)0x0001)
#define	SENDSTATE_TS0_NG		((NX_ULONG)0x0100)

#define	NONCYCSENDCOMP				(0x0000FFFF)

#define	FLGP_NOCYC_TS0			(0x0001)
#define	FLGP_NOCYC_TS1			(0x0002)
#define	FLGP_NOCYC_TS2			(0x0004)
#define	FLGP_NOCYC_TS3			(0x0008)
#define	FLGP_NOCYC_TS4			(0x0010)
#define	FLGP_NOCYC_TS5			(0x0020)
#define	FLGP_NOCYC_TS6			(0x0040)
#define	FLGP_NOCYC_TS7			(0x0080)

#define	TX_TSMAX				((NX_USHORT)4)


typedef struct tagNCYC_TX_INFO {
	NX_USHORT		usTsNo;
	NX_USHORT		usTxDisc;
	NCYC_TX_FRAME*	pstTxFrame;
} NCYC_TX_INFO;

typedef struct tagTX_INFO_LIST {
	NX_USHORT		usFrameNum;
	NCYC_TX_INFO	stInfo[NCYC_MAXNUM + 1];
} NCYC_TX_INFO_LIST;

typedef struct tagNCYC_TX_SNDSTRFLG {
	NX_USHORT		usFlgPtn;
	NX_ULONG*		pulSndStrData;
} NCYC_TX_SNDSTRFLG;

typedef struct tagNCYC_TX_DISPAY {
	NX_USHORT	usNextNo;
	NX_USHORT	usFramFormat;
	NX_USHORT	usVLAN;
	NX_USHORT	usLastFlg;
	NX_USHORT	usPort1;
	NX_USHORT	usPort2;
	NX_USHORT	usHeaderSize;
	NX_USHORT	usDataSize;
} NCYC_TX_DISPAY;

NX_STATIC	NX_USHORT	gusTsNoForTSN = TXN_TS_NO_FOR_TSN;

NX_ULONG	gulTsState;

NX_STATIC NX_CONST NCYC_TX_SNDSTRFLG SendStartFlgTbl[TS_SIZE] = {
	{FLGP_NOCYC_TS0,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOTF.DATA	},
	{FLGP_NOCYC_TS1,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[0].DATA},
	{FLGP_NOCYC_TS2,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[1].DATA},
	{FLGP_NOCYC_TS3,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[2].DATA},
	{FLGP_NOCYC_TS4,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[3].DATA},
	{FLGP_NOCYC_TS5,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[4].DATA},
	{FLGP_NOCYC_TS6,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[5].DATA},
	{FLGP_NOCYC_TS7,	(NX_ULONG*)&NGN_CN_TN1_REG->R_MUSLOT[6].DATA}
};

NX_CONST NX_USHORT MailBoxIdList[TS_SIZE] =	{
	MBXID_NX_SEND_TS0,
	MBXID_NX_SEND_TS1,
	MBXID_NX_SEND_TS2,
	MBXID_NX_SEND_TS3,
	MBXID_NX_SEND_TS4,
	MBXID_NX_SEND_TS5,
	MBXID_NX_SEND_TS6,
	MBXID_NX_SEND_TS7
};


NX_STATIC NX_VOID vTXN_TxNonCycFrame_NotTs(NX_VOID);
NX_STATIC NX_VOID vTXN_TxNonCycFrame_Ts(NX_VOID);
NX_STATIC NX_VOID vTXN_MakeNonCycTxList_Ts(NCYC_TX_INFO_LIST*, NX_USHORT*);
NX_STATIC NX_VOID vTXN_MakeNonCycTxList_NotTs(NCYC_TX_INFO_LIST*);
NX_STATIC NX_VOID vTXN_MakeNonCycTxList_TS0(NCYC_TX_INFO_LIST*, NX_USHORT, NX_USHORT*);
NX_STATIC NX_VOID vTXN_MakeNonCycTxList_TSN(NCYC_TX_INFO_LIST*, NX_USHORT, NX_USHORT*);
NX_STATIC NX_VOID vTXN_MakeNonCycTxList_Normal(NCYC_TX_INFO_LIST*, NX_USHORT, NX_USHORT*);
NX_STATIC NX_VOID vTXN_MakeTxPduDisc_NotTs(NCYC_TX_INFO_LIST*);
NX_STATIC NX_VOID vTXN_MakeTxPduDisc_Ts(NCYC_TX_INFO_LIST*);
NX_STATIC NX_VOID vTXN_SetDisPay (NCYC_TX_DISPAY, NX_USHORT);
NX_STATIC NX_VOID vTXN_MakeDmaList(NCYC_TX_INFO_LIST*, DMA_ITEM*);
NX_STATIC NX_USHORT usTXN_GetTxDiscNo(NCYC_TX_FRAME*);
NX_STATIC NX_VOID vTXN_StartNonCycTx_NotTs(NX_VOID);
NX_STATIC NX_VOID vTXN_StartNonCycTx_Ts(NX_USHORT usSendBitFld);
NX_STATIC NX_VOID vTXN_NonCycTxComp (NCYC_TX_INFO_LIST*, 	NX_SHORT, FLGPTN);
NX_STATIC NX_VOID vTXN_InitTsState (NX_VOID);
NX_STATIC NX_VOID vTXN_DisableTs (NX_VOID);
NX_STATIC NX_VOID vTXN_SendCycFrame_ClassA (NX_VOID);
NX_STATIC NX_ULONG ulTXN_StartSendFrame_ClassA (NX_VOID);

NX_EXTERN TXDISC_UPD_FUNC	gfpTxDiscUpdFunc;

NX_VOID vTXN_Init (NX_VOID)
{
	vTXN_InitNonCycTxBuf();
	vTXN_InitTsState();
	
	return;
}

NX_VOID vTXN_InitTsState (NX_VOID)
{
	gulTsState = (NX_ULONG)TSREQ_DICOMP;
	return;
}

NX_VOID vNX_Task_TxNonCycFrame (NX_VOID)
{
	NX_ULONG	ulCheckResult;
	NX_USHORT	usLinkSpdSta = 	NX_LINKSPD_STA_1G;
	while (NX_ONE) {
		slp_tsk();
		switch (gulTsState) {
		case TSSTATE_DI:
			vTXN_TxNonCycFrame_NotTs();
			break;
		case TSSTATE_EI_REQ:
			ulCheckResult = ulINTR_CheckIntLow(INTR_LOW_CYCLECOMPE_PORT1);
			if (ulCheckResult == (NX_ULONG)NX_ON) {
				gulTsState = (NX_ULONG)TSSTATE_DI_REQWAIT;
				NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= (NX_ULONG)DIS_UPDATE_ON;
				vINTR_ClearIntLow(INTR_LOW_CYCLECOMPE_PORT1);
				usLinkSpdSta	=	usLSM_GetLinkSpd();
				if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
					vINTR_ClearIntLow(INTR_LOW_CYCLESWICH_PORT1_100);
					vINTR_MaskClearIntLow(INTR_LOW_CYCLESWICH_PORT1_100);
				}
				else {
					vINTR_ClearIntLow(INTR_LOW_CYCLESWICH_PORT1);
					vINTR_MaskClearIntLow(INTR_LOW_CYCLESWICH_PORT1);
				}
			}
			else {
				vTXN_TxNonCycFrame_NotTs();
			}
			break;
		case TSSTATE_DI_REQWAIT:
			break;
		case TSSTATE_EN:
			vTXN_TxNonCycFrame_Ts();
			break;
		case TSSTATE_DI_REQ:
			vTXN_DisableTs();
			vTXN_TxNonCycFrame_NotTs();
			gulTsState = (NX_ULONG)TSSTATE_DI;
			break;
		default:
			break;
		}
		(NX_VOID)can_wup(TSKID_NX_NCYC_TX);
	}
	return;
}

NX_STATIC NX_VOID vTXN_TxNonCycFrame_NotTs (NX_VOID)
{
	NCYC_TX_INFO_LIST	stTxInfoList;
	DMA_ITEM			astDmaList[NCYC_MAXNUM + 1];
	FLGPTN				flgPtn = (FLGPTN)NX_OFF;
	NX_LONG				lDiscResult = (NX_LONG)NX_OFF;
	NX_SHORT			sWaitResult = (NX_SHORT)E_OK;
	
	vTXN_MakeNonCycTxList_NotTs(&stTxInfoList);
	
	lDiscResult = lNMG_Set_SndDiscCtrlArea();
	
	
	if (stTxInfoList.usFrameNum > (NX_USHORT)NX_ZERO) {
		vTXN_MakeTxPduDisc_NotTs(&stTxInfoList);
		vTXN_MakeDmaList(&stTxInfoList, astDmaList);
		clr_flg(EVFLGID_NX_DMACOMP03, (FLGPTN)(~FLGP_DMACOMP));
		vNX_ExecDmaLinkMode(DMA_CHANNEL_3, astDmaList);
		flgPtn = (FLGPTN)NX_OFF;
		sWaitResult = twai_flg(EVFLGID_NX_DMACOMP03, FLGP_DMACOMP, TWF_ANDW, &flgPtn, WAITTIME_DMA);
		if (sWaitResult != (NX_SHORT)E_OK) {
		}
		else {
			clr_flg(EVFLGID_NX_TXDISC_UPD, (FLGPTN)(~FLGP_TXDISC_UPD));
			NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= (NX_ULONG)DIS_UPDATE_ON;
			flgPtn = (FLGPTN)NX_OFF;
			sWaitResult = (NX_SHORT)twai_flg(EVFLGID_NX_TXDISC_UPD, FLGP_TXDISC_UPD, TWF_ANDW, &flgPtn, WAITTIME_HWCHANGE);
			if (sWaitResult != (NX_SHORT)E_OK) {
			}
			else {
				clr_flg(EVFLGID_NX_NOCYCTXCOMP, (FLGPTN)(~FLGP_NOCYC_TS0));
				vTXN_StartNonCycTx_NotTs();
				flgPtn = (FLGPTN)NX_OFF;
				sWaitResult = twai_flg(EVFLGID_NX_NOCYCTXCOMP, FLGP_NOCYC_TS0, TWF_ANDW, &flgPtn, WAITTIME_COMP);
			}
		}
		vTXN_NonCycTxComp(&stTxInfoList, sWaitResult, flgPtn);
	}
	else {
		if (lDiscResult == (NX_LONG)NX_ON) {
			clr_flg(EVFLGID_NX_TXDISC_UPD, (FLGPTN)(~FLGP_TXDISC_UPD));
			NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= (NX_ULONG)DIS_UPDATE_ON;
			sWaitResult = twai_flg(EVFLGID_NX_TXDISC_UPD, FLGP_TXDISC_UPD, TWF_ANDW, &flgPtn, WAITTIME_HWCHANGE);
		}
	}
	
	if (sWaitResult != (NX_SHORT)E_OK) {
	}
	return;
}

NX_STATIC NX_VOID vTXN_TxNonCycFrame_Ts (NX_VOID)
{
	NCYC_TX_INFO_LIST	stTxInfoList;
	DMA_ITEM			astDmaList[NCYC_MAXNUM + 1];
	FLGPTN				flgPtn = (FLGPTN)NX_OFF;
	NX_USHORT			usSendBitFld = (NX_USHORT)NX_ZERO;
	NX_LONG				lDiscResult = (NX_LONG)NX_OFF;
	NX_SHORT			sWaitResult = (NX_SHORT)E_OK;
	
	vTXN_MakeNonCycTxList_Ts(&stTxInfoList, &usSendBitFld);
	
	lDiscResult = lNMG_Set_SndDiscCtrlArea();
	
	if (stTxInfoList.usFrameNum > (NX_USHORT)NX_ZERO) {
		vTXN_MakeTxPduDisc_Ts(&stTxInfoList);
		vTXN_MakeDmaList(&stTxInfoList, astDmaList);
		clr_flg(EVFLGID_NX_DMACOMP03, (FLGPTN)(~FLGP_DMACOMP));
		vNX_ExecDmaLinkMode(DMA_CHANNEL_3, astDmaList);
		flgPtn = (FLGPTN)NX_OFF;
		sWaitResult = (NX_SHORT)twai_flg(EVFLGID_NX_DMACOMP03, FLGP_DMACOMP, TWF_ANDW, &flgPtn, WAITTIME_DMA);
		if (sWaitResult != (NX_SHORT)E_OK) {
		}
		else {
			clr_flg(EVFLGID_NX_TXDISC_UPD, (FLGPTN)(~FLGP_TXDISC_UPD));
			NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= (NX_ULONG)DIS_UPDATE_ON;
			flgPtn = (FLGPTN)NX_OFF;
			sWaitResult = twai_flg(EVFLGID_NX_TXDISC_UPD, FLGP_TXDISC_UPD, TWF_ANDW, &flgPtn, WAITTIME_HWCHANGE);
			if (sWaitResult != (NX_SHORT)E_OK) {
			}
			else {
				clr_flg(EVFLGID_NX_NOCYCTXCOMP, (FLGPTN)(~usSendBitFld));
				vTXN_StartNonCycTx_Ts(usSendBitFld);
				flgPtn = (FLGPTN)NX_OFF;
				sWaitResult = twai_flg(EVFLGID_NX_NOCYCTXCOMP, usSendBitFld, TWF_ANDW, &flgPtn, WAITTIME_COMP);
			}
		}
		vTXN_NonCycTxComp(&stTxInfoList, sWaitResult, flgPtn);
	}
	else {
		if (lDiscResult == (NX_LONG)NX_ON) {
			clr_flg(EVFLGID_NX_TXDISC_UPD, (FLGPTN)(~FLGP_TXDISC_UPD));
			NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= (NX_ULONG)DIS_UPDATE_ON;
			sWaitResult = twai_flg(EVFLGID_NX_TXDISC_UPD, FLGP_TXDISC_UPD, TWF_ANDW, &flgPtn, WAITTIME_HWCHANGE);
		}
	}
	
	if (sWaitResult != (NX_SHORT)E_OK) {
	}
	return;
}

NX_STATIC NX_VOID vTXN_MakeNonCycTxList_NotTs (
	NCYC_TX_INFO_LIST* pstTxInfoList
)
{
	NCYC_TX_FRAME*	pstTxFrame;
	T_MSG			*pstMsg;
	NX_LONG			lRcvResult;
	NX_USHORT		usTsNo = (NX_USHORT)NX_ZERO;
	NX_USHORT		usFrameCnt = (NX_USHORT)NX_ZERO;
	
	pstTxInfoList->usFrameNum = (NX_USHORT)NX_ZERO;
	
	for (usTsNo = (NX_USHORT)NX_ZERO; usTsNo < (NX_USHORT)TS_SIZE; usTsNo++) {
		while (NX_ONE) {
			lRcvResult = prcv_mbx(MailBoxIdList[usTsNo], (T_MSG**)&pstMsg);
			if (lRcvResult != (NX_LONG)E_OK) {
				break;
			}
			else {
				pstTxFrame = (NCYC_TX_FRAME*)pstMsg;
				pstTxInfoList->stInfo[usFrameCnt].usTsNo = usTsNo;
				pstTxInfoList->stInfo[usFrameCnt].usTxDisc = usTXN_GetTxDiscNo(pstTxFrame);
				pstTxInfoList->stInfo[usFrameCnt].pstTxFrame = pstTxFrame;
				pstTxInfoList->usFrameNum += (NX_USHORT)NX_ONE;
				usFrameCnt += (NX_USHORT)NX_ONE;
			}
		}
	}
	return;
}

NX_STATIC NX_VOID vTXN_MakeNonCycTxList_Ts (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	NX_USHORT*			pusSendBitFld
)
{
	NX_USHORT		usTsNo = (NX_USHORT)NX_ZERO;
	
	pstTxInfoList->usFrameNum = (NX_USHORT)NX_ZERO;
	
	for (usTsNo = (NX_USHORT)NX_ZERO; usTsNo < (NX_USHORT)TS_SIZE; usTsNo++) {
		if (usTsNo == NCYC_TXFRAME_TS0) {
			vTXN_MakeNonCycTxList_TS0(pstTxInfoList, usTsNo, pusSendBitFld);
		}
		else if (usTsNo == gusTsNoForTSN) {
			vTXN_MakeNonCycTxList_TSN(pstTxInfoList, usTsNo, pusSendBitFld);
		}
		else {
			vTXN_MakeNonCycTxList_Normal(pstTxInfoList, usTsNo, pusSendBitFld);
		}
	}
	return;
}

NX_STATIC NX_VOID vTXN_MakeNonCycTxList_TS0 (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	NX_USHORT			usTsNo,
	NX_USHORT* 			pusSendBitFld
)
{
	T_MSG			*pstMsg;
	NCYC_TX_FRAME*	pstTxFrame;
	NX_ULONG		ulMailCnt;
	NX_LONG			lRcvResult;
	NX_USHORT		usFrameNumTmp;
	
	usFrameNumTmp = pstTxInfoList->usFrameNum;
	
	for (ulMailCnt = (NX_ULONG)NX_ZERO; ulMailCnt < (NX_ULONG)TXN_TXNCT_TS0; ulMailCnt++) {
		
		lRcvResult = prcv_mbx(MailBoxIdList[usTsNo], (T_MSG**)&pstMsg);
		if (lRcvResult != (NX_LONG)E_OK) {
			break;
		}
		else {
			pstTxFrame = (NCYC_TX_FRAME*)pstMsg;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTsNo		= usTsNo;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTxDisc	= usTXN_GetTxDiscNo(pstTxFrame);
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].pstTxFrame	= pstTxFrame;
			pstTxInfoList->usFrameNum += (NX_USHORT)NX_ONE;
		}
	}
	if ( usFrameNumTmp < pstTxInfoList->usFrameNum ) {
		*(SendStartFlgTbl[usTsNo].pulSndStrData) = (NX_ULONG)pstTxInfoList->stInfo[usFrameNumTmp].usTxDisc << (NX_ULONG)SHIFT_SENDSTART;
		*pusSendBitFld |= SendStartFlgTbl[usTsNo].usFlgPtn;
	}
}


NX_STATIC NX_VOID vTXN_MakeNonCycTxList_TSN (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	NX_USHORT			usTsNo,
	NX_USHORT* 			pusSendBitFld
)                                                   
{
	T_MSG			*pstMsg;
	NCYC_TX_FRAME*	pstTxFrame;
	NX_LONG			lRcvResult;
	NX_USHORT		usFrameNumTmp;
	
	usFrameNumTmp = pstTxInfoList->usFrameNum;
	
	while (NX_ONE) {
		lRcvResult = prcv_mbx(MailBoxIdList[usTsNo], (T_MSG**)&pstMsg);
		if (lRcvResult != (NX_LONG)E_OK) {
			break;
		}
		else {
			pstTxFrame = (NCYC_TX_FRAME*)pstMsg;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTsNo		= usTsNo;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTxDisc	= usTXN_GetTxDiscNo(pstTxFrame);
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].pstTxFrame	= pstTxFrame;
			pstTxInfoList->usFrameNum += (NX_USHORT)NX_ONE;
		}
	}
	if ( usFrameNumTmp < pstTxInfoList->usFrameNum ) {
		*(SendStartFlgTbl[usTsNo].pulSndStrData) = (NX_ULONG)pstTxInfoList->stInfo[usFrameNumTmp].usTxDisc << (NX_ULONG)SHIFT_SENDSTART;
		*pusSendBitFld |= SendStartFlgTbl[usTsNo].usFlgPtn;
	}
}

NX_STATIC NX_VOID vTXN_MakeNonCycTxList_Normal (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	NX_USHORT			usTsNo,
	NX_USHORT* 			pusSendBitFld
)
{
	T_MSG			*pstMsg;
	NCYC_TX_FRAME*	pstTxFrame;
	NX_ULONG		ulMailCnt;
	NX_LONG			lRcvResult;
	NX_USHORT		usFrameNumTmp;
	
	usFrameNumTmp = pstTxInfoList->usFrameNum;
	
	for (ulMailCnt = (NX_ULONG)NX_ZERO; ulMailCnt < (NX_ULONG)TXN_TXNCT_NOT_TS0_TSN; ulMailCnt++) {
		lRcvResult = prcv_mbx(MailBoxIdList[usTsNo], (T_MSG**)&pstMsg);
		if (lRcvResult != (NX_LONG)E_OK) {
			break;
		}
		else {
			pstTxFrame = (NCYC_TX_FRAME*)pstMsg;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTsNo		= usTsNo;
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].usTxDisc	= usTXN_GetTxDiscNo(pstTxFrame);
			pstTxInfoList->stInfo[pstTxInfoList->usFrameNum].pstTxFrame	= pstTxFrame;
			pstTxInfoList->usFrameNum += (NX_USHORT)NX_ONE;
		}
	}
	if ( usFrameNumTmp < pstTxInfoList->usFrameNum ) {
		*(SendStartFlgTbl[usTsNo].pulSndStrData) = (NX_ULONG)pstTxInfoList->stInfo[usFrameNumTmp].usTxDisc << (NX_ULONG)SHIFT_SENDSTART;
		*pusSendBitFld |= SendStartFlgTbl[usTsNo].usFlgPtn;
	}
}

NX_STATIC NX_VOID vTXN_MakeTxPduDisc_NotTs (
	NCYC_TX_INFO_LIST* pstTxInfoList
)
{
	NCYC_TX_FRAME*		pstTxFrame;
	NCYC_TX_DISPAY		stTxDisPaySetData;
	NX_USHORT			usFrameCnt;
	NX_USHORT			usDiscNo;
	
	for (usFrameCnt = (NX_USHORT)NX_ZERO; usFrameCnt < pstTxInfoList->usFrameNum; usFrameCnt++) {
		pstTxFrame = pstTxInfoList->stInfo[usFrameCnt].pstTxFrame;
		usDiscNo = pstTxInfoList->stInfo[usFrameCnt].usTxDisc;
		
		if (usFrameCnt < (pstTxInfoList->usFrameNum - (NX_USHORT)NX_ONE)) {
			stTxDisPaySetData.usNextNo = pstTxInfoList->stInfo[usFrameCnt + NX_ONE].usTxDisc;
			stTxDisPaySetData.usLastFlg = (NX_USHORT)NX_OFF;
		}
		else {
			stTxDisPaySetData.usNextNo = (NX_USHORT)NX_ZERO;
			stTxDisPaySetData.usLastFlg = (NX_USHORT)NX_ON;
		}
		if (pstTxFrame->usPort == NCYC_TXFRAME_PORT_1) {
			stTxDisPaySetData.usPort1 = (NX_USHORT)NX_ON;
			stTxDisPaySetData.usPort2 = (NX_USHORT)NX_OFF;
		}
		else if (pstTxFrame->usPort == NCYC_TXFRAME_PORT_2){
			stTxDisPaySetData.usPort1 = (NX_USHORT)NX_OFF;
			stTxDisPaySetData.usPort2 = (NX_USHORT)NX_ON;
		}
		else {
			stTxDisPaySetData.usPort1 = (NX_USHORT)NX_ON;
			stTxDisPaySetData.usPort2 = (NX_USHORT)NX_ON;
		}
		stTxDisPaySetData.usDataSize = pstTxFrame->usDataSize;
		stTxDisPaySetData.usFramFormat = pstTxFrame->usFramFormat;
		stTxDisPaySetData.usVLAN = pstTxFrame->usVLAN;
		stTxDisPaySetData.usHeaderSize = pstTxFrame->usHeaderSize;
		
		vTXN_SetDisPay(stTxDisPaySetData, usDiscNo);
	}

	NGN_CN_TN1_REG->R_MUSLOTF.BITS.b0BZSndDiscriptTopNo = pstTxInfoList->stInfo[NX_ZERO].usTxDisc;
	return;
}

NX_STATIC NX_VOID vTXN_MakeTxPduDisc_Ts (
	NCYC_TX_INFO_LIST* pstTxInfoList
)
{
	NCYC_TX_FRAME*		pstTxFrame;
	NCYC_TX_DISPAY		stTxDisPaySetData;
	NX_USHORT			usFrameCnt;
	NX_USHORT			usDiscNo;
	
	for (usFrameCnt = (NX_USHORT)NX_ZERO; usFrameCnt < pstTxInfoList->usFrameNum; usFrameCnt++) {
		pstTxFrame = pstTxInfoList->stInfo[usFrameCnt].pstTxFrame;
		usDiscNo = pstTxInfoList->stInfo[usFrameCnt].usTxDisc;
		
		if (usFrameCnt < (pstTxInfoList->usFrameNum - (NX_USHORT)NX_ONE)) {
			if (pstTxInfoList->stInfo[usFrameCnt].usTsNo != pstTxInfoList->stInfo[usFrameCnt + NX_ONE].usTsNo ) {
				stTxDisPaySetData.usNextNo = (NX_USHORT)NX_ZERO;
				stTxDisPaySetData.usLastFlg = (NX_USHORT)NX_ON;
			}
			else {
				stTxDisPaySetData.usNextNo = pstTxInfoList->stInfo[usFrameCnt + NX_ONE].usTxDisc;
				stTxDisPaySetData.usLastFlg = (NX_USHORT)NX_OFF;
			}
		}
		else {
			stTxDisPaySetData.usNextNo = (NX_USHORT)NX_ZERO;
			stTxDisPaySetData.usLastFlg = (NX_USHORT)NX_ON;
		}
		if (pstTxFrame->usPort == NCYC_TXFRAME_PORT_1) {
			stTxDisPaySetData.usPort1	= (NX_USHORT)NX_ON;
			stTxDisPaySetData.usPort2	= (NX_USHORT)NX_OFF;
		}
		else if (pstTxFrame->usPort == NCYC_TXFRAME_PORT_2){
			stTxDisPaySetData.usPort1	= (NX_USHORT)NX_OFF;
			stTxDisPaySetData.usPort2	= (NX_USHORT)NX_ON;
		}
		else {
			stTxDisPaySetData.usPort1	= (NX_USHORT)NX_ON;
			stTxDisPaySetData.usPort2	= (NX_USHORT)NX_ON;
		}
		stTxDisPaySetData.usDataSize = pstTxFrame->usDataSize;
		stTxDisPaySetData.usFramFormat = pstTxFrame->usFramFormat;
		stTxDisPaySetData.usVLAN = pstTxFrame->usVLAN;
		stTxDisPaySetData.usHeaderSize = pstTxFrame->usHeaderSize;
		
		vTXN_SetDisPay(stTxDisPaySetData, usDiscNo);
	}
	
	return;
}

NX_STATIC NX_VOID vTXN_SetDisPay (
	NCYC_TX_DISPAY		stTxDisPaySetData,
	NX_USHORT			usDiscNo
)
{
	ASIC_RTNDIS_TAG*	pstTxDisc;
	ASIC_RTNPDU_TAG*	pstPduDisc;
	NX_ULONG			ulSetDataArea1 = (NX_ULONG)NX_ZERO;
	NX_ULONG			ulSetDataPDU   = (NX_ULONG)NX_ZERO;
	
	pstTxDisc = (ASIC_RTNDIS_TAG*)&NGN_CN_TNDIS_REG->R_TNDIS[usDiscNo];
	pstPduDisc = (ASIC_RTNPDU_TAG*)&NGN_CN_TNDIS_REG->R_TNPDU[usDiscNo];
	
	ulSetDataArea1 = pstTxDisc->ASIC_rtndis1.DATA & (NX_ULONG)MASK_DIS1_PDUTOPNO;
	ulSetDataPDU = pstPduDisc->ASIC_rtnpdu1.DATA & ((NX_ULONG)MASK_PDU_NEXT | (NX_ULONG)MASK_PDU_LAST);
	
	pstTxDisc->ASIC_rtndis2.DATA = 
					 ((NX_ULONG)stTxDisPaySetData.usPort1 	 << (NX_ULONG)SHIFT_SNDFRAMEPORT1) |
					 ((NX_ULONG)stTxDisPaySetData.usPort2 	 << (NX_ULONG)SHIFT_SNDFRAMEPORT2) |
					 ((NX_ULONG)stTxDisPaySetData.usHeaderSize << (NX_ULONG)SHIFT_SENDHEADERFRMSIZE);
					 
	pstPduDisc->ASIC_rtnpdu1.DATA = 
					 ulSetDataPDU |
					 ((NX_ULONG)stTxDisPaySetData.usDataSize	 << (NX_ULONG)SHIFT_DATASIZE);
					 
	pstTxDisc->ASIC_rtndis1.DATA = 
					 ulSetDataArea1 |
					 ((NX_ULONG)stTxDisPaySetData.usNextNo     << (NX_ULONG)SHIFT_SNDDISCRIPTNEXTNO) |
					 ((NX_ULONG)stTxDisPaySetData.usFramFormat << (NX_ULONG)SHIFT_FRAMEFORMAT) |
					 ((NX_ULONG)stTxDisPaySetData.usVLAN       << (NX_ULONG)SHIFT_FRAMECONFIGVLAN) |
					 ((NX_ULONG)stTxDisPaySetData.usLastFlg    << (NX_ULONG)SHIFT_LASTFLG) |
					 ((NX_ULONG)NX_ON						   << (NX_ULONG)SHIFT_FRAMEFLAG);
	return;
}

NX_STATIC NX_VOID vTXN_MakeDmaList (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	DMA_ITEM			astDmaList[]
)
{
	NCYC_TX_FRAME*		pstTxFrame;
	NX_ULONG			ulDmaCnt;
	NX_USHORT			usDiscNo;
	NX_USHORT			usFrameCnt;
	
	ulDmaCnt = (NX_ULONG)NX_ZERO;
	for (usFrameCnt = (NX_USHORT)NX_ZERO; usFrameCnt < pstTxInfoList->usFrameNum; usFrameCnt++) {
		pstTxFrame = pstTxInfoList->stInfo[usFrameCnt].pstTxFrame;
		usDiscNo = pstTxInfoList->stInfo[usFrameCnt].usTxDisc;
		
		if (pstTxFrame->usHeaderSize > (NX_USHORT)NX_ZERO) {
			astDmaList[ulDmaCnt].ulHeader	= (NX_ULONG)DMA_HEADER_DEF;
			astDmaList[ulDmaCnt].ulSize		= ((NX_ULONG)pstTxFrame->usHeaderSize);
			astDmaList[ulDmaCnt].ulSrc		= (NX_ULONG)&pstTxFrame->auchData[NX_ZERO];
			astDmaList[ulDmaCnt].ulDst		= gstTXNSndNonCyclicBuffAdd[usDiscNo].ulTxnHeadBuffAdd;
			astDmaList[ulDmaCnt].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
											  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
											  (NX_ULONG)DMA_CONFIG_DEM +
											  (NX_ULONG)DMA_CONFIG_TCM +
											  (NX_ULONG)DMA_CONFIG_AM2 +
											  (NX_ULONG)DMA_CONFIG_REQD;
			astDmaList[ulDmaCnt].ulInterval	= (NX_ULONG)NX_ZERO;
			astDmaList[ulDmaCnt].ulNext		= (NX_ULONG)&astDmaList[ulDmaCnt + NX_ONE];
			ulDmaCnt++;
		}
		if (pstTxFrame->usDataSize > (NX_USHORT)NX_ZERO) {
			astDmaList[ulDmaCnt].ulHeader	= (NX_ULONG)DMA_HEADER_DEF;
			astDmaList[ulDmaCnt].ulSize		= ((NX_ULONG)pstTxFrame->usDataSize);
			astDmaList[ulDmaCnt].ulSrc		= (NX_ULONG)&pstTxFrame->auchData[pstTxFrame->usHeaderSize];
			astDmaList[ulDmaCnt].ulDst		= gstTXNSndNonCyclicBuffAdd[usDiscNo].ulTxnSndBuffAdd;
			astDmaList[ulDmaCnt].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
											  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
											  (NX_ULONG)DMA_CONFIG_DEM +
											  (NX_ULONG)DMA_CONFIG_TCM +
											  (NX_ULONG)DMA_CONFIG_AM2 +
											  (NX_ULONG)DMA_CONFIG_REQD;
			astDmaList[ulDmaCnt].ulInterval	= (NX_ULONG)NX_ZERO;
			astDmaList[ulDmaCnt].ulNext		= (NX_ULONG)&astDmaList[ulDmaCnt + NX_ONE];
			ulDmaCnt++;
		}
	}
	
	astDmaList[ulDmaCnt - NX_ONE].ulHeader	= (NX_ULONG)DMA_HEADER_END;
	astDmaList[ulDmaCnt - NX_ONE].ulConfig	= (NX_ULONG)DMA_CONFIG_DMS +
											  (NX_ULONG)DMA_CONFIG_BLOCKTRANS +
											  (NX_ULONG)DMA_CONFIG_AM2 +
											  (NX_ULONG)DMA_CONFIG_REQD;
	astDmaList[ulDmaCnt - NX_ONE].ulNext = (NX_ULONG)NX_ZERO;
	
	return;
}

NX_STATIC NX_USHORT usTXN_GetTxDiscNo (
	NCYC_TX_FRAME*	pstTxFrame
)
{
	NX_USHORT	usIndex = (NX_USHORT)NX_ZERO;
	
	switch (pstTxFrame->usBuffId & (BUFFIDMASK_FRAME | BUFFIDMASK_SIZE)) {
	case BUFFID_NCYC_TX_BUF_SYNC_S:
		usIndex = (NX_USHORT)NX_DISCNO_STA_SYNC_S + (pstTxFrame->usBuffId & (NX_USHORT)BUFFIDMASK_INDEX);
		break;
	case BUFFID_NCYC_TX_BUF_SYNC_L:
		usIndex = (NX_USHORT)NX_DISCNO_STA_SYNC_L + (pstTxFrame->usBuffId & (NX_USHORT)BUFFIDMASK_INDEX);
		break;
	case BUFFID_NCYC_TX_BUF_S:
		usIndex = (NX_USHORT)NX_DISCNO_STA_S + (pstTxFrame->usBuffId & (NX_USHORT)BUFFIDMASK_INDEX);
		break;
	case BUFFID_NCYC_TX_BUF_L:
		usIndex = (NX_USHORT)NX_DISCNO_STA_L + (pstTxFrame->usBuffId & (NX_USHORT)BUFFIDMASK_INDEX);
		break;
	default:
		break;
	}
	
	return usIndex;
}

NX_VOID	vTXN_StartNonCycTx_NotTs (NX_VOID)
{
	NGN_CN_TN1_REG->R_MUSLOTF.BITS.b01ZNONCycleSndTmgCtrlEn = (NX_ULONG)NX_OFF;
	NGN_CN_TN1_REG->R_MUSLOTF.BITS.b01ZNONCycleSndStartFlag = (NX_ULONG)NX_ON;
	
	return;
}

NX_VOID	vTXN_StartNonCycTx_Ts (
	NX_USHORT usSendBitFld
)
{
	NX_USHORT	usTsNo;
	union {
		NX_ULONG		aulCnt[2];
		NX_ULONGLONG	ullCnt;
	} stCycCount;

	NX_ULONG	ulSettingData;
	NX_LONG		alEntryFlg[TX_TSMAX];
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
	for (usTsNo = NX_ZERO; usTsNo < TX_TSMAX; usTsNo++) {
		if (SendStartFlgTbl[usTsNo].usFlgPtn == (usSendBitFld & SendStartFlgTbl[usTsNo].usFlgPtn)) {
			alEntryFlg[usTsNo] = NX_ON;
		}
		else {
			alEntryFlg[usTsNo] = NX_OFF;
		}
	}
	ulSettingData = ONCYCLESNDTMGCTRLEN + ONCYCLESNDSTARTFLAG;
	usTsNo = NX_ZERO;
	
	vNX_vDisableDispatch();
	
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		stCycCount.aulCnt[NX_ONE] = NGN_CN_TS_P1_REG->R_TCPXSSC0;
		stCycCount.aulCnt[NX_ZERO] = NGN_CN_TS_P1_REG->R_TCPXSSC1;
		stCycCount.ullCnt += TXN_NCYC_DELAY_START_CNT;
		
	}
	else {
		stCycCount.aulCnt[NX_ONE] = NGN_CN_TS_P1_REG->R_TCPXSC0;
		stCycCount.aulCnt[NX_ZERO] = NGN_CN_TS_P1_REG->R_TCPXSC1;
		stCycCount.ullCnt += TXN_NCYC_DELAY_START_CNT;
	
	}
	while (usTsNo < TX_TSMAX) {
		if (alEntryFlg[usTsNo] == NX_ON) {
			NGN_CN_TN1_REG->R_TNCYCX[usTsNo][NX_ONE] = stCycCount.aulCnt[NX_ZERO];
			NGN_CN_TN1_REG->R_TNCYCX[usTsNo][NX_ZERO] = stCycCount.aulCnt[NX_ONE];
			*(SendStartFlgTbl[usTsNo].pulSndStrData) |= ulSettingData;
		}
		usTsNo++;
	}
	vNX_vEnableDispatch();
	return;
}

NX_VOID vTXN_NonCycTxComp (
	NCYC_TX_INFO_LIST*	pstTxInfoList,
	NX_SHORT			sWaitResult,
	FLGPTN				fFlgPtn
)
{
	NX_ULONG			ulResult;
	NX_ULONG			ulFrameCnt;
	NCYC_TX_FRAME*		pstTxFrame;
	ASIC_RTNDIS_TAG*	pstTxDisc;


	ulResult = (NX_ULONG)NX_ZERO;
	
	for (ulFrameCnt = (NX_ULONG)NX_ZERO; ulFrameCnt < (NX_ULONG)pstTxInfoList->usFrameNum; ulFrameCnt++) {
		pstTxFrame = pstTxInfoList->stInfo[ulFrameCnt].pstTxFrame;
		
		if ((sWaitResult != (NX_SHORT)E_OK) ||
			((NX_ULONG)fFlgPtn & ((NX_ULONG)ERRBITPOINT << (NX_ULONG)pstTxInfoList->stInfo[ulFrameCnt].usTsNo))) {
			ulResult = (NX_ULONG)RESULT_ERR;
		}
		pstTxDisc = (ASIC_RTNDIS_TAG*)&NGN_CN_TNDIS_REG->R_TNDIS[pstTxInfoList->stInfo[ulFrameCnt].usTxDisc];
		pstTxDisc->ASIC_rtndis1.BITS.b01ZFrameFlag = (NX_ULONG)NX_ZERO;
		
		if (pstTxFrame->pvCbfunc != NX_NULL) {
			pstTxFrame->pvCbfunc((NX_ULONG)pstTxFrame, ulResult);
		}
		
		if (pstTxFrame->usRelFlg == (NX_USHORT)NX_ON) {
			vTXN_ReleaseNonCycTxBuf(pstTxFrame->usBuffId);
		}
		else {
		}
	}
	NGN_CN_TN1_REG->R_TNMUST.DATA = (NX_ULONG)NONCYCSENDCOMP;
	return;
}

NX_STATIC NX_VOID vTXN_DisableTs (NX_VOID)
{
	NX_ULONGLONG	ullComCycle;
	NX_ULONG		ulWaitTime;
	FLGPTN			flgPtn = (FLGPTN)NX_OFF;
	
	vCYC_DeactivateCyclicSnd();
	
	ullComCycle = ullNMG_GetComCycle();
	ulWaitTime = (NX_ULONG)(((ullComCycle * WAIITIME_AUTOSEND) + 
				 (CONVERT_NS_TO_MS - (NX_ULONGLONG)1)) / CONVERT_NS_TO_MS);
	
	(NX_VOID)twai_flg(EVFLGID_NX_DUMMY, FLGP_DUMMY, TWF_ANDW, &flgPtn, (signed int)ulWaitTime);
	
	vNMG_DeactivateTimeslot();
	return;
}


NX_VOID vNX_TxnMainClassA (
	NX_USHORT usCycRcvFlg
)
{
	NX_USHORT	usAuthClass;
	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_A == usAuthClass) {
		if ((NX_USHORT)NX_ON == usCycRcvFlg) {
			vTXN_SendCycFrame_ClassA();
		}
		else {
		}
	}
	
	return;
}

NX_VOID vTXN_Init_ClassA (NX_VOID)
{
	vTXN_InitNonCycTxBuf();
	
	return;
}

NX_STATIC NX_VOID vTXN_SendCycFrame_ClassA (NX_VOID)
{
	NX_ULONG ulTimeoutState;
	
	vCYC_SetCycDisClassA();
	
	ulTimeoutState = ulTXN_StartSendFrame_ClassA();
	
	vCYC_CycTxCompClassA(ulTimeoutState);
	
	return;
}


NX_STATIC NX_ULONG ulTXN_StartSendFrame_ClassA  (NX_VOID)
{
	NX_ULONG	ulTimeoutState = (NX_ULONG)NX_OK;
	NX_ULONG	ulStartTime;
	NX_ULONG	ulIntLowResult;
	NX_ULONG	ulIntLowTxResult;
	NX_ULONG	ulIntHighTxResult;
	NX_ULONG	ulSendState;
	
	NGN_CN_TNDIS_REG->R_TNDISSETP1.DATA= DIS_UPDATE_ON;
	ulStartTime = ulNX_GetLifeTime();
	do {
		ulIntLowResult = ulINTR_CheckIntLowTx(INTR_TXL_CHANGE_HWAREA);
		if (ulIntLowResult == (NX_ULONG)NX_ON) {
			break;
		}
		ulTimeoutState = ulNX_WaitLifeTime(ulStartTime, WAITTIME_SEND_CLASSA);
	} while (ulTimeoutState == (NX_ULONG)NX_OK);
	
	vINTR_ClearIntLowTx(INTR_TXL_CHANGE_HWAREA);

	if (ulTimeoutState == (NX_ULONG)NX_OK) {
		vTXN_StartNonCycTx_NotTs();
		do {
			ulIntLowTxResult	= ulINTR_CheckIntLowTx(INTR_TXL_NCYC_COMPTS0);
			ulIntHighTxResult	= ulINTR_CheckIntHighTx(INTR_TXH_ERR);
			ulSendState 		= (NX_ULONG)NGN_CN_TN1_REG->R_TNMUST.DATA;
			
			if (((NX_ULONG)NX_ON == ulIntLowTxResult) && 
				((ulSendState & SENDSTATE_TS0_OK) == SENDSTATE_TS0_OK)) {
				break;
			}
			
			if (((NX_ULONG)NX_ON == ulIntHighTxResult) &&
				((ulSendState & SENDSTATE_TS0_NG) == SENDSTATE_TS0_NG)) {
				ulTimeoutState = (NX_ULONG)NX_NG;
				break;
			}
			
			ulTimeoutState = ulNX_WaitLifeTime(ulStartTime, WAITTIME_SEND_CLASSA);
		} while (ulTimeoutState == (NX_ULONG)NX_OK);

		vINTR_ClearIntLowTx(INTR_TXL_NCYC_COMPTS0);
		vINTR_ClearIntHighTx(INTR_TXH_ERR);		
		NGN_CN_TN1_REG->R_TNMUST.DATA = (NX_ULONG)NONCYCSENDCOMP;
	}
	
	return ulTimeoutState;
}



NX_ULONG ulTXN_GetSndData_EtherMAC (
	NCYC_TX_FRAME**	pstTxFrameInfo
)
{
	NCYC_TX_FRAME*	pstFrameInfoTmp;
	T_MSG			*pstMsg;
	NX_ULONG		ulRslt;
	NX_LONG			lRcvResult;
	NX_USHORT		usTsNo = (NX_USHORT)NX_ZERO;
	
	ulRslt = NX_UL_NG;
	lRcvResult = prcv_mbx(MailBoxIdList[usTsNo], (T_MSG**)&pstMsg);
	if (lRcvResult != (NX_LONG)E_OK) {
	}
	else {
		*pstTxFrameInfo = (NCYC_TX_FRAME*)pstMsg;
		ulRslt = NX_UL_OK;
	}
	
	return ulRslt;
}
