/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ManagementSM.h"
#ifdef	PTP_USE_MANAGEMENT
#include "ManagementSM_1588.h"
#include "ManagementAPI_1588.h"

#include "mdtransinterface_msg.h"
#include "ptp_LogRecord.h"

#define	MGT_ACT_GETTBL_SZ			36

const MGT_ACT_SEL_TBL_1588	stMgt_Action_Get[MGT_ACT_GETTBL_SZ] = {
	{MGT_MNM_NULL_MANAGEMENT, 		PTPM_MGT_NULL_MANAGEMENT,		MGT_APPLIES_PORT,	&getManagement_0000},
	{MGT_MNM_CLOCK_DESCRIPTION,		PTPM_MGT_CLOCK_DESCRIPTION,		MGT_APPLIES_PORT,	&getManagement_0001},
	{MGT_MNM_USER_DESCRIPTION,		PTPM_MGT_USER_DESCRIPTION,		MGT_APPLIES_CLOCK,	&getManagement_0002},
	{MGT_MNM_FAULT_LOG,				PTPM_MGT_FAULT_LOG,				MGT_APPLIES_CLOCK,	&getManagement_0006},
	{MGT_MNM_DEFAULT_DATA_SET,		PTPM_MGT_DEFAULT_DATA_SET,		MGT_APPLIES_CLOCK,	&getManagement_2000},
	{MGT_MNM_CURRENT_DATA_SET,		PTPM_MGT_CURRENT_DATA_SET,		MGT_APPLIES_CLOCK,	&getManagement_2001},
	{MGT_MNM_PARENT_DATA_SET,		PTPM_MGT_PARENT_DATA_SET,		MGT_APPLIES_CLOCK,	&getManagement_2002},
	{MGT_MNM_TIME_PROPERT_DATA_SET,	PTPM_MGT_TIME_PROPERT_DATA_SET,	MGT_APPLIES_CLOCK,	&getManagement_2003},
	{MGT_MNM_PORT_DATA_SET,			PTPM_MGT_PORT_DATA_SET,			MGT_APPLIES_PORT,	&getManagement_2004},
	{MGT_MNM_PRIORITY1,				PTPM_MGT_PRIORITY1,				MGT_APPLIES_CLOCK,	&getManagement_2005},
	{MGT_MNM_PRIORITY2,				PTPM_MGT_PRIORITY2,				MGT_APPLIES_CLOCK,	&getManagement_2006},
	{MGT_MNM_DOMAIN,				PTPM_MGT_DOMAIN,				MGT_APPLIES_CLOCK,	&getManagement_2007},
	{MGT_MNM_SLAVE_ONLY,			PTPM_MGT_SLAVE_ONLY,			MGT_APPLIES_CLOCK,	&getManagement_2008},
	{MGT_MNM_LOG_ANNOUNCE_INTERVAL,	PTPM_MGT_LOG_ANNOUNCE_INTERVAL,	MGT_APPLIES_PORT,	&getManagement_2009},
	{MGT_MNM_ANNOUNCE_RECEIPT_TMOUT,PTPM_MGT_ANNOUNCE_RECEIPT_TMOUT,MGT_APPLIES_PORT,	&getManagement_200A},
	{MGT_MNM_LOG_SYNC_INTERVAL,		PTPM_MGT_LOG_SYNC_INTERVAL,		MGT_APPLIES_PORT,	&getManagement_200B},
	{MGT_MNM_VERSION_NUMBER,		PTPM_MGT_VERSION_NUMBER,		MGT_APPLIES_PORT,	&getManagement_200C},
	{MGT_MNM_TIME,					PTPM_MGT_TIME,					MGT_APPLIES_CLOCK,	&getManagement_200F},
	{MGT_MNM_CLOCK_ACCURACY,		PTPM_MGT_CLOCK_ACCURACY,		MGT_APPLIES_CLOCK,	&getManagement_2010},
	{MGT_MNM_UTC_PROPERTIES,		PTPM_MGT_UTC_PROPERTIES,		MGT_APPLIES_CLOCK,	&getManagement_2011},
	{MGT_MNM_TRACEABILITY_PROPERT,	PTPM_MGT_TRACEABILITY_PROPERT,	MGT_APPLIES_CLOCK,	&getManagement_2012},
	{MGT_MNM_TIMESCALE_PROPERTIES,	PTPM_MGT_TIMESCALE_PROPERTIES,	MGT_APPLIES_CLOCK,	&getManagement_2013},
	{MGT_MNM_UNICAST_NEGOTI_ENABLE,	PTPM_MGT_UNICAST_NEGOTI_ENABLE,	MGT_APPLIES_PORT,	&getManagement_2014},
	{MGT_MNM_PATH_TRACE_LIST,		PTPM_MGT_PATH_TRACE_LIST,		MGT_APPLIES_CLOCK,	&getManagement_2015},
	{MGT_MNM_PATH_TRACE_ENABLE,		PTPM_MGT_PATH_TRACE_ENABLE,		MGT_APPLIES_CLOCK,	&getManagement_2016},
	{MGT_MNM_GM_CLUSTER_TBL,		PTPM_MGT_GM_CLUSTER_TBL,		MGT_APPLIES_CLOCK,	&getManagement_2017},
	{MGT_MNM_UNICAST_MSTR_TBL,		PTPM_MGT_UNICAST_MSTR_TBL,		MGT_APPLIES_PORT,	&getManagement_2018},
	{MGT_MNM_UNICAST_MSTR_MAX_TBLSZ,PTPM_MGT_UNICAST_MSTR_MAX_TBLSZ,MGT_APPLIES_PORT,	&getManagement_2019},
	{MGT_MNM_PORT_STAT_COUNT,		PTPM_MGT_PORT_STAT_COUNT,		MGT_APPLIES_PORT,	&getManagement_2100},
	{MGT_MNM_CMLD_PORT_STAT_COUNT,	PTPM_MGT_CMLD_PORT_STAT_COUNT,	MGT_APPLIES_PORT,	&getManagement_2101},
	{MGT_MNM_PORT_STAT_ERRCOUNT,	PTPM_MGT_PORT_STAT_ERRCOUNT,	MGT_APPLIES_PORT,	&getManagement_2102},
	{MGT_MNM_TCLK_DEFAULT_DATA_SET,	PTPM_MGT_TCLK_DEFAULT_DATA_SET,	MGT_APPLIES_CLOCK,	&getManagement_4000},
	{MGT_MNM_TCLK_PORT_DATA_SET,	PTPM_MGT_TCLK_PORT_DATA_SET,	MGT_APPLIES_PORT,	&getManagement_4001},
	{MGT_MNM_PRIMARY_DOMAIN,		PTPM_MGT_PRIMARY_DOMAIN,		MGT_APPLIES_CLOCK,	&getManagement_4002},
	{MGT_MNM_DELAY_MECHANISM,		PTPM_MGT_DELAY_MECHANISM,		MGT_APPLIES_PORT,	&getManagement_6000},
	{MGT_MNM_LOG_MIN_PDREQ_INTERVAL,PTPM_MGT_LOG_MIN_PDREQ_INTERVAL,MGT_APPLIES_PORT,	&getManagement_6001}
};

VOID ManagementSM_GET(MANAGEMENTSM_GD* pstSmGbl, CLOCKDATA* pstClockData, PORTDATA* pstPortData, USHORT usRecvMsgLen)
{
	PTPMSG_MANAGEMENT_1588*	pstMsg			= (PTPMSG_MANAGEMENT_1588*)pstSmGbl->puchMgtRxMsg;
	static	PTPMSG_MANAGEMENT_TLV	stMsgTLV;
	USHORT					usTLVLen		= 0;
	UCHAR*					puchMsgPtr		= NULL;
	SHORT					sLength		= 0;
	SHORT					sLoopNum		= MGT_ACT_GETTBL_SZ;
	SHORT					sLoop			= 0;

	BOOL					blRet	= FALSE;
	PTPMSG_MANAGEMENT_1588*	pstOutMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;

	PTPMSG_MANAGEMENT_TLV*			pstOutTLV	  = (PTPMSG_MANAGEMENT_TLV*)&pstOutMsg->stManagemant_TLV;

	puchMsgPtr	 = (UCHAR*)&pstMsg->stManagemant_TLV;


	pstOutMsg->stHeader.usMegLength = 0;

	if (pstMsg->stHeader.usMegLength > usRecvMsgLen)
	{
		sLength	 = usRecvMsgLen - PTPMSG_MANAGEMENT_SZ;
	}
	else
	{
		sLength	 = (SHORT)(pstMsg->stHeader.usMegLength - PTPMSG_MANAGEMENT_SZ);
	}

	while(sLength > 0)
	{

		usTLVLen = ptp_Mdl_ntohMsgManagTLV(puchMsgPtr, &stMsgTLV, sLength);
		if (usTLVLen == 0)
		{
			break;
		}	
		if (usTLVLen < PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ + PTPMSG_MGTTLV_MANAGEMENTID_SZ)
		{
			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
			
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_MGTSM_1588_GET, PTP_LOGVE_87000003);
			continue;
		}

		blRet	= FALSE;
		if (stMsgTLV.usTLVType != PTPM_TLVTYP_MANAGEMENT)
		{


			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_MGTSM_1588_GET, PTP_LOGVE_87000002);

			usTLVLen += stMsgTLV.usLengthField - PTPMSG_MGTTLV_MANAGEMENTID_SZ;

			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);

		}
		else 
		{
			for (sLoop = 0; sLoop < sLoopNum; sLoop++)
			{
				if (stMsgTLV.usManagementId == stMgt_Action_Get[sLoop].usManagementId)
				{
					if ((stMgt_Action_Get[sLoop].enTypeApplies == MGT_APPLIES_PORT)
						&& (pstPortData != NULL))
					{
						blRet = (*stMgt_Action_Get[sLoop].pfnFunc)(pstPortData, &stMsgTLV, pstOutTLV);
					}
					else if (stMgt_Action_Get[sLoop].enTypeApplies == MGT_APPLIES_CLOCK)
					{
						blRet = (*stMgt_Action_Get[sLoop].pfnFunc)(pstClockData, &stMsgTLV, pstOutTLV);
					}
					else
					{
					}
					break;
				}
			}
			if (blRet)
			{
				SetTxManagementMsg(pstSmGbl, pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else if ((blRet == FALSE) && (sLoop == sLoopNum))
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, PTPM_MGTER_NO_SUCH_ID);

				SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV *)pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, PTPM_MGTER_NO_SUCH_ID);
				SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV*)pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
				break;
			}
			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
		}
	}
	pstOutMsg = (PTPMSG_MANAGEMENT_1588 *)pstSmGbl->ulTxMgtMsg;
	if (pstOutMsg->stHeader.usMegLength)
	{
		TxManagementMsg(pstSmGbl, pstClockData);
	}

	return;
}
BOOL getManagement_0000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_0001(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGD_CLOCK_DESCRIPTION);

	MGT_CLOCK_DESCRIPTION* pstDataF = &pstOutTLV->stDataField.stClockDescription;
	nRet = GetIe1588ClockDescription(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_CLK_DESCRIPTION_SIZE(pstDataF, usDataFieldLen);
	usDataFieldLen += usDataFieldLen%2;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_0002(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_USER_DESCRIPTION);

	MGT_USER_DESCRIPTION* pstDataF = &pstOutTLV->stDataField.stUserDescription;
	nRet = GetIe1588UserDescription(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_USER_DESCRIPTION_SIZE(pstDataF, usDataFieldLen);
	usDataFieldLen += usDataFieldLen%2;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_0006(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet;
	USHORT	usInfoLen;

	MGT_FAULT_LOG* pstDataF = &pstOutTLV->stDataField.stFaultLog;

	GetMGT_FAULT_RECORD_SIZE(pstDataF->stFaultRecords, usInfoLen);
	usInfoLen *= MGT_FAULTRECORDS;
	nRet = GetIe1588FaultLog(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}
	usDataFieldLen = (usDataFieldLen % 2) + usDataFieldLen;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_DEFAULT_DATA_SET);

	MGT_DEFAULT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stDefaultDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_DEFAULT_DATA_SET));

	nRet = GetIe1588DefaultDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_DEFAULT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2001(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_CURRENT_DATA_SET);

	MGT_CURRENT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stCurrentDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_CURRENT_DATA_SET));

	nRet = GetIe1588CurrentDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_CURRENT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2002(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PARENT_DATA_SET);

	MGT_PARENT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stParentDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PARENT_DATA_SET));

	nRet = GetIe1588ParentDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PARENT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2003(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TIME_PROPERTIES_DATA_SET);

	MGT_TIME_PROPERTIES_DATA_SET* pstDataF = &pstOutTLV->stDataField.stTimePropertiesDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TIME_PROPERTIES_DATA_SET));

	nRet = GetIe1588TimePropertiesDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TIMEPRPRTS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2004(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PORT_DATA_SET);

	MGT_PORT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stPortDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PORT_DATA_SET));

	nRet = GetIe1588PortDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PORT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2005(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIORITY1);

	MGT_PRIORITY1* pstDataF = (MGT_PRIORITY1*)&pstOutTLV->stDataField;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PRIORITY1));

	nRet = GetIe1588Priority1(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PRIORITY1_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2006(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIORITY2);

	MGT_PRIORITY2* pstDataF = &pstOutTLV->stDataField.stPriority2;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PRIORITY2));

	nRet = GetIe1588Priority2(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PRIORITY2_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2007(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;




	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);

	return TRUE;
}

BOOL getManagement_2008(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_SLAVE_ONLY);

	MGT_SLAVE_ONLY* pstDataF = &pstOutTLV->stDataField.stSlaveOnly;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_SLAVE_ONLY));

	nRet = GetIe1588SlaveOnly(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_SLAVE_ONLY_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2009(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_LOG_ANNOUNCE_INTERVAL);

	MGT_LOG_ANNOUNCE_INTERVAL* pstDataF = &pstOutTLV->stDataField.stLogAnnounceIntv;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_LOG_ANNOUNCE_INTERVAL));

	nRet = GetIe1588LogAnnounInterval(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_LOG_ANNOUINTVAL_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_200A(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT);

	MGT_ANNOUNCE_RECEIPT_TIMEOUT* pstDataF = &pstOutTLV->stDataField.stAnnounceReceiptTout;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT));

	nRet = GetIe1588AnnounReceiptTimeout(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_ANNOU_RCPTTMOUT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_200B(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_LOG_SYNC_INTERVAL);

	MGT_LOG_SYNC_INTERVAL* pstDataF = &pstOutTLV->stDataField.stLogSyncInterval;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_LOG_SYNC_INTERVAL));

	nRet = GetIe1588LogSyncInterval(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_LOG_SYNCINTVAL_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_200C(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_VERSION_NUMBER);

	MGT_VERSION_NUMBER* pstDataF = &pstOutTLV->stDataField.stVersionNum;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_VERSION_NUMBER));

	nRet = GetIe1588VersionNum(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_VERSION_NUM_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_200F(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TIME);

	MGT_TIME* pstDataF = &pstOutTLV->stDataField.stTime;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TIME));

	nRet = GetIe1588Time(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TIME_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2010(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_CLOCK_ACCURACY);

	MGT_CLOCK_ACCURACY* pstDataF = &pstOutTLV->stDataField.stClockAccuracy;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_CLOCK_ACCURACY));

	nRet = GetIe1588ClockAccuracy(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_CLKACC_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2011(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_UTC_PROPERTIES);

	MGT_UTC_PROPERTIES* pstDataF = &pstOutTLV->stDataField.stUTC_Properties;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_UTC_PROPERTIES));

	nRet = GetIe1588UtcProperties(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_UTC_PRPRTS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2012(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TRACEABILITY_PROPERTIES);

	MGT_TRACEABILITY_PROPERTIES* pstDataF = &pstOutTLV->stDataField.stTrcebltyProperties;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TRACEABILITY_PROPERTIES));

	nRet = GetIe1588TraceProperties(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TRACEBLTY_PRPRTS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2013(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TIMESCALE_PROPERTIES);

	MGT_TIMESCALE_PROPERTIES* pstDataF = &pstOutTLV->stDataField.stTimScaleProperties;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TIMESCALE_PROPERTIES));

	nRet = GetIe1588TimesProperties(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TMSCALE_PRPRTS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2014(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2015(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PATH_TRACE_LIST);

	nRet = GetIe1588PathTraceList(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2016(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PATH_TRACE_ENABLE);

	MGT_PATH_TRACE_ENABLE* pstDataF = &pstOutTLV->stDataField.stPathTraceEnable;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PATH_TRACE_ENABLE));

	nRet = GetIe1588PathTraceEnable(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PATH_TRACEENABLE_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2017(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return FALSE;
}

BOOL getManagement_2018(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return FALSE;
}

BOOL getManagement_2019(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return FALSE;
}

BOOL getManagement_2100(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PORT_STATISTICS_COUNT);

	MGT_PORT_STATISTICS_COUNT* pstDataF = &pstOutTLV->stDataField.stPortStatisticsCnt;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PORT_STATISTICS_COUNT));

	nRet = GetIe1588PortStatCount(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PORT_STATIS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2101(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_CMLD_PORT_STATIS_COUNT);

	MGT_CMLD_PORT_STATIS_COUNT* pstDataF = &pstOutTLV->stDataField.stCMLD_PortStatisticsCnt;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_CMLD_PORT_STATIS_COUNT));

	nRet = GetIe1588CmldStatPortCount(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_CMLDPORT_STATIS_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_2102(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PORT_STATISTICS_ERRCOUNT);

	MGT_PORT_STATISTICS_ERRCOUNT* pstDataF = &pstOutTLV->stDataField.stPortStatisticsErrCnt;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PORT_STATISTICS_ERRCOUNT));

	nRet = GetIe1588CmldStatPortCount(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PORT_STATISER_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_4000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TCLK_DEFAULT_DATA_SET);

	MGT_TCLK_DEFAULT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stTCLK_DefaultDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TCLK_DEFAULT_DATA_SET));

	nRet = GetIe1588TransClockDefaultDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TCLK_DEFAULT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_4001(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TCLK_PORT_DATA_SET);

	MGT_TCLK_PORT_DATA_SET* pstDataF = &pstOutTLV->stDataField.stTCLK_PortDS;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_TCLK_PORT_DATA_SET));

	nRet = GetIe1588TransClockPortDS(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_TCLK_PORT_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_4002(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIMARY_DOMAIN);

	MGT_PRIMARY_DOMAIN* pstDataF = &pstOutTLV->stDataField.stPrimaryDomain;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_PRIMARY_DOMAIN));

	nRet = GetIe1588PrimaryDomain(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_PM_DOMAIN_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_6000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_DELAY_MECHANISM);
	PORTDATA*	pstPortData = (PORTDATA*)pvData;
	ENUM_CLOCKSUPPORTTYPE_1588 enClockSupporType;

	MGT_DELAY_MECHANISM* pstDataF = &pstOutTLV->stDataField.stDelayMechanism;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_DELAY_MECHANISM));

	enClockSupporType = pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;
	if ((enClockSupporType == ENUM_CSTYPE_TRANSCLOCKE2E_1588) ||
 			(enClockSupporType == ENUM_CSTYPE_TRANSCLOCKP2P_1588))
 	{
		nRet = GetIe1588DelayMechanismTC(pstPortData->pstClockData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
		if (nRet != RET_ENOERR) {
			return FALSE;
		}
	}
	else
	{

	nRet = GetIe1588DelayMechanism(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
		}
	}

	GetMGT_DLY_MECHANISM_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_6001(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_DELAY_MECHANISM);

	MGT_LOG_MIN_PDREQ_INTERVAL* pstDataF = &pstOutTLV->stDataField.stLogMinPdelayReqIntv;
	tsn_Wrapper_MemSet(pstDataF, 0x00, sizeof(MGT_LOG_MIN_PDREQ_INTERVAL));

	nRet = GetIe1588LogMinPDReqInterval(pvData, (UCHAR*)&pstOutTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	GetMGT_LOG_MINPDREQINTV_DS_SIZE(pstDataF, usDataFieldLen);
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL getManagement_NOP(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	return FALSE;
}
#endif
