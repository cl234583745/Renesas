/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPSENDSM_1588_H__
#define __MDDELAYRESPSENDSM_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDDelayRespSendSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDDelayRespSendSM_00_1588(PORTDATA* pstPort);
VOID MDDelayRespSendSM_01_1588(PORTDATA* pstPort);
VOID MDDelayRespSendSM_02_1588(PORTDATA* pstPort);
VOID MDDelayRespSendSM_NP_1588(PORTDATA* pstPort);

BOOL MDDRespSnd_NotEnable_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDDRespSnd_WtFrDResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL MDDRespSnd_WtFrDRespTC_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL SetDelayResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL SetDelayRespTC_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL TxDelayResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
