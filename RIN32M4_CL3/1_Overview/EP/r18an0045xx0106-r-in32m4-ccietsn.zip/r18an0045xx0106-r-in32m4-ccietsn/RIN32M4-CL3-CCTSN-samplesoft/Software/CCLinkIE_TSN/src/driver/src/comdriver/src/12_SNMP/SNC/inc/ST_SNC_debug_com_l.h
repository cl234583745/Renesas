/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_DEBUG_COM_L_H__
#define __ST_SNC_DEBUG_COM_L_H__

#ifdef SWPS
#include "ST_Common.h"
#include <Windows.h>
#if SNC_DEBUG
#include <stdio.h>
#endif
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#endif
#endif

#if SNC_DEBUG
#define DBGPRINT(x,...)     fprintf(stderr,(x),__VA_ARGS__)
#define DBGTRACEOPEN(x,y)   ST_SNC_TraceOpen((x),(y))
#define DBGTRACE(x,...)     ST_SNC_TraceFprintf((x),__VA_ARGS__)
#define DBGDUMP(x,y,z)      ST_SNC_TraceDump((x),(y),(z))
#define DBGTRACEOID(x,y,z)  ST_SNC_TraceOid((x),(y),(z))
#define DBGTRACECLOSE()     ST_SNC_TraceClose(TRUE)
#else
#define DBGPRINT(x,...)
#define DBGTRACEOPEN(x,y)
#define DBGTRACE(x,...)
#define DBGDUMP(x,y)
#define DBGTRACEOID(x,y,z)
#define DBGTRACECLOSE()
#endif


#ifdef SWPS
typedef struct ST_SNC_DbgError_TAG {
	ULONG	ulError;
	ULONG	ulLine;
} ST_SNC_DbgError;


extern VOID ST_SNC_TraceOpen(LPCTSTR filePath, ST_SNC_DbgError* pstError);
extern VOID ST_SNC_TraceClose(BOOL bLock);
extern VOID ST_SNC_TraceWrite(ST_SNC_DbgError* pstError, const CHAR* buf);
extern VOID ST_SNC_TraceFprintf(const CHAR* pszFmt, ...);
extern VOID ST_SNC_TraceDump(const CHAR* pchStr, const UCHAR *puchData, ULONG ulSize);
extern VOID ST_SNC_TraceOid(const CHAR* pchStr, const UINT *puiOid, ULONG ulSize);
#endif

#endif

