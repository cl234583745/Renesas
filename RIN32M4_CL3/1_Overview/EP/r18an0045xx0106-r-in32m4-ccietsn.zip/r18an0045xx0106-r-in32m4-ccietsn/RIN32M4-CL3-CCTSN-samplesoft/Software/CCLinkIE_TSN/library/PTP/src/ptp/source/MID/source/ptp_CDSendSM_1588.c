/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_tsn_Wrapper.h"
#include "ptp_LogRecord.h"
#include "PTP_GlobalData.h"

#ifdef	PTP_USE_IEEE1588

#include "ptp_LCEntity.h"
#include "ptp_PDRQSend_1588.h"
#include "ptp_PDRSSend_1588.h"
#include "ptp_PDRSReceive_1588.h"
#include "ptp_PDRQReceive_1588.h"
#include "ptp_CDSend_1588.h"

#define DREQ_TX_STATE_PAUSE		0
#define DREQ_TX_STATE_BUSY		1
#define DREQ_TX_STATE_RUN		2


#define RAND_MAX_LOG			15

#define D_FUNC		0
#define D_DREQTO	0
#define D_DBG		0


VOID	CDSend_1588_00(CLOCKDATA*	pstClockData);
VOID	CDSend_1588_01(CLOCKDATA*	pstClockData);
VOID	CDSend_1588_02(CLOCKDATA*	pstClockData);
VOID	CDSend_1588_03(CLOCKDATA*	pstClockData);
PORTDATA*	GetSlavePort(CLOCKDATA*	pstClockData);
MDDELAYREQ*  setMDDelayReqSend_1588(PORTDATA*	pstPortData);
MDDELAYREQ*  setMDDelayReq_1588(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
static VOID	txPDRQSend_1588(MDDELAYREQ*		pstMDDelayReqSendPtr, PORTDATA*	pstPortData);
VOID	txPDRQSendAll_1588(CLOCKDATA*	pstClockData);
MDDELAYRESP*	setMDDelayResp_1588(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
VOID	txPDRSSend_1588(MDDELAYRESP*	pstMdDelayRespSendPtr, PORTDATA*	pstPortData);
VOID	txPDRSSendAll_1588(CLOCKDATA*	pstClockData);
VOID	getClockDelayReqInterval(CLOCKDATA*	pstClockData);
static VOID getClockDelayReqInterval_ME( CLOCKDATA* pstClockData );
static VOID getClockDelayReReqInterval( CLOCKDATA* pstClockData );
CHAR	initClockLogDelayReqInterval(CLOCKDATA*		pstClockData);



#define	CONSSPAN_2		(2)

VOID (*const pfnCDSendMatrix[ST_CDS_MAX][EV_CDS_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CDSend_1588_01, &CDSend_1588_01, &CDSend_1588_01, &CDSend_1588_01, &CDSend_1588_00},
	{&CDSend_1588_01, &CDSend_1588_02, &CDSend_1588_02, &CDSend_1588_03, &CDSend_1588_00},
	{&CDSend_1588_01, &CDSend_1588_02, &CDSend_1588_02, &CDSend_1588_03, &CDSend_1588_00},
	{&CDSend_1588_01, &CDSend_1588_02, &CDSend_1588_02, &CDSend_1588_03, &CDSend_1588_00},
	{&CDSend_1588_01, &CDSend_1588_02, &CDSend_1588_02, &CDSend_1588_03, &CDSend_1588_00}
};






VOID	clockDelaySend_1588 (
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CDS	enEvt = EV_CDS_EVENT_MAX;
	BOOL 		blSts = FALSE;

	
	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("CDSendSM_1588   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.enStatusCDS);
}
#endif
		enEvt = GetCDSendSM_1588_Event(usEvent, pstClockData);

		blSts = IsCDSendSM_1588_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CDS_EVENT_MAX))
		{
			(*pfnCDSendMatrix[pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.enStatusCDS][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CDSENDSM_1588, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.blRcvdMDDelayReq	= FALSE;
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.blRcvdMDDelayResp	= FALSE;
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.blDReqSendTO		= FALSE;
		}

	}
}



CDSENDSM_1588_GD*	GetCDSendSM_1588_GD(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD);
	return pstCDSGlb;
}

EN_EV_CDS	GetCDSendSM_1588_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb	= GetCDSendSM_1588_GD(pstClockData);
	EN_EV_CDS	enEvt = EV_CDS_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CDS_BEGIN;
			break;

		case PTP_EV_DELAYREQ_SENDTIME_1588:
			pstCDSGlb->blDReqSendTO = TRUE;
			pstCDSGlb->pstTMO_DelayReqSendTime = NULL;
			enEvt = EV_CDS_DELAYREQ_SENDTIME_1588;
			break;

		case PTP_EV_DELAYREQ_SEND_1588:
			enEvt = EV_CDS_DELAYREQ_SEND_1588;
			break;

		case PTP_EV_DELAYRESP_SEND_1588:
			enEvt = EV_CDS_DELAYRESP_SEND_1588;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CDS_CLOSE_1588;
			break;

		default:
			enEvt = EV_CDS_EVENT_MAX;
			break;
	}

	return	enEvt;
}

BOOL	IsCDSendSM_1588_Status(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb	= GetCDSendSM_1588_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if(pstCDSGlb->enStatusCDS < ST_CDS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	CDSend_1588_00(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb		= GetCDSendSM_1588_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CDSend_1588_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	if (pstCDSGlb->pstTMO_DelayReqSendTime != NULL)
	{
		(VOID)ptp_TimeOut_Can(pstCDSGlb->pstTMO_DelayReqSendTime);
		pstCDSGlb->pstTMO_DelayReqSendTime = NULL;
	}

	pstCDSGlb->blRcvdMDDelayReq		= FALSE;
	pstCDSGlb->blRcvdMDDelayResp	= FALSE;
	pstCDSGlb->blDReqSendTO			= FALSE;
	pstCDSGlb->enStatusCDS			= ST_CDS_NONE;

	ptp_dbg_msg( D_FUNC, ("CDSend_1588_00::-\n") );
}




VOID	CDSend_1588_01(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb		= GetCDSendSM_1588_GD(pstClockData);
	USHORT				usSSTimeEvent	= PTP_EV_DELAYREQ_SENDTIME_1588;
	USCALEDNS			stCurrentTime	= {0};


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (IS_OD_BC_1588(pstClockData))
	{
		if (pstCDSGlb->pstTMO_DelayReqSendTime != NULL)
		{
			(VOID)ptp_TimeOut_Can(pstCDSGlb->pstTMO_DelayReqSendTime);
			pstCDSGlb->pstTMO_DelayReqSendTime = NULL;
		}

		pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval
			= initClockLogDelayReqInterval(pstClockData);

		getClockDelayReqInterval(pstClockData);
		(VOID)ptpAddUSNs_USNs(&stCurrentTime,
								&(pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval),
								&(pstCDSGlb->stDelayReqSendTime));

		pstCDSGlb->pstTMO_DelayReqSendTime = ptp_TimeOut_Req(usSSTimeEvent,
																pstClockData,
																pstCDSGlb->stDelayReqSendTime,
																(CallBackFunc)&clockDelaySend_1588);
	}
	pstCDSGlb->blRcvdMDDelayReq		= FALSE;
	pstCDSGlb->blRcvdMDDelayResp	= FALSE;
	pstCDSGlb->blDReqSendTO			= FALSE;
	pstCDSGlb->enStatusCDS			= ST_CDS_WAITING;
}




VOID	CDSend_1588_02(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb				= GetCDSendSM_1588_GD(pstClockData);
	USHORT				usSSTimeEvent			= PTP_EV_DELAYREQ_SENDTIME_1588;
	PORTDATA*			pstPortData				= NULL;
	MDDELAYREQ*			pstMDDelayReqSendPtr	= NULL;
	USCALEDNS			stCurrentTime			= {0};
	INT nTxState = DREQ_TX_STATE_PAUSE;

	ptp_dbg_msg(D_FUNC, ("CDSend_1588_02::+\n"));
	ptp_dbg_msg(D_DBG,  ("--domain(%d)::\n", pstClockData->stDefaultDS.uchDomainNumber));

	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (IS_OD_BC_1588(pstClockData) &&
		(pstCDSGlb->blDReqSendTO))
	{
		pstPortData = GetSlavePort(pstClockData);
		if (pstPortData != NULL)
		{





			ptp_dbg_msg(D_FUNC, ("pstCmldsPortDs->blCmldsPortEnabled   =[%d]\n", pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled));

			if ( pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE )
			{

				DreqTransChkTmo( pstClockData );

				nTxState = ChkDreqTransProcessing( pstClockData );
				
				switch( nTxState )
				{
					case DREQ_TX_STATE_PAUSE:
						pstMDDelayReqSendPtr = setMDDelayReqSend_1588( pstPortData );
						txPDRQSend_1588( pstMDDelayReqSendPtr, pstPortData );
						break;
					case DREQ_TX_STATE_RUN:
						PTP_WARNING_LOGRECORD( pstPortData->pstClockData, 
											   PTP_LOG_CDSENDSM_1588, 
											   PTP_LOGVE_84000012 );
						break;
					case DREQ_TX_STATE_BUSY:
						break;
					default:
						break;
				}
			}


			if (nTxState == DREQ_TX_STATE_BUSY)
			{
				getClockDelayReReqInterval(pstPortData->pstClockData);
			}
			else
			{
#ifdef PTP_USE_DREQ_INTERVAL_ME
				getClockDelayReqInterval_ME(pstPortData->pstClockData);
#else
				getClockDelayReqInterval(pstPortData->pstClockData);
#endif
			}

		}
		else
		{
			pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval
				= initClockLogDelayReqInterval(pstClockData);
		}

		(VOID)ptpAddUSNs_USNs(&stCurrentTime,
								&(pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval),
								&(pstCDSGlb->stDelayReqSendTime));

		ptp_dbg_msg( D_DREQTO, 
		             ("domain(%d)::dreq timer. interval= %04x.%08x.%08x.%04x\n",
		              pstClockData->stDefaultDS.uchDomainNumber,
		              pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval.usNsec_msb,
					  pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval.ulNsec_2nd,
					  pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval.ulNsec_lsb,
					  pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval.usFrcNsec) );

		pstCDSGlb->pstTMO_DelayReqSendTime = ptp_TimeOut_Req(usSSTimeEvent,
																pstClockData,
																pstCDSGlb->stDelayReqSendTime,
																(CallBackFunc)&clockDelaySend_1588);

		pstCDSGlb->blDReqSendTO	= FALSE;

	}
	else if (pstCDSGlb->blRcvdMDDelayReq)
	{





		DreqTransChkTmo( pstClockData );

		nTxState = ChkDreqTransProcessing( pstClockData );
		if( nTxState == DREQ_TX_STATE_PAUSE )
		{
			txPDRQSendAll_1588( pstClockData );
		}
		else
		{
			PTP_WARNING_LOGRECORD( pstClockData, 
								   PTP_LOG_CDSENDSM_1588, 
								   PTP_LOGVE_84000012 );
		}
	}
	else
	{
	}

	pstCDSGlb->blRcvdMDDelayReq = FALSE;
	pstCDSGlb->enStatusCDS	= ST_CDS_WAITING;

	ptp_dbg_msg(D_FUNC, ("CDSend_1588_02::-\n"));
}



VOID	CDSend_1588_03(
	CLOCKDATA*	pstClockData)
{
	CDSENDSM_1588_GD*	pstCDSGlb				= GetCDSendSM_1588_GD(pstClockData);


	if (pstCDSGlb->blRcvdMDDelayResp)
	{

		txPDRSSendAll_1588(pstClockData);

		pstCDSGlb->blRcvdMDDelayResp = FALSE;
	}

	pstCDSGlb->enStatusCDS	= ST_CDS_WAITING;

}



PORTDATA*	GetSlavePort(
	CLOCKDATA*	pstClockData)
{
	PORTDATA*	pstPortData = NULL;


	for (pstPortData = pstClockData->pstPortData;
			pstPortData != NULL;
			pstPortData = pstPortData->pstNextPortDataPtr)
	{
		if ( (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_SLAVE) ||
			(pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstPortData->stPort_GD.usThisPort]
																											== (UCHAR)PS_EX_UNCALIBRATED))
		{
			break;
		}
	}

	return pstPortData;
}




MDDELAYREQ*  setMDDelayReqSend_1588(
	PORTDATA*	pstPortData)
{
	CLOCKDATA*			pstClockData			= pstPortData->pstClockData;
	CDSENDSM_1588_GD*	pstCDSGlb				= NULL;
	MDDELAYREQ*			pstMdDelayReqSendPtr	= NULL;




	pstCDSGlb						= GetCDSendSM_1588_GD(pstClockData);
	pstCDSGlb->pstRcvdMDDReqRcvPtr	= &(pstPortData->stPort_GD.stMdDelayReqSnd);
	pstMdDelayReqSendPtr			= pstCDSGlb->pstRcvdMDDReqRcvPtr;

	pstMdDelayReqSendPtr->uchClockNumber = pstClockData->stDefaultDS.uchDomainNumber;
	SET_SCALEDNS((pstMdDelayReqSendPtr->stCorrectionField), 0, 0, 0, 0);

	pstMdDelayReqSendPtr->stSourcePortIdentity = pstPortData->stPortDS.stPortIdentity;
	pstMdDelayReqSendPtr->usSequenceId = 0;
	SET_TIMESTAMP((pstMdDelayReqSendPtr->stOriginTimestamp), 0, 0, 0);

	pstCDSGlb->pstTxMDDReqSndPtr = pstMdDelayReqSendPtr;

	return pstMdDelayReqSendPtr;
}



MDDELAYREQ*  setMDDelayReq_1588(
	CLOCKDATA*	pstClockData,
	PORTDATA*	pstPortData)
{
	CDSENDSM_1588_GD*	pstCDSGlb				= GetCDSendSM_1588_GD(pstClockData);
	MDDELAYREQ*			pstMdDelayReqSendPtr	= &(pstPortData->stPort_GD.stMdDelayReqSnd);


	*pstMdDelayReqSendPtr = *pstCDSGlb->pstRcvdMDDReqRcvPtr;
	pstCDSGlb->pstTxMDDReqSndPtr = pstMdDelayReqSendPtr;

	return pstMdDelayReqSendPtr;
}





static VOID txPDRQSend_1588( MDDELAYREQ* pstMDDelayReqSendPtr,
		              		 PORTDATA*	 pstPortData )
{
	PDRQSENDSM_1588_GD*	pstPDRQSENDSM_1588_GD	= &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQSendSM_1588_GD);
	USCALEDNS	stCurrentTime;
	USCALEDNS	stInterval;
	USCALEDNS	stUSNs = { 0 };
	INT 		nIndex;
	BOOL		blRet;
	USHORT		usEvent;

	ptp_dbg_msg(D_FUNC, ("txPDRQSend_1588::+\n"));
	ptp_dbg_msg(D_DBG,  ("--port (%d)[%08x]\n", pstPortData->stPortDS.stPortIdentity.usPortNumber, (UINT)pstPortData));

	if ( (pstPortData->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_DREQ) != 0U )
	{
		tsn_Wrapper_MemCpy( (VOID *)&stInterval,
		                    (VOID *)&pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout,
		                    sizeof(USCALEDNS) );
	}
	else
	{
		stUSNs.ulNsec_lsb = DEQ_EGRESS_TS_TIMEOUT;
		(VOID)ptpMultUSNs_ULONG( &stUSNs, 1000U, &stInterval );
	}
	
	ptp_dbg_msg( D_DREQTO, 
	             ("domain(%d)::add dreq timeout timer. port=[%d]\n", 
				  pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
				  pstPortData->stPort_GD.usThisPort) );

	nIndex = (INT)pstPortData->stPort_GD.usThisPort - 1;
	gstDreqTmoManage[nIndex].pstDreqSendPort = pstPortData;
	
	if ( IS_USCALEDNS_0(stInterval) != TRUE )
	{
		ptp_GetCurrentTime( pstPortData->pstClockData, &stCurrentTime );
		

		blRet = ptpAddUSNs_USNs( &stCurrentTime, 
								 &stInterval, 
								 &gstDreqTmoManage[nIndex].stDreqCompWaitTimeoutTime );
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPortData->pstClockData, PTP_LOG_CDSENDSM_1588, (ULONG)PTP_LOGVE_OVERFLOW);
		}
	}
	else
	{
		gstDreqTmoManage[nIndex].stDreqCompWaitTimeoutTime.usNsec_msb = 0xFFFFU;
		gstDreqTmoManage[nIndex].stDreqCompWaitTimeoutTime.ulNsec_2nd = 0xFFFFFFFFU;
		gstDreqTmoManage[nIndex].stDreqCompWaitTimeoutTime.ulNsec_lsb = 0xFFFFFFFFU;
		gstDreqTmoManage[nIndex].stDreqCompWaitTimeoutTime.usFrcNsec  = 0xFFFFU;
	}

	ptp_dbg_msg(D_DBG, ("ulME_extend                                    =[%08x]\n", pstPortData->pstClockData->stClock_GD.ulME_extend));
	ptp_dbg_msg(D_DBG, ("gstCurrentTime                                 =[%04x:%08x:%08x:%04x]\n"
		, gstCurrentTime.usNsec_msb
		, gstCurrentTime.ulNsec_2nd
		, gstCurrentTime.ulNsec_lsb
		, gstCurrentTime.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("DEQ_EGRESS_TS_TIMEOUT                          =[%08x]\n", DEQ_EGRESS_TS_TIMEOUT));
	ptp_dbg_msg(D_DBG, ("stClock_1588_GD.stDelayRespTimeout             =[%04x:%08x:%08x:%04x]\n"
		, pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout.usNsec_msb
		, pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout.ulNsec_2nd
		, pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout.ulNsec_lsb
		, pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout.usFrcNsec
		));

	ptp_dbg_msg(D_DBG, ("gstDreqTmoManage[%d].stDreqCompWaitTimeoutTime =[%04x:%08x:%08x:%04x]\n"
		, pstPortData->stPortDS.stPortIdentity.usPortNumber
		, gstDreqTmoManage[pstPortData->stPort_GD.usThisPort - 1].stDreqCompWaitTimeoutTime.usNsec_msb
		, gstDreqTmoManage[pstPortData->stPort_GD.usThisPort - 1].stDreqCompWaitTimeoutTime.ulNsec_2nd
		, gstDreqTmoManage[pstPortData->stPort_GD.usThisPort - 1].stDreqCompWaitTimeoutTime.ulNsec_lsb
		, gstDreqTmoManage[pstPortData->stPort_GD.usThisPort - 1].stDreqCompWaitTimeoutTime.usFrcNsec
	) );

	ptp_dbg_msg(D_DBG, ("gstDreqTmoManage[%d].pstDreqSendPort          =[%08x]\n"
		, pstPortData->stPortDS.stPortIdentity.usPortNumber
		, (UINT)gstDreqTmoManage[pstPortData->stPort_GD.usThisPort - 1].pstDreqSendPort
	) );

	pstPDRQSENDSM_1588_GD->pstRcvdMDDReqRcvPtr = pstMDDelayReqSendPtr;
	pstPDRQSENDSM_1588_GD->blRcvdMDDelayReq    = TRUE;

	usEvent = PTP_EV_FOR_PDLRQSND_RCVMDDLRQ;
	portDelayReqSend_1588( usEvent, pstPortData );

	ptp_dbg_msg(D_FUNC, ("txPDRQSend_1588::-\n"));

	return ;
}



VOID	txPDRQSendAll_1588(
	CLOCKDATA*		pstClockData)
{
	PORTDATA*			pstPortData				= pstClockData->pstPortData;
	USHORT				usRecPortNum			= PORT_NO_0;
	MDDELAYREQ*			pstMDDelayReqSendPtr	= NULL;

	usRecPortNum = pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.usRcvdMDDReqRcvPNumber;

	while (pstPortData != NULL)
	{
		if (IS_PORTOK(pstPortData) &&
			(pstPortData->stPort_GD.usThisPort != usRecPortNum))
		{
			pstMDDelayReqSendPtr = setMDDelayReq_1588(pstClockData, pstPortData);

			txPDRQSend_1588(pstMDDelayReqSendPtr, pstPortData);
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

}



MDDELAYRESP*	setMDDelayResp_1588(
	CLOCKDATA*	pstClockData,
	PORTDATA*	pstPortData)
{
	CDSENDSM_1588_GD*	pstCDSGlb				= GetCDSendSM_1588_GD(pstClockData);
	MDDELAYRESP*		pstMDDelayRespSendPtr	= &(pstPortData->stPort_GD.stMdDelayRespSnd);


	*pstMDDelayRespSendPtr = *pstCDSGlb->pstRcvdMDDRespRcvPtr;
	pstCDSGlb->pstTxMDDRespSndPtr = pstMDDelayRespSendPtr;

	return pstMDDelayRespSendPtr;
}




VOID	txPDRSSend_1588(
	MDDELAYRESP*	pstMdDelayRespSendPtr,
	PORTDATA*		pstPortData)
{
	USHORT				usEvent					= PTP_EV_BASE;
	PDRSSENDSM_1588_GD*	pstPDRSSENDSM_1588_GD	= &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD);


	pstPDRSSENDSM_1588_GD->pstRcvdMDDRespRcvPtr = pstMdDelayRespSendPtr;
	pstPDRSSENDSM_1588_GD->blRcvdMDDelayResp = TRUE;

	usEvent = PTP_EV_FOR_PDLRSSND_RCVMDDLRS;
	portDelayRespSend_1588(usEvent, pstPortData);

}





VOID	txPDRSSendAll_1588(
	CLOCKDATA*		pstClockData)
{
	PORTDATA*			pstPortData				= pstClockData->pstPortData;
	USHORT				usRecPortNum			= PORT_NO_0;
	MDDELAYRESP*		pstMdDelayRespSendPtr	= NULL;

	usRecPortNum = pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.usRcvdMDDRespRcvPNumber;

	while (pstPortData != NULL)
	{
		if (   (pstPortData->stPort_GD.blPortValid == TRUE)
		    && IS_PORTOK(pstPortData) 
			&& (pstPortData->stPort_GD.usThisPort != usRecPortNum) )
		{
			pstMdDelayRespSendPtr = setMDDelayResp_1588(pstClockData, pstPortData);

			txPDRSSend_1588(pstMdDelayRespSendPtr, pstPortData);
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

}

VOID	getClockDelayReqInterval(
	CLOCKDATA*	pstClockData)
{
	ULONG				ulRandom		= 0;
	ULONG				ulSpanRandam	= 0;
	USCALEDNS			stSpanNs_In		= {0};
	USCALEDNS			stSpanNs		= {0};
	USCALEDNS			stSpanNs_W		= {0};
	USCALEDNS			stSpanNs_W2		= {0};
	CHAR				chSpanShift		= ((CHAR)(-CONS_SHIFT15)) + CONS_SHIFT16;


	stSpanNs_In.ulNsec_lsb = CONST10_9 >> CONS_SHIFT15;
	stSpanNs_In.usFrcNsec  = (USHORT)((CONST10_9 & (ULONG)MASK_7FFF) << CONS_SHIFT1);
	(VOID)ptpShiftUSNs_CHAR(&stSpanNs_In,
							pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval,
							&stSpanNs_W);

	ulRandom = (ULONG)tsn_Wrapper_Rand();
	ulSpanRandam = (ulRandom % (ULONG)S_MIN_8000) + ULCONST_1;

	(VOID)ptpMultUSNs_ULONG(&stSpanNs_W,
							ulSpanRandam,
							&stSpanNs_W2);

	(VOID)ptpShiftUSNs_CHAR(&stSpanNs_W2,
							chSpanShift,
							&stSpanNs);

	tsn_Wrapper_MemCpy((VOID*)&pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval,
							((const VOID*)&stSpanNs),
							sizeof(USCALEDNS));
}
static VOID getClockDelayReqInterval_ME( CLOCKDATA* pstClockData )
{
	ULONG     ulRandom;
	CHAR      chLog;
	USCALEDNS stUSNs     = { 0 };
	USCALEDNS stUnitNs   = { 0 };
	USCALEDNS stOffsetNs = { 0 };

	ptp_dbg_msg(D_FUNC, ("getClockDelayReqInterval_ME::+\n"));

	chLog = pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval - RAND_MAX_LOG;
	
	stUnitNs.ulNsec_lsb = 1U;
	(VOID)ptpShiftUSNs_CHAR( &stUnitNs, chLog, &stUSNs );

	tsn_Wrapper_MemSet(&stUnitNs, 0, sizeof(USCALEDNS));
	(VOID)ptpMultUSNs_ULONG( &stUSNs, CONST10_9, &stUnitNs );

	ulRandom  = (ULONG)tsn_Wrapper_Rand();
	ulRandom &= MASK_7FFF;

	(VOID)ptpMultUSNs_ULONG( &stUnitNs, ulRandom, &stOffsetNs );

	tsn_Wrapper_MemSet( &stUSNs,   0, sizeof(USCALEDNS) );
	tsn_Wrapper_MemSet( &stUnitNs, 0, sizeof(USCALEDNS) );

	chLog = pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval;

	stUnitNs.ulNsec_lsb = 1U;
	(VOID)ptpShiftUSNs_CHAR( &stUnitNs, chLog, &stUSNs );
	tsn_Wrapper_MemSet(&stUnitNs, 0, sizeof(USCALEDNS));
	(VOID)ptpMultUSNs_ULONG( &stUSNs, CONST10_9, &stUnitNs );
	
	(VOID)ptpAddUSNs_USNs( &stUnitNs, 
						   &stOffsetNs, 
						  &pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval );

	ptp_dbg_msg(D_FUNC, ("getClockDelayReqInterval_ME::-\n"));

	return ;
}
static VOID getClockDelayReReqInterval( CLOCKDATA* pstClockData )
{
	
	tsn_Wrapper_MemCpy( (VOID*)&pstClockData->stUn_Clock_GD.stClock_1588_GD.stDReqSendHoldTime,
						(const VOID*)&pstClockData->stUn_Clock_GD.stClock_1588_GD.stClockDelayReqInterval,
						sizeof(USCALEDNS) );

	return ;
}


CHAR	initClockLogDelayReqInterval(
	CLOCKDATA*		pstClockData)
{
	PORTDATA*	pstPortData		= pstClockData-> pstPortData;
	CHAR		chLMDInterval	= 0;


	chLMDInterval = pstPortData->stPort_1588_DS.chLogMinDelayReqInterval;

	while (pstPortData != NULL)
	{
		if (chLMDInterval < pstPortData->stPort_1588_DS.chLogMinDelayReqInterval)
		{
			chLMDInterval = pstPortData->stPort_1588_DS.chLogMinDelayReqInterval;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	return	chLMDInterval;

}
VOID DreqTransChkTmo( CLOCKDATA* pstClock )
{
	USCALEDNS	stCurrentTime = {0};
	CHAR		chRet;
	USHORT 		usIndex;

	ptp_dbg_msg(D_FUNC, ("DreqTransChkTmo::+\n"));

	ptp_GetCurrentTime( pstClock, &stCurrentTime );
	
	for( usIndex=0U; usIndex < pstClock->stDefaultDS.usNumberPorts; usIndex++ )
	{

		if ( gstDreqTmoManage[usIndex].pstDreqSendPort != NULL )
		{
			chRet = ptpCompUSNs_USNs( &gstDreqTmoManage[usIndex].stDreqCompWaitTimeoutTime, 
									  &stCurrentTime );
			if ( chRet == COMP_A_LESS )
			{
				gstDreqTmoManage[usIndex].pstDreqSendPort->stPortMD_GD.blTxDlySequencdIdChg = FALSE;
				
				tsn_Wrapper_MemSet( (VOID *)&gstDreqTmoManage[usIndex], 0, sizeof(DREQTMOMAN) );
				PTP_ERROR_LOGRECORD( pstClock, 
									 PTP_LOG_CDSENDSM_1588, 
									 PTP_LOGVE_84000011 );
			}
		}
	}

	ptp_dbg_msg(D_FUNC, ("DreqTransChkTmo::-\n"));

	return ;
}
INT ChkDreqTransProcessing ( CLOCKDATA* pstClock )
{
	PORTDATA* 	pstPort;
	INT 		nIndex;
	INT			nRet;

	ptp_dbg_msg(D_FUNC, ("ChkDreqTransProcessing::+\n"));

	nRet = DREQ_TX_STATE_PAUSE;

	if ( IS_OD_BC_1588(pstClock) )
	{
		for ( pstPort = pstClock->pstPortData; pstPort != NULL; pstPort = pstPort->pstNextPortDataPtr )
		{
			nIndex = (INT)pstPort->stPort_GD.usThisPort;
			if (   (pstClock->stClock_GD.enSelectedState[nIndex] == ENUM_PORTSTATE_SLAVE) 
			    || (pstClock->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[nIndex] == (UCHAR)PS_EX_UNCALIBRATED) )
			{
				break;
			}
		}
	}
	else
	{
		for ( pstPort = pstClock->pstPortData; pstPort != NULL; pstPort = pstPort->pstNextPortDataPtr )
		{
			if (   IS_PORTOK(pstPort) 
			    && (pstPort->stPort_GD.usThisPort != pstClock->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.usRcvdMDDReqRcvPNumber) )
			{
				break;
			}
		}
	}
	
	if ( pstPort != NULL )
	{
		nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
		if ( gstDreqTmoManage[nIndex].pstDreqSendPort != NULL )
		{
			if ( gstDreqTmoManage[nIndex].pstDreqSendPort == pstPort )
			{
				nRet = DREQ_TX_STATE_RUN;
			}
			else
			{
				nRet = DREQ_TX_STATE_BUSY;
			}
			ptp_dbg_msg( D_DREQTO, 
			             ("dreq send processing(%d). domain,port=[%d,%d]\n", 
			              nRet,
			              gstDreqTmoManage[nIndex].pstDreqSendPort->pstClockData->stDefaultDS.uchDomainNumber,
			              gstDreqTmoManage[nIndex].pstDreqSendPort->stPort_GD.usThisPort) );
		}
	}

	ptp_dbg_msg(D_FUNC, ("ChkDreqTransProcessing::-\n"));

	return	nRet;
}


#endif

