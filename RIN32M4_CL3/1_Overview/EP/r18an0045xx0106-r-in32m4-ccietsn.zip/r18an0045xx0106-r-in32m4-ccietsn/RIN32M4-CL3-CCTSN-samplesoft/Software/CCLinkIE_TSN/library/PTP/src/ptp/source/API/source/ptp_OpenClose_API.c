/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Proto.h"

#include "ptp_api.h"
#include "ptp_MemManage.h"

#include "ManagementSM.h"

#include "ptp_LCEntity.h"
#include "PortAnnounceReceiveSM.H"
#include "PortAnnounceInformationSM.h"
#include "PortStateSelectionSM.h"
#include "PortAnnounceTransmitSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "MDDelayReqReceiveSM.h"
#include "MDDelayReqSendSM.h"
#include "MDDelayRespReceiveSM.h"
#include "MDDelayRespSendSM.h"
#include "MDLkDlyIntvalSet.h"
#include "MDOneStpTxOprSet.h"
#include "MDPdelayReq.h"
#include "MDPdelayResp.h"
#include "MDSyncIntvalSet.h"
#include "MDSyncReceiveSM.h"
#include "MDSyncSendSM.h"


#include "ptp_BCSSend_1588.h"
#include "ptp_CDSend_1588.h"
#include "ptp_CMSOffset_1AS.h"
#include "ptp_CMSReceive.h"
#include "ptp_CMSSend.h"

#include "ptp_CSSync_1588.h"
#include "ptp_CSSync_1AS.h"
#include "ptp_LCEntity.h"
#include "ptp_PDRQReceive_1588.h"
#include "ptp_PDRQSend_1588.h"
#include "ptp_PDRSReceive_1588.h"
#include "ptp_PDRSSend_1588.h"
#include "ptp_PSSReceive_1588.h"
#include "ptp_PSSReceive_1AS.h"
#include "ptp_PSSSend.h"
#include "ptp_SSSync_1588.h"
#include "ptp_SSSync_1AS.h"
#include "AnnounceIntvalSet.h"
#ifdef	PTP_USE_IEEE802_1
#include "gptpCapableIntSetSM.h"
#include "gptpCapableReceiveSM.h"
#include "gptpCapableTransmitSM.h"
#endif

#include "ptp_API_Local.h"
#include "ptp_OpenClose_API.h"


static BOOL ptp_sm_clock( CLOCKDATA* pstClockData, USHORT usEvent );
static BOOL ptp_sm_port( CLOCKDATA* pstClockData, USHORT usEvent );
INT	ptp_open_Protcol(CLOCKDATA* pstClockData);
INT ptp_close_Protcol(CLOCKDATA* pstClockData);
static VOID ptp_portenable( CLOCKDATA* pstClockData );
static VOID ptp_portdisable( CLOCKDATA* pstClockData );
INT ptp_Mdl_close(CLOCKDATA*);




const PTP_API_CLOCKSM	stPtpClockFunction[] =
{
#ifdef	PTP_USE_GM
	{"clockMasterSyncSend",			&clockMasterSyncSend,			PTP_APISUPPORT_1AS_1588	},
	{"clockMasterSyncReceive",		&clockMasterSyncReceive,		PTP_APISUPPORT_1AS_1588	},
#endif
#ifdef	PTP_USE_IEEE1588
	{"siteSyncSync_1588",			&siteSyncSync_1588,				PTP_APISUPPORT_1588		},
#endif
#ifdef	PTP_USE_IEEE802_1
	{"siteSyncSync_1AS",			&siteSyncSync_1AS,				PTP_APISUPPORT_1AS		},
#endif
#ifdef	PTP_USE_IEEE802_1
#ifdef	PTP_USE_GM
	{"clockMasterSyncOffset_1AS",	&clockMasterSyncOffset_1AS,		PTP_APISUPPORT_1AS		},
#endif
#endif
#ifdef	PTP_USE_IEEE1588
	{"clockSlaveSync_1588",			&clockSlaveSync_1588,			PTP_APISUPPORT_1588		},
#endif
#ifdef	PTP_USE_IEEE802_1
	{"clockSlaveSync_1AS",			&clockSlaveSync_1AS,			PTP_APISUPPORT_1AS		},
#endif
#ifdef	PTP_USE_IEEE1588
	{"boundaryClockSyncSend_1588",	&boundaryClockSyncSend_1588,	PTP_APISUPPORT_1588		},
	{"clockDelaySend_1588",			&clockDelaySend_1588,			PTP_APISUPPORT_1588		},
#endif
};

const PTP_API_PORTSM	stPtpPortFunction[] =
{

#ifdef	PTP_USE_SIGNALING
#ifdef	PTP_USE_IEEE802_1
	{"gptpCapableIntSetSM",			&gptpCapableIntSetSM,			PTP_APISUPPORT_1AS		},
#endif
	{"SyncIntervalSettingSM",		&SyncIntervalSettingSM,			PTP_APISUPPORT_1AS	},
	{"LinkDelayIntervalSettingSM",	&LinkDelayIntervalSettingSM,	PTP_APISUPPORT_1AS	},
	{"OneStepTxOperSettingSM",		&OneStepTxOperSettingSM,		PTP_APISUPPORT_1AS	},
#endif
#ifdef	PTP_USE_IEEE802_1
	{"gptpCapableReceiveSM",		&gptpCapableReceiveSM,			PTP_APISUPPORT_1AS		},
	{"gptpCapableTransmitSM",		&gptpCapableTransmitSM,			PTP_APISUPPORT_1AS		},
#endif

	{"MDDelayReqReceiveSM",			&MDDelayReqReceiveSM,			PTP_APISUPPORT_1588	},
	{"MDDelayReqSendSM",			&MDDelayReqSendSM,				PTP_APISUPPORT_1588	},
	{"MDDelayRespReceiveSM",		&MDDelayRespReceiveSM,			PTP_APISUPPORT_1588	},
	{"MDDelayRespSendSM",			&MDDelayRespSendSM,				PTP_APISUPPORT_1588	},
	{"MDPdelayReq",					&MDPdelayReq,					PTP_APISUPPORT_1AS_1588	},
	{"MDPdelayResp",				&MDPdelayResp,					PTP_APISUPPORT_1AS_1588	},
	{"MDSyncReceiveSM",				&MDSyncReceiveSM,				PTP_APISUPPORT_1AS_1588	},
	{"MDSyncSendSM",				&MDSyncSendSM,					PTP_APISUPPORT_1AS_1588	},
#ifdef	PTP_USE_SIGNALING
	{"AnnounceIntervalSettingSM",	&AnnounceIntervalSettingSM,		PTP_APISUPPORT_1AS		},
#endif
#ifdef	PTP_USE_BMCA
	{"portAnnounceReceiveSM",		&portAnnounceReceiveSM,			PTP_APISUPPORT_1AS_1588	},
#endif
	{"portStateSelectionSM",		&portStateSelectionSM,			PTP_APISUPPORT_1AS_1588	},
	{"portAnnounceTransmitSM",		&portAnnounceTransmitSM,		PTP_APISUPPORT_1AS_1588	},
#ifdef	PTP_USE_BMCA
	{"portAnnounceInformationSM",	&portAnnounceInformationSM,		PTP_APISUPPORT_1AS_1588	},
#endif
	{"portAnnounceInformationExtSM",&portAnnounceInformationExtSM,	PTP_APISUPPORT_1AS_1588	},
	{"portSyncSyncSend",			&portSyncSyncSend,				PTP_APISUPPORT_1AS_1588	},
#ifdef	PTP_USE_IEEE1588
	{"portSyncSyncReceive_1588",	&portSyncSyncReceive_1588,		PTP_APISUPPORT_1588		},
#endif
#ifdef	PTP_USE_IEEE802_1
	{"portSyncSyncReceive_1AS",		&portSyncSyncReceive_1AS,		PTP_APISUPPORT_1AS		},
#endif
#ifdef	PTP_USE_IEEE1588
	{"portDelayReqSend_1588",		&portDelayReqSend_1588,			PTP_APISUPPORT_1588		},
	{"portDelayRespSend_1588",		&portDelayRespSend_1588,		PTP_APISUPPORT_1588		},
	{"portDelayReqReceive_1588",	&portDelayReqReceive_1588,		PTP_APISUPPORT_1588		},
	{"portDelayRespReceive_1588",	&portDelayRespReceive_1588,		PTP_APISUPPORT_1588		}
#endif
};





INT	ptp_open( VOID )
{
	CLOCKDATA*		pstClockData;
	INT				nRet			= RET_ENOERR;

	if ( gpstClockDataHPtr == NULL )
	{
		return RET_ESTATE;
	}
	if ( gblStartUpConfig != TRUE )
	{
		return RET_ESTATE;
	}

	if ( gblStartUpOpen == TRUE )
	{
		return RET_ESTATE;
	}

	nRet = ptp_SystemSemLockWait( gpstClockDataHPtr );
	if (nRet != RET_ENOERR)
	{
		return RET_ESTATE;
	}

	if ( RET_ENOERR != ptp_open_Protcol(gpstClockDataHPtr) )
	{
		(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
		return RET_ETRANS;
	}

	for ( pstClockData  = gpstClockDataHPtr;
	      pstClockData != NULL;
	      pstClockData  = pstClockData->pstNextClockDataPtr )
	{
		pstClockData->stClock_GD.blBEGIN = TRUE;

		localClockEntity( PTP_EV_BEGIN, pstClockData );

		ptp_portenable( pstClockData );

		if ( ptp_sm_clock( pstClockData, PTP_EV_BEGIN ) == FALSE )
		{
			(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
			return RET_ESTATE;
		}
		if ( ptp_sm_port( pstClockData, PTP_EV_BEGIN ) == FALSE )
		{
			(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
			return RET_ESTATE;
		}
		pstClockData->stClock_GD.blBEGIN = FALSE;
	}

	gblStartUpOpen	= TRUE;

	(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );

	return nRet;
}

INT	ptp_close( VOID )
{
	CLOCKDATA*		pstClockData;
	LONG			lRet;

	if ( gpstClockDataHPtr == NULL )
	{
		return RET_ESTATE;
	}
	if ( gblStartUpOpen == FALSE )
	{
		return RET_ESTATE;
	}

	lRet = ptp_SystemSemLockWait(gpstClockDataHPtr);
	if (lRet != RET_ENOERR)
	{
		return RET_ESTATE;
	}

	if (RET_ENOERR != ptp_close_Protcol(gpstClockDataHPtr))
	{
		(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
		return RET_ETRANS;
	}

	for ( pstClockData  = gpstClockDataHPtr;
	      pstClockData != NULL;
	      pstClockData  = pstClockData->pstNextClockDataPtr )
	{
		if ( ptp_sm_clock( pstClockData, PTP_EV_CLOSE ) == FALSE )
		{
			return RET_ESTATE;
		}

		if ( ptp_sm_port( pstClockData, PTP_EV_CLOSE ) == FALSE )
		{
			(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
			return RET_ESTATE;
		}
		if (RET_ENOERR != ptp_Mdl_close(pstClockData))
		{
			(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );
			return RET_ETRANS;
		}
		ptp_portdisable( pstClockData );
	}

	(VOID)ptp_MMClose( gpstClockDataHPtr->stDefaultDS.uchDomainNumber );

	gblStartUpConfig = FALSE;
	gblStartUpOpen	 = FALSE;

	(VOID)ptp_SystemSemUnLock( gpstClockDataHPtr );

	return RET_ENOERR;
}



static BOOL ptp_sm_clock( CLOCKDATA* pstClockData, USHORT usEvent )
{

	ENUM_PTPAPI_SUPPORT enApp;
	INT			nLoopNum = 0;
	INT			i;
	if (gpstClockDataHPtr == NULL)
	{
		return FALSE;
	}
	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS) {
		enApp = PTP_APISUPPORT_1AS;
	}
	else {
		enApp = PTP_APISUPPORT_1588;
	}

	nLoopNum = sizeof(stPtpClockFunction) / sizeof(stPtpClockFunction[0]);

	for (i = 0; i < nLoopNum; i++)
	{
		if ((enApp == stPtpClockFunction[i].enSupportPTPType) ||
			(stPtpClockFunction[i].enSupportPTPType == PTP_APISUPPORT_1AS_1588))
		{
			(*stPtpClockFunction[i].pfnFuncClock)(usEvent, pstClockData);
		}
	}
	return TRUE;
}

static BOOL ptp_sm_port( CLOCKDATA* pstClockData, USHORT usEvent )
{
	PORTDATA*	pstPortData		= NULL;
	PORTDATA*	pstNextPortData	= NULL;
	ENUM_PTPAPI_SUPPORT enApp;
	INT			nLoopNum = 0;
	INT			i, j;
	if (gpstClockDataHPtr == NULL)
	{
		return FALSE;
	}

	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS) {
		enApp = PTP_APISUPPORT_1AS;
	}
	else {
		enApp = PTP_APISUPPORT_1588;
	}

	nLoopNum = sizeof(stPtpPortFunction) / sizeof(stPtpPortFunction[0]);

	for (i = 0; i < nLoopNum; i++)
	{
		pstNextPortData = pstClockData->pstPortData;
		for (j = 0; j < pstClockData->stDefaultDS.usNumberPorts; j++)
		{
			pstPortData = pstNextPortData;
			if ((enApp == stPtpPortFunction[i].enSupportPTPType) ||
				(stPtpPortFunction[i].enSupportPTPType == PTP_APISUPPORT_1AS_1588))
			{
				(*stPtpPortFunction[i].pfnFuncPort)(usEvent, pstPortData);
			}

			pstNextPortData = pstClockData->pstPortData->pstNextPortDataPtr;
			if (pstNextPortData == NULL)
			{
				break;
			}
		}
	}
	return TRUE;
}

BOOL ptp_sm_port_des(USHORT usEvent, PORTDATA* pstPortData)
{
	CLOCKDATA*	pstClockData	= gpstClockDataHPtr;
	ENUM_PTPAPI_SUPPORT enApp;
	INT			nLoopNum = 0;
	INT			i;
	if (gpstClockDataHPtr == NULL)
	{
		return FALSE;
	}

	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS) {
		enApp = PTP_APISUPPORT_1AS;
	}
	else {
		enApp = PTP_APISUPPORT_1588;
	}

	nLoopNum = sizeof(stPtpPortFunction) / sizeof(stPtpPortFunction[0]);

	for (i = 0; i < nLoopNum; i++)
	{
		if ((enApp == stPtpPortFunction[i].enSupportPTPType) ||
			(stPtpPortFunction[i].enSupportPTPType == PTP_APISUPPORT_1AS_1588))
		{
			(*stPtpPortFunction[i].pfnFuncPort)(usEvent, pstPortData);
		}
	}
	return TRUE;
}

static VOID ptp_portenable( CLOCKDATA* pstClockData )
{
	PORTDATA*	pstPortData		= NULL;
	PORTDATA*	pstNextPortData	;
	INT			i;

	pstNextPortData = pstClockData->pstPortData;
	for (i = 0; i < pstClockData->stDefaultDS.usNumberPorts; i++)
	{
		pstPortData = pstNextPortData;
		pstPortData->stPort_1AS_DS.blPtpPortEnabled = TRUE;
		pstPortData->stPort_GD.blPortOper			= TRUE;

		pstNextPortData = pstClockData->pstPortData->pstNextPortDataPtr;
		if (pstNextPortData == NULL)
		{
			break;
		}
	}
}
static VOID ptp_portdisable( CLOCKDATA* pstClockData )
{
	PORTDATA*	pstPortData		= NULL;
	PORTDATA*	pstNextPortData	;
	INT			i;

	pstNextPortData = pstClockData->pstPortData;
	for (i = 0; i < pstClockData->stDefaultDS.usNumberPorts; i++)
	{
		pstPortData = pstNextPortData;
		pstPortData->stPort_1AS_DS.blPtpPortEnabled = FALSE;
		pstPortData->stPort_GD.blPortOper			= FALSE;

		pstNextPortData = pstClockData->pstPortData->pstNextPortDataPtr;
		if (pstNextPortData == NULL)
		{
			break;
		}
	}
}

VOID ptp_portenable_des(PORTDATA* pstPortData)
{
	pstPortData->stPort_1AS_DS.blPtpPortEnabled = TRUE;
	pstPortData->stPort_GD.blPortOper			= TRUE;
}
#if 1
BOOL ptp_portStatus_des(PORTDATA* pstPortData)
{
	return (( pstPortData->stPort_1AS_DS.blPtpPortEnabled) ||
			(pstPortData->stPort_GD.blPortOper));
}
#endif
VOID ptp_portdisable_des(PORTDATA* pstPortData)
{
	pstPortData->stPort_1AS_DS.blPtpPortEnabled = FALSE;
	pstPortData->stPort_GD.blPortOper			= FALSE;
}

INT ptp_open_Protcol(CLOCKDATA* pstClockData)
{
	USHORT			usPortmaxNum		= pstClockData->stDefaultDS.usNumberPorts;
	INT				nRet			= RET_ENOERR;
	INT				nOpenRet;

	switch( pstClockData->pstPortAddrInfo->enClockTrans )
	{
	case	CLK_TRANS_IEEE802_1_AS:
	case	CLK_TRANS_IEEE1588_L2:
		nOpenRet = layer2_open(usPortmaxNum, (MACADDR *)pstClockData->pstPortAddrInfo->pvAddrInfo);

		if (nOpenRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	case	CLK_TRANS_IEEE1588_L4_IPV4:
		nOpenRet = layer4V4_open( usPortmaxNum, 
							 	  pstClockData->pstPortAddrInfo->stPortAdrInfSub.ulNetMask,
								  (IPV4ADDR *)pstClockData->pstPortAddrInfo->pvAddrInfo );

		if (nOpenRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	case	CLK_TRANS_IEEE1588_L4_IPV6:
		nOpenRet = layer4V6_open( usPortmaxNum, 
								  (ULONG)pstClockData->pstPortAddrInfo->stPortAdrInfSub.nPrefixLen,
								  (IPV6ADDR *)pstClockData->pstPortAddrInfo->pvAddrInfo);

		if (nOpenRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	default:
		nRet = RET_ETRANS;
		break;
	}

	return nRet;
}
INT ptp_close_Protcol(CLOCKDATA* pstClockData)
{
	INT				nRet			= RET_ENOERR;
	INT				nCloseRet;

	switch( pstClockData->pstPortAddrInfo->enClockTrans )
	{
	case	CLK_TRANS_IEEE802_1_AS:
	case	CLK_TRANS_IEEE1588_L2:
		nCloseRet = layer2_close();
		if (nCloseRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	case	CLK_TRANS_IEEE1588_L4_IPV4:
		nCloseRet = layer4V4_close();
		if (nCloseRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	case	CLK_TRANS_IEEE1588_L4_IPV6:
		nCloseRet = layer4V6_close();
		if (nCloseRet == RET_ENOERR) {
			nRet = RET_ENOERR;
		}
		else {
			nRet = RET_ETRANS;
		}
		break;
	default:
		nRet = RET_ETRANS;
		break;
	}

	return nRet;
}
