/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "TOOL_api.h"
#include "ccienx_const.h"
#include "LSM_api.h"
#include "ccienx_api.h"
#include "NGN_ASIC.h"

#define	RELNSPD_1G		(NX_ULONG)0x00000000
#define	RELNSPD_100M	(NX_ULONG)0x01010101

typedef struct tagNX_LSM_CTRL {
	NX_USHORT	usLinkSpdSta;
	NX_USHORT	usRsv1;
} NX_LSM_CTRL;
NX_STATIC NX_LSM_CTRL 			gstLsmCtrl;

NX_VOID vLSM_Init ( NX_VOID )
{
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
	
	vNX_FillMemory16( &gstLsmCtrl, NX_ZERO, sizeof(NX_LSM_CTRL) / sizeof(NX_USHORT));
	
	vLSM_ApplyLinkSpd();
	
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
		NGN_CN_REG->R_RELNSPD.DATA		=	RELNSPD_100M;
	}
	else {
		NGN_CN_REG->R_RELNSPD.DATA		=	RELNSPD_1G;
	}
	
	return;
}

NX_VOID vLSM_ApplyLinkSpd ( NX_VOID )
{
	if (gstAppInfo.stEthInfo.ulLinkSpd == NX_LINKSPD_CONF_100M) {
		
		gstLsmCtrl.usLinkSpdSta = NX_LINKSPD_STA_100M;
		
	}
	else {
		
		gstLsmCtrl.usLinkSpdSta = NX_LINKSPD_STA_1G;
		
	}
	
	return;
}

NX_USHORT usLSM_GetLinkSpd ( NX_VOID )
{
	return gstLsmCtrl.usLinkSpdSta;
}

/*[EOF]*/
