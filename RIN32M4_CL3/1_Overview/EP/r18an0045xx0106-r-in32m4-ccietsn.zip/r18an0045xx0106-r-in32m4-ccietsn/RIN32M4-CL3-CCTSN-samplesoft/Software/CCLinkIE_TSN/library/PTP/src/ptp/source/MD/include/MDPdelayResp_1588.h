/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYRESP_1588_H__
#define __MDPDELAYRESP_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDPdelayResp_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDPdelayResp_00_1588(PORTDATA* pstPort);
VOID MDPdelayResp_01_1588(PORTDATA* pstPort);
VOID MDPdelayResp_02_1588(PORTDATA* pstPort);
VOID MDPdelayResp_03_1588(PORTDATA* pstPort);
VOID MDPdelayResp_NP_1588(PORTDATA* pstPort);

BOOL MDPdlyResp_NotEnable_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_IntWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_TwoWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_OneWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_StPDRpTwoWtFrTS_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_StPDRpOneWtFrTS_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDPdelayReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetPdelayRespTwoStep_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetPdelayRespOneStep_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayResp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetPdelayRespFollowUp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayRespFollowUp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
