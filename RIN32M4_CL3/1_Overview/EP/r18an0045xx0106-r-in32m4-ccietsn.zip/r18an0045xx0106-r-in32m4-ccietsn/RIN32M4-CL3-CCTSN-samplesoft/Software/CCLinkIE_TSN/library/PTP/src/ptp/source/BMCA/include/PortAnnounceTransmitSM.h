/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTANNOUNCETRANSMIT_H__
#define __PORTANNOUNCETRANSMIT_H__
#include <ptp_type.h>
#include <ptp_Struct_Port.h>



#ifdef __cplusplus
extern "C" {
#endif

VOID	portAnnounceTransmitSM(USHORT usEvent, PORTDATA *pstPort);
PATRANSMITSM_EV GetportAnnTransmitEvent(USHORT usEvent);
VOID	PortAnnounceTransmit_00(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_01(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_02(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_03(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_04(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_05(PORTDATA *pstPort);
VOID	PortAnnounceTransmit_nop(PORTDATA *pstPort);
VOID	txAnnounce(struct tagPORTDATA *pstPort);
VOID	txAnnounce_1588(struct tagPORTDATA *pstPort);
VOID	txAnnounce_AS(struct tagPORTDATA *pstPort);
VOID	SetTxAnnouceTimer(PORTDATA *pstPort);
#ifndef PTP_USE_SIGNALING
VOID anuncIntSet_1AS(PORTDATA* pstPort);
#endif

#ifdef __cplusplus
}
#endif

#endif
