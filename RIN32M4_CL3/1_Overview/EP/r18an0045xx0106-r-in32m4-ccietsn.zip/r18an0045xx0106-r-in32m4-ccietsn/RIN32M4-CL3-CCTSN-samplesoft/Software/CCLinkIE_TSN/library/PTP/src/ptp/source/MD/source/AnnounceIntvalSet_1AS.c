/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0


#ifdef	PTP_USE_IEEE802_1

#include "AnnounceIntvalSet.h"
#include "AnnounceIntvalSet_1AS.h"


VOID (*const AnuncIntvalSetSM_1AS_Matrix[DANUNCI_STATUS_MAX][DANUNCI_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_NP_1AS},
	{&AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_02_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_00_1AS},
	{&AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_02_1AS, &AnuncIntvalSetSM_03_1AS, &AnuncIntvalSetSM_00_1AS},
	{&AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_01_1AS, &AnuncIntvalSetSM_NP_1AS, &AnuncIntvalSetSM_03_1AS, &AnuncIntvalSetSM_00_1AS}
};

VOID AnuncIntvalSetSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	ANUNCINTVSET_EV	enEvt = ANUNCI_E_EVENT_MAX;
	ANUNCINTVSET_ST	enSts = ANUNCI_STATUS_MAX;
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET_1AS, PTP_LOGVE_82080001);
	enEvt = GetAnuncIntvSetEvent(usEvent, pstPort);

	enSts = GetAnuncIntvSetStatus(pstPort);

	if ((enSts != ANUNCI_STATUS_MAX) && (enEvt != ANUNCI_E_EVENT_MAX))
	{
		(*AnuncIntvalSetSM_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET_1AS, PTP_LOGVE_82000006);
	}
	return;
}

VOID AnuncIntvalSetSM_00_1AS(PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "AnuncIntvalSetSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetAnuncIntvSetGlobal(pstPort);

	AnuncIntSet_NotEnabled_1AS(pstGbl, pstPort);
	SetAnuncIntvSetStatus(ANUNCI_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("AnuncIntvalSetSM_00_1AS::-\n") );

	return;
}

VOID AnuncIntvalSetSM_01_1AS(PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;
	BOOL			blRet;
	pstGbl = GetAnuncIntvSetGlobal(pstPort);

	blRet = AnuncIntSet_NotEnabled_1AS(pstGbl, pstPort);
	if (blRet)
	{
		SetAnuncIntvSetStatus(ANUNCI_NOT_ENABLED, pstPort);
	}
	else
	{
		AnuncIntSet_Initialize_1AS(pstGbl, pstPort);
		SetAnuncIntvSetStatus(ANUNCI_INITIALIZE, pstPort);
	}
	return;
}

VOID AnuncIntvalSetSM_02_1AS(PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;

	pstGbl = GetAnuncIntvSetGlobal(pstPort);

	AnuncIntSet_Initialize_1AS(pstGbl, pstPort);
	SetAnuncIntvSetStatus(ANUNCI_INITIALIZE, pstPort);
	return;
}

VOID AnuncIntvalSetSM_03_1AS(PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;

	pstGbl = GetAnuncIntvSetGlobal(pstPort);

	if (pstGbl->blRcvdSignalingMsg2 == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET_1AS, PTP_LOGVE_82000009);
		AnuncIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetAnuncIntvSetStatus(ANUNCI_NOT_ENABLED, pstPort);
		return;
	}
	if (pstGbl->pstRcvdSignaling == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET_1AS, PTP_LOGVE_8200000A);
		AnuncIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetAnuncIntvSetStatus(ANUNCI_NOT_ENABLED, pstPort);
		return;
	}

	AnuncIntSet_SetInterval_1AS(pstGbl, pstPort);
	SetAnuncIntvSetStatus(ANUNCI_SET_INTERVALS, pstPort);
	return;
}

VOID AnuncIntvalSetSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET_1AS, PTP_LOGVE_82000007);
	return;
}


BOOL AnuncIntSet_NotEnabled_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS* pstPortDS = &pstPort->stPort_1AS_DS;
	if (pstPortDS->blUseMgtSetLogAnnounceInterval)
	{
		pstPortDS->chCurrentLogAnnounceInterval
			= pstPortDS->chMgtSettableLogAnnounceInterval;
		computeAnuncInterval_1AS(pstPort);
	}

	pstSmGbl->blRcvdSignalingMsg2 = FALSE;

	return pstPortDS->blUseMgtSetLogAnnounceInterval;
}

VOID AnuncIntSet_Initialize_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORTBMC_GD*		pstPortBMC	= &pstPort->stPortBMC_GD;

	if (pstPortDS->blUseMgtSetLogAnnounceInterval == FALSE)
	{
		pstPortDS->chCurrentLogAnnounceInterval
			= pstPortDS->chInitialLogAnnounceInterval;

		computeAnuncInterval_1AS(pstPort);
	}

	pstSmGbl->blRcvdSignalingMsg2 = FALSE;
	tsn_Wrapper_MemCpy(&pstPortBMC->stOldAnnounceInterval,
		&pstPortBMC->stAnnounceInterval, sizeof(pstPortBMC->stOldAnnounceInterval));
	pstPortBMC->blAnnounceSlowdown = FALSE;

	return;
}

VOID AnuncIntSet_SetInterval_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CHAR timeAnnounceInterval =
		pstSmGbl->pstRcvdSignaling->stSignaling_1AS.stIntervalReq_TLV.chAnnounceInterval;
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORTBMC_GD*		pstPortBMC	= &pstPort->stPortBMC_GD;

	switch(timeAnnounceInterval)
	{
	case PTPM_TLV_ANNOUNCE_INTVAL_NCHG:
		break;
	case PTPM_TLV_ANNOUNCE_INTVAL_INIT:
		pstPortDS->chCurrentLogAnnounceInterval
			= pstPortDS->chInitialLogAnnounceInterval;

		computeAnuncInterval_1AS(pstPort);
		break;
	default:
		pstPortDS->chCurrentLogAnnounceInterval = timeAnnounceInterval;

		computeAnuncInterval_1AS(pstPort);
		break;
	}

	pstSmGbl->blRcvdSignalingMsg2 = FALSE;

	if (ptpCompUSNs_USNs(&pstPortBMC->stAnnounceInterval, &pstPortBMC->stOldAnnounceInterval) == COMP_A_LESS)
	{
		pstPortBMC->blAnnounceSlowdown = TRUE;
	}
	else
	{
		pstPortBMC->blAnnounceSlowdown = FALSE;
	}
	return;
}
VOID computeAnuncInterval_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORTBMC_GD*		pstPortBMC	= &pstPort->stPortBMC_GD;
	USCALEDNS		stA_USNs= {0};

	stA_USNs.ulNsec_lsb = CONST10_9;
	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstPortDS->chCurrentLogAnnounceInterval,
		&pstPortBMC->stAnnounceInterval);
	return;
}

#endif
#endif
