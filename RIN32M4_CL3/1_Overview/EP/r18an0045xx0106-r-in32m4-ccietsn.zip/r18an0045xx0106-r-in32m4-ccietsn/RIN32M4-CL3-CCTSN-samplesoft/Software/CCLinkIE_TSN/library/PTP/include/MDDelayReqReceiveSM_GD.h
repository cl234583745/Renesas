/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYREQRECEIVESM_GD_H__
#define __MDDELAYREQRECEIVESM_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagMDDREQRCVSM_ST {
	MDDRQR_NONE = 0,
	MDDRQR_NOT_ENABLED,
	MDDRQR_WAITING_FOR_DELAY_REQ,
	MDDRQR_STATUS_MAX

}	MDDREQRCVSM_ST;
#define	DMDDRQR_STATUS_MAX			3

typedef enum tagMDDREQRCVSM_EV {
	MDDRQR_E_BEGIN = 0,
	MDDRQR_E_RCVD_DELAY_REQ,
	MDDRQR_E_CLOSE,
	MDDRQR_E_EVENT_MAX

}	MDDREQRCVSM_EV;
#define	DMDDRQR_E_EVENT_MAX			3

typedef struct tagMDDREQRVSM_GD
{
	MDDREQRCVSM_ST		enStsMDDReqRcv;
	
	BOOL				blRcvdDelayReq;
	PTPMSG*				pstRcvdDelayReq;
	TIMESTAMP			stIngMDTimestampReceive;
#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stIngMDTimestampReceive_Frun;
#endif

} MDDREQRVSM_GD;

#endif
