/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTPWRAP_PROTO_H__
#define __PTPWRAP_PROTO_H__

#ifdef __cplusplus
extern "C" {
#endif


INT	layer2_open(USHORT		usMaxPort,
				MACADDR *	pstMacAddr);

INT	layer2_close(VOID);

INT	layer4V4_open(USHORT	   usMaxPort,
				  ULONG		   ulNetMask,
				  IPV4ADDR *   pstIpv4Addr);

INT	layer4V4_close(VOID);


INT	layer4V6_open(USHORT	   usMaxPort,
				  ULONG		   ulPrefixLen,
				  IPV6ADDR *   pstIpv6Addr);

INT	layer4V6_close(VOID);

INT	ptp_send(UCHAR			uchPort,
			 UCHAR			uchTraClsNo,
			 UCHAR *		puchMsgPtr,
			 USHORT			usMsgLen,
			 SENDTIMESCB	stSendCBFunc,
			 VOID *			pvLinkId);

VOID ptp_recv(UCHAR					uchPort,
			  UCHAR *				puchMsgPtr,
			  USHORT				usMsgLen,
			  EXTENDEDTIMESTAMP *	pstTimeStamp);


#ifdef __cplusplus
}
#endif

#endif
