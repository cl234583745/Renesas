/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_USERADJUST_H__
#define __PTP_USERADJUST_H__
#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_api.h"

#include "ptp_Struct.h"


#ifdef __cplusplus
extern "C" {
#endif

#ifdef	PTP_USERADJUST_EXTEND

VOID	ptp_useradjust2( UCHAR      	uchDomainNumber,
                         SCALEDNS*  	pstOffset, 
						 DOUBLE*    	pdbFreqRate, 
						 UCHAR      	uchPriDomainNumber,
						 PARENT_DS*		pstParentDS,
						 CURRENT_DS*	pstCurrentDS,
						 DELAYINFO* 	pstDelyInfo, 
						 USCALEDNS* 	pstNeighborPropDelay,
						 ULONG	    	ulPropDelayNumber );

#else

VOID	ptp_useradjust( UCHAR      	uchDomainNumber,
						SCALEDNS*	pstOffset, 
						DOUBLE*		pdbFreqRate,
						UCHAR      	uchPriDomainNumber );

#endif

#ifdef __cplusplus
}
#endif


#endif


