/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDPdelayReq.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDPdelayReq_1AS.h"
#endif
#ifdef	PTP_USE_IEEE1588
#include "MDPdelayReq_1588.h"
#endif

#define	D_FUNC		0
#define D_DBG		0

VOID MDPdelayReq(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		MDPdelayReq_1AS(usEvent, pstPort);
		return;
	}
#endif
#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDPdelayReq_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000002);
	return;
}

MDPREQSM_GD* GetMDPdelayReqGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDPReqSM_GD;
}

MDPDELAYREQ_EV GetMDPdelayReqEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYREQ_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDPDRQ_E_BEGIN;
		break;
		case PTP_EV_RCVDPDELAYRESP:
			enEvt = MDPDRQ_E_RCVD_PDRESP;
		break;
		case PTP_EV_RCVDPDELAYRESPFOLLOWUP:
			enEvt = MDPDRQ_E_RCVD_PDRESP_FOLLOWUP;
		break;
		case PTP_EV_RCVDMDTIMESTAMPRECEIVE:
			enEvt = MDPDRQ_E_RCVD_MDTIMESTAMP_RCV;
		break;
		case PTP_EV_PDELAY_SENDTIME:
			enEvt = MDPDRQ_E_PDELAY_SENDTIME;
			MDPdelayTimeClear(pstPort);
		break;
		case PTP_EV_CLOSE:
			enEvt = MDPDRQ_E_CLOSE;
		break;

		default:
			enEvt = MDPDRQ_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDPDELAYREQ_ST GetMDPdelayReqStatus(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;
	MDPDELAYREQ_ST	enSts = MDPDRQ_STATUS_MAX;

	pstGbl = GetMDPdelayReqGlobal(pstPort);
	if (pstGbl->enStsMDPdelayReq < MDPDRQ_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDPdelayReq;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDPdelayReqStatus(MDPDELAYREQ_ST enSts, PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);

	pstGbl->enStsMDPdelayReq = enSts;
	return;
}


VOID IncMDPDlyReqRxPDlyRespCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulRxPdelayResponseCount++;
	}
	return;
}

VOID IncMDPDlyReqRxPDRpFollowUpCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulRxPdelayResponseFollowUpCount++;
	}
	return;
}

VOID IncMDPDlyReqRxPTPPcktDscrdCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulRxPTPPacketDiscardCount++;
	}
	return;
}

VOID IncMDPDlyReqTxPDlyReqCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulTxPdelayRequestCount++;
	}
	return;
}

VOID IncMDPDlyReqLostRespExcdCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs )
{
	if( pstCmldsPortStatDs != NULL )
	{
		pstCmldsPortStatDs->ulPdelayAllwLostRespExcdCount++;
	}
	return;
}

BOOL MDPdelayTimeStart(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	USCALEDNS	stCurrentTime;

#ifdef	PTP_USE_IEEE1588
	PORT_1588_DS* pstPort1588DS 	= &pstPort->stPort_1588_DS;
	PORTMD_GD*			pstPortMD		= &pstPort->stPortMD_GD;
	USCALEDNS			stA_USNs	= {0};
#endif
	if (pstSmGbl->pstTimeOutManage != NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000022);
		return FALSE;
	}


	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		ptpAddUSNs_USNs( &stCurrentTime, &pstPort->stPortMD_GD.stPdelayReqInterval, &pstSmGbl->stPdelayIntervalTimer);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE1588
		stA_USNs.ulNsec_lsb = CONST10_9;
		ptpShiftUSNs_CHAR(
			&stA_USNs,
			pstPort1588DS->chLogMinPdelayReqInterval,
			&pstPortMD->stPdelayReqInterval);
		ptpAddUSNs_USNs( &stCurrentTime, &pstPort->stPortMD_GD.stPdelayReqInterval, &pstSmGbl->stPdelayIntervalTimer);
#endif
	}
	pstSmGbl->pstTimeOutManage = ptp_TimeOut_Req(
							PTP_EV_PDELAY_SENDTIME,
							(VOID*)pstPort,
							pstSmGbl->stPdelayIntervalTimer,
							(CallBackFunc)&MDPdelayReq);
	if (pstSmGbl->pstTimeOutManage == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000021);
		return FALSE;
	}
	return TRUE;
}

BOOL MDPdelayTimeStop( MDPREQSM_GD*      pstSmGbl, 
					   PORTDATA*         pstPort,
					   CMLDSPORT_1AS_DS* pstCmldsPortDs )
{
	USHORT	usTimeRet = (USHORT)RET_ENOERR;

	ptp_dbg_msg( D_FUNC, ("MDPdelayTimeStop::+\n") );

	ptp_dbg_msg( D_DBG,  ("blCmldsPortEnabled = [%d] blPdelayExecFlag = [%d] Timer = [%08x]\n"
		,pstCmldsPortDs->blCmldsPortEnabled ,pstPort->stPort_GD.blPdelayExecFlag ,(ULONG)pstSmGbl->pstTimeOutManage
	) );

	if ( ( pstCmldsPortDs->blCmldsPortEnabled == TRUE ) && ( pstPort->stPort_GD.blPdelayExecFlag == TRUE) )
	{

		if (pstSmGbl->pstTimeOutManage == NULL)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000024);
			return TRUE;
		}

		ptp_dbg_msg( D_DBG, ("[ptp_TimeOut_Can Call(%08x)]\n",(ULONG)pstSmGbl->pstTimeOutManage) );

		usTimeRet = ptp_TimeOut_Can(pstSmGbl->pstTimeOutManage);
		if (usTimeRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000023);
			return FALSE;
		}
		pstSmGbl->pstTimeOutManage = NULL;

	}

	ptp_dbg_msg( D_FUNC, ("MDPdelayTimeStop::-\n") );

	return TRUE;
}

VOID MDPdelayTimeClear(PORTDATA* pstPort)
{
	MDPREQSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayReqGlobal(pstPort);
	if (pstGbl->pstTimeOutManage == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYREQ, PTP_LOGVE_82000024);
	}
	pstGbl->pstTimeOutManage = NULL;
	return;
}

BOOL SetMDPdlyReqEvEgresTimestamp(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stEgMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstPortMD->stPdlyReqEventEgressTimestamp,
			&pstSmGbl->stEgMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortMD->stPdlyReqEventEgressTimestamp, 0L, sizeof(TIMESTAMP));
	}
	return blRet;
}

BOOL SetMDPdlyRespEvIngresTimestamp(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORTMD_GD* pstPortMD = &pstPort->stPortMD_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstPortMD->stPdlyRespEventIngressTimestamp,
			&pstSmGbl->stIngMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortMD->stPdlyRespEventIngressTimestamp, 0L, sizeof(TIMESTAMP));
	}
	return blRet;
}
VOID SetMDPdelayTimestampInfo(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD*	pstPortGD = &pstPort->stPort_GD;
	PORTMD_GD*	pstPortMD = &pstPort->stPortMD_GD;

	pstPortGD->stPdlyReqSendtime =
		pstPortMD->stPdlyReqEventEgressTimestamp;

	pstPortGD->stPdlyRespReceiveTime =
		pstPortMD->stPdlyRespEventIngressTimestamp;


	pstPortGD->stPdlyRespReqRecpTimeStamp =
		pstPortMD->stPdlyReqMsgIngressTimestamp;
	pstPortGD->stPdlyRespCorrectionField =
		pstPortMD->stPdlyReqMsgIngressCorrection;

	pstPortGD->stPdlyRespFupReqRecpTimeStamp =
		pstPortMD->stPdlyRespMsgEgressTimestamp;

	pstPortGD->stPdlyRespFupCorrectionField =
		pstPortMD->stPdlyRespMsgEgressCorrection;
	return;
}
