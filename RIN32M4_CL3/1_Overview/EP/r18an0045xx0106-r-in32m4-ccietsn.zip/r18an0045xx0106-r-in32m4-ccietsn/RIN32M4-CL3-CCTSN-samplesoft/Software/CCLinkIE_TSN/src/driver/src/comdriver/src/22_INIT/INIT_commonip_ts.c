/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"



NX_VOID vINIT_commonip_ts ( NX_VOID )
{
	NX_ULONGLONG	ullCurTime				=	0;
	NX_ULONGLONG	ullComCyc				=	0;
	NX_ULONGLONG	ullComCycNum			=	0;
	NX_ULONGLONG	ullCurComCycMulTime		=	0;
	NX_USHORT		usTsLoopCnt				=	0;


	for (usTsLoopCnt = NX_ZERO; usTsLoopCnt < NGN_ASIC_TSMAX; usTsLoopCnt++) {
		NGN_CN_TS_P1_REG->R_TCPXSOnN[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;
		NGN_CN_TS_P1_REG->R_TCPXSOnS[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;

		NGN_CN_TS_P1_REG->R_TCPXEOnN[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;
		NGN_CN_TS_P1_REG->R_TCPXEOnS[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;

		NGN_CN_TS_P1_REG->R_TCPXRCnN[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;
		NGN_CN_TS_P1_REG->R_TCPXRCnS[usTsLoopCnt].DATA	=	(NX_ULONG)0x00000000;
	}





	NGN_CN_TS_P1_REG->R_TCPXMSEL.DATA		=	(NX_ULONG)0x00000000;

	NGN_CN_TS_P1_REG->R_TCPXTXON.DATA		=	(NX_ULONG)8;
	NGN_CN_TS_P1_REG->R_TCPXTXOS.DATA		=	(NX_ULONG)0x00000000;


	NGN_CN_TS_P1_REG->R_TCPXINTM.DATA		=	(NX_ULONG)0x00FFFFFF;
	NGN_CN_TS_P1_REG->R_TCPXINT.DATA		=	(NX_ULONG)0x00FFFFFF;

	NGN_CN_TS_P1_REG->R_TCPXSSH0			=	(NX_ULONG)0x00000000;
	NGN_CN_TS_P1_REG->R_TCPXSSH1			=	(NX_ULONG)0x00000000;

	NGN_CN_TS_P1_REG->R_TCPXMAGN.DATA		=	(NX_ULONG)0x00000000;

	NGN_CN_TS_P1_REG->R_TCPXCNEN.DATA		=	(NX_ULONG)0x00000000;


	NGN_CN_TS_P1_REG->R_TCPXSST0			=	(NX_ULONG)0x00000000;
	NGN_CN_TS_P1_REG->R_TCPXSST1			=	(NX_ULONG)0x00000000;

	NGN_CN_TS_P2_REG->R_TCP2ON.DATA			=	(NX_ULONG)0x00000000;



	return;
}
/*[EOF]*/
