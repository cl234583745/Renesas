/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#if defined DEBUG_RCV_MDTR || defined DEBUG_SND_MDTR
#include <stdio.h>
#endif
#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Proto.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"
#include "ptp_MemManage.h"
#include "ptp_LCEntity.h"

#include "mdtransinterface.h"
#ifdef DEBUG_LOG_MDTR
#include "mdtransinterfaceDisp.h"
#endif

#include "PTP_GlobalData.h"
#include "MDSyncSendSM.h"

#include "mdtransinterface_msg.h"

#ifdef	OFFSET_DEBUG
void	setFrameEgTimeStamp(TIMESTAMP* pstTimestamp, USHORT usPort, UCHAR uchFrType);

#define	MAX_PTPTIMESTAMPLOG	50

typedef	struct	tagTIMESTAMPLOG	{
	USHORT				usType;
	UCHAR				uchFlameType;
	UCHAR				uchDomainNumber;
	USHORT				usSequenceId;
	USHORT				usPortNumber;
	EXTENDEDTIMESTAMP	stTimestamp;
	EXTENDEDTIMESTAMP	stTimestamp_Frun;
}	PTPTIMESTAMPLOG;

PTPTIMESTAMPLOG	stPtpTimestamplog[MAX_PTPTIMESTAMPLOG];

USHORT	usPtpDebugTimestampLogCount = 0;
#endif

ULONG   ulMdtrMsgBuff[(sizeof(PTPMSG)+sizeof(ULONG)-1)/sizeof(ULONG)];




#ifdef	PTP_USE_IEEE802_1
static VOID ptp_recv_8021AS( PORTDATA*          pstPort, 
							 UCHAR*             puchMsgPtr, 
							 USHORT             usMsgLen, 
							 EXTENDEDTIMESTAMP* pstMTimeStamp, 
							 PTPMSG*            pstPtpmsg );
#endif

#ifdef	PTP_USE_IEEE1588
static VOID ptp_recv_1588( PORTDATA*          pstPort, 
						   UCHAR*             puchMsgPtr, 
						   USHORT             usMsgLen, 
						   EXTENDEDTIMESTAMP* pstMTimeStamp, 
						   PTPMSG*            pstPtpmsg );
#endif



#ifdef	PTP_USE_IEEE802_1

static VOID ptp_recv_8021AS( PORTDATA*          pstPort, 
							 UCHAR*             puchMsgPtr, 
							 USHORT             usMsgLen, 
							 EXTENDEDTIMESTAMP* pstMTimeStamp, 
							 PTPMSG*            pstPtpmsg )
{
	BOOL blRet;

	USCALEDNS	stLTimeStamp={0};
#ifndef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP		stTimeStamp = {0};
#else
	TIMESTAMP		stTimeStamp[2] = {0};
#endif
	USCALEDNS		stCurrentTime;


	blRet = ptp_Mdl_HeaderCheck_8021AS( &pstPtpmsg->stHeader );
	if ( blRet != TRUE )
	{
		return;
	}


	switch( MPTPMSG_H_GET_MSG_TYPE(&pstPtpmsg->stHeader) )
	{
	case PTPM_MSGTYPE_SYNC:
		blRet = ptp_Mdl_ntohMsgSyncAS( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD( pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D );
			return;
		}
		ptp_Mdl_recv_Sync_AS(pstPort, puchMsgPtr, usMsgLen, pstMTimeStamp);
		break;

	case PTPM_MSGTYPE_DELAY_REQ:
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000001);
		}
		break;

	case PTPM_MSGTYPE_PDELAY_REQ:
		blRet = ptp_Mdl_ntohMsgPDlyReqAS( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp );
		ptp_Mdl_recv_Pdelay_Req_AS( pstPort, 
								    puchMsgPtr, 
								    usMsgLen, 
								    &stTimeStamp );
#else
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp[0] );

		ptp_Mdl_recv_Pdelay_Req_AS( pstPort, 
									puchMsgPtr, 
									usMsgLen, 
									&stTimeStamp[0] );
#endif
		break;
	
	case PTPM_MSGTYPE_PDELAY_RESP:
		blRet = ptp_Mdl_ntohMsgPDlyRespAS( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
								      pstMTimeStamp, 
								      &stLTimeStamp, 
								      &stTimeStamp );
		ptp_Mdl_recv_Pdelay_Resp_AS( pstPort, 
									puchMsgPtr, 
									usMsgLen, 
									&stTimeStamp );

#else
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp[0] );
		ptp_Mdl_recv_Pdelay_Resp_AS( pstPort, 
									 puchMsgPtr, 
									 usMsgLen, 
									 &stTimeStamp[0] );
#endif
		break;

	case PTPM_MSGTYPE_FOLLOWUP:
		if ( usMsgLen < PTPMSG_AS_FLLWUP_SZ )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}

		blRet = ptp_Mdl_ntohMsgFollowUpAS( puchMsgPtr, pstPtpmsg );
		if (  blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_FollowUp_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_FollowUp_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
	
	case PTPM_MSGTYPE_DELAY_RESP:
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000001);
		}
		break;
	
	case PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP:
		
		blRet = ptp_Mdl_ntohMsgPDlyRespFllwUpAS( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Pdly_Rsp_Fup_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Pdly_Rsp_Fup_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;

	case PTPM_MSGTYPE_ANNOUNCE:
		ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

		if ( usMsgLen < PTPMSG_ANUNC_SZ )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return ;
		}
		blRet = ptp_Mdl_ntohMsgAnnounceAS( puchMsgPtr, pstPtpmsg, usMsgLen );
		if (  blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return ;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Announce_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Announce_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
		
	case PTPM_MSGTYPE_SIGNALING:
		
		blRet = ptp_Mdl_ntohMsgSignalAS( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return ;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Signal_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Signal_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;

#ifdef	PTP_USE_MANAGEMENT
	case	PTPM_MSGTYPE_MANAGEMENT:
#ifndef	PTP_USE_ME_HW_ASSIST
			ptp_Mdl_recv_Manage_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
			ptp_Mdl_recv_Manage_AS(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
#endif

	default:
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000002);
		break;
	}

	return ;
}
#endif

#ifdef	PTP_USE_IEEE1588

static VOID ptp_recv_1588( PORTDATA*          pstPort, 
						   UCHAR*             puchMsgPtr, 
						   USHORT             usMsgLen, 
						   EXTENDEDTIMESTAMP* pstMTimeStamp, 
						   PTPMSG*            pstPtpmsg )
{
	BOOL blRet;

	USCALEDNS	stLTimeStamp={0};

#ifndef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP		stTimeStamp = {0};
#else
	TIMESTAMP		stTimeStamp[2] = {0};
#endif
	USCALEDNS		stCurrentTime;

	blRet = ptp_Mdl_HeaderCheck_1588( &pstPtpmsg->stHeader );
	if ( blRet != TRUE )
	{
		return;
	}

	switch( MPTPMSG_H_GET_MSG_TYPE(&pstPtpmsg->stHeader) )
	{
		
	case PTPM_MSGTYPE_SYNC:
		
		blRet = ptp_Mdl_ntohMsgSync( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
		ptp_Mdl_recv_Sync_1588( pstPort, puchMsgPtr, usMsgLen, pstMTimeStamp );
		break;

	case PTPM_MSGTYPE_DELAY_REQ:
		
		if ( pstPtpmsg->stHeader.chLogMsgInterVal != PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return;
		}
		blRet = ptp_Mdl_ntohMsgDlyReq( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
		ptp_Mdl_recv_Delay_Req_1588( pstPort, puchMsgPtr, usMsgLen, pstMTimeStamp );
		break;

	case PTPM_MSGTYPE_PDELAY_REQ:

		if ( pstPtpmsg->stHeader.chLogMsgInterVal != PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return;
		}
		blRet = ptp_Mdl_ntohMsgPDlyReq( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp );
		ptp_Mdl_recv_Pdelay_Req_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp[0] );
		ptp_Mdl_recv_Pdelay_Req_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
	
	case PTPM_MSGTYPE_PDELAY_RESP:
		if ( pstPtpmsg->stHeader.chLogMsgInterVal != 	PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return;
		}
		blRet = ptp_Mdl_ntohMsgPDlyResp( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp );
		ptp_Mdl_recv_Pdelay_Resp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		(VOID)ptp_Mdl_recv_Timestamp( PTPMDL_RCVTIMESTAMPTYPE_MASTER,
									  pstMTimeStamp, 
									  &stLTimeStamp, 
									  &stTimeStamp[0] );
		ptp_Mdl_recv_Pdelay_Resp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
	
	case PTPM_MSGTYPE_FOLLOWUP:
	
		blRet = ptp_Mdl_ntohMsgFollowUp( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}

#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_FollowUp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_FollowUp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
	
	case PTPM_MSGTYPE_DELAY_RESP:
		blRet = ptp_Mdl_ntohMsgDlyResp( puchMsgPtr, pstPtpmsg );
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Delay_Resp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Delay_Resp_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
	
	case PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP:
		if ( pstPtpmsg->stHeader.chLogMsgInterVal != PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return ;
		}
		blRet = ptp_Mdl_ntohMsgPDlyRespFllwUp(puchMsgPtr, pstPtpmsg);
		if ( blRet == FALSE )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
			return ;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Pdly_Rsp_Fup_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Pdly_Rsp_Fup_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;

	case PTPM_MSGTYPE_ANNOUNCE:
		ptp_GetCurrentTime( pstPort->pstClockData, &stCurrentTime );

		ptp_Mdl_ntohMsgAnnounce( puchMsgPtr, pstPtpmsg );

		blRet = ptpConvUSNs_TS( &stCurrentTime, &pstPtpmsg->stAnnounce.stOriginTimestamp );
		if (!blRet)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PARECEIVESM, (ULONG)PTP_LOGVE_OVERFLOW);
			return ;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Announce_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Announce_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
#ifdef	PTP_USE_SIGNALING
	case PTPM_MSGTYPE_SIGNALING:

		if ( pstPtpmsg->stHeader.chLogMsgInterVal != PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return ;
		}

#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Signal_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Signal_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
#endif

#ifdef	PTP_USE_MANAGEMENT
	case PTPM_MSGTYPE_MANAGEMENT:

		if ( pstPtpmsg->stHeader.chLogMsgInterVal != 	PTPM_LOGMSGINTERVAL_0x7F )
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000024);
			return ;
		}
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_Mdl_recv_Manage_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp);
#else
		ptp_Mdl_recv_Manage_1588(pstPort, puchMsgPtr, usMsgLen, &stTimeStamp[0]);
#endif
		break;
#endif
	default:
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000002);
		break;
	}

	return ;
}
#endif

VOID ptp_recv( UCHAR uchPort, UCHAR* puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP* pstMTimeStamp )
{

	PTPMSG*			pstPtpmsg;
	BOOL blRet;
	CLOCK_GD*		pstClockGd;

	PORTDATA*		pstPort;
	CLOCKDATA*		pstClockData	= gpstClockDataHPtr;
	USHORT			usLoopCnt;
	LONG			lRet			= RET_ESTATE;

	PORTDATA*		pstPortW;
	BOOL			blPortValid		= FALSE;


	if ( gpstClockDataHPtr == NULL )
	{
		return;
	}
	if( gblStartUpOpen != TRUE )
	{
		return;
	}

	pstClockGd = &gpstClockDataHPtr->stClock_GD;

	pstPort = gpstClockDataHPtr->pstPortData;

	for (usLoopCnt = 0U; ((usLoopCnt < MAX_PORT) && (pstPort != NULL)) ; usLoopCnt++)
	{
		if ( ((USHORT)uchPort + 1U) == pstPort->stPortDS.stPortIdentity.usPortNumber)
		{
			break;
		}
		pstPort = pstPort->pstNextPortDataPtr;
	}

	if (pstPort == NULL)
	{
		return;
	}

	lRet = ptp_SystemSemLockWait(pstClockData);
	if ( lRet != RET_ENOERR )
	{
		return;
	}

	pstPtpmsg = (PTPMSG *)ulMdtrMsgBuff;

	if ( usMsgLen < PTPMSG_HEAD_SZ )
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
		(VOID)ptp_SystemSemUnLock(pstClockData);
		return;
	}
	
	blRet = ptp_Mdl_ntohMsgHeader( puchMsgPtr, &pstPtpmsg->stHeader );
	if ( blRet == FALSE )
	{
		(VOID)ptp_SystemSemUnLock(pstClockData);

		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
		return;
	}

	if ( pstPtpmsg->stHeader.usMegLength > usMsgLen )
	{
		(VOID)ptp_SystemSemUnLock(pstClockData);
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001D);
		return;
	}

#ifdef	OFFSET_DEBUG
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].usType       	= 1;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].uchFlameType		= pstPtpmsg->stHeader.byMjSdoIdAndMsgTyp;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].usSequenceId 	= pstPtpmsg->stHeader.usSequenceId;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].uchDomainNumber	= pstPtpmsg->stHeader.uchDomainNumber;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].usPortNumber		= ((USHORT)uchPort + 1U);
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].stTimestamp		= *pstMTimeStamp;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].stTimestamp_Frun = *(pstMTimeStamp+1);
	usPtpDebugTimestampLogCount++;
#endif

	while ( pstClockData != NULL )
	{
		if (pstClockData->stDefaultDS.uchDomainNumber == pstPtpmsg->stHeader.uchDomainNumber)
		{
			pstPortW = pstClockData->pstPortData;

			while ( pstPortW != NULL )
			{
				if ( pstPortW->stPortDS.stPortIdentity.usPortNumber == ((USHORT)uchPort + 1U) )
				{
					if (pstPortW->stPort_GD.blPortValid == TRUE)
					{
						blPortValid = TRUE;
					}
					else
					{
						if (pstPtpmsg->stHeader.uchDomainNumber == (UCHAR)0)
						{
							if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
							{
								switch (MPTPMSG_H_GET_MSG_TYPE(&pstPtpmsg->stHeader))
								{
									case	PTPM_MSGTYPE_PDELAY_REQ:
									case	PTPM_MSGTYPE_PDELAY_RESP:
									case	PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP:
										blPortValid = TRUE;
										break;
									default:
										break;
								}
							}
						}
					}
					if ( blPortValid == TRUE )
					{
						break;
					}
				}
				pstPortW = pstPortW->pstNextPortDataPtr;
			}
			break;
		}
		pstClockData = pstClockData->pstNextClockDataPtr;
	}

	if (blPortValid != TRUE)
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000025);
		(VOID)ptp_SystemSemUnLock(pstClockData);
		return;
	}

	pstPort = pstPortW;

	lRet = tsn_Wrapper_MemCmp( (VOID *)&pstPtpmsg->stHeader.stSrcPortIdentity.stClockIdentity, 
							   (VOID *)&pstPort->stPortDS.stPortIdentity.stClockIdentity, 
							   sizeof(CLOCKIDENTITY) );
	if ( lRet == 0 )
	{
		if ( pstPtpmsg->stHeader.stSrcPortIdentity.usPortNumber == pstPort->stPortDS.stPortIdentity.usPortNumber )
		{
			(VOID)ptp_SystemSemUnLock(pstClockData);
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_8500001B);
			return;
		}
	}

#ifdef	DEBUG_RCV_MDTR
	{
		printf("ptp_recv(% 6d) [PortNo:%02x]PTPM_MSGTYPE[%02x]: SState = [%d] [%d] [%d]\n",
								pstPtpmsg->stHeader.usSequenceId,
								(uchPort+1),
								pstPtpmsg->stHeader.stMjSdoIdAndMsgTyp.byMsgType,
								pstClockGd->enSelectedState[0],
								pstClockGd->enSelectedState[1],
								pstClockGd->enSelectedState[2]);
	}
#endif


	switch( pstClockGd->enSupportPTPType )
	{
#ifdef	PTP_USE_IEEE802_1
		case ENUM_SUPPORTPTPTYPE_IEEE802_1AS:
			ptp_recv_8021AS( pstPort, puchMsgPtr, usMsgLen, pstMTimeStamp, pstPtpmsg );
			break;
#endif

#ifdef	PTP_USE_IEEE1588
		case ENUM_SUPPORTPTPTYPE_IEEE1588:
			ptp_recv_1588( pstPort, puchMsgPtr, usMsgLen, pstMTimeStamp, pstPtpmsg );
			break;
#endif

		default:
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_PTPRECV, PTP_LOGVE_85000001);
			break;
	}

	ptp_chkCurrentTimeTimeout( pstClockData );

	(VOID)ptp_SystemSemUnLock( pstClockData );

	return ;
}


BOOL ptp_Mdl_recv_Timestamp(UCHAR uchType, EXTENDEDTIMESTAMP* pstExtTimeStamp, USCALEDNS* pstLclTimeStamp, TIMESTAMP* pstTimeStamp)
{
	BOOL	blRet = FALSE;
	BOOL	blConvRet = FALSE;
	TIMESTAMP	stTimeStamp;

	if (gpstClockDataHPtr == NULL)
	{
		return FALSE;
	}

	if (uchType == PTPMDL_RCVTIMESTAMPTYPE_MASTER)
	{
		blConvRet = ptpConvETS_TS(pstExtTimeStamp, &stTimeStamp);
	}
	else if (uchType == PTPMDL_RCVTIMESTAMPTYPE_LOCAL)
	{
		blConvRet = ptpConvUSNs_TS(pstLclTimeStamp, &stTimeStamp);
	}
	else
	{
	}
	if (blConvRet)
	{
		tsn_Wrapper_MemCpy(pstTimeStamp, &stTimeStamp, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	return blRet;
}
INT	MD_ptp_send(UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP_CALLBK_INF *pstTimeStampCallbackInf)
{
	CLOCK_GD*		pstClockGd		= &pstTimeStampCallbackInf->pstPortData->pstClockData->stClock_GD;

	PTPMSG_HEADER	*pstPtpMsgHdr;
	PTPMSG			*pstPtpMsg;

	VOID 			*pvLinkId = NULL;
	SENDTIMESCB		pstSendTimesCB = NULL;

	INT				nRet;

	UCHAR*			chMsgPtr = (UCHAR *)ulMdtrMsgBuff;

	USHORT			usPortNumber;

	usPortNumber = pstTimeStampCallbackInf->pstPortData->stPortDS.stPortIdentity.usPortNumber;

	usPortNumber = usPortNumber - 1;

	pstPtpMsgHdr = (PTPMSG_HEADER *)puchMsgPtr;
	pstPtpMsg	 = (PTPMSG *)puchMsgPtr;

#ifdef DEBUG_LOG_MDTR
	Disp_MessageField(puchMsgPtr);
#endif
#ifdef	DEBUG_SND_MDTR
	{
		printf("ptp_send(% 6d) [PortNo:%02x]PTPM_MSGTYPE[%02x]: SState = [%d] [%d] [%d]\n",
				pstPtpMsgHdr->usSequenceId,
				(usPortNumber+1),
				pstPtpMsgHdr->stMjSdoIdAndMsgTyp.byMsgType,
				pstClockGd->enSelectedState[0],
				pstClockGd->enSelectedState[1],
				pstClockGd->enSelectedState[2]);
	}
#endif
	switch( MPTPMSG_H_GET_MSG_TYPE(pstPtpMsgHdr) )
	{
		case	PTPM_MSGTYPE_SYNC:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgSync(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_MASTER;
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgSyncAS(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_LOCAL;
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
				break;
			}

			(VOID)tsn_Wrapper_MemCpy (&pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_SYNC,
				pstTimeStampCallbackInf, sizeof(TIMESTAMP_CALLBK_INF));
			pvLinkId = &pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_SYNC;
			pstSendTimesCB = &MD_ptp_TimeStamp_CallBack;
			break;
		case	PTPM_MSGTYPE_DELAY_REQ:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgDlyReq(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_MASTER;
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
				break;
			}
			(VOID)tsn_Wrapper_MemCpy (&pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_DREQ,
																		pstTimeStampCallbackInf, sizeof(TIMESTAMP_CALLBK_INF));
			pvLinkId = &pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_DREQ;
			pstSendTimesCB = &MD_ptp_TimeStamp_CallBack;
			break;
		case	PTPM_MSGTYPE_PDELAY_REQ:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgPDlyReq(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_LOCAL;
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgPDlyReqAS(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_LOCAL;
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
				break;
			}
			(VOID)tsn_Wrapper_MemCpy (&pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_PDREQ,
																		pstTimeStampCallbackInf, sizeof(TIMESTAMP_CALLBK_INF));
			pvLinkId = &pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_PDREQ;
			pstSendTimesCB = &MD_ptp_TimeStamp_CallBack;
			break;
		case	PTPM_MSGTYPE_PDELAY_RESP:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgPDlyResp(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_LOCAL;
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgPDlyRespAS(chMsgPtr, pstPtpMsg);
				pstTimeStampCallbackInf->uchTimeStampType = PTPMDL_RCVTIMESTAMPTYPE_LOCAL;
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
				break;
			}
			(VOID)tsn_Wrapper_MemCpy (&pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_PDRESP,
																		pstTimeStampCallbackInf, sizeof(TIMESTAMP_CALLBK_INF));
			pvLinkId = &pstTimeStampCallbackInf->pstPortData->stPort_GD.stTimeStampCallbkInf_PDRESP;
			pstSendTimesCB = &MD_ptp_TimeStamp_CallBack;
			break;
		case	PTPM_MSGTYPE_FOLLOWUP:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgFollowUp(chMsgPtr, pstPtpMsg);
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgFollowUpAS(chMsgPtr, pstPtpMsg);
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
		case	PTPM_MSGTYPE_DELAY_RESP:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgDlyResp(chMsgPtr, pstPtpMsg);
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
		case	PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgPDlyRespFllwUp(chMsgPtr, pstPtpMsg);
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgPDlyRespFllwUpAS(chMsgPtr, pstPtpMsg);
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
		case	PTPM_MSGTYPE_ANNOUNCE:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgAnnounce(chMsgPtr, pstPtpMsg);
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
#ifdef	PTP_USE_IEEE802_1
				ptp_Mdl_htonMsgAnnounceAS(chMsgPtr, pstPtpMsg);
#endif
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
		case	PTPM_MSGTYPE_SIGNALING:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
				ptp_Mdl_htonMsgSignalAS(chMsgPtr, pstPtpMsg);
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
#ifdef	PTP_USE_MANAGEMENT
		case	PTPM_MSGTYPE_MANAGEMENT:
			if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE1588))
			{
#ifdef	PTP_USE_IEEE1588
				ptp_Mdl_htonMsgManagement(chMsgPtr, pstPtpMsg);
#endif
			}
			else if(IsSupportPTPType(pstClockGd, ENUM_SUPPORTPTPTYPE_IEEE802_1AS))
			{
			}
			else
			{
				PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000001);
			}
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			break;
#endif
		default:
			pvLinkId = NULL;
			pstSendTimesCB = NULL;
			PTP_ERROR_LOGRECORD(pstTimeStampCallbackInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000002);
			break;
	}

	if (pstTimeStampCallbackInf->pstPortData->stPort_GD.blUnicast)
	{
		*(chMsgPtr+PTPM_HEADER_FLAG0_OFFSET) |= PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2;
	}

	mdtra_ntoh_us((chMsgPtr + 2), &usMsgLen);
	nRet= ptp_send ((UCHAR)usPortNumber, PTP_QBV_TRAFFIC_CLASS,
		chMsgPtr, usMsgLen, (SENDTIMESCB)pstSendTimesCB, pvLinkId);

	return (nRet);
}

VOID	MD_ptp_TimeStamp_CallBack(INT nErrorCode, UCHAR uchPort, EXTENDEDTIMESTAMP *pstMstTimeStamp, VOID *pvLinkId)
{
	TIMESTAMP_CALLBK_INF	*pstTimeStampInf;
	BOOL					blRet;
	LONG	lRet;

	pstTimeStampInf = (TIMESTAMP_CALLBK_INF *)pvLinkId;

	if(gblStartUpConfig != TRUE)
	{
		return;
	}
	else if(pstTimeStampInf == 0)
	{
		return;
	}
	else if((pstTimeStampInf->pstTimeStamp == 0)||
		    (pstTimeStampInf->pstPortData == 0))
	{
		return;
	}

	if (!nErrorCode)
	{
		if (pstMstTimeStamp)
		{

			blRet = ptpConvETS_TS(pstMstTimeStamp, pstTimeStampInf->pstTimeStamp);
			if(blRet==FALSE)
			{
				PTP_ERROR_LOGRECORD(pstTimeStampInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000004);
				return;
			}
			if (pstTimeStampInf->pfnCall == (TMSCB_FUNC_PTR)&MDSyncSendSM)
			{
				blRet = ptpConvETS_TS(pstMstTimeStamp+1, pstTimeStampInf->pstTimeStamp+1);
				if(blRet==FALSE)
				{
					PTP_ERROR_LOGRECORD(pstTimeStampInf->pstPortData->pstClockData, PTP_LOG_PTPSEND, PTP_LOGVE_85000004);
					return;
				}
			}
			*(pstTimeStampInf->pblTimeStampFlag) = TRUE;
		}
		else
		{
			*(pstTimeStampInf->pblTimeStampFlag) = FALSE;
		}
	}
	else
	{
		*(pstTimeStampInf->pblTimeStampFlag) = FALSE;
	}

	if (pstMstTimeStamp != NULL)
	{
	lRet = ptp_SystemSemLockWait(pstTimeStampInf->pstPortData->pstClockData);
	if (lRet != RET_ENOERR)
	{
		return;
	}

	(*(pstTimeStampInf->pfnCall))(pstTimeStampInf->usEvent, pstTimeStampInf->pstPortData);

	(VOID)ptp_SystemSemUnLock(pstTimeStampInf->pstPortData->pstClockData);
	}
	else
	{
		(*(pstTimeStampInf->pfnCall))(pstTimeStampInf->usEvent, pstTimeStampInf->pstPortData);
	}

}

VOID ptp_trns_an_port(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen)
{
	PORTDATA*	pstNextPort		= NULL;
	PORTDATA*	pstPortDat		= NULL;
	INT			nLoop;
	CLOCKDATA*	pstClock			= pstPort->pstClockData;
	USHORT		usPortNumber		= pstPort->stPortDS.stPortIdentity.usPortNumber;
	USHORT		usNumberPorts		= pstClock->stDefaultDS.usNumberPorts;
	pstNextPort = pstClock->pstPortData;
	for (nLoop = 0; nLoop < usNumberPorts; nLoop++)
	{
		pstPortDat = pstNextPort;
		if (usPortNumber != pstPortDat->stPortDS.stPortIdentity.usPortNumber)
		{
			if (pstPortDat->stPort_GD.blPortOper != TRUE)
			{
				continue;
			}

			if (pstPortDat->stPort_GD.blUnicast)
			{
				*(puchMsgPtr+PTPM_HEADER_FLAG0_OFFSET) |= PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2;
			}
			else
			{
				*(puchMsgPtr+PTPM_HEADER_FLAG0_OFFSET) &= (~PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2);
			}
			ptp_send (((UCHAR)pstPortDat->stPortDS.stPortIdentity.usPortNumber - 1),
				PTP_QBV_TRAFFIC_CLASS, puchMsgPtr, usMsgLen, NULL, 0);
		}
		pstNextPort = pstPortDat->pstNextPortDataPtr;
		if (pstNextPort == NULL)
		{
			break;
		}
	}
	return;
}

VOID ptp_trns_an_port_manage(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen)
{
	PORTDATA*	pstNextPort		= NULL;
	PORTDATA*	pstPortDat		= NULL;
	INT			nLoop;
	CLOCKDATA*	pstClock			= pstPort->pstClockData;
	USHORT		usPortNumber		= pstPort->stPortDS.stPortIdentity.usPortNumber;
	USHORT		usNumberPorts		= pstClock->stDefaultDS.usNumberPorts;
	UCHAR*		puchBoundaryHops	= puchMsgPtr+PTPMSG_HEAD_SZ+PTPMSG_MANAGEMENT_TGTPORTID_SZ+PTPMSG_MANAGEMENT_SBUNDRYHOPS_SZ;

	if (*puchBoundaryHops == 0)
	{
		return;
	}
	else
	{
		*puchBoundaryHops = (*puchBoundaryHops - 1);
	}
	
	pstNextPort = pstClock->pstPortData;
	for (nLoop = 0; nLoop < usNumberPorts; nLoop++)
	{
		pstPortDat = pstNextPort;
		if (usPortNumber != pstPortDat->stPortDS.stPortIdentity.usPortNumber)
		{
			if (pstPortDat->stPort_GD.blUnicast)
			{
				*(puchMsgPtr+PTPM_HEADER_FLAG0_OFFSET) |= PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2;
			}
			else
			{
				*(puchMsgPtr+PTPM_HEADER_FLAG0_OFFSET) &= (~PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2);
			}
			(VOID)ptp_send (((UCHAR)pstPortDat->stPortDS.stPortIdentity.usPortNumber - 1),
				PTP_QBV_TRAFFIC_CLASS, puchMsgPtr, usMsgLen, NULL, 0);
		}
		pstNextPort = pstPortDat->pstNextPortDataPtr;
		if (pstNextPort == NULL)
		{
			break;
		}
	}
	return;
}


INT ptp_Mdl_close(
	CLOCKDATA*	pstClockData)
{
	INT				nRet			= RET_ENOERR;




	return nRet;
}


BOOL	ptp_Mdl_HeaderCheck_8021AS(PTPMSG_HEADER* pstMsgHdr)
{
	UCHAR	uchDat;
	uchDat = MPTPMSG_H_GET_MAJORSDO_ID( pstMsgHdr );

	if ((uchDat != PTPM_MAJOR_SDOID_1) && (uchDat != PTPM_MAJOR_SDOID_2))
	{
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_8500001E);
		return FALSE;
	}



	if (pstMsgHdr->uchMinorSdoId != PTPM_MINOR_SDOID_0)
	{
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_85000021);
		return FALSE;
	}
	if ( MPTPMSG_H_GET_VER_PTP(pstMsgHdr) != PTPM_VER_PTP_2 )
	{
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_85000022);
		return FALSE;
	}
	return	TRUE;
}


BOOL	ptp_Mdl_HeaderCheck_1588(PTPMSG_HEADER* pstMsgHdr)
{

	if ( MPTPMSG_H_GET_VER_PTP(pstMsgHdr) != PTPM_VER_PTP_2 )
	{
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_PTPRECV, PTP_LOGVE_85000022);
		return FALSE;
	}
	return	TRUE;
}


#ifdef	OFFSET_DEBUG
void	setFrameEgTimeStamp(TIMESTAMP* pstTimestamp, USHORT usPort, UCHAR uchFrType)
{
	TIMESTAMP* pstDestTimestamp;

	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].usType       	= 2;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].uchFlameType		= uchFrType;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].usPortNumber		= usPort;
	stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].stTimestamp.stNsec.usFrcNsec = 0U;
	pstDestTimestamp = &stPtpTimestamplog[usPtpDebugTimestampLogCount%MAX_PTPTIMESTAMPLOG].stTimestamp;
	*pstDestTimestamp = *pstTimestamp;

	usPtpDebugTimestampLogCount++;
}
#endif
