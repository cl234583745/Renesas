/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MANAGEMENTAPI_1588_H__
#define __MANAGEMENTAPI_1588_H__

#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_managementid_1588.h"

#define	MGT1588_ACTION_GET					(0)
#define	MGT1588_ACTION_SET					(1)
#define	MGT1588_ACTION_MAX	   (MGTAS_ACTION_SET)

typedef	enum	tagMID1588_APPLIES
{
	MID1588_APPLIES_CLOCK = 0,
	MID1588_APPLIES_PORT

}	MID1588_APPLIES;

typedef struct tagMGT_API_SEL_TBL_1588
{
	UCHAR			uchManagementIdname[56];
	USHORT			usManagementId;
	MID1588_APPLIES	enTypeApplies;
	BOOL			(*pfnFunc[2])(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	USHORT			usMoldTypeSize;
}	MGT_ACT_API_TBL_1588;


#ifdef __cplusplus
extern "C" {
#endif
	INT ManagementAPI_1588( UCHAR uchAction, 
							USHORT usParamId_1588, 
							UCHAR  uchDomainNumber,
							USHORT usPortNumber, 
							UCHAR* puchInfo, 
							USHORT usInfoSize );

	INT	ManagementSM_1588_API(UCHAR uchAction, USHORT usParamId_1588, CLOCKDATA* pstClockData, PORTDATA* pstPortData, UCHAR* puchInfo, USHORT usInfoSize);
	BOOL GetManagement1588ParamId(ENUM_CLOCKSUPPORTTYPE_1588 enClockSupporType, USHORT usParamId_1588, USHORT* pusTblIndex, USHORT* pusSize);

	INT GetIe1588ClockDescription		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588UserDescription		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588UserDescription		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588FaultLog				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588FaultLogReset			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588DefaultDS				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588CurrentDS				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588ParentDS				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588TimePropertiesDS		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588PortDS					(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588Priority1				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588Priority1				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588Priority2				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588Priority2				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588SlaveOnly				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588SlaveOnly				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588LogAnnounInterval		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588LogAnnounInterval		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588AnnounReceiptTimeout	(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588AnnounReceiptTimeout	(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588LogSyncInterval		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588LogSyncInterval		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588VersionNum				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588VersionNum				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588EnablePort				(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588DisablePort			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588Time					(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588Time					(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588ClockAccuracy			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588ClockAccuracy			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588UtcProperties			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588UtcProperties			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588TraceProperties		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588TraceProperties		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588TimesProperties		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588TimesProperties		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588PathTraceList			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588PathTraceEnable		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588PathTraceEnable		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588PortStatCount			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588CmldStatPortCount		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588TransClockDefaultDS	(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588TransClockPortDS		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588PrimaryDomain			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588PrimaryDomain			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588DelayMechanism			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588DelayMechanism			(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588DelayMechanismTC		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588DelayMechanismTC		(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT GetIe1588LogMinPDReqInterval	(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT SetIe1588LogMinPDReqInterval	(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);
	INT NopIe1588_NOP					(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen);

#ifdef __cplusplus
}
#endif

#endif
