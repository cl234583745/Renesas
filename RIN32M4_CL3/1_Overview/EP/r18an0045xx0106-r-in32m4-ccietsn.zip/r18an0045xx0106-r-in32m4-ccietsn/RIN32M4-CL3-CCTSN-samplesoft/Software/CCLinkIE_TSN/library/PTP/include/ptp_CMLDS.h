/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTP_CMLDS_H__
#define __PTP_CMLDS_H__


#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct.h"
#include "ptp_Struct_Port.h"



typedef struct tagCMLDSPORT_MANAGE
{
	PORTDATA* 					pstExecuteCmldsPortPtr;
	CMLDSPORT_1AS_DS			stCmldsPort_1AS_DS;
	CMLDSDSCRPORT_1AS_DS		stCmldsDscrPort_1AS_DS;
	CMLDSPORTSTATISTICS_1AS_DS	stCmldsPortStatistics_1AS_DS;
}CMLDSPORT_MANAGE;



typedef struct tagCMLDS_MANAGE
{
	CMLDSDEFAULT_1AS_DS	stCmldsDefault_1AS_DS;
	CMLDSPORT_MANAGE	stCmldsPortManage[MAX_PORT];
}CMLDS_MANAGE;

#endif
