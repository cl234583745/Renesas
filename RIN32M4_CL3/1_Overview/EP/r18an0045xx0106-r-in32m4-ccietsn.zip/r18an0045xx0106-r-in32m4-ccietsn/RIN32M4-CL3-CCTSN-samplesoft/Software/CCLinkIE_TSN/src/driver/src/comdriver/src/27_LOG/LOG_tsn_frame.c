/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#include "nx_common.h"
#include "LOG_api.h"
#include "ccienx_api.h"
#include "nx_frame_sync.h"
#include "tsn_common.h"

#if TSN_LOG_FRAME

typedef struct TSNFRAMELOG_RECORD_T {
	NX_ULONGLONG	ullEventId;
	NX_ULONGLONG	ullPort;
	NX_ULONGLONG	ullDomain;
	NX_ULONGLONG	ullMessId;
	NX_ULONGLONG	ullSeqId;
	NX_ULONGLONG	ullTime;
} TSNFRAMELOG_RECORD;

typedef struct TSNFRAMELOG_AREA_TAG {
	NX_ULONGLONG		ullLogExec;
	NX_ULONGLONG		ullLogStopReq;
	NX_ULONGLONG		ullLogStopRemainTimes;
	NX_ULONGLONG		ullNowWriteIndex;
	NX_ULONGLONG		ullRecordNum;
	TSNFRAMELOG_RECORD	astRecord[TSNFRAMELOG_RECORD_SIZE];
} TSNFRAMELOG_AREA;




	
	

#endif
