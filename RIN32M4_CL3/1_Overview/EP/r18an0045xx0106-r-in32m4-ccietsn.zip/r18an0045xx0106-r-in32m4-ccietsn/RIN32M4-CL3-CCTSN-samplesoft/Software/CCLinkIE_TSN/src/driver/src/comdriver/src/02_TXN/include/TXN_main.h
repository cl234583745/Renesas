/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __TXN_MAIN_H_INCLUDE__
#define __TXN_MAIN_H_INCLUDE__
#include "nx_common.h"

#define	TSSTATE_DI					(0x000000001)
#define	TSSTATE_EI_REQ				(0x000000002)
#define	TSSTATE_DI_REQWAIT			(0x000000004)
#define	TSSTATE_EN					(0x000000008)
#define	TSSTATE_DI_REQ				(0x000000010)

#define	TSSTATE_EXE_MSK				((NX_ULONG)0x00000016)


NX_EXTERN NX_CONST NX_USHORT MailBoxIdList[TS_SIZE];


#endif
/*[EOF]*/
