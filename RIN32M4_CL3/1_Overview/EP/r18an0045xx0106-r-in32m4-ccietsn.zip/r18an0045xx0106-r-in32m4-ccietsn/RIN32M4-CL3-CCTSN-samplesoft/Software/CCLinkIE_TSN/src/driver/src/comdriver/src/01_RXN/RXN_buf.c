/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "RXN_buf.h"
#include "ccienx_api.h"

#define	ALL_USED				(0xFF)
#define	BYTEBITNUM				(8)


NCYC_RX_BUF_S			gstNonCycRxBufS;
NCYC_RX_BUF_L			gstNonCycRxBufL;

NX_STATIC NX_ULONG ulRXN_UsedFlgSet_RX (NX_ULONG*, NX_ULONG*);

NX_CONST NX_UCHAR UnUsedFlgCheckTable[256] = {
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	5,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	6,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	5,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	7,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	5,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	6,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	5,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	4,
	0,	1,	0,	2,	0,	1,	0,	3,
	0,	1,	0,	2,	0,	1,	0,	ALL_USED
};

NX_VOID vRXN_InitNonCycRxBuf (NX_VOID)
{
    NX_USHORT  usCount;
	vNX_FillMemory32(&gstNonCycRxBufS, NX_ZERO, (sizeof(NCYC_RX_BUF_S) / sizeof(NX_ULONG)));
	vNX_FillMemory32(&gstNonCycRxBufL, NX_ZERO, (sizeof(NCYC_RX_BUF_L) / sizeof(NX_ULONG)));
	
	for (usCount = (NX_USHORT)NX_ZERO; usCount < (NX_USHORT)NCYC_RX_NUM_S; usCount++) {
		gstNonCycRxBufS.astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_RX_BUF_S + usCount;
	}
	for (usCount = (NX_USHORT)NX_ZERO; usCount < (NX_USHORT)NCYC_RX_NUM_L; usCount++) {
		gstNonCycRxBufL.astFrame[usCount].usBuffId = (NX_USHORT)BUFFID_NCYC_RX_BUF_L + usCount;
	}
	
	gstNonCycRxBufS.ulUsedFlg = (NX_ULONG)NCYC_RX_NUM_S_BIT;
	gstNonCycRxBufL.ulUsedFlg = (NX_ULONG)NCYC_RX_NUM_L_BIT;

	return;
}

NX_ULONG ulRXN_AllocNonCycRxBuf (
	NX_USHORT		usSize,
	NCYC_RX_FRAME**	pstRxFrame
)
{
	NX_ULONG		*pulUsedFlgAdd;
	NX_ULONG		ulResult;
	NX_ULONG		ulBuffPoint;
	NX_ULONG		ulBuffAdd;
	NX_ULONG		ulBuffSize;
	
	ulResult = NX_UL_NG;
	
	if (usSize <= (NX_USHORT)NCYC_RX_FRAME_SIZE_S) {
		pulUsedFlgAdd = &gstNonCycRxBufS.ulUsedFlg;
		ulBuffAdd = (NX_ULONG)&gstNonCycRxBufS.astFrame[NX_ZERO];
		ulBuffSize = (NX_ULONG)sizeof(NCYC_RX_FRAME_S);
	}
	else {
		pulUsedFlgAdd = &gstNonCycRxBufL.ulUsedFlg;
		ulBuffAdd = (NX_ULONG)&gstNonCycRxBufL.astFrame[NX_ZERO];
		ulBuffSize = (NX_ULONG)sizeof(NCYC_RX_FRAME_L);
	}
	ulResult = ulRXN_UsedFlgSet_RX(pulUsedFlgAdd, &ulBuffPoint);
	
	if (ulResult != NX_UL_OK) {
	}
	else {
		*pstRxFrame = (NCYC_RX_FRAME*)(ulBuffAdd + (ulBuffSize * ulBuffPoint));
	}
	
	return ulResult;
}

NX_ULONG ulRXN_UsedFlgSet_RX (
	NX_ULONG			*pulUsedFlgAdd,
	NX_ULONG			*pulBuffPoint
)
{
	NX_ULONG	ulResult = NX_UL_NG;
	NX_ULONG	ulWritePointer = (NX_ULONG)NX_ZERO;
	NX_USHORT	usCount;
	NX_UCHAR	uchUsedFlgIndex;
	
	NX_ULONG	ulFlg;
	
	vNX_vDisableDispatch();
	
	ulFlg = *pulUsedFlgAdd;
	
	for (usCount = (NX_USHORT)NX_ZERO; usCount < (NX_USHORT)sizeof(NX_ULONG); usCount++) {
		uchUsedFlgIndex = (NX_UCHAR)(ulFlg & NX_BIT00_07);
		if (UnUsedFlgCheckTable[uchUsedFlgIndex] != (NX_UCHAR)ALL_USED) {
			ulWritePointer += UnUsedFlgCheckTable[uchUsedFlgIndex];
			*(NX_ULONG*)BITBAND_SRAM((NX_ULONG)pulUsedFlgAdd, ulWritePointer) = 1;
			*pulBuffPoint = ulWritePointer;
			ulResult = NX_UL_OK;
			break;
		}
		ulWritePointer += BYTEBITNUM;
		ulFlg >>= BYTEBITNUM;
	}
	vNX_vEnableDispatch();
	return ulResult;
}

NX_VOID vRXN_ReleaseNonCycRxBuf (
	NX_USHORT	usBuffId
)
{
	switch (usBuffId & (BUFFIDMASK_SIZE | BUFFIDMASK_FRAME)) {
	case BUFFID_NCYC_RX_BUF_S:
		*(NX_ULONG*)BITBAND_SRAM((NX_ULONG)&gstNonCycRxBufS.ulUsedFlg, ((NX_ULONG)(usBuffId & BUFFIDMASK_INDEX))) = 0;
		break;
	case BUFFID_NCYC_RX_BUF_L:
		*(NX_ULONG*)BITBAND_SRAM((NX_ULONG)&gstNonCycRxBufL.ulUsedFlg, ((NX_ULONG)(usBuffId & BUFFIDMASK_INDEX))) = 0;
		break;
	default:
		break;
	}
	return;
}
