/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#include "MDOneStpTxOprSet.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDOneStpTxOprSet_1AS.h"
#endif


VOID OneStepTxOperSettingSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET, PTP_LOGVE_82080001);
#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		 OneStepTxOperSetSM_1AS(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET, PTP_LOGVE_82000002);
	return;
}

OSTOSETTINGSM_GD* GetOneStpTxOprSetGlobal(PORTDATA* pstPort)
{
		return &pstPort->stOSTOSettingSM_GD;
}

ONESTPTXOPRSET_EV GetOneStpTxOprSetEvent(USHORT usEvent, PORTDATA* pstPort)
{
	ONESTPTXOPRSET_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDOSTO_E_BEGIN;
		break;
		case PTP_EV_USEMGTSETLOGONESTPTXOP_ON:
			enEvt = MDOSTO_E_UMGTSETLOGONESTPTXO_ON;
		break;
		case PTP_EV_USEMGTSETLOGONESTPTXOP_OF:
			enEvt = MDOSTO_E_UMGTSETLOGONESTPTXO_OF;
		break;
		case PTP_EV_RCVDSIGNALINGMSG4:
			enEvt = MDOSTO_E_RCVDSIGNALINGMSG4;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDOSTO_E_CLOSE;
		break;

		default:
			enEvt = MDOSTO_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

ONESTPTXOPRSET_ST GetOneStpTxOprSetStatus(PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;
	ONESTPTXOPRSET_ST	enSts = MDOSTO_STATUS_MAX;

	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	if (pstGbl->enStsOneStpTxOprSet < MDOSTO_STATUS_MAX)
	{
		enSts = pstGbl->enStsOneStpTxOprSet;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDOSTXOPRSET, PTP_LOGVE_82000004);
	}

	return enSts;
}

VOID SetOneStpTxOprSetStatus(ONESTPTXOPRSET_ST enSts, PORTDATA* pstPort)
{
	OSTOSETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetOneStpTxOprSetGlobal(pstPort);

	pstGbl->enStsOneStpTxOprSet = enSts;
	return;
}
#endif
