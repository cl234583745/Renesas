/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "itron.h"
#include "kernel.h"
#include "RXN_api.h"
#include "RXN_buf.h"
#include "TOOL_api.h"






NX_LONG lRXN_PollingRxNonCycFrame (
	ID				mbx_id,
	NCYC_RX_FRAME	**pRxFrame
)
{
	T_MSG *pstMsg;
	NX_LONG	lResult;
	NX_LONG	lRcvResult;
	lResult = NCYC_RX_BUF_RSLT_PARAM_ERR;
	
	lRcvResult = prcv_mbx(mbx_id, (T_MSG**)&pstMsg);
	if (lRcvResult != E_OK) {
		lResult = NCYC_RX_BUF_RSLT_NO_MAIL;
	}
	else {
		lResult = NCYC_RX_BUF_RSLT_OK;
		*pRxFrame = (NCYC_RX_FRAME*)pstMsg;
	}
	return lResult;
}

NX_VOID vRXN_RelRxNonCycFrameBuf (
	NCYC_RX_FRAME*	pstBuf
)
{
	vRXN_ReleaseNonCycRxBuf(pstBuf->usBuffId);
	return;
}

