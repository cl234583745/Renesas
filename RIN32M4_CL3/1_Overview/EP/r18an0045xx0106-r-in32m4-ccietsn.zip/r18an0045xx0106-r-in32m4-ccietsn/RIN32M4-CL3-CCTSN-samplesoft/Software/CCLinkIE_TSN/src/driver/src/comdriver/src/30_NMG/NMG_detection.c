/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "ccienx_api.h"
#include "TXN_api.h"
#include "RXN_api.h"
#include "ccienx_task.h"

#define RCV_FRMNUMBER_TESTDATA		((NX_USHORT)0)
#define RCV_FRMNUMBER_DETECTION		((NX_USHORT)1)
#define RCV_FRMNUMBER_FIRST_DT		RCV_FRMNUMBER_TESTDATA
#define RCV_FRMNUMBER_LAST_DT		RCV_FRMNUMBER_DETECTION
#define RCV_FRMNUMBER_UNKNOWN_DT	((NX_USHORT)RCV_FRMNUMBER_LAST_DT+(NX_USHORT)NX_ONE)

#define TRN_FRMNUMBER_TESTDATAACK	((NX_USHORT)0)
#define TRN_FRMNUMBER_DETECTIONACK	((NX_USHORT)1)

#define RCVFRM_KIND_DT		((NX_USHORT)2)
#define TRNFRM_KIND_DT		((NX_USHORT)2)

typedef NX_VOID (* FRM_ANALYZE_PROC_DT)(NX_UCHAR*, NX_USHORT, NX_VOID*);

typedef struct tagDT_TBL_REC {
	NX_UCHAR			uchFrameType;
	FRM_ANALYZE_PROC_DT	pFunc;
} DT_TBL_REC;

typedef struct tagDT_CTRL {
	NX_USHORT	usSts;
	NX_USHORT	usTrnFrmNumber;
	NX_ULONG	aulReq[TRNFRM_KIND_DT];
	NX_ULONG	aulFin[TRNFRM_KIND_DT];
	NX_USHORT	ausPort[TRNFRM_KIND_DT];
	NX_ULONG	aulBufAddr[TRNFRM_KIND_DT];
} DT_CTRL;

NX_STATIC	DT_CTRL	gstDt;

NX_STATIC	NX_CONST	DT_TBL_REC	gastDtTbl[RCVFRM_KIND_DT] = {
	{FRAMETYPE_TESTDATA,	NX_NULL					},
	{FRAMETYPE_DETECTION,	vNMG_AnalyzeDetection	}
};

NX_VOID vNMG_RcvDt ( NX_VOID );
NX_USHORT usNMG_GetFrameKindDt ( NX_VOID* );
NX_VOID vNMG_CheckFrmTrnReqDt ( NX_VOID );
NX_ULONG ulNMG_CheckFrmTrnFinishDt ( NX_VOID );

NX_VOID vNMG_InitCieNetMngDt ( NX_VOID )
{
	vNX_FillMemory32((NX_VOID*)&gstDt, NX_ZERO, sizeof(DT_CTRL) / sizeof(NX_ULONG));
	
	
	return;
}

NX_VOID vNMG_RcvDtMain ( NX_VOID )
{
	NX_ULONG	ulTrnFinish = (NX_ULONG)NX_OFF;
	
	if (gstDt.usSts == NM_STS_WAIT_RCV) {
		
		vNMG_RcvDt();
		
		vNMG_CheckFrmTrnReqDt();
		
	}
	else if (gstDt.usSts == NM_STS_WAIT_TRN) {
		
		ulTrnFinish = ulNMG_CheckFrmTrnFinishDt();
		
		if (ulTrnFinish == (NX_ULONG)NX_ON) {
			vNMG_CheckFrmTrnReqDt();
		}
		
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_RcvDt ( NX_VOID )
{
	NX_USHORT		usFrmNumber		=	NX_ZERO;
	FRM_NGN_HEAD	*pstNgnHead;
	NX_LONG			lFrmExist		=	NCYC_RX_BUF_RSLT_NO_MAIL;
	NCYC_RX_FRAME	*pstData;
	
	lFrmExist = lRXN_PollingRxNonCycFrame(MBXID_NX_RECEIVE_NGN, &pstData);
	
	if (lFrmExist == NCYC_RX_BUF_RSLT_OK) {
		
		pstNgnHead = (FRM_NGN_HEAD*)((NX_ULONG)pstData->auchData + pstData->usEtherOffset);
		usFrmNumber = usNMG_GetFrameKindDt(pstNgnHead);
		
		if (usFrmNumber <= RCV_FRMNUMBER_LAST_DT) {
			if (NX_NULL != gastDtTbl[usFrmNumber].pFunc) {
				vNMG_ClrNmgErrDt();
				(gastDtTbl[usFrmNumber].pFunc)((pstData->auchData + SIZE_ETHERNET_HEADER_DA), pstData->usPort, (NX_VOID*)((NX_ULONG)pstData->auchData + SIZE_ETHERNET_HEADER_DA + SIZE_ETHERNET_HEADER_SA));
			}
		}
		else {
		}
		(NX_VOID)vRXN_RelRxNonCycFrameBuf(pstData);
	}
	else {
	}
	
	return;
}

NX_USHORT usNMG_GetFrameKindDt (
	NX_VOID*	pstData
)
{
	NX_USHORT		usIndex;
	FRM_NGN_HEAD	*pstHead;
	NX_UCHAR		uchFrameType = (NX_UCHAR)NX_ZERO;
	NX_USHORT		usFrmNumber = RCV_FRMNUMBER_UNKNOWN_DT;
	
	pstHead = (FRM_NGN_HEAD*)pstData;
	
	uchFrameType = pstHead->uchFrameType;
	
	for (usIndex = RCV_FRMNUMBER_FIRST_DT; usIndex <= RCV_FRMNUMBER_LAST_DT; usIndex++) {
	
		if (gastDtTbl[usIndex].uchFrameType == uchFrameType) {
			
			usFrmNumber = usIndex;
			
			break;
		}
		
	}
	
	return usFrmNumber;
}

NX_VOID vNMG_CheckFrmTrnReqDt ( NX_VOID )
{
	NX_USHORT		usFrmNumber	=	NX_ZERO;
	NX_USHORT		usSts		=	NM_STS_WAIT_RCV;
	
	for (usFrmNumber = NX_ZERO; usFrmNumber < TRNFRM_KIND_DT; usFrmNumber++) {
		
		if (gstDt.aulReq[usFrmNumber] == (NX_ULONG)NX_ON) {
						
			if (usFrmNumber == RCV_FRMNUMBER_DETECTION) {
				(NX_VOID)vTXN_NotifyStore_TxNonCycBuf(gstNM.stTrnBuf.pstDetectionAck->usTsNo, gstNM.stTrnBuf.pstDetectionAck);
			}
			else if (usFrmNumber == RCV_FRMNUMBER_TESTDATA) {
				(NX_VOID)vTXN_NotifyStore_TxNonCycBuf(gstNM.stTrnBuf.pstTestDataAck->usTsNo, gstNM.stTrnBuf.pstTestDataAck);
			}
			
			gstDt.usTrnFrmNumber = usFrmNumber;
			
			usSts = NM_STS_WAIT_TRN;
			
			break;
		}
		
	}
	
	gstDt.usSts = usSts;
	
	return;
}

NX_ULONG ulNMG_CheckFrmTrnFinishDt ( NX_VOID )
{
	NX_ULONG	ulTrnFinish	=	(NX_ULONG)NX_OFF;
	
	ulTrnFinish = gstDt.aulFin[gstDt.usTrnFrmNumber];
	
	if (ulTrnFinish == (NX_ULONG)NX_ON) {
		
		gstDt.aulReq[gstDt.usTrnFrmNumber] = (NX_ULONG)NX_OFF;
		gstDt.aulFin[gstDt.usTrnFrmNumber] = (NX_ULONG)NX_OFF;
	}
	else {
		
	}
	
	return ulTrnFinish;
}

NX_VOID vNMG_ReqTrnDetectionAck ( NX_VOID )
{
	gstDt.aulReq[TRN_FRMNUMBER_DETECTIONACK] = (NX_ULONG)NX_ON;
	return;
}


NX_VOID vNMG_CallbackTrnDetectionAck (
	NX_ULONG	ulTXFrameInfo,
	NX_ULONG	ulResult
)
{
	gstDt.aulFin[TRN_FRMNUMBER_DETECTIONACK] = (NX_ULONG)NX_ON;
		
	return;
}

NX_VOID vNMG_CallbackTrnTestDataAck (
	NX_ULONG	ulCbArg,
	NX_ULONG	ulResult
)
{
	gstDt.aulFin[TRN_FRMNUMBER_TESTDATAACK] = (NX_ULONG)NX_ON;
	return;
}
/*[EOF]*/
