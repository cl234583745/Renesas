/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "mdtransinterface.h"

#include "ManagementSM.h"

#ifdef	PTP_USE_MANAGEMENT

#include "ManagementSM_1588.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord_GD.h"

VOID ManagementSM_1588(UCHAR* puchMsg, USHORT usMsgLen, UCHAR uchInterFaceNo)
{
	CLOCKDATA*				pstClock_DT	= NULL;
	PORTDATA*				pstPort_DT		= NULL;
	MANAGEMENTSM_GD*		pstGmGbl		= NULL;
	PTPMSG_MANAGEMENT_1588*	pstMsg = NULL;

	pstMsg      = (PTPMSG_MANAGEMENT_1588 *)puchMsg;
	pstClock_DT = GetMGTClockData( pstMsg->stHeader.uchDomainNumber );
	if (pstClock_DT == NULL)
	{
		return;
	}

	pstGmGbl = GetManagementSMGlobal(pstClock_DT);

	if (SetMGTRcvManagementMsg(pstGmGbl, puchMsg, usMsgLen, uchInterFaceNo) == FALSE)
	{
		return;
	}
	pstPort_DT	= GetMGTPortData(pstClock_DT, pstGmGbl->stMgtTagetPortId.usPortNumber);

	switch (pstGmGbl->byMgtAction)
	{
	case	PTPM_MGT_ACTION_GET:
		ManagementSM_GET(pstGmGbl, pstClock_DT, pstPort_DT, usMsgLen);
		break;
	case	PTPM_MGT_ACTION_SET:
		ManagementSM_SET(pstGmGbl, pstClock_DT, pstPort_DT, usMsgLen);
		break;
	case	PTPM_MGT_ACTION_CMD:
		ManagementSM_CMD(pstGmGbl, pstClock_DT, pstPort_DT, usMsgLen);
		break;
	case	PTPM_MGT_ACTION_RES:
	case	PTPM_MGT_ACTION_ACK:
		break;
	default:
		PTP_WARNING_LOGRECORD(gpstClockDataHPtr, PTP_LOG_MGTSM_1588, PTP_LOGVE_87000001);
		break;
	}


	return;
}


BOOL SetMGTRcvManagementMsg(MANAGEMENTSM_GD* pstSmGbl, UCHAR* puchMsg, USHORT usMsgLen, UCHAR uchInterFaceNo)
{
	PTPMSG_MANAGEMENT_1588*	pstMsg		= NULL;

	if ((puchMsg == NULL) || (usMsgLen == 0))
	{
		return FALSE;
	}

	pstMsg = (PTPMSG_MANAGEMENT_1588*)puchMsg;
	if ( PTPM_MSGTYPE_MANAGEMENT != MPTPMSG_H_GET_MSG_TYPE( &pstMsg->stHeader ) )
	{
		return FALSE;
	}


	pstSmGbl->puchMgtRxMsg		= puchMsg;
	pstSmGbl->usMgtRxMsgLen		= usMsgLen;
    pstSmGbl->byMgtAction       = PTP_GET_BITS( &pstMsg->byActionField, 0, 3 );
	pstSmGbl->stMgtTagetPortId	= pstMsg->stTargetPortIdentity;
	pstSmGbl->stMgtsourcePortId	= pstMsg->stHeader.stSrcPortIdentity;
	pstSmGbl->uchMgtInterFaceNo	= uchInterFaceNo;

	return TRUE;
}

VOID SetMGT_TLVHeaderInfo(
	PTPMSG_MANAGEMENT_TLV*	pstInTLV,
	PTPMSG_MANAGEMENT_TLV*	pstOutTLV,
	USHORT					usDataFieldLen)
{
	pstOutTLV->usTLVType		= pstInTLV->usTLVType;
	pstOutTLV->usManagementId= pstInTLV->usManagementId;
	pstOutTLV->usLengthField = usDataFieldLen + ((UCHAR *)&pstInTLV->stDataField - (UCHAR *)pstInTLV)- (PTPMSG_MGTTLV_TLVTYPE_SZ) - (PTPMSG_MGTERSTTLV_TLVLENGTH_SZ);

	return;
}

VOID SetManagementErrorTLVInfo(
	PTPMSG_MANAGEMENT_TLV*				pstInTLV,
	PTPMSG_MANAGEMENT_ERRSTA_TLV*		pstErrOutTLV,
	USHORT								usManagementErrorId)
{
	tsn_Wrapper_MemSet(pstErrOutTLV, 0, sizeof(PTPMSG_MANAGEMENT_ERRSTA_TLV));

	pstErrOutTLV->usTLVType		= PTPM_TLVTYP_MANAGEMENT_ERR_STAT;
	pstErrOutTLV->usManagementErrorId = usManagementErrorId;
	pstErrOutTLV->usManagementId	= pstInTLV->usManagementId;
	pstErrOutTLV->usLengthField	= PTPM_MGTTVL_LENGTH_FIXMIN
						+ sizeof(pstErrOutTLV->usManagementId)
						+ 4
						+ 2;
	return;
}

VOID SetTxManagementMsg(
	MANAGEMENTSM_GD*		pstSmGbl,
	PTPMSG_MANAGEMENT_TLV*	pstOutTLV,
	PORTDATA* pstPortData)
{
	USHORT		usDataFieldLen =
		(pstOutTLV->usLengthField + PTPM_MGTBDY_TVLLENGTH_FIXMIN);
	USHORT		usMsgLen	   = 0;
	PTPMSG_MANAGEMENT_1588*	pstRxMsg = (PTPMSG_MANAGEMENT_1588*)pstSmGbl->puchMgtRxMsg;
	PTPMSG_MANAGEMENT_1588*	pstTxMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;
	PORTDATA* pstPortDataWork;

	UCHAR	*puchTxMsg;

	puchTxMsg = (UCHAR *)pstTxMsg;
	puchTxMsg = puchTxMsg + (pstTxMsg->stHeader.usMegLength);

	if(pstTxMsg->stHeader.usMegLength == 0)
	{

	GetPTPMSG_HEADER(pstTxMsg->stHeader, usMsgLen);
	GetPTPMSG_MANAGEMENT_1588(*pstTxMsg, usMsgLen);

	tsn_Wrapper_MemCpy(pstTxMsg, pstRxMsg,
		(sizeof(PTPMSG_MANAGEMENT_1588) - sizeof(PTPMSG_MGTTLV_1588)));

	pstTxMsg->stHeader.usMegLength = (sizeof(PTPMSG_MANAGEMENT_1588) - sizeof(PTPMSG_MGTTLV_1588));

	tsn_Wrapper_MemCpy(&pstTxMsg->stTargetPortIdentity,
		&pstSmGbl->stMgtsourcePortId, sizeof(pstTxMsg->stHeader.stSrcPortIdentity));
	tsn_Wrapper_MemSet(&pstTxMsg->stHeader.stCorrectionField, 0,
		sizeof(pstTxMsg->stHeader.stCorrectionField));

	if (pstPortData == NULL)
	{
		pstPortDataWork = searchPortFromPortNumber (pstSmGbl->uchMgtInterFaceNo);
	}
	else
	{
		pstPortDataWork = pstPortData;
	}
	tsn_Wrapper_MemCpy(&pstTxMsg->stHeader.stSrcPortIdentity,
		&pstPortDataWork->stPortDS.stPortIdentity,sizeof(pstTxMsg->stHeader.stSrcPortIdentity));


	pstTxMsg->stHeader.uchControl = PTPM_CONTROL_MANAGEMENT;					
	pstTxMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;

	pstSmGbl->usTxMgtMsgLen = PTPM_MGTBDY_LENGTH_FIX;

	puchTxMsg = (UCHAR *)&pstTxMsg->stManagemant_TLV;
	}

	tsn_Wrapper_MemCpy(puchTxMsg, pstOutTLV, usDataFieldLen);
	pstSmGbl->usTxMgtMsgLen += usDataFieldLen;
	pstTxMsg->stHeader.usMegLength = pstTxMsg->stHeader.usMegLength + usDataFieldLen;
	if ((pstSmGbl->byMgtAction == PTPM_MGT_ACTION_GET) ||
		(pstSmGbl->byMgtAction == PTPM_MGT_ACTION_SET))
	{
        PTP_SET_BITS( &pstTxMsg->byActionField, 0, 3, PTPM_MGT_ACTION_RES );
	}
	else if (pstSmGbl->byMgtAction == PTPM_MGT_ACTION_CMD)
	{
        PTP_SET_BITS( &pstTxMsg->byActionField, 0, 3, PTPM_MGT_ACTION_ACK );
	}
	else
	{
	}

	return;
}

BOOL TxManagementMsg(
	MANAGEMENTSM_GD*	pstSmGbl
	,CLOCKDATA*			pstClockData)
{
	INT		nPtpSend = 0;
	PTPMSG_MANAGEMENT_1588*	pstTxMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;

	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= GetMGTPortData(pstClockData, pstSmGbl->uchMgtInterFaceNo);
	if (pstCallback->pstPortData == NULL)
	{
		return FALSE;
	}
		nPtpSend = MD_ptp_send(
			(UCHAR *)pstSmGbl->ulTxMgtMsg,
			pstTxMsg->stHeader.usMegLength,
			pstCallback);

	if (nPtpSend == 0) {
		return TRUE;
	}
	else {
		return FALSE;
	}
}

VOID SetMGT_TLVDataField(
	PTPMSG_MANAGEMENT_TLV*	pstInTLV,
	PTPMSG_MANAGEMENT_TLV*	pstOutTLV)
{
	tsn_Wrapper_MemCpy(&pstOutTLV->stDataField, &pstInTLV->stDataField, pstOutTLV->usLengthField - PTPMSG_MGTTLV_MANAGEMENTID_SZ);
	return;
}

PORTDATA*	searchPortFromPortNumber(UCHAR uchInterfaceNo)
{
	PORTDATA*	pstPortData;
	USHORT		usInterfaceNo;

	usInterfaceNo = (USHORT)uchInterfaceNo;
	pstPortData = gpstClockDataHPtr->pstPortData;

	while(pstPortData != NULL)
	{
		if (pstPortData->stPortDS.stPortIdentity.usPortNumber == (usInterfaceNo + 1))
		{
			break;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}
	return	pstPortData;
}
#endif

