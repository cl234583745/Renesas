/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRQRECEIVE_1588_GD_H__
#define __PTP_PDRQRECEIVE_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PDRQR {
	ST_PDRQR_NONE	= 0,
	ST_PDRQR_DISCARD,
	ST_PDRQR_RECEIVED_DELAYREQ,
	ST_PDRQR_MAX
} EN_ST_PDRQR;


typedef	enum	tagEN_EV_PDRQR {
	EV_PDRQR_BEGIN = 0,
	EV_PDRQR_FOR_PDLRQRV_RCVMDDLRQ,
	EV_PDRQR_CLOSE,
	EV_PDRQR_EVENT_MAX
} EN_EV_PDRQR;


typedef	struct tagPDRQRECEIVESM_1588_GD
{
	EN_ST_PDRQR		enStatusPDRQR;
	BOOL			blRcvdMDDelayReq;
	MDDELAYREQ*		pstRcvdMDDReqRcvPtr;
	MDDELAYREQ*		pstTxMDDReqSndPtr;
	MDDELAYRESP*	pstTxMDDRespSndPtr;
} PDRQRECEIVESM_1588_GD;	



#endif


