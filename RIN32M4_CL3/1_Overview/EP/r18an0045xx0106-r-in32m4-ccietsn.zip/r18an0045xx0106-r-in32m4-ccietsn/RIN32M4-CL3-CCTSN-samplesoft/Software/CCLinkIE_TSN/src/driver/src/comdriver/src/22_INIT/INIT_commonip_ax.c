/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"





NX_VOID vINIT_commonip_ax ( NX_VOID )
{
	
	NGN_AXI_REG->R_RGELAERR.DATA	=	(NX_ULONG)0x000003FF;
	
	
	
	

	
	return;
}

/*[EOF]*/
