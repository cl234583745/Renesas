/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYRESP_1AS_H__
#define __MDPDELAYRESP_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDPdelayResp_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID MDPdelayResp_00_1AS(PORTDATA* pstPort);
VOID MDPdelayResp_01_1AS(PORTDATA* pstPort);
VOID MDPdelayResp_02_1AS(PORTDATA* pstPort);
VOID MDPdelayResp_03_1AS(PORTDATA* pstPort);
VOID MDPdelayResp_NP_1AS(PORTDATA* pstPort);

BOOL MDPdlyResp_NotEnable_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_IntWtFrPDReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_WtFrPDReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyResp_StPDRespWtFrTS_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDPdelayReq_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetPdelayResp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayResp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetPdelayRespFollowUp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayRespFollowUp_1AS(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
