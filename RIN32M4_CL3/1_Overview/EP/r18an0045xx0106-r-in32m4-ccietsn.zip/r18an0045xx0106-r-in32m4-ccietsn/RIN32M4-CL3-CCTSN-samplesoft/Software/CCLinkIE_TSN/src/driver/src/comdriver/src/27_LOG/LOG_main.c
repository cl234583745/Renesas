/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "log.h"
#include "ccienx_api.h"
#include "JADE.h"
#include "INTR_api.h"
#include "SNMP_mib_api.h"
#if TSN_LOG_ADJUST
#include "LOG_api.h"
#endif
#if TSN_LOG_FRAME
#include "LOG_api.h"
#endif
#if GENERAL_PURPOSE_DATASAVE
#include "LOG_api.h"
#endif

#define	R_SNTM0			((NX_ULONG)&NGN_SN_REG->R_SNTM0)
#define	R_SNTM1			((NX_ULONG)&NGN_SN_REG->R_SNTM1)
#define	R_TCP1SC0		((NX_ULONG)&NGN_CN_TS_P1_REG->R_TCPXSC0)
#define	R_TCP1SC1		((NX_ULONG)&NGN_CN_TS_P1_REG->R_TCPXSC1)
#define	R_RE_BERR		((NX_ULONG)&NGN_CN_REG->R_REBERR)
#define	R_AERRDB 		((NX_ULONG)&NX_JADE_SYS->R_AERRDB)

#define	GETTYPE_OVER	((NX_ULONG)0)
#define	GETTYPE_ADD		((NX_ULONG)1)
#define	GETTYPE_OR		((NX_ULONG)2)
#define	GETTYPE_SPECIAL	((NX_ULONG)3)
#define	GETTYPE_END		((NX_ULONG)0xFFFFFFFF)

#define	NOADDRESS		((NX_ULONG)0x00000000)
#define	ASICREAD_MAX	((NX_ULONG)(240 / 2))

#define	WRITE_FIRST			((NX_ULONG)1)
#define	WRITE_FIRST_SECOND	((NX_ULONG)2)


typedef struct tagGETLOGLIST {
	NX_ULONG	ulAddress_First;
	NX_ULONG	ulAddress_Second;
	NX_ULONG	ulMeans;
} READTARGETLIST;

typedef struct tagFREEREADSETTING {
	NX_ULONG	ulAddress_First;
	NX_ULONG	ulAddress_Second;
	NX_ULONG	ulResult_First;
	NX_ULONG	ulResult_Second;
} FREEREADINFO;
typedef struct tagLOGDATAINFO {
	NX_ULONG	ulReadArea;
	NX_ULONG	ulDummy;
} LOGDATAINFO;

#if REC_TSN_INF
#include "NMG_common.h"
extern NM_CTRL			gstNM;
#endif
LOGDATAINFO gstLogDataInfo;
NX_STATIC NX_ULONG gaulAsicReadData[2][ASICREAD_MAX];
NX_STATIC FREEREADINFO gstFreeReadSetting;
NX_CONST NX_STATIC READTARGETLIST ReadTargetTable[] =	{

	{R_SNTM0,														R_SNTM1,			GETTYPE_OVER	},
	{R_TCP1SC0,														R_TCP1SC1,			GETTYPE_OVER	},
	{(NX_ULONG)&gulIntHighCount,									NOADDRESS,			GETTYPE_OVER	},
	{R_RE_BERR,														NOADDRESS,			GETTYPE_OR		},
	{(NX_ULONG)&gulIntTxnHighCount,									NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gulIntRxnErrCount,									NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gulIntRxnCount,										NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstStatistictInfo.ulCycRecvCnt,						NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulCycRecvDicardCnt,				NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulNonCycRecvCnt[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulNonCycRecvCnt[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstLogDataInfo.ulDummy,								NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstLogDataInfo.ulDummy,								NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstLogDataInfo.ulDummy,								NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstLogDataInfo.ulDummy,								NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstStatistictInfo.ulHecErrFrameNum[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulHecErrFrameNum[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulDcsErrFrameNum[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulDcsErrFrameNum[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulFcsErrFrameNum[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulFcsErrFrameNum[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulShortPacketFrameNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulShortPacketFrameNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulLongPacketFrameNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulLongPacketFrameNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT1],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT2],	NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulIpFrameNum[NX_PORT1],			NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulIpFrameNum[NX_PORT2],			NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulIeeeFrameNum[NX_PORT1],			NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulIeeeFrameNum[NX_PORT2],			NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulRecvSfdDetCnt[NX_PORT1],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulRecvSfdDetCnt[NX_PORT2],		NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulMinIfgDetCnt[NX_PORT1],			NOADDRESS,			GETTYPE_ADD		},
	{(NX_ULONG)&gstStatistictInfo.ulMinIfgDetCnt[NX_PORT2],			NOADDRESS,			GETTYPE_ADD		},
	{R_AERRDB,														NOADDRESS,			GETTYPE_OVER	},
#if REC_TSN_INF == 1
	{(NX_ULONG)&gstNET.stPtp.ulPtpSts,								NOADDRESS,			GETTYPE_OVER	},
	{(NX_ULONG)&gstNM.stNet,										NOADDRESS,			GETTYPE_OVER	},
#endif
	{NOADDRESS,														NOADDRESS,			GETTYPE_END		}   
	};                                                          


NX_STATIC NX_VOID vLOG_UpDateReadArea (NX_VOID);
NX_STATIC NX_VOID vLOG_UpdateLogData_Over (NX_ULONG, NX_ULONG, NX_ULONG*, NX_ULONG*);
NX_STATIC NX_VOID vLOG_UpdateLogData_Add (NX_ULONG, NX_ULONG, NX_ULONG*, NX_ULONG*, NX_ULONG*);
NX_STATIC NX_VOID vLOG_UpdateLogData_Or (NX_ULONG, NX_ULONG, NX_ULONG*, NX_ULONG*, NX_ULONG*);






NX_VOID vLOG_Init (NX_VOID)
{
	vNX_FillMemory32((NX_VOID*)&gstLogDataInfo.ulReadArea, (NX_LONG)0, sizeof(LOGDATAINFO) / sizeof(NX_ULONG));
	vNX_FillMemory32((NX_VOID*)&gaulAsicReadData[0], (NX_LONG)0, ASICREAD_MAX);
	vNX_FillMemory32((NX_VOID*)&gstFreeReadSetting, (NX_LONG)0, (sizeof(FREEREADINFO) / sizeof(NX_ULONG)));
#if TSN_LOG_ADJUST
	vADJUSTLOG_init();
#endif
#if TSN_LOG_FRAME
	vTSNFRAMELOG_init();
#endif
#if GENERAL_PURPOSE_DATASAVE
	vGPDS_init();
#endif
	return;
}

NX_VOID vLOG_GetLogData (NX_VOID)
{
	NX_ULONG	ulCount;
	NX_ULONG	ulWriteArea;
	NX_ULONG	ulWriteCount = (NX_ULONG)NX_ZERO;
	NX_ULONG*	pulWriteData;
	NX_ULONG*	pulReadData;
	
	ulWriteArea = (NX_ULONG)1 & ~gstLogDataInfo.ulReadArea;
	pulWriteData = (NX_ULONG*)&gaulAsicReadData[ulWriteArea][0];
	pulReadData = (NX_ULONG*)&gaulAsicReadData[gstLogDataInfo.ulReadArea][0];
	
	for (ulCount = (NX_ULONG)NX_ZERO; ReadTargetTable[ulCount].ulAddress_First != NOADDRESS; ulCount++) {
		switch (ReadTargetTable[ulCount].ulMeans) {
		case GETTYPE_OVER:
			vLOG_UpdateLogData_Over(ReadTargetTable[ulCount].ulAddress_First,
									ReadTargetTable[ulCount].ulAddress_Second,
									pulWriteData,
									&ulWriteCount);
			break;
		case GETTYPE_ADD:
			vLOG_UpdateLogData_Add(ReadTargetTable[ulCount].ulAddress_First,
								   ReadTargetTable[ulCount].ulAddress_Second,
								   pulWriteData,
								   pulReadData,
								   &ulWriteCount);
			break;
		case GETTYPE_OR:
			vLOG_UpdateLogData_Or(ReadTargetTable[ulCount].ulAddress_First,
								   ReadTargetTable[ulCount].ulAddress_Second,
								   pulWriteData,
								   pulReadData,
								   &ulWriteCount);
			break;
		case GETTYPE_SPECIAL:
			break;
		default:
			break;
		}
		pulWriteData += ulWriteCount;
		pulReadData  += ulWriteCount;
	}

	vLOG_UpDateReadArea();
	
	return;
}

NX_STATIC NX_VOID vLOG_UpDateReadArea (NX_VOID)
{
	gstLogDataInfo.ulReadArea = (NX_ULONG)1 & ~gstLogDataInfo.ulReadArea;
	return;
}

NX_STATIC NX_VOID vLOG_UpdateLogData_Over (
	NX_ULONG	ulAddress_First,
	NX_ULONG	ulAddress_Second,
	NX_ULONG*	pulWriteData,
	NX_ULONG*	pulWriteCount
)
{
	if (ulAddress_Second != NOADDRESS) {
		vNX_vDisableDispatch();
		*pulWriteData = *(NX_ULONG*)ulAddress_First;
		pulWriteData++;
		*pulWriteData = *(NX_ULONG*)ulAddress_Second;
		vNX_vEnableDispatch();
		*pulWriteCount = WRITE_FIRST_SECOND;
	}
	else {
		*pulWriteData = *(NX_ULONG*)ulAddress_First;
		*pulWriteCount = WRITE_FIRST;
	}
	return;
}

NX_STATIC NX_VOID vLOG_UpdateLogData_Add (
	NX_ULONG	ulAddress_First,
	NX_ULONG	ulAddress_Second,
	NX_ULONG*	pulWriteData,
	NX_ULONG*	pulReadData,
	NX_ULONG*	pulWriteCount
)
{
	if (ulAddress_Second != NOADDRESS) {
		vNX_vDisableDispatch();
		*pulWriteData = *(NX_ULONG*)ulAddress_First;
		pulWriteData++;
		*pulWriteData = *(NX_ULONG*)ulAddress_Second;
		vNX_vEnableDispatch();
		*pulWriteCount = WRITE_FIRST_SECOND;
	}
	else {
		*pulWriteData = (*(NX_ULONG*)ulAddress_First) + *pulReadData;
		*pulWriteCount = WRITE_FIRST;
	}
	return;
}

NX_STATIC NX_VOID vLOG_UpdateLogData_Or (
	NX_ULONG	ulAddress_First,
	NX_ULONG	ulAddress_Second,
	NX_ULONG*	pulWriteData,
	NX_ULONG*	pulReadData,
	NX_ULONG*	pulWriteCount
)
{
	if (ulAddress_Second != NOADDRESS) {
		vNX_vDisableDispatch();
		*pulWriteData = (*(NX_ULONG*)ulAddress_First) | *pulReadData;
		pulWriteData++;
		*pulWriteData = (*(NX_ULONG*)ulAddress_Second) | *pulReadData;
		vNX_vEnableDispatch();
		*pulWriteCount = WRITE_FIRST_SECOND;
	}
	else {
		*pulWriteData = (*(NX_ULONG*)ulAddress_First) | *pulReadData;
		*pulWriteCount = WRITE_FIRST;
	}
	return;
}
