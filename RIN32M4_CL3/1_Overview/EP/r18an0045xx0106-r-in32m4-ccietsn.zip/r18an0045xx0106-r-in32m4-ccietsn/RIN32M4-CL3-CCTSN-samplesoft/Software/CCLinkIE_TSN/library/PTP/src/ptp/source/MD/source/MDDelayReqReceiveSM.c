/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDDelayReqReceiveSM.h"

#ifdef	PTP_USE_IEEE1588
#include "MDDelayReqReceiveSM_1588.h"
#endif


VOID MDDelayReqReceiveSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDDelayReqReceiveSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM, PTP_LOGVE_82000002);
	return;
}

MDDREQRVSM_GD* GetMDDReqRcvSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDDReqRcvSM_GD;
}

MDDREQRCVSM_EV GetMDDReqRcvEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDDREQRCVSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDDRQR_E_BEGIN;
		break;
		case PTP_EV_RCVD_DELAY_REQ:
			enEvt = MDDRQR_E_RCVD_DELAY_REQ;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDDRQR_E_CLOSE;
		break;

		default:
			enEvt = MDDRQR_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDDREQRCVSM_ST GetMDDReqRcvStatus(PORTDATA* pstPort)
{
	MDDREQRVSM_GD*	pstGbl = NULL;
	MDDREQRCVSM_ST	enSts = MDDRQR_STATUS_MAX;

	pstGbl = GetMDDReqRcvSMGlobal(pstPort);
	if (pstGbl->enStsMDDReqRcv < MDDRQR_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDDReqRcv;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQRECEIVESM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDDReqRcvStatus(MDDREQRCVSM_ST enSts, PORTDATA* pstPort)
{
	MDDREQRVSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDReqRcvSMGlobal(pstPort);

	pstGbl->enStsMDDReqRcv = enSts;
	return;
}

BOOL SetMDDlyReqEvIngresTimestamp(MDDREQRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstPortGD->stDelayReqIngressTimestamp,
			&pstSmGbl->stIngMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortGD->stDelayReqIngressTimestamp, 0L, sizeof(TIMESTAMP));
	}
#ifdef	PTP_USE_ME_HW_ASSIST
	if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive_Frun) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstPortGD->stDelayReqIngressTimestamp_Frun,
			&pstSmGbl->stIngMDTimestampReceive_Frun, sizeof(TIMESTAMP));
	}
	else
	{
		tsn_Wrapper_MemSet(&pstPortGD->stDelayReqIngressTimestamp_Frun, 0L, sizeof(TIMESTAMP));
		blRet = FALSE;
	}
#endif
	return blRet;
}

