/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_OPENCLOSE_API_H__
#define __PTP_OPENCLOSE_API_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"



#ifdef __cplusplus
extern "C" {
#endif
	
typedef	enum	tagENUM_PTPAPI_SUPPORT
{
	PTP_APISUPPORT_1AS = 0,
	PTP_APISUPPORT_1588,
	PTP_APISUPPORT_1AS_1588

}	ENUM_PTPAPI_SUPPORT;

typedef struct tagPTP_API_CLOCKSM
{
	UCHAR		uchSMname[32];
	VOID		(*pfnFuncClock)(USHORT usEvent, CLOCKDATA* pstClockData);
	ENUM_PTPAPI_SUPPORT	enSupportPTPType;

}	PTP_API_CLOCKSM;

typedef struct tagPTP_API_PORTSM
{
	UCHAR		uchSMname[32];
	VOID		(*pfnFuncPort)(USHORT usEvent, PORTDATA* pstPort);
	ENUM_PTPAPI_SUPPORT	enSupportPTPType;

}	PTP_API_PORTSM;

#ifdef __cplusplus
}
#endif


#endif
