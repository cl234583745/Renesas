/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_IEEE802_1

#include "ptp_PSSSend.h"
#include "ptp_CSSync_1AS.h"
#include "ptp_SSSync_1AS.h"

#define D_FUNC	0
#define D_DBG	0


VOID	SSSync_1AS_00(CLOCKDATA*	pstClockData);
VOID	SSSync_1AS_01(CLOCKDATA*	pstClockData);
VOID	SSSync_1AS_02(CLOCKDATA*	pstClockData);
PORTSYNCSYNC*  setPSSyncSend_1AS(PORTSYNCSYNC*	pstRcvdPSSyncPtr, CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
VOID	txPSSync_1AS(PORTSYNCSYNC*	pstTxPSSyncPtr,	PORTDATA*	pstPortData);
VOID	txPSSyncToCSS_1AS(PORTSYNCSYNC*	pstTxPSSyncPtr,	CLOCKDATA*	pstClockData);





VOID (*const pfnSSSyncMatrix[ST_SSS_MAX][EV_SSS_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&SSSync_1AS_01, &SSSync_1AS_01, &SSSync_1AS_00},
	{&SSSync_1AS_01, &SSSync_1AS_02, &SSSync_1AS_00},
	{&SSSync_1AS_01, &SSSync_1AS_02, &SSSync_1AS_00}
};



VOID	siteSyncSync_1AS(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_SSS	enEvt = EV_SSS_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("SSSyncSM_1AS   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.enStatusSSS);
}
#endif
		enEvt = GetSSSyncSM_1AS_Event(usEvent, pstClockData);
		if((pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.blRcvdPSSync == FALSE) &&
							((enEvt != EV_SSS_BEGIN) && (enEvt != EV_SSS_CLOSE)))
		{
			return;
		}

		blSts = IsSSSyncSM_1AS_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_SSS_EVENT_MAX))
		{
			(*pfnSSSyncMatrix[pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.enStatusSSS][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_SSSYNCSM_1AS, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.blRcvdPSSync	= FALSE;
		}

	}
}




SSSYNCSM_1AS_GD*	GetSSSyncSM_1AS_GD(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb = &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD);
	return pstSSSGlb;
}




EN_EV_SSS	GetSSSyncSM_1AS_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb			= GetSSSyncSM_1AS_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	EN_EV_SSS			enEvt					= EV_SSS_EVENT_MAX;


	pstRcvdPSSyncPtr = pstSSSGlb->pstRcvdPSSyncPtr;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_SSS_BEGIN;
			break;

		case PTP_EV_FOR_STSYNSYN_RCVSYNC:
			if ((pstSSSGlb->blRcvdPSSync) &&
				(pstClockData->stClock_GD.enSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber] == ENUM_PORTSTATE_SLAVE) &&
				(pstClockData->stClock_GD.blGmPresent))
			{
				enEvt = EV_SSS_FOR_STSYNSYN_RCVSYNC;
			}
			else
			{
				if (pstRcvdPSSyncPtr->usLocalPortNumber != 0)
				{
					PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_SSSYNCSM_1AS, PTP_LOGVE_84000004);
				}
				pstSSSGlb->blRcvdPSSync	= FALSE;
			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_SSS_CLOSE;
			break;

		default:
			enEvt = EV_SSS_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsSSSyncSM_1AS_Status(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb	= GetSSSyncSM_1AS_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstSSSGlb->enStatusSSS < ST_SSS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	SSSync_1AS_00(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb = GetSSSyncSM_1AS_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "SSSync_1AS_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstSSSGlb->blRcvdPSSync	= FALSE;
	pstSSSGlb->enStatusSSS	= ST_SSS_NONE;

	ptp_dbg_msg( D_FUNC, ("SSSync_1AS_00::-\n") );
}




VOID	SSSync_1AS_01(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb = GetSSSyncSM_1AS_GD(pstClockData);


	pstSSSGlb->blRcvdPSSync	= FALSE;
	pstSSSGlb->enStatusSSS	= ST_SSS_INITIALIZING;
}




VOID	SSSync_1AS_02(
	CLOCKDATA*	pstClockData)
{
	SSSYNCSM_1AS_GD*	pstSSSGlb			= GetSSSyncSM_1AS_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= NULL;
	PORTSYNCSYNC*		pstTxPSSyncPtr		= NULL;
	PORTDATA*			pstPdelay_Port		= NULL;

	if (pstSSSGlb->pstRcvdPSSyncPtr->usLocalPortNumber != 0U)
	{
		pstPdelay_Port = GetPdelayPort_1AS(pstClockData, pstSSSGlb->pstRcvdPSSyncPtr->usLocalPortNumber);
	}

	ptp_dbg_msg(D_FUNC,
		("%s::domain=[%d]\n",
			"SSSync_1AS_02+",
			pstClockData->stDefaultDS.uchDomainNumber
			));

	pstRcvdPSSyncPtr = pstSSSGlb->pstRcvdPSSyncPtr;
	pstPortData = pstClockData->pstPortData;
	pstSSSGlb->blRcvdPSSync	= FALSE;

	pstSSSGlb->blCumulativeRateRatioValid = TRUE;

	if (pstPdelay_Port != NULL)
	{
		if (pstSSSGlb->dbRcvdCumulativeRateRatio == (DOUBLE)1.0)
		{
			if ((tsn_Wrapper_MemCmp(&pstClockData->stParentDS.stGrandmasterIdentity
				 ,&pstPdelay_Port->stPort_GD.pstPdlyIntStackMan->stStackClockIdentity
					, sizeof(CLOCKIDENTITY))))
			{
				pstSSSGlb->blCumulativeRateRatioValid = FALSE;
			}
		}

		if (pstPdelay_Port->stPort_GD.pstPdlyIntStackMan->uchStackCountSameClock < pstPdelay_Port->pstClockData->stClock_GD.uchRateCalDatNum)
		{
			SSSYNCSM_1AS_GD* pstSSSGlb = GetSSSyncSM_1AS_GD(pstClockData);

			pstSSSGlb->blCumulativeRateRatioValid = FALSE;
		}
	}

	while (pstPortData != NULL)
	{
		ptp_dbg_msg(D_DBG,
			("port=[%d] blPortValid=[%d] stat={%d]\n",
				pstPortData->stPortDS.stPortIdentity.usPortNumber,
				pstPortData->stPort_GD.blPortValid,
				pstClockData->stClock_GD.enSelectedState[pstPortData->stPortDS.stPortIdentity.usPortNumber]
				));

		if (pstPortData->stPort_GD.blPortValid == TRUE)
		{
			if (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER)
			{
				pstTxPSSyncPtr = setPSSyncSend_1AS(pstRcvdPSSyncPtr, pstClockData, pstPortData);
				pstPortData->stPort_GD.chParentLogSyncInterval = pstTxPSSyncPtr->chLogMessageInterval;
				txPSSync_1AS(pstTxPSSyncPtr, pstPortData);
			}
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	pstPortData = NULL;
	pstTxPSSyncPtr = setPSSyncSend_1AS(pstRcvdPSSyncPtr, pstClockData, pstPortData);
	txPSSyncToCSS_1AS(pstTxPSSyncPtr, pstClockData);

	pstSSSGlb->enStatusSSS	= ST_SSS_RECEIVING_SYNC;

	ptp_dbg_msg(D_FUNC, ("SSSync_1AS_02::-\n"));

}




PORTSYNCSYNC*  setPSSyncSend_1AS(
	PORTSYNCSYNC*	pstRcvdPSSyncPtr,
	CLOCKDATA*		pstClockData,
	PORTDATA*		pstPortData)
{
	PORTSYNCSYNC*		pstTxPSSyncPtr	= NULL;


	if (pstPortData == NULL)
	{
		pstTxPSSyncPtr						= &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD.stRcvdPSSyncDat);
		pstTxPSSyncPtr->usLocalPortNumber	= pstRcvdPSSyncPtr->usLocalPortNumber;
	}
	else
	{
		pstTxPSSyncPtr						= &(pstPortData->stPSSSendSM_GD.stRcvdPSSync);
		pstTxPSSyncPtr->usLocalPortNumber	= pstRcvdPSSyncPtr->usLocalPortNumber;
	}

	pstTxPSSyncPtr->uchClockNumber				= pstRcvdPSSyncPtr->uchClockNumber;
	pstTxPSSyncPtr->stSyncReceiptTimeoutTime	= pstRcvdPSSyncPtr->stSyncReceiptTimeoutTime;
	pstTxPSSyncPtr->stFollowUpCorrectionField	= pstRcvdPSSyncPtr->stFollowUpCorrectionField;
	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdPSSyncPtr->stSourcePortIdentity;
	pstTxPSSyncPtr->chLogMessageInterval		= pstRcvdPSSyncPtr->chLogMessageInterval;
	pstTxPSSyncPtr->stPreciseOriginTimestamp	= pstRcvdPSSyncPtr->stPreciseOriginTimestamp;
	pstTxPSSyncPtr->stUpstreamTxTime			= pstRcvdPSSyncPtr->stUpstreamTxTime;
	pstTxPSSyncPtr->dbRateRatio					= pstRcvdPSSyncPtr->dbRateRatio;

	pstTxPSSyncPtr->usGmTimeBaseIndicator		= pstClockData->stClock_GD.usCurMasterTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange			= pstClockData->stClock_GD.stCurMasterLastPhaseChange;
	pstTxPSSyncPtr->dbLastGmFreqChange			= pstClockData->stClock_GD.dbCurMasterLastFreqChange;

	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdPSSyncPtr->stSourcePortIdentity;

	return pstTxPSSyncPtr;

}





VOID  txPSSync_1AS(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	PORTDATA*		pstPortData)
{
	USHORT		usEvent = PTP_EV_BASE;

	ptp_dbg_msg(D_FUNC, ("txPSSync_1AS::+\n"));

	pstPortData->stPSSSendSM_GD.pstRcvdPSSyncPtr = pstTxPSSyncPtr;
	pstPortData->stPSSSendSM_GD.blRcvdPSSync	 = TRUE;

	usEvent = PTP_EV_FOR_PORTSYNSYNSD_RVPSYNC;
	portSyncSyncSend(usEvent, pstPortData);

	ptp_dbg_msg(D_FUNC, ("txPSSync_1AS::-\n"));
}




VOID	txPSSyncToCSS_1AS(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	CLOCKDATA*		pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSyncSM_1AS_GD	= &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD);
	USHORT				usEvent				= PTP_EV_BASE;


	pstCSSyncSM_1AS_GD->pstRcvdPSSyncPtr	= pstTxPSSyncPtr;
	pstCSSyncSM_1AS_GD->blRcvdPSSync		= TRUE;


	usEvent = PTP_EV_FOR_CLKSLVSYN_RVPSYNC ;
	clockSlaveSync_1AS(usEvent, pstClockData);

}



#endif

