/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_rxn.h"
#include "TOOL_api.h"
#include "INTR_api.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "INTR_common.h"



NX_VOID vINTR_CycRcvP01 (NX_VOID);
NX_VOID vINTR_CycRcvP02 (NX_VOID);



NX_ULONG gulIntRxnErrCount = 0;
NX_ULONG gulIntRxnCount = 0;






NX_ULONG ulINTR_CheckIntLowRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_RN->R_RNINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntLowRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_RN->R_RNINT.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntRxnCount |= ulCountTarget;
	}
	NGN_RN->R_RNINT.DATA = ulCheckTarget;
	return;
}



NX_ULONG ulINTR_CheckIntHighRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_RN->R_RNINTE.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntHighRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_RN->R_RNINTE.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntRxnErrCount |= ulCountTarget;
	}
	NGN_RN->R_RNINTE.DATA = ulCheckTarget;
	return;
}




