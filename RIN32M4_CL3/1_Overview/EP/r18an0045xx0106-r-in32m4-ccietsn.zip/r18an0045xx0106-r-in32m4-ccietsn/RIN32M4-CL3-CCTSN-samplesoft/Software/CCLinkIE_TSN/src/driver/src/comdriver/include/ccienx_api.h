/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_API_H_INCLUDE__
#define __CCIENX_API_H_INCLUDE__
#include "ccienx_type.h"
#include "ccienx_struct.h"

NX_VOID			vNX_CcienxInit(NX_VOID);
NX_VOID			vNX_GetCyclicRcvSts(NX_CYC_RCV_STS*);
NX_VOID			vNX_GetCyclicTrnSts(NX_CYC_TRN_STS*);
NX_VOID			vNX_UpdateDiagnosisData (NX_USHORT);
NX_VOID			vNX_FinishTrnCycData(NX_VOID);
NX_USHORT		usNX_CheckCycExeTmg (NX_VOID);
NX_VOID			vNX_SyncSwitchSwReadSide(NX_VOID);
NX_VOID			vNX_GetSyncCyclicRcvSts(NX_CYC_RCV_STS*);
NX_VOID			vNX_SetClockOffset(NX_LONGLONG, NX_LONG, NX_SHORT, NX_SHORT);
NX_VOID			vNX_GetClockOffset(NX_LONGLONG*, NX_LONG*, NX_SHORT*, NX_SHORT*);	
NX_ULONG		ulNX_GetClockOffsetRecvFlag (NX_VOID);
NX_ULONG		ulNX_GetCycSendSts (NX_VOID);
NX_ULONG		ulNX_GetTopology (NX_VOID);
NX_VOID			vNX_SetNetworkClock(NX_UCHAR*);
NX_ULONG		ulNX_GetOutOfTimeSyncSts (NX_VOID);
NX_VOID			vNX_SetRunLed(NX_USHORT);
NX_VOID			vNX_SetDlinkLed(NX_USHORT);
NX_VOID			vNX_SetErrLed(NX_USHORT);
NX_VOID			vNX_UpdateLed (NX_VOID);
NX_ULONG		lNX_GetRunLedStatus (NX_VOID);
NX_ULONG		lNX_GetErrLedStatus (NX_VOID);
NX_ULONG		lNX_GetDlinkLedStatus (NX_VOID);
NX_ULONG		lNX_GetUser1LedStatus (NX_VOID);
NX_ULONG		lNX_GetUser2LedStatus (NX_VOID);
NX_ULONG		lNX_GetSdSdrd1LedStatus (NX_VOID);
NX_ULONG		lNX_GetRdSdrd2LedStatus (NX_VOID);
NX_ULONG		lNX_GetLER1LedStatus (NX_VOID);
NX_ULONG		lNX_GetLER2LedStatus (NX_VOID);
NX_ULONG		ulNX_ChkCycRcvNoData ( NX_VOID );
NX_USHORT		usNX_GetSlmpAppFrame(NX_TRN_RCV_INFO*);
NX_USHORT		usNX_ReleaseSlmpAppFrame(NX_VOID);
NX_USHORT		usNX_SetSlmpFrame(NX_TRN_SND_INFO*);
NX_VOID			vNX_CtrlSystemReset(NX_USHORT);
NX_VOID			vNX_InitWdt(NX_ULONG);
NX_VOID			vNX_StartWdt(NX_VOID);
NX_VOID			vNX_StopWdt(NX_VOID);
NX_VOID			vNX_ClearWdt(NX_VOID);
NX_VOID			vNX_vDisableDispatch(NX_VOID);
NX_VOID			vNX_vEnableDispatch(NX_VOID);
NX_VOID			vNX_vDisableInterrupt(NX_VOID);
NX_VOID			vNX_vEnableInterrupt(NX_VOID);
NX_USHORT		usNX_CnvEndianShort(NX_USHORT);
NX_ULONG		ulNX_CnvEndianLong(NX_ULONG);
NX_ULONGLONG	ullNX_CnvEndianLongLong(NX_ULONGLONG);
NX_VOID			vNX_CnvEndian6Byte(NX_UCHAR*, NX_UCHAR*);
NX_LONG			lNX_CompareMemory(NX_VOID*, NX_VOID*,NX_ULONG);
NX_VOID			vNX_CopyMemory(NX_VOID*, NX_VOID*, NX_ULONG);
NX_VOID			vNX_CopyMemory16(NX_VOID*, NX_VOID*, NX_ULONG);
NX_VOID			vNX_CopyMemory32(NX_VOID*, NX_VOID*, NX_ULONG);
NX_VOID			vNX_FillMemory(NX_VOID*, NX_CHAR, NX_ULONG);
NX_VOID			vNX_FillMemory16(NX_VOID*, NX_SHORT, NX_ULONG);
NX_VOID			vNX_FillMemory32(NX_VOID*, NX_LONG, NX_ULONG);
NX_ULONG		ulNX_GetLifeTime (NX_VOID);
NX_ULONG		ulNX_WaitLifeTime (NX_ULONG, NX_ULONG);
NX_VOID			vNX_GetUnixTime (NX_UNIX_TIME*);
NX_VOID			vNX_CnvUnixTimeToCalendar (NX_UNIX_TIME*, NX_CALENDAR*);

NX_ULONG		ulNX_ChkIpAddress (NX_ULONG, NX_ULONG);

NX_VOID			vNX_SNMP_Main(NX_VOID);
NX_ULONG		ulNX_SetMibCurrentErr(NX_VOID* pvData);
NX_VOID			vNX_DelMibCurrentErr(NX_VOID);
#ifdef CURERR_OPTIONINFO_ENABLE
NX_VOID			vNX_DelMibCurrentErrController(NX_VOID);
NX_ULONG		ulNX_SetMibCurrentErrOption(NX_VOID* pvData, NX_USHORT usIndexNum);
NX_ULONG		ulNX_SetMibCurrentErrOptionInit(NX_VOID* pvData, NX_USHORT usIndexNum);
NX_ULONG		ulNX_DelMibCurrentErrOption(NX_USHORT usIndexNum);
#endif

NX_USHORT		usNX_StopAppSyncSig (NX_VOID);

NX_VOID			vNX_TxnMainClassA(NX_USHORT);
#endif
/*[EOF]*/
