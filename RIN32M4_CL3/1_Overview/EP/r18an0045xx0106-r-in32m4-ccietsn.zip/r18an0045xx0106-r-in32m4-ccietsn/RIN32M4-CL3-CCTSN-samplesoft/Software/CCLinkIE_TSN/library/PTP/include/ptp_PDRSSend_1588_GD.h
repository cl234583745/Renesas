/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRSSEND_1588_GD_H__
#define __PTP_PDRSSEND_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PDRSS {
	ST_PDRSS_NONE	= 0,
	ST_PDRSS_TRANSMIT_INIT,
	ST_PDRSS_SEND_MD_DELAYRESP,
	ST_PDRSS_MAX
} EN_ST_PDRSS;


typedef	enum	tagEN_EV_PDRSS {
	EV_PDRSS_BEGIN = 0,
	EV_PDRSS_FOR_PDLRSSND_RCVMDDLRS,
	EV_PDRSS_CLOSE,
	EV_PDRSS_EVENT_MAX
} EN_EV_PDRSS;


typedef	struct tagPDRSSENDSM_1588_GD
{
	EN_ST_PDRSS		enStatusPDRSS;
	BOOL			blRcvdMDDelayResp;
	MDDELAYRESP*	pstRcvdMDDRespRcvPtr;
	MDDELAYRESP*	pstTxMDDRespSndPtr;
} PDRSSENDSM_1588_GD;	



#endif


