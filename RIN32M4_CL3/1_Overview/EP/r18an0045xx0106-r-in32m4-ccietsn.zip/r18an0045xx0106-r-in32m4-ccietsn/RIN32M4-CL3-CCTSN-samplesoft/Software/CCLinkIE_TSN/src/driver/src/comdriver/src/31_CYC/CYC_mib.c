/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "CYC_common.h"
#include "NMG_common.h"
#include "NGN_ASIC.h"

#define	CYCMIB_CYCSTOP_NORMAL		((NX_UCHAR)0x00)
#define	CYCMIB_CYCSTOP_DISCONNECT	((NX_UCHAR)0x02)
#define	CYCMIB_CYCSTOP_RSVSTA		((NX_UCHAR)0x12)
#define	CYCMIB_CYCSTOP_CYCSTOPREQ	((NX_UCHAR)0x01)

NX_UCHAR uchCYC_GetCyclicStopInfo ( NX_VOID )
{
	NX_UCHAR	uchCycStop	=	(NX_UCHAR)NX_ZERO;
	
	
	if (gstNM.stNet.usNetSts != NETSTS_DLINK) {
		
		if (gstNET.stCyc.usEstComOnce == (NX_USHORT)NX_ON) {
			
			uchCycStop = CYCMIB_CYCSTOP_DISCONNECT;
		}
		else {
			
			uchCycStop = CYCMIB_CYCSTOP_NORMAL;
		}
		
	}
	else {
		
		if (gstNET.stCyc.usRsvSta == NX_ON) {
			
			uchCycStop = CYCMIB_CYCSTOP_RSVSTA;
		}
		else if (gstNET.stCyc.usStopDLink == NX_ON) {
			
			uchCycStop = CYCMIB_CYCSTOP_CYCSTOPREQ;
		}
		else {
			
			uchCycStop = CYCMIB_CYCSTOP_NORMAL;
		}
		
	}
	
	return uchCycStop;
}

NX_UCHAR uchCYC_GetDiagnosisData ( NX_VOID )
{
	return gstCycCtrl.uchSelfDiagData;
}

/*[EOF]*/
