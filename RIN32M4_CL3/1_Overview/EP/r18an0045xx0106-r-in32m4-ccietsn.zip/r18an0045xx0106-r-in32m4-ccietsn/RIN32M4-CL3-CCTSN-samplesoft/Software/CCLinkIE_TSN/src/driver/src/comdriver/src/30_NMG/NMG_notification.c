/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NMG_common.h"
#include "nx_frame_common.h"
#include "nx_frame_notification.h"
#include "SLMP_api.h"
#include "ccienx_api.h"
#include "ccienx_app_supply.h"
#include "TSN_api.h"
#include "NGN_ASIC.h"
#include "CYC_api.h"
#include "TXN_api.h"
#include "ACM_api.h"


#define	NX_NOTIF_NODATA_SIZE_BYTE		((NX_USHORT)0x0010)
#define	NX_NOTIFICATION_COMMAND			((NX_USHORT)0x0E94)
#define	NX_NOTIFICATION_SEND_SERIAL_MIN	((NX_USHORT)0x0000)
#define	NX_NOTIFICATION_SEND_SERIAL_MAX	((NX_USHORT)0xFFFF)
#define	NX_SLMP_WATCH_TIME_DEFAULT		((NX_USHORT)0x0008)
#define	NX_CMM_RQ_FTYPE_0068			((NX_USHORT)(0x0068))
#define	NTF_RCV_CODE_TBL_NUM			((NX_USHORT)3)
#define	NTF_SND_CODE_TBL_NUM			((NX_USHORT)1)
#define	NTF_RELAYSET_PORT12				((NX_USHORT)0)
#define	NTF_CTRL2_UPDATE_NONE			((NX_USHORT)0)
#define	NTF_CTRL2_UPDATE_ON				((NX_USHORT)1)
#define	NTF_CTRL2_UPDATE_OFF			((NX_USHORT)2)
#define	NTF_FLT_CHK_TBL_NUM				((NX_USHORT)4)

typedef NX_VOID (* NTF_REQ_EXTRACT)(NX_VOID*, NX_ULONG*);
typedef NX_VOID (* NTF_RESP_CREATE)(NX_VOID*);
typedef NX_VOID (* NTF_REQ_CREATE)(NX_USHORT, NX_USHORT);

typedef struct tagRCV_NTF_CODE_TBL {
	NX_USHORT				usNotifCode;
	NTF_REQ_EXTRACT			pReqExtractFunc;
	NTF_RESP_CREATE			pRespCreateFunc;
} RCV_NTF_CODE_TBL;

typedef struct tagSND_NTF_CODE_TBL {
	NX_USHORT				usNotifCode;
	NTF_REQ_CREATE			pReqCreateFunc;
} SND_NTF_CODE_TBL;

NX_VOID		vNMG_ChkNotificationReq ( NX_VOID*, NX_ULONG*, NX_USHORT);
NX_VOID		vNMG_ChkNotificationResp ( NX_VOID* );
NX_VOID		vNMG_CreateNotificationRespNrml ( NX_VOID* );
NX_VOID		vNMG_CreateNotificationRespFault ( NX_VOID*, NX_USHORT );
NX_VOID		vNMG_CreateNotificationReq ( NX_USHORT, NX_USHORT );
NX_VOID		vNMG_Extract_Relay ( NX_VOID*, NX_ULONG* );
NX_VOID		vNMG_Extract_BMCA ( NX_VOID*, NX_ULONG* );
NX_VOID		vNMG_Extract_TopologyChangeReq ( NX_VOID*, NX_ULONG*);
NX_VOID		vNMG_RespCreate_None ( NX_VOID* );
NX_VOID		vNMG_RespCreate_BMCA ( NX_VOID* );
NX_VOID		vNMG_ReqCreate_None ( NX_USHORT, NX_USHORT );
NX_VOID		vNMG_ChkCyclicSndCom (NX_UCHAR, NX_UCHAR, NX_USHORT*, NX_USHORT*);

NX_STATIC	NX_CONST	RCV_NTF_CODE_TBL	gastNotifCodeRcvReqTbl[NTF_RCV_CODE_TBL_NUM] = {
	{NTF_CODE_RELAYSET,	vNMG_Extract_Relay,				vNMG_RespCreate_None,	},
	{NTF_CODE_BMCA_CMP,	vNMG_Extract_BMCA,				vNMG_RespCreate_BMCA,	},
	{NTF_CODE_TOPOLOGY,	vNMG_Extract_TopologyChangeReq,	vNMG_RespCreate_None,	},
};

NX_STATIC	NX_CONST	SND_NTF_CODE_TBL	gastNotifCodeSndReqTbl[NTF_SND_CODE_TBL_NUM] = {
	{NTF_CODE_TIMESYNC_CMP,	vNMG_ReqCreate_None		},
};

NX_UCHAR	guchGMChkRslt	= TSN_NOT_STARTED;

NX_STATIC	NX_CONST	NX_USHORT	gausFltChkTbl[NTF_FLT_CHK_TBL_NUM][NTF_FLT_CHK_TBL_NUM] = {
	{NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_OFF,	NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_NONE	},
	{NTF_CTRL2_UPDATE_ON,	NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_ON,	NTF_CTRL2_UPDATE_NONE	},
	{NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_OFF,	NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_NONE	},
	{NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_NONE,	NTF_CTRL2_UPDATE_NONE	}
};

NX_USHORT	gusRelayChkP1	= NTF_CTRL2_UPDATE_NONE;
NX_USHORT	gusRelayChkP2	= NTF_CTRL2_UPDATE_NONE;
NX_STATIC NX_ULONG	gulDiscCtrlSetFlg = (NX_ULONG)NX_OFF;
NX_STATIC NX_ULONG	gulDiscCtrlSetFlgClassA = (NX_ULONG)NX_OFF;

NX_VOID vNMG_AnalyzeNotificationReq (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	NX_ULONG	ulChkResult		= NX_ZERO;
	
	vNMG_ChkNotificationReq(pData, &ulChkResult, usPort);
	
	if (ulChkResult == RESP_NORMAL) {
		vNMG_CreateNotificationRespNrml(pData);
		vNMG_ReqTrnNotificationResp();
	}
	else if (ulChkResult == RESP_ERR) {
		vNMG_CreateNotificationRespFault(pData, CMM_SLMP_MISS_REQDATA);
		vNMG_ReqTrnNotificationResp();
	}
	else if (ulChkResult == RESP_DIV_ERR) {
		vNMG_CreateNotificationRespFault(pData, CMM_SLMP_NOT_SUPP_DIV);
		vNMG_ReqTrnNotificationResp();
	}
	else if (ulChkResult == RESP_NOTHING) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else if (ulChkResult == RESP_DESTRUCT) {
		(NX_VOID)usSLMP_ReleaseSlmpCmnFrame();
	}
	else {
	}

	return;
}

NX_VOID vNMG_AnalyzeNotificationResp (
	NX_USHORT	usPort,
	NX_ULONG	ulIPAddress,
	NX_VOID		*pData
)
{
	vNMG_ChkNotificationResp(pData);
	
	return;
}

NX_VOID vNMG_ChkNotificationReq (
	NX_VOID			*pData,
	NX_ULONG		*pulChkResult,
	NX_USHORT		usPort
)
{
	FRM_NF_REQ_DATA_NONE	*pstFrm;
	NX_USHORT				usLoop =	NX_US_ZERO;

	pstFrm = (FRM_NF_REQ_DATA_NONE*)pData;
	
	if ((pstFrm->uchMsgId			!= (NX_UCHAR)NX_ZERO) ||
		(pstFrm->usDivisionTotalNum	!= (NX_USHORT)NX_ZERO) ||
		(pstFrm->usDivisionId		!= (NX_USHORT)NX_ZERO)) {
		if (pstFrm->usDivisionTotalNum == pstFrm->usDivisionId) {
			*pulChkResult	= RESP_DIV_ERR;
		}
		else {
			*pulChkResult	= RESP_DESTRUCT;
		}
	}
	else {
		for (usLoop = NX_US_ZERO; usLoop < NTF_RCV_CODE_TBL_NUM; usLoop++) {
			if (gastNotifCodeRcvReqTbl[usLoop].usNotifCode == pstFrm->usNtfCode) {
				*pulChkResult = RESP_NORMAL;
				gastNotifCodeRcvReqTbl[usLoop].pReqExtractFunc(pData, pulChkResult);
				if (NTF_CODE_BMCA_CMP == pstFrm->usNtfCode) {
					gstNM.usBMCARcvPort = usPort;
				}
				break;
			}
		}

		if (NTF_RCV_CODE_TBL_NUM == usLoop) {
			*pulChkResult	= RESP_ERR;
		}
	}

	return;
}


NX_VOID vNMG_Extract_Relay (
	NX_VOID		*pData,
	NX_ULONG	*pulChkResult
)
{
	FRM_NF_RELAYSET_REQ	*pstFrm;
	NX_UCHAR			uchNewFltSetP1	= NX_RELAYSETTING_FILTER_NONE;
	NX_UCHAR			uchNewFltSetP2	= NX_RELAYSETTING_FILTER_NONE;
	NGN_CN_RC_TAG		stRelaySetting;
	NX_USHORT			usCycSndPortResult	= NX_US_NG;
	NX_USHORT			usAuthClass 	= (NX_USHORT)NX_AUTHENTICATION_CLS_B;

	*pulChkResult = RESP_NORMAL;
	pstFrm		= (FRM_NF_RELAYSET_REQ*)pData;

	uchNewFltSetP1	= pstFrm->astRelayFilSetting[NTF_RELAYSET_PORT12].b02Filter1;
	uchNewFltSetP2	= pstFrm->astRelayFilSetting[NTF_RELAYSET_PORT12].b02Filter2;

	if (FIN_RCVD_CYCCFG_TRNSPD == (gstNM.stNet.usStatusFinish & FIN_RCVD_CYCCFG_TRNSPD)) {
		usCycSndPortResult	= usNMG_ChkCyclicSnd(uchNewFltSetP1, uchNewFltSetP2);
		if (NX_US_NG == usCycSndPortResult) {
			*pulChkResult = RESP_ERR;
			return;
		}
	}
	else {
	}

	
	vNX_vDisableDispatch();
	vNX_CopyMemory((NX_VOID*)&stRelaySetting.R_RCRLYVL.DATA, (NX_VOID*)&NGN_RC_REG->R_RCRLYVL.DATA, (NX_ULONG)sizeof(NX_ULONG));
	if (uchNewFltSetP1 == NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN) {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt	= (NX_ULONG)NX_ON;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2IEFFilt			= (NX_ULONG)NX_OFF;
	}
	else if (uchNewFltSetP1 == NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN) {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt	= (NX_ULONG)NX_OFF;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2IEFFilt			= (NX_ULONG)NX_ON;
	}
	else {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2BrdMltCastFilt	= (NX_ULONG)NX_OFF;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort2IEFFilt			= (NX_ULONG)NX_OFF;
	}

	if (uchNewFltSetP2 == NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN) {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt	= (NX_ULONG)NX_ON;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1IEFFilt			= (NX_ULONG)NX_OFF;
	}
	else if (uchNewFltSetP2 == NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN) {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt	= (NX_ULONG)NX_OFF;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1IEFFilt			= (NX_ULONG)NX_ON;
	}
	else {
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1BrdMltCastFilt	= (NX_ULONG)NX_OFF;
		stRelaySetting.R_RCRLYVL.BITS.b01ZPort1IEFFilt			= (NX_ULONG)NX_OFF;
	}
	NGN_RC_REG->R_RCRLYVL.DATA = stRelaySetting.R_RCRLYVL.DATA;
	vNX_vEnableDispatch();
	vNMG_UpdateRelaySettingChkRslt(uchNewFltSetP1, uchNewFltSetP2);
	usAuthClass = usACM_GetAuthenticationClass();
	
	if(NX_AUTHENTICATION_CLS_B == usAuthClass) {
		gulDiscCtrlSetFlg	= (NX_ULONG)NX_ON;
	}
	else {
		gulDiscCtrlSetFlgClassA	= (NX_ULONG)NX_ON;
	}

	return;
}

NX_VOID vNMG_Extract_BMCA (
	NX_VOID		*pData,
	NX_ULONG	*pulChkResult
)
{
	NX_ULONG			ulBmcaFinRslt;
	NX_UCHAR			auchMacTemp[NX_MAC_ADDR_SIZE];
	FRM_NF_BMCA_REQ		*pstFrm;
	NX_USHORT	usAuthClass = (NX_USHORT)NX_AUTHENTICATION_CLS_B;
	*pulChkResult = RESP_NORMAL;
	pstFrm = (FRM_NF_BMCA_REQ*)pData;

	usAuthClass = usACM_GetAuthenticationClass();
	if (NX_AUTHENTICATION_CLS_B == usAuthClass) {
		vNX_CnvEndian6Byte(&auchMacTemp[NX_ZERO], &pstFrm->auchGmMac[NX_ZERO]);
		ulBmcaFinRslt	= ulTsn_Notify_BMCAFinished((NX_UCHAR*)auchMacTemp);

		if ( TSN_NOT_STARTED == ulBmcaFinRslt ) {
			*pulChkResult	= RESP_DESTRUCT;
		}else {
			guchGMChkRslt	= (NX_UCHAR)ulBmcaFinRslt;
		}
	}
	else{
		*pulChkResult	= RESP_DESTRUCT;
	}

	return;
}

NX_VOID vNMG_Extract_TopologyChangeReq (
	NX_VOID		*pData,
	NX_ULONG	*pulChkResult
)
{
	*pulChkResult = RESP_NOTHING;
	return;	
}

NX_LONG lNMG_Set_SndDiscCtrlArea ( NX_VOID )
{
	NX_LONG				lRet	= (NX_LONG)NX_OFF;
	ASIC_RTNDIS1_Bits*	pstTnDescNo0_1	= NX_NULL;
	ASIC_RTNDIS2_Bits*	pstTnDescNo0_2	= NX_NULL;
	ASIC_RTNDIS1_Bits*	pstTnDescNo1_1	= NX_NULL;
	ASIC_RTNDIS2_Bits*	pstTnDescNo1_2	= NX_NULL;
	NX_USHORT			usDescriptor0	= NX_US_ZERO;
	NX_USHORT			usDescriptor1	= NX_US_ZERO;
	NX_USHORT			usEnableNum		= NX_US_ZERO;
	NX_ULONG			ulMultiChk;
	ASIC_RTNDIS1_Bits*	pstPreTnDescNo0_1	= NX_NULL;
	ASIC_RTNDIS1_Bits*	pstPreTnDescNo1_1	= NX_NULL;
	NX_USHORT			usTrnDescNo			= (NX_USHORT)NX_ZERO;

	if (gulDiscCtrlSetFlg == (NX_ULONG)NX_ON) {

		ulMultiChk = vNMG_ChkMacAddrBrdMlt_LtEd( (NX_UCHAR*)gstNET.stCyc.stTrnSubPayL[PDUDISC_NO].auchDestFrame );
	
		if (NX_MAC_BRDMLTCAST == ulMultiChk) {
			if ((NTF_CTRL2_UPDATE_NONE != gusRelayChkP1)
			 || (NTF_CTRL2_UPDATE_NONE != gusRelayChkP2)) {

				lRet = (NX_LONG)NX_ON;
				vNMG_GetPortSndDescriptor( gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1,
										   gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2,
										   &usDescriptor0,
										   &usDescriptor1,
										   &usEnableNum );

				if ((NX_USHORT)NX_TWO == usEnableNum) {
					pstTnDescNo0_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
					pstTnDescNo0_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis2.BITS;
					pstTnDescNo1_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis1.BITS;
					pstTnDescNo1_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1].ASIC_rtndis2.BITS;

					pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO1;
					pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;

					if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
						pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
						pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
					}
					else {
						pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
						pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
					}

					pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
					pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;

					if ((NX_USHORT)NX_PORT1 == usDescriptor1) {
						pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
						pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
					}
					else {
						pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
						pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
					}
				}
				else if ((NX_USHORT)NX_ONE == usEnableNum){
					pstTnDescNo0_1		= (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis1.BITS;
					pstTnDescNo0_2		= (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0].ASIC_rtndis2.BITS;

					pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
					pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;

					if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
						pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
						pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
					}
					else {
						pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
						pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
					}
				}
				else {
				}

				for (usTrnDescNo = (NX_USHORT)NX_TWO; usTrnDescNo < gstNET.stCyc.usTrnFrameNum; usTrnDescNo += (NX_USHORT)NX_TWO) {
					pstPreTnDescNo0_1 = pstTnDescNo0_1;
					pstPreTnDescNo1_1 = pstTnDescNo1_1;
					pstTnDescNo0_1    = (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0 + usTrnDescNo].ASIC_rtndis1.BITS;
					pstTnDescNo0_2    = (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO0 + usTrnDescNo].ASIC_rtndis2.BITS;
					pstTnDescNo1_1    = (ASIC_RTNDIS1_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1 + usTrnDescNo].ASIC_rtndis1.BITS;
					pstTnDescNo1_2    = (ASIC_RTNDIS2_Bits*)&NGN_CN_TNDIS_REG->R_TNDIS[TRNDISC_NO1 + usTrnDescNo].ASIC_rtndis2.BITS;

					if ((NX_USHORT)NX_TWO == usEnableNum) {
						pstPreTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
						pstPreTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;

						pstTnDescNo0_1->b0BZSndDiscriptNextNo		= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo + NX_ONE);
						pstTnDescNo0_1->b01ZSndDiscriptEndFlag		= (NX_ULONG)NX_OFF;

						if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
							pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
							pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
						}
						else {
							pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
							pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
						}
	
						pstTnDescNo1_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
						pstTnDescNo1_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;
	
						if ((NX_USHORT)NX_PORT1 == usDescriptor1) {
							pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
							pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
						}
						else {
							pstTnDescNo1_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
							pstTnDescNo1_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
						}
					}
					else if ((NX_USHORT)NX_ONE == usEnableNum){
						pstPreTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)(TRNDISC_NO0 + usTrnDescNo);
						pstPreTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_OFF;

						pstTnDescNo0_1->b0BZSndDiscriptNextNo	= (NX_ULONG)TRNDISC_NO_NXT;
						pstTnDescNo0_1->b01ZSndDiscriptEndFlag	= (NX_ULONG)NX_ON;

						if ((NX_USHORT)NX_PORT1 == usDescriptor0) {
							pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_ON;
							pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_OFF;
						}
						else {
							pstTnDescNo0_2->b01ZSndFramePort1	= (NX_ULONG)NX_OFF;
							pstTnDescNo0_2->b01ZSndFramePort2	= (NX_ULONG)NX_ON;
						}
					}
					else {
					}
				}
			}
		}
		
		gulDiscCtrlSetFlg	= (NX_ULONG)NX_OFF;
	}

	return lRet;
}

NX_VOID vNMG_GetSettingValueSndDiscClassA ( NX_VOID )
{
	NX_USHORT			usDescriptor0	= NX_US_ZERO;
	NX_USHORT			usDescriptor1	= NX_US_ZERO;
	NX_USHORT			usEnableNum		= NX_US_ZERO;
	NX_ULONG			ulMultiChk		= NX_MAC_UNICAST;
	
	if((NX_ULONG)NX_ON == gulDiscCtrlSetFlgClassA) {
		
		ulMultiChk = vNMG_ChkMacAddrBrdMlt_LtEd( (NX_UCHAR*)gstNET.stCyc.stTrnSubPayL[NX_ZERO].auchDestFrame );

		if (NX_MAC_BRDMLTCAST == ulMultiChk) {
			
			if ((NTF_CTRL2_UPDATE_NONE != gusRelayChkP1)
			 || (NTF_CTRL2_UPDATE_NONE != gusRelayChkP2)) {
				
				vNMG_GetPortSndDescriptor( gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1,
										   gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2,
										   &usDescriptor0,
										   &usDescriptor1,
										   &usEnableNum );
				
				gstClassAInfo.usDescriptor0 = usDescriptor0;
				gstClassAInfo.usDescriptor1 = usDescriptor1;
				gstClassAInfo.usDiscEnableNum = usEnableNum;
			}
		}
		gulDiscCtrlSetFlgClassA = (NX_ULONG)NX_OFF;
	}
	return;
}

NX_VOID vNMG_ChkNotificationResp (
	NX_VOID		*pData
)
{
	FRM_NF_RES_DATA_NONE	*pstFrm;

	pstFrm = (FRM_NF_RES_DATA_NONE*)pData;

	if (gstNM.stWchNtfResp.usSndSerial	== pstFrm->stSlmpHead.usSerialNo) {
	}
	else {
	}
	
	return;
}

NX_VOID vNMG_CreateNotificationRespNrml (
	NX_VOID			*pData
)
{
	FRM_NF_REQ_DATA_NONE	*pstReq;
	NX_USHORT				usLoop =	NX_US_ZERO;

	pstReq	= (FRM_NF_REQ_DATA_NONE*)pData;

	for (usLoop = NX_US_ZERO; usLoop < NTF_RCV_CODE_TBL_NUM; usLoop++) {
		if (gastNotifCodeRcvReqTbl[usLoop].usNotifCode == pstReq->usNtfCode) {
			gastNotifCodeRcvReqTbl[usLoop].pRespCreateFunc(pData);
			break;
		}
	}

	return;
}

NX_VOID vNMG_RespCreate_None (
	NX_VOID			*pData
)
{
	FRM_NF_RES_DATA_NONE	*pstResp;
	FRM_NF_REQ_DATA_NONE	*pstReq;

	pstResp	= (FRM_NF_RES_DATA_NONE*)gstNM.stTrnBuf.puchNotificationResp;
	pstReq	= (FRM_NF_REQ_DATA_NONE*)pData;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
							&pstResp->stSlmpHead,
							SLMP_FINISHCODE_NORMAL,
							sizeof(FRM_NF_RES_DATA_NONE)
							 - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero			= NX_ZERO;
	pstResp->uchMsgId				= NX_ZERO;
	pstResp->usDivisionTotalNum		= NX_ZERO;
	pstResp->usDivisionId			= NX_ZERO;

	pstResp->usNtfCode				= pstReq->usNtfCode;

	pstResp->usFixedZero			= NX_ZERO;

	return;
}

NX_VOID vNMG_RespCreate_BMCA (
	NX_VOID			*pData
)
{
	FRM_NF_BMCA_RESP_NORMAL	*pstResp;
	FRM_NF_BMCA_REQ			*pstReq;

	pstResp	= (FRM_NF_BMCA_RESP_NORMAL*)gstNM.stTrnBuf.puchNotificationResp;
	pstReq	= (FRM_NF_BMCA_REQ*)pData;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
							&pstResp->stSlmpHead,
							SLMP_FINISHCODE_NORMAL,
							sizeof(FRM_NF_BMCA_RESP_NORMAL)
							 - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero			= NX_ZERO;
	pstResp->uchMsgId				= NX_ZERO;
	pstResp->usDivisionTotalNum		= NX_ZERO;
	pstResp->usDivisionId			= NX_ZERO;

	pstResp->usNtfCode				= pstReq->usNtfCode;

	pstResp->uchGMChkRslt			= guchGMChkRslt;
	pstResp->uchFixedZero2			= NX_ZERO;

	return;
}

NX_VOID vNMG_CreateNotificationRespFault (
	NX_VOID				*pData,
	NX_USHORT			usFinCode
)
{
	FRM_NF_RESP_ERR			*pstResp;
	FRM_NF_REQ_DATA_NONE	*pstReq;

	pstResp = (FRM_NF_RESP_ERR*)gstNM.stTrnBuf.puchNotificationResp;
	pstReq	= (FRM_NF_REQ_DATA_NONE*)pData;

	vNMG_SetSlmpRespHead6E(	&pstReq->stSlmpHead,
							&pstResp->stSlmpHead,
							usFinCode,
							sizeof(FRM_NF_RESP_ERR)
							 - SLMP_SUBH_TO_DATALEN_SIZE);

	pstResp->uchFixedZero					= NX_ZERO;
	pstResp->uchMsgId						= NX_ZERO;
	pstResp->usDivisionTotalNum				= NX_ZERO;
	pstResp->usDivisionId					= NX_ZERO;

	pstResp->stErrInfo.uchRcvStNetNo		= pstReq->stSlmpHead.uchNetNo;
	pstResp->stErrInfo.uchRcvStStNo			= pstReq->stSlmpHead.uchStNo;
	pstResp->stErrInfo.usUtIONo				= pstReq->stSlmpHead.usUtIONo;
	pstResp->stErrInfo.uchMultiDropStNo		= pstReq->stSlmpHead.uchMultiDropStNo;
	pstResp->stErrInfo.auchRsv2[NX_ZERO]	= pstReq->stSlmpHead.auchRsv2[NX_ZERO];
	pstResp->stErrInfo.usRcvStExStNo		= pstReq->stSlmpHead.usExStNo;

	return;
}

NX_VOID vNMG_CreateNotificationReq (
	NX_USHORT	usSerialNo,
	NX_USHORT	usNotifCode
)
{
	NX_USHORT				usLoop =	NX_US_ZERO;

	for (usLoop = NX_US_ZERO; usLoop < NTF_SND_CODE_TBL_NUM; usLoop++) {
		if (gastNotifCodeSndReqTbl[usLoop].usNotifCode == usNotifCode) {
			gastNotifCodeSndReqTbl[usLoop].pReqCreateFunc(usSerialNo, usNotifCode);
			break;
		}
	}

	return;
}

NX_VOID vNMG_ReqCreate_None (
	NX_USHORT	usSerialNo,
	NX_USHORT	usNotifCode
)
{
	FRM_NF_REQ_DATA_NONE	*pstReq;

	pstReq = (FRM_NF_REQ_DATA_NONE*)gstNM.stTrnBuf.puchNotificationReq;

	pstReq->stSlmpHead.usFrameType		= NX_CMM_RQ_FTYPE_0068;
	pstReq->stSlmpHead.usSerialNo		= usSerialNo;
	pstReq->stSlmpHead.auchRsv1[0]		= NX_ZERO;
	pstReq->stSlmpHead.auchRsv1[1]		= NX_ZERO;
	pstReq->stSlmpHead.uchNetNo			= NX_SET_VAL_RCV_NET_NO;
	pstReq->stSlmpHead.uchStNo			= NX_SET_VAL_RCV_ST_NO;
	pstReq->stSlmpHead.usUtIONo			= NX_SET_VAL_UNIT_IO_NO;
	pstReq->stSlmpHead.uchMultiDropStNo	= NX_SET_VAL_MULTIDROP_ST_NO;
	pstReq->stSlmpHead.auchRsv2[0]		= NX_ZERO;
	pstReq->stSlmpHead.usExStNo			= NX_SET_VAL_RCV_EX_ST_NO;
	pstReq->stSlmpHead.usDataBSize		= NX_NOTIF_NODATA_SIZE_BYTE;
	pstReq->stSlmpHead.usWatchTime		= NX_SLMP_WATCH_TIME_DEFAULT;
	pstReq->stSlmpHead.usCmd			= NX_NOTIFICATION_COMMAND;
	pstReq->stSlmpHead.usSubCmd			= NX_ZERO;

	pstReq->uchFixedZero				= NX_ZERO;
	pstReq->uchMsgId					= NX_ZERO;
	pstReq->usDivisionTotalNum			= NX_ZERO;
	pstReq->usDivisionId				= NX_ZERO;
	pstReq->usNtfCode					= usNotifCode;

	pstReq->usFixedZero					= NX_ZERO;

	return;
}

NX_VOID vNMG_PreparSndNotificationReq (
	NX_USHORT	usNotifCode
)
{
	if (NX_NOTIFICATION_SEND_SERIAL_MAX != gstNM.stWchNtfResp.usSndSerial) {
		gstNM.stWchNtfResp.usSndSerial++;
	}
	else {
		gstNM.stWchNtfResp.usSndSerial = NX_NOTIFICATION_SEND_SERIAL_MIN;
	}

	vNMG_CreateNotificationReq(gstNM.stWchNtfResp.usSndSerial, usNotifCode);
	vNMG_ReqTrnNotificationReq();


	return;
}

NX_VOID vNMG_UpdateRelaySettingChkRslt (
	NX_UCHAR	uchFltSetP1,
	NX_UCHAR	uchFltSetP2
)
{
	NX_UCHAR	uchLastFltSetP1	= NX_RELAYSETTING_FILTER_NONE;
	NX_UCHAR	uchLastFltSetP2	= NX_RELAYSETTING_FILTER_NONE;

	uchLastFltSetP1	= gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1;
	uchLastFltSetP2	= gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2;

	gusRelayChkP1	= gausFltChkTbl[uchLastFltSetP1][uchFltSetP1];
	gusRelayChkP2	= gausFltChkTbl[uchLastFltSetP2][uchFltSetP2];

	gstNM.stNetworkConfigMain.stRelaySetting.b02Filter1 = uchFltSetP1;
	gstNM.stNetworkConfigMain.stRelaySetting.b02Filter2 = uchFltSetP2;
	
	return;
}

NX_VOID vNMG_ChkCyclicSndCom (
	NX_UCHAR	uchFltSetP1,
	NX_UCHAR	uchFltSetP2,
	NX_USHORT*	pusCyclicSndP1,
	NX_USHORT*	pusCyclicSndP2
)
{
	NX_USHORT	usPort						= (NX_USHORT)NX_PORT1;
	NX_UCHAR	uchDownPortSnd				= (NX_UCHAR)NX_ZERO;
	NX_USHORT	ausCyclicSnd[NX_PORT_SIZE];
	NX_UCHAR	auchFltSet[NX_PORT_SIZE];
	NX_ULONG	ulMultiChk					= (NX_ULONG)NX_ZERO;

	uchDownPortSnd	= gstNET.stCyc.stTrnSubPayL[PDUDISC_NO].uchDownPortSnd;

	ulMultiChk	= vNMG_ChkMacAddrBrdMlt_LtEd( (NX_UCHAR*)gstNET.stCyc.stTrnSubPayL[PDUDISC_NO].auchDestFrame );

	auchFltSet[NX_PORT1]	= uchFltSetP1;
	auchFltSet[NX_PORT2]	= uchFltSetP2;

	for (usPort = (NX_USHORT)NX_PORT1; usPort < (NX_USHORT)NX_PORT_SIZE; usPort++) {
		if (NGN_PORTROLE_LOOP == gstNET.stPort[usPort].usPortRole) {
			ausCyclicSnd[usPort] = (NX_USHORT)NX_ON;
		}
		else {
			if ((NX_UCHAR)NX_ON == uchDownPortSnd) {
				ausCyclicSnd[usPort] = (NX_USHORT)NX_ON;
			}
			else {
				if (NGN_PORTROLE_UP == gstNET.stPort[usPort].usPortRole) {
					ausCyclicSnd[usPort] = (NX_USHORT)NX_ON;
				}
				else {
					ausCyclicSnd[usPort] = (NX_USHORT)NX_OFF;
				}
			}
		}

		if ((NX_USHORT)NX_ON == ausCyclicSnd[usPort]) {
			if ((NX_MAC_BRDMLTCAST == ulMultiChk)
			 && (   (NX_RELAYSETTING_FILTER_BRDMLT_RELAY_BAN	== auchFltSet[usPort])
				 || (NX_RELAYSETTING_FILTER_IEF_OTHER_RELAY_BAN	== auchFltSet[usPort])) ) {
				ausCyclicSnd[usPort]	= (NX_USHORT)NX_OFF;
			}
		}
	}

	*pusCyclicSndP1	= ausCyclicSnd[NX_PORT1];
	*pusCyclicSndP2	= ausCyclicSnd[NX_PORT2];

	return;
}

NX_USHORT usNMG_ChkCyclicSnd (
	NX_UCHAR	uchFltSetP1,
	NX_UCHAR	uchFltSetP2
)
{
	NX_USHORT	usResult		= (NX_USHORT)NX_US_OK;
	NX_USHORT	usCyclicSndP1	= (NX_USHORT)NX_OFF;
	NX_USHORT	usCyclicSndP2	= (NX_USHORT)NX_OFF;

	vNMG_ChkCyclicSndCom(uchFltSetP1, uchFltSetP2, &usCyclicSndP1, &usCyclicSndP2);

	if (((NX_USHORT)NX_OFF == usCyclicSndP1)
	 && ((NX_USHORT)NX_OFF == usCyclicSndP2)) {
		usResult =	NX_US_NG;
	}
	else {
		usResult =	NX_US_OK;
	}

	return usResult;
}

NX_VOID vNMG_GetPortSndDescriptor (
	NX_UCHAR	uchFltSetP1,
	NX_UCHAR	uchFltSetP2,
	NX_USHORT*	pusDescriptor0,
	NX_USHORT*	pusDescriptor1,
	NX_USHORT*	pusEnableNum
)
{
	NX_USHORT	usCyclicSndP1	= (NX_USHORT)NX_OFF;
	NX_USHORT	usCyclicSndP2	= (NX_USHORT)NX_OFF;
	NX_USHORT	usEnableNum		= (NX_USHORT)NX_ZERO;

	vNMG_ChkCyclicSndCom(uchFltSetP1, uchFltSetP2, &usCyclicSndP1, &usCyclicSndP2);

	if ((NX_ULONG)NX_ON == usCyclicSndP1) {
		usEnableNum++;
	}
	if ((NX_ULONG)NX_ON == usCyclicSndP2) {
		usEnableNum++;
	}
	*pusEnableNum = usEnableNum;
	
	if ((NX_USHORT)NX_TWO == usEnableNum) {
		if (NGN_PORTROLE_UP == gstNET.stPort[NX_PORT2].usPortRole) {
			*pusDescriptor0 = (NX_USHORT)NX_PORT2;
			*pusDescriptor1 = (NX_USHORT)NX_PORT1;
		}
		else {
			*pusDescriptor0 = (NX_USHORT)NX_PORT1;
			*pusDescriptor1 = (NX_USHORT)NX_PORT2;
		}
	}
	else if ( (NX_USHORT)NX_ONE == usEnableNum ){
		if ((NX_ULONG)NX_ON == usCyclicSndP1) {
			*pusDescriptor0 = (NX_USHORT)NX_PORT1;
		}
		else {
			*pusDescriptor0 = (NX_USHORT)NX_PORT2;
		}
		*pusDescriptor1 = (NX_USHORT)NX_PORTNON;
	}
	else {
		*pusDescriptor0 = (NX_USHORT)NX_PORTNON;
		*pusDescriptor1 = (NX_USHORT)NX_PORTNON;
	}

	return;
}

/*[EOF]*/
