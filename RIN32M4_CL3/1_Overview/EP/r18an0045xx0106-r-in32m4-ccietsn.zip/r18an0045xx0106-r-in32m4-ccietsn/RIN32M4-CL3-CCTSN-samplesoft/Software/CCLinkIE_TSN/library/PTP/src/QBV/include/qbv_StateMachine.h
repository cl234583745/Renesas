/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

 
#ifndef QBV_STATEMACHINE_H
#define QBV_STATEMACHINE_H

#include "ptp_type.h"
#include "qbv_global.h"
#include "qbv_Macro.h"


#define qbv_SM_lcf_wait_cchg &qbv_SM_lcf_idle_cchg
#define qbv_SM_lcf_wait_gdis &qbv_SM_lcf_idle_gdis
#define qbv_SM_ctm_wait_gdis &qbv_SM_ctm_idle_gdis
#define qbv_SM_lex_cycl_gdis &qbv_SM_lex_idle_gdis


INT qbv_StateMachine(UCHAR uchPort, USHORT usEvent, VOID* pvPara);
INT qbv_SM_lcf_idle_cchg(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lcf_idle_gdis(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lcf_wait_tick(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_ctm_idle_gdis(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_ctm_idle_tick(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_ctm_wait_tick(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_idle_gdis(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_idle_sreq(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_idle_tick(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_idle_scmp(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_cycl_sreq(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_cycl_tick(UCHAR uchPort, VOID* pvPara);
INT qbv_SM_lex_cycl_scmp(UCHAR uchPort, VOID* pvPara);
INT qbv_Calculat_CycleStartTime(EXTENDEDTIMESTAMP *pstCurrentTime, EXTENDEDTIMESTAMP *pstBaseTime,
									TIME_EXTENTION *pstCycleTime, EXTENDEDTIMESTAMP *pstCycleStartTime);
INT make_CycleTime_ShifTbl(TIME_EXTENTION* pstCycleTime);
#endif
