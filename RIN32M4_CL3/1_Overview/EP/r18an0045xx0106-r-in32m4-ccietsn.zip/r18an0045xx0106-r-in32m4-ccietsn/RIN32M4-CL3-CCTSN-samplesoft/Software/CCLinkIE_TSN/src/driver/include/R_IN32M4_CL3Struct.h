/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3STRUCT_H__
#define __R_IN32M4_CL3STRUCT_H__


/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "R_IN32M4_CL3Types.h"
#include "R_IN32M4_CL3Const.h"

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
#ifndef TSN_CAN_ENABLE
#define	R_IN_SEND_CYCLIC_BUFFER_RX_NUM		(2)								/* Number of RX buffer information	*/
#define	R_IN_SEND_CYCLIC_BUFFER_RWR_NUM		(2)								/* Number of RWr buffer information	*/
#else
#define	R_IN_SEND_CYCLIC_BUFFER_RX_NUM		(2)								/* Number of RX buffer information	*/
#define	R_IN_SEND_CYCLIC_BUFFER_RWR_NUM		(R_IN_CAN_MAX_ODTABLE_NUM+1)	/* Number of RWr buffer information	*/
#endif
#ifdef SAFETY_PDU_ENABLE
#define	R_IN_SEND_CYCLIC_BUFFER_SSPDU_NUM	(2)								/* Number of SSPDU buffer information	*/
#endif


/*********************************************************************************/
/* Structures                                                                    */
/*********************************************************************************/
/* UNIX time information */
typedef struct R_IN_UNIX_TIME_TAG {
	ULONG	ulNanoSecond;											/* UNIX time (nanosecond)					*/
	ULONG	ulSecond;												/* UNIX time (sec)							*/
} R_IN_UNIX_TIME_T;

/* Clock information */
typedef struct R_IN_TIMEINFO_TAG {
	USHORT	usYear;													/* Year										*/
	USHORT	usMonth;												/* Month									*/
	USHORT	usDay;													/* Day										*/
	USHORT	usHour;													/* Hour										*/
	USHORT	usMin;													/* Minute									*/
	USHORT	usSec;													/* Sec										*/
	USHORT	usMsec;													/* Msec										*/
	USHORT	usWday;													/* Day of week								*/
} R_IN_TIMEINFO_T;

/* R-IN32M4-CL3 optional information */
typedef struct R_IN_OPTIONINFO_TAG {
	ULONG	ulOptionUnitModelCode;									/* Optional model code						*/
	USHORT  usOptionExUnitModelCode;								/* Optional extended model code				*/
	USHORT	usOptionVendorCode;										/* Optional vendor code						*/
	UCHAR	auchOptionSerialNumber[R_IN_SERIAL_NUMBER_LENGTH];		/* Optional serial number					*/
	UCHAR	uchOptionDeviceVersion;									/* Optional function version				*/
	UCHAR	auchOptionModelName[R_IN_MODEL_NAME_LENGTH];			/* Optional model name						*/
	UCHAR	auchOptionVendorName[R_IN_VENDOR_NAME_LENGTH];			/* Optional vendor name						*/
} R_IN_OPTIONINFO_T;

/* Time synchronization related information */
typedef struct R_IN_PTPINFO_TAG {
	UCHAR	uchPriority1;											/* Priority1								*/
	ULONG	ulClockQuality;											/* ClockQuality								*/
	UCHAR	uchPriority2;											/* Priority2								*/
} R_IN_PTPINFO_T;

/* WDC Information (Transfer SubPayload) */
typedef struct R_IN_TRN_SPLD_WDC_INFO_TAG {
	USHORT	usWdcOffset;											/* WDC UL Offset							*/
} R_IN_TRN_SPLD_WDC_INFO_T;

/* WDC Information (Transfer SubPayload) */
typedef struct R_IN_RCV_SPLD_WDC_INFO_TAG {
	USHORT	usWdcOffset;											/* WDC DL Offset							*/
} R_IN_RCV_SPLD_WDC_INFO_T;

/* WDC Information */
typedef struct R_IN_WDCINFO_TAG {
	R_IN_TRN_SPLD_WDC_INFO_T	stTrnSpldWdcInfo;					/* WDC information (transfer subpayload)	*/
	R_IN_RCV_SPLD_WDC_INFO_T	stRcvSpldWdcInfo;					/* WDC information (receive subpayload)		*/
	USHORT						usWdcThresholdDef;					/* WDC NG continous count threshold def.	*/
	USHORT						usWdcIncrement;						/* WDC increment value						*/
} R_IN_WDCINFO_T;

/* R-IN32M4-CL3 module information */
typedef struct R_IN_UNITINFO_TAG {
	USHORT	usMaxRySize;											/* RY size (byte)							*/
	USHORT	usMaxRWwSize;											/* RWw size (word)							*/
#ifdef SAFETY_PDU_ENABLE
	USHORT	usMaxRspduSize;											/* RSPDU size (byte)						*/
#endif
	USHORT	usMaxRxSize;											/* RX size (byte)							*/
	USHORT	usMaxRWrSize;											/* RWr size (word)							*/
#ifdef SAFETY_PDU_ENABLE
	USHORT	usMaxSspduSize;											/* SSPDU size (byte)						*/
#endif
	UCHAR	uchMyStationPortTotalNumber;							/* Own number of ports (1 or 2)				*/
	USHORT	usNetVersion;											/* Network firmware version					*/
	USHORT	usNetModelType;											/* Network model type						*/
	ULONG	ulNetUnitModelCode;										/* Network model code						*/
	USHORT	usNetVendorCode;										/* Network vendor code						*/
	UCHAR	auchNetUnitModelName[R_IN_MODEL_NAME_LENGTH];			/* Network model name						*/
	UCHAR	auchNetVendorName[R_IN_VENDOR_NAME_LENGTH];				/* Network vendor name						*/
	UCHAR	uchNetHwVersion;										/* Hardware version of the network			*/
	USHORT	usNetDeviceVersion;										/* Function version of the network			*/
	BOOL	blInformationFlag;										/* Controller information presence flag		*/
	UCHAR	uchCtrlVersion;											/* Controller firmware version				*/
	USHORT	usCtrlModelType;										/* Model type of controller					*/
	ULONG	ulCtrlUnitModelCode;									/* Controller model code					*/
	USHORT	usCtrlVendorCode;										/* Vendor code of the controller			*/
	UCHAR	auchCtrlUnitModelName[R_IN_MODEL_NAME_LENGTH];			/* Controller model name					*/
	UCHAR	auchCtrlVendorName[R_IN_VENDOR_NAME_LENGTH];			/* Controller vendor name					*/
	USHORT	usNetExUnitModelCode;									/* Extended network model code				*/
	UCHAR	auchNetSerialNumber[R_IN_SERIAL_NUMBER_LENGTH];			/* Network serial number					*/
	UCHAR	uchCtrlDeviceVersion;									/* Function version of the controller		*/
	UCHAR	uchCtrlHwVersion;										/* Hardware version of the controller		*/
	UCHAR	auchCtrlSerialNumber[R_IN_SERIAL_NUMBER_LENGTH];		/* Controller serial number					*/
	USHORT	usCtrlExUnitModelCode;									/* Extended controller model code			*/
	USHORT	usStationMode;											/* Station mode								*/
	USHORT	usReserved;												/* Reservation								*/
	BOOL	blOptionInfoFlag;										/* Optional information presence flag		*/
	UCHAR	uchNumberOfOption;										/* Number of optional information			*/
#if R_IN_OPTIONTABLE_ENTRY_SIZE != 0
	R_IN_OPTIONINFO_T astOptionInfo[R_IN_OPTIONTABLE_ENTRY_SIZE];	/* Option information table					*/
#endif
	R_IN_PTPINFO_T stPtpInfo;										/* Time synchronization related information	*/
	ULONG	ulCorrespondingFunction;								/* Supported functions						*/
	USHORT	usNumberOfStationSubID;									/* Station sub ID number					*/
	R_IN_WDCINFO_T stWdcInfo;										/* WDC Information							*/
	ULONG	ulLinkSpeed;											/* Link speed								*/
	USHORT		usCCIETSNClass;										/* CC-Link IE TSN Class						*/
	USHORT		usCyclicDataUpdatePeriodic;							/* Cyclic data update periodic (microsecond)*/
	ULONGLONG	ullCommunicationCycleMin1G;							/* Minimum communication cycle (1Gbps)		*/
	ULONGLONG	ullCommunicationCycleMax1G;							/* Maximum communication cycle (1Gbps)		*/
	ULONGLONG	ullCommunicationCycleMin100M;						/* Minimum communication cycle (100Mbps)	*/
	ULONGLONG	ullCommunicationCycleMax100M;						/* Maximum communication cycle (100Mbps)	*/
	USHORT		usCyclicMaxResponseTime;							/* Time-managed polling method response time*/
} R_IN_UNITINFO_T;

/* R-IN32M4-CL3 initial configuration */
typedef struct R_IN_UNITINIT_TAG {
	BOOL	blHighInterruptUse;										/* High priority interrupt usage			*/
	UCHAR	uchNodeType;											/* Station type								*/
} R_IN_UNITINIT_T;

/* Statistics */
typedef struct R_IN_STATISTICS_TAG {
	USHORT	usCyclicReceiveCounter;									/* Cyclic reception counter					*/
	USHORT	usCyclicReceiveDiscardCounter;							/* Cyclic receive discard counter			*/
	USHORT	usCyclicFrameReceiveCounter;							/* Cyclic frame reception counter			*/
	USHORT	usNonCyclicReceiveCounter;								/* Non-cyclic reception counter				*/
	USHORT	usNonCyclicReceiveDiscardCounter;						/* Non-cyclic receive discard counter		*/
	USHORT	usNumberOfHecErrorFrame;								/* HEC error frame count					*/
	USHORT	usNumberOfDcsErrorFrame;								/* DCS error frame count					*/
	USHORT	usNumberOfFcsErrorFrame;								/* FCS error frame count					*/
	USHORT	usNumberOfSdcrcErrorFrame;								/* SDCRC error frame count					*/
	USHORT	usNumberOfShortPacketFrame;								/* Short packet frame count					*/
	USHORT	usNumberOfJumboFrame;									/* Jumbo frame count						*/
	USHORT	usNumberOfLongPacketFrame;								/* Long packet count						*/
	USHORT	usNumberOfFailedCcLinkIePduSize;						/* CC-Link IE TSN PDU length abnormal count	*/
	USHORT	usNumberOfFlagmentErrorFrame;							/* Fragment error frame count				*/
	USHORT	usNumberOfPriorityControlFrame;							/* Priority control frame count				*/
	USHORT	usNumberOfIpFrame;										/* IP frame count							*/
	USHORT	usNumberOfIeee802or1588Frame;							/* IEEE802.1AS/IEEE1588 frame count			*/
	USHORT	usNumberOfLldpFrame;									/* LLDP frame count							*/
	USHORT	usNumberOfSyncFrame;									/* Sync frame count							*/
} R_IN_STATISTICS_T;

/* Error information */
typedef struct R_IN_ERROR_INFORMATION_TAG {
	USHORT	usErrorCode;											/* Error code								*/
	UCHAR	uchErrorDetailSize;										/* Error detail size						*/
	USHORT	ausErrorDetail[R_IN_ERROR_DETAIL_SIZE];					/* Error details							*/
}R_IN_ERROR_INFORMATION_T;

/* Cyclic communication size */
typedef struct R_IN_CYCLIC_SIZE_TAG{
	ULONG	ulRySize;												/* RY size (octet)							*/
	ULONG	ulRWwSize;												/* RWw size (octet)							*/
	ULONG	ulRxSize;												/* RX size (octet)							*/
	ULONG	ulRWrSize;												/* RWr size (octet)							*/
#ifdef SAFETY_PDU_ENABLE
	ULONG	ulRspduSize;											/* RSPDU size (octet)						*/
	ULONG	ulSspduSize;											/* SSPDU size (octet)						*/
#endif
} R_IN_CYCLIC_SIZE_T;

/* Cyclic send buffer */
typedef struct R_IN_SEND_CYCLIC_BUFFER_TAG {
	struct {
		ULONG		ulAddr;											/* RX buffer address						*/
		USHORT		usSize;											/* RX buffer size (byte)					*/
	} stRx[R_IN_SEND_CYCLIC_BUFFER_RX_NUM];
	struct {
		ULONG		ulAddr;											/* RWr buffer address						*/
		USHORT		usSize;											/* RWr buffer size (byte)					*/
	} stRWr[R_IN_SEND_CYCLIC_BUFFER_RWR_NUM];
#ifdef SAFETY_PDU_ENABLE
	struct {
		ULONG		ulAddr;											/* SSPDU buffer address						*/
		USHORT		usSize;											/* SSPDU buffer size (byte)					*/
	} stSspdu[R_IN_SEND_CYCLIC_BUFFER_SSPDU_NUM];
#endif
	USHORT			usRxNum;										/* Number of RX buffer						*/
	USHORT			usRWrNum;										/* Number of RWr buffer						*/
#ifdef SAFETY_PDU_ENABLE
	USHORT			usSspduNum;										/* Number of SSPDU buffer					*/
#endif
} R_IN_SEND_CYCLIC_BUFFER_T;


/* Communication cycle information struct */
typedef struct R_IN_COMCYCLE_INFO_TAG {
	UCHAR		uchTimeslotNum;												/* Number of timeslots                       */
	UCHAR		uchReserve;													/* Reserved                                  */
	USHORT		usRepetitionCount;											/* Number of communication cycle repetitions */
	ULONGLONG	aullTsStartTime[R_IN_TIMESLOT_MAX];							/* Start time of TS0 to TS7                  */
	ULONGLONG	aullTsEndTime[R_IN_TIMESLOT_MAX];							/* End time of TS0 to TS7                    */
	ULONGLONG	ullComCycle;												/* Communication cycle                       */
} R_IN_COMCYCLE_INFO_T;


#ifdef MCUIF_ENABLE
/* Execution function table structure when receiving GPIO communication request */
typedef struct R_IN_MCU_IF_GPIO_FUNCTION_REQUEST_TBL_TAG {
	USHORT	usKind;														/* Event type								*/
	USHORT	usCode;														/* Event code								*/
	R_IN_MCU_IF_REQUEST_FUNCTION	fpvFunction;						/* Command function							*/
} R_IN_MCU_IF_GPIO_FUNCTION_REQUEST_TBL_T;

/* Execution function table structure when receiving GPIO communication response */
typedef struct R_IN_MCU_IF_GPIO_FUNCTION_RESPONSE_TBL_TAG {
	USHORT	usKind;														/* Event type								*/
	USHORT	usCode;														/* Event code								*/
	R_IN_MCU_IF_RESPONSE_FUNCTION	fpvFunction;						/* Command function							*/
} R_IN_MCU_IF_GPIO_FUNCTION_RESPONSE_TBL_T;

/* Inter-MCU I/F management table structure */
typedef struct R_IN_MCU_IF_GPIO_MANAGEMENT_TBL_TAG {
	USHORT											usRequestNumber;	/* Number of registered request commands				*/
	USHORT											usResponseNumber;	/* Number of registered response commands				*/
	CONST R_IN_MCU_IF_GPIO_FUNCTION_REQUEST_TBL_T*	pstRequest;			/* Request command execution function table pointer		*/
	CONST R_IN_MCU_IF_GPIO_FUNCTION_RESPONSE_TBL_T*	pstResponse;		/* Response command execution function table pointer	*/
	R_IN_MCU_IF_ACK_GPIO_SET_FUNCTION				fpvAckGpioSet;		/* GPIO communication reception							*/
	R_IN_MCU_IF_ACK_GPIO_CLEAR_FUNCTION				fpvAckGpioClear;	/* GPIO communication reception clear					*/
	R_IN_MCU_IF_REQUEST_GPIO_SET_FUNCTION			ferRequestGpioSet;	/* GPIO communication IO settings						*/
} R_IN_MCU_IF_GPIO_MANAGEMENT_TBL_T;

/* Execution function table structure when serial communication is completed */
typedef struct R_IN_MCU_IF_RTDMA_FUNCTION_TBL_TAG {
	R_IN_MCU_IF_RTDMA_RESERVED_FUNCTION	fpvReceivedFunction;			/* Internal MCU <- external MCU transfer completed	*/
	R_IN_MCU_IF_RTDMA_SEND_FUNCTION		fpvSendFunction;				/* Internal MCU -> external MCU transfer completed	*/
} R_IN_MCU_IF_RTDMA_FUNCTION_TBL_T;

#endif

#endif

/*** EOF ***/
