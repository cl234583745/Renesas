/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CYC_COMMON_H_INCLUDE__
#define __CYC_COMMON_H_INCLUDE__

#include "nx_common.h"

#include "ccienx_const_ex.h"

#define	RCV_SIDE_A			((NX_ULONG)0)
#define	RCV_SIDE_B			((NX_ULONG)1)
#define	RCV_SIDE_C			((NX_ULONG)2)
#define	RCV_SIDE_SIZE		((NX_USHORT)4)

#define	TRN_SIDE_A			((NX_ULONG)1)
#define	TRN_SIDE_B			((NX_ULONG)2)
#define	TRN_SIDE_C			((NX_ULONG)3)
#define	TRN_SIDE_SIZE		((NX_USHORT)4)

#define	CYC_IGNORE_MSK_ON	((NX_UCHAR)0x80)
#define	CYC_IGNORE_MSK_OFF	((NX_UCHAR)0x7F)


#define	ADDR_SELFSTSW_VER		((NX_USHORT)0)
#define	ADDR_SELFSTSW_SET		((NX_USHORT)1)
#define	ADDR_SELFSTSW_CYC_L		((NX_USHORT)2)
#define	ADDR_SELFSTSW_CYC_H		((NX_USHORT)3)
#define	ADDR_SELFSTSW_ERR		((NX_USHORT)4)
#define	ADDR_SELFSTSW_APPINFO	((NX_USHORT)6)

#define	BIT_APPINFO_NWSYNC		((NX_UCHAR)NX_BIT0)

#define	RCVFLGADDR_UNI				(NX_ULONG)(0x00000001)
#define	SWITCH_SWRD_HWWRCMP2		(NX_ULONG)(0x00000001)

typedef struct tagAPPERR_CTRL {
	NX_USHORT	usHldClrEn;
	NX_USHORT	usRcvCycDataDis;
} APPERR_CTRL;

typedef struct tagCYC_CTRL {
	NX_ULONG	ulTrnSide;
	NX_USHORT	usHldClrStsPre;
	NX_USHORT	usRsv1;
	APPERR_CTRL	stAppErr;
	NX_UCHAR	uchSelfDiagData;
	NX_UCHAR	auchRsv2[3];
	NX_ULONG	ulAppErrSts;
	NX_UCHAR	auchSelfStsW[8];
} CYC_CTRL;

typedef struct tagCYC_TRN_ADDR {
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRX[NX_SPLD_NUM_RX];
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRWr[NX_SPLD_NUM_RWR];
#ifdef SAFETY_PDU_ENABLE
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stSpdux[NX_SPLD_NUM_SPDUX];
#endif
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stStsW[NX_SPLD_NUM_STSW];

	NX_USHORT		usRxNum;
	NX_USHORT		usRWrNum;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT		usSpduxNum;
#endif
	NX_USHORT		usStswNum;
} CYC_TRN_ADDR;

typedef struct tagCYC_RCV_ADDR {
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRY[NX_SPLD_NUM_RY];
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stRWw[NX_SPLD_NUM_RWW];
#ifdef SAFETY_PDU_ENABLE
	struct {
		NX_ULONG	ulAddr;
		NX_USHORT	usSize;
	} stSpduy[NX_SPLD_NUM_SPDUY];
#endif

	NX_USHORT		usRyNum;
	NX_USHORT		usRWwNum;
#ifdef SAFETY_PDU_ENABLE
	NX_USHORT		usSpduyNum;
#endif
} CYC_RCV_ADDR;

NX_EXTERN	CYC_CTRL	gstCycCtrl;
NX_EXTERN	CYC_TRN_ADDR	gstPreCycTrnAddr;
NX_EXTERN	CYC_TRN_ADDR	gstCycTrnAddr;
NX_EXTERN	CYC_RCV_ADDR	gstCycRcvAddr;

NX_EXTERN	NX_CONST	NX_ULONG	gaulRyAddrTbl[NX_LIB_MODE_SIZE][RCV_SIDE_SIZE];
NX_EXTERN	NX_CONST	NX_ULONG	gaulRWwAddrTbl[RCV_SIDE_SIZE];
#ifdef SAFETY_PDU_ENABLE
NX_EXTERN	NX_CONST	NX_ULONG	gaulSpduyAddrTbl[RCV_SIDE_SIZE];
#endif
NX_EXTERN	NX_CONST	NX_ULONG	gaulRxAddrTbl[NX_LIB_MODE_SIZE][TRN_SIDE_SIZE];
NX_EXTERN	NX_CONST	NX_ULONG	gaulRWrAddrTbl[TRN_SIDE_SIZE];
#ifdef SAFETY_PDU_ENABLE
NX_EXTERN	NX_CONST	NX_ULONG	gaulSpduxAddrTbl[TRN_SIDE_SIZE];
#endif
NX_EXTERN	NX_CONST	NX_ULONG	gaulStsWAddrTbl[TRN_SIDE_SIZE];
NX_EXTERN	NX_CONST	NX_ULONG	gaulBaseAddrTbl[TRN_SIDE_SIZE];

NX_EXTERN	NX_CONST	NX_ULONG	gaulRxSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_RX];
NX_EXTERN	NX_CONST	NX_ULONG	gaulRyRcvDataAddrTbl[NX_SPLD_ADDR_NUM_RY];
NX_EXTERN	NX_CONST	NX_ULONG	gaulRWrSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_RWR];
NX_EXTERN	NX_CONST	NX_ULONG	gaulRWwRcvDataAddrTbl[NX_SPLD_ADDR_NUM_RWW];

NX_EXTERN	NX_CONST	NX_USHORT	gusRxSndDataStorageAddrTblSize;
NX_EXTERN	NX_CONST	NX_USHORT	gusRyRcvDataAddrTblSize;
NX_EXTERN	NX_CONST	NX_USHORT	gusRWrSndDataStorageAddrTblSize;
NX_EXTERN	NX_CONST	NX_USHORT	gusRWwRcvDataAddrTblSize;

#ifdef SAFETY_PDU_ENABLE
NX_EXTERN	NX_CONST	NX_ULONG	gaulSpduxSndDataStorageAddrTbl[NX_SPLD_ADDR_NUM_SPDUX];
NX_EXTERN	NX_CONST	NX_ULONG	gaulSpduyRcvDataAddrTbl[NX_SPLD_ADDR_NUM_SPDUY];
NX_EXTERN	NX_CONST	NX_USHORT	gusSpduxSndDataStorageAddrTblSize;
NX_EXTERN	NX_CONST	NX_USHORT	gusSpduyRcvDataAddrTblSize;
#endif


NX_EXTERN	NX_CONST	NX_ULONG	aulUnusedSideTbl[TRN_SIDE_SIZE][TRN_SIDE_SIZE];
NX_EXTERN	NX_CONST	NX_ULONG	gaulSideMsk[TS_SIZE_EXCEPT_TS0];
NX_EXTERN	NX_CONST	NX_USHORT	gausSideShift[TS_SIZE_EXCEPT_TS0];
NX_EXTERN	volatile	NX_ULONG*	gpaulCycRevFlg[RCV_SIDE_SIZE];
NX_EXTERN	volatile	NX_ULONG*	gpaulCycAlive[RCV_SIDE_SIZE];
NX_EXTERN	NX_CONST	NX_UCHAR	gauchDiagErrInfo[ERR_STS_SIZE];

NX_VOID vCYC_InitCyclicStart ( NX_VOID );
NX_VOID vCYC_ActivateCyclic ( NX_VOID );
NX_VOID vCYC_DeactivateCyclicSnd ( NX_VOID );
NX_VOID vCYC_DeactivateCyclicRcv ( NX_VOID );
NX_VOID vCYC_InitStsW ( NX_VOID );
NX_VOID vCYC_UpdateSelfStsW ( NX_VOID );
NX_VOID vCYC_SetSelfStsW ( NX_ULONG );
NX_VOID vCYC_ForceWdtErrStsW ( NX_VOID );
NX_VOID vCYC_DeactivateCyclicClassA ( NX_VOID );
NX_VOID vCYC_UpdateAppErrFW ( NX_ULONG );
NX_VOID vCYC_ChkFirstCyclicRcv ( NX_ULONG );
NX_ULONG ulCYC_DetectIpErr ( NX_VOID );
NX_VOID vCYC_ExecGetCyclicRcvStsClassA ( NX_CYC_RCV_STS* );
NX_ULONG ulCYC_ChkCycRcv (NX_ULONG);
NX_USHORT usCYC_DetectSndCyclicTmgClassA ( NX_VOID );
NX_ULONG ulCYC_SwitchSwReadSide2 ( NX_ULONG* );
NX_ULONG ulCYC_SelectUnusedSideClassA ( NX_VOID );
NX_VOID vCYC_SetCycDisClassA ( NX_VOID );
NX_VOID vCYC_CycTxCompClassA ( NX_ULONG );
NX_VOID vCYC_SetTimeoutSettingClassA ( NX_ULONG );
#endif
/*[EOF]*/
