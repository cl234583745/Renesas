//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "ethernet.h"
#include "lldp.h"
#include "msw_lldp.h"
#include "lldpd.h"
#include "usnet_supply.h"

#define MH(mb) ((struct Ehdr *)mb)

extern struct NET nets[];
extern struct NETCONF netconf[];
extern struct CONNECT connblo[];
extern PTABLE  *const P_tab[];
extern PTABLE   ussLLDPTable;
extern const int confsiz;

#ifdef USSW_LLDP

static int opeN(int conno, int flags)
{
    (void)conno;
    (void)flags;
    return 1;
}



static int closE(int conno)
{
    (void)conno;
    return 0;
}


static int writE(int conno, MESS * mess)
{
    int i1;
    int netno;
    int confix;

    netno = mess->netno;
    confix = mess->confix;
    Nmemcpy((char *) &MH(mess)->from, (char *) &nets[netno].id, Eid_SZ);
    mess->offset = MESSH_SZ;
    mess->id = bRELEASE;

    if (conno < 0)
        return 0;

    mess->confix = 255;
    i1 = nets[netno].protoc[ussDriverIndex]->writE(netno, mess);
    if (i1)
        Nrelbuf(mess);

    return i1;
}


static int screen(MESS * mess)
{
    int i1;
    int len;

    if (memcmp(&MH(mess)->from, (char *)&nets[mess->netno].id, Eid_SZ)) {
        len = mess->mlen - mess->offset;
        mswLldpRecv(lldpdhwport[mess->portno].ifname, 
            ((unsigned char *)mess + mess->offset - LHDRSZ), (len + LHDRSZ));
    }
    return -2;
}



static int init(int netno, char *params)
{
    (void)netno;
    (void)params;
    return 0;
}


static void shut(int netno)
{
    (void)netno;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}

void lldpsend(char *port, unsigned char *outframe, 
        unsigned short len, void *usrData)
{
    int  i1 = 0;
    int netno = 0;
    MESS *mp;
    char *p;
    short portno = 0;
    unsigned long   ulLinkSts = 0;

    (void)usrData;
    if (port == NULL)
        return;

    for (i1 = 0; i1 < LLDPD_PORT_NUM; i1++) {
        if (!memcmp(lldpdhwport[i1].ifname, port, strlen(port))) {
            netno = lldpdhwport[i1].netno;
            portno = i1;
            break;
        }
    }

    if (i1 == LLDPD_PORT_NUM) {
        return;
    }

    vUSN_GetLinkSts((unsigned short)portno, &ulLinkSts);

    if (ulLinkSts != USNET_LINKUP) {
       return;
    }

    if ((mp = Ngetbuf()) == 0)
        return;


    mp->netno = netno;
    mp->portno = portno;
    mp->confix = nets[netno].confix;
    mp->mlen = MESSH_SZ + len;
    p = (char *)mp;
    p += MESSH_SZ;
    memcpy(p, outframe, len);
    writE(netno, mp);
}


GLOBALCONST
PTABLE ussLLDPTable = {
    "LLDP", init, 0, screen, opeN, closE, 0, writE, ioctl, ETH_TYPE_LLDP, 0
};

#endif
