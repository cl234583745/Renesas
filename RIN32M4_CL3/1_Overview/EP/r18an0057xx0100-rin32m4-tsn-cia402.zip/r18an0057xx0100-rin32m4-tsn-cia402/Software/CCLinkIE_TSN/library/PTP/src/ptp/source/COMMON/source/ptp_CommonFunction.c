/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"

#include "ptp_tsn_Wrapper.h"








BOOL	ptpAddUSNs_USNs_Ul3(USCALEDNS*	pstA_UScaledNs, USCALEDNS*	pstB_UScaledNs,	
							USCALEDNS*	pstAnsUScaledNs, UCHAR*	puchOvf3);
BOOL	ptpAddUSNs_TInt_Ul3(USCALEDNS*	pstA_UScaledNs, TIME_INTERVAL*	pstB_Time_Interval,
							USCALEDNS*	pstAnsUScaledNs, UCHAR*	puchOvf3);
BOOL	ptpAddUSNs_TInt_L4(USCALEDNS*	pstA_UScaledNs,	TIME_INTERVAL*	pstB_Time_Interval,
							USCALEDNS*	pstAnsUScaledNs, LONG*	pl4);





BOOL	ptpAddUSNs_USNs_Ul3( 
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs,
	USCALEDNS*			pstAnsUScaledNs,
	UCHAR*				puchOvf3)
{
	ULONG		ul1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf1 = 0;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;


	ul1 = ((ULONG)pstA_UScaledNs->usFrcNsec) + ((ULONG)pstB_UScaledNs->usFrcNsec);
	if (ul1 > (ULONG)US_MAX_FFFF)
	{
		uchOvf1 = UCHCONST_1;
	}


	ul2 = pstA_UScaledNs->ulNsec_lsb + pstB_UScaledNs->ulNsec_lsb;
	if ((ul2 < pstA_UScaledNs->ulNsec_lsb) ||
		(ul2 < pstB_UScaledNs->ulNsec_lsb))
	{
		uchOvf2 = UCHCONST_1;
	}
	else if ((ul2 == UL_MAX_FFFFFFFF) &&
			 (uchOvf1 == UCHCONST_1))
	{
		uchOvf2 = UCHCONST_1;
	}
	else
	{
	}

	ul2 = ul2 + (ULONG)uchOvf1;


	ul3 = pstA_UScaledNs->ulNsec_2nd + pstB_UScaledNs->ulNsec_2nd;
	if ((ul3 < pstA_UScaledNs->ulNsec_2nd) ||
		(ul3 < pstB_UScaledNs->ulNsec_2nd))
	{
		uchOvf3 = UCHCONST_1;
	}
	else if ((ul3 == (ULONG)UL_MAX_FFFFFFFF) &&
			 (uchOvf2 == UCHCONST_1))
	{
		uchOvf3 = UCHCONST_1;
	}
	else
	{
	}
	ul3 = ul3 + uchOvf2;

	pstAnsUScaledNs->usFrcNsec	= (USHORT)ul1;
	pstAnsUScaledNs->ulNsec_lsb = ul2;
	pstAnsUScaledNs->ulNsec_2nd = ul3;
	(*puchOvf3) = uchOvf3;

	blRet = TRUE;

	return	blRet;
}




BOOL	ptpAddUSNs_TInt_Ul3( 
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	USCALEDNS*			pstAnsUScaledNs,
	UCHAR*				puchOvf3)
{
	ULONG		ul1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	ULONG		ul3_B	= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf1 = 0;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;


	ul1 = ((ULONG)pstA_UScaledNs->usFrcNsec) + ((ULONG)pstB_Time_Interval->usFrcNsec);
	if (ul1 > (ULONG)US_MAX_FFFF)
	{
		uchOvf1 = UCHCONST_1;
	}


	ul2 = pstA_UScaledNs->ulNsec_lsb + pstB_Time_Interval->ulNsec_lsb;
	if ((ul2 < pstA_UScaledNs->ulNsec_lsb) ||
		(ul2 < pstB_Time_Interval->ulNsec_lsb))
	{
		uchOvf2 = UCHCONST_1;
	}
	else if ((ul2 == UL_MAX_FFFFFFFF) &&
			 (uchOvf1 == UCHCONST_1))
	{
		uchOvf2 = UCHCONST_1;
	}
	else
	{
	}
	ul2 = ul2 + uchOvf1;


	ul3_B = (ULONG)((LONG)(pstB_Time_Interval->sNsec_msb));
	ul3 = pstA_UScaledNs->ulNsec_2nd + ul3_B;
	if ((ul3 < pstA_UScaledNs->ulNsec_2nd) ||
		(ul3 < ul3_B))
	{
		uchOvf3 = UCHCONST_1;
	}
	else if ((ul3 == UL_MAX_FFFFFFFF) &&
			 (uchOvf2 == UCHCONST_1))
	{
		uchOvf3 = UCHCONST_1;
	}
	else
	{
	}
	ul3 = ul3 + uchOvf2;

	pstAnsUScaledNs->usFrcNsec	= (USHORT)ul1;
	pstAnsUScaledNs->ulNsec_lsb = ul2;
	pstAnsUScaledNs->ulNsec_2nd = ul3;
	(*puchOvf3) = uchOvf3;

	blRet = TRUE;

	return	blRet;
}



BOOL	ptpAddUSNs_TInt_L4( 
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	USCALEDNS*			pstAnsUScaledNs,
	LONG*				pl4)
{
	LONG		l4		= 0;
	LONG		l4_B	= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf3 = 0;


	blRet = ptpAddUSNs_TInt_Ul3(pstA_UScaledNs,
								pstB_Time_Interval,
								pstAnsUScaledNs,
								&uchOvf3);
	if (blRet == FALSE)
	{
		return blRet;
	}


	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		l4_B = -1;
	}
	l4 = ((LONG)pstA_UScaledNs->usNsec_msb) + l4_B;
	l4 = l4 + (LONG)uchOvf3;

	(*pl4) = l4;

	blRet = TRUE;
	return	blRet;
}

















BOOL	ptpMultUL_UL(
		ULONG ulA,
		ULONG ulB,
		ULONG* pulC_msb,
		ULONG* pulC_lsb)
{
	USHORT		usA_lsb = (USHORT)(ulA & UL_MASK_0000FFFF);
	USHORT		usA_msb = (USHORT)(ulA >> CONS_SHIFT16);
	USHORT		usB_lsb = (USHORT)(ulB & UL_MASK_0000FFFF);
	USHORT		usB_msb = (USHORT)(ulB >> CONS_SHIFT16);
	ULONG		ulC_lsb = 0;
	ULONG		ulC_msb = 0;
	ULONG		ulC_w = 0;
	ULONG		ulC_w2 = 0;
	ULONG		ulC_w3 = 0;
	ULONG		ulC_w4 = 0;
	USHORT		usC_2nd = 0;
	USHORT		usC_2nd_2 = 0;
	USHORT		usC_3rd = 0;
	USHORT		usC_3rd_2 = 0;
	BOOL		blRet = TRUE;


	PTP_MULTUS_US(usA_lsb, usB_lsb, ulC_lsb);
	
	PTP_MULTUS_US(usA_lsb, usB_msb, ulC_w);

	usC_3rd   = (USHORT)(ulC_w >> CONS_SHIFT16);
	usC_2nd_2 = (USHORT)(ulC_w & UL_MASK_0000FFFF);
	usC_2nd   = (USHORT)(ulC_lsb >> CONS_SHIFT16);
	ulC_lsb   = ulC_lsb & UL_MASK_0000FFFF;
	PTP_ADDUS_US(usC_2nd, usC_2nd_2, ulC_w2);
	
	PTP_MULTUS_US(usA_msb, usB_lsb, ulC_w);

	usC_3rd_2 = (USHORT)(ulC_w >> CONS_SHIFT16);
	usC_2nd_2 = (USHORT)(ulC_w & UL_MASK_0000FFFF);
	usC_2nd   = (USHORT)(ulC_w2 & UL_MASK_0000FFFF);
	PTP_ADDUS_US(usC_2nd, usC_2nd_2, ulC_w3);
	ulC_lsb = ulC_lsb + (((ULONG)(ulC_w3 & UL_MASK_0000FFFF)) << CONS_SHIFT16);
	
	PTP_ADDUS_US(usC_3rd, usC_3rd_2, ulC_msb);
	usC_3rd   = (USHORT)(ulC_w2 >> CONS_SHIFT16);
	usC_3rd_2 = (USHORT)(ulC_w3 >> CONS_SHIFT16);
	PTP_ADDUS_US(usC_3rd, usC_3rd_2, ulC_w4);
	ulC_w4	  = ulC_msb + ulC_w4;
	
	PTP_MULTUS_US(usA_msb, usB_msb, ulC_w);

	ulC_msb = ulC_w4 + ulC_w;
	
	(*pulC_lsb) = ulC_lsb;
	(*pulC_msb) = ulC_msb;

	return	blRet;
}




BOOL	ptp2sComplementSNs(
	SCALEDNS*	pstA_SNs,
	SCALEDNS*	pstB_SNs)
{
	UCHAR	uchOvf = 0;
	SCALEDNS	stC_SNs = {0};
	USHORT		us4_w = 0;
	BOOL		blRet = TRUE;


	
	if (!IS_SCALEDNS_0((*pstA_SNs)))
	{
		stC_SNs.usFrcNsec = ~(pstA_SNs->usFrcNsec);
		if (stC_SNs.usFrcNsec == US_MAX_FFFF)
		{
			stC_SNs.usFrcNsec = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_SNs.usFrcNsec = stC_SNs.usFrcNsec + CONST_1;
			uchOvf = 0;
		}

		stC_SNs.ulNsec_lsb = ~(pstA_SNs->ulNsec_lsb);
		if ((stC_SNs.ulNsec_lsb == UL_MAX_FFFFFFFF) &&
			(uchOvf == UCHCONST_1))
		{
			stC_SNs.ulNsec_lsb = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_SNs.ulNsec_lsb = stC_SNs.ulNsec_lsb + uchOvf;
			uchOvf = 0;
		}

		stC_SNs.ulNsec_2nd = ~(pstA_SNs->ulNsec_2nd);
		if ((stC_SNs.ulNsec_2nd == UL_MAX_FFFFFFFF) &&
			(uchOvf == UCHCONST_1))
		{
			stC_SNs.ulNsec_2nd = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_SNs.ulNsec_2nd = stC_SNs.ulNsec_2nd + uchOvf;
			uchOvf = 0;
		}

		us4_w = ~((USHORT)pstA_SNs->sNsec_msb);
		if ((us4_w == (USHORT)S_MAX_7FFF) &&
			 (uchOvf == UCHCONST_1))
		{
			stC_SNs.sNsec_msb = 0;
			blRet  = FALSE;
		}
		else
		{
			us4_w = us4_w + uchOvf;
			stC_SNs.sNsec_msb = (SHORT)us4_w;
			blRet = TRUE;
		}
	}
	
	(*pstB_SNs) = stC_SNs;
		
	return	blRet;
}




BOOL	ptp2sComplementUSNs(
	USCALEDNS*	pstA_USNs,
	USCALEDNS*	pstB_USNs,
	LONG*		pl4)
{
	UCHAR		uchOvf		= 0;
	USCALEDNS	stC_USNs	= {0};
	ULONG		ul4_w		= 0;
	BOOL		blRet		= TRUE;


	if (!IS_USCALEDNS_0((*pstA_USNs)))
	{
		stC_USNs.usFrcNsec = ~(pstA_USNs->usFrcNsec);
		if (stC_USNs.usFrcNsec == US_MAX_FFFF)
		{
			stC_USNs.usFrcNsec = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_USNs.usFrcNsec = stC_USNs.usFrcNsec + CONST_1;
			uchOvf = 0;
		}

		stC_USNs.ulNsec_lsb = ~(pstA_USNs->ulNsec_lsb);
		if ((stC_USNs.ulNsec_lsb == UL_MAX_FFFFFFFF) &&
			(uchOvf == UCHCONST_1))
		{
			stC_USNs.ulNsec_lsb = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_USNs.ulNsec_lsb = stC_USNs.ulNsec_lsb + uchOvf;
			uchOvf = 0;
		}

		stC_USNs.ulNsec_2nd = ~(pstA_USNs->ulNsec_2nd);
		if ((stC_USNs.ulNsec_2nd == UL_MAX_FFFFFFFF) &&
			(uchOvf == UCHCONST_1))
		{
			stC_USNs.ulNsec_2nd = 0;
			uchOvf = UCHCONST_1;
		}
		else
		{
			stC_USNs.ulNsec_2nd = stC_USNs.ulNsec_2nd + uchOvf;
			uchOvf = 0;
		}

		ul4_w = ~((ULONG)pstA_USNs->usNsec_msb);
		ul4_w = ul4_w + uchOvf;
		stC_USNs.usNsec_msb = (USHORT)ul4_w;
	}
	
	(*pstB_USNs) = stC_USNs;
	(*pl4) = (LONG)ul4_w;

	return	blRet;
}




BOOL	ptpDivSec48_UL(
		SEC48*	pstA_Sec48,
		ULONG	ulB,
		ULONG*	pulC_Div,
		ULONG*	pulC_Mod)
{
	BOOL		blRet	= TRUE;
	DOUBLE		dbA		= DBCONST0_0; 
	DOUBLE		dbB		= DBCONST0_0; 
	DOUBLE		dbC		= DBCONST0_0; 
	ULONG		ulC_Div = 0;
	ULONG		ulC_Mod = 0;

	
	if (ulB < UL_DIVMIN_10000)
	{
		blRet = FALSE;
	}
	else if (ulB == UL_DIVMIN_10000)
	{
		ulC_Div = (ULONG)(((ULONG)(pstA_Sec48->usSec_msb)) << CONS_SHIFT16);
		ulC_Div = ulC_Div + (ULONG)(pstA_Sec48->ulSec_lsb >> CONS_SHIFT16);
		ulC_Mod = (ULONG)(pstA_Sec48->ulSec_lsb & UL_MASK_0000FFFF);
	}
	else
	{
		dbA = (((DOUBLE)(pstA_Sec48->usSec_msb)) * DBCONST2_32) + ((DOUBLE)(pstA_Sec48->ulSec_lsb));
		dbB = (DOUBLE)ulB;

		dbC = dbA / dbB;
		ulC_Div = (ULONG)dbC;
		ulC_Mod = (ULONG)(dbA - (((DOUBLE)ulC_Div) * dbB));
	}

	(*pulC_Div) = ulC_Div;
	(*pulC_Mod) = ulC_Mod;

	return	blRet;
}




BOOL	setDbToUSNs(
		DOUBLE		dbDouble,
		USHORT		usGPos,
		USCALEDNS*	pstAnsUScaledNs)
{
	BOOL		blRet	= FALSE;
	DOUBLE		dbW		= DBCONST0_0;
	DOUBLE		dbW1	= DBCONST0_0;
	DOUBLE		dbW11	= DBCONST0_0;
	DOUBLE		dbW12	= DBCONST0_0;
	DOUBLE		dbW13	= DBCONST0_0;
	DOUBLE		dbW21	= DBCONST0_0;
	DOUBLE		dbW22	= DBCONST0_0;
	DOUBLE		dbW23	= DBCONST0_0;


	if (dbDouble < DBCONST0_0)
	{
		return	blRet;
	}

	if (!((usGPos == GPOS_USNS_00) ||
		  (usGPos == GPOS_USNS_16) ||
		  (usGPos == GPOS_USNS_48) ||
		  (usGPos == GPOS_USNS_80)))
	{
		return	blRet;
	}

	SET_USCALEDNS((*pstAnsUScaledNs), 0, 0, 0, 0);

	dbW1 = dbDouble;
	if (usGPos >= GPOS_USNS_16)
	{
		dbW1 = dbW1 * DBCONST2_16;
	}
	if (usGPos >= GPOS_USNS_48)
	{
		dbW1 = dbW1 * DBCONST2_32;
	}
	if (usGPos >= GPOS_USNS_80)
	{
		dbW1 = dbW1 * DBCONST2_32;
	}

	if (dbW1 >= DBCONST2_16)
	{
		dbW11 = dbW1 / DBCONST2_16;
	}
	else
	{
		pstAnsUScaledNs->usFrcNsec	= (USHORT)(dbW1 + DBCONST0_5);

		blRet = TRUE;
		return blRet;
	}

	if (dbW11 >= DBCONST2_32)
	{
		dbW12 = dbW11 / DBCONST2_32;
	}
	else
	{
		pstAnsUScaledNs->ulNsec_lsb	= (ULONG)dbW11;

		dbW = dbW11 - (DOUBLE)pstAnsUScaledNs->ulNsec_lsb;
		dbW = dbW * DBCONST2_16;
		pstAnsUScaledNs->usFrcNsec	= (USHORT)dbW;
		
		blRet = TRUE;
		return blRet;
	}

	if (dbW12 >= DBCONST2_32)
	{
		dbW13 = dbW12 / DBCONST2_32;
	}
	else
	{
		pstAnsUScaledNs->ulNsec_2nd = (ULONG)dbW12;

		dbW22 = dbW12 - (DOUBLE)pstAnsUScaledNs->ulNsec_2nd;
		dbW22 = dbW22 * DBCONST2_32;
		pstAnsUScaledNs->ulNsec_lsb	= (ULONG)dbW22;

		dbW21 = dbW22 - (DOUBLE)pstAnsUScaledNs->ulNsec_lsb;
		dbW21 = dbW21 * DBCONST2_16;
		pstAnsUScaledNs->usFrcNsec	= (USHORT)dbW21;
		
		blRet = TRUE;
		return blRet;
	}

	if (dbW13 >= DBCONST2_16)
	{
		return	blRet;
	}
	else
	{
		pstAnsUScaledNs->usNsec_msb =  (USHORT)dbW13;

		dbW23 = dbW13 - (DOUBLE)pstAnsUScaledNs->usNsec_msb;
		dbW23 = dbW23 * DBCONST2_32;
		pstAnsUScaledNs->ulNsec_2nd = (ULONG)dbW23;

		dbW22 = dbW23 - (DOUBLE)pstAnsUScaledNs->ulNsec_2nd;
		dbW22 = dbW22 * DBCONST2_32;
		pstAnsUScaledNs->ulNsec_lsb	= (ULONG)dbW22;

		dbW21 = dbW22 - (DOUBLE)pstAnsUScaledNs->ulNsec_lsb;
		dbW21 = dbW21 * DBCONST2_16;
		pstAnsUScaledNs->usFrcNsec	= (USHORT)dbW21;
	}
	blRet = TRUE;

	return	blRet;
}




BOOL	setDbToSNs(
		DOUBLE		dbDouble,
		USHORT		usGPos,
		SCALEDNS*	pstAnsScaledNs)
{
	BOOL		blRet	= FALSE;
	SCALEDNS	stW_SNs		= {0};
	USCALEDNS	stW_USNs	= {0};
	DOUBLE		dbDoubleW	= DBCONST0_0;
	BOOL		blSignA = TRUE;



	if (dbDouble < DBCONST0_0)
	{
		blSignA = FALSE;
		dbDoubleW = -dbDouble;
	}
	else
	{
		dbDoubleW = dbDouble;
	}
	blRet = setDbToUSNs(dbDoubleW,
						usGPos,
						&stW_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpConvUSNs_SNs(&stW_USNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	if (blSignA == FALSE)
	{
		blRet = ptp2sComplementSNs(&stW_SNs, pstAnsScaledNs);
		if (blRet == FALSE) {
			return	blRet;
		}
	}
	else
	{
		(*pstAnsScaledNs) = stW_SNs;
	}
	blRet = TRUE;

	return	blRet;
}




BOOL	setDbToTInt(
		DOUBLE			dbDouble,
		USHORT			usGPos,
		TIME_INTERVAL*	pstAnsTime_Interval)
{
	BOOL		blRet	= FALSE;
	SCALEDNS		stW_SNs		= {0};



	blRet = setDbToSNs(dbDouble,
						usGPos,
						&stW_SNs);

	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvSNs_TInt(&stW_SNs,
							pstAnsTime_Interval);


	return	blRet;
}






BOOL	ptpConvETS_USNs(
	EXTENDEDTIMESTAMP*	pstETimestamp,
	USCALEDNS*			pstUScaledNs	)
{
	USCALEDNS			stA_USNs	= {0};
	USCALEDNS			stB_USNs	= {0};
	USCALEDNS			stC_USNs	= {0};
	ULONG				ulW			= 0;
	ULONG				ulW_m		= 0;
	BOOL				blRet		= FALSE;
	
	
	stA_USNs.usFrcNsec = pstETimestamp->stNsec.usFrcNsec;
	
	stA_USNs.ulNsec_lsb = pstETimestamp->stNsec.ulNsec;

	blRet = ptpMultUL_UL(pstETimestamp->stSec.ulSec_lsb, CONST10_9, &ulW_m, &ulW);
	if (blRet == FALSE)
	{
		return blRet;
	}
	stB_USNs.ulNsec_lsb = ulW;
	stB_USNs.ulNsec_2nd = ulW_m;

	blRet = ptpMultUL_UL((ULONG)(pstETimestamp->stSec.usSec_msb), CONST10_9, &ulW_m, &ulW);
	if ((blRet == FALSE) ||
		(ulW_m > (ULONG)US_MAX_FFFF))
	{
		blRet = FALSE;
		return blRet;
	}
	stA_USNs.ulNsec_2nd = ulW;
	stA_USNs.usNsec_msb = (USHORT)ulW_m;

	blRet = ptpAddUSNs_USNs(&stA_USNs, &stB_USNs, &stC_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}
	(*pstUScaledNs) = stC_USNs;

	return	blRet;
}





BOOL	ptpConvUSNs_ETS(
	USCALEDNS*			pstUScaledNs,
	EXTENDEDTIMESTAMP*	pstETimestamp)
{
	SEC48				stA_Sec48	= {0};
	ULONG				ulW			= CONST10_9;
	EXTENDEDTIMESTAMP	stB_ETS		= {0};
	ULONG				ulW_Div		= 0;
	ULONG				ulW_Mod		= 0;
	ULONG				ulW2		= 0;
	BOOL				blRet		= FALSE;
	

	stA_Sec48.usSec_msb = pstUScaledNs->usNsec_msb;
	stA_Sec48.ulSec_lsb = pstUScaledNs->ulNsec_2nd;

	blRet = ptpDivSec48_UL(&stA_Sec48, ulW, &ulW_Div, &ulW_Mod);
	if (blRet == FALSE)
	{
		return blRet;
	}
	if (ulW_Div > (ULONG)US_MAX_FFFF)
	{
		blRet = FALSE;
		return blRet;
	}
	stB_ETS.stSec.usSec_msb = (USHORT)ulW_Div;


	stA_Sec48.usSec_msb = (USHORT)(ulW_Mod >> CONS_SHIFT16);
	stA_Sec48.ulSec_lsb = (ULONG)(((ulW_Mod & UL_MASK_0000FFFF) << CONS_SHIFT16)
							+ (pstUScaledNs->ulNsec_lsb >> CONS_SHIFT16));

	blRet = ptpDivSec48_UL(&stA_Sec48, ulW, &ulW_Div, &ulW_Mod);
	if (blRet == FALSE)
	{
		return blRet;
	}
	ulW2 = (ULONG)stB_ETS.stSec.usSec_msb + (ulW_Div >> CONS_SHIFT16);
	if (ulW2 > (ULONG)US_MAX_FFFF)
	{
		blRet = FALSE;
		return blRet;
	}
	stB_ETS.stSec.usSec_msb = (USHORT)ulW2;
	stB_ETS.stSec.ulSec_lsb = (ulW_Div & UL_MASK_0000FFFF) << CONS_SHIFT16;


	stA_Sec48.usSec_msb = (USHORT)(ulW_Mod >> CONS_SHIFT16);
	stA_Sec48.ulSec_lsb = ((ulW_Mod & UL_MASK_0000FFFF) << CONS_SHIFT16)
							+ (pstUScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);

	blRet = ptpDivSec48_UL(&stA_Sec48, ulW, &ulW_Div, &ulW_Mod);
	if (blRet == FALSE)
	{
		return blRet;
	}
	ulW2 = stB_ETS.stSec.ulSec_lsb + ulW_Div;
	if ((ulW2 < stB_ETS.stSec.ulSec_lsb) ||
		(ulW2 < ulW_Div))
	{
		if (stB_ETS.stSec.usSec_msb >= US_MAX_FFFF)
		{
			blRet = FALSE;
			return blRet;
		}
		else
		{
			stA_Sec48.usSec_msb = stA_Sec48.usSec_msb + CONST_1;
		}
	}
	stB_ETS.stSec.ulSec_lsb = ulW2;

	stB_ETS.stNsec.ulNsec = ulW_Mod;
	stB_ETS.stNsec.usFrcNsec = 	pstUScaledNs->usFrcNsec;

	(*pstETimestamp) = stB_ETS;
	blRet = TRUE;

	return	blRet;
}




BOOL	ptpConvETS_TS(
	EXTENDEDTIMESTAMP*	pstETimestamp,
	TIMESTAMP*			pstTimestamp)
{
	BOOL				blRet = TRUE;


	pstTimestamp->stSeconds = pstETimestamp->stSec;
	pstTimestamp->ulNanoseconds = pstETimestamp->stNsec.ulNsec;

	return blRet;
}





BOOL	ptpConvTS_USNs( 
	TIMESTAMP*	pstTimestamp,
	USCALEDNS*	pstUScaledNs)
{
	USCALEDNS			stA_USNs = {0};
	USCALEDNS			stB_USNs = {0};
	USCALEDNS			stC_USNs = {0};
	ULONG				ulW = 0;
	ULONG				ulW_m = 0;
	BOOL				blRet = FALSE;
	
	
	stA_USNs.usFrcNsec = 0;
	
	stA_USNs.ulNsec_lsb = pstTimestamp->ulNanoseconds;

	blRet = ptpMultUL_UL(pstTimestamp->stSeconds.ulSec_lsb, CONST10_9, &ulW_m, &ulW);
	if (blRet == FALSE)
	{
		return blRet;
	}
	stB_USNs.ulNsec_lsb = ulW;
	stB_USNs.ulNsec_2nd = ulW_m;

	blRet = ptpMultUL_UL((ULONG)(pstTimestamp->stSeconds.usSec_msb), CONST10_9, &ulW_m, &ulW);
	if ((blRet == FALSE) ||
		(ulW_m > (ULONG)US_MAX_FFFF))
	{
		blRet = FALSE;
		return blRet;
	}
	stA_USNs.ulNsec_2nd = ulW;
	stA_USNs.usNsec_msb = (USHORT)ulW_m;

	blRet = ptpAddUSNs_USNs(&stA_USNs, &stB_USNs, &stC_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}
	(*pstUScaledNs) = stC_USNs;

	return	blRet;
}




BOOL	ptpConvUSNs_TS( 
	USCALEDNS*	pstUScaledNs,
	TIMESTAMP*	pstTimestamp)
{
	EXTENDEDTIMESTAMP	stB_ETS = {0};
	BOOL				blRet	= FALSE;
	

	blRet = ptpConvUSNs_ETS(pstUScaledNs, &stB_ETS);
	if (blRet == FALSE)
	{
		return blRet;
	}

	pstTimestamp->stSeconds = stB_ETS.stSec;
	pstTimestamp->ulNanoseconds = stB_ETS.stNsec.ulNsec;

	return	blRet;
}




BOOL	ptpConvUSNs_SNs( 
	USCALEDNS*	pstA_UScaledNs,
	SCALEDNS*	pstB_ScaledNs)
{
	BOOL				blRet = FALSE;


	if (pstA_UScaledNs->usNsec_msb > S_MAX_7FFF)
	{
		return	blRet;
	}
	pstB_ScaledNs->sNsec_msb  = (SHORT)pstA_UScaledNs->usNsec_msb;
	pstB_ScaledNs->ulNsec_2nd = pstA_UScaledNs->ulNsec_2nd;
	pstB_ScaledNs->ulNsec_lsb = pstA_UScaledNs->ulNsec_lsb;
	pstB_ScaledNs->usFrcNsec  = pstA_UScaledNs->usFrcNsec;
	blRet = TRUE;

	return	blRet;
}




BOOL	ptpConvSNs_USNs( 
	SCALEDNS*	pstA_ScaledNs,
	USCALEDNS*	pstB_UScaledNs)
{
	BOOL				blRet = FALSE;


	if (pstA_ScaledNs->sNsec_msb < 0)
	{
		return	blRet;
	}
	pstB_UScaledNs->usNsec_msb = (USHORT)pstA_ScaledNs->sNsec_msb;
	pstB_UScaledNs->ulNsec_2nd = pstA_ScaledNs->ulNsec_2nd;
	pstB_UScaledNs->ulNsec_lsb = pstA_ScaledNs->ulNsec_lsb;
	pstB_UScaledNs->usFrcNsec  = pstA_ScaledNs->usFrcNsec;
	blRet = TRUE;

	return	blRet;
}




BOOL	ptpConvSNs_Dbl( 
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE*				pdbAnsDouble)
{
	BOOL		blRet	= FALSE;
	BOOL		blSignA = TRUE;
	SCALEDNS	stA_SNs = {0};
	DOUBLE		dbW		= DBCONST0_0;


	if (pstA_ScaledNs->sNsec_msb < 0)
	{
		blSignA = FALSE;
		blRet = ptp2sComplementSNs(pstA_ScaledNs, &stA_SNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}
	}
	else
	{
		stA_SNs = (*pstA_ScaledNs);
	}

	dbW = (DOUBLE)stA_SNs.sNsec_msb;
	dbW = (dbW * DBCONST2_32) + (DOUBLE)stA_SNs.ulNsec_2nd;
	dbW = (dbW * DBCONST2_32) + (DOUBLE)stA_SNs.ulNsec_lsb;
	dbW = (dbW * DBCONST2_16) + (DOUBLE)stA_SNs.usFrcNsec;

	if (blSignA == FALSE)
	{
		dbW = dbW * (-DBCONST1_0);
	}

	(*pdbAnsDouble) = dbW;
	blRet = TRUE;

	return	blRet;
}




BOOL	ptpConvSNs_TInt(
	SCALEDNS*		pstA_ScaledNs,
	TIME_INTERVAL*	pstB_Time_Interval)
{
	BOOL		blRet	= FALSE;
	SCALEDNS	stA_SNs = {0};


	if (pstA_ScaledNs->sNsec_msb < 0)
	{
		blRet = ptp2sComplementSNs(pstA_ScaledNs, &stA_SNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}
		if ((stA_SNs.sNsec_msb > 0) ||
			(stA_SNs.ulNsec_2nd >= (ULONG)S_MIN_8000))
		{
			if ((stA_SNs.ulNsec_2nd == (ULONG)S_MIN_8000))
			{
				if ((stA_SNs.ulNsec_lsb != 0) || (stA_SNs.usFrcNsec != 0))
				{
					blRet = FALSE;
					return	blRet;
				}
			}
			else

			{
				blRet = FALSE;
				return	blRet;
			}
		}
	}
	else
	{
		if ((pstA_ScaledNs->sNsec_msb > 0) ||
			(pstA_ScaledNs->ulNsec_2nd > (ULONG)S_MAX_7FFF))
		{
			blRet = FALSE;
			return	blRet;
		}
	}

	pstB_Time_Interval->sNsec_msb	= (SHORT)(pstA_ScaledNs->ulNsec_2nd);
	pstB_Time_Interval->ulNsec_lsb	= pstA_ScaledNs->ulNsec_lsb;
	pstB_Time_Interval->usFrcNsec	= pstA_ScaledNs->usFrcNsec;
	blRet = TRUE;

	return	blRet;
}







BOOL	ptpAddETS_USNs( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_USNs(&stA_USNs, pstB_UScaledNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddETS_SNs( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_SNs(&stA_USNs, pstB_ScaledNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddETS_TInt( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIME_INTERVAL*		pstB_Time_Interval,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_TInt(&stA_USNs, pstB_Time_Interval, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddTS_USNs( 
	TIMESTAMP*			pstA_Timestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvTS_USNs(pstA_Timestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_USNs(&stA_USNs, pstB_UScaledNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddTS_SNs( 
	TIMESTAMP*			pstA_Timestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvTS_USNs(pstA_Timestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_SNs(&stA_USNs, pstB_ScaledNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddTS_TInt( 
	TIMESTAMP*			pstA_Timestamp,
	TIME_INTERVAL*		pstB_Time_Interval,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};


	blRet = ptpConvTS_USNs(pstA_Timestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_TInt(&stA_USNs, pstB_Time_Interval, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpAddUSNs_USNs( 
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs,
	USCALEDNS*			pstAnsUScaledNs)
{
	ULONG		ul1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	ULONG		ul4		= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf1 = 0;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;

	ul1 = ((ULONG)pstA_UScaledNs->usFrcNsec) + ((ULONG)pstB_UScaledNs->usFrcNsec);
	if (ul1 > (ULONG)US_MAX_FFFF)
	{
		uchOvf1 = UCHCONST_1;
	}


	ul2 = pstA_UScaledNs->ulNsec_lsb + pstB_UScaledNs->ulNsec_lsb;
	if ((ul2 < pstA_UScaledNs->ulNsec_lsb) ||
		(ul2 < pstB_UScaledNs->ulNsec_lsb))
	{
		uchOvf2 = UCHCONST_1;
	}
	else if ((ul2 == UL_MAX_FFFFFFFF) &&
			 (uchOvf1 == UCHCONST_1))
	{
		uchOvf2 = UCHCONST_1;
	}
	else
	{
	}
	ul2 = ul2 + uchOvf1;


	ul3 = pstA_UScaledNs->ulNsec_2nd + pstB_UScaledNs->ulNsec_2nd;
	if ((ul3 < pstA_UScaledNs->ulNsec_2nd) ||
		(ul3 < pstB_UScaledNs->ulNsec_2nd))
	{
		uchOvf3 = UCHCONST_1;
	}
	else if ((ul3 == UL_MAX_FFFFFFFF) &&
			 (uchOvf2 == UCHCONST_1))
	{
		uchOvf3 = UCHCONST_1;
	}
	else
	{
	}
	ul3 = ul3 + uchOvf2;


	ul4	= ((ULONG)(pstA_UScaledNs->usNsec_msb)) + ((ULONG)(pstB_UScaledNs->usNsec_msb));
	ul4 = ul4 + uchOvf3;
	if (ul4  > (ULONG)US_MAX_FFFF)
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsUScaledNs->usFrcNsec	= (USHORT)ul1;
	pstAnsUScaledNs->ulNsec_lsb = ul2;
	pstAnsUScaledNs->ulNsec_2nd = ul3;
	pstAnsUScaledNs->usNsec_msb = (USHORT)ul4;

	blRet = TRUE;
	return	blRet;

}




BOOL	ptpAddUSNs_SNs( 
	USCALEDNS*			pstA_UScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	USCALEDNS*			pstAnsUScaledNs)
{
	ULONG		ul1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	LONG		l4		= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf1 = 0;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;


	ul1 = ((ULONG)pstA_UScaledNs->usFrcNsec) + ((ULONG)pstB_ScaledNs->usFrcNsec);
	if (ul1 > (ULONG)US_MAX_FFFF)
	{
		uchOvf1 = UCHCONST_1;
	}


	ul2 = pstA_UScaledNs->ulNsec_lsb + pstB_ScaledNs->ulNsec_lsb;
	if ((ul2 < pstA_UScaledNs->ulNsec_lsb) ||
		(ul2 < pstB_ScaledNs->ulNsec_lsb))
	{
		uchOvf2 = UCHCONST_1;
	}
	else if ((ul2 == UL_MAX_FFFFFFFF) &&
			 (uchOvf1 == UCHCONST_1))
	{
		uchOvf2 = UCHCONST_1;
	}
	else
	{
	}
	ul2 = ul2 + uchOvf1;


	ul3 = pstA_UScaledNs->ulNsec_2nd + pstB_ScaledNs->ulNsec_2nd;
	if ((ul3 < pstA_UScaledNs->ulNsec_2nd) ||
		(ul3 < pstB_ScaledNs->ulNsec_2nd))
	{
		uchOvf3 = UCHCONST_1;
	}
	else if ((ul3 == UL_MAX_FFFFFFFF) &&
			 (uchOvf2 == UCHCONST_1))
	{
		uchOvf3 = UCHCONST_1;
	}
	else
	{
	}
	ul3 = ul3 + uchOvf2;


	l4 = ((LONG)(pstA_UScaledNs->usNsec_msb)) + ((LONG)(pstB_ScaledNs->sNsec_msb));
	l4 = l4 + (LONG)uchOvf3;
	if ((l4 > (LONG)((ULONG)US_MAX_FFFF)) ||
		(l4 < 0))
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsUScaledNs->usFrcNsec	= (USHORT)ul1;
	pstAnsUScaledNs->ulNsec_lsb = ul2;
	pstAnsUScaledNs->ulNsec_2nd = ul3;
	pstAnsUScaledNs->usNsec_msb = (USHORT)l4;

	blRet = TRUE;
	return	blRet;
}




BOOL	ptpAddUSNs_TInt( 
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	USCALEDNS*			pstAnsUScaledNs)
{
	LONG		l4	  = 0;
	BOOL		blRet = FALSE;


	blRet = ptpAddUSNs_TInt_L4(pstA_UScaledNs,
								pstB_Time_Interval,
								pstAnsUScaledNs,
								&l4);
	if (blRet == FALSE)
	{
		return blRet;
	}


	if ((l4 > (LONG)((ULONG)US_MAX_FFFF)) ||
		(l4 < 0))
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsUScaledNs->usNsec_msb = (USHORT)l4;

	blRet = TRUE;
	return	blRet;
}




BOOL	ptpAddSNs_SNs( 
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	SCALEDNS*			pstAnsScaledNs)
{
	ULONG		ul1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	LONG		l4		= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf1 = 0;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;


	ul1 = ((ULONG)pstA_ScaledNs->usFrcNsec) + ((ULONG)pstB_ScaledNs->usFrcNsec);
	if (ul1 > (ULONG)US_MAX_FFFF)
	{
		uchOvf1 = UCHCONST_1;
	}


	ul2 = pstA_ScaledNs->ulNsec_lsb + pstB_ScaledNs->ulNsec_lsb;
	if ((ul2 < pstA_ScaledNs->ulNsec_lsb) ||
		(ul2 < pstB_ScaledNs->ulNsec_lsb))
	{
		uchOvf2 = UCHCONST_1;
	}
	else if ((ul2 == UL_MAX_FFFFFFFF) &&
			 (uchOvf1 == UCHCONST_1))
	{
		uchOvf2 = UCHCONST_1;
	}
	else
	{
	}
	ul2 = ul2 + uchOvf1;


	ul3 = pstA_ScaledNs->ulNsec_2nd + pstB_ScaledNs->ulNsec_2nd;
	if ((ul3 < pstA_ScaledNs->ulNsec_2nd) ||
		(ul3 < pstB_ScaledNs->ulNsec_2nd))
	{
		uchOvf3 = UCHCONST_1;
	}
	else if ((ul3 == UL_MAX_FFFFFFFF) &&
			 (uchOvf2 == UCHCONST_1))
	{
		uchOvf3 = UCHCONST_1;
	}
	else
	{
	}
	ul3 = ul3 + uchOvf2;


	l4 = ((LONG)(pstA_ScaledNs->sNsec_msb)) + ((LONG)(pstB_ScaledNs->sNsec_msb));
	l4 = l4 + (LONG)uchOvf3;
	if ((l4 > (LONG)CONS_SMAX) ||
		(l4 < (LONG)CONS_SMIN))
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsScaledNs->usFrcNsec  = (USHORT)ul1;
	pstAnsScaledNs->ulNsec_lsb = ul2;
	pstAnsScaledNs->ulNsec_2nd = ul3;
	pstAnsScaledNs->sNsec_msb  = (SHORT)l4;

	blRet = TRUE;
	return	blRet;
}




BOOL	ptpAddTInt_USNs( 
	TIME_INTERVAL*		pstA_Time_Interval,
	USCALEDNS*			pstB_UScaledNs,
	TIME_INTERVAL*		pstAnsTime_Interval)
{
	USCALEDNS	stAnsUScaledNs	= {0};
	ULONG		ul3				= 0;
	LONG		l4				= 0;
	BOOL		blRet			= FALSE;


	blRet = ptpAddUSNs_TInt_L4(pstB_UScaledNs,
								pstA_Time_Interval,
								&stAnsUScaledNs,
								&l4);
	if (blRet == FALSE)
	{
		return blRet;
	}

		
	if (l4 == -1)
	{
		ul3 = stAnsUScaledNs.ulNsec_2nd & UL_MASK_FFFF8000;

		if (ul3 != UL_MASK_FFFF8000)
		{
			blRet = FALSE;
			return	blRet;
		}
	}
	else if (l4 == 0)
	{
		if (stAnsUScaledNs.ulNsec_2nd > S_MAX_7FFF)
		{
			blRet = FALSE;
			return	blRet;
		}
	}
	else
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsTime_Interval->usFrcNsec = stAnsUScaledNs.usFrcNsec;
	pstAnsTime_Interval->ulNsec_lsb = stAnsUScaledNs.ulNsec_lsb;
	pstAnsTime_Interval->sNsec_msb = (SHORT)(stAnsUScaledNs.ulNsec_2nd & UL_MASK_0000FFFF);

	blRet = TRUE;

	return	blRet;
}




BOOL	ptpAddTInt_SNs( 
	TIME_INTERVAL*		pstA_Time_Interval,
	SCALEDNS*			pstB_ScaledNs,
	TIME_INTERVAL*		pstAnsTime_Interval)
{
	USCALEDNS	stW_UScaledNs	= {0};
	USCALEDNS	stAnsUScaledNs	= {0};
	ULONG		ul3				= 0;
	LONG		l4				= 0;
	LONG		l4_A			= 0;
	BOOL		blRet			= FALSE;
	UCHAR		uchOvf3			= 0;


	stW_UScaledNs.usFrcNsec = pstB_ScaledNs->usFrcNsec;
	stW_UScaledNs.ulNsec_lsb = pstB_ScaledNs->ulNsec_lsb;
	stW_UScaledNs.ulNsec_2nd = pstB_ScaledNs->ulNsec_2nd;

	blRet = ptpAddUSNs_TInt_Ul3(&stW_UScaledNs,
								pstA_Time_Interval,
								&stAnsUScaledNs,
								&uchOvf3);
	if (blRet == FALSE)
	{
		return blRet;
	}


	if (pstA_Time_Interval->sNsec_msb < 0)
	{
		l4_A = -1;
	}
	l4 = ((LONG)pstB_ScaledNs->sNsec_msb) + l4_A;
	l4 = l4 + (LONG)uchOvf3;

		
	if (l4 == -1)
	{
		ul3 = stAnsUScaledNs.ulNsec_2nd & UL_MASK_FFFF8000;

		if (ul3 != UL_MASK_FFFF8000)
		{
			blRet = FALSE;
			return	blRet;
		}
	}
	else if (l4 == 0)
	{
		if (stAnsUScaledNs.ulNsec_2nd > S_MAX_7FFF)
		{
			blRet = FALSE;
			return	blRet;
		}
	}
	else
	{
		blRet = FALSE;
		return	blRet;
	}

	pstAnsTime_Interval->usFrcNsec = stAnsUScaledNs.usFrcNsec;
	pstAnsTime_Interval->ulNsec_lsb = stAnsUScaledNs.ulNsec_lsb;
	pstAnsTime_Interval->sNsec_msb = (SHORT)(stAnsUScaledNs.ulNsec_2nd & UL_MASK_0000FFFF);

	blRet = TRUE;

	return	blRet;
}





BOOL	ptpAddTInt_TInt( 
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet			= FALSE;
	SCALEDNS	stA_ScaledNs	= {0};
	SCALEDNS	stB_ScaledNs	= {0};
	SHORT		sA_Nsec_msb		= 0;
	SHORT		sB_Nsec_msb		= 0;
	ULONG		ulTemp;

	ulTemp = (ULONG)pstA_Time_Interval->sNsec_msb;
	if (pstA_Time_Interval->sNsec_msb < 0)
	{
		sA_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstA_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stA_ScaledNs, 
					sA_Nsec_msb, 
					ulTemp,
					pstA_Time_Interval->ulNsec_lsb, 
					pstA_Time_Interval->usFrcNsec);

	ulTemp = (ULONG)pstB_Time_Interval->sNsec_msb;
	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		sB_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstB_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stB_ScaledNs, 
					sB_Nsec_msb, 
					ulTemp,
					pstB_Time_Interval->ulNsec_lsb, 
					pstB_Time_Interval->usFrcNsec);

	blRet = ptpAddSNs_SNs(&stA_ScaledNs,
							&stB_ScaledNs,
							pstAnsScaledNs);

	return blRet;
}




BOOL	ptpSubETS_USNs( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};
	USCALEDNS	stW2_USNs	= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpSubUSNs_USNs(&stA_USNs, pstB_UScaledNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvSNs_USNs(&stW_SNs, &stW2_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW2_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpSubETS_USNs_SNs( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	USCALEDNS*			pstB_UScaledNs,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpSubUSNs_USNs(&stA_USNs, pstB_UScaledNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	(*pstAnsScaledNs) = stW_SNs;

	return blRet;
}




BOOL	ptpSubETS_SNs( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	SCALEDNS*			pstB_ScaledNs,
	EXTENDEDTIMESTAMP*	pstAnsETimestamp)
{
	BOOL		blRet			= FALSE;
	USCALEDNS	stA_USNs		= {0};
	SCALEDNS	stBCompl_SNs	= {0};
	USCALEDNS	stW_USNs		= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptp2sComplementSNs(pstB_ScaledNs, &stBCompl_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpAddUSNs_SNs(&stA_USNs, &stBCompl_SNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvUSNs_ETS(&stW_USNs, pstAnsETimestamp);

	return blRet;
}




BOOL	ptpSubETS_ETS( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	EXTENDEDTIMESTAMP*	pstB_ETimestamp,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stB_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvETS_USNs(pstB_ETimestamp, &stB_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpSubUSNs_USNs(&stA_USNs, &stB_USNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	(*pstAnsScaledNs) = stW_SNs;

	return blRet;
}




BOOL	ptpSubETS_TS( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIMESTAMP*			pstB_Timestamp,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stB_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};


	blRet = ptpConvETS_USNs(pstA_ETimestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvTS_USNs(pstB_Timestamp, &stB_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpSubUSNs_USNs(&stA_USNs, &stB_USNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	(*pstAnsScaledNs) = stW_SNs;

	return blRet;
}




BOOL	ptpSubTS_TS( 
	TIMESTAMP*			pstA_Timestamp,
	TIMESTAMP*			pstB_Timestamp,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet		= FALSE;
	USCALEDNS	stA_USNs	= {0};
	USCALEDNS	stB_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};


	blRet = ptpConvTS_USNs(pstA_Timestamp, &stA_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpConvTS_USNs(pstB_Timestamp, &stB_USNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	blRet = ptpSubUSNs_USNs(&stA_USNs, &stB_USNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return blRet;
	}

	(*pstAnsScaledNs) = stW_SNs;

	return blRet;
}




BOOL	ptpSubUSNs_USNs( 
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet			= FALSE;
	USCALEDNS	stW_UScaledNs	= {0};
	USCALEDNS	stC_SScaledNs	= {0};
	LONG		l4				= 0;
	LONG		l4_W			= 0;
	UCHAR		uchOvf3			= 0;


	blRet = ptp2sComplementUSNs(pstB_UScaledNs, &stW_UScaledNs, &l4_W);
	if (blRet)
	{
		blRet = ptpAddUSNs_USNs_Ul3(pstA_UScaledNs, 
									&stW_UScaledNs, 
									&stC_SScaledNs,
									&uchOvf3);
		if (blRet == FALSE)
		{
			return	blRet;
		}

		l4	= (LONG)((ULONG)(pstA_UScaledNs->usNsec_msb)) + l4_W;
		l4 = l4 + (LONG)uchOvf3;
		if ((l4 > (LONG)CONS_SMAX) ||
			(l4 < (LONG)CONS_SMIN))
		{
			blRet = FALSE;
			return	blRet;
		}
		
	}
	pstAnsScaledNs->usFrcNsec  = stC_SScaledNs.usFrcNsec;
	pstAnsScaledNs->ulNsec_lsb = stC_SScaledNs.ulNsec_lsb;
	pstAnsScaledNs->ulNsec_2nd = stC_SScaledNs.ulNsec_2nd;
	pstAnsScaledNs->sNsec_msb = (SHORT)((ULONG)l4 & UL_MASK_0000FFFF);

	blRet = TRUE;

	return	blRet;
}



BOOL	ptpSubSNs_SNs( 
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet			= FALSE;
	SCALEDNS	stW_ScaledNs	= {0};


	blRet = ptp2sComplementSNs(pstB_ScaledNs, &stW_ScaledNs);
	if (blRet)
	{
		blRet = ptpAddSNs_SNs(pstA_ScaledNs,  &stW_ScaledNs, pstAnsScaledNs);
	}

	return blRet;
}




BOOL	ptpSubSNs_TInt( 
	SCALEDNS*			pstA_ScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet			= FALSE;
	SCALEDNS	stB_ScaledNs	= {0};
	SHORT		sB_Nsec_msb		= 0;
	SCALEDNS	stW_ScaledNs	= {0};
	ULONG		ulTemp;

	ulTemp = (ULONG)pstB_Time_Interval->sNsec_msb;
	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		sB_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstB_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stB_ScaledNs, 
					sB_Nsec_msb, 
					ulTemp,
					pstB_Time_Interval->ulNsec_lsb, 
					pstB_Time_Interval->usFrcNsec);

	blRet = ptpSubSNs_SNs(pstA_ScaledNs,
							&stB_ScaledNs,
							&stW_ScaledNs);

	(*pstAnsScaledNs) = stW_ScaledNs;

	return blRet;
}




BOOL	ptpSubTInt_TInt( 
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval,
	TIME_INTERVAL*		pstAnsTime_Interval)
{
	BOOL		blRet			= FALSE;
	SCALEDNS	stA_ScaledNs	= {0};
	SCALEDNS	stB_ScaledNs	= {0};
	SHORT		sA_Nsec_msb		= 0;
	SHORT		sB_Nsec_msb		= 0;
	SCALEDNS	stW_ScaledNs	= {0};
	SCALEDNS	stW2_ScaledNs	= {0};

	ULONG		ulTemp;

	ulTemp = (ULONG)pstA_Time_Interval->sNsec_msb;

	if (pstA_Time_Interval->sNsec_msb < 0)
	{
		sA_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstA_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stA_ScaledNs, 
					sA_Nsec_msb, 
					ulTemp,
					pstA_Time_Interval->ulNsec_lsb, 
					pstA_Time_Interval->usFrcNsec);
	ulTemp = (ULONG)pstB_Time_Interval->sNsec_msb;
	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		sB_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstB_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stB_ScaledNs, 
					sB_Nsec_msb, 
					ulTemp,
					pstB_Time_Interval->ulNsec_lsb, 
					pstB_Time_Interval->usFrcNsec);

	blRet = ptpSubSNs_SNs(&stA_ScaledNs,
							&stB_ScaledNs,
							&stW_ScaledNs);

	if (blRet)
	{
		if (stW_ScaledNs.sNsec_msb < 0)
		{
			blRet = ptp2sComplementSNs(&stW_ScaledNs, &stW2_ScaledNs);
			if (blRet)
			{
				if((stW2_ScaledNs.sNsec_msb == 0) &&
				   (stW2_ScaledNs.ulNsec_2nd > (ULONG)S_MIN_8000))
				{
					blRet = FALSE;
					return blRet;
				}
			}
			else
			{
				return blRet;
			}
		}
		else
		{
			if((stW_ScaledNs.sNsec_msb == 0) &&
			   (stW_ScaledNs.ulNsec_2nd > (ULONG)S_MAX_7FFF))
			{
				blRet = FALSE;
				return blRet;
			}
		}
		SET_TIME_INTERVAL((*pstAnsTime_Interval),
							((SHORT)(stW_ScaledNs.ulNsec_2nd & UL_MASK_0000FFFF)),
							stW_ScaledNs.ulNsec_lsb,
							stW_ScaledNs.usFrcNsec);
	}

	return blRet;
}








BOOL	ptpMultUSNs_ULONG( 
	USCALEDNS*			pstA_UScaledNs,
	ULONG				ulB_Long,
	USCALEDNS*			pstAnsUScaledNs)
{
	USHORT		us1		= 0;
	ULONG		ul2		= 0;
	ULONG		ul3		= 0;
	ULONG		ul4		= 0;
	ULONG		ulW		= 0;
	ULONG		ulWmsb	= 0;
	ULONG		ulWlsb	= 0;
	BOOL		blRet	= FALSE;
	UCHAR		uchOvf2 = 0;
	UCHAR		uchOvf3 = 0;


	blRet = ptpMultUL_UL((ULONG)(pstA_UScaledNs->usFrcNsec),
							ulB_Long,
							&ulWmsb,
							&ulWlsb);
	if (blRet == FALSE)
	{
		return	blRet;
	}
	us1 = (USHORT)(ulWlsb & UL_MASK_0000FFFF);
	ulW = (ulWmsb << CONS_SHIFT16) + (ulWlsb >> CONS_SHIFT16);

	
	blRet = ptpMultUL_UL((ULONG)(pstA_UScaledNs->ulNsec_lsb),
							ulB_Long,
							&ulWmsb,
							&ulWlsb);
	if (blRet == FALSE)
	{
		return	blRet;
	}
	ul2 = ulWlsb + ulW;
	if ((ul2 < ulWlsb) ||
		(ul2 < ulW))
	{
		uchOvf2 = UCHCONST_1;
	}
	ulW = ulWmsb + uchOvf2;


	blRet = ptpMultUL_UL((ULONG)(pstA_UScaledNs->ulNsec_2nd),
							ulB_Long,
							&ulWmsb,
							&ulWlsb);
	if (blRet == FALSE)
	{
		return	blRet;
	}
	ul3 = ulWlsb + ulW;
	if ((ul3 < ulWlsb) ||
		(ul3 < ulW))
	{
		uchOvf3 = UCHCONST_1;
	}
	ulW = ulWmsb + uchOvf3;


	blRet = ptpMultUL_UL((ULONG)(pstA_UScaledNs->usNsec_msb),
							ulB_Long,
							&ulWmsb,
							&ulWlsb);
	if (blRet == FALSE)
	{
		return	blRet;
	}
	ul4 = ulWlsb + ulW;
	if ((ul4 < ulWlsb) ||
		(ul4 < ulW))
	{
		blRet = FALSE;
		return	blRet;
	}

	if ((ul4 > (ULONG)US_MAX_FFFF) ||
		(ulWmsb > 0))
	{
		blRet = FALSE;
		return	blRet;
	}


	pstAnsUScaledNs->usFrcNsec	= us1;
	pstAnsUScaledNs->ulNsec_lsb = ul2;
	pstAnsUScaledNs->ulNsec_2nd = ul3;
	pstAnsUScaledNs->usNsec_msb = (USHORT)ul4;

	blRet = TRUE;
	return	blRet;

}




BOOL	ptpMultUSNs_Doub( 
	USCALEDNS*			pstA_UScaledNs,
	DOUBLE				dbB_Double,
	USCALEDNS*			pstAnsUScaledNs)
{
	USCALEDNS	stW_USNs	= {0};
	USCALEDNS	stW2_USNs	= {0};
	USCALEDNS	stAns_USNs	= {0};
	DOUBLE		dbW			= 0.0;
	BOOL		blRet		= FALSE;


	dbW = (DOUBLE)(pstA_UScaledNs->usFrcNsec) * dbB_Double;

	blRet = setDbToUSNs(dbW, GPOS_USNS_00, &stAns_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_UScaledNs->ulNsec_lsb) * dbB_Double;

	blRet = setDbToUSNs(dbW, GPOS_USNS_16, &stW_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddUSNs_USNs(&stAns_USNs, &stW_USNs, &stW2_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_UScaledNs->ulNsec_2nd) * dbB_Double;

	SET_USCALEDNS(stAns_USNs, 0, 0, 0, 0);
	blRet = setDbToUSNs(dbW, GPOS_USNS_48, &stAns_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddUSNs_USNs(&stAns_USNs, &stW2_USNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_UScaledNs->usNsec_msb) * dbB_Double;

	SET_USCALEDNS(stW2_USNs, 0, 0, 0, 0);
	blRet = setDbToUSNs(dbW, GPOS_USNS_80, &stW2_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddUSNs_USNs(&stW_USNs, &stW2_USNs, &stAns_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	(*pstAnsUScaledNs) = stAns_USNs;

	blRet = TRUE;
	return	blRet;

}




BOOL	ptpMultSNs_Doub( 
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE				dbB_Double,
	SCALEDNS*			pstAnsScaledNs)
{
	SCALEDNS	stW_SNs		= {0};
	SCALEDNS	stW2_SNs	= {0};
	SCALEDNS	stAns_SNs	= {0};
	DOUBLE		dbW			= 0.0;
	BOOL		blRet		= FALSE;


	dbW = (DOUBLE)(pstA_ScaledNs->usFrcNsec) * dbB_Double;

	blRet = setDbToSNs(dbW, GPOS_USNS_00, &stAns_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_ScaledNs->ulNsec_lsb) * dbB_Double;

	blRet = setDbToSNs(dbW, GPOS_USNS_16, &stW_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddSNs_SNs(&stAns_SNs, &stW_SNs, &stW2_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_ScaledNs->ulNsec_2nd) * dbB_Double;

	SET_SCALEDNS(stAns_SNs, 0, 0, 0, 0);
	blRet = setDbToSNs(dbW, GPOS_USNS_48, &stAns_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddSNs_SNs(&stAns_SNs, &stW2_SNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_ScaledNs->sNsec_msb) * dbB_Double;

	SET_SCALEDNS(stW2_SNs, 0, 0, 0, 0);
	blRet = setDbToSNs(dbW, GPOS_USNS_80, &stW2_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddSNs_SNs(&stW_SNs, &stW2_SNs, &stAns_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	(*pstAnsScaledNs) = stAns_SNs;

	blRet = TRUE;
	return	blRet;

}




BOOL	ptpMultTInt_Doub( 
	TIME_INTERVAL*		pstA_Time_Interval,
	DOUBLE				dbB_Double,
	TIME_INTERVAL*		pstAnsTime_Interval)
{
	TIME_INTERVAL	stW_TInt	= {0};
	SCALEDNS		stW2_SNs	= {0};
	TIME_INTERVAL	stAns_TInt	= {0};
	DOUBLE			dbW			= 0.0;
	BOOL			blRet		= FALSE;


	dbW = (DOUBLE)(pstA_Time_Interval->usFrcNsec) * dbB_Double;

	blRet = setDbToTInt(dbW, GPOS_USNS_00, &stAns_TInt);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_Time_Interval->ulNsec_lsb) * dbB_Double;

	blRet = setDbToTInt(dbW, GPOS_USNS_16, &stW_TInt);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddTInt_TInt(&stAns_TInt, &stW_TInt, &stW2_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	dbW = (DOUBLE)(pstA_Time_Interval->sNsec_msb) * dbB_Double;

	SET_TIME_INTERVAL(stW_TInt, 0, 0, 0);
	blRet = setDbToTInt(dbW, GPOS_USNS_48, &stW_TInt);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpAddTInt_SNs(&stW_TInt, &stW2_SNs, &stAns_TInt);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	(*pstAnsTime_Interval) = stAns_TInt;

	blRet = TRUE;
	return	blRet;

}





BOOL	ptpShiftUSNs_CHAR( 
	USCALEDNS*			pstA_UScaledNs,
	CHAR				chB_Shift,
	USCALEDNS*			pstAnsUScaledNs)
{
	USCALEDNS	stAns_USNs	= {0};
	CHAR		chW			= 0;
	USHORT		usAW1		= 0;
	USHORT		usAW2		= 0;
	USHORT		usAW3		= 0;
	USHORT		usAW4		= 0;
	USHORT		usAW5		= 0;
	USHORT		usAW6		= 0;
	USHORT		usCW1		= 0;
	USHORT		usCW2		= 0;
	USHORT		usCW3		= 0;
	USHORT		usCW4		= 0;
	USHORT		usCW5		= 0;
	USHORT		usCW6		= 0;
	BOOL		blRet		= FALSE;


	if((chB_Shift >= CONS_SHIFT96) ||
		(chB_Shift <= -CONS_SHIFT96))
	{
		return	blRet;
	}

	chW = chB_Shift;

	if (chB_Shift >= 0)
	{
		if (chB_Shift < CONS_SHIFT16)
		{
			usAW1 = pstA_UScaledNs->usFrcNsec;
			usAW2 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW3 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW4 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW5 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW6 = pstA_UScaledNs->usNsec_msb;

		}
		else if (chB_Shift < CONS_SHIFT32)
		{
			usAW2 = pstA_UScaledNs->usFrcNsec;
			usAW3 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW4 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW5 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW6 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);

			chW = chW - CONS_USHORT16;
		}
		else if (chB_Shift < CONS_SHIFT48)
		{
			usAW3 = pstA_UScaledNs->usFrcNsec;
			usAW4 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW5 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW6 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);

			chW = chW - CONS_SHIFT32;
		}
		else if (chB_Shift < CONS_SHIFT64)
		{
			usAW4 = pstA_UScaledNs->usFrcNsec;
			usAW5 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW6 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			
			chW = chW - CONS_SHIFT48;
		}
		else if (chB_Shift < CONS_SHIFT80)
		{
			usAW5 = pstA_UScaledNs->usFrcNsec;
			usAW6 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			
			chW = chW - CONS_SHIFT64;
		}
		else
		{
			usAW6 = pstA_UScaledNs->usFrcNsec;
			
			chW = chW - CONS_SHIFT80;
		}

		if (chW == 0)
		{
			usCW1 = usAW1;
			usCW2 = usAW2;
			usCW3 = usAW3;
			usCW4 = usAW4;
			usCW5 = usAW5;
			usCW6 = usAW6;
		}
		else
		{
			usCW1 = usAW1 << chW;
			usCW2 = (usAW2 << chW) + (usAW1 >> (CONS_USHORT16 - chW));
			usCW3 = (usAW3 << chW) + (usAW2 >> (CONS_USHORT16 - chW));
			usCW4 = (usAW4 << chW) + (usAW3 >> (CONS_USHORT16 - chW));
			usCW5 = (usAW5 << chW) + (usAW4 >> (CONS_USHORT16 - chW));
			usCW6 = (usAW6 << chW) + (usAW5 >> (CONS_USHORT16 - chW));
		}
	}
	else
	{
		chW = -chB_Shift;
		if (chB_Shift > -CONS_SHIFT16)
		{
			usAW1 = pstA_UScaledNs->usFrcNsec;
			usAW2 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW3 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW4 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW5 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW6 = pstA_UScaledNs->usNsec_msb;

		}
		else if (chB_Shift > -CONS_SHIFT32)
		{
			usAW1 = (USHORT)(pstA_UScaledNs->ulNsec_lsb & UL_MASK_0000FFFF);
			usAW2 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW3 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW4 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW5 = pstA_UScaledNs->usNsec_msb;

			chW = chW - CONS_USHORT16;
		}
		else if (chB_Shift > -CONS_SHIFT48)
		{
			usAW1 = (USHORT)((pstA_UScaledNs->ulNsec_lsb & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW2 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW3 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW4 = pstA_UScaledNs->usNsec_msb;

			chW = chW - CONS_SHIFT32;
		}
		else if (chB_Shift > -CONS_SHIFT64)
		{
			usAW1 = (USHORT)(pstA_UScaledNs->ulNsec_2nd & UL_MASK_0000FFFF);
			usAW2 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW3 = pstA_UScaledNs->usNsec_msb;

			chW = chW - CONS_SHIFT48;
		}
		else if (chB_Shift > -CONS_SHIFT80)
		{
			usAW1 = (USHORT)((pstA_UScaledNs->ulNsec_2nd & UL_MASK_FFFF0000) >> CONS_USHORT16);
			usAW2 = pstA_UScaledNs->usNsec_msb;

			chW = chW - CONS_SHIFT64;
		}
		else
		{
			usAW1 = pstA_UScaledNs->usNsec_msb;

			chW = chW - CONS_SHIFT80;
		}

		if (chW == 0)
		{
			usCW1 = usAW1;
			usCW2 = usAW2;
			usCW3 = usAW3;
			usCW4 = usAW4;
			usCW5 = usAW5;
			usCW6 = usAW6;
		}
		else
		{
			usCW1 = (usAW1 >> chW) + (usAW2 << (CONS_USHORT16 - chW));
			usCW2 = (usAW2 >> chW) + (usAW3 << (CONS_USHORT16 - chW));
			usCW3 = (usAW3 >> chW) + (usAW4 << (CONS_USHORT16 - chW));
			usCW4 = (usAW4 >> chW) + (usAW5 << (CONS_USHORT16 - chW));
			usCW5 = (usAW5 >> chW) + (usAW6 << (CONS_USHORT16 - chW));
			usCW6 = usAW6 >> chW									;
		}

	}

	stAns_USNs.usFrcNsec	= usCW1;
	stAns_USNs.ulNsec_lsb	= (((ULONG)usCW3) << CONS_USHORT16) + (ULONG)usCW2;
	stAns_USNs.ulNsec_2nd	= (((ULONG)usCW5) << CONS_USHORT16) + (ULONG)usCW4;
	stAns_USNs.usNsec_msb	= usCW6;

	(*pstAnsUScaledNs) = stAns_USNs;

	
	blRet = TRUE;

	return	blRet;
}




BOOL	ptpShiftSNs_CHAR( 
	SCALEDNS*			pstA_ScaledNs,
	CHAR				chB_Shift,
	SCALEDNS*			pstAnsScaledNs)
{
	SCALEDNS	stAns_SNs	= {0};
	SCALEDNS	stAW_SNs	= {0};
	USCALEDNS	stAW2_USNs	= {0};
	USCALEDNS	stAW3_USNs	= {0};
	SCALEDNS	stAW4_SNs	= {0};
	BOOL		blSign		= TRUE;
	BOOL		blRet		= FALSE;


	if((chB_Shift >= CONS_SHIFT96) ||
	   (chB_Shift <= -CONS_SHIFT96))
	{
		return	blRet;
	}


	if (pstA_ScaledNs->sNsec_msb < 0)
	{
		blSign = FALSE;
		blRet = ptp2sComplementSNs(pstA_ScaledNs, &stAW_SNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}

		stAW2_USNs.usFrcNsec  = stAW_SNs.usFrcNsec;
		stAW2_USNs.ulNsec_lsb = stAW_SNs.ulNsec_lsb;
		stAW2_USNs.ulNsec_2nd = stAW_SNs.ulNsec_2nd;
		stAW2_USNs.usNsec_msb = (USHORT)stAW_SNs.sNsec_msb;
	}
	else
	{
		stAW2_USNs.usFrcNsec  = pstA_ScaledNs->usFrcNsec;
		stAW2_USNs.ulNsec_lsb = pstA_ScaledNs->ulNsec_lsb;
		stAW2_USNs.ulNsec_2nd = pstA_ScaledNs->ulNsec_2nd;
		stAW2_USNs.usNsec_msb = (USHORT)pstA_ScaledNs->sNsec_msb;
	}

	blRet = ptpShiftUSNs_CHAR(&stAW2_USNs, chB_Shift, &stAW3_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	stAW3_USNs.usNsec_msb = stAW3_USNs.usNsec_msb & S_MAX_7FFF;
	if (blSign == FALSE)
	{

		stAW4_SNs.usFrcNsec  = stAW3_USNs.usFrcNsec;
		stAW4_SNs.ulNsec_lsb = stAW3_USNs.ulNsec_lsb;
		stAW4_SNs.ulNsec_2nd = stAW3_USNs.ulNsec_2nd;
		stAW4_SNs.sNsec_msb = (SHORT)stAW3_USNs.usNsec_msb;

		blRet = ptp2sComplementSNs(&stAW4_SNs, &stAns_SNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}
	}
	else
	{
		stAns_SNs.usFrcNsec  = stAW3_USNs.usFrcNsec;
		stAns_SNs.ulNsec_lsb = stAW3_USNs.ulNsec_lsb;
		stAns_SNs.ulNsec_2nd = stAW3_USNs.ulNsec_2nd;
		stAns_SNs.sNsec_msb = (SHORT)stAW3_USNs.usNsec_msb;
	}

	(*pstAnsScaledNs) = stAns_SNs;

	blRet = TRUE;

	return	blRet;
}





BOOL	ptpDivUSNs_Doub( 
	USCALEDNS*			pstA_UScaledNs,
	DOUBLE				dbB_Double,
	USCALEDNS*			pstAnsUScaledNs)
{
	DOUBLE		dbW		= 0.0;
	BOOL		blRet	= FALSE;
	DOUBLE		dbB1	= 0.0;
	DOUBLE		dbB2	= 0.0;
	ULONG		ulB1 = 0;
	USHORT		usB2 = 0;
	DOUBLE		dbW_1	= 0.0;
	DOUBLE		dbW_2	= 0.0;
	DOUBLE		dbW_3	= 0.0;
	DOUBLE		dbW_4	= 0.0;
	DOUBLE		dbW_6	= 0.0;
	DOUBLE		dbW_Diff	= 0.0;
	USCALEDNS	stC1_USNs	= {0};
	USCALEDNS	stC2_USNs	= {0};
	USCALEDNS	stW_USNs	= {0};
	SHORT		sCnt;
	SHORT		sCnt1;

	if (IS_EPSILON0_0(dbB_Double))
	{
		blRet = FALSE;
		return	blRet;
	}


	dbW = DBCONST1_0 / dbB_Double;

	
	dbW_1 = dbW;
	if (dbW_1 <= DBCONST1_0)
	{
		sCnt = 0;
	}
	else
	{
		for (sCnt = 1; sCnt <= SCONST_12; sCnt++)
		{
			dbW_1 = dbW_1 / DBCONST2_8;
			if (dbW_1 <= DBCONST1_0)
			{
				break;
			}
		}
	}
	if (sCnt > SCONST_12)
	{
		blRet	= FALSE;
		return blRet;
	}


	dbW_2 = dbW_1 * DBCONST2_32;
	ulB1  = (ULONG)dbW_2;
	dbW_3 = dbW_2 - (DOUBLE)ulB1;
	dbW_4 = dbW_3 * DBCONST2_16;
	usB2  = (USHORT)dbW_4;

	dbW_6 = (DOUBLE)usB2;
	dbW_6 = dbW_6 / DBCONST2_16;
	dbW_6 = dbW_6 + (DOUBLE)ulB1;
	dbW_6 = dbW_6 / DBCONST2_32;
	sCnt1 = sCnt * 8;
	{
		DOUBLE	dbB1_s = {0};

		dbB1_s = (DOUBLE)(1 << sCnt1);
		dbB1 = dbW_6 * dbB1_s;
	}

	dbW_Diff = DBCONST1_0 - (dbB1 * dbB_Double);
	dbB2 = dbW_Diff / dbB_Double;

	blRet = ptpMultUSNs_Doub(pstA_UScaledNs, dbB1, &stC1_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpMultUSNs_Doub(pstA_UScaledNs, dbB2, &stC2_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}


	blRet = ptpAddUSNs_USNs(&stC1_USNs, &stC2_USNs, &stW_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	(*pstAnsUScaledNs) = stW_USNs;

	return	blRet;
}




BOOL	ptpDivSNs_Doub(
	SCALEDNS*			pstA_ScaledNs,
	DOUBLE				dbB_Double,
	SCALEDNS*			pstAnsScaledNs)
{
	BOOL		blRet	= FALSE;
	SCALEDNS	stA_SNs		= {0};
	USCALEDNS	stA_USNs	= {0};
	SCALEDNS	stW_SNs		= {0};
	USCALEDNS	stW_USNs	= {0};
	DOUBLE		dbDoubleW	= DBCONST0_0;
	BOOL		blSignA = TRUE;
	BOOL		blSignB = TRUE;



	if (pstA_ScaledNs->sNsec_msb < 0)
	{
		blSignA = FALSE;
		blRet = ptp2sComplementSNs(pstA_ScaledNs, &stA_SNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}
	}
	else
	{
		stA_SNs = *pstA_ScaledNs;
	}

	(VOID)ptpConvSNs_USNs(&stA_SNs, &stA_USNs);

	if (dbB_Double < DBCONST0_0)
	{
		blSignB = FALSE;
		dbDoubleW = -dbB_Double;
	}
	else
	{
		dbDoubleW = dbB_Double;
	}

	blRet = ptpDivUSNs_Doub(&stA_USNs,
							dbDoubleW,
							&stW_USNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpConvUSNs_SNs(&stW_USNs, &stW_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	if (((blSignA == FALSE) && (blSignB == TRUE) ) ||
		((blSignA == TRUE)	&& (blSignB == FALSE)))
	{
		blRet = ptp2sComplementSNs(&stW_SNs, pstAnsScaledNs);
		if (blRet == FALSE)
		{
			return	blRet;
		}
	}
	else
	{
		(*pstAnsScaledNs) = stW_SNs;
	}

	blRet = TRUE;
	return	blRet;
}




BOOL	ptpDivTInt_Doub( 
	TIME_INTERVAL*		pstA_Time_Interval,
	DOUBLE				dbB_Double,
	TIME_INTERVAL*		pstAnsTime_Interval)
{
	BOOL			blRet		= FALSE;
	SHORT			sA_Nsec_msb	= 0;
	SCALEDNS		stA_SNs		= {0};
	SCALEDNS		stW_SNs		= {0};
	TIME_INTERVAL	stW_TInt	= {0};

	ULONG			ulTemp;

	ulTemp = (ULONG)pstA_Time_Interval->sNsec_msb;


	if (pstA_Time_Interval->sNsec_msb < 0)
	{
		sA_Nsec_msb = -1;
		ulTemp = (ULONG)0x0000FFFFL;
		ulTemp = ulTemp << 16;
		ulTemp |= (ULONG)pstA_Time_Interval->sNsec_msb;
	}
	SET_SCALEDNS(stA_SNs, 
					sA_Nsec_msb, 
					ulTemp,
					pstA_Time_Interval->ulNsec_lsb, 
					pstA_Time_Interval->usFrcNsec);

	blRet = ptpDivSNs_Doub(&stA_SNs,
							dbB_Double,
							&stW_SNs);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpConvSNs_TInt(&stW_SNs, &stW_TInt);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	(*pstAnsTime_Interval) = stW_TInt;

	blRet = TRUE;
	return	blRet;
}





BOOL	ptpDivSNs_SNs( 
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs,
	DOUBLE*				pdbAnsDouble)
{
	BOOL		blRet	= FALSE;
	DOUBLE		dbA_W	= 0.0;
	DOUBLE		dbB_W	= 0.0;
	DOUBLE		dbAns_W = 0.0;


	blRet = ptpConvSNs_Dbl(pstA_ScaledNs, &dbA_W);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	blRet = ptpConvSNs_Dbl(pstB_ScaledNs, &dbB_W);
	if (blRet == FALSE)
	{
		return	blRet;
	}

	if (IS_EPSILON0_0(dbB_W))
	{
		blRet = FALSE;
		return	blRet;
	}

	dbAns_W = dbA_W / dbB_W;

	(*pdbAnsDouble) = dbAns_W;

	blRet = TRUE;

	return	blRet;
}






 
CHAR	ptpCompETS_ETS( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	EXTENDEDTIMESTAMP*	pstB_ETimestamp)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstA_ETimestamp->stSec.usSec_msb > pstB_ETimestamp->stSec.usSec_msb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stSec.usSec_msb < pstB_ETimestamp->stSec.usSec_msb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stSec.ulSec_lsb > pstB_ETimestamp->stSec.ulSec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stSec.ulSec_lsb < pstB_ETimestamp->stSec.ulSec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stNsec.ulNsec > pstB_ETimestamp->stNsec.ulNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stNsec.ulNsec < pstB_ETimestamp->stNsec.ulNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stNsec.usFrcNsec > pstB_ETimestamp->stNsec.usFrcNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stNsec.usFrcNsec < pstB_ETimestamp->stNsec.usFrcNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompETS_TS( 
	EXTENDEDTIMESTAMP*	pstA_ETimestamp,
	TIMESTAMP*			pstB_Timestamp)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstA_ETimestamp->stSec.usSec_msb > pstB_Timestamp->stSeconds.usSec_msb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stSec.usSec_msb < pstB_Timestamp->stSeconds.usSec_msb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stSec.ulSec_lsb > pstB_Timestamp->stSeconds.ulSec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stSec.ulSec_lsb < pstB_Timestamp->stSeconds.ulSec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stNsec.ulNsec > pstB_Timestamp->ulNanoseconds)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_ETimestamp->stNsec.ulNsec <  pstB_Timestamp->ulNanoseconds)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_ETimestamp->stNsec.usFrcNsec > 0 )
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompTS_TS( 
	TIMESTAMP*			pstA_Timestamp,
	TIMESTAMP*			pstB_Timestamp)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstA_Timestamp->stSeconds.usSec_msb > pstB_Timestamp->stSeconds.usSec_msb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_Timestamp->stSeconds.usSec_msb < pstB_Timestamp->stSeconds.usSec_msb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_Timestamp->stSeconds.ulSec_lsb > pstB_Timestamp->stSeconds.ulSec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_Timestamp->stSeconds.ulSec_lsb < pstB_Timestamp->stSeconds.ulSec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_Timestamp->ulNanoseconds > pstB_Timestamp->ulNanoseconds)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_Timestamp->ulNanoseconds <  pstB_Timestamp->ulNanoseconds)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompUSNs_USNs( 
	USCALEDNS*			pstA_UScaledNs,
	USCALEDNS*			pstB_UScaledNs)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstA_UScaledNs->usNsec_msb > pstB_UScaledNs->usNsec_msb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->usNsec_msb < pstB_UScaledNs->usNsec_msb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->ulNsec_2nd > pstB_UScaledNs->ulNsec_2nd)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_2nd < pstB_UScaledNs->ulNsec_2nd)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->ulNsec_lsb > pstB_UScaledNs->ulNsec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_lsb < pstB_UScaledNs->ulNsec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->usFrcNsec > pstB_UScaledNs->usFrcNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->usFrcNsec < pstB_UScaledNs->usFrcNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompUSNs_SNs( 
	USCALEDNS*			pstA_UScaledNs,
	SCALEDNS*			pstB_ScaledNs)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstB_ScaledNs->sNsec_msb < 0)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}


	if (pstA_UScaledNs->usNsec_msb > (USHORT)(pstB_ScaledNs->sNsec_msb))
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->usNsec_msb < (USHORT)(pstB_ScaledNs->sNsec_msb))
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->ulNsec_2nd > pstB_ScaledNs->ulNsec_2nd)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_2nd < pstB_ScaledNs->ulNsec_2nd)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->ulNsec_lsb > pstB_ScaledNs->ulNsec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_lsb < pstB_ScaledNs->ulNsec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->usFrcNsec > pstB_ScaledNs->usFrcNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->usFrcNsec < pstB_ScaledNs->usFrcNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompUSNs_TInt( 
	USCALEDNS*			pstA_UScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval)
{
	CHAR		chRet = COMP_EQUAL;


	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}


	if (pstA_UScaledNs->usNsec_msb > 0)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}


	if (pstA_UScaledNs->ulNsec_2nd > (ULONG)(pstB_Time_Interval->sNsec_msb))
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_2nd < (ULONG)(pstB_Time_Interval->sNsec_msb))
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->ulNsec_lsb > pstB_Time_Interval->ulNsec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->ulNsec_lsb < pstB_Time_Interval->ulNsec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_UScaledNs->usFrcNsec > pstB_Time_Interval->usFrcNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_UScaledNs->usFrcNsec < pstB_Time_Interval->usFrcNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompSNs_SNs(
	SCALEDNS*			pstA_ScaledNs,
	SCALEDNS*			pstB_ScaledNs)
{
	SCALEDNS	stA_SNs		= {0};
	SCALEDNS	stB_SNs		= {0};
	SCALEDNS*	pstA_SNs	= pstA_ScaledNs;
	SCALEDNS*	pstB_SNs	= pstB_ScaledNs;
	CHAR		chRet		= COMP_EQUAL;
	BOOL		blRetA		= FALSE;
	BOOL		blRetB		= FALSE;


	if ((pstA_ScaledNs->sNsec_msb >= 0) &&
		(pstB_ScaledNs->sNsec_msb < 0))
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if ((pstA_ScaledNs->sNsec_msb < 0) &&
			 (pstB_ScaledNs->sNsec_msb >= 0))
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else if (pstA_ScaledNs->sNsec_msb < 0)
	{
		blRetA = ptp2sComplementSNs(pstA_ScaledNs, &stA_SNs);
		blRetB = ptp2sComplementSNs(pstB_ScaledNs, &stB_SNs);

		if ((blRetA == FALSE) && 
			(blRetB == FALSE))
		{
			chRet = COMP_EQUAL;
			return	chRet;
		}
		else if (blRetA == FALSE)
		{
			chRet = COMP_A_LESS;
			return	chRet;
		}
		else if (blRetB == FALSE)
		{
			chRet = COMP_A_GREAT;
			return	chRet;
		}
		else
		{
		}
		pstA_SNs = &stB_SNs;
		pstB_SNs = &stA_SNs;
	}
	else
	{
	}


	if (pstA_SNs->sNsec_msb > pstB_SNs->sNsec_msb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_SNs->sNsec_msb < pstB_SNs->sNsec_msb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_SNs->ulNsec_2nd > pstB_SNs->ulNsec_2nd)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_SNs->ulNsec_2nd < pstB_SNs->ulNsec_2nd)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_SNs->ulNsec_lsb > pstB_SNs->ulNsec_lsb)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_SNs->ulNsec_lsb < pstB_SNs->ulNsec_lsb)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}


	if (pstA_SNs->usFrcNsec > pstB_SNs->usFrcNsec)
	{
		chRet = COMP_A_GREAT;
		return	chRet;
	}
	else if (pstA_SNs->usFrcNsec < pstB_SNs->usFrcNsec)
	{
		chRet = COMP_A_LESS;
		return	chRet;
	}
	else
	{
	}

	chRet = COMP_EQUAL;
	return	chRet;
}




CHAR	ptpCompSNs_TInt( 
	SCALEDNS*			pstA_ScaledNs,
	TIME_INTERVAL*		pstB_Time_Interval)
{
	SCALEDNS	stB_SNs = {0};
	CHAR		chRet	= COMP_EQUAL;


	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		stB_SNs.sNsec_msb = -1;
	}
	stB_SNs.ulNsec_2nd = (ULONG)((LONG)(pstB_Time_Interval->sNsec_msb));
	stB_SNs.ulNsec_lsb = pstB_Time_Interval->ulNsec_lsb;
	stB_SNs.usFrcNsec  = pstB_Time_Interval->usFrcNsec;

	chRet = ptpCompSNs_SNs(pstA_ScaledNs, &stB_SNs);

	return	chRet;
}




CHAR	ptpCompTInt_TInt( 
	TIME_INTERVAL*		pstA_Time_Interval,
	TIME_INTERVAL*		pstB_Time_Interval)
{
	SCALEDNS	stA_SNs = {0};
	SCALEDNS	stB_SNs = {0};
	CHAR		chRet	= COMP_EQUAL;


	if (pstA_Time_Interval->sNsec_msb < 0)
	{
		stA_SNs.sNsec_msb = -1;
	}
	stA_SNs.ulNsec_2nd = (ULONG)((LONG)(pstA_Time_Interval->sNsec_msb));
	stA_SNs.ulNsec_lsb = pstA_Time_Interval->ulNsec_lsb;
	stA_SNs.usFrcNsec  = pstA_Time_Interval->usFrcNsec;

	if (pstB_Time_Interval->sNsec_msb < 0)
	{
		stB_SNs.sNsec_msb = -1;
	}
	stB_SNs.ulNsec_2nd = (ULONG)((LONG)(pstB_Time_Interval->sNsec_msb));
	stB_SNs.ulNsec_lsb = pstB_Time_Interval->ulNsec_lsb;
	stB_SNs.usFrcNsec  = pstB_Time_Interval->usFrcNsec;

	chRet = ptpCompSNs_SNs(&stA_SNs, &stB_SNs);

	return	chRet;
}




