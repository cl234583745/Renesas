/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_COMMON_TIME_H__
#define __PTP_COMMON_TIME_H__

#include "ptp_type.h"

typedef VOID	(*CallBackFunc)(USHORT, VOID *);

typedef struct	tagSEC48
{
	USHORT	usSec_msb;
	ULONG	ulSec_lsb;
} SEC48;

typedef struct	tagFRAC_NSEC64
{
	SHORT	sNsec_msb;
	ULONG	ulNsec_lsb;
	USHORT	usFrcNsec;
} FRAC_NSEC64;

typedef struct tagFRAC_NSEC48 {  
	ULONG	ulNsec;
	USHORT	usFrcNsec;
} FRAC_NSEC48;	

typedef FRAC_NSEC64 TIME_INTERVAL;

typedef struct	tagSCALEDNS
{
	SHORT	sNsec_msb;
	ULONG	ulNsec_2nd;
	ULONG	ulNsec_lsb;
	USHORT	usFrcNsec;
} SCALEDNS;

typedef struct	tagUSCALEDNS
{
	USHORT	usNsec_msb;
	ULONG	ulNsec_2nd;
	ULONG	ulNsec_lsb;
	USHORT	usFrcNsec;
} USCALEDNS;

typedef struct	tagTIMESTAMP
{
	SEC48	stSeconds;
	ULONG	ulNanoseconds;
} TIMESTAMP;

typedef struct	tagEXTENDEDTIMESTAMP
{
	SEC48		stSec;
	FRAC_NSEC48 stNsec;
} EXTENDEDTIMESTAMP;

#define CLOCKIDENTITY_SIZE	8
typedef struct	tagCLOCKIDENTITY
{
	UCHAR	uchId[CLOCKIDENTITY_SIZE];
} CLOCKIDENTITY;

typedef struct	tagPORTIDENTITY
{
	CLOCKIDENTITY	stClockIdentity;
	USHORT			usPortNumber;
} PORTIDENTITY;


typedef struct	tagCLOCKQUALITY
{
	UCHAR	uchClockClass;
	UCHAR	uchClockAccuracy;
	USHORT	usOffsetScaledLogVariance;
} CLOCKQUALITY;

typedef struct	tagPORTADDRESS
{
	USHORT	usNetworkProtcol;
	USHORT	usAddressLength;
	UCHAR	uchAddressField[1];

}	PORTADDRESS;
#define	PORTADDRESS_PROTOCOL_IPV4		1
#define	PORTADDRESS_PROTOCOL_IPV6		2
#define	PORTADDRESS_PROTOCOL_IEEE802_3	3
#define	PORTADDRESS_PROTOCOL_UNKNOWN	0xFFFE

typedef struct	tagFIXPORTADDRESS
{
	USHORT	usNetworkProtcol;
	USHORT	usAddressLength;
	UCHAR	uchAddressField[16];

}	FIXPORTADDRESS;

typedef struct tagPTPTEXT
{
	UCHAR	uchTextLength;
	UCHAR	uchTextField[1];

}	PTPTEXT;

typedef struct tagFIXPTPTEXT
{
	UCHAR	uchTextLength;
	UCHAR	uchTextField[255];

}	FIXPTPTEXT;

typedef struct tagLOGPTPTEXT_1
{
	UCHAR	uchTextLength;
	UCHAR	uchTextField[4];

}	LOGPTPTEXT_1;

typedef struct tagLOGPTPTEXT_2
{
	UCHAR	uchTextLength;
	UCHAR	uchTextField[8];

}	LOGPTPTEXT_2;

typedef struct tagLOGPTPTEXT_3
{
	UCHAR	uchTextLength;

	UCHAR	uchTextField[2];
}	LOGPTPTEXT_3;
#define OCTET6_SIZE	6
typedef struct	tagOCTET6
{
	UCHAR	uchId[OCTET6_SIZE];
} OCTET6;

typedef FRAC_NSEC48	UINT48;


typedef	struct tagTMO_MANAGE_INF_BLK
{
	USHORT			usEvent;
	VOID*			pvParam;
	USCALEDNS		stTimeoutTime;
	CallBackFunc	pfnCallBack;
} TMO_MANAGE_INF_BLK;


typedef	struct tagCURRENTTIMEQUE
{
	struct tagCURRENTTIMEQUE*	pstNextCTQuePtr;
	struct tagCURRENTTIMEQUE*	pstPrevCTQuePtr;

	TMO_MANAGE_INF_BLK			stTMO_Manage_Inf_BLK;
} CURRENTTIMEQUE;


#define	ACCURACY_25NS	0x20
#define	ACCURACY_100NS	0x21
#define	ACCURACY_250NS	0x22
#define	ACCURACY_1US	0x23
#define	ACCURACY_2_5US	0x24
#define	ACCURACY_10US	0x25
#define	ACCURACY_25US	0x26
#define	ACCURACY_100US	0x27
#define	ACCURACY_250US	0x28
#define	ACCURACY_1MS	0x29
#define	ACCURACY_2_5MS	0x2A
#define	ACCURACY_10MS	0x2B
#define	ACCURACY_25MS	0x2C
#define	ACCURACY_100MS	0x2D
#define	ACCURACY_250MS	0x2E
#define	ACCURACY_1S		0x2F
#define	ACCURACY_10S	0x30
#define	ACCURACY_GT10S	0x31
#define	ACCURACT_UNKNOUN 0xFE


#endif
