/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayRespReceiveSM.h"
#include "MDDelayRespReceiveSM_1588.h"
#include "MDDelayRespSendSM.h"
#include "MDDelayRespSendSM_1588.h"
#include "ptp_CDSend_1588.h"
#include "ptp_PDRSReceive_1588.h"
#include "ptp_PSSReceive_1588.h"

#define D_FUNC	0


VOID	PDRSReceive_1588_00(PORTDATA*	pstPortData);
VOID	PDRSReceive_1588_01(PORTDATA*	pstPortData);
VOID	PDRSReceive_1588_02(PORTDATA*	pstPortData);
MDDELAYRESP*  setMDDRSSend(MDDELAYRESP*	pstTxMDDRespRcvPtr,PORTDATA*	pstPortData);
VOID  txCDSDRSSend(MDDELAYRESP*	pstTxMDDRSSendPtr,PORTDATA*	pstPortData);






VOID (*const pfnPDRSReceiveMatrix[ST_PDRSR_MAX][EV_PDRSR_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PDRSReceive_1588_01, &PDRSReceive_1588_01, &PDRSReceive_1588_00},
	{&PDRSReceive_1588_01, &PDRSReceive_1588_02, &PDRSReceive_1588_00},
	{&PDRSReceive_1588_01, &PDRSReceive_1588_02, &PDRSReceive_1588_00}
};



VOID	 portDelayRespReceive_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRSR	enEvt = EV_PDRSR_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("PDRSReceiveSM_1588   Evt=%d Sts=%d\n", usEvent, pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSReceiveSM_1588_GD.enStatusPDRSR);
}
#endif
		enEvt = GetPDRSReceiveSM_1588_Event(usEvent, pstPortData);

		blSts = IsPDRSReceiveSM_1588_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PDRSR_EVENT_MAX))
		{
			(*pfnPDRSReceiveMatrix[pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSReceiveSM_1588_GD.enStatusPDRSR][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PDRSRECEIVESM_1588, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSReceiveSM_1588_GD.blRcvdMDDelayResp	= FALSE;
		}

	}
}



PDRSRECEIVESM_1588_GD*	GetPDRSReceiveSM_1588_GD(
	PORTDATA*		pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb = &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSReceiveSM_1588_GD);
	return pstPDRSRGlb;
}




EN_EV_PDRSR	GetPDRSReceiveSM_1588_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRSR				enEvt				= EV_PDRSR_EVENT_MAX;
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb		= GetPDRSReceiveSM_1588_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PDRSR_BEGIN;
			break;

		case PTP_EV_FOR_PDLRSRV_RCVMDDLRS:
			if ((pstPDRSRGlb->blRcvdMDDelayResp) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PDRSR_BEGIN;
			}
			else if (pstPDRSRGlb->enStatusPDRSR == ST_PDRSR_DISCARD)
			{
				if ((pstPDRSRGlb->blRcvdMDDelayResp) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PDRSR_FOR_PDLRSRV_RCVMDDLRS;
				}
			}
			else if (pstPDRSRGlb->enStatusPDRSR == ST_PDRSR_RECEIVED_DELAYRESP)
			{
				if ((pstPDRSRGlb->blRcvdMDDelayResp) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PDRSR_FOR_PDLRSRV_RCVMDDLRS;
				}
			}
			else
			{
			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PDRSR_CLOSE;
			break;

		default:
			enEvt = EV_PDRSR_EVENT_MAX;
			break;
	}

	return	enEvt;
}

BOOL	IsPDRSReceiveSM_1588_Status(
	PORTDATA*	pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb = GetPDRSReceiveSM_1588_GD(pstPortData);
	BOOL					blRet			= FALSE;


	if (pstPDRSRGlb->enStatusPDRSR < ST_PDRSR_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	PDRSReceive_1588_00(
	PORTDATA*		pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb = GetPDRSReceiveSM_1588_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PDRSReceive_1588_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPDRSRGlb->blRcvdMDDelayResp	= FALSE;
	pstPDRSRGlb->enStatusPDRSR		= ST_PDRSR_NONE;

	ptp_dbg_msg( D_FUNC, ("PDRSReceive_1588_00::-\n") );
}




VOID	PDRSReceive_1588_01(
	PORTDATA*		pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb = GetPDRSReceiveSM_1588_GD(pstPortData);


	pstPDRSRGlb->blRcvdMDDelayResp	= FALSE;
	pstPDRSRGlb->enStatusPDRSR		= ST_PDRSR_DISCARD;
}




VOID	PDRSReceive_1588_02(
	PORTDATA*		pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb					= GetPDRSReceiveSM_1588_GD(pstPortData);
	CLOCKDATA*				pstClockData				= pstPortData->pstClockData;
	MDDELAYRESP*			pstRcvdMDDRespRcvPtr		= &(pstPortData->stPort_GD.stMdDelayRespRcv);
	MDDELAYRESP*			pstTxMDDRespSndPtr			= NULL;


	pstPDRSRGlb->blRcvdMDDelayResp = FALSE;
	pstPDRSRGlb->pstRcvdMDDRespRcvPtr = pstRcvdMDDRespRcvPtr;
	if (   IS_OD_BC_1588(pstClockData) 
		&& (pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE)  )
	{
		if ( (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_SLAVE) ||
			(pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstPortData->stPort_GD.usThisPort]
																											== (UCHAR)PS_EX_UNCALIBRATED))
		{
			calcPDRSRDelayTime_PSSR(pstPortData);
			pstPortData->stPort_1588_DS.chLogMinDelayReqInterval
				= pstRcvdMDDRespRcvPtr->chLogMessageInterval;
			pstClockData->stUn_Clock_GD.stClock_1588_GD.chClockLogDelayReqInterval
				= pstRcvdMDDRespRcvPtr->chLogMessageInterval;
		}
	}
	else if (pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 == ENUM_CSTYPE_TRANSCLOCKE2E_1588)
	{
		pstTxMDDRespSndPtr = setMDDRSSend(pstRcvdMDDRespRcvPtr, pstPortData);

		txCDSDRSSend(pstTxMDDRespSndPtr, pstPortData);
	}
	else
	{
	}

	pstPDRSRGlb->enStatusPDRSR	= ST_PDRSR_RECEIVED_DELAYRESP;

}








MDDELAYRESP*  setMDDRSSend(
	MDDELAYRESP*		pstTxMDDRespRcvPtr,
	PORTDATA*		pstPortData)
{
	PDRSRECEIVESM_1588_GD*	pstPDRSRGlb			= GetPDRSReceiveSM_1588_GD(pstPortData);
	MDDELAYRESP*			pstTxMDDRSSendPtr	= &(pstPortData->stPort_GD.stMdDelayRespSnd);


	*pstTxMDDRSSendPtr = *pstTxMDDRespRcvPtr;
	pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD.usRcvdMDDRespRcvPNumber =
		pstPortData->stPort_GD.usThisPort;

	pstPDRSRGlb->pstTxMDDRespSndPtr = pstTxMDDRSSendPtr;

	return pstTxMDDRSSendPtr;
}



VOID  txCDSDRSSend(
	MDDELAYRESP*	pstTxMDDRSSendPtr,
	PORTDATA*		pstPortData)
{

	USHORT				usEvent				= PTP_EV_BASE;
	CLOCKDATA*			pstClockData		= pstPortData->pstClockData;
	CDSENDSM_1588_GD*	pstCDSendSM_1588_GD = NULL;


	pstCDSendSM_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCDSendSM_1588_GD);
	pstCDSendSM_1588_GD->pstRcvdMDDRespRcvPtr	= pstTxMDDRSSendPtr;
	pstCDSendSM_1588_GD->blRcvdMDDelayResp	= TRUE;

	usEvent = PTP_EV_DELAYRESP_SEND_1588;
	clockDelaySend_1588(usEvent, pstClockData);

}



#endif

