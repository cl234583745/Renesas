/**
 *******************************************************************************
 * @file  R_IN32M4_CL3.h
 * @brief
 *
 * @note
 * Copyright (C) 2019 Renesas Electronics Corporation
 *
 * @par
 *  This is a sample program.
 *  Renesas Electronics assumes no responsibility for any losses incurred.
 *
 *******************************************************************************
 */
#ifndef	__R_IN32M4_CL3_H
#define __R_IN32M4_CL3_H

#ifdef __cplusplus
extern "C" {
#endif

/*============================================================================*/
/* Interrupt Numbers                                                          */
/*============================================================================*/
typedef enum IRQn
{
/******  Cortex-M4 Processor Exceptions Numbers ***************************************************/
  NonMaskableInt_IRQn           = -14,      /*!< 2 Non Maskable Interrupt                         */
  MemoryManagement_IRQn         = -12,      /*!< 4 Cortex-M4 Memory Management Interrupt          */
  BusFault_IRQn                 = -11,      /*!< 5 Cortex-M4 Bus Fault Interrupt                  */
  UsageFault_IRQn               = -10,      /*!< 6 Cortex-M4 Usage Fault Interrupt                */
  SVCall_IRQn                   = -5,       /*!< 11 Cortex-M4 SV Call Interrupt                   */
  DebugMonitor_IRQn             = -4,       /*!< 12 Cortex-M4 Debug Monitor Interrupt             */
  PendSV_IRQn                   = -2,       /*!< 14 Cortex-M4 Pend SV Interrupt                   */
  SysTick_IRQn                  = -1,       /*!< 15 Cortex-M4 System Tick Interrupt               */

/******  R-IN32M4 Specific Interrupt Numbers *****************************************************/  
// << Naming rule >>  
//   R-IN32M4 Interrupt name : INTxxx  
//   Software define         : xxx_IRQn  

	// ------ Timer ------
	TAUJ2I0_IRQn				=   0,		/*!<  16 Timer(TAUJ2) ch:0 Interrupt				*/
	TAUJ2I1_IRQn				=   1,		/*!<  17 Timer(TAUJ2) ch:1 Interrupt				*/
	TAUJ2I2_IRQn				=   2,		/*!<  18 Timer(TAUJ2) ch:2 Interrupt				*/
	TAUJ2I3_IRQn				=   3,		/*!<  19 Timer(TAUJ2) ch:3 Interrupt				*/

	// ------ UART ------
	UAJ0TIT_IRQn				=   4,		/*!<  20 UART ch:0 TX Interrupt						*/
	UAJ0TIR_IRQn				=   5,		/*!<  21 UART ch:0 RX Interrupt						*/
	UAJ1TIT_IRQn				=   6,		/*!<  22 UART ch:1 TX Interrupt						*/
	UAJ1TIR_IRQn				=   7,		/*!<  23 UART ch:1 RX Interrupt						*/

	// ------ CSI ------
	CSIH0IC_IRQn				=   8,		/*!<  24 CSI ch:0 communication Interrupt			*/
	CSIH0IR_IRQn				=   9,		/*!<  25 CSI ch:0 RX Interrupt						*/
	CSIH0IJC_IRQn				=  10,		/*!<  26 CSI ch:0 error Interrupt					*/
	CSIH1IC_IRQn				=  11,		/*!<  27 CSI ch:1 communication Interrupt			*/
	CSIH1IR_IRQn				=  12,		/*!<  28 CSI ch:1 RX Interrupt						*/
	CSIH1IJC_IRQn				=  13,		/*!<  29 CSI ch:1 error Interrupt					*/

	// ------ IIC ------
	IICB0TIA_IRQn				=  14,		/*!<  30 IIC ch:0 TX/RX Interrupt					*/
	IICB1TIA_IRQn				=  15,		/*!<  31 IIC ch:1 TX/RX Interrupt					*/

	// ------ CAN ------
	FCN0REC_IRQn				=  16,		/*!<  32 CAN ch:0 RX Interrupt						*/
	FCN0TRX_IRQn				=  17,		/*!<  33 CAN ch:0 TX Interrupt						*/
	FCN0WUP_IRQn				=  18,		/*!<  34 CAN ch:0 wake up Interrupt					*/
	FCN1REC_IRQn				=  19,		/*!<  35 CAN ch:1 RX Interrupt						*/
	FCN1TRX_IRQn				=  20,		/*!<  36 CAN ch:1 TX Interrupt						*/
	FCN1WUP_IRQn				=  21,		/*!<  37 CAN ch:1 wake up Interrupt					*/

	// ------ DMAC ------
	DMA00_IRQn					=  22,		/*!<  38 DMAC ch:0 transfer Interrupt				*/
	DMA01_IRQn					=  23,		/*!<  39 DMAC ch:1 transfer Interrupt				*/
	DMA02_IRQn					=  24,		/*!<  40 DMAC ch:2 transfer Interrupt				*/
	DMA03_IRQn					=  25,		/*!<  41 DMAC ch:3 transfer Interrupt				*/
	RTDMA_IRQn					=  26,		/*!<  42 RTPORT DMAC transfer Interrupt				*/

	// ------ TAUD ------
	TAUDI0_IRQn					=  27,		/*!<  43 Timer(TAUD) ch:0 Interrupt					*/
	TAUDI1_IRQn					=  28,		/*!<  44 Timer(TAUD) ch:1 Interrupt					*/
	TAUDI2_IRQn					=  29,		/*!<  45 Timer(TAUD) ch:2 Interrupt					*/
	TAUDI3_IRQn					=  30,		/*!<  46 Timer(TAUD) ch:3 Interrupt					*/
	TAUDI4_IRQn					=  31,		/*!<  47 Timer(TAUD) ch:4 Interrupt					*/

	// ------ Inter buffer DMA ------
	BUFDMA_IRQn					=  32,		/*!<  48 Inter buffer DMA Interrupt					*/

	// ------ Ether PHY ------
	ETHPHY0_IRQn				=  33,		/*!<  49 Ether PHY0 Interrupt						*/
	ETHPHY1_IRQn				=  34,		/*!<  50 Ether PHY1 Interrupt						*/

	// ------ Ether MAC ------
	ETHMIICMP_IRQn				=  35,		/*!<  51 Ether MAC MII Interrupt					*/
	ETHPAUSECMP_IRQn			=  36,		/*!<  52 Ether MAC PAUSE Interrupt					*/
	ETHTXCMP_IRQn				=  37,		/*!<  53 Ether MAC TX complete Interrupt			*/

	// ------ Ether Switch ------
	ETHSW_IRQn					=  38,		/*!<  54 EtherSwitch interrupt						*/
	ETHSWDLR_IRQn				=  39,		/*!<  55 EtherSwitch DLR interrupt					*/
	ETHSWSYNC_IRQn				=  40,		/*!<  56 EtherSwitch Synchronous interrupt			*/

	// ------ Ether MAC ------
	ETHRXFIFO_IRQn				=  41,		/*!<  57 Ether MAC RX FIFO overflow Interrupt		*/
	ETHTXFIFO_IRQn				=  42,		/*!<  58 Ether MAC TX FIFO underflow Interrupt		*/
	ETHRXDMA_IRQn				=  43,		/*!<  59 Ether MAC RX DMA complete Interrupt		*/
	ETHTXDMA_IRQn				=  44,		/*!<  60 Ether MAC TX DMA complete Interrupt		*/
	MACDMARXFRM_IRQn			=  45,		/*!<  61 Ether MAC RX DMA success Interrupt			*/

	// ------ Port/TAUD/TAPA ------
	INTPZ0_IRQn					=  47,		/*!<  63 INTPZ0 Interrupt							*/
	INTPZ1_IRQn					=  48,		/*!<  64 INTPZ1 Interrupt							*/
	INTPZ2_IRQn					=  49,		/*!<  65 INTPZ2 Interrupt							*/
	INTPZ3_IRQn					=  50,		/*!<  66 INTPZ3 Interrupt							*/
	INTPZ4_IRQn					=  51,		/*!<  67 INTPZ4 Interrupt							*/
	INTPZ5_IRQn					=  52,		/*!<  68 INTPZ5 Interrupt							*/
	INTPZ6_IRQn					=  53,		/*!<  69 INTPZ6 Interrupt							*/
	INTPZ7_IRQn					=  54,		/*!<  70 INTPZ7 Interrupt							*/
	INTPZ8_IRQn					=  55,		/*!<  71 INTPZ8 Interrupt							*/
	INTPZ9_IRQn					=  56,		/*!<  72 INTPZ9 Interrupt							*/
	INTPZ10_IRQn				=  57,		/*!<  73 INTPZ10 Interrupt							*/
	INTPZ11_IRQn				=  58,		/*!<  74 INTPZ11/Timer(TAUD) ch:5 Interrupt			*/
	INTPZ12_IRQn				=  59,		/*!<  75 INTPZ12/Timer(TAUD) ch:6 Interrupt			*/
	INTPZ13_IRQn				=  60,		/*!<  76 INTPZ13/Timer(TAUD) ch:7 Interrupt			*/
	INTPZ14_IRQn				=  61,		/*!<  77 INTPZ14/Timer(TAUD) ch:8 Interrupt			*/
	INTPZ15_IRQn				=  62,		/*!<  78 INTPZ15/Timer(TAUD) ch:9 Interrupt			*/
	INTPZ16_IRQn				=  63,		/*!<  79 INTPZ16/Timer(TAUD) ch:10 Interrupt		*/
	INTPZ17_IRQn				=  64,		/*!<  80 INTPZ17/Timer(TAUD) ch:11 Interrupt		*/
	INTPZ18_IRQn				=  65,		/*!<  81 INTPZ18/Timer(TAUD) ch:12 Interrupt		*/
	INTPZ19_IRQn				=  66,		/*!<  82 INTPZ19/Timer(TAUD) ch:13 Interrupt		*/
	INTPZ20_IRQn				=  67,		/*!<  83 INTPZ20/Timer(TAUD) ch:14 Interrupt		*/
	INTPZ21_IRQn				=  68,		/*!<  84 INTPZ21/Timer(TAUD) ch:15 Interrupt		*/
	INTPZ22_IRQn				=  69,		/*!<  85 INTPZ22 Interrupt							*/
	INTPZ23_IRQn				=  70,		/*!<  86 INTPZ23 Interrupt							*/
	INTPZ24_IRQn				=  71,		/*!<  87 INTPZ24 Interrupt							*/
	INTPZ25_IRQn				=  72,		/*!<  88 INTPZ25 Interrupt							*/
	INTPZ26_IRQn				=  73,		/*!<  89 INTPZ26 Interrupt							*/
	INTPZ27_IRQn				=  74,		/*!<  90 INTPZ27 Interrupt							*/
	INTPZ28_IRQn				=  75,		/*!<  91 INTPZ28 Interrupt							*/

	// ------ HW-RTOS ------
	HWRTOS_IRQn					=  76,		/*!<  92 HW-RTOS Interrupt							*/

	// ------ Status/Error Interrupt ------
	BRAMERR_IRQn				=  77,		/*!<  93 Buffer RAM access error Interrupt			*/
	IICB0TIS_IRQn				=  78,		/*!<  94 IIS ch:0 status Interrupt					*/
	IICB1TIS_IRQn				=  79,		/*!<  95 IIS ch:1 status Interrupt					*/
	WDTA_IRQn					=  80,		/*!<  96 WDT alarm Interrupt						*/
	SFLASH_IRQn					=  81,		/*!<  97 Serial Flash Interrupt						*/
	UAJ0TIS_IRQn				=  82,		/*!<  98 UART ch:0 status Interrupt					*/
	UAJ1TIS_IRQn				=  83,		/*!<  99 UART ch:1 status Interrupt					*/
	CSIH0IRE_IRQn				=  84,		/*!< 100 CSI ch:0 error Interrupt					*/
	CSIH1IRE_IRQn				=  85,		/*!< 101 CSI ch:1 error Interrupt					*/
	FCN0ERR_IRQn				=  86,		/*!< 102 CAN ch:0 error Interrupt					*/
	FCN1ERR_IRQn				=  87,		/*!< 103 CAN ch:1 error Interrupt					*/
	DERR0_IRQn					=  88,		/*!< 104 General DMAC error Interrupt				*/
	DERR1_IRQn					=  89,		/*!< 105 RTPORT DMAC error Interrupt				*/
	ETHTXFIFOERR_IRQn			=  90,		/*!< 106 Ether MAC TX FIFO error Interrupt			*/
	ETHRXERR_IRQn				=  91,		/*!< 107 Ether MAC RX error Interrupt				*/
	ETHRXDERR_IRQn				=  92,		/*!< 108 Ether MAC RX DMA error Interrupt			*/
	ETHTXDERR_IRQn				=  93,		/*!< 109 Ether MAC TX DMA error Interrupt			*/
	BUFDMAERR_IRQn				=  94,		/*!< 110 Inter buffer DMA error Interrupt			*/

	// ------ Gigabit Ethernet PHY ------
	LED0PHY0_IRQn				=  95,		/*!< 111 LED0_PHY0 Interrupt						*/
	LED0PHY1_IRQn				=  96,		/*!< 112 LED0_PHY1 Interrupt						*/

	IRAMECCSEC_IRQn				=  99,		/*!< 115 IRAM ECC error correction interrupt		*/
	DRAMECCSEC_IRQn				= 100,		/*!< 116 DRAM ECC error correction interrupt		*/
	BRAMECCSEC_IRQn				= 101,		/*!< 117 Buffer RAM ECC error correction interrupt	*/
	IRAMECCDED_IRQn				= 102,		/*!< 118 IRAM ECC error detection interrupt			*/
	DRAMECCDED_IRQn				= 103,		/*!< 119 DRAM ECC error detection interrupt			*/
	BRAMECCDED_IRQn				= 104,		/*!< 120 Buffer RAM ECC error detection interrupt	*/
	
	// ------ CC-Link IE Feild Network ------
	CCINMIZ_IRQn				= 107,		/*!< 123 CC-Link IE NMIZ Interrupt					*/
	CCIWDTZ_IRQn				= 108,		/*!< 124 CC-Link IE WDTZ Interrupt					*/
	CCIINTZ_IRQn				= 109,		/*!< 125 CC-Link IE INTZ Interrupt					*/
	CCICLKLOSSZ_IRQn			= 110,		/*!< 126 CC-Link IE CLKLOSSZ Interrupt				*/
	NCHINT_IRQn					= 111,		/*!< 127 NGNCC-LinkIE high priority interrupt		*/
	NCLINT_IRQn					= 112,		/*!< 128 NGNCC-LinkIE low priority interrupt		*/

	// ------ Gigabit Ethernet PHY ------
	GBEPHYFLF_IRQn	 			= 121,		/*!< 137 GbE-PHY FASTLINK_FAIL Interrupt			*/
	LED1PHY0_IRQn				= 122,		/*!< 138 LED1_PHY0 Interrupt						*/
	LED1PHY1_IRQn				= 123,		/*!< 139 LED1_PHY1 Interrupt						*/
	LED2PHY0_IRQn				= 124,		/*!< 140 LED2_PHY0 Interrupt						*/
	LED2PHY1_IRQn				= 125,		/*!< 141 LED2_PHY1 Interrupt						*/

	// ------ FPU ------
	FPU_IRQn					= 126,		/*!< 142 FPU Interrupt								*/

	// ------ Port ------
	INTPZ29_IRQn				= 127,		/*!< 143 INTPZ29 Interrupt							*/
	
	// ------ NetworkRAM ------
	NRAMECCSEC_IRQn				= 129,		/*!< 145 Network RAM ECC Collect Interrupt					*/
	NRAMECCDED_IRQn				= 130,		/*!< 146 Network RAM ECC Error Interrupt					*/

	// ------ BUS Bridge ------
	INTHSNGNREGBE_IRQn			= 132,		/*!< 148 BUS error Interrupt(HSNGNREG)				*/
	INTHSNGNBE_IRQn				= 133,		/*!< 149 BUS error Interrupt(HSNGN)					*/
	INTXSNGNBE_IRQn				= 134,		/*!< 150 BUS error Interrupt(XSNGN)					*/
	
	// ------ mc1_top_m ------
	MCINTWDTERR_IRQn			= 136,		/*!< 152 External CPU WDT Error Interrupt			*/
	
	// ------ on-chip regulator ------
	INTROK_IRQn					= 152,		/*!< 168 On-chip regulator Interrupt				*/
	
	END_OF_IRQn					= 239

} IRQn_Type;

/*============================================================================*/
/* Processor and Core Peripheral Section                                      */
/*============================================================================*/
/* Configuration of the Cortex-M4 Processor and Core Peripherals */
#define __MPU_PRESENT             1         /*!< MPU present or not                                */
#define __NVIC_PRIO_BITS          4         /*!< Number of Bits used for Priority Levels           */
#define __Vendor_SysTickConfig    0         /*!< Set to 1 if different SysTick Config is used      */
#define __FPU_PRESENT             1         /*!< FPU present or not                                */

#include "core_cm4.h"                       /* Cortex-M4 processor and core peripherals            */
#include "system_R_IN32M4_CL3.h"            /* R-IN32M4 system                                     */

//=============================================================
// Memory map
//=============================================================
//-------------------------------------
// Code region
//-------------------------------------
#define CODE_BASE				(0x00000000UL)				/* Instruction RAM Area								*/

//-------------------------------------
// SRAM region
//-------------------------------------
#define SRAM_BASE				(0x20000000UL)				/* Serial Flash ROM Area							*/

//-------------------------------------
// Peripheral region
//-------------------------------------
#define PERI_BASE				(0x40000000UL)				/* Peripheral Register Area							*/

// --- APB ---
#define RIN_TMR_BASE			(PERI_BASE    + 0x00000UL)	/* 32-bit Timer(TAUJ2) Register						*/
#define RIN_CSI0_BASE			(PERI_BASE    + 0x00100UL)	/* CSI CH0 Register									*/
#define RIN_CSI1_BASE			(PERI_BASE    + 0x00200UL)	/* CSI CH1 Register									*/
#define RIN_UART0_BASE			(PERI_BASE    + 0x00300UL)	/* UART CH0 Register								*/
#define RIN_UART1_BASE			(PERI_BASE    + 0x00400UL)	/* UART CH1 Register								*/
#define RIN_IIC0_BASE			(PERI_BASE    + 0x00500UL)	/* IIC CH0 Register									*/
#define RIN_IIC1_BASE			(PERI_BASE    + 0x00600UL)	/* IIC CH1 Register									*/
#define RIN_WDT_BASE			(PERI_BASE    + 0x00700UL)	/* Watchdog Timer Register							*/
#define RIN_TAUD_BASE			(PERI_BASE    + 0x00800UL)	/* 16-bit Timer(TAUD) Register						*/
#define RIN_SYS_BASE			(PERI_BASE    + 0x10000UL)	/* System Register		 							*/
#define RIN_CAN0_BASE			(PERI_BASE    + 0x20000UL)	/* CAN CH0 Register									*/
#define RIN_CAN1_BASE			(PERI_BASE    + 0x40000UL)	/* CAN CH1 Register			 						*/
#define RIN_ETHSW_BASE			(PERI_BASE    + 0x70000UL)	/* Ethernet Switch Control Register					*/

// --- AHB ---
#define RIN_HWOS_BASE			(PERI_BASE    + 0x80000UL)	/* HW-RTOS Register									*/
#define RIN_ETH_BASE			(PERI_BASE    + 0x90000UL)	/* Gigabit Ethernet MAC Register					*/
#define RIN_MEMC_BASE			(PERI_BASE    + 0xA2000UL)	/* Asynchronous SRAM MEMC Register					*/
#define RIN_SROM_BASE			(PERI_BASE    + 0xA2400UL)	/* Serial Flash ROM MEMC Register					*/
#define RIN_DMAC0_BASE			(PERI_BASE    + 0xA2800UL)	/* DMAC CH0 Control Register						*/
#define RIN_DMAC1_BASE			(PERI_BASE    + 0xA2840UL)	/* DMAC CH1 Control Register						*/
#define RIN_DMAC2_BASE			(PERI_BASE    + 0xA2880UL)	/* DMAC CH2 Control Register						*/
#define RIN_DMAC3_BASE			(PERI_BASE    + 0xA28C0UL)	/* DMAC CH3 Control Register						*/
#define RIN_DMAC0_LINK_BASE		(PERI_BASE    + 0xA2A00UL)	/* DMAC CH0 Link Register							*/
#define RIN_DMAC1_LINK_BASE		(PERI_BASE    + 0xA2A20UL)	/* DMAC CH1 Link Register							*/
#define RIN_DMAC2_LINK_BASE		(PERI_BASE    + 0xA2A40UL)	/* DMAC CH2 Link Register							*/
#define RIN_DMAC3_LINK_BASE		(PERI_BASE    + 0xA2A60UL)	/* DMAC CH3 Link Register							*/
#define RIN_DMAC_CTRL_BASE		(PERI_BASE    + 0xA2B00UL)	/* DMA Control Register								*/
#define RIN_RTDMAC_BASE			(PERI_BASE    + 0xA2C00UL)	/* RTDMAC Control Register							*/
#define RIN_RTDMAC_LINK_BASE	(PERI_BASE    + 0xA2E00UL)	/* RTDMAC Link Register								*/
#define RIN_RTDMAC_CTRL_BASE	(PERI_BASE    + 0xA2F00UL)	/* RTDMA Control Register							*/
#define RIN_GPIO_BASE			(PERI_BASE    + 0xA3000UL)	/* GPIO Register									*/
#define RIN_RTPORT_BASE			(PERI_BASE    + 0xA3400UL)	/* Real Time Port Register							*/
#define RIN_EXTPORT_BASE		(PERI_BASE    + 0xA3800UL)	/* Extension Port Register							*/
#define RIN_CCI_BRG_BASE		(PERI_BASE    + 0xA4000UL)	/* CC-Link IE Field Bridge Control Register			*/
#define RIN_SMC_BASE			(PERI_BASE    + 0xA8000UL)	/* Synchronous Burst MEMC Register					*/
#define RIN_UDLSYS_BASE			(PERI_BASE    + 0xF1800UL)	/* System Control Regiter							*/

//=============================================================
// Peripheral register
//=============================================================
//-----------------------------------------------------------------------------
// Timer register
//-----------------------------------------------------------------------------
typedef struct
{
// --- Control registers[1] ---
	__IO uint32_t	TAUJ2CDR0;					/*!< 0x000 : channel data register 0					*/
	__IO uint32_t	TAUJ2CDR1;					/*!< 0x004 : channel data register 1					*/
	__IO uint32_t	TAUJ2CDR2;					/*!< 0x008 : channel data register 2					*/
	__IO uint32_t	TAUJ2CDR3;					/*!< 0x00C : channel data register 3					*/

	__IO uint32_t	TAUJ2CNT0;					/*!< 0x010 : channel counter register 0					*/
	__IO uint32_t	TAUJ2CNT1;					/*!< 0x014 : channel counter register 1					*/
	__IO uint32_t	TAUJ2CNT2;					/*!< 0x018 : channel counter register 2					*/
	__IO uint32_t	TAUJ2CNT3;					/*!< 0x01C : channel counter register 3					*/

	__IO uint32_t	TAUJ2CMUR0;					/*!< 0x020 : channel mode user register 0				*/
	__IO uint32_t	TAUJ2CMUR1;					/*!< 0x024 : channel mode user register 1				*/
	__IO uint32_t	TAUJ2CMUR2;					/*!< 0x028 : channel mode user register 2				*/
	__IO uint32_t	TAUJ2CMUR3;					/*!< 0x02C : channel mode user register 3				*/

	__IO uint32_t	TAUJ2CSR0;					/*!< 0x030 : channel status register 0					*/
	__IO uint32_t	TAUJ2CSR1;					/*!< 0x034 : channel status register 1					*/
	__IO uint32_t	TAUJ2CSR2;					/*!< 0x038 : channel status register 2					*/
	__IO uint32_t	TAUJ2CSR3;					/*!< 0x03C : channel status register 3					*/

	__IO uint32_t	TAUJ2CSC0;					/*!< 0x040 : channel status clear trigger register 0	*/
	__IO uint32_t	TAUJ2CSC1;					/*!< 0x044 : channel status clear trigger register 1	*/
	__IO uint32_t	TAUJ2CSC2;					/*!< 0x048 : channel status clear trigger register 2	*/
	__IO uint32_t	TAUJ2CSC3;					/*!< 0x04C : channel status clear trigger register 3	*/

	__IO uint32_t	TAUJ2TE;					/*!< 0x050 : channel enable status register				*/
	__IO uint32_t	TAUJ2TS;					/*!< 0x054 : channel start trigger register				*/
	__IO uint32_t	TAUJ2TT;					/*!< 0x058 : channel stop trigger register				*/

// --- Output registers[1] ---
	__IO uint32_t	TAUJ2TO;					/*!< 0x05C : channel output register					*/
	__IO uint32_t	TAUJ2TOE;					/*!< 0x060 : channel output enable register				*/
	__IO uint32_t	TAUJ2TOL;					/*!< 0x064 : channel output active level register		*/

// --- Reload data registers[1] ---
	__IO uint32_t	TAUJ2RDT;					/*!< 0x068 : channel reload data trigger register		*/
	__IO uint32_t	TAUJ2RSF;					/*!< 0x06C : channel reload status register				*/

	     uint32_t	RESERVED0x070[4];			/*!< 0x070 - 0x007F : Reserved							*/

// --- Control registers[2] ---
	__IO uint32_t	TAUJ2CMOR0;					/*!< 0x080 : channel mode OS register 0					*/
	__IO uint32_t	TAUJ2CMOR1;					/*!< 0x084 : channel mode OS register 1					*/
	__IO uint32_t	TAUJ2CMOR2;					/*!< 0x088 : channel mode OS register 2					*/
	__IO uint32_t	TAUJ2CMOR3;					/*!< 0x08C : channel mode OS register 3					*/

// --- Prescaler registers ---
	__IO uint32_t	TAUJ2TPS;					/*!< 0x090 : prescaler clock select register			*/
	__IO uint32_t	TAUJ2BRS;					/*!< 0x094 : prescaler baud rate setting register		*/

// --- Output registers[2] ---
	__IO uint32_t	TAUJ2TOM;					/*!< 0x098 : channel output mode register				*/
	__IO uint32_t	TAUJ2TOC;					/*!< 0x09C : channel output configuration register		*/

// --- Reload data registers[2] ---
	__IO uint32_t	TAUJ2RDE;					/*!< 0x0A0 : channel reload data enable register		*/
	__IO uint32_t	TAUJ2RDM;					/*!< 0x0A4 : channel reload data mode register			*/
} RIN_TMR_TypeDef;

#define RIN_TMR					((RIN_TMR_TypeDef *)		RIN_TMR_BASE)

//-----------------------------------------------------------------------------
// CSI register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	CSIHnCTL0;					/*!< 0x000 : Control register 0								*/
	__I  uint32_t	CSIHnSTR0;					/*!< 0x004 : Status register 0								*/
	__IO uint32_t	CSIHnSTCR0;					/*!< 0x008 : Status clear register 0						*/
	     uint32_t	RESERVED0x00C;				/*!< 0x00C - 0x00F : Reserved								*/
	__IO uint32_t	CSIHnCTL1;					/*!< 0x010 : Control register 1								*/
	__IO uint32_t	CSIHnCTL2;					/*!< 0x014 : Control register 2								*/
	     uint8_t	RESERVED0x018[0x080 - 0x018];/*!< 0x018 - 0x07F : Reserved								*/
	__IO uint32_t	CSIHnMCTL1;					/*!< 0x080 : Memory control register 1						*/
	__IO uint32_t	CSIHnMCTL2;					/*!< 0x084 : Memory control register 2						*/
	__IO uint32_t	CSIHnTX0W;					/*!< 0x088 : Transmit data register 0 for word access		*/
	__IO uint32_t	CSIHnTX0H;					/*!< 0x08C : Transmit data register 0 for half word access	*/
	__I  uint32_t	CSIHnRX0W;					/*!< 0x090 : Receive  data register 0 for word access		*/
	__I  uint32_t	CSIHnRX0H;					/*!< 0x094 : Receive  data register 0 for half word access	*/
	__IO uint32_t	CSIHnMRWP0;					/*!< 0x098 : Memory read/write pointerregister 0			*/
	     uint8_t	RESERVED0x09C[0x0C0 - 0x09C];/*!< 0x09C - 0x0BF : Reserved								*/
	__IO uint32_t	CSIHnMCTL0;					/*!< 0x0C0 : Memory control register 0						*/
	__IO uint32_t	CSIHnCFG0;					/*!< 0x0C4 : Configuration register 0						*/
	__IO uint32_t	CSIHnCFG1;					/*!< 0x0C8 : Configuration register 1						*/
} RIN_CSI_TypeDef;

#define RIN_CSI0				((RIN_CSI_TypeDef *)		RIN_CSI0_BASE)
#define RIN_CSI1				((RIN_CSI_TypeDef *)		RIN_CSI1_BASE)

//-----------------------------------------------------------------------------
// UART register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	URTJnCTL0;					/*!< 0x000 : Control Register 0							*/
	__IO uint32_t	URTJnTRG;					/*!< 0x004 : Triger Register							*/
	__I  uint32_t	URTJnSTR0;					/*!< 0x008 : Status Register 0							*/
	__I  uint32_t	URTJnSTR1;					/*!< 0x00C : Status Register 1							*/
	__IO uint32_t	URTJnSTC;					/*!< 0x010 : Status Clear Register						*/
	     uint8_t	RESERVED0x014[0x020 - 0x014];/*!< 0x014 - 0x01F : Reserved							*/
	__IO uint32_t	URTJnCTL1;					/*!< 0x020 : Control Register 1							*/
	__IO uint32_t	URTJnCTL2;					/*!< 0x024 : Control Register 2							*/
	     uint8_t	RESERVED0x028[0x080 - 0x028];/*!< 0x028 - 0x07F : Reserved							*/
	__IO uint32_t	URTJnFCTL0;					/*!< 0x080 : FIFO Control Register 0					*/
	__I  uint32_t	URTJnFSTR0;					/*!< 0x084 : FIFO Status Register 0						*/
	__I  uint32_t	URTJnFSTR1;					/*!< 0x088 : FIFO Status Register 1						*/
	__IO uint32_t	URTJnFSTC;					/*!< 0x08C : FIFO Status Clear Register					*/
	__I  uint32_t	URTJnFRX;					/*!< 0x090 : FIFO Recieve Data Register					*/
	__IO uint32_t	URTJnFTX;					/*!< 0x094 : FIFO Transmit Data Register				*/
	     uint8_t	RESERVED0x098[0x0A0 - 0x098];/*!< 0x098 - 0x09F : Reserved							*/
	__IO uint32_t	URTJnFCTL1;					/*!< 0x0A0 : FIFO Control Register 1					*/
} RIN_UART_TypeDef;

#define RIN_UART0				((RIN_UART_TypeDef *)		RIN_UART0_BASE)
#define RIN_UART1				((RIN_UART_TypeDef *)		RIN_UART1_BASE)

//-----------------------------------------------------------------------------
// IIC register
//-----------------------------------------------------------------------------
typedef struct
{

	__IO uint32_t	IICBnDAT;					/*!< 0x000 : Data register								*/
	__IO uint32_t	IICBnSVA;					/*!< 0x004 : Slave address register						*/
	__IO uint32_t	IICBnCTL0;					/*!< 0x008 : Control Register 0							*/
	__IO uint32_t	IICBnTRG;					/*!< 0x00C : Trigger register							*/
	__I  uint32_t	IICBnSTR0;					/*!< 0x010 : Status Register 0							*/
	__I  uint32_t	IICBnSTR1;					/*!< 0x014 : Status Register 1							*/
	__IO uint32_t	IICBnSTRC;					/*!< 0x018 : Status clear register						*/
	     uint32_t	RESERVED0x01C;				/*!< 0x01C - 0x01F : Reserved							*/
	__IO uint32_t	IICBnCTL1;					/*!< 0x020 : Control Register 1							*/
	__IO uint32_t	IICBnWL;					/*!< 0x024 : Low level width setting register			*/
	__IO uint32_t	IICBnWH;					/*!< 0x028 : High level width setting register			*/

} RIN_IIC_TypeDef;

#define RIN_IIC0				((RIN_IIC_TypeDef *)		RIN_IIC0_BASE)
#define RIN_IIC1				((RIN_IIC_TypeDef *)		RIN_IIC1_BASE)

//-----------------------------------------------------------------------------
// WDT register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	WDTA0WDTE;					/*!< 0x000 : Watchdog Timer Enable register				*/
	     uint32_t	RESERVED0x004[2];			/*!< 0x004 - 0x00b 	: Reserved							*/
	__IO uint32_t	WDTA0MD;					/*!< 0x00C : Watchdog Timer Mode register				*/
} RIN_WDT_TypeDef;

#define RIN_WDT					((RIN_WDT_TypeDef *)		RIN_WDT_BASE)

//-----------------------------------------------------------------------------
// TAUD register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	TAUDCDR0;					/*!< 0x000 : Channel Data Register 0	 				*/
	__IO uint32_t	TAUDCDR1;					/*!< 0x004 : Channel Data Register 1	 				*/
	__IO uint32_t	TAUDCDR2;					/*!< 0x008 : Channel Data Register 2	 				*/
	__IO uint32_t	TAUDCDR3;					/*!< 0x00C : Channel Data Register 3	 				*/
	__IO uint32_t	TAUDCDR4;					/*!< 0x010 : Channel Data Register 4					*/
	__IO uint32_t	TAUDCDR5;					/*!< 0x014 : Channel Data Register 5					*/
	__IO uint32_t	TAUDCDR6;					/*!< 0x018 : Channel Data Register 6					*/
	__IO uint32_t	TAUDCDR7;					/*!< 0x01C : Channel Data Register 7					*/
	__IO uint32_t	TAUDCDR8;					/*!< 0x020 : Channel Data Register 8					*/
	__IO uint32_t	TAUDCDR9;					/*!< 0x024 : Channel Data Register 9					*/
	__IO uint32_t	TAUDCDR10;					/*!< 0x028 : Channel Data Register 10					*/
	__IO uint32_t	TAUDCDR11;					/*!< 0x02C : Channel Data Register 11					*/
	__IO uint32_t	TAUDCDR12;					/*!< 0x030 : Channel Data Register 12					*/
	__IO uint32_t	TAUDCDR13;					/*!< 0x034 : Channel Data Register 13					*/
	__IO uint32_t	TAUDCDR14;					/*!< 0x038 : Channel Data Register 14					*/
	__IO uint32_t	TAUDCDR15;					/*!< 0x03C : Channel Data Register 15					*/
	__IO uint32_t	TAUDTOL;					/*!< 0x040 : Channel Output Active Level Register		*/
	__O  uint32_t	TAUDRDT;					/*!< 0x044 : Channel Reload Data Trigger Register		*/
	__I  uint32_t	TAUDRSF;					/*!< 0x048 : Channel Reload Status Register				*/
	__IO uint32_t	TAUDTRO;					/*!< 0x04C : Channel Real-Time Output Register			*/
	__IO uint32_t	TAUDTME;					/*!< 0x050 : Channel Modulation Output Enable Register	*/
	__IO uint32_t	TAUDTDL;					/*!< 0x054 : Channel Dead-Time Output Level Register	*/
	__IO uint32_t	TAUDTO;						/*!< 0x058 : Channel Output Register					*/
	__IO uint32_t	TAUDTOE;					/*!< 0x05C : Channel Output Enable Register				*/
	     uint32_t	RESERVED0x060[8];			/*!< 0x060 - 0x7C : Reserved 							*/
	__I  uint32_t	TAUDCNT0;					/*!< 0x080 : Channel Counter Register 0	 				*/
	__I  uint32_t	TAUDCNT1;					/*!< 0x084 : Channel Counter Register 1	 				*/
	__I  uint32_t	TAUDCNT2;					/*!< 0x088 : Channel Counter Register 2	 				*/
	__I  uint32_t	TAUDCNT3;					/*!< 0x08C : Channel Counter Register 3	 				*/
	__I  uint32_t	TAUDCNT4;					/*!< 0x090 : Channel Counter Register 4	 				*/
	__I  uint32_t	TAUDCNT5;					/*!< 0x094 : Channel Counter Register 5	 				*/
	__I  uint32_t	TAUDCNT6;					/*!< 0x098 : Channel Counter Register 6	 				*/
	__I  uint32_t	TAUDCNT7;					/*!< 0x09C : Channel Counter Register 7	 				*/
	__I  uint32_t	TAUDCNT8;					/*!< 0x0A0 : Channel Counter Register 8	 				*/
	__I  uint32_t	TAUDCNT9;					/*!< 0x0A4 : Channel Counter Register 9	 				*/
	__I  uint32_t	TAUDCNT10;					/*!< 0x0A8 : Channel Counter Register 10 				*/
	__I  uint32_t	TAUDCNT11;					/*!< 0x0AC : Channel Counter Register 11 				*/
	__I  uint32_t	TAUDCNT12;					/*!< 0x0B0 : Channel Counter Register 12 				*/
	__I  uint32_t	TAUDCNT13;					/*!< 0x0B4 : Channel Counter Register 13				*/
	__I  uint32_t	TAUDCNT14;					/*!< 0x0B8 : Channel Counter Register 14 				*/
	__I  uint32_t	TAUDCNT15;					/*!< 0x0BC : Channel Counter Register 15 				*/
	__IO uint32_t	TAUDCMUR0;					/*!< 0x0C0 : Channel Mode User Register 0	 			*/
	__IO uint32_t	TAUDCMUR1;					/*!< 0x0C4 : Channel Mode User Register 1	 			*/
	__IO uint32_t	TAUDCMUR2;					/*!< 0x0C8 : Channel Mode User Register 2	 			*/
	__IO uint32_t	TAUDCMUR3;					/*!< 0x0CC : Channel Mode User Register 3	 			*/
	__IO uint32_t	TAUDCMUR4;					/*!< 0x0D0 : Channel Mode User Register 4	 			*/
	__IO uint32_t	TAUDCMUR5;					/*!< 0x0D4 : Channel Mode User Register 5	 			*/
	__IO uint32_t	TAUDCMUR6;					/*!< 0x0D8 : Channel Mode User Register 6	 			*/
	__IO uint32_t	TAUDCMUR7;					/*!< 0x0DC : Channel Mode User Register 7	 			*/
	__IO uint32_t	TAUDCMUR8;					/*!< 0x0E0 : Channel Mode User Register 8	 			*/
	__IO uint32_t	TAUDCMUR9;					/*!< 0x0E4 : Channel Mode User Register 9	 			*/
	__IO uint32_t	TAUDCMUR10;					/*!< 0x0E8 : Channel Mode User Register 10	 			*/
	__IO uint32_t	TAUDCMUR11;					/*!< 0x0EC : Channel Mode User Register 11	 			*/
	__IO uint32_t	TAUDCMUR12;					/*!< 0x0F0 : Channel Mode User Register 12	 			*/
	__IO uint32_t	TAUDCMUR13;					/*!< 0x0F4 : Channel Mode User Register 13	 			*/
	__IO uint32_t	TAUDCMUR14;					/*!< 0x0F8 : Channel Mode User Register 14	 			*/
	__IO uint32_t	TAUDCMUR15;					/*!< 0x0FC : Channel Mode User Register 15	 			*/
	     uint32_t	RESERVED0x100[16];			/*!< 0x100 - 0x13C : Reserved							*/
	__I  uint32_t	TAUDCSR0;					/*!< 0x140 : Channel Status Register 0	 				*/
	__I  uint32_t	TAUDCSR1;					/*!< 0x144 : Channel Status Register 1	 				*/
	__I  uint32_t	TAUDCSR2;					/*!< 0x148 : Channel Status Register 2	 				*/
	__I  uint32_t	TAUDCSR3;					/*!< 0x14C : Channel Status Register 3	 				*/
	__I  uint32_t	TAUDCSR4;					/*!< 0x150 : Channel Status Register 4	 				*/
	__I  uint32_t	TAUDCSR5;					/*!< 0x154 : Channel Status Register 5	 				*/
	__I  uint32_t	TAUDCSR6;					/*!< 0x158 : Channel Status Register 6	 				*/
	__I  uint32_t	TAUDCSR7;					/*!< 0x15C : Channel Status Register 7	 				*/
	__I  uint32_t	TAUDCSR8;					/*!< 0x160 : Channel Status Register 8	 				*/
	__I  uint32_t	TAUDCSR9;					/*!< 0x164 : Channel Status Register 9	 				*/
	__I  uint32_t	TAUDCSR10;					/*!< 0x168 : Channel Status Register 10	 				*/
	__I  uint32_t	TAUDCSR11;					/*!< 0x16C : Channel Status Register 11	 				*/
	__I  uint32_t	TAUDCSR12;					/*!< 0x170 : Channel Status Register 12	 				*/
	__I  uint32_t	TAUDCSR13;					/*!< 0x174 : Channel Status Register 13	 				*/
	__I  uint32_t	TAUDCSR14;					/*!< 0x178 : Channel Status Register 14	 				*/
	__I  uint32_t	TAUDCSR15;					/*!< 0x17C : Channel Status Register 15	 				*/
	__O  uint32_t	TAUDCSC0;					/*!< 0x180 : Channel Status Clear Trigger Register 0 	*/
	__O  uint32_t	TAUDCSC1;					/*!< 0x184 : Channel Status Clear Trigger Register 1 	*/
	__O  uint32_t	TAUDCSC2;					/*!< 0x188 : Channel Status Clear Trigger Register 2 	*/
	__O  uint32_t	TAUDCSC3;					/*!< 0x18C : Channel Status Clear Trigger Register 3 	*/
	__O  uint32_t	TAUDCSC4;					/*!< 0x190 : Channel Status Clear Trigger Register 4 	*/
	__O  uint32_t	TAUDCSC5;					/*!< 0x194 : Channel Status Clear Trigger Register 5 	*/
	__O  uint32_t	TAUDCSC6;					/*!< 0x198 : Channel Status Clear Trigger Register 6 	*/
	__O  uint32_t	TAUDCSC7;					/*!< 0x19C : Channel Status Clear Trigger Register 7 	*/
	__O  uint32_t	TAUDCSC8;					/*!< 0x1A0 : Channel Status Clear Trigger Register 8	*/
	__O  uint32_t	TAUDCSC9;					/*!< 0x1A4 : Channel Status Clear Trigger Register 9	*/
	__O  uint32_t	TAUDCSC10;					/*!< 0x1A8 : Channel Status Clear Trigger Register 10	*/
	__O  uint32_t	TAUDCSC11;					/*!< 0x1AC : Channel Status Clear Trigger Register 11	*/
	__O  uint32_t	TAUDCSC12;					/*!< 0x1B0 : Channel Status Clear Trigger Register 12	*/
	__O  uint32_t	TAUDCSC13;					/*!< 0x1B4 : Channel Status Clear Trigger Register 13	*/
	__O  uint32_t	TAUDCSC14;					/*!< 0x1B8 : Channel Status Clear Trigger Register 14	*/
	__O  uint32_t	TAUDCSC15;					/*!< 0x1BC : Channel Status Clear Trigger Register 15	*/
	__I  uint32_t	TAUDTE;						/*!< 0x1C0 : Channel Enable Status Register	 			*/
	__O  uint32_t	TAUDTS;						/*!< 0x1C4 : Channel Start Trigger Register	 			*/
	__O  uint32_t	TAUDTT;						/*!< 0x1C8 : Channel Stop Trigger Register	 			*/
	     uint32_t	RESERVEDx1CC[13];			/*!< 0x1CC - 0x1FC : Reserved							*/
	__IO uint32_t	TAUDCMOR0;					/*!< 0x200 : Channel Mode OS Register 0	 				*/
	__IO uint32_t	TAUDCMOR1;					/*!< 0x204 : Channel Mode OS Register 1	 				*/
	__IO uint32_t	TAUDCMOR2;					/*!< 0x208 : Channel Mode OS Register 2	 				*/
	__IO uint32_t	TAUDCMOR3;					/*!< 0x20C : Channel Mode OS Register 3	 				*/
	__IO uint32_t	TAUDCMOR4;					/*!< 0x210 : Channel Mode OS Register 4	 				*/
	__IO uint32_t	TAUDCMOR5;					/*!< 0x214 : Channel Mode OS Register 5	 				*/
	__IO uint32_t	TAUDCMOR6;					/*!< 0x218 : Channel Mode OS Register 6	 				*/
	__IO uint32_t	TAUDCMOR7;					/*!< 0x21C : Channel Mode OS Register 7	 				*/
	__IO uint32_t	TAUDCMOR8;					/*!< 0x220 : Channel Mode OS Register 8	 				*/
	__IO uint32_t	TAUDCMOR9;					/*!< 0x224 : Channel Mode OS Register 9	 				*/
	__IO uint32_t	TAUDCMOR10;					/*!< 0x228 : Channel Mode OS Register 10 				*/
	__IO uint32_t	TAUDCMOR11;					/*!< 0x22C : Channel Mode OS Register 11 				*/
	__IO uint32_t	TAUDCMOR12;					/*!< 0x230 : Channel Mode OS Register 12 				*/
	__IO uint32_t	TAUDCMOR13;					/*!< 0x234 : Channel Mode OS Register 13 				*/
	__IO uint32_t	TAUDCMOR14;					/*!< 0X238 : Channel Mode OS Register 14 				*/
	__IO uint32_t	TAUDCMOR15;					/*!< 0X23C : Channel Mode OS Register 15 				*/
	__IO uint32_t	TAUDTPS;					/*!< 0X240 : Prescaler Clock Select Register			*/
	__IO uint32_t	TAUDBRS;					/*!< 0X244 : Prescaler Baud Rate Control Register		*/
	__IO uint32_t	TAUDTOM;					/*!< 0x248 : Channel Output Mode Register				*/
	__IO uint32_t	TAUDTOC;					/*!< 0x24C : Channel Output Configuration Register		*/
	__IO uint32_t	TAUDTDE;					/*!< 0x250 : Channel Dead-Time Output Enable Register	*/
	__IO uint32_t	TAUDTDM;					/*!< 0x254 : Channel Dead-Time Output Mode Register		*/
	__IO uint32_t	TAUDTRE;					/*!< 0x258 : Channel Real-Time Output Enable Register	*/
	__IO uint32_t	TAUDTRC;					/*!< 0x25C : Channel Real-Time Output Control Register	*/
	__IO uint32_t	TAUDRDE;					/*!< 0x260 : Channel Reload Data Enable Register		*/
	__IO uint32_t	TAUDRDM;					/*!< 0x264 : Channel Reload Data Mode Register			*/
	__IO uint32_t	TAUDRDS;					/*!< 0x268 : Channel Reload Data Control CH Select Register		*/
	__IO uint32_t	TAUDRDC;					/*!< 0x26C : Channel Reload Data Control Register		*/
	     uint32_t	RESERVED0x270[8];			/*!< 0x270 - 0x28C : Reserved							*/
	__IO uint32_t	TAUDEMU;					/*!< 0x290 : Emulation Register							*/
} RIN_TAUD_TypeDef;

#define RIN_TAUD					((RIN_TAUD_TypeDef *)		RIN_TAUD_BASE)

//-----------------------------------------------------------------------------
// System register
//-----------------------------------------------------------------------------
typedef struct
{
// --- R-IN32M4 information ---
	__O  uint32_t	MDMNT;						/*!< 0x000 : Mode monitor register						*/
	__O  uint32_t	IDCODE;						/*!< 0x004 : ID code register							*/
	__O  uint32_t	RINVER;						/*!< 0x008 : Version register							*/
	     uint8_t	RESERVED0x00C[0x100 - 0x0C];/*!< 0x00C - 0x0FF : Reserved							*/

// --- Burst Access MEMC I/F ---
	__IO uint32_t	WREN;						/*!< 0x100 : Write enable register						*/
	     uint32_t	RESERVED0x104[1];			/*!< 0x104 - 0x107 : Reserved							*/
	__IO uint32_t	WAITZSEL;					/*!< 0x108 : WAITZ selection register					*/
	     uint32_t	RESERVED0x10C[1];			/*!< 0x10C - 0x10F : Reserved							*/
	__IO uint32_t	SMADSEL0;					/*!< 0x110	External memory I/F select 0				*/
	__IO uint32_t	SMADSEL1;					/*!< 0x114	External memory I/F select 1				*/
	__IO uint32_t	SMADSEL2;					/*!< 0x118	External memory I/F select 2				*/
	__IO uint32_t	SMADSEL3;					/*!< 0x11C	External memory I/F select 3				*/
	__IO uint32_t	BCLKSEL;					/*!< 0x120	BUSCLK devide								*/
	__IO uint32_t	SMC352MD;					/*!< 0x124	SMC operation mode 							*/
	     uint8_t	RESERVED0x128[0x180 - 0x128];/*!< 0x128 - 0x17F : Reserved							*/

// --- Watch Doc Timer ---
	__IO uint32_t	WDTCLKCFG;					/*!< 0x180	WDT input clock selection register			*/
	     uint8_t	RESERVED0x184[0x1A0 - 0x184];/*!< 0x184 - 0x18F : Reserved							*/

// --- Clock control ---
	__IO uint32_t	CLKGTD0;					/*!< 0x1A0	Clock control 0								*/
	__IO uint32_t	CLKGTD1;					/*!< 0x1A4	Clock control 1								*/
	__IO uint32_t	CLKGTD2;					/*!< 0x1A8	Clock control 2								*/
	     uint8_t	RESERVED0x1AC[0x1C0 - 0x1AC];/*!< 0x1AC - 0x1BF : Reserved							*/

// --- Reset control ---
	__IO uint32_t	SYSRESET;					/*!< 0x1C0	SYSTEM Reset resister						*/
	     uint8_t	RESERVED0x1C0[0x210 - 0x1C4];/*!< 0x1C0 - 0x20F : Reserved							*/

// --- System control ---
	__IO uint32_t	CPURESET;					/*!< 0x210	CPURESET									*/
	     uint8_t	RESERVED0x214[0x220 - 0x214];/*!< 0x214 - 0x21F : Reserved							*/

// --- Buffer function ---
	__IO uint32_t	DRCTLP0L;					/*!< 0x220	Buffer function select P0L					*/
	__IO uint32_t	DRCTLP0H;					/*!< 0x224	Buffer function select P0H					*/
	__IO uint32_t	DRCTLP1L;					/*!< 0x228	Buffer function select P1L					*/
	__IO uint32_t	DRCTLP1H;					/*!< 0x22C	Buffer function select P1H					*/
	__IO uint32_t	DRCTLP2L;					/*!< 0x230	Buffer function select P2L					*/
	__IO uint32_t	DRCTLP2H;					/*!< 0x234	Buffer function select P2H					*/
	__IO uint32_t	DRCTLP3L;					/*!< 0x238	Buffer function select P3L					*/
	__IO uint32_t	DRCTLP3H;					/*!< 0x23C	Buffer function select P3H					*/
	__IO uint32_t	DRCTLP4L;					/*!< 0x240	Buffer function select P4L					*/
	__IO uint32_t	DRCTLP4H;					/*!< 0x244	Buffer function select P4H					*/
	__IO uint32_t	DRCTLP5L;					/*!< 0x248	Buffer function select P5L					*/
	__IO uint32_t	DRCTLP5H;					/*!< 0x24C	Buffer function select P5H					*/
	__IO uint32_t	DRCTLP6L;					/*!< 0x250	Buffer function select P6L					*/
	__IO uint32_t	DRCTLP6H;					/*!< 0x254	Buffer function select P6H					*/
	__IO uint32_t	DRCTLP7L;					/*!< 0x258	Buffer function select P7L					*/
	__IO uint32_t	DRCTLP7H;					/*!< 0x25C	Buffer function select P7H					*/
	__IO uint32_t	DRCTLRP0L;					/*!< 0x260	Buffer function select RP0L					*/
	__IO uint32_t	DRCTLRP0H;					/*!< 0x264	Buffer function select RP0H					*/
	__IO uint32_t	DRCTLRP1L;					/*!< 0x268	Buffer function select RP1L					*/
	__IO uint32_t	DRCTLRP1H;					/*!< 0x26C	Buffer function select RP1H					*/
	__IO uint32_t	DRCTLRP2L;					/*!< 0x270	Buffer function select RP2L					*/
	__IO uint32_t	DRCTLRP2H;					/*!< 0x274	Buffer function select RP2H					*/
	__IO uint32_t	DRCTLRP3L;					/*!< 0x278	Buffer function select RP3L					*/
	__IO uint32_t	DRCTLRP3H;					/*!< 0x27C	Buffer function select RP3H					*/
	__IO uint32_t	DRCTLEXTP0L;				/*!< 0x280	Buffer function select EXTP0L				*/
	__IO uint32_t	DRCTLEXTP0H;				/*!< 0x284	Buffer function select EXTP0H				*/
	__IO uint32_t	DRCTLEXTP1L;				/*!< 0x288	Buffer function select EXTP1L				*/
	__IO uint32_t	DRCTLEXTP1H;				/*!< 0x28C	Buffer function select EXTP1H				*/
	     uint8_t	RESERVED0x290[0x300 - 0x290];	/*!< 0x290 - 0x2FF : Reserved						*/

// --- System protect ---
	__IO uint32_t	SYSPCMD;					/*!< 0x300	System protect command						*/
	     uint8_t	RESERVED0x304[0x400 - 0x304];/*!< 0x304 - 0x3FF : Reserved							*/

	__IO uint32_t	RTOS_SOFTRST;				/*!< 0x400	HW-RTOS software reset register				*/
	     uint8_t	RESERVED0x404[0x500 - 0x404];/*!< 0x404 - 0x4FF : Reserved							*/

// --- Timer ---
	__IO uint32_t	SELCNT;						/*!< 0x500	Timer input select							*/
	__IO uint32_t	SELCNTD;					/*!< 0x504	Timer input select							*/
	     uint8_t	RESERVED0x508[0x530 - 0x508];/*!< 0x508 - 0x52F : Reserved							*/

	__IO uint32_t	TMTFR0;						/*!< 0x530	Timer trigger factor 0						*/
	__IO uint32_t	TMTFR1;						/*!< 0x534	Timer trigger factor 1						*/
	__IO uint32_t	TMTFR2;						/*!< 0x538	Timer trigger factor 2						*/
	__IO uint32_t	TMTFR3;						/*!< 0x53C	Timer trigger factor 3						*/
	     uint8_t	RESERVED0x540[0x600 - 0x540];/*!< 0x540 - 0x5FF : Reserved							*/
// --- Ether  ---
	__IO uint32_t	MACSEL;						/*!< 0x600	MACSEL										*/
	__IO uint32_t	MDCCFG;						/*!< 0x604	MDC clock select							*/
	     uint8_t	RESERVED0x608[0x680 - 0x608];/*!< 0x608 - 0x67f : Reserved							*/

// --- EtherSW ---
	__IO uint32_t	ETHSWMTC;					/*!< 0x680	EtherSW management TAG						*/
	__IO uint32_t	ETHSWMD;					/*!< 0x684	EtherSW mode control						*/
	     uint8_t	RESERVED0x688[0x700 - 0x688];/*!< 0x688 - 0x6FF : Reserved							*/

// --- DMAC ---
	__IO uint32_t	NFC0;						/*!< 0x700	Noise filter control 0						*/
	__IO uint32_t	NFC1;						/*!< 0x704	Noise filter control 1						*/
	__IO uint32_t	NFC2;						/*!< 0x708	Noise filter control 2						*/
	__IO uint32_t	NFC3;						/*!< 0x70C	Noise filter control 3						*/
	__IO uint32_t	INTM0;						/*!< 0x710	External interrupt mode 0					*/
	__IO uint32_t	INTM1;						/*!< 0x714	External interrupt mode 1					*/
	__IO uint32_t	INTM2;						/*!< 0x718	External interrupt mode 2					*/
	     uint32_t	RESERVED0x71C;				/*!< 0x71C - 0x71F : Reserved							*/
	__IO uint32_t	DMAIFC0;					/*!< 0x720	DMA transfer interface signal 0				*/
	__IO uint32_t	DMAIFC1;					/*!< 0x724	DMA transfer interface signal 1				*/
	__IO uint32_t	RTDMAIFC;					/*!< 0x728	DMA transfer interface signal RT			*/
	     uint32_t	RESERVED0x72C;				/*!< 0x72C - 0x72F : Reserved							*/
	__IO uint32_t	DTFR0;						/*!< 0x730	DMA trigger factor 0						*/
	__IO uint32_t	DTFR1;						/*!< 0x734	DMA trigger factor 1						*/
	__IO uint32_t	DTFR2;						/*!< 0x738	DMA trigger factor 2						*/
	__IO uint32_t	DTFR3;						/*!< 0x73C	DMA trigger factor 3						*/
	__IO uint32_t	RTDTFR;						/*!< 0x740	DMA trigger factor RT						*/
	     uint8_t	RESERVED0x744[0x900 - 0x744];/*!< 0x744 - 0x8FF : Reserved							*/

// --- Scratch ---
	__IO uint32_t	SCRATCH0;					/*!< 0x900	Scratch 0									*/
	__IO uint32_t	SCRATCH1;					/*!< 0x904	Scratch 1									*/
	__IO uint32_t	SCRATCH2;					/*!< 0x908	Scratch 2									*/
	__IO uint32_t	SCRATCH3;					/*!< 0x90C	Scratch 3									*/
	__IO uint32_t	SCRATCH4;					/*!< 0x910	Scratch 4									*/
	__IO uint32_t	SCRATCH5;					/*!< 0x914	Scratch 5									*/
	__IO uint32_t	SCRATCH6;					/*!< 0x918	Scratch 6									*/
	__IO uint32_t	SCRATCH7;					/*!< 0x91C	Scratch 7									*/
	__IO uint32_t	SCRATCH8;					/*!< 0x920	Scratch 8									*/
	__IO uint32_t	SCRATCH9;					/*!< 0x924	Scratch 9									*/
	__IO uint32_t	SCRATCHA;					/*!< 0x928	Scratch A									*/
	__IO uint32_t	SCRATCHB;					/*!< 0x92C	Scratch B									*/
	__IO uint32_t	SCRATCHC;					/*!< 0x930	Scratch C									*/
	     uint32_t	RESERVED0x934;				/*!< 0x934	Reserved									*/

// --- CC-Link IE --- 
	     uint32_t	RESERVED0x938;				/*!< 0x938	Reserved									*/
	__IO uint32_t	PHYLINK_EN;					/*!< 0x93C	PHY Link Enable resister					*/
	     uint8_t	RESERVED0x940[0xA00 - 0x940];/*!< 0x940 - 0x9FF : Reserved							*/

// --- Port ---
	__IO uint32_t	RPTRGMD;					/*!< 0xA00	Trigger sync port control					*/
	     uint8_t	RESERVED0xA04[0xA30 - 0xA04];/*!< 0xA04 - 0xA2F : Reserved							*/
	__IO uint32_t	RP0TFR;						/*!< 0xA30	Trigger sync port factor 0					*/
	__IO uint32_t	RP1TFR;						/*!< 0xA34	Trigger sync port factor 1					*/
	__IO uint32_t	RP2TFR;						/*!< 0xA38	Trigger sync port factor 2					*/
	__IO uint32_t	RP3TFR;						/*!< 0xA3C	Trigger sync port factor 3					*/


	     uint8_t	RESERVED0xA40[0xD00 - 0xA40];/*!< 0xA40 - 0xCFF : Reserved							*/
	__IO uint32_t	TMDTFR0;					/*!< 0xD00	Timer trigger factor 0						*/
	__IO uint32_t	TMDTFR1;					/*!< 0xD04	Timer trigger factor 1						*/
	__IO uint32_t	TMDTFR2;					/*!< 0xD08	Timer trigger factor 2						*/
	__IO uint32_t	TMDTFR3;					/*!< 0xD0C	Timer trigger factor 3						*/
	__IO uint32_t	TMDTFR4;					/*!< 0xD10	Timer trigger factor 4						*/
	__IO uint32_t	TMDTFR5;					/*!< 0xD14	Timer trigger factor 5						*/
	__IO uint32_t	TMDTFR6;					/*!< 0xD18	Timer trigger factor 6						*/
	__IO uint32_t	TMDTFR7;					/*!< 0xD1C	Timer trigger factor 7						*/

	     uint8_t	RESERVED0xD20[0xE00 - 0xD20];/*!< 0xD20 - 0xDFF : Reserved							*/
	__IO uint32_t	MDIOSEL;					/*!< 0xE00	GMII/MII management interface select		*/

	     uint8_t	RESERVED0xE04[0x1100 - 0xE04];/*!< 0xE04 - 0x10FF : Reserved						*/

	__IO uint32_t	SWTMEN;						/*!< 0x1100	EtherSwitch timer output enable				*/
	     uint8_t	RESERVED0x1104[0x1110 - 0x1104];/*!< 0x1104 - 0x110F : Reserved						*/

	__IO uint32_t	SWTMSTSECL;					/*!< 0x1110	EtherSwitch timer start control (second) 0	*/
	__IO uint32_t	SWTMSTSECH;					/*!< 0x1114	EtherSwitch timer start control (second) 1	*/
	__IO uint32_t	SWTMSTNSL;					/*!< 0x1118	EtherSwitch timer start control (nano-second) 0	*/
	__IO uint32_t	SWTMSTNSH;					/*!< 0x111C	EtherSwitch timer start control (naoo-second) 1	*/
	__IO uint32_t	SWTMPSECL;					/*!< 0x1120	EtherSwitch timer period control (second) 0	*/
	__IO uint32_t	SWTMPSECH;					/*!< 0x1124	EtherSwitch timer period control (second) 1	*/
	__IO uint32_t	SWTMPNSL;					/*!< 0x1128	EtherSwitch timer period control (nano-second) 0	*/
	__IO uint32_t	SWTMPNSH;					/*!< 0x112C	EtherSwitch timer period control (nano-second) 1	*/
	__IO uint32_t	SWTMWTH;					/*!< 0x1130	EtherSwitch timer pulse width control	*/
	__IO uint32_t	SWTMMAXPL;					/*!< 0x1134	EtherSwitch timer maximum count countrol 0	*/
	__IO uint32_t	SWTMMAXPH;					/*!< 0x1138	EtherSwitch timer maximum count countrol 1	*/
	     uint32_t	RESERVED0x113C;				/*!< 0x113C	Reserved									*/
	__O  uint32_t	SWTMLATSEC;					/*!< 0x1140	EtherSwitch timer latch (second)			*/
	__O  uint32_t	SWTMLATNS;					/*!< 0x1144	EtherSwitch timer latch (nano-second)		*/
	     uint8_t	RESERVED0x1148[0x1220 - 0x1148];/*!< 0x1148 - 0x121F : Reserved						*/
	__IO uint32_t	PHYRST;						/*!< 0x1220	GigaBit ethernet phy reset				*/
	__IO uint32_t	PHYRSTCH;					/*!< 0x1224	GigaBit ethernet phy reset select		*/
	     uint8_t	RESERVED0x1228[0x1230 - 0x1228];/*!< 0x1228 - 0x122F : Reserved					*/
	__IO uint32_t	WDTISEL;					/*!< 0x1230	WDT filter select						*/
	     uint8_t	RESERVED0x1234[0x1240 - 0x1234];/*!< 0x1234 - 0x123F : Reserved					*/
	__IO uint32_t	TMISEL;						/*!< 0x1240	Timer interface select					*/
	__IO uint32_t	INTSEL;						/*!< 0x1244	INTPZ/Timer interrupt select			*/
	     uint8_t	RESERVED0x1248[0x1250 - 0x1248];/*!< 0x1248 - 0x124F : Reserved					*/
	__IO uint32_t	NFC4;						/*!< 0x1250	Noise filter control 4					*/
	     uint8_t	RESERVED0x1254[0x2010 - 0x1254];/*!< 0x1254 - 0x200F : Reserved					*/
	__IO uint32_t	NRAMCTL;					/*!< 0x2010	Network RAM ECC function control		*/
	     uint8_t	RESERVED0x2014[0x2020 - 0x2014];/*!< 0x2014 - 0x201F : Reserved					*/
	__I  uint32_t	PHYADD;						/*!< 0x2020	PHY address								*/
	     uint8_t	RESERVED0x2024[0x2030 - 0x2024];/*!< 0x2024 - 0x202F : Reserved					*/
	__I  uint32_t	DCDCMON0;					/*!< 0x2030	Regulator Monitor 0						*/
	__I  uint32_t	DCDCMON1;					/*!< 0x2034	Regulator Monitor 1						*/
} RIN_SYS_TypeDef;

#define RIN_SYS					((RIN_SYS_TypeDef *)		RIN_SYS_BASE)

//-----------------------------------------------------------------------------
// CAN register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	FCNnMmDATB[8];				/*!< 0x01000 : Message buffer register 0-7 (Byte data)			*/
	__IO uint32_t	FCNnMmDTLGB;				/*!< 0x01020 : Message data length register						*/
	__IO uint32_t	FCNnMmSTRB;					/*!< 0x01024 : Message configuration register					*/
	     uint8_t	RESERVED0x01040[0x18];		/*!< 0x01040 - 0x01028 : Reserved								*/
} RIN_CAN_MSGB_TypeDef;

typedef struct
{
	__IO uint32_t	FCNnMmDAT0H;				/*!< 0x09000 : Message buffer register 0 (Half word data)		*/
	     uint8_t	RESERVED0x09004[0x4];		/*!< 0x09004 - 0x09007 : Reserved								*/
	__IO uint32_t	FCNnMmDAT2H;				/*!< 0x09008 : Message buffer register 2 (Half word data)		*/
	     uint8_t	RESERVED0x0900C[0x4];		/*!< 0x0900C - 0x0900F : Reserved			    				*/
	__IO uint32_t	FCNnMmDAT4H;				/*!< 0x09010 : Message buffer register 4 (Half word data)		*/
	     uint8_t	RESERVED0x09014[0x4];		/*!< 0x09014 - 0x09017 : Reserved								*/
	__IO uint32_t	FCNnMmDAT6H;				/*!< 0x09018 : Message buffer register 6 (Half word data)		*/
	     uint8_t	RESERVED0x0901C[0xc];		/*!< 0x0901C - 0x09027 : Reserved								*/
	__IO uint32_t	FCNnMmMID0H;				/*!< 0x09028 : Message ID register 0 (Half word data)			*/
	     uint8_t	RESERVED0x0902C[0x4];		/*!< 0x0902C - 0x0902F : Reserved								*/
	__IO uint32_t	FCNnMmMID1H;				/*!< 0x09030 : Message ID register 1 (Half word data)			*/
	     uint8_t	RESERVED0x09034[0x4];		/*!< 0x09034 - 0x09037 : Reserved								*/
	__IO uint32_t	FCNnMmCTL;					/*!< 0x09038 : Message control register							*/
	     uint8_t	RESERVED0x9003C[0x4];		/*!< 0x0903C - 0x0903F : Reserved								*/
} RIN_CAN_MSGH_TypeDef;

typedef struct
{
	__IO uint32_t	FCNnMmDAT0W;				/*!< 0x11000 : Message buffer register 0 (Word data)			*/
		 uint8_t	RESERVED0x11004[0xC];		/*!< 0x11004 - 0x1100F : Reserved								*/
	__IO uint32_t	FCNnMmDAT4W;				/*!< 0x11010 : Message buffer register 4 (Word data)			*/
		 uint8_t	RESERVED0x11014[0x14];		/*!< 0x11014 - 0x11027 : Reserved								*/
	__IO uint32_t	FCNnMmMID0W;				/*!< 0x11028 : Message ID register 0 (Word data)				*/
		 uint8_t	RESERVED0x1102C[0x14];		/*!< 0x1102C - 0x1103F : Reserved								*/
} RIN_CAN_MSGW_TypeDef;

typedef union {
	// --- Gloabal register ---
	struct {
		     uint8_t	RESERVED0x00000[0x00008 - 0x00000];	/*!< 0x00000 - 0x00007 : Reserved								    	*/
		__IO uint32_t	FCNnGMCSPRE;					/*!< 0x00008 : global clock selection register						    	*/
		     uint8_t	RESERVED0x0000C[0x00020 - 0x0000C];	/*!< 0x0000C - 0x0001F : Reserved								    	*/
		__IO uint32_t	FCNnGMADCTL;					/*!< 0x00020 : global automatic block transmission delay setting register	*/
		     uint8_t	RESERVED0x00024[0x08000 - 0x00024];	/*!< 0x00024 - 0x07FFF : Reserved								    	*/
		__IO uint32_t	FCNnGMCLCTL;					/*!< 0x08000 : global control register										*/
		     uint8_t	RESERVED0x08004[0x08018 - 0x08004];	/*!< 0x08004 - 0x08017 : Reserved										*/
		__IO uint32_t	FCNnGMABCTL;					/*!< 0x08018 : global automatic block transmission control register			*/
		     uint8_t	RESERVED0x0801C[0x100C0 - 0x0801C];	/*!< 0x0801C - 0x100C0 : Reserved										*/
		__I  uint32_t	FCNnDNBMRX0;					/*!< 0x100C0 : global data update bit monitor register 0					*/
		     uint8_t	RESERVED0x100C4[0x100D0 - 0x100C4];	/*!< 0x100C4 - 0x100CF : Reserved										*/
		__I  uint32_t	FCNnDNBMRX1;					/*!< 0x100D0 : global data update bit monitor register 1					*/
	} GLB;
	// --- Module register ---
	struct {
		     uint8_t	RESERVED0x00000[0x00248 - 0x00000];/*!< 0x00000 - 0x00247 : Reserved										*/
		__IO uint32_t	FCNnCMLCSTR;					/*!< 0x00248 : module last error information register						*/
		__I  uint32_t	FCNnCMINSTR;					/*!< 0x0024C : module information register									*/
		     uint8_t	RESERVED0x00250[0x00268 - 0x00250];/*!< 0x00250 - 0x00267 : Reserved										*/
		__IO uint32_t	FCNnCMBRPRS;					/*!< 0x00268 : module bit-rate prescaler and clock selector register		*/
		     uint8_t	RESERVED0x0026C[0xc];			/*!< 0x0026C - 0x00277 : Reserved											*/
		__I  uint32_t	FCNnCMLISTR;					/*!< 0x00278 : module last receive pointer register							*/
		     uint8_t	RESERVED0x0027C[0xc];			/*!< 0x0027C - 0x00287 : Reserved											*/
		__I  uint32_t	FCNnCMLOSTR;					/*!< 0x00288 : module last transmit pointer register						*/
		     uint8_t	RESERVED0x0028C[0x08240 - 0x0028C];/*!< 0x0028C - 0x0823F : Reserved										*/
		__IO uint32_t	FCNnCMCLCTL;					/*!< 0x08240 : module control register										*/
		     uint8_t	RESERVED0x08244[0xc];			/*!< 0x08244 - 0x0824F : Reserved											*/
		__I  uint32_t	FCNnCMERCNT;					/*!< 0x08250 : module error counter register								*/
		     uint8_t	RESERVED0x08254[0x4];   		/*!< 0x08254 - 0x08257 : Reserved											*/
		__IO uint32_t	FCNnCMIECTL;					/*!< 0x08258 : module interrupt enable register								*/
		     uint8_t	RESERVED0x0825C[0x4];			/*!< 0x0825C - 0x0825F : Reserved											*/
		__IO uint32_t	FCNnCMISCTL;					/*!< 0x08260 : module interrupt status register								*/
		     uint8_t	RESERVED0x08264[0xc];			/*!< 0x08264 - 0x0826F : Reserved											*/
		__IO uint32_t	FCNnCMBTCTL;					/*!< 0x08270 : module bit-rate register										*/
		     uint8_t	RESERVED0x08274[0xc];			/*!< 0x08274 - 0x0827F : Reserved											*/
		__IO uint32_t	FCNnCMRGRX;						/*!< 0x08280 : module receive history list register							*/
		     uint8_t	RESERVED0x08284[0xc];			/*!< 0x08284 - 0x0828F : Reserved											*/
		__IO uint32_t	FCNnCMTGTX;						/*!< 0x08290 : module transmit history list register						*/
		     uint8_t	RESERVED0x08294[0x4];			/*!< 0x08294 - 0x08297 : Reserved											*/
		__IO uint32_t	FCNnCMTSCTL;					/*!< 0x08298 : module time stamp register									*/
		     uint8_t	RESERVED0x0829C[0x08300 - 0x0829C];/*!< 0x0829C - 0x082FF : Reserved										*/
		__IO uint32_t	FCNnCMMKCTL01H;					/*!< 0x08300 : module mask 1 register [15: 0]								*/
		     uint8_t	RESERVED0x08304[0x4];			/*!< 0x08304 - 0x08307 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL02H;					/*!< 0x08308 : module mask 1 register [28:16]								*/
		     uint8_t	RESERVED0x0830C[0x4];			/*!< 0x0830C - 0x0830F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL03H;					/*!< 0x08310 : module mask 2 register [15: 0]								*/
		     uint8_t	RESERVED0x08314[0x4];			/*!< 0x08314 - 0x08317 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL04H;					/*!< 0x08318 : module mask 2 register [28:16]								*/
		     uint8_t	RESERVED0x0831C[0x4];			/*!< 0x0831C - 0x0831F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL05H;					/*!< 0x08320 : module mask 3 register [15: 0]								*/
		     uint8_t	RESERVED0x08324[0x4];			/*!< 0x08324 - 0x08327 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL06H;					/*!< 0x08328 : module mask 3 register [28:16]								*/
		     uint8_t	RESERVED0x0832C[0x4];			/*!< 0x0832C - 0x0832F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL07H;					/*!< 0x08330 : module mask 4 register [15: 0]								*/
		     uint8_t	RESERVED0x08334[0x4];			/*!< 0x08334 - 0x08337 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL08H;					/*!< 0x08338 : module mask 4 register [28:16]								*/
		     uint8_t	RESERVED0x0833C[0x4];			/*!< 0x0833C - 0x0833F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL09H;					/*!< 0x08340 : module mask 5 register [15: 0]								*/
		     uint8_t	RESERVED0x08344[0x4];   		/*!< 0x08344 - 0x08347 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL10H;					/*!< 0x08348 : module mask 5 register [28:16]								*/
		     uint8_t	RESERVED0x0834C[0x4];			/*!< 0x0834C - 0x0834F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL11H;					/*!< 0x08350 : module mask 6 register [15: 0]								*/
		     uint8_t	RESERVED0x08354[0x4];			/*!< 0x08354 - 0x08357 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL12H;					/*!< 0x08358 : module mask 6 register [28:16]								*/
		     uint8_t	RESERVED0x0835C[0x4];			/*!< 0x0835C - 0x0835F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL13H;					/*!< 0x08360 : module mask 7 register [15: 0]								*/
		     uint8_t	RESERVED0x08364[0x4];			/*!< 0x08364 - 0x08367 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL14H;					/*!< 0x08368 : module mask 7 register [28:16]								*/
		     uint8_t	RESERVED0x0836C[0x4];			/*!< 0x0836C - 0x0836F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL15H;					/*!< 0x08370 : module mask 8 register [15: 0]								*/
		     uint8_t	RESERVED0x08374[0x4];			/*!< 0x08374 - 0x08377 : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL16H;					/*!< 0x08378 : module mask 8 register [28:16]								*/
		     uint8_t	RESERVED0x0837C[0x10300 - 0x0837c];	/*!< 0x0837C - 0x102FF : Reserved										*/
		__IO uint32_t	FCNnCMMKCTL01W;					/*!< 0x10300 : module mask 1 register [28:0]								*/
		     uint8_t	RESERVED0x10304[0xc];   		/*!< 0x10304 - 0x1030F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL03W;					/*!< 0x10310 : module mask 2 register [28:0]								*/
		     uint8_t	RESERVED0x10314[0xc];			/*!< 0x10314 - 0x1031F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL05W;					/*!< 0x10320 : module mask 3 register [28:0]								*/
		     uint8_t	RESERVED0x10324[0xc];			/*!< 0x10324 - 0x1032F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL07W;					/*!< 0x10330 : module mask 4 register [28:0]								*/
		     uint8_t	RESERVED0x10334[0xc];			/*!< 0x10334 - 0x1033F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL09W;					/*!< 0x10340 : module mask 5 register [28:0]								*/
		     uint8_t	RESERVED0x10344[0xc];			/*!< 0x10344 : Reserved														*/
		__IO uint32_t	FCNnCMMKCTL11W;					/*!< 0x10350 : module mask 6 register [28:0]								*/
		     uint8_t	RESERVED0x10354[0xc];			/*!< 0x13354 - 0x1035F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL13W;					/*!< 0x10360 : module mask 7 register [28:0]								*/
		     uint8_t	RESERVED0x10364[0xc];			/*!< 0x10364 - 0x1036F : Reserved											*/
		__IO uint32_t	FCNnCMMKCTL15W;					/*!< 0x10370 : module mask 8 register [28:0]								*/
	} MDL;
	// --- Message buffer ---
	struct {
		     uint8_t	RESERVED0x00000[0x01000];		/*!< 0x00000 - 0x00FFF : Reserved											*/
		RIN_CAN_MSGB_TypeDef		B[64];				/*!< 0x01000 - 0x01FFF : 													*/
		     uint8_t	RESERVED0x02000[0x09000 - 0x02000];	/*!< 0x02000 - 0x08FFF : Reserved										*/
		RIN_CAN_MSGH_TypeDef		H[64];				/*!< 0x09000 - 0x09FFF : 													*/
		     uint8_t	RESERVED0x0A000[0x11000 - 0x0a000];	/*!< 0x0A000 - 0x10FFF : Reserved										*/
		RIN_CAN_MSGW_TypeDef		W[64];				/*!< 0x11000 - 0x11FFF : 													*/
	} MSG;
} RIN_CAN_TypeDef;

#define RIN_CAN0				((RIN_CAN_TypeDef *)		RIN_CAN0_BASE)
#define RIN_CAN1				((RIN_CAN_TypeDef *)		RIN_CAN1_BASE)

//-----------------------------------------------------------------------------
// Ether Switch register
//-----------------------------------------------------------------------------
#define PORT_NUM		3			// Port 0,1,2
// --- Switch Configuration ---
typedef struct
{
	     uint32_t	RESERVED0x0000[(0x08 - 0x00)/4];/*!< 0x0000 :															*/
	__IO uint32_t	PORT_ENA;					/*!< 0x0008 : Port Enable Bits                                            	*/
	__IO uint32_t	UCAST_DEFAULT_MASK;			/*!< 0x000C : Default unicast flooding resolution                         	*/
	     uint32_t	RESERVED0x0010;				/*!< 0x0010 :                                                             	*/
	__IO uint32_t	BCAST_DEFAULT_MASK;			/*!< 0x0014 : Default broadcast resolution                                	*/
	__IO uint32_t	MCAST_DEFAULT_MASK;			/*!< 0x0018 : Default multicast resolution                                	*/
	__IO uint32_t	INPUT_LEARN_BLOCK;			/*!< 0x001C : Define port in blocking state and enable or disable learning	*/
	__IO uint32_t	MGMT_CONFIG;				/*!< 0x0020 : Bridge Management Port Config                               	*/
	__IO uint32_t	MODE_CONFIG;				/*!< 0x0024 : Define global config settings                               	*/
	     uint32_t	RESERVED0x0028[(0x34 - 0x28)/4];/*!< 0x0028 :															*/
	__IO uint32_t	VLAN_TAG_ID;				/*!< 0x0034 : VLAN type field value											*/
	     uint32_t	RESERVED0x0038[(0x80 - 0x38)/4];/*!< 0x0038 :															*/
	__IO uint32_t	OQMGR_STATUS;				/*!< 0x0080 : OQMGR status info                								*/
	__IO uint32_t	QMGR_MINCELLS;				/*!< 0x0084 : OQMGR Low memory threshold       								*/
	__IO uint32_t	QMGR_ST_MINCELLS;			/*!< 0x0088 : OQMGR Statistic lowest free cells								*/
	__IO uint32_t	QMGR_CGS_STAT;				/*!< 0x008C : OQMGR Congestion Status          								*/
	__IO uint32_t	QMGR_IFACE_STAT;			/*!< 0x0090 : OQMGR Internal I/F handshaking   								*/
	__IO uint32_t	QMGR_WEIGHTS;				/*!< 0x0094 : OQMGR weights                    								*/
	     uint32_t	RESERVED0x0098[(0x100 - 0x98)/4];/*!< 0x0098 :															*/
	__IO uint32_t	VLAN_PRIORITY[PORT_NUM];	/*!< 0x0100 : VLAN priority resolution map									*/
	     uint32_t	RESERVED0x010C[16 - PORT_NUM];/*!< 0x010C :																*/
	__IO uint32_t	IP_PRIORITY[PORT_NUM];		/*!< 0x0140 : IPv4 priority resolution										*/
	     uint32_t	RESERVED0x014C[16 - PORT_NUM];/*!< 0x014C :																*/
	__IO uint32_t	PRIORITY_CFG[PORT_NUM];		/*!< 0x0180 : priority resolution config									*/
	     uint32_t	RESERVED0x018C[16 - PORT_NUM];/*!< 0x018C :																*/
	__IO uint32_t	HUB_CONTROL;				/*!< 0x01C0 : HUB Control register           								*/
	__IO uint32_t	HUB_STATS;					/*!< 0x01C4 : HUB status                     								*/
	__IO uint32_t	HUB_FLT_MAC0lo;				/*!< 0x01C8 : first 4 octets of MAC address 0								*/
	__IO uint32_t	HUB_FLT_MAC0hi;				/*!< 0x01CC : last  2 octets of MAC address 0 								*/
	__IO uint32_t	HUB_FLT_MAC1lo;				/*!< 0x01D0 : first 4 octets of MAC address 1								*/
	__IO uint32_t	HUB_FLT_MAC1hi;				/*!< 0x01D4 : last  2 octets of MAC address 1 								*/
	__IO uint32_t	HUB_FLT_MAC2lo;				/*!< 0x01D8 : first 4 octets of MAC address 2								*/
	__IO uint32_t	HUB_FLT_MAC2hi;				/*!< 0x01DC : last  2 octets of MAC address 2 								*/
	__IO uint32_t	HUB_FLT_MAC3lo;				/*!< 0x01E0 : first 4 octets of MAC address 3								*/
	__IO uint32_t	HUB_FLT_MAC3hi;				/*!< 0x01E4 : last  2 octets of MAC address 3 								*/
	__IO uint32_t	HUB_FLT_MAC4lo;				/*!< 0x01E8 : first 4 octets of MAC address 4								*/
	__IO uint32_t	HUB_FLT_MAC4hi;				/*!< 0x01EC : last  2 octets of MAC address 4 								*/
	__IO uint32_t	HUB_FLT_MAC5lo;				/*!< 0x01F0 : first 4 octets of MAC address 5								*/
	__IO uint32_t	HUB_FLT_MAC5hi;				/*!< 0x01F4 : last  2 octets of MAC address 5 								*/
	__IO uint32_t	HUB_FLT_MAC6lo;				/*!< 0x01F8 : first 4 octets of MAC address 6								*/
	__IO uint32_t	HUB_FLT_MAC6hi;				/*!< 0x01FC : last  2 octets of MAC address 6 								*/
	     uint32_t	RESERVED0x0200[(0x300 - 0x200)/4];/*!< 0x0200 :															*/
	__IO uint32_t	TOTAL_BYT_FRM;				/*!< 0x0300 : Sum of bytes of frames in TOTAL_FRM            				*/
	__IO uint32_t	TOTAL_BYT_DISC;				/*!< 0x0304 : Sum of bytes of frames in TOTAL_DISC           				*/
	__IO uint32_t	TOTAL_FRM;					/*!< 0x0308 : Total number of incoming frames                				*/
	__IO uint32_t	TOTAL_DISC;					/*!< 0x030C : Total number of incoming frames discarded in SW				*/
	__IO uint32_t	ODISC0;						/*!< 0x0310 : Port 0 outgoing frames discarded               				*/
	__IO uint32_t	IDISC_BLOCKED0;				/*!< 0x0314 : Port 0 incoming frames discarded               				*/
	__IO uint32_t	ODISC1;						/*!< 0x0318 : Port 1 outgoing frames discarded               				*/
	__IO uint32_t	IDISC_BLOCKED1;				/*!< 0x031C : Port 1 incoming frames discarded               				*/
	__IO uint32_t	ODISC2;						/*!< 0x0320 : Port 2 outgoing frames discarded               				*/
	__IO uint32_t	IDISC_BLOCKED2;				/*!< 0x0324 : Port 2 incoming frames discarded               				*/
	     uint32_t	RESERVED0x0328[(0x500 - 0x328)/4];/*!< 0x0328 : 														*/
} RIN_ETHSW_SWCFG_TypeDef;


// --- Learning Interface ---
typedef struct
{
	__IO uint32_t	LRN_REC_A;					/*!< 0x0500 : Learning Records A            								*/
	__IO uint32_t	LRN_REC_B;					/*!< 0x0504 : Learning Records B            								*/
	__IO uint32_t	LRN_STATUS;					/*!< 0x0508 : Learning data available status								*/
	     uint8_t	RESERVED0x050C[0x600 - 0x050C];	/*!< 0x050C : Reserved													*/
} RIN_ETHSW_FIFO_TypeDef;


// --- Address lookup table ---
typedef struct
{
	__IO uint8_t	ADR_TABLE[0x47FD - 0x4000];	/*!< 0x4000-47FC : Address Table											*/
	     uint8_t	RESERVED0x47FD[0x8000 - 0x47FD];/*!< 0x47FD-7FFF : Reserved												*/
} RIN_ETHSW_LUT_TypeDef;

// --- MAC Port ---
//  MAC Port 0 : 0x8000 - 0x83FC
//  MAC Port 1 : 0xA000 - 0xA3FC
typedef struct
{
	     uint32_t	RESERVED0x8000[(0x08 - 0x00)/4];/*!< 0x8000 :															*/
	__IO uint32_t	COMMAND_CONFIG;				/*!< 0x8008 : Command Register                                              */
	     uint32_t	RESERVED0x800C[(0x14 - 0x0C)/4];/*!< 0x800C :															*/
	__IO uint32_t	FRM_LENGTH;					/*!< 0x8014 : Max frame length                                              */
	     uint32_t	RESERVED0x8018;				/*!< 0x8018 :																*/
	__IO uint32_t	RX_SECTION_EMPTY;			/*!< 0x801C : receive FIFO section empty threshold                          */
	__IO uint32_t	RX_SECTION_FULL;			/*!< 0x8020 : receive FIFO section full threshold                           */
	__IO uint32_t	TX_SECTION_EMPTY;			/*!< 0x8024 : transmit FIFO section empty threshold                         */
	__IO uint32_t	TX_SECTION_FULL;			/*!< 0x8028 : transmit FIFO section full threshold                          */
	__IO uint32_t	RX_ALMOST_EMPTY;			/*!< 0x802C : receive FIFO almost empty threshold                           */
	__IO uint32_t	RX_ALMOST_FULL;				/*!< 0x8030 : receive FIFO almost full threshold                            */
	__IO uint32_t	TX_ALMOST_EMPTY;			/*!< 0x8034 : transmit FIFO almost empty threshold                          */
	__IO uint32_t	TX_ALMOST_FULL;				/*!< 0x8038 : transmit FIFO almost full threshold                           */
	     uint8_t	RESERVED0x803C[0x58 - 0x3C];/*!< 0x803C :																*/
	__IO uint32_t	MAC_STATUS;					/*!< 0x8058 : informal status info for both MACs                            */
	__IO uint32_t	TX_IPG_LENGTH;				/*!< 0x805C : Programmable Inter-Packet Gap                                 */
	     uint8_t	RESERVED0x8060[0x100 - 0x60];/*!< 0x8060 :																*/
	// --- MAC Statistics register(RX Statistic Counters) ---
	__I  uint32_t	etherStatsOctets;					/*!< 0x8100 : total octets, good and bad frames								*/
	__I  uint32_t	OctetsOK;							/*!< 0x8104 : total octets, good frames only								*/
	__I  uint32_t	aAlignmentErrors;					/*!< 0x8108 : Counts when mii_rx_dv deasserted but no SFD (0xd5) was		*/
	__I  uint32_t	aPAUSEMACCtrlFrames;				/*!< 0x810C : PAUSEMACCtrlFrames good pause frames received					*/
	__I  uint32_t	FramesOK;							/*!< 0x8110 : good frames received											*/
	__I  uint32_t	CRCErrors;							/*!< 0x8114 : wrong CRC but good length (64..MTU)							*/
	__I  uint32_t	VLANOK;								/*!< 0x8118 : good,VLAN tagged												*/
	__I  uint32_t	ifInErrors;							/*!< 0x811C : Counts for any receive errors.								*/
														/*			  -FIFO Overflow Errors (while receiving)						*/
														/*			  -CRC Errors													*/
														/*			  -Payload Length Errors (if not suppressed)					*/
														/*			  -Jabber and Oversized Errors									*/
														/*			  -PHY errors (mii_rx_er asserted)								*/
	__I  uint32_t	ifInUcastPkts;						/*!< 0x8120 : ifInUcastPkts Good Unicast									*/
	__I  uint32_t	ifInMulticastPkts;					/*!< 0x8124 : Good Multicast												*/
	__I  uint32_t	ifInBroadcastPkts;					/*!< 0x8128 : Good Broadcast												*/
	__I  uint32_t	etherStatsDropEvents;				/*!< 0x812C : Increments when frames are dropped							*/
	__I  uint32_t	etherStatsPkts;						/*!< 0x8130 : total frames, good & bad										*/
	__I  uint32_t	etherStatsUndersizePkts;			/*!< 0x8134 : frames with length less 64 bytes and good CRC					*/
	__I  uint32_t	etherStatsPkts64Octets;				/*!< 0x8138 : frames with length of 64 bytes								*/
	__I  uint32_t	etherStatsPkts65to127Octets;		/*!< 0x813C : frames with length from 65 .. 127 bytes						*/
	__I  uint32_t	etherStatsPkts128to255Octets;		/*!< 0x8140 : frames with length from 128 .. 255 bytes						*/
	__I  uint32_t	etherStatsPkts256to511Octets;		/*!< 0x8144 : frames with length from 256 .. 511 bytes						*/
	__I  uint32_t	etherStatsPkts512to1023Octets;		/*!< 0x8148 : frames with length from 512 .. 1023 bytes						*/
	__I  uint32_t	etherStatsPkts1024to1518Octets;		/*!< 0x814C : frames with length from 1024 .. 1518 bytes					*/
	__I  uint32_t	etherStatsPkts1519toMax;			/*!< 0x8150 : frames with length from 1519 .. value in FRM_LENGTH register	*/
	__I  uint32_t	etherStatsOversizePkts;				/*!< 0x8154 : frames with length exceeding FRM_LENGTH, good CRC				*/
	__I  uint32_t	etherStatsJabbers;					/*!< 0x8158 : frames with length exceeding FRM_LENGTH, bad CRC				*/
	__I  uint32_t	etherStatsFragments;				/*!< 0x815C : frames with length less 64 and bad CRC						*/
	__I  uint32_t	aMACControlFramesReceived;			/*!< 0x8160 : Good Frames with type 0x8808 (incl. Pause)					*/
	__I  uint32_t	aFrameTooLong;						/*!< 0x8164 : total frames exceeding FRAME_LENGTH, good & bad				*/
	     uint32_t	RESERVED0x8168[(0x16c - 0x168)/4];	/*!< 0x8168 :																*/
	__I  uint32_t	StackedVLANOK;						/*!< 0x816C : Good with stacked VLAN (two VLAN tags)						*/
	     uint32_t	RESERVED0x8170[(0x180 - 0x170)/4];	/*!< 0x8170 :																*/
	// --- MAC Statistics register(TX Statistic Counters) ---
	__I  uint32_t	TXetherStatsOctets;					/*!< 0x8180 : total octets, good and bad frames								*/
	__I  uint32_t	TxOctetsOK;							/*!< 0x8184 : total octets, good and bad frames								*/
	     uint32_t	RESERVED0x8188[(0x18C - 0x188)/4];	/*!< 0x8188 :																*/
	__I  uint32_t	TXaPAUSEMACCtrlFrames;				/*!< 0x818C : good pause transmitted										*/
	__I  uint32_t	TxFramesOK;							/*!< 0x8190 : good transmitted												*/
	__I  uint32_t	TxCRCErrors;						/*!< 0x8194 : transmitted with error but good length (ff_tx_err)			*/
	__I  uint32_t	TxVLANOK;							/*!< 0x8198 : good,VLAN tagged												*/
	__I  uint32_t	ifOutErrors;						/*!< 0x819C : any error (ff_tx_err, toolong, but not counting undersized)	*/
	__I  uint32_t	ifUcastPkts;						/*!< 0x81A0 : Good Unicast													*/
	__I  uint32_t	ifMulticastPkts;					/*!< 0x81A4 : Good Multicast												*/
	__I  uint32_t	ifBroadcastPkts;					/*!< 0x81A8 : Good Broadcast												*/
	__I  uint32_t	TXetherStatsDropEvents;				/*!< 0x81AC : Counts undersized frames transmitted							*/
	__I  uint32_t	TXetherStatsPkts;					/*!< 0x81B0 : total frames, good & bad										*/
	__I  uint32_t	TXetherStatsUndersizePkts;			/*!< 0x81B4 : frames with length less 64 bytes and good CRC					*/
	__I  uint32_t	TXetherStatsPkts64Octets;			/*!< 0x81B8 : frames with length of 64 bytes								*/
	__I  uint32_t	TXetherStatsPkts65to127Octets;		/*!< 0x81BC : frames with length from 65 .. 127 bytes						*/
	__I  uint32_t	TXetherStatsPkts128to255Octets;		/*!< 0x81C0 : frames with length from 128 .. 255 byte						*/
	__I  uint32_t	TXetherStatsPkts256to511Octets;		/*!< 0x81C4 : frames with length from 256 .. 511 byte						*/
	__I  uint32_t	TXetherStatsPkts512to1023Octets;	/*!< 0x81C8 : frames with length from 512 .. 1023 byte						*/
	__I  uint32_t	TXetherStatsPkts1024to1518Octets;	/*!< 0x81CC : frames with length from 1024 .. 1518 byte						*/
	__I  uint32_t	TXetherStatsPkts1519toMax;			/*!< 0x81D0 : frames with length from 1519 .. value in FRM_LENGTH register	*/
	__I  uint32_t	TXetherStatsOversizePkts;			/*!< 0x81D4 : frames with length exceeding FRM_LENGTH, good					*/
	__I  uint32_t	TXetherStatsJabbers;				/*!< 0x81D8 : frames with length exceeding FRM_LENGTH, bad					*/
	__I  uint32_t	TXetherStatsFragments;				/*!< 0x81DC : frames with length less 64 bytes and marked erronenousyte		*/
	__I  uint32_t	aMACControlFrames;					/*!< 0x81E0 : Good frames with type 0x8808 (incl. Pause)					*/
	__I  uint32_t	TXaFrameTooLong;					/*!< 0x81E4 : total frames exceeding FRAME_LENGTH, good & bad				*/
	     uint32_t	RESERVED0x81E8;						/*!< 0x81E8 : Reserved														*/
	__I  uint32_t	aMultipleCollisions;				/*!< 0x81EC : Successful transmissions after multiple collisions			*/
	__I  uint32_t	aSingleCollisions;					/*!< 0x81F0 : Successful transmissions after one collisions					*/
	__I  uint32_t	aLateCollisions;					/*!< 0x81F4 : Frames transmitted in error due to late collisions			*/
	__I  uint32_t	aExcessCollisions;					/*!< 0x81F8 : aExcessCollisions Frames dropped due to excessive collisions	*/
	     uint32_t	RESERVED0x81FC[(0x2000 - 0x1FC)/4];	/*!< 0x81FC - 0x9FFF : Reserved												*/
} RIN_ETHSW_MAC_TypeDef;

// --- Timer Module ---
typedef struct
{
	     uint32_t	RESERVED0xC000;				/*!< 0xC000                                                                 */
	__IO uint32_t	TSM_CONFIG;					/*!< 0xC004 : TSM Module config                                             */
	__IO uint32_t	TSM_IRQ_STAT_ACK;			/*!< 0xC008 : TSM Interrupt Status/Ack                                      */
	     uint8_t	RESERVED0xC00C[0x020 - 0x00c];/*!< 0xC00C - 0xC01C :                                                    */
	__IO uint32_t	PORT0_CTRL;					/*!< 0xC020 : TSM Port 0 timestamp control/status                           */
	__I  uint32_t	PORT0_TIME;					/*!< 0xC024 : TSM Port0 memorized timestamp                                 */
	__IO uint32_t	PORT1_CTRL;					/*!< 0xC028 : TSM Port 1 timestamp control/status                           */
	__I  uint32_t	PORT1_TIME;					/*!< 0xC02C : TSM Port1 memorized timestamp                                 */
	     uint8_t	RESERVED0xC030[0x120 - 0x030];/*!< 0xC030 - 0xC11C :                                                    */
	__IO uint32_t	ATIME_CTRL;					/*!< 0xC120 : TSM Time control                                              */
	__IO uint32_t	ATIME;						/*!< 0xC124 : TSM Time value                                                */
	__IO uint32_t	ATIME_OFFSET;				/*!< 0xC128 : TSM offset corrections                                        */
	__IO uint32_t	ATIME_EVT_PERIOD;			/*!< 0xC12C : TSM periodic events                                           */
	__IO uint32_t	ATIME_CORR;					/*!< 0xC130 : TSM correction value                                          */
	__IO uint32_t	ATIME_INC;					/*!< 0xC134 : TSM correction increment value                                */
	__IO uint32_t	ATIME_SEC;					/*!< 0xC138 : TSM second time value                                         */
	__IO uint32_t	ATIME_OFFS_CORR;			/*!< 0xC13C : TSM offset correction counter                                 */
} RIN_ETHSW_TSM_TypeDef;

// --- DLR Extension Module ---
typedef struct
{
	__IO uint32_t	DLR_CONTROL;				/*!< 0xE000 : DLR Control register											*/
	__I  uint32_t	DLR_STATUS;					/*!< 0xE004 : DLR Status register											*/
	__IO uint32_t	DLR_ETH_TYP;				/*!< 0xE008 : Ethernet Type to compare for DLR frame 						*/
	__IO uint32_t	DLR_IRQ_CTRL;				/*!< 0xE00C : Interrupt Control												*/
	__IO uint32_t	DLR_IRQ_STAT_ACK;			/*!< 0xE010 : Interrupt Status/Acknowledgement								*/
	__IO uint32_t	LOC_MAClo;					/*!< 0xE014 : Local MAC address												*/
	__IO uint32_t	LOC_MAChi;					/*!< 0xE018 : Local MAC address												*/
	     uint8_t	RESERVED0xE01C[4];			/*!< 0xE01C : Reserved														*/
	__I  uint32_t	SUPR_MAClo;					/*!< 0xE020 : Active ring supervisor's MAC address							*/
	__I  uint32_t	SUPR_MAChi;					/*!< 0xE024 : Active ring supervisor's MAC address							*/
	__I  uint32_t	STATE_VLAN;					/*!< 0xE028 : DLR Ring state												*/
	__I  uint32_t	BEC_TMOUT;					/*!< 0xE02C : Beacon timeout timer value									*/
	__I  uint32_t	BEC_INTRVL;					/*!< 0xE030 : Beacon interval												*/
	__I  uint32_t	SUPR_IPADR;					/*!< 0xE034 : Ring supervisor's IP address									*/
	__I  uint32_t	ETH_STYP_VER;				/*!< 0xE038 : DLR Ring Ether sub Type and Protocol Version					*/
	__I  uint32_t	INV_TMOUT;					/*!< 0xE03C : Last out of range Beacon timeout timer value					*/
	__I  uint32_t	SEQ_ID;						/*!< 0xE040 : Sequence ID of the last Beacon frame							*/
	     uint8_t	RESERVED0xE044[0x060 - 0x044];/*!< 0xE044 - 0xE05C : Reserved											*/
	__I  uint32_t	RX_STAT0;					/*!< 0xE060 : Number of Beacon frames received on port 0					*/
	__I  uint32_t	RX_ERR_STAT0;				/*!< 0xE064 : Number of Beacon frames received with crc error on port 0		*/
	__I  uint32_t	TX_STAT0;					/*!< 0xE068 : Number of Beacon frames forwarded through the HUB from port 1 to port0	*/
	     uint8_t	RESERVED0xE06C[4];			/*!< 0xE06C : Reserved														*/
	__I  uint32_t	RX_STAT1;					/*!< 0xE070 : Number of Beacon frames received on port 1					*/
	__I  uint32_t	RX_ERR_STAT1;				/*!< 0xE074 : Number of Beacon frames received with crc error on port 1		*/
	__I  uint32_t	TX_STAT1;					/*!< 0xE078 : Number of Beacon frames forwarded through the HUB from port 0 to port1	*/
	     uint8_t	RESERVED0xE07C[4];			/*!< 0xE07C : Reserved														*/
} RIN_ETHSW_DLR_TypeDef;

// --- Ether switch ---
typedef struct
{
	RIN_ETHSW_SWCFG_TypeDef		SWCFG;			/*!< 0x0000 - 0x03FC : Switch Configuration									*/
	RIN_ETHSW_FIFO_TypeDef		FIFO;			/*!< 0x0500 - 0x05FC : Learning Interface									*/
	     uint8_t	RESERVED0x0600[0x4000 - 0x0600];/*!< 0x0600 - 0x3FFC : Reserved											*/
	RIN_ETHSW_LUT_TypeDef		LUT;			/*!< 0x4000 - 0x7FFC : Address lookup table									*/
	RIN_ETHSW_MAC_TypeDef		MAC[2];			/*!< 0x8000 - 0xBFFC : MAC Port 0/1											*/
	RIN_ETHSW_TSM_TypeDef		TSM;			/*!< 0xC000 - 0xC13C : Timer Module											*/
	     uint8_t	RESERVED0xC140[0xe000 - 0xc140];/*!< 0xC140 - 0xDFFC : Reserved											*/
	RIN_ETHSW_DLR_TypeDef		DLR;			/*!< 0xE000 - 0xE07C : DLR Extension Module									*/
} RIN_ETHSW_TypeDef;

#define RIN_ETHSW				((RIN_ETHSW_TypeDef *)		RIN_ETHSW_BASE)

//-----------------------------------------------------------------------------
// HWRTOS register
//-----------------------------------------------------------------------------
// ------ Context ------
typedef struct
{
	__IO uint32_t CNTX_TYPE;					/*!< 0x0000 : Context type								*/
	__IO uint32_t PRTY;							/*!< 0x0004 : Context priority							*/
	__IO uint32_t CNTX_STAT;					/*!< 0x0008 : Context status							*/
	__IO uint32_t INIT_ADD;						/*!< 0x000c : Initial address							*/
	__IO uint32_t INIT_R14;						/*!< 0x0010 : Initial stack point						*/
	__IO uint32_t WT_RSN;						/*!< 0x0014 : Wait reason								*/
	__IO uint32_t SMPH_ID;						/*!< 0x0018 : Waitting semaphore ID						*/
	__IO uint32_t EVNT_ID;						/*!< 0x001c : Waitting eventflag ID						*/
	__IO uint32_t EVNT_FLG;						/*!< 0x0020 : Waitting eventflag pattern				*/
	__IO uint32_t FLG_CND;						/*!< 0x0024 : Eventflag condition (1:and, 0:or)			*/
	__IO uint32_t WT_TIMEOUT;					/*!< 0x0028 : Timeout count								*/
	__IO uint32_t AT_CLR;						/*!< 0x002c : Auto flag clear enable					*/
	__IO uint32_t QUE_ODR;						/*!< 0x0030 : Que order									*/
	__IO uint32_t HWFUNC_ID;					/*!< 0x0034 : Hardware function ID						*/
	__IO uint32_t WUP_RQ_QUE;					/*!< 0x0038 : Wakeup request que count					*/
	__IO uint32_t TO_RQ_ODR;					/*!< 0x003c : Timeout que								*/
} HWOS_CONTEXT_TypeDef;

typedef struct
{
	__IO uint32_t	EXCPT_MODE;	 				/*!< 0x000 : Exception mode								*/
	__IO uint32_t	EXCPT_CNTX;					/*!< 0x004 : Exception context							*/
	__IO uint32_t	EXCPT_ADD;					/*!< 0x008 : Exception address							*/
	__IO uint32_t	DEBUG_CNTX;					/*!< 0x00c : Debug context								*/
	__IO uint32_t	DEBUG_ADD;					/*!< 0x010 : Debug address								*/
	__IO uint32_t	WT_TO_PRESCL;				/*!< 0x014 : Wait time counter to prescale				*/
	__IO uint32_t	SYS_TIM;					/*!< 0x018 : System timer								*/
} HWOS_COMMON_TypeDef;

// ------ HW-ISR ------
typedef struct
{
	__IO uint32_t	HWISR_PNTR[8];				/*!< 0x0000 - 0x001F : HW-ISR PNTR						*/
	     uint32_t	RESERVED0x0020[56];			/*!< 0x0020 - 0x00FF : (RSV) 							*/
	__IO uint32_t	HWISP_OPR[32];				/*!< 0x0100 - 0x017F : HW-ISR OPR						*/
	     uint32_t	RESERVED0x0180[32];			/*!< 0x0180 - 0x01FF : (RSV) 							*/
	__IO uint32_t	QINT;						/*!< 0x0200          : HW-ISR QINT						*/
} HWOS_HWISR_TypeDef;

// ------ CPU I/F ------
typedef struct
{
	__IO uint32_t	SYSC;						/*!< 0x0000 : CPU I/F SYSC 								*/
	__IO uint32_t	R4;							/*!< 0x0004 : CPU I/F R4   								*/
	__IO uint32_t	R5;							/*!< 0x0008 : CPU I/F R5   								*/
	__IO uint32_t	R6;							/*!< 0x000c : CPU I/F R6   								*/
	__IO uint32_t	R7;							/*!< 0x0010 : CPU I/F R7   								*/
	__IO uint32_t	CMD;						/*!< 0x0014 : CPU I/F CMD  								*/
	     uint32_t	RESERVED0x0018[2];			/*!< 0x0018 - 0x001F : Reserved							*/
	__IO uint32_t	R0;							/*!< 0x0020 : CPU I/F R0 								*/
	__IO uint32_t	R1;							/*!< 0x0024 : CPU I/F R1 								*/
} HWOS_CPUIF_TypeDef;

typedef struct
{
// ------ Context ------
	HWOS_CONTEXT_TypeDef	CNTX[64];			/*!< 0x0000 - 0x0FFF : Context control registers			*/
	uint32_t RESERVED0x1000[0x0C00];			/*!< 0x1000 - 0x3FFF : Reserved								*/
	HWOS_COMMON_TypeDef		CMN;				/*!< 0x4000 - 0x401B : Context control registers(common)	*/
	uint32_t RESERVED0x401C[0x0FF9];			/*!< 0x401C - 0x7FFF : Reserved								*/
// ------ Semaphore / Mutex ------
	__IO uint32_t			SEM_TBL[128];		/*!< 0x8000 - 0x81FF : Semaphore table						*/
	uint32_t RESERVED0x8200[0x0080];			/*!< 0x8200 - 0x83FF : Reserved								*/
// ------ Event flag ------
	__IO uint32_t			FLG_TBL[64];		/*!< 0x8400 - 0x84FF : Event flag table						*/
	uint32_t RESERVED0x8500[0x00C0];			/*!< 0x8500 - 0x87FF : Reserved								*/
// ------ HW-ISR ------
	HWOS_HWISR_TypeDef		HWISR; 				/*!< 0x8800 - 0x8A03 : Hardware ISR registers				*/
	uint32_t RESERVED0x8A04[0x007F];			/*!< 0x8A04 - 0x8BFF : Reserved								*/
// ------ Mailbox ------
	__IO uint32_t			MBX_TBL[64]; 		/*!< 0x8C00 - 0x8CFF : Mailbox table						*/
	uint32_t RESERVED0x8D00[0x00C0];			/*!< 0x8D00 - 0x8FFF : Reserved								*/
// ------ Mailbox ID ------
	__IO uint32_t			MBX_ID_TBL[192];	/*!< 0x9000 - 0x92FF : Mailbox ID table						*/
	uint32_t RESERVED0x9300[0x1740];			/*!< 0x9300 - 0xEFFF: Reserved								*/
// ------ CPU I/F ------
	HWOS_CPUIF_TypeDef		CPUIF;				/*!< 0xF000 - 0xF027 : CPU I/F registers					*/
	uint32_t RESERVED0xF028[0x07F6];			/*!< 0xF028 - 0x10FFF: Reserved								*/
// ------ QINT SEL ------
	__IO uint32_t			QINTSEL[32];		/*!< 0x11000 - 0x1107F : QINT select registers				*/
	uint32_t RESERVED0x11080[0x0020];			/*!< 0x11080 - 0x110FF : Reserved							*/
// ------ Buffer ID ------
	__IO uint32_t			BUFID;				/*!< 0x11100           : BUFID register 					*/
} RIN_HWOS_TypeDef;

#define RIN_HWOS				((RIN_HWOS_TypeDef *)		RIN_HWOS_BASE)

//-----------------------------------------------------------------------------
// EtherMAC register
//-----------------------------------------------------------------------------
typedef struct
{
	     uint32_t	RESERVED0x000[3];			/*!< 0x000 - 0x00F : Reserved							*/
	__IO uint32_t	GMAC_TXID;					/*!< 0x00C : TXID										*/
	__IO uint32_t	GMAC_TXRESULT;				/*!< 0x010 : TX Result									*/
	     uint32_t	RESERVED0x014[3];			/*!< 0x014 - 0x01F : Reserved							*/
	__IO uint32_t	GMAC_MODE;					/*!< 0x020 : MODE										*/
	__IO uint32_t	GMAC_RXMODE;				/*!< 0x024 : RX MODE									*/
	__IO uint32_t	GMAC_TXMODE;				/*!< 0x028 : TX MODE									*/
	     uint32_t	RESERED0x02C;				/*!< 0x02C :											*/
	__IO uint32_t	GMAC_RESET;					/*!< 0x030 : RESET										*/
	     uint32_t	RESERVED0x034[19];			/*!< 0x034 - 0x07F : Reserved							*/
	__IO uint32_t	GMAC_PAUSE1;				/*!< 0x080 : Pause Packet 1								*/
	__IO uint32_t	GMAC_PAUSE2;				/*!< 0x084 : Pause Packet 2								*/
	__IO uint32_t	GMAC_PAUSE3;				/*!< 0x088 : Pause Packet 3								*/
	__IO uint32_t	GMAC_PAUSE4;				/*!< 0x08C : Pause Packet 4								*/
	__IO uint32_t	GMAC_PAUSE5;				/*!< 0x090 : Pause Packet 5								*/
	     uint32_t	RESERVED0x094[1];			/*!< 0x094 : Reserved									*/
	__IO uint32_t	GMAC_FLWCTL;				/*!< 0x098 : RX Flow Control							*/
	__IO uint32_t	GMAC_PAUSPKT;				/*!< 0x09C : Pause PKT									*/
	__IO uint32_t	GMAC_MIIM;					/*!< 0x0A0 : MIIM										*/
	     uint32_t	RESERVED0x0A4[23];			/*!< 0x0A4 - 0x0AF : Reserved							*/
	__IO uint32_t	GMAC_ADR0A;					/*!< 0x100 : MAC Address 0A								*/
	__IO uint32_t	GMAC_ADR0B;					/*!< 0x104 : MAC Address 0B								*/
	__IO uint32_t	GMAC_ADR1A;					/*!< 0x108 : MAC Address 1A								*/
	__IO uint32_t	GMAC_ADR1B;					/*!< 0x10c : MAC Address 1B								*/
	__IO uint32_t	GMAC_ADR2A;					/*!< 0x110 : MAC Address 2A								*/
	__IO uint32_t	GMAC_ADR2B;					/*!< 0x114 : MAC Address 2B								*/
	__IO uint32_t	GMAC_ADR3A;					/*!< 0x118 : MAC Address 3A								*/
	__IO uint32_t	GMAC_ADR3B;					/*!< 0x11c : MAC Address 3B								*/
	__IO uint32_t	GMAC_ADR4A;					/*!< 0x120 : MAC Address 4A								*/
	__IO uint32_t	GMAC_ADR4B;					/*!< 0x124 : MAC Address 4B								*/
	__IO uint32_t	GMAC_ADR5A;					/*!< 0x128 : MAC Address 5A								*/
	__IO uint32_t	GMAC_ADR5B;					/*!< 0x12c : MAC Address 5B								*/
	__IO uint32_t	GMAC_ADR6A;					/*!< 0x130 : MAC Address 6A								*/
	__IO uint32_t	GMAC_ADR6B;					/*!< 0x134 : MAC Address 6B								*/
	__IO uint32_t	GMAC_ADR7A;					/*!< 0x138 : MAC Address 7A								*/
	__IO uint32_t	GMAC_ADR7B;					/*!< 0x13c : MAC Address 7B								*/
	__IO uint32_t	GMAC_ADR8A;					/*!< 0x140 : MAC Address 8A								*/
	__IO uint32_t	GMAC_ADR8B;					/*!< 0x144 : MAC Address 8B								*/
	__IO uint32_t	GMAC_ADR9A;					/*!< 0x148 : MAC Address 9A								*/
	__IO uint32_t	GMAC_ADR9B;					/*!< 0x14c : MAC Address 9B								*/
	__IO uint32_t	GMAC_ADR10A;				/*!< 0x150 : MAC Address 10A							*/
	__IO uint32_t	GMAC_ADR10B;				/*!< 0x154 : MAC Address 10B							*/
	__IO uint32_t	GMAC_ADR11A;				/*!< 0x158 : MAC Address 11A							*/
	__IO uint32_t	GMAC_ADR11B;				/*!< 0x15c : MAC Address 11B							*/
	__IO uint32_t	GMAC_ADR12A;				/*!< 0x160 : MAC Address 12A							*/
	__IO uint32_t	GMAC_ADR12B;				/*!< 0x164 : MAC Address 12B							*/
	__IO uint32_t	GMAC_ADR13A;				/*!< 0x168 : MAC Address 13A							*/
	__IO uint32_t	GMAC_ADR13B;				/*!< 0x16c : MAC Address 13B							*/
	__IO uint32_t	GMAC_ADR14A;				/*!< 0x170 : MAC Address 14A							*/
	__IO uint32_t	GMAC_ADR14B;				/*!< 0x174 : MAC Address 14B							*/
	__IO uint32_t	GMAC_ADR15A;				/*!< 0x178 : MAC Address 15A							*/
	__IO uint32_t	GMAC_ADR15B;				/*!< 0x17c : MAC Address 15B							*/
	     uint32_t	RESERVED0x180[32];			/*!< 0x180 - 0x1FF : Reserved							*/
	__IO uint32_t	GMAC_RXFIFO;				/*!< 0x200 : RX FIFO									*/
	__IO uint32_t	GMAC_TXFIFO;				/*!< 0x204 : TX FIFO									*/
	__IO uint32_t	GMAC_ACC;					/*!< 0x208 : TCPIP Acc									*/
	     uint32_t	RESERVED0x20C[5];			/*!< 0x20C - 0x21F : Reserved							*/
	__IO uint32_t	GMAC_RXMAC_ENA;				/*!< 0x220 : RXMAC Enable								*/
	__IO uint32_t	GMAC_LPI_MODE;				/*!< 0x224 : LPI Mode									*/
	__IO uint32_t	GMAC_LPI_TIMING;			/*!< 0x228 : LPI Timing									*/
	     uint8_t	RESERVED0x22C[0x1100-0x22C];/*!< 0x22C-0x1100 : 									*/
	__IO uint32_t	BUFID;						/*!< 0x1100: Receive Buffer info.						*/
} RIN_ETH_TypeDef;                  

#define RIN_ETH					((RIN_ETH_TypeDef *)		RIN_ETH_BASE)

//-----------------------------------------------------------------------------
// MEMC register
//-----------------------------------------------------------------------------
typedef struct
{
	     uint32_t	RESERVED0x000[1];			/*!< 0x000 : Reserved									*/
	__IO uint32_t	BSC;						/*!< 0x004 : Bus Size Control register					*/
	__IO uint32_t	SMC0;						/*!< 0x008 : Static Memory Control register 0			*/
	__IO uint32_t	SMC1;						/*!< 0x00C : Static Memory Control register 1			*/
	__IO uint32_t	SMC2;						/*!< 0x010 : Static Memory Control register 2			*/
	__IO uint32_t	SMC3;						/*!< 0x014 : Static Memory Control register 3			*/
	__IO uint32_t	PRC;						/*!< 0x018 : Page Rom Control register					*/
} RIN_MEMC_TypeDef;

#define RIN_MEMC				((RIN_MEMC_TypeDef *)		RIN_MEMC_BASE)

//-----------------------------------------------------------------------------
// Serial ROM MEMC register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	SFMSMD;						/*!< 0x000 : Transfer mode control register				*/
	__IO uint32_t	SFMSSC;						/*!< 0x004 : Chip select control register				*/
	__IO uint32_t	SFMSKC;						/*!< 0x008 : Clock control register						*/
	__IO uint32_t	SFMSST;						/*!< 0x00C : Status register							*/
	__IO uint32_t	SFMCOM;						/*!< 0x010 : Communication port register				*/
	__IO uint32_t	SFMCMD;						/*!< 0x014 : Communication mode control register		*/
	__IO uint32_t	SFMCST;						/*!< 0x018 : Communication status register				*/
	     uint32_t	RESERVED0x01C;				/*!< 0x01C : Reserved									*/
	__IO uint32_t	SFMSIC;						/*!< 0x020 : Instruction Code Register					*/
	__IO uint32_t	SFMSAC;						/*!< 0x024 : Address Mode Control Register				*/
	__IO uint32_t	SFMSDC;						/*!< 0x028 : Dummy Cycle Control Register				*/
	     uint32_t	RESERVED0x02C;				/*!< 0x02C : Reserved									*/
	__IO uint32_t	SFMSPC;						/*!< 0x030 : SPI Protocol Control Register				*/
	__IO uint32_t	SFMPMD;						/*!< 0x034 : Port Control Register						*/
	__IO uint32_t	SFMDTC;						/*!< 0x038 : Data Input Timing Control Register			*/
	     uint8_t	RESERVED0x03C[0x04C - 0x03C];/*!< 0x03C - 0x048 : Reserved							*/
	__IO uint32_t	SFMVER;						/*!< 0x04C : Version Register							*/	
	} RIN_SROM_TypeDef;

#define RIN_SROM				((RIN_SROM_TypeDef *)		RIN_SROM_BASE)

//-----------------------------------------------------------------------------
// DMAC register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint32_t	N0SA;						/*!< 0x000 : Source      address register [Next0]		*/
	__IO uint32_t	N0DA;						/*!< 0x004 : Destination address register [Next0]		*/
	__IO uint32_t	N0TB;						/*!< 0x008 : Transaction byte register    [Next0]		*/
	__IO uint32_t	N1SA;						/*!< 0x00C : Source      address register [Next1]		*/
	__IO uint32_t	N1DA;						/*!< 0x010 : Destination address register [Next1]		*/
	__IO uint32_t	N1TB;						/*!< 0x014 : Transaction byte register    [Next1]		*/
	__O  uint32_t	CRSA;						/*!< 0x018 : Source      address register [Current]		*/
	__O  uint32_t	CRDA;						/*!< 0x01C : Destination address register [Current]		*/
	__O  uint32_t	CRTB;						/*!< 0x020 : Transaction byte register    [Current]		*/
	__O  uint32_t	CHSTAT;						/*!< 0x024 : Channel status register					*/
	__IO uint32_t	CHCTRL;						/*!< 0x028 : Channel control register					*/
	__IO uint32_t	CHCFG;						/*!< 0x02C : Channel configulation register				*/
	__IO uint32_t	CHITVL;						/*!< 0x030 : Channel intereval register					*/
	     uint32_t	RESERVED0x034;				/*!< 0x034 : Reserved									*/
	__IO uint32_t	NXLA;						/*!< 0x038 : Link address register [Next]				*/
	__O  uint32_t	CRLA;						/*!< 0x03C : Link address register [Current]			*/
} RIN_DMAC_TypeDef;

#define RIN_DMAC0				((RIN_DMAC_TypeDef *)		RIN_DMAC0_BASE)
#define RIN_DMAC1				((RIN_DMAC_TypeDef *)		RIN_DMAC1_BASE)
#define RIN_DMAC2				((RIN_DMAC_TypeDef *)		RIN_DMAC2_BASE)
#define RIN_DMAC3				((RIN_DMAC_TypeDef *)		RIN_DMAC3_BASE)
#define RIN_RTDMAC				((RIN_DMAC_TypeDef *)		RIN_RTDMAC_BASE)

typedef struct
{
	__IO uint32_t	SCNT;						/*!< 0x000 : Continuation-source size register			*/
	__IO uint32_t	SSKP;						/*!< 0x004 : Skip-source size register					*/
	__IO uint32_t	DCNT;						/*!< 0x008 : Continuation-destination size register		*/
	__IO uint32_t	DSKP;						/*!< 0x00C : Skip-desitination size register			*/
} RIN_DMAC_LINK_TypeDef;

#define RIN_DMAC0_LINK				((RIN_DMAC_LINK_TypeDef *)		RIN_DMAC0_LINK_BASE)
#define RIN_DMAC1_LINK				((RIN_DMAC_LINK_TypeDef *)		RIN_DMAC1_LINK_BASE)
#define RIN_DMAC2_LINK				((RIN_DMAC_LINK_TypeDef *)		RIN_DMAC2_LINK_BASE)
#define RIN_DMAC3_LINK				((RIN_DMAC_LINK_TypeDef *)		RIN_DMAC3_LINK_BASE)
#define RIN_RTDMAC_LINK				((RIN_DMAC_LINK_TypeDef *)		RIN_RTDMAC_LINK_BASE)

typedef struct
{
	__IO uint32_t	DCTRL;						/*!< 0x000 : DMAC control regiseter						*/
	__IO uint32_t	DSCITVL;					/*!< 0x004 : Discriptor interval register				*/
	     uint8_t	RESERVED0x00C[0x10 - 0x08];	/*!< 0x00C - 0x108 : Reserved							*/
	__O  uint32_t	DSTEN;						/*!< 0x010 : DMAC enable status register				*/
	__O  uint32_t	DSTER;						/*!< 0x014 : DMAC error status register					*/
	__O  uint32_t	DSTEND;						/*!< 0x018 : DMAC end status register					*/
	__O  uint32_t	DSTTC;						/*!< 0x01C : DMAC terminal count status register		*/
	__O  uint32_t	DSTSUS;						/*!< 0x020 : DMAC suspend status register				*/
} RIN_DMAC_CTRL_TypeDef;

#define RIN_DMAC_CTRL				((RIN_DMAC_CTRL_TypeDef *)		RIN_DMAC_CTRL_BASE)
#define RIN_RTDMAC_CTRL				((RIN_DMAC_CTRL_TypeDef *)		RIN_RTDMAC_CTRL_BASE)

//-----------------------------------------------------------------------------
// PORT register
//-----------------------------------------------------------------------------
typedef struct
{
	__IO uint8_t	P0B;						/*!< 0x000 : Port register 0 ( 8 bit)						*/
	__IO uint8_t	P1B;						/*!< 0x001 : Port register 1 ( 8 bit)						*/
	__IO uint8_t	P2B;						/*!< 0x002 : Port register 2 ( 8 bit)						*/
	__IO uint8_t	P3B;						/*!< 0x003 : Port register 3 ( 8 bit)						*/
	__IO uint8_t	P4B;						/*!< 0x004 : Port register 4 ( 8 bit)						*/
	__IO uint8_t	P5B;						/*!< 0x005 : Port register 5 ( 8 bit)						*/
	__IO uint8_t	P6B;						/*!< 0x006 : Port register 6 ( 8 bit)						*/
	__IO uint8_t	P7B;						/*!< 0x007 : Port register 7 ( 8 bit)						*/
	     uint8_t	RESERVED0x008[0x010 - 0x008];/*!< 0x008 - 0x00F : Reserved								*/

	__IO uint8_t	PM0B;						/*!< 0x010 : Port mode register 0 ( 8 bit)					*/
	__IO uint8_t	PM1B;						/*!< 0x011 : Port mode register 1 ( 8 bit)					*/
	__IO uint8_t	PM2B;						/*!< 0x012 : Port mode register 2 ( 8 bit)					*/
	__IO uint8_t	PM3B;						/*!< 0x013 : Port mode register 3 ( 8 bit)					*/
	__IO uint8_t	PM4B;						/*!< 0x014 : Port mode register 4 ( 8 bit)					*/
	__IO uint8_t	PM5B;						/*!< 0x015 : Port mode register 5 ( 8 bit)					*/
	__IO uint8_t	PM6B;						/*!< 0x016 : Port mode register 6 ( 8 bit)					*/
	__IO uint8_t	PM7B;						/*!< 0x017 : Port mode register 7 ( 8 bit)					*/
	     uint8_t	RESERVED0x018[0x020 - 0x018];/*!< 0x018 - 0x01F : Reserved								*/

	__IO uint8_t	PMC0B;						/*!< 0x020 : Port mode control register 0 ( 8 bit)			*/
	__IO uint8_t	PMC1B;						/*!< 0x021 : Port mode control register 1 ( 8 bit)			*/
	__IO uint8_t	PMC2B;						/*!< 0x022 : Port mode control register 2 ( 8 bit)			*/
	__IO uint8_t	PMC3B;						/*!< 0x023 : Port mode control register 3 ( 8 bit)			*/
	__IO uint8_t	PMC4B;						/*!< 0x024 : Port mode control register 4 ( 8 bit)			*/
	__IO uint8_t	PMC5B;						/*!< 0x025 : Port mode control register 5 ( 8 bit)			*/
	__IO uint8_t	PMC6B;						/*!< 0x026 : Port mode control register 6 ( 8 bit)			*/
	__IO uint8_t	PMC7B;						/*!< 0x027 : Port mode control register 7 ( 8 bit)			*/
	     uint8_t	RESERVED0x028[0x030 - 0x028];/*!< 0x028 - 0x02F : Reserved								*/

	__IO uint8_t	PFC0B;						/*!< 0x030 : Port function control register 0 ( 8 bit)		*/
	__IO uint8_t	PFC1B;						/*!< 0x031 : Port function control register 1 ( 8 bit)		*/
	__IO uint8_t	PFC2B;						/*!< 0x032 : Port function control register 2 ( 8 bit)		*/
	__IO uint8_t	PFC3B;						/*!< 0x033 : Port function control register 3 ( 8 bit)		*/
	__IO uint8_t	PFC4B;						/*!< 0x034 : Port function control register 4 ( 8 bit)		*/
	__IO uint8_t	PFC5B;						/*!< 0x035 : Port function control register 5 ( 8 bit)		*/
	__IO uint8_t	PFC6B;						/*!< 0x036 : Port function control register 6 ( 8 bit)		*/
	__IO uint8_t	PFC7B;						/*!< 0x037 : Port function control register 7 ( 8 bit)		*/
	     uint8_t	RESERVED0x038[0x040 - 0x038];/*!< 0x038 - 0x03F : Reserved								*/

	__IO uint8_t	PFCE0B;						/*!< 0x040 : Port function control ext.register 0 ( 8 bit)	*/
	__IO uint8_t	PFCE1B;						/*!< 0x041 : Port function control ext.register 1 ( 8 bit)	*/
	__IO uint8_t	PFCE2B;						/*!< 0x042 : Port function control ext.register 2 ( 8 bit)	*/
	__IO uint8_t	PFCE3B;						/*!< 0x043 : Port function control ext.register 3 ( 8 bit)	*/
	__IO uint8_t	PFCE4B;						/*!< 0x044 : Port function control ext.register 4 ( 8 bit)	*/
	__IO uint8_t	PFCE5B;						/*!< 0x045 : Port function control ext.register 5 ( 8 bit)	*/
	__IO uint8_t	PFCE6B;						/*!< 0x046 : Port function control ext.register 6 ( 8 bit)	*/
	__IO uint8_t	PFCE7B;						/*!< 0x047 : Port function control ext.register 7 ( 8 bit)	*/
	     uint8_t	RESERVED0x048[0x050 - 0x048];/*!< 0x048 - 0x04F : Reserved								*/

	__I  uint8_t	PIN0B;						/*!< 0x050 : Port input level register 0 ( 8 bit)			*/
	__I  uint8_t	PIN1B;						/*!< 0x051 : Port input level register 1 ( 8 bit)			*/
	__I  uint8_t	PIN2B;						/*!< 0x052 : Port input level register 2 ( 8 bit)			*/
	__I  uint8_t	PIN3B;						/*!< 0x053 : Port input level register 3 ( 8 bit)			*/
	__I  uint8_t	PIN4B;						/*!< 0x054 : Port input level register 4 ( 8 bit)			*/
	__I  uint8_t	PIN5B;						/*!< 0x055 : Port input level register 5 ( 8 bit)			*/
	__I  uint8_t	PIN6B;						/*!< 0x056 : Port input level register 6 ( 8 bit)			*/
	__I  uint8_t	PIN7B;						/*!< 0x057 : Port input level register 7 ( 8 bit)			*/
	     uint8_t	RESERVED0x058[0x060 - 0x058];/*!< 0x058 - 0x05F : Reserved								*/
} RIN_GPIO_TypeDef;

typedef struct
{
	__IO uint16_t	P0H;						/*!< 0x000 : Port register 0 ( 16 bit)						*/
	__IO uint16_t	P2H;						/*!< 0x002 : Port register 2 ( 16 bit)						*/
	__IO uint16_t	P4H;						/*!< 0x004 : Port register 4 ( 16 bit)						*/
	__IO uint16_t	P6H;						/*!< 0x006 : Port register 6 ( 16 bit)						*/
	     uint8_t	RESERVED0x008[0x010 - 0x008];/*!< 0x008 - 0x00F : Reserved								*/


	__IO uint16_t	PM0H;						/*!< 0x010 : Port mode register 0 ( 16 bit)					*/
	__IO uint16_t	PM2H;						/*!< 0x012 : Port mode register 2 ( 16 bit)					*/
	__IO uint16_t	PM4H;						/*!< 0x014 : Port mode register 4 ( 16 bit)					*/
	__IO uint16_t	PM6H;						/*!< 0x016 : Port mode register 6 ( 16 bit)					*/
	     uint8_t 	RESERVED0x018[0x020 - 0x018];/*!< 0x018 - 0x01F : Reserved								*/

	__IO uint16_t	PMC0H;						/*!< 0x020 : Port mode control register 0 ( 16 bit)			*/
	__IO uint16_t	PMC2H;						/*!< 0x022 : Port mode control register 2 ( 16 bit)			*/
	__IO uint16_t	PMC4H;						/*!< 0x024 : Port mode control register 4 ( 16 bit)			*/
	__IO uint16_t	PMC6H;						/*!< 0x026 : Port mode control register 6 ( 16 bit)			*/
	     uint8_t	RESERVED0x028[0x030 - 0x028];/*!< 0x028 - 0x02F : Reserved								*/

	__IO uint16_t	PFC0H;						/*!< 0x030 : Port function control register 0 ( 16 bit)		*/
	__IO uint16_t	PFC2H;						/*!< 0x032 : Port function control register 2 ( 16 bit)		*/
	__IO uint16_t	PFC4H;						/*!< 0x034 : Port function control register 4 ( 16 bit)		*/
	__IO uint16_t	PFC6H;						/*!< 0x036 : Port function control register 6 ( 16 bit)		*/
	     uint8_t	RESERVED0x038[0x040 - 0x038];/*!< 0x038 - 0x03F : Reserved								*/

	__IO uint16_t	PFCE0H;						/*!< 0x040 : Port function control ext.register 0 ( 16 bit)	*/
	__IO uint16_t	PFCE2H;						/*!< 0x042 : Port function control ext.register 2 ( 16 bit)	*/
	__IO uint16_t	PFCE4H;						/*!< 0x044 : Port function control ext.register 4 ( 16 bit)	*/
	__IO uint16_t	PFCE6H;						/*!< 0x046 : Port function control ext.register 6 ( 16 bit)	*/
	     uint8_t	RESERVED0x048[0x050 - 0x048];/*!< 0x048 - 0x04F : Reserved								*/

	__I  uint16_t	PIN0H;						/*!< 0x050 : Port input level register 0 ( 16 bit)			*/
	__I  uint16_t	PIN2H;						/*!< 0x052 : Port input level register 2 ( 16 bit)			*/
	__I  uint16_t	PIN4H;						/*!< 0x054 : Port input level register 4 ( 16 bit)			*/
	__I  uint16_t	PIN6H;						/*!< 0x056 : Port input level register 6 ( 16 bit)			*/
	     uint8_t	RESERVED0x058[0x060 - 0x058];/*!< 0x058 - 0x05F : Reserved								*/
} RIN_GPIO_H_TypeDef;

typedef struct
{
	__IO uint32_t	P0W;						/*!< 0x000 : Port register 0 ( 32 bit)						*/
	__IO uint32_t	P4W;						/*!< 0x004 : Port register 4 ( 32 bit)						*/
	     uint8_t	RESERVED0x008[0x010 - 0x008];/*!< 0x008 - 0x00F : Reserved								*/

	__IO uint32_t	PM0W;						/*!< 0x010 : Port mode register 0 ( 32 bit)					*/
	__IO uint32_t	PM4W;						/*!< 0x014 : Port mode register 4 ( 32 bit)					*/
	     uint8_t	RESERVED0x018[0x020 - 0x018];/*!< 0x018 - 0x01F : Reserved								*/

	__IO uint32_t	PMC0W;						/*!< 0x020 : Port mode control register 0 ( 32 bit)			*/
	__IO uint32_t	PMC4W;						/*!< 0x024 : Port mode control register 4 ( 32 bit)			*/
	     uint8_t	RESERVED0x028[0x030 - 0x028];/*!< 0x028 - 0x02F : Reserved								*/

	__IO uint32_t	PFC0W;						/*!< 0x030 : Port function control register 0 ( 32 bit)		*/
	__IO uint32_t	PFC4W;						/*!< 0x034 : Port function control register 4 ( 32 bit)		*/
	     uint8_t	RESERVED0x038[0x040 - 0x038];/*!< 0x038 - 0x03F : Reserved								*/

	__IO uint32_t	PFCE0W;						/*!< 0x040 : Port function control ext.register 0 ( 32 bit)	*/
	__IO uint32_t	PFCE4W;						/*!< 0x044 : Port function control ext.register 4 ( 32 bit)	*/
	     uint8_t	RESERVED0x048[0x050 - 0x048];	/*!< 0x048 - 0x04F : Reserved							*/

	__I  uint32_t	PIN0W;						/*!< 0x050 : Port input level register 0 ( 32 bit)			*/
	__I  uint32_t	PIN4W;						/*!< 0x054 : Port input level register 4 ( 32 bit)			*/
	     uint8_t	RESERVED0x058[0x060 - 0x058];/*!< 0x058 - 0x05F : Reserved								*/
} RIN_GPIO_W_TypeDef;

typedef struct
{
	__IO uint8_t	RP0B;						/*!< 0x000 : RT Port register 0 ( 8 bit)					*/
	__IO uint8_t	RP1B;						/*!< 0x001 : RT Port register 1 ( 8 bit)					*/
	__IO uint8_t	RP2B;						/*!< 0x002 : RT Port register 2 ( 8 bit)					*/
	__IO uint8_t	RP3B;						/*!< 0x003 : RT Port register 3 ( 8 bit)					*/
	     uint8_t	RESERVED0[0x010 - 0x004];	/*!< 0x004 - 0x00F : Reserved								*/

	__IO uint8_t	RPM0B;						/*!< 0x010 : RT Port mode register 0 ( 8 bit)				*/
	__IO uint8_t	RPM1B;						/*!< 0x011 : RT Port mode register 1 ( 8 bit)				*/
	__IO uint8_t	RPM2B;						/*!< 0x012 : RT Port mode register 2 ( 8 bit)				*/
	__IO uint8_t	RPM3B;						/*!< 0x013 : RT Port mode register 3 ( 8 bit)				*/
	     uint8_t	RESERVED1[0x020 - 0x014];	/*!< 0x014 - 0x01F : Reserved								*/

	__IO uint8_t	RPMC0B;						/*!< 0x020 : RT Port mode control register 0 ( 8 bit)		*/
	__IO uint8_t	RPMC1B;						/*!< 0x021 : RT Port mode control register 1 ( 8 bit)		*/
	__IO uint8_t	RPMC2B;						/*!< 0x022 : RT Port mode control register 2 ( 8 bit)		*/
	__IO uint8_t	RPMC3B;						/*!< 0x023 : RT Port mode control register 3 ( 8 bit)		*/
	     uint8_t	RESERVED2[0x030 - 0x024];	/*!< 0x024 - 0x02F : Reserved								*/

	__IO uint8_t	RPFC0B;						/*!< 0x030 : RT Port function control register 0 ( 8 bit)	*/
	__IO uint8_t	RPFC1B;						/*!< 0x031 : RT Port function control register 1 ( 8 bit)	*/
	__IO uint8_t	RPFC2B;						/*!< 0x032 : RT Port function control register 2 ( 8 bit)	*/
	__IO uint8_t	RPFC3B;						/*!< 0x033 : RT Port function control register 3 ( 8 bit)	*/
	     uint8_t	RESERVED3[0x040 - 0x034];	/*!< 0x034 - 0x03F : Reserved								*/

	__IO uint8_t	RPFCE0B;					/*!< 0x040 : RT Port function control ext.register 0 ( 8 bit)*/
	__IO uint8_t	RPFCE1B;					/*!< 0x041 : RT Port function control ext.register 1 ( 8 bit)*/
	__IO uint8_t	RPFCE2B;					/*!< 0x042 : RT Port function control ext.register 2 ( 8 bit)*/
	__IO uint8_t	RPFCE3B;					/*!< 0x043 : RT Port function control ext.register 3 ( 8 bit)*/
	     uint8_t	RESERVED4[0x050 - 0x044];	/*!< 0x044 - 0x04F : Reserved								 */

	__I  uint8_t	RPIN0B;						/*!< 0x050 : RT Port input level register 0 ( 8 bit)		*/
	__I  uint8_t	RPIN1B;						/*!< 0x051 : RT Port input level register 1 ( 8 bit)		*/
	__I  uint8_t	RPIN2B;						/*!< 0x052 : RT Port input level register 2 ( 8 bit)		*/
	__I  uint8_t	RPIN3B;						/*!< 0x053 : RT Port input level register 3 ( 8 bit)		*/
	     uint8_t	RESERVED5[0x060 - 0x054];	/*!< 0x054 - 0x05F : Reserved								*/
} RIN_RTPORT_TypeDef;

typedef struct
{
	__IO uint16_t	RP0H;						/*!< 0x000 : RT Port register 0 ( 16 bit)					*/
	__IO uint16_t	RP2H;						/*!< 0x002 : RT Port register 2 ( 16 bit)					*/
	     uint8_t	RESERVED0x004[0x010 - 0x004];/*!< 0x004 - 0x00F : Reserved								*/

	__IO uint16_t	RPM0H;						/*!< 0x010 : RT Port mode register 0 ( 16 bit)				*/
	__IO uint16_t	RPM2H;						/*!< 0x012 : RT Port mode register 2 ( 16 bit)				*/
	     uint8_t	RESERVED0x014[0x020 - 0x014];/*!< 0x014 - 0x01F : Reserved								*/

	__IO uint16_t	RPMC0H;						/*!< 0x020 : RT Port mode control register 0 ( 16 bit)		*/
	__IO uint16_t	RPMC2H;						/*!< 0x022 : RT Port mode control register 2 ( 16 bit)		*/
	     uint8_t	RESERVED0x024[0x030 - 0x024];/*!< 0x024 - 0x02F : Reserved								*/

	__IO uint16_t	RPFC0H;						/*!< 0x030 : RT Port function control register 0 ( 16 bit)	*/
	__IO uint16_t	RPFC2H;						/*!< 0x032 : RT Port function control register 2 ( 16 bit)	*/
	     uint8_t	RESERVED0x034[0x040 - 0x034];/*!< 0x034 - 0x03F : Reserved								*/

	__IO uint16_t	RPFCE0H;					/*!< 0x040 : RT Port function control ext.register 0 ( 16 bit)*/
	__IO uint16_t	RPFCE2H;					/*!< 0x042 : RT Port function control ext.register 2 ( 16 bit)*/
	     uint8_t	RESERVED0x044[0x050 - 0x044];/*!< 0x044 - 0x04F : Reserved								 */

	__I  uint16_t	RPIN0H;						/*!< 0x050 : RT Port input level register 0 ( 16 bit)		*/
	__I  uint16_t	RPIN2H;						/*!< 0x052 : RT Port input level register 2 ( 16 bit)		*/
	     uint8_t	RESERVED0x054[0x060 - 0x054];/*!< 0x054 - 0x05F : Reserved								*/
} RIN_RTPORT_H_TypeDef;

typedef struct
{
	__IO uint32_t	RP0W;						/*!< 0x000 : RT Port register 0 ( 32 bit)					*/
	     uint8_t	RESERVED0x004[0x010 - 0x004];/*!< 0x004 - 0x00F : Reserved								*/

	__IO uint32_t	RPM0W;						/*!< 0x010 : RT Port mode register 0 ( 32 bit)				*/
	     uint8_t	RESERVED0x014[0x020 - 0x014];/*!< 0x014 - 0x01F : Reserved								*/

	__IO uint32_t	RPMC0W;						/*!< 0x020 : RT Port mode control register 0 ( 32 bit)		*/
	     uint8_t	RESERVED0x024[0x030 - 0x024];/*!< 0x024 - 0x02F : Reserved								*/

	__IO uint32_t	RPFC0W;						/*!< 0x030 : RT Port function control register 0 ( 32 bit)	*/
	     uint8_t	RESERVED0x034[0x040 - 0x034];/*!< 0x034 - 0x03F : Reserved								*/

	__IO uint32_t	RPFCE0W;					/*!< 0x040 : RT Port function control ext.register0 ( 32 bit)*/
	     uint8_t	RESERVED0x044[0x050 - 0x044];/*!< 0x044 - 0x04F : Reserved								 */

	__I  uint32_t	RPIN0W;						/*!< 0x050 : RT Port input level register 0 ( 32 bit)		*/
	     uint8_t	RESERVED0x054[0x060 - 0x054];/*!< 0x054 - 0x05F : Reserved								*/
} RIN_RTPORT_W_TypeDef;

typedef struct
{
	__IO uint8_t	EXTP0B;						/*!< 0x000 : Register 0 Byte								*/
	__IO uint8_t	EXTP1B;						/*!< 0x001 : Register 1 Byte								*/
         uint8_t	RESERVED0x002[0x010 - 0x002];/*!< 0x002 - 0x00F : Reserved								*/
	__IO uint8_t	EXTPM0B;					/*!< 0x010 : Mode Register 0 Byte							*/
	__IO uint8_t	EXTPM1B;					/*!< 0x011 : Mode Register 1 Byte							*/
	     uint8_t	RESERVED0x012[0x020 - 0x012];/*!< 0x012 - 0x01F : Reserved								*/
	__IO uint8_t	EXTPMC0B;					/*!< 0x020 : Mode Control Register 0 Byte					*/
	__IO uint8_t	EXTPMC1B;					/*!< 0x021 : Mode Control Register 1 Byte					*/
	     uint8_t	RESERVED0x022[0x030 - 0x022];/*!< 0x022 - 0x02F : Reserved								*/
	__IO uint8_t	EXTPFC0B;					/*!< 0x030 : Function Control Register 0 Byte				*/
	__IO uint8_t	EXTPFC1B;					/*!< 0x031 : Function Control Register 1 Byte				*/
	     uint8_t	RESERVED0x032[0x040 - 0x032];/*!< 0x032 - 0x03F : Reserved								*/
	__IO uint8_t	EXTPFCE0B;					/*!< 0x040 : Function Control Extend Register 0 Byte		*/
	__IO uint8_t	EXTPFCE1B;					/*!< 0x041 : Function Control Extend Register 1 Byte		*/
	     uint8_t	RESERVED0x042[0x050 - 0x042];/*!< 0x042 - 0x04F : Reserved								*/
	__IO uint8_t	EXTPIN0B;					/*!< 0x050 : Pin Register 0 Byte							*/
	__IO uint8_t	EXTPIN1B;					/*!< 0x051 : Pin Register 1 Byte							*/
} RIN_EXTPORT_TypeDef;
typedef struct
{
	__IO uint16_t	EXTP0H;						/*!< 0x000 : Register 0 HalfWord							*/
	     uint16_t	RESERVED0x002[7];			/*!< 0x002 - 0x00F : Reserved								*/
	__IO uint16_t	EXTPM0H;					/*!< 0x010 : Mode Register 0 HalfWord						*/
	     uint16_t	RESERVED0x012[7];			/*!< 0x012 - 0x01F : Reserved								*/
	__IO uint16_t	EXTPMC0H;					/*!< 0x020 : Mode Control Register 0 HalfWord				*/
	     uint16_t	RESERVED0x022[7];			/*!< 0x022 - 0x02F : Reserved								*/
	__IO uint16_t	EXTPFC0H;					/*!< 0x030 : Function Control Register 0 HalfWord			*/
	     uint16_t	RESERVED0x032[7];			/*!< 0x032 - 0x03F : Reserved								*/
	__IO uint16_t	EXTPFCE0H;					/*!< 0x040 : Function Control Extend Register 0 HalfWord	*/
	     uint16_t	RESERVED0x042[7];			/*!< 0x042 - 0x04F : Reserved								*/
	__IO uint16_t	EXTPIN0H;					/*!< 0x050 : Pin Register 0 HalfWord						*/
} RIN_EXTPORT_H_TypeDef;
typedef struct
{
	__IO uint32_t	EXTP0W;						/*!< 0x000 : Register 0 Word								*/
	     uint32_t	RESERVED0x004[3];			/*!< 0x004 - 0x00F : Reserved								*/
	__IO uint32_t	EXTPM0W;					/*!< 0x010 : Mode Register 0 Word							*/
	     uint32_t	RESERVED0x014[3];			/*!< 0x014 - 0x01F : Reserved								*/
	__IO uint32_t	EXTPMC0W;					/*!< 0x020 : Mode Control Register 0 Word					*/
	     uint32_t	RESERVED0x024[3];			/*!< 0x024 - 0x02F : Reserved								*/
	__IO uint32_t	EXTPFC0W;					/*!< 0x030 : Function Control Register 0 Word				*/
	     uint32_t	RESERVED0x034[3];			/*!< 0x034 - 0x03F : Reserved								*/
	__IO uint32_t	EXTPFCE0W;					/*!< 0x040 : Function Control Extend Register 0 Word		*/
	     uint32_t	RESERVED0x044[3];			/*!< 0x044 - 0x04F : Reserved								*/
	__IO uint32_t	EXTPIN0W;					/*!< 0x050 : Pin Register 0 Word							*/
} RIN_EXTPORT_W_TypeDef;

#define RIN_GPIO				((RIN_GPIO_TypeDef   *)		RIN_GPIO_BASE   )
#define RIN_GPIO_H				((RIN_GPIO_H_TypeDef   *)	RIN_GPIO_BASE   )
#define RIN_GPIO_W				((RIN_GPIO_W_TypeDef   *)	RIN_GPIO_BASE   )

#define RIN_RTPORT				((RIN_RTPORT_TypeDef *)		RIN_RTPORT_BASE )
#define RIN_RTPORT_H			((RIN_RTPORT_H_TypeDef *)	RIN_RTPORT_BASE )
#define RIN_RTPORT_W			((RIN_RTPORT_W_TypeDef *)	RIN_RTPORT_BASE )

#define RIN_EXTPORT				((RIN_EXTPORT_TypeDef *)	RIN_EXTPORT_BASE)
#define RIN_EXTPORT_H			((RIN_EXTPORT_H_TypeDef *)	RIN_EXTPORT_BASE)
#define RIN_EXTPORT_W			((RIN_EXTPORT_W_TypeDef *)	RIN_EXTPORT_BASE)

//-----------------------------------------------------------------------------
// CC-Link IE bridge register
//-----------------------------------------------------------------------------
typedef struct
{
	     uint32_t	RESERVED0x000;				/*!< 0x000 : Reserved									*/
	__IO uint32_t	CIEBSC;						/*!< 0x004 : Bus Size Control register					*/
	__IO uint32_t	CIESMC;						/*!< 0x008 : Static Memory Control register 0			*/
} RIN_CCI_BRG_TypeDef;

#define RIN_CCI_BRG				((RIN_CCI_BRG_TypeDef *)	RIN_CCI_BRG_BASE)


//-----------------------------------------------------------------------------
// Burst memory controler register
//-----------------------------------------------------------------------------
typedef struct
{
	     uint8_t	RESERVED0x000[0x010-0x000];	/*!< 0x000 - 0x00F : Reserved							*/
	__O  uint32_t	DIRECT_CMD;					/*!< 0x010 : Direct Command Register					*/
	__O  uint32_t	SET_CYCLES;					/*!< 0x014 : Set Cycles Register						*/
	__O  uint32_t	SET_OPMODE;					/*!< 0x018 : Set Operating Mode Register				*/
	     uint8_t	RESERVED0x01C[0x020-0x01C];	/*!< 0x01C - 0x01F : Reserved							*/
	__IO uint32_t	REF_PERIOD0;				/*!< 0x020 : Refresh Period 0 Register					*/
	     uint8_t	RESERVED0x024[0x100-0x024];	/*!< 0x024 - 0x0FF : Reserved							*/
	__I  uint32_t	SRAM_CYCLES0_0;				/*!< 0x100 : CS0 cycle setting register					*/
	__I  uint32_t	OPMODE0_0;					/*!< 0x104 : CS0 mode register							*/
	     uint8_t	RESERVED0x108[0x120-0x108];	/*!< 0x108 - 0x11F : Reserved							*/
	__I  uint32_t	SRAM_CYCLES0_1;				/*!< 0x120 : CS1 cycle setting register					*/
	__I  uint32_t	OPMODE0_1;					/*!< 0x124 : CS1 mode register							*/
	     uint8_t	RESERVED0x128[0x140-0x128];	/*!< 0x128 - 0x13F : Reserved							*/
	__I  uint32_t	SRAM_CYCLES0_2;				/*!< 0x140 : CS2 cycle setting register					*/
	__I  uint32_t	OPMODE0_2;					/*!< 0x144 : CS2 mode register							*/
	     uint8_t	RESERVED0x148[0x160-0x148];	/*!< 0x148 - 0x15F : Reserved							*/
	__I  uint32_t	SRAM_CYCLES0_3;				/*!< 0x160 : CS3 cycle setting register					*/
	__I  uint32_t	OPMODE0_3;					/*!< 0x164 : CS3 mode register							*/
	     uint8_t	RESERVED0x168[0x180-0x168];	/*!< 0x168 - 0x17F : Reserved							*/
} RIN_SMC_TypeDef;

#define RIN_SMC					((RIN_SMC_TypeDef *)		RIN_SMC_BASE)

//-----------------------------------------------------------------------------
// System Control Regiter
//-----------------------------------------------------------------------------
typedef struct
{
	     uint8_t	RESERVED0x000[0x00C-0x000];	/*!< 0x000 - 0x00B : Reserved							*/
	__IO uint32_t	mc_micon_set_reg;			/*!< 0x00C : Memory map switching register				*/
} RIN_UDLSYS_TypeDef;

#define RIN_UDLSYS				((RIN_UDLSYS_TypeDef *)	RIN_UDLSYS_BASE)


/*============================================================================*/
/* Bit-Band                                                                   */
/*============================================================================*/
#define BITBAND_OFFSET (0x02000000UL)
#define BITBAND_PERI_BASE (PERI_BASE + BITBAND_OFFSET)
#define BITBAND_PERI(addr, bitnum) (BITBAND_PERI_BASE + ((unsigned long)((addr) - PERI_BASE) << 5) + ((bitnum) << 2))

#define BITBAND_SRAM_BASE (SRAM_BASE + BITBAND_OFFSET)
#define BITBAND_SRAM(addr, bitnum) (BITBAND_SRAM_BASE + ((unsigned long)((addr) - SRAM_BASE) << 5) + ((bitnum) << 2))



#ifdef __cplusplus
}
#endif 

#endif	/* __RIN32M4_CL3_H */
