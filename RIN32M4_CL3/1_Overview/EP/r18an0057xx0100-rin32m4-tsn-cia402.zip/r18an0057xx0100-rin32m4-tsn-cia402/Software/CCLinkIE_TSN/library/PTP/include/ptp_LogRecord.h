/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_LOGRECORD_H__
#define __PTP_LOGRECORD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	ptp_LogRecordInit(CLOCKDATA* pstClockData);
VOID	ptp_LogRecordReq(CLOCKDATA* pstClockData, USHORT	usLogID, USHORT	usLogNameID, ULONG	ulLogVal);
PTP_LOGRECORD*	ptp_GetLogRecord(CLOCKDATA*	pstClockData, USHORT*	pusLogRecordNum);
INT	ptp_LRSetLogOperate(USHORT	usLogID, LOGOPERATE	enOperate);
INT	ptp_LRSetLogCallBack(USHORT	usLogID, LOGCB	pfnLogCBFunc);
VOID	ptp_EmergLogCallBack (PTP_LOGRECORD* pstLogRecord);


#ifdef __cplusplus
}
#endif


#endif


