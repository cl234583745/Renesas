//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "msw_lldp.h"
#include "lldpd.h"

void lldpdTxSmInit(LLDPD_AGENT_T *agent)
{
    agent->txState.state = TX_LLDP_INITIALIZE;
    return;
}

static void txInitializeLLDP(LLDPD_AGENT_T *agent)
{

    usswLldpdLock();
    agent->txState.state = TX_LLDP_INITIALIZE;

    memset(agent->txState.outFrame, 0x00, sizeof(agent->txState.outFrame));
    agent->txState.frameLen = 0;

    agent->lldpdConfig.reinitDelay     = lldpdMib.reinitDelay;
    agent->lldpdConfig.msgTxHold       = lldpdMib.msgTxHoldMult;
    agent->lldpdConfig.msgTxInterval   = lldpdMib.msgTxInterval;
    agent->lldpdConfig.msgFastTx       = lldpdMib.msgFastTx;

    agent->lldpdStat.statInfo.stsFrmOut = 0;

    agent->txState.localChange = FALSE;
    agent->txState.txTTL = 0;
    usswLldpdUnLock();

    return;
}

static void lldpdTxSmIdleProc(LLDPD_AGENT_T *agent)
{
}

void somethingChangedLocal(LLDPD_AGENT_T *agent)
{
    if (agent == NULL) {
        return;
    }

    usswLldpdLock();
    agent->txState.localChange = TRUE;
    agent->txState.txFast = agent->lldpdConfig.txFastInit;
    usswLldpdUnLock();

    return;
}

static void lldpdTxSmInfoFrameProc(LLDPD_AGENT_T *agent)
{
    LLDPD_PORT_T *port = agent->port;

    mswLldpSend(lldpdhwport[port->portno].ifname, 
        (agent->mcBitmap & TX_NEAREST_ALL), agent->txState.outFrame, 
        LLDPD_FRAME_LENGTH, &agent->lldpdStat.statInfo);

    if (agent->txState.txCredit > 0) {
        agent->txState.txCredit--;
    }
    agent->txState.txNow = FALSE;
    return;
}

static void lldpdTxSmShutdownFrameProc(LLDPD_AGENT_T *agent)
{
    LLDPD_PORT_T *port = agent->port;

    usswLldpdLock();
    if (agent->txState.txShutdownSend == TRUE) {
        mswLldpShutdownSend(lldpdhwport[port->portno].ifname, 
            (agent->mcBitmap & TX_NEAREST_ALL), agent->txState.outFrame, 
            LLDPD_FRAME_LENGTH,&agent->lldpdStat.statInfo);
        agent->txState.txShutdownWhile = agent->lldpdConfig.reinitDelay;
        agent->txState.txShutdownSend = FALSE;
    }
    usswLldpdUnLock();
    return;
}

static void lldpdTxSmStatChange(LLDPD_AGENT_T *agent, int newstate)
{
    switch (newstate) {
    case TX_LLDP_INITIALIZE:
    case TX_IDLE:
    case TX_INFO_FRAME:
    case TX_SHUTDOWN_FRAME:
        break;
    default:
        LLDPD_LOG_DBG(("lldpdTxSmStatChange: unknown state(%d)\n", newstate));
    }

    LLDPD_LOG_INF(("lldpdTxSmStatChange: state %d -> %d\n", 
        agent->txState.state, newstate));
    agent->txState.state = newstate;
    return;
}

static int lldpdTxSmStatUpdate(LLDPD_AGENT_T *agent)
{
    int ret = FALSE;
    unsigned char adminStatus = DISABLED;
    LLDPD_PORT_T *port = agent->port;

    if ((port->portEnabled == FALSE) && (port->prePortEnabled == TRUE)) {
        lldpdTxSmStatChange(agent, TX_LLDP_INITIALIZE);
    }
    port->prePortEnabled = port->portEnabled;

    switch (agent->txState.state) {
    case TX_LLDP_INITIALIZE:
        lldpdAdminStatusGet(lldpdhwport[port->portno].ifname, 
          agent->mcBitmap, &adminStatus);
        if ((port->portEnabled != FALSE) && 
            ((adminStatus == TX_AND_RX) || (adminStatus == TX_ONLY))) {
            lldpdTxSmStatChange(agent, TX_IDLE);
            ret = TRUE;
        }
        break;
    case TX_IDLE:
        lldpdAdminStatusGet(lldpdhwport[port->portno].ifname, 
          agent->mcBitmap, &adminStatus);
        if ((adminStatus == DISABLED) || (adminStatus == RX_ONLY)) {
            agent->txState.txShutdownSend = TRUE;
            lldpdTxSmStatChange(agent, TX_SHUTDOWN_FRAME);
            ret = TRUE;
            break;
        }
        if ((agent->txState.txNow) && ((agent->txState.txCredit > 0))) {
            lldpdTxSmStatChange(agent, TX_INFO_FRAME);
            ret = TRUE;
        }
        break;
    case TX_INFO_FRAME:
        lldpdTxSmStatChange(agent, TX_IDLE);
        ret = TRUE;
        break;
    case TX_SHUTDOWN_FRAME:
        if (agent->txState.txShutdownWhile == 0 && 
            agent->txState.txShutdownSend == FALSE) {
            lldpdTxSmStatChange(agent, TX_LLDP_INITIALIZE);
            ret = TRUE;
        }
        break;
    default:
        LLDPD_LOG_DBG(("lldpdTxSmStatUpdate: ERROR unknown state(%d)\n", 
            agent->txState.state));
        break;
    }
    return ret;
}

void lldpdTxSmRun(LLDPD_AGENT_T *agent)
{
    lldpdTxSmStatUpdate(agent);
    do {
        switch (agent->txState.state) {
        case TX_LLDP_INITIALIZE:
            txInitializeLLDP(agent);
            agent->txState.txShutdownWhile = 0;
            break;
        case TX_IDLE:
            lldpdTxSmIdleProc(agent);
            break;
        case TX_INFO_FRAME:
            lldpdTxSmInfoFrameProc(agent);
            break;
        case TX_SHUTDOWN_FRAME:
            lldpdTxSmShutdownFrameProc(agent);
            break;
        default:
            LLDPD_LOG_DBG(("lldpdTxSmRun: ERROR unknown state(%d)\n", 
                agent->txState.state));
        }
    } while (lldpdTxSmStatUpdate(agent) == TRUE);
    return;
}
