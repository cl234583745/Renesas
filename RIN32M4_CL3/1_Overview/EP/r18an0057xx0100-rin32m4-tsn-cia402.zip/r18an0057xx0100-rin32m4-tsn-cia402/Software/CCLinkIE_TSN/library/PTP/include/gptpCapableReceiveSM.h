/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifndef __GPTPCAPABLERECEIVESM_H__
#define __GPTPCAPABLERECEIVESM_H__
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"

#ifdef __cplusplus
extern "C" {
#endif

extern VOID gptpCapableReceiveSM( USHORT usEvent, PORTDATA* pstPort );


#ifdef __cplusplus
}
#endif

#endif
