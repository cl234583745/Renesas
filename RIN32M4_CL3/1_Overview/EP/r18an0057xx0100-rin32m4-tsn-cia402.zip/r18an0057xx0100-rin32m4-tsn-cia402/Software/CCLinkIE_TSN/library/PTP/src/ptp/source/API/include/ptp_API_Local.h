/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_API_LOCAL_H__
#define __PTP_API_LOCAL_H__

#include "ptp_api.h"
#include "ptp_System.h"
#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "PTP_GlobalData.h"


#ifdef __cplusplus
extern "C" {
#endif

BOOL ptp_sm_port_des(USHORT usEvent, PORTDATA* pstPortData);
VOID ptp_portenable_des(PORTDATA* pstPortData);
VOID ptp_portdisable_des(PORTDATA* pstPortData);
INT initParrentDS (DEFAULT_DS* pstDefaultDS, PARENT_DS* pstParentDS);
#if 1
BOOL ptp_portStatus_des(PORTDATA* pstPortData);
#endif
#ifdef __cplusplus
}
#endif

#endif
