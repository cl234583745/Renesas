/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYREQSENDSM_1588_H__
#define __MDDELAYREQSENDSM_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDDelayReqSendSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDDelayReqSendSM_00_1588(PORTDATA* pstPort);
VOID MDDelayReqSendSM_01_1588(PORTDATA* pstPort);
VOID MDDelayReqSendSM_02_1588(PORTDATA* pstPort);
VOID MDDelayReqSendSM_03_1588(PORTDATA* pstPort);
VOID MDDelayReqSendSM_NP_1588(PORTDATA* pstPort);

BOOL MDDReqSnd_NotEnable_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDDReqSnd_WtSndDReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDDReqSnd_SntDRqWtFrTmStmp_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL MDDReqSnd_SntDRqWtFrTS_1588_TC(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif

BOOL SetDelayReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#ifdef	PTP_USE_TRANS
BOOL SetDelayReqTC_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);
#endif
BOOL TxDelayReq_1588(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
