/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCRECEIVESM_H__
#define __MDSYNCRECEIVESM_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_LCEntity.h"
#include "ptp_LogRecord.h"


#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDSyncReceiveSM(USHORT usEvent, PORTDATA* pstPort);

MDSRECEIVESM_GD*	GetMDSyncRcvSMGlobal(PORTDATA* pstPort);
MDSYNCRCVSM_EV		GetMDSyncRcvEvent(USHORT usEvent, PORTDATA* pstPort);
MDSYNCRCVSM_ST		GetMDSyncRcvStatus(PORTDATA* pstPort);
VOID				SetMDSyncRcvStatus(MDSYNCRCVSM_ST enSts, PORTDATA* pstPort);

VOID	IncMDSyncRcvRxSyncCount(PORTDATA* pstPort);
VOID	IncMDSyncRcvRxFollowUpCount(PORTDATA* pstPort);
VOID	IncMDSyncRcvRxOneStpSyncCount(PORTDATA* pstPort);

BOOL	MDSynRcvTimeStart(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL	MDSynRcvTimeStop(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID	MDSyncTimeClear(PORTDATA* pstPort);
BOOL	SetMDSyncEvIngresTimestampSM(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID	SetMDSyncEvIngresTimestamp(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL	cmptMDSyncFollowUpReceiptTime(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort, CHAR chIntVal);

#ifdef __cplusplus
}
#endif

#endif
