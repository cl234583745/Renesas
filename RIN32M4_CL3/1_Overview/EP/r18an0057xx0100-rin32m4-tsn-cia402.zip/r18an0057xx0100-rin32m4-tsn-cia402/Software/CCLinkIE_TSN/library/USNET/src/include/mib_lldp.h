//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _MIB_LLDP_H
#define _MIB_LLDP_H

#include "config.h"
#include "snmpv3.h"
#include "msw_lldp.h"
#include "lldpd.h"

#define SNMP_TRUE  (1)
#define SNMP_FALSE (2)

#define SNMP_PORTCFG_TXEN_PORTDESC (1 << 3)
#define SNMP_PORTCFG_TXEN_SYSNAME  (1 << 2)
#define SNMP_PORTCFG_TXEN_SYSDESC  (1 << 1)
#define SNMP_PORTCFG_TXEN_SYSCAP   (1 << 0)
#define SNMP_PORTCFG_TXEN_ENC(x)   (x >> 4)
#define SNMP_PORTCFG_TXEN_DEC(x)   (x << 4)

#endif

