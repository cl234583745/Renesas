//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include <string.h>
#include "msw_lldp.h"
#include "msw_lldp_mand.h"
#include "msw_lldp_basman.h"

static char mswLldpVersion[] = "LLDP API Ver1.10";
#ifdef MSW_DEBUG
MSW_LLDP_MOD_INFO_T mswLldpModules[MSW_LLDP_MODULE_NUM];
MSW_LLDP_LOCAL_INFO_T mswLldpLocalInfo[MSW_LLDP_LINFO_NUM];
int mswLldpInitFlag = 0;
#else
static MSW_LLDP_MOD_INFO_T mswLldpModules[MSW_LLDP_MODULE_NUM];
static MSW_LLDP_LOCAL_INFO_T mswLldpLocalInfo[MSW_LLDP_LINFO_NUM];
static int mswLldpInitFlag = 0;
#endif

#ifdef MSW_LOG
long msw_lldp_log = (LLDP_LOG_FLG_ERR | LLDPD_LOG_FLG_ERR | LLDPMIB_LOG_FLG_ERR);
#endif

void (*mswLockFunc)(void) = NULL;
void (*mswUnLockFunc)(void) = NULL;
#define mswLock()   { if (mswLockFunc != NULL)   mswLockFunc(); }
#define mswUnLock() { if (mswUnLockFunc != NULL) mswUnLockFunc(); }


#ifdef MSW_USE_ALAXALA
const unsigned char nearest_bridge[ETH_ADR_SZ] = {0x01,0x00,0x87,0x58,0x13,0x10};
const unsigned char nearest_nontpmr_bridge[ETH_ADR_SZ] = {0x00,0x00,0x00,0x00,0x00,0x00};
const unsigned char nearest_customer_bridge[ETH_ADR_SZ] = {0x00,0x00,0x00,0x00,0x00,0x00};
#else
const unsigned char nearest_bridge[ETH_ADR_SZ] = {0x01,0x80,0xc2,0x00,0x00,0x0e};
const unsigned char nearest_nontpmr_bridge[ETH_ADR_SZ] = {0x01,0x80,0xc2,0x00,0x00,0x03};
const unsigned char nearest_customer_bridge[ETH_ADR_SZ] = {0x01,0x80,0xc2,0x00,0x00,0x00};
#endif

void (*msw_register_tbl[])(void) = {
        msw_mand_register,
        msw_basman_register,
        NULL,
};


static const unsigned char *mswGetMulticastAddr(unsigned char type)
{
    const unsigned char *ret = NULL;

    switch (type) {
    case NEAREST_BRIDGE:
        ret = nearest_bridge;
        break;
    case NEAREST_NONTPMR_BRIDGE:
        ret = nearest_nontpmr_bridge;
        break;
    case NEAREST_CUSTOMER_BRIDGE:
        ret = nearest_customer_bridge;
        break;
    }

    return ret;
}

int mswLldpInit(void)
{
    int ix;
    int count;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpInit: \n"));
#endif

    if (mswLldpInitFlag != 0) {
        return ret;
    }

    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        memset(&mswLldpLocalInfo[ix], 0x00, sizeof(MSW_LLDP_LOCAL_INFO_T));
    }

    mswLldpInitFlag = 1;

    count = sizeof(msw_register_tbl) / 
            sizeof(msw_register_tbl[0]);
    for (ix = 0; ix < count; ix++) {
        if (msw_register_tbl[ix] != NULL) {
            msw_register_tbl[ix]();
        }
    }

    return ret;
}

int mswLldpTerm(void)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpTerm: \n"));
#endif

    if (mswLldpInitFlag == 0) {
        return ret;
    }

    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        memset(&mswLldpLocalInfo[ix], 0x00, sizeof(MSW_LLDP_LOCAL_INFO_T));
    }

    for (ix = 0; ix < MSW_LLDP_MODULE_NUM; ix++) {
        if ((mswLldpModules[ix].status == MSW_ENABLE) && 
            (mswLldpModules[ix].ops != NULL) && 
            (mswLldpModules[ix].ops->lldp_unregister != NULL)) {
                mswLldpModules[ix].ops->lldp_unregister();
        }
    }
    mswLldpInitFlag = 0;
    return ret;
}

int mswLldpPortAdd(MSW_LLDP_LOCAL_INFO_T *localInfo)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpPortAdd:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (localInfo == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpPortAdd: ifname=%s\n", localInfo->ifname));
#endif
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (mswLldpLocalInfo[ix].ifname[0] == 0) {
            break;
        }
        if (!strcmp(mswLldpLocalInfo[ix].ifname, localInfo->ifname)) {
            if ((localInfo->mcBitmap & ACCEPT_DEF_MCBITMAP) &&
                (mswLldpLocalInfo[ix].mcBitmap != localInfo->mcBitmap)) {
                continue;
            }
            ret = MSW_EC_EXIST;
            break;
        }
    }
    if (ix == MSW_LLDP_LINFO_NUM) {
        ret = MSW_EC_FULL;
    }

    if (ret == MSW_EC_NO_ERROR) {
        mswLldpLocalInfo[ix] = *localInfo;
    }

    return ret;
}

int mswLldpPortDel(char *ifname, unsigned char mcBitmap)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpPortDel:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (ifname == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpPortDel: ifname=%s\n", ifname));
#endif
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (!strcmp(mswLldpLocalInfo[ix].ifname, ifname)) {
            if ((mcBitmap & ACCEPT_DEF_MCBITMAP) &&
                (mswLldpLocalInfo[ix].mcBitmap != mcBitmap)) {
                continue;
            }
            break;
        }
    }
    if (ix == MSW_LLDP_LINFO_NUM) {
        ret = MSW_EC_NOT_FOUND;
    }

    if (ret == MSW_EC_NO_ERROR) {
        memset(&mswLldpLocalInfo[ix], 0x00, sizeof(MSW_LLDP_LOCAL_INFO_T));
    }

    return ret;
}

int mswLldpModuleAdd(MSW_LLDP_MOD_INFO_T *module)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpModulAdd:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (module == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpModulAdd: id=%d\n", module->id));
#endif
    for (ix = 0; ix < MSW_LLDP_MODULE_NUM; ix++) {
        if (mswLldpModules[ix].status == MSW_ENABLE && 
            mswLldpModules[ix].id == module->id) {
            ret = MSW_EC_EXIST;
            break;
        }
        if (mswLldpModules[ix].status == MSW_DISABLE) {
            break;
        }
    }
    if (ix == MSW_LLDP_MODULE_NUM) {
        ret =MSW_EC_FULL;
    }

    if (ret == MSW_EC_NO_ERROR) {
        mswLldpModules[ix] = *module;
        mswLldpModules[ix].status = MSW_ENABLE;
    }

    return ret;
}

int mswLldpModuleDel(int id)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpModuleDel: id=%d\n", id));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    for (ix = 0; ix < MSW_LLDP_MODULE_NUM; ix++) {
        if (mswLldpModules[ix].status == MSW_ENABLE && 
            mswLldpModules[ix].id == id) {
            break;
        }
    }
    if (ix == MSW_LLDP_MODULE_NUM) {
        ret = MSW_EC_NOT_FOUND;
    }

    if (ret == 0) {
        memset(&mswLldpModules[ix], 0x00, sizeof(MSW_LLDP_MOD_INFO_T));
    }

    return ret;
}

int mswLldpLocalDataGet(MSW_LLDP_LOCAL_INFO_T *localInfo)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpLocalDataGet:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (localInfo == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpLocalDataGet: ifname=%s\n", localInfo->ifname));
#endif
    mswLock();
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (!strcmp(mswLldpLocalInfo[ix].ifname, localInfo->ifname)) {
            if ((localInfo->mcBitmap & ACCEPT_DEF_MCBITMAP) &&
                (mswLldpLocalInfo[ix].mcBitmap != localInfo->mcBitmap)) {
                continue;
            }
            *localInfo = mswLldpLocalInfo[ix];
            break;
        }
    }
    mswUnLock();


    if (ix == MSW_LLDP_LINFO_NUM) {
        ret = MSW_EC_NOT_FOUND;
    }

    return ret;
}

int mswLldpLocalDataPtrGet(char *ifname, unsigned char mcBitmap, 
    MSW_LLDP_LOCAL_INFO_T **info)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpLocalDataPtrGet:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (ifname == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpLocalDataPtrGet: ifname=%s mcBitmap=0x%02x\n", 
        ifname, mcBitmap));
#endif
    mswLock();
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (!strcmp(mswLldpLocalInfo[ix].ifname, ifname)) {
            if ((mcBitmap & ACCEPT_DEF_MCBITMAP) &&
                (mswLldpLocalInfo[ix].mcBitmap != mcBitmap)) {
                continue;
            }
            *info = &mswLldpLocalInfo[ix];
            break;
        }
    }
    mswUnLock();


    if (ix == MSW_LLDP_LINFO_NUM) {
        ret = MSW_EC_NOT_FOUND;
    }

    return ret;
}

int mswLldpLocalDataSet(MSW_LLDP_LOCAL_INFO_T *localInfo)
{
    int ix;
    int ret = MSW_EC_NO_ERROR;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpLocalDataSet:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (localInfo == NULL) {
        return MSW_EC_EPARAM;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpLocalDataSet: ifname=%s\n", localInfo->ifname));
#endif
    mswLock();
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (!strcmp(mswLldpLocalInfo[ix].ifname, localInfo->ifname)) {
            if ((localInfo->mcBitmap & ACCEPT_DEF_MCBITMAP) &&
                (mswLldpLocalInfo[ix].mcBitmap != localInfo->mcBitmap)) {
                continue;
            }
            mswLldpLocalInfo[ix] = *localInfo;
            break;
        }
    }
    mswUnLock();

    if (ix == MSW_LLDP_LINFO_NUM) {
        ret = MSW_EC_NOT_FOUND;
    }

    return ret;
}

int mswLldpduAnalysis(unsigned char *inlldpdu, unsigned short len,
                       MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData)
{
    unsigned char  *ptr = NULL;
    unsigned short length;
    unsigned short offset = 0;
    unsigned char  type;
    unsigned short count = 0;
    unsigned char  frmerr = 0;
    unsigned char  stored = 0;
    unsigned int   idx;
    unsigned char  flag;
    unsigned int   tmp;
    unsigned int   tmplen;
    unsigned char  f_pdes = 0;
    unsigned char  f_sname = 0;
    unsigned char  f_sdes = 0;
    unsigned char  f_scap = 0;
    unsigned short tmpus = 0;
    unsigned long  tmpul = 0;
    int            err = 0;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpduAnalysis: \n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }
    if (!inlldpdu) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduAnalysis: inlldpdu is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!info) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduAnalysis: info is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!tlv) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduAnalysis: tlv is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    memset(tlv, 0x00, sizeof(MSW_TLVS_T));

    if (len > LLDPDU_MAX_SZ) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduAnalysis: Frame size greater than or equal to LLDPDU_MAX_SZ.\n"));
#endif
        frmerr = 1;
        goto out;
    }

    do {
        count++;
        if (offset >= len) {
            if (count > TYPE_TIMETOLIVE) {
                goto out;
            } else {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: create size greater than or equal to remain size.\n"));
#endif
                frmerr = 1;
                goto out;
            }
        }
        
        ptr = &inlldpdu[offset];
        memcpy(&tmpus, ptr, sizeof(unsigned short));
        type = LLDPH2TYPE(ntohs(tmpus));
        length = LLDPH2LEN(ntohs(tmpus));
        if (count <= TYPE_TIMETOLIVE) {
            if (count != type) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: TLV missing or TLVs out of order.\n"));
#endif
                frmerr = 1;
                goto out;
            }
        }
        
        if (count > TYPE_TIMETOLIVE) {
            if ((type == TYPE_CHASSISID) || (type == TYPE_PORTID) || 
                (type == TYPE_TIMETOLIVE)) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: Extra Type 1 Type 2, or Type 3 TLV.\n"));
#endif
                frmerr = 1;
                goto out;
            }
        }
        
        if ((type == TYPE_TIMETOLIVE) && (length != 2)) {
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduAnalysis: TTL TLV validation error.\n"));
#endif
            frmerr = 1;
            goto out;
        }

        if ((offset + length) > len) {
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduAnalysis: Reference size greater than or equal to remain size.\n"));
#endif
            frmerr = 1;
            goto out;
        }
        
        if ((length == 0) && ((type == TYPE_CHASSISID)
                               || (type == TYPE_PORTID)
                               || (type == TYPE_TIMETOLIVE)
                               || (type == TYPE_SYSCAP)
                               || (type == TYPE_MNGADDR))) {
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduAnalysis: tlv length error.\n"));
#endif
            frmerr = 1;
            goto out;
        }
        switch(type) {
        case TYPE_EOL:
            stored = 1;
            break;
        case TYPE_CHASSISID:
            if (((Min_SZCHASSIS_INFO + sizeof(tlv->chassis.subtype)) > length) ||
                (length > (Max_SZCHASSIS_INFO + sizeof(tlv->chassis.subtype)))) {
                break;
            }
            if ((MSW_CHASSIS_SUB_MIN > *(ptr+sizeof(unsigned short))) ||
                (*(ptr+sizeof(unsigned short)) > MSW_CHASSIS_SUB_MAX)) {
                break;
            }
            tlv->chassis.curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->chassis.subtype), ptr, sizeof(tlv->chassis.subtype));
            ptr += sizeof(tlv->chassis.subtype);
            memcpy(&(tlv->chassis.id), ptr, length - sizeof(tlv->chassis.subtype));

            stored = 1;
            break;
        case TYPE_PORTID:
            if (((Min_SZPORTID_INFO + sizeof(tlv->portid.subtype)) > length) ||
                (length > (Max_SZPORTID_INFO + sizeof(tlv->portid.subtype)))) {
                break;
            }
            if ((MSW_PORTID_SUB_MIN > *(ptr+sizeof(unsigned short))) ||
                (*(ptr+sizeof(unsigned short)) > MSW_PORTID_SUB_MAX)) {
                break;
            }
            tlv->portid.curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->portid.subtype), ptr, sizeof(tlv->portid.subtype));
            ptr += sizeof(tlv->portid.subtype);
            memcpy(&(tlv->portid.id), ptr, length - sizeof(tlv->portid.subtype));
            stored = 1;
            break;
        case TYPE_TIMETOLIVE:
            ptr += sizeof(unsigned short);
            memcpy(&tmpus, ptr, sizeof(unsigned short));
            tlv->ttl.ttl = ntohs(tmpus);
            stored = 1;
            break;
        case TYPE_PORTDES:
            if (f_pdes == 1) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: Extra Type 4 TLV.\n"));
#endif
                frmerr = 1;
                goto out;
            }
            if ((Min_SZPORTDES_INFO > length) || (length > Max_SZPORTDES_INFO)) {
                break;
            }
            tlv->portdes.curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->portdes.pdes), ptr, length);
            tlv->portdes.status = 1;
            f_pdes = 1;
            stored = 1;
            break;
        case TYPE_SYSNAME:
            if (f_sname == 1) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: Extra Type 5 TLV.\n"));
#endif
                frmerr = 1;
                goto out;
            }
            if ((Min_SZSYSNAME_INFO > length) || (length > Max_SZSYSNAME_INFO)) {
                break;
            }
            tlv->sysname.curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->sysname.name), ptr, length);
            tlv->sysname.status = 1;
            f_sname = 1;
            stored = 1;
            break;
        case TYPE_SYSDES:
            if (f_sdes == 1) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: Extra Type 6 TLV.\n"));
#endif
                frmerr = 1;
                goto out;
            }
            if ((Min_SZSYSDES_INFO > length) || (length > Max_SZSYSDES_INFO)) {
                break;
            }
            tlv->sysdes.curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->sysdes.sdes), ptr, length);
            tlv->sysdes.status = 1;
            f_sdes = 1;
            stored = 1;
            break;
        case TYPE_SYSCAP:
            if (f_scap == 1) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: Extra Type 7 TLV.\n"));
#endif
                frmerr = 1;
                goto out;
            }
            if (length != 4) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: System Capabilities TLV validation error.\n"));
#endif
                break;
            }
            ptr += sizeof(unsigned short);
            memcpy(&tmpus, ptr, sizeof(unsigned short));
            tlv->syscap.scap = ntohs(tmpus);
            ptr += sizeof(tlv->syscap.scap);
            memcpy(&tmpus, ptr, sizeof(unsigned short));
            tlv->syscap.enbl = ntohs(tmpus);
            tlv->syscap.status = 1;
            f_scap = 1;
            stored = 1;
            break;
        case TYPE_MNGADDR:
            if ((Min_SZMNG_INFO > length) || (length > Max_SZMNG_INFO)) {
                break;
            }
            flag = 0;
            for (idx = 0; idx < MSW_LLDP_MNGTLV_NUM; idx++) {
                if (tlv->mngaddr[idx].status == 0) {
                    flag = 1;
                    break;
                }
            }
            if (!flag) {
                break;
            }

            tmp = sizeof(tlv->mngaddr[idx].addr.type);
            if (((Min_SZMNG_ADDR+tmp) > *(ptr+sizeof(unsigned short))) ||
                (*(ptr+sizeof(unsigned short)) > (Max_SZMNG_ADDR+tmp))) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: address length format error.\n"));
#endif
                break;
            }
            tmplen = *(ptr+sizeof(unsigned short));
            tmp = sizeof(unsigned short) + sizeof(tlv->mngaddr[idx].strlen) + tmplen;
            if ((IF_NUM_SUBTYPE_UNKNOWN > *(ptr+tmp)) || 
                (*(ptr+tmp) > IF_NUM_SUBTYPE_PORTNUM)) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: interface numbering subtype format error.\n"));
#endif
                break;
            }
            tmp = sizeof(unsigned short) + sizeof(tlv->mngaddr[idx].strlen) + tmplen
                  + sizeof(tlv->mngaddr[idx].iftype) + Max_SZMNG_IF;
            if ((Min_SZMNG_OBJ > *(ptr+tmp)) || (*(ptr+tmp) > Max_SZMNG_OBJ)) {
#if NTRACE > 0
                LLDP_LOG_ERR(("mswLldpduAnalysis: oid length format error.\n"));
#endif
                break;
            }
            tlv->mngaddr[idx].curlen = length;
            ptr += sizeof(unsigned short);
            memcpy(&(tlv->mngaddr[idx].strlen), ptr, sizeof(tlv->mngaddr[idx].strlen));
            ptr += sizeof(tlv->mngaddr[idx].strlen);
            memcpy(&(tlv->mngaddr[idx].addr.type), ptr, sizeof(tlv->mngaddr[idx].addr.type));
            ptr += sizeof(tlv->mngaddr[idx].addr.type);
            memcpy(&(tlv->mngaddr[idx].addr.addr), ptr, 
                   tlv->mngaddr[idx].strlen - sizeof(tlv->mngaddr[idx].addr.type));
            ptr += (tlv->mngaddr[idx].strlen - sizeof(tlv->mngaddr[idx].addr.type));
            memcpy(&(tlv->mngaddr[idx].iftype), ptr, sizeof(tlv->mngaddr[idx].iftype));
            ptr += sizeof(tlv->mngaddr[idx].iftype);
            memcpy(&tmpul, ptr, sizeof(unsigned long));
            tlv->mngaddr[idx].ifnum = ntohl(tmpul);
            ptr += Max_SZMNG_IF;
            memcpy(&(tlv->mngaddr[idx].obj.len), ptr, sizeof(tlv->mngaddr[idx].obj.len));
            ptr += sizeof(tlv->mngaddr[idx].obj.len);
            memcpy(&(tlv->mngaddr[idx].obj.id), ptr, tlv->mngaddr[idx].obj.len);
            tlv->mngaddr[idx].status = 1;
            stored = 1;
            break;
        case TYPE_ORGANIZE:
            for (idx = 0; idx < MSW_LLDP_MODULE_NUM; idx++) {
                if (!mswLldpModules[idx].ops || !mswLldpModules[idx].ops->lldp_notify_recv) {
                    continue;
                }
                err = mswLldpModules[idx].ops->lldp_notify_recv(&inlldpdu[offset],
                                                        &length, &(info->tlvinfo), usrData);
                if (err == MSW_EC_NO_ERROR) {
                    stored = 1;
                } else if (err == MSW_EC_LLDPERR) {
                    frmerr = 1;
                    goto out;
                }
            }
            if (stored == 0) {
                memcpy(info->orgDefInfo, &inlldpdu[offset], length+2);
                info->tlvinfo.stsTlvUnrecognized++;
            }
            break;
        default:
            memcpy(info->unknownTLV, &inlldpdu[offset], length+2);
            info->tlvinfo.stsTlvUnrecognized++;
            break;
        }
        if (stored == 0) {
            info->tlvinfo.stsTlvDiscarded++;
            if ((type == TYPE_CHASSISID) || (type == TYPE_PORTID) || (type == TYPE_TIMETOLIVE)) {
                frmerr = 1;
                goto out;
            }
        }
        offset += sizeof(unsigned short) + length;
        stored = 0;
    } while(type != TYPE_EOL);

out:

    if (frmerr) {
        info->stsFrmDiscarded++;
        info->stsFrmInErr++;
        return MSW_EC_ERROR;
    }
    info->stsFrmIn++;
    return MSW_EC_NO_ERROR;
}

int mswLldpduCreate(unsigned char *outlldpdu, unsigned short *len,
                     MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData)
{
    unsigned int err = 0;
    unsigned char frmerr = 0;
    unsigned short offset = 0;
	unsigned short remlen;
    unsigned short length;
    unsigned int idx;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpduCreate: \n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }
    if (!outlldpdu) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: outlldpdu is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!len) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: len is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!tlv) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: tlv is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!info) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: info is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }

    remlen = *len;
    length = *len;
    tlv->chassis.iscreate = 0;
    tlv->portid.iscreate = 0;
    tlv->ttl.iscreate = 0;

    for (idx = 0; idx < MSW_LLDP_MODULE_NUM; idx++) {
        if ((!mswLldpModules[idx].ops) || (!mswLldpModules[idx].ops->lldp_gettlv)) {
            continue;
        }
        err = mswLldpModules[idx].ops->lldp_gettlv(&outlldpdu[offset], &length, 
                  tlv, info, usrData);
        if (err) {
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduCreate: lldp_gettlv failed.\n"));
#endif
            frmerr = 1;
            goto out;
        }
        if (remlen < length){
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduCreate: lldp_gettlv length error.\n"));
#endif
            frmerr = 1;
            goto out;
        }
        offset += (remlen - length);
        remlen = length;
    }

    if ((!tlv->chassis.iscreate) ||
        (!tlv->portid.iscreate) ||
        (!tlv->ttl.iscreate)){
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: mandatory TLV create fail.\n"));
#endif
        frmerr = 1;
        goto out;
    }

    if (length < FIX_EOL_SZ) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduCreate: The End TLV not create.\n"));
#endif
        frmerr = 1;
        goto out;
    }
    memset(&outlldpdu[offset], 0x00, FIX_EOL_SZ);
    offset += FIX_EOL_SZ;

out:
    if (frmerr) {
        info->stsLenErr++;
        return MSW_EC_ERROR;
    }
    *len = offset;
    return MSW_EC_NO_ERROR;
}

int mswLldpduShutdownCreate(unsigned char *outlldpdu, unsigned short *len,
                     MSW_TLVS_T * tlv, MSW_INFO_T * info)
{
    unsigned int err = 0;
    unsigned char frmerr = 0;
    unsigned short offset = 0;
    unsigned short remlen;
    unsigned short length;
    unsigned int idx;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpduShutdownCreate: \n"));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }
    if (!outlldpdu) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: outlldpdu is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!len) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: len is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!tlv) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: tlv is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }
    if (!info) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: info is null.\n"));
#endif
        return MSW_EC_EPARAM;
    }

    remlen = *len;
    length = *len;
    tlv->chassis.iscreate = 0;
    tlv->portid.iscreate = 0;
    tlv->ttl.iscreate = 0;

    for (idx = 0; idx < MSW_LLDP_MODULE_NUM; idx++) {
        if (mswLldpModules[idx].id != MSW_LLDP_MOD_MAND) {
            continue;
        }
        if (!mswLldpModules[idx].ops || !mswLldpModules[idx].ops->lldp_gettlv) {
            continue;
        }
        err = mswLldpModules[idx].ops->lldp_gettlv(&outlldpdu[offset], &length, tlv, info, NULL);
        if (err) {
#if NTRACE > 0
            LLDP_LOG_ERR(("mswLldpduShutdownCreate: lldp_gettlv failed.\n"));
#endif
            frmerr = 1;
            goto out;
        }
        offset += (remlen - length);
        remlen = length;
    }

    if ((!tlv->chassis.iscreate) ||
        (!tlv->portid.iscreate) ||
        (!tlv->ttl.iscreate)){
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: mandatory TLV create fail.\n"));
#endif
        frmerr = 1;
        goto out;
    }

    memset(&outlldpdu[offset - FIX_TTL_SZ], 0x00, FIX_TTL_SZ);

    if (length < FIX_EOL_SZ) {
#if NTRACE > 0
        LLDP_LOG_ERR(("mswLldpduShutdownCreate: The End TLV not create.\n"));
#endif
        frmerr = 1;
        goto out;
    }
    memset(&outlldpdu[offset], 0x00, FIX_EOL_SZ);
    offset += FIX_EOL_SZ;

out:
    if (frmerr) {
        info->stsLenErr++;
        return MSW_EC_ERROR;
    }
    info->stsFrmOut++;
    *len = offset;
    return MSW_EC_NO_ERROR;
}

void mswLldpRecv(char *ifname, unsigned char *inframe, unsigned short len)
{
    int ix;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpRecv:\n"));
#endif

    if (mswLldpInitFlag == 0) {
        return;
    }

    if ((ifname == NULL) || (inframe == NULL)) {
        return;
    }

#if NTRACE > 0
    LLDP_LOG_INF(("mswLldpRecv: ifname=%s\n", ifname));
    LLDP_LOG_DMP((char *)inframe, (int)len);
#endif
    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if (!strcmp(mswLldpLocalInfo[ix].ifname, ifname)) {
            if ((mswLldpLocalInfo[ix].adminStatus != RX_ONLY) && 
                (mswLldpLocalInfo[ix].adminStatus != TX_AND_RX)) {
#if NTRACE > 0
                LLDP_LOG_INF(("mswLldpRecv: adminStatus not much adminStatus=%d\n", 
                    mswLldpLocalInfo[ix].adminStatus));
#endif
                continue;
            }

            if (mswLldpLocalInfo[ix].rxCallback == NULL) {
#if NTRACE > 0
                LLDP_LOG_INF(("mswLldpRecv: rxCallback=NULL\n"));
#endif
                continue;
            }

            if ((mswLldpLocalInfo[ix].mcBitmap & RX_NEAREST_BRIDGE) && 
                !memcmp(inframe, mswGetMulticastAddr(NEAREST_BRIDGE), ETH_ADR_SZ)) {
                mswLldpLocalInfo[ix].rxCallback(inframe, len, 
                    &mswLldpLocalInfo[ix]);
            }
            if ((mswLldpLocalInfo[ix].mcBitmap & RX_NEAREST_NONTPMR_BRIDGE) && 
                !memcmp(inframe, mswGetMulticastAddr(NEAREST_NONTPMR_BRIDGE), ETH_ADR_SZ)) {
               mswLldpLocalInfo[ix].rxCallback(inframe, len, 
                    &mswLldpLocalInfo[ix]);
            }
            if ((mswLldpLocalInfo[ix].mcBitmap & RX_NEAREST_CUSTOMER_BRIDGE) && 
                !memcmp(inframe, mswGetMulticastAddr(NEAREST_CUSTOMER_BRIDGE), ETH_ADR_SZ)) {
               mswLldpLocalInfo[ix].rxCallback(inframe, len, 
                   &mswLldpLocalInfo[ix]);
            }
        }
    }

    return;
}

int mswLldpSend(char *ifname, unsigned char dstMc, unsigned char *outframe, 
        unsigned short len, MSW_INFO_T *info)
{
    unsigned char *pos;
    unsigned short length;
    int ix;
    int ret = MSW_EC_NO_ERROR;
    int rc;
    int allFlag = 0;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpSend: ifname=%s\n", ifname==NULL?"NULL":ifname));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if ((outframe == NULL) || (len <= ETH_HDR_SZ)) {
        return MSW_EC_EPARAM;
    }
    if (ifname == NULL) {
        allFlag = 1;
    }

    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if ((ifname == NULL) || !strcmp(mswLldpLocalInfo[ix].ifname, ifname)) {
            if ((dstMc != 0) && 
                (dstMc != (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_ALL))) {
                continue;
            }
            if ((mswLldpLocalInfo[ix].adminStatus != TX_ONLY) && 
                (mswLldpLocalInfo[ix].adminStatus != TX_AND_RX)) {
#if NTRACE > 0
                LLDP_LOG_INF(("mswLldpSend: adminStatus not much adminStatus=%d\n", 
                    mswLldpLocalInfo[ix].adminStatus));
#endif
                ret = MSW_EC_ERROR;
                if (allFlag == 1) {
                    continue;
                }
                break;
            }

            if (mswLldpLocalInfo[ix].txFunc == NULL) {
#if NTRACE > 0
                LLDP_LOG_INF(("mswLldpSend: txFunc=NULL\n"));
#endif
                ret = MSW_EC_ERROR;
                if (allFlag == 1) {
                    continue;
                }
                break;
            }

            pos = outframe;
            pos += (ETH_ADR_SZ * 2);
            *(unsigned short *)pos = htons(ETH_TYPE_LLDP);
            pos += sizeof(unsigned short);

            length = len;
            length -= ETH_HDR_SZ;
            rc = mswLldpduCreate(pos, &length, &(mswLldpLocalInfo[ix].tlv), 
                     info, mswLldpLocalInfo[ix].usrData);
            if (rc != MSW_EC_NO_ERROR) {
                ret = rc;
                if (allFlag == 1) {
                    continue;
                }
                break;
            }

            length += ETH_HDR_SZ;
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData); 
                info->stsFrmOut++;
            }
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_NONTPMR_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_NONTPMR_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData);
                info->stsFrmOut++;
            }
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_CUSTOMER_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_CUSTOMER_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData); 
                info->stsFrmOut++;
            }
            if (allFlag == 1) {
                continue;
            }
            break;
        }
    }

    if ((ix == MSW_LLDP_LINFO_NUM) && (allFlag == 0)) {
        ret = MSW_EC_NOT_FOUND;
    }

    return ret;
}

int mswLldpShutdownSend(char *ifname, unsigned char dstMc, 
        unsigned char *outframe, unsigned short len, MSW_INFO_T *info)
{
    unsigned char *pos;
    unsigned short length;
    int ix;
    int ret = MSW_EC_NO_ERROR;
    int rc;
    int allFlag = 0;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpShutdownSend: ifname=%s\n", 
          ifname==NULL?"NULL":ifname));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if ((outframe == NULL) || (len <= ETH_HDR_SZ)) {
        return MSW_EC_EPARAM;
    }
    if (ifname == NULL) {
        allFlag = 1;
    }

    for (ix = 0; ix < MSW_LLDP_LINFO_NUM; ix++) {
        if ((ifname == NULL) || !strcmp(mswLldpLocalInfo[ix].ifname, ifname)) { 
            if ((dstMc != 0) && 
                (dstMc != (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_ALL))) {
                continue;
            }

            if (mswLldpLocalInfo[ix].txFunc == NULL) {
#if NTRACE > 0
                LLDP_LOG_INF(("mswLldpShutdownSend: txFunc=NULL\n"));
#endif
                ret = MSW_EC_ERROR;
                if (allFlag == 1) {
                    continue;
                }
                break;
            }

            pos = outframe;
            pos += (ETH_ADR_SZ * 2);
            *(unsigned short *)pos = htons(ETH_TYPE_LLDP);
            pos += sizeof(unsigned short);

            length = len;
            length -= ETH_HDR_SZ;
            rc = mswLldpduShutdownCreate(pos, &length, 
                    &(mswLldpLocalInfo[ix].tlv), info);
            if (rc != MSW_EC_NO_ERROR) {
                ret = rc;
                if (allFlag == 1) {
                    continue;
                }
                break;
            }

            length += ETH_HDR_SZ;
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData); 
                info->stsFrmOut++;
            }
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_NONTPMR_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_NONTPMR_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData); 
                info->stsFrmOut++;
            }
            if (mswLldpLocalInfo[ix].mcBitmap & TX_NEAREST_CUSTOMER_BRIDGE) {
                memcpy(outframe, mswGetMulticastAddr(NEAREST_CUSTOMER_BRIDGE), ETH_ADR_SZ);
#if NTRACE > 0
                LLDP_LOG_DMP((char *)outframe, (int)length);
#endif
                mswLldpLocalInfo[ix].txFunc(mswLldpLocalInfo[ix].ifname, 
                      outframe, length, mswLldpLocalInfo[ix].usrData); 
                info->stsFrmOut++;
            }
            if (allFlag == 1) {
                continue;
            }
            break;
        }
    }

    if ((ix == MSW_LLDP_LINFO_NUM) && (allFlag == 0)) {
        ret = MSW_EC_NOT_FOUND;
    }

    return ret;
}

int mswLldpMibDelete(char *ifname, unsigned char mcBitMap)
{
    int ix;
    int ret;
    MSW_LLDP_LOCAL_INFO_T *info;

#if NTRACE > 0
    LLDP_LOG_TRC(("mswLldpMibDelete: ifname=%s mcBitMap=0x%2x\n", 
          ifname==NULL?"NULL":ifname, mcBitMap));
#endif

    if (mswLldpInitFlag == 0) {
        return MSW_EC_NOT_INIT;
    }

    if (ifname == NULL) {
        return MSW_EC_EPARAM;
    }

    ret = mswLldpLocalDataPtrGet(ifname, mcBitMap, &info);
    if (ret == MSW_EC_NO_ERROR) {
        for (ix = 0; ix < MSW_LLDP_MODULE_NUM; ix++) {
            if (!mswLldpModules[ix].ops || !mswLldpModules[ix].ops->lldp_notify_deletemib) {
                continue;
            }
            mswLldpModules[ix].ops->lldp_notify_deletemib(info->usrData);
        }
    }

    return ret;
}

int mswSetLockFunc(void *func)
{
#if NTRACE > 0
    LLDP_LOG_TRC(("mswSetLockFunc: func=%p\n", func));
#endif

    mswLockFunc = (void(*)(void))func;

    return MSW_EC_NO_ERROR;
}

int mswSetUnLockFunc(void *func)
{
#if NTRACE > 0
    LLDP_LOG_TRC(("mswSetUnLockFunc: func=%p\n", func));
#endif

    mswUnLockFunc = (void(*)(void))func;
    return MSW_EC_NO_ERROR;
}

char *mswGetVersion(void)
{
    return mswLldpVersion;
}

#ifdef MSW_LOG
void mswLldpDump(char *data, int length)
{
    char temp[80];
    int ix, iy;

#define LP(x) (&x[strlen(x)])

    LLDP_PRINTF("data addr=%p length=%d\n", data, length);

    for (ix = 0; ix < length; ix += 16) {
        memset(temp, 0x00, 80);
        LLDP_SPRINTF(LP(temp), "%04x  ", ix);

        for (iy = 0; iy < 16; iy ++) {
            if (ix + iy < length) {
                unsigned int c = (unsigned int)data[ix + iy] & 0xff;
                LLDP_SPRINTF(LP(temp), "%02x ", c);
            } else {
                strcat(temp, "   ");
            }
        }
        strcat(temp, "  ");

        for (iy = 0; iy < 16; iy ++) {
            if (ix + iy < length) {
                signed char c = data[ix + iy];
                if (c < ' ') {
                    c = '.';
                }
                LLDP_SPRINTF(LP(temp), "%c", c);
            } else {
                strcat(temp, " ");
            }
        }
        LLDP_PRINTF("%s\n", temp);
    }
}
#endif
