/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MACRO_H__
#define __PTP_MACRO_H__

#define		MAX_DOMAIN					(2U)
#define		MAX_PORT					(2U)

#define		PTPMMTIMEBLK_NUM			(30U)
#define		PTPMMFOREBLK_NUM			(10U)



	#define	PTP_USE_IEEE802_1
	#define	PTP_USE_IEEE1588
	#define	PTP_USE_TRANS

	#define	PTP_USE_BMCA
	#define	PTP_USE_GM
	#define	PTP_USE_MANAGEMENT
	#define	PTP_USE_SIGNALING

#define	PTP_LOGID_ALERT_DLOGSTOP
#define	PTP_LOGID_CRIT_DLOGSTOP
#define	PTP_LOGID_ERROR_DLOGSTOP
#define	PTP_LOGID_WARNING_DLOGSTOP
#define	PTP_LOGID_NOTICE_DLOGSTOP
#define	PTP_LOGID_INFO_DLOGSTOP
#define	PTP_LOGID_DEBUG_DLOGSTOP

#define	PTP_USERADJUST_EXTEND


#define	PTP_QBV_TRAFFIC_CLASS		(1)

#define	PTP_NEIGHBOR_PROPDELAY_THRESH (8000000U)


#define	DEQ_EGRESS_TS_TIMEOUT		(2U)

#define	PTP_CLK_TGT_USE_DETAIL

 #define	PTP_USE_ME_HW_ASSIST 




#define	PTP_1588_MANUFACTURER_ID	"\x38\xE0\x8E"
#define	PTP_1588_PRODUCT_DESCR		"Product Description;ModelNumber;InstancesID"
#define	PTP_1588_REVISION_DATA		"HW;FW;SW"

#define	MDSYCR_STACK_N			(16)
#define	MDPDLYRATIO_STACK_N		(2)


#include "ptp_Define.h"

#endif
