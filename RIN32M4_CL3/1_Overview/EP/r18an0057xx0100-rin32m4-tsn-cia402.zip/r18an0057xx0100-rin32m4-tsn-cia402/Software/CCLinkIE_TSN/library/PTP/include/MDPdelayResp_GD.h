/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYRESP_GD_H__
#define __MDPDELAYRESP_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"


typedef enum tagMDPDELAYRESP_ST {
	MDPDRP_NONE = 0,
	MDPDRP_NOT_ENABLED,
	MDPDRP_INITIAL_WAIT_FR_PDREQ,
	MDPDRP_WAIT_FR_PDELAY_REQ,
	MDPDRP_SENT_PDRESP_WAIT_FR_TMST,
	MDPDRP_STATUS_MAX,

}	MDPDELAYRESP_ST;
#define	DMDPDRP_STATUS_MAX			5

typedef enum tagMDPDELAYRESP_EV {
	MDPDRP_E_BEGIN = 0,
	MDPDRP_E_RCVDPDELAYREQ,
	MDPDRP_E_RCVD_MDTIMESTAMP_RCV,
	MDPDRP_E_CLOSE,
	MDPDRP_E_EVENT_MAX

}	MDPDELAYRESP_EV;
#define	DMDPDRP_E_EVENT_MAX			4


typedef struct tagMDPRESPSM_GD
{
	MDPDELAYRESP_ST		enStsMDPdelayResp;
	
	BOOL				blRcvdPdelayReq;
	PTPMSG*				pstRcvdPdelayReq;
	TIMESTAMP			stIngMDTimestampReceive;
	
	BOOL				blEgMDTimestampReceive;
	TIMESTAMP			stEgMDTimestampReceive;

	PTPMSG_PDELAY_RESP_1AS				stTxPdelayRespAS;
	PTPMSG_PDRESP_FOLLOWUP_1AS			stTxPdelayRespFollowUpAS;
	PTPMSG_PDELAY_RESP_1588				stTxPdelayResp1588;
	PTPMSG_PDRESP_FOLLOWUP_1588			stTxPdelayRespFollowUp1588;

} MDPRESPSM_GD;

#endif
