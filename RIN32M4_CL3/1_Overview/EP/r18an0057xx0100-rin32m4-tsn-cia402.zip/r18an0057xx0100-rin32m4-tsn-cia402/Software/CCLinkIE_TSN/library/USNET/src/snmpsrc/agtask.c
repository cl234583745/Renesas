//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include "snmpv3.h"


extern const AGENT_CONTEXT snmp_ac;

void ussSNMPAgentTask(void)
{
    sint16 i1;

    i1 = ussSNMPAgentInit(&snmp_ac);
    if (i1 < 0)
    {
#if NTRACE
        Nprintf("SNMPAgentTask: Initialization failed %d\n", i1);
#endif
        return;
    }

    while (ussSNMPAgentCheck() >= 0)
    {
        ;
    }

    ussSNMPAgentShut();
}

