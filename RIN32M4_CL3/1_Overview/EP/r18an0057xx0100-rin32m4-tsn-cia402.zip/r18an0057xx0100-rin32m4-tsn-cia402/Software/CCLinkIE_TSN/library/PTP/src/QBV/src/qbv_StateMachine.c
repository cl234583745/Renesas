/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
 

#include "qbv_StateMachine.h"
#include "ptp_CommonFunction.h"
#include "ptp_ClockTarget_API.h"
#include "ptp_tsn_Wrapper.h"
#include "tcpwrap_Proto.h"


TRACLS_QUEUE				gTraClsQueue[MAX_PORT][MAX_TRAFFIC_CLASS];
TRACLS_QUEUE				gTraClsSendWait[MAX_PORT];

INT qbv_StateMachine(UCHAR uchPort, USHORT usEvent, VOID* pvPara)
{
	
	typedef	INT(*QBV_SMFUNC)(
		UCHAR				uchPort,
		VOID *				pvPara);

	typedef struct tagQBV_SMTBL
	{
		USHORT				usNextState;
		QBV_SMFUNC			stQbvFunc;
	} QBV_SMTBL;

	static	const	QBV_SMTBL	gListConfSMTbl[QBVS_LCONF_TWAIT + 1][QBVE_SEND_COMPLET + 1] =
	{
		{
			{	QBVS_LCONF_TWAIT, 		&qbv_SM_lcf_idle_cchg },
			{	QBVS_LCONF_IDLE, 		&qbv_SM_lcf_idle_gdis },
			{	QBVS_LCONF_IDLE, 		(QBV_SMFUNC)0 },
			{	QBVS_LCONF_IDLE, 		(QBV_SMFUNC)0 },
			{	QBVS_LCONF_IDLE, 		(QBV_SMFUNC)0 }
		},

		{
			{	QBVS_LCONF_TWAIT, 		qbv_SM_lcf_wait_cchg },
			{	QBVS_LCONF_IDLE, 		qbv_SM_lcf_wait_gdis },
			{	QBVS_LCONF_TWAIT, 		(QBV_SMFUNC)0 },
			{	QBVS_LCONF_TWAIT, 		&qbv_SM_lcf_wait_tick },
			{	QBVS_LCONF_TWAIT, 		(QBV_SMFUNC)0 }
		}
	};

	static	const	QBV_SMTBL	gCycleTimerSMTbl[QBVS_CTIME_TWAIT + 1][QBVE_SEND_COMPLET + 1] =
	{
		{
			{	QBVS_CTIME_IDLE, 		(QBV_SMFUNC)0 },
			{	QBVS_CTIME_IDLE, 		&qbv_SM_ctm_idle_gdis },
			{	QBVS_CTIME_IDLE, 		(QBV_SMFUNC)0 },
			{	QBVS_CTIME_IDLE, 		&qbv_SM_ctm_idle_tick },
			{	QBVS_CTIME_IDLE, 		(QBV_SMFUNC)0 }
		},

		{
			{	QBVS_CTIME_TWAIT, 		(QBV_SMFUNC)0 },
			{	QBVS_CTIME_IDLE, 		qbv_SM_ctm_wait_gdis },
			{	QBVS_CTIME_TWAIT, 		(QBV_SMFUNC)0 },
			{	QBVS_CTIME_TWAIT, 		&qbv_SM_ctm_wait_tick },
			{	QBVS_CTIME_TWAIT, 		(QBV_SMFUNC)0 }
		}
	};

	static	const	QBV_SMTBL	gListExecuteSMTbl[QBVS_LEXEC_CYCLE + 1][QBVE_SEND_COMPLET + 1] =
	{
		{
			{	QBVS_LEXEC_IDLE, 		(QBV_SMFUNC)0 },
			{	QBVS_LEXEC_IDLE, 		&qbv_SM_lex_idle_gdis },
			{	QBVS_LEXEC_IDLE, 		&qbv_SM_lex_idle_sreq },
			{	QBVS_LEXEC_IDLE, 		&qbv_SM_lex_idle_tick },
			{	QBVS_LEXEC_IDLE, 		&qbv_SM_lex_idle_scmp }
		},

		{
			{	QBVS_LEXEC_CYCLE, 		(QBV_SMFUNC)0 },
			{	QBVS_LEXEC_IDLE, 		qbv_SM_lex_cycl_gdis },
			{	QBVS_LEXEC_CYCLE, 		&qbv_SM_lex_cycl_sreq },
			{	QBVS_LEXEC_CYCLE, 		&qbv_SM_lex_cycl_tick },
			{	QBVS_LEXEC_CYCLE, 		&qbv_SM_lex_cycl_scmp }
		}
	};

	INT			nErrorCode = 0;
	QBV_SMFUNC	pfnActFunc = NULL;
	USHORT		usCurState = 0;

	CLKTARGETCURTIME	stCurTime = {0};

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort - 1)) {
		return (INT)RET_EINVAL;
	}

	ptp_clockTargetGetCurrentTime(0, &stCurTime);
	gGateParTbl[uchPort].stCurrentTime = stCurTime.stCurrentTime;

	usCurState = gGateParTbl[uchPort].usListConfStat;
	gGateParTbl[uchPort].usListConfStat =
		gListConfSMTbl[usCurState][usEvent].usNextState;
	pfnActFunc = gListConfSMTbl[usCurState][usEvent].stQbvFunc;
	if (pfnActFunc != (QBV_SMFUNC)0)
	{
		nErrorCode = (*(pfnActFunc))(uchPort, pvPara);
	}

	if (nErrorCode != RET_ENOERR) {
		return nErrorCode;
	}

	usCurState = gGateParTbl[uchPort].usCycleTimeStat;
	gGateParTbl[uchPort].usCycleTimeStat =
		gCycleTimerSMTbl[usCurState][usEvent].usNextState;
	pfnActFunc = gCycleTimerSMTbl[usCurState][usEvent].stQbvFunc;
	if (pfnActFunc != (QBV_SMFUNC)0)
	{
		nErrorCode = (*(pfnActFunc))(uchPort, pvPara);
	}

	if (nErrorCode != RET_ENOERR) {
		return nErrorCode;
	}

	usCurState = gGateParTbl[uchPort].usListExecStat;
	gGateParTbl[uchPort].usListExecStat =
		gListExecuteSMTbl[usCurState][usEvent].usNextState;
	pfnActFunc = gListExecuteSMTbl[usCurState][usEvent].stQbvFunc;
	if (pfnActFunc != (QBV_SMFUNC)0)
	{
		nErrorCode = (*(pfnActFunc))(uchPort, pvPara);
	}
	
	if (usEvent == QBVE_TICK){
		tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stBeforeTime, &gGateParTbl[uchPort].stCurrentTime, sizeof(EXTENDEDTIMESTAMP));
	}
	
	return nErrorCode;
}

INT qbv_SM_lcf_idle_cchg(UCHAR uchPort, VOID* pvPara)
{
	
	ULONG ulLoop = 0UL;
	INT nLoop = 0;
	ULONG ulLoop2 = 0UL;
	CHAR chRet = (CHAR)0;
	USCALEDNS stUSNS = {0};
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	EXTENDEDTIMESTAMP stTimeStamp = {0};


	UNREF_PARA(pvPara);

	gGateParTbl[uchPort].blConfigChange = FALSE;

	chRet = ptpCompETS_ETS(&gGateParTbl[uchPort].stAdmBaseTime, &gGateParTbl[uchPort].stCurrentTime);
	if (chRet >= COMP_EQUAL) {
		tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stConfChangTime, 
			&gGateParTbl[uchPort].stAdmBaseTime, sizeof(gGateParTbl[uchPort].stAdmBaseTime));
	}
	else if (gGateParTbl[uchPort].blGateEnabled == FALSE) {
		qbv_Calculat_CycleStartTime(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stAdmBaseTime,
											&gGateParTbl[uchPort].stAdmCycleTime, &gGateParTbl[uchPort].stConfChangTime);
		
	}
	else {
		gGateParTbl[uchPort].lConfChangErr++;
		qbv_Calculat_CycleStartTime(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stAdmBaseTime,
											&gGateParTbl[uchPort].stAdmCycleTime, &gGateParTbl[uchPort].stConfChangTime);
	}

	gGateParTbl[uchPort].blConfigPending = TRUE;

	for (ulLoop = 0; ulLoop < (ULONG)MAX_TRAFFIC_CLASS; ulLoop++) {
		while (gpTraEntryRecPtr[uchPort][ulLoop] != NULL) {
			pstTraEntry = gpTraEntryRecPtr[uchPort][ulLoop];
			gpTraEntryRecPtr[uchPort][ulLoop] = pstTraEntry->pstTraClsNext;
			pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
			gpTraEntryRecPtr0 = pstTraEntry;
		}
	}

	for (ulLoop = 0UL; ulLoop < (ULONG)MAX_TRAFFIC_CLASS; ulLoop++) {
		nLoop = (INT)0;
		while (nLoop < (INT)gGateParTbl[uchPort].usClassQueMax[ulLoop]) {
			pstTraEntry = gpTraEntryRecPtr0;
			if (pstTraEntry == NULL) {
				for (ulLoop2 = 0; ulLoop2 < (ULONG)MAX_TRAFFIC_CLASS; ulLoop2++) {
					while (gpTraEntryRecPtr[uchPort][ulLoop2] != NULL) {
						pstTraEntry = gpTraEntryRecPtr[uchPort][ulLoop2];
						gpTraEntryRecPtr[uchPort][ulLoop2] = pstTraEntry->pstTraClsNext;
						pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
						gpTraEntryRecPtr0 = pstTraEntry;
					}
				}
				return (INT)RET_ENOMEM;
			}
			gpTraEntryRecPtr0 = pstTraEntry->pstTraClsNext;
			pstTraEntry->pstTraClsNext = gpTraEntryRecPtr[uchPort][ulLoop];
			gpTraEntryRecPtr[uchPort][ulLoop] = pstTraEntry;
			nLoop++;
		}
	}

	return (INT)RET_ENOERR;
}

INT qbv_SM_lcf_idle_gdis(UCHAR uchPort, VOID* pvPara)
{

	INT nLoop = 0;
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;

	UNREF_PARA(pvPara);

	gGateParTbl[uchPort].blConfigPending = FALSE;


	for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
		while (gTraClsQueue[uchPort][nLoop].pstTraClsNext != NULL) {
			pstTraEntry = gTraClsQueue[uchPort][nLoop].pstTraClsNext;
			gTraClsQueue[uchPort][nLoop].pstTraClsNext = pstTraEntry->pstTraClsNext;
			pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
			gpTraEntryRecPtr0 = pstTraEntry;
		}
	}
	for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
		while (gpTraEntryRecPtr[uchPort][nLoop] != NULL) {
			pstTraEntry = gpTraEntryRecPtr[uchPort][nLoop];
			gpTraEntryRecPtr[uchPort][nLoop] = pstTraEntry->pstTraClsNext;
			pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
			gpTraEntryRecPtr0 = pstTraEntry;
		}
	}

	return (INT)RET_ENOERR;
}

INT qbv_SM_lcf_wait_tick(UCHAR uchPort, VOID* pvPara)
{
	
	ULONG ulLoop = 0UL;
	CHAR chRet = (CHAR)0;

	UNREF_PARA(pvPara);

	chRet = ptpCompETS_ETS(&gGateParTbl[uchPort].stConfChangTime, &gGateParTbl[uchPort].stCurrentTime);
	if (chRet == COMP_A_GREAT) {
		return (INT)RET_ENOERR;
	}
	else {
		gGateParTbl[uchPort].stOpeBaseTime = gGateParTbl[uchPort].stAdmBaseTime;
		for (ulLoop = 0UL; ulLoop < gGateParTbl[uchPort].ulAdmContListLen; ulLoop++) {
			gGateParTbl[uchPort].stOpeGateCont[ulLoop] = gGateParTbl[uchPort].stAdmGateCont[ulLoop];
		}
		gGateParTbl[uchPort].ulOpeContListLen = gGateParTbl[uchPort].ulAdmContListLen;
		gGateParTbl[uchPort].stOpeCycleTime = gGateParTbl[uchPort].stAdmCycleTime;
		gGateParTbl[uchPort].ulOpeCycleTimeExt = gGateParTbl[uchPort].ulAdmCycleTimeExt;
		gGateParTbl[uchPort].lNewConfigCT = TRUE;
	}

	gGateParTbl[uchPort].blConfigPending = FALSE;

	gGateParTbl[uchPort].usListConfStat = QBVS_LCONF_IDLE;

	return (INT)RET_ENOERR;
}

INT qbv_SM_ctm_idle_gdis(UCHAR uchPort, VOID* pvPara)
{

	UNREF_PARA(pvPara);

	gGateParTbl[uchPort].blCycleStart = FALSE;

	gGateParTbl[uchPort].lNewConfigCT = FALSE;

	return (INT)RET_ENOERR;
}

INT qbv_SM_ctm_idle_tick(UCHAR uchPort, VOID* pvPara)
{
	
	CHAR chRet = (CHAR)0;
	USCALEDNS stUSNS = {0};
	EXTENDEDTIMESTAMP stTimeStamp = {0};


	UNREF_PARA(pvPara);

	if (gGateParTbl[uchPort].lNewConfigCT == FALSE) {
		return (INT)RET_ENOERR;
	}
	else {
		gGateParTbl[uchPort].blCycleStart = FALSE;

		gGateParTbl[uchPort].lNewConfigCT = FALSE;
		
		chRet = ptpCompETS_ETS(&gGateParTbl[uchPort].stOpeBaseTime, &gGateParTbl[uchPort].stCurrentTime);
		
		if (chRet >= COMP_EQUAL) {
			tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stCycleStartTime,
				&gGateParTbl[uchPort].stOpeBaseTime, sizeof(gGateParTbl[uchPort].stOpeBaseTime));
		}
		else {
			qbv_Calculat_CycleStartTime(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stOpeBaseTime,
												&gGateParTbl[uchPort].stOpeCycleTime, &gGateParTbl[uchPort].stCycleStartTime);
		}
		
		
		gGateParTbl[uchPort].usCycleTimeStat = QBVS_CTIME_TWAIT;
	}
	return (INT)RET_ENOERR;
}

INT qbv_SM_ctm_wait_tick(UCHAR uchPort, VOID* pvPara)
{

	CHAR chRet = (CHAR)0;
	CHAR chRet2 = (CHAR)0;
	USCALEDNS stUSNS = {0};
	USCALEDNS stUSNS2 = {0};
	USCALEDNS stUSNS3 = {0};
	EXTENDEDTIMESTAMP stTimeStamp = {0};

	UNREF_PARA(pvPara);

	if (gGateParTbl[uchPort].lNewConfigCT == FALSE) {
		chRet = ptpCompETS_ETS(&gGateParTbl[uchPort].stCycleStartTime, &gGateParTbl[uchPort].stCurrentTime);
		if (chRet == COMP_A_GREAT) {
			return (INT)RET_ENOERR;
		}
		else {
			gGateParTbl[uchPort].blCycleStart = TRUE;
		}
	}
	else {
		gGateParTbl[uchPort].blCycleStart = FALSE;

		gGateParTbl[uchPort].lNewConfigCT = FALSE;

		tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stCycleStartTime,
			&gGateParTbl[uchPort].stOpeBaseTime, sizeof(gGateParTbl[uchPort].stOpeBaseTime));
	}


	if (gGateParTbl[uchPort].blConfigPending == FALSE) {

		chRet = ptpCompETS_ETS(&gGateParTbl[uchPort].stOpeBaseTime, &gGateParTbl[uchPort].stCurrentTime);

		if (chRet >= COMP_EQUAL) {
			tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stCycleStartTime, 
				&gGateParTbl[uchPort].stOpeBaseTime, sizeof(gGateParTbl[uchPort].stOpeBaseTime));
		}
		else {
			qbv_Calculat_CycleStartTime(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stCycleStartTime,
												&gGateParTbl[uchPort].stOpeCycleTime, &gGateParTbl[uchPort].stCycleStartTime);
		}
	}
	else {

		stUSNS.ulNsec_2nd = (ULONG)gGateParTbl[uchPort].stOpeCycleTime.lHighTimeBit;
		stUSNS.ulNsec_lsb = gGateParTbl[uchPort].stOpeCycleTime.ulLowTimeBit;
		stUSNS2.ulNsec_lsb = gGateParTbl[uchPort].ulOpeCycleTimeExt;
		ptpAddUSNs_USNs(&stUSNS, &stUSNS2, &stUSNS);
		ptpAddETS_USNs(&gGateParTbl[uchPort].stCurrentTime, &stUSNS, &stTimeStamp);
		chRet2 = ptpCompETS_ETS(&gGateParTbl[uchPort].stConfChangTime, &stTimeStamp);

		if (chRet2 == COMP_A_GREAT) {
			chRet2 = ptpCompETS_ETS(&gGateParTbl[uchPort].stCycleStartTime, &gGateParTbl[uchPort].stCurrentTime);
			if (chRet2 < COMP_EQUAL)
			{
				qbv_Calculat_CycleStartTime(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stCycleStartTime,
												&gGateParTbl[uchPort].stOpeCycleTime, &gGateParTbl[uchPort].stCycleStartTime);
			}

		} 
		else {
			tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stCycleStartTime, 
								&gGateParTbl[uchPort].stConfChangTime, sizeof(gGateParTbl[uchPort].stConfChangTime));
		}
	}

	return (INT)RET_ENOERR;
}

INT qbv_SM_lex_idle_gdis(UCHAR uchPort, VOID* pvPara)
{

	UNREF_PARA(pvPara);
	
	gGateParTbl[uchPort].byOpeGateStates = gGateParTbl[uchPort].byAdmGateStates;

	gGateParTbl[uchPort].stExitTimer.lHighTimeBit = 0L;
	gGateParTbl[uchPort].stExitTimer.ulLowTimeBit = 0UL;

	gGateParTbl[uchPort].lListPointer = 0L;

	gGateParTbl[uchPort].blCycleExec = FALSE;

	return (INT)RET_ENOERR;
}

INT qbv_SM_lex_idle_sreq(UCHAR uchPort, VOID* pvPara)
{
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	struct tagTRACLS_ENTRY* pstTagPara = pvPara;
	INT nErrorCode = 0;


	if ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTagPara->uchTraClsNo-1))) != 0) {
		if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
			gTraClsSendWait[uchPort].pstTraClsTail = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsNext = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
		}
		else {
			pstTraEntry = gTraClsSendWait[uchPort].pstTraClsTail;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
		}
	}
	else {
		if (gGateParTbl[uchPort].blCycleExec != FALSE) {
			if (gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsNext == NULL) {
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsNext = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = NULL;
			}
			else {
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = NULL;
			}
			return (INT)RET_ENOERR;
		}
		else {
			return (INT)RET_EINTERNAL;
		}
	}
	
	nErrorCode = ethwrap_send(uchPort, pstTagPara->puchFramPtr, pstTagPara->usFramLen);

	if (nErrorCode == RET_ENOERR) {
		gGateParTbl[uchPort].nSendCompWaitCT++;
	}
	else {
		nErrorCode = RET_EINTERNAL;
		if (gTraClsSendWait[uchPort].pstTraClsNext == gTraClsSendWait[uchPort].pstTraClsTail) {
			gTraClsSendWait[uchPort].pstTraClsTail = NULL;
			gTraClsSendWait[uchPort].pstTraClsNext = NULL;
		}
		else {
			gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
		}

		if (pstTagPara->stSendCBFunc != NULL) {
			tsn_Wrapper_UnLock(gpLockHandle);
			(*(pstTagPara->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, pstTagPara->pvLinkId);
			tsn_Wrapper_LockWait(gpLockHandle);
		}
	
		if (gGateParTbl[uchPort].usClassQueMax[pstTagPara->uchTraClsNo - 1u] != 0) {
			pstTagPara->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTagPara->uchTraClsNo - 1u];
			gpTraEntryRecPtr[uchPort][pstTagPara->uchTraClsNo - 1u] = pstTagPara;
		}
		else {
			pstTagPara->pstTraClsNext = gpTraEntryRecPtr0;
			gpTraEntryRecPtr0 = pstTagPara;
		}
	}
	return nErrorCode;
}

INT qbv_SM_lex_idle_tick(UCHAR uchPort, VOID* pvPara)
{
	
	INT nLoop = 0;
	INT nErrorCode = 0;
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	struct tagTRACLS_ENTRY* pstTraEntry2 = NULL;
	SCALEDNS stSNS = {0};
	SCALEDNS stSNS2 = {0};
	TIME_EXTENTION stTmpExitTimer = {0};

	UNREF_PARA(pvPara);

	if (gGateParTbl[uchPort].blCycleStart == FALSE) {
		return (INT)RET_ENOERR;
	}

	gGateParTbl[uchPort].blCycleStart = FALSE;
	gGateParTbl[uchPort].lListPointer = 0L;
	gGateParTbl[uchPort].blCycleExec = TRUE;
	gGateParTbl[uchPort].usListExecStat = QBVS_LEXEC_CYCLE;
	gGateParTbl[uchPort].byOpeGateStates = 
		gGateParTbl[uchPort].stOpeGateCont[gGateParTbl[uchPort].lListPointer].byGateState;
	tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stExitTimer, 
		&gGateParTbl[uchPort].stOpeGateCont[gGateParTbl[uchPort].lListPointer].stTimeInterval, 
		sizeof(TIME_EXTENTION));
	if ((gGateParTbl[uchPort].stExitTimer.lHighTimeBit == 0L) 
		&& (gGateParTbl[uchPort].stExitTimer.ulLowTimeBit == 0UL)) {
		gGateParTbl[uchPort].stExitTimer.ulLowTimeBit = 1;
	}

	for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
		gTraClsQueue[uchPort][nLoop].ulTotalDataSize = 0UL;
	}

	if (gGateParTbl[uchPort].stUserGOpenCB[gGateParTbl[uchPort].lListPointer] != NULL) {
		tsn_Wrapper_UnLock(gpLockHandle);
		(*(gGateParTbl[uchPort].stUserGOpenCB[gGateParTbl[uchPort].lListPointer]))(uchPort, (UCHAR)gGateParTbl[uchPort].lListPointer);
		tsn_Wrapper_LockWait(gpLockHandle);
	}

	tsn_Wrapper_MemCpy(&stTmpExitTimer, &gGateParTbl[uchPort].stExitTimer, sizeof(TIME_EXTENTION));
	stSNS.ulNsec_2nd = (ULONG)stTmpExitTimer.lHighTimeBit;
	stSNS.ulNsec_lsb = stTmpExitTimer.ulLowTimeBit;

	if (gGateParTbl[uchPort].nSendCompWaitCT > 0) {
		stSNS2.ulNsec_lsb = (ULONG)((ULONG)gGateParTbl[uchPort].nSendCompWaitCT * gGateParTbl[uchPort].ulMaxFrameTransTime);
		ptpSubSNs_SNs(&stSNS, &stSNS2, &stSNS);
		pstTraEntry = gTraClsSendWait[uchPort].pstTraClsNext;
		if ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTraEntry->uchTraClsNo-1))) == 0) {
			gGateParTbl[uchPort].stQueMaxSDU->ulTransOverrun++;
		}
	}
	
	for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
		pstTraEntry2 = gTraClsQueue[uchPort][nLoop].pstTraClsNext;
		if (pstTraEntry2 != NULL) {
			while ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTraEntry2->uchTraClsNo-1))) != 0){
				if (stSNS.sNsec_msb < 0) {
					return (INT)RET_ENOERR;
				}
				else if ((stSNS.sNsec_msb == 0)
					&& (stSNS.ulNsec_2nd == 0UL)
					&& (gGateParTbl[uchPort].ulMaxFrameTransTime > stSNS.ulNsec_lsb)) {
					return (INT)RET_ENOERR;
				}
				else if ((gTraClsQueue[uchPort][nLoop].ulTotalDataSize + pstTraEntry2->usFramLen) <
					gGateParTbl[uchPort].stQueMaxSDU->ulQueMaxSDU) {

					gTraClsQueue[uchPort][nLoop].pstTraClsNext = pstTraEntry2->pstTraClsNext;
					if (gTraClsQueue[uchPort][nLoop].pstTraClsNext == NULL) {
						gTraClsQueue[uchPort][nLoop].pstTraClsTail = NULL;
					}

					if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}
					else {
						pstTraEntry = gTraClsSendWait[uchPort].pstTraClsTail;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}

					nErrorCode = ethwrap_send(uchPort, pstTraEntry2->puchFramPtr, pstTraEntry2->usFramLen);

					if (nErrorCode == RET_ENOERR) {
						gGateParTbl[uchPort].nSendCompWaitCT++;
						gTraClsQueue[uchPort][nLoop].ulTotalDataSize += pstTraEntry2->usFramLen;
						stSNS2.ulNsec_lsb = gGateParTbl[uchPort].ulMaxFrameTransTime;
						ptpSubSNs_SNs(&stSNS, &stSNS2, &stSNS);
					}
					else {
						if (gTraClsSendWait[uchPort].pstTraClsNext == gTraClsSendWait[uchPort].pstTraClsTail) {
							gTraClsSendWait[uchPort].pstTraClsTail = NULL;
							gTraClsSendWait[uchPort].pstTraClsNext = NULL;
						}
						else {
							gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry;
							gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
						}

						if (pstTraEntry2->stSendCBFunc != NULL) {
							tsn_Wrapper_UnLock(gpLockHandle);
							(*(pstTraEntry2->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, pstTraEntry2->pvLinkId);
							tsn_Wrapper_LockWait(gpLockHandle);
						}

						if (pstTraEntry2->pvPacketId != 0) {
							tcpwrap_sbuffree(pstTraEntry2->pvPacketId);
							pstTraEntry2->pvPacketId = 0;
						}
						if (gGateParTbl[uchPort].usClassQueMax[pstTraEntry2->uchTraClsNo - 1u] != 0) {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u];
							gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u] = pstTraEntry2;
						}
						else {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr0;
							gpTraEntryRecPtr0 = pstTraEntry2;
						}
					}
				}
				else {
					return (INT)RET_ENOERR;
				}
				pstTraEntry2 = gTraClsQueue[uchPort][nLoop].pstTraClsNext;
				if (pstTraEntry2 == NULL) {
					break;
				}
			}
		}
	}

	return (INT)RET_ENOERR;
}

INT qbv_SM_lex_idle_scmp(UCHAR uchPort, VOID* pvPara)
{

	struct tagTRACLS_ENTRY* pstTraEntry = NULL;

	UNREF_PARA(pvPara);

	pstTraEntry = gTraClsSendWait[uchPort].pstTraClsNext;
	gTraClsSendWait[uchPort].pstTraClsNext = pstTraEntry->pstTraClsNext;
	if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
		gTraClsSendWait[uchPort].pstTraClsTail = NULL;
	}

	if (pstTraEntry->pvPacketId != 0) {
		tcpwrap_sbuffree(pstTraEntry->pvPacketId);
		pstTraEntry->pvPacketId = 0;
	}

	if (gGateParTbl[uchPort].usClassQueMax[pstTraEntry->uchTraClsNo - 1u] != 0) {
		pstTraEntry->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTraEntry->uchTraClsNo - 1u];
		gpTraEntryRecPtr[uchPort][pstTraEntry->uchTraClsNo - 1u] = pstTraEntry;
	}
	else {
		pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
		gpTraEntryRecPtr0 = pstTraEntry;
	}

	return (INT)RET_ENOERR;
}

INT qbv_SM_lex_cycl_sreq(UCHAR uchPort, VOID* pvPara)
{
	struct tagTRACLS_ENTRY* pstTagPara = pvPara;
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	INT nLoop = 0;
	INT nErrorCode = 0;
	SCALEDNS stElapsedTime = {0};
	SCALEDNS stTmpExitTimer = {0};
	SCALEDNS stSNS = {0};
	SCALEDNS stSNS2 = {0};

	for (nLoop = pstTagPara->uchTraClsNo-1; nLoop >= 0; nLoop--) {
		if (((gTraClsQueue[uchPort][nLoop].pstTraClsNext != NULL) && ((gGateParTbl[uchPort].byOpeGateStates & (1 << nLoop)) != 0))
			|| ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTagPara->uchTraClsNo-1))) == 0)) {
			if (gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsNext == NULL) {
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsNext = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = NULL;
			}
			else {
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail = pstTagPara;
				gTraClsQueue[uchPort][pstTagPara->uchTraClsNo-1].pstTraClsTail->pstTraClsNext = NULL;
			}
			return (INT)RET_ENOERR;
		}
	}

	ptpSubETS_ETS(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stBeforeTime, &stElapsedTime);
	stSNS.ulNsec_2nd = (ULONG)gGateParTbl[uchPort].stExitTimer.lHighTimeBit;
	stSNS.ulNsec_lsb = gGateParTbl[uchPort].stExitTimer.ulLowTimeBit;
	ptpSubSNs_SNs(&stSNS, &stElapsedTime, &stTmpExitTimer);
	if (stTmpExitTimer.sNsec_msb >= 0) {
		stSNS2.ulNsec_lsb = (ULONG)((ULONG)gGateParTbl[uchPort].nSendCompWaitCT * gGateParTbl[uchPort].ulMaxFrameTransTime);
		ptpSubSNs_SNs(&stTmpExitTimer, &stSNS2, &stTmpExitTimer);
	}

	if ((stTmpExitTimer.sNsec_msb < 0)
		|| ((gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1u].ulTotalDataSize + pstTagPara->usFramLen)
			>= gGateParTbl[uchPort].stQueMaxSDU->ulQueMaxSDU)) {
		if (gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsNext == NULL) {
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsNext = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = NULL;
		}
		else {
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = NULL;
		}
		return (INT)RET_ENOERR;
	}
	else if ((stTmpExitTimer.sNsec_msb == 0) 
		&& (stTmpExitTimer.ulNsec_2nd == 0UL)
		&& (gGateParTbl[uchPort].ulMaxFrameTransTime > stTmpExitTimer.ulNsec_lsb)) {
		if (gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsNext == NULL) {
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsNext = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = NULL;
		}
		else {
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail = pstTagPara;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].pstTraClsTail->pstTraClsNext = NULL;
		}
		return (INT)RET_ENOERR;	
	}
	else {

		if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
			gTraClsSendWait[uchPort].pstTraClsTail = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsNext = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
		}
		else {
			pstTraEntry = gTraClsSendWait[uchPort].pstTraClsTail;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail = pstTagPara;
			gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
		}

		nErrorCode = ethwrap_send(uchPort, pstTagPara->puchFramPtr, pstTagPara->usFramLen);

		if (nErrorCode == RET_ENOERR) {
			gGateParTbl[uchPort].nSendCompWaitCT++;
			gTraClsQueue[uchPort][pstTagPara->uchTraClsNo - 1].ulTotalDataSize += pstTagPara->usFramLen;
		}
		else {
			nErrorCode = RET_EINTERNAL;
			if (gTraClsSendWait[uchPort].pstTraClsNext == gTraClsSendWait[uchPort].pstTraClsTail) {
				gTraClsSendWait[uchPort].pstTraClsTail = NULL;
				gTraClsSendWait[uchPort].pstTraClsNext = NULL;
			}
			else {
				gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry;
				gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
			}

			if (pstTagPara->stSendCBFunc != NULL) {
				tsn_Wrapper_UnLock(gpLockHandle);
				(*(pstTagPara->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, pstTagPara->pvLinkId);
				tsn_Wrapper_LockWait(gpLockHandle);
			}

			if (gGateParTbl[uchPort].usClassQueMax[pstTagPara->uchTraClsNo - 1u] != 0) {
				pstTagPara->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTagPara->uchTraClsNo - 1u];
				gpTraEntryRecPtr[uchPort][pstTagPara->uchTraClsNo - 1u] = pstTagPara;
			}
			else {
				pstTagPara->pstTraClsNext = gpTraEntryRecPtr0;
				gpTraEntryRecPtr0 = pstTagPara;
			}
			return nErrorCode;
		}
		return nErrorCode;
	}
}

INT qbv_SM_lex_cycl_tick(UCHAR uchPort, VOID* pvPara)
{

	UCHAR uchLoop = 0;
	INT nErrorCode = 0;
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	struct tagTRACLS_ENTRY* pstTraEntry2 = NULL;
	TIME_EXTENTION stTmpExitTimer = {0};
	SCALEDNS stElapsedTime = {0};
	SCALEDNS stSNS = {0};
	SCALEDNS stSNS2 = {0};
	SCALEDNS stSNS3 = {0};

	UNREF_PARA(pvPara);

	if (gGateParTbl[uchPort].blCycleStart == TRUE) {
		gGateParTbl[uchPort].blCycleStart = FALSE;
		gGateParTbl[uchPort].lListPointer = 0L;
	}
	else {
		ptpSubETS_ETS(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stBeforeTime, &stElapsedTime);
		stSNS.ulNsec_2nd = (ULONG)gGateParTbl[uchPort].stExitTimer.lHighTimeBit;
		stSNS.ulNsec_lsb = gGateParTbl[uchPort].stExitTimer.ulLowTimeBit;
		ptpSubSNs_SNs(&stSNS, &stElapsedTime, &stSNS);
		
		if ((stSNS.sNsec_msb < 0) 
			|| ((stSNS.ulNsec_2nd == 0UL)
				&& (stSNS.sNsec_msb == 0) 
				&& (stSNS.ulNsec_lsb == 0UL))) {
			if (gQbvInfTbl.stUserFailedCB != NULL) {
				for (uchLoop = 0; uchLoop < MAX_TRAFFIC_CLASS; uchLoop++) {
					if ((gGateParTbl[uchPort].byOpeGateStates & (1 << uchLoop)) != 0) {
						if (gTraClsQueue[uchPort][uchLoop].pstTraClsNext != NULL) {
							tsn_Wrapper_UnLock(gpLockHandle);
							(*(gQbvInfTbl.stUserFailedCB))((INT)RET_EINTERNAL, uchPort, uchLoop);
							tsn_Wrapper_LockWait(gpLockHandle);
						}
						else {
							pstTraEntry = gTraClsSendWait[uchPort].pstTraClsNext;
							while (pstTraEntry != NULL) {
								if ((pstTraEntry->uchTraClsNo - 1) == uchLoop) {
									tsn_Wrapper_UnLock(gpLockHandle);
									(*(gQbvInfTbl.stUserFailedCB))((INT)RET_EINTERNAL, uchPort, uchLoop + 8);
									tsn_Wrapper_LockWait(gpLockHandle);
								}
								pstTraEntry = pstTraEntry->pstTraClsNext;
							}
						}
					}
				}
			}
			gGateParTbl[uchPort].lListPointer++;
			if (gGateParTbl[uchPort].lListPointer >= (LONG)gGateParTbl[uchPort].ulOpeContListLen) {
				gGateParTbl[uchPort].usListExecStat = QBVS_LEXEC_IDLE;
				gGateParTbl[uchPort].byOpeGateStates = 0x00;
				return (INT)RET_ENOERR;
			}
		}
		else {
			gGateParTbl[uchPort].stExitTimer.lHighTimeBit = (LONG)stSNS.ulNsec_2nd;
			gGateParTbl[uchPort].stExitTimer.ulLowTimeBit = stSNS.ulNsec_lsb;
			return (INT)RET_ENOERR;
		}
	}
	gGateParTbl[uchPort].byOpeGateStates =
		gGateParTbl[uchPort].stOpeGateCont[gGateParTbl[uchPort].lListPointer].byGateState;
	tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stExitTimer, 
		&gGateParTbl[uchPort].stOpeGateCont[gGateParTbl[uchPort].lListPointer].stTimeInterval, 
		sizeof(TIME_EXTENTION));
	if ((gGateParTbl[uchPort].stExitTimer.ulLowTimeBit == 0UL) 
		&& (gGateParTbl[uchPort].stExitTimer.lHighTimeBit == 0L)) {
		gGateParTbl[uchPort].stExitTimer.ulLowTimeBit = 1UL;
	}

	for (uchLoop = 0; uchLoop < MAX_TRAFFIC_CLASS; uchLoop++) {
		gTraClsQueue[uchPort][uchLoop].ulTotalDataSize = 0UL;
	}

	if (gGateParTbl[uchPort].stUserGOpenCB[gGateParTbl[uchPort].lListPointer] != NULL) {
		tsn_Wrapper_UnLock(gpLockHandle);
		(*(gGateParTbl[uchPort].stUserGOpenCB[gGateParTbl[uchPort].lListPointer]))(uchPort, (UCHAR)gGateParTbl[uchPort].lListPointer);
		tsn_Wrapper_LockWait(gpLockHandle);
	}

	tsn_Wrapper_MemCpy(&stTmpExitTimer, &gGateParTbl[uchPort].stExitTimer, sizeof(TIME_EXTENTION));

	if (gGateParTbl[uchPort].nSendCompWaitCT > 0) {
		stSNS2.ulNsec_lsb = (USHORT)((ULONG)gGateParTbl[uchPort].nSendCompWaitCT * gGateParTbl[uchPort].ulMaxFrameTransTime);
		stSNS3.ulNsec_2nd = (ULONG)stTmpExitTimer.lHighTimeBit;
		stSNS3.ulNsec_lsb = stTmpExitTimer.ulLowTimeBit;
		ptpSubSNs_SNs(&stSNS3, &stSNS2, &stSNS3);
		if (stSNS3.sNsec_msb >= 0) {
			stTmpExitTimer.lHighTimeBit = (LONG)stSNS3.ulNsec_2nd;
			stTmpExitTimer.ulLowTimeBit = stSNS3.ulNsec_lsb;
		}
		else {
			stTmpExitTimer.lHighTimeBit = -1;
		}
		pstTraEntry = gTraClsSendWait[uchPort].pstTraClsNext;
		if ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTraEntry->uchTraClsNo-1))) == 0) {
			gGateParTbl[uchPort].stQueMaxSDU->ulTransOverrun++;
		}
	}

	for (uchLoop = 0; uchLoop < MAX_TRAFFIC_CLASS; uchLoop++) {
		pstTraEntry2 = gTraClsQueue[uchPort][uchLoop].pstTraClsNext;
		if (pstTraEntry2 != NULL) {
			while ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTraEntry2->uchTraClsNo-1))) != 0) {
				if (stTmpExitTimer.lHighTimeBit < 0L) {
					return (INT)RET_ENOERR;
				}
				else if ((stTmpExitTimer.lHighTimeBit == 0L)
					&& (stTmpExitTimer.ulLowTimeBit < gGateParTbl[uchPort].ulMaxFrameTransTime)) {
					return (INT)RET_ENOERR;
				}
				else if ((gTraClsQueue[uchPort][uchLoop].ulTotalDataSize + pstTraEntry2->usFramLen) <
					gGateParTbl[uchPort].stQueMaxSDU->ulQueMaxSDU) {

					gTraClsQueue[uchPort][uchLoop].pstTraClsNext = pstTraEntry2->pstTraClsNext;
					if (gTraClsQueue[uchPort][uchLoop].pstTraClsNext == NULL) {
						gTraClsQueue[uchPort][uchLoop].pstTraClsTail = NULL;
					}

					if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}
					else {
						pstTraEntry = gTraClsSendWait[uchPort].pstTraClsTail;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}

					nErrorCode = ethwrap_send(uchPort, pstTraEntry2->puchFramPtr, pstTraEntry2->usFramLen);
						
					if (nErrorCode == RET_ENOERR) {
						stSNS3.sNsec_msb = 0;
						gGateParTbl[uchPort].nSendCompWaitCT++;
						gTraClsQueue[uchPort][uchLoop].ulTotalDataSize += pstTraEntry2->usFramLen;
						stSNS3.ulNsec_2nd = (ULONG)stTmpExitTimer.lHighTimeBit;
						stSNS3.ulNsec_lsb = stTmpExitTimer.ulLowTimeBit;
						stSNS.sNsec_msb = 0;
						stSNS.ulNsec_2nd = 0UL;
						stSNS.ulNsec_lsb = gGateParTbl[uchPort].ulMaxFrameTransTime;
						ptpSubSNs_SNs(&stSNS3, &stSNS, &stSNS3);
						if (stSNS3.sNsec_msb >= 0) {
							stTmpExitTimer.lHighTimeBit = (LONG)stSNS3.ulNsec_2nd;
							stTmpExitTimer.ulLowTimeBit = stSNS3.ulNsec_lsb;
						}
						else {
							stTmpExitTimer.lHighTimeBit = -1;
						}
					}
					else {
						if (gTraClsSendWait[uchPort].pstTraClsNext == gTraClsSendWait[uchPort].pstTraClsTail) {
							gTraClsSendWait[uchPort].pstTraClsTail = NULL;
							gTraClsSendWait[uchPort].pstTraClsNext = NULL;
						}
						else {
							gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry;
							gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
						}

						if (pstTraEntry2->stSendCBFunc != NULL) {
							tsn_Wrapper_UnLock(gpLockHandle);
							(*(pstTraEntry2->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, pstTraEntry2->pvLinkId);
							tsn_Wrapper_LockWait(gpLockHandle);
						}

						if (pstTraEntry2->pvPacketId != 0) {
							tcpwrap_sbuffree(pstTraEntry2->pvPacketId);
							pstTraEntry2->pvPacketId = 0;
						}

						if (gGateParTbl[uchPort].usClassQueMax[pstTraEntry2->uchTraClsNo - 1u] != 0) {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u];
							gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u] = pstTraEntry2;
						}
						else {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr0;
							gpTraEntryRecPtr0 = pstTraEntry2;
						}
					}
				}
				else {
					return (INT)RET_ENOERR;
				}
				pstTraEntry2 = gTraClsQueue[uchPort][uchLoop].pstTraClsNext;
				if (pstTraEntry2 == NULL) {
					break;
				}
			}
		}
	}

	return (INT)RET_ENOERR;

}

INT qbv_SM_lex_cycl_scmp(UCHAR uchPort, VOID* pvPara)
{

	INT nLoop = 0;
	INT nErrorCode = 0;
	struct tagTRACLS_ENTRY* pstTraEntry = NULL;
	struct tagTRACLS_ENTRY* pstTraEntry2 = NULL;
	SCALEDNS stElapsedTime = {0};
	SCALEDNS stSNS = {0};
	SCALEDNS stSNS2 = {0};
	TIME_EXTENTION stTmpExitTimer = {0};

	UNREF_PARA(pvPara);

	pstTraEntry = gTraClsSendWait[uchPort].pstTraClsNext;
	gTraClsSendWait[uchPort].pstTraClsNext = pstTraEntry->pstTraClsNext;
	if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
		gTraClsSendWait[uchPort].pstTraClsTail = NULL;
	}

	
	if (pstTraEntry->pvPacketId != 0) {
		tcpwrap_sbuffree(pstTraEntry->pvPacketId);
		pstTraEntry->pvPacketId = 0;
	}

	if (gGateParTbl[uchPort].usClassQueMax[pstTraEntry->uchTraClsNo - 1u] != 0) {
		pstTraEntry->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTraEntry->uchTraClsNo - 1u];
		gpTraEntryRecPtr[uchPort][pstTraEntry->uchTraClsNo - 1u] = pstTraEntry;
	}
	else {
		pstTraEntry->pstTraClsNext = gpTraEntryRecPtr0;
		gpTraEntryRecPtr0 = pstTraEntry;
	}

	ptpSubETS_ETS(&gGateParTbl[uchPort].stCurrentTime, &gGateParTbl[uchPort].stBeforeTime, &stElapsedTime);
	stSNS.ulNsec_2nd = (ULONG)gGateParTbl[uchPort].stExitTimer.lHighTimeBit;
	stSNS.ulNsec_lsb = gGateParTbl[uchPort].stExitTimer.ulLowTimeBit;
	ptpSubSNs_SNs(&stSNS, &stElapsedTime, &stSNS);
	if (stSNS.sNsec_msb >= 0) {
		if (gGateParTbl[uchPort].nSendCompWaitCT > 0) {
			stSNS2.ulNsec_lsb = (USHORT)((ULONG)gGateParTbl[uchPort].nSendCompWaitCT * gGateParTbl[uchPort].ulMaxFrameTransTime);
			ptpSubSNs_SNs(&stSNS, &stSNS2, &stSNS);
		}
		stTmpExitTimer.lHighTimeBit = (LONG)stSNS.ulNsec_2nd;
		stTmpExitTimer.ulLowTimeBit = stSNS.ulNsec_lsb;
	}
	else {
		stTmpExitTimer.lHighTimeBit = -1;
	}

	for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
		pstTraEntry2 = gTraClsQueue[uchPort][nLoop].pstTraClsNext;
		if (pstTraEntry2 != NULL) {
			while ((gGateParTbl[uchPort].byOpeGateStates & (1 << (pstTraEntry2->uchTraClsNo-1))) != 0) {
				if (stTmpExitTimer.lHighTimeBit < 0L) {
					return (INT)RET_ENOERR;
				}
				else if ((stTmpExitTimer.lHighTimeBit == 0L)
					&& (stTmpExitTimer.ulLowTimeBit < gGateParTbl[uchPort].ulMaxFrameTransTime)) {
					return (INT)RET_ENOERR;
				}
				else if ((gTraClsQueue[uchPort][nLoop].ulTotalDataSize + pstTraEntry2->usFramLen) <
					gGateParTbl[uchPort].stQueMaxSDU->ulQueMaxSDU) {

					gTraClsQueue[uchPort][nLoop].pstTraClsNext = pstTraEntry2->pstTraClsNext;
					if (gTraClsQueue[uchPort][nLoop].pstTraClsNext == NULL) {
						gTraClsQueue[uchPort][nLoop].pstTraClsTail = NULL;
					}

					if (gTraClsSendWait[uchPort].pstTraClsNext == NULL) {
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}
					else {
						pstTraEntry = gTraClsSendWait[uchPort].pstTraClsTail;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry2;
						gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
					}

					nErrorCode = ethwrap_send(uchPort, pstTraEntry2->puchFramPtr, pstTraEntry2->usFramLen);

					if (nErrorCode == RET_ENOERR) {
						gGateParTbl[uchPort].nSendCompWaitCT++;
						gTraClsQueue[uchPort][nLoop].ulTotalDataSize += pstTraEntry2->usFramLen;
						stSNS.sNsec_msb = 0;
						stSNS.ulNsec_2nd = (ULONG)stTmpExitTimer.lHighTimeBit;
						stSNS.ulNsec_lsb = stTmpExitTimer.ulLowTimeBit;
						stSNS2.ulNsec_lsb = gGateParTbl[uchPort].ulMaxFrameTransTime;
						ptpSubSNs_SNs(&stSNS, &stSNS2, &stSNS);
						if (stSNS.sNsec_msb >= 0) {
							stTmpExitTimer.lHighTimeBit = (LONG)stSNS.ulNsec_2nd;
							stTmpExitTimer.ulLowTimeBit = stSNS.ulNsec_lsb;
						}
						else {
							stTmpExitTimer.lHighTimeBit = -1;
						}
					}
					else {
						if (gTraClsSendWait[uchPort].pstTraClsNext == gTraClsSendWait[uchPort].pstTraClsTail) {
							gTraClsSendWait[uchPort].pstTraClsTail = NULL;
							gTraClsSendWait[uchPort].pstTraClsNext = NULL;
						}
						else {
							gTraClsSendWait[uchPort].pstTraClsTail = pstTraEntry;
							gTraClsSendWait[uchPort].pstTraClsTail->pstTraClsNext = NULL;
						}

						if (pstTraEntry2->stSendCBFunc != NULL) {
							tsn_Wrapper_UnLock(gpLockHandle);
							(*(pstTraEntry2->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, pstTraEntry2->pvLinkId);
							tsn_Wrapper_LockWait(gpLockHandle);
						}
						
						if (pstTraEntry2->pvPacketId != 0) {
							tcpwrap_sbuffree(pstTraEntry2->pvPacketId);
							pstTraEntry2->pvPacketId = 0;
						}

						if (gGateParTbl[uchPort].usClassQueMax[pstTraEntry2->uchTraClsNo - 1u] != 0) {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u];
							gpTraEntryRecPtr[uchPort][pstTraEntry2->uchTraClsNo - 1u] = pstTraEntry2;
						}
						else {
							pstTraEntry2->pstTraClsNext = gpTraEntryRecPtr0;
							gpTraEntryRecPtr0 = pstTraEntry2;
						}
					}
				}
				else {
					return (INT)RET_ENOERR;
				}
				pstTraEntry2 = gTraClsQueue[uchPort][nLoop].pstTraClsNext;
				if (pstTraEntry2 == NULL) {
					break;
				}
			}
		}
	}

	return (INT)RET_ENOERR;

}


#define	MAX_CYCLE_TIME_SHIFT_TABLE	80

USCALEDNS	gstCycleTime_ShihtValue[MAX_CYCLE_TIME_SHIFT_TABLE];

INT make_CycleTime_ShifTbl(TIME_EXTENTION* pstCycleTime)
{
	USCALEDNS	stUSNS = {0};
	USCALEDNS*	pstCycleTime_ShiftValue = &gstCycleTime_ShihtValue[0];
	UCHAR		uchIndex;

	stUSNS.ulNsec_2nd = (ULONG)pstCycleTime->lHighTimeBit;
	stUSNS.ulNsec_lsb = pstCycleTime->ulLowTimeBit;

	for( uchIndex=0 ; uchIndex<MAX_CYCLE_TIME_SHIFT_TABLE; uchIndex++, pstCycleTime_ShiftValue++ )
	{
		ptpShiftUSNs_CHAR( &stUSNS, (UCHAR)uchIndex, pstCycleTime_ShiftValue );
	}

	return (INT)RET_ENOERR;
}


INT qbv_Calculat_CycleStartTime(
	EXTENDEDTIMESTAMP	*pstCurrentTime,
	EXTENDEDTIMESTAMP	*pstBaseTime,
	TIME_EXTENTION		*pstCycleTime,
	EXTENDEDTIMESTAMP	*pstCycleStartTime
)
{
	USCALEDNS	stUSNS_Cycle = {0};
	USCALEDNS	stUSNS_Remind;
	USCALEDNS	stUSNS_Start;
	UINT		unIndex;
	USCALEDNS*	pstCycleTime_ShiftValue = &gstCycleTime_ShihtValue[0];
	CHAR		chRet;

	SCALEDNS	stSNS_Remind;

	ptpConvETS_USNs(pstCurrentTime, &stUSNS_Remind );

	stUSNS_Cycle.ulNsec_2nd = pstCycleTime->lHighTimeBit;
	stUSNS_Cycle.ulNsec_lsb = pstCycleTime->ulLowTimeBit;

	ptpConvETS_USNs( pstBaseTime, &stUSNS_Start );
	ptpSubETS_ETS( pstCurrentTime, pstBaseTime, &stSNS_Remind  );
	ptpConvSNs_USNs( &stSNS_Remind, &stUSNS_Remind  );

	make_CycleTime_ShifTbl(pstCycleTime);

	while(1)
	{
		chRet = ptpCompUSNs_USNs( &stUSNS_Remind, &stUSNS_Cycle);
		if( chRet <= COMP_EQUAL )
		{
			ptpAddUSNs_USNs( &stUSNS_Start, &stUSNS_Cycle, &stUSNS_Start );
			break;
		}
		else
		{
			for (	unIndex=0, pstCycleTime_ShiftValue=gstCycleTime_ShihtValue ;
					unIndex<MAX_CYCLE_TIME_SHIFT_TABLE ;
					unIndex++, pstCycleTime_ShiftValue++  )
			{
				chRet = ptpCompUSNs_USNs( &stUSNS_Remind, pstCycleTime_ShiftValue);
				if( chRet < COMP_EQUAL )
				{
					pstCycleTime_ShiftValue--;
					ptpSubUSNs_USNs( &stUSNS_Remind, pstCycleTime_ShiftValue, (SCALEDNS*)&stUSNS_Remind );
					ptpAddUSNs_USNs( &stUSNS_Start, pstCycleTime_ShiftValue, &stUSNS_Start );
					break;
				}
			}
		}
	}
	ptpConvUSNs_ETS( &stUSNS_Start , pstCycleStartTime);

	return (INT)RET_ENOERR;
}

