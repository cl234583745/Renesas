//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _USS_SNMPCONF_H_
#define _USS_SNMPCONF_H_


#define ENTERPRISE 51496
#define SNMP_IP "192.168.133.3"
#define SYSCONTACT ""
#define SYSLOCATION ""
#define SYSDESCR ""
#define SYSNAME ""
#define IFSPEED 1000000000
#define ENABLEAUTHENTRAPSVAL 2
#define MAXOID 15
#define MAXKEY 7
#define MAXKLEN 22
#define MAXVAR 100
#define SNMP_MAXSIZE (1500 + 150)

#endif
