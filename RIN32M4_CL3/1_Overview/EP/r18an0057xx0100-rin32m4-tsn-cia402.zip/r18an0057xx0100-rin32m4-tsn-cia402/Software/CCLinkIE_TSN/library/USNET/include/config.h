//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_CONFIG_H_
#define _USS_CONFIG_H_




#ifndef _USS_UCONSTS_H
#include "uconsts.h"
#endif


#ifndef FAR
#define FAR
#endif


#define NTRACE       0

#define GARP 

#define USSW_LLDP
#define USSW_LLDPD
#define USSW_LLDP_MIB
#define MIB2

#define MAXPFLEN 260

#endif
