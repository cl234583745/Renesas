/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_LCENTITY_GD_H__
#define __PTP_LCENTITY_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




 

#define		RET_ENOERR	(0)
#define		RET_EINVAL	(1)




typedef	enum	tagEN_ST_LCE {
	ST_LCE_NONE	= 0,
	ST_LCE_INITIALIZING,
	ST_LCE_RECEIVED_TICK,
	ST_LCE_MAX
} EN_ST_LCE;

typedef	enum	tagEN_EV_LCE {
	EV_LCE_BEGIN = 0,
	EV_LCE_TICK,
	EV_LCE_CLOSE,
	EV_LCE_EVENT_MAX
} EN_EV_LCE;




typedef	struct tagLCENTITYSM_GD
{
	EN_ST_LCE			enStatusLCE;

} LCENTITYSM_GD;	




#endif


