//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#include	<string.h>

#include	"net.h"
#include	"local.h"
#include	"support.h"
#include	"ethernet.h"
#include	"driver.h"
#include	"netdrv.h"
#include	"snmpv3.h"


static int writE(int conno, MESS *mess);
static int opeN(int conno, int flag);
static int closE(int conno);
static void shut(int netno);
static int init(int netno, char *params);
static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size);

extern const AGENT_CONTEXT snmp_ac;







static int init( int netno, char *params )
{
    (void)netno;
    (void)params;
	return 0;
}


static void shut( int netno )
{
	(void)netno;



	return;
}


static int opeN( int conno, int flag )
{
	(void)conno;
	(void)flag;
	return 0;
}


static int closE( int conno )
{
	(void)conno;
	return 0;
}


static int writE( int netno, MESS *mess )
{

	struct NET		*netp;
	int				iStat = ENOBUFS;

	int				iPort;


	netp  = &(nets[netno]);

	mess->offset = netno;

	DISABLE();

	iPort = mess->portno;

	if ( QUEUE_FULL( netp, depart[iPort] )) {

		ENABLE();
		mess->offset = boTXDONE;
		netp->ifOutDiscards++;

		return iStat;
	}
	else {
		QUEUE_IN( netp, depart[iPort], mess );
		iStat = 0;
	}
	ENABLE();

	return iStat;
}


static int ioctl( void *handle, enum ioctlreq request, void *arg, size_t size )
{

	int result = 0;

	(void)handle;
	(void)request;
	(void)arg;

	(void)size;
	
	return result;
}


GLOBALCONST PTABLE ussNetDrvTable =
{
    "CC-Link IE TSN",
    init,
    shut,
    0,
    opeN,
    closE,
    0,
    writE,
    ioctl,
    0,
    MESSH_SZ
};



unsigned long gulNTDRV_TransmitGetPacket( int iPort, unsigned char **puchPacket )
{
	MESS				*mess;
	unsigned long		ulLength = 0;
	struct				NET *netp;
	int					i;
	
	netp = &nets[0];
	
	if ( QUEUE_EMPTY( netp, depart[iPort] ) ) {
	}
	else {
		QUEUE_OUT( netp, depart[iPort], mess );
		ulLength = (unsigned long)(mess->mlen - MESSH_SZ);
		*puchPacket = (unsigned char *)mess + MESSH_SZ;
	}

	return ulLength;
}



void gNTDRV_TransmitComplete( int iPort, unsigned char *puchPacket, unsigned long ulPacketLength )
{
	MESS		*mess = NULL;
	struct NET	*netp;
	int			i;

	if ( puchPacket == NULL ) {
		return;
	}

	mess = (MESS *)( puchPacket - MESSH_SZ );
	mess->offset = boTXDONE;
	if ( mess->id <= bWACK ) {
		if ( mess->id == bRELEASE ) {
			mess->id = bALLOC;
			NrelbufIR( mess );
		}
	}

	return;
}


unsigned char *gpuchNTDRV_ReceiveGetPacket( int iPort, unsigned long ulPacketLength )
{
	MESS		*mess = NULL;
	struct NET	*netp;
	int			i;
	
	if (( MAXBUF - MESSH_SZ ) < ulPacketLength ) {
		return 0;
	}
	netp = &nets[0];
	if ( QUEUE_FULL( netp, arrive )) {
		return 0;
	}

	if (( mess = NgetbufIR()) == 0 ) {
		return 0;
	}

    return (unsigned char*)mess + MESSH_SZ;

}



void gNTDRV_ReceiveComplete( int iPort, unsigned char *puchPacket, unsigned long ulPacketLength )
{
	MESS		*mess = NULL;
	struct NET	*netp;
	int			i;

	if ( puchPacket == NULL ) {
		return;
	}

	netp = &nets[0];
	mess = (MESS *)( puchPacket - MESSH_SZ );
	mess->mlen = ulPacketLength + MESSH_SZ;
	mess->offset = MESSH_SZ;
	mess->netno = 0;
	mess->portno = iPort;
	QUEUE_IN( netp, arrive, mess );

	return;
}

void vNTDRV_SnmpAgentInit(void)
{
	(void)ussSNMPAgentInit(&snmp_ac);
	return;
}

