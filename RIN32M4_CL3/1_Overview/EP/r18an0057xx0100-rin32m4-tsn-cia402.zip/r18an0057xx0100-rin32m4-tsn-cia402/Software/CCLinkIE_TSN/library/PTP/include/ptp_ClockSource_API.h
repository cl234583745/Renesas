/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CS_API_H__
#define __PTP_CS_API_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_api.h"





#ifdef __cplusplus
extern "C" {
#endif

INT ptp_clockSourceSetTime(CLKSOURCETIME *pstClkSrcTime);
INT	ptp_clockSourceSetInfo(CLKSOURCEINFO *pstClkSrcInfo);

#ifdef __cplusplus
}
#endif


#endif


