/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifndef QBV_GLOBAL_H
#define QBV_GLOBAL_H

#include "qbv_Macro.h"
#include "qbv_api.h"


extern GATE_PARATBL				gGateParTbl[MAX_PORT];
extern TRACLS_QUEUE				gTraClsQueue[MAX_PORT][MAX_TRAFFIC_CLASS];
extern TRACLS_QUEUE				gTraClsSendWait[MAX_PORT];
extern QBV_INFTBL				gQbvInfTbl;
extern TRACLS_ENTRY				gTraEntryMem[MAX_TRACLS_ENTRY];
extern struct tagTRACLS_ENTRY* 	gpTraEntryRecPtr0;
extern struct tagTRACLS_ENTRY* 	gpTraEntryRecPtr[MAX_PORT][MAX_TRAFFIC_CLASS];
extern VOID*					gpLockHandle;

#endif
