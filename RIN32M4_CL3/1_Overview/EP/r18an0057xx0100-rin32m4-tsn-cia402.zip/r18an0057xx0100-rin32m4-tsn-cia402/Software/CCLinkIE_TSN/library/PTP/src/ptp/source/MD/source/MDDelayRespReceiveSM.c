/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDDelayRespReceiveSM.h"
#ifdef	PTP_USE_IEEE1588
#include "MDDelayRespReceiveSM_1588.h"
#endif


VOID MDDelayRespReceiveSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDDelayRespReceiveSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM, PTP_LOGVE_82000002);
	return;
}

MDDRESPRVSM_GD*	GetMDDRespRcvSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDDRespRcvSM_GD;
}

MDDRESPRCVSM_EV GetMDDRespRcvEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDDRESPRCVSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDDRPR_E_BEGIN;
		break;
		case PTP_EV_RCVD_DELAY_RESP:
			enEvt = MDDRPR_E_RCVD_DELAY_RESP;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDDRPR_E_CLOSE;
		break;

		default:
			enEvt = MDDRPR_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDDRESPRCVSM_ST GetMDDRespRcvStatus(PORTDATA* pstPort)
{
	MDDRESPRVSM_GD*	pstGbl = NULL;
	MDDRESPRCVSM_ST	enSts = MDDRPR_STATUS_MAX;

	pstGbl = GetMDDRespRcvSMGlobal(pstPort);

	if (pstGbl->enStsMDDRespRcv < MDDRPR_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDDRespRcv;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDDRespRcvStatus(MDDRESPRCVSM_ST enSts, PORTDATA* pstPort)
{
	MDDRESPRVSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDRespRcvSMGlobal(pstPort);

	pstGbl->enStsMDDRespRcv = enSts;
	return;
}
