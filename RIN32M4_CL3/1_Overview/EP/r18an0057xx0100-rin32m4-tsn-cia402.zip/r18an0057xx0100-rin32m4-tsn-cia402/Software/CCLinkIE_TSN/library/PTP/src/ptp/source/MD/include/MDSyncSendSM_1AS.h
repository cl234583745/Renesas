/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCSENDSM_1AS_H__
#define __MDSYNCSENDSM_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDSyncSendSM_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID MDSyncSendSM_00_1AS(PORTDATA* pstPort);
VOID MDSyncSendSM_01_1AS(PORTDATA* pstPort);
VOID MDSyncSendSM_02_1AS(PORTDATA* pstPort);
VOID MDSyncSendSM_03_1AS(PORTDATA* pstPort);
VOID MDSyncSendSM_04_1AS(PORTDATA* pstPort);
VOID MDSyncSendSM_NP_1AS(PORTDATA* pstPort);

BOOL MDSynSnd_Initial_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_SyncTwoStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_FollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_SyncOneStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynSnd_StCrectionField_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetSyncTwoStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetSyncOneStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxSync_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetFollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxFollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifndef PTP_USE_SIGNALING
VOID syncIntSet_1AS(PORTDATA* pstPort);
VOID oneStepTxOpSet_1AS(PORTDATA* pstPort);
#endif

#ifdef __cplusplus
}
#endif

#endif
