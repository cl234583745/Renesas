//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"

#define USS_KEEP_HOSTS

#define NHOPS 8

#define NETKNOWN   0
#define DEFAULTGW  1
#define BLINDFAITH 4

extern struct NETCONF netconf[];
extern const int confsiz;
#ifdef DNS
extern Iid      DNSiid[2];
#endif

unsigned char   cqfirst,
                cqlast;

int             BuildRoutes(void)
{
    int             i1,
                    i2,
                    i3,
                    i4,
                    uix,
                    confix,
                    confix2,
                    maxhop,
                    fnode,
                    sfnode,
                    netno,
                    hops,
                    remix;
    int             routerix,
                    routernet,
                    routerhops;
    int             hix[NHOPS * 2];
    Iid             iid,
                    hiid[NCONFIGS];
    struct NETCONF *confp,
                   *confp2,
                   *confp3,
                   *confp4;

    for (maxhop = confix = fnode = 0; confix < NCONFIGS; confix++) {
        confp2 = confp = &netconf[confix];
        if (confp->ncstat == 0)
            continue;
#ifdef  INET6
        if ((confp->ipv6.flags6 & ENABLE6) != 0)
            continue;
#endif

        confp->flags &= ~NODE;

        if (confp->Iaddr.l == 0) {
            for (confix2 = 0; confix2 < NCONFIGS; confix2++) {
                confp2 = &netconf[confix2];
#ifdef  INET6
                if ((confp2->ipv6.flags6 & ENABLE6) != 0)
                    continue;
#endif
                if (confp->Imask.l != confp2->Imask.l)
                    continue;

                if (confp2 == confp)
                    continue;

                if (strcmp(confp->pname, confp2->pname) != 0)
                    continue;

                goto lab11;
            }
            continue;
        }

lab11:  iid.l = confp2->Iaddr.l & confp2->Imask.l;

        for (confix2 = 0; confix2 < NCONFIGS; confix2++) {
            if (confix == confix2)
                continue;
            confp2 = &netconf[confix2];
            if (confp2->ncstat == 0)
                continue;
#ifdef  INET6
            if ((confp2->ipv6.flags6 & ENABLE6) != 0)
                continue;
#endif
            if (strlen(confp->name) != 0 &&
                strcmp(confp->name, confp2->name) == 0)
                confp->flags |= NODE;
        }

        for (i2 = 0; i2 < maxhop; i2++)
            if (iid.l == hiid[i2].l)
                goto cnt3;
        hiid[maxhop++] = iid;
cnt3:
        confp->nlstat = i2;

#ifdef DNS
        if ((confp->flags & DNSVER) && fnode < 2)
            memcpy((char *) &DNSiid[fnode++], confp->Iaddr.c, sizeof(Iid));
#endif
    }
    maxhop <<= 1;

    if (netconf[NCONFIGS - 1].cqprev == 0) {
        i1 = confsiz;
        for (confix = NCONFIGS - 1; confix >= confsiz; confix--) {
            confp = &netconf[confix];
            netconf[i1].cqnext = confix;
            confp->cqprev = i1;
            confp->gnid = 0;
            i1 = confix;
        }
        cqfirst = NCONFIGS - 1;
        cqlast = i1;
    }

    for (remix = 0; remix < NCONFIGS; remix++) {

        confp3 = &netconf[remix];
#ifdef  INET6
        if ((confp3->ipv6.flags6 & ENABLE6) != 0)
            continue;
#endif
        if ( confp3->hops >= 0xFD ) {
            hix[2] = confp3->nexthix;
            if (netconf[confp3->nexthix].flags & ROUTER) {
                 hix[2] = confp3->nexthix;
                 netno = confp3->netno;
                 hops  = confp3->hops << 1;
            }
            else {
                 netno = 255;
                 hops  = 510;
            }
            goto lab6;
        }

        if (confp3->ncstat == 0)
            continue;
        if (confp3->flags & LOCALHOST){
            confp3->nexthix = remix;
            continue;
        }

       if (netconf[remix].flags & NODE)
           goto conrem;
       for(i1 = 0; i1 < NCONFIGS; i1++)
           if ( (netconf[remix].nlstat == netconf[i1].nlstat) && (i1 != remix)
                 && (netconf[i1].flags & (NODE | LOCALHOST)) )
                 goto conect;

       if ((confp3->hops != 0) && (netconf[confp3->nexthix].flags & ROUTER)) {
            hix[2] = confp3->nexthix;
            netno = confp3->netno;
            hops  = confp3->hops << 1;
            goto lab6;
       }

       goto discon;

conrem:
       for (i2 = 0; i2 < remix; i2++)
           if (strlen(netconf[remix].name) != 0 &&
               strcmp(netconf[i2].name, netconf[remix].name) == 0) {
                hix[2] = netconf[i2].nexthix;
                hops  = netconf[i2].hops*2;
                netno = netconf[i2].netno;
                goto lab6;
           }

conect:
       fnode = 0;
       while ((netconf[fnode].flags & (NODE | LOCALHOST)) != NODE ||
               netconf[fnode].ncstat == 0 ||
               fnode == remix ||
               strcmp(netconf[fnode].name,netconf[remix].name) == 0 ) {
            fnode++;
            if (fnode >= NCONFIGS) {
                fnode = 0;
                break;
            }
       }
       sfnode = fnode;

       for (hix[2] = remix, hops = 2; hops <= maxhop; hops += 2) {
            hix[hops] = remix;

            for (hix[1] = 0; hix[1] < NCONFIGS; hix[1]++, fnode = sfnode) {
                confp4 = &netconf[hix[1]];
                if (confp4->ncstat == 0 || (confp4->flags & LOCALHOST) == 0)
                   continue;

                netno = confp4->netno;
nexttry:        uix = 2;
                for (i2 = 2; i2 < hops; i2++)
                   hix[i2] = fnode;
                goto lab2;

nxt2:           uix = i2;
                i1 = (hix[i2] + 1) % NCONFIGS;
                for (i4 = 1; i4 <= hops; i4++){
                   if (i1 == fnode)
                      goto nxtfnode;
                   if ( i1 == hix[i4] ||
                        (netconf[i1].flags & (NODE | LOCALHOST)) != NODE ||
                         netconf[i1].ncstat == 0 ){
                      ++i1;
                      i1 = i1 % NCONFIGS;
                      i4 = 0;
                   }
                }
                hix[i2] = i1;
lab2:
                for (i2 = (uix & 1) ? uix - 1 : uix; i2 < hops; i2 += 2) {
                  if ((netconf[hix[i2]].nlstat != netconf[hix[i2 - 1]].nlstat)
                       || ( hix[i2] == hix[i2 - 1]) )
                       goto nxt2;

                  if ( (strcmp(netconf[hix[i2 + 1]].name,
                               netconf[hix[i2]].name) )
                         || (hix[i2] == hix[i2 + 1]) ){
                       i2++;
                       goto nxt2;
                  }
                }
                i1 = hix[hops - 1];
                if (i1 != remix && netconf[i1].nlstat == confp3->nlstat) {
                    goto lab6;
                }
                for (i3 = 0; i3 < NCONFIGS; i3++)
                   if ( (netconf[i3].nlstat == netconf[i1].nlstat) &&
                        (strlen(netconf[remix].name) != 0 &&
                         strcmp(netconf[i3].name,netconf[remix].name) == 0)) {
                      i4 = i3;
                      do {
                         if( (hix[1] != i4) &&
                              (netconf[hix[1]].nlstat == netconf[i4].nlstat) )
                              if ( hops == 2 ||
                                   (strlen(netconf[hix[3]].name) != 0 &&
                                    strcmp(netconf[hix[3]].name,
                                    netconf[i4].name) == 0) ) {
                                  hix[2] = i4;
                                  break;
                              }
                         i4 = (i4 + 1) % NCONFIGS;
                      }
                      while (i4 != i3);
                      goto lab6;
                   }
                if (hops > 2){
                  if (fnode >= NCONFIGS)
                         goto nexthix;
                  i2 = hops - 1;
                   goto nxt2;
                }

nxtfnode:
                if (hops > 2) {
                  fnode++;
                  while((netconf[fnode].flags & (NODE | LOCALHOST)) != NODE
                         || netconf[fnode].ncstat == 0 || fnode == remix ||
                            strcmp(netconf[fnode].name,
                                   netconf[remix].name) == 0 ){
                      if (fnode >= NCONFIGS)
                         goto nexthix;
                      fnode++;
                  }
                   goto nexttry;
                }
nexthix:        ;
            }
       }
discon:
       routerix = -1, routernet = -1, routerhops = -1;
       for (i1 = 0; i1 < NCONFIGS && routerix < 0 ; i1++) {
           if ((strcmp(confp3->pname, netconf[i1].pname) == 0) &&
               (netconf[i1].flags & ROUTER)) {
               routerix = i1;
               routernet = netconf[i1].netno;
               routerhops -= 1;
               break;
           }
       }
       hops = routerhops*2;
       netno = routernet;
       hix[2] = routerix;
lab6:  confp3->hops = hops >> 1;
       confp3->netno = netno;
       confp3->nexthix = hix[2];
    }
    return 0;
}

int             GetHostData(unsigned long iidl, int flag, unsigned char netno)
{
    int             i1,
                    i2,
                    cntidx,
                    found_idx,
                    idx,
                    confix,
                    routflg;
    unsigned long   ul1;
    struct NETCONF *confp,
                   *confp2;
#ifdef NAT
    struct NET     *netp;
#endif

    if (iidl == 0)
        return -1;
    if (iidl == 0xffffffff) {
        if (flag & 2)
            return -1;
        return ussBroadcastIndex;
    }
#if USS_IP_MC_LEVEL
    else if (USS_ISCLASSD(iidl)) {
        if ((flag & 4) == 0)
            return ussMulticastIndex;
        else
            return -1;
    }
#endif

again:
    for (confix = 0; confix < NCONFIGS; confix++) {
        confp = &netconf[confix];
        if (confp->ncstat == 0)
            continue;
#ifdef  INET6
        if ((confp->ipv6.flags6 & ENABLE6) != 0)
            continue;
#endif
        ul1 = confp->Iaddr.l;
        if (iidl != ul1)
            continue;
refresh:
        if (confp->ncstat == 3) {
            BLOCKPREE();
            if (confp->Iaddr.l != ul1) {
                RESUMEPREE();
                goto again;
            }
            if (confix != cqfirst) {
                netconf[(unsigned int)confp->cqprev].cqnext = confp->cqnext;
                if (confix != cqlast)
                    netconf[(unsigned int)confp->cqnext].cqprev = confp->cqprev;
                else
                    cqlast = confp->cqprev;
                netconf[cqlast].cqnext = netconf[cqfirst].cqprev = confix;
                confp->cqnext = cqfirst;
                confp->cqprev = cqlast;
                cqfirst = confix;
            }
            RESUMEPREE();
        }
        if (confp->netno == 255 && (flag & 0x10) == 0)
            return -1;
#ifdef NAT
        if (confp->netno == 255) {
            netp = &nets[netno];
            if (netconf[netp->confix].flags & NATLOCAL) {
                confp->netno = netconf[confp->nexthix].netno;
            }
        }
        return confix;
#else
        return confix;
#endif
    }

    routflg = NETKNOWN;

    for (i1 = 0, i2 = 255; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->ncstat == 0)
            continue;
#ifdef  INET6
        if ((confp->ipv6.flags6 & ENABLE6) != 0)
            continue;
#endif
        if (confp->Imask.l == 0)
            continue;
        if ((iidl & confp->Imask.l) != (confp->Iaddr.l & confp->Imask.l))
            continue;
#ifdef NAT
        if (confp->netno != netno) {

            netp = &nets[netno];
            if (!(netconf[netp->confix].flags & NATLOCAL) &&
                !(netconf[nets[confp->netno].confix].flags & NATLOCAL)) {
                continue;
            }
            else {
                netno = confp->netno;
            }

        }
#endif
        if (confp->hops < (unsigned int) i2)
            confix = i1, i2 = confp->hops;
    }
    if (i2 < 255) {
        confp2 = &netconf[confix];
        ul1 = confp2->Iaddr.l;
        if ((iidl | confp2->Imask.l) == 0xffffffff) {
            if (flag & 2)
                return -1;
            if (confp2->hops < 2)
                return ussBroadcastIndex;
            confp = confp2;
            goto refresh;
        }
        goto lab6;
    }
    if (flag & 8)
        return -1;
    routflg = DEFAULTGW;
    for (confix = 0; confix < NCONFIGS; confix++) {
        confp2 = &netconf[confix];
        if (confp2->ncstat == 0)
            continue;
#ifdef  INET6
        if ((confp2->ipv6.flags6 & ENABLE6) != 0)
            continue;
#endif
        if ((confp2->flags & ROUTER) == 0)
            continue;
#ifdef NAT
        if (confp2->netno != netno) {
            netp = &nets[netno];
            if ((netconf[netp->confix].flags & NATLOCAL) ||
                (netconf[nets[confp2->netno].confix].flags & NATLOCAL))
                netno = confp2->netno;
            else
                continue;
        }
#else
        if (flag & 0x20) {
            if (confp2->netno == netno)
                continue;
            netno = confp2->netno;
        }
        else {
            if (confp2->netno != netno)
                continue;
        }
#endif
        goto lab6;
    }

    if (((flag & 4) == 0) || (flag & 0x20))
        return -1;
    routflg = BLINDFAITH;

lab6:
    if ((flag & 1) == 0)
        return -1;

    cntidx = 0;
    BLOCKPREE();
next_idx:
    cntidx++;
    confix = cqlast;
    confp = &netconf[confix];
    found_idx = 0;

    if ( confp->ncstat != 0 ) {
      for ( idx = cqfirst;
           (idx != confix) && !found_idx;
            idx = netconf[idx].cqnext) {
        if( netconf[idx].ncstat == 0 )
          continue;
        found_idx = (confix == netconf[idx].nexthix );
      }
    }

    cqlast = confp->cqprev;
    confp->cqnext = cqfirst;
    netconf[cqfirst].cqprev = confix;
    cqfirst = confix;
    if ( cntidx < ( NCONFIGS - confsiz ) ) {
      if ( found_idx ||
#ifdef  INET6
          (confp->ipv6.flags6 & ROUTER6) ||
#endif
          ussHostUsed(confix)) {
        goto next_idx;
      }
    }
    RESUMEPREE();

    if ( ussHostUsed(confix) ) {
      return -1;
    }

    confp->Iaddr.l = iidl;
    confp->name[0] = confp->pname[0] = 0;
    confp->Imask.l = 0;
    for ( i1 = 0; i1 < 6; i1++ ) {
        confp->Eaddr.c[i1] = 0;
    }
#ifdef  INET6
    memset((char *)&confp->ipv6.I6addr, 0, I6id_SZ);
    confp->ipv6.flags6  = 0;
    confp->ipv6.ndstate = 0;
    confp->ipv6.ndcount = 0;
#endif
    if (routflg == BLINDFAITH) {
        confp->Imask.l = 0xffffffff;
        confp->nexthix = 255;
    } else {
        if (routflg) {
            confp->hops = confp2->hops + 1;
        }
        else {
            strcpy(confp->pname, confp2->pname);
            confp->Imask = confp2->Imask;
            confp->hops = confp2->hops;
        }
        if (confp->hops <= 1) {
            confp->hwaddyes = 0;
            confp->nexthix = confix;
            confp->netno = confp2->netno;
        } else {
            confp->nexthix = confp2->nexthix;
            confp->netno = netno;
        }
    }
    confp->ncstat = 3;
    return confix;
}


void ussHostAcquire(int confix){
#ifdef USS_KEEP_HOSTS

  struct NETCONF *confp;

  if( confix >= NCONFIGS ) return;
  confp = &netconf[confix];
  if( confp->ncstat == 0 ||
      confp->ncstat == 4 )
    return;
  if( confp->gnid >= NCONNS ||
      confp->gnid >= 255 )
    return;
  confp->gnid++;
  if( confix != confp->nexthix)
    netconf[confp->nexthix].gnid++;

#endif
  return;
}


void ussHostRelease(int confix){
#ifdef USS_KEEP_HOSTS

  struct NETCONF *confp;

  if( confix >= NCONFIGS ) return;
  confp = &netconf[confix];
  if( confp->ncstat == 0 ||
      confp->ncstat == 4 ||
      confp->gnid == 0 )
    return;
  confp->gnid--;
  if( confix != confp->nexthix)
    netconf[confp->nexthix].gnid--;

#endif
  return;
}


int ussHostUsed(int confix){
#ifdef USS_KEEP_HOSTS

  if( confix >= NCONFIGS ||
      netconf[confix].ncstat == 4 )
    return(-1);
  return ( netconf[confix].gnid );

#else

  return(0);

#endif
}
