//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_SUPPORT_H_
#define _USS_SUPPORT_H_

#define MESSH_SZ ((sizeof(MESS)+USSBUFALIGN-1)&~(USSBUFALIGN-1))


#if USS_IP_MC_LEVEL == 2
#define IGMP
#endif



#define SIG_RC(conno) (conno+conno+EVBASE)
#define SIG_CC(conno) (conno+conno+1+EVBASE)
#define SIG_RN(netno) (2*netno+2*NCONNS+EVBASE)
#define SIG_WN(netno) (2*netno+2*NCONNS+1+EVBASE)
#define SIG_ARP (2*(NCONNS+NNETS)+EVBASE)
#define SIG_GEN (2*(NCONNS+NNETS)+1+EVBASE)
#define SIG_SEL (2*(NCONNS+NNETS)+2+EVBASE)
#ifdef  INET6
#define SIG_ND6 (2*(NCONNS+NNETS)+3+EVBASE)
#endif

#include <mtmacro.h>
#if MT == 0
void            NetTask(int netno);
#else
TASKFUNCTION    NetTask(void);
#endif


struct NET {
    int             netstat;
    PTABLE         *protoc[3];
    unsigned char   confix;
    char            sndoff;
    unsigned long   tout;
    int             maxblo;
    int             nettasktout;
    char            cflags;
    char            worktodo;
    unsigned char   none1;
    unsigned char   state;
    struct FIFOQ16  arrive;
    MESS           *fragmq;
    MESS           *fragmh;
    int             irno[4];
    int             port;
    char FAR       *base[2];
    struct Eid      id;
    unsigned char   netno;
    char            hwflags[2];
    MESS           *bufbas;
    MESS           *bufbaso;
    struct FIFOQ16  depart[2];
    long            bps;
#ifdef DHCP
    unsigned long   DHCPserver;
    unsigned long   LeaseTime;
    unsigned long   RenewalTime;
    unsigned long   RebindingTime;
    unsigned long   DHCPsecs;
#endif
    char           *ifDescr;
    int             ifType;
    int             ifAdminStatus;
#if (defined(MIB2) || defined(LQRP))
    unsigned long   ifLastChange;
    unsigned long   ifInOctets;
    unsigned long   ifInUcastPkts;
    unsigned long   ifInNUcastPkts;
#endif
    unsigned long   ifInDiscards;
    unsigned long   ifInErrors;
#if (defined(MIB2) || defined(LQRP))
    unsigned long   ifInUnknownProtos;
    unsigned long   ifOutOctets;
    unsigned long   ifOutUcastPkts;
    unsigned long   ifOutNUcastPkts;
#endif
    unsigned long   ifOutDiscards;
    unsigned long   ifOutErrors;
#ifdef LQRP
    unsigned long   ownLQRPms;
    unsigned long   peerLQRPms;
    char            lastins[32];
    unsigned long   OutLQRs;
    unsigned long   InLQRs;
    unsigned long   InGoodOctets;
#endif
    struct SERIAL {
        unsigned long   ul1,
                        ul2;
        unsigned long   timems;
        void            (*comec) (int, struct NET *);
        int             (*goingc) (struct NET *);
        char           *bufin;
        char           *buflim;
        char           *bufout;
        char            baudctl[2];
        int             chsout;
        unsigned char   lastin;
        unsigned char   nxtout;
        char opt1, opt2, opt3, opt4;
        char opt5, opt6, opt7, opt8;
#ifdef PPP
        unsigned short locopts, remopts;
        char *userid, *passwd;
        unsigned char *script, *sp;
        unsigned short st;
        unsigned long mnum, idle_time, idle_wait, echo_time, raccm;
    } hw;
    struct FIFOQ16 future;
    Iid haddr, raddr;
#else
    } hw;
#endif
#ifdef  INET6
    struct NET6 ipv6;
#endif
};

struct NETCONF {
    char            name[9];
    char            pname[9];
    Iid             Imask;
    Iid             Iaddr;
    struct Eid      Eaddr;
    short           flags;
    char            ncstat;
    unsigned char   cqnext,
                    cqprev;
    unsigned char   netno;
    unsigned char   hops;
    unsigned char   nexthix;
    unsigned char   gnid;
    char            hwaddyes;
#ifdef ARP
    char            ARPwait;
    MESS           *ARPwaitmp;
#endif
#ifdef GARP
    char            Iconflict[2];
#endif
    unsigned long   timems;
    unsigned char   nlstat;
#ifdef  INET6
    struct NETCONF6 ipv6;
#endif
};

struct CONNECT {
    char            blockstat;
    short            txstat;
    short            rxstat;
    char            state;
    struct CONNECT *next;
    int             backlog;
    int             icqcur;
    unsigned char   sendack;
    unsigned char   netno;
    unsigned char   confix;
    unsigned char   routeidx;
    unsigned char   arpidx;
    char            tcpflags;
    unsigned long   rxtout;
    unsigned long   txtout;
    long            txvar,
                    txave;
    unsigned long   txseq;
    unsigned long   rxseq;
    unsigned long   ackno;
    unsigned long   seqtoack;
    unsigned long   ackdseq;
    unsigned long   acktime;
    unsigned long   unackseq;
    MESS           *first,
                   *last;
    MESS           *wackf,
                   *wackl;
    unsigned char   ninque;
    unsigned char   nwacks;
    unsigned char   wackmax;
    unsigned char   wackslow;
    MESS           *future;
    PTABLE         *protoc[5];
    int             myport;
    int             herport;
    Iid             heriid;
    Iid             realiid;
    Iid             offerediid;
    unsigned int    window;
    unsigned int    mywindow;
    unsigned int    prevwindow;
    unsigned int    maxdat;
    unsigned int    doffset;
    unsigned long   lastrxtime;
    char            urgflag;
    char            urgdata;
    unsigned short  pseudosum;
    unsigned short  frid;
#ifdef IPOPTIONS
    char            IPOtxlen;
    char            IPOrxlen;
    unsigned char   IPOrxsrlen;
    char            none1;
    char            IPOtxopt[40];
    char            IPOrxopt[40];
    char            IPOrxsropt[40];
#endif
#ifdef TCP_OPTIONS
    char            TCPOtxlen;
    char            TCPOrxlen;
    char            TCPOtxopt[40];
    char            TCPOrxopt[40];
#endif
    int             urgcnt;
    unsigned long   urgseq;
    MESS           *ostreamb;
    MESS           *istreamb;
    int             istreamc;
    char           *istreamp;
    int             refcount;
    char            passive;
    char            refsock;
    int             l_linger;
#ifdef  INET6
    struct CONNECT6 ipv6;
#endif
    int             portno;
};
#define S_FIN   0x01
#define S_MON   0x02
#define S_KEEPA 0x04
#define S_PSH   0x08
#define S_NOCON 0x10
#define S_URG   0x20
#define S_STRM  0x40
#define S_NOWA  0x80
#define S_PASSIVE 0x100
#define S_SACK  0x200
#define S_PROBE 0x400
#define S_INSEQ 0x800

#define S_EOF   0x01
#define S_NOACK 0x02
#define S_UNREA 0x04
#define S_TIMEX 0x08
#define S_QUENC 0x10
#define S_FATAL 0x20
#define S_RST   0x40



#define CHECK_DRIVER_PACKET(netno) QUEUE_EMPTY(netp, arrive)
#define TAKE_DRIVER_PACKET(netno, mp) QUEUE_OUT(netp, arrive, mp)

#ifndef LITTLE
#define NLONG short
#define NC2(val) val
#define GETLONG(w, net) w.s[0] = ((NLONG * ) net)[0], w.s[1] = ((NLONG * ) net)[1]
#define PUTLONG(w, net) ((NLONG * ) net)[0] = w.s[0], ((NLONG * ) net)[1] = w.s[1]
#else
#define NLONG char
#define NC2(val) ((((unsigned short)(val)&0xff) << 8) | ((unsigned short)(val) >> 8))
#define GETLONG(w, net) w.c[0] = net[3], w.c[1] = net[2], \
    w.c[2] = net[1], w.c[3] = net[0]
#define PUTLONG(w, net) net[0] = w.c[3], net[1] = w.c[2], \
    net[2] = w.c[1], net[3] = w.c[0]
#endif

#ifdef __cplusplus
#define GLOBALCONST extern
#else
#define GLOBALCONST
#endif

#define SOCKET_CLEAR(s) connblo[s].rxstat = 0
#define SOCKET_NOBLOCK(s) connblo[s].txstat |= S_NOWA, connblo[s].rxtout = 0
#define SOCKET_BLOCK(s) connblo[s].txstat &= ~S_NOWA, \
    connblo[s].rxtout = TOUT_READ
#define SOCKET_IPADDR(s) connblo[s].realiid
#define SOCKET_OWNIPADDR(s) netconf[nets[connblo[s].netno].confix].Iaddr
#define SOCKET_PUSH(s) connblo[s].txstat |= S_PSH
#define SOCKET_FIN(s) connblo[s].txstat |= S_FIN
#define SOCKET_TESTFIN(s) (connblo[s].rxstat & S_EOF)
#define SOCKET_ISOPEN(s) (connblo[s].state == 1)
#define SOCKET_HASDATA(s) (connblo[s].first != 0)
#define SOCKET_CANSEND(s, len) socket_cansend(s, len)
int             socket_cansend(int, unsigned int);
#define SOCKET_MAXDAT(s) connblo[s].maxdat
#define SOCKET_RXTOUT(s, val) connblo[s].rxtout = val

#define SOCKET_ISFATAL(s) (connblo[s].rxstat & S_FATAL)
#define SOCKET_ISCLOSED(s) (connblo[s].blockstat == 0)
#ifdef	INET6
#define	SOCKET_FAMILY(s) connblo[s].ipv6.family
#define SOCKET_HASMYADDR6(s) (connblo[s].ipv6.flags & MY6ID)
#define SOCKET_MYADDR6(s) connblo[s].ipv6.myi6id
#define SOCKET_IPADDR6(s) connblo[s].ipv6.reali6id
#define SOCKET_OWNIPADDR6(s) netconf[nets[connblo[s].netno].confix].ipv6.I6addr
#endif



#if defined(memcpy_INASM) && !defined(WRAPTEST)
void Nmemcpy(void *, void *, int);
#else
#define Nmemcpy memcpy
#endif

MESS           *reaDD(int conno);
unsigned short  Nchksum(unsigned short *sp, int cnt);
unsigned short  Nportno(void);
int             Ninitsupp(void);
unsigned long   TimeMS(void);
void            SetTimeMS(unsigned long);
int             Nsprintf(char *buffer, char *format,...);
int             Nprintf(char *format,...);
int             Nsscanf(char *buffer, char *format,...);
void            Npanic(char *);
void            ConfLock(void);
void            ConfFree(void);
int             ConfFind(int startix, struct NETCONF * argp);
int             ConfDel(int argix);
int             ConfAdd(struct NETCONF * argp);
int             ConfRename(int argix, Iid iaddr);
void            ConfDisplay(void);
int             RARPget(int netno);
int             Ndial(int netno, char *phonenumber);
void            handlePacket(PTABLE *pp, MESS *mp, struct NET *netp);


unsigned short  htons(unsigned short);
#define ntohs(val) htons(val)
unsigned long   htonl(unsigned long);
#define ntohl(val) htonl(val)

unsigned long   inet_addr(char *dotted);

#ifdef ICMP
int             ICMPreply(MESS * mess, int type, int scode);
#else
#define ICMPreply(mess, type, scode)
#endif
#ifdef DHCP
int             DHCPget(int netno, unsigned long lease);
int             DHCPrelease(int netno);
#endif
#ifdef DNS
int             DNSresolve(char *fullname, Iid *iidp);
#ifdef	INET6
int             DNSresolve6(char *fullname, I6id *i6idp);
#endif
#endif
#ifdef PPP
int             MPjoin(int netno, int oldnetno);
int             MPleave(int netno);
#endif



#ifndef NETMODULE
extern char     localhostname[];
extern struct CONNECT connblo[];
extern struct NET nets[];
extern struct NETCONF netconf[];
#endif

struct ifgroup {
    int             ifNumber;
};
#ifdef MIB2
struct sysgroup {
    const char     *sysDescr;
    char           *sysContact;
    char           *sysName;
    char           *sysLocation;
};
struct IPgroup {
    int             ipForwarding;
    int             ipDefaultTTL;
    unsigned long   ipInReceives;
    unsigned long   ipInHdrErrors;
    unsigned long   ipInAddrErrors;
    unsigned long   ipForwDatagrams;
    unsigned long   ipInUnknownProtos;
    unsigned long   ipInDiscards;
    unsigned long   ipInDelivers;
    unsigned long   ipOutRequests;
    unsigned long   ipOutDiscards;
    unsigned long   ipOutNoRoutes;
    unsigned long   ipRoutingDiscards;
    int             ipReasmTimeout;
    unsigned long   ipReasmReqds;
    unsigned long   ipReasmOKs;
    unsigned long   ipReasmFails;
    unsigned long   ipFragOKs;
    unsigned long   ipFragFails;
    unsigned long   ipFragCreates;
};
struct ICMPgroup {
    unsigned long   icmpInMsgs;
    unsigned long   icmpInErrors;
    unsigned long   icmprx[19];
    unsigned long   icmpOutMsgs;
    unsigned long   icmpOutErrors;
    unsigned long   icmptx[19];
};
struct TCPgroup {
    unsigned long   tcpRtoMax;
    unsigned long   tcpActiveOpens;
    unsigned long   tcpPassiveOpens;
    unsigned long   tcpAttemptFails;
    unsigned long   tcpEstabResets;
    unsigned long   tcpCurrEstab;
    unsigned long   tcpInSegs;
    unsigned long   tcpOutSegs;
    unsigned long   tcpRetransSegs;
    unsigned long   tcpInErrs;
    unsigned long   tcpOutRsts;
};
struct UDPgroup {
    unsigned long   udpInDatagrams;
    unsigned long   udpNoPorts;
    unsigned long   udpInErrors;
    unsigned long   udpOutDatagrams;
};
#endif
#define USSW_NIOCTL
#ifdef USSW_DIRECTED_BROADCAST
struct DETECTIPDATA {
    Iid           Iaddr;
    int           detectedFlags;
    int           detectLastOctet;
    int           detectPort;
    unsigned long recvTime;
};
#endif

struct SETIid {
    int no;
    Iid addr;
};
struct SETEid {
    int no;
    struct Eid addr;
};

#ifdef USSW_NIOCTL
enum nioctlreq { 
                ussSetIaddr = 0,
                ussSetEaddr,
                ussSetImask,
                ussSetGateway,
                ussGetIPConflict,
              };

int Nioctl(int request, void * arg);
#ifdef USSW_DIRECTED_BROADCAST
int get_auto_detected_ip(unsigned long *ip);
int start_ip_auto_detect(unsigned long ip, unsigned short port);
int stop_ip_auto_detect(unsigned short port);
int check_receive_broadcast(void);
#endif

int getifstatus(int req, void *arg, int iPort);
#endif
#endif

