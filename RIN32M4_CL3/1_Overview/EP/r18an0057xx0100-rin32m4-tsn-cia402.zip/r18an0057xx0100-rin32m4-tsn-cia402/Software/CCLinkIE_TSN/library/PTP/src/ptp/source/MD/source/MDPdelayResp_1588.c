/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "MDPdelayResp.h"
#include "MDPdelayResp_1588.h"
#ifdef	PTP_USE_ME_HW_ASSIST
#include "ptp_GetDetailCurrentTime.h"
#endif

#define D_FUNC	0
#define D_DBG	0

VOID (*const MDPdelayResp_1588_Matrix[MDPDRP_STATUS_MAX][DMDPDRP_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDPdelayResp_01_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_NP_1588},
	{&MDPdelayResp_01_1588, &MDPdelayResp_02_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_00_1588},
	{&MDPdelayResp_01_1588, &MDPdelayResp_02_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_00_1588},
	{&MDPdelayResp_01_1588, &MDPdelayResp_02_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_00_1588},
	{&MDPdelayResp_01_1588, &MDPdelayResp_NP_1588, &MDPdelayResp_03_1588, &MDPdelayResp_00_1588}
};

VOID MDPdelayResp_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDPDELAYRESP_EV	enEvt = MDPDRP_E_EVENT_MAX;
	MDPDELAYRESP_ST	enSts = MDPDRP_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82080001);

	enEvt = GetMDPdelayRespEvent(usEvent, pstPort);
	enSts = GetMDPdelayRespStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDPdelayResp_1588        ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDPDRP_STATUS_MAX) && (enEvt != MDPDRP_E_EVENT_MAX))
	{
		(*MDPdelayResp_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDPdelayRespStatus(pstPort);
	printf ("<END  > [%02d]MDPdelayResp_1588        ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
}

VOID MDPdelayResp_00_1588(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDPdelayResp_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	MDPdlyResp_IntWtFrPDReq_1588(pstGbl, pstPort);
	SetMDPdelayRespStatus(MDPDRP_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDPdelayResp_00_1588::-\n") );

}

VOID MDPdelayResp_01_1588(PORTDATA* pstPort)
{
	MDPRESPSM_GD*	pstGbl = NULL;
	BOOL			blRet = FALSE;

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	blRet = MDPdlyResp_IntWtFrPDReq_1588(pstGbl, pstPort);
	if (blRet)
	{
		SetMDPdelayRespStatus(MDPDRP_INITIAL_WAIT_FR_PDREQ, pstPort);
	}
	else
	{
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
	}

}

VOID MDPdelayResp_02_1588(PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT	= pstPort->pstClockData;
	DEFAULT_1588_DS*	pstClkDefaultDS = &pstClockDT->stDefault_1588_DS;

	MDPRESPSM_GD*	pstGbl = NULL;

	ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1588::+\n"));

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	if (ConMDPdelayReq_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82001508);
		MDPdlyResp_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1588(FALSE)::-\n"));
		return;
	}

	IncMDPDlyRespRxPDlyReqCount(pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	if (SetMDPdlyReqEvIngresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_8200150B);
		MDPdlyResp_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1588(FALSE)::-\n"));
		return;
	}

	if (pstClkDefaultDS->blTwoStepFlag)
	{
		MDPdlyResp_StPDRpTwoWtFrTS_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_SENT_PDRESP_WAIT_FR_TMST, pstPort);
	}
	else
	{
		MDPdlyResp_StPDRpOneWtFrTS_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_SENT_PDRESP_WAIT_FR_TMST, pstPort);
	}
	ptp_dbg_msg(D_FUNC, ("MDPdelayResp_02_1588::-\n"));
}

VOID MDPdelayResp_03_1588(PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT	= pstPort->pstClockData;
	DEFAULT_1588_DS*	pstClkDefaultDS = &pstClockDT->stDefault_1588_DS;

	MDPRESPSM_GD*	pstGbl = NULL;

	pstGbl = GetMDPdelayRespGlobal(pstPort);

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_8200260C);
		MDPdlyResp_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
		return;
	}

	if (SetMDPdlyRespEvEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_8200260B);
		MDPdlyResp_NotEnable_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_NOT_ENABLED, pstPort);
		return;
	}

	if (pstClkDefaultDS->blTwoStepFlag)
	{
		MDPdlyResp_TwoWtFrPDReq_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_WAIT_FR_PDELAY_REQ, pstPort);
	}
	else
	{
		MDPdlyResp_OneWtFrPDReq_1588(pstGbl, pstPort);
		SetMDPdelayRespStatus(MDPDRP_WAIT_FR_PDELAY_REQ, pstPort);
	}
}

VOID MDPdelayResp_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDPdlyResp_NotEnable_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	return TRUE;
}

BOOL MDPdlyResp_IntWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*	pstCmldsPortDS	= pstPort->stPort_1588_GD.pstCmldsPortDs;

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1588::+\n"));

	pstSmGbl->blRcvdPdelayReq = FALSE;

	if (pstCmldsPortDS->blCmldsPortEnabled == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_IntWtFrPDReq_1588::-\n"));
	return TRUE;
}

BOOL MDPdlyResp_TwoWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_TwoWtFrPDReq_1588::+\n"));

	pstSmGbl->blEgMDTimestampReceive = FALSE;

	if (SetPdelayRespFollowUp_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_TwoWtFrPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayRespFollowUp_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_TwoWtFrPDReq_1588(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyRespTxPDRpFllwUpCount(pstPort->stPort_1588_GD.pstCmldsPortStatDs );
	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_TwoWtFrPDReq_1588::-\n"));
	return TRUE;
}

BOOL MDPdlyResp_OneWtFrPDReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	return TRUE;
}

BOOL MDPdlyResp_StPDRpTwoWtFrTS_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpTwoWtFrTS_1588::+\n"));

	pstSmGbl->blRcvdPdelayReq = FALSE;

	if (SetPdelayRespTwoStep_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpTwoWtFrTS_1588(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayResp_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpTwoWtFrTS_1588(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyRespTxPDlyRespCount( pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpTwoWtFrTS_1588::-\n"));
	return TRUE;
}

BOOL MDPdlyResp_StPDRpOneWtFrTS_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpOneWtFrTS_1588::+\n"));

	pstSmGbl->blRcvdPdelayReq = FALSE;

	if (SetPdelayRespOneStep_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpOneWtFrTS_1588(FALSE)::-\n"));
		return FALSE;
	}
	if (TxPdelayResp_1588(pstSmGbl, pstPort) == FALSE)
	{
		ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpOneWtFrTS_1588(FALSE)::-\n"));
		return FALSE;
	}

	IncMDPDlyRespTxPDlyRespCount( pstPort->stPort_1588_GD.pstCmldsPortStatDs );

	ptp_dbg_msg(D_FUNC, ("MDPdlyResp_StPDRpOneWtFrTS_1588::-\n"));
	return TRUE;
}

BOOL ConMDPdelayReq_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdPdelayReq == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82001509);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdPdelayReq == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_8200150A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConPdlyReq_1588,
		&pstSmGbl->pstRcvdPdelayReq->stPdlyReq_1588, sizeof(pstPortMD->stConPdlyReq_1588));

	return TRUE;
}

BOOL SetPdelayRespTwoStep_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{

	PORT_DS*	pstPortDS			= &pstPort->stPortDS;
	PORTMD_GD*	pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_PDELAY_REQ_1588*	 pstRcvMsg = &pstPortMD->stConPdlyReq_1588;

	PTPMSG_PDELAY_RESP_1588* pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxPdelayResp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDELAY_RESP );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstRcvMsg->stHeader.uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;
    MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, TRUE );
    
	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstRcvMsg->stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_RESP;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

#ifndef	SET_TIMESTAMP_MD
	pstMsg->stReqRcptTimestamp = pstPortMD->stPdlyReqEventIngressTimestamp;
#ifdef DEBUG_TIMESTAMP_MD_SEND
		printf(" [Snd:%02d]Pdelay_Req  IngresTimestamp   [ 0x%04x % 10d:% 10d ]\n",pstPortDS->stPortIdentity.usPortNumber,
						pstPortMD->stPdlyReqEventIngressTimestamp.stSeconds.usSec_msb,
						pstPortMD->stPdlyReqEventIngressTimestamp.stSeconds.ulSec_lsb,
						pstPortMD->stPdlyReqEventIngressTimestamp.ulNanoseconds);
#endif
#else
	SET_TIMESTAMP(pstMsg->stReqRcptTimestamp, 0, 0, 0);
#endif
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstRcvMsg->stHeader.stSrcPortIdentity, sizeof(pstMsg->stReqPortIdentity));
	GetPTPMSG_PDELAY_RESP_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL SetPdelayRespOneStep_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
#ifndef	PTP_USE_ME_HW_ASSIST
	CLOCKDATA*	pstClockDT			= pstPort->pstClockData;
#endif
	PORT_DS*	pstPortDS			= &pstPort->stPortDS;
	PORTMD_GD*	pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_PDELAY_REQ_1588*	 pstRcvMsg = &pstPortMD->stConPdlyReq_1588;

	TIMESTAMP	stA_Ts;
	SCALEDNS	stB_Ns;

	PTPMSG_PDELAY_RESP_1588* pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxPdelayResp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDELAY_RESP );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstRcvMsg->stHeader.uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;
	MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, FALSE );

	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stCorrectionField, &pstRcvMsg->stHeader.stCorrectionField,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstRcvMsg->stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_RESP;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	SET_TIMESTAMP(pstMsg->stReqRcptTimestamp, 0, 0, 0);
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstRcvMsg->stHeader.stSrcPortIdentity, sizeof(pstMsg->stReqPortIdentity));

#ifndef	PTP_USE_ME_HW_ASSIST
	GetMDCOMClockTime(pstClockDT, MDCOM_TMTYPE_MASTER, &stA_Ts);
#else
	{
		USCALEDNS	stC_UNs;
		ptp_GetDetailCurrentTime(&stC_UNs);
		ptpConvUSNs_TS (&stC_UNs, &stA_Ts);
	}
#endif

	ptpSubTS_TS(&stA_Ts, &pstPortMD->stPdlyReqEventIngressTimestamp, &stB_Ns);
	ptpAddTInt_SNs(&pstRcvMsg->stHeader.stCorrectionField, &stB_Ns,
		&pstMsg->stHeader.stCorrectionField);
	GetPTPMSG_PDELAY_RESP_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL TxPdelayResp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDPdelayResp;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayResp1588,
		pstSmGbl->stTxPdelayResp1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82002608);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

BOOL SetPdelayRespFollowUp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{

	PORT_DS*	pstPortDS			= &pstPort->stPortDS;
	PORTMD_GD*	pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_PDELAY_REQ_1588*	 pstRcvMsg = &pstPortMD->stConPdlyReq_1588;

	PTPMSG_PDRESP_FOLLOWUP_1588* pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxPdelayRespFollowUp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstRcvMsg->stHeader.uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;

	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stCorrectionField,
		&pstRcvMsg->stHeader.stCorrectionField, sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstRcvMsg->stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_PDLY_RESP_FOLLOWUP;
	pstMsg->stHeader.chLogMsgInterVal	= PTPM_LOGMSGINTERVAL_0x7F;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);



#ifndef	SET_TIMESTAMP_MD
	pstMsg->stRespOrgnTimestamp = pstPortMD->stPdlyRespEventEgressTimestamp;
#ifdef DEBUG_TIMESTAMP_MD_SEND
		printf(" [Snd:%02d]Pdelay_Resp EgresTimestamp    [ 0x%04x % 10d:% 10d ]\n", pstPortDS->stPortIdentity.usPortNumber,
						pstPortMD->stPdlyRespEventEgressTimestamp.stSeconds.usSec_msb,
						pstPortMD->stPdlyRespEventEgressTimestamp.stSeconds.ulSec_lsb,
						pstPortMD->stPdlyRespEventEgressTimestamp.ulNanoseconds);
#endif
#else
	SET_TIMESTAMP(pstMsg->stRespOrgnTimestamp, 0, 0, 0);
#endif
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstRcvMsg->stHeader.stSrcPortIdentity, sizeof(pstMsg->stReqPortIdentity));

#ifndef	SET_TIMESTAMP_MD
#else
	{
	TIMESTAMP	stA_Ts;
	SCALEDNS	stB_Ns;
	stA_Ts = pstPortMD->stPdlyRespEventEgressTimestamp;
	ptpSubTS_TS(&stA_Ts, &pstPortMD->stPdlyReqEventIngressTimestamp, &stB_Ns);
	ptpAddTInt_SNs(&pstRcvMsg->stHeader.stCorrectionField, &stB_Ns,
		&pstMsg->stHeader.stCorrectionField);
	}
#endif

	GetPTPMSG_PDRESP_FOLLOWUP_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL TxPdelayRespFollowUp_1588(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxPdelayRespFollowUp1588,
		pstSmGbl->stTxPdelayRespFollowUp1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDPDELAYRESP_1588, PTP_LOGVE_82002708);
#if D_DBG
#else
		return FALSE;
#endif
	}
	return TRUE;
}

#endif
