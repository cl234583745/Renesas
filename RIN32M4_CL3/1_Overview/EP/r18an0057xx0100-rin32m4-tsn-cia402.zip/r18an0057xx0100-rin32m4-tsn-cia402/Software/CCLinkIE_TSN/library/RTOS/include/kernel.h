/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef	KERNEL_H__
#define	KERNEL_H__

#ifdef	__IASMARM__
#ifndef	_ASM_
#define	_ASM_
#endif
#endif

#include <itron.h>
#ifndef	_ASM_
#include <stdint.h>
#endif

#ifndef	_ASM_
typedef	struct t_ctsk {
	ATR		tskatr;
	VP_INT	exinf;
	FP		task;
	PRI		itskpri;
	SIZE	stksz;
	VP		stk;
} T_CTSK;
#endif

#ifndef	_ASM_
typedef struct t_csem {
	ATR			sematr;
	ROS_UINT	isemcnt;
	ROS_UINT	maxsem;
}T_CSEM;
#endif

#ifndef	_ASM_
typedef struct t_cflg {
	ATR		flgatr;
	FLGPTN	iflgptn;
}T_CFLG;
#endif

#ifndef	_ASM_
typedef struct t_cmbx {
	ATR     mbxatr;
	PRI		maxmpri;
	VP		mprihd;
}T_CMBX;
#endif

#ifndef	_ASM_
typedef struct t_cmtx {
    ATR     mtxatr;
	PRI		ceilpri;
}T_CMTX;
#endif

#ifndef	_ASM_
typedef struct t_dinh {
	ATR		inhatr;
	FP		inthdr;
} T_DINH;
#endif


#ifndef	_ASM_
ER sta_tsk(ID tskid, VP_INT stacd);
void ext_tsk(void);
ER ter_tsk(ID tskid);
ER chg_pri(ID tskid, PRI tskpri);
ER get_pri(ID tskid, PRI *p_tskpri);
ER CRE_TSK(ID tskid, const T_CTSK *pk_ctsk);

ER slp_tsk(void);
ER tslp_tsk(TMO tmout);
ER wup_tsk(ID tskid);
ER iwup_tsk(ID tskid);
ER_UINT can_wup(ID tskid);
ER rel_wai(ID tskid);
ER irel_wai(ID tskid);

ER CRE_SEM(ID semid, const T_CSEM *pk_csem);
ER cre_sem(ID semid, T_CSEM *pk_csem);
ER del_sem(ID semid);
ER wai_sem(ID semid);
ER pol_sem(ID semid);
ER twai_sem(ID semid, TMO tmout);
ER sig_sem(ID semid);
ER isig_sem(ID semid);

ER CRE_FLG(ID flgid, const T_CFLG *pk_cflg);
ER cre_flg(ID flgid, T_CFLG *pk_cflg);
ER del_flg(ID flgid);
ER set_flg(ID flgid, FLGPTN setptn);
ER iset_flg(ID flgid, FLGPTN setptn);
ER clr_flg(ID flgid, FLGPTN clrptn);
ER wai_flg(ID flgid, FLGPTN waiptn, MODE wfmode, FLGPTN *p_flgptn);
ER pol_flg(ID flgid, FLGPTN waiptn, MODE wfmode, FLGPTN *p_flgptn);
ER twai_flg(ID flgid, FLGPTN waiptn, MODE wfmode, FLGPTN *p_flgptn, TMO tmout);

ER CRE_MBX(ID mbxid, const T_CMBX *pk_cmbx);
ER cre_mbx(ID mbxid, T_CMBX *pk_cmbx);
ER del_mbx(ID mbxid);
ER snd_mbx(ID mbxid, T_MSG *pk_msg);
ER isnd_mbx(ID mbxid, T_MSG *pk_msg);
ER rcv_mbx(ID mbxid, T_MSG **ppk_msg);
ER prcv_mbx(ID mbxid, T_MSG **ppk_msg);
ER trcv_mbx(ID mbxid, T_MSG **ppk_msg, TMO tmout);

ER CRE_MTX(ID mtxid, const T_CMTX *pk_cmtx);
ER cre_mtx(ID mtxid, T_CMTX *pk_cmtx);
ER del_mtx(ID mtxid);
ER loc_mtx(ID mtxid);
ER ploc_mtx(ID mtxid);
ER tloc_mtx(ID mtxid, TMO tmout);
ER unl_mtx(ID mtxid);

ER set_tim(SYSTIM *p_systim);
ER get_tim(SYSTIM *p_systim);

ER rot_rdq(PRI tskpri);
ER irot_rdq(PRI tskpri);
ER get_tid(ID *p_tskid);
ER iget_tid(ID *p_tskid);
ER loc_cpu(void);
ER unl_cpu(void);
ROS_BOOL sns_loc(void);
ER dis_dsp(void);
ER ena_dsp(void);

ER def_inh(INHNO inhno, T_DINH *pk_dinh );

char *rin_hwos_get_version(uint8_t mode);
void hwos_set_mpri_operation(int32_t flag);

#endif


#define	TA_HLNG		0x00
#define	TA_ASM		0x01
#define	TA_ACT		0x02

#define	TA_TFIFO	0x00
#define	TA_TPRI		0x01

#define	TA_WMUL		0x02
#define	TA_CLR		0x04

#define TA_MFIFO	0x00
#define TA_MPRI		0x02

#define TA_INHERIT	0x02
#define TA_CEILING  0x03

#define	TWF_ANDW	0x00
#define	TWF_ORW		0x01

#define TSK_SELF	0x00
#define TSK_NONE	0x00

#define TPRI_SELF	0x00
#define TPRI_INI	0x00

#define TMIN_TPRI	 1
#define TMAX_TPRI   15

#define TMIN_MPRI    1
#define TMAX_MPRI    7

#define TBIT_FLGPTN	16

#define TMAX_MAXSEM	31

#define TMIN_TSKID			  1
#define TMAX_TSKID			 64
#define TMIN_SEMID			  1
#define TMAX_SEMID			128
#define TMIN_FLGID			  1
#define TMAX_FLGID			 64
#define TMIN_MBXID			  1
#define TMAX_MBXID			 64
#define TMIN_MTXID			TMIN_SEMID
#define TMAX_MTXID			TMAX_SEMID


#ifndef	_ASM_
typedef struct task_table {
	ID	id;
	T_CTSK	t_ctsk;
}TSK_TBL;
#endif

#ifndef	_ASM_
typedef struct semaphore_table {
	ID	id;
	T_CSEM	pk_csem;
}SEM_TBL;
#endif

#ifndef	_ASM_
typedef struct flag_table {
	ID	id;
	T_CFLG	pk_cflg;
}FLG_TBL;
#endif

#ifndef	_ASM_
typedef struct mailbox_table {
	ID	id;
	T_CMBX	pk_cmbx;
}MBX_TBL;
#endif

#ifndef	_ASM_
typedef struct mutex_table {
	ID	id;
	T_CMTX	pk_cmtx;
}MTX_TBL;
#endif

#ifndef	_ASM_
typedef struct interrupt_table {
	INHNO	inhno;
	T_DINH	pk_dinh;
}INT_TBL;	
#endif

#ifndef	_ASM_
typedef struct hwisr_table {
	INHNO		inhno;
	ROS_UINT	hwisr_syscall;
	ID			id;
	FLGPTN		setptn;
}HWISR_TBL;	
#endif

#ifndef	_ASM_
typedef struct {
	uint32_t		ClockFrq;
	void*			InterruptStackBase;
	uint32_t		InterruptStackSize;
	void*			TaskStackBase;
	uint32_t		TaskStackSize;

	const TSK_TBL*		TaskInfo;
	uint32_t			TaskNum;
	const SEM_TBL*		SemaphoreInfo;
	uint32_t			SemaphoreNum;
	const FLG_TBL*		EventflagInfo;
	uint32_t			EventflagNum;
	const MBX_TBL*		MailboxInfo;
	uint32_t			MailboxNum;
	const MTX_TBL*		MutexInfo;
	uint32_t			MutexNum;
	const INT_TBL*		InterruptInfo;
	uint32_t			InterruptNum;
	const HWISR_TBL*	HwisrInfo;
	uint32_t			HwisrNum;
}	HWRTOS_SIT;
#endif


#ifndef	_ASM_
ER hwos_setup(void);
ER hwos_init(void);
void hwos_start(const HWRTOS_SIT* pSit);
ER DEF_HWISR(INHNO qintno, HWISR_TBL *pk_dhwisr );
#endif

#define MAX_CONTEXT_NUM		TMAX_TSKID
#define MAX_SEMAPHORE_NUM	TMAX_SEMID
#define MAX_EVENTFLAG_NUM	TMAX_FLGID
#define MAX_MAILBOX_NUM     TMAX_MBXID
#define MAX_MUTEX_NUM		MAX_SEMAPHORE_NUM

#define MAX_PRIORITY_NUM	TMAX_TPRI
#define MAX_SEMAPHORE_CNT	TMAX_MAXSEM

#define HWOS_TBL_END		(-1)
#define TASK_TBL_END		HWOS_TBL_END
#define SEMAPHORE_TBL_END	HWOS_TBL_END
#define EVENTFLAG_TBL_END	HWOS_TBL_END
#define MAILBOX_TBL_END		HWOS_TBL_END
#define MUTEX_TBL_END		HWOS_TBL_END
#define INT_TBL_END			0xffffffff
#define HWISR_TBL_END		0xffffffff

#define MAX_QINT_NUM       32

#define HWISR_SET_FLG		1
#define HWISR_SIG_SEM		2
#define HWISR_REL_WAI		3
#define HWISR_WUP_TSK		4

#define HWOS_DISABLE_MPRI			(0)
#define HWOS_ENABLE_MPRI			(1)

#endif
