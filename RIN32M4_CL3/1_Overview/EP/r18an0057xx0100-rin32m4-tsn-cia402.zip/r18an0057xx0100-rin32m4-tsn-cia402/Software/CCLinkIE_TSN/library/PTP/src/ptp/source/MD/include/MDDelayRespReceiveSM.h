/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPRECEIVESM_H__
#define __MDDELAYRESPRECEIVESM_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID MDDelayRespReceiveSM(USHORT usEvent, PORTDATA* pstPort);

MDDRESPRVSM_GD*	GetMDDRespRcvSMGlobal(PORTDATA* pstPort);
MDDRESPRCVSM_EV	GetMDDRespRcvEvent(USHORT usEvent, PORTDATA* pstPort);
MDDRESPRCVSM_ST	GetMDDRespRcvStatus(PORTDATA* pstPort);
VOID			SetMDDRespRcvStatus(MDDRESPRCVSM_ST enSts, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
