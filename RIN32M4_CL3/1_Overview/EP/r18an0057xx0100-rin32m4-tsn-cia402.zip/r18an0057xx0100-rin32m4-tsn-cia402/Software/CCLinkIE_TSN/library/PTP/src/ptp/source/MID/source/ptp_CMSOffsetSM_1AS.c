/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE802_1
#ifdef	PTP_USE_GM

#include "ptp_CMSReceive.h"
#include "ptp_UserAdjust.h"
#include "ptp_CSSync_1AS.h"
#include "ptp_CMSOffset_1AS.h"

#define D_FUNC	0
#define	D_DBG	0


VOID	CMSOffset_1AS_00(CLOCKDATA*	pstClockData);
VOID	CMSOffset_1AS_01(CLOCKDATA*	pstClockData);
VOID	CMSOffset_1AS_02(CLOCKDATA*	pstClockData);
DOUBLE	compuClockSourceFreqOffset_1AS(CLOCKDATA*	pstClockData);





VOID (*const pfnCMSOffsetMatrix[ST_CMSO_MAX][EV_CMSO_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CMSOffset_1AS_01, &CMSOffset_1AS_01, &CMSOffset_1AS_00},
	{&CMSOffset_1AS_01, &CMSOffset_1AS_02, &CMSOffset_1AS_00},
	{&CMSOffset_1AS_01, &CMSOffset_1AS_02, &CMSOffset_1AS_00}
};



VOID	clockMasterSyncOffset_1AS(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSO	enEvt = EV_CMSO_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("CMSOfhusetSM_1AS   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1as_GD.stCMSOffsetSM_1AS_GD.enStatusCMSO);
}
#endif
		enEvt = GetCMSOffsetSM_1AS_Event(usEvent, pstClockData);

		blSts = IsCMSOffsetSM_1AS_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CMSO_EVENT_MAX))
		{
			(*pfnCMSOffsetMatrix[pstClockData->stUn_CSM_GD.stCsm1as_GD.stCMSOffsetSM_1AS_GD.enStatusCMSO][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CMSOFFSETSM_1AS, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1as_GD.stCMSOffsetSM_1AS_GD.blRcvdSyncReceiptTime	= FALSE;
		}

	}
}



CMSOFFSETSM_1AS_GD*	GetCMSOffsetSM_1AS_GD(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb = &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stCMSOffsetSM_1AS_GD);
	return pstCMSOGlb;
}

EN_EV_CMSO	GetCMSOffsetSM_1AS_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSO	enEvt = EV_CMSO_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CMSO_BEGIN;
			break;

		case PTP_EV_RCVDSYNCRECEIPTTIME:
			enEvt = EV_CMSO_RCVDSYNCRECEIPTTIME;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CMSO_CLOSE;
			break;

		default:
			enEvt = EV_CMSO_EVENT_MAX;
			break;
	}

	return	enEvt;
}

BOOL	IsCMSOffsetSM_1AS_Status(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb	= GetCMSOffsetSM_1AS_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstCMSOGlb->enStatusCMSO < ST_CMSO_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	CMSOffset_1AS_00(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb = GetCMSOffsetSM_1AS_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CMSOffset_1AS_00",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstCMSOGlb->blRcvdSyncReceiptTime	= FALSE;
	pstCMSOGlb->blCSFOffsetOld			= FALSE;
	pstCMSOGlb->enStatusCMSO			= ST_CMSO_NONE;

	ptp_dbg_msg( D_FUNC, ("CMSOffset_1AS_00::-\n") );

}




VOID	CMSOffset_1AS_01(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb = GetCMSOffsetSM_1AS_GD(pstClockData);


	pstCMSOGlb->blRcvdSyncReceiptTime	= FALSE;
	pstCMSOGlb->blCSFOffsetOld			= FALSE;
	pstCMSOGlb->enStatusCMSO			= ST_CMSO_INITIALIZING;

}




#ifndef	PTP_USE_ME_HW_ASSIST
VOID	CMSOffset_1AS_02(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb			= GetCMSOffsetSM_1AS_GD(pstClockData);
	DOUBLE				dbFreqRateCand		= DBCONST1_0;
	SCALEDNS			stC_SNs				= {0};
	EXTENDEDTIMESTAMP	stMasterTime		= {0};

	ptp_dbg_msg(D_FUNC, ("CMSOffset_1AS_02::+\n"));

	ptp_GetMasterTime(pstClockData, &stMasterTime);

	if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] == ENUM_PORTSTATE_PASSIVE)
	{
		if (pstCMSOGlb->blNoGMFlag != TRUE)
		{
			gusClockSourceTimeBaseIndicator++;
			gusClockSourceTimeBaseIndOld = gusClockSourceTimeBaseIndicator;
			pstCMSOGlb->blNoGMFlag = TRUE;
		}

		(VOID)ptpSubETS_ETS(&(stMasterTime),
							 &(pstClockData->stClock_GD.stSyncReceiptTime),
							 &stC_SNs);

		pstCMSOGlb->stClockSourcePhaseOffsetCand = stC_SNs;

		pstCMSOGlb->dbClockSourceFreqOffsetCand = (gdbGmRateRatio / gdbRateRatio) - 1.0;

		if (!IS_EPSILON0_0((pstCMSOGlb->dbClockSourceFreqOffsetCand + DBCONST1_0)))
		{
			dbFreqRateCand = DBCONST1_0 / (pstCMSOGlb->dbClockSourceFreqOffsetCand + DBCONST1_0);
		}

		gstClockSourcePhaseOffset	= pstCMSOGlb->stClockSourcePhaseOffsetCand;
		if (!IS_EPSILON0_0(dbFreqRateCand))
		{
			gdbClockSourceFreqOffset	= (DBCONST1_0 / dbFreqRateCand) - DBCONST1_0;
		}
	}
	else if ( gusClockSourceTimeBaseIndicator != gusClockSourceTimeBaseIndOld )
	{
		pstCMSOGlb->stClockSourcePhaseOffsetCand	= gstClockSourceLastGmPhaseChange;
		pstCMSOGlb->dbClockSourceFreqOffsetCand		= gdbClockSourceLastGmFreqChange;
		gusClockSourceTimeBaseIndOld				= gusClockSourceTimeBaseIndicator;


		if (!IS_EPSILON0_0((pstCMSOGlb->dbClockSourceFreqOffsetCand + DBCONST1_0)))
		{
			dbFreqRateCand							= DBCONST1_0 / (pstCMSOGlb->dbClockSourceFreqOffsetCand + DBCONST1_0);
		}



		gstClockSourcePhaseOffset	= pstCMSOGlb->stClockSourcePhaseOffsetCand;
		if (!IS_EPSILON0_0(dbFreqRateCand))
		{
			gdbClockSourceFreqOffset	= (DBCONST1_0 / dbFreqRateCand) - DBCONST1_0;
		}


		pstCMSOGlb->blNoGMFlag = FALSE;

	}
	else
	{
		ptp_dbg_msg(D_DBG, ("<GM>\n"));
		pstCMSOGlb->blNoGMFlag = FALSE;
	}

	pstCMSOGlb->blRcvdSyncReceiptTime	= FALSE;
	pstCMSOGlb->enStatusCMSO			= ST_CMSO_SEND_SYNC_INDICATION;

	ptp_dbg_msg(D_FUNC, ("CMSOffset_1AS_02::-\n"));
}
#else
VOID	CMSOffset_1AS_02(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb			= GetCMSOffsetSM_1AS_GD(pstClockData);

	ptp_dbg_msg(D_FUNC, ("CMSOffset_1AS_02::+\n"));

	if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] != ENUM_PORTSTATE_PASSIVE)
	{

		if ( gusClockSourceTimeBaseIndicator != gusClockSourceTimeBaseIndOld )
		{
			ptp_dbg_msg(D_DBG, ("<gusClockSourceTimeBaseIndicator != gusClockSourceTimeBaseIndOld>\n"));

			gstClockSourcePhaseOffset	 = gstClockSourceLastGmPhaseChange;
			gdbClockSourceFreqOffset	 = gdbClockSourceLastGmFreqChange;
			gusClockSourceTimeBaseIndOld = gusClockSourceTimeBaseIndicator;
		}
	}
	pstCMSOGlb->blRcvdSyncReceiptTime	= FALSE;
	pstCMSOGlb->enStatusCMSO			= ST_CMSO_SEND_SYNC_INDICATION;

	ptp_dbg_msg(D_FUNC, ("CMSOffset_1AS_02::-\n"));
}
#endif




DOUBLE compuClockSourceFreqOffset_1AS(
	CLOCKDATA*	pstClockData)
{
	CMSOFFSETSM_1AS_GD*	pstCMSOGlb		= GetCMSOffsetSM_1AS_GD(pstClockData);
	SCALEDNS			stSubMTimeFO	= {0};
	SCALEDNS			stSubSRTimeFO	= {0};
	SCALEDNS			stSubSRTimeFO_0 = {0};
	DOUBLE				dbClockSFOffset = DBCONST0_0;
	CHAR				chRet			= 0;
	EXTENDEDTIMESTAMP	stMasterTime	= {0};


	ptp_GetMasterTime(pstClockData, &stMasterTime);

	pstCMSOGlb->stMasterTimeFOOld = pstCMSOGlb->stMasterTimeFO;
	pstCMSOGlb->stSyncReceiptTimeFOOld = pstCMSOGlb->stSyncReceiptTimeFO;
	pstCMSOGlb->stMasterTimeFO = stMasterTime;
	pstCMSOGlb->stSyncReceiptTimeFO = pstClockData->stClock_GD.stSyncReceiptTime;

	if (pstCMSOGlb->blCSFOffsetOld)
	{
		(VOID)ptpSubETS_ETS(&(pstCMSOGlb->stMasterTimeFO),
							 &(pstCMSOGlb->stMasterTimeFOOld),
							 &stSubMTimeFO);

		(VOID)ptpSubETS_ETS(&(pstCMSOGlb->stSyncReceiptTimeFO),
							 &(pstCMSOGlb->stSyncReceiptTimeFOOld),
							 &stSubSRTimeFO);

		chRet = ptpCompSNs_SNs(&stSubSRTimeFO, &stSubSRTimeFO_0);
		if (chRet != COMP_EQUAL)
		{
			(VOID)ptpDivSNs_SNs(&stSubMTimeFO, &stSubSRTimeFO, &dbClockSFOffset);
		}
		else
		{
			dbClockSFOffset = DBCONST1_0;
		}
		dbClockSFOffset = dbClockSFOffset - DBCONST1_0;

	}

	pstCMSOGlb->blCSFOffsetOld = TRUE;

	return dbClockSFOffset;

}




#endif
#endif

