//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#ifdef  INET6
#include "ip6.h"
#endif

#define MSL 120000UL
#define MAXFUT MAXWIND + 1
#define MAXCDEL 7500
#define INIT_TXAVE 0UL
#define INIT_TXVAR 3000UL
#define MINTXTOUT 300UL
#define MAXTXTOUT 60000UL
#define RETX_THR_R2 12
#define TCPOPENTXTOUT 1000UL
#define ACKDELAY 200
#define ACKLIMIT 3

#define URGSTAND 0

#define NEGOTI 0

#ifdef TCP_SACK
struct Sack {
    unsigned NLONG left[4/sizeof(NLONG)];
    unsigned NLONG right[4/sizeof(NLONG)];
};
#endif

#define TCP_FASTRECOVER

#define IPOFFSET (MESSH_SZ+LHDRSZ)
#define IP_TCP 6
#define MAXDAT 536
#if MAXBUF < 614
#error "TCP needs a MAXBUF (LOCAL.H) at least 590+MESSH_SZ"
#endif

struct Thdr {
    unsigned short  myport;
    unsigned short  herport;
    unsigned NLONG  seqno[4 / sizeof(NLONG)];
    unsigned NLONG  ackno[4 / sizeof(NLONG)];
    unsigned char   hdrlen;
    unsigned char   flags;
    unsigned short  window;
    unsigned short  chksum;
    unsigned short  urgp;
};

struct Pseudo {
    unsigned short s[2];
    unsigned long Iadd1, Iadd2;
    unsigned short us;
};


#ifdef TCP_OPTIONS
#define Thdr_SZ 60
#define OPTION_OFFSET 20
#else
#define Thdr_SZ 20
#define OPTION_OFFSET Thdr_SZ
#endif

#define pseudo_SZ 14

#define ESTABLISHED   1
#define FINWAIT_1     2
#define FINWAIT_2     3
#define CLOSED_WAIT   4
#define TIMEWAIT      5
#define LAST_ACK      6
#define CLOSED        7
#define SYN_SENT      8
#define SYN_RECEIVED  9
#define CLOSING      10
#define LISTEN       16
#define FIN 1
#define SYN 2
#define RST 4
#define PSH 8
#define ACK 0x10
#define URG 0x20

extern struct NETCONF netconf[];
extern struct NET nets[];
extern int      Nclocktick;
extern PTABLE   ussTCPTable;

#ifdef MIB2
struct TCPgroup TCPgroup;
#endif

static void clearconn(struct CONNECT * conp)
{
    MESS *mp;
    int i1;

    while ( (mp = conp->future) != 0) {
        conp->future = mp->next;
        Nrelbuf(mp);
    }

    while ( (mp = conp->wackf) != 0) {
        conp->wackf = mp->next;
        conp->nwacks -= MAXWACK;
        Ndisable();
        i1 = 0;
        if ( mp->offset != boTXDONE )
        {
            if ( mp->offset == mp->netno )
            {
                i1 = mp->id;
                mp->id = bRELEASE;
            }
        }
        Nenable();
        if ( i1 == 0 )
        {
            mp->id = bALLOC;
            Nrelbuf(mp);
        }

#ifdef ARP
        for (i1 = 0; i1 < NCONFIGS; i1++)
        {
            if (netconf[i1].ARPwait && mp == netconf[i1].ARPwaitmp)
            {
                netconf[i1].ARPwait = 0;
            }
        }
#endif

        if (conp->ostreamb == mp)
          {
          conp->ostreamb = 0;
          }

    }


    while ( (mp = conp->first) != 0) {
        conp->first = mp->next;
        conp->ninque--;
        Nrelbuf(mp);
    }

    if (conp->ostreamb)
    {
      Nrelbuf(conp->ostreamb);
      conp->ostreamb = 0;
    }

    if (conp->istreamc)
    {
        Nrelbuf(conp->istreamb);
        conp->istreamb = 0;
        conp->istreamc = 0;
        conp->istreamp = 0;
    }


    conp->txstat &= ~S_SACK;
}


static void tcp_reset( MESS * mess, char state, int tlen, int conno, struct Pseudo *pseudop )
{
    struct Thdr *thdrp;
    union {
        char c[4];
        short s[2];
        unsigned long l;
    } seqno, ackno;
    unsigned short tempport;

    thdrp = (struct Thdr *) ((char *) mess + mess->offset);

    GETLONG(seqno, thdrp->seqno);
    GETLONG(ackno, thdrp->ackno);

    thdrp->hdrlen = Thdr_SZ << 2;

    if ( state == CLOSED )
    {
        if (thdrp->flags & (FIN | SYN))
            tlen++;
        if ((thdrp->flags & ACK) == 0)
            ackno.l = 0;
        thdrp->flags = RST + ACK;
        seqno.l += tlen;
    }
    else
    {
        thdrp->flags = RST;
        seqno.l = 0;
    }
    PUTLONG(ackno, thdrp->seqno);
    PUTLONG(seqno, thdrp->ackno);

    tempport = thdrp->myport;
    thdrp->myport = thdrp->herport;
    thdrp->herport = tempport;

    mess->mlen = mess->offset + Thdr_SZ;
#ifdef  INET6
if (mess->ipv6.flag6 & FLAG6_IPV6) {
    thdrp->chksum = 0;
    mess->ipv6.sum6 = mess->offset + 16;
    mess->ipv6.flag6 |= FLAG6_SUM6;
} else {
#endif
    pseudop->s[0] = NC2(Thdr_SZ);
    pseudop->us = 0;
    thdrp->chksum = Nchksum((unsigned short *) pseudop, pseudo_SZ >> 1);
    thdrp->chksum = ~Nchksum((unsigned short *) thdrp, Thdr_SZ / 2);
#ifdef  INET6
}
#endif
#if NTRACE >=1
    Nprintf("RST %lu to %d P%-5u/%-5u C%d\n", TimeMS(), mess->confix,
            NC2(thdrp->herport), NC2(thdrp->myport), conno);
#endif
#ifdef MIB2
    TCPgroup.tcpOutSegs++;
    TCPgroup.tcpOutRsts++;
#endif
    return;
}

static int writE(int aconno, MESS * mess)
{
    int i1, conno, tlen, hlen, hdroff, probe;
    long leftout = 0;
    short *sp;
    union {
        unsigned char c[4];
        short s[2];
        long l;
    } UL1, UL2;
    struct NET *netp;
    MESS *mp;
    register struct CONNECT *conp;
    register struct Thdr *thdrp;
    struct Pseudo pseudo;

#ifdef TCP_SACK
    int fut_hlen, fut_tlen, cnt, blockcnt;
    struct Sack *sackp, *sackp2;
    MESS *future_mp;
    char sackblock[40];
    char *cp;
    register struct Thdr *thdrp2;
    struct {
        unsigned long left;
        unsigned long right;
    } tsack[MAXFUT], recent;
#endif

    conno = aconno < 0 ? mess->conno : aconno;
    conp = &connblo[conno];
    if (!(mess->mlen & 0x8000) && conp->state != ESTABLISHED) {
        return EBADF;
    }
    netp = &nets[conp->netno];
    hlen = Thdr_SZ;
#ifdef IPOPTIONS
    if ((aconno == -5) || (aconno == -4)) {
        hdroff = mess->offset;
    }
    else {
#ifdef  INET6
        hdroff = IPOFFSET + (conp->ipv6.family == 28 ? I6hdr_SZ : Ihdr_SZ);
#else
        hdroff = IPOFFSET + Ihdr_SZ;
#endif
        if (conp->IPOtxlen)
            hdroff += conp->IPOtxlen;
        else if (conp->IPOrxsrlen)
            hdroff += conp->IPOrxsrlen;
        mess->offset = hdroff;
    }
#else
#ifdef  INET6
    mess->offset = hdroff = IPOFFSET + 
        (conp->ipv6.family == 28 ? I6hdr_SZ : Ihdr_SZ);
#else
    mess->offset = hdroff = IPOFFSET + Ihdr_SZ;
#endif
#endif
#ifdef TCP_OPTIONS
    cp = ((char *) mess + hdroff + OPTION_OFFSET);
    memset(cp, 0, 40);
#endif

sendnext:
    mp = 0;

    thdrp = (struct Thdr *) ((char *) mess + hdroff);
    thdrp->urgp = 0;
    if (mess->mlen & 0x8000) {
        thdrp->flags = (unsigned char) mess->mlen;
        mess->mlen = hdroff + Thdr_SZ;
        tlen = mess->mlen - hdroff - hlen;
    } else {
        tlen = mess->mlen - hdroff - hlen;
        thdrp->flags = ACK;
        if ((UL1.c[0] = conp->txstat & (S_PSH | S_URG | S_FIN)) != 0) {
            thdrp->flags |= UL1.c[0];
            conp->txstat &= ~UL1.c[0];
            if (UL1.c[0] & S_FIN) {
                conp->state = conp->rxstat & S_EOF ? LAST_ACK : FINWAIT_1;
#ifdef MIB2
                if (conp->state == FINWAIT_1)
                    TCPgroup.tcpCurrEstab--;
#endif
            }
            if (UL1.c[0] & S_URG)
                thdrp->urgp = NC2(tlen + URGSTAND - 1);
        }
    }

#ifdef TCP_SACK
    if (conp->future && !(thdrp->flags & RST) && (conp->txstat & S_SACK)) {
        sackp = (struct Sack *) (conp->TCPOtxopt + 2);
        GETLONG(UL1, sackp->left);
        if (UL1.l == 0) {
            goto sack_done;
        }
        cnt = 0;
        memset((char *) &tsack, 0, sizeof(tsack));
        memset(sackblock, 0, sizeof(sackblock));
        future_mp = conp->future;
        i1 = 0;
        while ( (mp = future_mp) != 0) {
            future_mp = mp->next;
#ifdef  INET6
if (mp->ipv6.flag6 & FLAG6_IPV6)
            thdrp2 = (struct Thdr *) ((char *) mp + 
                        I6hdr_SZ + ip6optsize(mp) + IPOFFSET);
else
#endif
            thdrp2 = (struct Thdr *) ((char *) mp +
                      (((*((char *) mp + IPOFFSET)) & 0xf) << 2) + IPOFFSET);
            GETLONG(UL2, thdrp2->seqno);
            if (UL2.l == UL1.l) {
                continue;
            }
            fut_hlen = (thdrp2->hdrlen >> 4) << 2;
            fut_tlen = mp->mlen - mp->offset - fut_hlen;
            if ((UL2.l - tsack[cnt].right) != 0) {
                if (i1 !=0)
                    cnt++;
                tsack[cnt].left = UL2.l;
            }
            tsack[cnt].right = UL2.l + fut_tlen;
            i1++;
        }
        if (i1 == 0)
            cnt = -1;
        GETLONG(UL2, sackp->right);
        recent.left = UL1.l;
        recent.right = UL2.l;
        sackp2 = (struct Sack *) (sackblock + 2);
        memcpy(sackp2, sackp, 8);
        sackp = sackp2;
        blockcnt = cnt + 2;
        for (i1 = 0; i1 < (cnt + 1); i1++) {
            if ((recent.left >= tsack[i1].left) &&
                 (recent.right <= tsack[i1].right)) {
                sackp2 = sackp;
                blockcnt--;
            }
            else if ((recent.left > tsack[i1].left) &&
                      (recent.left - tsack[i1].right == 0)) {
                sackp2 = sackp;
                tsack[i1].right = recent.right;
                blockcnt--;
            }
            else if ((recent.left < tsack[i1].left) &&
                     (tsack[i1].left - recent.right == 0)) {
                sackp2 = sackp;
                tsack[i1].left = recent.left;
                blockcnt--;
            }
            else {
                sackp2 = sackp + i1 + 1;
                if ((sackp2 - sackp) > 4)
                    break;
            }
            UL1.l = tsack[i1].left;
            UL2.l = tsack[i1].right;
            PUTLONG(UL1, sackp2->left);
            PUTLONG(UL2, sackp2->right);
        }
        cp = sackblock;
        *cp++ = 5;
        *cp++ = (blockcnt*8) + 2;
        cp = (char *) ((char *) mess + hdroff + OPTION_OFFSET);
        memcpy(cp, sackblock, ((blockcnt*8) + 2));
    }
sack_done:
#endif

    if (thdrp->flags & SYN) {
        if (conp->seqtoack){
            conp->txseq --;
        } else{
            conp->txseq = TimeMS();
        }
#ifndef TCP_OPTIONS
        hlen += 4;
        mess->mlen = hdroff + Thdr_SZ + 4;
#endif
        sp = (short *) ((char *) mess + hdroff + OPTION_OFFSET);
#ifdef  INET6
        {
        if (conp->ipv6.family == 28 )
            i1 =  Ngetmaxblo6(conp->netno) - 
#ifdef IPOPTIONS
                 ((conp->IPOtxlen) ? conp->IPOtxlen : conp->IPOrxsrlen) -
#endif
                 I6hdr_SZ - Thdr_SZ;
        else
#endif
            i1 = netp->maxblo -
#ifdef IPOPTIONS
                 ((conp->IPOtxlen) ? conp->IPOtxlen : conp->IPOrxsrlen) -
#endif
                 Ihdr_SZ - Thdr_SZ;
#ifdef  INET6
        }
#endif
#if NEGOTI == 0
        if ((netconf[conp->confix].hops > 2) &&
            (i1 > MAXDAT))
            i1 = MAXDAT;
#endif
        conp->mywindow = i1 * MAXWIND;
        *sp++ = NC2(0x0204);
        *sp++ = NC2(i1);
#ifdef TCP_SACK
        if (((conp->txstat & S_PASSIVE) && (conp->txstat & S_SACK)) ||
             !(conp->txstat & S_PASSIVE)) {
            *sp++ = NC2(0x0101);
            *sp++ = NC2(0x0402);
        }
#endif
        conp->txvar = INIT_TXVAR;
        conp->txtout = (INIT_TXAVE >> 3) + INIT_TXVAR;
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        conp->pseudosum = 0;
    } else {
#endif
        pseudo.s[1] = NC2(IP_TCP);
        pseudo.s[0] = conp->myport;
        pseudo.Iadd1 = conp->heriid.l;
        pseudo.Iadd2 = netconf[netp->confix].Iaddr.l;
        pseudo.us = 0;
        conp->pseudosum = Nchksum((unsigned short *) &pseudo, pseudo_SZ >> 1);
#ifdef  INET6
    }
#endif
    }

    probe = 0;
    if (tlen) {
        UL2.l = conp->txstat & S_NOWA ? 0 : netp->tout * 8;
aga6:
        UL1.l = conp->txseq + tlen;
        WAITFOR( (
                   (
                     (conp->nwacks < conp->wackmax)
                     &&
                     ( (long) (UL1.l - conp->ackno - ((conp->wackmax / MAXWACK) * conp->maxdat) ) <= 0 )
                   )
                   ||
                   (conp->rxstat & (S_EOF | S_FATAL))
                 ),
                 SIG_CC(conno), UL2.l, i1);
        if (conp->rxstat & (S_EOF | S_FATAL))
            return ECONNABORTED;
        if (i1) {
            if (conp->txstat & S_NOWA)
                return ETIMEDOUT;
            goto aga6;
        }
        WAITFOR((((leftout = (long) (UL1.l - conp->ackno - conp->window)) <= 0) ||
                 (conp->rxstat & (S_EOF | S_FATAL))), SIG_CC(conno), UL2.l, i1);
        if (conp->rxstat & (S_EOF | S_FATAL))
            return ECONNABORTED;
        if (i1) {
            if (conp->txstat & S_NOWA) {
                return EWINZERO;
            }
            tlen -= (int) leftout;
            probe = -1;
            if (tlen <= 0) {
                leftout = tlen + leftout - 1;
                tlen = 1;
                probe = 1;
                conp->txstat |= S_PROBE;
            }
            mp = mess;
            if ((mess = Ngetbuf()) == 0)
                return ENOBUFS;
            memcpy((char *) mess, (char *) mp, mp->mlen);
            memcpy((char *) mp + hdroff + hlen,
                 (char *) mess + mess->mlen - (int) leftout, (int) leftout);
            mess->mlen -= (int) leftout;
            mp->mlen = hdroff + hlen + (int) leftout;
            thdrp = (struct Thdr *) ((char *) mess + hdroff);
        }
    }
    thdrp->hdrlen = (hlen << 4) >> 2;
    thdrp->herport = conp->herport;

#ifdef  INET6
if (conp->ipv6.family == 28 )
    *((char *) mess + IPOFFSET + 6) = IP_TCP;
else
#endif
    *((char *) mess + IPOFFSET + 9) = IP_TCP;

    UL1.l = conp->txseq;
#ifdef KEEPALIVETIME
    if (conp->sendack == 100)
        UL1.l--;
#endif
    PUTLONG(UL1, thdrp->seqno);
    conp->ackdseq = UL1.l = conp->seqtoack;
    PUTLONG(UL1, thdrp->ackno);
    conp->sendack = 0;
    thdrp->window = NC2(conp->mywindow);
    conp->prevwindow = conp->mywindow;
    i1 = tlen + hlen;
    if (i1 & 1)
        *((char *) thdrp + i1) = 0;
    thdrp->myport = NC2(i1);
#ifdef  INET6
if (conp->ipv6.family == 28 ) {
    thdrp->chksum = 0;
    mess->ipv6.sum6 = mess->offset + 16;
    mess->ipv6.flag6 |= FLAG6_SUM6;
} else {
#endif
    thdrp->chksum = conp->pseudosum;
    thdrp->chksum = ~Nchksum((unsigned short *) thdrp, (i1 + 1) / 2);
#ifdef  INET6
}
#endif
    thdrp->myport = conp->myport;

#if NTRACE >= 2
    GETLONG(UL1, thdrp->seqno);
    GETLONG(UL2, thdrp->ackno);
    Nprintf(
       "TX %09lu C%02d/%-5u ST%02d DL%04d W%04u/%04u SQ%08lx AK%08lx %02x\n",
       TimeMS(), conno, NC2(conp->myport), conp->state, tlen, conp->mywindow,
       conp->window, UL1.l, UL2.l, thdrp->flags );
#endif

    if (thdrp->flags & (FIN | SYN))
        tlen++;

    if (tlen) {
        BLOCKPREE();
        if (aconno != -5 && conp->blockstat == 0) {
            mess->id = bALLOC;
            if (mp)
            {
               mp->id = bALLOC;
               Nrelbuf(mess);
            }
            RESUMEPREE();
            return -1;
        }
        if (conp->rxstat & (S_RST | S_FATAL)) {
            mess->id = bALLOC;
            RESUMEPREE();
            return ECONNABORTED;
        }
#if NTRACE > 0
        if (mess->id != bALLOC)
        {
            Npanic("wack q");
        }
#endif
        mess->id = bWACK;
        mess->next = 0;
        if (conp->wackf)
            conp->wackl->next = mess;
        else
            conp->wackf = mess;
        conp->wackl = mess;
        conp->nwacks += MAXWACK;
        RESUMEPREE();
        conp->txseq += tlen;
        mess->timems = TimeMS();
    }
#ifdef MIB2
    TCPgroup.tcpOutSegs++;
#endif

    if (conp->rxstat & (S_RST | S_FATAL)) {
        BLOCKPREE();
        if (mess->id == bWACK) {
            if (conp->wackf == mess) {
                conp->wackf = conp->wackl->next;
                conp->wackl = conp->wackl->next;
                conp->nwacks -= MAXWACK;
                mess->id = bALLOC;
            }
            else {
                mp = conp->wackf;
                while (mp) {
                    if (mp->next == mess) {
                        mp->next = 0;
                        conp->wackl = mp;
                        conp->nwacks -= MAXWACK;
                        mess->id = bALLOC;
                        break;
                    }
                    mp = mp->next;
                }
            }
        }
        RESUMEPREE();
        return ECONNABORTED;
    }

    i1 = conp->protoc[1]->writE(aconno, mess);
    if (tlen) {
        if (probe) {
            if (probe > 0) {
                UL2.l = conp->txstat & S_NOWA ? 0 : netp->tout * 8;
                WAITFOR(conp->window || (conp->rxstat & (S_EOF | S_FATAL)),
                        SIG_CC(conno), UL2.l, probe);
                if (!probe)
                    conp->txstat &= ~ S_PROBE;
                if (conp->rxstat & (S_EOF | S_FATAL))
                    return ETIMEDOUT;
                conp->blockstat |= 0x40;
                WAITFOR(conp->nwacks == 0, SIG_CC(conno), conp->txtout, probe);
                conp->blockstat &= 0xbf;
            }
            mess = mp;
            if ((int) leftout)
                goto sendnext;
            return 1;
        }
        return 0;
    }
    return i1;
}


static int screen(MESS * mess)
{
    int i1, stat, netno, conno, portno, herport, tlen, hlen;
    int delete;
    int match = 0;
    int bestcount;
    int wildcount;
    int ac_count = 0;
    union {
        char c[4];
        short s[2];
        unsigned long l;
    } UL1, UL2, UL3;
    unsigned short us1, mss;
    char cflg, *cp, *cp2;
    register struct Thdr *thdrp, *thdrp2;
    register struct CONNECT *conp;
    struct CONNECT *conp2;
    MESS *mp, *mp2;
    struct Pseudo pseudo;
    struct Pseudo *pseudop;
#ifdef  INET6
    long I6add1[I6id_SZ/4];
#endif
#ifdef TCP_SACK
    struct Sack * sackp;
    union {
        char c[4];
        short s[2];
        unsigned long l;
    } sackl, sackr;
#endif

#ifdef MIB2
    TCPgroup.tcpInSegs++;
#endif

    thdrp = (struct Thdr *) ((char *) mess + mess->offset);
    tlen = mess->mlen - mess->offset;
    if (tlen < OPTION_OFFSET) {
        goto err1;
    }
#ifdef  INET6
if (mess->ipv6.flag6 & FLAG6_IPV6) {
    ip6acpy(I6add1, (char *) mess + mess->conno);
    if (tlen & 1) *((char *) thdrp + tlen) = 0;
    if (Ncksum6((char *)mess + IPOFFSET, 
        IP_TCP, (char *)thdrp, tlen) != 0xffff) {
#if NTRACE >=1
        Nprintf("#tcp: checksum fail\n");
#endif
        goto err1;
    }
} else {
#endif
    if (tlen & 1)
        *((char *) thdrp + tlen) = 0;
    pseudop = &pseudo;
    pseudo.s[1] = NC2(IP_TCP);
    pseudo.s[0] = NC2(tlen);
    memcpy((char *) &pseudo.Iadd1, (char *) mess + mess->conno, 2 * Iid_SZ);
    pseudo.us = Nchksum((unsigned short *) thdrp, (tlen + 1) / 2);
    if (Nchksum((unsigned short *) &pseudo, pseudo_SZ >> 1)
                != (unsigned short)0xffff) {
#ifdef MIB2
        TCPgroup.tcpInErrs++;
#endif
        goto err1;
    }
#ifdef  INET6
}
#endif

    netno = mess->netno;
    portno = thdrp->herport;
    herport = thdrp->myport;
    hlen = (thdrp->hdrlen >> 4) << 2;
    if (hlen < OPTION_OFFSET) {
        goto err1;
    }
    tlen -= hlen;
#if 1
    thdrp->flags = thdrp->flags & 0x3F;
#endif
    GETLONG(UL1, thdrp->seqno);
    GETLONG(UL2, thdrp->ackno);

    bestcount = 3;
    for (conno = 0; conno < NCONNS; conno++) {
        conp = &connblo[conno];
        wildcount = 0;
        if ((conp->blockstat == 0) ||
            (conp->protoc[0] != &ussTCPTable) ||
            (conp->myport != portno))
            continue;
        if (conp->herport != herport) {
            if (conp->herport != 0)
                continue;
            else
                wildcount++;
        }
#ifdef  INET6
    if (mess->ipv6.flag6 & FLAG6_IPV6){
        if (conp->ipv6.family != 28) continue;
        if (ip6acmp (conp->ipv6.heri6id.c, mess->ipv6.target6) != 0) {

            if (ip6acmp (conp->ipv6.heri6id.c, in6addr_none) != 0)
                continue;
            else if (ip6acmp (conp->ipv6.offeredi6id.c, in6addr_any) != 0) {
                if (conp->netno != netno)
                    continue;
            } else
                wildcount++;
        }
    } else {
        if (conp->ipv6.family == 28) continue;
#endif
        if (conp->heriid.l != mess->target) {
            if (conp->offerediid.l != 0) {
                if (conp->netno != netno)
                    continue;
            } else
                wildcount++;
        }
#ifdef  INET6
    }
#endif
        if (wildcount < bestcount) {
            match = conno;
            bestcount = wildcount;
            if (bestcount == 0)
                break;
        }
    }

    if (bestcount == 3) {
        if (thdrp->flags & RST)
            return -1;
        tcp_reset( mess, CLOSED, tlen, conno, pseudop );
        return -3;
    }

    conno = match;
    conp = &connblo[conno];

    if (thdrp->flags & RST) {
        if (conp->state == SYN_SENT) {
            if (thdrp->flags & ACK) {
                conp->rxstat |= S_FATAL | S_RST;
                conp->blockstat |= 4;
            }
            goto ret2;
        }
        if (UL1.l - conp->rxseq > conp->mywindow)
            goto ret2;
#if NTRACE >=1
        Nprintf("RST %lu from %d P%-5u/%-5u C%d\n", TimeMS(), mess->confix,
                NC2(portno), NC2(herport), conno);
#endif
        if (conp->state == SYN_RECEIVED) {
            BLOCKPREE();
            if (conp->txstat & S_PASSIVE) {
                if ( conp->backlog > 0 ) {
                    connblo[conp->icqcur].icqcur--;
                    conp->blockstat = 0;
                    conp->refsock = 0;
                } else {
                    conp->herport = 0;
#ifdef  INET6
                if (mess->ipv6.flag6 & FLAG6_IPV6)
                    Nsetheri6id (conno, NULL);
#endif
                    conp->heriid.l = 0xffffffff;
                    conp->state = LISTEN;
                }
            }
            else
                conp->rxstat |= (S_FATAL + S_RST);

            RESUMEPREE();

            clearconn(conp);

        }
        else if (conp->state != LISTEN) {

            BLOCKPREE();
            if ( conp->backlog > 0 && conp->state==ESTABLISHED) {

               conp2 = &connblo[conp->icqcur];

               while ( conp2->next && conp2->next != conp)
                 conp2 = conp2->next;

               if ( conp2->next != 0 && conp2->next == conp ) {
                 conp2->next = conp->next;
                 connblo[conp->icqcur].icqcur--;
                 conp->next = 0;
                 conp->blockstat |= 4;
                 conp->refsock = 0;
               }
            }
            conp->blockstat |= 4;
            conp->rxstat |= (S_FATAL + S_RST);
            RESUMEPREE();
        }
ret2:
        WAITNOMORE(SIG_RC(conno));
        WAITNOMORE(SIG_CC(conno));
        return -2;
    }

    us1 = NC2(thdrp->window);
    conp->lastrxtime = TimeMS();
#if NTRACE >= 3
    Nprintf(
      "SC %09lu C%02d/%-5u ST%02d DL%04d W%04u/%04u AK%08lx SQ%08lx %02x\n",
      conp->lastrxtime, conno, NC2(conp->myport), conp->state, tlen,
      conp->mywindow, us1, UL2.l, UL1.l, thdrp->flags);
#endif

#ifdef TCP_OPTIONS
    conp->TCPOrxlen = 0;
#endif
    for (cp = (char *) mess + mess->offset + OPTION_OFFSET;
         cp < (char *) mess + mess->offset + hlen;) {
        switch (cp[0]) {
        case 1:
            cp++;
            break;
        case 2:
            if (cp[1] != 4) {
                return -2;
            }
            mss = ((unsigned char *) cp)[3] | (((unsigned char *) cp)[2] << 8);
#if 1
            if (!mss)
                return -2;
#else
            i1 = MAXDAT;
#ifdef IPOPTIONS
            i1 -= 40;
#endif
#ifdef TCP_OPTIONS
            i1 -= 40;
#endif
            if (mss < i1) {
                return -2;
            }
#endif
#ifdef  INET6
        if (conp->ipv6.family == 28) {
            stat = Ngetmaxblo6(netno) -
#ifdef IPOPTIONS
                 ((conp->IPOtxlen) ? conp->IPOtxlen : conp->IPOrxsrlen) -
#endif
                I6hdr_SZ - Thdr_SZ;
        } else 
#endif
            stat = nets[netno].maxblo -
#ifdef IPOPTIONS
                 ((conp->IPOtxlen) ? conp->IPOtxlen : conp->IPOrxsrlen) -
#endif
                Ihdr_SZ - Thdr_SZ;
            conp->maxdat = mss <= stat ? mss : stat;
            cp += cp[1];
            break;
        case 4:
            if (cp[1] != 2) {
                return -2;
            }
#ifdef TCP_SACK
            conp->txstat |= S_SACK;
#endif
            cp += cp[1];
            break;
        case 5:
            if (cp[1] < 2) {
                return -2;
            }
#ifdef TCP_SACK
            if (conp->txstat & S_SACK) {
                conp->TCPOrxlen = cp[1];
                memcpy(conp->TCPOrxopt, &cp[2], conp->TCPOrxlen - 2);
            }
#endif
            cp += cp[1];
            break;
        default:
            if (cp[1] <= 0)
                goto lab2;
            cp += cp[1];
            break;
        }
    }

lab2:

#ifdef TCP_SACK
    if ((conp->txstat & S_SACK) && conp->TCPOrxlen > 2) {
        mp2 = conp->wackf;
        while ((mp = mp2) != 0) {
            mp2 = mp->next;
#ifdef  INET6
if (mp->ipv6.flag6 & FLAG6_IPV6)
            thdrp2 = (struct Thdr *) ((char *) mp + 
                I6hdr_SZ + ip6optsize(mp) + IPOFFSET);
else
#endif
            thdrp2 = (struct Thdr *) ((char *) mp +
                     (((*((char *) mp + IPOFFSET)) & 0xf) << 2) + IPOFFSET);
            GETLONG(UL3, thdrp2->seqno);
            sackp = (struct Sack *) (conp->TCPOrxopt);
            for (i1 = 0; i1 < ((conp->TCPOrxlen - 2)/8); i1++) {
                GETLONG(sackl, sackp->left);
                GETLONG(sackr, sackp->right);
                if ((UL3.l >= sackl.l) && (UL3.l < sackr.l)) {
                    mp->id = bSACK;
                    break;
                }
                else
                    sackp++;
            }
        }
    }
#endif


    if (thdrp->flags & ACK) {
        unsigned long tempackno = conp->ackno;
        int numack = 0;
        cflg = 0;
        i1 = 0;
        while ((mp = conp->wackf) != 0) {
#ifdef  INET6
if (mp->ipv6.flag6 & FLAG6_IPV6) {
            thdrp2 = (struct Thdr *) ((char *) mp + 
                        I6hdr_SZ + ip6optsize(mp) + IPOFFSET);
} else
#endif
            thdrp2 = (struct Thdr *) ((char *) mp +
                     (((*((char *) mp + IPOFFSET)) & 0xf) << 2) + IPOFFSET);
            GETLONG(UL3, thdrp2->seqno);
            if (i1 == 0) {
                conp->unackseq = UL3.l;
                i1 = 1;
            }
            UL3.l = UL2.l - UL3.l;
            if (UL3.l >= MAXWACK * MAXBUF || UL3.l == 0) {
                if (conp->txtout > MAXTXTOUT / 4)
                    conp->txtout = MAXTXTOUT / 4;
                break;
            }
#if NTRACE > 0
#ifdef TCP_SACK
            if (mp->id != bWACK && mp->id != bSACK)
#else
            if (mp->id != bWACK)
#endif
                Npanic("wack rem");
#endif
            if ((cflg | mp->retry) == 0) {
                UL3.l = conp->lastrxtime - mp->timems + Nclocktick;
                if (UL3.l > MAXTXTOUT)
                    goto lab7;
                UL3.l -= conp->txave / 8;
                conp->txave += UL3.l;
                if ((long) conp->txave < 0)
                    conp->txave = 40;
                if ((long) UL3.l < 0)
                    UL3.l = -UL3.l;
                UL3.l -= conp->txvar / 4;
                conp->txvar += UL3.l;
                if (conp->txvar < 10)
                    conp->txvar = 10;
                conp->txtout = (conp->txave / 8) + conp->txvar;
                if (conp->txtout < MINTXTOUT)
                    conp->txtout = MINTXTOUT;
                numack++;
            } else {
                numack = 0;
                cflg = 1;
            }
lab7:
            if (thdrp2->flags & SYN) {
                if (((conp->state == SYN_SENT) && (!(thdrp->flags & SYN))) ||
                   !((UL2.l <= conp->txseq) && (UL2.l >= conp->unackseq)))
                    break;
            }
            conp->wackf = mp->next;
            conp->nwacks -= MAXWACK;
            if (thdrp2->flags & FIN) {
                if (conp->state == FINWAIT_1)
                    conp->state = FINWAIT_2;
                else if (conp->state == LAST_ACK)
                    conp->state = CLOSED;
                else if (conp->state == CLOSING)
                    conp->state = TIMEWAIT;
            }
            Ndisable();
            delete = 0;
            if ( mp->offset != boTXDONE )
            {
                if ( mp->offset == mp->netno )
                {
                    delete = mp->id;
                    mp->id = bRELEASE;
                }
            }
            Nenable();
            if ( delete == 0 )
            {
                mp->id = bALLOC;
                Nrelbuf(mp);
            }

            conp->ackno = UL2.l;
        }
        if ( (conp->ackno != tempackno) && (numack != 0) )
        {
            if (conp->wackmax < (MAXWACK * MAXWACK)) {
                if (conp->wackmax < conp->wackslow)
                {
                    conp->wackmax += MAXWACK * numack;
                }
                else
                {
                    conp->wackmax += numack;
                }
                if ((MAXWACK * MAXWACK) < conp->wackmax )
                    conp->wackmax = (MAXWACK * MAXWACK);
            }
        }
    }

#ifdef TCP_SACK
    memset(conp->TCPOtxopt, 0, sizeof(conp->TCPOtxopt));
#endif

    if (!(thdrp->flags & SYN) && (conp->state != SYN_SENT)
          && (conp->state != LISTEN)) {
        if (conp->rxseq - UL1.l < MAXBUF && UL1.l + tlen - conp->rxseq < MAXBUF) {
            if ((i1 = conp->rxseq - UL1.l) > 0) {
                cp = (char *) thdrp + hlen;
                cp2 = cp + i1;
                mess->mlen -= i1;
                UL1.l += i1;
                PUTLONG(UL1, thdrp->seqno);
                i1 = tlen = tlen - i1;
                if (tlen <= 0)
                    goto err2;
                while (i1--)
                    *cp++ = *cp2++;
            }
            goto inseq;
        }
#ifdef TCP_SACK
        if (conp->txstat & S_SACK) {
            memset(conp->TCPOtxopt, 0, sizeof(conp->TCPOtxopt));
            sackp = (struct Sack *) (conp->TCPOtxopt + 2);
            PUTLONG(UL1, sackp->left);
            UL3.l = UL1.l + tlen;
            PUTLONG(UL3, sackp->right);
        }
#endif
        if (conp->rxseq - UL1.l < MAXWIND * MAXBUF)
            goto err2;
        if (UL1.l - conp->rxseq >= MAXWIND * MAXBUF)
            goto err1;
        mp2 = (MESS *) &conp->future;
        for (i1 = 0, mp = mp2->next; mp; mp2 = mp, mp = mp->next, i1++) {
            thdrp2 = (struct Thdr *) ((char *) mp + mp->offset);
            GETLONG(UL3, thdrp2->seqno);
            if (UL3.l == UL1.l && mp->mlen == mess->mlen)
                goto err1;
            if (UL3.l > UL1.l)
                break;
        }
#ifdef TCP_FASTRECOVER
        conp->sendack = ACKLIMIT;
#endif
        if (i1 >= MAXFUT) {
#if NTRACE >= 1
            Nprintf("FQ discard\n");
#endif
            goto err1;
        }

        mess->next = mp;
        mp2->next = mess;
        if (!mp)
            conp->window = us1;
        conp->txstat &= ~S_INSEQ;
#if NTRACE >= 1
        Nprintf("FQ queued SQ%08lx\n", UL1.l);
#endif
        goto err4;
    }

inseq:
    conp->txstat |= S_INSEQ;

    if ( (UL2.l >= conp->unackseq) && (UL2.l <= conp->txseq) ) {
        conp->window = us1;
    }

    switch (stat = conp->state) {
    case SYN_RECEIVED:
        if ((thdrp->flags & ACK) == 0)
            goto err1;
        conp->state = ESTABLISHED;
        conp->portno = mess->portno;
        if (conp->backlog > 0) {
            BLOCKPREE();
            conp2 = &connblo[conp->icqcur];
            while (conp2->next) {
                conp2 = conp2->next;
            }
            conp2->next = conp;
            conp->next = 0;
            RESUMEPREE();
            WAITNOMORE(SIG_CC(conp2 - &connblo[0]));
        }

#ifdef MIB2
        TCPgroup.tcpCurrEstab++;
#endif
    case ESTABLISHED:
    case FINWAIT_1:
    case FINWAIT_2:
    case CLOSING:
        if (thdrp->flags & SYN)
            goto err2;
        if ((i1 = tlen + (thdrp->flags & FIN)) == 0)
            break;

        if (thdrp->flags & S_URG) {
            if (conp->state != CLOSING) {
                conp->urgcnt = NC2(thdrp->urgp) + 1 - URGSTAND;
                conp->urgseq = UL1.l;
                conp->urgdata = *((char *)thdrp + hlen + NC2(thdrp->urgp) - URGSTAND);
                conp->urgflag = 1;
            }
        }
        if (conp->mywindow < tlen)
            goto err2;
        conp->mywindow -= tlen;

        conp->seqtoack = conp->rxseq = UL1.l + i1;
        if (conp->sendack == 0) {
            conp->acktime = conp->lastrxtime;
            conp->sendack = 1;
        }
        if (thdrp->flags & FIN) {
            conp->rxstat |= S_EOF;
            conp->sendack = ACKLIMIT;
            if (stat == FINWAIT_2)
                conp->state = TIMEWAIT;
            else if (stat == FINWAIT_1)
                conp->state = CLOSING;
            WAITNOMORE(SIG_CC(conno));
            WAITNOMORE(SIG_RC(conno));
            if (tlen == 0)
                goto retm5;
        }
        BLOCKPREE();
        if (tlen && conp->first) {
            mp = conp->last;
            if (mp->mlen + tlen <= MAXBUF) {
                thdrp2 = (struct Thdr *) ((char *) mp + mp->offset);
                memcpy((char *) mp + mp->mlen, (char *) thdrp + hlen, tlen);
                if ((thdrp->flags & S_URG) != 0)
                    conp->urgcnt += mp->mlen - mp->offset - sizeof(*thdrp2);
                mp->mlen += tlen;
                thdrp2->flags |= thdrp->flags & (S_PSH | S_URG);
                RESUMEPREE();
retm5:
                mess->conno = conno;
                return -5;
            }
        }
        RESUMEPREE();
        break;
    case CLOSED_WAIT:
        conp->state = CLOSED;
        break;
    case LISTEN:
        if ((thdrp->flags & ~PSH) != SYN) {
            tcp_reset( mess, LISTEN, tlen, conno, pseudop );
            return -3;
        }
        if (conp->backlog > 0) {
            BLOCKPREE();
            for (conno = 0; conno < NCONNS; conno++)
            {
                conp2 = &connblo[conno];
                if ((conp2->myport == conp->myport && conp2->txstat & S_PASSIVE
#if 1
                     && conp2->blockstat != 0 && conp2->netno == netno )
#else
                     && conp2->state == ESTABLISHED && conp2->netno == netno )
#endif
                     && conp2->backlog < 0 ){
                    ac_count++;
                }
            }
            RESUMEPREE();
            if ((conp->icqcur + ac_count) >= conp->backlog)
                return -1;
            BLOCKPREE();
            for (conno = 0; conno < NCONNS; conno++)
            {
                conp2 = &connblo[conno];
                if ( ! conp2->blockstat )
                {
                    if ( conp2->refcount == 0 && conp2->refsock == 0 )
                    {
                        *conp2 = *conp;
                        conp->icqcur++;
                        conp2->icqcur = conp - &connblo[0];
                        conp = conp2;
                        break;
                    }
                }
            }
            RESUMEPREE();
            if (conno == NCONNS) {
                conno = conp - connblo;
                WAITNOMORE(SIG_CC(conno));
                return -1;
            }
        }
        conp->txseq = conp->lastrxtime;
        conp->seqtoack = conp->rxseq = UL1.l + 1;
        conp->state = SYN_RECEIVED;
        conp->txstat |= S_PASSIVE;
        conp->wackslow = MAXWACK * MAXWACK;
        conp->wackmax = MAXWACK;

#ifdef MIB2
        TCPgroup.tcpPassiveOpens++;
#endif
        conp->herport = thdrp->myport;
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        ip6acpy(&conp->ipv6.reali6id, I6add1);
        Nsetheri6id (conno, (unsigned char *)I6add1);
        conp->realiid.l = conp->heriid.l = 0;
    } else
#endif
        conp->realiid.l = conp->heriid.l = pseudo.Iadd1;
        conp->netno = netno;
        conp->confix = mess->confix;
#ifdef IPOPTIONS
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        if (mess->offset > (IPOFFSET + I6hdr_SZ)) {
                ;
        }
    } else 
#endif
        if (mess->offset > (IPOFFSET + Ihdr_SZ)) {
            unsigned char *bp, length = 0;
            i1 = IPOFFSET + Ihdr_SZ;
            bp = (unsigned char *)mess + i1;
            i1 = mess->offset - i1;
            while (i1 > 0) {
                 if ((bp[0] == 0) || (bp[1] == 0))
                     break;
                 if (bp[0] == 1) {
                     i1--;
                     bp++;
                     continue;
                 }
                 if (((bp[0] == 0x83) || (bp[0] == 0x89)) &&
                     ((length = bp[1]) >= 7) && (i1 >= 7)) {
                     BLOCKPREE();
                     conp = &connblo[conno];
                     conp->IPOrxsropt[0] = bp[0];
                     conp->IPOrxsropt[1] = length = bp[1];
                     conp->IPOrxsropt[2] = 4;
                     hlen = 3;
                     tlen = length - Iid_SZ;
                     while (hlen <= tlen) {
                         memcpy((char *)&conp->IPOrxsropt[hlen], (bp + tlen), Iid_SZ);
                         memcpy((char *)&conp->IPOrxsropt[tlen], (bp + hlen), Iid_SZ);
                         hlen += Iid_SZ;
                         tlen -= Iid_SZ;
                     }
                     conp->IPOrxsrlen = (length + 3) & ~3;
                     conp->doffset += conp->IPOrxsrlen;
                     conp->maxdat  -= conp->IPOrxsrlen;
                     RESUMEPREE();
                     break;
                 }
                 i1 -= bp[1];
                 bp += bp[1];
            }
        }
#endif
        mess->mlen = 0x8000 | SYN | ACK;
        mess->conno = conno;
        writE(-5, mess);
        return -4;
    case SYN_SENT:
        if (thdrp->flags & ACK) {
            if ( (UL2.l <= conp->txseq) && (UL2.l >= conp->unackseq) ) {
                if (thdrp->flags & SYN) {
                    conp->seqtoack = conp->rxseq = UL1.l + 1;
                    conp->state = ESTABLISHED;
#ifdef  INET6
                if (conp->ipv6.family == 28 ) {
                    ip6acpy (&conp->ipv6.reali6id, I6add1);
                    conp->realiid.l = 0;
                } else
#endif
                    conp->realiid.l = pseudo.Iadd1;
#ifdef MIB2
                    TCPgroup.tcpCurrEstab++;
#endif
                    mess->mlen = 0x8000 | ACK;
                    mess->conno = conno;
                    mess->id = bRELEASE;
                    if (writE(-4, mess))
                        Nrelbuf(mess);
                    WAITNOMORE(SIG_CC(conno));
                    goto err4;
                }
                else {
                    goto err1;
                }
            } else {
                tcp_reset( mess, SYN_SENT, tlen, conno, pseudop);
                return -3;
            }

        } else if (thdrp->flags & SYN) {
            conp->seqtoack = conp->rxseq = UL1.l + 1;
            mess->mlen = 0x8000 | ACK | SYN;
            mess->conno = conno;
#ifdef  INET6
        if (conp->ipv6.family == 28 ) {
            ip6acpy (&conp->ipv6.reali6id, I6add1);
            conp->realiid.l = 0;
        } else
#endif
            conp->realiid.l = pseudo.Iadd1;
            writE(-5, mess);
            conp->state = SYN_RECEIVED;
            goto err4;
        }
        break;
    }
    WAITNOMORE(SIG_CC(conno));
    return tlen ? conno : -2;
err2:
    conp->sendack = ACKLIMIT;
err1:
    return -1;
err4:
    return -4;
}


static MESS *reaD(int conno)
{
    int hdroff, len;
    union {
        char c[4];
        short s[2];
        long l;
    } UL1;
#if NTRACE >= 2
    union {
        char c[4];
        short s[2];
        long l;
    } UL2;
#endif
    MESS *mp;
    register struct Thdr *thdrp;
    register struct CONNECT *conp;

    conp = &connblo[conno];

    mp = conp->protoc[1]->reaD(conno);
    if (mp == 0)
        return 0;

    hdroff = mp->offset;
    thdrp = (struct Thdr *) ((char *) mp + hdroff);
    conp->herport = thdrp->myport;
    mp->offset = hdroff + ((thdrp->hdrlen >> 4) << 2);
    len = mp->mlen - mp->offset;
    conp->tcpflags = thdrp->flags;
    GETLONG(UL1, thdrp->seqno);
    if (conp->tcpflags & S_URG)
    {
        hdroff = conp->urgseq - UL1.l;
        if (hdroff < 0 || hdroff >= len)
            conp->tcpflags &= ~ S_URG;
    }
    Ndisable();
    conp->mywindow += len;
    Nenable();
    if (conp->first == 0 && (conp->seqtoack - conp->ackdseq > conp->maxdat ||
                         conp->mywindow - conp->prevwindow >= conp->maxdat))
        conp->sendack = ACKLIMIT;
    else
        conp->sendack++;
    nets[mp->netno].worktodo = 1;
    WAITNOMORE(SIG_RN(mp->netno));
#if NTRACE >= 2
    GETLONG(UL2, thdrp->ackno);
    Nprintf(
      "RX %09lu C%02d/%-5u ST%02d DL%04d            AK%08lx SQ%08lx %02x\n",
      TimeMS(), conno, NC2(conp->myport), conp->state, len, UL2.l, UL1.l,
      thdrp->flags );
#endif
    return mp;
}


static int opeN(int conno, int flags)
{
    int i1;
    MESS *mess;
    register struct CONNECT *conp;

    (void) i1;
    conp = &connblo[conno];
    conp->wackslow = MAXWACK * MAXWACK;
    conp->wackmax = MAXWACK;
    conp->maxdat = MAXDAT;

    if (conp->herport == 0) {
        conp->rxtout = 0xffffffff;
        conp->state = LISTEN;
    }
    else {
        if ((mess = Ngetbuf()) == 0)
            return NE_NOBUFS;
        conp->state = SYN_SENT;
        conp->rxtout = TCPOPENTXTOUT;
#ifdef MIB2
        TCPgroup.tcpActiveOpens++;
#endif
        mess->mlen = 0x8000 | SYN;
        mess->netno = conp->netno;
        mess->portno = conp->portno;
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        Nsetmyi6id (conno, (unsigned char *)&conp->ipv6.heri6id);
        ip6acpy (mess->ipv6.target6, &conp->ipv6.heri6id); 
        mess->target = 0;
    } else
#endif
        mess->target = conp->heriid.l;
        if (writE(conno, mess))
            Nrelbuf(mess);
    }

    if (conp->txstat & S_NOWA)
        conp->rxtout = 0;
    if (flags & S_NOWA || conp->txstat & S_NOWA)
        return 0;

    WAITFOR(conp->state == ESTABLISHED || (conp->rxstat & S_FATAL),
        SIG_CC(conno), conp->rxtout, i1);
    if (conp->state != ESTABLISHED) {
#if NTRACE >= 1
        Nprintf("OP C%d/%-5u S%d failed\n", conno, NC2(conp->myport), conp->state);
#endif
#ifdef MIB2
        TCPgroup.tcpAttemptFails++;
#endif
        return ETIMEDOUT;
    }
    return 1;
}


static int closE(int conno)
{
    int i1, stat;
    MESS *mp;
    register struct CONNECT *conp;

    conp = &connblo[conno];
    switch (conp->state) {
    case LISTEN:
        return 0;
    case SYN_SENT:
        clearconn(conp);
        conp->protoc[1]->closE(conno);
        return 0;
    case ESTABLISHED:
        conp->state = conp->rxstat & S_EOF ? LAST_ACK : FINWAIT_1;
#ifdef MIB2
        TCPgroup.tcpCurrEstab--;
#endif
        if (conp->rxstat & S_FATAL) {
            stat = 3;
            goto ret3;
        }
        if ((mp = Ngetbuf()) != 0) {
            mp->mlen = 0x8000 | FIN | ACK;
            mp->netno = conp->netno;
            mp->portno = conp->portno;
#ifdef  INET6
        if (conp->ipv6.family == 28 ) {
            Nsetmyi6id (conno, (unsigned char *)&conp->ipv6.heri6id);
            ip6acpy (mp->ipv6.target6, &conp->ipv6.heri6id); 
            mp->target = 0;
        } else
#endif
            mp->target = conp->heriid.l;
            if (writE(conno, mp))
                Nrelbuf(mp);
        }
        else {
            stat = 1;
            goto ret3;
        }
        break;
    }
    if (conp->rxstat & S_FATAL) {
        stat = 3;
        goto ret3;
    }
    stat = conp->rxstat & S_NOACK ? 3 : 1;
    if (conp->txstat & S_NOWA)
        goto ret3;

    if (conp->l_linger)
        conp->rxtout = conp->l_linger;
    else
        conp->rxtout = TOUT_READ;

    WAITFOR(conp->state == CLOSED || conp->state == TIMEWAIT ||
            (conp->rxstat & S_FATAL), SIG_CC(conno),conp->rxtout, i1);
    if (i1) {
        stat = 3;
#if NTRACE >= 1
        Nprintf("CL %ld C%d/%-5u incomplete\n", TimeMS(), conno, NC2(conp->myport));
#endif
    }
ret3:
    conp->blockstat = 4;
    conp->protoc[1]->closE(conno);
    return stat;
}


static void timeout(int conno)
{
    int delete;
    int hdroff;
    unsigned short us1;
    unsigned long ul1;
    union {
        char c[4];
        short s[2];
        long l;
    } UL, UL2;
    unsigned NLONG *ulp;
    MESS *mp;
    struct CONNECT *conp;
    register struct Thdr *thdrp;

    conp = &connblo[conno];

    while ( (conp->txstat & S_INSEQ) &&  conp->future ) {
        conp->txstat &= ~S_INSEQ;
        mp = conp->future;
        conp->future = mp->next;
        handlePacket(conp->protoc[0], mp, 0);
    }

    BLOCKPREE();
    if (conp->ostreamb){
        mp = conp->ostreamb;
        if (conp->blockstat == 1 && conp->nwacks == 0 && conp->window >= (mp->mlen - mp->offset)) {
            mp = conp->ostreamb;
            conp->ostreamb = 0;
            RESUMEPREE();
            mp->conno = conno;
            if (writE(-7, mp))
                Nrelbuf(mp);
            BLOCKPREE();
        }
    }
    RESUMEPREE();

    ul1 = TimeMS();

    if ((conp->blockstat == 4 && ((ul1 - conp->lastrxtime > MAXCDEL) ||
        (conp->rxstat & S_FATAL) || (conp->state == CLOSED))) ||
        ((conp->blockstat & 0x04) && (conp->rxstat & S_RST)) &&
        (conp->refcount == 0))
    {
        clearconn(conp);
        conp->blockstat = 0;
        ussHostRelease(conp->confix);
#ifdef MIB2
        if (conp->state == ESTABLISHED)
            TCPgroup.tcpCurrEstab--;
#endif
        goto lab3;
    }

#ifdef KEEPALIVETIME
    if ((conp->txstat & S_KEEPA) && conp->state == ESTABLISHED &&
        (conp->rxstat & S_FATAL) == 0) {
        if (ul1 - conp->lastrxtime > KEEPALIVETIME &&
            ul1 - conp->acktime > KEEPALIVETIME) {
            if (ul1 - conp->lastrxtime < 8 * KEEPALIVETIME) {
                conp->acktime = ul1;
                conp->sendack = 100;
            } else {
                conp->rxstat |= S_FATAL + S_EOF;
                WAITNOMORE(SIG_RC(conno));
            }
        }
    }
#endif

    if (conp->sendack) {
        if (conp->sendack < ACKLIMIT && ul1 - conp->acktime < ACKDELAY) {
#if MT
            nets[conp->netno].nettasktout = ACKDELAY;
#endif
            goto noack;
        }
        if ((mp = Ngetbuf()) != 0) {
            mp->mlen = 0x8000 | ACK;
            mp->netno = conp->netno;
            mp->portno = conp->portno;
#ifdef  INET6
        if (conp->ipv6.family == 28 ) {
            Nsetmyi6id (conno, (unsigned char *)&conp->ipv6.heri6id);
            ip6acpy (mp->ipv6.target6, &conp->ipv6.heri6id); 
            mp->target = 0;
        } else
#endif
            mp->target = conp->heriid.l;
            mp->conno = conno;
            mp->id = bRELEASE;
            if (writE(-6, mp))
                Nrelbuf(mp);
        }
    }

noack:
    if ((mp = conp->wackf) == 0)
        goto lab3;
    if (mp->offset != boTXDONE)
        goto lab3;
#if NTRACE > 0
#ifdef TCP_SACK
    if (mp->id != bWACK && mp->id != bSACK)
#else
    if (mp->id != bWACK)
#endif
        Npanic("timeouts wack");
#endif
    if ((conp->blockstat & 0x41) == 0x41)
        conp->blockstat &= 0xbf;
    else if (ul1 - mp->timems < conp->txtout)
        goto lab3;

    conp->wackslow = ((conp->wackmax / 2) > MAXWACK) ?
                      (conp->wackmax / 2) : MAXWACK;
    conp->wackmax = conp->wackslow;

#ifdef TCP_SACK
    if (mp->id == bSACK)
        mp->id = bWACK;
#endif

    conp->txtout <<= 1;
    if (conp->txtout > MAXTXTOUT)
        conp->txtout = MAXTXTOUT;
    if ( ((mp->retry == RETX_THR_R2) || (conp->rxstat & S_FATAL)) &&
           (!(conp->txstat & S_PROBE)) ) {
        conp->wackf = mp->next;
        conp->nwacks -= MAXWACK;
        Ndisable();
        delete = 0;
        if ( mp->offset != boTXDONE )
        {
            if ( mp->offset == mp->netno )
            {
                delete = mp->id;
                mp->id = bRELEASE;
            }
        }
        Nenable();
        if ( delete == 0 )
        {
            mp->id = bALLOC;
            Nrelbuf(mp);
        }

        BLOCKPREE();
        if (conp->state == SYN_RECEIVED) {
#ifdef MIB2
            TCPgroup.tcpAttemptFails++;
#endif
            if (conp->backlog > 0) {
                connblo[conp->icqcur].icqcur--;
                conp->blockstat = 0;
                conp->refsock = 0;
            } else {
               conp->state = LISTEN;
#ifdef  INET6
            if (conp->ipv6.family == 28 )
               Nsetheri6id (conno, NULL);
#endif
               conp->heriid.l = 0xffffffff;
               conp->herport = 0;
            }
        } else {
            conp->rxstat |= S_NOACK + S_FATAL;
        }
        RESUMEPREE();
        WAITNOMORE(SIG_RC(conno));
        goto lab3;
    }
    mp->retry++;
    mp->timems = ul1;

    hdroff = IPOFFSET + Ihdr_SZ;
#ifdef IPOPTIONS
        if (conp->IPOtxlen)
            hdroff += conp->IPOtxlen;
        else if (conp->IPOrxsrlen)
            hdroff += conp->IPOrxsrlen;
#endif
#ifdef  INET6
        IPOFFSET + (conp->ipv6.family == 28 ? I6hdr_SZ : Ihdr_SZ);
#else
        IPOFFSET + Ihdr_SZ;
#endif

    thdrp = (struct Thdr *) ((char *) mp + hdroff);
    UL.l = conp->seqtoack;
    GETLONG(UL2,thdrp->ackno);
    if ( UL.l != UL2.l ) {
      us1 = NC2(thdrp->chksum);

      ussChecksumAdjust((unsigned char *)&us1,
                        (unsigned char *)UL2.c, 4,
                        (unsigned char *)UL.c, 4);
      PUTLONG(UL, thdrp->ackno);
      thdrp->chksum = NC2(us1);
    }

#if NTRACE >= 1
#ifdef  INET6
if (conp->ipv6.family == 28 )
    ulp = (unsigned NLONG *) ((char *) mp + IPOFFSET + 44);
else
#endif
    ulp = (unsigned NLONG *) ((char *) mp + IPOFFSET + 24);
    GETLONG(UL, ulp);
    Nprintf("reTX%d %lu C%d/%-5u ST%d SQ%lx MS%ld\n", mp->retry, ul1,
            conno, NC2(conp->myport), conp->state, UL.l, conp->txtout);
#endif

#ifdef MIB2
    TCPgroup.tcpRetransSegs++;
#endif

#ifdef  INET6
if (conp->ipv6.family == 28 )
    *((char *)mp + IPOFFSET + 6) = IP_TCP;
else
#endif
    *((char *)mp + IPOFFSET + 9) = IP_TCP;

    conp->protoc[1]->writE(-5, mp);

lab3:
    return;
}

static int init(int netno, char *params)
{
#ifdef MIB2
    memset(&TCPgroup, 0, sizeof(TCPgroup));
    TCPgroup.tcpRtoMax = MAXTXTOUT;
#endif
    (void) netno;
    (void) params;
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}


GLOBALCONST
PTABLE ussTCPTable = {
    "TCP", init, timeout, screen, opeN, closE, reaD, writE, ioctl,
       IP_TCP, Thdr_SZ
};
