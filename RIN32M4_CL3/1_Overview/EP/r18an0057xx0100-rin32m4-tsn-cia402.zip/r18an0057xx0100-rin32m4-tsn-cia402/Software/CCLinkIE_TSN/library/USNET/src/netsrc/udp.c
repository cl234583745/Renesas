//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#ifdef  INET6
#include "ip6.h"
#endif

#define NOCHKSUM 0

struct Uhdr {
    unsigned short myport;
    unsigned short herport;
    unsigned short tlen;
    unsigned short chksum;
};
#ifdef USSW_DIRECTED_BROADCAST
struct CclinkCyclicHdr {
    unsigned char fixed1[7];
    unsigned char length[2];
    unsigned char fixed2[2];
    unsigned char command[2];
    unsigned char sub[2];
    unsigned char version[2];
    unsigned char rsv1[2];
    unsigned char offset[2];
};
struct CclinkCyclicInfo {
    unsigned long master;
    unsigned char group;
    unsigned char rsv1;
    unsigned short seqno;
    unsigned short tmout;
    unsigned short tmoutcnt;
    unsigned short idno;
    unsigned short slavecnt;
    unsigned short status;
    unsigned short rsv2;
    unsigned long slaveid;
};
const static unsigned char CCLINK_HDR_FIXED1[] = {0x50, 0x00, 0x00, 0xFF, 0xFF, 0x03, 0x00};
const static unsigned char CCLINK_CYCLICK_COMMAND[] = {0x70, 0x0E};
const static unsigned char CCLINK_CYCLICK_SUB[] = {0x00, 0x00};
#define CCLINK_RWW_RY_DATA_LENGTH   72
#endif
#define Uhdr_SZ 8
#define IP_UDP 17
#define ESTABLISHED   1
#define LISTEN       16
#define ACTCONN      17

extern struct CONNECT connblo[];
extern struct NET nets[];
extern PTABLE ussUDPTable;

#ifdef MIB2
struct UDPgroup UDPgroup;
#endif
#ifdef USSW_DIRECTED_BROADCAST
extern struct DETECTIPDATA detectIpInfo;
#endif

static int opeN(int conno, int flags)
{
    int i1;
    register struct CONNECT *conp;

    conp = &connblo[conno];
    conp->txstat |= flags & S_NOCON;
    conp->prevwindow = conp->herport;
#if NTRACE >= 2
    Nprintf("UO C%d/%x %x\n", conno, NC2(conp->myport), NC2(conp->herport));
#endif
    if (conp->herport)
    {
        i1 = conp->protoc[1]->opeN(conno, flags);
        if ((flags & S_NOCON) == 0)
            conp->state = ACTCONN;
        return i1;
    }
    conp->rxtout = 0xffffffff;
    conp->state = LISTEN;
    conp->passive = 1;
    if ((flags | conp->txstat) & S_NOWA)
        return 0;
    WAITFOR(conp->state==ESTABLISHED||(conp->rxstat&S_FATAL), SIG_RC(conno),
        conp->rxtout, i1);
    if (i1)
        return ETIMEDOUT;
    if (conp->state != ESTABLISHED)
        return NE_PROTO;
    return 1;
}


static int closE(int conno)
{
    struct CONNECT *conp;

    conp = &connblo[conno];
#if NTRACE >= 2
    Nprintf("UC C%d/%x %x\n", conno, NC2(conp->myport), NC2(conp->herport));
#endif
    return conp->protoc[1]->closE(conno);
}


static int screen(MESS *mess)
{
    int netno, conno, portno, herport, tlen;
    register struct Uhdr *uhdrp;
    register struct CONNECT *conp;
    struct { short s[2]; unsigned char Iadd1[Iid_SZ], Iadd2[Iid_SZ];
    unsigned short us; } pseudo;
#ifdef USSW_DIRECTED_BROADCAST
    int detectedFlags_old = 0;
#endif
#ifdef  INET6
    long I6add1[I6id_SZ/4];
    long I6add2[I6id_SZ/4];
#endif

    uhdrp = (struct Uhdr *)((char *)mess + mess->offset);
    netno = mess->netno;
    portno = uhdrp->herport;
    herport = uhdrp->myport;


#if NOCHKSUM == 0
    if (uhdrp->chksum)
    {
#ifdef INET6
    if (mess->ipv6.flag6 & FLAG6_IPV6) {
        ip6acpy(I6add1, (char *) mess + mess->conno);
        ip6acpy(I6add2, (char *) mess + mess->conno + I6id_SZ);
        tlen = NC2(uhdrp->tlen);
        if (tlen < Uhdr_SZ || tlen != mess->mlen - mess->offset) {
            goto err1;
        }
        if (tlen & 1) *((char *) uhdrp + tlen) = 0;
        if (Ncksum6((char *)mess + (MESSH_SZ+LHDRSZ), IP_UDP,
                (char *)uhdrp, tlen) != 0xffff)
        {
#if NTRACE >=1
            Nprintf("#udp: ip6chksum fail\n");
#endif
            goto err1;
        }
    } else {
#endif
        memcpy((char *)&pseudo.Iadd1, (char*)mess+mess->conno, 2*Iid_SZ);
        tlen = NC2(uhdrp->tlen);
        if (tlen < Uhdr_SZ || tlen != mess->mlen - mess->offset) {
            goto err1;
        }
        if (tlen & 1)
            *((char *)uhdrp + tlen) = 0;
        pseudo.s[0] = NC2(IP_UDP);
        pseudo.s[1] = uhdrp->tlen;
        pseudo.us = Nchksum((unsigned short *)uhdrp, (tlen+1)/2);
        if (Nchksum((unsigned short *)&pseudo, 14>>1) != (unsigned short)0xffff)
        {
#ifdef MIB2
            UDPgroup.udpInErrors++;
#endif
            goto err1;
        }
#ifdef INET6
    }
#endif
    }
#endif

#ifdef USSW_DIRECTED_BROADCAST
    if (detectIpInfo.detectPort && (ntohs(portno) == detectIpInfo.detectPort)) {
        struct CclinkCyclicHdr *chdr;
        struct CclinkCyclicInfo *cinfo;
        int i1, reqsize, offset;

        detectedFlags_old = detectIpInfo.detectedFlags;
        chdr = (struct CclinkCyclicHdr *)
                ((char *)mess + mess->offset + sizeof(struct Uhdr));
        offset = chdr->offset[0] | (chdr->offset[1] << 8);
        reqsize = ((char *)chdr->command - (char *)uhdrp) + offset;

        if ((reqsize < tlen) &&
            !memcmp(chdr->fixed1, CCLINK_HDR_FIXED1, sizeof(chdr->fixed1)) &&
            !memcmp(chdr->command, CCLINK_CYCLICK_COMMAND, sizeof(chdr->command)) &&
            !memcmp(chdr->sub, CCLINK_CYCLICK_SUB, sizeof(chdr->sub))) {

            cinfo = (struct CclinkCyclicInfo *)((char *)chdr->command + offset);
            reqsize += 
                sizeof(struct CclinkCyclicInfo) - sizeof(cinfo->slaveid) + 
                cinfo->slavecnt * (sizeof(cinfo->slaveid) + CCLINK_RWW_RY_DATA_LENGTH);

            if (reqsize <= tlen) {
                for (i1 = 0; i1 < cinfo->slavecnt; i1++) {
                    unsigned long id = *(unsigned long *)(&cinfo->slaveid + i1);
                    if ((id & 0xff) == detectIpInfo.detectLastOctet) {
                        detectIpInfo.Iaddr.l = htonl(id);
                        detectIpInfo.detectedFlags = 1;
                        break;
                    }
                }
                detectIpInfo.recvTime = TimeMS();
            }
        }
    }
	if (((detectedFlags_old == 0) && (detectIpInfo.detectedFlags == 1))
	 || (detectIpInfo.detectPort != ntohs(portno))
	 || (detectIpInfo.detectPort == 0)) {
#endif
    for (conno = 0; conno < NCONNS; conno++)
    {
        conp = &connblo[conno];
        if (conp->blockstat == 0 || conp->blockstat == 2)
            continue;
        if (conp->myport != portno)
            continue;
        if (conp->protoc[0] != &ussUDPTable)
            continue;
#ifdef  INET6
        if (((mess->ipv6.flag6 & FLAG6_IPV6) && (conp->ipv6.family != 28)) ||
            (!(mess->ipv6.flag6 & FLAG6_IPV6) && (conp->ipv6.family == 28)))
            continue;
#endif
        if ((conp->state & 1) && (conp->txstat & S_NOCON) == 0)
        {
#ifdef  INET6
        if (mess->ipv6.flag6 & FLAG6_IPV6){
            if (ip6acmp (conp->ipv6.heri6id.c, mess->ipv6.target6) != 0 &&
                ip6acmp (conp->ipv6.heri6id.c, in6addr_none) != 0)
                 continue;
        } else {
#endif
            if (mess->target != conp->heriid.l &&
                conp->heriid.l != 0xffffffff &&
                conp->heriid.l != (mess->target|~netconf[mess->confix].Imask.l))
            {
                continue;
            }
#ifdef  INET6
        }
#endif
            if (conp->passive == 1) {
                conp->herport = herport;
            }
            else {
                if (conp->herport == 0) {
                    conp->herport = herport;
                }
                if (conp->herport != herport) {
                    continue;
                }
            }
        }
        else {
            if (conp->offerediid.l != 0){
                if (conp->netno != netno)
                    continue;
            }
        }
        goto lab1;
    }
#ifdef USSW_DIRECTED_BROADCAST
    }
#endif
#ifdef MIB2
    UDPgroup.udpNoPorts++;
#endif
    return -6;

err1:
    return -1;

lab1:
    if (conp->state == LISTEN)
    {
        conp->herport = herport;
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        Nsetheri6id(conno, mess->ipv6.target6);
        conp->heriid.l = 0;
    } else
#endif
        conp->heriid.l = mess->target;
    }

    if (conp->state != ESTABLISHED)
    {
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        conp->maxdat = Ngetmaxblo6(netno) - mess->offset +
            MESSH_SZ + LHDRSZ - Uhdr_SZ;
    } else
#endif
        conp->maxdat = nets[netno].maxblo - mess->offset +
            MESSH_SZ + LHDRSZ - Uhdr_SZ;
        if (conp->state >= LISTEN)
        {
            if (conp->state != ACTCONN)
                conp->confix = mess->confix;
            conp->state = ESTABLISHED;
            conp->netno = netno;
        }
    }

#if NTRACE >= 2
    Nprintf("US C%d/%x %x D%d\n", conno, NC2(conp->myport), NC2(conp->herport),
        mess->mlen);
#endif
    return conno;
}


static MESS *reaD(int conno)
{
    int mlen, hdroff;
    MESS *mess;
    register struct Uhdr *uhdrp;
    register struct CONNECT *conp;

    conp = &connblo[conno];
    mess = conp->protoc[1]->reaD(conno);
    if (mess == 0)
        return 0;
    hdroff = mess->offset;
    mess->offset = hdroff + Uhdr_SZ;
    uhdrp = (struct Uhdr *)((char *)mess + hdroff);
    mlen = NC2(uhdrp->tlen);
    mess->mlen = mlen + hdroff;
    if (conp->prevwindow == 0 && (conp->txstat & S_NOCON))
    {
#ifdef  INET6
    if (conp->ipv6.family == 28 ) {
        Nsetheri6id(conno, mess->ipv6.target6);
        conp->heriid.l = 0;
    } else
#endif
        conp->heriid.l = mess->target;
        conp->herport = uhdrp->myport;
        conp->confix = mess->confix;
        conp->netno = mess->netno;
    }
#if NTRACE >= 2
    hdroff = mess->offset;
    Nprintf("UR C%d/%x %x D%d %02x%02x%02x%02x\n", conno, NC2(conp->myport),
        NC2(conp->herport), mlen-Uhdr_SZ,
        ((unsigned char *)mess)[hdroff], ((unsigned char *)mess)[hdroff+1],
        ((unsigned char *)mess)[hdroff+2], ((unsigned char *)mess)[hdroff+3]);
#endif
#ifdef MIB2
    UDPgroup.udpInDatagrams++;
#endif
    return mess;
}


static int writE(int conno, MESS *mess)
{
    int hdroff, mlen;
    register struct Uhdr *uhdrp;
    register struct CONNECT *conp;
    struct { short s[2]; unsigned char Iadd1[Iid_SZ], Iadd2[Iid_SZ]; } pseudo;

    conp = &connblo[conno];
    if (conp->state == LISTEN) {
        return EBADF;
    }
    mess->offset -= Uhdr_SZ;
    hdroff = mess->offset;
    uhdrp = (struct Uhdr *)((char *)mess + hdroff);
    mlen = mess->mlen - hdroff;
    if (mlen & 1)
        *((char *)uhdrp + mlen) = 0;
    uhdrp->tlen = NC2(mlen);
    uhdrp->myport = conp->myport;
    uhdrp->herport = conp->herport;
#ifdef  INET6
if (conp->ipv6.family == 28 ) {
    uhdrp->chksum = 0;
    mess->ipv6.sum6 = mess->offset + 6;
    mess->ipv6.flag6 |= FLAG6_SUM6;
} else {
#endif
    *(Iid *)&pseudo.Iadd1 = conp->heriid;
    *(long *)&pseudo.Iadd2 = netconf[nets[conp->netno].confix].Iaddr.l;
    pseudo.s[0] = NC2(IP_UDP);
    pseudo.s[1] = uhdrp->tlen;
#if NOCHKSUM == 0
    uhdrp->chksum = Nchksum((unsigned short *)&pseudo, 12>>1);
    uhdrp->chksum = ~Nchksum((unsigned short *)uhdrp, (mlen+1)/2);
    if (uhdrp->chksum == 0)
        uhdrp->chksum = 0xffff;
#else
    uhdrp->chksum = 0;
#endif
#ifdef  INET6
}
#endif
#if NTRACE >= 2
    hdroff += Uhdr_SZ;
    Nprintf("UW C%d/%x D%d %02x%02x%02x%02x\n", conno, NC2(conp->myport),
        mlen-Uhdr_SZ,
        ((unsigned char *)mess)[hdroff], ((unsigned char *)mess)[hdroff+1],
        ((unsigned char *)mess)[hdroff+2], ((unsigned char *)mess)[hdroff+3]);
#endif
#ifdef MIB2
    UDPgroup.udpOutDatagrams++;
#endif
#ifdef  INET6
if (conp->ipv6.family == 28 )
    *((char *)mess + MESSH_SZ+LHDRSZ+6) = IP_UDP;
else
#endif
    *((char *)mess + MESSH_SZ+LHDRSZ+9) = IP_UDP;
    mess->id = bRELEASE;
    return conp->protoc[1]->writE(conno, mess);
}


static int init(int netno, char *params)
{
    (void)netno;
    (void)params;

#ifdef MIB2
    memset(&UDPgroup, 0, sizeof(UDPgroup));
#endif
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}


GLOBALCONST
PTABLE ussUDPTable = {"UDP", init, 0, screen, opeN, closE, reaD, writE,
    ioctl, IP_UDP, Uhdr_SZ};

