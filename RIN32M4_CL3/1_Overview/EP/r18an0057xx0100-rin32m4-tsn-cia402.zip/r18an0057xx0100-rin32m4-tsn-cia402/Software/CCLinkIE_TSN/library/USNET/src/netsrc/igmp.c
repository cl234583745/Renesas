//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================



#include <string.h>
#include <stdlib.h>
#include "net.h"
#include "local.h"
#include "support.h"

#define IP_IGMP 2


#define MEMBERSHIP_QUERY           0x11
#define VERSION1_MEMBERSHIP_REPORT 0x12
#define VERSION2_MEMBERSHIP_REPORT 0x16
#define LEAVE_GROUP                0x17

#define UNSOLICITED_REPORT_INTERVAL 10000UL

extern struct NET nets[];
extern struct NETCONF netconf[];
extern struct CONNECT connblo[];
extern PTABLE  *const P_tab[];
extern PTABLE   ICMP_T,
                IP_T;

#define NONMEMBER       0
#define DELAYING_MEMBER 1
#define IDLE_MEMBER     2

#define MCLISTMAX 10

static struct mclist_t {
    Iid             mcaddr;
    int             netno;
    int             refcnt;
    int             state;
    unsigned long   timerstart;
    unsigned long   timerperiod;
    int             lasthostflag;
}               mclist[MCLISTMAX];

struct IGMPhdr {
    unsigned char   type;
    unsigned char   maxresptime;
    unsigned short  checksum;
    unsigned char   groupaddress[Iid_SZ];
};
#define IGMPhdr_SZ 8

static int writE(int conno, MESS *mess);

struct Ihdr {
    char            message_header[MESSH_SZ];
    char            link_header[LHDRSZ];
    unsigned char   verlen;
    unsigned char   tservice;
    unsigned short  tlen;
    unsigned short  frid;
    unsigned short  fragm;
    unsigned char   time;
    unsigned char   prot;
    unsigned short  chksum;
    unsigned char   from[Iid_SZ];
    unsigned char   to[Iid_SZ];
    unsigned char   options;
};
#define MH(mb) ((struct Ihdr *)mb)
#define IPOFFSET (MESSH_SZ+LHDRSZ)
extern unsigned short IPfragid;
#define IP_VER 4
#define ET_IP 0x0800
const unsigned char  routeralert[] = {0x94, 0x04, 0x00, 0x00};
const unsigned char  all_hosts_address[] = {224, 0, 0, 1};
const unsigned char  all_routers_address[] = {224, 0, 0, 2};
const unsigned char  general_query_address[] = {0, 0, 0, 0};

static int igmpstate;


static void     SendIGMPMessage(Iid iid, int netno, int type)
{
    int i1;
    MESS           *mp;
    struct IGMPhdr *igmpp;

    if ((mp = Ngetbuf()) == 0)
        return;
    mp->target = iid.l;
    mp->mlen = MESSH_SZ + LHDRSZ + Ihdr_SZ + sizeof(routeralert) + IGMPhdr_SZ;
    mp->netno = netno;
    mp->offset = MESSH_SZ + LHDRSZ + Ihdr_SZ + sizeof(routeralert);
    mp->id = bRELEASE;
    igmpp = (struct IGMPhdr *) ((char *) mp + MESSH_SZ + LHDRSZ + Ihdr_SZ
                                + sizeof(routeralert));
    igmpp->type = type;
    igmpp->maxresptime = 0;
    memcpy((char *) &igmpp->groupaddress, (char *) &iid, Iid_SZ);

    i1 = writE(ussMulticastIndex, mp);
    if (i1)
        Nrelbuf(mp);

}


static int      init(int netno, char *params)
{
    (void)netno;
    (void)params;

    igmpstate = 0;
    memset((void *)&mclist, 0, sizeof(mclist));
    return 0;
}


static int opeN(int conno, int flags)
{
    return connblo[conno].protoc[1]->opeN(conno, flags);
}


static int screen(MESS *mess)
{
    int             mlen;
    int             i;
    unsigned long   ul1;
    struct IGMPhdr  *hdrp;
    struct mclist_t *mcptr;
    Iid              iid;

    hdrp = (struct IGMPhdr *) ((char *) mess + mess->offset);
    mlen = mess->mlen - mess->offset;
    if (mlen < 8)
        goto err1;
    if (mlen & 1)
        *((char *)hdrp + mlen) = 0;
    if (Nchksum((unsigned short *)hdrp, (mlen + 1) / 2) != 0xffff)
        goto err1;
    memcpy((char *)&iid, (char *)hdrp->groupaddress, Iid_SZ);
    ul1 = TimeMS();
    switch (hdrp->type) {

    case MEMBERSHIP_QUERY:
        if (iid.l == *(unsigned long *)general_query_address) {
            for (i = 0; i < MCLISTMAX; i++) {
                mcptr = &mclist[i];
                if ((mcptr->refcnt) && (mcptr->netno == mess->netno)) {
                    if (((mcptr->state == DELAYING_MEMBER) &&
                        (mcptr->timerperiod - (ul1 - mcptr->timerstart) >
                        hdrp->maxresptime * 100UL)) ||
                        (mcptr->state == IDLE_MEMBER)) {
                        mcptr->lasthostflag = 1;
                        mcptr->timerstart = TimeMS();
                        mcptr->timerperiod =
                           ((unsigned long)hdrp->maxresptime * 100UL *
                            (unsigned long)rand()) /
                            (unsigned long)RAND_MAX;
                        mcptr->state = DELAYING_MEMBER;
                        return -1;
                    }
                }
            }
        }
        else {
            for (i = 0; i < MCLISTMAX; i++) {
                mcptr = &mclist[i];
                if ((mcptr->refcnt) && (mcptr->netno == mess->netno) &&
                    (mcptr->mcaddr.l == iid.l)) {
                    if (((mcptr->state == DELAYING_MEMBER) &&
                        (mcptr->timerperiod - (ul1 - mcptr->timerstart) >
                        hdrp->maxresptime * 100UL)) ||
                        (mcptr->state == IDLE_MEMBER)) {
                        mcptr->lasthostflag = 1;
                        mcptr->timerstart = TimeMS();
                        mcptr->timerperiod =
                           ((unsigned long)hdrp->maxresptime * 100UL *
                            (unsigned long)rand()) /
                            (unsigned long)RAND_MAX;
                        mcptr->state = DELAYING_MEMBER;
                        return -1;
                    }
                }
            }
        }
        break;
    case VERSION1_MEMBERSHIP_REPORT:
        break;
    case VERSION2_MEMBERSHIP_REPORT:
        for (i = 0; i < MCLISTMAX; i++) {
            mcptr = &mclist[i];
            if ((mcptr->refcnt) && (mcptr->netno == mess->netno) &&
                (mcptr->mcaddr.l == iid.l) &&
                (mcptr->state == DELAYING_MEMBER)) {
                mcptr->state = IDLE_MEMBER;
                mcptr->lasthostflag = 0;
                return -1;
            }
        }
        break;
    case LEAVE_GROUP:
        break;
    }

err1:
    return -1;
}


static int      closE(int conno)
{
    return connblo[conno].protoc[1]->closE(conno);
}


static int      writE(int conno, MESS * mess)
{
    int             i1;
    int             ihdrsz;
    int             mlen;
    unsigned short  us1;
    struct IGMPhdr *hdrp;
    struct NET     *netp;

    hdrp = (struct IGMPhdr *) ((char *) mess + mess->offset);
    mlen = mess->mlen - mess->offset;
    hdrp->checksum = 0;
    if (mlen & 1)
        *((char *) hdrp + mlen) = 0;
    hdrp->checksum = ~Nchksum((unsigned short *) hdrp, (mlen + 1) / 2);
    *((char *) mess + MESSH_SZ + LHDRSZ + 9) = IP_IGMP;



    netp = &nets[mess->netno];
    mess->offset = IPOFFSET;

    mess->confix = ussMulticastIndex;
    us1 = IPfragid++;
    MH(mess)->frid = NC2(us1);


    MH(mess)->verlen = (IP_VER << 4) | ((Ihdr_SZ + sizeof(routeralert)) >> 2);
    MH(mess)->time = 1;
    MH(mess)->fragm = 0;
    MH(mess)->tservice = 0;
    if (hdrp->type == LEAVE_GROUP) {
        memcpy((char *) &MH(mess)->to, (char *) all_routers_address, Iid_SZ);
        mess->target = *(unsigned long *)all_routers_address;
    }
    else {
        memcpy((char *) &MH(mess)->to, (char *) &mess->target, Iid_SZ);
    }
    memcpy((char *) &MH(mess)->from, (char *) &netconf[netp->confix].Iaddr,
           Iid_SZ);
    memcpy((char *) &MH(mess)->options, routeralert, sizeof(routeralert));

    i1 = mess->mlen - IPOFFSET;
    MH(mess)->tlen = NC2(i1);

    MH(mess)->chksum = 0;
    ihdrsz = (MH(mess)->verlen & 0xf) * 2;
    MH(mess)->chksum = ~Nchksum((unsigned short *) ((char *) mess + IPOFFSET),
                                ihdrsz);
    *(short *) ((char *) mess + MESSH_SZ + 12) = NC2(ET_IP);

    return netp->protoc[0]->writE(conno, mess);
}


int             ussHostGroupJoin(Iid iid, int netno)
{
    int             i;
    Iid             iid2;
    struct mclist_t *mcptr;

    if (igmpstate == 0) {
        iid2.c[0] = 224;
        iid2.c[1] = 0;
        iid2.c[2] = 0;
        iid2.c[3] = 1;

        nets[netno].protoc[ussLinkIndex]->ioctl(&nets[netno],
           ussMcastGroupJoinE, &iid2, sizeof(iid2));
        igmpstate = 1;
    }

    for (i = 0; i < MCLISTMAX; i++) {
        mcptr = &mclist[i];
        if ((mcptr->mcaddr.l == iid.l) &&
            (mcptr->netno == netno) &&
            (mcptr->refcnt))
        {
            mcptr->refcnt++;
            return 0;
        }
    }

    for (i = 0; i < MCLISTMAX; i++) {
        mcptr = &mclist[i];
        if (mcptr->refcnt == 0) {
            mcptr->mcaddr = iid;
            mcptr->netno = netno;
            mcptr->refcnt = 1;
            nets[netno].protoc[ussLinkIndex]->ioctl(&nets[netno],
               ussMcastGroupJoinE, &iid, sizeof(iid));
            SendIGMPMessage(iid, netno, VERSION2_MEMBERSHIP_REPORT);
            mcptr->lasthostflag = 1;
            mcptr->timerstart = TimeMS();
            mcptr->timerperiod =
                           (UNSOLICITED_REPORT_INTERVAL *
                            (unsigned long)rand()) /
                            (unsigned long)RAND_MAX;
            mcptr->state = DELAYING_MEMBER;
            return 0;
        }
    }
    return -1;
}


int             ussHostGroupLeave(Iid iid, int netno)
{
    int             i;
    struct mclist_t *mcptr;

    for (i = 0; i < MCLISTMAX; i++) {
        mcptr = &mclist[i];
        if ((mcptr->mcaddr.l == iid.l) &&
            (mcptr->netno == netno) &&
            (mcptr->refcnt)) {
            mcptr->refcnt--;
            if (mcptr->refcnt == 0) {
                nets[netno].protoc[ussLinkIndex]->ioctl(&nets[netno],
                    ussMcastGroupLeaveE, &iid, sizeof(iid));
                if (mcptr->lasthostflag) {
                    SendIGMPMessage(mcptr->mcaddr, mcptr->netno,
                                    LEAVE_GROUP);
                }
                mcptr->state = NONMEMBER;
            }
            return 0;
        }
    }
    return -1;
}


int             ussHostGroupCheck(Iid iid, int netno)
{
    int             i;
    struct mclist_t *mcptr;

    for (i = 0; i < MCLISTMAX; i++) {
        mcptr = &mclist[i];
        if ((mcptr->mcaddr.l == iid.l) &&
            (mcptr->netno == netno) &&
            (mcptr->refcnt))
            return 1;
    }
    if (iid.l == *(unsigned long *)all_hosts_address)
        return 1;
    return 0;
}


static void timeout(int conno)
{
    int i1;
    unsigned long ul1;
    struct mclist_t *mcptr;

    (void)conno;

    ul1 = TimeMS();
    for (i1 = 0; i1 < MCLISTMAX; i1++) {
        mcptr = &mclist[i1];
        if (mcptr->state == DELAYING_MEMBER) {
            if (ul1 - mcptr->timerstart > mcptr->timerperiod) {
                 SendIGMPMessage(mcptr->mcaddr, mcptr->netno,
                            VERSION2_MEMBERSHIP_REPORT);
                 mcptr->lasthostflag = 1;
                 mcptr->state = IDLE_MEMBER;
            }
        }
    }
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    switch (request) {

    default:
        return ussErrInval;
    }
}



GLOBALCONST
PTABLE ussIGMPTable = {
    "IGMP", init, timeout, screen, opeN, closE, 0, writE, ioctl, IP_IGMP, 0
};
