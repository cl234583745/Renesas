/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ManagementSM.h"
#ifdef	PTP_USE_MANAGEMENT
#include "ManagementSM_1588.h"
#include "ManagementAPI_1588.h"

#include "mdtransinterface_msg.h"

#include "ptp_CommonFunction.h"

#include "PortStateSelectionSM.h"

#include "MDPdelayReq.h"

#define	MGT_ACT_SETTBL_SZ			22

const MGT_ACT_SEL_TBL_1588	stMgt_Action_Set[MGT_ACT_SETTBL_SZ] = {
	{MGT_MNM_NULL_MANAGEMENT, 		PTPM_MGT_NULL_MANAGEMENT,		MGT_APPLIES_PORT,	&setManagement_0000},
	{MGT_MNM_USER_DESCRIPTION,		PTPM_MGT_USER_DESCRIPTION,		MGT_APPLIES_CLOCK,	&setManagement_0002},
	{MGT_MNM_PRIORITY1,				PTPM_MGT_PRIORITY1,				MGT_APPLIES_CLOCK,	&setManagement_2005},
	{MGT_MNM_PRIORITY2,				PTPM_MGT_PRIORITY2,				MGT_APPLIES_CLOCK,	&setManagement_2006},
	{MGT_MNM_DOMAIN,				PTPM_MGT_DOMAIN,				MGT_APPLIES_CLOCK,	&setManagement_2007},
	{MGT_MNM_SLAVE_ONLY,			PTPM_MGT_SLAVE_ONLY,			MGT_APPLIES_CLOCK,	&setManagement_2008},
	{MGT_MNM_LOG_ANNOUNCE_INTERVAL,	PTPM_MGT_LOG_ANNOUNCE_INTERVAL,	MGT_APPLIES_PORT,	&setManagement_2009},
	{MGT_MNM_ANNOUNCE_RECEIPT_TMOUT,PTPM_MGT_ANNOUNCE_RECEIPT_TMOUT,MGT_APPLIES_PORT,	&setManagement_200A},
	{MGT_MNM_LOG_SYNC_INTERVAL,		PTPM_MGT_LOG_SYNC_INTERVAL,		MGT_APPLIES_PORT,	&setManagement_200B},
	{MGT_MNM_VERSION_NUMBER,		PTPM_MGT_VERSION_NUMBER,		MGT_APPLIES_PORT,	&setManagement_200C},
	{MGT_MNM_TIME,					PTPM_MGT_TIME,					MGT_APPLIES_CLOCK,	&setManagement_200F},
	{MGT_MNM_CLOCK_ACCURACY,		PTPM_MGT_CLOCK_ACCURACY,		MGT_APPLIES_CLOCK,	&setManagement_2010},
	{MGT_MNM_UTC_PROPERTIES,		PTPM_MGT_UTC_PROPERTIES,		MGT_APPLIES_CLOCK,	&setManagement_2011},
	{MGT_MNM_TRACEABILITY_PROPERT,	PTPM_MGT_TRACEABILITY_PROPERT,	MGT_APPLIES_CLOCK,	&setManagement_2012},
	{MGT_MNM_TIMESCALE_PROPERTIES,	PTPM_MGT_TIMESCALE_PROPERTIES,	MGT_APPLIES_CLOCK,	&setManagement_2013},
	{MGT_MNM_UNICAST_NEGOTI_ENABLE,	PTPM_MGT_UNICAST_NEGOTI_ENABLE,	MGT_APPLIES_PORT,	&setManagement_2014},
	{MGT_MNM_PATH_TRACE_ENABLE,		PTPM_MGT_PATH_TRACE_ENABLE,		MGT_APPLIES_CLOCK,	&setManagement_2016},
	{MGT_MNM_GM_CLUSTER_TBL,		PTPM_MGT_GM_CLUSTER_TBL,		MGT_APPLIES_CLOCK,	&setManagement_2017},
	{MGT_MNM_UNICAST_MSTR_TBL,		PTPM_MGT_UNICAST_MSTR_TBL,		MGT_APPLIES_PORT,	&setManagement_2018},
	{MGT_MNM_PRIMARY_DOMAIN,		PTPM_MGT_PRIMARY_DOMAIN,		MGT_APPLIES_CLOCK,	&setManagement_4002},
	{MGT_MNM_DELAY_MECHANISM,		PTPM_MGT_DELAY_MECHANISM,		MGT_APPLIES_PORT,	&setManagement_6000},
	{MGT_MNM_LOG_MIN_PDREQ_INTERVAL,PTPM_MGT_LOG_MIN_PDREQ_INTERVAL,MGT_APPLIES_PORT,	&setManagement_6001}
};

static	USHORT	usManageErrId;

VOID ManagementSM_SET(MANAGEMENTSM_GD* pstSmGbl, CLOCKDATA* pstClockData, PORTDATA* pstPortData, USHORT usRecvMsgLen)
{
	PTPMSG_MANAGEMENT_1588*	pstMsg			= (PTPMSG_MANAGEMENT_1588*)pstSmGbl->puchMgtRxMsg;
	static	PTPMSG_MANAGEMENT_TLV	stMsgTLV;
	USHORT					usTLVLen		= 0;
	UCHAR*					puchMsgPtr		= NULL;
	SHORT					sLength			= 0;
	SHORT					sLoopNum		= MGT_ACT_SETTBL_SZ;
	SHORT					sLoop			= 0;

	BOOL					blRet	= FALSE;
	PTPMSG_MANAGEMENT_1588*	pstOutMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;

	PTPMSG_MANAGEMENT_TLV*			pstOutTLV	  = (PTPMSG_MANAGEMENT_TLV*)&pstOutMsg->stManagemant_TLV;

	puchMsgPtr	 = (UCHAR*)&pstMsg->stManagemant_TLV;

	pstOutMsg->stHeader.usMegLength = 0;

	if (pstMsg->stHeader.usMegLength > usRecvMsgLen)
	{
		sLength	 = usRecvMsgLen - PTPMSG_MANAGEMENT_SZ;
	}
	else
	{
		sLength	 = (SHORT)(pstMsg->stHeader.usMegLength - PTPMSG_MANAGEMENT_SZ);
	}


	while(sLength > 0)
	{
		usTLVLen = ptp_Mdl_ntohMsgManagTLV(puchMsgPtr, &stMsgTLV, sLength);
		if (usTLVLen == 0)
		{
			break;
		}
		if ((usTLVLen < 7) && (stMsgTLV.usManagementId != PTPM_MGT_NULL_MANAGEMENT))
		{
			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_MGTSM_1588_SET, PTP_LOGVE_87000003);
			continue;
		}
		blRet	= FALSE;
		if (stMsgTLV.usTLVType != PTPM_TLVTYP_MANAGEMENT)
		{
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_MGTSM_1588_GET, PTP_LOGVE_87000002);

			usTLVLen += stMsgTLV.usLengthField - PTPMSG_MGTTLV_MANAGEMENTID_SZ;

			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
		}
		else {
			for (sLoop = 0; sLoop < sLoopNum; sLoop++)
			{
				if (stMsgTLV.usManagementId == stMgt_Action_Set[sLoop].usManagementId)
				{
					if ((stMgt_Action_Set[sLoop].enTypeApplies == MGT_APPLIES_PORT)
						&& (pstPortData != NULL))
					{
						blRet = (*stMgt_Action_Set[sLoop].pfnFunc)(pstPortData, &stMsgTLV, pstOutTLV);
					}
					else if (stMgt_Action_Set[sLoop].enTypeApplies == MGT_APPLIES_CLOCK)
					{
						blRet = (*stMgt_Action_Set[sLoop].pfnFunc)(pstClockData, &stMsgTLV, pstOutTLV);
					}
					else
					{
					}
					break;
				}
			}
			if (blRet)
			{
				SetTxManagementMsg(pstSmGbl, pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else if ((blRet == FALSE) && (sLoop == sLoopNum))
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, PTPM_MGTER_NO_SUCH_ID);
				SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV *)pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, usManageErrId);
				SetTxManagementMsg(pstSmGbl, pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
				break;
			}
			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
		}
	}

	pstOutMsg = (PTPMSG_MANAGEMENT_1588 *)pstSmGbl->ulTxMgtMsg;
	if (pstOutMsg->stHeader.usMegLength)
	{
		TxManagementMsg(pstSmGbl, pstClockData);
	}

	return;
}

BOOL setManagement_0000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}


#define	MAX_USER_DESCRIPTION_LEN	128

BOOL setManagement_0002(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGD_CLOCK_DESCRIPTION);

	if (pstInTLV->stDataField.stUserDescription.stUserDescription.uchTextLength > MAX_USER_DESCRIPTION_LEN)
	{
		usManageErrId = PTPM_MGTER_WRONG_LENGTH;
		return FALSE;
	}
	nRet = SetIe1588UserDescription(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2005(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIORITY1);

	nRet = SetIe1588Priority1(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if ((nRet != RET_ENOERR) && (nRet != RET_SAMEVAL)) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

#if 1
	if (nRet != RET_SAMEVAL)
	{
		CLOCKDATA* pstClockData = pvData;

		portStateSelectionSM(PTP_EV_SYSTEMIDENTITYCHANGE, pstClockData->pstPortData);
	}
#endif
	return TRUE;
}

BOOL setManagement_2006(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIORITY2);

	nRet = SetIe1588Priority2(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if ((nRet != RET_ENOERR) && (nRet != RET_SAMEVAL)) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

#if 1
	if (nRet != RET_SAMEVAL)
	{
		CLOCKDATA* pstClockData = pvData;

		portStateSelectionSM(PTP_EV_SYSTEMIDENTITYCHANGE, pstClockData->pstPortData);
	}
#endif
	return TRUE;
}

BOOL setManagement_2007(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;






	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	usManageErrId = PTPM_MGTER_NOT_SUPPORTED;
	return FALSE;
}

BOOL setManagement_2008(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_SLAVE_ONLY);

	nRet = SetIe1588SlaveOnly(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2009(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_LOG_ANNOUNCE_INTERVAL);

	nRet = SetIe1588LogAnnounInterval(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_200A(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT);

	nRet = SetIe1588AnnounReceiptTimeout(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_200B(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_LOG_SYNC_INTERVAL);

	nRet = SetIe1588LogSyncInterval(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_200C(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_VERSION_NUMBER);

	nRet = SetIe1588VersionNum(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_200F(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TIME);

	nRet = SetIe1588Time(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2010(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_CLOCK_ACCURACY);

	nRet = SetIe1588ClockAccuracy(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	return TRUE;
}

BOOL setManagement_2011(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_UTC_PROPERTIES);

	nRet = SetIe1588UtcProperties(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	return TRUE;
}

BOOL setManagement_2012(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TRACEABILITY_PROPERTIES);

	nRet = SetIe1588TraceProperties(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2013(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_TIMESCALE_PROPERTIES);

	nRet = SetIe1588TimesProperties(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2014(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	usManageErrId = PTPM_MGTER_NOT_SUPPORTED;
	return FALSE;
}

BOOL setManagement_2016(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PATH_TRACE_ENABLE);

	nRet = SetIe1588PathTraceEnable(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}	

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_2017(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT		usDataFieldLen = 0;

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	usManageErrId = PTPM_MGTER_NOT_SUPPORTED;
	return FALSE;
}

BOOL setManagement_2018(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);

	usManageErrId = PTPM_MGTER_NOT_SUPPORTED;
	return FALSE;
}

BOOL setManagement_4002(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_PRIMARY_DOMAIN);

	nRet = SetIe1588PrimaryDomain(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_6000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_DELAY_MECHANISM);
	
	PORTDATA* pstPortData = (PORTDATA*)pvData;
	PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;

	ENUM_CLOCKSUPPORTTYPE_1588	enClockSupporType;


	enClockSupporType = pstPortData->pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;
	if ((enClockSupporType == ENUM_CSTYPE_TRANSCLOCKE2E_1588) ||
				 (enClockSupporType == ENUM_CSTYPE_TRANSCLOCKP2P_1588))
	{
		nRet = SetIe1588DelayMechanismTC(pstPortData->pstClockData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
		if (nRet == RET_ENOERR)
		{
			return FALSE;
		}
	}
	else
	{
		nRet = SetIe1588DelayMechanism(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
		if (nRet == RET_ENOERR)
		{
			if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_E2E)
			{
				MDPdelayReq(PTP_EV_CLOSE,pstPortData);
			}
			else if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
			{
				MDPdelayReq(PTP_EV_BEGIN,pstPortData);
			}
			else
			{
				return FALSE;
			}
		}
	}

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_6001(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet = 0;
	USHORT	usInfoLen	= sizeof(MGT_LOG_MIN_PDREQ_INTERVAL);

	nRet = SetIe1588LogMinPDReqInterval(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}


	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	SetMGT_TLVDataField(pstInTLV, pstOutTLV);
	return TRUE;
}

BOOL setManagement_NOP(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	return FALSE;
}
#endif
