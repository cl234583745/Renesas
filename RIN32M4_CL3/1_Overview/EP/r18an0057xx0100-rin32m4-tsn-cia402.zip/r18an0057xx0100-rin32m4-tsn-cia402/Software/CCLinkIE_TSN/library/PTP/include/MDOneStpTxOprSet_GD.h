/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDONESTPTXOPRSET_GD_H__
#define __MDONESTPTXOPRSET_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagONESTPTXOPRSET_ST {
	MDOSTO_NONE = 0,
	MDOSTO_NOT_ENABLED,
	MDOSTO_INITIALIZE,
	MDOSTO_SET_ONE_STEP_OPER,
	MDOSTO_STATUS_MAX

}	ONESTPTXOPRSET_ST;
#define	DMDOSTO_STATUS_MAX			4


typedef enum tagONESTPTXOPRSET_EV {
	MDOSTO_E_BEGIN = 0,
	MDOSTO_E_UMGTSETLOGONESTPTXO_ON,
	MDOSTO_E_UMGTSETLOGONESTPTXO_OF,
	MDOSTO_E_RCVDSIGNALINGMSG4,
	MDOSTO_E_CLOSE,
	MDOSTO_E_EVENT_MAX

}	ONESTPTXOPRSET_EV;
#define	DMDOSTO_E_EVENT_MAX			5

typedef struct tagOSTOSETTINGSM_GD
{
	ONESTPTXOPRSET_ST	enStsOneStpTxOprSet;
	
	BOOL				blRcvdSignalingMsg4;
	PTPMSG*				pstRcvdSignaling;
	
}	OSTOSETTINGSM_GD;

#endif
