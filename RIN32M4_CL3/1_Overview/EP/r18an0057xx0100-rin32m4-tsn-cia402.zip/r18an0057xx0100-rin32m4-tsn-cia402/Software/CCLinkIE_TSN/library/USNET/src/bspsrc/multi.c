//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include "net.h"
#include "local.h"
#include "support.h"
#include "usnet_supply.h"

#if RTOS_ID == RTOS_NONE

extern unsigned int clocks_per_sec;
unsigned long ussTicks;
int errno;

void (*ussEthernetIRQHandler)(void);

void ussClock_init()
{

}

void ussClock_term(void)
{
}

void ussClockHandler(void)
{
    ussTicks++;
}

int Nclkinit()
{
	clocks_per_sec = 1000;
    return 0;
}

unsigned long Nclock()
{
	unsigned long	ulResult;
	
	ulResult = ulUSN_GetLifeTime();
	return ulResult;
}

void Nclkterm()
{
}

void Ndisable( void )
{
	vUSN_vDisableDispatch();
}

void Nenable( void )
{

	vUSN_vEnableDispatch();

}

void ForceNenable(void) {
}
void IRinstall(int irno, int netno, void (*adr)(void))
{
}

void IRrestore(int irno)
{
}


#endif
