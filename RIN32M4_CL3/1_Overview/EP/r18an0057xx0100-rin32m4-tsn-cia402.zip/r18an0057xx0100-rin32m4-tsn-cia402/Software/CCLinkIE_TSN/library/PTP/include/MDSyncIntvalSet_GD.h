/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCINTVALSET_GD_H__
#define __MDSYNCINTVALSET_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagSYNCINTVSET_ST {
	MDSYCI_NONE = 0,
	MDSYCI_NOT_ENABLED,
	MDSYCI_INITIALIZE,
	MDSYCI_SET_INTERVAL,
	MDSYCI_STATUS_MAX,

}	SYNCINTVSET_ST;
#define	DMDSYCI_STATUS_MAX			4


typedef enum tagSYNCINTVSET_EV {
	MDSYCI_E_BEGIN = 0,
	MDSYCI_E_USEMGTSETLOGSYNINT_ON,
	MDSYCI_E_USEMGTSETLOGSYNINT_OF,
	MDSYCI_E_RCVDSIGNALINGMSG1,
	MDSYCI_E_CLOSE,
	MDSYCI_E_EVENT_MAX

}	SYNCINTVSET_EV;
#define	DMDSYCI_E_EVENT_MAX			5

typedef struct tagSISETTINGSM_GD
{
	SYNCINTVSET_ST		enStsSyncIntvalSet;

	BOOL				blRcvdSignalingMsg1;
	PTPMSG*				pstRcvdSignaling;

}	SISETTINGSM_GD;

#endif
