/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588
#include "MDSyncReceiveSM_1AS.h"
#include "ptp_PSSReceive_1588.h"
#include "ptp_SSSync_1588.h"
#include "ptp_BCSSend_1588.h"

#define D_FUNC	0
#define D_DBG	0


VOID	BCSSend_1588_00(CLOCKDATA*	pstClockData);
VOID	BCSSend_1588_01(CLOCKDATA*	pstClockData);
VOID	BCSSend_1588_02(CLOCKDATA*	pstClockData);
PORTSYNCSYNC*	setPSSyncBCSS_1588(DOUBLE	dbRateRatio, CLOCKDATA*	pstClockData);
VOID	txPSSyncBCSS_1588(PORTSYNCSYNC*	pstTxPSSyncPtr, CLOCKDATA*	pstClockData);
CHAR	setLogMessageInterval_1588(CLOCKDATA*	pstClockData);
VOID	setCMSyncInterval_1588(CLOCKDATA*	pstClockData);





VOID (*const pfnBCSSend_1588_Matrix[ST_BCSS_1588_MAX][EV_BCSS_1588_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&BCSSend_1588_01, &BCSSend_1588_01, &BCSSend_1588_00},
	{&BCSSend_1588_01, &BCSSend_1588_02, &BCSSend_1588_00},
	{&BCSSend_1588_01, &BCSSend_1588_02, &BCSSend_1588_00}
};



VOID	boundaryClockSyncSend_1588(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_BCSS_1588	enEvt = EV_BCSS_1588_EVENT_MAX;
	BOOL 			blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("BCSSendSM_1588   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1588_GD.stBCSSendSM_1588_GD.enStatusBCSS_1588);
}
#endif
		enEvt = GetBCSSendSM_1588_Event(usEvent, pstClockData);

		blSts = IsBCSSendSM_1588_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_BCSS_1588_EVENT_MAX))
		{
			(*pfnBCSSend_1588_Matrix[pstClockData->stUn_CSM_GD.stCsm1588_GD.stBCSSendSM_1588_GD.enStatusBCSS_1588][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_BCSSENDSM_1588, PTP_LOGVE_84000010);
		}

	}
}



BCSSENDSM_1588_GD*	GetBCSSendSM_1588_GD(
	CLOCKDATA*	pstClockData)
{
	BCSSENDSM_1588_GD*	pstBCSSGlb = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBCSSendSM_1588_GD);
	return pstBCSSGlb;
}

EN_EV_BCSS_1588	GetBCSSendSM_1588_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_BCSS_1588	enEvt = EV_BCSS_1588_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_BCSS_1588_BEGIN;
			break;

		case PTP_EV_SYNC_SENDTIME_1588:
			enEvt = EV_BCSS_1588_SYNC_SENDTIME;
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stBCSSendSM_1588_GD.pstTMO_SyncSendTime_1588 = NULL;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_BCSS_1588_CLOSE;
			break;

		default:
			enEvt = EV_BCSS_1588_EVENT_MAX;
			break;
	}

	return	enEvt;
}

BOOL	IsBCSSendSM_1588_Status(
	CLOCKDATA*	pstClockData)
{
	BCSSENDSM_1588_GD*	pstBCSSGlb	= GetBCSSendSM_1588_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstBCSSGlb->enStatusBCSS_1588 < ST_BCSS_1588_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	BCSSend_1588_00(
	CLOCKDATA*	pstClockData)
{
	BCSSENDSM_1588_GD*	pstBCSSGlb		= GetBCSSendSM_1588_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "BCSSend_1588_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	if (pstBCSSGlb->pstTMO_SyncSendTime_1588 != NULL)
	{
		(VOID)ptp_TimeOut_Can(pstBCSSGlb->pstTMO_SyncSendTime_1588);
		pstBCSSGlb->pstTMO_SyncSendTime_1588 = NULL;
	}

	pstBCSSGlb->enStatusBCSS_1588	= ST_BCSS_1588_NONE;

	ptp_dbg_msg( D_FUNC, ("BCSSend_1588_00::-\n") );

}




VOID	BCSSend_1588_01(
	CLOCKDATA*	pstClockData)
{
	BCSSENDSM_1588_GD*	pstBCSSGlb		= GetBCSSendSM_1588_GD(pstClockData);
	USHORT				usSSTimeEvent	= PTP_EV_SYNC_SENDTIME_1588;
	USCALEDNS			stCurrentTime	= {0};


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (IS_OD_BC_1588(pstClockData))
	{
		if (!(pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_SYNC_LOCKED))
		{
			if (pstBCSSGlb->pstTMO_SyncSendTime_1588 != NULL)
			{
				(VOID)ptp_TimeOut_Can(pstBCSSGlb->pstTMO_SyncSendTime_1588);
				pstBCSSGlb->pstTMO_SyncSendTime_1588 = NULL;
			}

			setCMSyncInterval_1588(pstClockData);
			(VOID)ptpAddUSNs_USNs(&stCurrentTime,
									&(pstClockData->stClock_GD.stClockMasterSyncInterval),
									&(pstBCSSGlb->stSyncSendTime_1588));

			pstBCSSGlb->pstTMO_SyncSendTime_1588 = ptp_TimeOut_Req(usSSTimeEvent,
																	pstClockData,
																	pstBCSSGlb->stSyncSendTime_1588,
																	(CallBackFunc)&boundaryClockSyncSend_1588);
		}
	}
	pstBCSSGlb->enStatusBCSS_1588	= ST_BCSS_1588_INITIALIZING;

}



VOID	BCSSend_1588_02(
	CLOCKDATA*	pstClockData)
{
	BCSSENDSM_1588_GD*	pstBCSSGlb		= GetBCSSendSM_1588_GD(pstClockData);
	USHORT				usSSTimeEvent	= PTP_EV_SYNC_SENDTIME_1588;
	USCALEDNS		stCurrentTime	= {0};
	USCALEDNS			stInterval	= {0};
	BOOL 				blState =  FALSE;


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (IS_OD_BC_1588(pstClockData))
	{
		if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] != ENUM_PORTSTATE_SLAVE)
		{


			SyncTransChkTmo( pstClockData );

			blState = ChkSyncTransProcessing( pstClockData );
			if ( blState == FALSE )
			{
				pstBCSSGlb->pstTxPSSyncPtr = setPSSyncBCSS_1588(gdbGmRateRatio, pstClockData);
				txPSSyncBCSS_1588(pstBCSSGlb->pstTxPSSyncPtr, pstClockData);
			}
			else
			{
				stInterval = pstClockData->stClock_GD.stSyncSendHoldTime;
				(VOID)ptpAddUSNs_USNs( &stCurrentTime, 
									   &stInterval, 
									   &pstBCSSGlb->stSyncSendTime_1588 );

				ptp_dbg_msg(D_DBG, ("stCurrentTime                                  =[%04x:%08x:%08x:%04x]\n"
					, stCurrentTime.usNsec_msb
					, stCurrentTime.ulNsec_2nd
					, stCurrentTime.ulNsec_lsb
					, stCurrentTime.usFrcNsec
				));
				ptp_dbg_msg(D_DBG, ("stInterval                                     =[%04x:%08x:%08x:%04x]\n"
					, stInterval.usNsec_msb
					, stInterval.ulNsec_2nd
					, stInterval.ulNsec_lsb
					, stInterval.usFrcNsec
				));
				ptp_dbg_msg(D_DBG, ("ptp_TimeOut_Req:pstBCSSGlb->stSyncSendTime_1588=[%04x:%08x:%08x:%04x]\n"
					, pstBCSSGlb->stSyncSendTime_1588.usNsec_msb
					, pstBCSSGlb->stSyncSendTime_1588.ulNsec_2nd
					, pstBCSSGlb->stSyncSendTime_1588.ulNsec_lsb
					, pstBCSSGlb->stSyncSendTime_1588.usFrcNsec
				));

				pstBCSSGlb->pstTMO_SyncSendTime_1588 = ptp_TimeOut_Req( usSSTimeEvent,
																		pstClockData,
																		pstBCSSGlb->stSyncSendTime_1588,
																		(CallBackFunc)&boundaryClockSyncSend_1588 );
			}
		}

		if( blState == FALSE )
		{
		
			if (pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_SYNC_LOCKED)
			{
				pstBCSSGlb->blSyncSendTime = FALSE;
			}
			else
			{

				setCMSyncInterval_1588(pstClockData);
				(VOID)ptpAddUSNs_USNs(&stCurrentTime,
										&(pstClockData->stClock_GD.stClockMasterSyncInterval),
										&(pstBCSSGlb->stSyncSendTime_1588));

				pstBCSSGlb->pstTMO_SyncSendTime_1588 = ptp_TimeOut_Req(usSSTimeEvent,
																	pstClockData,
																	pstBCSSGlb->stSyncSendTime_1588,
																	(CallBackFunc)&boundaryClockSyncSend_1588);

			}
		}

	}

	pstBCSSGlb->enStatusBCSS_1588	= ST_BCSS_1588_SEND_SYNC_INDICAT;

}




PORTSYNCSYNC*  setPSSyncBCSS_1588(
	DOUBLE		dbRateRatio,
	CLOCKDATA*	pstClockData)
{
	PORTSYNCSYNC*		pstTxPSSyncPtr		= NULL;
	USCALEDNS			stUSNs				= {0xFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFF};
	EXTENDEDTIMESTAMP	stCurrentMasterETS	= {0};
	USCALEDNS			stCurrentMasterTime	= {0};

	ptp_dbg_msg(D_FUNC, ("setPSSyncBCSS_1588::+\n"));

	ptp_GetCurrentMasterTime(pstClockData, &stCurrentMasterTime);

	pstTxPSSyncPtr	 = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.stRcvdPSSyncDat);

	pstTxPSSyncPtr->uchClockNumber				= pstClockData->stDefaultDS.uchDomainNumber;
	pstTxPSSyncPtr->usLocalPortNumber			= PORT_NO_0;

	pstTxPSSyncPtr->stSyncReceiptTimeoutTime	= stUSNs;

	(VOID)ptpConvUSNs_ETS(&(stCurrentMasterTime), &stCurrentMasterETS);

	(VOID)ptpConvETS_TS(&stCurrentMasterETS,
						&(pstTxPSSyncPtr->stPreciseOriginTimestamp));

	SET_SCALEDNS(pstTxPSSyncPtr->stFollowUpCorrectionField,
					0,
					0,
					0,
					stCurrentMasterETS.stNsec.usFrcNsec);

	pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity = pstClockData->stDefaultDS.stClockIdentity;
	pstTxPSSyncPtr->stSourcePortIdentity.usPortNumber	 = PORT_NO_0;

	pstTxPSSyncPtr->chLogMessageInterval	   = setLogMessageInterval_1588(pstClockData);
	pstTxPSSyncPtr->stUpstreamTxTime		= stCurrentMasterTime;
	pstTxPSSyncPtr->dbRateRatio 			= dbRateRatio;



	pstTxPSSyncPtr->usGmTimeBaseIndicator	= gusClockSourceTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange		= gstClockSourcePhaseOffset;
	pstTxPSSyncPtr->dbLastGmFreqChange		= gdbClockSourceFreqOffset;

	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.domainNumber=[%d] defaultDS.domainNumber=[%d]\n", pstTxPSSyncPtr->uchClockNumber, pstClockData->stDefaultDS.uchDomainNumber));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.usLocalPortNumber=[%d]\n", pstTxPSSyncPtr->usLocalPortNumber));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.syncReceiptTimeoutTime=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.usNsec_msb
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.ulNsec_2nd
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.ulNsec_lsb
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("gstCurrentMasterTime=[%04x:%08x:%08x:%04x]\n"
		, gstCurrentMasterTime.usNsec_msb
		, gstCurrentMasterTime.ulNsec_2nd
		, gstCurrentMasterTime.ulNsec_lsb
		, gstCurrentMasterTime.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("stFollowUpCorrectionField=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stFollowUpCorrectionField.sNsec_msb
		, pstTxPSSyncPtr->stFollowUpCorrectionField.ulNsec_2nd
		, pstTxPSSyncPtr->stFollowUpCorrectionField.ulNsec_lsb
		, pstTxPSSyncPtr->stFollowUpCorrectionField.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.sourcePortIdentity=[%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x(%d)]\n"
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[0]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[1]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[2]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[3]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[4]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[5]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[6]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[7]
		, pstTxPSSyncPtr->stSourcePortIdentity.usPortNumber
		));
	ptp_dbg_msg(D_DBG, (" defaultDS.sourcePortIdentity=[%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x]\n"
		, pstClockData->stDefaultDS.stClockIdentity.uchId[0]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[1]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[2]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[3]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[4]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[5]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[6]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[7]
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.chLogMessageInterval=[%d]\n", pstTxPSSyncPtr->chLogMessageInterval));
	ptp_dbg_msg(D_DBG, ("gstLocalTime=[%04x:%08x:%08x:%04x]\n"
		, gstLocalTime.usNsec_msb
		, gstLocalTime.ulNsec_2nd
		, gstLocalTime.ulNsec_lsb
		, gstLocalTime.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.stPreciseOriginTimestamp=[%04x:%08x:%08x]\n"
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.stSeconds.usSec_msb
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.stSeconds.ulSec_lsb
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.ulNanoseconds
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.upstreamTxTime=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stUpstreamTxTime.usNsec_msb
		, pstTxPSSyncPtr->stUpstreamTxTime.ulNsec_2nd
		, pstTxPSSyncPtr->stUpstreamTxTime.ulNsec_lsb
		, pstTxPSSyncPtr->stUpstreamTxTime.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.rateRatio=[%f]\n"
		, pstTxPSSyncPtr->dbRateRatio
		));
	ptp_dbg_msg(D_DBG, ("gdbGmRateRatio=[%f]\n"
		, gdbGmRateRatio
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.gmTimeBaseIndicator=[%d]\n"
		, pstTxPSSyncPtr->usGmTimeBaseIndicator
		));
	ptp_dbg_msg(D_DBG, ("gusClockSourceTimeBaseIndicator=[%d]\n"
		, gusClockSourceTimeBaseIndicator
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.lastGmPhaseChange=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stLastGmPhaseChange.sNsec_msb
		, pstTxPSSyncPtr->stLastGmPhaseChange.ulNsec_2nd
		, pstTxPSSyncPtr->stLastGmPhaseChange.ulNsec_lsb
		, pstTxPSSyncPtr->stLastGmPhaseChange.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("gstClockSourcePhaseOffset=[%04x:%08x:%08x:%04x]\n"
		, gstClockSourcePhaseOffset.sNsec_msb
		, gstClockSourcePhaseOffset.ulNsec_2nd
		, gstClockSourcePhaseOffset.ulNsec_lsb
		, gstClockSourcePhaseOffset.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.lastGmFreqChange=[%f]\n"
		, pstTxPSSyncPtr->dbLastGmFreqChange
		));
	ptp_dbg_msg(D_DBG, ("gdbClockSourceFreqOffset=[%f]\n"
		, gdbClockSourceFreqOffset
		));

	ptp_dbg_msg(D_FUNC, ("setPSSyncBCSS_1588::-\n"));

	return pstTxPSSyncPtr;

}




VOID  txPSSyncBCSS_1588(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	CLOCKDATA*		pstClockData)
{
	USHORT				usEvent			= PTP_EV_BASE;
	SSSYNCSM_1588_GD*	pstSSS_1588_GD	= NULL;

	ptp_dbg_msg(D_FUNC, ("txPSSyncBCSS_1588::+\n"));

	pstSSS_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD);
	pstSSS_1588_GD->pstRcvdPSSyncPtr = pstTxPSSyncPtr;
	pstSSS_1588_GD->blRcvdPSSync = TRUE;

	usEvent = PTP_EV_FOR_STSYNSYN_RCVSYNC;
	siteSyncSync_1588(usEvent, pstClockData);

	ptp_dbg_msg(D_FUNC, ("txPSSyncBCSS_1588::-\n"));
}




CHAR	setLogMessageInterval_1588(
	CLOCKDATA*	pstClockData)
{
	PORTDATA*		pstPortData		= pstClockData-> pstPortData;
	CHAR			chCMLSInterval	= 0;


	chCMLSInterval = pstPortData->stPort_1588_DS.chLogSyncInterval;

	while (pstPortData != NULL)
	{
		if (chCMLSInterval > pstPortData->stPort_1588_DS.chLogSyncInterval)
		{
			chCMLSInterval = pstPortData->stPort_1588_DS.chLogSyncInterval;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}
	pstClockData->stClock_GD.chClockMasterLogSyncInterval = chCMLSInterval;

	return chCMLSInterval;

}




VOID	setCMSyncInterval_1588(
	CLOCKDATA*	pstClockData)
{
	CHAR			chCMLSInterval		= 0;
	USCALEDNS		stInitCMSInterval	= {0, 0, CONST10_9, 0};


	chCMLSInterval = setLogMessageInterval_1588(pstClockData);

	if ((chCMLSInterval >= -CONS_SHIFT16) &&
		(chCMLSInterval <= CONS_SHIFT16))
	{
		(VOID)ptpShiftUSNs_CHAR(&stInitCMSInterval,
								chCMLSInterval,
								&(pstClockData->stClock_GD.stClockMasterSyncInterval));
	}
	else
	{
		pstClockData->stClock_GD.stClockMasterSyncInterval = stInitCMSInterval;
	}
}




#endif

