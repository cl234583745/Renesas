/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"

#include "MDSyncCommonSM.h"
#include "MDSyncSendSM.h"
#include "MDSyncSendSM_1588.h"

#ifdef	PTP_USE_ME_HW_ASSIST
#include "ptp_GetDetailCurrentTime.h"
#endif

#define D_SYNCTO	0
#define D_FUNC		0


VOID (*const MDSyncSendSM_1588_Matrix[DMDSYCS_STATUS_MAX][DMDSYCS_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_NP_1588 ,&MDSyncSendSM_NP_1588 ,&MDSyncSendSM_NP_1588},
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_02_1588 ,&MDSyncSendSM_NP_1588 ,&MDSyncSendSM_00_1588},
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_02_1588 ,&MDSyncSendSM_03_1588 ,&MDSyncSendSM_00_1588},
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_02_1588 ,&MDSyncSendSM_NP_1588 ,&MDSyncSendSM_00_1588},
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_02_1588 ,&MDSyncSendSM_04_1588 ,&MDSyncSendSM_00_1588},
	{&MDSyncSendSM_01_1588 ,&MDSyncSendSM_02_1588 ,&MDSyncSendSM_NP_1588 ,&MDSyncSendSM_00_1588}
};

VOID MDSyncSendSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCSNDSM_EV	enEvt = MDSYCS_E_EVENT_MAX;
	MDSYNCSNDSM_ST	enSts = MDSYCS_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDSyncSndEvent(usEvent, pstPort);
	enSts = GetMDSyncSndStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDSyncSendSM_1588        ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDSYCS_STATUS_MAX) && (enEvt != MDSYCS_E_EVENT_MAX))
	{
		(*MDSyncSendSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDSyncSndStatus(pstPort);
	printf ("<END  > [%02d]MDSyncSendSM_1588        ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDSyncSendSM_00_1588(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::+ domain=[%d],port=[%d}\n", 
                  "MDSyncSendSM_00_1588",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	MDSynSnd_Initial_1588(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDSyncSendSM_00_1588::-\n") );

	return;
}

VOID MDSyncSendSM_01_1588(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	MDSynSnd_Initial_1588(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
	return;
}

VOID MDSyncSendSM_02_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;

	MDSSENDSM_GD*		pstGbl = NULL;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	if (pstGbl->blRcvdMDSync == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82003101);
		MDSynSnd_Initial_1588(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080011);
		MDSyncSendSM_02_1588_BC(pstGbl, pstPort);
	}
#ifdef	PTP_USE_TRANS
	else
	{
		blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
		blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
		if (blRet_1 || blRet_2)
		{
			PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080012);
			MDSyncSendSM_02_1588_TC(pstGbl, pstPort);
		}
	}
#endif
	return;
}

VOID MDSyncSendSM_03_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;
	INT  nIndex;

	MDSSENDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	if ( gstSyncTmoManage[nIndex].pstSyncSendPort == pstPort )
	{
		ptp_dbg_msg( D_SYNCTO, 
		             ("domain(%d)::del sync timeout timer. port=[%d]\n", 
		              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
		              pstPort->stPort_GD.usThisPort) );
		tsn_Wrapper_MemSet( (VOID *)&gstSyncTmoManage[nIndex], 0, sizeof(SYNCTMOMAN) );
	}

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210C);
		MDSynSnd_Initial_1588(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080011);
		MDSyncSendSM_03_1588_BC(pstGbl, pstPort);
	}
#ifdef	PTP_USE_TRANS
	else
	{
		blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
		blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
		if (blRet_1 || blRet_2)
		{
			PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080012);
			MDSyncSendSM_03_1588_TC(pstGbl, pstPort);
		}
	}
#endif
	return;
}

VOID MDSyncSendSM_04_1588(PORTDATA* pstPort)
{
	BOOL	blRet_1;
	BOOL	blRet_2;
	INT  nIndex;

	MDSSENDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	if ( gstSyncTmoManage[nIndex].pstSyncSendPort == pstPort )
	{
		ptp_dbg_msg( D_SYNCTO, 
		             ("domain(%d)::del sync timeout timer. port=[%d]\n", 
		              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
		              pstPort->stPort_GD.usThisPort) );
		tsn_Wrapper_MemSet( (VOID *)&gstSyncTmoManage[nIndex], 0, sizeof(SYNCTMOMAN) );
	}

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210C);
		MDSynSnd_Initial_1588(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	blRet_1 = IsMDCOMClockSupportTypOC(pstPort);
	blRet_2 = IsMDCOMClockSupportTypBC(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080011);
		MDSyncSendSM_04_1588_BC(pstGbl, pstPort);
	}
#ifdef	PTP_USE_TRANS
	blRet_1 = IsMDCOMClockSupportTypTC_E2E(pstPort);
	blRet_2 = IsMDCOMClockSupportTypTC_P2P(pstPort);
	if (blRet_1 || blRet_2)
	{
		PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82080012);
		MDSyncSendSM_04_1588_TC(pstGbl, pstPort);
	}
#endif
	return;
}

VOID MDSyncSendSM_02_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT	= pstPort->pstClockData;
	DEFAULT_1588_DS*	pstClkDefaultDS = &pstClockDT->stDefault_1588_DS;

	if (pstClkDefaultDS->blTwoStepFlag)
	{
		MDSynSnd_SyncTwoStep_1588_BC(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_TWO_STEP, pstPort);
	}
	else
	{
		MDSynSnd_SyncOneStep_1588_BC(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_ONE_STEP, pstPort);
	}
	return;
}

VOID MDSyncSendSM_03_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	if (SetMDSyncMgEgresTimestamp(pstSmGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1588(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	MDSynSnd_FollowUp_1588_BC(pstSmGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SEND_FOLLOW_UP, pstPort);
	return;
}

VOID MDSyncSendSM_04_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	if (SetMDSyncMgEgresTimestamp(pstSmGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1588(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	MDSynSnd_StCrectionField_1588(pstSmGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SET_CORRECTION_FIELD, pstPort);
	return;
}

#ifdef	PTP_USE_TRANS
VOID MDSyncSendSM_02_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT	= pstPort->pstClockData;
	DEFAULT_1588_DS*	pstClkDefaultDS = &pstClockDT->stDefault_1588_DS;

	if (pstClkDefaultDS->blTwoStepFlag)
	{
		MDSynSnd_SyncTwoStep_1588_TC(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_TWO_STEP, pstPort);
	}
	else
	{
		MDSynSnd_SyncOneStep_1588_TC(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_ONE_STEP, pstPort);
	}
	return;
}

VOID MDSyncSendSM_03_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	if (SetMDSyncMgEgresTimestamp(pstSmGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1588(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	SetMDSyncCorrectionPortEgress(pstSmGbl, pstPort);
	MDSynSnd_FollowUp_1588_TC(pstSmGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SEND_FOLLOW_UP, pstPort);
	return;
}

VOID MDSyncSendSM_04_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	if (SetMDSyncMgEgresTimestamp(pstSmGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1588(pstSmGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	MDSynSnd_StCrectionField_1588(pstSmGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SET_CORRECTION_FIELD, pstPort);
	return;
}
#endif

VOID MDSyncSendSM_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDSynSnd_Initial_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;
	pstSmGbl->blRcvdMDSync = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	pstPortMD->usSyncSequenceId = (USHORT)tsn_Wrapper_Rand();
	return TRUE;
}

BOOL MDSynSnd_SyncTwoStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	USCALEDNS	stCurrentTime={0};
	INT  nIndex;
	
	
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncTwoStep_1588_BC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	ptp_dbg_msg( D_SYNCTO, 
	             ("domain(%d)::add sync timeout timer. port=[%d]\n", 
	              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
	              pstPort->stPort_GD.usThisPort) );

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	gstSyncTmoManage[nIndex].pstSyncSendPort = pstPort;
	
	ptp_GetCurrentTime( pstPort->pstClockData, &stCurrentTime );

	(VOID)ptpAddUSNs_USNs( &stCurrentTime, 
					 	   &pstPort->pstClockData->stClock_GD.stSyncTransTimeout, 
					 	   &gstSyncTmoManage[nIndex].stSyncTransTimeoutTime );


	pstPortMD->usSyncSequenceId++;

	IncMDSyncSndTxSyncCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_FollowUp_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	if (SetFollowUp_1588_BC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxFollowUp_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	IncMDSyncSndTxFollowUpCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_SyncOneStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncOneStep_1588_BC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	pstPortMD->usSyncSequenceId++;

	IncMDSyncSndTxSyncCount(pstPort);
	IncMDSyncSndTxOneStepSyncCount(pstPort);
	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL MDSynSnd_SyncTwoStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	USCALEDNS	stCurrentTime={0};
	INT  nIndex;

	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncTwoStep_1588_TC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	gstSyncTmoManage[nIndex].pstSyncSendPort = pstPort;
	
	ptp_GetCurrentTime( pstPort->pstClockData, &stCurrentTime );

	(VOID)ptpAddUSNs_USNs( &stCurrentTime, 
					 	   &pstPort->pstClockData->stClock_GD.stSyncTransTimeout, 
					 	   &gstSyncTmoManage[nIndex].stSyncTransTimeoutTime );


	IncMDSyncSndTxSyncCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_FollowUp_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	if (SetFollowUp_1588_TC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxFollowUp_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	IncMDSyncSndTxFollowUpCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_SyncOneStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncOneStep_1588_TC(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	IncMDSyncSndTxSyncCount(pstPort);
	IncMDSyncSndTxOneStepSyncCount(pstPort);
	return TRUE;
}
#endif

BOOL MDSynSnd_StCrectionField_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;
	return TRUE;
}

BOOL SetSyncTwoStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*			pstClkDefaultDS	= &pstClockDT->stDefaultDS;
	PORT_DS*			pstPortDS			= &pstPort->stPortDS;
	PORT_1588_DS*		pstPortDS_1588		= &pstPort->stPort_1588_DS;

	PORTMD_GD*			pstPortMD			= &pstPort->stPortMD_GD;

	PTPMSG_SYNC_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSync1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_SYNC );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;
	MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, TRUE );
	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_SYNC,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstPortMD->usSyncSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_SYNC;
	pstMsg->stHeader.chLogMsgInterVal	= pstPortDS_1588->chLogSyncInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemSet(&pstMsg->stOriginTimestamp, 0, sizeof(pstMsg->stOriginTimestamp));
	GetPTPMSG_SYNC_1588(*pstMsg ,pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL SetSyncOneStep_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*			pstClkDefaultDS	= &pstClockDT->stDefaultDS;
	PORT_DS*			pstPortDS			= &pstPort->stPortDS;
	PORT_1588_DS*		pstPortDS_1588		= &pstPort->stPort_1588_DS;

	PORTMD_GD*			pstPortMD			= &pstPort->stPortMD_GD;

	TIMESTAMP			stTimeStamp;
	TIMESTAMP			stA_TS;
	SCALEDNS			stB_SNs;

	PTPMSG_SYNC_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSync1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_SYNC );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;
	MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, FALSE );

	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_SYNC,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstPortMD->usSyncSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_SYNC;
	pstMsg->stHeader.chLogMsgInterVal	= pstPortDS_1588->chLogSyncInterval;

#ifndef	PTP_USE_ME_HW_ASSIST
	GetMDCOMClockTime(pstClockDT, MDCOM_TMTYPE_MASTER, &stTimeStamp);
#else
	{
		USCALEDNS	stC_UNs;
		ptp_GetCurrentMasterTime((CLOCKDATA*)NULL, &stC_UNs);
		ptpConvUSNs_TS (&stC_UNs, &stTimeStamp);
	}
#endif

	GetMDCOMTimeStampNs(&stTimeStamp,&stA_TS);
	ptpSubTS_TS(&stTimeStamp, &stA_TS, &stB_SNs);
	ptpConvSNs_TInt(&stB_SNs, &pstMsg->stHeader.stCorrectionField);
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	ClrMDCOMTimeStampNs(&stTimeStamp, &pstMsg->stOriginTimestamp);
	GetPTPMSG_SYNC_1588(*pstMsg ,pstMsg->stHeader.usMegLength);

	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL SetSyncTwoStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD	= &pstClockDT->stUn_Clock_GD.stClock_1588_GD;
	PTPMSG_SYNC_1588*	pstRcvMsg = &pstClockGD->stSynCorctionClock.stConSync_1588;

	PTPMSG_SYNC_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSync1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	tsn_Wrapper_MemCpy(pstMsg, pstRcvMsg, sizeof(*pstMsg));

	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(&pstRcvMsg->stHeader) == FALSE )
	{
		MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, TRUE );

		tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
			sizeof(pstMsg->stHeader.stCorrectionField));

		tsn_Wrapper_MemSet(&pstMsg->stOriginTimestamp, 0, sizeof(pstMsg->stOriginTimestamp));
	}

	return TRUE;
}

BOOL SetSyncOneStep_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD	= &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	PTPMSG_SYNC_1588*		pstRcvMsg			= &pstClockGD->stSynCorctionClock.stConSync_1588;
	PTPMSG_FOLLOWUP_1588*	pstRcvFollowUpMsg	= &pstClockGD->stSynCorctionClock.stConFollowUp_1588;
	TIMESTAMP			stA_TS	 = pstClockGD->stSynCorctionClock.stCrrctionPort.stIngressTimestamp;
	TIMESTAMP			stB_TS;
	TIME_INTERVAL		stD_TInt = pstClockGD->stSynCorctionClock.stConSync_1588.stHeader.stCorrectionField;
	SCALEDNS			stC_SNs;

	PTPMSG_SYNC_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSync1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	tsn_Wrapper_MemCpy(pstMsg, pstRcvMsg, sizeof(*pstMsg));

	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(&pstRcvMsg->stHeader) )
	{
        MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, FALSE );
		tsn_Wrapper_MemCpy(&pstMsg->stHeader.stCorrectionField, &pstRcvFollowUpMsg->stHeader.stCorrectionField,
			sizeof(pstMsg->stHeader.stCorrectionField));
		tsn_Wrapper_MemCpy(&pstMsg->stOriginTimestamp, &pstRcvFollowUpMsg->stPrcsOrgnTimestamp,
			sizeof(pstMsg->stOriginTimestamp));

		stD_TInt = pstMsg->stHeader.stCorrectionField;
	}

#ifndef	PTP_USE_ME_HW_ASSIST
	GetMDCOMClockTime(pstClockDT, MDCOM_TMTYPE_MASTER, &stB_TS);
#else
	{
		USCALEDNS	stC_UNs;
		ptp_GetCurrentMasterTime((CLOCKDATA*)NULL, &stC_UNs);
		ptpConvUSNs_TS (&stC_UNs, &stB_TS);
	}
#endif

	ptpSubTS_TS(&stB_TS, &stA_TS, &stC_SNs);
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{

	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{

	}
	else
	{
		return FALSE;
	}
	ptpAddTInt_SNs(&stD_TInt, &stC_SNs, &pstMsg->stHeader.stCorrectionField);
	return TRUE;
}
#endif

BOOL TxSync_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;

	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDSyncSendSM;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxSync1588,
		pstSmGbl->stTxSync1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82002108);
		return FALSE;
	}
	return TRUE;
}

BOOL SetFollowUp_1588_BC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*			pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*			pstClkDefaultDS	= &pstClockDT->stDefaultDS;
	PORT_DS*			pstPortDS			= &pstPort->stPortDS;
	PORT_1588_DS*		pstPortDS_1588		= &pstPort->stPort_1588_DS;

	TIMESTAMP			stA_TS;
	SCALEDNS			stB_SNs;
	PTPMSG_SYNC_1588*	pstTxMsgSync		= &pstSmGbl->stTxSync1588;

	PTPMSG_FOLLOWUP_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxFollowUp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_FOLLOWUP );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;
	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_FOLLOWUP,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstTxMsgSync->stHeader.usSequenceId;

	pstMsg->stHeader.uchControl		= PTPM_CONTROL_FOLLOWUP;
	pstMsg->stHeader.chLogMsgInterVal	= pstPortDS_1588->chLogSyncInterval;

	GetMDCOMTimeStampNs(&pstSmGbl->stSyncEgTimestamp,&stA_TS);
	ptpSubTS_TS(&pstSmGbl->stSyncEgTimestamp, &stA_TS, &stB_SNs);
	ptpConvSNs_TInt(&stB_SNs, &pstMsg->stHeader.stCorrectionField);
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	ClrMDCOMTimeStampNs(&pstSmGbl->stSyncEgTimestamp, &pstMsg->stPrcsOrgnTimestamp);
	GetPTPMSG_FOLLOWUP_1588(*pstMsg,pstMsg->stHeader.usMegLength);

	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL SetFollowUp_1588_TC(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD	= &pstClockDT->stUn_Clock_GD.stClock_1588_GD;
	TRANSPARENTCLOCKPORT_1588_DS*	pstPortTC	= &pstPort->stTransparentClockPort_1588_DS;

	PTPMSG_SYNC_1588*	  rcvSyncMsg = &pstClockGD->stSynCorctionClock.stConSync_1588;
	PTPMSG_FOLLOWUP_1588* pstRcvMsg = &pstClockGD->stSynCorctionClock.stConFollowUp_1588;
	TIMESTAMP			stA_TS	 = pstClockGD->stSynCorctionClock.stCrrctionPort.stIngressTimestamp;
	TIMESTAMP			stB_TS	 = pstClockGD->stSynCorctionClock.stCrrctionPort.stEgressTimestamp;
	TIME_INTERVAL		stD_TInt = pstClockGD->stSynCorctionClock.stConFollowUp_1588.stHeader.stCorrectionField;
	TIME_INTERVAL		stE_TInt = pstPortTC->stPeerMeanPathDelay;
	SCALEDNS			stC_SNs;

	PTPMSG_FOLLOWUP_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxFollowUp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	tsn_Wrapper_MemCpy(pstMsg, pstRcvMsg, sizeof(*pstMsg));

	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP( &rcvSyncMsg->stHeader ) == FALSE )
	{
		tsn_Wrapper_MemCpy(pstMsg, rcvSyncMsg, sizeof(*pstMsg));
		MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_FOLLOWUP );
		MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, FALSE );

		stD_TInt = pstMsg->stHeader.stCorrectionField;
	}

	ptpSubTS_TS(&stB_TS, &stA_TS, &stC_SNs);
	ptpAddTInt_SNs(&stD_TInt, &stC_SNs, &pstMsg->stHeader.stCorrectionField);
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		ptpAddTInt_TInt(&pstMsg->stHeader.stCorrectionField, &stE_TInt, &stC_SNs);
		ptpConvSNs_TInt(&stC_SNs, &pstMsg->stHeader.stCorrectionField);
	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
	}
	else
	{
		return FALSE;
	}
	return TRUE;
}
#endif

BOOL TxFollowUp_1588(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxFollowUp1588,
		pstSmGbl->stTxFollowUp1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1588, PTP_LOGVE_82002208);
		return FALSE;
	}
	return TRUE;
}

#endif
