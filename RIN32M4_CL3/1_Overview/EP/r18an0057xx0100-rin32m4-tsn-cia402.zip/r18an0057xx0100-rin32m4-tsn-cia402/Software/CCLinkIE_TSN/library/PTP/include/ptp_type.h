/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_COMMON_TYPE_H__
#define __PTP_COMMON_TYPE_H__

#include "ptp_Macro.h"


typedef signed char 	CHAR;
typedef unsigned char	UCHAR;
typedef signed short	SHORT;
typedef unsigned short	USHORT;
typedef signed long 	LONG;
typedef unsigned long	ULONG;
typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;
typedef float			FLOAT;
typedef double			DOUBLE;
#ifndef VOID
typedef void			VOID;
#endif
typedef int 			INT;
typedef unsigned int	UINT;

#ifdef BOOL
#undef BOOL
typedef unsigned short int	BOOL;
#else
typedef int 				BOOL;
#endif

#ifndef  NULL
#ifdef __cplusplus
#define   NULL	0
#else
#define   NULL	((void*)0)
#endif
#endif

#endif
