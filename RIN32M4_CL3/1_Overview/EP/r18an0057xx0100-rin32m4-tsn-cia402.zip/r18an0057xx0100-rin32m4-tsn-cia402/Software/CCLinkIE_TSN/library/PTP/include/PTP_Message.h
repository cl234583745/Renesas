/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MESSAGE_H__
#define __PTP_MESSAGE_H__

#include "ptp_ddt.h"

#include "PTP_Message_TLV.h"
#include "PTP_Management_TLV.h"

#include "ptp_CommonFunction.h"

#ifdef DEBUG_LOG_MSG
#define	DEBUG_PRINT(a,b,c)	printf(a,b,c);
#else
#define	DEBUG_PRINT(a,b,c)
#endif
#define	PTPM_MAJOR_SDOID_1					(0x01)
#define	PTPM_MAJOR_SDOID_2					(0x02)

#define	PTPM_MSGTYPE_SYNC					(0x00)
#define	PTPM_MSGTYPE_DELAY_REQ				(0x01)
#define	PTPM_MSGTYPE_PDELAY_REQ				(0x02)
#define	PTPM_MSGTYPE_PDELAY_RESP			(0x03)
#define	PTPM_MSGTYPE_FOLLOWUP				(0x08)
#define	PTPM_MSGTYPE_DELAY_RESP				(0x09)
#define	PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP		(0x0A)
#define	PTPM_MSGTYPE_ANNOUNCE				(0x0B)
#define	PTPM_MSGTYPE_SIGNALING				(0x0C)
#define	PTPM_MSGTYPE_MANAGEMENT				(0x0D)

#define	PTPM_MINOR_VER_PTP_1				(0x01)

#define	PTPM_VER_PTP_2						(0x02)

#define	PTPM_MINOR_SDOID_0					(0x00)

#define	PTPM_DOMAIN_NUMBER_0				(0x00)

#define	PTPM_FLAG_ALL_FALSE					(0x00)

#define	PTPM_MTYPE_SPCFC_SYNC				(0x00)
#define	PTPM_MTYPE_SPCFC_DELAY_REQ			(0x00)
#define	PTPM_MTYPE_SPCFC_PDELAY_REQ			(0x00)
#define	PTPM_MTYPE_SPCFC_PDELAY_RESP		(0x00)
#define	PTPM_MTYPE_SPCFC_FOLLOWUP			(0x00)
#define	PTPM_MTYPE_SPCFC_DELAY_RESP			(0x00)
#define	PTPM_MTYPE_SPCFC_PDRESP_FOLLOWUP	(0x00)
#define	PTPM_MTYPE_SPCFC_ANNOUNCE			(0x00)
#define	PTPM_MTYPE_SPCFC_SIGNALING			(0x00)
#define	PTPM_MTYPE_SPCFC_MANAGEMENT			(0x00)



#define	PTPM_HEADER_FLAG0_OFFSET				6
#define	PTPM_HEADER_FLAG0_ALTMASTER_OCTET0_BIT0	(0x01)
#define	PTPM_HEADER_FLAG0_TWOSTEP_OCTET0_BIT1	(0x02)
#define	PTPM_HEADER_FLAG0_UNICAST_OCTET0_BIT2	(0x04)






#define	PTPM_CONTROL_SYNC					(0x00)
#define	PTPM_CONTROL_DLY_REQ				(0x01)
#define	PTPM_CONTROL_FOLLOWUP				(0x02)
#define	PTPM_CONTROL_DLY_RESP				(0x03)

#define	PTPM_CONTROL_MANAGEMENT				(0x04)

#define	PTPM_CONTROL_PDLY_REQ				(0x05)
#define	PTPM_CONTROL_PDLY_RESP				(0x05)
#define	PTPM_CONTROL_PDLY_RESP_FOLLOWUP		(0x05)

#define	PTPM_CONTROL_ANNOUNCE				(0x05)
#define	PTPM_CONTROL_SIGNALING				(0x05)

#define	PTPM_LOGMSGINTERVAL_0x7F			(0x7F)



#define MPTPMSG_H_GET_MSG_TYPE( hdr )			PTP_GET_BITS( &(hdr)->byMjSdoIdAndMsgTyp, 0, 3 )
#define MPTPMSG_H_SET_MSG_TYPE( hdr, val )		PTP_SET_BITS( &(hdr)->byMjSdoIdAndMsgTyp, 0, 3, val )

#define MPTPMSG_H_GET_MAJORSDO_ID( hdr )		PTP_GET_BITS( &(hdr)->byMjSdoIdAndMsgTyp, 4, 7 )
#define MPTPMSG_H_SET_MAJORSDO_ID( hdr, val )	PTP_SET_BITS( &(hdr)->byMjSdoIdAndMsgTyp, 4, 7, val )

#define	MPTPMSG_H_GET_VER_PTP( hdr )			PTP_GET_BITS( &(hdr)->byMiVerAndVerPTP, 0, 3 )
#define	MPTPMSG_H_SET_VER_PTP( hdr, val )		PTP_SET_BITS( &(hdr)->byMiVerAndVerPTP, 0, 3, val )
                                                
#define MPTPMSG_H_GET_MINOR_VER( hdr )			PTP_GET_BITS( &(hdr)->byMiVerAndVerPTP, 4, 7 )
#define MPTPMSG_H_SET_MINOR_VER( hdr, val )		PTP_SET_BITS( &(hdr)->byMiVerAndVerPTP, 4, 7, val )

#define MPTPMSG_H_GET_FLAGS0_ALTMASTER( hdr )           PTP_GET_BITS( &(hdr)->byFlags0, 0, 0 )
#define MPTPMSG_H_SET_FLAGS0_ALTMASTER( hdr, val )      PTP_SET_BITS( &(hdr)->byFlags0, 0, 0, val )

#define MPTPMSG_H_GET_FLAGS0_TWOSTEP( hdr )             PTP_GET_BITS( &(hdr)->byFlags0, 1, 1 )
#define MPTPMSG_H_SET_FLAGS0_TWOSTEP( hdr, val )        PTP_SET_BITS( &(hdr)->byFlags0, 1, 1, val )

#define MPTPMSG_H_GET_FLAGS0_UNICAST( hdr )             PTP_GET_BITS( &(hdr)->byFlags0, 2, 2 )
#define MPTPMSG_H_SET_FLAGS0_UNICAST( hdr, val )        PTP_SET_BITS( &(hdr)->byFlags0, 2, 2, val )

#define MPTPMSG_H_GET_FLAGS0_PTP_PROSPCFC1( hdr )       PTP_GET_BITS( &(hdr)->byFlags0, 3, 3 )
#define MPTPMSG_H_SET_FLAGS0_PTP_PROSPCFC1( hdr, val )  PTP_SET_BITS( &(hdr)->byFlags0, 3, 3, val )

#define MPTPMSG_H_GET_FLAGS0_PTP_PROSPCFC2( hdr )       PTP_GET_BITS( &(hdr)->byFlags0, 4, 4 )
#define MPTPMSG_H_SET_FLAGS0_PTP_PROSPCFC2( hdr, val )  PTP_SET_BITS( &(hdr)->byFlags0, 4, 4, val )

#define MPTPMSG_H_GET_FLAGS1_LEAP61( hdr )              PTP_GET_BITS( &(hdr)->byFlags1, 0, 0 )
#define MPTPMSG_H_SET_FLAGS1_LEAP61( hdr, val )         PTP_SET_BITS( &(hdr)->byFlags1, 0, 0, val )

#define MPTPMSG_H_GET_FLAGS1_LEAP59( hdr )              PTP_GET_BITS( &(hdr)->byFlags1, 1, 1 )
#define MPTPMSG_H_SET_FLAGS1_LEAP59( hdr, val )         PTP_SET_BITS( &(hdr)->byFlags1, 1, 1, val )

#define MPTPMSG_H_GET_FLAGS1_CRNT_UTCOFSVAL( hdr )      PTP_GET_BITS( &(hdr)->byFlags1, 2, 2 )
#define MPTPMSG_H_SET_FLAGS1_CRNT_UTCOFSVAL( hdr, val ) PTP_SET_BITS( &(hdr)->byFlags1, 2, 2, val )

#define MPTPMSG_H_GET_FLAGS1_PTPTIMESCALE( hdr )        PTP_GET_BITS( &(hdr)->byFlags1, 3, 3 )
#define MPTPMSG_H_SET_FLAGS1_PTPTIMESCALE( hdr, val )   PTP_SET_BITS( &(hdr)->byFlags1, 3, 3, val )

#define MPTPMSG_H_GET_FLAGS1_TMTRACEABLE( hdr )         PTP_GET_BITS( &(hdr)->byFlags1, 4, 4 )
#define MPTPMSG_H_SET_FLAGS1_TMTRACEABLE( hdr, val )    PTP_SET_BITS( &(hdr)->byFlags1, 4, 4, val )

#define MPTPMSG_H_GET_FLAGS1_FQTRACEABLE( hdr )         PTP_GET_BITS( &(hdr)->byFlags1, 5, 5 )
#define MPTPMSG_H_SET_FLAGS1_FQTRACEABLE( hdr, val )    PTP_SET_BITS( &(hdr)->byFlags1, 5, 5, val )


typedef struct tagPTPMSG_HEADER
{
	BYTE	            byMjSdoIdAndMsgTyp;
	BYTE	            byMiVerAndVerPTP;

	USHORT				usMegLength;
	UCHAR				uchDomainNumber;
	UCHAR				uchMinorSdoId;
	BYTE	            byFlags0;
	BYTE	            byFlags1;


	FRAC_NSEC64			stCorrectionField;
	UCHAR				uchMsgTypSpecific[4];
	PORTIDENTITY		stSrcPortIdentity;
	USHORT				usSequenceId;
	UCHAR				uchControl;
	CHAR				chLogMsgInterVal;

}	PTPMSG_HEADER;

#define	GetPTPMSG_HEADER(a,b)	\
		{	(b) = 0;							\
			(b) +=	(sizeof((a).byMjSdoIdAndMsgTyp))	\
				+	(sizeof((a).byMiVerAndVerPTP))		\
				+	(sizeof((a).usMegLength))			\
				+	(sizeof((a).uchDomainNumber))		\
				+	(sizeof((a).uchMinorSdoId))		\
				+	(sizeof((a).byFlags0))			\
				+	(sizeof((a).byFlags1))			\
				+	(sizeof((a).stCorrectionField.sNsec_msb))		\
				+	(sizeof((a).stCorrectionField.ulNsec_lsb))		\
				+	(sizeof((a).stCorrectionField.usFrcNsec))		\
				+	(sizeof((a).uchMsgTypSpecific))	\
				+	(sizeof((a).stSrcPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stSrcPortIdentity.usPortNumber))			\
				+	(sizeof((a).usSequenceId))		\
				+	(sizeof((a).uchControl))		\
				+	(sizeof((a).chLogMsgInterVal));	\
			DEBUG_PRINT("GetPTPMSG_HEADER = %d sizeof(%d) \n",(b), sizeof(PTPMSG_HEADER));	\
		}

#define	PTPMSG_HEAD_SZ					34U
#define	PTPMSG_HEAD_MJSDOIDANDMSGTYP_SZ	1U
#define	PTPMSG_HEAD_MIVERANDVERPTP_SZ	1U
#define	PTPMSG_HEAD_MEGLENGTH_SZ		2U
#define	PTPMSG_HEAD_DOMAINNUMBER_SZ		1U
#define	PTPMSG_HEAD_MINORSDOID_SZ		1U
#define	PTPMSG_HEAD_FLAGS0_SZ			1U
#define	PTPMSG_HEAD_FLAGS1_SZ			1U
#define	PTPMSG_HEAD_CORRECTIONFIELD_SZ	8U
#define	PTPMSG_HEAD_MSGTYPSPECIFIC_SZ	4U
#define	PTPMSG_HEAD_SRCPORTIDENTITY_SZ	10U
#define	PTPMSG_HEAD_SEQUENCEID_SZ		2U
#define	PTPMSG_HEAD_CONTROL_SZ			1U
#define	PTPMSG_HEAD_LOGMSGINTERVAL_SZ	1U


typedef struct tagPTPMSG_SYNC_TWO_STEP_1AS
{
	PTPMSG_HEADER		stHeader;
	UCHAR				uchReserved[10];

}	PTPMSG_SYNC_TWO_STEP_1AS;

#define	GetPTPMSG_SYNC_TWO_STEP_1AS(a,b) \
		{	\
			(b) +=	(sizeof((a).uchReserved));	\
			DEBUG_PRINT("GetPTPMSG_SYNC_TWO_STEP_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_SYNC_TWO_STEP_1AS));	\
		}

#define	PTPMSG_AS_SYNC_TWOS_SZ				44U
#define	PTPMSG_AS_SYNC_TWOS_RESERVED_SZ		10U


typedef struct tagPTPMSG_SYNC_ONE_STEP_1AS
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;
	PTPMSG_FOLLOWUP_TLV	stFollowUP_TLV;

}	PTPMSG_SYNC_ONE_STEP_1AS;

#define	GetPTPMSG_SYNC_ONE_STEP_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))\
				+	(sizeof((a).stOriginTimestamp.ulNanoseconds));	\
			DEBUG_PRINT("GetPTPMSG_SYNC_ONE_STEP_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_SYNC_ONE_STEP_1AS));	\
		}

#define	PTPMSG_AS_SYNC_ONES_SZ				76U
#define	PTPMSG_AS_SYNC_ONES_ORIGINTS_SZ		10U
#define	PTPMSG_AS_SYNC_ONES_FLLWUPTLV_SZ	32U

typedef struct tagPTPMSG_FOLLOWUP_1AS
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stPrcsOrgnTimestamp;
	PTPMSG_FOLLOWUP_TLV	stFollowUP_TLV;

}	PTPMSG_FOLLOWUP_1AS;

#define	GetPTPMSG_FOLLOWUP_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).stPrcsOrgnTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stPrcsOrgnTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stPrcsOrgnTimestamp.ulNanoseconds));	\
			DEBUG_PRINT("GetPTPMSG_FOLLOWUP_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_FOLLOWUP_1AS));	\
		}

#define	PTPMSG_AS_FLLWUP_SZ					76U
#define	PTPMSG_AS_FLLWUP_PRCSORGNTS_SZ		10U
#define	PTPMSG_AS_FLLWUP_FLLWUPTLV_SZ		32U

typedef struct tagPTPMSG_PDELAY_REQ_1AS
{
	PTPMSG_HEADER		stHeader;
	UCHAR				uchReserved1[10];
	UCHAR				uchReserved2[10];

}	PTPMSG_PDELAY_REQ_1AS;

#define	GetPTPMSG_PDELAY_REQ_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).uchReserved1))	\
				+	(sizeof((a).uchReserved2));	\
			DEBUG_PRINT("GetPTPMSG_PDELAY_REQ_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDELAY_REQ_1AS));	\
		}

#define	PTPMSG_AS_PDELAYREQ_SZ				54U
#define	PTPMSG_AS_PDELAYREQ_RESERVED1_SZ	10U
#define	PTPMSG_AS_PDELAYREQ_RESERVED2_SZ	10U

typedef struct tagPTPMSG_PDELAY_RESP_1AS
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stReqRcptTimestamp;
	PORTIDENTITY		stReqPortIdentity;

}	PTPMSG_PDELAY_RESP_1AS;

#define	GetPTPMSG_PDELAY_RESP_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).stReqRcptTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stReqRcptTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stReqRcptTimestamp.ulNanoseconds))		\
				+	(sizeof((a).stReqPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stReqPortIdentity.usPortNumber));			\
			DEBUG_PRINT("GetPTPMSG_PDELAY_RESP_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDELAY_RESP_1AS));	\
		}

#define	PTPMSG_AS_PDELAYRESP_SZ				54U
#define	PTPMSG_AS_PDELAYRESP_REQRCPTS_SZ	10U
#define	PTPMSG_AS_PDELAYRESP_REQPRTID_SZ	10U


typedef struct tagPTPMSG_PDRESP_FOLLOWUP_1AS
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stRespOrgnTimestamp;
	PORTIDENTITY		stReqPortIdentity;

}	PTPMSG_PDRESP_FOLLOWUP_1AS;

#define	GetPTPMSG_PDRESP_FOLLOWUP_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).stRespOrgnTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stRespOrgnTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stRespOrgnTimestamp.ulNanoseconds))		\
				+	(sizeof((a).stReqPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stReqPortIdentity.usPortNumber));			\
			DEBUG_PRINT("GetPTPMSG_PDRESP_FOLLOWUP_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDRESP_FOLLOWUP_1AS));	\
		}

#define	PTPMSG_AS_PDLYRESPFL_SZ				54U
#define	PTPMSG_AS_PDLYRESPFL_RSPORGTS_SZ	10U
#define	PTPMSG_AS_PDLYRESPFL_REQPRTID_SZ	10U



typedef struct tagPTPMSG_SYNC_1588
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;

}	PTPMSG_SYNC_1588;

#define	GetPTPMSG_SYNC_1588(a,b) \
		{	\
			(b) += 	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stOriginTimestamp.ulNanoseconds));		\
			DEBUG_PRINT("GetPTPMSG_SYNC_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_SYNC_1588));	\
		}

#define	PTPMSG_SYNC_SZ				44U
#define	PTPMSG_SYNC_ORIGINTS_SZ		10U


typedef struct tagPTPMSG_FOLLOWUP_1588{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stPrcsOrgnTimestamp;

}	PTPMSG_FOLLOWUP_1588;

#define	GetPTPMSG_FOLLOWUP_1588(a,b) \
		{	\
			(b) += 	(sizeof((a).stPrcsOrgnTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stPrcsOrgnTimestamp.stSeconds.ulSec_lsb))	\
				+ 	(sizeof((a).stPrcsOrgnTimestamp.ulNanoseconds));	\
			DEBUG_PRINT("GetPTPMSG_FOLLOWUP_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_FOLLOWUP_1588));	\
		}

#define	PTPMSG_FLLWUP_SZ				44U
#define	PTPMSG_FLLWUP_PRCSORGNTS_SZ		10U


typedef struct tagPTPMSG_DELAY_REQ_1588{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;

}	PTPMSG_DELAY_REQ_1588;

#define	GetPTPMSG_DELAY_REQ_1588(a,b) \
		{	\
			(b) += 	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))	\
				+ 	(sizeof((a).stOriginTimestamp.ulNanoseconds));		\
			DEBUG_PRINT("GetPTPMSG_DELAY_REQ_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_DELAY_REQ_1588));	\
		}

#define	PTPMSG_DELAYREQ_SZ				44U
#define	PTPMSG_DELAYREQ_ORIGINTS_SZ		10U

typedef struct tagPTPMSG_DELAY_RESP_1588{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stRcvTimestamp;
	PORTIDENTITY		stReqPortIdentity;

}	PTPMSG_DELAY_RESP_1588;

#define	GetPTPMSG_DELAY_RESP_1588(a,b) \
		{	\
			(b) += 	(sizeof((a).stRcvTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stRcvTimestamp.stSeconds.ulSec_lsb))	\
				+ 	(sizeof((a).stRcvTimestamp.ulNanoseconds))		\
				+ 	(sizeof((a).stReqPortIdentity.stClockIdentity.uchId))	\
				+ 	(sizeof((a).stReqPortIdentity.usPortNumber));			\
			DEBUG_PRINT("GetPTPMSG_DELAY_RESP_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_DELAY_RESP_1588));	\
		}

#define	PTPMSG_DELAYRESP_SZ				54U
#define	PTPMSG_DELAYRESP_RCVTS_SZ		10U
#define	PTPMSG_DELAYRESP_REQPORTID_SZ	10U


typedef struct tagPTPMSG_PDELAY_REQ_1588
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;
	UCHAR				uchReserved[10];

}	PTPMSG_PDELAY_REQ_1588;

#define	GetPTPMSG_PDELAY_REQ_1588(a,b) \
		{	\
			(b) +=	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stOriginTimestamp.ulNanoseconds))		\
				+	(sizeof((a).uchReserved));	\
			DEBUG_PRINT("GetPTPMSG_PDELAY_REQ_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDELAY_REQ_1588));	\
		}

#define	PTPMSG_PDELAYREQ_SZ					54U
#define	PTPMSG_PDELAYREQ_ORGTS_SZ			10U
#define	PTPMSG_PDELAYREQ_RESERVED_SZ		10U


typedef struct tagPTPMSG_PDELAY_RESP_1588
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stReqRcptTimestamp;
	PORTIDENTITY		stReqPortIdentity;

}	PTPMSG_PDELAY_RESP_1588;

#define	GetPTPMSG_PDELAY_RESP_1588(a,b) \
		{	\
			(b) +=	(sizeof((a).stReqRcptTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stReqRcptTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stReqRcptTimestamp.ulNanoseconds))		\
				+	(sizeof((a).stReqPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stReqPortIdentity.usPortNumber));			\
			DEBUG_PRINT("GetPTPMSG_PDELAY_RESP_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDELAY_RESP_1588));	\
		}

#define	PTPMSG_PDELAYRESP_SZ				54U
#define	PTPMSG_PDELAYRESP_REQRCPTS_SZ		10U
#define	PTPMSG_PDELAYRESP_REQPRTID_SZ		10U


typedef struct tagPTPMSG_PDRESP_FOLLOWUP_1588
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stRespOrgnTimestamp;
	PORTIDENTITY		stReqPortIdentity;

}	PTPMSG_PDRESP_FOLLOWUP_1588;

#define	GetPTPMSG_PDRESP_FOLLOWUP_1588(a,b) \
		{	\
			(b) += 	(sizeof((a).stRespOrgnTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stRespOrgnTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stRespOrgnTimestamp.ulNanoseconds))		\
				+	(sizeof((a).stReqPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stReqPortIdentity.usPortNumber));			\
			DEBUG_PRINT("GetPTPMSG_PDRESP_FOLLOWUP_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_PDRESP_FOLLOWUP_1588));	\
		}

#define	PTPMSG_PDLYRESPFL_SZ				54U
#define	PTPMSG_PDLYRESPFL_RSPORGTS_SZ		10U
#define	PTPMSG_PDLYRESPFL_REQPRTID_SZ		10U



typedef struct tagPTPMSG_SIGNALING_1AS
{
	PTPMSG_HEADER		stHeader;
	PORTIDENTITY		stTargetPortIdentity;
	union
	{
		PTPMSG_INTERVAL_TLV			stIntervalReq_TLV;
		PTPMSG_GPTPCAPABLE_TLV		stGptpCap_TLV;
		PTPMSG_GPTPCAPABLE_INT_TLV	stGptpCapInt_TLV;
	};
}	PTPMSG_SIGNALING_1AS;

#define	GetPTPMSG_SIGNALING_1AS(a,b) \
		{	\
			(b) += 	(sizeof((a).stTargetPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stTargetPortIdentity.usPortNumber));	\
			DEBUG_PRINT("GetPTPMSG_SIGNALING_1AS = %d sizeof(%d) \n",(b), sizeof(PTPMSG_SIGNALING_1AS));	\
		}

#define	PTPMSG_AS_SGNL_SZ					60U
#define	PTPMSG_AS_SGNL_TGTPORTID_SZ			10U
#define	PTPMSG_AS_SGNL_INTVALREQ_TLV_SZ		16U

typedef union tagPTPMSG_MGTTLV_1588
{
	UCHAR					uchTlvField[4];
	USHORT					usTlvField[2];
	ULONG					ulTlvField;
	UCHAR					uchManagemant_TLV;
}	PTPMSG_MGTTLV_1588;
typedef struct tagPTPMSG_MANAGEMENT_1588
{
	PTPMSG_HEADER			stHeader;
	PORTIDENTITY			stTargetPortIdentity;
	UCHAR					uchStartBoundaryHops;
	UCHAR					uchBoundaryHops;
	BYTE		            byActionField;

	UCHAR					uchReserved;
	PTPMSG_MGTTLV_1588		stManagemant_TLV;
}	PTPMSG_MANAGEMENT_1588;

#define	GetPTPMSG_MANAGEMENT_1588(a,b) \
		{	\
			(b) +=	(sizeof((a).stTargetPortIdentity.stClockIdentity.uchId))	\
				+	(sizeof((a).stTargetPortIdentity.usPortNumber))				\
				+	(sizeof((a).uchStartBoundaryHops))		\
				+	(sizeof((a).uchBoundaryHops))			\
				+	(sizeof((a).byActionField))				\
				+	(sizeof((a).uchReserved));				\
			DEBUG_PRINT("GetPTPMSG_MANAGEMENT_1588 = %d sizeof(%d) \n",(b), sizeof(PTPMSG_MANAGEMENT_1588));	\
		}

#define	PTPMSG_MANAGEMENT_SZ				48U
#define	PTPMSG_MANAGEMENT_TGTPORTID_SZ		10U
#define	PTPMSG_MANAGEMENT_SBUNDRYHOPS_SZ	1U
#define	PTPMSG_MANAGEMENT_BUNDRYHOPS_SZ		1U
#define	PTPMSG_MANAGEMENT_ACTIONFLD_SZ		1U
#define	PTPMSG_MANAGEMENT_RESERVED_SZ		1U

typedef struct tagPTPMSG_ANNOUNCE
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;
	SHORT				sCurrentUtcOffset;
	UCHAR				uchReserved;
	UCHAR				uchGrandmasterPriority1;
	CLOCKQUALITY		stGrandmasterClockQuality;
	UCHAR				uchGrandmasterPriority2;
	CLOCKIDENTITY		stGrandmasterIdentity;
	USHORT				usStepsRemoved;
	UCHAR				uchTimeSource;
	PTPMSG_ANNOUNCE_TLV	stAnnounce_TLV;
} PTPMSG_ANNOUNCE;

#define	GetPTPMSG_ANNOUNCE(a,b) \
		{	\
			(b) += 	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stOriginTimestamp.ulNanoseconds))		\
				+	(sizeof((a).sCurrentUtcOffset))				\
				+	(sizeof((a).uchReserved))					\
				+	(sizeof((a).uchGrandmasterPriority1))		\
				+	(sizeof((a).stGrandmasterClockQuality.uchClockClass))				\
				+	(sizeof((a).stGrandmasterClockQuality.uchClockAccuracy))			\
				+	(sizeof((a).stGrandmasterClockQuality.usOffsetScaledLogVariance))	\
				+	(sizeof((a).uchGrandmasterPriority2))		\
				+	(sizeof((a).stGrandmasterIdentity))			\
				+	(sizeof((a).usStepsRemoved))				\
				+	(sizeof((a).uchTimeSource));				\
			DEBUG_PRINT("GetPTPMSG_ANNOUNCE = %d sizeof(%d) \n",(b), sizeof(PTPMSG_ANNOUNCE));	\
		}

typedef struct tagPTPMSG_ANNOUNCE_WO_TLV
{
	PTPMSG_HEADER		stHeader;
	TIMESTAMP			stOriginTimestamp;
	SHORT				sCurrentUtcOffset;
	UCHAR				uchReserved;
	UCHAR				uchGrandmasterPriority1;
	CLOCKQUALITY		stGrandmasterClockQuality;
	UCHAR				uchGrandmasterPriority2;
	CLOCKIDENTITY		stGrandmasterIdentity;
	USHORT				usStepsRemoved;
	UCHAR				uchTimeSource;
} PTPMSG_ANNOUNCE_WO_TLV;

#define	GetPTPMSG_ANNOUNCE_WO_TLV(a,b) \
		{	\
			(b) += 	(sizeof((a).stOriginTimestamp.stSeconds.usSec_msb))	\
				+	(sizeof((a).stOriginTimestamp.stSeconds.ulSec_lsb))	\
				+	(sizeof((a).stOriginTimestamp.ulNanoseconds))		\
				+	(sizeof((a).sCurrentUtcOffset))				\
				+	(sizeof((a).uchReserved))					\
				+	(sizeof((a).uchGrandmasterPriority1))		\
				+	(sizeof((a).stGrandmasterClockQuality.uchClockClass))				\
				+	(sizeof((a).stGrandmasterClockQuality.uchClockAccuracy))			\
				+	(sizeof((a).stGrandmasterClockQuality.usOffsetScaledLogVariance))	\
				+	(sizeof((a).uchGrandmasterPriority2))		\
				+	(sizeof((a).stGrandmasterIdentity))			\
				+	(sizeof((a).usStepsRemoved))				\
				+	(sizeof((a).uchTimeSource));				\
			DEBUG_PRINT("GetPTPMSG_ANNOUNCE_WO_TLV = %d sizeof(%d) \n",(b), sizeof(GetPTPMSG_ANNOUNCE_WO_TLV));	\
		}

#define PTPMSG_ANUNC_SZ					64U
#define PTPMSG_ANUNC_ORGTS_SZ			10U
#define PTPMSG_ANUNC_RESERVEDAS_SZ		10U
#define PTPMSG_ANUNC_CRNTUTCOFS_SZ		2U
#define PTPMSG_ANUNC_RESERVED_SZ		1U
#define PTPMSG_ANUNC_GMPRIORITY1_SZ		1U
#define PTPMSG_ANUNC_GMCLKQUALITY_SZ	4U
#define PTPMSG_ANUNC_GMPRIORITY2_SZ		1U
#define PTPMSG_ANUNC_GMCLKID_SZ			8U
#define PTPMSG_ANUNC_STPSREMOVED_SZ		2U
#define PTPMSG_ANUNC_TIMESRC_SZ			1U

typedef union tagPTPMSG
{
	PTPMSG_HEADER						stHeader;
	PTPMSG_SYNC_TWO_STEP_1AS			stSyncTwo_1AS;
	PTPMSG_SYNC_ONE_STEP_1AS			stSyncOne_1AS;
	PTPMSG_FOLLOWUP_1AS					stFollowUp_1AS;
	PTPMSG_PDELAY_REQ_1AS				stPdlyReq_1AS;
	PTPMSG_PDELAY_RESP_1AS				stPdlyResp_1AS;
	PTPMSG_PDRESP_FOLLOWUP_1AS			stPDRespFlwUp_1AS;

	PTPMSG_SYNC_1588					stSync_1588;
	PTPMSG_FOLLOWUP_1588				stFollowUp_1588;
	PTPMSG_DELAY_REQ_1588				stDlyReq_1588;
	PTPMSG_DELAY_RESP_1588				stDlyResp_1588;
	PTPMSG_PDELAY_REQ_1588				stPdlyReq_1588;
	PTPMSG_PDELAY_RESP_1588				stPdlyResp_1588;
	PTPMSG_PDRESP_FOLLOWUP_1588			stPDRespFlwUp_1588;

	PTPMSG_SIGNALING_1AS				stSignaling_1AS;
	PTPMSG_MANAGEMENT_1588				stManagement_1588;

	PTPMSG_ANNOUNCE						stAnnounce;
}	PTPMSG;

#endif
