//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include "net.h"
#include "local.h"
#include "support.h"
#include "snmpv3.h"



static sint16 conno, tconno;
static sint16 passive_close(void);

extern struct NETCONF netconf[];
extern struct NET nets[];


static sint16 init(uint8 *ip, uint32 *maxsize, uint8 *name)
{
    sint16 i1;

    for (i1 = 0; i1 < NCONFIGS; i1++)
    {
        if (netconf[i1].flags & LOCALHOST)
        {
            if (*ip == 0 && *netconf[i1].Iaddr.c)
                memcpy(ip, netconf[i1].Iaddr.c, Iid_SZ);
            if (nets[netconf[i1].netno].maxblo - 40 < (sint16)*maxsize)
                *maxsize = nets[netconf[i1].netno].maxblo - 40;
        }
    }

    strcpy((char *)name, localhostname);

    return 0;
}


static sint16 passive_open(void)
{
    conno = Nopen("*", "UDP/IP", 161, 0, S_NOCON | S_NOWA);
    if (conno < 0)
    {
#if NTRACE
        Nprintf("TM_DPI: Nopen(*) failed %d!\n", conno);
#endif
        Nterm();
        return conno;
    }

    return 0;
}


static sint16 passive_read(uint8 *buff, uint16 len)
{
    int i1;

    YIELD();

    SOCKET_NOBLOCK(conno);
    i1 = Nread(conno, (char *)buff, len);
    SOCKET_BLOCK(conno);

    if (i1 < 0)
        if (i1 == EWOULDBLOCK)
            i1 = 0;
        else
        {
#if NTRACE
            Nprintf("TM_DPI: Nread() failed %d!\n", i1);
#endif
            passive_close();
            i1 = passive_open();
        }

    return i1;
}


static sint16 passive_write(const uint8 *buff, uint16 len)
{
    int i1;

    i1 = Nwrite(conno, (char *)buff, len);
    if (i1 == len)
        i1 = 0;
    else
    {
#if NTRACE
        Nprintf("TM_DPI: Nwrite() failed %d!\n", i1);
#endif
        passive_close();
        i1 = passive_open();
    }

    return i1;
}


static sint16 passive_close(void)
{
    Nclose(conno);

    return 0;
}


static sint16 active_open(const uint8 *rhost)
{
    sint16 i1;

    tconno = Nopen((char *)rhost, "UDP/IP", Nportno(), 162, 0);
    if (tconno >= 0)
        i1 = 0;
#if NTRACE
    else
    {
        i1 = tconno;
        Nprintf("TM_DPI: Active Nopen() for trap failed %d!\n", i1);
    }
#endif

    return i1;
}


static sint16 active_write(const uint8 *buff, uint16 len)
{
    sint16 i1;

    i1 = Nwrite(tconno, (char *)buff, len);
    if (i1 == len)
        i1 = 0;
#if NTRACE
    else
        Nprintf("TM_DPI: Nwrite() for trap failed %d!\n", i1);
#endif

    return i1;
}


static sint16 active_close(void)
{
    Nclose(tconno);

    return 0;
}


static uint32 host_time(void)
{
    return TimeMS() / 10;
}


const TRANSPORT_MAPPING TM_DPI =
{
    init,

    passive_open,
    passive_read,
    passive_write,
    passive_close,

    active_open,
    active_write,
    0,
    active_close,

    host_time
};

