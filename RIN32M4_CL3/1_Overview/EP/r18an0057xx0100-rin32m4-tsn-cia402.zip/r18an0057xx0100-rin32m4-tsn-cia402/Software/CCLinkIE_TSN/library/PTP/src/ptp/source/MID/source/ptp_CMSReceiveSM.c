/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"
#ifdef	PTP_USE_GM

#include "ptp_CMSOffset_1AS.h"
#include "ptp_CMSSend.h"
#include "ptp_CMSReceive.h"
#include "ptp_GetDetailCurrentTime.h"


#ifdef	PTP_USE_ME_HW_ASSIST
#include "ptp_CSSync_1AS.h"
#include "ptp_LCEntity.h"
#include "ptp_tsn_Wrapper.h"
#endif

#define D_FUNC	0


VOID	CMSReceive_00(CLOCKDATA*	pstClockData);
VOID	CMSReceive_01(CLOCKDATA*	pstClockData);
VOID	CMSReceive_02(CLOCKDATA*	pstClockData);
VOID	CMSReceive_03(CLOCKDATA*	pstClockData);
VOID	computeGmRateRatio(CLOCKDATA*	pstClockData);
VOID	setComputeGRRatioStack(CMSRECEIVESM_GD*	pstCMSRGlb,	CLOCKDATA*	pstClockData);
DOUBLE	calcRateRatio(	CMSRECEIVESM_GD*	pstCMSRGlb);
VOID	updateMasterTime(CLOCKDATA*	pstClockData);





VOID (*const pfnCMSReceiveMatrix[ST_CMSR_MAX][EV_CMSR_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CMSReceive_01, &CMSReceive_01, &CMSReceive_01, &CMSReceive_00},
	{&CMSReceive_01, &CMSReceive_02, &CMSReceive_02, &CMSReceive_00},
	{&CMSReceive_01, &CMSReceive_03, &CMSReceive_03, &CMSReceive_00},
	{&CMSReceive_01, &CMSReceive_03, &CMSReceive_03, &CMSReceive_00}
};



VOID	clockMasterSyncReceive(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSR	enEvt = EV_CMSR_EVENT_MAX;
	BOOL 		blSts = FALSE;
	CLOCKDATA*	pstClockDataWk;

	CMSRECEIVESM_GD*	pstCMSRGlb	= GetCMSReceiveSM_GD(pstClockData);
	CLKSOURCETIME*		pstRcvdClockSourceReqPtr = NULL;

	pstRcvdClockSourceReqPtr = &(pstCMSRGlb->stRcvdClockSourceReq);

	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("CMSReceiveSM   Evt=%d Sts=%d\n", usEvent, pstClockData->stCMSReceiveSM_GD.enStatusCMSR);
}
#endif
		enEvt = GetCMSReceiveSM_Event(usEvent, pstClockData);

		blSts = IsCMSReceiveSM_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CMSR_EVENT_MAX))
		{
			if (enEvt == EV_CMSR_BEGIN)
			{
				if (pstCMSRGlb->blRcvdClockSourceReq)
				{

					gusClockSourceTimeBaseIndOld 	= gusClockSourceTimeBaseIndicator;
					gusClockSourceTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;
					gstClockSourceLastGmPhaseChange = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;
					gdbClockSourceLastGmFreqChange  = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
					gstClockSourcePhaseOffset		= pstRcvdClockSourceReqPtr->stLastGmPhaseChange;
					gdbClockSourceFreqOffset		= pstRcvdClockSourceReqPtr->dbLastGmFreqChange;

					pstClockDataWk = gpstClockDataHPtr;

					while (pstClockDataWk)
					{
						pstClockDataWk->stClock_GD.dbCurMasterLastFreqChange    = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
						pstClockDataWk->stClock_GD.usCurMasterTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;
						pstClockDataWk->stClock_GD.stCurMasterLastPhaseChange   = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;

						pstClockDataWk = pstClockDataWk->pstNextClockDataPtr;
					}
				}
				pstCMSRGlb->blRcvdClockSourceReq	= FALSE;
			}
			(*pfnCMSReceiveMatrix[pstClockData->stCMSReceiveSM_GD.enStatusCMSR][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CMSRECEIVESM, PTP_LOGVE_84000010);
			pstClockData->stCMSReceiveSM_GD.blRcvdClockSourceReq	= FALSE;
			pstClockData->stCMSReceiveSM_GD.blRcvdLocalClockTick	= FALSE;
		}

	}
}




CMSRECEIVESM_GD*	GetCMSReceiveSM_GD(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb = &(pstClockData->stCMSReceiveSM_GD);
	return pstCMSRGlb;
}




EN_EV_CMSR	GetCMSReceiveSM_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSR	enEvt = EV_CMSR_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CMSR_BEGIN;
			break;

		case PTP_EV_RCVDCLOCKSOURCEREQ:
			enEvt = EV_CMSR_RCVDCLOCKSOURCEREQ;
			break;

		case PTP_EV_FOR_CLKMSYNRV_RVLOCTICK:
			enEvt = EV_CMSR_FOR_CLKMSYNRV_RVLOCTICK;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CMSR_CLOSE;
			break;

		default:
			enEvt = EV_CMSR_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsCMSReceiveSM_Status(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb	= GetCMSReceiveSM_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstCMSRGlb->enStatusCMSR < ST_CMSR_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}



VOID	ptp_GetMasterTime(
	CLOCKDATA*	pstClockData,
	EXTENDEDTIMESTAMP*	pstMasterTime)
{

#ifndef	PTP_USE_ME_HW_ASSIST
	(VOID)ptp_TimerSemLockWait();

	(*pstMasterTime) = gstMasterTime;

#else
	{
		SCALEDNS	stB_SNs;
		USCALEDNS	stC_USNs;
		SCALEDNS	stD_SNs;
		USCALEDNS	stE_USNs;

		ptp_GetDetailCurrentTime (&stC_USNs);

		(VOID)ptpSubUSNs_USNs(&stC_USNs,
					&gstCurrentTime,
					&stB_SNs);

		(VOID)ptpMultSNs_Doub(&stB_SNs, gdbGmRateRatio, &stD_SNs );

		ptp_GetCurrentMasterTime (pstClockData, &stC_USNs);

		(VOID)ptpAddUSNs_SNs( &stC_USNs, &stD_SNs, &stE_USNs );
		ptpConvUSNs_ETS(&stE_USNs, pstMasterTime);

	}
#endif
#ifndef	PTP_USE_ME_HW_ASSIST
	(VOID)ptp_TimerSemUnLock();
#endif

}




#ifndef	PTP_USE_ME_HW_ASSIST
VOID	ptp_SetMasterTime(
	CLOCKDATA*	pstClockData,
	EXTENDEDTIMESTAMP*	pstMasterTime)
{
	USCALEDNS			stDetailCurTime	= {0};
	SCALEDNS			stSNs			= {0};
	SCALEDNS			stDtSNs			= {0};
	USCALEDNS			stAnsUSNs 		= {0};


	(VOID)ptp_TimerSemLockWait();
 	gstMasterTime = *pstMasterTime;

	ptp_GetDetailCurrentTime(&stDetailCurTime);

	gstLocalTime   = stDetailCurTime;
	gstCurrentTime = stDetailCurTime;

	(VOID)ptpSubUSNs_USNs( &stDetailCurTime, &gstCurrentTime, &stSNs );

	(VOID)ptpMultSNs_Doub( &stSNs, gdbRateRatio, &stDtSNs );
	(VOID)ptpAddUSNs_SNs( &gstCurrentMasterTime, &stDtSNs, &stAnsUSNs );
	gstCurrentMasterTime = stAnsUSNs;


	(VOID)ptp_TimerSemUnLock();

}
#endif




VOID	ptp_GetLocalTime(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstLocalTime)
{

	(VOID)ptp_TimerSemLockWait();

	(*pstLocalTime) = gstLocalTime;

	(VOID)ptp_TimerSemUnLock();

}




VOID	ptp_SetLocalTime(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstLocalTime)
{

	(VOID)ptp_TimerSemLockWait();

	gstLocalTime = *pstLocalTime;

	(VOID)ptp_TimerSemUnLock();

}






VOID	CMSReceive_00(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb = GetCMSReceiveSM_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CMSReceive_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstCMSRGlb->uchStackCount    = 0U;
	pstCMSRGlb->uchCompareCount  = 0U;
	pstCMSRGlb->uchMaxStackCount = 0U;
	gusClockSourceTimeBaseIndOld = 0U;


	updateMasterTime(pstClockData);
	pstCMSRGlb->blRcvdLocalClockTick	= FALSE;

	pstCMSRGlb->enStatusCMSR			= ST_CMSR_NONE;

	ptp_dbg_msg( D_FUNC, ("CMSReceive_00::-\n") );

}




VOID	CMSReceive_01(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb = GetCMSReceiveSM_GD(pstClockData);

	CLOCKDATA*	pstClockDataWk;

	pstCMSRGlb->uchStackCount    = 0U;
	pstCMSRGlb->uchCompareCount  = 0U;
	pstCMSRGlb->uchMaxStackCount = 0U;

	gusClockSourceTimeBaseIndOld = 0U;

	if (pstCMSRGlb->blRcvdClockSourceReq)
	{
		updateMasterTime (pstClockData);

		gusClockSourceTimeBaseIndicator = pstCMSRGlb->stRcvdClockSourceReq.usTimeBaseIndicator;
		gstClockSourceLastGmPhaseChange	= pstCMSRGlb->stRcvdClockSourceReq.stLastGmPhaseChange;
		gdbClockSourceLastGmFreqChange  = pstCMSRGlb->stRcvdClockSourceReq.dbLastGmFreqChange;
		gstClockSourcePhaseOffset       = pstCMSRGlb->stRcvdClockSourceReq.stLastGmPhaseChange;
		gdbClockSourceFreqOffset		= pstCMSRGlb->stRcvdClockSourceReq.dbLastGmFreqChange;

		pstClockDataWk = gpstClockDataHPtr;

		while (pstClockDataWk)
		{
			pstClockDataWk->stClock_GD.dbCurMasterLastFreqChange    = pstCMSRGlb->stRcvdClockSourceReq.dbLastGmFreqChange;
			pstClockDataWk->stClock_GD.usCurMasterTimeBaseIndicator = pstCMSRGlb->stRcvdClockSourceReq.usTimeBaseIndicator;
			pstClockDataWk->stClock_GD.stCurMasterLastPhaseChange   = pstCMSRGlb->stRcvdClockSourceReq.stLastGmPhaseChange;

			pstClockDataWk = pstClockDataWk->pstNextClockDataPtr;
		}

		pstCMSRGlb->blRcvdClockSourceReq	= FALSE;
	}

	pstCMSRGlb->blRcvdLocalClockTick	= FALSE;
	pstCMSRGlb->enStatusCMSR			= ST_CMSR_WAITING;

}




VOID	CMSReceive_02(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb = GetCMSReceiveSM_GD(pstClockData);


	pstCMSRGlb->enStatusCMSR	= ST_CMSR_WAITING;

}




#ifndef	PTP_USE_ME_HW_ASSIST
VOID	CMSReceive_03(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb				= GetCMSReceiveSM_GD(pstClockData);
	CLKSOURCETIME*		pstRcvdClockSourceReqPtr	= NULL;

	CLOCKDATA*	pstClockDataWk;


	pstRcvdClockSourceReqPtr	= &(pstCMSRGlb->stRcvdClockSourceReq);
	updateMasterTime(pstClockData);



	if (pstCMSRGlb->blRcvdClockSourceReq)
	{
		computeGmRateRatio(pstClockData);



		gusClockSourceTimeBaseIndOld 	= gusClockSourceTimeBaseIndicator;
		gusClockSourceTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;
		gstClockSourceLastGmPhaseChange	= pstRcvdClockSourceReqPtr->stLastGmPhaseChange;
		gdbClockSourceLastGmFreqChange  = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
		gstClockSourcePhaseOffset       = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;
		gdbClockSourceFreqOffset		= pstRcvdClockSourceReqPtr->dbLastGmFreqChange;

		pstClockDataWk = gpstClockDataHPtr;

		while (pstClockDataWk)
		{
			pstClockDataWk->stClock_GD.dbCurMasterLastFreqChange    = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
			pstClockDataWk->stClock_GD.usCurMasterTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;
			pstClockDataWk->stClock_GD.stCurMasterLastPhaseChange   = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;

			pstClockDataWk = pstClockDataWk->pstNextClockDataPtr;
		}

	}

	pstCMSRGlb->blRcvdClockSourceReq	= FALSE;
	pstCMSRGlb->blRcvdLocalClockTick	= FALSE;
	pstCMSRGlb->enStatusCMSR			= ST_CMSR_WAITING;

}
#else
VOID	CMSReceive_03(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb					= GetCMSReceiveSM_GD(pstClockData);
	CLKSOURCETIME*		pstRcvdClockSourceReqPtr	= NULL;
	USCALEDNS			stCurrentMasterTime 		= {0};
	BOOL				blRet						= TRUE;
	DOUBLE				dbRateRatio					= 1.0;

	CLOCKDATA*	pstClockDataWk;


	pstRcvdClockSourceReqPtr	= &(pstCMSRGlb->stRcvdClockSourceReq);

	if (pstCMSRGlb->blRcvdClockSourceReq)
	{
		updateMasterTime(pstClockData);

		ptp_GetCurrentMasterTime((CLOCKDATA*)NULL,	&stCurrentMasterTime);
		ptp_GetDetailCurrentTime (&gstLocatTimeForMaster);

		tsn_Wrapper_MemCpy( (VOID *)&gstMasterLocalOffset,
							(const VOID *)&(pstRcvdClockSourceReqPtr->stSourceTime), 
							sizeof(EXTENDEDTIMESTAMP) );

		blRet = ptpSubETS_USNs_SNs( &(pstRcvdClockSourceReqPtr->stSourceTime), 
		                            &stCurrentMasterTime, 
		                            &gstClockSourcePhaseOffset );

		if (blRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CMSRECEIVESM, PTP_LOGVE_OVERFLOW);
		}

		computeGmRateRatio(pstClockData);


		gusClockSourceTimeBaseIndOld    = gusClockSourceTimeBaseIndicator;
		gusClockSourceTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;


		gstClockSourcePhaseOffset = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;
		gdbClockSourceFreqOffset  = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
		gdbClockSourceLastGmFreqChange = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;

		pstClockDataWk = gpstClockDataHPtr;

		while (pstClockDataWk)
		{
			pstClockDataWk->stClock_GD.dbCurMasterLastFreqChange    = pstRcvdClockSourceReqPtr->dbLastGmFreqChange;
			pstClockDataWk->stClock_GD.usCurMasterTimeBaseIndicator = pstRcvdClockSourceReqPtr->usTimeBaseIndicator;
			pstClockDataWk->stClock_GD.stCurMasterLastPhaseChange   = pstRcvdClockSourceReqPtr->stLastGmPhaseChange;

			pstClockDataWk = pstClockDataWk->pstNextClockDataPtr;
		}

	}

	pstCMSRGlb->blRcvdClockSourceReq	= FALSE;
	pstCMSRGlb->blRcvdLocalClockTick	= FALSE;
	pstCMSRGlb->enStatusCMSR			= ST_CMSR_WAITING;

}
#endif

VOID	computeGmRateRatio(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb	= GetCMSReceiveSM_GD(pstClockData);
	DOUBLE				dbGmRateW	= DBCONST0_0;


	if (pstCMSRGlb->uchMaxStackCount == 0)
	{
		pstCMSRGlb->uchStackCount = 0;
		pstCMSRGlb->uchCompareCount = 0;

		setComputeGRRatioStack(pstCMSRGlb, pstClockData);

		pstCMSRGlb->uchMaxStackCount += 1;

	}
	else if (pstCMSRGlb->uchMaxStackCount <= COMPUTEGRRATIO_N)
	{
		pstCMSRGlb->uchStackCount += 1;
		pstCMSRGlb->uchCompareCount = 0;

		setComputeGRRatioStack(pstCMSRGlb, pstClockData);

		pstCMSRGlb->uchMaxStackCount += 1;
		
		dbGmRateW = calcRateRatio(pstCMSRGlb);
		if ((dbGmRateW > DBCONST_RATE_MIN) &&
			(dbGmRateW < DBCONST_RATE_MAX))
		{
			gdbGmRateRatio = dbGmRateW;
		}
		else
		{
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CMSRECEIVESM, PTP_LOGVE_84000006);
		}
		
	}
	else
	{
		pstCMSRGlb->uchStackCount = pstCMSRGlb->uchCompareCount;

		setComputeGRRatioStack(pstCMSRGlb, pstClockData);

		if (pstCMSRGlb->uchCompareCount >= COMPUTEGRRATIO_N)
		{
			pstCMSRGlb->uchCompareCount = 0;
		}
		else
		{
			pstCMSRGlb->uchCompareCount += 1;
		}
		
		dbGmRateW = calcRateRatio(pstCMSRGlb);
		if ((dbGmRateW > DBCONST_RATE_MIN) &&
			(dbGmRateW < DBCONST_RATE_MAX))
		{
			gdbGmRateRatio = dbGmRateW;
		}
		else
		{
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CMSRECEIVESM, PTP_LOGVE_84000006);
		}

	}
}




VOID	setComputeGRRatioStack(
	CMSRECEIVESM_GD*	pstCMSRGlb,
	CLOCKDATA*	pstClockData)
{
	USCALEDNS		stLocalTime	= {0};


	ptp_GetLocalTime(pstClockData, &stLocalTime);

	pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchStackCount].stSourceTime
		= pstCMSRGlb->pstRcvdClockSourceReqPtr->stSourceTime;
	pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchStackCount].stLocalTime
		= stLocalTime;

}




DOUBLE	calcRateRatio(
	CMSRECEIVESM_GD*	pstCMSRGlb)
{
	SCALEDNS			stSubSTimeSNs	={0};
	SCALEDNS			stSubLTimeSNs	={0};
	DOUBLE				dbRateRatio		= DBCONST1_0;


	(VOID)ptpSubETS_ETS(&(pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchStackCount].stSourceTime),
							&(pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchCompareCount].stSourceTime),
							&stSubSTimeSNs);

	(VOID)ptpSubUSNs_USNs(&(pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchStackCount].stLocalTime),
							&(pstCMSRGlb->stComputeGRRatioStack[pstCMSRGlb->uchCompareCount].stLocalTime),
							&stSubLTimeSNs);

	if (!IS_SCALEDNS_0(stSubLTimeSNs))
	{
		(VOID)ptpDivSNs_SNs(&stSubSTimeSNs, &stSubLTimeSNs, &dbRateRatio);
	}

	return dbRateRatio;
}




VOID	updateMasterTime(
	CLOCKDATA*	pstClockData)
{
	CMSRECEIVESM_GD*	pstCMSRGlb		= GetCMSReceiveSM_GD(pstClockData);
	CLKSOURCETIME*		pstRcvdCSReqPtr = NULL;


	pstRcvdCSReqPtr = &(pstCMSRGlb->stRcvdClockSourceReq);
	if (pstCMSRGlb->blRcvdClockSourceReq)
	{
#ifdef	PTP_USE_ME_HW_ASSIST

		if (((gblStartUpOpen == TRUE) && (pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)) ||
					((gblStartUpOpen != TRUE) && (gblStartUpConfig == TRUE)))
		{
			ptp_SetMasterTime((CLOCKDATA*)NULL, &(pstRcvdCSReqPtr->stSourceTime));
		}
#else
		ptp_SetMasterTime(pstClockData, &(pstRcvdCSReqPtr->stSourceTime));
#endif
	}


}




#endif

