/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYREQSENDSM_H__
#define __MDDELAYREQSENDSM_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDDelayReqSendSM(USHORT usEvent, PORTDATA* pstPort);

MDDREQSDSM_GD*		GetMDDReqSndSMGlobal(PORTDATA* pstPort);
MDDREQSNDSM_EV		GetMDDReqSndEvent(USHORT usEvent, PORTDATA* pstPort);
MDDREQSNDSM_ST		GetMDDReqSndStatus(PORTDATA* pstPort);
VOID				SetMDDReqSndStatus(MDDREQSNDSM_ST enSts, PORTDATA* pstPort);

BOOL	SetMDDlyReqEvEgresTimestamp(MDDREQSDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
