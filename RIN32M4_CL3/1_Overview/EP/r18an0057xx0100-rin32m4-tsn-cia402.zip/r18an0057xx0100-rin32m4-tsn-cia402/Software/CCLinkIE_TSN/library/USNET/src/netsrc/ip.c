//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "socket.h"

#define TTL 64
#define TOS  0
#define MAXFRAG 3

int ussHostGroupCheck(Iid iid, int netno);

struct Ihdr {
    char            message_header[MESSH_SZ];
    char            link_header[LHDRSZ];
    unsigned char   verlen;
    unsigned char   tservice;
    unsigned short  tlen;
    unsigned short  frid;
    unsigned short  fragm;
    unsigned char   time;
    unsigned char   prot;
    unsigned short  chksum;
    unsigned char   from[Iid_SZ];
    unsigned char   to[Iid_SZ];
};

unsigned short IPfragid;

#define IP_VER 4
#define ET_IP 0x0800

#define MH(mb) ((struct Ihdr *)mb)

#define IPOFFSET (MESSH_SZ+LHDRSZ)

#ifndef LITTLE
#define PUTL(to, from) memcpy(to, from.c, 4)
#else
#define PUTL(to, from) to[0] = from.c[3], to[1] = from.c[2], \
    to[2] = from.c[1], to[3] = from.c[0]
#endif

extern struct NET nets[];
extern struct CONNECT connblo[];
extern PTABLE  *const P_tab[];
extern PTABLE   ussIPTable;
extern struct ifgroup ifgroup;

#ifdef USSW_DIRECTED_BROADCAST
extern struct DETECTIPDATA detectIpInfo;
#endif
#ifdef MIB2
struct IPgroup  IPgroup;
#endif

#ifdef NAT
void ussNATInit(void);
int ussNATMapOut(unsigned char *iphdrp, const unsigned char *hostIP,
    int len, int *lench);
int ussNATMapIn(unsigned char *iphdrp, int len, int *lench);
#endif

#ifndef IPFLTR_DIS

typedef	unsigned long (* IPFLTRFUNC)(unsigned long inIPaddr);

static IPFLTRFUNC fpIPfltrFunc;

void init_ip_filr_func(void)
{
	fpIPfltrFunc = NULL;
}

void regist_ip_filr_func(IPFLTRFUNC pfunc)
{
	fpIPfltrFunc = pfunc;
}

static int etherman_ip_fltr(unsigned long inIPaddr)
{
	unsigned long ret;
	if( NULL != fpIPfltrFunc ) {
		ret = fpIPfltrFunc(inIPaddr);
		return (int)ret;
	}
	return 1;
}
#endif

static int opeN(int conno, int flags)
{
    (void)conno;
    (void)flags;
    return 1;
}

static int closE(int conno)
{
    (void)conno;
    return 0;
}



static int writE(int conno, MESS *mess)
{
    int i1 = 0, hdroff, ihdrsz;
    unsigned short us1;
    struct NET *netp;
    unsigned char *cp;
#ifdef IPOPTIONS
    Iid iid;
    register struct CONNECT *conp;
    int i2, i3, offset, ipopts;
    unsigned char *endp;
#endif
#if FRAGMENTATION & 2
    unsigned short totdat, maxdat;
    MESS *mp;
    char lnk_hdr[LHDRSZ];
#endif

#ifdef MIB2
    IPgroup.ipOutRequests++;
#endif

    netp = &nets[mess->netno];
    mess->offset = IPOFFSET;

    if (conno < 0) {
        if (conno == -2)
            goto lab6;
        mess->confix = GetHostData(mess->target, 1, mess->netno);
#ifdef IPOPTIONS
        if (mess->retry != 0)
            i1 = -1;
        else if (conno >= -5)
            i1 = MH(mess)->verlen & 0xf;
        else
#endif
        if (conno == -7)
            conno = -5;
    } else {
        mess->confix = connblo[conno].confix;
    }
    us1 = IPfragid++;
    MH(mess)->frid = NC2(us1);

    if ((mess->confix != ussBroadcastIndex) &&
        (mess->confix != ussMulticastIndex)) {
        if (netconf[mess->confix].ncstat != 4)
            if ((mess->confix = GetHostData(mess->target, 3, mess->netno)) == 255)
              	return -1;
    }

#ifdef MIB2
    MH(mess)->time = IPgroup.ipDefaultTTL;
#else
    MH(mess)->time = TTL;
#endif
    MH(mess)->fragm = 0;
    MH(mess)->tservice = TOS;
    memcpy((char *) &MH(mess)->from, (char *) &netconf[netp->confix].Iaddr,
           Iid_SZ);
#ifdef IPOPTIONS
    if (i1 > 5) {
        ihdrsz = i1 * 4;
        ipopts = 0;
        for (cp = (unsigned char *) mess + IPOFFSET + Ihdr_SZ;
             cp < (unsigned char *) mess + IPOFFSET + ihdrsz; cp += offset) {

            if ((cp[0] == 0) || (cp[1] == 0))
                break;
            ipopts ++;
            offset = 1;
            if (cp[0] == 1)
                continue;
            offset = (unsigned char) cp[1];
            if ((cp[0] == 0x83) ||(cp[0] == 0x89)) {
                i2 = (unsigned char) cp[2] - 1;
                i3 = offset - i2;
                if (i3 >= 4) {
                    endp = (unsigned char *) mess + IPOFFSET + mess->mlen;
                    if (i3 == 4) {
                        i2 = 0;
                        i3 = offset;
                        --ipopts;
                    } else {
                        cp[1] -= i3;
                    }
                    if ((cp + offset) < endp) {
                        memcpy((char *)&cp[i2], (cp + offset), (endp - cp) - offset);
                    }
                    ihdrsz -= i3;
                    MH(mess)->verlen = (IP_VER << 4) | (ihdrsz >> 2);
                    mess->mlen -= i3;

                    offset -= i3;
                }
            }
        }

        if ((i2 = (ihdrsz % 4)) != 0) {
            i3 = 4 - i2;
            cp = (unsigned char *) mess + IPOFFSET + ihdrsz;
            memcpy((char *)&cp[i3], cp, mess->mlen - ihdrsz);
            memset((char *)cp, 0, i3);
            ihdrsz += i3;
            MH(mess)->verlen = (IP_VER << 4) | (ihdrsz >> 2);
            mess->mlen += i3;
            i1 = (ihdrsz >> 2);
        }
        if ((ihdrsz > Ihdr_SZ) && (ipopts == 0)) {
            cp = (unsigned char *) mess + IPOFFSET;
            i3 = ihdrsz - Ihdr_SZ;
            memcpy((char *)&cp[Ihdr_SZ], (cp + ihdrsz), mess->mlen - ihdrsz);
            MH(mess)->verlen = (IP_VER << 4) | (Ihdr_SZ >> 2);
            mess->mlen -= i3;
            i1 = (Ihdr_SZ >> 2);
        }
    }
    if (i1 == 0) {
        us1 = conno < 0 ? mess->conno : conno;
        conp = &connblo[us1];
        if ((conp->IPOtxlen > 0) || (conp->IPOrxsrlen != 0)) {
            if (conp->IPOtxlen) {
                cp = (unsigned char *)conp->IPOtxopt;
                i1 = conp->IPOtxlen;
                us1 = 1;
            }
            else {
                cp = (unsigned char *)conp->IPOrxsropt;
                i1 = conp->IPOrxsrlen;
                us1 = 0;
            }
            MH(mess)->verlen = (IP_VER << 4) | ((Ihdr_SZ + i1) >> 2);
            memcpy((char *)mess + IPOFFSET + Ihdr_SZ, cp, i1);
            ihdrsz = Ihdr_SZ + i1;
            for (cp = (unsigned char *) mess + IPOFFSET + Ihdr_SZ;
                 cp < (unsigned char *) mess + IPOFFSET + ihdrsz; cp += offset) {
                if ((cp[0] == 0) || (cp[1] == 0))
                    break;
                offset = 1;
                if (cp[0] == 1)
                    continue;
                offset = (unsigned char) cp[1];
                if (cp[0] == 0x83 || cp[0] == 0x89) {
                    memcpy((char *) &iid.l, cp + 3, Iid_SZ);
                    if ((i1 = GetHostData(iid.l, 1, mess->netno)) >= 0) {
                        if (cp[0] == 0x83 || netconf[i1].hops <= 1)
                            mess->confix = i1;
                    } else if (cp[0] == 0x89) {
#ifdef MIB2
                        IPgroup.ipOutNoRoutes++;
#endif
                        return EHOSTUNREACH;
                    }
                    us1 = cp[1] - Iid_SZ;
                    i1 = 3;
                    while (i1 < (short) us1) {
                        memcpy((cp + i1), (cp + i1 + Iid_SZ), Iid_SZ);
                        i1 += 4;
                    }
                    memcpy((cp + i1), (char *)&mess->target, Iid_SZ);
                    memcpy((char *)&mess->target, (char *)&iid, Iid_SZ);
                    break;
                }
            }
        }
        else {
            MH(mess)->verlen = (IP_VER << 4) | (Ihdr_SZ >> 2);
        }
    }
    else if (i1 > 5) {
        ihdrsz = i1 * 4;
        for (cp = (unsigned char *) mess + IPOFFSET + Ihdr_SZ;
             cp < (unsigned char *) mess + IPOFFSET + ihdrsz; cp += offset) {

            if ((cp[0] == 0) || (cp[1] == 0))
                break;
            offset = 1;
            if (cp[0] == 1)
                continue;
            offset = (unsigned char) cp[1];

            if ((cp[0] == 0x83) ||(cp[0] == 0x89)) {
                cp[2] = 4;
                us1 = cp[1] - Iid_SZ;
                memcpy((char *)&iid, (cp + us1), Iid_SZ);
                if ((i1 = GetHostData(iid.l, 1, mess->netno)) >= 0) {
                    if (cp[0] == 0x83 || netconf[i1].hops <= 1)
                        mess->confix = i1;
                } else if (cp[0] == 0x89) {
#ifdef MIB2
                    IPgroup.ipOutNoRoutes++;
#endif
                    return EHOSTUNREACH;
                }

                memcpy((cp + us1), (char *)&mess->target, Iid_SZ);
                mess->target = iid.l;
                i1 = 3;
                while (i1 < (short) (us1 -= Iid_SZ)) {
                    memcpy((char *)&iid, (cp + us1), Iid_SZ);
                    memcpy((cp + us1), (cp + i1), Iid_SZ);
                    memcpy((cp + i1), (char *)&iid, Iid_SZ);
                    i1 += Iid_SZ;
                }
                break;
            }
        }
    }
#else
    MH(mess)->verlen = (IP_VER << 4) | (Ihdr_SZ >> 2);
#endif
    i1 = mess->mlen - IPOFFSET;
    MH(mess)->tlen = NC2(i1);

lab6:
    MH(mess)->chksum = 0;
    ihdrsz = (MH(mess)->verlen & 0xf) * 2;
    memcpy((char *) &MH(mess)->to, (char *) &mess->target, Iid_SZ);
    MH(mess)->chksum = ~Nchksum((unsigned short *) ((char *) mess + IPOFFSET),
                                ihdrsz);
    *(short *) ((char *) mess + MESSH_SZ + 12) = NC2(ET_IP);
    if (mess->mlen - IPOFFSET <= netp->maxblo) {
        if (mess->id == bFREE)
        {
            return ECONNABORTED;
        }
        return netp->protoc[0]->writE(conno, mess);
    }

#if (FRAGMENTATION & 2) == 0
    return NE_PARAM;
#else
    if ((mp = Ngetbuf()) == 0) {
#ifdef MIB2
        IPgroup.ipFragFails++;
#endif
        return NE_NOBUFS;
    }
#ifdef MIB2
    IPgroup.ipFragOKs++;
#endif
    mp->netno = mess->netno;
    mp->confix = mess->confix;
    mp->target = mess->target;
    mp->portno = mess->portno;
    ihdrsz = (MH(mess)->verlen & 0xf) * 4;
    memcpy((char *) mp + IPOFFSET - 2, (char *) mess + IPOFFSET - 2, ihdrsz + 2);
    maxdat = (netp->maxblo - ihdrsz) & ~7;
    cp = (unsigned char *) mess + IPOFFSET + ihdrsz;
    totdat = mess->mlen - IPOFFSET - ihdrsz;

    memcpy(lnk_hdr, MH(mess)->link_header, LHDRSZ);

    for (hdroff = 0x2000; totdat > 0; cp += maxdat) {
        i1 = totdat > maxdat ? maxdat : totdat;
        totdat -= i1;
        mp->mlen = i1 + ihdrsz + mess->offset;
        memcpy((char *) mp + mess->offset + ihdrsz, cp, i1);
        *(short *)((char *)mp + MESSH_SZ + 12) = NC2(ET_IP);
        if (totdat == 0) {
            hdroff &= ~0x2000;
            mess->offset = boTXDONE;
        }
        i1 += ihdrsz;
        MH(mp)->tlen = NC2(i1);
        MH(mp)->fragm = NC2(hdroff);
        hdroff += maxdat >> 3;
        MH(mp)->chksum = 0;
        MH(mp)->tservice = TOS;
        MH(mp)->chksum = ~Nchksum((unsigned short *) ((char *) mp + IPOFFSET),
                                  ihdrsz / 2);

        memcpy((char *) mp + MESSH_SZ, lnk_hdr, LHDRSZ);

#ifdef MIB2
        IPgroup.ipFragCreates++;
#endif
        i1 = netp->protoc[0]->writE(conno, mp);
        if (i1 < 0)
            break;
    }
    Nrelbuf(mp);
    return i1;
#endif
}

static int screen(MESS *mess)
{
    int i1, i2, netno, nxtlev, confix, ihdrsz, bcast;
    struct NETCONF *ownconfp, *confp;
    Iid iid, iid2;
    struct NET *netp;
    unsigned char *bp, *bp2;
#if RELAYING == 1
    unsigned long targetold;
    unsigned char netold;
    unsigned char confixold;
#ifdef IPOPTIONS
    union {
        unsigned char c[4];
        short s[2];
        long l;
    } UL1;
#endif
#endif
#if FRAGMENTATION & 1
    MESS *mp, *mp3;
    unsigned short holebelow, databelow, holeabove, dataabove, holebeyond;
    unsigned short base, length, us3;
#endif

#ifdef MIB2
    IPgroup.ipInReceives++;
#endif

    netno = mess->netno;
    netp = &nets[netno];
    i1 = NC2(MH(mess)->tlen) + IPOFFSET;
    memcpy((char *) &iid, &MH(mess)->to, Iid_SZ);

    if (mess->mlen < (unsigned int) i1)
        goto err1;
    mess->mlen = i1;
    if (MH(mess)->verlen >> 4 != IP_VER)
        goto err1;
    ihdrsz = (MH(mess)->verlen & 0xf) * 4;
    if (ihdrsz < Ihdr_SZ) {
        goto err1;
    }
    if (Nchksum((unsigned short *) ((char *) mess + IPOFFSET), ihdrsz / 2) != 0xffff)
        goto err1;
    ownconfp = &netconf[netp->confix];

    memcpy((char *) &mess->target, &MH(mess)->from, Iid_SZ);

#ifndef IPFLTR_DIS
	if( 1 != etherman_ip_fltr(mess->target) ){
		goto err1;
	}
#endif

    confix = GetHostData(mess->target, 0x17, netno);
    if (confix == -1) {
        if (mess->target)
            goto err1;
        else if (MH(mess)->prot != 17)
            goto err1;
        for (confix = 0; confix < NCONFIGS; confix++) {
            confp = &netconf[confix];
            if (confp->netno != netno)
                continue;
            if (confp->flags & (LOCALHOST + NOTUSED))
                continue;
            if (netp->sndoff == 0 || memcmp((char *) &confp->Eaddr,
                                 (char *) mess + netp->sndoff, Eid_SZ) == 0)
                goto lab6;
        }
#if DHCP == 2
        confix = GetHostData((netconf[netp->confix].Iaddr.l &
                              netconf[netp->confix].Imask.l),
                              0x17,
                              netno);
        memcpy(netconf[confix].Eaddr.c, (char *) mess + netp->sndoff, Eid_SZ);
#else
        goto err1;
#endif
    }

lab6:
    mess->confix = confix;
    confp = &netconf[confix];
    if (confp->nexthix == 255) {
        confp->nexthix = confix;
        memcpy((char *) &confp->Eaddr, (char *) mess + netp->sndoff, Eid_SZ);
        confp->hwaddyes = 2;
        confp->netno = netno;
        confp->hops = 253;
    }
    netconf[confp->nexthix].timems = TimeMS();

    bcast = mess->conno;
    if (iid.l == ownconfp->Iaddr.l) {
#if RELAYING == 1
#ifdef IPOPTIONS
        if (Ihdr_SZ < ihdrsz)
            goto checkipopt;
#endif
#endif
        goto lab8;
    }
    if (iid.l == 0xffffffff) {
        if (MH(mess)->prot == 6)
            goto err1;
        goto lab88;
    }
    i2 = (iid.c[0] & 0xc0) >> 3;
    if (i2 == 0)
        i2 = 8;
    for (i1 = 0; i1 < NNETS; i1++) {
        if (nets[i1].netstat == 0)
            continue;
        confp = &netconf[nets[i1].confix];
        iid2.l = confp->Iaddr.l;
        if (iid.l == iid2.l)
            goto lab8;
        if (iid.l == (iid2.l | ~confp->Imask.l)) {
            if (MH(mess)->prot == 6)
                goto err1;
            goto lab88;
        }
#ifdef USSW_DIRECTED_BROADCAST
        if (detectIpInfo.detectPort && 
            (MH(mess)->prot == 17) &&
            ((ntohl(iid.l) & 0xff) == 0xff)) {
            goto lab88;
        }
#endif
        if (iid.l == (iid2.l | htonl(0xffffffffUL >> i2))) {
            if (MH(mess)->prot == 6)
                goto err1;
            goto lab88;
        }
    }
#if USS_IP_MC_LEVEL == 2
    if (ussHostGroupCheck(iid, mess->netno))
        goto lab8;
#endif
    if (iid.l == 0)
        goto err1;

#if RELAYING != 1
#ifdef MIB2
    IPgroup.ipInAddrErrors++;
#endif
    goto err1;
#else
#ifdef MIB2
    if (IPgroup.ipForwarding != 1)
        goto err1;
#endif
    if (MH(mess)->time-- == 0)
        goto err1;
    if (bcast)
        goto err1;

#ifdef NAT
checkrelay:
#endif

#ifdef IPOPTIONS
checkipopt:
    for (bp = (unsigned char *) mess + IPOFFSET + Ihdr_SZ;
         bp < (unsigned char *) mess + IPOFFSET + ihdrsz; bp += i1) {
        if ((bp[0] == 0) || (bp[1] == 0))
            break;
        i1 = 1;
        if (bp[0] == 1)
            continue;
        i1 = (unsigned char) bp[1];
        if (bp[0] == 68) {
            i2 = (unsigned char) bp[2] - 1;
            if (i2 < i1) {
                if (i1 < i2 + 4)
                    goto err1;
                nxtlev = bp[3] & 0xf;
                if (nxtlev == 3) {
                    UL1.l = NC2(ownconfp->Iaddr.l);
                    if (memcmp((char *) bp + i2, (char *) ownconfp->Iaddr.c,
                               Iid_SZ) != 0)
                        continue;
                    i2 += 4;
                    bp[2] += 4;
                } else if (nxtlev == 1) {
                    memcpy((char *) bp + i2, (char *) ownconfp->Iaddr.c, Iid_SZ);
                    i2 += 4;
                    bp[2] += 4;
                }
                if (i1 < i2 + 4)
                    goto err1;
                UL1.l = TimeMS();
                PUTL((bp + i2), UL1);
                bp[2] += 4;
            } else {
                if (bp[3] >= 0xf0)
                    goto err1;
                bp[3] += 0x10;
            }
        } else if (bp[0] == 7) {
            i2 = (unsigned char) bp[2] - 1;
            if (i2 < i1) {
                if (i1 < i2 + 4)
                    goto err1;
                memcpy((char *) bp + i2, (char *) ownconfp->Iaddr.c, Iid_SZ);
                bp[2] += 4;
            }
        }
        else if (bp[0] == 0x83 || bp[0] == 0x89) {
            i2 = (unsigned char) bp[2] - 1;
            nxtlev = memcmp((char *)&iid, (char *)ownconfp->Iaddr.c, Iid_SZ);
            if ((bp[0] == 0x83) && (i2 == i1)) {
                if (nxtlev != 0)
                    goto err1;
                continue;
            }
            if (bp[0] == 0x89) {
                if (nxtlev != 0)
                    goto err1;
                if (i2 == i1)
                    continue;
            }
            if (i2 < i1) {
                if (i1 < i2 + 4)
                    goto err1;
                memcpy((char *) &iid2, bp + i2, Iid_SZ);
                if ((confix = GetHostData(iid2.l, 1, netno)) >= 0) {
                    if ((bp[0] == 0x83) || (netconf[confix].hops <= 1) ||
                        ((bp[1] < (bp[2] + 4)) && (netconf[confix].hops == 0))) {
                        for (i1=0; i1<NCONFIGS; i1++) {
                            if ((netconf[i1].netno == netconf[confix].netno) &&
                                (netconf[i1].flags & LOCALHOST)) {
                                ownconfp = &netconf[i1];
                                break;
                            }
                        }
                        memcpy((char *) bp + i2, (char *) ownconfp->Iaddr.c,
                               Iid_SZ);
                        bp[2] += 4;
                        goto relay;
                    }
                }
                if (bp[0] == 0x83) {
#ifdef MIB2
                    IPgroup.ipOutNoRoutes++;
#endif
                    if (ICMPreply(mess, 3, 5)) {
                        return -1;
                    }
                    return -4;
                }
            }
            if (bp[0] == 0x89) {
#ifdef MIB2
                IPgroup.ipOutNoRoutes++;
#endif
                if (ICMPreply(mess, 3, 5)) {
                    return -1;
                }
                return -4;
            }
        }
    }
#endif

    if ((confix = GetHostData(iid.l, 0x21, netno)) < 0) {
#ifdef MIB2
        IPgroup.ipOutNoRoutes++;
#endif
        if (ICMPreply(mess, 3, 5)) {
            return -1;
        }
        return -4;
    }
    if ((netconf[confix].flags & LOCALHOST))
        goto lab8;

relay:
    confp = &netconf[confix];

#ifdef MIB2
    IPgroup.ipForwDatagrams++;
#endif
    confixold = mess->confix;
    mess->confix = confix;

    netold = mess->netno;
#ifdef USS_PROXYARP
    if (mess->netno == confp->netno) {
        int i, j;
        struct NETCONF *confp2, *confp3;
        for (i = 0; i < NCONFIGS; i++) {
            confp2 = &netconf[i];
            if (confp2->Iaddr.l == iid.l) {
                for (j = 0; j < NCONFIGS; j++) {
                    confp3 = &netconf[j];
                    if (!strcmp(confp2->pname, confp3->pname)
                            && (confp3->flags & LOCALHOST)) {
                        mess->netno = confp3->netno;
                        break;
                    }
                }
                break;
            }
        }
    } else
#endif
        mess->netno = confp->netno;

    targetold = mess->target;
    mess->target = confp->Iaddr.l;
#if NTRACE >= 2
    Nprintf("RL %d->%d %d.%d.%d.%d\n", netno, mess->netno,
            iid.c[0], iid.c[1], iid.c[2], iid.c[3]);
#endif

#ifdef NAT
    i2 = 0;
    if ((netconf[netp->confix].flags & NATLOCAL) &&
         ussNATMapOut((unsigned char *)mess + MESSH_SZ + LHDRSZ,
                      (unsigned char *)&netconf[nets[mess->netno].confix].Iaddr,
                      mess->mlen - MESSH_SZ - LHDRSZ,
                      &i2))
    {
        mess->mlen += i2;
        goto lab5;
    }
#endif

    i2 = nets[mess->netno].maxblo;
    if (mess->mlen - IPOFFSET > i2) {
#if FRAGMENTATION & 2
        if (MH(mess)->fragm & NC2(0x4000))
#endif
        {
#ifdef MIB2
            IPgroup.ipFragFails++;
#endif
            mess->mlen   = i2;
            mess->target = targetold;
            mess->netno  = netold;
            mess->confix = confixold;
            if (ICMPreply(mess, 3, 4)) {
                return -2;
            }
            return -4;
        }
lab5:
        mess->id = bRELEASE;
        if (writE(-2, mess))
            return -2;
        return -4;
    }
#ifdef IPOPTIONS
    if (ihdrsz != Ihdr_SZ)
        goto lab5;
#endif

    if ((MH(mess)->chksum += NC2(0x0100)) < NC2(0x0100))
        MH(mess)->chksum += NC2(1);
    mess->id = bRELEASE;
    *(short *) ((char *) mess + MESSH_SZ + 12) = NC2(ET_IP);
    if (nets[mess->netno].protoc[0]->writE(-2, mess))
        return -2;
    return -4;
#endif

lab88:
    bcast = 1;
lab8:
#if RELAYING == 1
#ifdef NAT
    i2 = 0;
    if (ussNATMapIn((unsigned char *)mess + MESSH_SZ + LHDRSZ,
                    mess->mlen - MESSH_SZ - LHDRSZ,
                    &i2))
    {
        mess->mlen += i2;
        memcpy((char *)&iid, &MH(mess)->to, Iid_SZ);
        bcast = 0;
        ihdrsz = 0;
        goto checkrelay;
    }
#endif
#endif

    mess->offset = IPOFFSET + ihdrsz;

#if FRAGMENTATION & 1
    if (MH(mess)->fragm & NC2(0x3fff)) {
#ifdef MIB2
        IPgroup.ipReasmReqds++;
#endif
        length = NC2(MH(mess)->tlen);
        base = NC2(MH(mess)->fragm) << 3;
        bp2 = (unsigned char *) mess + IPOFFSET;
        if (base != 0) {
            base += ihdrsz;
            length -= ihdrsz;
            bp2 += ihdrsz;
        }
        mp3 = (MESS *) & netp->fragmq;
        nxtlev = -4;
        for (i2 = 0, mp = mp3->next; mp; i2++, mp3 = mp, mp = mp->next) {
            if (memcmp(&MH(mess)->from, &MH(mp)->from, Iid_SZ))
                continue;
            if (MH(mess)->frid == MH(mp)->frid)
                goto lab3;
        }
        if (i2 >= MAXFRAG || (long)base + length > MAXBUF - IPOFFSET) {
#ifdef MIB2
            IPgroup.ipReasmFails++;
#endif
            return -2;
        }
        mp3->next = mess;
        mess->next = 0;
        bp = (unsigned char *) mess + IPOFFSET;
        mp = mess;
        mp->mlen = holebeyond = dataabove = 0xffff;
        databelow = base;
        holeabove = base + length;
        *(unsigned short *) ((char *) mp + MESSH_SZ) = holebelow = 0;
        goto lab4;
lab3:
        nxtlev = -2;
        if ((long)base + length > MAXBUF - IPOFFSET) {
            mp3->next = mp->next;
            Nrelbuf(mp);
#ifdef MIB2
            IPgroup.ipReasmFails++;
#endif
            return -2;
        }
        bp = (unsigned char *) mp + IPOFFSET;
        holebelow = us3 = *(unsigned short *) ((char *) mp + MESSH_SZ);
        for (; us3 < base; us3 = *(unsigned short *) (bp + ((us3 + 1) & ~1)))
            holebelow = us3;
        if ((databelow = *(unsigned short *) (bp + ((holebelow + 3) & ~1))) > base)
            databelow = base;
        us3 = holebelow;
        for (; (dataabove = *(unsigned short *) (bp + ((us3 + 3) & ~1))) <= base + length;)
            us3 = *(unsigned short *) (bp + ((us3 + 1) & ~1));
        holeabove = base + length;
        if (holeabove < us3)
            holeabove = us3;
        holebeyond = *(unsigned short *) (bp + ((us3 + 1) & ~1));
lab4:
        memmove(bp + base, bp2, length);
        if (holebelow < databelow) {
            *(unsigned short *) (bp + ((holebelow + 1) & ~1)) = holeabove;
            *(unsigned short *) (bp + ((holebelow + 3) & ~1)) = databelow;
        } else
            *(unsigned short *) ((char *) mp + MESSH_SZ) = holeabove;
        *(unsigned short *) (bp + ((holeabove + 1) & ~1)) = holebeyond;
        *(unsigned short *) (bp + ((holeabove + 3) & ~1)) = dataabove;
        mp->timems = TimeMS();
        if ((MH(mess)->fragm & NC2(0x2000)) == 0)
            mp->mlen = base + length;
        if (*(unsigned short *) ((char *) mp + MESSH_SZ) < mp->mlen)
            return nxtlev;
        mp->mlen += IPOFFSET;
        mp3->next = mp->next;
        Nrelbuf(mess);
        netp->fragmh = mp;
        mess = mp;
#ifdef MIB2
        IPgroup.ipReasmOKs++;
#endif
    }
#endif

    mess->conno = IPOFFSET + 12;
    i1 = MH(mess)->prot;
    for (nxtlev = 1; P_tab[nxtlev]; nxtlev++)
        if (i1 == P_tab[nxtlev]->Eprotoc) {
#ifdef MIB2
            IPgroup.ipInDelivers++;
#endif
            i1 = P_tab[nxtlev]->screen(mess);
            if (i1 == -6 && bcast == 0) {
                i1 = -4;
                if (ICMPreply(mess, 3, 3) != 0)
                    i1 = -2;
            }
            if (i1 == -3) {
                mess->id = bRELEASE;
                i1 = -4;
                if (writE(-1, mess)) {
                    i1 = -2;
                }
            }
            return i1;
        }
#ifdef MIB2
    IPgroup.ipInUnknownProtos++;
#endif
    if (bcast == 0) {
        if (ICMPreply(mess, 3, 2) == 0) {
            return -4;
        }
    }
    return -1;

err1:
#ifdef MIB2
    IPgroup.ipInHdrErrors++;
#endif
    return -1;
}

static MESS *reaD(int conno)
{
    int i1;
    MESS *mess;
    register struct CONNECT *conp;

    (void) i1;
    conp = &connblo[conno];
    WAITFOR(conp->first || (conp->rxstat & (S_EOF + S_FATAL)), SIG_RC(conno),
            conp->rxtout, i1);
    BLOCKPREE();
    if (!conp->first)
    {
        RESUMEPREE();
        return 0;
    }
    MESS_OUT(conp, mess);
    RESUMEPREE();

#ifdef IPOPTIONS
    conp->IPOrxlen = (((*((char *) mess + IPOFFSET)) & 0xf) << 2) - Ihdr_SZ;
    memcpy(conp->IPOrxopt, (char *) mess + IPOFFSET + Ihdr_SZ, conp->IPOrxlen);
#endif
    conp->realiid.l = mess->target;
    return mess;
}

static int init(int netno, char *params)
{
    (void) netno;
    (void) params;
#ifdef MIB2
    memset(&IPgroup, 0, sizeof(IPgroup));
    IPgroup.ipForwarding = RELAYING;
    IPgroup.ipDefaultTTL = TTL;
    IPgroup.ipReasmTimeout = 64;
#endif
#ifdef NAT
    ussNATInit();
#endif
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}


GLOBALCONST PTABLE ussIPTable = {
    "IP", init, 0, screen, opeN, closE, reaD, writE, ioctl, ET_IP, Ihdr_SZ
};

