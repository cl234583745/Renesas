/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifndef __PORTANNOUNCERECEIVESMGD_H__
#define __PORTANNOUNCERECEIVESMGD_H__

#include <ptp_Macro.h>

#define	ALLOWED_STEPSREMOVED	255

typedef	enum tagPARECEIVESM_ST
{
	PARVSM_NONE = 0,
	PARVSM_DISCARD,
	PARVSM_RECEIVE,
	PARVSM_STATUS_MAX
} PARECEIVESM_ST;
#define	PARECEIVESM_ST_MAX	3

typedef enum tagPARECEIVESM_EV {
	PARV_EV_BEGIN = 0,
	PARV_EV_RCVDANNOUNCE,
	PARV_EV_CLOSE,
	PARV_EV_EVENT_MAX
} PARECEIVESM_EV;
#define	PARECEIVESM_EV_MAX	3

typedef struct tagPARECEIVESM_GD
{
	BOOL				blRcvdAnnounce;
	PARECEIVESM_ST		enStatus;
} PARECEIVESM_GD;
#endif
