//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_ETHERNET_H_
#define _USS_ETHERNET_H_


#define	ET_MINLEN 60
#define	ET_MAXLEN 1500
#define ET_TOUT 1000

struct Ehdr {
    char            message_header[MESSH_SZ];
    unsigned char   to[Eid_SZ];
    unsigned char   from[Eid_SZ];
    unsigned short  type;
};
#define Ehdr_SZ 14
#define	ET_IP      0x0800
#define	ET_ARP     0x0806
#define	ET_RARP    0x8035
#ifdef  INET6
#define ET_IP6     0x86dd
#endif
#endif
