/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYREQSENDSM_GD_H__
#define __MDDELAYREQSENDSM_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagMDDREQSNDSM_ST {
	MDDRQS_NONE = 0,
	MDDRQS_NOT_ENABLED,
	MDDRQS_WAIT_SND_DREQ,
	MDDRQS_SNT_DREQ_WAIT_FOR_TMSTMP,
	MDDRQS_STATUS_MAX

}	MDDREQSNDSM_ST;
#define	DMDDRQS_STATUS_MAX			4

typedef enum tagMDDREQSNDSM_EV {
	MDDRQS_E_BEGIN = 0,
	MDDRQS_E_RCVD_MDDELAY_REQ,
	MDDRQS_E_RCVD_MDTIMESTAMP_RCV,
	MDDRQS_E_CLOSE,
	MDDRQS_E_EVENT_MAX

}	MDDREQSNDSM_EV;
#define	DMDDRQS_E_EVENT_MAX			4

typedef struct tagMDDREQSDSM_GD
{
	MDDREQSNDSM_ST		enStsMDDReqSnd;
	
	BOOL				blRcvdMDDelayReq;
	
	BOOL				blEgMDTimestampReceive;
	TIMESTAMP			stEgMDTimestampReceive;
	USHORT				usDelayReqSequenceId;

	PTPMSG_DELAY_REQ_1588	stTxDelayReq1588;

} MDDREQSDSM_GD;

#endif
