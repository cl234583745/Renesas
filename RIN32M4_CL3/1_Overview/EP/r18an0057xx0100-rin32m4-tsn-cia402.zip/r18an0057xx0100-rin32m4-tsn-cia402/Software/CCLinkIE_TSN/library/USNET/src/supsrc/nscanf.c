//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include	<stdarg.h>

#define GETAP(ap) \
    ap = (char *) va_arg(args,char *);

static int match(char *fmt, char cc)
{
    int exc=0;
    char *cp1;

    if (!cc)
	return 0;
    if (*fmt == '^')
    {
	exc = 1;
	fmt++;
    }
    for (cp1=fmt; *cp1 && *cp1 != ']'; )
    {
	if (cp1[1] == '-' && cp1[2] > cp1[0])
	{
	    if (cc >= cp1[0] && cc <= cp1[2])
		return exc^1;
	    cp1 += 3;
	}
	else
	{
	    if (cc == *cp1)
		return exc^1;
	    cp1++;
	}
    }
    return exc;
}

static long asclng(char **cp, int width, int base)
{
    long answer;
    char cc, sign, *cp1;

    answer = sign = 0;
    for (cp1=*cp; *cp1; cp1++)
    {
	if (*cp1 > ' ')
	    break;
    }
    if (*cp1 == '-' || *cp1 == '+')
	sign = *cp1++, width--;
    if (!*cp1 || !width)
	goto exi1;
    if (!base)
    {
	base = 10;
	if (*cp1 == '0')
	{
	    base = 8;
	    goto lab4;
	}
    }
    else if (base == 16)
    {
	if (*cp1 == '0')
	{
lab4:	    cp1++, width--;
	    if (width > 0)
	    {
		if (*cp1 == 'x' || *cp1 == 'X')
		    base = 16, cp1++, width--;
	    }
	}
    }
    for ( ; width && *cp1; cp1++,width--)
    {
	if ((cc = *cp1) < '0')
	    break;
        if (cc <= '9')
	    cc &= 0xf;
        else
        {
	    cc &= 0xdf;
	    if (cc >= 'A')
	        cc -= 'A' - 10;
        }
        if (cc >= base)
	    break;
	answer = base * answer + cc;
    }
exi1:
    *cp = cp1;
    if (sign == '-')
	answer = -answer;
    return answer;
}

int Nsscanf(char *buf, char *fmt, ...)
{
    int field;
    int sizdef;
    int width;
    int par1;
    long l1;
    int nfields;
    char fch;
    char *orgbuf, *prebuf;
    char *ap;
    va_list args;

    va_start(args,fmt);
    if (!*buf)
	return -1;
    nfields = field = sizdef = 0;
    orgbuf = buf;
    while ((fch = *fmt++) != 0)
    {
	if (!field)
	{
	    if (fch == '%')
	    {
		if (*fmt != '%')
		{
		    field = 1;
		    continue;
		}
		fch = *fmt++;
	    }
	    if (fch <= ' ')
		for (; *buf== ' '||*buf=='\t'; buf++) ;
	    else if (fch == *buf)
		buf++;
	}
	else
	{
	    width = 0x7fff;
	    if (fch == '*')
	    {
		width = va_arg(args,int);
		goto lab6;
	    }
	    else if (fch >= '0' && fch <= '9')
	    {
		fmt--;
		width = asclng(&fmt,9,10);
lab6:		fch = *fmt++;
	    }
	    if (fch == 'h')
	    {
		sizdef = 1;
		goto lab7;
	    }
	    else if (fch == 'l')
	    {
		sizdef = 2;
lab7:       	fch = *fmt++;
	    }
	    prebuf = buf;
            switch (fch)
	    {
	    case 'd':
		par1 = 10;
		goto lab3;
	    case 'o':
		par1 = 8;
		goto lab3;
	    case 'x':
	    case 'X':
		par1 = 16;
		goto lab3;
	    case 'u':
	    case 'i':
		par1 = 0;
lab3:		GETAP(ap);
		l1 = asclng(&buf, width, par1);
		if (prebuf == buf)
		    break;
		if (sizdef == 2)
		    *(long *)ap = l1;
		else if (sizdef == 1)
		    *(short *)ap = l1;
		else
		    *(int *)ap = l1;
		goto lab12;
	    case 'c':
		GETAP(ap);
		for (; width && *buf; width--)
		{
		    *ap++ = *buf++;
		    if (width == 0x7fff)
			break;
		}
		goto lab12;
	    case '[':
		GETAP(ap);
		for (; width && match(fmt,*buf); width--)
		    *ap++ = *buf++;
		while (*fmt++ != ']') ;
		goto lab11;
	    case 's':
		GETAP(ap);
		for (; *buf==' '||*buf==0x07; buf++) ;
		for (; width && *buf && *buf>' '; width--)
		    *ap++ = *buf++;
lab11:		if (prebuf == buf)
		    break;
		*(char *)ap = 0;
		goto lab12;
	    case 'n':
		GETAP(ap);
		*(int *)ap = buf - orgbuf;
		break;
	    case 'p':
		GETAP(ap);
		*(long *)ap = asclng(&buf, width, 16);
lab12:		nfields++;
		break;
	    default:
		goto term;
	    }
	    field = 0;
	}
	if (!fch)
	    break;
    }
term:
    return nfields;
}

