//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include <string.h>
#include <net.h>
#include <local.h>
#include <support.h>

extern struct NET nets[];
extern struct NETCONF netconf[];


static int writE(int conno, MESS *mess)
{
    int i1, netno;
    struct NET *netp;
    MESS *mp;

    (void)conno;
    netno = mess->netno;

    if ((mp = Ngetbuf()) == 0)
        return NE_NOBUFS;
    i1 = mess->mlen;
#ifdef PPP
    if (nets[netno].protoc[0] == PPP)
        i1 += 2;
#endif
    memcpy((void *)mp, (void *)mess, i1);
    mp->netno = netno;
    mp->id = bALLOC;
    netp = &nets[netno];
    QUEUE_IN(netp, arrive, mp);
    WAITNOMORE(SIG_RN(netno));

    mess->offset = boTXDONE;
    if (mess->id <= bWACK) {
        if (mess->id == bRELEASE) {
            mess->id = bALLOC;
            Nrelbuf(mess);
        }
    }
    else
    {
        WAITNOMORE(SIG_WN(netno));
    }

    YIELD();
    YIELD();

    return 0;
}

static int opeN(int conno, int flags)
{
    (void)conno;
    (void)flags;
    return 1;
}

static int closE(int conno)
{
    (void)conno;
    return 0;
}

static int init(int netno, char *params)
{
    (void)params;
    memset((char *)&nets[netno].id, 0x76, Eid_SZ);
    return 0;
}

static void shut(int netno)
{
    (void)netno;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}


GLOBALCONST PTABLE ussWrapTable = {
    "wrap", init, shut, 0, opeN, closE, 0, writE, ioctl, 0, MESSH_SZ
};

