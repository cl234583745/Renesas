/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CSSYNC_1588_H__
#define __PTP_CSSYNC_1588_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	clockSlaveSync_1588(USHORT usEvent, CLOCKDATA*	pstClockData);

CSSYNCSM_1588_GD*		GetCSSyncSM_1588_GD(CLOCKDATA*	pstClockData);
EN_EV_CSS_1588			GetCSSyncSM_1588_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsCSSyncSM_1588_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


