//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msw_lldp.h"
#include "msw_lldp_mand.h"

static const MSW_LLDP_OPS_T mand_ops = {
    msw_mand_register,
    msw_mand_unregister,
    msw_mand_gettlv,
    NULL,
    NULL,
};

void msw_mand_register(void)
{
    MSW_LLDP_MOD_INFO_T info;

    info.id = MSW_LLDP_MOD_MAND;
    info.ops = &mand_ops;
    mswLldpModuleAdd(&info);
}

void msw_mand_unregister(void)
{
    mswLldpModuleDel(MSW_LLDP_MOD_MAND);
}

static int mand_chassis_tlv(unsigned char *outframe, unsigned short *len,
                            MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    LLDP_LOG_TRC(("mand_chassis_tlv: \n"));

    if (*len < (sizeof(header) + tlv->chassis.curlen)) {
        LLDP_LOG_ERR(("mand_chassis_tlv: Frame overflow error(len=%d curlen=%d)\n", 
            *len, tlv->chassis.curlen));
        goto out_err;
    }
    if ((tlv->chassis.curlen < (Min_SZCHASSIS_INFO + sizeof(tlv->chassis.subtype))) ||
        ((Max_SZCHASSIS_INFO + sizeof(tlv->chassis.subtype)) < tlv->chassis.curlen)) {
        LLDP_LOG_ERR(("mand_chassis_tlv: chassis curlen errror(curlen=%d)\n", 
            tlv->chassis.curlen));
        goto out_err;
    }

    CREATE_LLDP_HDR(header, TYPE_CHASSISID, tlv->chassis.curlen);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    if ((MSW_CHASSIS_SUB_MIN <= tlv->chassis.subtype) &&
        (tlv->chassis.subtype <= MSW_CHASSIS_SUB_MAX)) {
            if(tlv->chassis.id){
                memcpy(&outframe[sizeof(header)], &(tlv->chassis.subtype), sizeof(tlv->chassis.subtype));
                memcpy(&outframe[sizeof(header)+sizeof(tlv->chassis.subtype)],
                       &(tlv->chassis.id),
                       tlv->chassis.curlen - sizeof(tlv->chassis.subtype));
                *len -= tlv->chassis.curlen;
            } else {
                LLDP_LOG_ERR(("chassis id format error\n"));
                goto out_err;
            }
    } else {
        LLDP_LOG_ERR(("mand_chassis_tlv: chassis id subtype format error\n"));
        goto out_err;
    }
    
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int mand_portid_tlv(unsigned char *outframe, unsigned short *len,
                           MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    LLDP_LOG_TRC(("mand_portid_tlv: \n"));

    if (*len < (sizeof(header) + tlv->portid.curlen)) {
        LLDP_LOG_ERR(("mand_portid_tlv: Frame overflow error(len=%d curlen=%d)\n", 
            *len, tlv->portid.curlen));
        goto out_err;
    }

    if ((tlv->portid.curlen < (Min_SZPORTID_INFO + sizeof(tlv->portid.subtype))) ||
        ((Max_SZPORTID_INFO + sizeof(tlv->portid.subtype)) < tlv->portid.curlen)) {
        LLDP_LOG_ERR(("mand_portid_tlv: portid curlen errror(curlen=%d)\n", 
            tlv->portid.curlen));
        goto out_err;
    }

    CREATE_LLDP_HDR(header, TYPE_PORTID, tlv->portid.curlen);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    if ((MSW_PORTID_SUB_MIN <= tlv->portid.subtype) &&
        (tlv->portid.subtype <= MSW_PORTID_SUB_MAX)) {
        if (tlv->portid.id) {
            memcpy(&outframe[sizeof(header)], &(tlv->portid.subtype), sizeof(tlv->portid.subtype));
            memcpy(&outframe[sizeof(header)+sizeof(tlv->portid.subtype)],
                   &(tlv->portid.id),
                   tlv->portid.curlen - sizeof(tlv->portid.subtype));
            *len -= tlv->portid.curlen;
        } else {
            LLDP_LOG_ERR(("mand_portid_tlv: portid format error\n"));
            goto out_err;
        }
    } else {
        LLDP_LOG_ERR(("mand_portid_tlv: portid subtype format error\n"));
        goto out_err;
    }
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int mand_ttl_tlv(unsigned char *outframe, unsigned short *len,
                        MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    unsigned short tmpus;
    LLDP_LOG_TRC(("mand_ttl_tlv: \n"));

    if (*len < (sizeof(header) + Fix_SZTTL_INFO)) {
        LLDP_LOG_ERR(("mand_ttl_tlv: Frame overflow error\n"));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_TIMETOLIVE, Fix_SZTTL_INFO);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    tmpus = htons(tlv->ttl.ttl);
    memcpy(&outframe[sizeof(header)], &tmpus, sizeof(tmpus));
    *len -= Fix_SZTTL_INFO;
    
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

int msw_mand_gettlv(unsigned char *outframe, unsigned short *len, MSW_TLVS_T * tlv,
                   MSW_INFO_T * info, void * usrData)
{
    int ret;
    unsigned short length = *len;
    (void)info;
    (void)usrData;
    LLDP_LOG_TRC(("msw_mand_gettlv: \n"));

    ret = mand_chassis_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
        LLDP_LOG_ERR(("msw_mand_gettlv: mand_chassis_tlv fail\n"));
        goto out_err;
    }
    tlv->chassis.iscreate = 1;

    ret = mand_portid_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
        LLDP_LOG_ERR(("msw_mand_gettlv: mand_portid_tlv fail\n"));
        goto out_err;
    }
    tlv->portid.iscreate = 1;

    ret = mand_ttl_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
        LLDP_LOG_ERR(("msw_mand_gettlv: mand_ttl_tlv fail\n"));
        goto out_err;
    }
    tlv->ttl.iscreate = 1;

    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}
