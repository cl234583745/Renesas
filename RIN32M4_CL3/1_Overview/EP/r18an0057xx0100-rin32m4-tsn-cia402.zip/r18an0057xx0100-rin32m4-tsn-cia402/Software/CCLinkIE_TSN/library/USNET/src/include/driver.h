//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _USS_DRIVER_H_
#define _USS_DRIVER_H_

void IRinstall(int irno, int netno, void (*irhan) (void));
#ifndef IRrestore
void IRrestore(int irno);
#endif

#define DISABLE()   Ndisable()
#define ENABLE()    Nenable()

#define FORCE_ENABLE()	ForceNenable()
#endif
