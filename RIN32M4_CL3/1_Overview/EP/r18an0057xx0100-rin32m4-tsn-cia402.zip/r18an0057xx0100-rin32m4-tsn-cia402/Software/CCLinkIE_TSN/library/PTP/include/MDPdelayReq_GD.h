/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYREQ_GD_H__
#define __MDPDELAYREQ_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"


typedef enum tagMDPDELAYREQ_ST {
	MDPDRQ_NONE = 0,
	MDPDRQ_NOT_ENABLED,
	MDPDRQ_INITIAL_SEND_PDREQ,
	MDPDRQ_RESET,
	MDPDRQ_SEND_PDELAY_REQ,
	MDPDRQ_WAIT_FOR_PDRESP,
	MDPDRQ_WAIT_FOR_PDRESP_FOLLOWUP,
	MDPDRQ_WAIT_FOR_PDELAY_INTV_TM,
	MDPDRQ_STATUS_MAX

}	MDPDELAYREQ_ST;
#define	DMDPDRQ_STATUS_MAX			8

typedef enum tagMDPDELAYREQ_EV {
	MDPDRQ_E_BEGIN = 0,
	MDPDRQ_E_RCVD_PDRESP,
	MDPDRQ_E_RCVD_PDRESP_FOLLOWUP,
	MDPDRQ_E_RCVD_MDTIMESTAMP_RCV,
	MDPDRQ_E_PDELAY_SENDTIME,
	MDPDRQ_E_CLOSE,
	MDPDRQ_E_EVENT_MAX

}	MDPDELAYREQ_EV;
#define	DMDPDRQ_E_EVENT_MAX			6


typedef struct tagMDPDLYREQSM_STACK
{
	USCALEDNS	stIngressTimestamp;
	USCALEDNS	stCrrctEvTimestamp;
}MDPDLYREQSM_STACK;


typedef struct tagMDPDLYREQSM_STACK_MANAGE
{
	UCHAR				uchStackCount;
	UCHAR				uchCompareCount;
	UCHAR				uchMaxStackCount;
	MDPDLYREQSM_STACK	stCmptMDPdlyRatioStack[MDPDLYRATIO_STACK_N];
	UCHAR				uchStackCountSameClock;
	CLOCKIDENTITY		stStackClockIdentity;
}MDPDLYREQSM_STACK_MANAGE;

typedef	union	tagPDELAY_REQ_COM	{
	PTPMSG_PDELAY_REQ_1AS  stTxPdelayReq_1AS;
	PTPMSG_PDELAY_REQ_1588 stTxPdelayReq_1588;
}	PDELAY_REQ_COM;

typedef struct tagMDPREQSM_GD
{
	MDPDELAYREQ_ST		enStsMDPdelayReq;

	TMO_MANAGE_INF_BLK*	pstTimeOutManage;
	USCALEDNS			stPdelayIntervalTimer;

	BOOL				blRcvdPdelayResp;
	PTPMSG*				pstRcvdPdelayResp;
	TIMESTAMP			stIngMDTimestampReceive;

	BOOL				blRcvdPdelayRespFollowUp;
	PTPMSG*				pstRcvdPdelayRespFollowUp;

	PDELAY_REQ_COM		stTxPdelayReq;
	USHORT				usSentPdelayReqSequenceId;
	BOOL				blEgMDTimestampReceive;
	TIMESTAMP			stEgMDTimestampReceive;
	USHORT				usPdelayReqSequenceId;

	BOOL				blInitPdelayRespReceived;
	USHORT				usLostResponses;
	BOOL				blNeighborRateRatioValid;
	USHORT				usDelectedFaults;
	MDPDLYREQSM_STACK_MANAGE	*pstPdelayAveCalc;






} MDPREQSM_GD;

#endif
