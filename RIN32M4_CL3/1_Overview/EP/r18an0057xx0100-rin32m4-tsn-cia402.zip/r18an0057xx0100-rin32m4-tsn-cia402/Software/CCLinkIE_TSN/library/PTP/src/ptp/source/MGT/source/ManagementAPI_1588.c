/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ManagementSM.h"
#include "ManagementAPI_1588.h"

INT ManagementAPI_1588( UCHAR  uchAction, 
						USHORT usParamId_1588, 
						UCHAR  uchDomainNumber, 
						USHORT usPortNumber, 
						UCHAR* puchInfo, 
						USHORT usInfoSize )
{
	CLOCKDATA*	pstClock_DT	= NULL;
	PORTDATA*	pstPort_DT		= NULL;
	USHORT		usTblIndex	= 0;
	USHORT		usSize		= 0;
	BOOL		blRet		= FALSE;
	ENUM_CLOCKSUPPORTTYPE_1588	enClockSupporType;
	INT			nRet		= RET_ENOERR;

	pstClock_DT = GetMGTClockData( uchDomainNumber );
	if (pstClock_DT == NULL)
	{
		return RET_ESTATE;
	}
	if (pstClock_DT->stClock_GD.enSupportPTPType != ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
		return RET_ESTATE;
	}
	if (uchAction > MGT1588_ACTION_MAX)
	{
		return RET_EINVAL;
	}
	if (usParamId_1588 > MID_1588_MAX)
	{
		return RET_EINVAL;
	}
	if ((puchInfo == NULL) && (usInfoSize != 0))
	{
		return RET_EINVAL;
	}
	pstPort_DT  = GetMGTPortData(pstClock_DT, usPortNumber);
	enClockSupporType = pstClock_DT->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588;
	blRet = GetManagement1588ParamId(enClockSupporType, usParamId_1588, &usTblIndex, &usSize);
	if ((blRet == FALSE) || (usInfoSize < usSize))
	{
		return RET_EINVAL;
	}

	nRet = ManagementSM_1588_API(uchAction, usTblIndex, pstClock_DT, pstPort_DT, puchInfo, usInfoSize);
	return nRet;
}
