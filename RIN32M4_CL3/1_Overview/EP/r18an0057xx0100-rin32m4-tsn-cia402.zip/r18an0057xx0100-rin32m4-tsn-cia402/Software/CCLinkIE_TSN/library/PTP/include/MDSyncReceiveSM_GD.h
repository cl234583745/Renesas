/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCRECEIVESM_GD_H__
#define __MDSYNCRECEIVESM_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

#include "ptp_LCEntity_GD.h"


typedef enum tagMDSYNCRCVSM_ST {
	MDSYCR_NONE = 0,
	MDSYCR_DISCARD,
	MDSYCR_WAITING_FOR_FOLLOW_UP,
	MDSYCR_WAITING_FOR_SYNC,
	MDSYCR_STATUS_MAX

}	MDSYNCRCVSM_ST;
#define	DMDSYCR_STATUS_MAX			4

typedef enum tagMDSYNCRCVSM_EV {
	MDSYCR_E_BEGIN = 0,
	MDSYCR_E_FOR_MDSYN_RCV_RCVDSYNC,
	MDSYCR_E_RCVDFOLLOWUP,
	MDSYCR_E_FOLLOWUPRECEIPTTIMEOUT,
	MDSYCR_E_CLOSE,
	MDSYCR_E_EVENT_MAX

}	MDSYNCRCVSM_EV;
#define	DMDSYCR_E_EVENT_MAX			5

typedef struct tagMDSYNCRCVSM_STACK
{
	USCALEDNS	stIngressTimestamp;
	USCALEDNS	stCrrctEvTimestamp;

}	MDSYNCRCVSM_STACK;

typedef struct tagMDSRECEIVESM_GD
{
	MDSYNCRCVSM_ST		enStsMDSyncReceive;
	
	TMO_MANAGE_INF_BLK*	pstTimeOutManage;
	USCALEDNS			stFollowUpReceiptTimoutTime;
	
	BOOL				blRcvdSync;
	PTPMSG*				pstRcvdSync;
	TIMESTAMP			stIngMDTimestampReceive;

#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stIngMDTimestampReceive_Frun;
#endif

	TIMESTAMP			stSyncIngTimestamp;

#ifdef	PTP_USE_ME_HW_ASSIST
	TIMESTAMP			stSyncIngTimestamp_Frun;
#endif

	BOOL				blRcvdFollowUp;
	PTPMSG*				pstRcvdFollowUp;

	MDSYNCRCVSM_STACK	stCmptMDSyncRatioStack[MDSYCR_STACK_N];
	UCHAR				uchStackCount;
	UCHAR				uchCompareCount;
	UCHAR				uchMaxStackCount;
	DOUBLE				dbCmptRatio;
} MDSRECEIVESM_GD;

#endif
