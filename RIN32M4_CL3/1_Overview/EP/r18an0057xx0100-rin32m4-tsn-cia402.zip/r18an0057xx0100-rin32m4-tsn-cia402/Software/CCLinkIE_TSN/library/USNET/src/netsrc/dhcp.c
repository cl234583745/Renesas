//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "socket.h"
#include "dhcp.h"
#include "icmp.h"



extern struct NETCONF netconf[];
extern struct CONNECT connblo[];
extern struct NET nets[];
#ifdef MIB2
extern struct IPgroup IPgroup;
#endif
#ifdef DNS
extern Iid      DNSiid[2];
extern char     DNSdomain[];
#endif

char            DHCPbootfile[FILENAMESIZE];



int             DHCPget(int netno, unsigned long lease)
{
    int             i1,
                    i2,
                    renew,
                    retry,
                    stat,
                    oplen,
                    len,
                    confix,
                    cs,
                    icmpsock,
                    rc,
                    clilen;
    unsigned long   ul1 = 0,
                    initime,
                    alltime,
                    xid,
                    inidelay,
                    delay;
    unsigned char   uc1,
                   *cp;
    struct NETCONF *confp,
                   *confp2;
    struct NET     *netp;
    Iid             iid;
    struct DHCPstr  DHCPrec,
                    bootsend;
    struct ICMPhdr  echoreq;
    struct sockaddr_in
                    clisock,
                    socki;
    struct timeval  timeout;
    fd_set          client_set;
    union {
        unsigned char   c[4];
        short           s[2];
        long            l;
    }               UL2;
    const struct Eid ezero = {0,0,0,0,0,0};
#ifdef OLD_STYLE
    int            sendlen;
#endif

    renew = retry = 0;
    DHCPbootfile[0] = 0;
    netp = &nets[netno];
    confp = &netconf[netp->confix];

    for (uc1 = stat = 0, xid = 0; stat < Eid_SZ; stat++) {
        uc1 += confp->Eaddr.c[stat];
        xid += (confp->Eaddr.c[stat] * stat);
    }
    inidelay = (unsigned int) uc1 << 4;
    if (inidelay == 0)
        inidelay = 1;

    xid *= xid;

restart:
    initime = TimeMS();
    if (netp->DHCPserver) {
        if ((long) (initime - netp->RenewalTime) < 0) {
            stat = 0;
            netp->DHCPsecs = (netp->RenewalTime - initime) / 1000;
            goto ret8;
        }
        else if ((long) (initime - netp->RebindingTime) < 0) {
            renew = 1;
            netp->RenewalTime = 0;
        }
        else if ((long) (initime - netp->LeaseTime) <= 0) {
            renew = 1;
            netp->DHCPserver = 0xffffffff;
            netp->RenewalTime = 0;
            netp->RebindingTime = 0;
        }
        else {
#if NTRACE >= 1
            Nprintf("DHCP %d address expired\n", netno);
#endif
            netp->RenewalTime   = 0;
            netp->RebindingTime = 0;
            netp->DHCPserver    = 0;
            confp->Iaddr.l      = 0;
            stat = ETIMEDOUT;
            goto ret8;
        }
    }
restart2:
    cs = socket(AF_INET, SOCK_DGRAM, 0);
    if (cs < 0) {
#if NTRACE > 0
        Nprintf("Error opening DHCP socket\n");
#endif
        stat = cs;
        goto ret7;
    }
    memset(&clisock, 0, sizeof(clisock));

    clisock.sin_family = AF_INET;
    clisock.sin_port = htons(CLIENT_PORT);
    clisock.sin_addr.s_addr = htonl(INADDR_ANY);
    stat = bind(cs, (struct sockaddr *) &clisock, sizeof(clisock));
    if (stat < 0) {
#if NTRACE > 0
        Nprintf("Error in DHCP socket bind\n");
#endif
        goto ret7;
    }
    clisock.sin_port = htons(SERVER_PORT);

    if ((renew == 0) || (netp->RebindingTime == 0)) {
        stat= setsockopt(cs, SOL_SOCKET, SO_BROADCAST, 0, 0);
        clisock.sin_addr.s_addr = 0xffffffff;
    }
    else
        clisock.sin_addr.s_addr = netp->DHCPserver;


    setsockopt(cs, SOL_SOCKET, SO_BINDTODEVICE, confp->pname,
               strlen(confp->pname));

    timeout.tv_sec =  1;
    timeout.tv_usec = 0;

    memset(&bootsend, 0, sizeof(struct DHCPstr));
    bootsend.op = 1;
    bootsend.htype = 1;
    bootsend.hlen = sizeof(struct Eid);
    bootsend.xid = xid++;
    bootsend.flags = NC2(0x8000);
    memcpy((char *) &bootsend.ciaddr, (char *) &confp->Iaddr, Iid_SZ);
    memcpy((char *) bootsend.chaddr, (char *) &confp->Eaddr, Eid_SZ);
    memcpy((char *) bootsend.options, discopts, sizeof(discopts));
    len = sizeof(discopts);
#ifdef OLD_STYLE
    sendlen = 63;
#endif
    cp = bootsend.options + len;
    if (lease) {
        *cp++ = 51;
        *cp++ = 4;
        UL2.l = lease;
        PUTLONG_BYTE(UL2, cp);
        cp += 4;
        len += 6;
    }
    if (renew) {
        goto renewaddress;
    }
    if (confp->Iaddr.l) {
        *cp++ = 50;
        *cp++ = 4;
        memcpy((char *)cp, confp->Iaddr.c, 4);
        cp += 4;
        len += 6;
    }
    *cp = 255;
    for (delay = inidelay; delay < MAXDELAY; delay <<= 1) {
        for (ul1 = TimeMS(); TimeMS() - ul1 < delay;)
            YIELD();
        bootsend.secs = (TimeMS() - initime) / 1000;
        clilen = sizeof(clisock);
#ifdef OLD_STYLE
        sendto(cs, (char *) &bootsend, DHCPsz + sendlen + 1, 0,
                       (struct sockaddr *)&clisock, clilen, NULL);
#else
        sendto(cs, (char *) &bootsend, DHCPsz + len + 1, 0,
                       (struct sockaddr *)&clisock, clilen, NULL);
#endif
        YIELD();
read3:  FD_ZERO(&client_set);
        FD_SET(cs, &client_set);
        rc = selectsocket(cs+1, &client_set, 0, 0, &timeout);
        if (rc > 0) {
           stat = recvfrom(cs, (char *) &DHCPrec, sizeof(struct DHCPstr), 0,
                         (struct sockaddr *) &clisock, &clilen, NULL);
            if (stat > DHCPsz) {
                if (DHCPrec.xid != bootsend.xid)
                    goto read3;
                if (DHCPrec.op != 2)
                    goto read3;
                goto lab2;
            }
        }
        else {
            FD_CLR(cs, &client_set);
            stat = ETIMEDOUT;
        }
    }
    goto ret7;

lab2:
    InitOption;
    i1 = 0;
    while ((cp = NextOption(&DHCPrec)) != 0) {
        i2 = cp[0];
        if (i2 == 53)  {
            if (cp[2] == DHCPOFFER)
                i1 = 1;
        }
        if (i2 == 54) {
            i2 = cp[1] + 2;
            memcpy((char *) bootsend.options + len, cp, i2);
            len += i2;
        }
    }
    if (i1 == 0)
        goto read3;

renewaddress:
    bootsend.options[6] = DHCPREQUEST;
    if (!renew) {
        cp = bootsend.options + len;
        *cp++ = 50;
        *cp++ = 4;
        memcpy((char *) cp, (char *) &DHCPrec.yiaddr, 4);
        cp += 4;
        len += 6;
    }
    bootsend.options[len] = 255;
    bootsend.xid = xid++;
    if (renew) {
        bootsend.flags = 0;
    }
    else {
        bootsend.flags = NC2(0x8000);
    }
    for (delay = inidelay; delay < MAXDELAY; delay <<= 1) {
        for (ul1 = TimeMS(); TimeMS() - ul1 < delay;)
            YIELD();
        alltime = TimeMS();
        if (renew) {
            bootsend.secs = (TimeMS() - initime) / 1000;
        }
        else {
            clisock.sin_addr.s_addr = 0xffffffff;
        }
#ifdef OLD_STYLE
        stat = sendto(cs, (char *) &bootsend, DHCPsz + sendlen + 1, 0,
                       (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#else
        stat = sendto(cs, (char *) &bootsend, DHCPsz + len + 1, 0,
                       (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#endif
        YIELD();
read4:  FD_ZERO(&client_set);
        FD_SET(cs, &client_set);
        rc = selectsocket(cs+1, &client_set, 0, 0, &timeout);
        if (rc > 0) {
            stat = recvfrom(cs, (char *) &DHCPrec, sizeof(struct DHCPstr), 0,
                         (struct sockaddr *) &clisock, &clilen, NULL);
            if (stat > DHCPsz) {
                if (DHCPrec.xid != bootsend.xid)
                    goto read4;
                if (DHCPrec.op != 2)
                    goto read4;
                InitOption;
                while ((cp = NextOption(&DHCPrec)) != 0) {
                    if (cp[0] == 53) {
                        if (cp[2] == DHCPACK)
                            goto lab4;
                        if (cp[2] == DHCPNAK) {
                            renew = 0;
                            confp->Iaddr.l = 0;
                            goto waitstart;
                        }
                    }
                }
            }
        }
        else {
            FD_CLR(cs, &client_set);
            stat = ETIMEDOUT;
        }
    }
waitstart:
    if (retry++ > 5) {
        stat = -1;
        goto ret7;
    }
    closesocket(cs);
    for (ul1 = TimeMS(); TimeMS() - ul1 < 10000;)
        YIELD();
    if (!renew)
        goto restart2;
    renew = 0;
    goto restart;

lab4:


#ifdef ARP
    if (netp->sndoff && DHCPrec.yiaddr != confp->Iaddr.l) {
        confp->Iaddr.l = 0;
        if (confp->Imask.l == 0) {
            confp->Imask.c[0] = 0xff, confp->Imask.c[1] = 0xff;
            confp->Imask.c[2] = 0xff, confp->Imask.c[3] = 0x00;
        }
        confix = GetHostData((DHCPrec.yiaddr & confp->Imask.l), 0x17, netno);
        confp2 = &netconf[confix];
        confp2->Imask.l = confp->Imask.l;
        confp2->netno = confp->netno;
        confp2->hops = 0;
        icmpsock = socket(AF_INET, SOCK_DGRAM, ICMP);
        if (icmpsock < 0) {
#if NTRACE > 0
            Nprintf("Error creating socket for DHCP address probe\n");
#endif
            stat = icmpsock;
            goto ret7;
        }
        memset(&socki, 0, sizeof(socki));
        socki.sin_family = AF_INET;
        socki.sin_addr.s_addr = DHCPrec.yiaddr;
        echoreq.type = IC_ECHO;
        echoreq.scode = 0;
        echoreq.chksum = 0;
        rc = sendto(icmpsock, (char *)&echoreq, 64+8, 0,
                    (struct sockaddr *)&socki, sizeof(socki), NULL);
        confp2->ncstat = 0;
        if (rc <= 0) {
            closesocket(icmpsock);
            goto lab5;
        }
        else {
            bootsend.options[6] = DHCPDECLINE;
            if (renew) {
                cp = bootsend.options + len;
                *cp++ = 50;
                *cp++ = 4;
                memcpy((char *) cp, (char *) &DHCPrec.yiaddr, 4);
                cp += 4;
                len += 6;
            }
            bootsend.options[len] = 255;
            bootsend.xid = xid++;
            bootsend.ciaddr = 0;
            clisock.sin_addr.s_addr = 0xffffffff;
#ifdef OLD_STYLE
            sendto(cs, (char *) &bootsend, DHCPsz + sendlen + 1, 0,
                       (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#else
            sendto(cs, (char *) &bootsend, DHCPsz + len + 1, 0,
                       (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#endif
            closesocket(icmpsock);
            goto waitstart;
        }
    }
#endif


lab5:
    memcpy( (char *) confp->Iaddr.c, (char *) &DHCPrec.yiaddr, Iid_SZ);


    InitOption;
    while ((cp = NextOption(&DHCPrec)) != 0) {
        oplen = cp[1];
        switch (*cp) {
        default:
#if NTRACE >= 3
            Nprintf("DHCP unsupported option %d\n", *cp);
#endif
            break;
        case 1:
            memcpy((char *) confp->Imask.c, cp + 2, Iid_SZ);
            break;
        case 2:
            break;
        case 3:
            memcpy((char *) iid.c, cp + 2, 4);
            for (i1 = 0; i1 < NCONFIGS; i1++) {
                confp2 = &netconf[i1];
                if ((confp2->flags & ROUTER) && (confp2->netno == netno)
                    && (confp2->hops == 1) && (confp2->ncstat)) {
                    confp2->Iaddr.l = iid.l;
                    confp2->Imask.l = confp->Imask.l;
                    break;
                }
            }
#if DHCP_CONFIG == 2
            if ((i1 == NCONFIGS) || (iid.l == 0)) {
                stat = EDHCPROUTER;
            }
#endif
            break;
        case 4:
            break;
        case 6:
#ifdef DNS
            i1 = ((oplen >= 8) ? 8 : 4);
            memcpy((char *) DNSiid[0].c, cp + 2, i1);
#endif
            break;
        case 9:
            break;
        case 12:
            if (confp->name[0])
                break;
            for (i1 = 2; i1 < oplen; i1++) {
                if (i1 == sizeof(confp->name) - 1)
                    break;
                if (cp[i1] == '@')
                    break;
                confp->name[i1] = cp[i1];
            }
            confp->name[i1] = 0;
            break;
#ifdef DNS
        case 15:
            memcpy(DNSdomain, cp + 2, oplen);
            DNSdomain[oplen] = 0;
            break;
#endif
        case 18:
            if (oplen < sizeof(DHCPbootfile)) {
                memcpy(DHCPbootfile, cp + 2, oplen);
                DHCPbootfile[oplen] = 0;
            }
            break;
        case 19:
#if RELAYING == 1
#ifdef MIB2
            if (*(cp + 2) == 0)
                IPgroup.ipForwarding = 2;
            else
                IPgroup.ipForwarding = 1;
#endif
#endif
            break;
        case 51:
            cp += 2;
            GETLONG_BYTE(UL2, cp);
            ul1 = (unsigned long)UL2.l;
            netp->LeaseTime = TIMEINMS(ul1, alltime);
            if (netp->RenewalTime == 0) {
                netp->DHCPsecs = ul1;
                netp->RenewalTime = TIMEINMS((ul1 / 2), alltime);
            }
            if (netp->RebindingTime == 0) {
                netp->RebindingTime = TIMEINMS(((ul1 * 7) / 8), alltime);
            }
            break;
        case 53:
            break;
        case 54:
            memcpy((char *) &DHCPrec.siaddr, cp + 2, Iid_SZ);
            netp->DHCPserver = DHCPrec.siaddr;
            break;
        case 58:
            cp += 2;
            GETLONG_BYTE(UL2, cp);
            ul1 = (unsigned long)UL2.l;
            netp->DHCPsecs = ul1;
            netp->RenewalTime = TIMEINMS(ul1, alltime);
            break;
        case 59:
            cp += 2;
            GETLONG_BYTE(UL2, cp);
            ul1 = (unsigned long)UL2.l;
            netp->RebindingTime = TIMEINMS(ul1, alltime);
            break;
        }
    }

    if ((DHCPrec.htype & 1) == 0 && DHCPrec.file[0])
        memcpy(DHCPbootfile, (char *) DHCPrec.file, sizeof(DHCPbootfile));

    if (confp->Iaddr.l == 0)
        stat = -1;
    else {
        confix = GetHostData(netp->DHCPserver, 2, netno);
        if (confix >= 0) {
            confp2 = &netconf[confix];
            if ((confp2->hops == 253) &&
                ((confp->Iaddr.l & confp->Imask.l) == (confp2->Iaddr.l & confp->Imask.l))) {
                confp2->hops    = confp->hops;
                confp2->nlstat  = confp->nlstat;
                confp2->Imask.l = confp->Imask.l;
            }
        }
    }

    for (i1 = 0; i1 < NCONFIGS; i1++) {
        confp2 = &netconf[i1];
        if (confp2->Iaddr.l == DHCPrec.yiaddr) {
            if (memcmp((char *) confp2->Eaddr.c, (char *) &ezero, 6) == 0) {
                confp2->Iaddr.l = 0;
                confp2->ncstat = 0;
                confp2->hops = 0;
                confp2->Imask.l = 0;
                confp2->gnid = 0;
            }
        }
    }

ret7:
#if NTRACE >= 1
    if (stat > 0 || stat == EDHCPROUTER) {
        Nprintf("DHCP %d %d.%d.%d.%d for %lu sec\n", netno,
                confp->Iaddr.c[0], confp->Iaddr.c[1],
                confp->Iaddr.c[2], confp->Iaddr.c[3], ul1);
        if (stat == EDHCPROUTER) {
            Nprintf("DHCP router install failed on interface: %d\n", netno);
        }
    }
    else {
        Nprintf("DHCP failed on interface %d\n", netno);
    }
#endif

    closesocket(cs);
ret8:
    return stat;
}


int             DHCPrelease(int netno)
{
    int             stat,
                    len,
                    cs;
    unsigned char  *cp;
    struct NETCONF *confp;
    struct DHCPstr bootsend;
    struct NET     *netp;
    struct sockaddr_in
                    clisock;
#ifdef OLD_STYLE
    int            sendlen;
#endif


    netp = &nets[netno];
    if (netp->DHCPserver == 0)
        return 0;
    confp = &netconf[nets[netno].confix];

    cs = socket(AF_INET, SOCK_DGRAM, 0);
    if (cs < 0) {
#if NTRACE > 0
        Nprintf("Error opening DHCP socket\n");
#endif
        stat = cs;
        goto ret8;
    }
    stat= setsockopt(cs, SOL_SOCKET, SO_BROADCAST, 0, 0);
    setsockopt(cs, SOL_SOCKET, SO_BINDTODEVICE, confp->pname,
               strlen(confp->pname));

    clisock.sin_family = AF_INET;
    clisock.sin_addr.s_addr = htonl(INADDR_ANY);
    clisock.sin_port = htons(CLIENT_PORT);
    stat = bind(cs, (struct sockaddr *) &clisock, sizeof(clisock));
    if (stat < 0) {
#if NTRACE > 0
        Nprintf("Error in DHCP socket bind\n");
#endif
        closesocket(cs);
        goto ret8;
    }

    clisock.sin_port = htons(SERVER_PORT);

    memset(&bootsend, 0, sizeof(struct DHCPstr));
    bootsend.op = 1;
    bootsend.htype = 1;
    bootsend.hlen = sizeof(struct Eid);
    bootsend.xid = TimeMS();
    memcpy((char *) &bootsend.ciaddr, (char *) &confp->Iaddr, Iid_SZ);
    memcpy((char *) bootsend.chaddr, (char *) &confp->Eaddr, Eid_SZ);
    memcpy((char *) bootsend.options, releopts, sizeof(releopts));
    len = sizeof(releopts);
    cp = bootsend.options + len;
    *cp++ = 54;
    *cp++ = 4;
    memcpy((char *) cp, (char *) &netp->DHCPserver, Iid_SZ);
    len += 6;
    cp += 4;
    *cp++ = 255;
    clisock.sin_addr.s_addr = 0xffffffff;
#ifdef OLD_STYLE
    sendlen = 63;
    sendto(cs, (char *) &bootsend, DHCPsz + sendlen + 1, 0,
                 (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#else
    sendto(cs, (char *) &bootsend, DHCPsz + len + 1, 0,
                 (struct sockaddr *)&clisock, sizeof(clisock), NULL);
#endif
    closesocket(cs);
    stat = 0;

    confp->Iaddr.l = 0;

    netp->DHCPserver = 0;

    netp->RenewalTime = 0;

    netp->RebindingTime = 0;

ret8:
    return stat;
}


short DHCPfirst;
short DHCPadv;

unsigned char *NextOption(struct DHCPstr * DHCPp)
{
    unsigned char   *cp;
    int             i1;

    if (DHCPfirst == 0) {
        if (DHCPp->op & 1 || DHCPp->op & 2)
            DHCPadv = 44;
        else {
#if NTRACE > 0
        Nprintf("Message type not BOOTREQUEST or BOOTREPLY\n");
#endif
            return 0;
        }
    }
    cp = (unsigned char *) DHCPp + DHCPadv;

    if (DHCPfirst == 0) {
        DHCPfirst++;
        for (i1 = 0; i1 < 3; i1++) {
            if ((cp[0] == 99) && (cp[1] == 130) && (cp[2] == 83)
                   && (cp[3] == 99)) {
                cp += 4;
                break;
            }
            else {
                cp += 64;
                if (i1)
                    cp += 64;
            }
        }
        DHCPadv = cp - (unsigned char *)DHCPp;
    }

    if (cp[0] != 255) {
        DHCPadv += (cp[1] + 2);
        if (cp[0] == 52) {
#if NTRACE > 0
            Nprintf("DHCP server: option overload not allowed\n");
#endif
        }
    }
    else
        return 0;
    return cp;
}
