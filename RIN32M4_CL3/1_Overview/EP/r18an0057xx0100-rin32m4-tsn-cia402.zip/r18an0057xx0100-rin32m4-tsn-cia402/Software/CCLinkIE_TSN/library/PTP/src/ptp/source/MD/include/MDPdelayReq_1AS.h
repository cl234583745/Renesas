/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYREQ_1AS_H__
#define __MDPDELAYREQ_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDPdelayReq_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID MDPdelayReq_00_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_01_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_02_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_03_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_04_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_05_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_06_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_07_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_08_1AS(PORTDATA* pstPort);
VOID MDPdelayReq_NP_1AS(PORTDATA* pstPort);

BOOL MDPdlyReq_NotEnable_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_IntSndPDReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_Reset_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_SndPDReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_WtFrPDResp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_WtFrPDRpFollowUp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_WtFrPDlyInterval_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDPdelayResp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL ConMDPdelayRespFollowUp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL JugMDPdlyReq_PDResp_1AS(MDPREQSM_GD* pstSmGbl);
BOOL JugMDPdlyReq_PDRespFollowUp_1AS(MDPREQSM_GD* pstSmGbl);

VOID SetMDPdlyReqMgIngresTmstmp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetMDPdlyRespMgEgresTmstmp_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetPdelayReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayReq_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL computeMDPdelayRateRatio_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetCmptMDPdlyRatioStack_1AS( MDPDLYREQSM_STACK_MANAGE*	pstPdlyIntStackMan, 
								  PORTDATA*                 pstPort );
BOOL CalMDPdlyRateRatio_1AS( MDPDLYREQSM_STACK_MANAGE*	pstPdlyIntStackMan, 
							 PORTDATA*                  pstPort, 
							 DOUBLE*                    dbRateRatio );
VOID updateAsCapable( PORTDATA* pstPortData );


BOOL computeMDPdelayPropTime_1AS(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
