/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_SSSYNC_1AS_H__
#define __PTP_SSSYNC_1AS_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif

VOID	siteSyncSync_1AS(USHORT usEvent, CLOCKDATA*	pstClockData);

SSSYNCSM_1AS_GD*		GetSSSyncSM_1AS_GD(CLOCKDATA*	pstClockData);
EN_EV_SSS				GetSSSyncSM_1AS_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsSSSyncSM_1AS_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


