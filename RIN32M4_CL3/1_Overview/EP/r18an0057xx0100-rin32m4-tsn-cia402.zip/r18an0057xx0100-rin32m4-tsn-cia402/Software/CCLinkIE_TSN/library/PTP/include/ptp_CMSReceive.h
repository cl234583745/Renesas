/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSRECEIVE_H__
#define __PTP_CMSRECEIVE_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	clockMasterSyncReceive(USHORT usEvent, CLOCKDATA*	pstClockData);
VOID	ptp_GetMasterTime(CLOCKDATA*	pstClockData, EXTENDEDTIMESTAMP*	pstMasterTime);
VOID	ptp_SetMasterTime(CLOCKDATA*	pstClockData, EXTENDEDTIMESTAMP*	pstMasterTime);
VOID	ptp_GetLocalTime(CLOCKDATA*	pstClockData, USCALEDNS*	pstLocalTime);
VOID	ptp_SetLocalTime(CLOCKDATA*	pstClockData, USCALEDNS*	pstLocalTime);

CMSRECEIVESM_GD*		GetCMSReceiveSM_GD(CLOCKDATA*	pstClockData);
EN_EV_CMSR				GetCMSReceiveSM_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsCMSReceiveSM_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


