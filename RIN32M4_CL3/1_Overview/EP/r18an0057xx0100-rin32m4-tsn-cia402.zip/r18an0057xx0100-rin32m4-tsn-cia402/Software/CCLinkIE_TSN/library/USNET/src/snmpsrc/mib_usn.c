//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================


#include "net.h"
#include "local.h"
#include "support.h"
#include "snmpv3.h"


extern const int confsiz;
extern unsigned char cqfirst, cqlast;
extern PTABLE ussUDPTable;
extern struct ifgroup ifgroup;
extern struct IPgroup IPgroup;
extern struct ICMPgroup ICMPgroup;
extern struct UDPgroup UDPgroup;

extern uint32 sysStartTime;



static const MIBVAR mibvar_if[] =
{
    {{8,{0x2b,6,1,2,1,2,1,0}}, 0,  Integer, sizeof(int), &ifgroup.ifNumber},
    {{9,{0x2b,6,1,2,1,2,2,1,1}}, SX,  Integer, 1, 0},
    {{9,{0x2b,6,1,2,1,2,2,1,2}}, 0,  String, 0, &nets[0].ifDescr},
    {{9,{0x2b,6,1,2,1,2,2,1,3}}, 0,  Integer, sizeof(int), &nets[0].ifType},
    {{9,{0x2b,6,1,2,1,2,2,1,4}}, 0,  Integer, sizeof(int), &nets[0].maxblo},
    {{9,{0x2b,6,1,2,1,2,2,1,5}}, 0,  Gauge, sizeof(long), &nets[0].bps},
    {{9,{0x2b,6,1,2,1,2,2,1,6}}, 0,  OctetString, Eid_SZ, &nets[0].id},
    {{9,{0x2b,6,1,2,1,2,2,1,7}}, W,  Integer, sizeof(int), &nets[0].ifAdminStatus},
    {{9,{0x2b,6,1,2,1,2,2,1,8}}, IMMED,  Integer, 1, 0},
    {{9,{0x2b,6,1,2,1,2,2,1,9}}, CAR+SCALAR,  Ticks, 4, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,2,2,1,10}}, 0,  Counter, sizeof(int), &nets[0].ifInOctets},
    {{9,{0x2b,6,1,2,1,2,2,1,11}}, 0,  Counter, sizeof(int),
        &nets[0].ifInUcastPkts},
    {{9,{0x2b,6,1,2,1,2,2,1,12}}, 0,  Counter, sizeof(int),
        &nets[0].ifInNUcastPkts},
    {{9,{0x2b,6,1,2,1,2,2,1,13}}, 0,  Counter, sizeof(int), &nets[0].ifInDiscards},
    {{9,{0x2b,6,1,2,1,2,2,1,14}}, 0,  Counter, sizeof(int), &nets[0].ifInErrors},
    {{9,{0x2b,6,1,2,1,2,2,1,15}}, 0,  Counter, sizeof(int),
        &nets[0].ifInUnknownProtos},
    {{9,{0x2b,6,1,2,1,2,2,1,16}}, 0,  Counter, sizeof(int), &nets[0].ifOutOctets},
    {{9,{0x2b,6,1,2,1,2,2,1,17}}, 0,  Counter, sizeof(int),
        &nets[0].ifOutUcastPkts},
    {{9,{0x2b,6,1,2,1,2,2,1,18}}, 0,  Counter, sizeof(int),
        &nets[0].ifOutNUcastPkts},
    {{9,{0x2b,6,1,2,1,2,2,1,19}}, 0,  Counter, sizeof(int),
        &nets[0].ifOutDiscards},
    {{9,{0x2b,6,1,2,1,2,2,1,20}}, 0,  Counter, sizeof(int), &nets[0].ifOutErrors},
    {{9,{0x2b,6,1,2,1,2,2,1,21}}, CAR+SCALAR,  Gauge, 4, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,2,2,1,22}}, CAR+SCALAR,  Identifier, 2, &snmp_uint16},
};

static sint16 mibvarsize_if(void)
{
    return sizeof(mibvar_if) / sizeof(MIBVAR);
}

#define XifIndex 1

static const MIBTAB mibtab_if[] =
{
    {{7,{0x2b,6,1,2,1,2,2}}, 1, {XifIndex,0,0,0}, sizeof(struct NET)},
};

static sint16 mibtabsize_if(void)
{
    return sizeof(mibtab_if) / sizeof(MIBTAB);
}

static void mibget_if(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    if (varix == 9)
    {
        *(uint32 *)*vvptr = nets[tabix].ifLastChange;
        if (*(uint32 *)*vvptr > sysStartTime)
            *(uint32 *)*vvptr -= sysStartTime;
        else
            *(uint32 *)*vvptr = 0;
    }
    else if (varix == 21)
    {
        *(uint32 *)*vvptr = (nets[tabix].depart[0].mtail -
                     nets[tabix].depart[0].mhead) & 15;
    }
    else if (varix == 22)
    {
        *(uint16 *)*vvptr = 0;
    }
}

static sint16 mibindex_if(sint16 varix, sint16 tabix)
{
    uint16 us1;
    uint8 *cp;

    cp = (uint8 *)mibvar_if[varix].oid.name + 5;
    us1 = *cp++ << 8;
    us1 += *cp;

    if (us1 == 0x0202)
    {
        if (tabix >= NNETS)
            return -1;
        if (nets[tabix].netstat)
            return 1;
    }
    return 0;
}

static sint16 mibcheck_if(sint16 varix, sint16 tabix, const uint8 *inp)
{
    uint32 ul1 = 0;
    sint16 i1;

    (void)tabix;

    if (varix == 7)
    {
        i1 = snmpReadInt(&ul1, sizeof(ul1), &inp, mibvar_if[varix].type);
        if (i1 < 0 || ul1 == 0 || ul1 > 3)
            return wrongValue;
    }
    return 0;
}

const MIB mib_if =
{
    mibvar_if,
    mibvarsize_if,
    mibtab_if,
    mibtabsize_if,
    mibget_if,
    0,
    mibindex_if,
    0,
    mibcheck_if
};



static const MIBVAR mibvar_at[] =
{
    {{9,{0x2b,6,1,2,1,3,1,1,1}}, W+BASE1,  Integer, sizeof(netconf[0].netno), &netconf[0].netno},

    {{9,{0x2b,6,1,2,1,3,1,1,2}}, W, OctetString, Eid_SZ, &netconf[0].Eaddr},

    {{9,{0x2b,6,1,2,1,3,1,1,3}}, W|CHOICE, IpAddress, Iid_SZ, &netconf[0].Iaddr},
};

static sint16 mibvarsize_at(void)
{
    return sizeof(mibvar_at) / sizeof(MIBVAR);
}

#define XatIfIndex 0
#define XatNetAddress 2

static const MIBTAB mibtab_at[] =
{
    {{7,{0x2b,6,1,2,1,3,1}}, 2, {XatIfIndex,XatNetAddress,0,0}, sizeof(struct NETCONF)},
};

static sint16 mibtabsize_at(void)
{
    return sizeof(mibtab_at) / sizeof(MIBTAB);
}

static sint16 mibindex_at(sint16 varix, sint16 tabix)
{
    uint16 us1;
    uint8 *cp;

    cp = (uint8 *)mibvar_at[varix].oid.name + 5;
    us1 = *cp++ << 8;
    us1 += *cp;

    if (us1 == 0x0301)
    {
        if (tabix >= NCONFIGS)
            return -1;
        if (netconf[tabix].ncstat)
            for (us1 = 0; us1 < Eid_SZ; us1++)
                if (netconf[tabix].Eaddr.c[us1])
                    return 1;
        return 0;
    }
    return 1;
}

const MIB mib_at =
{
    mibvar_at,
    mibvarsize_at,
    mibtab_at,
    mibtabsize_at,
    0,
    0,
    mibindex_at,
    0
};




static const MIBVAR mibvar_ip[] =
{
    {{8,{0x2b,6,1,2,1,4,1,0}}, W,  Integer, sizeof(int), &IPgroup.ipForwarding},
    {{8,{0x2b,6,1,2,1,4,2,0}}, W,  Integer, sizeof(int), &IPgroup.ipDefaultTTL},
    {{8,{0x2b,6,1,2,1,4,3,0}}, 0,  Counter, sizeof(long), &IPgroup.ipInReceives},
    {{8,{0x2b,6,1,2,1,4,4,0}}, 0,  Counter, sizeof(long), &IPgroup.ipInHdrErrors},
    {{8,{0x2b,6,1,2,1,4,5,0}}, 0,  Counter, sizeof(long), &IPgroup.ipInAddrErrors},

    {{8,{0x2b,6,1,2,1,4,6,0}}, 0,  Counter, sizeof(long),
        &IPgroup.ipForwDatagrams},
    {{8,{0x2b,6,1,2,1,4,7,0}}, 0,  Counter, sizeof(long),
        &IPgroup.ipInUnknownProtos},
    {{8,{0x2b,6,1,2,1,4,8,0}}, 0,  Counter, sizeof(long), &IPgroup.ipInDiscards},
    {{8,{0x2b,6,1,2,1,4,9,0}}, 0,  Counter, sizeof(long), &IPgroup.ipInDelivers},
    {{8,{0x2b,6,1,2,1,4,10,0}}, 0,  Counter, sizeof(long), &IPgroup.ipOutRequests},

    {{8,{0x2b,6,1,2,1,4,11,0}}, 0,  Counter, sizeof(long), &IPgroup.ipOutDiscards},
    {{8,{0x2b,6,1,2,1,4,12,0}}, 0,  Counter, sizeof(long), &IPgroup.ipOutNoRoutes},
    {{8,{0x2b,6,1,2,1,4,13,0}}, 0,  Integer, sizeof(int), &IPgroup.ipReasmTimeout},
    {{8,{0x2b,6,1,2,1,4,14,0}}, 0,  Counter, sizeof(long), &IPgroup.ipReasmReqds},
    {{8,{0x2b,6,1,2,1,4,15,0}}, 0,  Counter, sizeof(long), &IPgroup.ipReasmOKs},

    {{8,{0x2b,6,1,2,1,4,16,0}}, 0,  Counter, sizeof(long), &IPgroup.ipReasmFails},
    {{8,{0x2b,6,1,2,1,4,17,0}}, 0,  Counter, sizeof(long), &IPgroup.ipFragOKs},
    {{8,{0x2b,6,1,2,1,4,18,0}}, 0,  Counter, sizeof(long), &IPgroup.ipFragFails},
    {{8,{0x2b,6,1,2,1,4,19,0}}, 0,  Counter, sizeof(long), &IPgroup.ipFragCreates},
    {{9,{0x2b,6,1,2,1,4,20,1,1}}, 0,  IpAddress, Iid_SZ, &netconf[0].Iaddr},

    {{9,{0x2b,6,1,2,1,4,20,1,2}}, BASE1,  Integer, sizeof(netconf[0].netno),
        &netconf[0].netno},
    {{9,{0x2b,6,1,2,1,4,20,1,3}}, 0,  IpAddress, Iid_SZ, &netconf[0].Imask},
    {{9,{0x2b,6,1,2,1,4,20,1,4}}, IMMED,  Integer, 1, 0},
    {{9,{0x2b,6,1,2,1,4,20,1,5}}, CAR+SCALAR, Integer, 4, &snmp_uint32},

    {{9,{0x2b,6,1,2,1,4,21,1,1}}, W, IpAddress, Iid_SZ, &netconf[0].Iaddr},
    {{9,{0x2b,6,1,2,1,4,21,1,2}}, W+BASE1, Integer, sizeof(netconf[0].netno),
        &netconf[0].netno},
    {{9,{0x2b,6,1,2,1,4,21,1,3}}, W, Integer, 1, &netconf[0].hops},
    {{9,{0x2b,6,1,2,1,4,21,1,4}}, IMMED, Integer, 255, 0},
    {{9,{0x2b,6,1,2,1,4,21,1,5}}, IMMED, Integer, 255, 0},
    {{9,{0x2b,6,1,2,1,4,21,1,6}}, IMMED, Integer, 255, 0},

    {{9,{0x2b,6,1,2,1,4,21,1,7}}, CAR+W+SCALAR,  IpAddress, Iid_SZ, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,4,21,1,8}}, IMMED, Integer, 3, 0},
    {{9,{0x2b,6,1,2,1,4,21,1,9}}, IMMED, Integer, 2, 0},
    {{9,{0x2b,6,1,2,1,4,21,1,10}}, CAR+SCALAR, Integer, 4, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,4,21,1,11}}, W, IpAddress, Iid_SZ, &netconf[0].Imask},
    {{9,{0x2b,6,1,2,1,4,21,1,12}}, IMMED, Integer, 255, 0},
    {{9,{0x2b,6,1,2,1,4,21,1,13}}, CAR+SCALAR, Identifier, 2, &snmp_uint16},
    {{9,{0x2b,6,1,2,1,4,22,1,1}}, W+BASE1, Integer, sizeof(netconf[0].netno),
        &netconf[0].netno},
    {{9,{0x2b,6,1,2,1,4,22,1,2}}, W, OctetString, Eid_SZ, &netconf[0].Eaddr},
    {{9,{0x2b,6,1,2,1,4,22,1,3}}, W, IpAddress, Iid_SZ, &netconf[0].Iaddr},

    {{9,{0x2b,6,1,2,1,4,22,1,4}}, CAR+W+SCALAR,  Integer, 1, &snmp_sint8},
    {{8,{0x2b,6,1,2,1,4,23,0}},  0, Counter, sizeof(long),
        &IPgroup.ipRoutingDiscards},
};

static sint16 mibvarsize_ip(void)
{
    return sizeof(mibvar_ip) / sizeof(MIBVAR);
}

#define XipAdEntAddr 19
#define XipRouteDest 24
#define XipNetToMediaIfIndex 37
#define XipNetToMediaNetAddress 39

static const MIBTAB mibtab_ip[] =
{
    {{7,{0x2b,6,1,2,1,4,20}}, 1, {XipAdEntAddr,0,0,0}, sizeof(struct NETCONF)},
    {{7,{0x2b,6,1,2,1,4,21}}, 1, {XipRouteDest,0,0,0}, sizeof(struct NETCONF)},
    {{7,{0x2b,6,1,2,1,4,22}}, 2, {XipNetToMediaIfIndex,XipNetToMediaNetAddress,0,0},
        sizeof(struct NETCONF)},
};

static sint16 mibtabsize_ip(void)
{
    return sizeof(mibtab_ip) / sizeof(MIBTAB);
}

static void mibget_ip(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    switch (varix)
    {
    case 23:
        *(uint32 *)*vvptr = (uint32)nets[netconf[tabix].netno].maxblo;
        break;
    case 30:
        if (netconf[tabix].nexthix == 255)
            *(uint32 *)*vvptr = 0;
        else
            *(uint32 *)*vvptr = (uint32)netconf[tabix].Iaddr.l;
        break;
    case 33:
        *(uint32 *)*vvptr = 0;
        break;
    case 36:
        *(uint16 *)*vvptr = 0;
        break;
    case 40:
        **vvptr = (uint8)netconf[tabix].ncstat;
        break;
    default:
        break;
    }
}

static sint16 mibset_ip(sint16 varix, sint16 tabix)
{
    struct NETCONF *confp;
    sint16 errcode;

    errcode = 0;

    if (tabix < 0)
        errcode = inconsistentValue;
    else if (varix == 40)
    {
        confp = &netconf[tabix];
        if (snmp_sint8 == 3)
        {
            if (confp->ncstat != 3)
            {
                BLOCKPREE();
                confp->cqnext = cqfirst;
                confp->cqprev = cqlast;
                netconf[cqlast].cqnext = netconf[cqfirst].cqprev = tabix;
                cqlast = tabix;
                confp->ncstat = 3;
                RESUMEPREE();
            }
        }
        else if (snmp_sint8 == 4)
        {
            if (confp->ncstat != 4)
            {
                BLOCKPREE();
                if (cqfirst == tabix)
                    cqfirst = confp->cqnext;
                if (cqlast == tabix)
                    cqlast = confp->cqprev;
                netconf[confp->cqprev].cqnext = confp->cqnext;
                netconf[confp->cqnext].cqprev = confp->cqprev;
                confp->ncstat = 4;
                RESUMEPREE();
            }
        }
        else
            errcode = wrongValue;
    }

    return errcode;
}

static sint16 mibindex_ip(sint16 varix, sint16 tabix)
{
    uint8 *cp;
    uint16 us1;
    sint16 i1;

    cp = (uint8 *)mibvar_ip[varix].oid.name + 5;
    us1 = *cp++ << 8;
    us1 += *cp;

    switch (us1)
    {
    case 0x0416:
        if (tabix >= NCONFIGS)
            goto lab7;
        if (netconf[tabix].ncstat == 0)
            break;
        for (i1 = 0; i1 < Eid_SZ; i1++)
            if (netconf[tabix].Eaddr.c[i1])
                goto lab5;
        break;
    case 0x0414:
        if (tabix >= confsiz)
            goto lab7;
        if (netconf[tabix].flags & LOCALHOST)
            goto lab5;
        break;
    case 0x0415:
        if (tabix >= NCONFIGS)
            goto lab7;
        if (netconf[tabix].ncstat == 0)
            break;
        if (!(netconf[tabix].flags & LOCALHOST))
            goto lab5;
        break;
    default:
        goto lab5;
    }
    return 0;
lab5:
    return 1;
lab7:
    return -1;
}

static sint16 mibcheck_ip(sint16 varix, sint16 tabix, const uint8 *inp)
{
    uint32 ul1 = 0;
    sint16 i1;

    (void)tabix;

    if (varix == 0)
    {
        i1 = snmpReadInt(&ul1, sizeof(ul1), &inp, mibvar_ip[varix].type);
        if (i1 < 0 || ul1 < 1 || ul1 > 2)
            return wrongValue;
    }
    return 0;
}

const MIB mib_ip =
{
    mibvar_ip,
    mibvarsize_ip,
    mibtab_ip,
    mibtabsize_ip,
    mibget_ip,
    mibset_ip,
    mibindex_ip,
    0,
    mibcheck_ip
};




static const MIBVAR mibvar_icmp[] =
{
    {{8,{0x2b,6,1,2,1,5,1,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmpInMsgs},
    {{8,{0x2b,6,1,2,1,5,2,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmpInErrors},
    {{8,{0x2b,6,1,2,1,5,3,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[3]},
    {{8,{0x2b,6,1,2,1,5,4,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[11]},
    {{8,{0x2b,6,1,2,1,5,5,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[12]},
    {{8,{0x2b,6,1,2,1,5,6,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[4]},
    {{8,{0x2b,6,1,2,1,5,7,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[5]},
    {{8,{0x2b,6,1,2,1,5,8,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[8]},
    {{8,{0x2b,6,1,2,1,5,9,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[0]},
    {{8,{0x2b,6,1,2,1,5,10,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[13]},
    {{8,{0x2b,6,1,2,1,5,11,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[14]},
    {{8,{0x2b,6,1,2,1,5,12,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[17]},
    {{8,{0x2b,6,1,2,1,5,13,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmprx[18]},
    {{8,{0x2b,6,1,2,1,5,14,0}},  0, Counter, sizeof(long), &ICMPgroup.icmpOutMsgs},
    {{8,{0x2b,6,1,2,1,5,15,0}}, 0,  Counter, sizeof(long),
        &ICMPgroup.icmpOutErrors},
    {{8,{0x2b,6,1,2,1,5,16,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[3]},
    {{8,{0x2b,6,1,2,1,5,17,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[11]},
    {{8,{0x2b,6,1,2,1,5,18,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[12]},
    {{8,{0x2b,6,1,2,1,5,19,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[4]},
    {{8,{0x2b,6,1,2,1,5,20,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[5]},
    {{8,{0x2b,6,1,2,1,5,21,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[8]},
    {{8,{0x2b,6,1,2,1,5,22,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[0]},
    {{8,{0x2b,6,1,2,1,5,23,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[13]},
    {{8,{0x2b,6,1,2,1,5,24,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[14]},
    {{8,{0x2b,6,1,2,1,5,25,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[17]},
    {{8,{0x2b,6,1,2,1,5,26,0}}, 0,  Counter, sizeof(long), &ICMPgroup.icmptx[18]},
};

static sint16 mibvarsize_icmp(void)
{
    return sizeof(mibvar_icmp) / sizeof(MIBVAR);
}

const MIB mib_icmp =
{
    mibvar_icmp,
    mibvarsize_icmp,
    0,
    0,
    0,
    0,
    0,
    0,
    0
};



#ifdef TCP

extern PTABLE ussTCPTable;
extern struct TCPgroup TCPgroup;

static const MIBVAR mibvar_tcp[] =
{
    {{8,{0x2b,6,1,2,1,6,1,0}}, IMMED, Integer, 4, 0},
    {{8,{0x2b,6,1,2,1,6,2,0}}, IMMED, Integer, 100, 0},
    {{8,{0x2b,6,1,2,1,6,3,0}}, 0, Integer, sizeof(unsigned long), &TCPgroup.tcpRtoMax},
    {{8,{0x2b,6,1,2,1,6,4,0}}, IMMED, Integer, NCONNS, 0},
    {{8,{0x2b,6,1,2,1,6,5,0}}, 0, Counter, sizeof(long),
        &TCPgroup.tcpActiveOpens},

    {{8,{0x2b,6,1,2,1,6,6,0}}, 0, Counter, sizeof(long),
        &TCPgroup.tcpPassiveOpens},
    {{8,{0x2b,6,1,2,1,6,7,0}}, 0, Counter, sizeof(long),
        &TCPgroup.tcpAttemptFails},
    {{8,{0x2b,6,1,2,1,6,8,0}}, 0, Counter, sizeof(long),
        &TCPgroup.tcpEstabResets},
    {{8,{0x2b,6,1,2,1,6,9,0}}, 0, Gauge, sizeof(long), &TCPgroup.tcpCurrEstab},
    {{8,{0x2b,6,1,2,1,6,10,0}}, 0, Counter, sizeof(long), &TCPgroup.tcpInSegs},

    {{8,{0x2b,6,1,2,1,6,11,0}}, 0, Counter, sizeof(long), &TCPgroup.tcpOutSegs},
    {{8,{0x2b,6,1,2,1,6,12,0}}, 0, Counter, sizeof(long),
        &TCPgroup.tcpRetransSegs},
    {{9,{0x2b,6,1,2,1,6,13,1,1}}, CAR+W+SCALAR, Integer, 1, &snmp_sint8},
    {{9,{0x2b,6,1,2,1,6,13,1,2}}, CAR+SCALAR, IpAddress, Iid_SZ, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,6,13,1,3}}, CAR+NWORDER, Integer, sizeof(connblo[0].myport),
        &connblo[0].myport},

    {{9,{0x2b,6,1,2,1,6,13,1,4}}, 0, IpAddress, Iid_SZ, &connblo[0].heriid},
    {{9,{0x2b,6,1,2,1,6,13,1,5}}, CAR+NWORDER, Integer, sizeof(connblo[0].herport),
        &connblo[0].herport},
    {{8,{0x2b,6,1,2,1,6,14,0}}, 0, Counter, sizeof(long), &TCPgroup.tcpInErrs},
    {{8,{0x2b,6,1,2,1,6,15,0}}, 0, Counter, sizeof(long), &TCPgroup.tcpOutRsts},
};

static sint16 mibvarsize_tcp(void)
{
    return sizeof(mibvar_tcp) / sizeof(MIBVAR);
}

#define XtcpConnLocalAddress 13
#define XtcpConnLocalPort 14
#define XtcpConnRemAddress 15
#define XtcpConnRemPort 16

static const MIBTAB mibtab_tcp[] =
{
    {{7,{0x2b,6,1,2,1,6,13}}, 4, {XtcpConnLocalAddress,XtcpConnLocalPort,
        XtcpConnRemAddress,XtcpConnRemPort}, sizeof(struct CONNECT)},
};

static sint16 mibtabsize_tcp(void)
{
    return sizeof(mibtab_tcp) / sizeof(MIBTAB);
}

static const uint8 statetab[] =
{
    1, 5, 6, 7, 8, 11, 9, 10, 3, 4, 1, 1, 1, 1, 1, 1, 2
};

static void mibget_tcp(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    if (varix == 12)
        if (connblo[tabix].state >= (char)sizeof(statetab))
            **vvptr = 0;
        else
            **vvptr = (uint8)statetab[connblo[tabix].state];
    else if (varix == XtcpConnLocalAddress)
        if (connblo[tabix].state == 1)
            *(uint32 *)*vvptr = (SOCKET_OWNIPADDR(tabix)).l;
        else
            *(uint32 *)*vvptr = 0;
#ifdef LITTLE
    else if (varix == XtcpConnLocalPort && sizeof(connblo[0].myport) == 4) {
        snmp_uint32 = (uint32)connblo[tabix].myport;
        snmp_uint32 <<= 16;
        *vvptr = (uint8 *)&snmp_uint32;
    }
    else if (varix == XtcpConnRemPort && sizeof(connblo[0].herport) == 4) {
        snmp_uint32 = (uint32)connblo[tabix].herport;
        snmp_uint32 <<= 16;
        *vvptr = (uint8 *)&snmp_uint32;
    }
#endif
}

static sint16 mibset_tcp(sint16 varix, sint16 tabix)
{
    struct NETCONF *confp;
    sint16 errcode;

    errcode = 0;

    if (tabix < 0)
        errcode = inconsistentValue;
    else if (varix == 12)
    {
        if (snmp_uint8 == 12)
        {
            connblo[tabix].rxstat |= S_FATAL;
            WAITNOMORE(SIG_RC(tabix));
            WAITNOMORE(SIG_CC(tabix));
        }
        else
            errcode = wrongValue;
    }

    return errcode;
}

static sint16 mibindex_tcp(sint16 varix, sint16 tabix)
{
    int i2;
    uint16 us1;
    uint8 *cp;

    cp = (uint8 *)mibvar_tcp[varix].oid.name + 5;
    us1 = *cp++ << 8;
    us1 += *cp;

    switch (us1)
    {
    case 0x060d:
        if (tabix >= NCONNS)
            goto lab7;
        if (connblo[tabix].blockstat &&
            connblo[tabix].protoc[0] == &ussTCPTable)
            goto lab5;
        break;
    default:
        goto lab5;
    }
    return 0;
lab5:
    return 1;
lab7:
    return -1;
}

static sint16 mibcheck_tcp(sint16 varix, sint16 tabix, const uint8 *inp)
{
    uint32 ul1 = 0;
    sint16 i1;

    (void)tabix;

    if (varix == 12)
    {
        i1 = snmpReadInt(&ul1, sizeof(ul1), &inp, mibvar_tcp[varix].type);
        if (i1 < 0 || ul1 == 0 || ul1 > 11)
            return wrongValue;
    }
    return 0;
}

const MIB mib_tcp =
{
    mibvar_tcp,
    mibvarsize_tcp,
    mibtab_tcp,
    mibtabsize_tcp,
    mibget_tcp,
    mibset_tcp,
    mibindex_tcp,
    0,
    mibcheck_tcp
};

#endif



static const MIBVAR mibvar_udp[] =
{
    {{8,{0x2b,6,1,2,1,7,1,0}}, 0, Counter, sizeof(long), &UDPgroup.udpInDatagrams},
    {{8,{0x2b,6,1,2,1,7,2,0}}, 0, Counter, sizeof(long), &UDPgroup.udpNoPorts},
    {{8,{0x2b,6,1,2,1,7,3,0}}, 0, Counter, sizeof(long), &UDPgroup.udpInErrors},
    {{8,{0x2b,6,1,2,1,7,4,0}}, 0, Counter, sizeof(long), &UDPgroup.udpOutDatagrams},
    {{9,{0x2b,6,1,2,1,7,5,1,1}}, CAR+SCALAR, IpAddress, Iid_SZ, &snmp_uint32},
    {{9,{0x2b,6,1,2,1,7,5,1,2}}, CAR+NWORDER, Integer, sizeof(connblo[0].myport),
        &connblo[0].myport},
};

static sint16 mibvarsize_udp(void)
{
    return sizeof(mibvar_udp) / sizeof(MIBVAR);
}

#define XudpLocalAddress 4
#define XudpLocalPort 5

static const MIBTAB mibtab_udp[] =
{
    {{7,{0x2b,6,1,2,1,7,5}}, 2, {XudpLocalAddress,XudpLocalPort,0,0},
        sizeof(struct CONNECT)}
};

static sint16 mibtabsize_udp(void)
{
    return sizeof(mibtab_udp) / sizeof(MIBTAB);
}

static void mibget_udp(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    if (varix == XudpLocalAddress)
        if (connblo[tabix].state == 1)
            *(uint32 *)*vvptr = (SOCKET_OWNIPADDR(tabix)).l;
        else
            *(uint32 *)*vvptr = 0;
#ifdef LITTLE
    else if (varix == XudpLocalPort && sizeof(connblo[0].myport) == 4) {
        snmp_uint32 = (uint32)connblo[tabix].myport;
        snmp_uint32 <<= 16;
        *vvptr = (uint8 *)&snmp_uint32;
    }
#endif
}

static sint16 mibindex_udp(sint16 varix, sint16 tabix)
{
    int i2;
    uint16 us1;
    uint8 *cp;

    cp = (uint8 *)mibvar_udp[varix].oid.name + 5;
    us1 = *cp++ << 8;
    us1 += *cp;

    switch (us1)
    {
    case 0x0705:
        if (tabix >= NCONNS)
            goto lab7;
        if (connblo[tabix].blockstat &&
            connblo[tabix].protoc[0] == &ussUDPTable)
            goto lab5;
        break;
    default:
        goto lab5;
    }
    return 0;
lab5:
    return 1;
lab7:
    return -1;
}

const MIB mib_udp =
{
    mibvar_udp,
    mibvarsize_udp,
    mibtab_udp,
    mibtabsize_udp,
    mibget_udp,
    0,
    mibindex_udp,
    0,
    0
};

