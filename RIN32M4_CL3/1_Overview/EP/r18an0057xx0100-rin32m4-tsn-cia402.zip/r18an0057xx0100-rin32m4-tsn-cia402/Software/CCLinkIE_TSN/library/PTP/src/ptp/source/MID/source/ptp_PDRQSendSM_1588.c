/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayReqReceiveSM.h"
#include "MDDelayReqReceiveSM_1588.h"
#include "MDDelayReqSendSM.h"
#include "MDDelayReqSendSM_1588.h"
#include "MDDelayRespSendSM.h"
#include "MDDelayRespSendSM_1588.h"
#include "ptp_CDSend_1588.h"
#include "ptp_PDRQSend_1588.h"

#define D_FUNC	0


VOID	PDRQSend_1588_00(PORTDATA*	pstPortData);
VOID	PDRQSend_1588_01(PORTDATA*	pstPortData);
VOID	PDRQSend_1588_02(PORTDATA*	pstPortData);
MDDELAYREQ*	setMDDelayReq(MDDELAYREQ*	pstRcvdMDDRQSendPtr);
VOID  txMDDelayReq(MDDELAYREQ*	pstTxMDDRQSendPtr, PORTDATA*	pstPortData);





VOID (*const pfnPDRQSendMatrix[ST_PDRQS_MAX][EV_PDRQS_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PDRQSend_1588_01, &PDRQSend_1588_01, &PDRQSend_1588_00},
	{&PDRQSend_1588_01, &PDRQSend_1588_02, &PDRQSend_1588_00},
	{&PDRQSend_1588_01, &PDRQSend_1588_02, &PDRQSend_1588_00}
};



VOID	 portDelayReqSend_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRQS	enEvt = EV_PDRQS_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("PDRQSendSM_1588   Evt=%d Sts=%d\n", usEvent, pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQSendSM_1588_GD.enStatusPDRQS);
}
#endif
		enEvt = GetPDRQSendSM_1588_Event(usEvent, pstPortData);

		blSts = IsPDRQSendSM_1588_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PDRQS_EVENT_MAX))
		{
			(*pfnPDRQSendMatrix[pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQSendSM_1588_GD.enStatusPDRQS][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PDRQSENDSM_1588, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQSendSM_1588_GD.blRcvdMDDelayReq	= FALSE;
		}

	}
}



PDRQSENDSM_1588_GD*	GetPDRQSendSM_1588_GD(
	PORTDATA*		pstPortData)
{
	PDRQSENDSM_1588_GD*	pstPDRQSGlb = &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRQSendSM_1588_GD);
	return pstPDRQSGlb;
}




EN_EV_PDRQS	GetPDRQSendSM_1588_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRQS			enEvt				= EV_PDRQS_EVENT_MAX;
	PDRQSENDSM_1588_GD*	pstPDRQSGlb		= GetPDRQSendSM_1588_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PDRQS_BEGIN;
			break;

		case PTP_EV_FOR_PDLRQSND_RCVMDDLRQ:
			if ((pstPDRQSGlb->blRcvdMDDelayReq) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PDRQS_BEGIN;
			}
			else if (pstPDRQSGlb->enStatusPDRQS == ST_PDRQS_TRANSMIT_INIT)
			{
				if ((pstPDRQSGlb->blRcvdMDDelayReq) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PDRQS_FOR_PDLRQSND_RCVMDDLRQ;
				}
			}
			else if (pstPDRQSGlb->enStatusPDRQS == ST_PDRQS_SEND_MD_DELAYREQ)
			{
				if ((pstPDRQSGlb->blRcvdMDDelayReq) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PDRQS_FOR_PDLRQSND_RCVMDDLRQ;
				}
			}
			else
			{
			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PDRQS_CLOSE;
			break;

		default:
			enEvt = EV_PDRQS_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsPDRQSendSM_1588_Status(
	PORTDATA*	pstPortData)
{
	PDRQSENDSM_1588_GD*	pstPDRQSGlb = GetPDRQSendSM_1588_GD(pstPortData);
	BOOL				blRet			= FALSE;

	if (pstPDRQSGlb->enStatusPDRQS < ST_PDRQS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}






VOID	PDRQSend_1588_00(
	PORTDATA*		pstPortData)
{
	PDRQSENDSM_1588_GD*	pstPDRQSGlb = GetPDRQSendSM_1588_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PDRQSend_1588_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPDRQSGlb->blRcvdMDDelayReq	= FALSE;
	pstPDRQSGlb->enStatusPDRQS		= ST_PDRQS_NONE;

	ptp_dbg_msg( D_FUNC, ("PDRQSend_1588_00::-\n") );
}




VOID	PDRQSend_1588_01(
	PORTDATA*		pstPortData)
{
	PDRQSENDSM_1588_GD*	pstPDRQSGlb = GetPDRQSendSM_1588_GD(pstPortData);

	pstPDRQSGlb->blRcvdMDDelayReq	= FALSE;
	pstPDRQSGlb->enStatusPDRQS		= ST_PDRQS_TRANSMIT_INIT;
}




VOID	PDRQSend_1588_02(
	PORTDATA*		pstPortData)
{
	PDRQSENDSM_1588_GD*	pstPDRQSGlb			= GetPDRQSendSM_1588_GD(pstPortData);
	MDDELAYREQ*			pstRcvdMDDReqRcvPtr = NULL;
	MDDELAYREQ*			pstTxMDDRQSendPtr	= NULL;


	pstRcvdMDDReqRcvPtr = &(pstPortData->stPort_GD.stMdDelayReqSnd);
	pstPDRQSGlb->blRcvdMDDelayReq = FALSE;
	pstPDRQSGlb->pstTxMDDReqSndPtr = pstRcvdMDDReqRcvPtr;

	pstTxMDDRQSendPtr = setMDDelayReq(pstRcvdMDDReqRcvPtr);

	txMDDelayReq(pstTxMDDRQSendPtr, pstPortData);

	pstPDRQSGlb->enStatusPDRQS	= ST_PDRQS_SEND_MD_DELAYREQ;

}




MDDELAYREQ*	setMDDelayReq(
	MDDELAYREQ*	pstRcvdMDDRQSendPtr)
{
	MDDELAYREQ*		pstTxMDDRQSendPtr = NULL;


	pstTxMDDRQSendPtr = pstRcvdMDDRQSendPtr;

	return pstTxMDDRQSendPtr;
}




VOID  txMDDelayReq(
	MDDELAYREQ*		pstTxMDDRQSendPtr,
	PORTDATA*		pstPortData)
{
	USHORT			usEvent				= PTP_EV_BASE;
	MDDREQSDSM_GD*	pstMDDREQSDSM_GD	= &(pstPortData->stMDDReqSndSM_GD);


	pstMDDREQSDSM_GD->blRcvdMDDelayReq	= TRUE;

	usEvent = PTP_EV_FOR_MDDLRQSND_RCVDDLRQ;
	MDDelayReqSendSM(usEvent, pstPortData);

}



#endif

