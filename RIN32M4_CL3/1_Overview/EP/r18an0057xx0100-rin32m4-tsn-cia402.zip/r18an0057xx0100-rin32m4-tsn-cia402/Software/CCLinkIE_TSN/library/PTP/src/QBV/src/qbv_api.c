/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
 

 
#include "qbv_api.h"
#include "qbv_StateMachine.h"
#include "qbv_global.h"
#include "ptp_tsn_Wrapper.h"
#include "tcpwrap_Proto.h"


GATE_PARATBL				gGateParTbl[MAX_PORT];
QBV_INFTBL					gQbvInfTbl;
TRACLS_ENTRY				gTraEntryMem[MAX_TRACLS_ENTRY];
struct tagTRACLS_ENTRY* 	gpTraEntryRecPtr0;
struct tagTRACLS_ENTRY* 	gpTraEntryRecPtr[MAX_PORT][MAX_TRAFFIC_CLASS];
VOID*						gpLockHandle;

INT qbv_init(USHORT usMaxPort)
{

	USHORT usLoop = 0;
	INT nLoop = 0;

	if (gQbvInfTbl.ulMagicNo == INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if ( (usMaxPort < (USHORT)START_PORT_NO) || (usMaxPort > (USHORT)MAX_PORT) ) {
		return (INT)RET_EINVAL;
	}
		
	gQbvInfTbl.ulMagicNo = INIT_MASIC_NO;
	gQbvInfTbl.usMaxPort = usMaxPort;

	for (usLoop = 0; usLoop < usMaxPort; usLoop++) {
		tsn_Wrapper_MemSet(&gGateParTbl[usLoop], (INT)0, sizeof(GATE_PARATBL));
		gGateParTbl[usLoop].usListConfStat = QBVS_LCONF_IDLE;
		gGateParTbl[usLoop].usCycleTimeStat = QBVS_CTIME_IDLE;
		gGateParTbl[usLoop].usListExecStat = QBVS_LEXEC_IDLE;
		gGateParTbl[usLoop].blConfigPending = FALSE;
		gGateParTbl[usLoop].blCycleStart = FALSE;
		gGateParTbl[usLoop].lNewConfigCT = FALSE;
		gGateParTbl[usLoop].byAdmGateStates = 0xff;
		gGateParTbl[usLoop].byOpeGateStates = gGateParTbl[usLoop].byAdmGateStates;
		gGateParTbl[usLoop].stExitTimer.lHighTimeBit = 0L;
		gGateParTbl[usLoop].stExitTimer.ulLowTimeBit = 0UL;
		gGateParTbl[usLoop].lListPointer = 0L;
		gGateParTbl[usLoop].blGateEnabled = FALSE;
		gGateParTbl[usLoop].ulMaxFrameTransTime = 150000UL;
		gGateParTbl[usLoop].lSupportListMax = MAX_GATE_ENTRY;
		gGateParTbl[usLoop].blCycleExec = FALSE;
	}

	gpTraEntryRecPtr0 = NULL;
	for (usLoop = 0; usLoop < usMaxPort; usLoop++) {
		gTraClsSendWait[usLoop].pstTraClsNext = NULL;
		gTraClsSendWait[usLoop].pstTraClsTail = NULL;
		for (nLoop = 0; nLoop < MAX_TRAFFIC_CLASS; nLoop++) {
			gpTraEntryRecPtr[usLoop][nLoop] = NULL;
			gTraClsQueue[usLoop][nLoop].pstTraClsNext = NULL;
			gTraClsQueue[usLoop][nLoop].pstTraClsTail = NULL;
		}
	}

	gpTraEntryRecPtr0 = &gTraEntryMem[0];
	for (nLoop = 0; (nLoop + 1) < MAX_TRACLS_ENTRY; nLoop++) {
		gTraEntryMem[nLoop].pstTraClsNext = &gTraEntryMem[nLoop + 1];
	}
	gTraEntryMem[nLoop].pstTraClsNext = NULL;
	
	tsn_Wrapper_LockCreate(&gpLockHandle);
	
	return (INT)RET_ENOERR;
}

INT qbv_set_gatepar(UCHAR uchPort, USHORT usParID, const VOID* puchParValuePtr, USHORT usParLength)
{

	BOOL		blGateEnabled = 0;
	BOOL		blConfigChange = 0;
	INT			nErrorCode = 0;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort-1) ) {
		return (INT)RET_EINVAL;
	}
	
	if (puchParValuePtr == NULL) {
		return (INT)RET_EINVAL;
	}
	
	tsn_Wrapper_LockWait(gpLockHandle);
	
	blGateEnabled = gGateParTbl[uchPort].blGateEnabled;
	blConfigChange = gGateParTbl[uchPort].blConfigChange;

	switch (usParID) {
	case GPARA_QMAX_SDU:
		if (gGateParTbl[uchPort].blGateEnabled == TRUE) {
			nErrorCode = RET_ESTATE;
		}
		else {
			if (((usParLength % (USHORT)sizeof(QUE_MAXSDU)) == 0)
				&& (usParLength <= (USHORT)(sizeof(QUE_MAXSDU) * (size_t)MAX_TRAFFIC_CLASS))) {
				tsn_Wrapper_MemCpy(gGateParTbl[uchPort].stQueMaxSDU, puchParValuePtr, (size_t)usParLength);
			}
			else {
				nErrorCode = RET_EINVAL;
			}
		}
		break;
	case GPARA_GATE_ENABL:
		if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].blGateEnabled)) {
			gGateParTbl[uchPort].blGateEnabled = *(BOOL*)puchParValuePtr;
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_GSTAT:
		if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].byAdmGateStates)) {
			gGateParTbl[uchPort].byAdmGateStates = *(BYTE*)puchParValuePtr;
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_CNTLST_LEN:
		if ((usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].ulAdmContListLen)) 
			&& (1 <= *(ULONG*)puchParValuePtr)
			&& (*(ULONG*)puchParValuePtr <= MAX_GATE_ENTRY)) {
			gGateParTbl[uchPort].ulAdmContListLen = *(ULONG*)puchParValuePtr;
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_CNT_LST:
		if (((usParLength % (USHORT)sizeof(GATE_CONTENT)) == 0) 
			&& (usParLength <= (USHORT)(sizeof(GATE_CONTENT) * (size_t)MAX_GATE_ENTRY))) {
			tsn_Wrapper_MemCpy(gGateParTbl[uchPort].stAdmGateCont, puchParValuePtr, (size_t)usParLength);
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_CYCL_TIME:
		if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].stAdmCycleTime)) {
			tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stAdmCycleTime, puchParValuePtr, (size_t)usParLength);
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_CYCLT_EXT:
		if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].ulAdmCycleTimeExt)) {
			gGateParTbl[uchPort].ulAdmCycleTimeExt = *(ULONG*)puchParValuePtr;
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_ADMI_BASE_TIME:
		if (((usParLength % (USHORT)sizeof(EXTENDEDTIMESTAMP)) == 0) 
			&& (usParLength <= (USHORT)sizeof(EXTENDEDTIMESTAMP))) {
			tsn_Wrapper_MemCpy(&gGateParTbl[uchPort].stAdmBaseTime, puchParValuePtr, (size_t)usParLength);
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_CONF_CHNG:
		if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].blConfigChange)) {
			gGateParTbl[uchPort].blConfigChange = *(BOOL*)puchParValuePtr;
		}
		else {
			nErrorCode = RET_EINVAL;
		}
		break;
	case GPARA_MAXFRAM_TXTIME:
		if (gGateParTbl[uchPort].blGateEnabled == TRUE) {
			nErrorCode = RET_ESTATE;
		}
		else {
			if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].ulMaxFrameTransTime)) {
				gGateParTbl[uchPort].ulMaxFrameTransTime = *(ULONG*)puchParValuePtr;
			}
			else {
				nErrorCode = RET_EINVAL;
			}
		}
		break;
	case GPARA_CLASSQUE_MAX:
		if (gGateParTbl[uchPort].blGateEnabled == TRUE) {
			nErrorCode = RET_ESTATE;
		}
		else {
			if (usParLength <= (USHORT)sizeof(gGateParTbl[uchPort].usClassQueMax)) {
				tsn_Wrapper_MemCpy(gGateParTbl[uchPort].usClassQueMax, puchParValuePtr, (size_t)usParLength);
			}
			else {
				nErrorCode = RET_EINVAL;
			}
		}
		break;
	default:
		nErrorCode = RET_EINVAL;
		break;
	}

	if (nErrorCode == RET_ENOERR) {
		if ((blConfigChange == FALSE) || (blGateEnabled == FALSE)) {
			if ((gGateParTbl[uchPort].blConfigChange == TRUE) 
				&& (gGateParTbl[uchPort].blGateEnabled == TRUE)) {
				(void)qbv_StateMachine(uchPort, (USHORT)QBVE_CONF_CHANHGE, NULL);
			}
		}
		if (blGateEnabled == TRUE) {
			if (gGateParTbl[uchPort].blGateEnabled == FALSE) {
				(void)qbv_StateMachine(uchPort, (USHORT)QBVE_GATE_DISABLE, NULL);
			}
		}
	}
	tsn_Wrapper_UnLock(gpLockHandle);
	return nErrorCode;
}

INT qbv_get_gatepar(UCHAR uchPort, USHORT usParID, VOID* puchParValuePtr, USHORT* pusParLength)
{

	INT		nErrorCode = RET_ENOERR;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort-1) ) {
		return (INT)RET_EINVAL;
	}
	
	tsn_Wrapper_LockWait(gpLockHandle);
	
	switch (usParID)
	{
	case GPARA_QMAX_SDU:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stQueMaxSDU)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, gGateParTbl[uchPort].stQueMaxSDU, sizeof(gGateParTbl[uchPort].stQueMaxSDU));
			*pusParLength = sizeof(gGateParTbl[uchPort].stQueMaxSDU);
		}
		break;
	case GPARA_GATE_ENABL:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].blGateEnabled)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(BOOL *)puchParValuePtr = gGateParTbl[uchPort].blGateEnabled;
			*pusParLength = sizeof(gGateParTbl[uchPort].blGateEnabled);
		}
		break;
	case GPARA_ADMI_GSTAT:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].byAdmGateStates)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(BYTE *)puchParValuePtr = gGateParTbl[uchPort].byAdmGateStates;
			*pusParLength = sizeof(gGateParTbl[uchPort].byAdmGateStates);
		}
		break;
	case GPARA_OPER_GSTAT:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].byOpeGateStates)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(BYTE *)puchParValuePtr = gGateParTbl[uchPort].byOpeGateStates;
			*pusParLength = sizeof(gGateParTbl[uchPort].byOpeGateStates);
		}
		break;
	case GPARA_ADMI_CNTLST_LEN:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].ulAdmContListLen)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(ULONG *)puchParValuePtr = gGateParTbl[uchPort].ulAdmContListLen;
			*pusParLength = sizeof(gGateParTbl[uchPort].ulAdmContListLen);
		}
		break;
	case GPARA_OPER_CNTLST_LEN:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].ulOpeContListLen)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(ULONG *)puchParValuePtr = gGateParTbl[uchPort].ulOpeContListLen;
			*pusParLength = sizeof(gGateParTbl[uchPort].ulOpeContListLen);
		}
		break;
	case GPARA_ADMI_CNT_LST:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stAdmGateCont)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, gGateParTbl[uchPort].stAdmGateCont, 
				(size_t)((sizeof(gGateParTbl[uchPort].stAdmGateCont) * (ULONG)gGateParTbl[uchPort].lSupportListMax)));
			*pusParLength = sizeof(gGateParTbl[uchPort].stAdmGateCont);
		}
		break;
	case GPARA_OPER_CNT_LST:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stOpeGateCont)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, gGateParTbl[uchPort].stOpeGateCont, 
				(size_t)((sizeof(gGateParTbl[uchPort].stOpeGateCont) * (ULONG)gGateParTbl[uchPort].lSupportListMax)));	
			*pusParLength = sizeof(gGateParTbl[uchPort].stOpeGateCont);
		}
		break;
	case GPARA_ADMI_CYCL_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stAdmCycleTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stAdmCycleTime,
								sizeof(gGateParTbl[uchPort].stAdmCycleTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stAdmCycleTime);
		}
		break;
	case GPARA_OPER_CYCL_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stOpeCycleTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stOpeCycleTime,
								sizeof(gGateParTbl[uchPort].stOpeCycleTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stOpeCycleTime);
		}
		break;
	case GPARA_ADMI_CYCLT_EXT:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].ulAdmCycleTimeExt)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(ULONG *)puchParValuePtr = gGateParTbl[uchPort].ulAdmCycleTimeExt;
			*pusParLength = sizeof(gGateParTbl[uchPort].ulAdmCycleTimeExt);
		}
		break;
	case GPARA_OPER_CYCLT_EXT:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].ulOpeCycleTimeExt)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(ULONG *)puchParValuePtr = gGateParTbl[uchPort].ulOpeCycleTimeExt;
			*pusParLength = sizeof(gGateParTbl[uchPort].ulOpeCycleTimeExt);
		}
		break;
	case GPARA_ADMI_BASE_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stAdmBaseTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stAdmBaseTime, sizeof(gGateParTbl[uchPort].stAdmBaseTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stAdmBaseTime);
		}
		break;
	case GPARA_OPER_BASE_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stOpeBaseTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stOpeBaseTime, sizeof(gGateParTbl[uchPort].stOpeBaseTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stOpeBaseTime);
		}
		break;
	case GPARA_CONF_CHNG:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].blConfigChange)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(BOOL *)puchParValuePtr = gGateParTbl[uchPort].blConfigChange;
			*pusParLength = sizeof(gGateParTbl[uchPort].blConfigChange);
		}
		break;
	case GPARA_CONFCHNG_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stConfChangTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stConfChangTime, sizeof(gGateParTbl[uchPort].stConfChangTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stConfChangTime);
		}
		break;
	case GPARA_TICK_GRANUL:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].lTickGranul)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(LONG *)puchParValuePtr = gGateParTbl[uchPort].lTickGranul;
			*pusParLength = sizeof(gGateParTbl[uchPort].lTickGranul);
		}
		break;
	case GPARA_CURR_TIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].stCurrentTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].stCurrentTime, sizeof(gGateParTbl[uchPort].stCurrentTime));
			*pusParLength = sizeof(gGateParTbl[uchPort].stCurrentTime);
		}
		break;
	case GPARA_CONF_PEND:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].blConfigPending)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(BOOL *)puchParValuePtr = gGateParTbl[uchPort].blConfigPending;
			*pusParLength = sizeof(gGateParTbl[uchPort].blConfigPending);
		}
		break;
	case GPARA_CONFCHNG_ERR:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].lConfChangErr)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(LONG *)puchParValuePtr = gGateParTbl[uchPort].lConfChangErr;
			*pusParLength = sizeof(gGateParTbl[uchPort].lConfChangErr);
		}
		break;
	case GPARA_SUPP_LISTMAX:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].lSupportListMax)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(LONG *)puchParValuePtr = gGateParTbl[uchPort].lSupportListMax;
			*pusParLength = sizeof(gGateParTbl[uchPort].lSupportListMax);
		}
		break;
	case GPARA_MAXFRAM_TXTIME:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].ulMaxFrameTransTime)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			*(ULONG *)puchParValuePtr = gGateParTbl[uchPort].ulMaxFrameTransTime;
			*pusParLength = sizeof(gGateParTbl[uchPort].ulMaxFrameTransTime);
		}
		break;
	case GPARA_CLASSQUE_MAX:
		if (*pusParLength < sizeof(gGateParTbl[uchPort].usClassQueMax)) {
			nErrorCode = RET_EINVAL;
		}
		else {
			tsn_Wrapper_MemCpy(puchParValuePtr, &gGateParTbl[uchPort].usClassQueMax, sizeof(gGateParTbl[uchPort].usClassQueMax));
			*pusParLength = sizeof(gGateParTbl[uchPort].usClassQueMax);
		}
		break;
	default:
		nErrorCode = RET_EINVAL;
		break;
	}

	tsn_Wrapper_UnLock(gpLockHandle);
	return nErrorCode;
}

INT qbv_open(void)
{

	USHORT		usLoop = 0;
	BOOL	blGateEnabled = 0;
	BOOL	blConfigChange = 0;
	INT		nErrorCode = 0;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
		
	tsn_Wrapper_LockWait(gpLockHandle);

	for (usLoop = 0; usLoop < gQbvInfTbl.usMaxPort; usLoop++) {
		blGateEnabled = gGateParTbl[usLoop].blGateEnabled;
		blConfigChange = gGateParTbl[usLoop].blConfigChange;
		gGateParTbl[usLoop].blConfigChange = TRUE;
		gGateParTbl[usLoop].blGateEnabled = TRUE;
		if ( (blGateEnabled == FALSE) || (blConfigChange == FALSE) ) {
			nErrorCode = qbv_StateMachine((UCHAR)usLoop, (USHORT)QBVE_CONF_CHANHGE, NULL);
		}
	}
	
	tsn_Wrapper_UnLock(gpLockHandle);
	return nErrorCode;
	
}

INT qbv_close(void)
{

	USHORT usLoop = 0;
	BOOL blGateEnabled = 0;
	INT nErrorCode = 0;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
		
	tsn_Wrapper_LockWait(gpLockHandle);

	for (usLoop = 0; usLoop < gQbvInfTbl.usMaxPort; usLoop++) {
		blGateEnabled = gGateParTbl[usLoop].blGateEnabled;
		gGateParTbl[usLoop].blGateEnabled = FALSE;
		if (blGateEnabled == TRUE) {
			nErrorCode = qbv_StateMachine((UCHAR)usLoop, (USHORT)QBVE_GATE_DISABLE, NULL);
		}
	}

	tsn_Wrapper_UnLock(gpLockHandle);
	
	return nErrorCode;
	
}

INT qbv_send(UCHAR uchPort, UCHAR uchTraClsNo, UCHAR* puchFramPtr, USHORT usFrameLen, VOID* pvPacketId, 
																	SENDTIMESCB stSendCBFunc, VOID* pvLinkId)
{
	struct tagTRACLS_ENTRY* gpTraEntry = NULL;
	INT nErrorCode = 0;
	
	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort -1)) {
		return (INT)RET_EINVAL;
	}
	
	if ( (uchTraClsNo < (UCHAR)START_CLASS_NO) 
		|| (uchTraClsNo > (UCHAR)MAX_TRAFFIC_CLASS) ) {
		return (INT)RET_EINVAL;
	}
	
	if ( (usFrameLen < (USHORT)MINIMUM_SEND_SIZE) 
		|| (usFrameLen > (USHORT)MAX_SEND_SIZE) 
		|| (puchFramPtr == NULL) ) {
		return (INT)RET_EINVAL;
	}

	tsn_Wrapper_LockWait(gpLockHandle);
	
	if (gGateParTbl[uchPort].usClassQueMax[uchTraClsNo - 1u] != (USHORT)0) {
		if (gpTraEntryRecPtr[uchPort][uchTraClsNo - 1u] == (struct tagTRACLS_ENTRY *)NULL) {
			tsn_Wrapper_UnLock(gpLockHandle);
			return (INT)RET_ENOMEM;
		}
		gpTraEntry = (struct tagTRACLS_ENTRY *)gpTraEntryRecPtr[uchPort][uchTraClsNo-1u];
		gpTraEntryRecPtr[uchPort][uchTraClsNo-1u] = (struct tagTRACLS_ENTRY *)gpTraEntry->pstTraClsNext;
	}
	else {
		if (gpTraEntryRecPtr0 == NULL) {
			tsn_Wrapper_UnLock(gpLockHandle);
			return (INT)RET_ENOMEM;
		}
		gpTraEntry = gpTraEntryRecPtr0;
		gpTraEntryRecPtr0 = gpTraEntry->pstTraClsNext;
	}
	

	gpTraEntry->uchPort = uchPort;
	gpTraEntry->uchTraClsNo = uchTraClsNo;
	gpTraEntry->puchFramPtr = puchFramPtr;
	gpTraEntry->usFramLen = usFrameLen;
	gpTraEntry->pvPacketId = pvPacketId;
	gpTraEntry->stSendCBFunc = stSendCBFunc;
	gpTraEntry->pvLinkId = pvLinkId;

	nErrorCode = qbv_StateMachine(uchPort, (USHORT)QBVE_SEND_REQUEST, gpTraEntry);
	
	tsn_Wrapper_UnLock(gpLockHandle);

	return nErrorCode;
}



INT qbv_multi_send(QBV_SENDPAR* pstSendPar, USHORT* pusParLen)
{

	USHORT usLoop = 0;
	INT nErrorCode = 0;
	USHORT usSuccess = 0;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}
	
	if ( (pstSendPar == NULL) || (pusParLen == NULL) ) {
		return (INT)RET_EINVAL;
	}
	
	for (usLoop = 0; usLoop < *pusParLen; usLoop++) {
		nErrorCode = qbv_send(pstSendPar->uchPort, pstSendPar->uchTraClsNo, pstSendPar->puchFramPtr, pstSendPar->usFramLen, 
			pstSendPar->pvPacketId, pstSendPar->stSendCBFunc, pstSendPar->pvLinkId);
		
		if (nErrorCode == RET_ENOERR) {
			usSuccess++;
		}
		else {
			*pusParLen = usSuccess;
			return (INT)RET_EINTERNAL;
		}
	}
	*pusParLen = usSuccess;
	
	return (INT)RET_ENOERR;
	
}



INT qbv_RegisterFailedCB(QBV_USER_FAILEDCB pstUserFailedCB)
{

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}

	tsn_Wrapper_LockWait(gpLockHandle);

	gQbvInfTbl.stUserFailedCB = pstUserFailedCB;

	tsn_Wrapper_UnLock(gpLockHandle);

	return (INT)RET_ENOERR;

}



INT qbv_queue_clear(UCHAR uchPort, UCHAR uchTraClsNo)
{

	struct tagTRACLS_ENTRY* temp;

	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}

	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort-1)) {
		return (INT)RET_EINVAL;
	}

	if ((uchTraClsNo < (UCHAR)START_CLASS_NO) || (uchTraClsNo > (UCHAR)MAX_TRAFFIC_CLASS)) {
		return (INT)RET_EINVAL;
	}

	tsn_Wrapper_LockWait(gpLockHandle);

	while (gTraClsQueue[uchPort][uchTraClsNo - 1u].pstTraClsNext != (struct tagTRACLS_ENTRY *)NULL) {
		temp = gTraClsQueue[uchPort][uchTraClsNo - 1u].pstTraClsNext;
		gTraClsQueue[uchPort][uchTraClsNo - 1u].pstTraClsNext = (struct tagTRACLS_ENTRY *)temp->pstTraClsNext;

		if (temp->stSendCBFunc != NULL) {
			tsn_Wrapper_UnLock(gpLockHandle);
			(*(temp->stSendCBFunc))((INT)RET_EINTERNAL, uchPort, NULL, temp->pvLinkId);
			tsn_Wrapper_LockWait(gpLockHandle);
		}
		
		if (temp->pvPacketId != 0) {
			tcpwrap_sbuffree(temp->pvPacketId);
		}

		if (gGateParTbl[uchPort].usClassQueMax[temp->uchTraClsNo-1] != 0) {
			temp->pstTraClsNext = gpTraEntryRecPtr[uchPort][temp->uchTraClsNo - 1u]->pstTraClsNext;
			gpTraEntryRecPtr[uchPort][temp->uchTraClsNo - 1u]->pstTraClsNext = temp;
		}
		else {
			temp->pstTraClsNext = gpTraEntryRecPtr0;
			gpTraEntryRecPtr0 = temp;
		}
	}

 	tsn_Wrapper_UnLock(gpLockHandle);

	return (INT)RET_ENOERR;

}



INT qbv_RegisterGateOpenCB(UCHAR uchPort, UCHAR uchGateIdNo, QBV_USER_GOPENCB pstUserGateOpenCB)
{
	
	if (gQbvInfTbl.ulMagicNo != INIT_MASIC_NO) {
		return (INT)RET_ESTATE;
	}

	if (uchPort > (UCHAR)(gQbvInfTbl.usMaxPort - 1)) {
		return (INT)RET_EINVAL;
	}

	if (uchGateIdNo >= (UCHAR)MAX_GATE_ENTRY) {
		return (INT)RET_EINVAL;
	}

	tsn_Wrapper_LockWait(gpLockHandle);

	gGateParTbl[uchPort].stUserGOpenCB[uchGateIdNo] = pstUserGateOpenCB;

	tsn_Wrapper_UnLock(gpLockHandle);

	return (INT)RET_ENOERR;

}

VOID qbv_Tick(void)
{
	
	USHORT usLoop = 0;

	tsn_Wrapper_LockWait(gpLockHandle);

	for (usLoop = 0; usLoop < gQbvInfTbl.usMaxPort; usLoop++) {
		qbv_StateMachine((UCHAR)usLoop, (USHORT)QBVE_TICK, NULL);
	}

	tsn_Wrapper_UnLock(gpLockHandle);

}

VOID qbv_SendComp(UCHAR uchPort)
{
	
	gGateParTbl[uchPort].nSendCompWaitCT--;

	qbv_StateMachine(uchPort, (USHORT)QBVE_SEND_COMPLET, NULL);

	return;
}

