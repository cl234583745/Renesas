/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_TSN_WRAPPER_H__
#define __PTP_TSN_WRAPPER_H__


#include "ptp_type.h"

typedef	unsigned int	size_t;

VOID*	tsn_Wrapper_MemCpy(
		VOID *pvDst,
		const VOID *pvSrc,
		size_t ullIn
	);

INT		tsn_Wrapper_MemCmp(
		const VOID *pvBuf1,
		const VOID *pvBuf2,
		size_t ullIn
	);
VOID*	tsn_Wrapper_MemSet(
		VOID *pvBuf,
		INT nCh,
		size_t ullIn
	);
VOID	tsn_Wrapper_RandInit(VOID);

INT		tsn_Wrapper_Rand(VOID);

VOID*	tsn_Wrapper_Malloc(
		size_t ullIn
	);

VOID	tsn_Wrapper_Free(
		VOID *pvBuf
	);

DOUBLE	tsn_Wrapper_Pow(
		DOUBLE	dbX,
		DOUBLE	dbY
	);


INT	tsn_Wrapper_LockCreate(VOID **pvLockHandle);

INT	tsn_Wrapper_LockDelete(VOID *pvLockHandle);

INT	tsn_Wrapper_LockWait(VOID *pvLockHandle);

INT	tsn_Wrapper_Lock(VOID *pvLockHandle);

INT	tsn_Wrapper_LockWait(VOID *pvLockHandle);

LONG tsn_Wrapper_UnLock(VOID *pvLockHandle);



#endif
