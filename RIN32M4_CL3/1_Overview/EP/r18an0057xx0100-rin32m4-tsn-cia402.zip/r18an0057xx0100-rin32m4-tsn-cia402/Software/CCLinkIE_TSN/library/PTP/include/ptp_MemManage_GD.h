/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MEMMANAGE_GD_H__
#define __PTP_MEMMANAGE_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"


 










typedef	struct	tagPTPMMLNK
{
	struct tagPTPMMLNK*			pstNextMmLnkPtr;
	struct tagPTPMMLNK*			pstPrevMmLnkPtr;
} PTPMMLNK; 




typedef	struct	tagPTPMMTIMEBLK
{
	PTPMMLNK			stPtpMmTimeLnk;
	CURRENTTIMEQUE		stCurrentTimeQue;
} PTPMMTIMEBLK; 


typedef	struct	tagPTPMMANNOBLK
{
	PTPMMLNK			stPtpMmAnnoLnk;
	ANNOUNCE_INFO		stAnnounceInfo;
} PTPMMANNOBLK; 


typedef	struct	tagPTPMMFOREBLK
{
	PTPMMLNK			stPtpMmForeLnk;
	FOREIGN_MASTER_INFO	stForeignMasterInfo;
} PTPMMFOREBLK; 


typedef	struct tagMEMMANAGE_GD
{
	PTPMMLNK			stPtpMMClockLnkH;
	PTPMMLNK			stPtpMMPortLnkH;

	PTPMMLNK			stPtpMMTimeLnkH;
	PTPMMTIMEBLK		stPtpMMTimeBlk[PTPMMTIMEBLK_NUM];

	PTPMMLNK			stPtpMMAnnoLnkH;
	PTPMMANNOBLK		stPtpMMAnnoBlk[PTPMMANNOBLK_NUM];

	PTPMMLNK			stPtpMMForeLnkH;
	PTPMMFOREBLK		stPtpMMForeBlk[PTPMMFOREBLK_NUM];

} MEMMANAGE_GD;	




#endif


