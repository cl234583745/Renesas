/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#include "MDLkDlyIntvalSet.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDLkDlyIntvalSet_1AS.h"
#endif

VOID LinkDelayIntervalSettingSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET, PTP_LOGVE_82080001);
#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		LinkDelayIntvalSetSM_1AS(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET, PTP_LOGVE_82000002);
	return;
}

LDISETTINGSM_GD* GetLkDlyIntvSetGlobal(PORTDATA* pstPort)
{
	return &pstPort->stLDISettingSM_GD;
}

LDLYINTVSET_EV GetLkDlyIntvSetEvent(USHORT usEvent, PORTDATA* pstPort)
{
	LDLYINTVSET_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDLKDI_E_BEGIN;
		break;
		case PTP_EV_USEMGTSETLOGPDELREQINT_ON:
			enEvt = MDLKDI_E_UMGTSETLOGPDREQINT_ON;
		break;
		case PTP_EV_USEMGTSETLOGPDELREQINT_OF:
			enEvt = MDLKDI_E_UMGTSETLOGPDREQINT_OF;
		break;
		case PTP_EV_F_LNKDLINTSET_RVDSIGMSG1:
			enEvt = MDLKDI_E_F_LKDLINTST_RVDSGMSG1;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDLKDI_E_CLOSE;
		break;

		default:
			enEvt = MDLKDI_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

LDLYINTVSET_ST GetLkDlyIntvSetStatus(PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;
	LDLYINTVSET_ST		enSts = MDLKDI_STATUS_MAX;

	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	if (pstGbl->enStsLDlyIntvalSet < MDLKDI_STATUS_MAX)
	{
		enSts = pstGbl->enStsLDlyIntvalSet;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetLkDlyIntvSetStatus(LDLYINTVSET_ST enSts, PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	pstGbl->enStsLDlyIntvalSet = enSts;
	return;
}
#endif
