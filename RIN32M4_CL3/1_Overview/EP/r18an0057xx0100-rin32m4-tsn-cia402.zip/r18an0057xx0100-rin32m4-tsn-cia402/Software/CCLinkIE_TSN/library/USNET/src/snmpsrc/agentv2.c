//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "snmpv3.h"
#ifdef USSW_LLDP_MIB
#include "mib_lldp.h"
#include "msw_lldp.h"
#include "lldpd.h"
#endif
#include "net.h"
#include "usnet_supply.h"
#include "support.h"

#define SNMP_ERROR_CHECK 1

#if SNMP_ERROR_CHECK && NTRACE >= 5
void err_go(const char *errstring, int errval, int line)
{
    Nprintf("SNMPAG Error ");
    if (errval)
        Nprintf("[%d] ", errval);
    Nprintf("[line %d]: ", line);
    Nprintf("'%s'\n", errstring);
}
#define ERR_VGO(s, v, t) do { err_go(s, v, __LINE__); goto t; } while (0)
#define ERR_GO(s, t) ERR_VGO(s, 0, t)

void Nprinthex(char *title, uint8 *cp, int len)
{
    int i1;
    Nprintf("%s [%d bytes]:", title, len);
    for (i1 = 0; i1 < len; i1++) {
        if ((i1 % 20) == 0)
            Nprintf("\n");
        Nprintf(" %02x", *cp++);
    }
    Nprintf("\n");
}
#else
#define ERR_VGO(s, v, t) goto t
#define ERR_GO(s, t) goto t
#define Nprinthex(t,c,l)
#endif


static uint8 buffh[SNMP_MAXSIZE], buffi[SNMP_MAXSIZE], bufft[SNMP_MAXSIZE];
#define buffo buffh

static const MIB **mibs;
static uint16 nmibs;
static const TRAP_HOST **thosts;
static uint16 trapv, trapid, nthosts;
static uint8 tm_ip[4];

static const TRANSPORT_MAPPING *snmp_tm;

sint8 snmp_sint8;
uint8 snmp_uint8;
sint16 snmp_sint16;
uint16 snmp_uint16;
sint32 snmp_sint32;
uint32 snmp_uint32;

#ifdef USSW_LLDP_MIB
static uint32 lldp_lasttrap_time = 0;
static uint32 lldp_next_sendtrap = 0;
#endif



#if ENTERPRISE < 0x80
#define EPR_SZ 1
#elif ENTERPRISE < 0x4000
#define EPR_SZ 2
#elif ENTERPRISE < 0x200000
#define EPR_SZ 3
#elif ENTERPRISE < 0x10000000
#define EPR_SZ 4
#else
#define EPR_SZ 5
#endif
static uint8 sysObjectID[8 + EPR_SZ];

static struct
{
    uint8 *sysDescr;
    uint8 *sysContact;
    uint8 *sysName;
    uint8 *sysLocation;
} sysgroup;

uint32 sysStartTime;
static uint8 sysContact[64], sysName[64], sysLocation[64];
static uint8 sysDescr[64];

static const MIBVAR mibvar_sys[] =
{
    {{8,{0x2b,6,1,2,1,1,1,0}}, 0, String, sizeof(sysDescr), &sysgroup.sysDescr},
    {{8,{0x2b,6,1,2,1,1,2,0}}, 0, Identifier, 6 + EPR_SZ, sysObjectID},
    {{8,{0x2b,6,1,2,1,1,3,0}}, CAR, Ticks, 4, &snmp_uint32},
    {{8,{0x2b,6,1,2,1,1,4,0}}, W, String, sizeof(sysContact), &sysgroup.sysContact},
    {{8,{0x2b,6,1,2,1,1,5,0}}, W, String, sizeof(sysName), &sysgroup.sysName},
    {{8,{0x2b,6,1,2,1,1,6,0}}, W, String, sizeof(sysLocation), &sysgroup.sysLocation},
    {{8,{0x2b,6,1,2,1,1,7,0}}, IMMED, Integer, 0x4e, 0},
};

static sint16 mibvarsize_sys(void)
{
    return sizeof(mibvar_sys) / sizeof(MIBVAR);
}

static void mibget_sys(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    (void)tabix;
    if (varix == 2)
        *(uint32 *)*vvptr = 0;
}

static void mibinit_sys(uint16 type)
{
    uint8 *cp;
    (void)type;

    sysStartTime = snmp_tm->time();

    vUSN_GetModelNameMib(sysDescr);
    sysDescr[sizeof(sysDescr) - 1] = 0;
    sysgroup.sysDescr = sysDescr;
    
    cp = sysObjectID;
    *cp++ = 0x2b;
    *cp++ = 0x06;
    *cp++ = 0x01;
    *cp++ = 0x04;
    *cp++ = 0x01;
    cp += EPR_SZ;
    snmpEncodeID(&cp, EPR_SZ, ENTERPRISE);
    cp += EPR_SZ;
    *cp++ = 0x01;

    sncopy(sysContact, SYSCONTACT, sizeof(sysContact));
    sysContact[sizeof(sysContact) - 1] = 0;
    sysgroup.sysContact = sysContact;

    sncopy(sysName, SYSNAME, sizeof(sysName));
    sysName[sizeof(sysName) - 1] = 0;
    sysgroup.sysName = sysName;

    sncopy(sysLocation, SYSLOCATION, sizeof(sysLocation));
    sysLocation[sizeof(sysLocation) - 1] = 0;
    sysgroup.sysLocation = sysLocation;

    return;
}


const MIB mib_sys =
{
    mibvar_sys,
    mibvarsize_sys,
    0,
    0,
    mibget_sys,
    0,
    0,
    mibinit_sys,
    0,
};







uint8 snmpEngineID[9];
uint32 snmpEngineBoots;
uint32 snmpEngineTime;
uint32 snmpEngineMaxMessageSize;

uint32 snmpUnknownContexts;

static const MIBVAR mibvar_engine[] =
{
    {{10,{0x2b,6,1,6,3,10,2,1,1,0}}, 0, OctetString, 9, snmpEngineID},
    {{10,{0x2b,6,1,6,3,10,2,1,2,0}}, 0, Integer, sizeof(uint32), &snmpEngineBoots},
    {{10,{0x2b,6,1,6,3,10,2,1,3,0}}, 0, Integer, sizeof(uint32), &snmpEngineTime},
    {{10,{0x2b,6,1,6,3,10,2,1,4,0}}, 0, Integer, sizeof(uint32), &snmpEngineMaxMessageSize},

    {{9,{0x2b,6,1,6,3,12,1,5,0}}, 0, Counter32, sizeof(uint32), &snmpUnknownContexts},
};

static sint16 mibvarsize_engine(void)
{
    return sizeof(mibvar_engine) / sizeof(MIBVAR);
}

static void mibinit_engine(uint16 type)
{
    uint8 *cp;
    sint16 i1;
    (void)type;

    cp = snmpEngineID;
    for (i1 = 0; i1 < 4; i1++)
        *cp++ = (uint8)((uint32)ENTERPRISE >> ((3 - i1) * 8));
    *snmpEngineID |= 0x80;
    *cp++ = 0x01;
    for (i1 = 0; i1 < 4; i1++)
        *cp++ = tm_ip[i1];

    snmpEngineBoots = 1;

    return;
}

const MIB mib_engine =
{
    mibvar_engine,
    mibvarsize_engine,
    0,
    0,
    0,
    0,
    0,
    mibinit_engine,
    0,
};



struct
{
    uint32 snmpInPkts;
    uint32 snmpOutPkts;
    uint32 snmpInBadVersions;
    uint32 snmpInBadCommunityNames;
    uint32 snmpInBadCommunityUses;
    uint32 snmpInASNParseErrs;
    uint32 snmpInTooBigs;
    uint32 snmpInNoSuchNames;
    uint32 snmpInBadValues;
    uint32 snmpInReadOnlys;
    uint32 snmpInGenErrs;
    uint32 snmpInTotalReqVars;
    uint32 snmpInTotalSetVars;
    uint32 snmpInGetRequests;
    uint32 snmpInGetNexts;
    uint32 snmpInSetRequests;
    uint32 snmpInGetResponses;
    uint32 snmpInTraps;
    uint32 snmpOutTooBigs;
    uint32 snmpOutNoSuchNames;
    uint32 snmpOutBadValues;
    uint32 snmpOutGenErrs;
    uint32 snmpOutGetRequests;
    uint32 snmpOutGetNexts;
    uint32 snmpOutSetRequests;
    uint32 snmpOutGetResponses;
    uint32 snmpOutTraps;
    uint32 snmpEnableAuthenTraps;
} snmpgroup;

static const MIBVAR mibvar_snmp[] =
{
    {{8,{0x2b,6,1,2,1,11,1,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInPkts},
    {{8,{0x2b,6,1,2,1,11,2,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutPkts},
    {{8,{0x2b,6,1,2,1,11,3,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInBadVersions},
    {{8,{0x2b,6,1,2,1,11,4,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInBadCommunityNames},
    {{8,{0x2b,6,1,2,1,11,5,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInBadCommunityUses},
    {{8,{0x2b,6,1,2,1,11,6,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInASNParseErrs},
    {{8,{0x2b,6,1,2,1,11,8,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInTooBigs},
    {{8,{0x2b,6,1,2,1,11,9,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInNoSuchNames},
    {{8,{0x2b,6,1,2,1,11,10,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInBadValues},
    {{8,{0x2b,6,1,2,1,11,11,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInReadOnlys},
    {{8,{0x2b,6,1,2,1,11,12,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInGenErrs},
    {{8,{0x2b,6,1,2,1,11,13,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInTotalReqVars},
    {{8,{0x2b,6,1,2,1,11,14,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInTotalSetVars},
    {{8,{0x2b,6,1,2,1,11,15,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInGetRequests},
    {{8,{0x2b,6,1,2,1,11,16,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInGetNexts},
    {{8,{0x2b,6,1,2,1,11,17,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInSetRequests},
    {{8,{0x2b,6,1,2,1,11,18,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInGetResponses},
    {{8,{0x2b,6,1,2,1,11,19,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpInTraps},
    {{8,{0x2b,6,1,2,1,11,20,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutTooBigs},
    {{8,{0x2b,6,1,2,1,11,21,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutNoSuchNames},
    {{8,{0x2b,6,1,2,1,11,22,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutBadValues},
    {{8,{0x2b,6,1,2,1,11,24,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutGenErrs},
    {{8,{0x2b,6,1,2,1,11,25,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutGetRequests},
    {{8,{0x2b,6,1,2,1,11,26,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutGetNexts},
    {{8,{0x2b,6,1,2,1,11,27,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutSetRequests},
    {{8,{0x2b,6,1,2,1,11,28,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutGetResponses},
    {{8,{0x2b,6,1,2,1,11,29,0}}, 0, Counter, sizeof(uint32), &snmpgroup.snmpOutTraps},
    {{8,{0x2b,6,1,2,1,11,30,0}}, W, Integer, sizeof(uint32), &snmpgroup.snmpEnableAuthenTraps},
};

static sint16 mibvarsize_snmp(void)
{
    return sizeof(mibvar_snmp) / sizeof(MIBVAR);
}

static void mibinit_snmp(uint16 type)
{
    (void)type;

    memset((char *)&snmpgroup, 0, sizeof(snmpgroup));
    snmpgroup.snmpEnableAuthenTraps = ENABLEAUTHENTRAPSVAL;

    snmpUnknownContexts = 0;

    return;
}

static sint16 mibcheck_snmp(sint16 varix, sint16 tabix, const uint8 *inp)
{
    uint32 ul1 = 0;
    sint16 i1;

    (void)tabix;

    if (varix == 27)
    {
        i1 = snmpReadInt(&ul1, sizeof(ul1), &inp, mibvar_snmp[varix].type);
        if (i1 < 0 || ul1 < 1 || ul1 > 2)
            return wrongValue;
    }
    return 0;
}

const MIB mib_snmp =
{
    mibvar_snmp,
    mibvarsize_snmp,
    0,
    0,
    0,
    0,
    0,
    mibinit_snmp,
    mibcheck_snmp
};



static sint16 inReqOutRep(uint8 **obp, uint16 olen, const uint8 *ibp, uint16 ilen);


sint16 ussSNMPAgentInit(const AGENT_CONTEXT *acp)
{
    const MIB *mibp;
    const uint8 *cp;
    sint16 i1, i2;

    mibs = acp->mibs;
    nmibs = acp->nummibs;
    snmp_tm = acp->tm;
    thosts = acp->thosts;
    nthosts = acp->numthosts;
    trapv = acp->trapv;
    trapid = 1;

#ifdef SNMP_IP
    cp = (const uint8 *)SNMP_IP;
    for (i1 = 0; i1 < 4; i1++)
    {
        for (i2 = 0; *cp && *cp != '.'; cp++)
            i2 = i2 * 10 + (*cp - '0');
        tm_ip[i1] = i2;
        if (*cp++ == 0)
            break;
    }
#else
    memset(tm_ip, 0, sizeof(tm_ip));
#endif

    snmpEngineMaxMessageSize = SNMP_MAXSIZE;

    if (snmp_tm->init)
        snmp_tm->init((uint8 *)tm_ip, &snmpEngineMaxMessageSize, sysName);

    for (i1 = 0; i1 < (sint16)nmibs; i1++)
    {
        mibp = mibs[i1];
        if (mibp->init)
            mibp->init(acp->trapv);
    }

    i2 = snmp_tm->passive_open();
    if (i2 < 0)
    {
#if NTRACE
        Nprintf("SNMPAG: Error - Can't open passive transport! %d\n", i2);
#endif
        return i2;
    }

    switch (acp->trapt)
    {
    case COLDSTART:
    case WARMSTART:
    case LINKDOWN:
    case LINKUP:
    case AUTHENTICATIONFAILURE:
    case EGPNEIGHBORLOSS:
    case ENTERPRISESPECIFIC:
        ussSNMPAgentTrap((uint8)acp->trapt, 0, (const uint8 *)"public", 0, 0);
        break;
    default:
        break;
    }

    return 0;
}


sint16 ussSNMPAgentCheck(void)
{
    uint8 *cp;
    sint16 i1, i2;

    snmpEngineTime = snmp_tm->time() / 100;

    i1 = snmp_tm->passive_read(buffi, sizeof(buffi));

    if (i1 > 0)
    {
        Nprinthex("Packet in", buffi, i1);
        snmpgroup.snmpInPkts++;

        cp = buffo + sizeof(buffo);
        i2 = inReqOutRep(&cp, sizeof(buffo), buffi, i1);
        if (i2 > 0)
        {
            i1 = snmp_tm->passive_write(cp, i2);
            if (i1 >= 0)
            {
                Nprinthex("Packet out", cp, i2);
                snmpgroup.snmpOutPkts++;
                snmpgroup.snmpOutGetResponses++;
                i1 = 0;
            }
        }
#if NTRACE
        if (i1 < 0)
            Nprintf("SNMPAG: Error - Passive reply/write failure! %d\n", i1);
#endif
    }
#if NTRACE
    else if (i1 < 0)
        Nprintf("SNMPAG: Error - Passive read failure! %d\n", i1);
#endif

    return i1;
}


sint16 ussSNMPAgentShut(void)
{
    ussSNMPAgentTrap(LINKDOWN, 0, (const uint8 *)"public", 0, 0);

    return snmp_tm->passive_close();
}



static const uint8 oid_sysuptime[] = {0x2b, 6, 1, 2, 1, 1, 3, 0};
static const uint8 oid_snmptrapoid[] = {0x2b, 6, 1, 6, 3, 1, 1, 4, 1, 0};
static const uint8 oid_snmptraptype[] = {0x2b, 6, 1, 6, 3, 1, 1, 5, 0};


sint16 ussSNMPAgentTrap(uint8 type, uint8 specific, const uint8 *contextName,
    const uint8 *vbs, uint16 len)
{

	return 0;

}


static sint16 inReqOutRep(uint8 **obp, uint16 olen, const uint8 *ibp, uint16 ilen)
{
    const MIB *mibp;
    const MIBVAR *mvp;
    const MIBTAB *mtp;
    const uint8 *varbinds[MAXVAR];
    const uint8 *ibpend, *chkp, *chkp2, *inp;
    uint8 *obpend, *outp, *valp, *cp, *cp2, *soutp;
    uint8 *contextName, *securityName;
    uint32 ul1, reqid, nonrep, maxrep, reps;
    sint32 sl1;
    sint16 i1, i2, i3, len, len2, mibix, tabix, ixlen;
    uint8 type, version, flags, errix, errcode, nflag;
    sint8 vindex, vindex_save;

    flags = errix = errcode = nflag = 0;

    ibpend = ibp + ilen;
    inp = ibp;

    *obp -= 7;
    olen -= 7;
    outp = *obp;
    obpend = *obp - olen;

    securityName = obpend + 1;
    *securityName = 0;

    len = snmpReadLength(&inp, Sequence);
    if (len <= 0)
    {
err_parse:
        snmpgroup.snmpInASNParseErrs++;
        return 0;
    }
    chkp = inp + len;

    len = snmpReadInt(&ul1, sizeof(ul1), &inp, Integer);
    if (len <= 0 || len > (uint8)sizeof(ul1))
        ERR_VGO("msgVersion Length", len, err_parse);
    version = ul1;

    if (version != 0 && version != 1)
    {
        snmpgroup.snmpInBadVersions++;
        ERR_VGO("Bad version", version, err_parse);
    }

    contextName = securityName + slength(securityName) + 1;
    len = snmpReadVal(contextName, olen, &inp, String);
    if (len < 0 || (uint16)len > olen)
        ERR_VGO("ContextName Length", len, err_parse);
    contextName[len] = 0;

    type = *inp;
    len = snmpReadLength(&inp, type);
    if (len <= 0)
        ERR_VGO("Type Field Length", len, err_parse);
    chkp2 = inp + len;

    len = snmpReadInt(&reqid, sizeof(reqid), &inp, Integer);
    if (len < 1)
        ERR_VGO("Request-ID Length", len, err_parse);

    len = snmpReadInt(&nonrep, sizeof(nonrep), &inp, Integer);
    if (len <= 0)
        ERR_VGO("Error value Length", len, err_parse);

    len = snmpReadInt(&maxrep, sizeof(maxrep), &inp, Integer);
    if (len <= 0)
        ERR_VGO("Error Index Length", len, err_parse);

    len = snmpReadLength(&inp, Sequence);
    if (len < 0)
        ERR_VGO("PDU Data Length", len, err_parse);

    vindex = 0;
    varbinds[0] = inp;
    while (inp < ibpend)
    {
        varbinds[vindex++] = inp;

        len2 = snmpReadLength(&inp, Sequence);
        if (len2 <= 0)
            ERR_VGO("Variable", vindex, err_parse);

        inp += len2;

        if (vindex >= MAXVAR)
        {
err_toobig:
            errcode = tooBig;
            errix = 0;
            vindex = 0;
            break;
        }
    }

    if (inp > ibpend)
        ERR_GO("Whole packet size", err_parse);

    if (inp != chkp)
        ERR_GO("Variable binding size", err_parse);

    nflag = 0;
    switch (type) {
    case SetRequest:
        snmpgroup.snmpInSetRequests++;
        break;
    case GetRequest:
        snmpgroup.snmpInGetRequests++;
        break;
    case GetNextRequest:
        snmpgroup.snmpInGetNexts++;
    case GetBulkRequest:
        reps = 0;
        nflag = 1;
    default:
        break;
    };

    vindex_save = vindex;

    if (type == GetBulkRequest)
        vindex = 1;

    while ((type != GetBulkRequest && vindex) ||
           (type == GetBulkRequest && vindex <= vindex_save))
    {
        mvp = 0;
        mtp = 0;
        tabix = -1;
        soutp = outp;

        inp = varbinds[vindex - 1];
        snmpReadLength(&inp, Sequence);
        len2 = snmpReadLength(&inp, Identifier);

        if ( ( len2 <= 0 ) || ( len2 > ( ibpend - inp ) ) )
            ERR_VGO("Variable OID Length", len2, err_parse);

        for (mibix = 0; mibix < (sint16)nmibs && mvp == 0; mibix++)
        {
            mibp = mibs[mibix];

            sl1 = snmpFindOID((const uint8 **)&mvp,
                (const uint8 *)mibp->mvp, sizeof(MIBVAR), mibp->numvars(),
                inp, len2);

            ixlen = 0;

            if (nflag)
            {
                if (mvp)
                {
                    if (mvp->oid.name[mvp->oid.nlen - 1] == 0 || sl1 > 255)
                    {
try_next:
                        if (++mvp >= mibp->mvp + mibp->numvars())
                            mvp = 0;
                        else
                            sl1 = 0;
                    }
                    else
                        ixlen = len2 - mvp->oid.nlen;
                }
                else if (sl1 < 0)
                {
                    mvp = mibp->mvp;
                    ixlen = len2 - mvp->oid.nlen;
                    sl1 = 0;
                }
            }
            else if (mvp)
                ixlen = len2 - mvp->oid.nlen;

            if (mvp) {
                tabix = (sint16)mvp->oid.name[mvp->oid.nlen - 1] - 1;
                if (tabix < 0) {
                    if (sl1)
                        mvp = 0;
                }
                else {

                    if ( nflag == 0 )
                    {
                        if ( tabix < 0 || ( sl1 & 0xffff0000 ) != 0 )
                        {
                            mvp = 0;
                            continue;
                        }
                    }

                    if (ixlen < 0)
                        ixlen = 0;

                    sl1 = snmpFindOID((const uint8 **)&mtp,
                        (uint8 *)mibp->mtp, sizeof(MIBTAB), mibp->numtabs(),
                        (uint8 *)mvp->oid.name, mvp->oid.nlen - 2);

                    if (mtp == 0 || sl1) {
                        i1 = genErr;
                        ERR_VGO("No matching table for var!", sl1, err_val);
                    }

                    sl1 = snmpFindIndex(&tabix, mtp, mibp, mvp,
                        inp + mvp->oid.nlen, (uint8)ixlen,
                        nflag);

                    if (tabix < 0) {
                        if (nflag) {
                            ixlen = 0;
                            goto try_next;
                        }
                        mvp = 0;
                    }
                    else if (nflag == 0 && sl1)
                        mvp = 0;
                }
            }
        }

        if (mvp == 0) {
            if (version == 0)
                i1 = noSuchName;
            else
                i1 = 0;
            ERR_VGO("End of MIB for var", vindex, err_val);
        }

        i1 = (type == SetRequest) ? AC_WRITE : AC_READ;
        i2 = isAccessAllowed(securityName, flags, (uint8)i1, contextName, mvp);
        switch (i2) {
        case accessAllowed:
            break;
        case noSuchContext:
            if (version < 3)
                snmpgroup.snmpInBadCommunityNames++;
            else
                snmpUnknownContexts++;
        case noGroupName:
        case noAccessEntry:
        case noSuchView:
        case notInView:
        default:
            if (nflag) {
                ixlen = 0;
                goto try_next;
            }
            i1 = noAccess;
            ERR_VGO("VACM failure for var", vindex, err_val);
        }

        valp = mvp->ptr;

        if (type == SetRequest)
        {
            inp += len2;
            chkp2 = inp;

             if (mvp->type == OctetString)
                len = snmpReadLength((const uint8 **)&chkp2, (mvp->type&0x7));
             else
                len = snmpReadLength((const uint8 **)&chkp2, mvp->type);

            if (len < 0)
                ERR_VGO("Bad length field for var", vindex, err_parse);

            i1 = 0;
            if ((mvp->opt & W) == 0)
                i1 = readOnly;
            else if (mvp->type == Integer || mvp->type == Counter ||
                     mvp->type == Ticks || mvp->type == Gauge ||
                     mvp->type == OctetString)
            {
                if (len > mvp->len || len < 1)
                    i1 = wrongLength;

                if (mvp->type == Integer && *chkp2 & 0x80)
                    i3 = 0xff;
                else
                    i3 = 0;
            }
            else if (mvp->type == String)
            {
                if (len >= mvp->len)
                    i1 = wrongLength;
            }
            else if (len != mvp->len)
                i1 = wrongLength;

            if (i1)
                ERR_VGO("Incorrect length for SetRequest", vindex, err_val);
            else if (mibp->check)
            {
                i1 = mibp->check(mvp - mibp->mvp, tabix, inp);
                if (i1)
                    ERR_VGO("MIB check invalidated SetRequest", vindex, err_val);
            }
        }
        else
        {
            if ((mvp->opt & CAR) && mibp->get)
                mibp->get(mvp - mibp->mvp, tabix, &valp);
        }

        if (tabix >= 0)
        {
            if (mvp->opt & SX)
#ifdef LITTLE
                valp = (uint8 *)&tabix;
#else
                valp = (uint8 *)&tabix + sizeof(tabix) - 1;
#endif
#ifdef USSW_LLDP_MIB
            else if ((mvp->opt & (SCALAR | BASE1)) == 0)
#else
            else if ((mvp->opt & SCALAR) == 0)
#endif
                valp += mtp->len * tabix;
        }

        switch (mvp->opt & 7)
        {
        case IMMED:
            ul1 = mvp->len;
            snmpRWriteInt(&outp, ul1, mvp->type, sizeof(mvp->type));
            break;
        case IMMED2:
            ul1 = ((uint32)mvp->type << 8) + mvp->len;
            snmpRWriteInt(&outp, ul1, Integer, 2);
            break;
        case BASE1:
            if (type == SetRequest)
                *valp = *chkp2 - 1;
            snmpRWriteInt(&outp, (*valp) + 1, mvp->type, mvp->len);
            break;
        case 0:
        case SCALAR:
            cp2 = valp;
            switch (mvp->type)
            {
            case Integer:
            case Counter:
            case Ticks:
            case Gauge:
                if (type == SetRequest)
                {
                    len = snmpReadInt(&ul1, mvp->len, &inp, mvp->type);
                    if (len < 1)
                        ERR_VGO("Bad type/length field for var", vindex, err_parse);
                    i2 = (mvp->len > len) ? len : mvp->len;
                    i1 = mvp->len - i2;
#ifdef LITTLE
                    if ((mvp->opt & NWORDER) == 0)
                    {
                        while (i2--)
                        {
                            *cp2++ = ul1;
                            ul1 >>= 8;
                        }
                        while (i1--)
                            *cp2++ = (uint8)i3;
                    }
                    else
#endif
                    {
                        cp2 += mvp->len;
                        while (i2--)
                        {
                            *--cp2 = ul1;
                            ul1 >>= 8;
                        }
                        while (i1--)
                            *--cp2 = (uint8)i3;
                    }
                    cp2 = valp;
                }

                if (mvp->opt & SX)
                    ul1 = tabix + 1;
                else
                {
                    ul1 = 0;
#ifdef LITTLE
                    if ((mvp->opt & NWORDER) == 0)
                        for (i1 = mvp->len; i1--; )
                            ul1 = (ul1 << 8) + cp2[i1];
                    else
#endif
                        for (i1 = mvp->len; i1; i1--)
                            ul1 = (ul1 << 8) + *cp2++;
                }
                snmpRWriteInt(&outp, ul1, mvp->type, mvp->len);
                break;
            case String:
                cp2 = *(uint8 **)valp;
                if (type == SetRequest)
                {
                    len = snmpReadVal(cp2, mvp->len, &inp, mvp->type);
                    if (len < 0 || len > mvp->len)
                        ERR_VGO("Bad type/length field for var", vindex, err_parse);
                    cp2[len] = 0;
                }
                snmpRWriteVal(&outp, cp2, String, slength(cp2));
                break;
            default:
                if (mvp->type == OctetString)
                    i2 = String;
                else
                    i2 = mvp->type;
                if (type == SetRequest)
                {
                    len = snmpReadVal(cp2, mvp->len, &inp, i2);
                    if (len < 0 || len > mvp->len)
                        ERR_VGO("Cannot set var", vindex, err_parse);
                }
                snmpRWriteVal(&outp, valp, i2, mvp->len);
                break;
            }
            break;
        default:
            i1 = genErr;
            ERR_VGO("Invalid options for var", vindex, err_val);
        }

        if (type == SetRequest && mvp->opt & CAW && mibp->set)
        {
            i1 = mibp->set(mvp - mibp->mvp, tabix);
            if (i1 < 0)
                outp = soutp;
        }
        else
            i1 = 0;

        if (i1 < 0)
        {
            ERR_VGO("MIB set() failed", i1, err_val);
err_val:
            if (type == GetBulkRequest && reps != 0)
            {
                reps = 0;
                vindex++;
                continue;
            }
            if (!version || i1 != noSuchName)
            {
                errcode = i1;
                errix = vindex;
            }

            snmpRWriteVal(&outp, 0, version ? (nflag ? 0x82 : 0x81) : Null, 0);
            snmpRWriteVal(&outp, inp, Identifier, len2);
            mvp = 0;
        }
        else
        {
            if (tabix < 0)
                snmpRWriteVal(&outp, mvp->oid.name, Identifier, mvp->oid.nlen);
            else
            {
                chkp = outp;
                snmpEncodeIndex(&outp, mibp, mtp, tabix);
                snmpRWriteVal(&outp, mvp->oid.name, Identifier, mvp->oid.nlen);
                snmpReadLength((const uint8 **)&outp, Identifier);
                snmpRWriteLength(&outp, Identifier, chkp - outp);
            }
        }

        snmpRWriteLength(&outp, Sequence, soutp - outp);
        if (type == GetBulkRequest)
        {
            if (*obp - outp > (sint16)olen - 150)
                break;
            if (mvp && vindex > (sint16)nonrep && ++reps < maxrep)
            {
                varbinds[vindex - 1] = outp;
                continue;
            }
        }
        else if (*obp - outp > (sint16)olen - 150)
            goto err_toobig;

        if (type == GetBulkRequest) {
            reps = 0;
            vindex++;
        }
        else
            vindex--;
    }

    if (version == 0 && errcode)
    {
        i1 = ibpend - varbinds[0];
        outp = *obp - i1;
        memcpy(outp, varbinds[0], i1);
    }
    else if (type == GetBulkRequest)
    {
        uint8 *outp2;

        cp = outp;
        outp2 = bufft + SNMP_MAXSIZE;
        for (cp = outp; cp < *obp; )
        {
            cp2 = cp;
            len = snmpReadLength((const uint8 **)&cp, Sequence);
            cp += len;

            outp2 -= cp - cp2;
            memcpy(outp2, cp2, cp - cp2);
        }
        memcpy(outp, outp2, *obp - outp);

        errcode = 0;
    }

    snmpRWriteLength(&outp, Sequence, *obp - outp);
    if (errcode == 0)
        errix = 0;
    else if (version == 0)
    {
        switch (errcode)
        {
        case wrongValue:
        case wrongEncoding:
        case wrongType:
        case wrongLength:
        case inconsistentValue:
            errcode = badValue;
            break;
        case noAccess:
        case notWritable:
        case noCreation:
        case inconsistentName:
            errcode = noSuchName;
            break;
        case resourceUnavailable:
        case commitFailed:
        case undoFailed:
            errcode = genErr;
            break;
        case authorizationError:
            snmpgroup.snmpInBadCommunityUses++;
            errcode = noSuchName;
            break;
        default:
            break;
        }
    }
    snmpRWriteInt(&outp, errix, Integer, sizeof(errix));
    snmpRWriteInt(&outp, errcode, Integer, sizeof(errcode));

    switch (errcode) {
    case 0:
        if (type == SetRequest)
            snmpgroup.snmpInTotalSetVars += vindex_save;
        else
            snmpgroup.snmpInTotalReqVars += vindex_save;
        break;
    case tooBig:
        snmpgroup.snmpOutTooBigs++;
        break;
    case noSuchName:
        snmpgroup.snmpOutNoSuchNames++;
        if (version < 3 && snmpgroup.snmpEnableAuthenTraps == AUTHENTRAPSENABLED)
            ussSNMPAgentTrap(AUTHENTICATIONFAILURE, 0, contextName, 0, 0);
        break;
    case badValue:
        snmpgroup.snmpOutBadValues++;
        break;
    case readOnly:
    case genErr:
        snmpgroup.snmpOutGenErrs++;
        break;
    default:
        break;
    }

    snmpRWriteInt(&outp, reqid, Integer, sizeof(reqid));
    snmpRWriteLength(&outp, GetResponse, *obp - outp);
    snmpRWriteVal(&outp, contextName, String, slength(contextName));
    snmpRWriteInt(&outp, version, Integer, sizeof(version));
    snmpRWriteLength(&outp, Sequence, *obp - outp);

    i1 = *obp - outp;
    *obp = outp;
    return i1;
}

#ifdef USSW_LLDP_MIB
const static struct lldp_trap_data_t {
    uint32 *ptr;
    OID oid;
} lldp_trap_data[] = {
    {&lldpdMib.remTblAgeouts, {12, {0x2b,111,2,134,34,1,1,13,0,0,1,4}}},
    {&lldpdMib.remTblDrops,   {12, {0x2b,111,2,134,34,1,1,13,0,0,1,3}}},
    {&lldpdMib.remTblDeletes, {12, {0x2b,111,2,134,34,1,1,13,0,0,1,2}}},
    {&lldpdMib.remTblInserts, {12, {0x2b,111,2,134,34,1,1,13,0,0,1,1}}},
    {NULL,                    {11, {0x2b,111,2,134,34,1,1,13,0,0,1}}},
};

void ussLLDPAgentTrap(void *param)
{

}

void snmplldpdTask(int netno)
{
    static int is_send = 0;

    if (!lldp_next_sendtrap)
    {
        return;
    }

    if (TimeMS() < lldp_next_sendtrap)
    {
        return;
    }

    if (!is_send) {
        is_send = 1;
        ussLLDPAgentTrap(NULL);
        is_send = 0;
    }
}

#endif
