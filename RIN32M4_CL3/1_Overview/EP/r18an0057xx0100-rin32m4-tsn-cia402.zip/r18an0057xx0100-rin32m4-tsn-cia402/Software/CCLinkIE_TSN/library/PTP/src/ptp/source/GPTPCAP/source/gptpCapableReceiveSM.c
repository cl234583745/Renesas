/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_Macro.h"
#ifdef	PTP_USE_IEEE802_1
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"
#include "MDPdelayReq_1AS.h"
#include "gptpCapableReceiveSM.h"

#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0

static VOID gptpCapableReceive_NP( PORTDATA* pstPort );
static VOID gptpCapableReceive_00( PORTDATA* pstPort );
static VOID gptpCapableReceive_01( PORTDATA* pstPort );
static VOID gptpCapableReceive_02( PORTDATA* pstPort );

static GPTPCAPRCVSM_EV getGptpCapableReceiveEvt( USHORT usEvent );
static GPTPCAPRCVSM_ST getGptpCapableReceiveStatus( PORTDATA* pstPort );
static VOID setGptpCapableReceiveStatus( PORTDATA* pstPort, GPTPCAPTRSM_ST enSts );
static VOID (*const pfnGptpCapableReceiveMatrix[GPTPCAPRCVSM_STATUS_MAX][GPTPCAPRCVSM_EV_EVENT_MAX])(PORTDATA* pstPort) = 
{
	{&gptpCapableReceive_01, &gptpCapableReceive_NP, &gptpCapableReceive_NP, &gptpCapableReceive_00},
	{&gptpCapableReceive_01, &gptpCapableReceive_02, &gptpCapableReceive_NP, &gptpCapableReceive_00},
	{&gptpCapableReceive_01, &gptpCapableReceive_02, &gptpCapableReceive_01, &gptpCapableReceive_00}
};


static GPTPCAPRCVSM_EV getGptpCapableReceiveEvt( USHORT usEvent )
{

	GPTPCAPRCVSM_EV enEvt;
	
	enEvt = GPTPCAPRCVSM_EV_EVENT_MAX;
	
	switch ( usEvent )
	{
		case PTP_EV_BEGIN:
			enEvt = GPTPCAPRCVSM_EV_BEGIN;
			break;
		case PTP_EV_RCVDGPTPCAPTLV:
			enEvt = GPTPCAPRCVSM_EV_RCVDGPTPCAPTLV;
			break;
		case PTP_EV_RCVDGPTPCAPTLV_TMO:
			enEvt = GPTPCAPRCVSM_EV_RCVDGPTPCAPTLV_TMO;
			break;
		case PTP_EV_CLOSE:
			enEvt = GPTPCAPRCVSM_EV_CLOSE;
			break;
		default:
	        ptp_dbg_msg( D_ERR, 
	        			 ("%s::unknown ptp event. event=[%d]\n", 
	                      "getGptpCapableReceiveEvt",
	                      usEvent) );
			break;
	}
	
	return enEvt;
}
static GPTPCAPRCVSM_ST getGptpCapableReceiveStatus( PORTDATA* pstPort )
{
	GPTPCAPTRSM_ST enSts;
	
	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "getGptpCapableReceiveStatus") );
		return GPTPCAPTRSM_STATUS_MAX;
	}
	enSts = pstPort->stGPTPCapRecvSM_GD.enStsgptpCapableRecv;
	
	return enSts;

}
static VOID setGptpCapableReceiveStatus( PORTDATA* pstPort, GPTPCAPTRSM_ST enSts )
{
	
	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "setGptpCapableReceiveStatus") );
		return ;
	}
    ptp_dbg_msg( D_STATE, 
    			 ("%s::state %d->%d \n", 
                  "setGptpCapableReceiveStatus",
                  pstPort->stGPTPCapRecvSM_GD.enStsgptpCapableRecv,
                  enSts) );
	
	pstPort->stGPTPCapRecvSM_GD.enStsgptpCapableRecv = enSts;
	
	return ;
}

static VOID gptpCapableReceive_NP( PORTDATA* pstPort )
{
	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_NP::+\n") );

	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_NP::-\n") );

	return ;
}
static VOID gptpCapableReceive_00( PORTDATA* pstPort )
{
	GPTPCAPRECVSM_GD* pstRecvSM;

	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_00::+\n") );

	pstRecvSM    = &pstPort->stGPTPCapRecvSM_GD;

	if( pstRecvSM->pstTMO_GPtpCapableReceipt != NULL )
	{
		(VOID)ptp_TimeOut_Can( pstRecvSM->pstTMO_GPtpCapableReceipt );
		pstRecvSM->pstTMO_GPtpCapableReceipt = NULL;
	}

	setGptpCapableReceiveStatus( pstPort, GPTPCAPRCVSM_NONE );

	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_00::-\n") );

	return ;
}
static VOID gptpCapableReceive_01( PORTDATA* pstPort )
{
	PORT_GD*          pstPortGD;

	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_01::+\n") );

	if (pstPort->pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag == TRUE)
	{

		pstPortGD = &pstPort->stPort_GD;

		pstPortGD->blNeighborGptpCapable = FALSE;

		updateAsCapable( pstPort );
		
		setGptpCapableReceiveStatus( pstPort, GPTPCAPRCVSM_INITIALIZE );

		ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_01::-\n") );

	}
	return ;
}
static VOID gptpCapableReceive_02( PORTDATA* pstPort )
{
	GPTPCAPRECVSM_GD* pstRecvSM;
	PORT_GD*          pstPortGD;
	PORT_1AS_GD*      pstPort1AsGd;
	PORT_1AS_DS*      pstPort1AsDs;
	USCALEDNS		  stTimeoutTime;
	USCALEDNS		  stUSNs={0};
	USCALEDNS		  stUnit={0};

	PTPMSG_GPTPCAPABLE_TLV *pstTlv;

	
	
	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_02::+\n") );

	pstRecvSM    = &pstPort->stGPTPCapRecvSM_GD;
	pstPort1AsGd = &pstPort->stPort_1AS_GD;
	pstPort1AsDs = &pstPort->stPort_1AS_DS;
	pstPortGD    = &pstPort->stPort_GD;
	
	if ( pstRecvSM->pstRcvdSignalingMsgPtr == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::don't have recvice packet..\n", 
                      "gptpCapableReceive_02") );
		return ;
	}

	setGptpCapableReceiveStatus( pstPort, GPTPCAPRCVSM_RECEIVED_TLV );

	pstPortGD->blNeighborGptpCapable = TRUE;

	updateAsCapable( pstPort );

	pstTlv = (PTPMSG_GPTPCAPABLE_TLV *)&pstRecvSM->pstRcvdSignalingMsgPtr->stGptpCap_TLV;
	
	stUSNs.ulNsec_lsb = CONST10_9;
	(VOID)ptpShiftUSNs_CHAR( &stUSNs,
		               		 pstTlv->chlogGptpCapableMessageInterval,
		               		 &stUnit );

	(VOID)ptpMultUSNs_ULONG( &stUnit,
		               		 (ULONG)pstPort1AsDs->uchGPtpCapableReceiptTimeout + 1U,
		               		 &pstRecvSM->stGptpCapReceiptTimeoutTimeInt );

	ptp_GetCurrentTime( pstPort->pstClockData, &stUSNs );

	(VOID)ptpAddUSNs_USNs( &stUSNs, &pstRecvSM->stGptpCapReceiptTimeoutTimeInt, &stTimeoutTime );

	if ( pstRecvSM->pstTMO_GPtpCapableReceipt != NULL )
	{
		(VOID)ptp_TimeOut_Can( pstRecvSM->pstTMO_GPtpCapableReceipt );
		pstRecvSM->pstTMO_GPtpCapableReceipt = NULL;
	}
	
	pstRecvSM->pstTMO_GPtpCapableReceipt = ptp_TimeOut_Req( PTP_EV_RCVDGPTPCAPTLV_TMO,
														    (VOID *)pstPort, 
															stTimeoutTime, 
															(CallBackFunc)&gptpCapableReceiveSM );

	ptp_dbg_msg( D_FUNC, ("gptpCapableReceive_02::-\n") );

	return ;
}

VOID gptpCapableReceiveSM( USHORT usEvent, PORTDATA* pstPort )
{

	GPTPCAPRCVSM_EV enEvt;
	GPTPCAPRCVSM_ST enSts;

	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "gptpCapableReceiveSM") );
		return ;
	}

	enEvt = getGptpCapableReceiveEvt( usEvent );
	enSts = getGptpCapableReceiveStatus( pstPort );
	
	if (   (enEvt >= GPTPCAPRCVSM_EV_EVENT_MAX)
        || (enSts >= GPTPCAPRCVSM_STATUS_MAX) )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::unknown event ro status. event=[%d], status=[%d]\n", 
                      "gptpCapableReceiveSM",
                      enEvt,
                      enSts) );
		return ;
	}

	if (enEvt==GPTPCAPRCVSM_EV_RCVDGPTPCAPTLV_TMO)
	{
		pstPort->stGPTPCapRecvSM_GD.pstTMO_GPtpCapableReceipt = NULL;
	}

	pfnGptpCapableReceiveMatrix[enSts][enEvt]( pstPort );
	
	return ;
}
#endif
