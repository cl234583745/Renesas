//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include "net.h"
#include "local.h"
#include "msw_lldp.h"
#include "lldpd.h"

LLDPD_SETTING_T lldp_setting[] = {
    {
        "eth0",
        "",
        TRUE,
        SYSTEM_CAP_STA,
        SYSTEM_CAP_STA,

        LLDPD_NEAREST_BRIDGE_BM,
        TX_AND_RX,
        LLDPD_DEF_TX_INTERVAL,
        LLDPD_DEF_TX_HOLD,
        LLDPD_DEF_REINIT_DELAY,
        LLDPD_DEF_NOTIFIY_INTERVAL,
        LLDPD_DEF_TX_CREDIT_MAX,
        LLDPD_DEF_FAST_TX_INTERVAL,
        LLDPD_DEF_TX_FAST_INIT,
        TRUE,
        (TVLS_TX_EN_PORTDES | TVLS_TX_EN_SYSNAME | 
         TVLS_TX_EN_SYSDES  | TVLS_TX_EN_SYSCAP),

        CHA_ID_SUBTYPE_MAC,
        "",

        POR_ID_SUBTYPE_LOC,
        "Port1",


        "port0",

        "                    ",

        "                    ",


        {
            {
                1,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {8, {0x2b, 111, 2, 134, 34, 1, 1, 13}},
            },
            {
                0,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {0},
            },
            {
                0,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {0},
            }
        }
    },
    {
        "eth1",
        "eth0",
        TRUE,
        SYSTEM_CAP_STA,
        SYSTEM_CAP_STA,

        LLDPD_NEAREST_BRIDGE_BM,
        TX_AND_RX,
        LLDPD_DEF_TX_INTERVAL,
        LLDPD_DEF_TX_HOLD,
        LLDPD_DEF_REINIT_DELAY,
        LLDPD_DEF_NOTIFIY_INTERVAL,
        LLDPD_DEF_TX_CREDIT_MAX,
        LLDPD_DEF_FAST_TX_INTERVAL,
        LLDPD_DEF_TX_FAST_INIT,
        TRUE,
        (TVLS_TX_EN_PORTDES | TVLS_TX_EN_SYSNAME | 
         TVLS_TX_EN_SYSDES  | TVLS_TX_EN_SYSCAP),

        CHA_ID_SUBTYPE_MAC,
        "",

        POR_ID_SUBTYPE_LOC,
        "Port2",


        "port0",

        "                    ",

        "                    ",


        {
            {
                1,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {8, {0x2b, 111, 2, 134, 34, 1, 1, 13}},
            },
            {
                0,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {0},
            },
            {
                0,
                ADDR_SUBTYPE_IPV4,
                "",
                IF_NUM_SUBTYPE_IFINDEX,
                {0},
            }
        }
    }
};

