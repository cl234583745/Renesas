/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYRESP_H__
#define __MDPDELAYRESP_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"


#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDPdelayResp(USHORT usEvent, PORTDATA* pstPort);

MDPRESPSM_GD*	GetMDPdelayRespGlobal(PORTDATA* pstPort);
MDPDELAYRESP_EV	GetMDPdelayRespEvent(USHORT usEvent, PORTDATA* pstPort);
MDPDELAYRESP_ST	GetMDPdelayRespStatus(PORTDATA* pstPort);
VOID			SetMDPdelayRespStatus(MDPDELAYRESP_ST enSts, PORTDATA* pstPort);



VOID IncMDPDlyRespRxPDlyReqCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs );
VOID IncMDPDlyRespTxPDlyRespCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs );
VOID IncMDPDlyRespTxPDRpFllwUpCount( CMLDSPORTSTATISTICS_1AS_DS* pstCmldsPortStatDs );

BOOL	SetMDPdlyReqEvIngresTimestamp(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL	SetMDPdlyRespEvEgresTimestamp(MDPRESPSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
