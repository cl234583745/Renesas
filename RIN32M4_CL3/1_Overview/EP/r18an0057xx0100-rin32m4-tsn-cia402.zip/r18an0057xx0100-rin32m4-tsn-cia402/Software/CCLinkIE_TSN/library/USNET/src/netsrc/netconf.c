//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#include "net.h"
#include "local.h"
#include "support.h"

#ifdef  INET6
#include "net6.h"

#define NI6ADDR         3
#define NI6ROUTER       2

struct I6ADDR   i6addr1[NI6ADDR];
struct I6ROUTER i6router1[NI6ROUTER];


#define SZ(x) (sizeof(x)/sizeof((x)[0]))

struct NETDATA6 ip6data1[1] = {
    0,
    NULL,
    SZ(i6addr1),
    i6addr1,
    SZ(i6router1),
    i6router1
};

#define NETDATA6_1 ip6data1

#endif

#undef A
#undef B
#undef C
#undef X
#define A {0xff,0x00,0x00,0x00}
#define B {0xff,0xff,0x00,0x00}
#define C {0xff,0xff,0xff,0x00}
#define X {0,0,0,0}		
#define EA0 {00,00,00,00,00,00}
#define EAMSW {0xf0,0x2E,0x15,0x6C,0x77,0x00}



GLOBALCONST
const struct NETDATA netdata[]={
#ifndef LTEST
    "ussw", PORT_NAME, C, {192,168,3,250}, EAMSW, 0, Ethernet, NETDRV, 0, 0,


#else
#ifdef  INET6
    "none", "wrap", C, {127,0,0,1}, EA0, 0, Ethernet, WRAP, 0, 0, NETDATA6_1,
#else
    "ussw", "wrap", C, {127,0,0,1}, EAMSW, 0, Ethernet, WRAP, 0, 0,
#endif
#endif
};


#define NN sizeof(netdata)/sizeof(struct NETDATA)
GLOBALCONST
const int confsiz=NN;
struct NETCONF netconf[NCONFIGS];

#ifdef DNS
GLOBALCONST
const char domain[] = "ussw.com";
#endif

