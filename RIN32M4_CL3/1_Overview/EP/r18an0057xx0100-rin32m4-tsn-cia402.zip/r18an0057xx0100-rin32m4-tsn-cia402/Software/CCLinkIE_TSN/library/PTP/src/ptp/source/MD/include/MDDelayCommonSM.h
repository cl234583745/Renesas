/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYCOMMONSM_H__
#define __MDDELAYCOMMONSM_H__

#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"

#ifdef __cplusplus
extern "C" {
#endif
#ifdef	PTP_USE_TRANS
BOOL JugMDDelayCorrectionPort(PORTDATA* pstPort, USHORT *usIndex);
BOOL JugMDDelayRespCorrectionPort(PORTDATA* pstPort, USHORT *usIndex);
BOOL JugAndAddMDDelayCorrectionPort(PORTDATA* pstPort, USHORT *pusIndex);
BOOL SetMDDelayCorrectionPortIngress(PORTDATA* pstPort, USHORT usIndex);
BOOL SetMDDelayCorrectionPortEgress(PORTDATA* pstPort, USHORT usIndex);
BOOL GetMDDelayCorrectionPort(PORTDATA* pstPort, USHORT usIndex);
#endif
#ifdef __cplusplus
}
#endif

#endif
