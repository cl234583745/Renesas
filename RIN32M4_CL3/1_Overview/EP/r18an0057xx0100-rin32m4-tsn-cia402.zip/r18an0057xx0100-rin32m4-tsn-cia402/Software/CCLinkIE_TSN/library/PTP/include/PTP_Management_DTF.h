/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MANAGEMENT_DTF_H__
#define __PTP_MANAGEMENT_DTF_H__

#include "ptp_type.h"
#include "ptp_ddt.h"

#include "PortAnnounceReceiveSMGD.h"



typedef struct tagMGT_CLOCK_DESCRIPTION
{
	BYTE	        byClockType[2];
	FIXPTPTEXT		stPhyLyrProtocol;
	USHORT			usPhyAddressLength;
	UCHAR			uchPhyAddress[6];
	FIXPORTADDRESS	stProtocolAddress;
	UCHAR			uchManufacturerIdentity[3];
	UCHAR			uchReserved1;
	FIXPTPTEXT		stProductDescription;
	FIXPTPTEXT		stRevisionData;
	FIXPTPTEXT		stUserDescription;
	UCHAR			uchProfileIdentity[6];
	UCHAR			uchPad[1];

}	MGT_CLOCK_DESCRIPTION;




#define	GetMGT_CLK_DESCRIPTION_SIZE(a,b)	{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byClockType))+				\
								(sizeof((a)->stPhyLyrProtocol.uchTextLength))+	\
								((a)->stPhyLyrProtocol.uchTextLength)+				\
								(sizeof((a)->usPhyAddressLength))+		\
								((a)->usPhyAddressLength)+				\
								(sizeof((a)->stProtocolAddress.usNetworkProtcol))+	\
								(sizeof((a)->stProtocolAddress.usAddressLength))+	\
								((a)->stProtocolAddress.usAddressLength)+				\
								(sizeof((a)->uchManufacturerIdentity))+	\
								(sizeof((a)->uchReserved1))+			\
								(sizeof((a)->stProductDescription.uchTextLength))+	\
								((a)->stProductDescription.uchTextLength)+				\
								(sizeof((a)->stRevisionData.uchTextLength))+	\
								((a)->stRevisionData.uchTextLength)+			\
								(sizeof((a)->stUserDescription.uchTextLength))+	\
								((a)->stUserDescription.uchTextLength)+			\
								(sizeof((a)->uchProfileIdentity)));	\
}

#define	MGT_CLK_DESCRIPTION_CLOCKTYPE_SZ	2U
#define	MGT_CLK_DESCRIPTION_PYLYRPROT_SZ	1U
#define	MGT_CLK_DESCRIPTION_PHYADRLEN_SZ	2U
#define	MGT_CLK_DESCRIPTION_PHYADR_SZ		1U
#define	MGT_CLK_DESCRIPTION_PROTADR_SZ		5U
#define	MGT_CLK_DESCRIPTION_MANUFTID_SZ		3U
#define	MGT_CLK_DESCRIPTION_RESERVED_SZ		1U
#define	MGT_CLK_DESCRIPTION_PRODUCTDC_SZ	1U
#define	MGT_CLK_DESCRIPTION_REVISION_SZ		1U
#define	MGT_CLK_DESCRIPTION_USERDC_SZ		1U
#define	MGT_CLK_DESCRIPTION_PROFID_SZ		6U

#define	MGT_CLK_DESCRIPTION_SZ				(MGT_CLK_DESCRIPTION_CLOCKTYPE_SZ + \
											MGT_CLK_DESCRIPTION_PYLYRPROT_SZ + \
											MGT_CLK_DESCRIPTION_PHYADRLEN_SZ + \
											MGT_CLK_DESCRIPTION_PHYADR_SZ + \
											MGT_CLK_DESCRIPTION_PROTADR_SZ + \
											MGT_CLK_DESCRIPTION_MANUFTID_SZ + \
											MGT_CLK_DESCRIPTION_RESERVED_SZ + \
											MGT_CLK_DESCRIPTION_PRODUCTDC_SZ + \
											MGT_CLK_DESCRIPTION_REVISION_SZ + \
											MGT_CLK_DESCRIPTION_USERDC_SZ + \
											MGT_CLK_DESCRIPTION_PROFID_SZ)



typedef struct tagMGT_USER_DESCRIPTION
{
	FIXPTPTEXT		stUserDescription;
	UCHAR			uchPad[1];

}	MGT_USER_DESCRIPTION;

#define	GetMGT_USER_DESCRIPTION_SIZE(a,b)	{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->stUserDescription.uchTextLength))+	\
								((a)->stUserDescription.uchTextLength));			\
}

#define	MGT_USR_DESCRIPTION_USR_DESC_SZ		1U

#define	MGT_USR_DESCRIPTION_SZ				MGT_USR_DESCRIPTION_USR_DESC_SZ


typedef struct tagMGT_INITIALIZE
{
	USHORT			usInitialKey;

}	MGT_INITIALIZE;

#define	MGT_INITIALIZE_INITKEY_SZ		1U

#define	MGT_INITIALIZE_SZ				MGT_INITIALIZE_INITKEY_SZ

typedef struct tagMGT_FAULT_RECORD
{
	USHORT				usFaultRecordLength;
	TIMESTAMP			stFaultTimestamp;
	UCHAR				uchSeverityCode;
	LOGPTPTEXT_1		stFaultName;
	LOGPTPTEXT_2		stFaultValue;
	LOGPTPTEXT_3		stFaultDescription;

}	MGT_FAULT_RECORD;
#define	GetMGT_FAULT_RECORD_SIZE(a,b)	{					\
								(b) = (						\
								(sizeof((a)->usFaultRecordLength))+	\
								(sizeof((a)->stFaultTimestamp.stSeconds.usSec_msb))+	\
								(sizeof((a)->stFaultTimestamp.stSeconds.ulSec_lsb))+	\
								(sizeof((a)->stFaultTimestamp.ulNanoseconds))+			\
								(sizeof((a)->uchSeverityCode))+		\
								(sizeof((a)->stFaultName.uchTextLength))+		\
								(a)->stFaultName.uchTextLength+					\
								(sizeof((a)->stFaultValue.uchTextLength))+		\
								(a)->stFaultValue.uchTextLength+					\
								(sizeof((a)->stFaultDescription.uchTextLength))+	\
								(a)->stFaultDescription.uchTextLength);			\
}
#if 1
#define	MGT_FAULTRECORDS	50
#endif

#define	MGT_FAULT_RECORD_FLTRCDLEN_SZ		2u
#define	MGT_FAULT_RECORD_FLTTIMSTAMP_SZ		10u
#define	MGT_FAULT_RECORD_SEVCODE_SZ			1u
#define	MGT_FAULT_RECORD_FAULTNAME_SZ		1u
#define	MGT_FAULT_RECORD_FAULTVALUE_SZ		1u
#define	MGT_FAULT_RECORD_FAULTDESC_SZ		1u

#define	MGT_FAULT_RECORD_SZ					(MGT_FAULT_RECORD_FLTRCDLEN_SZ + \
											MGT_FAULT_RECORD_FLTTIMSTAMP_SZ + \
											MGT_FAULT_RECORD_SEVCODE_SZ + \
											MGT_FAULT_RECORD_FAULTNAME_SZ + \
											MGT_FAULT_RECORD_FAULTVALUE_SZ + \
											MGT_FAULT_RECORD_FAULTDESC_SZ)

typedef struct tagMGT_FAULT_LOG
{
	USHORT				usNumOfFaultRecords;
	MGT_FAULT_RECORD	stFaultRecords[MGT_FAULTRECORDS];
	UCHAR				uchPad[1];

}	MGT_FAULT_LOG;

#define	GetMGT_FAULT_LOG_SIZE(a,b)	{									\
								(b) = 0;								\
								(b) = (									\
								(sizeof((a)->usNumOfFaultRecords)));	\
}

#define	MGT_FAULT_LOG_NUMOFFLTREC_SZ		2u

#define	MGT_FAULT_LOG_SZ					MGT_FAULT_LOG_NUMOFFLTREC_SZ

typedef struct tagMGT_DEFAULT_DATA_SET
{
	BYTE	        byFlags;
	UCHAR			uchReserved1;
	USHORT			usNumPorts;
	UCHAR			uchPriority1;
	CLOCKQUALITY	stClockQuality;
	UCHAR			uchPriority2;
	CLOCKIDENTITY	stClockIdentity;
	UCHAR			uchDomainNum;
	UCHAR			uchReserved2;

}	MGT_DEFAULT_DATA_SET;


#define	GetMGT_DEFAULT_DS_SIZE(a,b)			{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchReserved1))+	\
								(sizeof((a)->usNumPorts))+		\
								(sizeof((a)->uchPriority1))+	\
								(sizeof((a)->stClockQuality.uchClockClass))+				\
								(sizeof((a)->stClockQuality.uchClockAccuracy))+				\
								(sizeof((a)->stClockQuality.usOffsetScaledLogVariance))+	\
								(sizeof((a)->uchPriority2))+	\
								(sizeof((a)->stClockIdentity.uchId))+	\
								(sizeof((a)->uchDomainNum))+		\
								(sizeof((a)->uchReserved2)));	\
}


#define	MGT_DEFAULT_DS_COMFLG_SZ			1U
#define	MGT_DEFAULT_DS_RESERVED1_SZ			1U
#define	MGT_DEFAULT_DS_NUMPORTS_SZ			2U
#define	MGT_DEFAULT_DS_PRIORITY1_SZ			1U
#define	MGT_DEFAULT_DS_CLKQUALLITY_SZ		4U
#define	MGT_DEFAULT_DS_PRIORITY2_SZ			1U
#define	MGT_DEFAULT_DS_CLOCKID_SZ			8U
#define	MGT_DEFAULT_DS_DOMAINNUM			1U
#define	MGT_DEFAULT_DS_RESERVED2			1U

#define	MGT_DEFAULT_DS_SZ					(MGT_DEFAULT_DS_COMFLG_SZ + \
											MGT_DEFAULT_DS_RESERVED1_SZ + \
											MGT_DEFAULT_DS_NUMPORTS_SZ + \
											MGT_DEFAULT_DS_PRIORITY1_SZ + \
											MGT_DEFAULT_DS_CLKQUALLITY_SZ + \
											MGT_DEFAULT_DS_PRIORITY2_SZ + \
											MGT_DEFAULT_DS_CLOCKID_SZ + \
											MGT_DEFAULT_DS_DOMAINNUM + \
											MGT_DEFAULT_DS_RESERVED2)

typedef struct tagMGT_CURRENT_DATA_SET
{
	USHORT			usStepsRemoved;
	TIME_INTERVAL	stOffsetFromMaster;
	TIME_INTERVAL	stMeanPathDelay;

}	MGT_CURRENT_DATA_SET;

#define	GetMGT_CURRENT_DS_SIZE(a,b)			{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->usStepsRemoved))+	\
								(sizeof((a)->stOffsetFromMaster.sNsec_msb))+	\
								(sizeof((a)->stOffsetFromMaster.ulNsec_lsb))+	\
								(sizeof((a)->stOffsetFromMaster.usFrcNsec))+	\
								(sizeof((a)->stMeanPathDelay.sNsec_msb))+		\
								(sizeof((a)->stMeanPathDelay.ulNsec_lsb))+		\
								(sizeof((a)->stMeanPathDelay.usFrcNsec)));	\
}

#define	MGT_CURRENT_DS_STEPSREMOVED_SZ		2u
#define	MGT_CURRENT_DS_OFSFRMMASTER_SZ		8u
#define	MGT_CURRENT_DS_MEANPATHDELAY_SZ		8u

#define	MGT_CURRENT_DS_SZ					(MGT_CURRENT_DS_STEPSREMOVED_SZ + \
											MGT_CURRENT_DS_OFSFRMMASTER_SZ + \
											MGT_CURRENT_DS_MEANPATHDELAY_SZ)


typedef struct tagMGT_PARENT_DATA_SET
{
	PORTIDENTITY	stPrntPortIdentity;
	BYTE	        byFlags;
	UCHAR			uchReserved1;
	USHORT			usObsPrentOfsetScalLogVrnc;
	LONG			lObsPrentClockPhsChngRate;
	UCHAR			uchGMasterPriority1;
	CLOCKQUALITY	stGMasterClockQuality;
	UCHAR			uchGMasterPriority2;
	CLOCKIDENTITY	stGMasterIdentity;

}	MGT_PARENT_DATA_SET;

#define	GetMGT_PARENT_DS_SIZE(a,b)			{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->stPrntPortIdentity.stClockIdentity.uchId))+	\
								(sizeof((a)->stPrntPortIdentity.usPortNumber))+				\
								(sizeof((a)->byFlags))+						\
								(sizeof((a)->uchReserved1))+				\
								(sizeof((a)->usObsPrentOfsetScalLogVrnc))+	\
								(sizeof((a)->lObsPrentClockPhsChngRate))+	\
								(sizeof((a)->uchGMasterPriority1))+			\
								(sizeof((a)->stGMasterClockQuality.uchClockClass))+				\
								(sizeof((a)->stGMasterClockQuality.uchClockAccuracy))+			\
								(sizeof((a)->stGMasterClockQuality.usOffsetScaledLogVariance))+	\
								(sizeof((a)->uchGMasterPriority2))+			\
								(sizeof((a)->stGMasterIdentity.uchId)));	\
}

#define	MGT_PARENT_DS_PARENTPTID_SZ			10u
#define	MGT_PARENT_DS_FLAGS_SZ				1u
#define	MGT_PARENT_DS_RESERVED1_SZ			1u
#define	MGT_PARENT_DS_OBSPOFSSCLLGVAR_SZ	2u
#define	MGT_PARENT_DS_ObSPCLKPHSCHGRT_SZ	4u
#define	MGT_PARENT_DS_GRMSPRIORITY1_SZ		1u
#define	MGT_PARENT_DS_GRMSCLKQUALITY_SZ		4u
#define	MGT_PARENT_DS_GRMSPRIORITY2_SZ		1u
#define	MGT_PARENT_DS_GRMSIDENTITY_SZ		8u

#define	MGT_PARENT_DS_SZ					(MGT_PARENT_DS_PARENTPTID_SZ + \
											MGT_PARENT_DS_FLAGS_SZ + \
											MGT_PARENT_DS_RESERVED1_SZ + \
											MGT_PARENT_DS_OBSPOFSSCLLGVAR_SZ + \
											MGT_PARENT_DS_ObSPCLKPHSCHGRT_SZ + \
											MGT_PARENT_DS_GRMSPRIORITY1_SZ + \
											MGT_PARENT_DS_GRMSCLKQUALITY_SZ + \
											MGT_PARENT_DS_GRMSPRIORITY2_SZ + \
											MGT_PARENT_DS_GRMSIDENTITY_SZ)


typedef struct tagMGT_TIME_PROPERTIES_DATA_SET
{
	SHORT			sCrentUtcOffset;
	BYTE	        byFlags;
	UCHAR			uchTimeSource;
	UCHAR			uchReserved;

}	MGT_TIME_PROPERTIES_DATA_SET;

#define	GetMGT_TIMEPRPRTS_DS_SIZE(a,b)			{				\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->sCrentUtcOffset))+	\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchTimeSource))+	\
								(sizeof((a)->uchReserved)));	\
}


#define	MGT_TIMEPRPRTS_DS_CRTUTCOFS_SZ		2u
#define	MGT_TIMEPRPRTS_DS_FLAGS_SZ			1u
#define	MGT_TIMEPRPRTS_DS_TIMESOURCE_SZ		1u

#define	MGT_TIMEPRPRTS_DS_SZ				(MGT_TIMEPRPRTS_DS_CRTUTCOFS_SZ + \
											MGT_TIMEPRPRTS_DS_FLAGS_SZ + \
											MGT_TIMEPRPRTS_DS_TIMESOURCE_SZ)

typedef struct tagMGT_PORT_DATA_SET
{
	PORTIDENTITY	stPortIdentity;
	UCHAR			uchPortState;
	CHAR			chLogMinDReqInterval;
	TIME_INTERVAL	stPerMeanPathDelay;
	CHAR			chLogAnounceInterval;
	UCHAR			uchAnounceRcptTimeout;
	CHAR			chLogSyncInterval;
	UCHAR			uchDelayMechanism;
	CHAR			chLogMinPDReqInterval;
	BYTE			byVerNum;

}	MGT_PORT_DATA_SET;

#define	GetMGT_PORT_DS_SIZE(a,b)			{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->stPortIdentity.stClockIdentity.uchId))+	\
								(sizeof((a)->stPortIdentity.usPortNumber))+				\
								(sizeof((a)->uchPortState))+			\
								(sizeof((a)->chLogMinDReqInterval))+	\
								(sizeof((a)->stPerMeanPathDelay.sNsec_msb))+	\
								(sizeof((a)->stPerMeanPathDelay.ulNsec_lsb))+	\
								(sizeof((a)->stPerMeanPathDelay.usFrcNsec))+	\
								(sizeof((a)->chLogAnounceInterval))+	\
								(sizeof((a)->uchAnounceRcptTimeout))+	\
								(sizeof((a)->chLogSyncInterval))+		\
								(sizeof((a)->uchDelayMechanism))+		\
								(sizeof((a)->chLogMinPDReqInterval))+	\
								(sizeof((a)->byVerNum)));				\
}

#define	MGT_PORT_DS_PORTID_SZ				10u
#define	MGT_PORT_DS_PORTSTAT_SZ				1u
#define	MGT_PORT_DS_LOGMINDREQINT_SZ		1u
#define	MGT_PORT_DS_PERMEANPATDLY_SZ		8u
#define	MGT_PORT_DS_LOGANOINT_SZ			1u
#define	MGT_PORT_DS_ANORCPTTMO_SZ			1u
#define	MGT_PORT_DS_LOGSYNCINT_SZ			1u
#define	MGT_PORT_DS_DELAYMECHANISM_SZ		1u
#define	MGT_PORT_DS_LOGMINPDRREQINT_SZ		1u
#define	MGT_PORT_DS_VERNUM_SZ				1u

#define	MGT_PORT_DS_SZ						(MGT_PORT_DS_PORTID_SZ + \
											MGT_PORT_DS_PORTSTAT_SZ + \
											MGT_PORT_DS_LOGMINDREQINT_SZ + \
											MGT_PORT_DS_PERMEANPATDLY_SZ + \
											MGT_PORT_DS_LOGANOINT_SZ * \
											MGT_PORT_DS_ANORCPTTMO_SZ + \
											MGT_PORT_DS_LOGSYNCINT_SZ + \
											MGT_PORT_DS_DELAYMECHANISM_SZ + \
											MGT_PORT_DS_LOGMINPDRREQINT_SZ + \
											MGT_PORT_DS_VERNUM_SZ)
				

typedef struct tagMGT_PRIORITY1
{
	UCHAR			uchPriority1;
	UCHAR			uchReserved1;

}	MGT_PRIORITY1;

#define	GetMGT_PRIORITY1_DS_SIZE(a,b)		{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->uchPriority1))+	\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_PRIORITY1_PRIORITY1_SZ			1u
#define	MGT_PRIORITY1_RESERVED1_SZ			1u

#define	MGT_PRIORITY1_SZ					(MGT_PRIORITY1_PRIORITY1_SZ + \
											MGT_PRIORITY1_RESERVED1_SZ)

typedef struct tagMGT_PRIORITY2
{
	UCHAR			uchPriority2;
	UCHAR			uchReserved1;

}	MGT_PRIORITY2;

#define	GetMGT_PRIORITY2_DS_SIZE(a,b)		{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->uchPriority2))+	\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_PRIORITY2_PRIORITY2_SZ			1u
#define	MGT_PRIORITY2_RESERVED1_SZ			1u

#define	MGT_PRIORITY2_SZ					(MGT_PRIORITY2_PRIORITY2_SZ + \
											MGT_PRIORITY2_RESERVED1_SZ)

typedef struct tagMGT_DOMAIN
{
	UCHAR			uchDomainNum;
	UCHAR			uchReserved1;

}	MGT_DOMAIN;

#define	GetMGT_DOMAIN_DS_SIZE(a,b)		{						\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->uchDomainNum))+		\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_DOMAIN_DOMAINNUM_SZ				1u
#define	MGT_DOMAIN_RESERVED1_SZ				1u

#define	MGT_DOMAIN_SZ						(MGT_DOMAIN_DOMAINNUM_SZ + \
											MGT_DOMAIN_RESERVED1_SZ)

typedef struct tagMGT_SLAVE_ONLY
{
	BYTE	        byFlags;
	UCHAR			uchReserved1;

}	MGT_SLAVE_ONLY;

#define	GetMGT_SLAVE_ONLY_DS_SIZE(a,b)	{						\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchReserved1)));	\
}


#define	MGT_SLAVE_ONLY_FLAGS_SZ				1u
#define	MGT_SLAVE_ONLY_RESERVED1_SZ			1u

#define	MGT_SLAVE_ONLY_SZ					(MGT_SLAVE_ONLY_FLAGS_SZ + \
											MGT_SLAVE_ONLY_RESERVED1_SZ)

typedef struct tagMGT_LOG_ANNOUNCE_INTERVAL
{
	CHAR			chLogAnounceInterval;
	UCHAR			uchReserved1;

}	MGT_LOG_ANNOUNCE_INTERVAL;

#define	GetMGT_LOG_ANNOUINTVAL_DS_SIZE(a,b)	{							\
								(b) = 0;								\
								(b) = (									\
								(sizeof((a)->chLogAnounceInterval))+	\
								(sizeof((a)->uchReserved1)));			\
}

#define	MGT_LOG_ANNOUINTVAL_LOGANOINT_SZ	1u
#define	MGT_LOG_ANNOUINTVAL_RESERVED1_SZ	1u

#define	MGT_LOG_ANNOUINTVAL_SZ				(MGT_LOG_ANNOUINTVAL_LOGANOINT_SZ + \
											MGT_LOG_ANNOUINTVAL_RESERVED1_SZ)

typedef struct tagMGT_ANNOUNCE_RECEIPT_TIMEOUT
{
	UCHAR			uchAnounceRcptTimeout;
	UCHAR			uchReserved1;

}	MGT_ANNOUNCE_RECEIPT_TIMEOUT;

#define	GetMGT_ANNOU_RCPTTMOUT_DS_SIZE(a,b)	{							\
								(b) = 0;								\
								(b) = (									\
								(sizeof((a)->uchAnounceRcptTimeout))+	\
								(sizeof((a)->uchReserved1)));			\
}

#define	MGT_ANNOU_RCPTTMOUT_ANORCPTMO_SZ	1u
#define	MGT_ANNOU_RCPTTMOUT_RESERVED1_SZ	1u

#define	MGT_ANNOU_RCPTTMOUT_SZ				(MGT_LOG_ANNOUINTVAL_LOGANOINT_SZ + \
											MGT_LOG_ANNOUINTVAL_RESERVED1_SZ)

typedef struct tagMGT_LOG_SYNC_INTERVAL
{
	CHAR			chLogSyncInterval;
	UCHAR			uchReserved1;

}	MGT_LOG_SYNC_INTERVAL;

#define	GetMGT_LOG_SYNCINTVAL_DS_SIZE(a,b)	{						\
								(b) = 0;							\
								(b) = (								\
								(sizeof((a)->chLogSyncInterval))+	\
								(sizeof((a)->uchReserved1)));		\
}

#define	MGT_LOG_SYNCINTVAL_LOGSYNCINT_SZ	1u
#define	MGT_LOG_SYNCINTVAL_RESERVED1_SZ		1u

#define	MGT_LOG_SYNCINTVAL_SZ				(MGT_LOG_SYNCINTVAL_LOGSYNCINT_SZ + \
											MGT_LOG_SYNCINTVAL_RESERVED1_SZ)


typedef struct tagMGT_VERSION_NUMBER
{
	BYTE			byVerNum;
	UCHAR			uchReserved1;

}	MGT_VERSION_NUMBER;

#define	GetMGT_VERSION_NUM_DS_SIZE(a,b)		{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byVerNum))+		\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_VERSION_NUM_VERNUM_SZ			1u
#define	MGT_VERSION_NUM_RESERVED1_SZ		1u

#define	MGT_VERSION_NUM_SZ					(MGT_VERSION_NUM_VERNUM_SZ + \
											MGT_VERSION_NUM_RESERVED1_SZ)

typedef struct tagMGT_TIME
{
	TIMESTAMP	stTime;

}	MGT_TIME;

#define	GetMGT_TIME_DS_SIZE(a,b)		{									\
								(b) = 0;									\
								(b) = (										\
								(sizeof((a)->stTime.stSeconds.usSec_msb))+	\
								(sizeof((a)->stTime.stSeconds.ulSec_lsb))+	\
								(sizeof((a)->stTime.ulNanoseconds)));		\
}

#define	MGT_TIME_TIME_SZ					10u

#define	MGT_TIME_SZ							(MGT_TIME_TIME_SZ)

typedef struct tagMGT_CLOCK_ACCURACY
{
	UCHAR			uchClockAccuracy;
	UCHAR			uchReserved1;

}	MGT_CLOCK_ACCURACY;

#define	GetMGT_CLKACC_DS_SIZE(a,b)		{							\
								(b) = 0;							\
								(b) = (								\
								(sizeof((a)->uchClockAccuracy))+	\
								(sizeof((a)->uchReserved1)));		\
}

#define	MGT_CLKACC_CLKACC_SZ				1u
#define	MGT_CLKACC_RESERVED1_SZ				1u

#define	MGT_CLKACC_SZ						(MGT_CLKACC_CLKACC_SZ + \
											MGT_CLKACC_RESERVED1_SZ)

typedef struct tagMGT_UTC_PROPERTIES
{
	SHORT			sCrentUtcOffset;
	BYTE	        byFlags;
	UCHAR			uchReserved1;
}	MGT_UTC_PROPERTIES;

#define	GetMGT_UTC_PRPRTS_DS_SIZE(a,b)		{						\
								(b) = 0;							\
								(b) = (								\
								(sizeof((a)->sCrentUtcOffset))+		\
								(sizeof((a)->byFlags))+				\
								(sizeof((a)->uchReserved1)));		\
}

#define	MGT_UTC_PROPERTIES_CRTUTCOFS_SZ		2u
#define	MGT_UTC_PROPERTIES_FLAGS_SZ			1u
#define	MGT_UTC_PROPERTIES_RESERVED1_SZ		1u

#define	MGT_UTC_PROPERTIES_SZ				(MGT_UTC_PROPERTIES_CRTUTCOFS_SZ + \
											MGT_UTC_PROPERTIES_FLAGS_SZ + \
											MGT_UTC_PROPERTIES_RESERVED1_SZ)

typedef struct tagMGT_TRACEABILITY_PROPERTIES
{
	BYTE	        byFlags;
	UCHAR			uchReserved1;

}	MGT_TRACEABILITY_PROPERTIES;

#define	GetMGT_TRACEBLTY_PRPRTS_DS_SIZE(a,b)	{				\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_TRACEBLTY_PRPRTS_FLAGS_SZ		1u
#define	MGT_TRACEBLTY_PRPRTS_RESV1_SZ		1u

#define	MGT_TRACEBLTY_PRPRTS_SZ				(MGT_TRACEBLTY_PRPRTS_FLAGS_SZ + \
											MGT_TRACEBLTY_PRPRTS_RESV1_SZ)

typedef struct tagMGT_TIMESCALE_PROPERTIES
{
	BYTE	        byFlags;
	UCHAR			uchTimeSource;

}	MGT_TIMESCALE_PROPERTIES;

#define	GetMGT_TMSCALE_PRPRTS_DS_SIZE(a,b)	{					\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchTimeSource)));	\
}

#define	MGT_TMSCALE_PRPRTS_FLAGS_SZ			1u
#define	MGT_TMSCALE_PRPRTS_TIMSRC_SZ		1u

#define	MGT_TMSCALE_PRPRTS_SZ				(MGT_TMSCALE_PRPRTS_FLAGS_SZ + \
											MGT_TMSCALE_PRPRTS_TIMSRC_SZ)

typedef struct tagMGT_UNICAST_NEGO_ENABLE
{
	BYTE	        byFlags;
	UCHAR			uchReserved1;

}	MGT_UNICAST_NEGO_ENABLE;

#define	MGT_TMSCALE_PRPRTS_FLAGS_SZ			1u
#define	MGT_TMSCALE_PRPRTS_TIMSRC_SZ		1u

#define	MGT_TMSCALE_PRPRTS_SZ				(MGT_TMSCALE_PRPRTS_FLAGS_SZ + \
											MGT_TMSCALE_PRPRTS_TIMSRC_SZ)

typedef struct tagMGT_PATH_TRACE_LIST
{
	USHORT			usPathSequenceNum;
	CLOCKIDENTITY	stPathSequence[ALLOWED_STEPSREMOVED];

}	MGT_PATH_TRACE_LIST;

#define	MGT_PATH_TRACE_LST_PATHSEQNM_SZ			1u

#define	MGT_PATH_TRACE_LST_SZ				(MGT_PATH_TRACE_LST_PATHSEQNM_SZ)

typedef struct tagMGT_PATH_TRACE_ENABLE
{
	BYTE	        byFlags;
	UCHAR			uchReserved1;

}	MGT_PATH_TRACE_ENABLE;

#define	GetMGT_PATH_TRACEENABLE_DS_SIZE(a,b)	{				\
								(b) = 0;						\
								(b) = (							\
								(sizeof((a)->byFlags))+			\
								(sizeof((a)->uchReserved1)));	\
}

#define	MGT_PATH_TRACEENABLE_FLAGS_SZ		1u
#define	MGT_PATH_TRACEENABLE_RESERVED_SZ	1u

#define	MGT_PATH_TRACEENABLE_SZ				(MGT_PATH_TRACEENABLE_FLAGS_SZ + \
											MGT_PATH_TRACEENABLE_RESERVED_SZ)

typedef struct tagMGT_GRANDMS_CLUSTER_TABLE
{
	CHAR			chLogQueryInterval;
	UCHAR			uchTableSize;
	FIXPORTADDRESS	stGMClusterMembers[16];
	UCHAR			uchPad[1];

}	MGT_GRANDMS_CLUSTER_TABLE;

#define	MGT_GRANDMS_CLUSTER_LOGQURINT_SZ	1u
#define	MGT_GRANDMS_CLUSTER_TBLSZ_SZ		1u

#define	MGT_GRANDMS_CLUSTER_SZ				(MGT_GRANDMS_CLUSTER_LOGQURINT_SZ + \
											MGT_GRANDMS_CLUSTER_TBLSZ_SZ)

typedef struct tagMGT_UNICAST_MASTER_TABLE
{
	CHAR			chLogQueryInterval;
	USHORT			usTableSize;
	FIXPORTADDRESS	stUnicastMasterTable[16];
	UCHAR			uchPad[1];

}	MGT_UNICAST_MASTER_TABLE;

#define	MGT_UNICAST_MASTER_LOGQURINT_SZ		1u
#define	MGT_UNICAST_MASTER_TBLSZ_SZ			2u

#define	MGT_UNICAST_MASTER_SZ				(MGT_UNICAST_MASTER_LOGQURINT_SZ + \
											MGT_UNICAST_MASTER_TBLSZ_SZ)

typedef struct tagMGT_UNICASTMS_MAX_TABLE_SZ
{
	USHORT			usMaxTableSize;

}	MGT_UNICASTMS_MAX_TABLE_SZ;

#define	MGT_UNICASTMS_MAX_MAXTBLSZ_SZ		1u

#define	MGT_UNICASTMS_MAX_SZ				(MGT_UNICASTMS_MAX_MAXTBLSZ_SZ)

typedef struct tagMGT_PORT_STATISTICS_COUNT
{
	ULONG			ulRxSyncCount;
	ULONG			ulRxOneStepSyncCount;
	ULONG			ulRxFollowUpCount;
	ULONG			ulRxAnnounceCount;
	ULONG			ulRxPTPPacketDiscardCount;
	ULONG			ulSyncReceiptTimeoutCount;
	ULONG			ulAnnounceReceiptTimeoutCount;
	ULONG			ulTxSyncCount;
	ULONG			ulTxOneStepSyncCount;
	ULONG			ulTxFollowUpCount;
	ULONG			ulTxAnnounceCount;

}	MGT_PORT_STATISTICS_COUNT;

#define	GetMGT_PORT_STATIS_DS_SIZE(a,b)	{									\
								(b) = 0;									\
								(b) = (											\
								(sizeof((a)->ulRxSyncCount))+					\
								(sizeof((a)->ulRxOneStepSyncCount))+			\
								(sizeof((a)->ulRxFollowUpCount))+				\
								(sizeof((a)->ulRxAnnounceCount))+				\
								(sizeof((a)->ulRxPTPPacketDiscardCount))+		\
								(sizeof((a)->ulSyncReceiptTimeoutCount))+		\
								(sizeof((a)->ulAnnounceReceiptTimeoutCount))+	\
								(sizeof((a)->ulTxSyncCount))+					\
								(sizeof((a)->ulTxOneStepSyncCount))+			\
								(sizeof((a)->ulTxFollowUpCount))+				\
								(sizeof((a)->ulTxAnnounceCount)));				\
}

#define	MGT_PORT_STAT_CNT_RXSYNCNT_SZ		4u
#define	MGT_PORT_STAT_CNT_RXONESYNCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_RXFLOWUPCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_RXANOCNT_SZ		4u
#define	MGT_PORT_STAT_CNT_RXPKTDSCCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_SYNRTTMOCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_ANORTTMOCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_TCSYNCNT_SZ		4u
#define	MGT_PORT_STAT_CNT_TXONESYNCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_TXFLOWUPCNT_SZ	4u
#define	MGT_PORT_STAT_CNT_TXANOCNT_SZ		4u

#define	MGT_PORT_STAT_CNT_SZ				(MGT_PORT_STAT_CNT_RXSYNCNT_SZ + \
											MGT_PORT_STAT_CNT_RXONESYNCNT_SZ + \
											MGT_PORT_STAT_CNT_RXFLOWUPCNT_SZ + \
											MGT_PORT_STAT_CNT_RXANOCNT_SZ + \
											MGT_PORT_STAT_CNT_RXPKTDSCCNT_SZ + \
											MGT_PORT_STAT_CNT_SYNRTTMOCNT_SZ + \
											MGT_PORT_STAT_CNT_ANORTTMOCNT_SZ * \
											MGT_PORT_STAT_CNT_TCSYNCNT_SZ + \
											MGT_PORT_STAT_CNT_TXONESYNCNT_SZ + \
											MGT_PORT_STAT_CNT_TXFLOWUPCNT_SZ + \
											MGT_PORT_STAT_CNT_TXANOCNT_SZ)

typedef struct tagMGT_CMLD_PORT_STATIS_COUNT
{
	ULONG			ulRxPDReqCount;
	ULONG			ulRxPDRespCount;
	ULONG			ulRxPDRespFollowUpCount;
	ULONG			ulRxPTPPacketDiscardCount;
	ULONG			ulPDAllowedLostRespExceedCount;
	ULONG			ulTxPDReqCount;
	ULONG			ulTxPDRespCount;
	ULONG			ulTxPDRespFollowUpCount;

}	MGT_CMLD_PORT_STATIS_COUNT;

#define	GetMGT_CMLDPORT_STATIS_DS_SIZE(a,b)	{									\
								(b) = 0;										\
								(b) = (											\
								(sizeof((a)->ulRxPDReqCount))+					\
								(sizeof((a)->ulRxPDRespCount))+					\
								(sizeof((a)->ulRxPDRespFollowUpCount))+			\
								(sizeof((a)->ulRxPTPPacketDiscardCount))+		\
								(sizeof((a)->ulPDAllowedLostRespExceedCount))+	\
								(sizeof((a)->ulTxPDReqCount))+					\
								(sizeof((a)->ulTxPDRespCount))+					\
								(sizeof((a)->ulTxPDRespFollowUpCount)));		\
}

#define	MGT_CMLDPORT_STAT_RXPDREQCNT_SZ		4u
#define	MGT_CMLDPORT_STAT_RXPDRSPCNT_SZ		4u
#define	MGT_CMLDPORT_STAT_RXPDRSPWCNT_SZ	4u
#define	MGT_CMLDPORT_STAT_RXPKTDSCCNT_SZ	4u
#define	MGT_CMLDPORT_STAT_PDALWLSTCNT_SZ	4u
#define	MGT_CMLDPORT_STAT_TXPDREQCNT_SZ		4u
#define	MGT_CMLDPORT_STAT_TXPDRESPCNT_SZ	4u
#define	MGT_CMLDPORT_STAT_TXPDRSPFCNT_SZ	4u

#define	MGT_CMLDPORT_STAT_SZ				(MGT_CMLDPORT_STAT_RXPDREQCNT_SZ + \
											MGT_CMLDPORT_STAT_RXPDRSPCNT_SZ + \
											MGT_CMLDPORT_STAT_RXPDRSPWCNT_SZ + \
											MGT_CMLDPORT_STAT_RXPKTDSCCNT_SZ + \
											MGT_CMLDPORT_STAT_PDALWLSTCNT_SZ + \
											MGT_CMLDPORT_STAT_TXPDREQCNT_SZ * \
											MGT_CMLDPORT_STAT_TXPDRESPCNT_SZ + \
											MGT_CMLDPORT_STAT_TXPDRSPFCNT_SZ)

typedef struct tagMGT_PORT_STATISTICS_ERRCOUNT
{
	ULONG			ulTxMessageErrCount;

}	MGT_PORT_STATISTICS_ERRCOUNT;

#define	GetMGT_PORT_STATISER_DS_SIZE(a,b)	{							\
								(b) = 0;								\
								(b) = (									\
								(sizeof((a)->ulTxMessageErrCount)));	\
}

#define	MGT_PORT_STAI_ERCNT_TXERCNT_SZ		4u

#define	MGT_PORT_STAI_ERCNT_SZ				(MGT_PORT_STAI_ERCNT_TXERCNT_SZ)

typedef struct tagMGT_TCLK_DEFAULT_DATA_SET
{
	CLOCKIDENTITY	stClockIdentity;
	USHORT			usNumberPorts;
	UCHAR			uchDelayMechanism;
	UCHAR			uchPrimaryDomain;

}	MGT_TCLK_DEFAULT_DATA_SET;

#define	GetMGT_TCLK_DEFAULT_DS_SIZE(a,b)	{							\
								(b) = 0;								\
								(b) = (									\
								(sizeof((a)->stClockIdentity.uchId))+	\
								(sizeof((a)->usNumberPorts))+			\
								(sizeof((a)->uchDelayMechanism))+		\
								(sizeof((a)->uchPrimaryDomain)));		\
}

#define	MGT_TCLK_DEF_DATA_SET_CLKID_SZ		8u
#define	MGT_TCLK_DEF_DATA_SET_NUMPT_SZ		2u
#define	MGT_TCLK_DEF_DATA_SET_DLYMECH_SZ	1u
#define	MGT_TCLK_DEF_DATA_SET_PRIMDOM_SZ	1u

#define	MGT_TCLK_DEF_DATA_SET_SZ			(MGT_TCLK_DEF_DATA_SET_CLKID_SZ + \
											MGT_TCLK_DEF_DATA_SET_NUMPT_SZ + \
											MGT_TCLK_DEF_DATA_SET_DLYMECH_SZ + \
											MGT_TCLK_DEF_DATA_SET_PRIMDOM_SZ)

typedef struct tagMGT_TCLK_PORT_DATA_SET
{
	PORTIDENTITY	stPortIdentity;
	BYTE	        byFlags;
	CHAR			chLogMinPdelayReqInterval;
	TIME_INTERVAL	stPeerMeanPathDelay;

}	MGT_TCLK_PORT_DATA_SET;

#define	GetMGT_TCLK_PORT_DS_SIZE(a,b)	{										\
								(b) = 0;										\
								(b) = (											\
								(sizeof((a)->stPortIdentity.stClockIdentity.uchId))+	\
								(sizeof((a)->stPortIdentity.usPortNumber))+				\
								(sizeof((a)->byFlags))+							\
								(sizeof((a)->chLogMinPdelayReqInterval))+		\
								(sizeof((a)->stPeerMeanPathDelay.sNsec_msb))+	\
								(sizeof((a)->stPeerMeanPathDelay.ulNsec_lsb))+	\
								(sizeof((a)->stPeerMeanPathDelay.usFrcNsec)));	\
}

#define	MGT_TCLK_PT_DATA_SET_PTID_SZ		10u
#define	MGT_TCLK_PT_DATA_SET_FLAG_SZ		1u
#define	MGT_TCLK_PT_DATA_SET_LMNDLINT_SZ	1u
#define	MGT_TCLK_PT_DATA_SET_PMEANPTD_SZ	8u

#define	MGT_TCLK_PT_DATA_SET_SZ				(MGT_TCLK_PT_DATA_SET_PTID_SZ + \
											MGT_TCLK_PT_DATA_SET_FLAG_SZ + \
											MGT_TCLK_PT_DATA_SET_LMNDLINT_SZ + \
											MGT_TCLK_PT_DATA_SET_PMEANPTD_SZ)

typedef struct tagMGT_PRIMARY_DOMAIN
{
	UCHAR			uchPrimaryDomain;
	UCHAR			uchReserved1;

}	MGT_PRIMARY_DOMAIN;

#define	GetMGT_PM_DOMAIN_DS_SIZE(a,b)	{							\
								(b) = 0;							\
								(b) = (								\
								(sizeof((a)->uchPrimaryDomain))+	\
								(sizeof((a)->uchReserved1)));		\
}

#define	MGT_PRIMARY_DOMAIN_PRIMDOMAIN_SZ	1u
#define	MGT_PRIMARY_RESERVED1_SZ			1u

#define	MGT_PRIMARY_DOMAIN_SZ				(MGT_PRIMARY_DOMAIN_PRIMDOMAIN_SZ + \
											MGT_PRIMARY_RESERVED1_SZ)

typedef struct tagMGT_DELAY_MECHANISM
{
	UCHAR			uchDelayMechanism;
	UCHAR			uchReserved1;

}	MGT_DELAY_MECHANISM;

#define	GetMGT_DLY_MECHANISM_DS_SIZE(a,b)	{						\
								(b) = 0;							\
								(b) = (								\
								(sizeof((a)->uchDelayMechanism))+	\
								(sizeof((a)->uchReserved1)));		\
}

#define	MGT_DELAY_MECHANISM_DLYMEC_SZ		1u
#define	MGT_DELAY_MECHANISM_RSV1_SZ			1u

#define	MGT_DELAY_MECHANISM_SZ				(MGT_DELAY_MECHANISM_DLYMEC_SZ + \
											MGT_DELAY_MECHANISM_RSV1_SZ)

typedef struct tagMGT_LOG_MIN_PDREQ_INTERVAL
{
	CHAR			chLogMinPdelayReqInterval;
	UCHAR			uchReserved1;

}	MGT_LOG_MIN_PDREQ_INTERVAL;

#define	GetMGT_LOG_MINPDREQINTV_DS_SIZE(a,b)	{							\
								(b) = 0;									\
								(b) = (										\
								(sizeof((a)->chLogMinPdelayReqInterval))+	\
								(sizeof((a)->uchReserved1)));				\
}

#define	MGT_LG_MIN_PDR_INT_LGMPDRINT_SZ		1u
#define	MGT_LG_MIN_PDR_INT_RSV1_SZ			1u

#define	MGT_LG_MIN_PDR_INT_SZ				(MGT_LG_MIN_PDR_INT_LGMPDRINT_SZ + \
											MGT_LG_MIN_PDR_INT_RSV1_SZ)

typedef union tagMGT_DATAFIELD
{
	MGT_CLOCK_DESCRIPTION			stClockDescription;
	MGT_USER_DESCRIPTION			stUserDescription;
	MGT_INITIALIZE					stInitialize;
	MGT_FAULT_LOG					stFaultLog;
	MGT_DEFAULT_DATA_SET			stDefaultDS;
	MGT_CURRENT_DATA_SET			stCurrentDS;
	MGT_PARENT_DATA_SET				stParentDS;
	MGT_TIME_PROPERTIES_DATA_SET	stTimePropertiesDS;
	MGT_PORT_DATA_SET				stPortDS;
	MGT_PRIORITY1					stPriority1;
	MGT_PRIORITY2					stPriority2;
	MGT_DOMAIN						stDomain;
	MGT_SLAVE_ONLY					stSlaveOnly;
	MGT_LOG_ANNOUNCE_INTERVAL		stLogAnnounceIntv;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT	stAnnounceReceiptTout;
	MGT_LOG_SYNC_INTERVAL			stLogSyncInterval;
	MGT_VERSION_NUMBER				stVersionNum;
	MGT_TIME						stTime;
	MGT_CLOCK_ACCURACY				stClockAccuracy;
	MGT_UTC_PROPERTIES				stUTC_Properties;
	MGT_TRACEABILITY_PROPERTIES		stTrcebltyProperties;
	MGT_TIMESCALE_PROPERTIES		stTimScaleProperties;
	MGT_UNICAST_NEGO_ENABLE			stUCastNegoEnable;
	MGT_PATH_TRACE_LIST				stPathTraceList;
	MGT_PATH_TRACE_ENABLE			stPathTraceEnable;
	MGT_GRANDMS_CLUSTER_TABLE		stGM_ClusterTbl;
	MGT_UNICAST_MASTER_TABLE		stUCastMasterTbl;
	MGT_UNICASTMS_MAX_TABLE_SZ		stUCastMasterMaxTblSZ;
	MGT_PORT_STATISTICS_COUNT		stPortStatisticsCnt;
	MGT_CMLD_PORT_STATIS_COUNT		stCMLD_PortStatisticsCnt;
	MGT_PORT_STATISTICS_ERRCOUNT	stPortStatisticsErrCnt;
	MGT_TCLK_DEFAULT_DATA_SET		stTCLK_DefaultDS;
	MGT_TCLK_PORT_DATA_SET 			stTCLK_PortDS;
	MGT_PRIMARY_DOMAIN				stPrimaryDomain;
	MGT_DELAY_MECHANISM				stDelayMechanism;
	MGT_LOG_MIN_PDREQ_INTERVAL		stLogMinPdelayReqIntv;

}	MGT_DATAFIELD;


#endif
