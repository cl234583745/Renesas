/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_SSSYNC_1AS_GD_H__
#define __PTP_SSSYNC_1AS_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_SSS {
	ST_SSS_NONE	= 0,
	ST_SSS_INITIALIZING,
	ST_SSS_RECEIVING_SYNC,
	ST_SSS_MAX
} EN_ST_SSS;

typedef	enum	tagEN_EV_SSS {
	EV_SSS_BEGIN = 0,
	EV_SSS_FOR_STSYNSYN_RCVSYNC,
	EV_SSS_CLOSE,
	EV_SSS_EVENT_MAX
} EN_EV_SSS;

typedef	struct tagSSSYNCSM_1AS_GD
{
	EN_ST_SSS		enStatusSSS;
	BOOL			blRcvdPSSync;
	PORTSYNCSYNC	stRcvdPSSyncDat;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr;
	PORTSYNCSYNC	stTxPSSyncDat;
	PORTSYNCSYNC*	pstTxPSSyncPtr;
	DOUBLE			dbRcvdCumulativeRateRatio;
	BOOL			blCumulativeRateRatioValid;
} SSSYNCSM_1AS_GD;	




#endif


