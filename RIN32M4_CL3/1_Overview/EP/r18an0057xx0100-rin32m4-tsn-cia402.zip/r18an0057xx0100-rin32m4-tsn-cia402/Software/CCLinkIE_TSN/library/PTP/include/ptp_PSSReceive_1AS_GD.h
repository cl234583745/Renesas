/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PSSRECEIVE_1AS_GD_H__
#define __PTP_PSSRECEIVE_1AS_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PSSR {
	ST_PSSR_NONE	= 0,
	ST_PSSR_DISCARD,
	ST_PSSR_RECEIVED_SYNC,
	ST_PSSR_MAX
} EN_ST_PSSR;

typedef	enum	tagEN_EV_PSSR {
	EV_PSSR_BEGIN = 0,
	EV_PSSR_FOR_PSYNSYNRV_RCVMDSYNC,
	EV_PSSR_CLOSE,
	EV_PSSR_EVENT_MAX
} EN_EV_PSSR;

typedef	struct tagPSSRECEIVESM_1AS_GD
{
	EN_ST_PSSR		enStatusPSSR;
	BOOL			blRcvdMDSync;
	MDSYNCRECEIVE*	pstRcvdMDSyncPtr;
	PORTSYNCSYNC*	pstTxPSSyncPtr;
} PSSRECEIVESM_1AS_GD;	



#endif


