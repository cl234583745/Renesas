/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Struct.h"
#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"

#include "PTP_GlobalData.h"
#include "ptp_CommonFunction.h"
#include "ptp_LCEntity_GD.h"



CLOCKDATA*			gpstClockDataHPtr			= NULL;
USCALEDNS			gstCurrentTime				= {0};
BOOL				gblCurrentTimeInit			= FALSE;

VOID*				gpvLockHandleTimer			= NULL;
VOID*				gpvLockHandlePTP			= NULL;

#if 1
BOOL				gblStartUpInit				= FALSE;
BOOL				gblStartUpConfig			= FALSE;
BOOL				gblStartUpOpen				= FALSE;
#endif

CURRENTTIMEQUE*		gpstCurrentTimeQuePtr				= NULL;
#ifdef PTP_USE_ME_HW_ASSIST
EXTENDEDTIMESTAMP	gstMasterLocalOffset				= {0};
USCALEDNS			gstLocatTimeForMaster				= {0};
#endif
DOUBLE				gdbClockSourceFreqOffset			= 0.0;
SCALEDNS			gstClockSourcePhaseOffset			= {0};
USHORT				gusClockSourceTimeBaseIndicator		= 0U;
USHORT				gusClockSourceTimeBaseIndOld		= 0U;
SCALEDNS			gstClockSourceLastGmPhaseChange		= {0};
EXTENDEDTIMESTAMP	gstMasterTime						= {0};
USCALEDNS			gstCurrentMasterTime				= {0};
BOOL				gblCurrentMasterTimeInit			= FALSE;
CMLDS_MANAGE*		gpstCmldsPtr						= NULL;
MDPDLYREQSM_STACK_MANAGE*	gpstMdPdlyTspStk         	= NULL;
CMLDSPORT_1AS_DS*			gpstCmldsPort_1AS_DS		= NULL;
CMLDSPORTSTATISTICS_1AS_DS*	gpstCmldsPortStatistics_1AS_DS = NULL;
DOUBLE				gdbRateRatio						= 0.0;
DOUBLE				gdbClockSourceLastGmFreqChange		= 0.0;
DOUBLE				gdbGmRateRatio						= 0.0;
USCALEDNS			gstLocalTime						= {0};
DOUBLE				gdbCMFreqOffset						= 0.0;
SCALEDNS			gstCMPhaseOffset					= {0};

CLOCKDATA*			gpstBestDomain						= NULL;
LOGRECORD_GD		gstLogRecord_GD						= {0};
MEMMANAGE_GD		gstMemManage_GD					    = {0};
DREQTMOMAN 			gstDreqTmoManage[MAX_PORT]			= {0};
SYNCTMOMAN 			gstSyncTmoManage[MAX_PORT]			= {0};



