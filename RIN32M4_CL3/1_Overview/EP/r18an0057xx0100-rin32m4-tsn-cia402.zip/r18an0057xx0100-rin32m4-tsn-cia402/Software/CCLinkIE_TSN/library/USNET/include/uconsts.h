//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_UCONSTS_H_
#define _USS_UCONSTS_H_



#define RTOS_NONE    0
#define RTOS_MT      1
#define RTOS_TT      2
#define RTOS_HI      3
#define RTOS_RX      4
#define RTOS_PPSM    5
#define RTOS_HI7750  6


#define RTOS_MT6     1
#define RTOS_TT3     2

#define RTOS_HI_SH7  3
#define RTOS_HI_SH77 3




#define USS_LITTLE      0
#define USS_BIG         1

#endif

