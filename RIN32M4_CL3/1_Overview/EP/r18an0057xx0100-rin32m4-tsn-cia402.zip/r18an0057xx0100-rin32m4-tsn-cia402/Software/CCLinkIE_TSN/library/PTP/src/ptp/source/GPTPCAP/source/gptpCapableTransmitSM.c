/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_Macro.h"
#ifdef	PTP_USE_IEEE802_1
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"
#include "mdtransinterface.h"
#include "gptpCapableTransmitSM.h"

#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0

static VOID gptpCapableTransmit_NP( PORTDATA* pstPort );
static VOID gptpCapableTransmit_00( PORTDATA* pstPort );
static VOID gptpCapableTransmit_01( PORTDATA* pstPort );
static VOID gptpCapableTransmit_02( PORTDATA* pstPort );

static VOID setGptpCapableTlv( PORTDATA* pstPort );
static VOID txGptpCapableSinglingMsg( GPTPCAPTRANSSM_GD* pstSmGbl, PORTDATA* pstPort );
static VOID setGptpCapableTransmitStatus( PORTDATA* pstPort, GPTPCAPTRSM_ST enSts );
static GPTPCAPTRSM_EV getGptpCapableTransmitEvt( USHORT usEvent );
static GPTPCAPTRSM_ST getGptpCapableTransmitStatus( PORTDATA* pstPort );

#ifndef PTP_USE_SIGNALING
static VOID gptpCapableIntSet_1AS(PORTDATA* pstPort);
#endif
static VOID (*const pfnGptpCapableTransmitMatrix[GPTPCAPTRSM_STATUS_MAX][GPTPCAPTRSM_EV_EVENT_MAX])(PORTDATA* pstPort) = 
{
	{&gptpCapableTransmit_01, &gptpCapableTransmit_NP, &gptpCapableTransmit_NP},
	{&gptpCapableTransmit_01, &gptpCapableTransmit_02, &gptpCapableTransmit_00}
};

static VOID setGptpCapableTlv( PORTDATA* pstPort )
{
	PTPMSG_SIGNALING_1AS* pstMsg = &pstPort->stGPTPCapTransSM_GD.stTxSignalingMsg;

	MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	MPTPMSG_H_SET_MINOR_VER(&pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_SIGNALING );

	pstMsg->stHeader.uchDomainNumber  = pstPort->pstClockData->stDefaultDS.uchDomainNumber;
	pstMsg->stHeader.usMegLength      = PTPMSG_HEAD_SZ 
										+ PTPMSG_AS_SGNL_TGTPORTID_SZ 
										+ PTPMSG_GPTPCAP_TVLTYPE_SZ 
										+ PTPMSG_GPTPCAP_TLVLENGTH_SZ 
										+ PTPMSG_GPTPCAP_ORGANIZATIONID_SZ
										+ PTPMSG_GPTPCAP_ORGSUBTYPE_SZ 
										+ PTPMSG_GPTPCAP_LOGGPTPCAPMSGINT_SZ 
										+ PTPMSG_GPTPCAP_FLAGS_SZ 
										+ PTPMSG_GPTPCAP_RESERVED_SZ;
	pstMsg->stHeader.uchControl		  = 5U;
	pstMsg->stHeader.byFlags0		  = 0U;
	pstMsg->stHeader.byFlags1		  = 0U;

	pstMsg->stHeader.usSequenceId     = pstPort->stGPTPCapTransSM_GD.usSignalingSequenceNum;
	pstMsg->stHeader.chLogMsgInterVal = (CHAR)0x7F;

	tsn_Wrapper_MemCpy( (VOID *)&pstMsg->stHeader.stSrcPortIdentity.stClockIdentity,
						(VOID *)&pstPort->stPortDS.stPortIdentity.stClockIdentity, 
						sizeof(CLOCKIDENTITY) );

	pstMsg->stHeader.stSrcPortIdentity.usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	tsn_Wrapper_MemSet( (VOID *)&pstMsg->stHeader.stCorrectionField, 
						0,
						sizeof(pstMsg->stHeader.stCorrectionField) );

	tsn_Wrapper_MemSet( (VOID *)&pstMsg->stTargetPortIdentity.stClockIdentity, 
						0xFF, 
						sizeof(pstMsg->stTargetPortIdentity.stClockIdentity) );
	pstMsg->stTargetPortIdentity.usPortNumber = (USHORT)0xFFFFU;

	pstMsg->stGptpCap_TLV.usTLVType = PTPM_TLVTYP_ORGANIZATION_EXTEN;

	pstMsg->stGptpCap_TLV.usLengthField = PTPMSG_FLWUPT_LSTGMPHSCHG_SZ;

	pstMsg->stGptpCap_TLV.byFlags = (UCHAR)0x00;
	pstMsg->stGptpCap_TLV.chlogGptpCapableMessageInterval = pstPort->stPort_1AS_DS.chCurrentLogGptpCapMsgInt;
	pstMsg->stGptpCap_TLV.uchOrganizationID[0] = 0x00U;
	pstMsg->stGptpCap_TLV.uchOrganizationID[1] = 0x80U;
	pstMsg->stGptpCap_TLV.uchOrganizationID[2] = 0xC2U;

	pstMsg->stGptpCap_TLV.uchOrganizationSubType[0] = 0x00U;
	pstMsg->stGptpCap_TLV.uchOrganizationSubType[1] = 0x00U;
	pstMsg->stGptpCap_TLV.uchOrganizationSubType[2] = PTPMSG_TLV_ORGSUBTYPE_GPTPCAP;

	return;
}

static VOID txGptpCapableSinglingMsg( GPTPCAPTRANSSM_GD* pstSmGbl, PORTDATA* pstPort )
{
	
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;

	stCallback.pstPortData = pstPort;

	nPtpSend = MD_ptp_send( (UCHAR *)&pstSmGbl->stTxSignalingMsg,
							pstSmGbl->stTxSignalingMsg.stHeader.usMegLength,
							&stCallback );
	if ( nPtpSend != 0 )
	{
		PTP_ERROR_LOGRECORD( pstPort->pstClockData, 
						     PTP_LOG_MDPDELAYREQ_1AS, 
						     PTP_LOGVE_8200250D );
	}
	return;
}

static GPTPCAPTRSM_EV getGptpCapableTransmitEvt( USHORT usEvent )
{

	GPTPCAPTRSM_EV enEvt;
	
	enEvt = GPTPCAPTRSM_EV_EVENT_MAX;
	
	switch ( usEvent )
	{
		case PTP_EV_BEGIN:
			enEvt = GPTPCAPTRSM_EV_BEGIN;
			break;
		case PTP_EV_GPTPCAPBLE_SENDTIME:
			enEvt = GPTPCAPTRSM_EV_GPTPCAPBLE_SENDTIME;
			break;
		case PTP_EV_CLOSE:
			enEvt = GPTPCAPTRSM_EV_CLOSE;
			break;
		default:
	        ptp_dbg_msg( D_ERR, 
	        			 ("%s::unknown ptp event. event=[%d]\n", 
	                      "getGptpCapableTransmitEvt",
	                      usEvent) );
			break;
	}
	
	return enEvt;
}
static GPTPCAPTRSM_ST getGptpCapableTransmitStatus( PORTDATA* pstPort )
{
	GPTPCAPTRSM_ST enSts;
	
	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "getGptpCapableTransmitStatus") );
		return GPTPCAPTRSM_STATUS_MAX;
	}
	enSts = pstPort->stGPTPCapTransSM_GD.enStsgptpCapableTransmit;
	
	return enSts;
}
static VOID setGptpCapableTransmitStatus( PORTDATA* pstPort, GPTPCAPTRSM_ST enSts )
{

	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "setGptpCapableTransmitStatus") );
		return ;
	}
    ptp_dbg_msg( D_STATE, 
    			 ("%s::state %d->%d \n", 
                  "setGptpCapableTransmitStatus",
                  pstPort->stGPTPCapTransSM_GD.enStsgptpCapableTransmit,
                  enSts) );

	pstPort->stGPTPCapTransSM_GD.enStsgptpCapableTransmit = enSts;

	return ;
}
static VOID gptpCapableTransmit_NP( PORTDATA* pstPort )
{
	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_NP::+\n") );

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_NP::-\n") );

	return ;
}
static VOID gptpCapableTransmit_00( PORTDATA* pstPort )
{
	GPTPCAPTRANSSM_GD *pstTransSM;

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_00::+\n") );

	pstTransSM = &pstPort->stGPTPCapTransSM_GD;

	if (pstTransSM->pstTMO_GPtpCapableTransmit != NULL )
	{
		(VOID)ptp_TimeOut_Can(pstTransSM->pstTMO_GPtpCapableTransmit );
		pstTransSM->pstTMO_GPtpCapableTransmit = NULL;
	}

	setGptpCapableTransmitStatus( pstPort, GPTPCAPTRSM_NONE );

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_00::-\n") );

	return ;
}

static VOID gptpCapableTransmit_01( PORTDATA* pstPort )
{
	GPTPCAPTRANSSM_GD *pstTransSM;
	PORT_1AS_GD       *pstAs;

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_01::+\n") );

	if (pstPort->pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag == TRUE)
	{

		if (pstPort->stPort_GD.blPortValid == TRUE)
		{
			pstTransSM = &pstPort->stGPTPCapTransSM_GD;
			pstAs = &pstPort->stPort_1AS_GD;

			pstAs->blGptpCapMsgSlowdown = FALSE;
			pstTransSM->uchNumGptpCapMsgTransmissions = 0U;

			ptp_GetCurrentTime( pstPort->pstClockData,
								&pstTransSM->stGptpSendIntervalTimer );

			pstTransSM->usSignalingSequenceNum = (USHORT)tsn_Wrapper_Rand();

#ifndef PTP_USE_SIGNALING
			gptpCapableIntSet_1AS(pstPort);
#endif

			gptpCapableTransmit_02(pstPort);

			setGptpCapableTransmitStatus(pstPort, GPTPCAPTRSM_TRANSMIT_TLV);

		}
	}

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_01::-\n") );

	return ;
}
static VOID gptpCapableTransmit_02( PORTDATA* pstPort )
{
	GPTPCAPTRANSSM_GD *pstTransSM;
	PORT_1AS_GD       *pstPort1AsGd;
	PORT_1AS_DS       *pstPort1AsDs;
	USCALEDNS		   stInterval3;

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_02::+\n") );

	pstTransSM   = &pstPort->stGPTPCapTransSM_GD;
	pstPort1AsGd = &pstPort->stPort_1AS_GD;
	pstPort1AsDs = &pstPort->stPort_1AS_DS;

	pstTransSM->usSignalingSequenceNum++;

	setGptpCapableTlv( pstPort );
	
	txGptpCapableSinglingMsg( pstTransSM, pstPort );

	if ( pstPort1AsGd->blGptpCapMsgSlowdown == TRUE ) 
	{

		if( pstTransSM->uchNumGptpCapMsgTransmissions >= pstPort1AsDs->uchGPtpCapableReceiptTimeout )
		{
			stInterval3 = pstPort1AsGd->stGptpCapMsgInt;
			pstTransSM->uchNumGptpCapMsgTransmissions = 0U;
			pstPort1AsGd->blGptpCapMsgSlowdown = FALSE;
		}
		else
		{
			stInterval3 = pstPort1AsGd->stOldGptpCapMsgInt;
			pstTransSM->uchNumGptpCapMsgTransmissions++;
		}
	}
	else
	{
		stInterval3 = pstPort1AsGd->stGptpCapMsgInt;
		pstTransSM->uchNumGptpCapMsgTransmissions = 0U;
	}
	(VOID)ptpAddUSNs_USNs( &pstTransSM->stGptpSendIntervalTimer, 
						   &stInterval3, 
						   &pstTransSM->stGptpSendIntervalTimer );
	
	pstTransSM->pstTMO_GPtpCapableTransmit = ptp_TimeOut_Req( PTP_EV_GPTPCAPBLE_SENDTIME, 
									 	 					  (VOID *)pstPort, 
									 	 					  pstTransSM->stGptpSendIntervalTimer,
									 	 					  (CallBackFunc)&gptpCapableTransmitSM );

	ptp_dbg_msg( D_FUNC, ("gptpCapableTransmit_02::-\n") );

	return ;
}
VOID gptpCapableTransmitSM( USHORT usEvent, PORTDATA* pstPort )
{

	GPTPCAPTRSM_EV enEvt;
	GPTPCAPTRSM_ST enSts;

	if ( pstPort == NULL )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::invalid argument..\n", 
                      "gptpCapableTransmitSM") );
		return ;
	}

	enEvt = getGptpCapableTransmitEvt( usEvent );
	enSts = getGptpCapableTransmitStatus( pstPort );
	
	if (   (enEvt >= GPTPCAPTRSM_EV_EVENT_MAX)
        || (enSts >= GPTPCAPTRSM_STATUS_MAX) )
	{
        ptp_dbg_msg( D_ERR, 
        			 ("%s::unknown event ro status. event=[%d], status=[%d]\n", 
                      "gptpCapableTransmitSM",
                      enEvt,
                      enSts) );
		return ;
	}

	pfnGptpCapableTransmitMatrix[enSts][enEvt]( pstPort );
	
	return ;
}
#ifndef PTP_USE_SIGNALING
static VOID gptpCapableIntSet_1AS(PORTDATA* pstPort)
{
	USCALEDNS 	stA_USNs = { 0 };

	if ( pstPort->stPort_1AS_DS.blUseMgtSettableLogGptpCapMsgInt )
	{
		pstPort->stPort_1AS_DS.chCurrentLogGptpCapMsgInt
			= pstPort->stPort_1AS_DS.chMgtSettableLogGptpCapMsagInt;
	}
	else
	{

		pstPort->stPort_1AS_DS.chCurrentLogGptpCapMsgInt
			= pstPort->stPort_1AS_DS.chInitialLogGptpCapMsgInt;
	}

	stA_USNs.ulNsec_lsb = CONST10_9;

	(VOID)ptpShiftUSNs_CHAR( &stA_USNs,
					   		 pstPort->stPort_1AS_DS.chCurrentLogGptpCapMsgInt,
					         &pstPort->stPort_1AS_GD.stGptpCapMsgInt );

}
#endif
#endif
