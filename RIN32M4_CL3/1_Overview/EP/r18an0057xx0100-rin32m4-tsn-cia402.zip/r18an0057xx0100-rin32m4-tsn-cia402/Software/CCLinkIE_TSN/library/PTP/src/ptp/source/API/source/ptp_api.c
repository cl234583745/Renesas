/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "PTP_GlobalData.h"
#include "ptp_Struct.h"
#include "ptp_api.h"
#include "ptp_MemManage.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_Macro.h"

#include "ptp_CommonFunction.h"

#ifdef	PTP_USE_IEEE802_1
static INT ptp_config_AS( PTPINFSET *pstPtpInfSet );
#endif
#ifdef	PTP_USE_IEEE1588
static INT ptp_config_1588( PTPINFSET *pstPtpInfSet );
#endif


static INT initFor1588bound( PTPINFSET* pstPtpInfSet, 
							 CLOCKDATA* pstClockData,
							 INT	    nClockNumber );
static INT initFor1588Trans( PTPINFSET* pstPtpInfSet, 
							 CLOCKDATA* pstClockData,
							 INT 		nClockNumber );
static INT initForAS( PTPINFSET* pstPtpInfSet, 
                      CLOCKDATA* pstClockData,
                      INT 		nClockNumber );

static INT initDefaultDS( PTPINFSET* pstPtpInfSet, 
						  CLOCKDATA* pstClockData,
						  INT 		 nClockNumber );


INT initDefaultDSForAS(PTPINFSET* pstPtpInfSet, CLOCKDATA* pstClockData);
INT initCurrentDS(PTPINFSET* pstPtpInfSet, CURRENT_DS* pstCurrentDS);
INT initParentDS(DEFAULT_DS* pstDefaultDS, PARENT_DS* pstParentDS);
INT initTimePropertiesDS(PTPINFSET* pstPtpInfSet, TIMEPROPERTIES_DS* pstTimeProDS);

static INT initDefault_1588_DS( PTPINFSET* 		 pstPtpInfSet, 
								DEFAULT_1588_DS* pstDefault1588_DS, 
								INT 			 nClockNumber );

INT initCurrent_1588_DS(PTPINFSET* pstPtpInfSet, CURRENT_1588_DS* pstCurrent_1588_DS);
INT initParent_1588_DS(PTPINFSET* pstPtpInfSet, PARENT_1588_DS* pstParent1588_DS);
#ifdef	PTP_USE_TRANS
static INT initTransDefault_1588_DS( PTPINFSET* 		pstPtpInfSet, 
									 TCDEFAULT_1588_DS* pstTcDefault1588_DS, 
									 INT 				nClockNumber );
#endif
static INT initDefault_AS_DS( PTPINFSET* pstPtpInfSet, 
							  CLOCKDATA* pstClockData,
							  INT 		 nClockNumber );
INT initCurrent_AS_DS(PTPINFSET* pstPtpInfSet, CURRENT_1AS_DS* pstCurrentAS_DS);
INT initParent_AS_DS(PTPINFSET* pstPtpInfSet, PARENT_1AS_DS* pstParentAS_DS);
INT initPthTrace_AS_DS(PTPINFSET* pstPtpInfSet, PATHTRACE_1AS_DS* pstPathTraceAS_DS);
INT initCmldsDefault_AS_DS(PTPINFSET* pstPtpInfSet, CMLDSDEFAULT_1AS_DS* pstCmldsDefaultAS_DS);

static INT initFor1588boundPort( PTPINFSET* pstPtpInfSet, 
								 CLOCKDATA* pstClockData ,
								 INT        nClockNumber );

#ifdef	PTP_USE_TRANS
static INT initFor1588TransPort( PTPINFSET* pstPtpInfSet, 
								 CLOCKDATA* pstClockData, 
								 INT        nClockNumber );
#endif



static  INT initForASPort( PTPINFSET* pstPtpInfSet, 
						   CLOCKDATA* pstClockData, 
						   INT 		  nClockNumber );
static INT initPortDS( PORTINFSET* 	pstPortInfSet, 
					   CLOCKDATA* 	pstClockData, 
					   PORTDATA* 	pstPortData, 
					   USHORT 		usPortNumber, 
					   BOOL* 		pblMasterPort );
static INT initPortDSForAS( PORTASINFSET*	pstPortAsInfSet,
							CLOCKDATA* 		pstClockData, 
							PORTDATA* 		pstPortData, 
							USHORT 			usPortNumber, 
							BOOL* 			pblMasterPort );
static INT initPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
						   CLOCKDATA* 		pstClockData, 
						   PORTDATA* 		pstPortData, 
						   USHORT 			usPortNumber );
static INT initDescriptPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
								   CLOCKDATA* 		pstClockData, 
								   PORTDATA* 		pstPortData, 
								   USHORT 			usPortNumber );
static INT initCmldsPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
								CLOCKDATA* 		pstClockData, 
								PORTDATA* 		pstPortData, 
								USHORT 			usPortNumber );
static  INT initPort_1588_DS( PTPINFSET* pstPtpInfSet, 
							  CLOCKDATA* pstClockData, 
							  INT        nClockNumber,  
							  PORTDATA*  pstPortData, 
							  USHORT 	 usPortNumber, 
							  BOOL* 	 pblMasterPort );
#ifdef	PTP_USE_TRANS
static INT initTransPort_1588_DS( PTPINFSET* pstPtpInfSet, 
								  CLOCKDATA* pstClockData, 
								  INT 		 nClockNumber,
								  PORTDATA*  pstPortData, 
								  USHORT 	 usPortNumber );
#endif

INT initPort_GD(PTPINFSET* pstPtpInfSet, CLOCKDATA* pstClockData, PORTDATA* pstPortData, USHORT usPortNumber);

static INT initPort_GDFor1588bound( PTPINFSET* pstPtpInfSet, 
									CLOCKDATA* pstClockData, 
							 		INT        nClockNumber,  
									PORTDATA*  pstPortData, 
									USHORT     usPortNumber );
#ifdef	PTP_USE_TRANS
static INT	initPort_GDFor1588Trans( PTPINFSET* pstPtpInfSet, 
									 CLOCKDATA* pstClockData, 
							 		 INT        nClockNumber,  
									 PORTDATA*  pstPortData, 
									 USHORT     usPortNumber );
#endif
static INT initPort_GDForAS( PTPINFSET* pstPtpInfSet, 
							 CLOCKDATA* pstClockData, 
							 INT        nClockNumber, 
							 PORTDATA*  pstPortData, 
							 USHORT     usPortNumber );







void initManageClockDescription (CLOCKDATA* pstClockData);
USHORT	getStringLen(UCHAR* puchPo, USHORT usMaxCnt);

#define	PTP_PROFILEID_SIZE	6
BYTE	PTP_Profile_ID[PTP_PROFILEID_SIZE]={0x00,0x80,0xC2,0x00,0x01,0x00};



#ifdef	PTP_USE_IEEE802_1
static INT ptp_config_AS( PTPINFSET *pstPtpInfSet )
{

	IEEE1588_L2*	pstIeee1588L2;
	PORTADDRINFO*	pstPortAddrInfo;
	CLOCKDATA*		pstClockData;
	ULONG			ulAdrInfoSize;
	INT 			nClockCount;
	INT 			nRet;
	CLOCKASINFSET*	pstClockAsInfSet;
	UINT 			unIndex1;
	UINT 			unIndex2;
	BOOL 			blDomain0;

	pstPortAddrInfo = gpstClockDataHPtr->pstPortAddrInfo;

	if ( pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol != CLK_TRANS_IEEE802_1_AS )
	{
		return RET_EINVAL;
	}

	pstClockAsInfSet = (CLOCKASINFSET *)pstPtpInfSet->pvClockInfo;
	
	blDomain0 = FALSE;
	for ( unIndex1 = 0U ; unIndex1 < pstPtpInfSet->pstClockKndInfo->uchDomainNum ; unIndex1++ )
	{
		for ( unIndex2 = unIndex1 + 1U ; unIndex2 < pstPtpInfSet->pstClockKndInfo->uchDomainNum ; unIndex2++ )
		{
			if ( pstClockAsInfSet[unIndex1].uchDomainNum == pstClockAsInfSet[unIndex2].uchDomainNum )
			{
				return RET_EINVAL;
			}
		}
		if ( pstClockAsInfSet[unIndex1].uchDomainNum == 0U )
		{
			blDomain0 = TRUE;
		}
	}
	if ( blDomain0 != TRUE )
	{
		return RET_EINVAL;
	}

	pstIeee1588L2 = (IEEE1588_L2*)pstPtpInfSet->pvTransAdrInfo;
	if ( pstIeee1588L2->pstMacAdd == NULL )
	{
		return RET_EINVAL;
	}
	ulAdrInfoSize = sizeof(MACADDR) * (ULONG)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;

	(VOID)tsn_Wrapper_MemCpy( pstPortAddrInfo->pvAddrInfo, 
							  (VOID *)pstIeee1588L2->pstMacAdd, 
							  (size_t)ulAdrInfoSize );

	pstPortAddrInfo->enClockTrans = pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol;
	
	nClockCount = 0;
	for ( pstClockData  = gpstClockDataHPtr;
		  pstClockData != NULL;
		  pstClockData  = pstClockData->pstNextClockDataPtr )
	{
		
		pstClockData->stClock_GD.enSupportPTPType = ENUM_SUPPORTPTPTYPE_IEEE802_1AS;
		pstClockData->stClock_GD.ulME_extend      = pstPtpInfSet->ulME_extend;

		pstClockData->stClock_GD.dbCurMasterLastFreqChange             = (DOUBLE)1.0;
		pstClockData->stClock_GD.dbCurMasterLastFreqChangeForGM        = (DOUBLE)1.0;
		nRet = initForAS( pstPtpInfSet, pstClockData, nClockCount );
		if ( nRet != RET_ENOERR )
		{
			return nRet;
		}

		if (pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_AS_GPTP_CAPABLE_1)
		{
			if (!(pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_AS_GPTP_CAPABLE_2))
			{
				if (pstPtpInfSet->pstClockKndInfo->uchDomainNum <= 1)
				{
					pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag = FALSE;
				}
				else
				{
					pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag = TRUE;
				}
			}
			else
			{
				pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag = FALSE;
			}
		}
		else
		{
			pstClockData->stUn_Clock_GD.stClock_1AS_GD.blgPTPCapableExecFlag = TRUE;
		}

		nRet = initForASPort( pstPtpInfSet, pstClockData, nClockCount );
		if ( nRet != RET_ENOERR )
		{
			return nRet;
		}
		nClockCount++;
	}
	
	return RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE1588
static INT ptp_config_1588( PTPINFSET *pstPtpInfSet )
{

	IEEE1588_L4V4*	pstIeee1588L4V4;
	IEEE1588_L4V6*	pstIeee1588L4V6;
	IEEE1588_L2*	pstIeee1588L2;
	PORTADDRINFO*	pstPortAddrInfo;
	CLOCKDATA*		pstClockData;
	VOID*			pvAddrInfo;
	ULONG			ulAdrInfoSize;
	INT 			nClockCount;
	INT 			nRet;
	CLOCKINFSET*	pstClockInfSet;
	UINT 			unIndex1;
	UINT 			unIndex2;

	pstPortAddrInfo = gpstClockDataHPtr->pstPortAddrInfo;

	pstClockInfSet	= (CLOCKINFSET*)pstPtpInfSet->pvClockInfo;

	for ( unIndex1 = 0U ; unIndex1 < pstPtpInfSet->pstClockKndInfo->uchDomainNum ; unIndex1++ )
	{
		for ( unIndex2 = unIndex1 + 1U ; unIndex2 < pstPtpInfSet->pstClockKndInfo->uchDomainNum ; unIndex2++ )
		{
			if ( pstClockInfSet[unIndex1].uchDomainNum == pstClockInfSet[unIndex2].uchDomainNum )
			{
				return RET_EINVAL;
			}
		}
	}

	switch ( pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol )
	{
		case CLK_TRANS_IEEE1588_L4_IPV4:
			pstIeee1588L4V4 = (IEEE1588_L4V4 *)pstPtpInfSet->pvTransAdrInfo;
			if ( pstIeee1588L4V4->pstMyIpAdd == NULL )
			{
				return RET_EINVAL;
			}
			pvAddrInfo    = (VOID *)pstIeee1588L4V4->pstMyIpAdd;
			ulAdrInfoSize = sizeof(IPV4ADDR) * (ULONG)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;
			pstPortAddrInfo->stPortAdrInfSub.ulNetMask = pstIeee1588L4V4->ulNetMask;
			break;

		case CLK_TRANS_IEEE1588_L4_IPV6:
			pstIeee1588L4V6 = (IEEE1588_L4V6 *)pstPtpInfSet->pvTransAdrInfo;
			if ( pstIeee1588L4V6->pstV6addr == NULL )
			{
				return RET_EINVAL;
			}
			pvAddrInfo    = (VOID *)pstIeee1588L4V6->pstV6addr;
			ulAdrInfoSize = sizeof(IPV6ADDR) * (ULONG)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;
			pstPortAddrInfo->stPortAdrInfSub.nPrefixLen = pstIeee1588L4V6->nPrefixLen;
			break;
		case CLK_TRANS_IEEE1588_L2:
			pstIeee1588L2 = (IEEE1588_L2*)pstPtpInfSet->pvTransAdrInfo;
			if ( pstIeee1588L2->pstMacAdd == NULL )
			{
				return RET_EINVAL;
			}
			pvAddrInfo    = (VOID *)pstIeee1588L2->pstMacAdd;
			ulAdrInfoSize = sizeof(MACADDR) * (ULONG)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;
			break;
		default:
			return RET_EINVAL;
	}
	(VOID)tsn_Wrapper_MemCpy( pstPortAddrInfo->pvAddrInfo, pvAddrInfo, (size_t)ulAdrInfoSize );
	pstPortAddrInfo->enClockTrans = pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol;
	

	nClockCount = 0;
	for ( pstClockData  = gpstClockDataHPtr;
	 	  pstClockData != NULL;
		  pstClockData  = pstClockData->pstNextClockDataPtr )
	{
		pstClockData->stClock_GD.enSupportPTPType = ENUM_SUPPORTPTPTYPE_IEEE1588;
		pstClockData->stClock_GD.ulME_extend      = pstPtpInfSet->ulME_extend;	
		if (pstPtpInfSet->pstClockKndInfo->enClockKind == CLK_KIND_BOUND_ORDI)
		{
			nRet = initFor1588bound( pstPtpInfSet, pstClockData, nClockCount );
			if( nRet != RET_ENOERR )
			{
				return nRet;
			}
			nRet = initFor1588boundPort( pstPtpInfSet, pstClockData, nClockCount );
			if( nRet != RET_ENOERR )
			{
				return nRet;
			}
		}
		else if (pstPtpInfSet->pstClockKndInfo->enClockKind == CLK_KIND_TRANSPARENT)
		{
#ifdef	PTP_USE_TRANS

			nRet = initFor1588Trans( pstPtpInfSet, pstClockData, nClockCount );
			if(nRet != RET_ENOERR)
			{
				return nRet;
			}
			nRet = initFor1588TransPort( pstPtpInfSet, pstClockData, nClockCount );
			if(nRet != RET_ENOERR)
			{
				return nRet;
			}
#else
			return RET_EINVAL;
#endif
		}
		else
		{
			return RET_EINVAL;
		}
		initManageClockDescription ( pstClockData );
		
		nClockCount++;
	}
	
	return RET_ENOERR;
}
#endif


INT ptp_config( PTPINFSET *pstPtpInfSet )
{
	INT 		nRet;
	BOOL		blRet;

	if ( gblStartUpConfig == TRUE )
	{
		return	RET_EINVAL;
	}
	gblStartUpConfig = FALSE;

	if( pstPtpInfSet == NULL )
	{
		return	RET_EINVAL;
	}

	if ( pstPtpInfSet->pvTransAdrInfo == NULL )
	{
		return RET_EINVAL;
	}

	if ( pstPtpInfSet->pstClockKndInfo == NULL )
	{
		return RET_EINVAL;
	}

	if ( pstPtpInfSet->pvClockInfo == NULL )
	{
		return RET_EINVAL;
	}

	if ( pstPtpInfSet->pvPortInfo == NULL )
	{
		return RET_EINVAL;
	}

	if (   (pstPtpInfSet->pstClockKndInfo->uchInterfaceNum > MAX_PORT)
	    || (pstPtpInfSet->pstClockKndInfo->uchInterfaceNum == 0U) )
	{
		return	RET_EINVAL;
	}

	blRet = ptp_MMBegin( pstPtpInfSet->pstClockKndInfo->uchDomainNum, 
						 (USHORT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum );
	if ( blRet == FALSE )
	{
		(VOID)ptp_MMClose( 0U );
		return RET_ESTATE;
	}

	switch( pstPtpInfSet->pstClockKndInfo->enClockPtpProtcol )
	{
#ifdef	PTP_USE_IEEE802_1
		case PROTOCOL_IEEE802_1_AS:
			nRet = ptp_config_AS( pstPtpInfSet );
			break;
#endif
#ifdef	PTP_USE_IEEE1588
		case PROTOCOL_IEEE1588:
			nRet = ptp_config_1588( pstPtpInfSet );
			break;
#endif
		default:
			nRet = RET_EINVAL;
			break;
	}
	if ( nRet != RET_ENOERR )
	{
		(VOID)ptp_MMClose( 0U );
		return nRet;
	}

	gblStartUpConfig = TRUE;

	return nRet;
}


#ifdef	PTP_USE_IEEE1588
static INT initFor1588bound( PTPINFSET* pstPtpInfSet, 
							 CLOCKDATA* pstClockData,
							 INT	    nClockNumber )
{
	INT nRet;


	if( pstPtpInfSet->pstClockKndInfo->uchInterfaceNum == 1U )
	{
		pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_ORDINARYCLOCK_1588;
	}
	else
	{
		pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_BOUNDARYCLOCK_1588;
	}

	nRet = initDefaultDS( pstPtpInfSet, pstClockData, nClockNumber );
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initCurrentDS(pstPtpInfSet, &pstClockData->stCurrentDS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initParentDS(&pstClockData->stDefaultDS, &pstClockData->stParentDS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initTimePropertiesDS(pstPtpInfSet, &pstClockData->stTimePropertiesDS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initDefault_1588_DS( pstPtpInfSet,
	 							&pstClockData->stDefault_1588_DS, 
	 							nClockNumber );
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initCurrent_1588_DS(pstPtpInfSet, &pstClockData->stCurrent_1588_DS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initParent_1588_DS(pstPtpInfSet, &pstClockData->stParent_1588_DS);

	{
		USCALEDNS	stTempUSNs;
		CLOCKINFSET* pstClockInfSet;

		pstClockInfSet = pstPtpInfSet->pvClockInfo;
		pstClockInfSet = &pstClockInfSet[nClockNumber];

		tsn_Wrapper_MemSet(&stTempUSNs, 0x00, sizeof(USCALEDNS));
		stTempUSNs.ulNsec_lsb = pstClockInfSet->ulSyncTransTimeout;
		(VOID)ptpMultUSNs_ULONG (&stTempUSNs, 1000U, &pstClockData->stClock_GD.stSyncTransTimeout);
	}

	return nRet;
}

#ifdef	PTP_USE_TRANS
static INT initFor1588Trans( PTPINFSET* pstPtpInfSet, 
						     CLOCKDATA* pstClockData,
						     INT 		nClockNumber )
{
	INT nRet;


	TRANSPARENT_CLOCKINFSET* pstTrnsClockInfSet;

	pstTrnsClockInfSet = (TRANSPARENT_CLOCKINFSET*)pstPtpInfSet->pvClockInfo;
	pstTrnsClockInfSet = &pstTrnsClockInfSet[nClockNumber];

	if (pstTrnsClockInfSet->enDelayMechanism == DELAY_E2E) {
		pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_TRANSCLOCKE2E_1588;
	}
	else if (pstTrnsClockInfSet->enDelayMechanism == DELAY_P2P)
	{
		pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_TRANSCLOCKP2P_1588;
	}
	else
	{
		return RET_EINVAL;
	}

	pstClockData->stDefault_1588_DS.blTwoStepFlag = pstTrnsClockInfSet->blTwoStepFlag;
	(VOID)tsn_Wrapper_MemCpy(&pstClockData->stDefaultDS.stClockIdentity, &pstTrnsClockInfSet->stClockIdentity, sizeof(CLOCKIDENTITY));
	pstClockData->stDefaultDS.usNumberPorts = pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;

	nRet = initTransDefault_1588_DS ( pstPtpInfSet, 
									  &pstClockData->stTCDefault_1588_DS, 
									  nClockNumber );

	return nRet;
}
#endif

#endif

#ifdef	PTP_USE_IEEE802_1
static INT initForAS( PTPINFSET* pstPtpInfSet, 
                      CLOCKDATA* pstClockData,
                      INT        nClockNumber )
{

	INT nRet;

	nRet = initDefault_AS_DS( pstPtpInfSet, pstClockData, nClockNumber );
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initParentDS(&pstClockData->stDefaultDS, &pstClockData->stParentDS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}

	nRet = initCurrent_AS_DS(pstPtpInfSet, &pstClockData->stCurrent_1AS_DS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initParent_AS_DS(pstPtpInfSet, &pstClockData->stParent_1AS_DS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initPthTrace_AS_DS(pstPtpInfSet, &pstClockData->stPathTrace_1AS_DS);
	if (nRet != RET_ENOERR) {
		return nRet;
	}
	nRet = initCmldsDefault_AS_DS( pstPtpInfSet, &gpstCmldsPtr->stCmldsDefault_1AS_DS );

	return nRet;
}
#endif


#ifdef	PTP_USE_IEEE1588
static INT initDefaultDS( PTPINFSET* pstPtpInfSet, 
						  CLOCKDATA* pstClockData,
						  INT 		 nClockNumber )
{
	CLOCKINFSET*	pstClockInfSet;
	BMC_GD* 		pstBmc_Gd;
	DEFAULT_DS*		pstDefaultDS;
	USCALEDNS		stUSNs={0};

	pstClockInfSet	= (CLOCKINFSET*)pstPtpInfSet->pvClockInfo;
	pstClockInfSet	= &pstClockInfSet[nClockNumber];
	pstBmc_Gd		= &(pstClockData->stBMC_GD);
	pstDefaultDS	= &(pstClockData->stDefaultDS);

	(VOID)tsn_Wrapper_MemCpy( (VOID *)&pstDefaultDS->stClockIdentity, 
							  (VOID *)&pstPtpInfSet->pstClockKndInfo->stClockIdentity, 
							  sizeof(CLOCKIDENTITY) );

	pstDefaultDS->usNumberPorts = pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;
	pstDefaultDS->stClockQuality.uchClockClass = pstClockInfSet->stClockQuality.uchClockClass;
	pstDefaultDS->stClockQuality.uchClockAccuracy = pstClockInfSet->stClockQuality.uchClockAccuracy;
	pstDefaultDS->stClockQuality.usOffsetScaledLogVariance = pstClockInfSet->stClockQuality.usOffsetScaledLogVariance;
	pstDefaultDS->uchPriority1 = pstClockInfSet->uchPriority1;

	pstDefaultDS->uchPriority2 = pstClockInfSet->uchPriority2;

	pstDefaultDS->uchDomainNumber = pstClockInfSet->uchDomainNum;
	stUSNs.ulNsec_lsb = pstClockInfSet->ulDelayRespTimeout;
	(VOID)ptpMultUSNs_ULONG( &stUSNs, 1000U, &pstClockData->stUn_Clock_GD.stClock_1588_GD.stDelayRespTimeout );

	tsn_Wrapper_MemSet(&stUSNs, 0x00, sizeof(USCALEDNS));
	stUSNs.ulNsec_lsb = pstClockInfSet->ulSyncSendHoldTime;
	(VOID)ptpMultUSNs_ULONG( &stUSNs, 1000U, &pstClockData->stClock_GD.stSyncSendHoldTime );

	tsn_Wrapper_MemSet(&stUSNs, 0x00, sizeof(USCALEDNS));
	stUSNs.ulNsec_lsb = pstClockInfSet->ulDReqSendHoldTime;
	(VOID)ptpMultUSNs_ULONG( &stUSNs, 1000U, &pstClockData->stUn_Clock_GD.stClock_1588_GD.stDReqSendHoldTime );


	if (pstClockInfSet->blExternalPortConfiguration == TRUE)
	{
		pstBmc_Gd->blExternalPortConfiguration = TRUE;
	}
	else if (pstClockInfSet->blExternalPortConfiguration == FALSE)
	{
		pstBmc_Gd->blExternalPortConfiguration = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	pstBmc_Gd->blPathTraceEnable = FALSE;

	tsn_Wrapper_MemCpy (&pstClockData->stClock_GD.stAveDelayTrash, &pstClockInfSet->stAveDelayTrash, sizeof(USCALEDNS));

	if (MDSYCR_STACK_N < STACK_N_MIN)
	{
		return	RET_EINVAL;
	}
	if (MDSYCR_STACK_N > STACK_N_MAX)
	{
		return	RET_EINVAL;
	}
	if (pstClockInfSet->uchRateCalDatNum < STACK_N_MIN)
	{
		return	RET_EINVAL;
	}
	else if (pstClockInfSet->uchRateCalDatNum > MDSYCR_STACK_N)
	{
		return	RET_EINVAL;
	}

	pstClockData->stClock_GD.uchRateCalDatNum = pstClockInfSet->uchRateCalDatNum;


	return RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE1588
INT initCurrentDS(PTPINFSET* pstPtpInfSet, CURRENT_DS* pstCurrentDS)
{
	return RET_ENOERR;
}
#endif
INT initParentDS(DEFAULT_DS* pstDefaultDS, PARENT_DS* pstParentDS)
{
	(VOID)tsn_Wrapper_MemCpy(&pstParentDS->stParentPortIdentity, &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
	pstParentDS->stParentPortIdentity.usPortNumber = 0;

	(VOID)tsn_Wrapper_MemCpy(&pstParentDS->stGrandmasterIdentity, &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
	(VOID)tsn_Wrapper_MemCpy(&pstParentDS->stGrandmasterClockQuality, &pstDefaultDS->stClockQuality, sizeof(CLOCKQUALITY));
	pstParentDS->uchGrandmasterPriority1 = pstDefaultDS->uchPriority1;

	pstParentDS->uchGrandmasterPriority2 = pstDefaultDS->uchPriority2;

	return RET_ENOERR;
}
#ifdef	PTP_USE_IEEE1588
INT initTimePropertiesDS(PTPINFSET* pstPtpInfSet, TIMEPROPERTIES_DS* pstTimeProDS)
{
	return RET_ENOERR;
}
static INT initDefault_1588_DS( PTPINFSET* 		 pstPtpInfSet, 
								DEFAULT_1588_DS* pstDefault1588_DS, 
								INT 			 nClockNumber )
{
	CLOCKINFSET* pstClockInfSet;

	pstClockInfSet = pstPtpInfSet->pvClockInfo;
	pstClockInfSet = &pstClockInfSet[nClockNumber];

	if(pstClockInfSet->blTwoStepFlag == TRUE)
	{
		pstDefault1588_DS->blTwoStepFlag = TRUE;
	}
	else if (pstClockInfSet->blTwoStepFlag == FALSE)
	{
		pstDefault1588_DS->blTwoStepFlag = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstClockInfSet->blSlaveOnly == TRUE)
	{
		if (pstClockInfSet->stClockQuality.uchClockClass == 255)
		{
			pstDefault1588_DS->blSlaveOnly = TRUE;
		}
		else
		{
			return	RET_EINVAL;
		}
	}
	else if (pstClockInfSet->blSlaveOnly == FALSE)
	{
		pstDefault1588_DS->blSlaveOnly = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	return	RET_ENOERR;
}

INT initCurrent_1588_DS(PTPINFSET* pstPtpInfSet, CURRENT_1588_DS* pstCurrent_1588_DS)
{
	return	RET_ENOERR;
}

INT initParent_1588_DS(PTPINFSET* pstPtpInfSet, PARENT_1588_DS* pstParent1588_DS)
{
	pstParent1588_DS->blParentStats = FALSE;

	pstParent1588_DS->usObservedPOSLogVariance = OFFSETSCALEDLOGVALIANCE_MAX;

	return	RET_ENOERR;
}

#ifdef	PTP_USE_TRANS
static INT initTransDefault_1588_DS( PTPINFSET* 		pstPtpInfSet, 
									 TCDEFAULT_1588_DS* pstTcDefault1588_DS, 
									 INT 				nClockNumber )
{
	TRANSPARENT_CLOCKINFSET* pstTrnsClockInfSet;

	pstTrnsClockInfSet = (TRANSPARENT_CLOCKINFSET*)pstPtpInfSet->pvClockInfo;
	pstTrnsClockInfSet = &pstTrnsClockInfSet[nClockNumber];


	(VOID)tsn_Wrapper_MemCpy(&pstTcDefault1588_DS->stClockIdentity, &pstTrnsClockInfSet->stClockIdentity, sizeof(CLOCKIDENTITY));

	if (pstTrnsClockInfSet->enDelayMechanism == DELAY_E2E)
	{
		pstTcDefault1588_DS->enDdelayMechanism = ENUM_DELAYMECHANISM_E2E;
	}
	else if (pstTrnsClockInfSet->enDelayMechanism == DELAY_P2P)
	{
		pstTcDefault1588_DS->enDdelayMechanism = ENUM_DELAYMECHANISM_P2P;
	}
	else
	{
		return	RET_EINVAL;
	}

	pstTcDefault1588_DS->usNumberPorts = pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;

	pstTcDefault1588_DS->uchPprimaryDomain = 0;

	tsn_Wrapper_MemCpy (&gpstClockDataHPtr->stClock_GD.stAveDelayTrash, &pstTrnsClockInfSet->stAveDelayTrash, sizeof(USCALEDNS));

	return	RET_ENOERR;
}
#endif

#endif

#ifdef	PTP_USE_IEEE802_1
static INT initDefault_AS_DS( PTPINFSET* pstPtpInfSet, 
							  CLOCKDATA* pstClockData,
							  INT 		 nClockNumber )
{
	CLOCKASINFSET*	pstClockAsInfSet;
	DEFAULT_1AS_DS* pstDefault_1AS_DS;
	DEFAULT_DS* 	pstDefault_DS;
	USCALEDNS		stUSNs={0};

	pstClockAsInfSet = (CLOCKASINFSET *)pstPtpInfSet->pvClockInfo;
	pstClockAsInfSet = &pstClockAsInfSet[nClockNumber];


	pstDefault_DS	  = &(pstClockData->stDefaultDS);
	pstDefault_1AS_DS = &(pstClockData->stDefault_1AS_DS);

	(VOID)tsn_Wrapper_MemCpy( (VOID *)&pstDefault_DS->stClockIdentity, 
							  (VOID *)&pstPtpInfSet->pstClockKndInfo->stClockIdentity, 
							  sizeof(CLOCKIDENTITY) );

	pstDefault_DS->usNumberPorts = pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;
	pstDefault_DS->stClockQuality.uchClockClass = pstClockAsInfSet->stClockQuality.uchClockClass;
	pstDefault_DS->stClockQuality.uchClockAccuracy = pstClockAsInfSet->stClockQuality.uchClockAccuracy;
	pstDefault_DS->stClockQuality.usOffsetScaledLogVariance = pstClockAsInfSet->stClockQuality.usOffsetScaledLogVariance;
	pstDefault_DS->uchPriority1 = pstClockAsInfSet->uchPriority1;

	pstDefault_DS->uchPriority2 = pstClockAsInfSet->uchPriority2;

	pstDefault_DS->uchDomainNumber = pstClockAsInfSet->uchDomainNum;


	if (pstClockAsInfSet->blGmCapable == TRUE)
	{
		if (pstClockAsInfSet->uchPriority1 == LOWEST_PRI_FOR_BMCA)
		{
			return	RET_EINVAL;
		}

		if (pstClockAsInfSet->stClockQuality.uchClockClass == LOWEST_PRI_FOR_BMCA)
		{
			return	RET_EINVAL;
		}
		else
		{
			pstDefault_1AS_DS->blGmCapable = TRUE;
		}
	}
	else
	{
		if (pstClockAsInfSet->blGmCapable == FALSE) {
			if (pstClockAsInfSet->uchPriority1 != LOWEST_PRI_FOR_BMCA)
			{
				return	RET_EINVAL;
			}
			if (pstClockAsInfSet->stClockQuality.uchClockClass != LOWEST_PRI_FOR_BMCA)
			{
				return	RET_EINVAL;
			}
			pstDefault_1AS_DS->blGmCapable = FALSE;
		}
	}

	pstDefault_1AS_DS->blInstanceEnable = TRUE;
	pstDefault_1AS_DS->sCurrentUtcOffset = 0;
	pstDefault_1AS_DS->blCurrentUtcOffsetValid = FALSE;
	pstDefault_1AS_DS->blLeap59 = FALSE;
	pstDefault_1AS_DS->blLeap61 = FALSE;
	pstDefault_1AS_DS->blTimeTraceable = FALSE;
	pstDefault_1AS_DS->uchTimeSource = TIMESOURCE_INTREVAL_OSCILLATOR;
	pstDefault_1AS_DS->blFrequencyTraceable = FALSE;
	pstDefault_1AS_DS->blPtpTimescale = FALSE;

	pstDefault_1AS_DS->usSdoId = PTPM_MAJOR_SDOID_1<<8;

	if (pstClockAsInfSet->blExternalPortConfiguration == TRUE)
	{
		pstDefault_1AS_DS->blExternalPortConfiguration = TRUE;
		pstClockData->stBMC_GD.blExternalPortConfiguration = TRUE;

	}
	else if (pstClockAsInfSet->blExternalPortConfiguration == FALSE)
	{
		pstDefault_1AS_DS->blExternalPortConfiguration = FALSE;
		pstClockData->stBMC_GD.blExternalPortConfiguration = FALSE;

	}
	else
	{
		return	RET_EINVAL;
	}

	tsn_Wrapper_MemCpy (&pstClockData->stClock_GD.stAveDelayTrash, &pstClockAsInfSet->stAveDelayTrash, sizeof(USCALEDNS));

	{
		USCALEDNS	stTempUSNs;

		tsn_Wrapper_MemSet(&stTempUSNs, 0x00, sizeof(USCALEDNS));
		stTempUSNs.ulNsec_lsb = pstClockAsInfSet->ulSyncTransTimeout;
		(VOID)ptpMultUSNs_ULONG (&stTempUSNs, 1000U, &pstClockData->stClock_GD.stSyncTransTimeout);
	}

	if (MDPDLYRATIO_STACK_N < STACK_N_MIN)
	{
		return	RET_EINVAL;
	}
	if (MDPDLYRATIO_STACK_N > STACK_N_MAX)
	{
		return	RET_EINVAL;
	}
	if (pstClockAsInfSet->uchRateCalDatNum < STACK_N_MIN)
	{
		return	RET_EINVAL;
	}
	else if (pstClockAsInfSet->uchRateCalDatNum > MDPDLYRATIO_STACK_N)
	{
		return	RET_EINVAL;
	}

	pstClockData->stClock_GD.uchRateCalDatNum = pstClockAsInfSet->uchRateCalDatNum;

	stUSNs.ulNsec_lsb = pstClockAsInfSet->ulSyncSendHoldTime;
	(VOID)ptpMultUSNs_ULONG( &stUSNs, 1000U, &pstClockData->stClock_GD.stSyncSendHoldTime );


	return	RET_ENOERR;
}

INT initCurrent_AS_DS(PTPINFSET* pstPtpInfSet, CURRENT_1AS_DS* pstCurrentAS_DS)
{
	return	RET_ENOERR;
}

INT initParent_AS_DS(PTPINFSET* pstPtpInfSet, PARENT_1AS_DS* pstParentAS_DS)
{
	return	RET_ENOERR;
}

INT initPthTrace_AS_DS(PTPINFSET* pstPtpInfSet, PATHTRACE_1AS_DS* pstPathTraceAS_DS)
{
	pstPathTraceAS_DS->blEnable = TRUE;

	return	RET_ENOERR;
}

INT initCmldsDefault_AS_DS(PTPINFSET* pstPtpInfSet, CMLDSDEFAULT_1AS_DS* pstCmldsDefaultAS_DS)
{


	(VOID)tsn_Wrapper_MemCpy( &pstCmldsDefaultAS_DS->stClockIdentity, 
							  &pstPtpInfSet->pstClockKndInfo->stClockIdentity, 
							  sizeof(CLOCKIDENTITY) );

	pstCmldsDefaultAS_DS->usNumberPorts = pstPtpInfSet->pstClockKndInfo->uchInterfaceNum;

	pstCmldsDefaultAS_DS->usSdoId = PTPM_MAJOR_SDOID_2<<8;

	return	RET_ENOERR;
}
#endif



#ifdef	PTP_USE_IEEE1588
static INT	initFor1588boundPort( PTPINFSET* pstPtpInfSet, 
						 		  CLOCKDATA* pstClockData,
						 		  INT 		 nClockNumber )
{
	USHORT	usLoopCnt;
	INT		nRet;
	PORTDATA* pstPortData;
	BOOL	blMasterPort,blGrandMasterPort;
	PORTINFSET* 	pstPortInfSet;
	INT 			nIndex;

	blGrandMasterPort = TRUE;

	pstPortData = pstClockData->pstPortData;
	for(usLoopCnt = 0U;
		usLoopCnt < pstClockData->stDefaultDS.usNumberPorts;
		usLoopCnt++)
	{
		nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usLoopCnt;
		pstPortInfSet = (PORTINFSET *)pstPtpInfSet->pvPortInfo;
		pstPortInfSet = &pstPortInfSet[nIndex];

		nRet = initPortDS(pstPortInfSet, pstClockData, pstPortData, usLoopCnt, &blMasterPort);
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}

		nRet = initPort_GDFor1588bound( pstPtpInfSet, 
										pstClockData, 
										nClockNumber, 
										pstPortData, 
										usLoopCnt );
		if ( nRet != RET_ENOERR )
		{
			return nRet;
		}
		nRet = initPort_1588_DS( pstPtpInfSet, 
								 pstClockData, 
								 nClockNumber, 
								 pstPortData, 
								 usLoopCnt, 
								 &blMasterPort );
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}
		if (blGrandMasterPort == TRUE)
		{
			if (blMasterPort == FALSE)
			{
				blGrandMasterPort = FALSE;
			}
		}

		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	if(blGrandMasterPort==TRUE)
	{
		pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[0] = SlavePort;
		pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_SLAVE;
	}
	else
	{
		pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[0] = PassivePort;
		pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_PASSIVE;
	}
	return	RET_ENOERR;
}

#ifdef	PTP_USE_TRANS
static INT	initFor1588TransPort( PTPINFSET* pstPtpInfSet, 
								  CLOCKDATA* pstClockData,
								  INT 		 nClockNumber )
{
	USHORT	usLoopCnt;
	INT		nRet;
	PORTDATA* pstPortData;

	pstPortData = pstClockData->pstPortData;
	for(usLoopCnt = 0;
		usLoopCnt < pstClockData->stDefaultDS.usNumberPorts;
		usLoopCnt++)
	{
		nRet = initTransPort_1588_DS( pstPtpInfSet, 
									  pstClockData,
									  nClockNumber, 
									  pstPortData, 
									  usLoopCnt );
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}
		nRet = initPort_GDFor1588Trans( pstPtpInfSet, 
										pstClockData, 
										nClockNumber, 
										pstPortData, 
										usLoopCnt );
		if ( nRet != RET_ENOERR )
		{
			return nRet;
		}

		pstPortData = pstPortData->pstNextPortDataPtr;
	}
	return	RET_ENOERR;
}
#endif

#endif

#ifdef	PTP_USE_IEEE802_1
static  INT initForASPort( PTPINFSET* pstPtpInfSet, 
						   CLOCKDATA* pstClockData, 
						   INT 		  nClockNumber )
{
	USHORT	usLoopCnt;
	INT		nRet;
	PORTDATA* pstPortData;
	BOOL	blMasterPort;
	BOOL	blGrandMasterPort;
	CLOCKASINFSET*	pstClockAsInfSet;
	PORTASINFSET*	pstPortAsInfSet;
	INT nIndex;

	blGrandMasterPort = TRUE;

	pstPortData = pstClockData->pstPortData;
	for(usLoopCnt = 0;
		usLoopCnt < pstClockData->stDefaultDS.usNumberPorts;
		usLoopCnt++)
	{
		pstClockAsInfSet = (CLOCKASINFSET *)pstPtpInfSet->pvClockInfo;
		pstClockAsInfSet = &pstClockAsInfSet[nClockNumber];

		nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usLoopCnt;
		pstPortAsInfSet = (PORTASINFSET *)pstPtpInfSet->pvPortInfo;
		pstPortAsInfSet = &pstPortAsInfSet[nIndex];

		nRet = initPortDSForAS( pstPortAsInfSet, pstClockData, pstPortData, usLoopCnt, &blMasterPort );
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}
		nRet = initPort_AS_DS( pstPortAsInfSet, pstClockData, pstPortData, usLoopCnt );
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}

		nRet = initDescriptPort_AS_DS( pstPortAsInfSet, pstClockData, pstPortData, usLoopCnt );
		if (nRet != RET_ENOERR)
		{
			return nRet;
		}
		nRet = initPort_GDForAS( pstPtpInfSet, 
								 pstClockData, 
								 nClockNumber, 
								 pstPortData, 
								 usLoopCnt );
		if ( nRet != RET_ENOERR )
		{
			return nRet;
		}

		if ( pstClockAsInfSet->uchDomainNum == 0U )
		{
			nRet = initCmldsPort_AS_DS( pstPortAsInfSet, 
										pstClockData, 
										pstPortData, 
										usLoopCnt);
			if (nRet != RET_ENOERR)
			{
				return nRet;
			}
		}

		if (blGrandMasterPort == TRUE)
		{
			if (blMasterPort == FALSE)
			{
				blGrandMasterPort = FALSE;
			}
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	if(blGrandMasterPort == TRUE)
	{
		pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_SLAVE;
	}
	else
	{
		pstClockData->stClock_GD.enSelectedState[0] = ENUM_PORTSTATE_PASSIVE;
	}

	return	RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE1588
static INT initPortDS( PORTINFSET* 	pstPortInfSet, 
					   CLOCKDATA* 	pstClockData, 
					   PORTDATA* 	pstPortData, 
					   USHORT 		usPortNumber, 
					   BOOL* 		pblMasterPort )
{
	PORT_DS*		pstPortDS;
	BMC_GD* 		pstBmc_Gd;


	pstPortDS	  = &(pstPortData->stPortDS);
	pstBmc_Gd	  = &(pstClockData->stBMC_GD);

	*pblMasterPort = FALSE;

	(VOID)tsn_Wrapper_MemCpy(&pstPortDS->stPortIdentity, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
	pstPortDS->stPortIdentity.usPortNumber = usPortNumber+1;


	if(pstBmc_Gd->blExternalPortConfiguration)
	{
		pstPortData->stPAIExtSM_GD.enPortStateInd = (ENUM_PORTSTATE)pstPortInfSet->enPortState;

		if(pstPortInfSet->enPortState == MasterPort)
		{
			*pblMasterPort = TRUE;
		}
	}
	else
	{
		pstClockData->stClock_GD.enSelectedState[usPortNumber+1] = ENUM_PORTSTATE_DISABLED;
		pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber+1] = DisabledPort;
	}

	pstPortDS->uchAnnounceReceiptTimeout = pstPortInfSet->uchAnnounceReceiptTimeout;

	pstPortDS->byVersionNumber = PTPM_VER_PTP_2;

	return	RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE802_1
static INT initPortDSForAS( PORTASINFSET*	pstPortAsInfSet,
							CLOCKDATA* 		pstClockData, 
							PORTDATA* 		pstPortData, 
							USHORT 			usPortNumber, 
							BOOL* 			pblMasterPort )
{
	PORT_DS*		pstPortDS;
	BMC_GD* 		pstBmc_Gd;
	PORTDATA*		pstPortDataWk;


	pstPortDataWk	= pstPortData;
	pstPortDS		= &(pstPortDataWk->stPortDS);
	pstBmc_Gd		= &(pstClockData->stBMC_GD);

	*pblMasterPort = FALSE;

	(VOID)tsn_Wrapper_MemCpy(&pstPortDS->stPortIdentity, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
	pstPortDS->stPortIdentity.usPortNumber = usPortNumber+1;

	if(pstBmc_Gd->blExternalPortConfiguration)
	{
		switch(pstPortAsInfSet->enPortState)
		{
			case	DisabledPort:
			case	MasterPort:
			case	PassivePort:
			case	SlavePort:
				pstPortData->stPAIExtSM_GD.enPortStateInd = (ENUM_PORTSTATE)pstPortAsInfSet->enPortState;

					break;
			default:
				return	RET_EINVAL;
		}
		if(pstPortAsInfSet->enPortState != SlavePort)
		{
			*pblMasterPort = TRUE;
		}
	}
	else
	{
		pstClockData->stClock_GD.enSelectedState[usPortNumber+1] = ENUM_PORTSTATE_DISABLED;
	}

	pstPortDS->uchAnnounceReceiptTimeout = pstPortAsInfSet->uchAnnounceReceiptTimeout;

	pstPortDS->byVersionNumber = PTPM_VER_PTP_2;

	return	RET_ENOERR;
}

static INT initPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
						   CLOCKDATA* 		pstClockData, 
						   PORTDATA* 		pstPortData, 
						   USHORT 			usPortNumber )
{
	PORT_1AS_DS*	pstPortAsDS;


	pstPortAsDS	  = &(pstPortData->stPort_1AS_DS);

	pstPortAsDS->blPtpPortEnabled = TRUE;

	pstPortAsDS->blAsCapable	  = FALSE;

	if ((pstPortAsInfSet->chInitialLogAnnounceInt == 127) || ((pstPortAsInfSet->chInitialLogAnnounceInt >= -124) && (pstPortAsInfSet->chInitialLogAnnounceInt <= 123)))
	{
		pstPortAsDS->chInitialLogAnnounceInterval = pstPortAsInfSet->chInitialLogAnnounceInt;
	}
	else
	{
		return	RET_EINVAL;
	}

	pstPortAsDS->blUseMgtSetLogAnnounceInterval = pstPortAsInfSet->blUseMgtSettableLogAnnounceInt;

	if ((pstPortAsInfSet->chMgtSettableLogAnnounceInt == 127) || ((pstPortAsInfSet->chInitialLogAnnounceInt >= -124) && (pstPortAsInfSet->chInitialLogAnnounceInt <= 123)))
	{
		pstPortAsDS->chMgtSettableLogAnnounceInterval = pstPortAsInfSet->chMgtSettableLogAnnounceInt;
	}
	else
	{
		return	RET_EINVAL;
	}

	if ((pstPortAsInfSet->chInitialLogSyncInt == 127) || ((pstPortAsInfSet->chInitialLogSyncInt >= -124) && (pstPortAsInfSet->chInitialLogSyncInt <= 123)))
	{
		pstPortAsDS->chInitialLogSyncInterval = pstPortAsInfSet->chInitialLogSyncInt;
	}
	else
	{
		return	RET_EINVAL;
	}


	pstPortAsDS->blUseMgtSettableLogSyncInterval = pstPortAsInfSet->blUseMgtSettableLogSyncInt;

	if ((pstPortAsInfSet->chMgtSettableLogSyncInt == 127) || ((pstPortAsInfSet->chMgtSettableLogSyncInt >= -124) && (pstPortAsInfSet->chMgtSettableLogSyncInt <= 123)))
	{
		pstPortAsDS->chMgtSettableLogSyncInterval = pstPortAsInfSet->chMgtSettableLogSyncInt;
	}
	else
	{
		return	RET_EINVAL;
	}

	pstPortAsDS->uchSyncReceiptTimeout = pstPortAsInfSet->uchSyncReceiptTimeout;

	if(pstPortAsInfSet->blOneStepTransmit == TRUE)
	{
		pstPortAsDS->blOneStepTransmit = TRUE;
	}
	else if (pstPortAsInfSet->blOneStepTransmit == FALSE)
	{
		pstPortAsDS->blOneStepTransmit = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstPortAsInfSet->blInitialOneStepTxOper == TRUE)
	{
		pstPortAsDS->blInitialOneStepTxOper = TRUE;
	}
	else if (pstPortAsInfSet->blInitialOneStepTxOper == FALSE)
	{
		pstPortAsDS->blInitialOneStepTxOper = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstPortAsInfSet->blUseMgtSettableOneStepTxOper == TRUE)
	{
		pstPortAsDS->blUseMgtSettableOneStepTxOper = TRUE;
	}
	else if(pstPortAsInfSet->blUseMgtSettableOneStepTxOper == FALSE)
	{
		pstPortAsDS->blUseMgtSettableOneStepTxOper = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstPortAsInfSet->blMgtSettableOneStepTxOper == TRUE)
	{
		pstPortAsDS->blMgtSettableOneStepTxOper = TRUE;
	}
	else if(pstPortAsInfSet->blMgtSettableOneStepTxOper == FALSE)
	{
		pstPortAsDS->blMgtSettableOneStepTxOper = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}
	
	if (   (pstPortAsInfSet->chLogGptpCapMsgInt < -24)
        || (pstPortAsInfSet->chLogGptpCapMsgInt > 24) )
	{
		return RET_EINVAL;
	}
	pstPortAsDS->chInitialLogGptpCapMsgInt = pstPortAsInfSet->chLogGptpCapMsgInt;

	pstPortAsDS->blSyncLocked = FALSE;

	pstPortAsDS->byMinorVersionNumber = PTPM_MINOR_VER_PTP_1;

	pstPortAsDS->blOneStepReceive = TRUE;

	pstPortAsDS->uchGPtpCapableReceiptTimeout = pstPortAsInfSet->uchGptpCapReceiptTimeout;

	return	RET_ENOERR;
}

static INT initDescriptPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
								   CLOCKDATA* 		pstClockData, 
								   PORTDATA* 		pstPortData, 
								   USHORT 			usPortNumber )
{


	(VOID)tsn_Wrapper_MemCpy(&pstPortData->stDescriptionPort_1AS_DS.stProfileIdentifier, PTP_Profile_ID, sizeof(OCTET6));

	return	RET_ENOERR;
}

static INT initCmldsPort_AS_DS( PORTASINFSET*	pstPortAsInfSet, 
								CLOCKDATA* 		pstClockData, 
								PORTDATA* 		pstPortData, 
								USHORT 			usPortNumber )
{
	CMLDSPORT_1AS_DS* pstCmldsPortAsDs;


	pstCmldsPortAsDs = &gpstCmldsPtr->stCmldsPortManage[usPortNumber].stCmldsPort_1AS_DS;


	(VOID)tsn_Wrapper_MemCpy(&pstCmldsPortAsDs->stPortIdentity, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
	pstCmldsPortAsDs->stPortIdentity.usPortNumber = usPortNumber+1;

	pstCmldsPortAsDs->stDelayAsymmetry.sNsec_msb = 0;
	pstCmldsPortAsDs->stDelayAsymmetry.ulNsec_2nd = 0;
	pstCmldsPortAsDs->stDelayAsymmetry.ulNsec_lsb = 0;
	pstCmldsPortAsDs->stDelayAsymmetry.usFrcNsec = 0;

	if ((pstPortAsInfSet->chInitialLogPdelayReqInt == 127) || ((pstPortAsInfSet->chInitialLogPdelayReqInt >= -124) && (pstPortAsInfSet->chInitialLogPdelayReqInt <= 123)))
	{
		pstCmldsPortAsDs->chInitialLogPdelayReqInterval = pstPortAsInfSet->chInitialLogPdelayReqInt;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstPortAsInfSet->blUseMgtSettableLogPdelayReqInt == TRUE)
	{
		pstCmldsPortAsDs->blUseMgtSttblLogPdReqInterval = TRUE;
	}
	else if (pstPortAsInfSet->blUseMgtSettableLogPdelayReqInt == FALSE)
	{
		pstCmldsPortAsDs->blUseMgtSttblLogPdReqInterval = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if ((pstPortAsInfSet->chMgtSettableLogPdelayReqInt == 127) || ((pstPortAsInfSet->chMgtSettableLogPdelayReqInt >= -124) && (pstPortAsInfSet->chMgtSettableLogPdelayReqInt <= 123)))
	{
		pstCmldsPortAsDs->chMgtSttblLogPdReqInterval = pstPortAsInfSet->chMgtSettableLogPdelayReqInt;
	}
	else
	{
		return	RET_EINVAL;
	}

	pstCmldsPortAsDs->usAllowedLostResponses = pstPortAsInfSet->usAllowedLostResponses;

	pstCmldsPortAsDs->usAllowedFaults		 = pstPortAsInfSet->usAllowedFaults;


	pstCmldsPortAsDs->blCmldsPortEnabled = TRUE;

	pstCmldsPortAsDs->stNeighborPropDelayThresh.ulNsec_lsb = PTP_NEIGHBOR_PROPDELAY_THRESH;

	return	RET_ENOERR;

}
#endif



#ifdef	PTP_USE_IEEE1588
static  INT initPort_1588_DS( PTPINFSET* pstPtpInfSet, 
							  CLOCKDATA* pstClockData, 
							  INT        nClockNumber,  
							  PORTDATA*  pstPortData, 
							  USHORT 	 usPortNumber, 
							  BOOL* 	 pblMasterPort )
{
	INT nIndex;
	PORTINFSET*		pstPortInfSet;
	BMC_GD* 		pstBmc_Gd;
	PORT_1588_DS*	pstPort1588Ds;
	CMLDSPORT_1AS_DS* pstCmldsPortAsDs;
	pstCmldsPortAsDs = pstPortData->stPort_1588_GD.pstCmldsPortDs;

	pstBmc_Gd	  = &(pstClockData->stBMC_GD);

	nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usPortNumber;
	pstPortInfSet = (PORTINFSET *)pstPtpInfSet->pvPortInfo;
	pstPortInfSet = &pstPortInfSet[nIndex];

	pstPort1588Ds = &pstPortData->stPort_1588_DS;

	pstPort1588Ds->chLogAnnounceInterval = pstPortInfSet->chInitialLogAnnounceInt;
	pstPort1588Ds->chLogSyncInterval	 = pstPortInfSet->chInitialLogSyncInt;
	*pblMasterPort = FALSE;

	pstPort1588Ds->chLogMinDelayReqInterval  = pstPortInfSet->chLogMinDelayReqInt;
	pstPort1588Ds->chLogMinPdelayReqInterval = pstPortInfSet->chLogMinPdelayReqInt;

	if(pstPortInfSet->enDelayMechanism == DELAY_E2E)
	{
		pstPort1588Ds->enDelayMechanism = ENUM_DELAYMECHANISM_E2E;
		pstCmldsPortAsDs->blCmldsPortEnabled = FALSE;

	}
	else if(pstPortInfSet->enDelayMechanism == DELAY_P2P)
	{
		pstPort1588Ds->enDelayMechanism = ENUM_DELAYMECHANISM_P2P;
		pstCmldsPortAsDs->blCmldsPortEnabled = TRUE;
	}
	else
	{
		return	RET_EINVAL;
	}

	if(pstBmc_Gd->blExternalPortConfiguration)
	{
		switch(pstPortInfSet->enPortState)
		{
			case	DisabledPort:
			case	MasterPort:
			case	PassivePort:
			case	SlavePort:
				pstClockData->stClock_GD.enSelectedState[usPortNumber+1] = (ENUM_SELECTEDSTATE)pstPortInfSet->enPortState;
				pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber+1] = pstPortInfSet->enPortState;
				break;
			default:
				return	RET_EINVAL;
		}
		if(pstPortInfSet->enPortState != SlavePort)
	{
			*pblMasterPort = TRUE;
		}
	}
	else
	{
		pstClockData->stClock_GD.enSelectedState[usPortNumber+1] = (ENUM_SELECTEDSTATE)DisabledPort;
		pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[usPortNumber+1] = DisabledPort;
	}

	if(pstPortInfSet->blUnicast == TRUE)
	{
		if ((pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol == CLK_TRANS_IEEE1588_L4_IPV4) ||
					(pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol == CLK_TRANS_IEEE1588_L4_IPV6))
		{
			pstPortData->stPort_GD.blUnicast = TRUE;
		}
		else
		{
			return	RET_EINVAL;
		}
	}
	else if (pstPortInfSet->blUnicast == FALSE)
	{
		pstPortData->stPort_GD.blUnicast = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}


	return	RET_ENOERR;

}

static INT initTransPort_1588_DS( PTPINFSET* pstPtpInfSet, 
								  CLOCKDATA* pstClockData, 
								  INT 		 nClockNumber,
								  PORTDATA*  pstPortData, 
								  USHORT 	 usPortNumber )
{
	TRANSPARENT_PORTINFSET* pstPortTransInfSet;
	TRANSPARENTCLOCKPORT_1588_DS *pstTransPort_1588_DS;
	INT nIndex;

	pstTransPort_1588_DS = &(pstPortData->stTransparentClockPort_1588_DS);

	nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usPortNumber;
	pstPortTransInfSet = (TRANSPARENT_PORTINFSET *)pstPtpInfSet->pvPortInfo;
	pstPortTransInfSet = &pstPortTransInfSet[nIndex];

	(VOID)tsn_Wrapper_MemCpy(&pstTransPort_1588_DS->stPortIdentity, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
	pstTransPort_1588_DS->stPortIdentity.usPortNumber = usPortNumber+1;

	pstPortData->stPortDS.stPortIdentity.usPortNumber = usPortNumber+1;

	if (pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 == ENUM_CSTYPE_TRANSCLOCKP2P_1588)
	{
		pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled = TRUE;

		pstPortData->stPort_1588_DS.enDelayMechanism = ENUM_DELAYMECHANISM_P2P;
	}
	else
	{
		pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled = FALSE;

		pstPortData->stPort_1588_DS.enDelayMechanism = ENUM_DELAYMECHANISM_E2E;
	}

	pstPortData->stPortDS.byVersionNumber	 = PTPM_VER_PTP_2;

	(VOID)tsn_Wrapper_MemCpy(&pstPortData->stPortDS.stPortIdentity, &pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));

	if(pstPortTransInfSet->blUnicast == TRUE)
	{
		if ((pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol == CLK_TRANS_IEEE1588_L4_IPV4) ||
					(pstPtpInfSet->pstClockKndInfo->enClockTrpProtocol == CLK_TRANS_IEEE1588_L4_IPV6))
		{
			pstPortData->stPort_GD.blUnicast = TRUE;
		}
		else
		{
			return	RET_EINVAL;
		}
	}
	else if (pstPortTransInfSet->blUnicast == FALSE)
	{
		pstPortData->stPort_GD.blUnicast = FALSE;
	}
	else
	{
		return	RET_EINVAL;
	}

	return	RET_ENOERR;
}
#endif


INT initPort_GD(PTPINFSET* pstPtpInfSet, CLOCKDATA* pstClockData, PORTDATA* pstPortData, USHORT usPortNumber)
{
	INT		nRet	= RET_ENOERR;


	pstPortData->pstClockData			= pstClockData;
	pstPortData->stPort_GD.usThisPort	= usPortNumber + 1;

	return	nRet;
}
#ifdef	PTP_USE_IEEE1588
static INT initPort_GDFor1588bound( PTPINFSET* pstPtpInfSet, 
									CLOCKDATA* pstClockData, 
							 		INT        nClockNumber,  
									PORTDATA*  pstPortData, 
									USHORT     usPortNumber )
{
	PORTINFSET*	pstPortInfSet;
	INT	nRet;
	INT nIndex;

	nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usPortNumber;
	pstPortInfSet = (PORTINFSET *)pstPtpInfSet->pvPortInfo;
	pstPortInfSet = &pstPortInfSet[nIndex];

	nRet = initPort_GD( pstPtpInfSet, pstClockData, pstPortData, usPortNumber );
	if ( nRet != RET_ENOERR )
	{
		return nRet;
	}


	pstPortData->stPort_GD.lCmldsPortNumber = 0;
	
	pstPortData->stPort_GD.blPdelayExecFlag = TRUE;
	pstPortData->stPort_GD.blPortValid      = pstPortInfSet->blPortValid;
	

	if (   (gpstMdPdlyTspStk == NULL)
        || (gpstCmldsPort_1AS_DS == NULL)
        || (gpstCmldsPortStatistics_1AS_DS == NULL) )
	{
		return RET_ESTATE;
	}

	pstPortData->stPort_GD.pstPdlyIntStackMan = &gpstMdPdlyTspStk[nIndex];

	pstPortData->stPort_1588_GD.pstCmldsPortDs     = &gpstCmldsPort_1AS_DS[nIndex];
	pstPortData->stPort_1588_GD.pstCmldsPortStatDs = &gpstCmldsPortStatistics_1AS_DS[nIndex];
	
	return	RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE1588
static INT initPort_GDFor1588Trans( PTPINFSET* pstPtpInfSet, 
									CLOCKDATA* pstClockData, 
							 		INT        nClockNumber,  
									PORTDATA*  pstPortData, 
									USHORT     usPortNumber )
{
	TRANSPARENT_CLOCKINFSET*	pstClockTransInfSet;
	TRANSPARENT_PORTINFSET*		pstPortTransInfSet;
	INT	nRet;
	INT nIndex;

	pstClockTransInfSet = (TRANSPARENT_CLOCKINFSET *)pstPtpInfSet->pvClockInfo;
	pstClockTransInfSet = &pstClockTransInfSet[nClockNumber];

	nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usPortNumber;
	pstPortTransInfSet  = (TRANSPARENT_PORTINFSET *)pstPtpInfSet->pvPortInfo;
	pstPortTransInfSet  = &pstPortTransInfSet[nIndex];
	
	nRet = initPort_GD( pstPtpInfSet, pstClockData, pstPortData, usPortNumber );
	if ( nRet != RET_ENOERR )
	{
		return nRet;
	}

	pstPortData->stPort_GD.lCmldsPortNumber = 0;
	
	pstPortData->stPort_GD.blPdelayExecFlag = TRUE;
	pstPortData->stPort_GD.blPortValid      = pstPortTransInfSet->blPortValid;


	if (   (gpstMdPdlyTspStk == NULL)
        || (gpstCmldsPort_1AS_DS == NULL)
        || (gpstCmldsPortStatistics_1AS_DS == NULL) )
	{
		return RET_ESTATE;
	}

	pstPortData->stPort_GD.pstPdlyIntStackMan = &gpstMdPdlyTspStk[nIndex];

	pstPortData->stPort_1588_GD.pstCmldsPortDs     = &gpstCmldsPort_1AS_DS[nIndex];
	pstPortData->stPort_1588_GD.pstCmldsPortStatDs = &gpstCmldsPortStatistics_1AS_DS[nIndex];

	return	RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE802_1
static INT initPort_GDForAS( PTPINFSET* pstPtpInfSet, 
							 CLOCKDATA* pstClockData, 
							 INT        nClockNumber, 
							 PORTDATA*  pstPortData, 
							 USHORT     usPortNumber )
{
	CLOCKASINFSET*	pstClockAsInfSet;
	PORTASINFSET*	pstPortAsInfSet;
	INT	nRet;
	INT	nIndex;

	nRet = initPort_GD( pstPtpInfSet, pstClockData, pstPortData, usPortNumber );
	if ( nRet != RET_ENOERR )
	{
		return nRet;
	}
	nIndex = (INT)pstPtpInfSet->pstClockKndInfo->uchInterfaceNum * nClockNumber + usPortNumber;

	pstClockAsInfSet = (CLOCKASINFSET *)pstPtpInfSet->pvClockInfo;
	pstClockAsInfSet = &pstClockAsInfSet[nClockNumber];

	pstPortAsInfSet  = (PORTASINFSET *)pstPtpInfSet->pvPortInfo;
	pstPortAsInfSet  = &pstPortAsInfSet[nIndex];

	
	pstPortData->stPort_GD.lCmldsPortNumber = (LONG)usPortNumber;
	pstPortData->stPort_GD.blPortValid      = pstPortAsInfSet->blPortValid;

	if ( pstClockAsInfSet->uchDomainNum == 0U )
	{
		if ( gpstCmldsPtr == NULL )
		{
			return RET_ESTATE;
		}
		pstPortData->stPort_GD.blPdelayExecFlag = TRUE;
		gpstCmldsPtr->stCmldsPortManage[usPortNumber].pstExecuteCmldsPortPtr = pstPortData;
	}

	if ( gpstMdPdlyTspStk == NULL )
	{
		return RET_ESTATE;
	}
	pstPortData->stPort_GD.pstPdlyIntStackMan = &gpstMdPdlyTspStk[nIndex];

	return	RET_ENOERR;
}
#endif

#ifdef	PTP_USE_IEEE1588
void initManageClockDescription (CLOCKDATA* pstClockData)
{
	static	UCHAR	uchManufactureID[3] = PTP_1588_MANUFACTURER_ID;
	static	UCHAR	uchProductDescription[] = PTP_1588_PRODUCT_DESCR;
	static	UCHAR	ucRevisionData[] = PTP_1588_REVISION_DATA;

	USHORT	usCount;

	tsn_Wrapper_MemCpy((VOID*)pstClockData->stManagementSM_GD.stMGTClockDscrption.uchManufctrId,(const VOID *)uchManufactureID, (size_t)3);

	usCount = sizeof(PTP_1588_PRODUCT_DESCR);
	if (usCount > 64)
	{
		usCount = 64;
	}
	usCount = getStringLen(&uchProductDescription[0], usCount);
	if (usCount >= sizeof(PTP_1588_PRODUCT_DESCR))
	{
		usCount = sizeof(PTP_1588_PRODUCT_DESCR);
	}


	tsn_Wrapper_MemCpy((VOID*)&(pstClockData->stManagementSM_GD.stMGTClockDscrption.stPrdctDscrption.uchTextField[0]),
					(const VOID *)&uchProductDescription[0], (size_t)usCount);
	pstClockData->stManagementSM_GD.stMGTClockDscrption.stPrdctDscrption.uchTextLength = (UCHAR)usCount;

	usCount = sizeof(PTP_1588_REVISION_DATA);
	if (usCount > 32)
	{
		usCount = 32;
	}
	usCount = getStringLen(&ucRevisionData[0], usCount);
	if (usCount >= sizeof(PTP_1588_REVISION_DATA))
	{
		usCount = sizeof(PTP_1588_REVISION_DATA);
	}

	tsn_Wrapper_MemCpy((VOID*)&(pstClockData->stManagementSM_GD.stMGTClockDscrption.stRevisionData.uchTextField[0]),
					(const VOID *)&ucRevisionData[0], (size_t)usCount);

	pstClockData->stManagementSM_GD.stMGTClockDscrption.stRevisionData.uchTextLength = (UCHAR)usCount;
}
#endif

USHORT	getStringLen(UCHAR* puchPo, USHORT usMaxCnt)
{
	ULONG	ulLoop;

	for(ulLoop=0; ulLoop < usMaxCnt; ulLoop++)
	{
		if (*puchPo ==0)
		{
			break;
		}
		puchPo++;
	}
	return (USHORT)ulLoop;
}

