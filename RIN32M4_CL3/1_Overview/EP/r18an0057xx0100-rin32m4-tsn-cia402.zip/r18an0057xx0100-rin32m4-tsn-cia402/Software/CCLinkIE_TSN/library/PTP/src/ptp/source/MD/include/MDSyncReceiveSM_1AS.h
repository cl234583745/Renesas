/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCRECEIVESM_1AS_H__
#define __MDSYNCRECEIVESM_1AS_H__

#define IsDecMDSyncTwoStep_1AS(a)	MPTPMSG_H_GET_FLAGS0_TWOSTEP(&a->stSyncTwo_1AS.stHeader)

#ifdef __cplusplus
extern "C" {
#endif

VOID MDSyncReceiveSM_1AS(USHORT usEvent, PORTDATA* pstPort);
VOID MDSyncReceiveSM_00_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_01_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_02_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_03_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_04_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_05_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_06_1AS(PORTDATA* pstPort);
VOID MDSyncReceiveSM_NP_1AS(PORTDATA* pstPort);

BOOL MDSynRcv_Discard_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSyncRcv_WtFrFollowUp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynRcv_WtFrSyncTwo_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDSynRcv_WtFrSyncOne_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDSync_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL ConMDFollowUp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

VOID SetMDTwoSyncMgEgresTmstmp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetMDOneSyncMgEgresTmstmp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetMDSyncTwoReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetMDSyncOneReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxMDSyncReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);


VOID SyncTransChkTmo( CLOCKDATA* pstClock );
BOOL ChkSyncTransProcessing( CLOCKDATA* pstClock );


#ifdef __cplusplus
}
#endif

#endif
