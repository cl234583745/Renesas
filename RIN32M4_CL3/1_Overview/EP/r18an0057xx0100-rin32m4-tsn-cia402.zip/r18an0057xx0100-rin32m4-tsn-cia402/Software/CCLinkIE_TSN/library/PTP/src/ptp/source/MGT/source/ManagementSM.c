/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "PTP_GlobalData.h"

#include "ManagementSM.h"
#include "ManagementSM_1AS.h"
#include "ManagementSM_1588.h"
#include "ManagementAPI_1588.h"

#ifdef	PTP_USE_MANAGEMENT
static MGD_CLOCK_DESCRIPTION	ClockDescInfo = {
	0x0f,
	{
		0x01,
		"F"
	},
	0x0001,
	"C",
	{
		0x0000,
		0x0001,
		"B"
	},
	{0x01,0x02,0x03},
	{
		0x01,
		"A"
	},
	{
		0x01,
		"B"
	},
	{
		0x01,
		"C"
	},
	{0x01,0x02,0x03,0x04,0x05,0x06}
};




VOID ManagementSM(UCHAR* puchMsg, USHORT usMsgLen, UCHAR uchInterFaceNo)
{
	ManagementSM_1588(puchMsg, usMsgLen, uchInterFaceNo);
	return;
}
#endif

INT Management_AS( UCHAR  uchAction, 
				   USHORT usParamId_AS, 
				   UCHAR  uchDomainNumber, 
				   USHORT usPortNumber, 
				   UCHAR* puchInfo, 
				   USHORT usInfoSize )
{
	INT nRet;

	nRet = ManagementAPI_AS( uchAction, 
							 usParamId_AS, 
							 uchDomainNumber, 
							 usPortNumber, 
							 puchInfo, 
							 usInfoSize );
	return nRet;
}

INT Management_1588( UCHAR  uchAction, 
					 USHORT usParamId_1588, 
					 UCHAR  uchDomainNumber, 
					 USHORT usPortNumber, 
					 UCHAR* puchInfo, 
					 USHORT usInfoSize )
{
	INT nRet;

	nRet = ManagementAPI_1588( uchAction, 
							   usParamId_1588, 
							   uchDomainNumber, 
							   usPortNumber, 
							   puchInfo, 
							   usInfoSize );
	return nRet;
}




CLOCKDATA* GetMGTClockData( UCHAR uchDomainNumber )
{
	CLOCKDATA* pstClockData;
	
	for ( pstClockData  = gpstClockDataHPtr;
	      pstClockData != NULL;
	      pstClockData  = pstClockData->pstNextClockDataPtr )
	{
		if ( pstClockData->stDefaultDS.uchDomainNumber == uchDomainNumber )
		{
			break;
		}
	}
	return pstClockData;
}
PORTDATA*	GetMGTPortData(CLOCKDATA* pstClockData, USHORT usPortNumber)
{
	PORTDATA*	pstPortData = NULL;

	for (pstPortData = pstClockData->pstPortData;
		 pstPortData != NULL;
		 pstPortData = pstPortData->pstNextPortDataPtr)
	{
		if (pstPortData->stPortDS.stPortIdentity.usPortNumber == usPortNumber)
		{
			break;
		}
	}
	return pstPortData;
}

MANAGEMENTSM_GD* GetManagementSMGlobal(CLOCKDATA* pstClock)
{
	return &pstClock->stManagementSM_GD;
}

VOID HextoCharChar(UCHAR* puchChar, UCHAR uchValue)
{
	
	puchChar[0] = (UCHAR)(uchValue >> 4) & 0x0FU;
	HEXTOCHAR(puchChar[0]);
	puchChar[1] = uchValue & 0x0FU;
	HEXTOCHAR(puchChar[1]);

	return;
}

VOID	HextoShortChar(UCHAR* puchChar, USHORT usValue)
{
	USHORT	work = 0x000fU;
	puchChar[0] = (UCHAR)((usValue >> 4*3) & work);
	HEXTOCHAR(puchChar[0]);
	puchChar[1] = (UCHAR)((usValue >> 4*2) & work);
	HEXTOCHAR(puchChar[1]);
	puchChar[2] = (UCHAR)((usValue >> 4*1) & work);
	HEXTOCHAR(puchChar[2]);
	puchChar[3] = (UCHAR)((usValue >> 4*0) & work);
	HEXTOCHAR(puchChar[3]);
}

VOID	HextoLongChar(UCHAR* puchChar, ULONG ulValue)
{
	ULONG	work = 0x0000000f;
	puchChar[0] = (UCHAR)((ulValue >> 4*7) & work);
	HEXTOCHAR(puchChar[0]);
	puchChar[1] = (UCHAR)((ulValue >> 4*6) & work);
	HEXTOCHAR(puchChar[1]);
	puchChar[2] = (UCHAR)((ulValue >> 4*5) & work);
	HEXTOCHAR(puchChar[2]);
	puchChar[3] = (UCHAR)((ulValue >> 4*4) & work);
	HEXTOCHAR(puchChar[3]);
	puchChar[4] = (UCHAR)((ulValue >> 4*3) & work);
	HEXTOCHAR(puchChar[4]);
	puchChar[5] = (UCHAR)((ulValue >> 4*2) & work);
	HEXTOCHAR(puchChar[5]);
	puchChar[6] = (UCHAR)((ulValue >> 4*1) & work);
	HEXTOCHAR(puchChar[6]);
	puchChar[7] = (UCHAR)((ulValue >> 4*0) & work);
	HEXTOCHAR(puchChar[7]);
}

#ifdef	PTP_USE_MANAGEMENT

VOID SetDescriptionInfo(CLOCKDATA* pstClockData)
{
	MANAGEMENTSM_GD*		pstManageGD	= &pstClockData->stManagementSM_GD;
	MGD_CLOCK_DESCRIPTION*	pstDescGD		= &pstManageGD->stMGTClockDscrption;

#if 1
	tsn_Wrapper_MemCpy( pstDescGD, &ClockDescInfo, sizeof(MGD_CLOCK_DESCRIPTION));
#else
	pstDescGD->byClockType = 0;

	pstDescGD->stPhyLayerPrtcl.ucTextLength 		= 0;
	pstDescGD->stPhyLayerPrtcl.ucTextField[0] 		= 0;

	pstDescGD->usPhyAddrLength						= 0;
	pstDescGD->uchPhysAddress[0]					= 0;

	pstDescGD->stPrtclAddress.usNetworkProtcol		= 0;
	pstDescGD->stPrtclAddress.usAddressLength		= 0;
	pstDescGD->stPrtclAddress.uchAddressField[0]	= 0;

	pstDescGD->uchManufctrId[0]					= 0;
	pstDescGD->uchManufctrId[1]					= 0;
	pstDescGD->uchManufctrId[2]					= 0;

	pstDescGD->stPrdctDscrption.ucTextLength		= 0;
	pstDescGD->stPrdctDscrption.ucTextField[0]		= 0;

	pstDescGD->stRevisionData.ucTextLength			= 0;
	pstDescGD->stRevisionData.ucTextField[0]		= 0;

	pstDescGD->stUserDscrption.ucTextLength		= 0;
	pstDescGD->stUserDscrption.ucTextField[0]		= 0;

	pstDescGD->uchProfileId[0]						= 0;
#endif
}
#endif
