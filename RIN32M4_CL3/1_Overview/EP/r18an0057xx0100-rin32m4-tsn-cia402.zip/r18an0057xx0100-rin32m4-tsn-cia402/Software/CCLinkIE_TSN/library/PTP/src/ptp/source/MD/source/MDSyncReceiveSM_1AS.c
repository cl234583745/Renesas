/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"


#include "PTP_GlobalData.h"

#include "MDSyncReceiveSM.h"
#include "MDSyncReceiveSM_1AS.h"

#include "ptp_PSSReceive_1AS.h"

#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"
#include "MDSyncReceiveSM_1AS.h"

#include "ptp_CSSync_1AS.h"

#define	D_FUNC		0
#define D_SYNCTO	0

#ifdef	PTP_USE_IEEE802_1

#ifdef	OFFSET_DEBUG
extern	USHORT	usPtpDebugLogCount;
extern	BOOL	blPtpOffsetUnder50Flag;
extern	BOOL	blPtpOffsetUpper500Flag;

#define	MAX_CORRECTIONTLOG	64

typedef	struct	tagCORRECTIONLOG	{
	USHORT		ulType;
	USHORT		usPortNo;
	USCALEDNS	stSyncEventIngressTimestamp_Frun;
	TIMESTAMP	stSyncEventIngressTimestamp;
	USCALEDNS	stNeighborPropDelay;
	DOUBLE		dbNeighborRateRatio;
	USCALEDNS	stNeighborPropDelay2;
	USCALEDNS	stUpstreamTxTime;
	USCALEDNS	stSyncEgTimestamp_Frun;
	TIMESTAMP	stSyncEgTimestamp;
	USCALEDNS	stUpstreamTxTime2;
	SCALEDNS	ststayTime;
	DOUBLE		dbRateRatio;
	FRAC_NSEC64	stCorrectionField;
	TIMESTAMP	stSyncEventIngressTimestamp_Frun_TS;
	USHORT		usSequenceId;
	USHORT		usPortNumber;
	USHORT		usCorrectiontLogCount;
}	CORRECTIONLOG;

CORRECTIONLOG	stCorrectiontLog[MAX_CORRECTIONTLOG];

USHORT	usCorrectiontLogCount = 0;
#endif

VOID (*const MDSyncReceiveSM_1AS_Matrix[DMDSYCR_STATUS_MAX][DMDSYCR_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDSyncReceiveSM_01_1AS ,&MDSyncReceiveSM_NP_1AS ,&MDSyncReceiveSM_NP_1AS ,&MDSyncReceiveSM_NP_1AS, &MDSyncReceiveSM_NP_1AS},
	{&MDSyncReceiveSM_01_1AS ,&MDSyncReceiveSM_03_1AS ,&MDSyncReceiveSM_NP_1AS ,&MDSyncReceiveSM_NP_1AS, &MDSyncReceiveSM_00_1AS},
	{&MDSyncReceiveSM_02_1AS ,&MDSyncReceiveSM_04_1AS ,&MDSyncReceiveSM_05_1AS ,&MDSyncReceiveSM_06_1AS, &MDSyncReceiveSM_00_1AS},
	{&MDSyncReceiveSM_01_1AS ,&MDSyncReceiveSM_03_1AS ,&MDSyncReceiveSM_NP_1AS ,&MDSyncReceiveSM_NP_1AS, &MDSyncReceiveSM_00_1AS}
};

VOID MDSyncReceiveSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCRCVSM_EV	enEvt = MDSYCR_E_EVENT_MAX;
	MDSYNCRCVSM_ST	enSts = MDSYCR_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82080001);

	enEvt = GetMDSyncRcvEvent(usEvent, pstPort);
	enSts = GetMDSyncRcvStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDSyncReceiveSM_1AS      ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDSYCR_STATUS_MAX) && (enEvt != MDSYCR_E_EVENT_MAX))
	{
		(*MDSyncReceiveSM_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDSyncRcvStatus(pstPort);
	printf ("<END  > [%02d]MDSyncReceiveSM_1AS      ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDSyncReceiveSM_00_1AS(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDSyncReceiveSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);
	MDSynRcvTimeStop(pstGbl, pstPort);
	MDSynRcv_Discard_1AS(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDSyncReceiveSM_00_1AS::-\n") );

	return;
}

VOID MDSyncReceiveSM_01_1AS(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcv_Discard_1AS(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
	return;
}

VOID MDSyncReceiveSM_02_1AS(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcvTimeStop(pstGbl, pstPort);
	MDSynRcv_Discard_1AS(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
	return;
}

VOID MDSyncReceiveSM_03_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*		pstPortDS = &pstPort->stPort_1AS_DS;

	MDSRECEIVESM_GD*	pstGbl = NULL;
	BOOL				blRet;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	SyncTransChkTmo( pstPort->pstClockData );

	if (ConMDSync_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001108);
		MDSynRcv_Discard_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	if (SetMDSyncEvIngresTimestampSM(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200110B);
		MDSynRcv_Discard_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	IncMDSyncRcvRxSyncCount(pstPort);

	if (IsDecMDSyncTwoStep_1AS(pstGbl->pstRcvdSync))
	{
		blRet = ChkSyncTransProcessing( pstPort->pstClockData );
		if(blRet != FALSE)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82003106);
			pstGbl->blRcvdSync = FALSE;
			SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
		}
		else
		{
			MDSyncRcv_WtFrFollowUp_1AS(pstGbl, pstPort);
			SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_FOLLOW_UP, pstPort);
		}
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);
		if (pstPortDS->blOneStepReceive)
		{
			blRet = ChkSyncTransProcessing( pstPort->pstClockData );
			if(blRet != FALSE)
			{
				PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82003106);
				pstGbl->blRcvdSync = FALSE;
				SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
			}
			SetMDOneSyncMgEgresTmstmp_1AS(pstGbl, pstPort);
			SetMDSyncEvIngresTimestamp(pstGbl, pstPort);

			MDSynRcv_WtFrSyncOne_1AS(pstGbl, pstPort);
			SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200110C);
			MDSynRcv_Discard_1AS(pstGbl, pstPort);
			SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		}
	}

	return;
}

VOID MDSyncReceiveSM_04_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*		pstPortDS = &pstPort->stPort_1AS_DS;

	MDSRECEIVESM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	if (ConMDSync_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001108);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	if (SetMDSyncEvIngresTimestampSM(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200110B);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	IncMDSyncRcvRxSyncCount(pstPort);

	if (IsDecMDSyncTwoStep_1AS(pstGbl->pstRcvdSync))
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001100);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSyncRcv_WtFrFollowUp_1AS(pstGbl, pstPort);
	}
	else
	{
		IncMDSyncRcvRxOneStpSyncCount(pstPort);
		if (pstPortDS->blOneStepReceive)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001100);
			MDSynRcvTimeStop(pstGbl, pstPort);
			SetMDOneSyncMgEgresTmstmp_1AS(pstGbl, pstPort);
			SetMDSyncEvIngresTimestamp(pstGbl, pstPort);

			MDSynRcv_WtFrSyncOne_1AS(pstGbl, pstPort);
			SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200110C);

			MDSynRcv_Discard_1AS(pstGbl, pstPort);
			SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		}
	}
	return;
}
VOID MDSyncReceiveSM_05_1AS(PORTDATA* pstPort)
{
	PORTMD_GD*			pstPortMD = &pstPort->stPortMD_GD;
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	if (ConMDFollowUp_1AS(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001208);
		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_Discard_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
		return;
	}

	IncMDSyncRcvRxFollowUpCount(pstPort);

	if (pstGbl->pstRcvdFollowUp->stFollowUp_1AS.stHeader.usSequenceId
		== pstPortMD->stConSyncTwo_1AS.stHeader.usSequenceId)
	{
		SetMDTwoSyncMgEgresTmstmp_1AS(pstGbl, pstPort);
		SetMDSyncEvIngresTimestamp(pstGbl, pstPort);

		MDSynRcvTimeStop(pstGbl, pstPort);
		MDSynRcv_WtFrSyncTwo_1AS(pstGbl, pstPort);
		SetMDSyncRcvStatus(MDSYCR_WAITING_FOR_SYNC, pstPort);
	}
	else
	{
		pstGbl->blRcvdFollowUp = FALSE;
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200120B);
	}
	return;
}

VOID MDSyncReceiveSM_06_1AS(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	MDSynRcv_Discard_1AS(pstGbl, pstPort);
	SetMDSyncRcvStatus(MDSYCR_DISCARD, pstPort);
}

VOID MDSyncReceiveSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82000007);
	return;
}

BOOL MDSynRcv_Discard_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;
	pstSmGbl->blRcvdFollowUp = FALSE;
	return TRUE;
}

BOOL MDSyncRcv_WtFrFollowUp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CHAR	chInterval = 0;

	pstSmGbl->blRcvdSync = FALSE;
	chInterval = pstSmGbl->pstRcvdSync->stSyncTwo_1AS.stHeader.chLogMsgInterVal;
	if (cmptMDSyncFollowUpReceiptTime(pstSmGbl, pstPort, chInterval))
	{
		MDSynRcvTimeStart(pstSmGbl, pstPort);
	}
	return TRUE;
}

BOOL MDSynRcv_WtFrSyncTwo_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;
	pstSmGbl->blRcvdFollowUp = FALSE;

	if (SetMDSyncTwoReceive_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDSyncReceive_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL MDSynRcv_WtFrSyncOne_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdSync = FALSE;

	if (SetMDSyncOneReceive_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDSyncReceive_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

VOID SetMDTwoSyncMgEgresTmstmp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_FOLLOWUP_1AS*	pstMsgSyncFollowUp
		= &pstSmGbl->pstRcvdFollowUp->stFollowUp_1AS;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventEgressTimestamp,
		&pstMsgSyncFollowUp->stPrcsOrgnTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortGD->stSyncCorrectionField,
		&pstMsgSyncFollowUp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL ConMDSync_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdSync == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001109);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdSync == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200110A);
		return FALSE;
	}

	if (IsDecMDSyncTwoStep_1AS(pstSmGbl->pstRcvdSync))
	{
		tsn_Wrapper_MemCpy(&pstPortMD->stConSyncTwo_1AS,
			&pstSmGbl->pstRcvdSync->stSyncTwo_1AS, sizeof(pstPortMD->stConSyncTwo_1AS));
	}
	else
	{
		tsn_Wrapper_MemCpy(&pstPortMD->stConSyncOne_1AS,
			&pstSmGbl->pstRcvdSync->stSyncOne_1AS, sizeof(pstPortMD->stConSyncOne_1AS));
	}
	return TRUE;
}

BOOL ConMDFollowUp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	if (pstSmGbl->blRcvdFollowUp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_82001209);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdFollowUp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM_1AS, PTP_LOGVE_8200120A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConFollowUp_1AS,
		&pstSmGbl->pstRcvdFollowUp->stFollowUp_1AS, sizeof(pstPortMD->stConFollowUp_1AS));

	return TRUE;
}

VOID SetMDOneSyncMgEgresTmstmp_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_SYNC_ONE_STEP_1AS*	pstMsgSync
		= &pstSmGbl->pstRcvdSync->stSyncOne_1AS;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventEgressTimestamp,
		&pstMsgSync->stOriginTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortGD->stSyncCorrectionField,
		&pstMsgSync->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL SetMDSyncTwoReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCRECEIVE*				pstSyncRcv = &pstPort->stPort_GD.stMdSyncReceive;
	PTPMSG_SYNC_TWO_STEP_1AS*	pstMsgSync = &pstPort->stPortMD_GD.stConSyncTwo_1AS;
	PTPMSG_FOLLOWUP_1AS*		pstMsgFollow = &pstPort->stPortMD_GD.stConFollowUp_1AS;
	PORT_GD*					pstPortGD	= &pstPort->stPort_GD;

	SCALEDNS			stA_SNs				= {0};
	USCALEDNS			stB_USNs			= {0};
	SCALEDNS			stD_SNs				= {0};
	USCALEDNS			stF_USNs			= {0};
	DOUBLE				dbA 				= 0.0;

	PORTDATA*			pstPort_delay		= NULL;
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstPort->pstClockData);

	pstPort_delay = GetPdelayPort_1AS(pstPort->pstClockData, pstPort->stPortDS.stPortIdentity.usPortNumber);

	pstSyncRcv->uchClockNumber = pstMsgSync->stHeader.uchDomainNumber;

	{
		ptpAddTInt_TInt((TIME_INTERVAL*)&pstMsgSync->stHeader.stCorrectionField,
					(TIME_INTERVAL*)&pstMsgFollow->stHeader.stCorrectionField,
					&pstSyncRcv->stFollowUpCorrectionField);
	}

	pstSyncRcv->stSourcePortIdentity		= pstMsgSync->stHeader.stSrcPortIdentity;
	pstSyncRcv->chLogMessageInterval		= pstMsgSync->stHeader.chLogMsgInterVal;
	pstSyncRcv->stPreciseOriginTimestamp	= pstMsgFollow->stPrcsOrgnTimestamp;
#if 1

	ptpDivUSNs_Doub(&pstPort_delay->stPort_GD.stNeighborPropDelay, pstPort_delay->stPort_GD.dbNeighborRateRatio, &stB_USNs);

#ifndef	PTP_USE_ME_HW_ASSIST
	ptpConvTS_USNs(&pstPortGD->stSyncEventIngressTimestamp, &stF_USNs);
#else
	ptpConvTS_USNs(&pstPortGD->stSyncEventIngressTimestamp_Frun, &stF_USNs);
#endif
	ptpSubUSNs_USNs(&stF_USNs, &stB_USNs, &stA_SNs);

	ptpSubSNs_SNs(&stA_SNs, &pstPortGD->stDelayAsymmetry, &stD_SNs);

	ptpConvSNs_USNs(&stD_SNs, &pstSyncRcv->stUpstreamTxTime);
#endif

#ifdef	OFFSET_DEBUG
	if (blPtpOffsetUnder50Flag)
	{
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].ulType	= 1;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].usPortNo 
										= pstPort->stPortDS.stPortIdentity.usPortNumber;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stSyncEventIngressTimestamp_Frun
										= stF_USNs;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stSyncEventIngressTimestamp
										= pstPortGD->stSyncEventIngressTimestamp;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stNeighborPropDelay
										= pstPort_delay->stPort_GD.stNeighborPropDelay;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].dbNeighborRateRatio
										= pstPort_delay->stPort_GD.dbNeighborRateRatio;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stNeighborPropDelay2
										= stB_USNs;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stUpstreamTxTime
										= pstSyncRcv->stUpstreamTxTime;

		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stSyncEventIngressTimestamp_Frun_TS
										= pstPortGD->stSyncEventIngressTimestamp_Frun;

		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].usPortNumber
										= pstPort->stPortDS.stPortIdentity.usPortNumber;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].usSequenceId
										= pstMsgSync->stHeader.usSequenceId;
		stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].usCorrectiontLogCount
										= usCorrectiontLogCount;

		usCorrectiontLogCount ++;
	}
#endif

	{
		dbA = DBCONST2_M41;
		dbA = dbA * (DOUBLE)pstMsgFollow->stFollowUP_TLV.lCmltvScaledRateOffset;

		pstSyncRcv->dbRateRatio = dbA + DBCONST1_0;
	}

	pstSyncRcv->usGmTimeBaseIndicator	= pstMsgFollow->stFollowUP_TLV.usGMTmBaseIndicator;
	pstSyncRcv->stLastGmPhaseChange	= pstMsgFollow->stFollowUP_TLV.stLstGMPhsChange;
	{
		dbA = DBCONST2_M41;
		dbA = dbA * (DOUBLE)pstMsgFollow->stFollowUP_TLV.lScaledLstGMFrqChange;
		pstSyncRcv->dbLastGmFreqChange		= dbA + DBCONST1_0;
	}
	return TRUE;
}

BOOL SetMDSyncOneReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCRECEIVE*				pstSyncRcv = &pstPort->stPort_GD.stMdSyncReceive;
	PTPMSG_SYNC_ONE_STEP_1AS*	pstMsgSync = &pstPort->stPortMD_GD.stConSyncOne_1AS;
	PORT_GD*					pstPortGD	= &pstPort->stPort_GD;

	DOUBLE				dbA = 0.0;
	SCALEDNS			stA_SNs				= {0};
	USCALEDNS			stB_USNs			= {0};
	SCALEDNS			stD_SNs				= {0};
	USCALEDNS			stF_USNs			= {0};

	PORTDATA*			pstPort_delay		= NULL;
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstPort->pstClockData);

	pstPort_delay = GetPdelayPort_1AS(pstPort->pstClockData, pstCSSGlb->pstRcvdPSSyncPtr->usLocalPortNumber);

	pstSyncRcv->uchClockNumber = pstMsgSync->stHeader.uchDomainNumber;
	{
		TIME_INTERVAL		stA_TInt= {0};
		ptpAddTInt_TInt((TIME_INTERVAL*)&pstMsgSync->stHeader.stCorrectionField, &stA_TInt,
					&pstSyncRcv->stFollowUpCorrectionField);
	}

	pstSyncRcv->stSourcePortIdentity		= pstMsgSync->stHeader.stSrcPortIdentity;
	pstSyncRcv->chLogMessageInterval		= pstMsgSync->stHeader.chLogMsgInterVal;
	pstSyncRcv->stPreciseOriginTimestamp	= pstMsgSync->stOriginTimestamp;
#if 1
	ptpDivUSNs_Doub(&pstPort_delay->stPort_GD.stNeighborPropDelay, pstPortGD->dbNeighborRateRatio, &stB_USNs);
#ifndef	PTP_USE_ME_HW_ASSIST
	ptpConvTS_USNs(&pstPort_delay->stPort_GD.stSyncEventIngressTimestamp, &stF_USNs);
#else
	ptpConvTS_USNs(&pstPort_delay->stPort_GD.stSyncEventIngressTimestamp_Frun, &stF_USNs);
#endif
	ptpSubUSNs_USNs(&stF_USNs, &stB_USNs, &stA_SNs);

	ptpSubSNs_SNs(&stA_SNs, &pstPortGD->stDelayAsymmetry, &stD_SNs);

	ptpConvSNs_USNs(&stD_SNs, &pstSyncRcv->stUpstreamTxTime);
#endif
	{
		dbA = DBCONST2_M41;
		dbA = dbA * (DOUBLE)pstMsgSync->stFollowUP_TLV.lCmltvScaledRateOffset;

		pstSyncRcv->dbRateRatio = dbA + DBCONST1_0;
	}
	pstSyncRcv->usGmTimeBaseIndicator	= pstMsgSync->stFollowUP_TLV.usGMTmBaseIndicator;
	pstSyncRcv->stLastGmPhaseChange	= pstMsgSync->stFollowUP_TLV.stLstGMPhsChange;

	{
		dbA = DBCONST2_M41;
		dbA = dbA * (DOUBLE)pstMsgSync->stFollowUP_TLV.lScaledLstGMFrqChange;

		pstSyncRcv->dbLastGmFreqChange	= dbA + DBCONST1_0;
	}
	return TRUE;
}

BOOL TxMDSyncReceive_1AS(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PSSRECEIVESM_1AS_GD*	pstMediaInd_GD = &pstPort->stUn_PSM_GD.stPsm1as_GD.stPSSReceiveSM_1AS_GD;
	pstMediaInd_GD->blRcvdMDSync = TRUE;

	portSyncSyncReceive_1AS(PTP_EV_FOR_PSYNSYNRV_RCVMDSYNC, pstPort);

	return TRUE;
}


#endif
VOID SyncTransChkTmo( CLOCKDATA* pstClock )
{
	USCALEDNS	stCurrentTime = {0};
	CHAR		chRet;
	UINT 		unIndex;

	ptp_GetCurrentTime( pstClock, &stCurrentTime );
	
	for( unIndex=0U; unIndex < pstClock->stDefaultDS.usNumberPorts; unIndex++ )
	{

		if ( gstSyncTmoManage[unIndex].pstSyncSendPort != NULL )
		{
			chRet = ptpCompUSNs_USNs( &gstSyncTmoManage[unIndex].stSyncTransTimeoutTime, 
									  &stCurrentTime );
			if ( chRet == COMP_A_LESS )
			{
				ptp_dbg_msg( D_SYNCTO, 
				             ("sync send timeout. domain,port=[%d,%d]\n", 
				              gstSyncTmoManage[unIndex].pstSyncSendPort->pstClockData->stDefaultDS.uchDomainNumber,
				              gstSyncTmoManage[unIndex].pstSyncSendPort->stPort_GD.usThisPort) );

				gstSyncTmoManage[unIndex].pstSyncSendPort->stMDSSendSM_GD.blRcvdMDSync           = FALSE;
				gstSyncTmoManage[unIndex].pstSyncSendPort->stMDSSendSM_GD.blEgMDTimestampReceive = FALSE;
				gstSyncTmoManage[unIndex].pstSyncSendPort->stMDSSendSM_GD.enStsMDSyncSend        = MDSYCS_SEND_FOLLOW_UP;

				tsn_Wrapper_MemSet( (VOID *)&gstSyncTmoManage[unIndex], 0, sizeof(SYNCTMOMAN) );
				PTP_ERROR_LOGRECORD( pstClock, 
									 PTP_LOG_MDSSENDSM_1AS, 
									 PTP_LOGVE_8200210D );
			}
		}
	}
	return ;
}
BOOL ChkSyncTransProcessing( CLOCKDATA* pstClock )
{
	BOOL		blRet			= FALSE;
	UINT 		unIndex;

	for( unIndex=0U; unIndex < pstClock->stDefaultDS.usNumberPorts; unIndex++ )
	{
		if( pstClock->stClock_GD.enSelectedState[unIndex+1U] == ENUM_PORTSTATE_MASTER )
		{
			if ( gstSyncTmoManage[unIndex].pstSyncSendPort != NULL )
			{
				ptp_dbg_msg( D_SYNCTO, 
				             ("sync send processing. domain,port=[%d,%d]\n", 
				              gstSyncTmoManage[unIndex].pstSyncSendPort->pstClockData->stDefaultDS.uchDomainNumber,
				              gstSyncTmoManage[unIndex].pstSyncSendPort->stPort_GD.usThisPort) );
				blRet = TRUE;
				break;
			}
		}
	}
	return	blRet;
}

