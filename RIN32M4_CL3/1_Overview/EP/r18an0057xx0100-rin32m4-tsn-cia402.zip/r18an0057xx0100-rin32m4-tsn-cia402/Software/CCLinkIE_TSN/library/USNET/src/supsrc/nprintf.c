//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdarg.h>
#include "net.h"
#include "local.h"
#include "support.h"

static void insert(char *s, char c)
{
    char *tmps;

    tmps = s;
    while (*tmps++);
    while( tmps > s ){
	tmps--;
	tmps[1] = tmps[0];
    }
    *s = c;
}


static void append(char *s, char c)
{
    while(*s++);
    *s-- = 0;
    *s = c;
}

int visprintf(char *buf, const char *fmt, va_list args)
{
    int count;
    int pwidth,width,pcnt,base;
    unsigned long num;
    char fch, c;
    char *s, *bp;
    char ljust, zsup;
    char sign;
    char letter = 0;
    char islong;
    char pflag;

    count = 0;
    *buf = 0;
    bp = buf;
    while((fch = *fmt++) != 0){
	while(*bp)
	    bp++;
	if( fch == '%' ){
	    if ((fch= *fmt++) == '%')
		goto copy;
	    if ((ljust = fch) == '-')
		fch = *fmt++;
	    zsup = fch;
	    pwidth = sizeof(void *)*2;
	    pcnt = 0;
	    sign = 0;
	    pflag = 0;
	    base = 10;
	    if (fch == '*')
		width = va_arg(args, int);
	    else
	    {
	        for (width=0; fch>='0' && fch<='9'; fch=*fmt++)
		    width = width * 10 + fch - '0';
	    }
	    if ((islong = (fch & 0xdf)) == 'L')
		fch = *fmt++;
	    switch( fch ){
		case 'd':
		    sign = 1;
		    goto donumber;
		case 'o':
		    base = 8;
		    goto donumber;
		case 'u':
		    goto donumber;
		case 'x':
		    base = 16;
		    letter = 'a'-10;
		    goto donumber;
		case 'X':
		    base = 16;
		    letter = 'A'-10;
		    goto donumber;
		case 'p':
		    pflag = 1;
		    if( width < pwidth )
			width = pwidth;
		    base = 16;
		    letter = 'A'-10;
		    num = (long)va_arg(args, void *);
		    goto doptr;
		case 'c':
		    fch = (char) va_arg(args, int);
		    goto copy;
		case 's':
		    s = va_arg(args,char *);
		    while( *s ){
			append(bp,*s++);
			count++;
			pcnt++;
		    }
		    for( ; pcnt<width; pcnt++){
			count++;
			if (ljust == '-')
			    append(bp, ' ');
			else{
			    insert(bp, ' ');
			}
		    }
		    goto endarg;
	    }
donumber:
    {
	if (islong == 'L')
	    num = va_arg(args, long int);
	else if (sign)
	    num = (long)va_arg(args, int);
	else
	    num = (long)va_arg(args, unsigned int);
	if( sign && (num & 0x80000000) ){
	    sign = 1;
	    num = -num;
	}else{
	    sign = 0;
	}
doptr:
	while( num != 0l ){
	    c = num % base;
	    num /= base;
	    insert(bp, (char)(c > 9 ? c + letter : (char)c + '0'));
	    pcnt++;
	    count++;
	}
	if(!*bp){
	    insert(bp, '0');
	    pcnt++;
	    count++;
	}
	if( pflag ){
	    for(;pcnt < pwidth; pcnt++){
		insert(bp, '0');
		count++;
	    }
	}
	if (zsup != '0') zsup = ' ';
	for (pcnt += sign ;pcnt < width; pcnt++)
        if (ljust == '-'){
		append(bp, ' ');
		count++;
	    }else{
		insert(bp, zsup);
		count++;
	    }
	if (sign)
	    insert(bp, '-');
    }

	}else{
copy:	    append(bp++, fch);
	    count++;
	}
endarg:
	continue;
    }
    return count;
}

int Nsprintf(char *buf, char *fmt, ...)
{
    va_list args;

    va_start(args,fmt);
    return visprintf(buf, (const char *) fmt,args);
}

#if NTRACE > 0
int Nprintf(char *fmt, ...)
{
    char pf_buf[MAXPFLEN];
    int count;
    char *p;
    va_list args;

    va_start(args,fmt);
    count = visprintf(pf_buf, (const char *) fmt, args);
    p = pf_buf;
    while( *p )
	Nputchr(*p++);
    return count;
}
#endif

