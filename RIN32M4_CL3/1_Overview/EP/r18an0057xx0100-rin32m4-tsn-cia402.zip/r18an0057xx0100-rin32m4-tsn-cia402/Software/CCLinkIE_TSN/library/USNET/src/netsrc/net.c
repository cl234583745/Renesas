//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdlib.h>
#include <string.h>
#define NETMODULE
#include "net.h"
#include "local.h"
#include "support.h"
#ifdef  INET6
#include "ip6.h"
#include "icmp6.h"
#include "nd6.h"
#endif
#include "usnet_supply.h"
#include "lldp.h"
#include "msw_lldp.h"
#include "lldpd.h"
#include "snmpv3.h"

#define MIB2
#ifdef MIB2

extern const AGENT_CONTEXT snmp_ac;

#if defined(USM_MD5) || defined(USM_SHA) || defined(USM_DES)
extern const MIB mib_usm;
#endif

extern const MIB mib_sys, mib_snmp, mib_engine;

#ifdef MIB2
extern const MIB mib_if, mib_at, mib_ip, mib_icmp, mib_udp;
#ifdef TCP
extern const MIB mib_tcp;
#endif
#endif
#ifdef USSW_LLDP_MIB
extern const MIB mib_lldp;
#endif
extern const MIB mib_CCLINKIEN;

static const MIB *mibs[] =
{
    &mib_sys,
#ifdef MIB2
    &mib_if,
    &mib_at,
    &mib_ip,
    &mib_icmp,
#ifdef TCP
#endif
    &mib_udp,
#endif
    &mib_snmp,
	&mib_CCLINKIEN,
    &mib_engine,
#ifdef USSW_LLDP_MIB
    &mib_lldp,
#endif
#if defined(USM_MD5) || defined(USM_SHA) || defined(USM_DES)
    &mib_usm
#endif

};
static TRAP_HOST primary;

static TRAP_HOST *thosts[] =
{
    &primary
};

#ifdef USNET
extern const TRANSPORT_MAPPING TM_DPI;
#endif
extern const TRANSPORT_MAPPING TM_BSD;

const AGENT_CONTEXT snmp_ac =
{
    mibs, (sizeof(mibs) / sizeof(MIB *)),
    thosts, (sizeof(thosts) / sizeof(TRAP_HOST)), 1, COLDSTART,
    &TM_BSD
};

#endif

static int nullinit(int netno, char *params)
{
    (void) netno;
    (void) params;
    return 0;
}
static void nullshut(int netno)
{
    (void) netno;
}
static int nullscreen(MESS *mess)
{
    (void) mess;
    return -1;
}
PTABLE ussNullTable =
   {"null", nullinit, nullshut, nullscreen, 0, 0, 0, 0, 0, 0, 0};

#ifdef IP
extern PTABLE ussIPTable;
#else
#define ussIPTable ussNullTable
#endif
#ifdef ICMP
extern PTABLE ussICMPTable;
#else
#define ussICMPTable ussNullTable
#endif
#ifdef  INET6
extern PTABLE ussIP6Table;
extern PTABLE ussICMP6Table;
#else
#define ussIP6Table ussNullTable
#define ussICMP6Table ussNullTable
#endif
#ifdef IGMP
extern PTABLE   ussIGMPTable;
#else
#define ussIGMPTable ussNullTable
#endif
#ifdef ARP
extern PTABLE ussARPTable;
#else
#define ussARPTable ussNullTable
#endif
#ifdef RARP
extern PTABLE ussRARPTable;
#else
#define ussRARPTable ussNullTable
#endif
#ifdef UDP
extern PTABLE ussUDPTable;
#else
#define ussUDPTable ussNullTable
#endif
#ifdef TCP
extern PTABLE ussTCPTable;
#else
#define ussTCPTable ussNullTable
#endif

#ifdef USSW_LLDP
extern PTABLE ussLLDPTable;
#else
#define ussLLDPTable ussNullTable
#endif

#ifdef PPPOE
extern void pppoe_timer(int netno);
extern PTABLE ussPPPoESessionTable;
extern PTABLE ussPPPoEDiscoveryTable;
#endif

#ifdef LQRP
extern PTABLE ussLQRPTable;
#else
#define ussLQRPTable ussNullTable
#endif

GLOBALCONST
PTABLE * const P_tab[] = {
    &ussNullTable, &ussIPTable, &ussICMPTable, &ussARPTable,
    &ussRARPTable, &ussUDPTable, &ussTCPTable,
#ifdef  INET6
    &ussIP6Table, &ussICMP6Table,
#endif
#ifdef PPPOE
    &ussPPPoESessionTable, &ussPPPoEDiscoveryTable,
#endif
#ifdef LQRP
        &ussLQRPTable,
#endif
#ifdef IGMP
        &ussIGMPTable,
#endif
#ifdef USSW_LLDP
        &ussLLDPTable,
#endif
        0
};

#ifdef GARP
#define GARP_TOUT 1000
#endif
char localhostname[32];
struct NET nets[NNETS];
struct CONNECT connblo[NCONNS];
GLOBALCONST const struct Eid
    ecast = {255, 255, 255, 255, 255, 255},
    ezero = {0, 0, 0, 0, 0, 0};
extern const int confsiz;
extern const struct NETDATA netdata[];
extern struct NETCONF netconf[];
struct ifgroup ifgroup;
#ifdef DNS
extern char domain[];
Iid DNSiid[2];
#if defined(INET6) && defined(DNS6)
I6id DNSi6id[2];
#endif
char DNSdomain[65];
#endif

int ussSelectFlag;

#ifdef MIB2
struct sysgroup sysgroup;
#endif

#if MT
static int gflag, gnetno;
#endif

#ifdef USSW_DIRECTED_BROADCAST
struct DETECTIPDATA detectIpInfo;
#endif

#ifdef GARP
unsigned long gulLinkUpState[2];
unsigned long ulGarpSend[2];
unsigned long ulReGarpSend[2];
unsigned long wwul1[2];
unsigned long wwul2[2];
unsigned long wwul3[2];
unsigned long wwul4[2];
int iSndRet[2];
int iReSndRet[2];
#define LINK_UP_DLAY_TIME   2000
#define GARP_RETRY 100
#endif


#ifdef NETPEER
extern char *target_name;
#endif

#ifndef USNET_UNLOCK
#define R_FTYP1_ADR (0x40140070UL)
#define R_FTYP2_ADR (0x40140074UL)
#define R_FTYP3_ADR (0x40140078UL)
#define R_FTYP1_VAL (0xC3C2C1C0UL)
#define R_FTYP2_VAL (0xC7C6C5C4UL)
#define R_FTYP3_VAL (0x000000C8UL)
#endif

#ifndef IPFLTR_DIS
extern void init_ip_filr_func(void);
#endif

static int sendgarp(int netno, int clear, int portno)
{
    int  i1 = 0;
#ifdef GARP
    MESS *mp;
    char *p;

    netconf[nets[netno].confix].timems = TimeMS();

    if ((mp = Ngetbuf()) == 0)
        return -1;

    mp->netno = netno;
    mp->confix = nets[netno].confix;
	mp->portno = portno;
    ussARPTable.writE(-1, mp);

    p = (char *)mp;
    p += MESSH_SZ;
    memset(p, 0xff, Eid_SZ);
    p += Eid_SZ;
    memcpy(p, (char *) &nets[netno].id, Eid_SZ);
    mp->offset = MESSH_SZ;
    mp->id = bRELEASE;

    if (clear)
        netconf[nets[netno].confix].Iconflict[portno] = 0;

    i1 = nets[netno].protoc[1]->writE(netno, mp);
    if (i1)
        Nrelbuf(mp);

#endif
    return i1;
}

int Ninit(void)
{
    int i1, i3, netno;
    register const struct NETDATA *datap;
    register struct NETCONF *confp;

#ifndef USNET_UNLOCK
	volatile unsigned long	*ulreg_1;
	volatile unsigned long	*ulreg_2;
	volatile unsigned long	*ulreg_3;

	ulreg_1 = (unsigned long *)R_FTYP1_ADR;
	ulreg_2 = (unsigned long *)R_FTYP2_ADR;
	ulreg_3 = (unsigned long *)R_FTYP3_ADR;
	
	while (1) {
		if ((R_FTYP1_VAL == *ulreg_1) && (R_FTYP2_VAL == *ulreg_2) && (R_FTYP3_VAL == *ulreg_3)) {
			break;
		}
	}
#endif

#ifndef IPFLTR_DIS
	init_ip_filr_func();
#endif


#if 128 < NCONNS
#error "NCONNS must be less than 129"
#endif

#if 256 < NCONFIGS
#error "NCONFIGS must be less than 257"
#endif

#if NTRACE>=1
    Nprintf("Ninit: initialize network data \n");
#endif
    if (NCONFIGS <= confsiz) {
#if NTRACE >= 1
        Nprintf("NCONFIGS %d too small, %d entries configured\n",
                NCONFIGS, confsiz);
#endif
        return ENOBUFS;
    }
#ifdef NMTINIT
    if (NMTINIT() < 0)
        return -1;
#endif
#if MT || !defined(WRAPTEST)
    i1 = LOCALSETUP();
    if (i1 < 0)
        return i1;
#endif
#ifndef WRAPTEST
    LOCALHOSTNAME(localhostname);
#else
    strcpy(localhostname, "none");
#endif
#if NTRACE>=1
    Nprintf("Ninit: this computer is `%s`\n", localhostname);
#endif

    ussSelectFlag = 0;

    if ((i1 = Ninitsupp()) < 0)
        return i1;
    memset((void *) connblo, 0, sizeof(connblo));
    memset((void *) nets, 0, sizeof(nets));
#ifdef DNS
    memset((void *) DNSiid, 0, sizeof(DNSiid));
#if defined(INET6) && defined(DNS6)
    memset((void *) DNSi6id, 0, sizeof(DNSi6id));
#endif
    strcpy(DNSdomain, domain);
#endif
    Ninitbuf(MAXBUF, NBUFFS);
#ifdef USSW_DIRECTED_BROADCAST
    memset(&detectIpInfo, 0, sizeof(detectIpInfo));
#endif

#ifdef USSW_LLDPD
    lldpdPortReset();
#endif


    memset((void *) netconf, 0, sizeof(struct NETCONF) * NCONFIGS);
    for (netno = i1 = 0; i1 < confsiz; i1++) {
        confp = &netconf[i1];
        datap = &netdata[i1];
        if(strlen(datap->name) > 8 || strlen(datap->pname) > 8){
#if NTRACE>=1
            Nprintf("Computer's name or pname is too long. \n");
#endif
            return -1;
        }
        strcpy(confp->name, datap->name);
        strcpy(confp->pname, datap->pname);
        memcpy((char *) confp->Imask.c, datap->Imask.c, Iid_SZ);
        memcpy((char *) confp->Iaddr.c, datap->Iaddr.c, Iid_SZ);
        confp->Eaddr = datap->Eaddr;
        if (memcmp((char *) &confp->Eaddr, (char *) &ezero, Eid_SZ))
            confp->hwaddyes = 2;
        confp->flags = datap->flags;
        if (confp->flags & NOTUSED)
            continue;
        confp->ncstat = 4;
        if (strcmp(confp->name, localhostname) != 0)
            continue;
#if NTRACE>=5
    Nprintf("Ninit: %s has interface (net) %d\n", confp->name, netno);
#endif
        confp->flags |= LOCALHOST;
        if (netno == NNETS)
            return ENOBUFS;
        nets[netno].netstat = -1;
        nets[netno].confix = i1;
        nets[netno].cflags = confp->flags;
        nets[netno].netno = netno;
        confp->netno = netno;
#ifdef GARP
        confp->Iconflict[0] = 0;
        confp->Iconflict[1] = 0;
        gulLinkUpState[0] = USNET_LINKDOWN;
        gulLinkUpState[1] = USNET_LINKDOWN;
#endif
        netno++;
    }
    ifgroup.ifNumber = netno;
    if (netno == 0) {
#if NTRACE >= 1
        Nprintf("This computer's name `%s` not in NETCONF.C \n", localhostname);
#endif
        return -1;
    }

    i3 = BuildRoutes();

    for (i1 = 0; P_tab[i1]; i1++)
        if (P_tab[i1]->init != 0)
            P_tab[i1]->init(0, 0);

    return i3;
}

int Nterm()
{
    Portterm("*");
#if MT || !defined(WRAPTEST)
    LOCALSHUTOFF();
#endif
    lldpdStop();
    return 0;
}

int Portinit(char *port)
{
    int i1, i2, netno;
    struct NET *netp;
    const struct NETDATA *datap;
    PTABLE **ppp;
    int             iPort;

#if NTRACE>=1
    Nprintf("Portinit: initialize device drivers\n");
#endif
    i2 = EHOSTUNREACH;
    for (netno = 0; netno < NNETS; netno++) {
        netp = &nets[netno];
        i1 = netp->confix;
#if NTRACE>=5
        Nprintf("Portinit: net=%d stat=%d pname=%s\n",
            netno, netp->netstat, netconf[i1].pname);
#endif
        if (netp->netstat >= 0)
            continue;
        datap = &netdata[i1];
        if (port[0] != '*' && strcmp(port, netconf[i1].pname))
            continue;
        netp->depart[0].mtail = 0;
        netp->depart[0].mhead = 0;
        netp->depart[1].mtail = 0;
        netp->depart[1].mhead = 0;
#ifdef PPP
        netp->future.mtail = 0;
        netp->future.mhead = 0;
#endif
        netp->hwflags[0] = 0;
        netp->hwflags[1] = 0;
        ppp = netp->protoc;
        ppp[0] = datap->lprotoc;
        ppp[1] = datap->dprotoc;
        ppp[2] = datap->adapter;
        if (!ppp[2])
            ppp[2] = &ussNullTable;
        i2 = ppp[0]->init(netno, datap->params);
        if (i2 < 0)
            break;
#ifdef MIB2
        netp->ifDescr = (char *)ppp[1]->name;
        netp->ifLastChange = TimeMS() / 10;
        netp->ifAdminStatus = 1;
        netp->bps = IFSPEED;
#endif

#if MT
        if (netp->netstat == -1) {
            gflag = 0;
            gnetno = netno;
            RUNTASK(NetTask, NET_PRIOR);
            WAITFOR(gflag, SIG_GEN, 1000, i2);
        }
#endif
        netp->netstat = 1;
#ifdef  INET6
        NetInit6(netno);
#endif
#ifdef DHCP
#if DHCP == 2
        if (netconf[netp->confix].Iaddr.l == 0 &&
            netp->protoc[0] == Ethernet)
        {
            i2 = DHCPget(netno, 0);
            if (i2 < 0)
                break;
        }
#endif
#endif

#ifdef USSW_LLDPD
        lldpdPortEnable(netno);
#endif

#ifdef GARP
        netconf[netp->confix].timems = 0;
#endif
    }
#ifdef USSW_LLDPD
		lldpdRun();
#endif

    return i2;
}

int Portterm(char *port)
{
    int netno, stat, i1;
    register struct NET *netp;
    register struct CONNECT *connp;

    for (netno = 0; netno < NNETS; netno++) {
        netp = &nets[netno];
        if (netp->netstat != 1)
            continue;
        if (port[0] != '*' && strcmp(port, netconf[netp->confix].pname))
            continue;
#ifdef DHCP
#if DHCP == 2
        if (netp->DHCPserver)
            DHCPrelease(netno);
#endif
#endif
#ifdef  INET6
        NetTerm6(netno);
#endif
        WAITFOR((netp->hwflags[0] == 0 && netp->hwflags[1] == 0), SIG_WN(netno), netp->tout, stat);
        if (netp->protoc[0])
            netp->protoc[0]->shut(netno);
        netp->netstat = -2;
        WAITNOMORE(SIG_RN(netno));
#if MT
        WAITFOR(netp->netstat == -1, SIG_GEN, netp->tout, stat);
#endif
        BLOCKPREE();
        netp->hwflags[0] = 1;
        netp->hwflags[1] = 1;
        netp->depart[0].mtail = 0;
        netp->depart[0].mhead = 1;
        netp->depart[1].mtail = 0;
        netp->depart[1].mhead = 1;
        memset((char *)&netp->depart[0], 0, sizeof(netp->depart[0].mp));
        memset((char *)&netp->depart[1], 0, sizeof(netp->depart[1].mp));
#ifdef PPP
        netp->future.mtail = 0;
        netp->future.mhead = 1;
        memset((char *)&netp->future, 0, sizeof(netp->future.mp));
#endif
        memset((char *)&netp->arrive, 0, sizeof(struct FIFOQ16));
        netp->bufbas = 0;
        netp->bufbaso = 0;
        netp->fragmq = 0;
        for (i1 = 0; i1 < NCONNS; i1++) {
            connp = &connblo[i1];
            if ((connp->netno == netno) && (connp->blockstat != 0)) {
                connp->first    =
                connp->wackf    =
                connp->future   =
                connp->ostreamb =
                connp->istreamb = 0;
                connp->nwacks   = 0;
                if (connp->state != 16)
                    connp->rxstat = S_FATAL;
            }
        }
#ifdef USSW_LLDPD
        lldpdPortDisable(netno);
#endif
        Nclearbuf(MAXBUF, NBUFFS, netno);
        RESUMEPREE();
    }
#ifdef USSW_DIRECTED_BROADCAST
    for (i1 = confsiz; i1 < NCONFIGS; i1++) {
        netconf[i1].Iaddr.l = 0;
        netconf[i1].hwaddyes = 0;
        netconf[i1].hops = 0;
        netconf[i1].ncstat = 0;
    }
#endif
    return 0;
}

#if defined(USSW_LLDPD)
#define NETTASKDELAY 20
#else
#define NETTASKDELAY 1000
#endif

#if MT == 0
void            NetTask(int netno)
{
#else
TASKFUNCTION    NetTask(void)
{
    int             netno;
#endif
    int             i1,
                    conno;
    register struct CONNECT *conp;
    struct NET     *netp;
    MESS           *mp;
    PTABLE         *pp;
    struct NETCONF *confp;
    unsigned long   ul1;
    int             iPort;
    unsigned long   ulLinkSts = 0;
    int             iRslt;
    int             iGarpSndPort = 0;
    unsigned long   ulGarpSndLinkSts = 0;
#if MT != 0
    netno = gnetno;
    gflag = 1;
    WAITNOMORE(SIG_GEN);
    nets[netno].netstat = 1;
#endif
    netp = &nets[netno];
#if MT == 0
    if (netp->netstat <= 0)
        return;
    netp->netstat = -1;
#else
aga:
#endif

#ifdef USSW_LLDPD
    lldpdTimer(netno);
    snmplldpdTask(netno);

#endif
	
    while (!CHECK_DRIVER_PACKET(netno)) {
        TAKE_DRIVER_PACKET(netno, mp);
        handlePacket(netp->protoc[ussLinkIndex], mp, netp);
    }

#if MT
    netp->nettasktout = NETTASKDELAY;
#endif

#ifdef GARP
	for (iPort = 0; iPort < 2; iPort++) {
		vUSN_GetLinkSts((unsigned short)iPort, &ulLinkSts);

		if (ulLinkSts == USNET_LINKUP) {
			if (gulLinkUpState[iPort] != USNET_LINKUP) {
				iSndRet[iPort] = -1;
				wwul1[iPort] = TimeMS();
				ulGarpSend[iPort] = 1;
			}
			else {
				if (iSndRet[iPort] < 0) {
					if (ulGarpSend[iPort] == 1) {
						if ((TimeMS() - wwul1[iPort]) >= LINK_UP_DLAY_TIME) {
							ulGarpSend[iPort] = 2;
							wwul2[iPort] = TimeMS();
						}
					}
					if (ulGarpSend[iPort] == 2) {
						iRslt = sendgarp(netno, 0, iPort);
						if (0 == iRslt) {
							iSndRet[iPort] = 0;
							iReSndRet[iPort] = -1;
							ulReGarpSend[iPort] = 1;
							wwul3[iPort] = TimeMS();
						}
						else {
							if ((TimeMS() - wwul2[iPort]) >= GARP_TOUT) {
								iSndRet[iPort] = 0;
								iReSndRet[iPort] = 0;
							}
						}
					}
				}
				else {
					if (iReSndRet[iPort] < 0) {
						if (ulReGarpSend[iPort] == 1) {
							if ((TimeMS() - wwul3[iPort]) >= GARP_RETRY) {
								ulReGarpSend[iPort] = 2;
								wwul4[iPort] = TimeMS();
							}
						}
						if (ulReGarpSend[iPort] == 2) {
							iRslt = sendgarp(netno, 0, iPort);
							if (0 == iRslt) {
								iReSndRet[iPort] = 0;
							}
							else {
								if ((TimeMS() - wwul4[iPort]) >= GARP_TOUT) {
									iReSndRet[iPort] = 0;
								}
							}
						}
					}
				}
			}
		}
		else {
			netconf[netp->confix].Iconflict[iPort] = 0;
		}
		gulLinkUpState[iPort] = ulLinkSts;
		
		for (i1 = 0; i1 < NCONFIGS; i1++) {
			confp = &netconf[i1];
			
			if (confp->Iconflict[iPort] == 1) {
				netp->netstat = 1;
				Portterm(confp->pname);
				return;
			}
			else if (confp->Iconflict[iPort] == 2) {
				for (iGarpSndPort = 0; iGarpSndPort < 2; iGarpSndPort++) {
					vUSN_GetLinkSts((unsigned short)iGarpSndPort, &ulGarpSndLinkSts);
					
					if (ulGarpSndLinkSts == USNET_LINKUP) {
						sendgarp(confp->netno, 0, iGarpSndPort);
					}
				}
				confp->Iconflict[iPort] = 0;
			}
			else {
			}
		}
	}
#endif

#ifdef TCP
    for (conno = 0; conno < NCONNS; conno++) {
        conp = &connblo[conno];
        if (conp->blockstat <= 0 || conp->netno != netno)
            continue;
        pp = conp->protoc[0];
        if (pp->shut)
            pp->shut(conno);
    }
#endif

#ifdef PPP
    if (netp->protoc[ussLinkIndex] == PPP)
        pppTimeout(netno);
#ifdef PPPOE
    else if (netp->protoc[ussLinkIndex] == PPPOE) {
        pppTimeout(netno);
        pppoe_timer(netno);
    }
#endif
#endif
#if USS_IP_MC_LEVEL == 2
    ussIGMPTable.shut(0);
#endif

#ifdef ARP
    ul1 = TimeMS();
    for (i1 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->netno != netno || confp->ncstat == 0)
            continue;
#ifdef  INET6
        if (confp->ipv6.flags6 & ENABLE6)
            continue;
#endif
#if ARPTOUT > 0
        if (confp->hwaddyes == 1 && (confp->flags & (LOCALHOST + NOTUSED)) == 0)
            if (ul1 - confp->timems > ARPTOUT)
                confp->hwaddyes = 0;
#endif
        if (confp->ARPwait && ul1 - confp->timems > NETTASKDELAY * 2) {
            confp->ARPwaitmp->offset = boTXDONE;
            if (confp->ARPwait != (char)-5)
                Nrelbuf(confp->ARPwaitmp);
            confp->ARPwait = 0;
        }
    }
#endif
#ifdef  INET6
    NetTask6(netno);
#endif

#ifdef FRAGMENTATION

    if (netp->fragmq) {
        mp = netp->fragmq;
        if (TimeMS() - mp->timems > REASSTOUT) {
            netp->fragmq = mp->next;
#ifdef  INET6
            if (mp->ipv6.flag6 & FLAG6_IPV6) {
                if (mp->ipv6.frag6) {
                    ICMP6error(mp->ipv6.frag6, ICMP6_TIME_EXCEEDED, 
                            ICMP6_TIME_EXCEED_REASSEMBLY, 0);
                    mp->ipv6.frag6 = NULL;
                }
                Nrelbuf(mp);
            } else {
#endif
            i1 = 1;
            if (*(unsigned short *) ((char *) mp + MESSH_SZ) >= Ihdr_SZ * 2)
                i1 = ICMPreply(mp, 11, 1);
            if (i1)
                Nrelbuf(mp);
#ifdef  INET6
            }
#endif
        }
    }
#endif

    if (ussSelectFlag) {
        WAITNOMORE(SIG_SEL);
    }

#if MT
    WAITFOR(!QUEUE_EMPTY(netp, arrive) || netp->worktodo || netp->netstat < 0,
            SIG_RN(netno), netp->nettasktout, i1);
    if (netp->netstat > 0) {
        netp->worktodo = 0;
        goto aga;
    }
    netp->netstat = -1;
    WAITNOMORE(SIG_GEN);
#ifdef KILLTASK
    KILLTASK();
#endif
#else
    netp->netstat = 1;
#endif
}


void handlePacket(PTABLE *pp, MESS *mp, struct NET *netp)
{

    register struct CONNECT *conp;
    int status;

    status = pp->screen(mp);
    if (netp && netp->fragmh) {
        mp = netp->fragmh;
        netp->fragmh = 0;
    }

    if (status < 0) {
        if (status != -4)
            Nrelbuf(mp);
    }
    else
    {
        mp->next = 0;
        conp = &connblo[status];

        if (conp->blockstat & 6) {
            Nrelbuf(mp);
            return;
        }

        BLOCKPREE();
        if (conp->first)
            conp->last->next = mp;
        else
            conp->first = mp;
        conp->last = mp;
        conp->ninque++;
        RESUMEPREE();
        WAITNOMORE(SIG_RC(status));
    }

    return;

}

#ifdef USSW_NIOCTL
static int setipaddr(int req, void *arg)
{
    struct NETCONF *confp;
    int            i1, i2;
    struct SETIid  host_iid;

    memcpy(&host_iid, arg, sizeof(host_iid));
    for (i1 = 0, i2 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->flags & LOCALHOST) {
            if (i2 == host_iid.no) {
                confp->Iaddr.l = host_iid.addr.l;
                break;
            }
            i2++;
        }
    }
    if (NCONFIGS <= i1) {
        return -1;
    }

    return 0;
}

static int seteaddr(int req, void *arg)
{
    struct NET    *netp;
    int           i1, i2;
    struct SETEid host_eid;

    memcpy(&host_eid, arg, sizeof(host_eid));

    for (i1 = 0, i2 = 0; i1 < NNETS; i1++) {
        netp = &nets[i1];
        if ((netp->netno == i1) && 
            (netconf[netp->confix].flags & LOCALHOST)) {
            if (i2 == host_eid.no) {
                memcpy((char *) netp->id.c, &host_eid.addr, Eid_SZ);
                break;
            }
            i2++;
        }
    }
    if (NNETS <= i1) {
        return -1;
    }

    return 0;
}

static int setimask(int req, void *arg)
{
    struct NETCONF *confp;
    int            i1, i2;
    struct SETIid  host_iid;

    memcpy(&host_iid, arg, sizeof(host_iid));

    for (i1 = 0, i2 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->flags & LOCALHOST) {
            if (i2 == host_iid.no) {
                confp->Imask.l = host_iid.addr.l;
                break;
            }
            i2++;
        }
    }
    if (NCONFIGS <= i1) {
        return -1;
    }

    return 0;
}

static int setgateway(int req, void *arg)
{
    struct NETCONF *confp;
    int            i1, i2;
    struct SETIid  host_iid;

    memcpy(&host_iid, arg, sizeof(host_iid));

    if (host_iid.addr.c[3] == 0) {
        return -1;
    }
    if (255 == host_iid.addr.c[3]) {
        return -1;
    }
    for (i1 = 0, i2 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->flags & ROUTER) {
            if (i2 == host_iid.no) {
                memset((char *) confp->Eaddr.c, 0, Eid_SZ);
                confp->hwaddyes = 0;
                confp->Iaddr.l = host_iid.addr.l;
                break;
            }
            i2++;
        }
    }
    if (NCONFIGS <= i1) {
        return -1;
    }

    return 0;
}

typedef int (*ussIoctlFunction)(int req, void *arg);
ussIoctlFunction ussIoctlFunctions[] = {
    setipaddr,
    seteaddr,
    setimask,
    setgateway,
};

int Nioctl(int request, void *arg)
{

    if (arg == 0) {
        return -2;
    }

    if ((request < 0) || 
        (sizeof(ussIoctlFunctions) / sizeof(ussIoctlFunction) <= request)) {
        return -3;
    }

    return ussIoctlFunctions[request](request, arg);

}

#ifdef USSW_DIRECTED_BROADCAST
int get_auto_detected_ip(unsigned long *ip)
{
    if (ip == NULL) {
        return -1;
    }

    if (detectIpInfo.detectedFlags) {
        *ip = detectIpInfo.Iaddr.l;
        detectIpInfo.detectedFlags = 0;
        return 1;
    }
    return -1;
}

int start_ip_auto_detect(unsigned long ip, unsigned short port)
{
    struct NETCONF *confp;
    struct SETIid  host_iid;
    int            i1;

    if (detectIpInfo.detectPort) {
        return -1;
    }
    if (port == 0) {
        return -1;
    }
    for (i1 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (confp->flags & LOCALHOST) {
            if (confp->Iaddr.l == ip) {
                break;
            }
        }
    }
    if (NCONFIGS <= i1) {
        host_iid.no = 0;
        host_iid.addr.l = ip;
        if (setipaddr(ussSetIaddr, &host_iid) < 0) {
            return -1;
        }
    }

    memset(&detectIpInfo, 0, sizeof(detectIpInfo));
    detectIpInfo.detectLastOctet = ntohl(ip) & 0xff;
    detectIpInfo.detectPort = port;

    return 1;
}

int stop_ip_auto_detect(unsigned short port)
{
    if (!detectIpInfo.detectPort) {
        return 1;
    }
    if (detectIpInfo.detectPort != port) {
        return -1;
    }

    detectIpInfo.detectPort = 0;
    detectIpInfo.recvTime = 0;

    return 1;
}

int check_receive_broadcast(void)
{
    if (!detectIpInfo.recvTime) {
        return 0;
    }
    if (CC_RECV_THRESHOLD_TIME < (TimeMS() - detectIpInfo.recvTime)) {
        detectIpInfo.recvTime = 0;
        return 0;
    }
    return 1;
}
#endif
int getifstatus(int req, void *arg, int iPort)

{
    struct NETCONF *confp = NULL;
    int            i1;
    
    for (i1 = 0; i1 < NCONFIGS; i1++) {
        if ((strcmp(netconf[i1].pname, (char *)arg) == 0) && 
            (netconf[i1].flags & LOCALHOST)) {
            confp = &netconf[i1];
            break;
        }
    }
    if (confp == NULL) {
        return -1;
    }
    
    
    i1 = 0;
    switch (req) {
    case ussGetIPConflict:
        if (0 < confp->Iconflict[iPort])
            i1 = 1;
        break;
    default:
        i1 = -1;
    }
    return i1;
}
#endif
