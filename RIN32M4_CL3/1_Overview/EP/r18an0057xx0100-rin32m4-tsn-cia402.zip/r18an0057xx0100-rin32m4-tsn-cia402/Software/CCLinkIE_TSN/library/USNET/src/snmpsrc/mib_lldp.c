//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include "net.h"
#include "local.h"
#include "support.h"
#include "snmpv3.h"
#include "mib_lldp.h"

#ifdef USSW_LLDP_MIB

typedef struct {
    void (*get)(sint16 varix, sint16 tabix, uint8 **vvptr);
    sint16 (*set)(sint16 varix, sint16 tabix, void *vptr);
    sint16 (*index)(sint16 varix, sint16 tabix);
    void *ptr;
    uint32 fixed;
    uint32 min;
    uint32 max;
} LLDPMIB_PARAM;

enum {
    lldpV2MessageTxInterval,
    lldpV2MessageTxHoldMultiplier,
    lldpV2ReinitDelay,
    lldpV2NotificationInterval,
    lldpV2TxCreditMax,
    lldpV2MessageFastTx,
    lldpV2TxFastInit,
    lldpV2AddressTableIndex,
    lldpV2DestMacAddress,
    lldpV2ManAddrConfigIfIndex,
    lldpV2ManAddrConfigDestAddressIndex,
    lldpV2ManAddrConfigLocManAddrSubtype,
    lldpV2ManAddrConfigLocManAddr,
    lldpV2ManAddrConfigTxEnable,
    lldpV2ManAddrConfigRowStatus,
    lldpV2PortConfigIfIndexV2,
    lldpV2PortConfigDestAddressIndexV2,
    lldpV2PortConfigAdminStatusV2,
    lldpV2PortMessageTxInterval,
    lldpV2PortMessageTxHoldMultiplier,
    lldpV2PortReinitDelay,
    lldpV2PortNotificationInterval,
    lldpV2PortTxCreditMax,
    lldpV2PortMessageFastTx,
    lldpV2PortTxFastInit,
    lldpV2PortConfigNotificationEnableV2,
    lldpV2PortConfigTLVsTxEnableV2,
    lldpV2StatsRemTablesLastChangeTime,
    lldpV2StatsRemTablesInserts,
    lldpV2StatsRemTablesDeletes,
    lldpV2StatsRemTablesDrops,
    lldpV2StatsRemTablesAgeouts,
    lldpV2StatsTxIfIndex,
    lldpV2StatsTxDestMACAddress,
    lldpV2StatsTxPortFramesTotal,
    lldpV2StatsTxLLDPDULengthErrors,
    lldpV2StatsRxDestIfIndex,
    lldpV2StatsRxDestMACAddress,
    lldpV2StatsRxPortFramesDiscardedTotal,
    lldpV2StatsRxPortFramesErrors,
    lldpV2StatsRxPortFramesTotal,
    lldpV2StatsRxPortTLVsDiscardedTotal,
    lldpV2StatsRxPortTLVsUnrecognizedTotal,
    lldpV2StatsRxPortAgeoutsTotal,
    lldpV2LocChassisIdSubtype,
    lldpV2LocChassisId,
    lldpV2LocSysName,
    lldpV2LocSysDesc,
    lldpV2LocSysCapSupported,
    lldpV2LocSysCapEnabled,
    lldpV2LocPortIfIndex,
    lldpV2LocPortIdSubtype,
    lldpV2LocPortId,
    lldpV2LocPortDesc,
    lldpV2LocManAddrSubtype,
    lldpV2LocManAddr,
    lldpV2LocManAddrLen,
    lldpV2LocManAddrIfSubtype,
    lldpV2LocManAddrIfId,
    lldpV2LocManAddrOID,
    lldpV2RemTimeMark,
    lldpV2RemLocalIfIndex,
    lldpV2RemLocalDestMACAddress,
    lldpV2RemIndex,
    lldpV2RemChassisIdSubtype,
    lldpV2RemChassisId,
    lldpV2RemPortIdSubtype,
    lldpV2RemPortId,
    lldpV2RemPortDesc,
    lldpV2RemSysName,
    lldpV2RemSysDesc,
    lldpV2RemSysCapSupported,
    lldpV2RemSysCapEnabled,
    lldpV2RemRemoteChanges,
    lldpV2RemTooManyNeighbors,
    lldpV2RemManAddrSubtype,
    lldpV2RemManAddr,
    lldpV2RemManAddrIfSubtype,
    lldpV2RemManAddrIfId,
    lldpV2RemManAddrOID,
    lldpV2RemUnknownTLVType,
    lldpV2RemUnknownTLVInfo,
    lldpV2RemOrgDefInfoOUI,
    lldpV2RemOrgDefInfoSubtype,
    lldpV2RemOrgDefInfoIndex,
    lldpV2RemOrgDefInfo,

};

static uint32 lasttrap_time = 0;
static int request_sendtrap = 0;

#define LLDP_OID_BASE    0x2b,111,2,134,34,1,1,13
static uint8 snmp_lldpbuf[516];
static MIBVAR mibvar_lldp[] =
{
    {{12, {LLDP_OID_BASE,1,1,1,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,2,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,3,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,4,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,5,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,6,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,1,7,0}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,9,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,9,1,2}}, CAR|SCALAR, OctetString, Eid_SZ, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,2}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,3}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,4}}, CAR|SCALAR, OctetString, Max_SZMNG_ADDR, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,5}}, W|CAR|CAW|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,10,1,6}}, CAR|SCALAR, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,2}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,3}}, W|CAR|CAW|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,4}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,5}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,6}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,7}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,8}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,9}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,10}}, W|CAR|CAW|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,11}}, W|CAR|CAW|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,1,11,1,12}}, W|CAR|CAW|SCALAR, OctetString, sizeof(char), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,2,1,0}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,2,2,0}}, CAR|SCALAR, Gauge, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,2,3,0}}, CAR|SCALAR, Gauge, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,2,4,0}}, CAR|SCALAR, Gauge, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,2,5,0}}, CAR|SCALAR, Gauge, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,6,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,6,1,2}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,6,1,3}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,6,1,4}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,2}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,3}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,4}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,5}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,6}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,7}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,2,7,1,8}}, CAR|SCALAR, Gauge, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,1,0}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,2,0}}, CAR|SCALAR, OctetString, Max_SZCHASSIS_INFO, snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,3,0}}, CAR|SCALAR, OctetString, Max_SZSYSNAME_INFO, snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,4,0}}, CAR|SCALAR, OctetString, Max_SZSYSDES_INFO, snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,5,0}}, CAR|SCALAR, Integer, sizeof(short), snmp_lldpbuf},
    {{12, {LLDP_OID_BASE,1,3,6,0}}, CAR|SCALAR, Integer, sizeof(short), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,7,1,1}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,7,1,2}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,7,1,3}}, CAR|SCALAR, OctetString, Max_SZPORTID_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,7,1,4}}, CAR|SCALAR, OctetString, Max_SZPORTDES_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,1}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,2}}, CAR|SCALAR, OctetString, Max_SZMNG_ADDR, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,3}}, CAR|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,4}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,5}}, CAR|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,3,8,1,6}}, CAR|SCALAR, Identifier, Max_SZMNG_OBJ, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,1}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,2}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,3}}, CAR|BASE1, Integer, sizeof(char), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,4}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,5}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,6}}, CAR|SCALAR, OctetString, Max_SZCHASSIS_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,7}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,8}}, CAR|SCALAR, OctetString, Max_SZPORTID_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,9}}, CAR|SCALAR, OctetString, Max_SZPORTDES_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,10}}, CAR|SCALAR, OctetString, Max_SZSYSNAME_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,11}}, CAR|SCALAR, OctetString, Max_SZSYSDES_INFO, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,12}}, CAR|SCALAR, Integer, sizeof(short), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,13}}, CAR|SCALAR, Integer, sizeof(short), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,14}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,1,1,15}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,2,1,1}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,2,1,2}}, CAR|SCALAR, OctetString, Max_SZMNG_ADDR, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,2,1,3}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,2,1,4}}, CAR|SCALAR, Uinteger32, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,2,1,5}}, CAR|SCALAR, Identifier, Max_SZMNG_OBJ, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,3,1,1}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,3,1,2}}, CAR|SCALAR, OctetString, LLDPD_UNKOWN_TLV_SIZE, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,4,1,1}}, CAR|SCALAR, OctetString, 3, snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,4,1,2}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,4,1,3}}, CAR|SCALAR, Integer, sizeof(long), snmp_lldpbuf},
    {{13, {LLDP_OID_BASE,1,4,4,1,4}}, CAR|SCALAR, OctetString, LLDPD_MAX_TLV_SZ - 6, snmp_lldpbuf},

};

static sint16 mibvarsize_lldp(void)
{
    return sizeof(mibvar_lldp) / sizeof(MIBVAR);
}

static const MIBTAB mibtab_lldp[] =
{
    {{11, {LLDP_OID_BASE,1,1,9}}, 1, {lldpV2AddressTableIndex}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,1,10}}, 4, {lldpV2ManAddrConfigIfIndex,lldpV2ManAddrConfigDestAddressIndex,lldpV2ManAddrConfigLocManAddrSubtype,lldpV2ManAddrConfigLocManAddr}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,1,11}}, 2, {lldpV2PortConfigIfIndexV2,lldpV2PortConfigDestAddressIndexV2}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,2,6}}, 2, {lldpV2StatsTxIfIndex,lldpV2StatsTxDestMACAddress}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,2,7}}, 2, {lldpV2StatsRxDestIfIndex,lldpV2StatsRxDestMACAddress}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,3,7}}, 1, {lldpV2LocPortIfIndex}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,3,8}}, 2, {lldpV2LocManAddrSubtype,lldpV2LocManAddr}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,4,1}}, 4, {lldpV2RemTimeMark,lldpV2RemLocalIfIndex,lldpV2RemLocalDestMACAddress,lldpV2RemIndex}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,4,2}}, 6, {lldpV2RemTimeMark,lldpV2RemLocalIfIndex,lldpV2RemLocalDestMACAddress,lldpV2RemIndex,lldpV2RemManAddrSubtype,lldpV2RemManAddr}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,4,3}}, 5, {lldpV2RemTimeMark,lldpV2RemLocalIfIndex,lldpV2RemLocalDestMACAddress,lldpV2RemIndex,lldpV2RemUnknownTLVType}, sizeof(LLDPD_PORT_T)},
    {{11, {LLDP_OID_BASE,1,4,4}}, 7, {lldpV2RemTimeMark,lldpV2RemLocalIfIndex,lldpV2RemLocalDestMACAddress,lldpV2RemIndex,lldpV2RemOrgDefInfoOUI,lldpV2RemOrgDefInfoSubtype,lldpV2RemOrgDefInfoIndex}, sizeof(LLDPD_PORT_T)},


};

static sint16 mibtabsize_lldp(void)
{
    return sizeof(mibtab_lldp) / sizeof(MIBTAB);
}


static void get_enableport(sint16 varix, sint16 tabix, uint8 **vvptr);
static void get_enableagent(sint16 varix, sint16 tabix, uint8 **vvptr);
static void get_agentconfig(sint16 varix, sint16 tabix, uint8 **vvptr);
static sint16 set_agentconfig(sint16 varix, sint16 tabix, void *vptr);
static void get_destaddr(sint16 varix, sint16 tabix, uint8 **vvptr);
static sint16 set_localport(sint16 varix, sint16 tabix, void *vptr);
static void get_localport(sint16 varix, sint16 tabix, uint8 **vvptr);
static void get_remote(sint16 varix, sint16 tabix, uint8 **vvptr);
static void get_remote_status(sint16 varix, sint16 tabix, uint8 **vvptr);
static void get_localsysdata(sint16 varix, sint16 tabix, uint8 **vvptr);
static sint16 chkindex_destaddr(sint16 varix, sint16 tabix);
static sint16 chkindex_agent(sint16 varix, sint16 tabix);
static sint16 chkindex_port(sint16 varix, sint16 tabix);
static sint16 chkindex_remote(sint16 varix, sint16 tabix);
static sint16 chkindex_remote_on(sint16 varix, sint16 tabix);
static sint16 chkindex_localdata_on(sint16 varix, sint16 tabix);
static sint16 chkindex_localdata(sint16 varix, sint16 tabix);

static const LLDPMIB_PARAM lldp_mibparam [] = {
    {NULL, NULL, NULL, &lldpdMib.msgTxInterval, -1,1,3600},
    {NULL, NULL, NULL, &lldpdMib.msgTxHoldMult, -1,1,100},
    {NULL, NULL, NULL, &lldpdMib.reinitDelay, -1,1,10},
    {NULL, NULL, NULL, &lldpdMib.notifiyInterval, -1,5,3600},
    {NULL, NULL, NULL, &lldpdMib.txCreditMax, -1,1,10},
    {NULL, NULL, NULL, &lldpdMib.msgFastTx, -1,1,3600},
    {NULL, NULL, NULL, &lldpdMib.txFastInit, -1,1,8},
    {NULL, NULL, chkindex_destaddr, NULL, -1,0,0},
    {get_destaddr, NULL, chkindex_destaddr, NULL, -1,0,0},
    {get_enableport, NULL, chkindex_localdata, NULL, -1,0,0},
    {get_enableagent, NULL, chkindex_localdata, NULL, -1,0,0},
    {get_localsysdata, NULL, chkindex_localdata, NULL, -1,0,0},
    {get_localsysdata, NULL, chkindex_localdata, NULL, -1,0,0},
    {get_localsysdata, set_localport, chkindex_localdata, NULL, -1,1,2},
    {NULL, NULL, chkindex_localdata, NULL, 1,0,0},
    {get_enableport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_enableagent, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localport, set_localport, chkindex_agent, NULL, -1,1,4},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,3600},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,100},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,10},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,5,3600},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,10},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,3600},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,8},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,1,2},
    {get_agentconfig, set_agentconfig, chkindex_agent, NULL, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.tblLastChangeTime, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.remTblInserts, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.remTblDeletes, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.remTblDrops, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.remTblAgeouts, -1,0,0},
    {get_enableport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_enableagent, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_enableport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_enableagent, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_agentconfig, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localsysdata, NULL, NULL, NULL, -1,0,0},
    {get_localsysdata, NULL, NULL, NULL, -1,0,0},
    {get_localsysdata, NULL, NULL, NULL, -1,0,0},
    {get_localsysdata, NULL, NULL, NULL, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.locSysCapSup, -1,0,0},
    {NULL, NULL, NULL, &lldpdMib.locSysCapEna, -1,0,0},
    {get_enableport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localport, NULL, chkindex_agent, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {get_localport, NULL, chkindex_localdata_on, NULL, -1,0,0},
    {NULL, NULL, chkindex_remote, NULL, 1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,1,2147483647},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote_status, NULL, chkindex_remote_on, NULL, -1,0,0},
    {get_remote_status, NULL, chkindex_remote_on, NULL, -1,0,0},
    {get_remote_status, NULL, chkindex_remote_on, NULL, -1,0,0},
    {get_remote_status, NULL, chkindex_remote_on, NULL, -1,0,0},
    {get_remote_status, NULL, chkindex_remote_on, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,9,126},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},
    {get_remote, NULL, chkindex_remote, NULL, -1,1,255},
    {NULL, NULL, chkindex_remote, NULL, 1,1,2147483647},
    {get_remote, NULL, chkindex_remote, NULL, -1,0,0},

};

static int getunit_index(sint16 tabix, int *index, int *pix, int *aix)
{
    LLDPD_PORT_T *port;
    int tmp;
    static int agent_factor = 0;

    if (!agent_factor) {
        int data = LLDPD_PORT_NUM * LLDPD_MC_NUM;
        agent_factor = 1;
        do {
            data /= 10;
            agent_factor *= 10;
        } while (0 < data);
    }
    if (tabix < 0) {
        *index = 0;
        *aix = 0;
        *pix = 0;
    }
    else {
        tmp = tabix % agent_factor;
        *index = tabix / agent_factor;
        *aix = tmp % LLDPD_MC_NUM;
        *pix = tmp / LLDPD_MC_NUM;
    }

    if (LLDPD_PORT_NUM <= *pix || LLDPD_MC_NUM <= *aix) {
        return 0;
    }
    return 1;
}
static int getunit_tlv_index(sint16 tabix, int *index, int *pix, int *aix)
{
    int ret;
    ret = getunit_index(tabix, index, pix, aix);

    if (MSW_LLDP_MNGTLV_NUM <= *index) {
        return -1;
    }
    return ret;
}

static void get_enableport(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    int pix = 0, aix, index;

    if (lldp_mibparam[varix].index == chkindex_localdata || 
        lldp_mibparam[varix].index == chkindex_remote) {
        getunit_tlv_index(tabix, &index, &pix, &aix);
    }
    else if (lldp_mibparam[varix].index == chkindex_agent) {
        pix = tabix / LLDPD_MC_NUM;
    }
    else {
        pix = tabix;
    }
    **vvptr = lldpdMib.lldpdPort[pix].portno;
}

static void get_enableagent(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    int pix = 0, aix = 0, index;

    getunit_tlv_index(tabix, &index, &pix, &aix);
    **vvptr = aix;
}

static void get_agentconfig(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    sint16 pix = tabix / LLDPD_MC_NUM;
    sint16 aix = tabix % LLDPD_MC_NUM;
    LLDPD_AGENT_T *agent;

    usswLldpdLock();
    agent = &lldpdMib.lldpdPort[pix].lldpdAgent[aix];
    switch (varix) {
        case lldpV2PortMessageTxInterval:
            **(uint32 **)vvptr = agent->lldpdConfig.msgTxInterval;
            break;
        case lldpV2PortMessageTxHoldMultiplier:
            **(uint32 **)vvptr = agent->lldpdConfig.msgTxHold;
            break;
        case lldpV2PortReinitDelay:
            **(uint32 **)vvptr = agent->lldpdConfig.reinitDelay;
            break;
        case lldpV2PortNotificationInterval:
            **(uint32 **)vvptr = agent->lldpdConfig.notifiyInterval;
            break;
        case lldpV2PortTxCreditMax:
            **(uint32 **)vvptr = agent->lldpdConfig.txCreditMax;
            break;
        case lldpV2PortMessageFastTx:
            **(uint32 **)vvptr = agent->lldpdConfig.msgFastTx;
            break;
        case lldpV2PortTxFastInit:
            **(uint32 **)vvptr = agent->lldpdConfig.txFastInit;
            break;
        case lldpV2PortConfigNotificationEnableV2:
            **(uint32 **)vvptr = agent->lldpdConfig.notifiyEnableV2 ? SNMP_TRUE : SNMP_FALSE;
            break;
        case lldpV2PortConfigTLVsTxEnableV2:
            **(uint8 **)vvptr = SNMP_PORTCFG_TXEN_DEC(agent->lldpdConfig.tLVsTxEnableV2);
            break;
        case lldpV2StatsTxPortFramesTotal:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.stsFrmOut;
            break;
        case lldpV2StatsTxLLDPDULengthErrors:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.stsLenErr;
            break;
        case lldpV2StatsRxPortFramesDiscardedTotal:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.stsFrmDiscarded;
            break;
        case lldpV2StatsRxPortFramesErrors:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.stsFrmInErr;
            break;
        case lldpV2StatsRxPortFramesTotal:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.stsFrmIn;
            break;
        case lldpV2StatsRxPortTLVsDiscardedTotal:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.tlvinfo.stsTlvDiscarded;
            break;
        case lldpV2StatsRxPortTLVsUnrecognizedTotal:
            **(uint32 **)vvptr = agent->lldpdStat.statInfo.tlvinfo.stsTlvUnrecognized;
            break;
        case lldpV2StatsRxPortAgeoutsTotal:
            **(uint32 **)vvptr = agent->lldpdStat.rxAgeoutsTotal;
            break;
    }
    usswLldpdUnLock();
}

static int setUint32Value(uint32 val, uint32 *result)
{
    if (val == *result) {
        return 0;
    }
    *result = val;
    return 1;
}

static sint16 set_agentconfig(sint16 varix, sint16 tabix, void *vptr)
{
    sint16 pix = tabix / LLDPD_MC_NUM;
    sint16 aix = tabix % LLDPD_MC_NUM;
    LLDPD_AGENT_T *agent;
    int change = 0;
    int ttl = -1;
    int status = -1;

    usswLldpdLock();
    agent = &lldpdMib.lldpdPort[pix].lldpdAgent[aix];
    switch (varix) {
        case lldpV2PortMessageTxInterval:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.msgTxInterval);
            if (change) {
                ttl = agent->lldpdConfig.msgTxInterval * agent->lldpdConfig.msgTxHold + 1;
            }
            break;
        case lldpV2PortMessageTxHoldMultiplier:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.msgTxHold);
            if (change) {
                ttl = agent->lldpdConfig.msgTxInterval * agent->lldpdConfig.msgTxHold + 1;
            }
            break;
        case lldpV2PortReinitDelay:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.reinitDelay);
            break;
        case lldpV2PortNotificationInterval:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.notifiyInterval);
            break;
        case lldpV2PortTxCreditMax:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.txCreditMax);
            break;
        case lldpV2PortMessageFastTx:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.msgFastTx);
            break;
        case lldpV2PortTxFastInit:
            change = setUint32Value(*(uint32 *)vptr, &agent->lldpdConfig.txFastInit);
            break;
        case lldpV2PortConfigNotificationEnableV2:
        {
            uint32 val = *(uint32 *)vptr;
            if (val == SNMP_TRUE && !agent->lldpdConfig.notifiyEnableV2) {
                agent->lldpdConfig.notifiyEnableV2 = TRUE;
                change = 1;
            }
            else if (val == SNMP_FALSE && agent->lldpdConfig.notifiyEnableV2) {
                agent->lldpdConfig.notifiyEnableV2 = FALSE;
                change = 1;
            }
        }
            break;
        case lldpV2PortConfigTLVsTxEnableV2:
        {
            uint8 val = SNMP_PORTCFG_TXEN_ENC(*(uint8 *)vptr);

            if (val != agent->lldpdConfig.tLVsTxEnableV2) {
                agent->lldpdConfig.tLVsTxEnableV2 = val;
                status = val;
                change = 1;
            }
        }
            break;
    }
    usswLldpdUnLock();

    if (0 <= ttl || 0 <= status) {
        MSW_LLDP_LOCAL_INFO_T info;
        if (0xffff < ttl) {
            ttl = 0xffff;
        }

        strncpy(info.ifname, 
            lldpdhwport[lldpdMib.lldpdPort[pix].portno].ifname, 
            sizeof(info.ifname));
        info.mcBitmap = agent->mcBitmap;

        if (mswLldpLocalDataGet(&info) == MSW_EC_NO_ERROR) {
            if (0 <= ttl) {
                info.tlv.ttl.ttl = ttl;
            }
            if (0 <= status) {
                info.tlv.portdes.status = !!(status & SNMP_PORTCFG_TXEN_PORTDESC);
                info.tlv.sysname.status = !!(status & SNMP_PORTCFG_TXEN_SYSNAME);
                info.tlv.sysdes.status = !!(status & SNMP_PORTCFG_TXEN_SYSDESC);
                info.tlv.syscap.status = !!(status & SNMP_PORTCFG_TXEN_SYSCAP);
            }
            mswLldpLocalDataSet(&info);
        }
    }
    if (change) {
        somethingChangedLocal(agent);
    }

    return 0;
}

static void get_destaddr(sint16 varix, sint16 tabix, uint8 **vvptr)
{

    switch (tabix) {
        case NEAREST_BRIDGE:
            memcpy(*vvptr, nearest_bridge, ETH_ADR_SZ);
            break;
        case NEAREST_NONTPMR_BRIDGE:
            memcpy(*vvptr, nearest_nontpmr_bridge, ETH_ADR_SZ);
            break;
        case NEAREST_CUSTOMER_BRIDGE:
            memcpy(*vvptr, nearest_customer_bridge, ETH_ADR_SZ);
            break;
        default:
            break;
    }
}

static void get_remote(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    int i1, pix, aix;
    int count;
    LLDPD_AGENT_T *agent;
    LLDPD_REM_TBL_T *rem;

    count = 0;
    for (pix = 0; pix < LLDPD_PORT_NUM; pix++) {
        for (aix = 0; aix < LLDPD_MC_NUM; aix++) {
            agent = &lldpdMib.lldpdPort[pix].lldpdAgent[aix];
            rem = agent->pLldpdRemData;
            while (rem && (count++ < tabix)) {
                rem = rem->next;
            }
            if (rem) {
                break;
            }
        }
        if (rem) {
            break;
        }
    }
    if (!rem) {
        return ;
    }

    switch (varix) {
        case lldpV2RemLocalIfIndex:
            **(uint8 **)vvptr = pix;
            break;
        case lldpV2RemLocalDestMACAddress:
            **(uint8 **)vvptr = aix;
            break;
        case lldpV2RemIndex:
            **(uint32 **)vvptr = rem->remIndex + 1;
            break;
        case lldpV2RemChassisIdSubtype:
            **(uint32 **)vvptr = rem->tlvs.chassis.subtype;
            break;
        case lldpV2RemChassisId:
            if (1 < rem->tlvs.chassis.curlen) {
                mibvar_lldp[varix].len = rem->tlvs.chassis.curlen - 1;
            }
            memcpy(*vvptr, 
                rem->tlvs.chassis.id, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemPortIdSubtype:
            **(uint32 **)vvptr = rem->tlvs.portid.subtype;
            break;
        case lldpV2RemPortId:
            if (1 < rem->tlvs.portid.curlen) {
                mibvar_lldp[varix].len = rem->tlvs.portid.curlen - 1;
            }
            memcpy(*vvptr, 
                rem->tlvs.portid.id, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemPortDesc:
            mibvar_lldp[varix].len = rem->tlvs.portdes.curlen;
            memcpy(*vvptr, 
                rem->tlvs.portdes.pdes, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemSysName:
            mibvar_lldp[varix].len = rem->tlvs.sysname.curlen;
            memcpy(*vvptr, 
                rem->tlvs.sysname.name, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemSysDesc:
            mibvar_lldp[varix].len = rem->tlvs.sysdes.curlen;
            memcpy(*vvptr, 
                rem->tlvs.sysdes.sdes, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemSysCapSupported:
            **(uint16 **)vvptr = rem->tlvs.syscap.scap;
            break;
        case lldpV2RemSysCapEnabled:
            **(uint16 **)vvptr = rem->tlvs.syscap.enbl;
            break;
        case lldpV2RemRemoteChanges:
            **(uint32 **)vvptr = agent->rxState.remoteChange ? SNMP_TRUE : SNMP_FALSE;
            break;
        case lldpV2RemTooManyNeighbors:
            **(uint32 **)vvptr = agent->rxState.tooManyNghbrs ? SNMP_TRUE : SNMP_FALSE;
            break;
        case lldpV2RemUnknownTLVType:
            **(uint32 **)vvptr = (rem->remUnknownTLV[0] & 0xFE) >> 1;
            break;
        case lldpV2RemUnknownTLVInfo:
            mibvar_lldp[varix].len = 
                (((rem->remUnknownTLV[0] & 0x01) << 8) | rem->remUnknownTLV[1] & 0xff) + 2;
            if (mibvar_lldp[varix].len < 0) {
                mibvar_lldp[varix].len = 0;
            }
            memcpy(*vvptr, 
                rem->remUnknownTLV, 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemOrgDefInfoOUI:
            memcpy(*vvptr, 
                &rem->orgDefInfo[2], 
                mibvar_lldp[varix].len);
            break;
        case lldpV2RemOrgDefInfoSubtype:
            **(uint32 **)vvptr = rem->orgDefInfo[5];
            break;
        case lldpV2RemOrgDefInfo:
            mibvar_lldp[varix].len = 
                (((rem->orgDefInfo[0] & 0x01) << 8) | rem->orgDefInfo[1] & 0xff) - 4;
            if (mibvar_lldp[varix].len < 0) {
                mibvar_lldp[varix].len = 0;
            }
            memcpy(*vvptr, 
                &rem->orgDefInfo[6], 
                mibvar_lldp[varix].len);
            break;
    }
}

static void get_remote_status(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    int i1, pix, aix;
    int count;
    LLDPD_REM_TBL_T *rem;

    count = 0;
    for (pix = 0; pix < LLDPD_PORT_NUM; pix++) {
        for (aix = 0; aix < LLDPD_MC_NUM; aix++) {
            rem = lldpdMib.lldpdPort[pix].lldpdAgent[aix].pLldpdRemData;
            while (rem && (count++ < tabix)) {
                rem = rem->next;
            }
            if (rem) {
                break;
            }
        }
        if (rem) {
            break;
        }
    }
    if (!rem) {
        return ;
    }

    for (i1 = 0; i1 < MSW_LLDP_MNGTLV_NUM; i1++) {
        if (rem->tlvs.mngaddr[i1].status) {
            switch (varix) {
                case lldpV2RemManAddrSubtype:
                    **(uint32 **)vvptr = rem->tlvs.mngaddr[i1].addr.type;
                    break;
                case lldpV2RemManAddr:
                    if (1 < rem->tlvs.mngaddr[i1].strlen) {
                        mibvar_lldp[varix].len = rem->tlvs.mngaddr[i1].strlen - 1;
                    }
                    memcpy(*vvptr, 
                        rem->tlvs.mngaddr[i1].addr.addr, 
                        mibvar_lldp[varix].len);
                    break;
                case lldpV2RemManAddrIfSubtype:
                    **(uint32 **)vvptr = rem->tlvs.mngaddr[i1].iftype;
                    break;
                case lldpV2RemManAddrIfId:
                    **(uint32 **)vvptr = rem->tlvs.mngaddr[i1].ifnum;
                    break;
                case lldpV2RemManAddrOID:
                    mibvar_lldp[varix].len = rem->tlvs.mngaddr[i1].obj.len;
                    memcpy(*vvptr, 
                        rem->tlvs.mngaddr[i1].obj.id, 
                        mibvar_lldp[varix].len);
                    break;
            }
            break;
        }
    }
}

static int getunit_localdata(sint16 tabix, MSW_LLDP_LOCAL_INFO_T *info)
{
    LLDPD_PORT_T *port;
    LLDPD_AGENT_T *agent;
    int pix, aix, index;
    int ret;

    ret = getunit_tlv_index(tabix, &index, &pix, &aix);
    if (ret < 0) {
        return -1;
    }
    if (ret == 0) {
        return 0;
    }

    port = &lldpdMib.lldpdPort[pix];
    agent = &port->lldpdAgent[aix];

    if (!port->portEnabled || port->netno < 0 || !agent->agentEnabled) {
        return 0;
    }

    strncpy(info->ifname, 
        lldpdhwport[port->portno].ifname, 
        sizeof(info->ifname));
    info->mcBitmap = agent->mcBitmap;

    if (mswLldpLocalDataGet(info) != MSW_EC_NO_ERROR) {
        return 0;
    }

    return index + 1;
}
static LLDPD_AGENT_T * getunit_agent(sint16 tabix)
{
    LLDPD_PORT_T *port;
    LLDPD_AGENT_T *agent;
    int pix, aix, index;
    int ret;
    

    ret = getunit_tlv_index(tabix, &index, &pix, &aix);
    if (ret <= 0) {
        return NULL;
    }

    port = &lldpdMib.lldpdPort[pix];
    agent = &port->lldpdAgent[aix];

    if (!port->portEnabled || port->netno < 0 || !agent->agentEnabled) {
        return NULL;
    }
    return agent;
}

static sint16 set_localport(sint16 varix, sint16 tabix, void *vptr)
{
    MSW_LLDP_LOCAL_INFO_T info;
    LLDPD_AGENT_T *agent;
    int index;
    int change = 0;

    index = getunit_localdata(tabix, &info) - 1;
    if (index < 0) {
        return -1;
    }

    switch (varix) {
        case lldpV2PortConfigAdminStatusV2:
        {
            uint32 val = *(uint32 *)vptr;
            if (val != info.adminStatus) {
                info.adminStatus = val;
                change = 1;
            }
        }
            break;
        case lldpV2ManAddrConfigTxEnable:
        {
            uint32 val = *(uint32 *)vptr;
            if (val == SNMP_TRUE && !info.tlv.mngaddr[index].status) {
                info.tlv.mngaddr[index].status = TRUE;
                change = 1;
            }
            else if (val == SNMP_FALSE && info.tlv.mngaddr[index].status) {
                info.tlv.mngaddr[index].status = FALSE;
                change = 1;
            }
        }
            break;
        default:
            return -1;
    }
    if (change) {
        if (mswLldpLocalDataSet(&info) != MSW_EC_NO_ERROR) {
            return -1;
        }
        agent = getunit_agent(tabix);
        if (agent != NULL) {
            somethingChangedLocal(agent);
        }
    }

    return 0;
}

static void get_localport(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    MSW_LLDP_LOCAL_INFO_T info;
    int index;
    int len;

    index = getunit_localdata(tabix, &info) - 1;
    if (index < 0) {
        return ;
    }
    if (!info.tlv.mngaddr[index].status) {
        return ;
    }

    switch (varix) {
        case lldpV2PortConfigAdminStatusV2:
            **(uint32 **)vvptr = info.adminStatus;
            break;
        case lldpV2LocPortIdSubtype:
            **(uint32 **)vvptr = info.tlv.portid.subtype;
            break;
        case lldpV2LocPortId:
            if (1 < info.tlv.portid.curlen) {
                mibvar_lldp[varix].len = info.tlv.portid.curlen - 1;
            }
            memcpy(*vvptr, 
                info.tlv.portid.id,
                mibvar_lldp[varix].len);
            break;
        case lldpV2LocPortDesc:
            mibvar_lldp[varix].len = info.tlv.portdes.curlen;
            memcpy(*vvptr, 
                info.tlv.portdes.pdes,
                mibvar_lldp[varix].len);
            break;
        case lldpV2LocManAddrSubtype:
            **(uint32 **)vvptr = info.tlv.mngaddr[index].addr.type;
            break;
        case lldpV2LocManAddr:
            len = info.tlv.mngaddr[index].strlen <= Max_SZMNG_ADDR ? 
                (info.tlv.mngaddr[index].strlen - 1) : Max_SZMNG_ADDR;
            if (0 < len) {
                memcpy(*vvptr, info.tlv.mngaddr[index].addr.addr, len);
                mibvar_lldp[varix].len = len;
            }
            else {
                mibvar_lldp[varix].len = 0;
            }
            break;
        case lldpV2LocManAddrLen:
            **(uint32 **)vvptr = info.tlv.mngaddr[index].strlen;
            break;
        case lldpV2LocManAddrIfSubtype:
            **(uint32 **)vvptr = info.tlv.mngaddr[index].iftype;
            break;
        case lldpV2LocManAddrIfId:
            **(uint32 **)vvptr = info.tlv.mngaddr[index].ifnum;
            break;
        case lldpV2LocManAddrOID:
            mibvar_lldp[varix].len = info.tlv.mngaddr[index].obj.len;
            memcpy(*vvptr, 
                info.tlv.mngaddr[index].obj.id,
                mibvar_lldp[varix].len);
            break;
    }
}

static void get_localsysdata(sint16 varix, sint16 tabix, uint8 **vvptr)
{
    MSW_LLDP_LOCAL_INFO_T info;
    int index;
    int len;

    index = getunit_localdata(tabix, &info) - 1;
    if (index < 0) {
        return ;
    }

    switch (varix) {
        case lldpV2LocChassisIdSubtype:
            **(uint32 **)vvptr = info.tlv.chassis.subtype;
            break;
        case lldpV2LocChassisId:
            if (1 < info.tlv.chassis.curlen) {
                mibvar_lldp[varix].len = info.tlv.chassis.curlen - 1;
            }
            memcpy(*vvptr, 
                info.tlv.chassis.id,
                mibvar_lldp[varix].len);
            break;
        case lldpV2LocSysName:
            mibvar_lldp[varix].len = info.tlv.sysname.curlen;
            memcpy(*vvptr, 
                info.tlv.sysname.name,
                mibvar_lldp[varix].len);
            break;
        case lldpV2LocSysDesc:
            mibvar_lldp[varix].len = info.tlv.sysdes.curlen;
            memcpy(*vvptr, 
                info.tlv.sysdes.sdes,
                mibvar_lldp[varix].len);
            break;
        case lldpV2ManAddrConfigLocManAddrSubtype:
            **(uint32 **)vvptr = info.adminStatus;
            break;
        case lldpV2ManAddrConfigTxEnable:
            **(uint32 **)vvptr = info.tlv.mngaddr[index].status ? SNMP_TRUE : SNMP_FALSE;
            break;
        case lldpV2ManAddrConfigLocManAddr:
            len = info.tlv.mngaddr[index].strlen <= Max_SZMNG_ADDR ? 
                (info.tlv.mngaddr[index].strlen - 1) : Max_SZMNG_ADDR;
            if (0 < len) {
                memcpy(*vvptr, info.tlv.mngaddr[index].addr.addr, len);
                mibvar_lldp[varix].len = len;
            }
            else {
                mibvar_lldp[varix].len = 0;
            }
            break;
    }
}

static sint16 chkindex_destaddr(sint16 varix, sint16 tabix)
{
    if (tabix < 0 || MSW_LLDP_MC_NUM <= tabix) {
        return -1;
    }
    return 1;
}

static sint16 chkindex_agent(sint16 varix, sint16 tabix)
{
    sint16 ret = 0;
    sint16 pix, aix;

    if (tabix < 0 || (LLDPD_PORT_NUM * LLDPD_MC_NUM) <= tabix) {
        return -1;
    }

    pix = tabix / LLDPD_MC_NUM;
    aix = tabix % LLDPD_MC_NUM;

    if ((lldpdMib.lldpdPort[pix].portEnabled == TRUE) && 
        0 <= lldpdMib.lldpdPort[pix].netno && 
        (lldpdMib.lldpdPort[pix].lldpdAgent[aix].agentEnabled == TRUE)) {
        ret = 1;
    }
    return ret;
}

static sint16 chkindex_port(sint16 varix, sint16 tabix)
{
    sint16 ret = 0;
    if (tabix < 0 || LLDPD_PORT_NUM <= tabix) {
        return -1;
    }

    if (lldpdMib.lldpdPort[tabix].portEnabled == TRUE && 
        0 <= lldpdMib.lldpdPort[tabix].netno) {
        ret = 1;
    }
    return ret;
}

static sint16 chkindex_remote(sint16 varix, sint16 tabix)
{
    int pix, aix, count;
    LLDPD_REM_TBL_T *rem;

    if (tabix < 0) {
        return 0;
    }
    if (LLDPD_REM_TBL_NUM <= tabix) {
        return -1;
    }

    count = 0;
    for (pix = 0; pix < LLDPD_PORT_NUM; pix++) {
        for (aix = 0; aix < LLDPD_MC_NUM; aix++) {
            rem = lldpdMib.lldpdPort[pix].lldpdAgent[aix].pLldpdRemData;
            while (rem && (count++ < tabix)) {
                rem = rem->next;
            }
            if (rem) {
                break;
            }
        }
        if (rem) {
            break;
        }
    }
    if (!rem) {
        return 0;
    }

    return 1;
}

static sint16 chkindex_remote_on(sint16 varix, sint16 tabix)
{
    int pix, aix, count;
    int i1;
    LLDPD_REM_TBL_T *rem;

    if (tabix < 0) {
        return 0;
    }
    if (LLDPD_REM_TBL_NUM <= tabix) {
        return -1;
    }

    count = 0;
    for (pix = 0; pix < LLDPD_PORT_NUM; pix++) {
        for (aix = 0; aix < LLDPD_MC_NUM; aix++) {
            rem = lldpdMib.lldpdPort[pix].lldpdAgent[aix].pLldpdRemData;
            while (rem && (count++ < tabix)) {
                rem = rem->next;
            }
            if (rem) {
                break;
            }
        }
        if (rem) {
            break;
        }
    }
    if (!rem) {
        return 0;
    }
    for (i1 = 0; i1 < MSW_LLDP_MNGTLV_NUM; i1++) {
        if (rem_tbl[tabix].tlvs.mngaddr[i1].status) {
            return 1;
        }
    }

    return 0;
}
static sint16 chkindex_local_core(sint16 varix, sint16 tabix, int chkstatus)
{
    MSW_LLDP_LOCAL_INFO_T info;
    int index;

    index = getunit_localdata(tabix, &info);
    if (index < 0) {
        return -1;
    }
    else if (index == 0) {
        return 0;
    }
    else {
        if (chkstatus) {
            if (!info.tlv.mngaddr[index - 1].status) {
                return 0;
            }
        }
    }

    return 1;
}
static sint16 chkindex_localdata_on(sint16 varix, sint16 tabix)
{
    return chkindex_local_core(varix, tabix, 1);
}
static sint16 chkindex_localdata(sint16 varix, sint16 tabix)
{
    return chkindex_local_core(varix, tabix, 0);
}


static void mibget_lldp(sint16 varix, sint16 tabix, uint8 **vvptr)
{

    if (varix < 0 || (sizeof(lldp_mibparam) / sizeof(lldp_mibparam[0])) <= varix) {
        return;
    }

    memset(*vvptr, 0, mibvar_lldp[varix].len);

    if (lldp_mibparam[varix].ptr != NULL) {
        memcpy(*vvptr, lldp_mibparam[varix].ptr, mibvar_lldp[varix].len);
    }
    else {
        if (lldp_mibparam[varix].get != NULL) {
            lldp_mibparam[varix].get(varix, tabix, vvptr);
        }
        else {
            if (lldp_mibparam[varix].fixed & 0x80000000) {
                **vvptr = tabix;
            }
            else {
                if (mibvar_lldp[varix].opt & BASE1) {
                    **vvptr = lldp_mibparam[varix].fixed - 1;
                }
                else {
                    **(uint32 **)vvptr = lldp_mibparam[varix].fixed;
                }
            }
        }
    }
end:
    return;
}

static sint16 mibset_lldp(sint16 varix, sint16 tabix)
{
    int ret = 0;

    if (varix < 0 || (sizeof(lldp_mibparam) / sizeof(lldp_mibparam[0])) <= varix) {
        return -1;
    }

    if (lldp_mibparam[varix].min < lldp_mibparam[varix].max) {
        uint32 val = *(uint32 *)mibvar_lldp[varix].ptr;
        if (val < lldp_mibparam[varix].min) {
            return -1;
        }
        else if (lldp_mibparam[varix].max < val) {
            return -1;
        }
    }

    if (lldp_mibparam[varix].ptr != NULL) {
        usswLldpdLock();
        memcpy(lldp_mibparam[varix].ptr, 
            mibvar_lldp[varix].ptr, 
            mibvar_lldp[varix].len);
        usswLldpdUnLock();
    }
    else {
        if (lldp_mibparam[varix].set != NULL) {
            ret = lldp_mibparam[varix].set(varix, tabix, mibvar_lldp[varix].ptr);
        }
    }

    return ret;
}

static sint16 mibindex_lldp(sint16 varix, sint16 tabix)
{
    sint16 ret = -1;

    if (varix < 0 || (sizeof(lldp_mibparam) / sizeof(lldp_mibparam[0])) <= varix) {
        return -1;
    }

    if (lldp_mibparam[varix].index != NULL) {
        ret = lldp_mibparam[varix].index(varix, tabix);
    }
    else {
        if (tabix == 0) {
            ret = 1;
        }
        else {
            ret = -1;
        }
    }
    return ret;
}

const MIB mib_lldp =
{
    mibvar_lldp,
    mibvarsize_lldp,
    mibtab_lldp,
    mibtabsize_lldp,
    mibget_lldp,
    mibset_lldp,
    mibindex_lldp,
    0,
    0
};
#endif
