/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MANAGEMENTID_1588_H__
#define __PTP_MANAGEMENTID_1588_H__


#define MID_1588_CLOCK_DESCRIPTION		(0)
#define MID_1588_USER_DESCRIPTION		(1)
#define MID_1588_FAULT_LOG				(2)
#define MID_1588_FALULTLOG_RESET		(3)
#define MID_1588_DEFAULT_DATA_SET		(4)
#define MID_1588_CURRENT_DATA_SET		(5)
#define MID_1588_PARENT_DATA_SET		(6)
#define MID_1588_TIME_PROP_DATA_SET		(7)
#define MID_1588_PORT_DATA_SET			(8)
#define MID_1588_PRIORITY1				(9)
#define MID_1588_PRIORITY2				(10)

#define MID_1588_SLAVE_ONLY				(11)
#define MID_1588_LOG_ANN_INT			(12)
#define MID_1588_ANN_RECEIPT_TMO		(13)
#define MID_1588_LOG_SYNC_INT			(14)
#define MID_1588_VERSION_NUMBER			(15)
#define MID_1588_ENABLE_PORT			(16)
#define MID_1588_DISABLE_PORT			(17)
#define MID_1588_TIME					(18)
#define MID_1588_CLOCK_ACCURACY			(19)
#define MID_1588_UTC_PROPERTIES			(20)
#define MID_1588_TRACE_PROP				(21)
#define MID_1588_TIMESCALE_PROP			(22)
#define MID_1588_PATH_TRACE_LIST		(23)
#define MID_1588_PATH_TRACE_ENBLE		(24)
#define MID_1588_PORT_STAT_CNT			(25)
#define MID_1588_CMLD_PORT_STAT_CNT		(26)
#define MID_1588_TRANS_DEFAULT_DS		(27)
#define MID_1588_TRANS_PORT_DS			(28)
#define MID_1588_PRIMARY_DOMAIN			(29)
#define MID_1588_DELAY_MECHANISM		(30)
#define MID_1588_MIN_PDELAY_REQ_INT		(31)
#define MID_1588_MAX					(MID_1588_MIN_PDELAY_REQ_INT)

#endif
