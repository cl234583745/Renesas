//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
#ifndef _USS_CONFIG6_H_
#define _USS_CONFIG6_H_

#undef INET6

#undef USS_IP6_REDIRECT
#undef USS_IP6_PMTU

#endif
