//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_DHCP_H_
#define _USS_DHCP_H_

#define DHCP_SERVER "test"

#define DHCP_PROBE

#undef DHCP_BROADCAST

#define CONF_FILE "dhcp.con"

#define LEASE_FILE 	"dhcp.lea"

#define SERVER_PORT 67
#define CLIENT_PORT 68

#define DHCP_CONFIG 1

#define FILENAMESIZE 80

#define MAXDELAY 30000         


#define DHCPDISCOVER 	1
#define DHCPOFFER 	2
#define DHCPREQUEST 	3
#define DHCPDECLINE 	4
#define DHCPACK 	5
#define DHCPNAK 	6
#define DHCPRELEASE 	7
#define DHCPINFORM  8
#define BOOTREQUEST 1
#define BOOTREPLY 2

#ifndef EOF
#include <stdio.h>
#endif

struct DHCPstr {
    unsigned char   op;
    unsigned char   htype;
    unsigned char   hlen;
    unsigned char   hops;
    unsigned long   xid;
    unsigned short  secs;
    unsigned short  flags;
    unsigned long   ciaddr;
    unsigned long   yiaddr;
    unsigned long   siaddr;
    unsigned long   giaddr;
    unsigned char   chaddr[16];
    unsigned char   sname[64];
    unsigned char   file[128];
    unsigned char   options[312];
};

#define DHCPsz 236

#if DHCP_CONFIG == 2
static const unsigned char discopts[] = {99, 130, 83, 99, 53, 1, DHCPDISCOVER, 55, 3, 1, 3, 6};
#else
static const unsigned char discopts[] = {99, 130, 83, 99, 53, 1, DHCPDISCOVER};
#endif
static const unsigned char releopts[] = {99, 130, 83, 99, 53, 1, DHCPRELEASE};
static const unsigned char offopts[] = {99, 130, 83, 99, 53, 1, DHCPOFFER};
static const unsigned char ackopts[] = {99, 130, 83, 99, 53, 1, DHCPACK};
static const unsigned char nakopts[] = {99, 130, 83, 99, 53, 1, DHCPNAK};

struct client {		
	struct Eid haddr;
	Iid iaddr;
	short active;
};


struct addrpool {
	Iid iaddr;
	short used;
};

struct config {
	Iid submask;
	Iid rangel;
	Iid rangeh;
	int nrouter;
	Iid routeaddr[5];
	int ndns;
	Iid dnsaddr[5];
	char dns_domain[65];
	char bootfile[128];
};


#define TIMEINMS(sec, curtime) \
    sec > 0x7fffffffUL/1000UL ? curtime + 0x7fffffffUL : sec*1000UL + curtime

extern short DHCPfirst;
extern short DHCPadv;

#define InitOption DHCPfirst = 0, DHCPadv = 0

#ifndef LITTLE
#define GETLONG2(w, net) memcpy(w, net, 6)
#define GETLONG_BYTE(w, net) (w.c[0] = net[0], w.c[1] = net[1], \
        w.c[2] = net[2], w.c[3] = net[3])
#define PUTLONG_BYTE(w, net) (net[0] = w.c[0], net[1] = w.c[1], \
        net[2] = w.c[2], net[3] = w.c[3])
#define PUTLONG2(w, net) memcpy(net, w, 6)
#else
#define GETLONG_BYTE GETLONG
#define PUTLONG_BYTE PUTLONG
#define GETLONG2(w, net) w.c[0] = net[5], w.c[1] = net[4], \
        w.c[2] = net[3], w.c[3] = net[2], w.c[4] = net[1], \
		w.c[5] = net[0] 
#define PUTLONG2(w, net) net[0] = w.c[5], net[1] = w.c[4], \
        net[2] = w.c[3], net[3] = w.c[2], net[4] = w.c[1], \
		net[5] = w.c[0]   	
#endif

#define INADDR_ANY 0


#ifndef Eid_SZ

#define Eid_SZ 6
struct Eid {
	unsigned char c[Eid_SZ];
};

#define Iid_SZ 4
typedef union {
	unsigned char c[Iid_SZ];
	unsigned short s[Iid_SZ/2];
	unsigned long l;
}			Iid;


#endif

#ifndef NLONG

#ifndef LITTLE
#define GETLONG(w, net) w.s[0] = net[0], w.s[1] = net[1]
#define PUTLONG(w, net) net[0] = w.s[0], net[1] = w.s[1]
#else
#define GETLONG(w, net) w.c[0] = net[3], w.c[1] = net[2], \
	w.c[2] = net[1], w.c[3] = net[0]
#define PUTLONG(w, net) net[0] = w.c[3], net[1] = w.c[2], \
	net[2] = w.c[1], net[3] = w.c[0]
#endif

#endif


#ifndef NNETS

#define DNS 1

char            localhostname[32];
#define LOCALHOSTNAME(grommit) \
    if (getenv("HOST")) strcpy(grommit,getenv("HOST")); \
    else strcpy(grommit, "none")


#endif

void DHCPserv(void);
unsigned char *NextOption(struct DHCPstr * DHCPp);

#endif
