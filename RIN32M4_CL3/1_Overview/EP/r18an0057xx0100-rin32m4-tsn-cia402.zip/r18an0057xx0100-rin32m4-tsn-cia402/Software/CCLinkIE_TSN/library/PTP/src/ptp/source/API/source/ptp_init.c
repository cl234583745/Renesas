/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/



#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_tsn_Wrapper.h"
#include "ptp_api.h"
#include "ptp_MemManage.h"

#include "ptp_init.h"
#include "ptp_LCEntity.h"

#include "ptp_LogRecord.h"











INT ptp_init(void)
{
	INT			nRet				= RET_ESTATE;
	BOOL		blRet 				= FALSE;
	VOID*		pvLockHandleTimer	= NULL;
	VOID*		pvLockHandlePTP		= NULL;
	USHORT		usEvent				= PTP_EV_BEGIN;
	CLOCKDATA*	pstClockData		= NULL;

	if (gblStartUpInit == TRUE)
	{
		return nRet;
	}

#if 1
	gblStartUpInit	= FALSE;
#endif
	if (gpstClockDataHPtr != NULL)
	{
		return	nRet;
	}
	ptp_LogRecordInit( gpstClockDataHPtr );

	blRet = ptp_MMInit(CLOCK_NUM_0);
	if(blRet == FALSE)
	{
		nRet = RET_ESTATE;
		return	nRet;
	}

	tsn_Wrapper_RandInit();

	nRet = tsn_Wrapper_LockCreate(&pvLockHandleTimer);
	if (nRet != RET_ENOERR)
	{
		nRet = RET_EWRAP;
		return	nRet;
	}

	nRet = tsn_Wrapper_LockCreate(&pvLockHandlePTP);
	if (nRet != RET_ENOERR)
	{
		tsn_Wrapper_LockDelete(pvLockHandleTimer);
		nRet = RET_EWRAP;
		return	nRet;
	}

	gpvLockHandleTimer 	= pvLockHandleTimer;
	gpvLockHandlePTP 	= pvLockHandlePTP;


	localClockEntity(usEvent, pstClockData);

#if 1
	gblStartUpInit		= TRUE;
#endif
	nRet				= RET_ENOERR;

	return	nRet;

}

INT ptp_uninit(void)
{
	INT			nRet				= RET_ESTATE;
	INT			nRetSub				= RET_ENOERR;

	if (gblStartUpInit == FALSE)
	{
		return nRet;
	}
	else if(gblStartUpConfig == TRUE)
	{
		return nRet;
	}


	nRet = RET_ENOERR;

	nRetSub = tsn_Wrapper_LockDelete(gpvLockHandleTimer);
	if (nRetSub != RET_ENOERR)
	{
		nRet = RET_EWRAP;
	}

	nRetSub = tsn_Wrapper_LockDelete(gpvLockHandlePTP);
	if (nRetSub != RET_ENOERR)
	{
		nRet = RET_EWRAP;
	}

	gpvLockHandleTimer 	= NULL;
	gpvLockHandlePTP 	= NULL;

	gblStartUpInit = FALSE;
	gblStartUpConfig = FALSE;

	return nRet;

}




