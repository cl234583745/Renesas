/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDTRANSINTERFACE_H__
#define __MDTRANSINTERFACE_H__

#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#define	IsSupportPTPType(a,b)				(a->enSupportPTPType == b)

#define	PTPMDL_RCVTIMESTAMPTYPE_MASTER		1U
#define	PTPMDL_RCVTIMESTAMPTYPE_LOCAL		2U

#define	PTP_MDTR_TLV_ERROR	0xFFFF

#ifdef __cplusplus
extern "C" {
#endif
extern ULONG	ulMdtrMsgBuff[];

VOID ptp_recv(UCHAR uchPort, UCHAR* puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP* pstMTimeStamp);

VOID ptp_trns_an_port(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen);
VOID ptp_trns_an_port_manage(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen);

INT  MD_ptp_send(UCHAR* puchMsgPtr, USHORT usMsgLen, TIMESTAMP_CALLBK_INF* pstTimeStampCallbackInf);
VOID MD_ptp_TimeStamp_CallBack(INT nErrorCode, UCHAR uchPort, EXTENDEDTIMESTAMP* pstTimeStamp, VOID* pvLinkId);
BOOL ptp_Mdl_recv_Timestamp(UCHAR uchType, EXTENDEDTIMESTAMP* pstExtTimeStamp, USCALEDNS* pstLclTimeStamp, TIMESTAMP* pstTimeStamp);

VOID callSignalSM_1588(VOID);

VOID ptp_Mdl_recv_Sync_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Delay_Req_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP *pstTimeStamp);

VOID ptp_Mdl_recv_Delay_Resp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Pdelay_Req_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Pdelay_Resp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_FollowUp_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Pdly_Rsp_Fup_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Announce_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Manage_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Signal_1588(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);

VOID callSignalSM_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, PORTDATA* pstRcvPort);
VOID ptp_Mdl_recv_Sync_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, EXTENDEDTIMESTAMP	*pstTimeStamp);
VOID ptp_Mdl_recv_Pdelay_Req_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Pdelay_Resp_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_FollowUp_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Pdly_Rsp_Fup_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Announce_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Manage_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);
VOID ptp_Mdl_recv_Signal_AS(PORTDATA *pstPort, UCHAR *puchMsgPtr, USHORT usMsgLen, TIMESTAMP *pstTimeStamp);

BOOL ptp_Mdl_ntohMsgHeader(UCHAR* puchMsgPtr, PTPMSG_HEADER* pstPtpmsgHdr);

BOOL ptp_Mdl_ntohMsgSyncAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgFollowUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgFollowUpTLV(UCHAR* puchMsgPtr, PTPMSG_FOLLOWUP_TLV* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyReqAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyRespAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyRespFllwUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgSignalAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgIntvalTLV(UCHAR* puchMsgPtr, PTPMSG_INTERVAL_TLV* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgAnnounceAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg, USHORT usMsgLen);
BOOL ptp_Mdl_ntohMsgAnnounceTLV(UCHAR* puchMsgPtr, PTPMSG_ANNOUNCE_TLV* pstPtpmsg, USHORT usMsgLen);

BOOL ptp_Mdl_ntohMsgSync(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgFollowUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgPDlyRespFllwUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
BOOL ptp_Mdl_ntohMsgDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_ntohMsgManagement(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_ntohMsgAnnounce(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);


VOID ptp_Mdl_htonMsgHeader(UCHAR* puchMsgPtr, PTPMSG_HEADER* pstPtpmsgHdr);

VOID ptp_Mdl_htonMsgSyncAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgFollowUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgFollowUpTLV(UCHAR* puchMsgPtr, PTPMSG_FOLLOWUP_TLV* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyReqAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyRespAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyRespFllwUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgSignalAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgIntvalTLV(UCHAR* puchMsgPtr, PTPMSG_INTERVAL_TLV* pstPtpmsg);
VOID ptp_Mdl_htonMsgAnnounceAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgAnnounceTLV(UCHAR* puchMsgPtr, PTPMSG_ANNOUNCE_TLV* pstPtpmsg);
VOID ptp_Mdl_htonMsgGptpCapTLV(UCHAR* puchMsgPtr, PTPMSG_GPTPCAPABLE_TLV* pstPtpmsg);
VOID ptp_Mdl_htonMsgGptpCapIntTLV(UCHAR* puchMsgPtr, PTPMSG_GPTPCAPABLE_INT_TLV* pstPtpmsg);

VOID ptp_Mdl_htonMsgSync(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgFollowUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgPDlyRespFllwUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgManagement(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);
VOID ptp_Mdl_htonMsgAnnounce(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg);

BOOL checkBroadCastSingnal(PORTIDENTITY* pstPortIdentity);

BOOL	ptp_Mdl_HeaderCheck_8021AS(PTPMSG_HEADER* pstMsgHdr);
BOOL	ptp_Mdl_HeaderCheck_1588(PTPMSG_HEADER* pstMsgHdr);

#ifdef __cplusplus
}
#endif

#endif
