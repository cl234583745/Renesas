//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include <stddef.h>
#include "net.h"
#include "local.h"
#include "driver.h"
#include "support.h"

#if NTRACE > 0
void Npanic(char *text)
{
    while(*text)
        Nputchr(*text++);
    Nputchr('\n');
    while(1) ;
}
#endif


unsigned int clocks_per_sec      = 0;
int Nclocktick                   = 0;
static int ticktype              = 0;
static short coef                = 0;
static unsigned long basems      = 0;
static unsigned long baseticks   = 0;
static unsigned long basewrap    = 0;
static unsigned int wrapcount    = 0;
static unsigned long lastticks   = 0;
static unsigned short portnumber = 0;

#ifdef MTsupportRoutines
MTsupportRoutines()
#endif


int Ninitsupp()
{
    unsigned long ul1;

    ul1 = clocks_per_sec;

    if( clocks_per_sec == 0 )
    {
        return NE_PARAM;
    }
    else if (ul1 == 18)
    {
        ticktype = 0;
        coef = 55;
    }
    else if (ul1 == 1000)
    {
        ticktype = 1;
    }
    else if ((ul1 % 1000) == 0)
    {
        ticktype = 2;
        coef = ul1 / 1000;
    }
    else if (ul1 <= 0xffff)
    {
        ticktype = 3;
        coef = ul1;
    }
    else
    {
        return NE_PARAM;
    }
    basems = baseticks = basewrap = wrapcount = lastticks = 0;
    Nclocktick = 1000 / ul1;
    portnumber = (unsigned short)Nclock() | 1024;
    return 0;
}


unsigned long TimeMS( )
{
    unsigned long y0;
    unsigned long y1;
    unsigned long v1;
    unsigned long x0;
    unsigned long x1;
    unsigned long quot;
    unsigned long rem;

    y1 = Nclock( );
    if( y1 < lastticks )
    {
        if( lastticks - y1 > 1000 )
        {
            wrapcount++;
        }
    }
    lastticks = y1;
    y0 = wrapcount;
    if( y1 < baseticks )
    {
        y0--;
    }
    y1 -= baseticks;
    y0 -= basewrap;
    switch( ticktype )
    {
        case 0:
            v1 = y1 << 6;
            v1 -= y1 + (y1 << 3);
            break;
        case 1:
        default:
            v1 = y1;
            break;
        case 3:
            x1 = y1 << 3;
            x0 = (y0 << 3) + (y1 >> 29);
            y0 = (y0 << 10) | (y1 >> 22);
            rem = y1 << 10;
            if( rem < x1 )
                y0--;
            y1 = rem - x1;
            y0 -= x0;
            x0 = (x0 << 1) | (x1 >> 31);
            x1 <<= 1;
            if (y1 < x1)
                y0--;
            y1 -= x1;
            y0 -= x0;
        case 2:
            if( coef == 64 )
            {
                v1 = (y1 >> 6) | (y0 << 26);
            }
            else
            {
                rem = (y1 >> 16) | (y0 << 16);
                quot = rem / coef;
                rem = rem % coef;
                v1 = quot << 16;
                v1 += ((rem << 16) | (y1 & 0xffff)) / coef;
            }
            break;
    }
    return ( v1 + basems );
}

void SetTimeMS(unsigned long val)
{
    baseticks = Nclock();
    if (baseticks < lastticks)
        wrapcount++;
    basewrap = wrapcount;
    basems = val;
}

static MESS *Nfirstbuf;
MESS *Nbufbase;

MESS * NgetbufIR( void )
{
    register MESS *mp;

    if( (mp = Nfirstbuf) == 0 )
        return 0;
    Nfirstbuf = mp->next;
#if NTRACE > 0
    if( mp->id != bFREE )
        Npanic("NgetbufIR id");
#endif
    mp->id = bALLOC;
    mp->next = 0;
    mp->retry  = 0;
#ifdef  INET6
    mp->ipv6.flag6 = 0;
#endif
    return mp;
}

MESS * Ngetbuf( void )
{
    register MESS *mp;

    DISABLE();
    if( (mp = Nfirstbuf) == 0 )
    {
        goto lab3;
    }
    Nfirstbuf = mp->next;
#if NTRACE > 0
    if( mp->id != bFREE )
    {
        Npanic("Ngetbuf id");
    }
#endif
    mp->id = bALLOC;
    mp->next = 0;
    mp->retry = 0;
#ifdef  INET6
    mp->ipv6.flag6 = 0;
#endif
lab3:

    ENABLE();
    return mp;
}


void NrelbufIR( MESS * mp )
{
    if ( !mp ) {
#if NTRACE > 0
        Nprintf("NrelbufIR: NULL buffer is referenced !\n");
#endif
        return;
    }
    if ( mp->id == bFREE ) {
#if NTRACE > 0
        Nprintf("NrelbufIR: buffer is referenced twice !\n");
#endif
        return;
    }
#if NTRACE > 0
    if( (mp->id != bALLOC) && (mp->id != bRELEASE) )
    {
        Npanic("NrelbufIR id");
    }
#endif
    mp->id     = bFREE;
    mp->offset = boRELEASED;
    mp->next   = Nfirstbuf;
    Nfirstbuf  = mp;
}


void Nrelbuf( MESS * mp )
{
    if ( !mp ) {
#if NTRACE > 0
        Nprintf("Nrelbuf: NULL buffer is referenced !\n");
#endif
        return;
    }
    if ( mp->id == bFREE ) {
#if NTRACE > 0
        Nprintf("Nrelbuf: buffer is referenced twice !\n");
#endif
        return;
    }
#if NTRACE > 0
    if( (mp->id != bALLOC) && (mp->id != bRELEASE) )
    {
        Npanic("Nrelbuf id");
    }
#endif
    DISABLE( );
    mp->id     = bFREE;
    mp->offset = boRELEASED;
    mp->next   = Nfirstbuf;
    Nfirstbuf  = mp;
    ENABLE( );
}





#define EXTRAPADDING  ( USSBUFALIGN - 1 )
static unsigned char FAR bufpool[ EXTRAPADDING + ( MAXBUF + 4 + 2*EXTRAPADDING ) * (unsigned)NBUFFS ];

void Ninitbuf( int size, int count )
{
    int i1;
    int tSize;
    char *cp1;
    MESS *mp, *mp2;


    cp1 = (char *)(((long)&bufpool + USSBUFALIGN - 1 ) & ~(USSBUFALIGN-1));


    tSize = (int)( size + 4 + 2 * EXTRAPADDING ) & ~(USSBUFALIGN - 1);

    Nbufbase = Nfirstbuf = mp2 = mp = (MESS *)cp1;
    for( i1 = 0; i1 < count; i1++ )
    {
        mp->id = bFREE;
        mp2 = mp;
        mp = (MESS *)((char *)mp + tSize);
        mp2->next = mp;
    }
    mp2->next = 0;
}



void Nclearbuf( int size, int count, int netno )
{
int   i;
int   tSize;
char *cp;
MESS *mp;


    cp = (char *)(((long)&bufpool + USSBUFALIGN - 1 ) & ~( USSBUFALIGN - 1 ));


    tSize = (int)( size + 4 + 2 * EXTRAPADDING ) & ~( USSBUFALIGN - 1 );

    mp = (MESS *)cp;
    for( i = 0; i < count; i++ ){
        if ( mp->id != bFREE && mp->netno == netno ) {
            mp->id = bRELEASE;
            Nrelbuf(mp);
        }
        mp = (MESS *)((char *)mp + tSize);
    }
}



#if NTRACE > 0
void Ncntbuf()
{
    int i1;
    MESS *mp;
    int tSize;

    tSize = (int)( MAXBUF + 4 + 2 * EXTRAPADDING ) & ~(USSBUFALIGN - 1);

    for (i1=0,mp=Nbufbase; i1<NBUFFS; i1++,mp=(MESS*)((char *)mp+tSize))
        if (mp->id != bFREE)
            Npanic("cntbuf");
}
#endif


unsigned short Nportno( )
{
    int i;

retry:
    portnumber++;
    if( portnumber < 1024 )
    {
        portnumber = 1024;
    }
    BLOCKPREE();
    for (i = 0; i < NCONNS; i++) {
        if (connblo[i].blockstat != 0 && 
            connblo[i].myport == portnumber)
            break;
    }
    RESUMEPREE();
    if (i != NCONNS)
        goto retry;
    return portnumber;
}

int socket_cansend( int conno, unsigned int len )
{
    MESS * mp;
    struct CONNECT * conp;

    BLOCKPREE( );
    if( (mp = Nfirstbuf) != 0 )
    {
        mp = mp->next;
    }
    RESUMEPREE();
    if( mp != 0 )
    {
        conp = &connblo[ conno ];
        if( conp->protoc[0]->Eprotoc == 6 )
        {
            if( (conp->state == 1) && (conp->nwacks < conp->wackmax) &&
                (long)(conp->ackno + conp->window - conp->txseq - len) >= 0 )
            {
                return 1;
            }
        }
        else {
            return 1;
        }
    }
    return 0;
}

unsigned short htons(unsigned short val)
{
#ifdef LITTLE
    return ((val & 0xff) << 8) | ((unsigned short) val >> 8);
#else
    return val;
#endif
}

unsigned long htonl(unsigned long val)
{
#ifdef LITTLE
    return ((long) val << 24) | (((long) val & 0xff00) << 8) |
    (val >> 8) & 0xff00 | ((unsigned long) val >> 24);
#else
    return val;
#endif
}


unsigned long inet_addr(char *dotted)
{
    int i1, i2, i3, i4;
    Iid iid;

    Nsscanf(dotted, "%d.%d.%d.%d", &i1, &i2, &i3, &i4);
    iid.c[0] = i1;
    iid.c[1] = i2;
    iid.c[2] = i3;
    iid.c[3] = i4;
    return iid.l;
}


#if !defined( chksum_INASM )
unsigned short Nchksum( unsigned short * cp, int cnt )
{
    register unsigned short i1 = 0;
    register unsigned short i2;

    while( cnt-- )
    {
        i2  = *cp++;
        i1 += i2;
        if( i1 < i2 )
        {
            i1++;
        }
    }
    return i1;
}
#endif




MESS *reaDD(int conno)
{
    int i1;
    MESS *mess;
    register struct CONNECT *conp;

    conp = &connblo[ conno ];
    WAITFOR( conp->first || (conp->rxstat & S_EOF),
             SIG_RC(conno),
             conp->rxtout,
             i1);
    if( !conp->first )
    {
        return 0;
    }
    BLOCKPREE( );
    MESS_OUT( conp, mess );
    RESUMEPREE( );
    return mess;
}


