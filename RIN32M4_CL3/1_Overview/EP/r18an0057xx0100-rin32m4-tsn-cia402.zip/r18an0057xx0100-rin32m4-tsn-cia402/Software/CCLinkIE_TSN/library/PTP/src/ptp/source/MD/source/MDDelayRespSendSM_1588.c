/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayRespSendSM.h"
#include "MDDelayRespSendSM_1588.h"

#define D_FUNC	0

VOID (*const MDDelayRespSendSM_1588_Matrix[DMDDRPS_STATUS_MAX][DMDDRPS_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDDelayRespSendSM_01_1588 ,&MDDelayRespSendSM_NP_1588, &MDDelayRespSendSM_NP_1588},
	{&MDDelayRespSendSM_01_1588 ,&MDDelayRespSendSM_02_1588, &MDDelayRespSendSM_00_1588},
	{&MDDelayRespSendSM_01_1588 ,&MDDelayRespSendSM_02_1588, &MDDelayRespSendSM_00_1588}
};

VOID MDDelayRespSendSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDDRESPSNDSM_EV enEvt = MDDRPS_E_EVENT_MAX;
	MDDRESPSNDSM_ST enSts = MDDRPS_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDDRespSndEvent(usEvent, pstPort);
	enSts = GetMDDRespSndStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDDelayRespSendSM_1588   ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDDRPS_STATUS_MAX) && (enEvt != MDDRPS_E_EVENT_MAX))
	{
		(*MDDelayRespSendSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDDRespSndStatus(pstPort);
	printf ("<END  > [%02d]MDDelayRespSendSM_1588   ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDDelayRespSendSM_00_1588(PORTDATA* pstPort)
{
	MDDRESPSDSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDDelayRespSendSM_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDDRespSndSMGlobal(pstPort);

	MDDRespSnd_NotEnable_1588(pstGbl, pstPort);
	SetMDDRespSndStatus(MDDRPS_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDDelayRespSendSM_00_1588::-\n") );

	return;
}

VOID MDDelayRespSendSM_01_1588(PORTDATA* pstPort)
{
	MDDRESPSDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDRespSndSMGlobal(pstPort);

	MDDRespSnd_NotEnable_1588(pstGbl, pstPort);
	SetMDDRespSndStatus(MDDRPS_NOT_ENABLED, pstPort);
	return;
}

VOID MDDelayRespSendSM_02_1588(PORTDATA* pstPort)
{
	MDDRESPSDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDRespSndSMGlobal(pstPort);

	if (pstGbl->blRcvdMDDelayResp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82003105);
		MDDRespSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDRespSndStatus(MDDRPS_NOT_ENABLED, pstPort);
		return;
	}

#ifdef	PTP_USE_TRANS
	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		PTP_NOTICE_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82000012);
		MDDRespSnd_NotEnable_1588(pstGbl, pstPort);
		SetMDDRespSndStatus(MDDRPS_NOT_ENABLED, pstPort);
		return;
	}
	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
		MDDRespSnd_WtFrDRespTC_1588(pstGbl, pstPort);
		SetMDDRespSndStatus(MDDRPS_WAITING_SND_DRESP, pstPort);
		return;
	}
	else
	{
	}
#endif

	MDDRespSnd_WtFrDResp_1588(pstGbl, pstPort);
	SetMDDRespSndStatus(MDDRPS_WAITING_SND_DRESP, pstPort);
	return;
}


VOID MDDelayRespSendSM_NP_1588(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDDRespSnd_NotEnable_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayResp = FALSE;
	return TRUE;
}

BOOL MDDRespSnd_WtFrDResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayResp = FALSE;

	if (SetDelayResp_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxDelayResp_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL MDDRespSnd_WtFrDRespTC_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdMDDelayResp = FALSE;

	if (SetDelayRespTC_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxDelayResp_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}
#endif

BOOL SetDelayResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*		pstClockDT			= pstPort->pstClockData;
	DEFAULT_DS*		pstClkDefaultDS		= &pstClockDT->stDefaultDS;
	PORT_DS*		pstPortDS			= &pstPort->stPortDS;
	PORT_1588_DS*	pstPortDS_1588		= &pstPort->stPort_1588_DS;

	MDDELAYRESP*	pstDlyRespSnd		= &pstPort->stPort_GD.stMdDelayRespSnd;

	PTPMSG_DELAY_REQ_1588*	pstRcvMsg	= &pstPort->stPortMD_GD.stConDlyReq_1588;

	PTPMSG_DELAY_RESP_1588*	pstMsg		= NULL;
	pstMsg = &pstSmGbl->stTxDelayResp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_DELAY_RESP );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, pstPortDS->byVersionNumber );

	pstMsg->stHeader.uchDomainNumber	= pstClkDefaultDS->uchDomainNumber;
	pstMsg->stHeader.usMegLength		= 0;

	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstPortDS->stPortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstRcvMsg->stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_DLY_RESP;
	pstMsg->stHeader.chLogMsgInterVal	= pstPortDS_1588->chLogMinDelayReqInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stRcvTimestamp,
		&pstPort->stPort_GD.stDelayReqIngressTimestamp, sizeof(pstMsg->stRcvTimestamp));
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstDlyRespSnd->stRequestPortIdentity, sizeof(pstMsg->stReqPortIdentity));
	GetPTPMSG_DELAY_RESP_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

#ifdef	PTP_USE_TRANS
BOOL SetDelayRespTC_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{


	MDDELAYRESP*	pstDlyRespSnd		= &pstPort->stPort_GD.stMdDelayRespSnd;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;
	PTPMSG_DELAY_RESP_1588*	pstRcvMsg	= &pstClockGD->stDlyCorctionClock.stConDlyResp_1588;

	PTPMSG_DELAY_RESP_1588*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxDelayResp1588;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));
	tsn_Wrapper_MemCpy(pstMsg, pstRcvMsg, sizeof(*pstMsg));

	pstMsg->stHeader.usMegLength		= 0;


	pstMsg->stHeader.stCorrectionField.usFrcNsec = pstDlyRespSnd->stCorrectionField.usFrcNsec;
	pstMsg->stHeader.stCorrectionField.ulNsec_lsb = pstDlyRespSnd->stCorrectionField.ulNsec_lsb;
	pstMsg->stHeader.stCorrectionField.sNsec_msb = (SHORT)pstDlyRespSnd->stCorrectionField.ulNsec_2nd;

	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stRcvTimestamp,
		&pstDlyRespSnd->stReceiveTimestamp, sizeof(pstMsg->stRcvTimestamp));
	tsn_Wrapper_MemCpy(&pstMsg->stReqPortIdentity,
		&pstDlyRespSnd->stRequestPortIdentity, sizeof(pstMsg->stReqPortIdentity));
	GetPTPMSG_DELAY_RESP_1588(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}
#endif

BOOL TxDelayResp_1588(MDDRESPSDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxDelayResp1588,
		pstSmGbl->stTxDelayResp1588.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM_1588, PTP_LOGVE_82002408);
		return FALSE;
	}
	return TRUE;
}

#endif
