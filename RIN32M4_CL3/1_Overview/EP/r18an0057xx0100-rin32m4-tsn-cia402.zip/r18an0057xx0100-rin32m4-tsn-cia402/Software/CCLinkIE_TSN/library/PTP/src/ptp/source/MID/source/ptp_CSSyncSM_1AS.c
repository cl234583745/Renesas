/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"

#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_IEEE802_1

#include "ptp_UserAdjust.h"
#include "ptp_CMSOffset_1AS.h"
#include "ptp_SSSync_1AS.h"
#include "ptp_CSSync_1AS.h"
#include "ptp_CMSReceive.h"

#define D_FUNC	0
#define D_DBG	0


#include "ptp_PSSSend.h"
#include "ptp_tsn_Wrapper.h"


VOID	CSSync_1AS_00(CLOCKDATA*	pstClockData);
VOID	CSSync_1AS_01(CLOCKDATA*	pstClockData);
VOID	CSSync_1AS_02(CLOCKDATA*	pstClockData);
VOID	txSRTimeToCMSO(CLOCKDATA*	pstClockData);
VOID	offsetCurrentMasterTime(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData, USCALEDNS*	pstNewCurrentMasterTime);
DOUBLE computeCMFreqOffset_1AS(CLOCKDATA*	pstClockData);
ULONG	calcChangeEventLong(USCALEDNS* pstCMUSNs);
VOID	setSyncReceiptTime_1AS(CLOCKDATA*	pstClockData);
PORTDATA*	GetPstPortData_1AS(CLOCKDATA*	pstClockData, USHORT	usPortNum);


#ifdef	OFFSET_DEBUG

#define	OFFSET_LOG_TYPE1
#define	OFFSET_LOG_TYPE2
#define	OFFSET_LOG_TYPE3
#define	OFFSET_LOG_TYPE4
#define	OFFSET_LOG_TYPE5
#define	OFFSET_LOG_TYPE6
#define	OFFSET_LOG_TYPE7
#define	OFFSET_LOG_TYPE8

extern	USHORT	usCorrectiontLogCount;

#define	MAX_PTPOFSETLOG	64

typedef	struct	tagPTPOFSETLOG	{
	ULONG		ulType;
	TIMESTAMP	stPdlyRespEventIngressTimestamp;
	TIMESTAMP	stPdlyReqEventEgressTimestamp;
	TIMESTAMP	stPdlyRespMsgEgressTimestamp;
	TIMESTAMP	stPdlyReqMsgIngressTimestamp;
	DOUBLE		dbNeighborRateRatio;
	USCALEDNS	stNeighborPropDelay;
	USCALEDNS	stSyncReceiptCMTime;
	TIMESTAMP	stPreciseOriginTimestamp;
	SCALEDNS	stFollowUpCorrectionField;
	SCALEDNS	stSyncESubInSNs;
	DOUBLE		dbCMFrecRateCand;

	DOUBLE		dbRateRatio;

	UCHAR		uchDomainNumber;

	TIMESTAMP	stSyncEventEgressTimestamp;
	FRAC_NSEC64	stSyncCorrectionField;
	USHORT		usCorrectiontLogCount;
	USHORT		usPdelayReqSequenceId;
	USHORT		usPortNumber;
	TIMESTAMP	stSyncEventIngressTimestamp_Frun_TS;
	USHORT		usPtpDebugLogCount;
	UCHAR		uchStackCountSameClock;
	BOOL		blCumulativeRateRatioValid;
	CLOCKIDENTITY	stStackClockIdentity;
	BOOL		blClockRateValid;
}	PTPOFFSETLOG;

PTPOFFSETLOG	stPtpOfsetLog[MAX_PTPOFSETLOG];

USHORT	usPtpDebugLogCount = 0;
BOOL	blPtpOffsetUnder50Flag  = FALSE;
BOOL	blPtpOffsetUpper500Flag = FALSE;
TIMESTAMP		stSyncEventIngressTimestamp_Frun_TS = {0};
static	BOOL	blPtpSyncIngressBadFlag = FALSE;

#endif



VOID (*const pfnCSSyncMatrix[ST_CSS_MAX][EV_CSS_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CSSync_1AS_01, &CSSync_1AS_01, &CSSync_1AS_01, &CSSync_1AS_00},
	{&CSSync_1AS_01, &CSSync_1AS_02, &CSSync_1AS_02, &CSSync_1AS_00},
	{&CSSync_1AS_01, &CSSync_1AS_02, &CSSync_1AS_02, &CSSync_1AS_00}
};



VOID	clockSlaveSync_1AS(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CSS	enEvt = EV_CSS_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("CSSyncSM_1AS   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD.enStatusCSS);
}
#endif
		enEvt = GetCSSyncSM_1AS_Event(usEvent, pstClockData);

		blSts = IsCSSyncSM_1AS_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CSS_EVENT_MAX))
		{
			(*pfnCSSyncMatrix[pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD.enStatusCSS][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD.blRcvdPSSync	= FALSE;
		}

	}
}




CSSYNCSM_1AS_GD*	GetCSSyncSM_1AS_GD(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb = &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stCSSyncSM_1AS_GD);
	return pstCSSGlb;
}




EN_EV_CSS	GetCSSyncSM_1AS_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CSS	enEvt = EV_CSS_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CSS_BEGIN;
			break;

		case PTP_EV_FOR_CLKSLVSYN_RVPSYNC:
			enEvt = EV_CSS_FOR_CLKSLVSYN_RVPSYNC;
			break;

		case PTP_EV_FOR_CLKSLVSYN_RVLCLKTICK:
			enEvt = EV_CSS_FOR_CLKSLVSYN_RVLCLKTICK;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CSS_CLOSE;
			break;

		default:
			enEvt = EV_CSS_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsCSSyncSM_1AS_Status(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb	= GetCSSyncSM_1AS_GD(pstClockData);
	BOOL				blRet			= FALSE;


	if (pstCSSGlb->enStatusCSS < ST_CSS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	CSSync_1AS_00(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb = GetCSSyncSM_1AS_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CSSync_1AS_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstCSSGlb->blRcvdPSSync	= FALSE;
	pstCSSGlb->blRcvdLocalClockTick	= FALSE;
	pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
	pstCSSGlb->enStatusCSS	= ST_CSS_NONE;
	pstCSSGlb->enSelectedState0_Old	= ENUM_PORTSTATE_DISABLED;

	ptp_dbg_msg( D_FUNC, ("CSSync_1AS_00::-\n") );
}




VOID	CSSync_1AS_01(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb = GetCSSyncSM_1AS_GD(pstClockData);


	pstCSSGlb->blRcvdPSSync	= FALSE;
	pstCSSGlb->blRcvdLocalClockTick	= FALSE;
	pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
	pstCSSGlb->enStatusCSS	= ST_CSS_INITIALIZING;
	pstCSSGlb->enSelectedState0_Old	= ENUM_PORTSTATE_DISABLED;
}




VOID	CSSync_1AS_02(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstClockData);
PSSSENDSM_GD*		pstPSSSGlb;
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= pstClockData->pstPortData;
	DOUBLE				dbA_Ratio			=  DBCONST1_0;
	USCALEDNS			stB_USNs			= {0};
	EXTENDEDTIMESTAMP	stC_ETStamp			= {0};
	EXTENDEDTIMESTAMP	stD_ETStamp			= {0};
#ifndef	PTP_USE_ME_HW_ASSIST
	SCALEDNS			stE_SNs				= {0};
	USCALEDNS			stF_USNs			= {0};
#endif
	ULONG				ulChangeEvent		= 0;
#ifndef	PTP_USE_ME_HW_ASSIST
	USCALEDNS			stCurrentDetailTime	= {0};
#endif
	USCALEDNS			stCurrentMasterTime	= {0};
	LONG				lRet				= RET_ESTATE;

	PORTDATA*			pstPort_delay		= NULL;
	PORT_GD*			pstPort_GD 			= NULL;

	ptp_dbg_msg( D_FUNC, ("CSSync_1AS_02::+\n") );
	ptp_dbg_msg( D_DBG,  ("   --(Domain=%d)\n", pstClockData->stDefaultDS.uchDomainNumber));

#if D_DBG
	gdbGmRateRatio += 0.0001;
#endif

#ifndef	PTP_USE_ME_HW_ASSIST
#endif



#ifndef	PTP_USE_ME_HW_ASSIST
	ptp_GetCurrentMasterTime2(pstClockData,
								&stCurrentMasterTime,
								&stCurrentDetailTime);
#endif

	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

	if (pstCSSGlb->blRcvdPSSync)
	{
		if (pstRcvdPSSyncPtr->usLocalPortNumber == 0)
		{
#ifndef	PTP_USE_ME_HW_ASSIST
			setSyncReceiptTime_1AS(pstClockData);
			
#endif
			lRet = ptp_TimerSemLockWait();
			if (lRet != RET_ENOERR)
			{
				ptp_dbg_msg( D_FUNC, ("CSSync_1AS_02::-\n") );

				return;
			}
			pstClockData->stClock_GD.dbRateRatio = gdbGmRateRatio;

#ifndef	PTP_USE_ME_HW_ASSIST
#endif
			(VOID)ptp_TimerSemUnLock();

		}
		else
		{
			pstPortData = GetPstPortData_1AS(pstClockData,
											  pstRcvdPSSyncPtr->usLocalPortNumber);
			pstPort_delay = GetPdelayPort_1AS(pstClockData, pstRcvdPSSyncPtr->usLocalPortNumber);
			pstPort_GD = &(pstPort_delay->stPort_GD);

			if ((pstPort_GD->dbNeighborRateRatio > DBCONST_RATE_MIN) &&
				(pstPort_GD->dbNeighborRateRatio < DBCONST_RATE_MAX))
			{
				dbA_Ratio = pstRcvdPSSyncPtr->dbRateRatio / pstPort_GD->dbNeighborRateRatio;
			}
			else
			{
				dbA_Ratio = pstRcvdPSSyncPtr->dbRateRatio;
				PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000007);
			}
			(VOID)ptpMultUSNs_Doub(&(pstPort_GD->stNeighborPropDelay),
									dbA_Ratio,
									&stB_USNs);

			(VOID)ptpAddTS_SNs(&(pstRcvdPSSyncPtr->stPreciseOriginTimestamp),
								&(pstRcvdPSSyncPtr->stFollowUpCorrectionField),
								&stC_ETStamp);
			(VOID)ptpAddETS_USNs(&stC_ETStamp,
									&stB_USNs,
									&stD_ETStamp);
			(VOID)ptpAddETS_SNs(&stD_ETStamp,
									&(pstPort_GD->stDelayAsymmetry),
									&stC_ETStamp);
		
			pstClockData->stClock_GD.stSyncReceiptTime = stC_ETStamp;
		
#ifndef	PTP_USE_ME_HW_ASSIST

			SET_USCALEDNS(stB_USNs, 0, 0, 0, 0);
			if ((pstPort_GD->dbNeighborRateRatio > DBCONST_RATE_MIN) &&
				(pstPort_GD->dbNeighborRateRatio < DBCONST_RATE_MAX))
			{
				(VOID)ptpDivUSNs_Doub(&(pstPort_GD->stNeighborPropDelay),
										pstPort_GD->dbNeighborRateRatio,
										&stB_USNs);
			}
			else
			{
				stB_USNs = pstPort_GD->stNeighborPropDelay;
				PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000007);
			}
		
			(VOID)ptpDivSNs_Doub(&(pstPort_GD->stDelayAsymmetry),
									pstRcvdPSSyncPtr->dbRateRatio,
									&stE_SNs);

			(VOID)ptpAddUSNs_USNs(&(pstRcvdPSSyncPtr->stUpstreamTxTime),
									&stB_USNs,
									&stF_USNs);
			(VOID)ptpAddUSNs_SNs(&stF_USNs,
									&stE_SNs,
									&stB_USNs);
		
			pstClockData->stClock_GD.stSyncReceiptLocalTime = stB_USNs;
		}
		(VOID)ptpSubUSNs_USNs(&stCurrentMasterTime,
								&stCurrentDetailTime,
								&stE_SNs);
		(VOID)ptpAddUSNs_SNs(&(pstClockData->stClock_GD.stSyncReceiptLocalTime),
								&stE_SNs,
								&stF_USNs);
		pstClockData->stClock_GD.stSyncReceiptCMTime = stF_USNs;
#else
			ptpConvTS_USNs(&pstPortData->stMDSReceiveSM_GD.stSyncIngTimestamp, &pstClockData->stClock_GD.stSyncReceiptCMTime);
		}
#endif

		offsetCurrentMasterTime(pstClockData, pstPortData, &stCurrentMasterTime);

		pstClockData->stCurrent_1AS_DS.usGmTimebaseIndicator = pstRcvdPSSyncPtr->usGmTimeBaseIndicator;
		pstClockData->stCurrent_1AS_DS.stLastGmPhaseChange	= pstRcvdPSSyncPtr->stLastGmPhaseChange;
		pstClockData->stCurrent_1AS_DS.dbLastGmFreqChange  = pstRcvdPSSyncPtr->dbLastGmFreqChange;

#ifndef	PTP_USE_ME_HW_ASSIST
		if (!IS_SCALEDNS_0(pstRcvdPSSyncPtr->stLastGmPhaseChange))
		{
			ulChangeEvent = calcChangeEventLong(&(stCurrentMasterTime));
			pstClockData->stCurrent_1AS_DS.ulTimeOfLastGmPhaseChangeEvent	= ulChangeEvent;
		}
		if (pstRcvdPSSyncPtr->dbLastGmFreqChange != (DOUBLE)0.0)
		{
			ulChangeEvent = calcChangeEventLong(&(stCurrentMasterTime));
			pstClockData->stCurrent_1AS_DS.ulTimeOfLastGmFreqChangeEvent	= ulChangeEvent;
		}

#else
		if ((!IS_SCALEDNS_0(pstRcvdPSSyncPtr->stLastGmPhaseChange)) || (pstRcvdPSSyncPtr->dbLastGmFreqChange != (DOUBLE)0.0))
		{
			ptp_GetCurrentMasterTime((CLOCKDATA*)NULL, &stCurrentMasterTime);
			ulChangeEvent = calcChangeEventLong(&(stCurrentMasterTime));

			if (!IS_SCALEDNS_0(pstRcvdPSSyncPtr->stLastGmPhaseChange))
			{
				pstClockData->stCurrent_1AS_DS.ulTimeOfLastGmPhaseChangeEvent	= ulChangeEvent;
			}
			if (pstRcvdPSSyncPtr->dbLastGmFreqChange != (DOUBLE)0.0)
			{
				pstClockData->stCurrent_1AS_DS.ulTimeOfLastGmFreqChangeEvent	= ulChangeEvent;
			}
		}
#endif

		txSRTimeToCMSO(pstClockData);


		if (pstRcvdPSSyncPtr->usLocalPortNumber != 0)
		{	pstPortData = GetPstPortData_1AS(pstClockData, pstRcvdPSSyncPtr->usLocalPortNumber);
			pstPSSSGlb	= GetPSSSendSM_GD(pstPortData);
			if (pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime != NULL)
			{
				(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime));
				pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;

			}

			pstPSSSGlb->stSyncReceiptTimeoutTime = pstRcvdPSSyncPtr->stSyncReceiptTimeoutTime;
			pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = ptp_TimeOut_Req(
															PTP_EV_SYNCRECEIPTTIMEOUT,
															pstPortData,
															pstPSSSGlb->stSyncReceiptTimeoutTime,
															(CallBackFunc)&portSyncSyncSend);
		}


	}


	pstCSSGlb->blRcvdPSSync			= FALSE;
	pstCSSGlb->blRcvdLocalClockTick	= FALSE;
	pstCSSGlb->enStatusCSS	= ST_CSS_SEND_SYNC_INDICATION;
	pstCSSGlb->enSelectedState0_Old = pstClockData->stClock_GD.enSelectedState[0];

	ptp_dbg_msg( D_FUNC, ("CSSync_1AS_02::-\n") );

}




VOID	setSyncReceiptTime_1AS(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	EXTENDEDTIMESTAMP	stC_ETStamp			= {0};


	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

		(VOID)ptpAddTS_SNs(&(pstRcvdPSSyncPtr->stPreciseOriginTimestamp),
							&(pstRcvdPSSyncPtr->stFollowUpCorrectionField),
							&stC_ETStamp);
		pstClockData->stClock_GD.stSyncReceiptTime = stC_ETStamp;

		pstClockData->stClock_GD.stSyncReceiptLocalTime = pstRcvdPSSyncPtr->stUpstreamTxTime;

}




VOID	txSRTimeToCMSO(
	CLOCKDATA*	pstClockData)
{
#ifdef	PTP_USE_GM
	USHORT		usEvent = PTP_EV_BASE;


	pstClockData->stUn_CSM_GD.stCsm1as_GD.stCMSOffsetSM_1AS_GD.blRcvdSyncReceiptTime
		= TRUE;

	usEvent = PTP_EV_RCVDSYNCRECEIPTTIME;
	clockMasterSyncOffset_1AS(usEvent, pstClockData);
#endif
}




VOID	offsetCurrentMasterTime(
	CLOCKDATA*		pstClockData,
	PORTDATA*		pstPortData,
	USCALEDNS*		pstNewCurrentMasterTime)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstClockData);
	DOUBLE				dbCMFrecRateCand	= DBCONST1_0;
	SCALEDNS			stA_SNs				= {0};
	SCALEDNS			stB_SNs				= {0};
	TIME_INTERVAL		stD_TInt			= {0};
	BOOL				blRet				= FALSE;
	USCALEDNS			stNeighborPropDelay	= {0};
	ULONG				ulPropDelayNumber ={0};

	PORT_GD*			pstPort_GD			= &(pstPortData->stPort_GD);
	PORTDATA*			pstPort_Delay		= pstPortData;

	ptp_dbg_msg(D_FUNC, ("offsetCurrentMasterTime::+\n"));

	ptp_dbg_msg(D_DBG,
		("pstClockData->stClock_GD.dbRateRatio            = [%f]\n", pstClockData->stClock_GD.dbRateRatio));
	ptp_dbg_msg(D_DBG,
		("gdbGmRateRatio                                  = [%f]\n", gdbGmRateRatio) );	
	ptp_dbg_msg(D_DBG,
		("pstClockData->stClock_GD.stSyncReceiptTime      = [%04x:%08x:%08x:%04x]\n"
			, pstClockData->stClock_GD.stSyncReceiptTime.stSec.usSec_msb
			, pstClockData->stClock_GD.stSyncReceiptTime.stSec.ulSec_lsb
			, pstClockData->stClock_GD.stSyncReceiptTime.stNsec.ulNsec
			, pstClockData->stClock_GD.stSyncReceiptTime.stNsec.usFrcNsec)
	);
	ptp_dbg_msg(D_DBG,
		("pstRcvdPSSyncPtr->stPreciseOriginTimestamp      = [%04x:%08x:%08x]\n"
			, pstCSSGlb->pstRcvdPSSyncPtr->stPreciseOriginTimestamp.stSeconds.usSec_msb
			, pstCSSGlb->pstRcvdPSSyncPtr->stPreciseOriginTimestamp.stSeconds.ulSec_lsb
			, pstCSSGlb->pstRcvdPSSyncPtr->stPreciseOriginTimestamp.ulNanoseconds)
	);
	ptp_dbg_msg(D_DBG,
		("pstRcvdPSSyncPtr->stFollowUpCorrectionField     = [%04x:%08x:%08x:%04x]\n"
		, pstCSSGlb->pstRcvdPSSyncPtr->stFollowUpCorrectionField.sNsec_msb
		, pstCSSGlb->pstRcvdPSSyncPtr->stFollowUpCorrectionField.ulNsec_2nd
		, pstCSSGlb->pstRcvdPSSyncPtr->stFollowUpCorrectionField.ulNsec_lsb
		, pstCSSGlb->pstRcvdPSSyncPtr->stFollowUpCorrectionField.usFrcNsec)
	);
	ptp_dbg_msg(D_DBG,
		("pstClockData->stClock_GD.stSyncReceiptLocalTime = [%04x:%08x:%08x:%04x]\n"
			, pstClockData->stClock_GD.stSyncReceiptLocalTime.usNsec_msb
			, pstClockData->stClock_GD.stSyncReceiptLocalTime.ulNsec_2nd
			, pstClockData->stClock_GD.stSyncReceiptLocalTime.ulNsec_lsb
			, pstClockData->stClock_GD.stSyncReceiptLocalTime.usFrcNsec)
	);
	ptp_dbg_msg(D_DBG,
		("pstRcvdPSSyncPtr->stUpstreamTxTime             = [%04x:%08x:%08x:%04x]\n"
		, pstCSSGlb->pstRcvdPSSyncPtr->stUpstreamTxTime.usNsec_msb
		, pstCSSGlb->pstRcvdPSSyncPtr->stUpstreamTxTime.ulNsec_2nd
		, pstCSSGlb->pstRcvdPSSyncPtr->stUpstreamTxTime.ulNsec_lsb
		, pstCSSGlb->pstRcvdPSSyncPtr->stUpstreamTxTime.usFrcNsec)
	);
	ptp_dbg_msg(D_DBG,
		("gstCurrentMasterTime                           = [%04x:%08x:%08x:%04x]\n"
			, gstCurrentMasterTime.usNsec_msb, gstCurrentMasterTime.ulNsec_2nd, gstCurrentMasterTime.ulNsec_lsb, gstCurrentMasterTime.usFrcNsec));

	pstPort_Delay = GetPdelayPort_1AS(pstClockData, pstCSSGlb->pstRcvdPSSyncPtr->usLocalPortNumber);
	pstPort_GD = &(pstPort_Delay->stPort_GD);

#ifdef	PTP_USE_ME_HW_ASSIST
	if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
	{
#endif
	(VOID)ptpSubETS_USNs_SNs(&(pstClockData->stClock_GD.stSyncReceiptTime),
							 &(pstClockData->stClock_GD.stSyncReceiptCMTime),
							 &stA_SNs);

#ifdef	OFFSET_DEBUG
	if(blPtpOffsetUnder50Flag == FALSE)
	{
		if((stA_SNs.sNsec_msb == 0U) && (stA_SNs.ulNsec_2nd == 0U) && (stA_SNs.ulNsec_lsb < 50U))
		{
			blPtpOffsetUnder50Flag = TRUE;
		}
	}

#ifdef	OFFSET_LOG_TYPE2
	if (blPtpOffsetUnder50Flag)
	{

		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].ulType = 2;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stSyncReceiptCMTime 		= pstClockData->stClock_GD.stSyncReceiptCMTime;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stPreciseOriginTimestamp	= pstCSSGlb->pstRcvdPSSyncPtr->stPreciseOriginTimestamp;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stFollowUpCorrectionField = pstCSSGlb->pstRcvdPSSyncPtr->stFollowUpCorrectionField;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stSyncESubInSNs			= stA_SNs;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbNeighborRateRatio		= pstPort_Delay->stPort_GD.dbNeighborRateRatio;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbRateRatio				= pstClockData->stClock_GD.dbRateRatio;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stNeighborPropDelay		= pstPort_GD->stNeighborPropDelay;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchDomainNumber			= pstClockData->stDefaultDS.uchDomainNumber;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stSyncEventEgressTimestamp = pstPortData->stPort_GD.stSyncEventEgressTimestamp;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stSyncCorrectionField		= pstPortData->stPort_GD.stSyncCorrectionField;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usCorrectiontLogCount		= usCorrectiontLogCount;

		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stSyncEventIngressTimestamp_Frun_TS
																					= pstPortData->stPort_GD.stSyncEventIngressTimestamp_Frun;
		stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].usPtpDebugLogCount		= usPtpDebugLogCount;

	}
#endif
#endif

	pstCSSGlb->stCMPhaseOffsetCand = stA_SNs;
	(VOID)ptp2sComplementSNs(&pstCSSGlb->stCMPhaseOffsetCand,
								&stB_SNs);
	blRet = ptpConvSNs_TInt(&stB_SNs,
							&stD_TInt);
	if (blRet == FALSE)
	{
		SET_TIME_INTERVAL(stD_TInt, 0, 0, 0);
	}
	pstClockData->stCurrentDS.stOffsetFromMaster = stD_TInt;

#ifdef	PTP_USE_ME_HW_ASSIST
	}
	else
	{
		pstCSSGlb->stCMPhaseOffsetCand = stA_SNs;
	}
#endif
	pstCSSGlb->dbCMFreqOffsetCand	= pstClockData->stClock_GD.dbRateRatio - DBCONST1_0;

	if (!IS_EPSILON0_0((pstCSSGlb->dbCMFreqOffsetCand + DBCONST1_0)))
	{
		dbCMFrecRateCand = DBCONST1_0 / (pstCSSGlb->dbCMFreqOffsetCand + DBCONST1_0);
	}
#ifdef	OFFSET_DEBUG
	if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
	{
		if (blPtpOffsetUnder50Flag)
		{
			stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].dbCMFrecRateCand			= dbCMFrecRateCand;

			if((stA_SNs.sNsec_msb == 0U) && (stA_SNs.ulNsec_2nd == 0U) && (stA_SNs.ulNsec_lsb > 500U))
			{
				blPtpOffsetUpper500Flag = TRUE;
			}

			if ((stSyncEventIngressTimestamp_Frun_TS.stSeconds.usSec_msb != 0U) || 
					(stSyncEventIngressTimestamp_Frun_TS.stSeconds.ulSec_lsb != 0U) ||
						(stSyncEventIngressTimestamp_Frun_TS.ulNanoseconds != 0U))
			{
				if ( ptpCompTS_TS(&stSyncEventIngressTimestamp_Frun_TS, &pstPortData->stPort_GD.stSyncEventIngressTimestamp_Frun) == 1)
				{
					blPtpSyncIngressBadFlag = TRUE;
				}
			}
			stSyncEventIngressTimestamp_Frun_TS = pstPortData->stPort_GD.stSyncEventIngressTimestamp_Frun;
		}
	}
#endif

	if (pstClockData->stClock_GD.enSelectedState[(USHORT)PORT_NO_0] != SlavePort)
	{
		pstClockData->stClock_GD.stCurMasterLastPhaseChangeForGM = stB_SNs;
	}
#ifdef	PTP_USERADJUST_EXTEND


	if (!pstPortData)
	{
		ulPropDelayNumber = 0;
		tsn_Wrapper_MemSet((VOID *)&stNeighborPropDelay, 0x00, sizeof(USCALEDNS));
		pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
	}
	else
	{
		if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
		{
			ulPropDelayNumber = pstPort_GD->ulPropDelayNumber;
			stNeighborPropDelay = pstPort_GD->stNeighborPropDelay;

			pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.stSyncOriginTimeStamp = 
															pstPortData->stPort_GD.stSyncEventEgressTimestamp;
			pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.stSyncCorrectionField = 
															pstPortData->stPort_GD.stSyncCorrectionField;
			pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.blClockRateValid = FALSE;

			if (pstPort_GD->pstPdlyIntStackMan->uchStackCountSameClock >= pstPortData->pstClockData->stClock_GD.uchRateCalDatNum)
			{
				SSSYNCSM_1AS_GD* pstSSSGlb = GetSSSyncSM_1AS_GD(pstClockData);

				if (pstSSSGlb->blCumulativeRateRatioValid == TRUE)
				{
					pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.blClockRateValid = TRUE;
				}
			}

#ifdef	OFFSET_DEBUG
#ifdef	OFFSET_LOG_TYPE2
			if (blPtpOffsetUnder50Flag)
			{
				SSSYNCSM_1AS_GD* pstSSSGlb = GetSSSyncSM_1AS_GD(pstClockData);

				stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].uchStackCountSameClock = pstPort_GD->pstPdlyIntStackMan->uchStackCountSameClock;
				stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].blCumulativeRateRatioValid = pstSSSGlb->blCumulativeRateRatioValid;
				tsn_Wrapper_MemCpy(&stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].stStackClockIdentity,
					&pstPort_GD->pstPdlyIntStackMan->stStackClockIdentity, sizeof(CLOCKIDENTITY));
				stPtpOfsetLog[usPtpDebugLogCount%MAX_PTPOFSETLOG].blClockRateValid = pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.blClockRateValid;
				usPtpDebugLogCount++;
			}
#endif
#endif
															

		}
		else
		{
			ulPropDelayNumber = 0;
			tsn_Wrapper_MemSet((VOID *)&stNeighborPropDelay, 0x00, sizeof(USCALEDNS));
			pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
		}
	}
	pstClockData->stClock_GD.stDelayInfo.usSlavePortNumber = serchSlavePort(pstClockData);

#if (D_DBG==1)
	if (pstPortData)
	{ 
		ptp_dbg_msg(D_DBG,
			("stPort_GD.ulPropDelayNumber = [%d]\n"
				, pstPort_GD->ulPropDelayNumber)
		);
		ptp_dbg_msg(D_DBG,
			("pstPortData->stPort_GD.stNeighborPropDelay = [%04x:%08x:%08x:%04x]\n"
				, pstPort_GD->stNeighborPropDelay.usNsec_msb
				, pstPort_GD->stNeighborPropDelay.ulNsec_2nd
				, pstPort_GD->stNeighborPropDelay.ulNsec_lsb
				, pstPort_GD->stNeighborPropDelay.usFrcNsec)
		);
	}
#endif 


	ptp_useradjust2( pstClockData->stDefaultDS.uchDomainNumber,
					 &(pstCSSGlb->stCMPhaseOffsetCand),
					 &dbCMFrecRateCand,
					 gpstBestDomain->stDefaultDS.uchDomainNumber,
					 &pstClockData->stParentDS,
					 &pstClockData->stCurrentDS,
					 &(pstClockData->stClock_GD.stDelayInfo),
					 &stNeighborPropDelay,
					 ulPropDelayNumber );





#else


	ptp_useradjust( pstClockData->stDefaultDS.uchDomainNumber,
					&(pstCSSGlb->stCMPhaseOffsetCand),
					&dbCMFrecRateCand,
					gpstBestDomain->stDefaultDS.uchDomainNumber );


#endif

#ifndef	PTP_USE_ME_HW_ASSIST


	if ( !IS_EPSILON0_0(dbCMFrecRateCand) )
	{
		gdbCMFreqOffset	= (DBCONST1_0 / dbCMFrecRateCand) - DBCONST1_0;
		gdbRateRatio    = gdbCMFreqOffset + DBCONST1_0;
		gdbGmRateRatio  = gdbRateRatio;
	}

	ptp_dbg_msg(D_DBG,
		("(after useradjust)dbCMFrecRateCand                     = [%f]\n", dbCMFrecRateCand));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gdbRateRatio                         = [%f]\n", gdbRateRatio));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gdbGmRateRatio                       = [%f]\n", gdbGmRateRatio));

	if ( !IS_SCALEDNS_0(pstCSSGlb->stCMPhaseOffsetCand) )
	{
		EXTENDEDTIMESTAMP	stMasterTimeW;
		
		gstCMPhaseOffset = pstCSSGlb->stCMPhaseOffsetCand;
		
		ptp_SetCurrentMasterTime( pstClockData,
								  &gstCMPhaseOffset,
								  pstNewCurrentMasterTime );

		(VOID)ptpConvUSNs_ETS(pstNewCurrentMasterTime, &stMasterTimeW);

		ptp_SetMasterTime (pstClockData, &stMasterTimeW);

		ptp_dbg_msg(D_DBG, ("(after useradjust)gstCMPhaseOffset = [%04x:%08x:%08x:%04x]\n", gstCMPhaseOffset.sNsec_msb, gstCMPhaseOffset.ulNsec_2nd, gstCMPhaseOffset.ulNsec_lsb, gstCMPhaseOffset.usFrcNsec));

		SET_SCALEDNS( gstCMPhaseOffset, 0, 0, 0, 0 );
		gdbCMFreqOffset		= DBCONST0_0;
	}

#else
	SET_SCALEDNS( gstCMPhaseOffset, 0, 0, 0, 0 );
	gdbCMFreqOffset		= DBCONST0_0;

	ptp_dbg_msg(D_DBG, ("(after useradjust)gstCMPhaseOffset = [%04x:%08x:%08x:%04x]\n", gstCMPhaseOffset.sNsec_msb, gstCMPhaseOffset.ulNsec_2nd, gstCMPhaseOffset.ulNsec_lsb, gstCMPhaseOffset.usFrcNsec));

#endif

	ptp_dbg_msg(D_DBG,
		("(after useradjust)gstCurrentMasterTime = [%04x:%08x:%08x:%04x]\n", gstCurrentMasterTime.usNsec_msb, gstCurrentMasterTime.ulNsec_2nd, gstCurrentMasterTime.ulNsec_lsb, gstCurrentMasterTime.usFrcNsec));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gstMasterTime        = [%04x:%08x:%08x:%04x]\n", gstMasterTime.stSec.usSec_msb, gstMasterTime.stSec.ulSec_lsb, gstMasterTime.stNsec.ulNsec, gstMasterTime.stNsec.usFrcNsec));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gdbCMFreqOffset      = [%f]\n", gdbCMFreqOffset));

	ptp_dbg_msg(D_FUNC, ("offsetCurrentMasterTime::-\n"));
}

DOUBLE computeCMFreqOffset_1AS(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1AS_GD*	pstCSSGlb			= GetCSSyncSM_1AS_GD(pstClockData);
	SCALEDNS			stSubCMTimeFO		= {0};
	SCALEDNS			stSubSRTimeFO		= {0};
	SCALEDNS			stSubSRTimeFO_0		= {0};
	DOUBLE				dbClockCMFOffset	= DBCONST0_0;
	CHAR				chRet				= 0;
	USCALEDNS			stCurrentMasterTime	= {0};
	DOUBLE				dbClockCMRateRatio	= DBCONST1_0;
	BOOL				blRet				= FALSE;


	ptp_GetCurrentMasterTime(pstClockData, &stCurrentMasterTime);

	pstCSSGlb->stCurrentMasterTimeFOOld = pstCSSGlb->stCurrentMasterTimeFO;
	pstCSSGlb->stCMSyncReceiptTimeFOOld = pstCSSGlb->stCMSyncReceiptTimeFO;
	pstCSSGlb->stCurrentMasterTimeFO = stCurrentMasterTime;
	pstCSSGlb->stCMSyncReceiptTimeFO = pstClockData->stClock_GD.stSyncReceiptTime;

	if (pstCSSGlb->blCMFOffsetOld)
	{
		(VOID)ptpSubUSNs_USNs(&(pstCSSGlb->stCurrentMasterTimeFO),
								&(pstCSSGlb->stCurrentMasterTimeFOOld),
								&stSubCMTimeFO);

		(VOID)ptpSubETS_ETS(&(pstCSSGlb->stCMSyncReceiptTimeFO),
							 &(pstCSSGlb->stCMSyncReceiptTimeFOOld),
							 &stSubSRTimeFO);

		chRet = ptpCompSNs_SNs(&stSubCMTimeFO, &stSubSRTimeFO_0);

		if (chRet != COMP_EQUAL)
		{
			blRet = ptpDivSNs_SNs(&stSubCMTimeFO, &stSubSRTimeFO, &dbClockCMRateRatio);
			if (blRet == FALSE)
			{
				dbClockCMRateRatio = DBCONST1_0;
				PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000008);
			}
		}
		else
		{
			dbClockCMRateRatio = DBCONST1_0;
		}

		if (dbClockCMRateRatio >= DBCONST_RATE_MAX)
		{
			dbClockCMRateRatio = DBCONST1_0;
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000008);
		}
		else if (dbClockCMRateRatio <= DBCONST_RATE_MIN)
		{
			dbClockCMRateRatio = DBCONST1_0;
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1AS, PTP_LOGVE_84000008);
		}
		else
		{
		}

		dbClockCMFOffset = dbClockCMRateRatio - DBCONST1_0;

	}

	pstCSSGlb->blCMFOffsetOld = TRUE;

	return dbClockCMFOffset;

}




ULONG	calcChangeEventLong(
	USCALEDNS*		pstCMUSNs)
{
	ULONG	ulChangeEvent;
	EXTENDEDTIMESTAMP	stCMETS ={0};
	ULONG	ulLSec	= 0;
	ULONG	ulNsec	= 0;


	(VOID)ptpConvUSNs_ETS(pstCMUSNs, &stCMETS);
	ulNsec = stCMETS.stNsec.ulNsec;
	ulLSec = stCMETS.stSec.ulSec_lsb;

	ulChangeEvent =  (ulLSec * CONST10_2) + (ulNsec / CONST10_7);

	return ulChangeEvent;
}




PORTDATA*	GetPstPortData_1AS(
	CLOCKDATA*	pstClockData,
	USHORT		usPortNum)
{
	PORTDATA*	pstPortData	= pstClockData->pstPortData;


	while (pstPortData != NULL)
	{
		if (pstPortData->stPort_GD.usThisPort == usPortNum)
		{
			break;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	return	pstPortData;
}




#endif

USHORT	serchSlavePort(
	CLOCKDATA*	pstClockData
)
{
	PORTDATA*	pstPortData = pstClockData->pstPortData;
	USHORT		usSlavePortNumber = 0;
			
	if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
	{
		while (pstPortData != NULL)
		{
			if (pstClockData->stClock_GD.enSelectedState[pstPortData->stPortDS.stPortIdentity.usPortNumber] == ENUM_PORTSTATE_SLAVE)
			{
				usSlavePortNumber = pstPortData->stPortDS.stPortIdentity.usPortNumber;
				break;
			}
			pstPortData = pstPortData->pstNextPortDataPtr;
		}
	}
	return	usSlavePortNumber;
}

PORTDATA* GetPdelayPort_1AS(
	CLOCKDATA*	pstClockData,
	USHORT		usPortNum
)
{
	PORTDATA*	pstPortData_Ret	= pstClockData->pstPortData;
	PORTDATA*	pstPortData	= pstClockData->pstPortData;

	while (pstPortData != NULL)
	{
		if (pstPortData->stPort_GD.usThisPort == usPortNum)
		{
			pstPortData_Ret = gpstCmldsPtr->stCmldsPortManage[pstPortData->stPort_GD.lCmldsPortNumber].pstExecuteCmldsPortPtr;
			break;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}
	return pstPortData_Ret;
}
