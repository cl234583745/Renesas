//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <stdio.h>

#include "net.h"
#include "local.h"
#include "support.h"
#include "icmp.h"
#include "socket.h"

#if (MT != 0)
#define DEBUG_LEVEL  3
#else
#define DEBUG_LEVEL  5
#endif

#define DEBUG_FUNC


#if (MT != 0)

#define SYSMEM_SZ   1024*1024
#define MEMPL_SZ    1024*1024
#define MESBF_SZ    1024*1024

#define TASK_NUM_MAX  20

#pragma section _SYSMEM_
unsigned int sysmem[SYSMEM_SZ / sizeof(int)];
unsigned int mplmem[MEMPL_SZ / sizeof(int)];
unsigned int mbfmem[MESBF_SZ / sizeof(int)];
#pragma section

T_ITRN memory;

extern ID TaskId[];

static void print_tskst(UINT stat);
static void print_tskname(void *func);
static void printtask(void);

TASKFUNCTION shell(void);
TASKFUNCTION init_task(void);
ER RUN_CMDTASK(FP task, PRI prior, int argc, char *argv[]);
TASKFUNCTION kill(int argc, char *argv[]);
TASKFUNCTION show(int argc, char *argv[]);

ID nettask_id[NNETS];

static ID shell_task_id = 0;

int input_per_task[NUMTSK];

#else

typedef unsigned short  ID;
typedef unsigned short  PRI;

#endif

static void exec_cmd(int commnad, char *tmp_cmd, char tmp_argc, char **tmp_argv);

#define READ_WAIT  30000
#define ACC_WAIT   10000

#define BUFSIZE   3072

#if (MT == 0)
static char testbuf[BUFSIZE];
#endif

#define IPD_OFFSET  (MESSH_SZ + LHDRSZ +Ihdr_SZ)

#if (MAXBUF < BUFSIZE)
#define DPI_SEND_SIZE  MAXBUF
#else
#define DPI_SEND_SIZE  BUFSIZE
#endif

#define RWSIZE    1600
static char msgbuf1[RWSIZE+1];
static char msgbuf2[RWSIZE+1];
struct iovec iovectbl[] = {
    {msgbuf1, RWSIZE},
    {msgbuf2, RWSIZE}
};

#define CMDL_SIZE 80
static char cmdline[CMDL_SIZE];
static char cmdline2[CMDL_SIZE];

#define STOCK_NUM 30
static char cmdstock[STOCK_NUM][CMDL_SIZE];

#define ARG_MAX 16

#define IPOPTLEN 36

int boffset;
int senddata = 0;
unsigned long dhcpleasetime = 360;

int natport = 0;

extern struct CONNECT connblo[];
extern struct NETCONF netconf[];
extern struct NET nets[];
extern MESS *Nbufbase;

#define N_COMM        "h"
#define N_GETTIME     "gtime"
#define N_SETTIME     "stime"
#define N_RARPGET     "rarpget"
#define N_EGP         "egp"
#define N_ICMP_SEND   "icmpsend"
#define N_ICMP_RPLY   "icmpreply"
#define N_PING        "ping"
#define N_SOCK_IP_OPT "sockipo"
#define N_SOCK_FUNC   "sockf"
#define N_SOCK_RW     "sockrw"
#define N_TCP_SOCK    "socktcp"
#define N_UDP_SOCK    "sockudp"
#define N_TCP_DPI     "dtcp"
#define N_UDP_DPI     "dudp"
#define N_RST_SOCK    "rsts"
#define N_RST_DPI     "rstd"
#define N_BENCH_SOCK  "blast"
#define N_TNSERV      "tnserv"
#if (DHCP >= 1)
#define N_DHCPGET     "dhcpget"
#define N_DHCPREL     "dhcprel"
#endif

#define N_SHOW_NET    "shownet"
#define N_SHOW_NCON   "shownconf"
#define N_SHOW_CONN   "showconn"
#define N_SHOW_MESS   "showmess"
#if (MT != 0)
#define N_TASK_SHOW   "showtask"
#define N_TASK_KILL   "killtask"
#define N_INPUT       "input"
#endif
#ifdef DEBUG_FUNC
#define N_NAT_PORT    "natport"
#endif
#define N_MEM_EDIT    "me"
#define N_MEM_READ    "mr"
#define N_MEM_DUMP    "md"
#define N_PINIT       "pinit"
#define N_NINIT       "ninit"
#define N_PTERM       "pterm"
#define N_NTERM       "nterm"
#define N_BLD_RT      "bldrt"
#define N_FTPTEST     "ftptest"
#ifdef USSW_DIRECTED_BROADCAST
#define N_GET_CHG_IP  "getchgip"
#define N_SET_CHG_IP  "setchgip"
#define N_SET_IP      "setip"
#define N_SET_EADDR   "seteaddr"
#define N_SET_IMASK   "setimask"
#define N_SET_GATEWAY "setgateway"
#define N_START_DET_IP "startdetect"
#define N_STOP_DET_IP "stopdetect"
#define N_GET_DETSTAT "detectstat"
#endif
#define N_STOP        "stop"
#define N_END         "end"

#define TCP_SEND  1
#define TCP_RECV  2
#define UDP_SEND  3
#define UDP_RECV  4

#define CC_NEXT   'n'
#define CC_END    'e'
#define CC_READ   'r'
#define CC_WRITE  'w'
#define CC_SET    's'
#define CC_GET    'g'
#define CC_DEL    'd'
#define CC_RST    'a'
#define CC_LOOP   'l'

#define SF_GET_HOST_NAME        0
#define SF_GET_HOST_ADDR        1
#define SF_GET_SOCK_PEER_NAME   2
#define SF_SET_OPT_IP           3
#define SF_SET_OPT_TCP          4
#define SF_SET_OPT_SOCK_REUSE   5
#define SF_SET_OPT_SOCK_BINDDEV 6
#define SF_SET_OPT_SOCK_KEEPA   7
#define SF_SET_OPT_SOCK_OOBINL  8
#define SF_SET_OPT_SOCK_LINGER  9
#define SF_SET_OPT_SOCK_DONTRT  10
#define SF_SET_OPT_SOCK_BCAST   11
#define SF_FCTL_NDELAY          12
#define SF_IOCTL_ALL            13
#define SF_SELECTSOCK           14
#define SF_RECV_PEEK_OOB        15
#define SF_SEND_OOB_DONTROUTT   16
#define SF_RECVFROM_SIZE        17

#define SRW_NONE          0
#define SRW_OOB           1
#define SRW_PEEK          2
#define SRW_DNTRT         4
#define SRW_SYNACK_RST    5
#define SRW_SYNACK_DSCRD  6
#define SRW_LISTEN_RST    7
#define SRW_ESTABL_RST    8
#define SRW_ACCEPT        9
#define SRW_IPOPT         10

enum  command {
    C_NOCOMM,
    C_COMM,
    C_GETTIME,
    C_SETTIME,
    C_RARPGET,
    C_EGP,
    C_PING,
    C_ICMP_SEND,
    C_ICMP_RPLY,
    C_SOCK_IP_OPT,
    C_SOCK_FUNC,
    C_SOCK_RW,
    C_TCP_SOCK,
    C_UDP_SOCK,
    C_TCP_DPI,
    C_UDP_DPI,
    C_RST_SOCK,
    C_RST_DPI,
    C_BENCH_SOCK,
#ifdef INCLUDE_TELNET
    C_TNSERV,
#endif
#if (DHCP >= 1)
    C_DHCPGET,
    C_DHCPREL,
#endif
    C_SHOW_NET,
    C_SHOW_NCON,
    C_SHOW_CONN,
    C_SHOW_MESS,
#if (MT != 0)
    C_TASK_KILL,
    C_TASK_SHOW,
    C_INPUT,
#endif
#ifdef DEBUG_FUNC
    C_NAT_PORT,
#endif
    C_MEM_EDIT,
    C_MEM_READ,
    C_MEM_DUMP,
    C_PINIT,
    C_NINIT,
    C_PTERM,
    C_NTERM,
    C_BLD_RT,
    C_FTPTEST,
#ifdef USSW_DIRECTED_BROADCAST
    C_GET_CHG_IP,
    C_SET_CHG_IP,
    C_SET_IP,
    C_SET_EADDR,
    C_SET_IMASK,
    C_SET_GATEWAY,
    C_START_DET_IP,
    C_STOP_DET_IP,
    C_GET_DETSTAT,
#endif
    C_STOP,
    C_END
};

struct cmd_arry {
    char *cmdname;
    char cmdnum;
};

struct cmd_arry cmdarray[] = {
    {N_COMM        ,C_COMM       },
    {N_GETTIME     ,C_GETTIME    },
    {N_SETTIME     ,C_SETTIME    },
    {N_RARPGET     ,C_RARPGET    },
    {N_EGP         ,C_EGP        },
    {N_ICMP_SEND   ,C_ICMP_SEND  },
    {N_ICMP_RPLY   ,C_ICMP_RPLY  },
    {N_PING        ,C_PING       },
    {N_SOCK_IP_OPT ,C_SOCK_IP_OPT},
    {N_SOCK_FUNC   ,C_SOCK_FUNC  },
    {N_SOCK_RW     ,C_SOCK_RW    },
    {N_TCP_SOCK    ,C_TCP_SOCK   },
    {N_UDP_SOCK    ,C_UDP_SOCK   },
    {N_TCP_DPI     ,C_TCP_DPI    },
    {N_UDP_DPI     ,C_UDP_DPI    },
    {N_RST_SOCK    ,C_RST_SOCK   },
    {N_RST_DPI     ,C_RST_DPI    },
    {N_BENCH_SOCK  ,C_BENCH_SOCK },
#ifdef INCLUDE_TELNET
    {N_TNSERV      ,C_TNSERV     },
#endif
#if (DHCP >= 1)
    {N_DHCPGET     ,C_DHCPGET    },
    {N_DHCPREL     ,C_DHCPREL    },
#endif
    {N_SHOW_NET    ,C_SHOW_NET   },
    {N_SHOW_NCON   ,C_SHOW_NCON  },
    {N_SHOW_CONN   ,C_SHOW_CONN  },
    {N_SHOW_MESS   ,C_SHOW_MESS  },
#if (MT != 0)
    {N_TASK_KILL   ,C_TASK_KILL  },
    {N_TASK_SHOW   ,C_TASK_SHOW  },
    {N_INPUT       ,C_INPUT      },
#endif
#ifdef DEBUG_FUNC
    {N_NAT_PORT    ,C_NAT_PORT   },
#endif
    {N_MEM_EDIT    ,C_MEM_EDIT   },
    {N_MEM_READ    ,C_MEM_READ   },
    {N_MEM_DUMP    ,C_MEM_DUMP   },
    {N_PINIT       ,C_PINIT      },
    {N_NINIT       ,C_NINIT      },
    {N_PTERM       ,C_PTERM      },
    {N_NTERM       ,C_NTERM      },
    {N_BLD_RT      ,C_BLD_RT     },
    {N_FTPTEST     ,C_FTPTEST    },
#ifdef USSW_DIRECTED_BROADCAST
    {N_GET_CHG_IP  ,C_GET_CHG_IP },
    {N_SET_CHG_IP  ,C_SET_CHG_IP },
    {N_SET_IP      ,C_SET_IP     },
    {N_SET_EADDR   ,C_SET_EADDR  },
    {N_SET_IMASK   ,C_SET_IMASK  },
    {N_SET_GATEWAY ,C_SET_GATEWAY},
    {N_START_DET_IP,C_START_DET_IP},
    {N_STOP_DET_IP ,C_STOP_DET_IP},
    {N_GET_DETSTAT ,C_GET_DETSTAT},
#endif
    {N_STOP        ,C_STOP       },
    {N_END         ,C_END        }
};

struct mess_id {
    unsigned short id;
    char *idname;
};

struct mess_id mess_id_tab[] = {
    {bFUTURE , "bFUTURE "},
    {bFREE   , "bFREE   "},
    {bALLOC  , "bALLOC  "},
    {bWACK   , "bWACK   "},
    {bSACK   , "bSACK   "},
    {bRELEASE, "bRELEASE"}
};

struct mess_ofs {
    char offset;
    char *ofsname;
};

struct mess_ofs mess_ofs_tab[] = {
    {boRELEASED , "boRELEASED"},
    {boTXDONE   , "boTXDONE  "}
};

struct port_type {
    unsigned short portno;
    char *protocol;
};

struct port_type port_tab[] = {
    {20  , "ftp-data "},
    {21  , "ftp      "},
    {22  , "ssh      "},
    {23  , "telnet   "},
    {25  , "smtp     "},
    {53  , "dns      "},
    {67  , "boot-serv"},
    {68  , "boot-clnt"},
    {69  , "tftp     "},
    {80  , "http     "},
    {110 , "pop3     "},
    {161 , "snmp     "},
    {162 , "snmp-trap"}
};

struct stat_type {
    unsigned short stattno;
    char *statname;
};

struct stat_type stat_tab[] = {
    { 0, " -          "},
    { 1, "ESTABLISHED "},
    { 2, "FINWAIT_1   "},
    { 3, "FINWAIT_2   "},
    { 4, "CLOSED_WAIT "},
    { 5, "TIMEWAIT    "},
    { 6, "LAST_ACK    "},
    { 7, "CLOSED      "},
    { 8, "SYN_SENT    "},
    { 9, "SYN_RECEIVED"},
    {10, "CLOSING     "},
    {16, "LISTEN      "},
    {17, "ACTCONN     "}
};

struct stat_type tx_stat_tab[] = {
    {S_INSEQ  , "S_INSEQ"  },
    {S_PROBE  , "S_PROBE"  },
    {S_SACK   , "S_SACK"   },
    {S_PASSIVE, "S_PASSIVE"},
    {S_NOWA   , "S_NOWA"   },
    {S_STRM   , "S_STRM"   },
    {S_URG    , "S_URG"    },
    {S_NOCON  , "S_NOCON"  },
    {S_PSH    , "S_PSH"    },
    {S_KEEPA  , "S_KEEPA"  },
    {S_MON    , "S_MON"    },
    {S_FIN    , "S_FIN"    }
};

struct stat_type rx_stat_tab[] = {
    {S_RST  , "S_RST"  },
    {S_FATAL, "S_FATAL"},
    {S_QUENC, "S_QUENC"},
    {S_TIMEX, "S_TIMEX"},
    {S_UNREA, "S_UNREA"},
    {S_NOACK, "S_NOACK"},
    {S_EOF  , "S_EOF"  }
};

struct stat_type nc_stat_tab[] = {
    {NATLOCAL  , "NATLOCAL"  },
    {PROXYARP  , "PROXYARP"  },
    {DNSVER    , "DNSVER"    },
    {DIAL      , "DIAL"      },
    {NODE      , "NODE"      },
    {LOCALHOST , "LOCALHOST" },
    {ROUTER    , "ROUTER"    },
    {TIMESERVER, "TIMESERVER"},
    {BOOTSERVER, "BOOTSERVER"},
    {NOTUSED   , "NOTUSED"   }
};

void comm_icmp_send(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: ip[*] type[*] code[*] prm1[*] prm2[*]\n", N_ICMP_SEND);
    Nprintf("     [ECHO REQUEST ]: type=8,  code=0, prm1=size,  prm2=count\n");
    Nprintf("     [TIME QUERY   ]: type=13, code=0, prm1=[*], prm2=0\n");
    Nprintf("        <prm1>\n");
    Nprintf("           0: socket read\n");
    Nprintf("           1: stack process\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_icmp_reply(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: protcol[t/u] src_prt[*] type[*] code[*] prm1[*]\n", N_ICMP_RPLY);
    Nprintf("     [UNREACAHBLE  ]: type=3,  code=[0-5], prm1=0\n");
    Nprintf("     [SOURCE QUENCH]: type=4,  code=0,     prm1=0\n");
    Nprintf("     [REDIRECT     ]: type=5,  code=[0-3], prm1=ip[*]\n");
    Nprintf("     [PARAMETER    ]: type=12, code=0,     prm1=0\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_tcp_serv(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[s] ip[*] src_prt[*] dst_prt[0]\n", N_TCP_SOCK);
    Nprintf("             patarn[*] prm1[*] prm2[*] prm3[*] prm4[*] prm5[*] prm6[*]\n");
    Nprintf("    <patarn>\n");
    Nprintf("       0: bind -> listen -> accept -> select -> recv -> select -> send\n");
    Nprintf("       1: bind -> listen -> accept -> select -> recv -----------> send\n");
    Nprintf("       2: bind -> listen -> accept -----------> recv -> select -> send\n");
    Nprintf("       3: bind -> listen -> accept -----------> recv -----------> send\n");
    Nprintf("       4: bind -> listen -----------> select -> recv -> select -> send\n");
    Nprintf("       5: bind -> listen -----------> select -> recv -----------> send\n");
    Nprintf("       6: bind -> listen ---------------------> recv -> select -> send\n");
    Nprintf("       7: bind -> listen ---------------------> recv -----------> send\n");
    Nprintf("    <prm1>\n");
    Nprintf("       0: read\n");
    Nprintf("       1: read & send\n");
    Nprintf("       2: continuous read\n");
    Nprintf("       3: continuous read & send\n");
    Nprintf("       4: read at each input\n");
    Nprintf("    <prm2>\n");
    Nprintf("       0: patarn[*]\n");
    Nprintf("       1: patarn[* -> 7]\n");
    Nprintf("    <prm3>\n");
    Nprintf("       *: loop count of [socket - closesocket]\n");
    Nprintf("    <prm4>\n");
    Nprintf("       *: loop count of [accept]\n");
    Nprintf("    <prm5>\n");
    Nprintf("       *: timeout of read (second)\n");
    Nprintf("    <prm6>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_tcp_clnt(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[c] ip[*] src_prt[*] dst_prt[*]\n", N_TCP_SOCK);
    Nprintf("             patarn[*] prm1[*] prm2[*] prm3[*] prm4[*] prm5[*] prm6[*]\n");
    Nprintf("    <patarn>\n");
    Nprintf("       0: bind -> connect -> select -> send -> select -> recv\n");
    Nprintf("       1: bind -> connect -> select -> send -----------> recv\n");
    Nprintf("       2: bind -> connect -> --------> send -> select -> recv\n");
    Nprintf("       3: bind -> connect -> --------> send -----------> recv\n");
    Nprintf("    <prm1>\n");
    Nprintf("       0: send\n");
    Nprintf("       1: send & read\n");
    Nprintf("       2: continuous send\n");
    Nprintf("       3: continuous send & read\n");
    Nprintf("    <prm2>\n");
    Nprintf("       0: patarn[*]\n");
    Nprintf("       1: patarn[* -> 3]\n");
    Nprintf("    <prm3>\n");
    Nprintf("       *: loop count of [socket - closesocket]\n");
    Nprintf("    <prm4>\n");
    Nprintf("       *: loop count of [send - recv]\n");
    Nprintf("    <prm5>\n");
    Nprintf("       *: send size < [%d]\n", BUFSIZE - IPD_OFFSET);
    Nprintf("    <prm6>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_udp_serv(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[s] ip[*] src_prt[*] dst_prt[*]\n", N_UDP_SOCK);
    Nprintf("             patarn[*] prm1[*] prm2[*] prm3[*] prm4[*] prm5[*] prm6[*]\n");
    Nprintf("    <patarn>\n");
    Nprintf("        0: bind -> listen -> select -> recvfrom -> sendto  \n");
    Nprintf("        1: bind -> listen -> select -> recvfrom -> sendmsg \n");
    Nprintf("        2: bind -> listen -> select -> recvmsg  -> sendto  \n");
    Nprintf("        3: bind -> listen -> select -> recvmsg  -> sendmsg \n");
    Nprintf("        4: bind -> listen -----------> recvfrom -> sendto  \n");
    Nprintf("        5: bind -> listen -----------> recvfrom -> sendmsg \n");
    Nprintf("        6: bind -> listen -----------> recvmsg  -> sendto  \n");
    Nprintf("        7: bind -> listen -----------> recvmsg  -> sendmsg \n");
    Nprintf("        8: bind -----------> select -> recvfrom -> sendto  \n");
    Nprintf("        9: bind -----------> select -> recvfrom -> sendmsg \n");
    Nprintf("       10: bind -----------> select -> recvmsg  -> sendto  \n");
    Nprintf("       11: bind -----------> select -> recvmsg  -> sendmsg \n");
    Nprintf("       12: bind ---------------------> recvfrom -> sendto  \n");
    Nprintf("       13: bind ---------------------> recvfrom -> sendmsg \n");
    Nprintf("       14: bind ---------------------> recvmsg  -> sendto  \n");
    Nprintf("       15: bind ---------------------> recvmsg  -> sendmsg \n");
    Nprintf("    <prm1>\n");
    Nprintf("       0: read\n");
    Nprintf("       1: read & send\n");
    Nprintf("       2: continuous read\n");
    Nprintf("       3: continuous read & send\n");
#ifdef IPOPTIONS
    Nprintf("       4: continuous read & send (check IP optoins)\n");
#endif
    Nprintf("    <prm2>\n");
    Nprintf("       0: patarn[*]\n");
    Nprintf("       1: patarn[* -> 15]\n");
    Nprintf("    <prm3>\n");
    Nprintf("       *: loop count of [socket - closesocket]\n");
    Nprintf("    <prm4>\n");
    Nprintf("       *: loop count of [recvform - sendto]\n");
    Nprintf("    <prm5>\n");
    Nprintf("       *: timeout of read (second)\n");
    Nprintf("    <prm6>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_udp_clnt(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[c] ip[*] src_prt[*] dst_prt[*]\n", N_UDP_SOCK);
    Nprintf("             patarn[*] prm1[*] prm2[*] prm3[*] prm4[*] prm5[*] prm6[*]\n");
    Nprintf("    <patarn>\n");
    Nprintf("        0: bind -> listen -> sendto  -> select -> recvfrom\n");
    Nprintf("        1: bind -> listen -> sendto  -> select -> recvmsg \n");
    Nprintf("        2: bind -> listen -> sendto  -----------> recvfrom\n");
    Nprintf("        3: bind -> listen -> sendto  -----------> recvmsg \n");
    Nprintf("        4: bind -> listen -> sendmsg -> select -> recvfrom\n");
    Nprintf("        5: bind -> listen -> sendmsg -> select -> recvmsg \n");
    Nprintf("        6: bind -> listen -> sendmsg -----------> recvfrom\n");
    Nprintf("        7: bind -> listen -> sendmsg -----------> recvmsg \n");
    Nprintf("        8: bind -----------> sendto  -> select -> recvfrom\n");
    Nprintf("        9: bind -----------> sendto  -> select -> recvmsg \n");
    Nprintf("       10: bind -----------> sendto  -----------> recvfrom\n");
    Nprintf("       11: bind -----------> sendto  -----------> recvmsg \n");
    Nprintf("       12: bind -----------> sendmsg -> select -> recvfrom\n");
    Nprintf("       13: bind -----------> sendmsg -> select -> recvmsg \n");
    Nprintf("       14: bind -----------> sendmsg -----------> recvfrom\n");
    Nprintf("       15: bind -----------> sendmsg -----------> recvmsg \n");
    Nprintf("    <prm1>\n");
    Nprintf("       0: send\n");
    Nprintf("       1: send & read\n");
    Nprintf("       2: continuous send\n");
    Nprintf("       3: continuous send & read\n");
    Nprintf("    <prm2>\n");
    Nprintf("       0: patarn[*]\n");
    Nprintf("       1: patarn[* -> 15]\n");
    Nprintf("    <prm3>\n");
    Nprintf("       *: loop count of [socket - closesocket]\n");
    Nprintf("    <prm4>\n");
    Nprintf("       *: loop count of [sendto - recvfrom]\n");
    Nprintf("    <prm5>\n");
    Nprintf("       *: send size < [%d]\n", BUFSIZE - IPD_OFFSET);
    Nprintf("    <prm6>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_ip_opt(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[i/t/u] ip[*] src_prt[*] dst_prt[*]\n", N_SOCK_IP_OPT);
    Nprintf("          type[*] prm1[*] prm2[*] prm3[*] prm4[*] prm5[*] prm6[*] prm7[*]\n");
    Nprintf("    <type>\n");
    Nprintf("       7: Record Route\n");
    Nprintf("      68: Internet Timestamp\n");
    Nprintf("     131: Loose Source and Record Route\n");
    Nprintf("     137: Strict Source and Record Route\n");
    Nprintf("    <prm1>\n");
    Nprintf("       *: [7] count / [68] flag\n");
    Nprintf("    <prm2>\n");
    Nprintf("       *: [ 68 / 131 /137 ] IP address 1\n");
    Nprintf("    <prm3>\n");
    Nprintf("       *: [ 68 / 131 / 137] IP address 2\n");
    Nprintf("    <prm4>\n");
    Nprintf("       *: [ 68 / 131 / 137] IP address 3\n");
    Nprintf("    <prm5>\n");
    Nprintf("       *: [ 68 / 131 / 137] IP address 4\n");
    Nprintf("    <prm6>\n");
    Nprintf("       *: size\n");
    Nprintf("    <prm7>\n");
    Nprintf("       *: loop count\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_func(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: comm[*] name/ip[*] src_prt[*] dst_prt[*] prm1[*] prm2[*] prm3[*]\n", N_SOCK_FUNC);
    Nprintf("  <comm>\n");
    Nprintf("     %d : gethostbyname\n", SF_GET_HOST_NAME);
    Nprintf("     %d : gethostbyaddr\n", SF_GET_HOST_ADDR);
    Nprintf("     %d : getsockname / getpeername\n", SF_GET_SOCK_PEER_NAME);
    Nprintf("     %d : setsockopt (MULTICAST_IF / ADD_MEMBERSHIP / DROP_MEMBERSHIP)", SF_SET_OPT_IP);
    Nprintf(" : prm1=[s/r]\n");
    Nprintf("     %d : setsockopt (TCP_NODELAY / TCP_MAXSEG) \n", SF_SET_OPT_TCP);
    Nprintf("     %d : setsockopt (SO_REUSEADDR)\n", SF_SET_OPT_SOCK_REUSE);
    Nprintf("     %d : setsockopt (SO_BINDTODEVICE)\n", SF_SET_OPT_SOCK_BINDDEV);
    Nprintf("     %d : setsockopt (SO_KEEPALIVE)\n", SF_SET_OPT_SOCK_KEEPA);
    Nprintf("     %d : setsockopt (SO_OOBINLINE)\n", SF_SET_OPT_SOCK_OOBINL);
    Nprintf("     %d : setsockopt (SO_LINGER) : prm1=[l_linger] prm2[s/c]\n", SF_SET_OPT_SOCK_LINGER);
    Nprintf("     %d: setsockopt (SO_DONTROUTE)\n", SF_SET_OPT_SOCK_DONTRT);
    Nprintf("     %d: setsockopt (SO_BROADCAST)\n", SF_SET_OPT_SOCK_BCAST);
    Nprintf("     %d: fcntlsocket (O_NDELAY)\n", SF_FCTL_NDELAY);
    Nprintf("     %d: ioctlsocket (FIONBIO / FIONREAD / SIOCATMARK)\n", SF_IOCTL_ALL);
    Nprintf("     %d: selectsocket : prm1=[t/u] prm2=[type], prm3=[len]\n", SF_SELECTSOCK);
    Nprintf("           <type> 0=readfds, 1=writefds 2=exceptfds\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_sock_rw(void)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: protocol[t/u] mode[s/c] rw[r/w] ip[*] src_prt[*] dst_prt[*]", N_SOCK_RW);
    Nprintf(" flag[*] size[*]\n");
    Nprintf("    <flag>\n");
    Nprintf("       %d: NONE\n", SRW_NONE);
    Nprintf("       %d: MSG_OOB\n", SRW_OOB);
    Nprintf("       %d: MSG_PEEK\n", SRW_PEEK);
    Nprintf("       %d: MSG_DONTROUTE\n", SRW_DNTRT);
    Nprintf("       %d: change [conp->herport] after send [SYN]\n", SRW_SYNACK_RST);
    Nprintf("       %d: stop [NetTask()] after send [SYN]\n", SRW_SYNACK_DSCRD);
    Nprintf("       %d: send [RST] to [LISTEN] port\n", SRW_LISTEN_RST);
    Nprintf("       %d: send [RST] to [ESTABLISHED] port\n", SRW_ESTABL_RST);
    Nprintf("       %d: set backlog:5 -> accept()\n", SRW_ACCEPT);
    Nprintf("       %d: send IP option message\n", SRW_IPOPT);
    Nprintf("    <size>\n");
    Nprintf("       *: read/write size < [%d]\n", BUFSIZE - IPD_OFFSET);
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_dpi_tcp(char cc)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[s/c] ip[*] src_prt[*] dst_prt[*]", N_TCP_DPI);
    Nprintf(" flag[*] prm1[*] prm2[*] prm3[*]\n");
    Nprintf("    <flag>\n");
    Nprintf("       0: NONE\n");
    Nprintf("       1: S_KEEPA\n");
    Nprintf("       2: S_URG\n");
    Nprintf("       3: S_NOWA\n");
    Nprintf("       4: minute Nclose()\n");
    Nprintf("    <prm1>\n");
    if (cc == 's') {
        Nprintf("       0: read\n");
        Nprintf("       1: read & send\n");
        Nprintf("       2: continuous read\n");
        Nprintf("       3: continuous read & send\n");
        Nprintf("    <prm2>\n");
        Nprintf("       *: timeout of read (second)\n");
    }
    else {
        Nprintf("       0: send\n");
        Nprintf("       1: send & read\n");
        Nprintf("       2: continuous send \n");
        Nprintf("       3: continuous send & read\n");
        Nprintf("       4: connection keep 100ms \n");
        Nprintf("       *: continuous send with interval [*]ms\n");
        Nprintf("    <prm2>\n");
        Nprintf("       *: send size < [%d]\n", DPI_SEND_SIZE - IPD_OFFSET);
    }
    Nprintf("    <prm3>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void comm_dpi_udp(char cc)
{
#if (MT != 0)
    Nprintf("\r");
#endif
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s: mode[s/c] ip[*] src_prt[*] dst_prt[*]", N_UDP_DPI);
    Nprintf(" flag[*] prm1[*] prm2[*] prm3[*]\n");
    Nprintf("    <flag>\n");
    Nprintf("       0: NONE\n");
    Nprintf("       1: S_NOWA\n");
    Nprintf("       2: S_NOCON\n");
    Nprintf("       3: S_NOCON | S_NOWA\n");
    Nprintf("    <prm1>\n");
    if (cc == 's') {
        Nprintf("       0: read\n");
        Nprintf("       1: read & send\n");
        Nprintf("       2: continuous read\n");
        Nprintf("       3: continuous read & send\n");
        Nprintf("    <prm2>\n");
        Nprintf("       *: timeout of read (second)\n");
    }
    else {
        Nprintf("       0: send\n");
        Nprintf("       1: send & read\n");
        Nprintf("       2: continuous send \n");
        Nprintf("       3: continuous send & read\n");
        Nprintf("       4: send after SCOKET_CANSEND()\n");
        Nprintf("       *: continuous send with interval [*]ms\n");
        Nprintf("    <prm2>\n");
        Nprintf("       *: send size < [%d]\n", DPI_SEND_SIZE - IPD_OFFSET);
    }
    Nprintf("    <prm3>\n");
    Nprintf("       1: display log\n");
    Nprintf("-----------------------------------------------------------------------------\n");
#if (MT != 0)
    Nprintf("->");
#endif
}

void command_dispaly(void)
{
    Nprintf("\nselect test\n");
    Nprintf("-----------------------------------------------------------------------------\n");
    Nprintf("  %s\n", N_GETTIME);
    Nprintf("  %s: time[*] (hexadecimal)\n", N_SETTIME);
    Nprintf("  %s: netno[*]\n", N_RARPGET);
    Nprintf("  %s: ip[*]\n", N_EGP);
    Nprintf("  %s: ip[*] size[* < %d] count[*] seqnno[*]\n", N_PING,
        DPI_SEND_SIZE - IPD_OFFSET - 8);
    Nprintf("  %s: ...\n", N_ICMP_SEND);
    Nprintf("  %s: ...\n", N_ICMP_RPLY);
    Nprintf("  %s: ...\n", N_SOCK_IP_OPT);
    Nprintf("  %s: ...\n", N_SOCK_FUNC);
    Nprintf("  %s: ...\n", N_SOCK_RW);
    Nprintf("  %s: mode[s/c] ...\n", N_TCP_SOCK);
    Nprintf("  %s: mode[s/c] ...\n", N_UDP_SOCK);
    Nprintf("  %s: mode[s/c] ...\n", N_TCP_DPI);
    Nprintf("  %s: mode[s/c] ...\n", N_UDP_DPI);
    Nprintf("  %s: mode[s/c] ip[*] herport[*]\n", N_RST_SOCK);
    Nprintf("  %s: herport[*]\n", N_RST_DPI);
    Nprintf("  %s: protocol[t/u] mode[s/c] rw[r/w] ip[*] src_prt[*] dst_prt[*] size[*]\n", N_BENCH_SOCK);
#if (DHCP >= 1)
    Nprintf("  %s: netno[*] Lease Time[*] mode[*] count[*]\n", N_DHCPGET);
    Nprintf("    <mode>\n");
    Nprintf("       0: normal\n");
    Nprintf("       1: del server's IP address\n");
    Nprintf("    <count>\n");
    Nprintf("       0: once\n");
    Nprintf("       1: continue\n");
    Nprintf("  %s: netno[*]\n", N_DHCPREL);
#endif
#ifdef INCLUDE_TELNET
    Nprintf("  %s: backlog[*]\n", N_TNSERV);
#endif
    Nprintf("  %s\n", N_NINIT   );
    Nprintf("  %s\n", N_NTERM   );
    Nprintf("  %s: pname[*]\n", N_PINIT);
    Nprintf("  %s: pname[*]\n", N_PTERM);
    Nprintf("  %s\n", N_BLD_RT  );
    Nprintf("  %s: netno[*]\n", N_SHOW_NET);
    Nprintf("  %s: confix[*]\n", N_SHOW_NCON);
    Nprintf("  %s: conno[*]\n", N_SHOW_CONN);
    Nprintf("  %s\n", N_SHOW_MESS);
#if (MT != 0)
    Nprintf("  %s\n", N_TASK_SHOW);
    Nprintf("  %s: TaskID[*]\n", N_TASK_KILL);
    Nprintf("  %s: TaskID[*] data[*]\n", N_INPUT);
#endif
    Nprintf("  %s: address[*] unit[b/w/l] data[*]\n", N_MEM_EDIT);
    Nprintf("  %s: address[*] unit[b/w/l]\n", N_MEM_READ);
    Nprintf("  %s: address[*] length[*]\n", N_MEM_DUMP);
    Nprintf("  %s <host> <get|put> <filename> <user id> <password> [file size]\n", N_FTPTEST);
#ifdef USSW_DIRECTED_BROADCAST
    Nprintf("  %s: \n", N_GET_CHG_IP);
    Nprintf("  %s: \n", N_SET_CHG_IP);
    Nprintf("  %s: no[*] addr1[*] addr2[*] addr3[*] addr4[*] \n", N_SET_IP);
    Nprintf("  %s: no[*] addr1[*] addr2[*] addr3[*] addr4[*] addr5[*] addr6[*] \n", N_SET_EADDR);
    Nprintf("  %s: no[*] addr1[*] addr2[*] addr3[*] addr4[*] \n", N_SET_IMASK);
    Nprintf("  %s: no[*] addr1[*] addr2[*] addr3[*] addr4[*] \n", N_SET_GATEWAY);
    Nprintf("  %s: addr1[*] addr2[*] addr3[*] addr4[*] port[*]\n", N_START_DET_IP);
    Nprintf("  %s: port[*]\n", N_STOP_DET_IP);
    Nprintf("  %s: \n", N_GET_DETSTAT);
#endif
    Nprintf("  %s\n", N_STOP);
    Nprintf("  %s\n", N_END);
    Nprintf("-----------------------------------------------------------------------------\n");
}

static void init_board(void)
{

    Nenable();

    Nclkinit();

    Ninitchr();
}


int init_usnet(void)
{
    if ( Ninit() < 0 ) {
        Nprintf("Ninit() error!\n");
        return -1;
    }

#if (MT == 0)
    Nenable();
#endif
    Nprintf("Ninit() OK\n");
    if ( Portinit("*") < 0 ) {
        Nprintf("Portinit() error!\n");
    }
    Nprintf("USNET is initialized!\n\n");

    return 0;
}

static void show_info(int menu, int num)
{
    unsigned char *bp;
    int i1, i2, i3, cc;
    struct NET *netp;
    struct NETCONF *confp;
    register struct CONNECT *conp, *conp2, *conp3;
    struct FIFOQ16 tmpqueue;
    MESS *mess = Nbufbase;

#if (MT != 0)
    BLOCKPREE();
#endif

    Nprintf("\nTimeMS() = [%u]ms\n", TimeMS());

    switch (menu) {
    case C_SHOW_NET:
        netp = &nets[num];
        Nprintf(" -----------------------------------------------------------\n");
        Nprintf(" netno        : %d\n", netp->netno);
        Nprintf(" hwflags      : %d\n", netp->hwflags);
        Nprintf(" netstat      : %d\n", netp->netstat);
        Nprintf(" confix       : %d\n", netp->confix);
        Nprintf(" tout         : %lu\n", netp->tout);
        Nprintf(" maxblo       : %d\n", netp->maxblo);
        Nprintf(" nettasktout  : %d\n", netp->nettasktout);
        Nprintf(" id           : %02X:%02X:%02X:%02X:%02X:%02X\n",
            netp->id.c[0], netp->id.c[1], netp->id.c[2],
            netp->id.c[3], netp->id.c[4], netp->id.c[5]);
        Nprintf(" fragmq       : ");
        if (netp->fragmq == 0) {
            Nprintf("- \n");
        }
        else {
            mess = netp->fragmq;
            i1 = 1;
            while (mess) {
                if (i1++ > 5)
                    Nprintf("\n                ");
                Nprintf("0x%08X", mess);
                mess = mess->next;
                if (mess)
                    Nprintf(" - ");
            }
            Nprintf("\n");
        }
        Nprintf(" fragmh       : ");
        if (netp->fragmh == 0) {
            Nprintf("- \n");
        }
        else {
            mess = netp->fragmh;
            i1 = 1;
            while (mess) {
                if (i1++ > 5)
                    Nprintf("\n                ");
                Nprintf("0x%08X", mess);
                mess = mess->next;
                if (mess)
                    Nprintf(" - ");
            }
            Nprintf("\n");
        }
        Nprintf(" bufbas       : 0x%08X\n", netp->bufbas);
        Nprintf(" bufbaso      : 0x%08X\n", netp->bufbaso);
#if (DHCP >= 1)
        Nprintf(" DHCPserver   : %03d.%03d.%03d.%03d\n",
            (unsigned char)(netp->DHCPserver >> 24),
            (unsigned char)(netp->DHCPserver >> 16),
            (unsigned char)(netp->DHCPserver >> 8),
            (unsigned char)(netp->DHCPserver));
        Nprintf(" LeaseTime    : %lu\n", netp->LeaseTime);
        Nprintf(" RenewalTime  : %lu\n", netp->RenewalTime);
        Nprintf(" RebindingTime: %lu\n", netp->RebindingTime);
        Nprintf(" DHCPsecs     : %lu\n", netp->DHCPsecs);
#endif
        Nprintf(" ifInDiscards      : %lu\n", netp->ifInDiscards);
        Nprintf(" ifInErrors        : %lu\n", netp->ifInErrors);
        Nprintf(" ifOutDiscards     : %lu\n", netp->ifOutDiscards);
        Nprintf(" ifOutErrors       : %lu\n", netp->ifOutErrors);
        Ndisable();
        memcpy((char *)&tmpqueue, (char *)&netp->depart, sizeof(struct FIFOQ16));
        Nenable();
        Nprintf(" depart.mhead : %d\n", tmpqueue.mhead);
        Nprintf(" depart.mtail : %d\n", tmpqueue.mtail);
        i2 = 0, i3 = 8;
        Nprintf(" depart.mp[%2d]: 0x%08X %s %s  [%2d]: 0x%08X %s %s\n",
            i2, tmpqueue.mp[i2],
            (tmpqueue.mhead==i2)?"<-hd":"    ",
            (tmpqueue.mtail==i2)?"<-tl":"    ",
            i3, tmpqueue.mp[i3],
            (tmpqueue.mhead==i3)?"<-hd":"    ",
            (tmpqueue.mtail==i3)?"<-tl":"    ");
        for (i2=1; i2<i3; i2++) {
            i1 = i2+i3;
            Nprintf("          [%2d]: 0x%08X %s %s  [%2d]: 0x%08X %s %s\n",
                i2, tmpqueue.mp[i2],
                (tmpqueue.mhead==i2)?"<-hd":"    ",
                (tmpqueue.mtail==i2)?"<-tl":"    ",
                i1, tmpqueue.mp[i1],
                (tmpqueue.mhead==i1)?"<-hd":"    ",
                (tmpqueue.mtail==i1)?"<-tl":"    ");
        }

        Ndisable();
        memcpy((char *)&tmpqueue, (char *)&netp->arrive, sizeof(struct FIFOQ16));
        Nenable();
        Nprintf(" arrive.mhead : %d\n", tmpqueue.mhead);
        Nprintf(" arrive.mtail : %d\n", tmpqueue.mtail);
        i2 = 0, i3 = 8;
        Nprintf(" arrive.mp[%2d]: 0x%08X %s %s  [%2d]: 0x%08X %s %s\n",
            i2, tmpqueue.mp[i2],
            (tmpqueue.mhead==i2)?"<-hd":"    ",
            (tmpqueue.mtail==i2)?"<-tl":"    ",
            i3, tmpqueue.mp[i3],
            (tmpqueue.mhead==i3)?"<-hd":"    ",
            (tmpqueue.mtail==i3)?"<-tl":"    ");
        for (i2=1; i2<i3; i2++) {
            i1 = i2+i3;
            Nprintf("          [%2d]: 0x%08X %s %s  [%2d]: 0x%08X %s %s\n",
                i2, tmpqueue.mp[i2],
                (tmpqueue.mhead==i2)?"<-hd":"    ",
                (tmpqueue.mtail==i2)?"<-tl":"    ",
                i1, tmpqueue.mp[i1],
                (tmpqueue.mhead==i1)?"<-hd":"    ",
                (tmpqueue.mtail==i1)?"<-tl":"    ");
        }
show_net_end:
        Nprintf(" -----------------------------------------------------------\n");
        break;
    case C_SHOW_NCON:
        if (num < 0) {
            Nprintf(" No  Eaddr              Iaddr            Imask          ");
            Nprintf("  flags ncst cqnx cqpr hops nxth gind nlst netno hw\n");
            Nprintf(" ---------------------------------------------------------");
            Nprintf("--------------------------------------------------------\n");
            for (i1 = 0; i1 < NCONFIGS; i1++) {
                confp = &netconf[i1];
                Nprintf(" %2d  %02X:%02X:%02X:%02X:%02X:%02X  %03d.%03d.%03d.%03d  %03d.%03d.%03d.%03d",
                    i1,
                    confp->Eaddr.c[0],
                    confp->Eaddr.c[1],
                    confp->Eaddr.c[2],
                    confp->Eaddr.c[3],
                    confp->Eaddr.c[4],
                    confp->Eaddr.c[5],
                    confp->Iaddr.c[0],
                    confp->Iaddr.c[1],
                    confp->Iaddr.c[2],
                    confp->Iaddr.c[3],
                    confp->Imask.c[0],
                    confp->Imask.c[1],
                    confp->Imask.c[2],
                    confp->Imask.c[3]);
                Nprintf("  0x%03X   %d  %3d  %3d  %3d  %3d  %3d  %3d   %3d   %d\n",
                    confp->flags, confp->ncstat, confp->cqnext, confp->cqprev, confp->hops,
                    confp->nexthix, confp->gnid, confp->nlstat, confp->netno, confp->hwaddyes);

            }
        }
        else {
            confp = &netconf[num];
            Nprintf(" name      :");
            if (confp->name == 0)
                Nprintf(" - \n");
            else
                Nprintf(" %s\n", confp->name);
            Nprintf(" pname     :");
            if (confp->pname == 0)
                Nprintf(" - \n");
            else
                Nprintf(" %s\n", confp->pname);
            Nprintf(" Iaddr     : %03d.%03d.%03d.%03d\n",
                confp->Iaddr.c[0], confp->Iaddr.c[1],
                confp->Iaddr.c[2], confp->Iaddr.c[3]);
            Nprintf(" Imask     : %03d.%03d.%03d.%03d\n",
                confp->Imask.c[0], confp->Imask.c[1],
                confp->Imask.c[2], confp->Imask.c[3]);
            Nprintf(" Eaddr     : %02X:%02X:%02X:%02X:%02X:%02X\n",
                confp->Eaddr.c[0], confp->Eaddr.c[1], confp->Eaddr.c[2],
                confp->Eaddr.c[3],confp->Eaddr.c[4],  confp->Eaddr.c[5]);
            Nprintf(" flags     : 0x%04X", confp->flags);
            if (confp->flags) {
               i1 = sizeof(nc_stat_tab) / sizeof(struct stat_type);
                Nprintf(" [ ");
                for (i2=0; i2 < i1; i2++) {
                    if (confp->flags & nc_stat_tab[i2].stattno) {
                        Nprintf("%s", nc_stat_tab[i2].statname);
                        for (i3=(i2+1); i3 < i1; i3++)
                            if (confp->flags & nc_stat_tab[i3].stattno) {
                                Nprintf(" | ");
                                break;
                            }
                    }
                }
                Nprintf(" ]");
            }
            Nprintf("\n");
            Nprintf(" ncstat    : %d\n", confp->ncstat);
            Nprintf(" nexthix   : %d\n", confp->nexthix);
            Nprintf(" nlstat    : %d\n", confp->nlstat);
            Nprintf(" netno     : %d\n", confp->netno);
            Nprintf(" gnid      : %d\n", confp->gnid);
            Nprintf(" cqnext    : %u\n", confp->cqnext);
            Nprintf(" cqprev    : %u\n", confp->cqprev);
            Nprintf(" timems    : %lu\n", confp->timems);
#ifdef ARP
            Nprintf(" ARPwait   : %d\n", confp->ARPwait);
            Nprintf(" ARPwaitmp :");
            if (confp->ARPwaitmp == 0)
                Nprintf(" - \n");
            else
                Nprintf(" 0x%08X\n", confp->ARPwaitmp);
#endif
        }
        break;
    case C_SHOW_CONN:
        if (num < 0) {
        Nprintf(" No blkst state            refc refs  txstat rxstat myport    herport");
            Nprintf("   confix  heriid\n");
            Nprintf(" ----------------------------------------------------------");
            Nprintf("-------------------------------------\n");
            for (i1 = 0; i1 < NCONNS; i1++) {
                conp = &connblo[i1];
                Nprintf(" %2d %4d ", i1, conp->blockstat);
                i2 = sizeof(stat_tab) / sizeof(struct stat_type);

                for (i3=0; i3 < i2; i3++)
                    if (conp->state == stat_tab[i3].stattno)
                        break;
                if (i3 < i2)
                    Nprintf(" %2d: %s", conp->state, stat_tab[i3].statname);
                else
                    Nprintf(" %2d: ?           ", conp->state);

#ifdef VER_25900
                Nprintf("  %2d  0x%04X  0x%02X ",
                    conp->refcount,
                    conp->txstat,
                    conp->rxstat
                );
#else
                Nprintf("  %2d   %2d   0x%04X  0x%02X ",
                    conp->refcount,
                    conp->refsock,
                    conp->txstat,
                    conp->rxstat
                );
#endif

                i2 = sizeof(port_tab) / sizeof(struct port_type);
                for (i3=0; i3 < i2; i3++)
                    if (NC2(conp->myport) == port_tab[i3].portno)
                        break;
                if (i3 < i2)
                    Nprintf(" %s", port_tab[i3].protocol);
                else
                    Nprintf(" %5d    ", NC2(conp->myport));
                for (i3=0; i3 < i2; i3++)
                    if (NC2(conp->herport) == port_tab[i3].portno)
                        break;
                if (i3 < i2)
                    Nprintf(" %s", port_tab[i3].protocol);
                else
                    Nprintf(" %5d    ", NC2(conp->herport));

                Nprintf("  %4d   %03d.%03d.%03d.%03d\n",
                    conp->confix,
                    conp->heriid.c[0],
                    conp->heriid.c[1],
                    conp->heriid.c[2],
                    conp->heriid.c[3]
                );
            }
        }
        else if (num < NCONNS) {
            conp = &connblo[num];
            Nprintf(" -----------------------------------------------------------\n");
            Nprintf(" blockstat  : %d\n", conp->blockstat);
            Nprintf(" state      : %d", conp->state);
            i1 = sizeof(stat_tab) / sizeof(struct stat_type);
            for (i2=0; i2 < i1; i2++)
                if (conp->state == stat_tab[i2].stattno)
                    break;
            if (i2 < i1)
                 Nprintf(" [ %s]\n", stat_tab[i2].statname);
            else
                Nprintf("  [?]\n");
            Nprintf(" netno      : %d\n", conp->netno);
            Nprintf(" txstat     : 0x%04X", conp->txstat);
            if (conp->txstat) {
               i1 = sizeof(tx_stat_tab) / sizeof(struct stat_type);
                Nprintf(" [ ");
                for (i2=0; i2 < i1; i2++) {
                    if (conp->txstat & tx_stat_tab[i2].stattno) {
                        Nprintf("%s", tx_stat_tab[i2].statname);
                        for (i3=(i2+1); i3 < i1; i3++)
                            if (conp->txstat & tx_stat_tab[i3].stattno) {
                                Nprintf(" | ");
                                break;
                            }
                    }
                }
                Nprintf(" ]");
            }
            Nprintf("\n");
            Nprintf(" rxstat     : 0x%04X", conp->rxstat);
            if (conp->rxstat) {
               i1 = sizeof(rx_stat_tab) / sizeof(struct stat_type);
                Nprintf(" [ ");
                for (i2=0; i2 < i1; i2++) {
                    if (conp->rxstat & rx_stat_tab[i2].stattno) {
                        Nprintf("%s", rx_stat_tab[i2].statname);
                        for (i3=(i2+1); i3 < i1; i3++)
                            if (conp->rxstat & rx_stat_tab[i3].stattno) {
                                Nprintf(" | ");
                                break;
                            }
                    }
                }
                Nprintf(" ]");
            }
            Nprintf("\n");
            Nprintf(" refcount   : %d\n", conp->refcount);
#ifndef VER_25900
            Nprintf(" refsock    : %d\n", conp->refsock);
#endif
            Nprintf(" confix     : %u\n", conp->confix);

            Nprintf(" heriid     : %03d.%03d.%03d.%03d\n",
                conp->heriid.c[0], conp->heriid.c[1],
                conp->heriid.c[2], conp->heriid.c[3]);
            Nprintf(" realiid    : %03d.%03d.%03d.%03d\n",
                conp->realiid.c[0], conp->realiid.c[1],
                conp->realiid.c[2], conp->realiid.c[3]);
#ifndef VER_25900
            Nprintf(" offerediid : %03d.%03d.%03d.%03d\n",
                conp->offerediid.c[0], conp->offerediid.c[1],
                conp->offerediid.c[2], conp->offerediid.c[3]);
#endif
            Nprintf(" myport     : %u\n", NC2(conp->myport));
            Nprintf(" herport    : %u\n", NC2(conp->herport));
            Nprintf(" txseq      : %lu\n", conp->txseq);
            Nprintf(" rxseq      : %lu\n", conp->rxseq);
            Nprintf(" ackno      : %lu\n", conp->ackno);
            Nprintf(" seqtoack   : %lu\n", conp->seqtoack);
            Nprintf(" ackdseq    : %lu\n", conp->ackdseq);
            Nprintf(" acktime    : %lu\n", conp->acktime);
            Nprintf(" unackseq   : %lu\n", conp->unackseq);
            Nprintf(" lastrxtime : %lu\n", conp->lastrxtime);
            Nprintf(" rxtout     : %lu\n", conp->rxtout);
            Nprintf(" txtout     : %lu\n", conp->txtout);
            Nprintf(" txvar      : %lu\n", conp->txvar);
            Nprintf(" txave      : %lu\n", conp->txave);
            Nprintf(" sendack    : %u\n", conp->sendack);
            Nprintf(" nwacks     : %u\n", conp->nwacks);
            Nprintf(" wackmax    : %u\n", conp->wackmax);
            Nprintf(" window     : %u\n", conp->window);
            Nprintf(" wackslow   : %u\n", conp->wackslow);
            Nprintf(" mywindow   : %u\n", conp->mywindow);
            Nprintf(" prevwindow : %u\n", conp->prevwindow);
            Nprintf(" maxdat     : %u\n", conp->maxdat);
            Nprintf(" doffset    : %u\n", conp->doffset);
            Nprintf(" tcpflags   : %d\n", conp->tcpflags);
            Nprintf(" urgflag    : %d\n", conp->urgflag);
            Nprintf(" urgcnt     : %d\n", conp->urgcnt);
            Nprintf(" urgdata    : 0x%02X\n", conp->urgdata);
            Nprintf(" urgseq     : %lu\n", conp->urgseq);
            Nprintf(" backlog    : %d\n", conp->backlog);
            Nprintf(" icqcur     : %d\n", conp->icqcur);
            Nprintf(" next       :");
            if (conp->next == 0) {
                Nprintf(" - \n");
            }
            else {
                conp2 = conp->next;
                while (conp2) {
                    for (i1=0; i1<NCONNS; i1++) {
                        conp3 = &connblo[i1];
                        if (conp2 == conp3)
                            Nprintf(" -> %d", i1);
                    }
                    conp2 = conp2->next;
                }
                Nprintf("\n");
            }
            Nprintf(" passive    : %d\n", conp->passive);
#ifndef VER_25900
            Nprintf(" l_linger   : %d\n", conp->l_linger);
#endif
            Nprintf(" first      : ");
            if (conp->first == 0) {
                Nprintf("- \n");
            }
            else {
                mess = conp->first;
                i1 = 1;
                while (mess) {
                    if ((i1++ % 5) == 0)
                        Nprintf("\n              ");
                    Nprintf("0x%08X", mess);
                    mess = mess->next;
                    if (mess)
                        Nprintf(" - ");
                }
                Nprintf("\n");
            }
            Nprintf(" last       : 0x%08X\n", conp->last);

            Nprintf(" wackf      : ");
            if (conp->wackf == 0) {
                Nprintf("- \n");
            }
            else {
                mess = conp->wackf;
                i1 = 1;
                while (mess) {
                    if ((i1++ % 5) == 0)
                        Nprintf("\n              ");
                    Nprintf("0x%08X", mess);
                    mess = mess->next;
                    if (mess)
                        Nprintf(" - ");
                }
                Nprintf("\n");
            }
            Nprintf(" wackl      : 0x%08X\n", conp->wackl);

            Nprintf(" future     : ");
            if (conp->future == 0) {
                Nprintf("- \n");
            }
            else {
                mess = conp->future;
                i1 = 1;
                while (mess) {
                    if ((i1++ % 5) == 0)
                        Nprintf("\n              ");
                    Nprintf("0x%08X", mess);
                    mess = mess->next;
                    if (mess)
                        Nprintf(" - ");
                }
                Nprintf("\n");
            }
            Nprintf(" ostreamb   : 0x%08X\n", conp->ostreamb);
            Nprintf(" istreamb   : 0x%08X\n", conp->istreamb);
            Nprintf(" istreamp   : 0x%08X\n", conp->istreamp);
            Nprintf(" istreamc   : %d\n", conp->istreamc);

#ifdef IPOPTIONS
            Nprintf(" IPOtxlen   : %d\n", conp->IPOtxlen);
            Nprintf(" IPOrxlen   : %d\n", conp->IPOrxlen);
#ifndef VER_25900
            Nprintf(" IPOrxsrlen : %d\n", conp->IPOrxsrlen);
#endif
#endif
#ifdef TCP_OPTIONS
            Nprintf(" TCPOtxlen  : %d\n", conp->TCPOtxlen);
            Nprintf(" TCPOrxlen  : %d\n", conp->TCPOrxlen);
#endif
            Nprintf(" -----------------------------------------------------------\n");
        }
        else {
            Nprintf("Invalid connection number [num < %d]\n", NCONNS);
        }
        break;
    case C_SHOW_MESS:
        Nprintf(" No mess       next        id       confix  mlen  offset  conno  netno");
#ifdef VER_25900
        Nprintf("  terget          \n");
#else
        Nprintf("  retry  terget          \n");
#endif
        Nprintf(" ---------------------------------------------------------------------");
        Nprintf("-------------------------\n");
        boffset = 1604;
        for ( i1 = 0; i1 < NBUFFS; i1++, mess=(MESS *)((char *)mess + boffset) ) {
            Nprintf("%2d: 0x%08X 0x%08X", i1, mess, mess->next);

            i2 = sizeof(mess_id_tab) / sizeof(struct mess_id);
            for (i3=0; i3 < i2; i3++)
                if (mess->id == mess_id_tab[i3].id)
                    break;
            if (i3 < i2)
                Nprintf("  %s", mess_id_tab[i3].idname);
            else
                Nprintf("  %6d  ", mess->id);

            Nprintf("  %3d    %4u", mess->confix, mess->mlen);

            i2 = sizeof(mess_ofs_tab) / sizeof(struct mess_ofs);
            for (i3=0; i3 < i2; i3++)
                if (mess->offset == mess_ofs_tab[i3].offset)
                    break;
            if (i3 < i2)
                Nprintf("  %s", mess_ofs_tab[i3].ofsname);
            else
                Nprintf("   %3d", mess->offset);
#ifdef VER_25900
            Nprintf("     %3d    %3d", mess->conno, mess->netno);
#else
            Nprintf("     %3d    %3d    %3d", mess->conno, mess->netno, mess->retry);
#endif
            bp = (unsigned char *)&mess->target;
            Nprintf("   %03d.%03d.%03d.%03d\n", bp[0], bp[1], bp[2], bp[3]);
        }
        Nprintf(" ---------------------------------------------------------------------");
        Nprintf("-------------------------\n");
        break;
    }
    Nprintf("\n");

#if (MT != 0)
    RESUMEPREE();
#endif

}

#if (MT != 0)
void data_input(ID task_id, char *cc)
{
    input_per_task[task_id] = (int)*cc;
}
#endif

int data_get(ID task_id)
{
    int cc;

#if (MT != 0)
    if ((cc = input_per_task[task_id]) != 0) {
        input_per_task[task_id] = 0;
        return cc;
    }
#else
    if (Nchkchr() != 0) {
        cc = Ngetchr();
        return cc;
    }
    (void)task_id;
#endif

    return 0;
}

void data_dump(char *buf, unsigned long size)
{
    unsigned char *bp;
    int i1, i2;
    unsigned long left;

    left = (size + 0x0F) & ~0x0F;

    Nprintf("\n address");
    for (i1 = 0; i1 < 16; i1++)
        Nprintf(" %2X", i1);
    Nprintf("     ");
    for (i1 = 0; i1 < 16; i1++)
        Nprintf("%1X", i1);
    Nprintf("\n");
    Nprintf(" -------------------------------------------------------");
    Nprintf("     ");
    Nprintf("----------------");
    for (i1 = 0; i1 < left; i1++) {
        if ((i1 != 0) && ((i1 % 512) == 0))
            Nprintf("\n");
        if ((i1 % 16) == 0) {
            Nprintf("\n 0x%04X:", i1);
        }
        if (i1 < size)
            Nprintf(" %02X", (unsigned char)buf[i1]);
        else
            Nprintf("   ");

        if (((i1 + 1) % 16) == 0) {
            bp = (unsigned char *)&buf[i1 - 15];
            Nprintf("  -  ");
            for (i2 = 0; i2 < 16; i2++, bp++) {
               if (*bp < 0x20 || *bp >= 0x7E)
                   Nprintf(".");
               else
                   Nprintf("%c", *bp);
            }
        }

    }
    Nprintf("\n\n");
}

void stop_process(void) {
#if (MT != 0)
    BLOCKPREE();
#endif
    Nprintf("push any key to exit\n");
    while (1) {
        if (Nchkchr() != 0) {
           Ngetchr();
           break;
        }
    }
#if (MT != 0)
    RESUMEPREE();
#endif
}

void wait(unsigned long waittime)
{
   unsigned ul1;

   for (ul1 = TimeMS(); TimeMS() - ul1 < waittime; )
       YIELD();

}

TASKFUNCTION rarp_get(int argc, char **argv)
{
    int i1=0, status;
    struct NETCONF *confp;
    ID task_id;


#if (MT != 0)
    get_tid(&task_id);
#endif

    if (argc >= 1) {
        i1 = atoi(argv[1]);
    }

    status = RARPget(i1);
    if (status < 0) {
        Nprintf("RARPget(%d): ERROR[%d]\n", i1, status);
    }
    else {
        confp = &netconf[nets[i1].confix];
        Nprintf("  confp->Iaddr   = [%03d.%03d.%03d.%03d]\n",
            confp->Iaddr.c[0], confp->Iaddr.c[1],
            confp->Iaddr.c[2], confp->Iaddr.c[3]);
    }

#if (MT != 0)
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

struct EGPhdr {
    unsigned char version;
    unsigned char type;
    unsigned char code;
    unsigned char status;
    unsigned short chksum;
    unsigned short autosys;
    unsigned short seqno;
};
extern PTABLE ussIPTable;

TASKFUNCTION send_egp(int argc, char **argv)
{
    char *target;
    int conno, status, mlen;
    struct EGPhdr *hdrp;
    MESS *mess;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto egp_kill2;
    }
#endif

    if (argc < 1) {
        Nprintf("argument invalid\n");
        goto egp_kill;
    }
    target = argv[1];

    conno = Nopen(target, "ICMP/IP", 0, 0, 0);
    if (conno < 0) {
        Nprintf("ERROR: Nopen() returns[%d]\n", conno);
        goto egp_kill;
    }

    if ((mess = Ngetbuf()) == 0) {
        Nprintf("ERROR: Ngetbuf()\n");
        goto egp_end;
    }

    hdrp = (struct EGPhdr *) ((char *) mess + MESSH_SZ + LHDRSZ + Ihdr_SZ);
    hdrp->version = 2;
    hdrp->type = 3;
    hdrp->code = 0;
    hdrp->status = 1;

    mess->netno  = 0;
    mess->target = inet_addr(target);
    mess->offset = MESSH_SZ + LHDRSZ + Ihdr_SZ + sizeof(struct EGPhdr);
    mess->mlen   = mess->offset;
    mlen = sizeof(struct EGPhdr);
    hdrp->chksum = 0;
    if (mlen & 1)
        *((char *) hdrp + mlen) = 0;
    hdrp->chksum = ~Nchksum((unsigned short *) hdrp, (mlen + 1) / 2);
    *((char *) mess + MESSH_SZ + LHDRSZ + 9) = 8;

    mess->id = bRELEASE;

    status = ussIPTable.writE(conno, mess);
    if (status < 0)
        Nprintf("ERROR: ussIPTable.writE(%d) returns[%d]\n", conno, status);

egp_end:
    Nclose(conno);

egp_kill:
#if (MT != 0)
    relmem(testbuf);
egp_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION icmp_send(int argc, char **argv)
{
    char *target;
    int type, code, prm1, prm2;
    int conno, status, i1;
    unsigned long *ulp;
    struct ICMPhdr hdr;
    unsigned short id=1, seqnum=1;
    unsigned long ul1, ul2, tlen=0;
    unsigned NLONG  gtime[4 / sizeof(NLONG)];
    Iid ul3;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto icmpsend_kill2;
    }
#endif

    if (argc != 5) {
        comm_icmp_send();
        goto icmpsend_kill;
    }
    target = argv[1];
    type   = atoi(argv[2]);
    code   = atoi(argv[3]);
    prm1 = atoi(argv[4]);
    prm2 = atoi(argv[5]);

    conno = Nopen(target, "ICMP/IP", 0, 0, 0);
    if (conno < 0) {
        Nprintf("ERROR: Nopen() returns[%d]\n", conno);
        goto icmpsend_kill;
    }

    switch (type) {
    case IC_ECHO:
        Nprintf("Pinging %s with %d bytes of data:\n\n", target, prm1);
        for ( i1=1; i1 <= prm2; i1++ ) {
            hdr.type = IC_ECHO;
            hdr.scode = code;
            hdr.chksum = 0;
            ulp = (unsigned long *)hdr.param;
            ulp[0] = (unsigned long)(id << 16) | (unsigned long)(seqnum + tlen);
            ulp[1] = 2;
            ulp[2] = 3;
            ulp[3] = 4;
            ulp[4] = 5;
            ulp[5] = 6;

            if ((BUFSIZE - 8) < prm1)
                prm1 = (BUFSIZE - 8);

            memcpy(testbuf, (char *)&hdr, sizeof(struct ICMPhdr));

            ul1 = TimeMS();
            status = Nwrite(conno, testbuf, (8 + prm1));
            if ( status < 0 ){
                Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                break;
            }

            SOCKET_RXTOUT(conno, 1000);
            status = Nread(conno, testbuf, (8 + prm1));
            ul2 = TimeMS();
            if ( status < 0 ) {
                Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                break;
            }
            else {
                Nprintf("Reply from %s: bytes=%d time=%lums count=%d\n",
                    target, status - 8, ul2 - ul1, i1);
            }
            tlen += prm1;

            if (i1 < (prm2 - 1))
                while (TimeMS() - ul2 < 1000)
                    YIELD();

            if (data_get(task_id) != 0) {
                break;
            }

        }
        break;
    case IC_TIMEQ:
        hdr.type = IC_TIMEQ;
        hdr.scode = code;
        hdr.chksum = 0;
        ulp = (unsigned long *)hdr.param;
        ulp[0] = (unsigned long)(id << 16) | (unsigned long)seqnum;
        ul3.l = TimeMS();
        PUTLONG(ul3, gtime);
        memcpy((char *)&ulp[1], gtime, 4);
        ulp[2] = 0;
        ulp[3] = 0;
        ulp[4] = 0;
        ulp[5] = 0;
        status = Nwrite(conno, (char *)&hdr, sizeof(struct ICMPhdr));
        if (status != sizeof(struct ICMPhdr) ){
            Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
        }

        if (prm1 == 0) {
            SOCKET_RXTOUT(conno, READ_WAIT);
            status = Nread(conno, (char *)&hdr, sizeof(struct ICMPhdr));
            if ( status < 0 ) {
                Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                break;
            }
            else {
                Nprintf("Reply from %s:\n", target);
                memcpy(gtime, &ulp[1], 4);
                GETLONG(ul3, gtime);
                Nprintf("  Originate Timestamp : %u\n", ul3.l);
                memcpy(gtime, &ulp[2], 4);
                GETLONG(ul3, gtime);
                Nprintf("  Receive Timestamp   : %u\n", ul3.l);
                memcpy(gtime, &ulp[3], 4);
                GETLONG(ul3, gtime);
                Nprintf("  Transmit Timestamp  : %u\n", ul3.l);
            }
        }
        break;
    }
#if DEBUG_LEVEL >= 5
    Nprintf("\n");
#endif
    Nclose(conno);

icmpsend_kill:
#if (MT != 0)
    relmem(testbuf);
icmpsend_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

extern PTABLE ussICMPTable;

TASKFUNCTION icmp_reply(int argc, char **argv)
{
    char *iphdr, *prot, *prm1;
    unsigned short myport;
    int type, code;
    int cc, conno, status;
    unsigned long *ulp;
    unsigned long ul1, tlen=0;
    struct ICMPhdr *icmphdrp;
    struct CONNECT *conp;
    MESS *mess;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto icmp_reply_kill2;
    }
#endif

    if (argc != 5) {
        comm_icmp_reply();
        goto icmp_reply_kill;
    }
    prot   = argv[1];
    myport = (unsigned short)atoi(argv[2]);
    type   = atoi(argv[3]);
    code   = atoi(argv[4]);
    prm1 = argv[5];

    if (*prot == 't') {
        conno = Nopen("*", "TCP/IP", myport, 0, 0);
    }
    else {
        conno = Nopen("*", "UDP/IP", myport, 0, S_NOWA | S_NOCON);
    }
    if (conno < 0) {
        Nprintf("ERROR: Nopen() returns[%d]\n", conno);
        goto icmp_reply_kill;
    }

    if (type == IC_QUEN) {
        SOCKET_RXTOUT(conno, READ_WAIT);
        Nprintf("waiting packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: write\n", CC_WRITE);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (1) {
            status = Nread(conno, testbuf, BUFSIZE);
            if (status < 0){
                Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                break;
            }
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_WRITE) {
                    conp = &connblo[conno];
                    mess = conp->protoc[1]->reaD(conno);
                    if (mess == 0)
                        continue;
                    iphdr = (char *)mess + MESSH_SZ + LHDRSZ;
                    tlen  = NC2(*(unsigned short *)(iphdr + 2));
                    memcpy(testbuf, iphdr, tlen);

                    icmphdrp = (struct ICMPhdr *)((char *)mess + MESSH_SZ + LHDRSZ + Ihdr_SZ);
                    mess->offset = MESSH_SZ + LHDRSZ + Ihdr_SZ;
                    icmphdrp->type   = IC_QUEN;
                    icmphdrp->scode  = 0;
                    icmphdrp->chksum = 0;
                    memcpy((char *)icmphdrp + 8, testbuf, tlen);
                    mess->mlen = MESSH_SZ + LHDRSZ + Ihdr_SZ + 8 + tlen;
                    status = ussICMPTable.writE(conno, mess);
                    if (status < 0){
                        Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                        break;
                    }
                }
                if (cc == CC_END)
                    goto icmp_reply_end;
#if (MT == 0)
                    Nprintf("->");
#endif
            }
        }
    }
    else {
        SOCKET_NOBLOCK(conno);
        conp = &connblo[conno];
        Nprintf("waiting packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (1) {
            mess = conp->protoc[1]->reaD(conno);
            if (mess == 0) {
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_END)
                        goto icmp_reply_end;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
                YIELD();
                continue;
            }
            iphdr = (char *)mess + MESSH_SZ + LHDRSZ;
            tlen  = NC2(*(unsigned short *)(iphdr + 2));
            memcpy(testbuf, iphdr, tlen);
            icmphdrp = (struct ICMPhdr *)((char *)mess + MESSH_SZ + LHDRSZ + Ihdr_SZ);
            mess->offset = MESSH_SZ + LHDRSZ + Ihdr_SZ;
            switch (type) {
            case IC_UNRE:
                icmphdrp->type   = IC_UNRE;
                icmphdrp->scode  = (char)code;
                icmphdrp->chksum = 0;
                break;
            case IC_REDI:
                icmphdrp->type   = IC_REDI;
                icmphdrp->scode  = (char)code;
                icmphdrp->chksum = 0;
                ul1 = inet_addr(prm1);
                memcpy(((char *)icmphdrp + 4), (char *)&ul1, 4);
                break;
            case IC_PARAM:
                icmphdrp->type   = IC_PARAM;
                icmphdrp->scode  = 0;
                icmphdrp->chksum = 0;
                *(char *)((char *)icmphdrp + 4) = 1;
                break;
            }
            memcpy((char *)icmphdrp + 8, testbuf, tlen);
            mess->mlen = MESSH_SZ + LHDRSZ + Ihdr_SZ + 8 + tlen;
            status = ussICMPTable.writE(conno, mess);
            if (status < 0){
                Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
            }
        }
    }

icmp_reply_end:

    Nclose(conno);

icmp_reply_kill:
#if (MT != 0)
    relmem(testbuf);
icmp_reply_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION ping(int argc, char **argv)
{
    unsigned char cc;
    char *target;
    int prm1=64, prm2=4, prm3=1, prm4=1;
    int conno, status, i1;
    unsigned long *ulp;
    struct ICMPhdr hdr;
    unsigned short id=1;
    unsigned long ul1, ul2, tlen=0;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);
#endif

    if (argc < 1) {
#if (MT != 0)
        goto ping_kill2;
#else
        goto ping_kill;
#endif
    }
    target = argv[1];
    if (argc >= 2) {
        prm1 = atoi(argv[2]);
        if ((BUFSIZE - 8) < prm1)
            prm1 = (BUFSIZE - 8);
    }
    ul2 = prm1 + 8;
#if (MT != 0)
    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto ping_kill2;
    }
#endif

    if (argc >= 3) {
        prm2 = atoi(argv[3]);
    }
    if (argc >= 4) {
        prm3 = atoi(argv[4]);
    }
    if (argc >= 5) {
        prm4 = atoi(argv[5]);
    }

    cc = (unsigned char)TimeMS();

    for (ul1 = 0; ul1 < ul2; ul1++) {
        testbuf[ul1] = cc++;
    }

    conno = Nopen(target, "ICMP/IP", 0, 0, 0);
    if (conno < 0) {
        Nprintf("ERROR: Nopen() returns[%d]\n", conno);
        goto ping_kill;
    }

    if (prm4) {
        Nprintf("Pinging %s with %d bytes of data:\n\n", target, prm1);
    }
    for ( i1=1; i1 <= prm2; i1++ ) {
        hdr.type = IC_ECHO;
        hdr.scode = 0;
        hdr.chksum = 0;
        ulp = (unsigned long *)hdr.param;
        ulp[0] = (unsigned long)(id++ << 16) | (unsigned long)(prm3 + tlen);
        ulp[1] = 2;
        ulp[2] = 3;
        ulp[3] = 4;
        ulp[4] = 5;
        ulp[5] = 6;

        memcpy(testbuf, (char *)&hdr, sizeof(struct ICMPhdr));

        ul1 = TimeMS();
        status = Nwrite(conno, testbuf, (8 + prm1));
        if ( status < 0 ){
            if ((status == ETIMEDOUT) || (errno == ETIMEDOUT)) {
                Nprintf("Request timed out. (Nwrite: status=[%d] errno=[%d])\n", status, errno);
                if (data_get(task_id) != 0)
                    break;
                continue;
            }
            else {
                Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                break;
            }
        }

        SOCKET_RXTOUT(conno, 1000);
        status = Nread(conno, testbuf, (8 + prm1));
        ul2 = TimeMS();
        if (status < 0) {
            if ((status == ETIMEDOUT) || (errno == ETIMEDOUT)) {
                Nprintf("Request timed out. (Nread: status=[%d] errno=[%d])\n", status, errno);
            }
            else {
                Nprintf("ERROR: Nread(%d) returns[%d] errno[%d]\n", conno, status, errno);
                break;
            }
        }
        else {
            if (prm4) {
                Nprintf("Reply from %s: bytes=%d time=%lums count=%d\n",
                    target, status - 8, ul2 - ul1, i1);
            }
        }
        tlen += prm1;

        if (i1 < prm2)
            while (TimeMS() - ul1 < 1000)
                YIELD();

        if (data_get(task_id) != 0) {
            break;
        }
    }

ping_end:
    Nclose(conno);

ping_kill:
#if (MT != 0)
    relmem(testbuf);
ping_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION sock_ip_opt(int argc, char **argv)
{
    char *mode, *target, ipOption[IPOPTLEN], ipOptLen;
    unsigned char type, count, flag;
    unsigned short myport, herport;
    int conno, status, i1=0, i2, i3, size, loop, cc;
    struct ICMPhdr hdr, *rphdr;
    unsigned short id=1, seqnum=1;
    unsigned long ul1, ul2, tlen=0, *ulp;
    unsigned long routip[4];
    struct sockaddr_in socka;
    struct hostent *hostent;
    Iid iid;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_ipopt_kill2;
    }
#endif

    if (argc < 6) {
        comm_sock_ip_opt();
        goto sock_ipopt_kill;
    }
    mode    = argv[1];
    target  = argv[2];
    myport  = (unsigned short)atoi(argv[3]);
    herport = (unsigned short)atoi(argv[4]);
    type    = (unsigned char)atoi(argv[5]);
    if (type == 7) {
        count = (unsigned char)atoi(argv[6]);
    }
    else if (type == 68) {
        flag = (unsigned char)atoi(argv[6]);
    }
    else if ((type != 131) && (type != 137)) {
        comm_sock_ip_opt();
        goto sock_ipopt_kill;
    }

    if ((type == 68) || (type == 131) || (type == 137)) {
        if (argc < 7) {
            comm_sock_ip_opt();
            goto sock_ipopt_kill;
        }
        count = 1;
        routip[0] = inet_addr(argv[7]);

        if (8 <= argc) {
            count++;
            routip[1] = inet_addr(argv[8]);
        }
        if (9 <= argc) {
            count++;
            routip[2] = inet_addr(argv[9]);
        }
        if (10 <= argc) {
            count++;
            routip[3] = inet_addr(argv[10]);
        }
    }


#if DEBUG_LEVEL >= 5
    Nprintf("IP ooption test start\n");
#endif

    iid.l = inet_addr(target);

    memset(ipOption,0,IPOPTLEN);
    ipOption[0] = type;
    switch (type) {
    case 7:
        ipOption[1] = 3 + 4 * count;
        ipOption[2] = 4;
        ipOptLen = ipOption[1] + 1;
        break;
    case 68:
        ipOption[1] = 4;
        ipOption[2] = 5;
        ipOption[3] = flag;
        if (flag == 0) {
            ipOption[1] += (4 * count);
        }
        else if (flag == 1) {
            ipOption[1] += (8 * count);
        }
        else if (flag == 3) {
            ipOption[1] += (8 * count);
            for (i1 = 0; i1 < count; i1++) {
                memcpy(&ipOption[4 + (i1 * 8)], (char *)&routip[i1], 4);
            }
        }
        ipOptLen = ipOption[1];
        break;
    case 131:
    case 137:
        ipOption[1] = 3 + (4 * count);
        ipOption[2] = 4;
        i2 = 0;
        for (i1 = 0; i1 < count; i1++) {
            memcpy(&ipOption[3 + i2], (char *)&routip[i1], 4);
            i2 += 4;
        }
        ipOptLen = ipOption[1];
        break;
    default:
        Nprintf("argument invalid\n");
        goto sock_ipopt_kill;
    }

    if (*mode == 'i') {
        if (11 <= argc)
            size = atoi(argv[11]);
        else
            size = 64;

        if (12 <= argc)
            loop = atoi(argv[12]);
        else
            loop = 4;

        conno = socket(PF_INET, SOCK_DGRAM, ICMP);
        if (conno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno);
            goto sock_ipopt_kill;
        }
        status = setsockopt(conno, IPPROTO_IP, IP_OPTIONS, ipOption, ipOptLen);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end0;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        socka.sin_port        = 0;
        socka.sin_addr.s_addr = inet_addr(target);


        Nprintf("Pinging %s with %d bytes of data:\n\n", target, size);
        for ( i1=1; i1 <= loop; i1++ ) {
            hdr.type = IC_ECHO;
            hdr.scode = 0;
            hdr.chksum = 0;
            ulp = (unsigned long *)hdr.param;
            ulp[0] = (unsigned long)(id << 16) | (unsigned long)(seqnum + tlen);
            ulp[1] = 2;
            ulp[2] = 3;
            ulp[3] = 4;
            ulp[4] = 5;
            ulp[5] = 6;

            memcpy(testbuf, (char *)&hdr, sizeof(struct ICMPhdr));
            errno = 0;

            ul1 = TimeMS();
            status = sendto(conno, testbuf, (size + 8), 0, (struct sockaddr *)&socka, sizeof(socka));
            if (status < 0){
                Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                break;
            }

            SOCKET_RXTOUT(conno, 1000);
            errno = 0;
            status = recvfrom(conno, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka, &i2);
            ul2 = TimeMS();
            if (status < 0) {
                if (errno == ETIMEDOUT) {
                    Nprintf("Request timed out.\n");
                }
                else {
                    Nprintf("ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    break;
                }
            }
            else {
                rphdr = (struct ICMPhdr *)testbuf;
                if (rphdr->type == IC_EREP) {
                    Nprintf("Reply from %s: bytes=%d time=%lums count=%d\n",
                        target, status - 8, ul2 - ul1, i1);
                }
                else {
                    Nprintf("ICMP message: type=%d code=%d\n", rphdr->type, rphdr->scode);
                }
            }
            tlen += size;

            if (i1 < loop)
                while (TimeMS() - ul1 < 1000)
                    YIELD();
        }

sock_ipopt_end0:
        closesocket(conno);

    }
    else if (*mode == 't') {
        conno = socket(PF_INET, SOCK_STREAM, 0);
        if (conno < 0) {
            Nprintf("ERROR: socket(%d) returns[%d]\n", conno, conno);
            goto sock_ipopt_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end1;
        }

        status = setsockopt(conno, IPPROTO_IP, IP_OPTIONS, ipOption, ipOptLen);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end1;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        socka.sin_port        = htons(herport);
        socka.sin_addr.s_addr = inet_addr(target);
        status = connect(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: connect(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end1;
        }

        while(1) {
            YIELD();
#if (MT != 0)
            Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf("input: command[*]\n");
#endif
            Nprintf("%c: write\n", CC_WRITE);
            Nprintf("%c: end\n", CC_END);
            Nprintf("->");
            while ((cc = data_get(task_id)) == 0)
                YIELD();
#if (MT == 0)
            Nprintf("%c\n", cc);
#endif
            if (cc == CC_WRITE) {
                errno = 0;
                memset(testbuf, 0, 100);
                Nsprintf(testbuf, " IP-OPTION-DATA%d", i1++);
                i2 = strlen(testbuf);
#ifdef SAKA_DEB_IP_IPOPT_NTTSK_WT
                status = send(conno, testbuf, 5793, 0);
#else
                status = send(conno, testbuf, i2, 0);
#endif
                if (status < 0){
                    Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    goto sock_ipopt_end1;
                }
                else {
                    Nprintf(" send(%d) -> [%s]\n", status, testbuf);
                }
                SOCKET_RXTOUT(conno, READ_WAIT);
                memset(testbuf, 0, 100);
                status = recv(conno, testbuf, i2, 0);
                if (status < 0){
                    Nprintf(" ERROR: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else if (status == 0) {
                    Nprintf(" EOF: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else {
                    Nprintf(" recv(%d) -> [%s]\n", status, testbuf);
                }
            }
            else if (cc == CC_END) {
                goto sock_ipopt_end1;
            }
        }

sock_ipopt_end1:
        closesocket(conno);

    }
    else if (*mode == 'u') {

        conno = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno);
            goto sock_ipopt_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end2;
        }

        status = setsockopt(conno, IPPROTO_IP, IP_OPTIONS, ipOption, ipOptLen);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_ipopt_end2;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        socka.sin_port        = htons(herport);
        socka.sin_addr.s_addr = inet_addr(target);
        while(1) {
            YIELD();
#if (MT != 0)
            Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf("input: command[*]\n");
#endif
            Nprintf("%c: write\n", CC_WRITE);
            Nprintf("%c: end\n", CC_END);
            Nprintf("->");
            while ((cc = data_get(task_id)) == 0)
                YIELD();
#if (MT == 0)
            Nprintf("%c\n", cc);
#endif
            if (cc == CC_WRITE) {
                errno = 0;
                Nsprintf(testbuf, " IP-OPTION-DATA%d", i1++);
                i2 = strlen(testbuf);
                status = sendto(conno, testbuf, i2, 0, (struct sockaddr *)&socka, sizeof(socka));
                if (status < 0){
                    Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    goto sock_ipopt_end2;
                }
                else {
                    Nprintf(" sendto(%d) -> [%s]\n", status, testbuf);
                }
                SOCKET_RXTOUT(conno, READ_WAIT);
                status = recvfrom(conno, testbuf, i2, 0, (struct sockaddr *)&socka, &i3);
                if (status < 0){
                    Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else {
                    Nprintf(" recvfrom(%d) -> [%s]\n", status, testbuf);
                }
            }
            else if (cc == CC_END) {
                goto sock_ipopt_end2;
            }
        }

sock_ipopt_end2:
        closesocket(conno);
    }

#if DEBUG_LEVEL >= 5
    Nprintf("socket function test end\n");
#endif

sock_ipopt_kill:
#if (MT != 0)
    relmem(testbuf);
sock_ipopt_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION sock_func(int argc, char **argv)
{
    char *name, *mode;
    unsigned short myport, herport;
    int comm, conno1, conno2, status, i1, i2, cc;
    unsigned long ul1, ul2;
    struct sockaddr_in socka1, socka2;
    struct hostent *hostent;
    struct ip_mreq mreq;
    struct linger linger_d;
    struct timeval timeout;
    fd_set readfds, writefds, exceptfds;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_func_kill2;
    }
#endif

    if (argc < 2) {
        comm_sock_func();
        goto sock_func_kill;
    }
    comm = atoi(argv[1]);
    name = argv[2];

    if (comm >= 2) {
        if (argc < 4) {
            comm_sock_func();
            goto sock_func_kill;
        }
        myport  = (unsigned short)atoi(argv[3]);
        herport = (unsigned short)atoi(argv[4]);
    }

    switch (comm) {
    case SF_GET_HOST_NAME:
        Nprintf("gethostbyname(%s) -> ", name);
        memset((char *)&socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        hostent = gethostbyname(name);
        if (hostent == 0)
            Nprintf("ERROR: gethostbyname fails\n");
        else
            Nprintf("OK: addr[%03d.%03d.%03d.%03d]\n",
                 (unsigned char)hostent->h_addr_list[0][0],
                 (unsigned char)hostent->h_addr_list[0][1],
                 (unsigned char)hostent->h_addr_list[0][2],
                 (unsigned char)hostent->h_addr_list[0][3]
            );
        break;
    case SF_GET_HOST_ADDR:
        Nprintf("gethostbyaddr(%s) -> ", name);
        socka1.sin_addr.s_addr = inet_addr(name);
        hostent = gethostbyaddr((char *)&socka1.sin_addr, Iid_SZ, AF_INET);
        if (hostent == 0)
            Nprintf("ERROR: gethostbyaddr fails\n");
        else
            Nprintf("OK: name[%s]\n", hostent->h_name);
        break;
    case SF_GET_SOCK_PEER_NAME:
        conno1 = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }
        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        SOCKET_NOBLOCK(conno1);
        errno = 0;
        Nprintf("waiting UDP packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");

        while(1) {
            status = recvfrom(conno1, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka1, &i1);
            if ((errno != EWOULDBLOCK) && (status < 0)) {
                Nprintf("ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                break;
            }
            else if (status > 0) {
                Nprintf(" recvfrom(%d) -> [%d]byte\n", conno1, status);

                Nprintf("getsockname(%d) -> ", conno1);
                memset((char *) &socka1, 0, sizeof(socka1));
                status = getsockname(conno1, (struct sockaddr *)&socka1, &i1);
                if (status < 0) {
                    Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                    break;
                }
                Nprintf("OK: myport[%d] ipaddr[%03d.%03d.%03d.%03d]\n",
                    socka1.sin_port,
                    (unsigned char)(socka1.sin_addr.s_addr >> 24),
                    (unsigned char)(socka1.sin_addr.s_addr >> 16),
                    (unsigned char)(socka1.sin_addr.s_addr >> 8),
                    (unsigned char)(socka1.sin_addr.s_addr)
                );

                Nprintf("getpeername(%d) -> ", conno1);
                memset((char *) &socka1, 0, sizeof(socka1));
                status = getpeername(conno1, (struct sockaddr *)&socka1, &i1);
                if (status < 0) {
                    Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                    break;
                }
                Nprintf("OK: herport[%d] heriid[%03d.%03d.%03d.%03d]\n",
                    socka1.sin_port,
                    (unsigned char)(socka1.sin_addr.s_addr >> 24),
                    (unsigned char)(socka1.sin_addr.s_addr >> 16),
                    (unsigned char)(socka1.sin_addr.s_addr >> 8),
                    (unsigned char)(socka1.sin_addr.s_addr)
                );
            }
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    break;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        goto sock_func_end1;
    case SF_SET_OPT_IP:
        if (argc < 5) {
            comm_sock_func();
            goto sock_func_kill;
        }

        conno1 = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *)&socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        memset((char *)&mreq, 0, sizeof(struct ip_mreq));
        memset((char *)&socka2, 0, sizeof(struct sockaddr_in));

        mreq.imr_interface.s_addr = netconf[0].Iaddr.l;
        Nprintf("setsockopt(%d, IP_MULTICAST_IF) -> ", conno1);
        status = setsockopt(conno1, IPPROTO_IP, IP_MULTICAST_IF,
             (char *)&mreq.imr_interface.s_addr, sizeof(struct in_addr));
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        i1 = sizeof(struct in_addr);
        Nprintf("getsockopt(%d, IP_MULTICAST_IF) -> ", conno1);
        status = getsockopt(conno1, IPPROTO_IP, IP_MULTICAST_IF,
             (char *)&socka2.sin_addr.s_addr, &i1);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        else if (socka2.sin_addr.s_addr == mreq.imr_interface.s_addr) {
            Nprintf("OK: set[%03d.%03d.%03d.%03d] get[%03d.%03d.%03d.%03d]\n",
                (unsigned char)(mreq.imr_interface.s_addr >> 24),
                (unsigned char)(mreq.imr_interface.s_addr >> 16),
                (unsigned char)(mreq.imr_interface.s_addr >> 8),
                (unsigned char)(mreq.imr_interface.s_addr),
                (unsigned char)(socka2.sin_addr.s_addr >> 24),
                (unsigned char)(socka2.sin_addr.s_addr >> 16),
                (unsigned char)(socka2.sin_addr.s_addr >> 8),
                (unsigned char)(socka2.sin_addr.s_addr)
            );
        }
        else {
            Nprintf("ERROR: address different!!\n");
            goto sock_func_end1;
        }

        mreq.imr_multiaddr.s_addr = inet_addr(name);
        Nprintf("setsockopt(%d, IP_ADD_MEMBERSHIP, [%s]) -> ", conno1, name);
        status = setsockopt(conno1, IPPROTO_IP, IP_ADD_MEMBERSHIP, (char *)&mreq, sizeof(mreq));
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        SOCKET_NOBLOCK(conno1);
        mode = argv[5];
        if (*mode == 'r') {
socf_mc_read:
            Nprintf("waiting Multicact packet ...\n");
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: leave\n", CC_DEL);
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");

            while (1) {
                i1 = sizeof(socka1);
                status = recvfrom(conno1, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka1, &i1);
                if ((errno != EWOULDBLOCK) && (status < 0)) {
                    Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                    goto sock_func_end1;
                }
                else if (status > 0) {
                    Nprintf(" recvfrom(%d) -> [%d]byte\n", conno1, status);
                    break;
                }
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_DEL)
                        goto socf_mc_leave;
                    if (cc == CC_END)
                        goto sock_func_end1;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
            }
        }
        else {
            while (1) {
socf_mc_write:
                Nprintf("waiting Multicact packet send ...\n");
#if (MT != 0)
                Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf(" input: command[*]\n");
#endif
                Nprintf(" %c: send\n", CC_WRITE);
                Nprintf(" %c: leave\n", CC_DEL);
                Nprintf(" %c: end\n", CC_END);
                Nprintf("->");

                while (1) {
                    YIELD();
                    if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                        Nprintf("%c\n", cc);
#endif
                        if (cc == CC_WRITE)
                            break;
                        if (cc == CC_DEL)
                            goto socf_mc_leave;
                        if (cc == CC_END)
                            goto sock_func_end1;
#if (MT == 0)
                        Nprintf("->");
#endif
                    }
                }
                socka1.sin_family      = AF_INET;
                socka1.sin_port        = htons(herport);
                socka1.sin_addr.s_addr = inet_addr(name);
                status = sendto(conno1, testbuf, RWSIZE, 0, (struct sockaddr *)&socka1, sizeof(socka1));
                if ((errno != EWOULDBLOCK) && (status < 0)) {
                    Nprintf("ERROR: sendto(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                    goto sock_func_end1;
                }
                else if (status > 0) {
                    Nprintf(" sendto(%d) -> [%d]byte\n", conno1, status);
                }
            }

        }
socf_mc_leave:
        Nprintf("setsockopt(%d, IP_DROP_MEMBERSHIP, [%s]) -> ", conno1, name);
        status = setsockopt(conno1, IPPROTO_IP, IP_DROP_MEMBERSHIP, (char *)&mreq, sizeof(mreq));
        if (status < 0)
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
        else
            Nprintf("OK\n");

        if (*mode == 'r')
            goto socf_mc_read;
        else
            goto socf_mc_write;
    case SF_SET_OPT_TCP:
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (!SOCKET_ISOPEN(conno1)) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        Nprintf("setsockopt(%d, TCP_NODELAY) -> ", conno1);
        status = setsockopt(conno1, IPPROTO_TCP, TCP_NODELAY, 0, 0);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        status = send(conno1, testbuf, 5841, 0);
        if (status < 0){
            Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }
        else {
            Nprintf(" send(%d) returns[%d]\n", conno1, status);
        }

        Nprintf("getsockopt(%d, TCP_NODELAY) -> ", conno1);
        i2 = sizeof(i2);
        status = getsockopt(conno1, IPPROTO_TCP, TCP_NODELAY, (char *)&i1, &i2);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);

        Nprintf("getsockopt(%d, TCP_MAXSEG) -> ", conno1);
        i2 = sizeof(i2);
        status = getsockopt(conno1, IPPROTO_TCP, TCP_MAXSEG, (char *)&i1, &i2);
        if (status < 0)
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
        else
            Nprintf("OK: conp->maxdat=[%d]\n", (unsigned short)i1);
        goto sock_func_end1;
    case SF_SET_OPT_SOCK_REUSE:
    case SF_SET_OPT_SOCK_BINDDEV:
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        conno2 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_end2;
        }

        Nprintf("setsockopt(%d, SO_REUSEADDR) -> ", conno2);
        status = setsockopt(conno2, SOL_SOCKET, SO_REUSEADDR, 0, 0);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno2, status, errno);
            goto sock_func_end2;
        }
        Nprintf("OK\n");

        memset((char *) &socka2, 0, sizeof(socka2));
        socka2.sin_family = AF_INET;
        socka2.sin_port   = htons(myport);
        status = bind(conno2, (struct sockaddr *)&socka2, sizeof(socka2));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno2, status, errno);
            goto sock_func_end2;
        }
        if (comm == SF_SET_OPT_SOCK_REUSE) {
            Nprintf("getsockopt(%d, SO_REUSEADDR) -> ", conno2);
            i2 = sizeof(i2);
            status = getsockopt(conno2, SOL_SOCKET, SO_REUSEADDR, (char *)&i1, &i2);
            if (status < 0) {
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            }
            else {
                Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);
                show_info(C_SHOW_CONN, -1);
            }
            goto sock_func_end2;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end2;
        }
        status = listen(conno2, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno2, status, errno);
            goto sock_func_end2;
        }

        Nprintf("setsockopt(%d, SO_BINDTODEVICE, [%s]) -> ", conno1, netconf[0].pname);
        status = setsockopt(conno1, SOL_SOCKET, SO_BINDTODEVICE, netconf[0].pname, 0);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end2;
        }
        Nprintf("OK\n");

        Nprintf("setsockopt(%d, SO_BINDTODEVICE, [%s]) -> ", conno2, netconf[1].pname);
        status = setsockopt(conno2, SOL_SOCKET, SO_BINDTODEVICE, netconf[1].pname, 0);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno2, status, errno);
            goto sock_func_end2;
        }
        Nprintf("OK\n");

        Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (!SOCKET_ISOPEN(conno1) || !SOCKET_ISOPEN(conno2)) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    goto sock_func_end2;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        Nprintf("waiting TCP packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        SOCKET_NOBLOCK(conno1);
        SOCKET_NOBLOCK(conno2);
        while(1) {
            errno = 0;
            status = recv(conno1, testbuf, BUFSIZE, 0);
            if ((errno != EWOULDBLOCK) && (status < 0)) {
                Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                break;
            }
            else if (status > 0) {
                Nprintf(" recv(%d) -> [%d]byte\n", conno1, status);
            }

            status = recv(conno2, testbuf, BUFSIZE, 0);
            if ((errno != EWOULDBLOCK) && (status < 0)) {
                Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno2, status, errno);
                break;
            }
            else if (status > 0) {
                Nprintf(" recv(%d) -> [%d]byte\n", conno2, status);
            }
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    break;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        goto sock_func_end2;
    case SF_SET_OPT_SOCK_KEEPA:
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (!SOCKET_ISOPEN(conno1)) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        Nprintf("setsockopt(%d, SO_KEEPALIVE) -> ", conno1);
        status = setsockopt(conno1, SOL_SOCKET, SO_KEEPALIVE, 0, 0);
        if (status < 0) {
            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        Nprintf("waiting send KEEPALIVE packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: next\n", CC_NEXT);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while(1) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_NEXT)
                    break;
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        Nprintf("getsockopt(%d, SO_KEEPALIVE) -> ", conno1);
        i2 = sizeof(i2);
        status = getsockopt(conno1, SOL_SOCKET, SO_KEEPALIVE, (char *)&i1, &i2);
        if (status < 0)
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
        else
            Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);
        goto sock_func_end1;
    case SF_SET_OPT_SOCK_OOBINL:
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (!SOCKET_ISOPEN(conno1)) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        Nprintf("setsockopt(%d, SO_OOBINLINE) -> ", conno1);
        status = setsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, 0, 0);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        Nprintf("waiting URG packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: set SO_OOBINLINE\n", CC_SET);
        Nprintf(" %c: get SO_OOBINLINE\n", CC_GET);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");

        SOCKET_NOBLOCK(conno1);
        while(1) {
            errno = 0;
            status = recv(conno1, testbuf, BUFSIZE, MSG_OOB);
            if ((errno != EWOULDBLOCK) && (errno != EOPNOTSUPP) && (status < 0)) {
                Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                break;
            }
            else if (status > 0) {
                Nprintf(" recv(%d) -> [%d]byte\n", conno1, status);
            }
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_GET) {
                    i2 = sizeof(i2);
                    Nprintf("getsockopt(%d, SO_OOBINLINE) -> ", conno1);
                    status = getsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, (char *)&i1, &i2);
                    if (status < 0) {
                        Nprintf("ERROR: returns[%d] errno[%d]\n",status, errno);
                        goto sock_func_end1;
                    }
                    Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);
                }
                else if (cc == CC_SET) {
                    Nprintf("setsockopt(%d, SO_OOBINLINE) -> ", conno1);
                    status = setsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, 0, 0);
                    if (status < 0) {
                        Nprintf("ERROR: returns[%d] errno[%d]\n",status, errno);
                        break;
                    }
                    Nprintf("OK\n");
                }
                else if (cc == CC_END) {
                    break;
                }
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        goto sock_func_end1;
    case SF_SET_OPT_SOCK_LINGER:
        if (argc < 6) {
            comm_sock_func();
            goto sock_func_kill;
        }
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        if (*argv[6] == 's') {
            status = listen(conno1, 0);
            if (status < 0){
                Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }

            Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            while (!SOCKET_ISOPEN(conno1)) {
                YIELD();
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_END)
                        goto sock_func_end1;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
            }
        }
        else {
            memset((char *) &socka1, 0, sizeof(socka1));
            socka1.sin_family      = AF_INET;
            socka1.sin_port        = htons(herport);
            socka1.sin_addr.s_addr = inet_addr(name);
            status = connect(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
            if (status < 0) {
                Nprintf(" ERROR: connect(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
        }

        linger_d.l_onoff  = 1;
        linger_d.l_linger = atoi(argv[5]);
        Nprintf("setsockopt(%d, SO_LINGER, l_linger=[%d]) -> ", conno1, linger_d.l_linger);
        status = setsockopt(conno1, SOL_SOCKET, SO_LINGER, (char *)&linger_d, sizeof(struct linger));
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        Nprintf("getsockopt(%d, SO_LINGER) -> ", conno1);
        i2 = sizeof(struct linger);
        status = getsockopt(conno1, SOL_SOCKET, SO_LINGER, (char *)&linger_d, &i2);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK: l_onoff=[%d] l_linger=[%d]\n", linger_d.l_onoff, linger_d.l_linger);

        Nprintf("waiting closesocket start...\n");
#if (MT != 0)
    Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
    Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: start\n", CC_NEXT);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (1) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_NEXT)
                    break;
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        if (linger_d.l_linger == 0) {
            closesocket(conno1);
        }
        else {
            Nprintf("closesocket start\n");
            ul1 = TimeMS();
            closesocket(conno1);
            ul2 = TimeMS();
            Nprintf("closesocket end / waited [%lu]ms\n", ul2 - ul1);
            goto sock_func_kill;
        }
        goto sock_func_end1;
    case SF_SET_OPT_SOCK_DONTRT:
    case SF_SET_OPT_SOCK_BCAST:
    case SF_FCTL_NDELAY:
        conno1 = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno2, status, errno);
            goto sock_func_end1;
        }

        switch (comm) {
        case SF_SET_OPT_SOCK_DONTRT:
            Nprintf("setsockopt(%d, SO_DONTROUTE) -> ", conno1);
            status = setsockopt(conno1, SOL_SOCKET, SO_DONTROUTE, 0, 0);
            if (status < 0) {
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                goto sock_func_end1;
            }
            Nprintf("OK\n");

            errno = 0;
            memset((char *) &socka1, 0, sizeof(socka1));
            socka1.sin_family      = AF_INET;
            socka1.sin_port        = htons(herport);
            socka1.sin_addr.s_addr = inet_addr(name);
            status = sendto(conno1, testbuf, RWSIZE, 0, (struct sockaddr *)&socka1, sizeof(socka1));
            if (errno != EHOSTUNREACH) {
                Nprintf("ERROR: sendto(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
            Nprintf("  sendto(%d) set errno [EHOSTUNREACH]\n", status);

            Nprintf("getsockopt(%d, SO_DONTROUTE) -> ", conno1);
            i2 = sizeof(i2);
            status = getsockopt(conno1, SOL_SOCKET, SO_DONTROUTE, (char *)&i1, &i2);
            if (status < 0)
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            else
                Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);
            break;
        case SF_SET_OPT_SOCK_BCAST:
            Nprintf("setsockopt(%d, SO_BROADCAST) -> ", conno1);
            status = setsockopt(conno1, SOL_SOCKET, SO_BROADCAST, 0, 0);
            if (status < 0) {
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                goto sock_func_end1;
            }
            Nprintf("OK\n");

            errno = 0;
            memset((char *) &socka1, 0, sizeof(socka1));
            socka1.sin_family      = AF_INET;
            socka1.sin_port        = htons(herport);
            socka1.sin_addr.s_addr = 0xFFFFFFFF;
            status = sendto(conno1, testbuf, RWSIZE, 0, (struct sockaddr *)&socka1, sizeof(socka1));
            if (status < 0) {
                Nprintf("ERROR: sendto(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
            Nprintf(" sendto(%d) -> [%d]byte\n", conno1, status);

            Nprintf("getsockopt(%d, SO_DONTROUTE) -> ", conno1);
            i2 = sizeof(i2);
            status = getsockopt(conno1, SOL_SOCKET, SO_BROADCAST, (char *)&i1, &i2);
            if (status < 0)
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            else
                Nprintf("OK: socp->sockopt=[0x%04X]\n", (unsigned short)i1);
            break;
        case SF_FCTL_NDELAY:
            Nprintf("fcntlsocket(%d, F_SETFL, O_NDELAY) -> ", conno1);
            errno = 0;
            status = fcntlsocket(conno1, F_SETFL, O_NDELAY);
            if (status < 0) {
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                goto sock_func_end1;
            }
            Nprintf("OK\n");

            status = recvfrom(conno1, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka1, &i1);
            if (errno != EWOULDBLOCK) {
                Nprintf("ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
            Nprintf("  recvfrom(%d) set errno [EWOULDBLOCK]\n", status);

            Nprintf("fcntlsocket(%d, F_GETFL, 0) -> ", conno1);
            status = fcntlsocket(conno1, F_GETFL, 0);
            if (status < 0) {
                Nprintf("ERROR: fcntlsocket(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
            Nprintf("OK: conp->txstat=[0x%04X]\n", (unsigned short)status);
            break;
        default:
            break;
        }
        goto sock_func_end1;
    case SF_IOCTL_ALL:
        conno1 = socket(PF_INET, SOCK_STREAM, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (!SOCKET_ISOPEN(conno1)) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        i1 = 1;
        errno = 0;
        Nprintf("ioctlsocket(%d, FIONBIO) -> ", conno1);
        status = ioctlsocket(conno1, FIONBIO, &i1);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        status = recv(conno1, testbuf, BUFSIZE, 0);
        if (errno != EWOULDBLOCK) {
            Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }
        Nprintf("  recvfrom(%d) set errno [EWOULDBLOCK]\n", status);

        Nprintf("waiting UDP packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: read\n", CC_NEXT);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (1) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_NEXT)
                    break;
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        i1 = 0;
        errno = 0;
        Nprintf("ioctlsocket(%d, FIONREAD) -> ", conno1);
        status = ioctlsocket(conno1, FIONREAD, &i1);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK : [%d]byte\n", i1);

        status = recv(conno1, testbuf, BUFSIZE, 0);
        if (status < 0) {
            Nprintf("ERROR: recvf(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }
        Nprintf("  recv(%d) -> [%d]byte\n", conno1, status);

        Nprintf("setsockopt(%d, SO_OOBINLINE) -> ", conno1);
        status = setsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, 0, 0);
        if (status < 0) {
            Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
            goto sock_func_end1;
        }
        Nprintf("OK\n");

        Nprintf("waiting URG packet ...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: set SO_OOBINLINE\n", CC_SET);
        Nprintf(" %c: get SO_OOBINLINE\n", CC_GET);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");

        SOCKET_NOBLOCK(conno1);
        while(1) {
            errno = 0;
            status = recv(conno1, testbuf, BUFSIZE, MSG_OOB);
            if ((errno != EWOULDBLOCK) && (errno != EOPNOTSUPP) && (status < 0)) {
                Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                break;
            }
            else if (status > 0) {
                Nprintf(" recv(%d) -> [%d]byte\n", conno1, status);
            }
            status = ioctlsocket(conno1, SIOCATMARK, &i1);
            if (i1 != 0) {
                Nprintf("ioctlsocket(%d, SIOCATMARK) -> OK\n", conno1);
                break;
            }
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_GET) {
                    i2 = sizeof(i2);
                    Nprintf("getsockopt(%d, SO_OOBINLINE) -> ", conno1);
                    status = getsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, (char *)&i1, &i2);
                    if (status < 0) {
                        Nprintf("ERROR: returns[%d] errno[%d]\n",status, errno);
                        break;
                    }
                    if (i1 == 0)
                        Nprintf("OFF\n");
                    else
                        Nprintf("ON\n");
                }
                else if (cc == CC_SET) {
                    Nprintf("setsockopt(%d, SO_OOBINLINE) -> ", conno1);
                    status = setsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, 0, 0);
                    if (status < 0) {
                        Nprintf("ERROR: returns[%d] errno[%d]\n",status, errno);
                        break;
                    }
                    Nprintf("OK\n");
                }
                else if (cc == CC_END) {
                    break;
                }
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }
        goto sock_func_end1;
    case SF_SELECTSOCK:
        if (argc < 6) {
            comm_sock_func();
            goto sock_func_kill;
        }
        mode = argv[5];
        comm = atoi(argv[6]);
        if (comm > 2) {
            comm_sock_func();
            goto sock_func_kill;
        }

        if (*mode == 't')
            i1 = SOCK_STREAM;
        else
            i1 = SOCK_DGRAM;

        conno1 = socket(PF_INET, i1, 0);
        if (conno1 < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno1);
            goto sock_func_kill;
        }

        memset((char *) &socka1, 0, sizeof(socka1));
        socka1.sin_family = AF_INET;
        socka1.sin_port   = htons(myport);
        status = bind(conno1, (struct sockaddr *)&socka1, sizeof(socka1));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        status = listen(conno1, 0);
        if (status < 0){
            Nprintf("ERROR: listen(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            goto sock_func_end1;
        }

        if (*mode == 't') {
            Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            while (!SOCKET_ISOPEN(conno1)) {
                YIELD();
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_END)
                        goto sock_func_end1;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
            }
        }

        ul1 = BUFSIZE;
        if (argc >= 6) {
            ul1 = (unsigned)atol(argv[7]);
        }

        Nprintf("waiting selectsocket() start...\n");
#if (MT != 0)
        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
        Nprintf(" input: command[*]\n");
#endif
        Nprintf(" %c: start\n", CC_NEXT);
        Nprintf(" %c: end\n", CC_END);
        Nprintf("->");
        while (1) {
            YIELD();
            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_NEXT)
                    break;
                if (cc == CC_END)
                    goto sock_func_end1;
#if (MT == 0)
                Nprintf("->");
#endif
            }
        }

        switch (comm) {
        case 0:
select_readfds:
            Nprintf("selectsocket(%d, readfds) ...\n", conno1);
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            if (*mode == 'u')
                Nprintf(" %c: send [herport + 1]\n", CC_WRITE);
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            while (1) {
                do {
                    timeout.tv_sec  = 1;
                    timeout.tv_usec = 0;
                    FD_ZERO(&readfds);
                    FD_SET(conno1, &readfds);
                    status = selectsocket(conno1 + 1, &readfds, 0, 0, &timeout);
                    if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                        Nprintf("%c\n", cc);
#endif
                        if (cc == CC_WRITE) {
                            if (*mode == 'u') {
                                socka1.sin_port = htons(connblo[conno1].herport + 1);
                                status = sendto(conno1, testbuf, 100, 0, (struct sockaddr *)&socka1, sizeof(socka1));
                                if (status < 0){
                                    Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                                    goto sock_func_end1;
                                }
                                Nprintf("  sendto(%d) -> [%d]byte\n", conno1, status);
                                goto select_readfds;
                            }
                        }
                        else if (cc == CC_END)
                            goto sock_func_end1;
#if (MT == 0)
                        Nprintf("->");
#endif
                    }
                }
                while ((status == 0) && !FD_ISSET(conno1, &readfds));

                if (status < 0) {
                    Nprintf("ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                    break;
                }

                if (*mode == 't') {
                    status = recv(conno1, testbuf, ul1, 0);
                    if (status <= 0) {
                        Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                        break;
                    }
                    else {
                        Nprintf(" recv(%d) -> [%d]byte\n", conno1, status);
                    }
                }
                else {
                    status = recvfrom(conno1, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka1, &i1);
                    if (status < 0) {
                        Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                        break;
                    }
                    else {
                        Nprintf(" recvfrom(%d) -> [%d]byte\n", conno1, status);
                    }
                }
            }
            goto sock_func_end1;
        case 1:
            Nprintf("selectsocket(%d, writefds) ...\n", conno1);
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
select_writefds:
            do {
                timeout.tv_sec  = 1;
                timeout.tv_usec = 0;
                FD_ZERO(&writefds);
                FD_SET(conno1, &writefds);
                status = selectsocket(conno1 + 1, 0, &writefds, 0, &timeout);
                if (data_get(task_id) != 0) {
                    goto sock_func_end1;
                }
            }
            while ((!SOCKET_TESTFIN(conno1)) && (status == 0) && !FD_ISSET(conno1, &writefds));

            if (status < 0) {
                Nprintf("ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }
            else if (SOCKET_TESTFIN(conno1)) {
                Nprintf("EOF: selectsocket(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }

            if (*mode == 't') {
                status = send(conno1, testbuf, ul1, 0);
                if (status <= 0)
                    Nprintf("ERROR: send(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                else
                    Nprintf(" send(%d) -> [%d]byte\n", conno1, status);
                goto select_writefds;
            }
            else {
                status = recvfrom(conno1, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka1, &i1);
                if (status < 0) {
                    Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                    goto sock_func_end1;
                }
                Nprintf(" recvfrom(%d) -> [%d]byte\n", conno1, status);

                status = sendto(conno1, testbuf, 100, 0, (struct sockaddr *)&socka1, sizeof(socka1));
                if (status < 0){
                    Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                }
                else {
                    Nprintf("  sendto(%d) -> [%d]byte\n", conno1, status);
                }
                goto sock_func_end1;
            }
        case 2:
            Nprintf("setsockopt(%d, SO_OOBINLINE) -> ", conno1);
            status = setsockopt(conno1, SOL_SOCKET, SO_OOBINLINE, 0, 0);
            if (status < 0) {
                Nprintf("ERROR: returns[%d] errno[%d]\n", status, errno);
                goto sock_func_end1;
            }
            Nprintf("OK\n");

            Nprintf("selectsocket(%d, exceptfds) ...\n", conno1);
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            do {
                timeout.tv_sec  = 1;
                timeout.tv_usec = 0;
                FD_ZERO(&exceptfds);
                FD_SET(conno1, &exceptfds);
                status = selectsocket(conno1 + 1, 0, 0, &exceptfds, &timeout);
                if (data_get(task_id) != 0) {
                    goto sock_func_end1;
                }
            }
            while ((status == 0) && !FD_ISSET(conno1, &exceptfds));

            if (status < 0) {
                Nprintf("ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno1, status, errno);
                goto sock_func_end1;
            }

            status = recv(conno1, testbuf, ul1, MSG_OOB);
            if (status <= 0)
                Nprintf("ERROR: recv(%d) returns[%d] errno[%d]\n", conno1, status, errno);
            else
                Nprintf(" recv(%d) -> [%d]byte\n", conno1, status);

            goto sock_func_end1;
        }
        goto sock_func_end1;
    default:
        break;
    }

sock_func_end2:
closesocket(conno2);

sock_func_end1:
closesocket(conno1);

sock_func_kill:
#if (MT != 0)
    relmem(testbuf);
sock_func_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION sock_rw(int argc, char **argv)
{
    char *mode, *protocol, *rw, *target;
    unsigned short myport, herport;
    int flag, size;
    int cc, conno, status, i1=0, i2;
    unsigned long ul1;
    struct CONNECT *conp;
    struct sockaddr_in socka;
    struct linger linger_d;
    struct {
        short s[2];
        unsigned long Iadd1, Iadd2;
    } pseudo;

    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_rw_kill2;
    }
#endif

    if (argc < 6) {
       comm_sock_rw();
       goto sock_rw_kill;
    }
    protocol = argv[1];
    mode     = argv[2];
    rw       = argv[3];
    target   = argv[4];
    myport   = (unsigned short)atoi(argv[5]);
    herport  = (unsigned short)atoi(argv[6]);

    if (argc >= 7)
        flag = atoi(argv[7]);
    else
        flag = 0;

    if (argc >= 8)
        size = atoi(argv[8]);
    else if (*rw == 'w')
        size = RWSIZE;
    else
        size = BUFSIZE;

    if (*protocol == 't') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP READ/WRITE\n");
#endif
send_rst1:
        conno = socket(PF_INET, SOCK_STREAM, 0);
        if (conno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno);
            goto sock_rw_kill;
        }

        conp = &connblo[conno];

        if (flag == SRW_LISTEN_RST) {
            conp->state = 1;
            conp->heriid.l = inet_addr(target);
            conp->myport  = htons(myport);
            conp->herport = htons(herport);
            conp->mywindow = 1460 * 4;
            conp->txseq = 1;
            conp->seqtoack = 1;
            pseudo.s[1] = NC2(6);
            pseudo.s[0] = conp->myport;
            pseudo.Iadd1 = conp->heriid.l;
            pseudo.Iadd2 = netconf[0].Iaddr.l;
            conp->pseudosum = Nchksum((unsigned short *) &pseudo, 12 >> 1);
            Nprintf("waiting send RST ...\n");
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: send\n", CC_WRITE);
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            while (1) {
                YIELD();
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_WRITE)
                        break;
                    if (cc == CC_END)
                        goto srw_end1;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
            }
send_rst2:
            linger_d.l_onoff  = 1;
            linger_d.l_linger = 0;
            status = setsockopt(conno, SOL_SOCKET, SO_LINGER, (char *)&linger_d, sizeof(struct linger));
            if (status < 0) {
                Nprintf("ERROR: setsockopt(%d, SO_LINGER) returns[%d] errno[%d]\n", conno, status, errno);
                goto srw_end1;
            }
            closesocket(conno);
            if (flag == 5)
                goto send_rst1;
            else
                goto sock_rw_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto srw_end1;
        }

        if (*mode == 'c') {
            memset((char *) &socka, 0, sizeof(socka));
            socka.sin_family      = AF_INET;
            socka.sin_port        = htons(herport);
            socka.sin_addr.s_addr = inet_addr(target);
            if (flag == SRW_SYNACK_RST) {
                SOCKET_NOBLOCK(conno);
                connect(conno, (struct sockaddr *)&socka, sizeof(socka));
                conp->heriid.l = 0x01010101;
                for (ul1 = TimeMS(); TimeMS() - ul1 < 2000; )
                    YIELD();
                goto srw_end1;
            }
            else if (flag == SRW_SYNACK_DSCRD) {
                SOCKET_NOBLOCK(conno);
                connect(conno, (struct sockaddr *)&socka, sizeof(socka));
                stop_process();
                goto srw_end1;
            }
            else {
                status = connect(conno, (struct sockaddr *)&socka, sizeof(socka));
                if (status < 0) {
                    Nprintf(" ERROR: connect(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    goto srw_end1;
                }
            }
            if (flag == SRW_ESTABL_RST)
                goto send_rst2;
        }
        else {
            if (flag == SRW_ACCEPT) {
                int conno2;

                status = listen(conno, 5);
                if (status < 0){
                    Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    goto srw_end1;
                }
                memset((char *) &socka, 0, sizeof(socka));
                socka.sin_family = AF_INET;
                socka.sin_port   = htons(myport);

                while (1) {
                    Nprintf("waiting accept() start ...\n");
#if (MT != 0)
                    Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                    Nprintf(" input: command[*]\n");
#endif
                    Nprintf(" %c: get [conp->icqcur] (LISTEN)\n", CC_GET);
                    Nprintf(" %c: start\n", CC_NEXT);
                    Nprintf(" %c: end\n", CC_END);
                    Nprintf("->");
                    while (1) {
                        YIELD();
                        if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                            Nprintf("%c\n", cc);
#endif
                            if (cc == CC_GET)
                                Nprintf("conp->icqcur=[%d]\n", conp->icqcur);
                            else if (cc == CC_NEXT)
                                break;
                            else if (cc == CC_END)
                                goto srw_end1;
#if (MT == 0)
                            Nprintf("->");
#endif
                        }
                    }
                    conno2 = accept(conno, (struct sockaddr *)&socka, &i1);
                    if ((conno2 < 0) && (errno != EWOULDBLOCK)) {
                        Nprintf(" ERROR: accept(%d) returns[%d] errno[%d]\n", conno, conno2, errno);
                        goto srw_end1;
                    }
                    else if (conno2 >= 0) {
                        Nprintf(" OK: accept(%d): conno2=[%d] conp->icqcur=[%d]\n", conno2, conno2,
                            connblo[conno2].icqcur);

                        Nprintf("waiting closesocket(%d) start ...\n", conno2);
#if (MT != 0)
                        Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                        Nprintf(" input: command[*]\n");
#endif
                        Nprintf(" %c: get [conp->icqcur] (LISTEN)\n", CC_GET);
                        Nprintf(" %c: start\n", CC_NEXT);
                        Nprintf("->");
                        while (1) {
                            YIELD();
                            if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                                Nprintf("%c\n", cc);
#endif
                                if (cc == CC_GET) {
                                    Nprintf("conp->icqcur=[%d]\n", conp->icqcur);
                                }
                                else if (cc == CC_NEXT) {
                                    closesocket(conno2);
                                    break;
                                }
#if (MT == 0)
                                Nprintf("->");
#endif
                            }
                        }

                    }
                }
            }
            else {
                status = listen(conno, 0);
                if (status < 0){
                    Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    goto srw_end1;
                }
                Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
                Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf(" input: command[*]\n");
#endif
                Nprintf(" %c: end\n", CC_END);
                Nprintf("->");
                while (!SOCKET_ISOPEN(conno)) {
                    YIELD();
                    if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                        Nprintf("%c\n", cc);
#endif
                        if (cc == CC_END)
                            goto srw_end1;
#if (MT == 0)
                        Nprintf("->");
#endif
                    }
                }
            }
        }

        if (*rw == 'w') {
            while(1) {
#if (MT != 0)
                Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf("input: command[*]\n");
#endif
                Nprintf("%c: set [MSG_OOB]\n", CC_SET);
                Nprintf("%c: del [MSG_OOB]\n", CC_DEL);
                Nprintf("%c: write\n", CC_WRITE);
                Nprintf("%c: send RST\n", CC_RST);
                Nprintf("%c: end\n", CC_END);
                Nprintf("->");
                while ((cc = data_get(task_id)) == 0)
                    YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                switch (cc) {
                case CC_SET:
                    flag |= MSG_OOB;
                    break;
                case CC_DEL:
                    flag &= ~MSG_OOB;
                    break;
                case CC_WRITE:
                    if (flag == MSG_OOB) {
                        memset((char *)&testbuf, 0, 100);
                        Nsprintf(testbuf, " URG-DATA%d", i1++);
                        size = strlen(testbuf);
                    }
                    else if (flag == SRW_IPOPT) {
                        memset((char *)&testbuf, 0, 100);
                        Nsprintf(testbuf, " IP-OPTION-DATA%d", i1++);
                        size = strlen(testbuf);
                    }
                    status = send(conno, testbuf, size, flag);
                    if (status < 0){
                        Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto srw_end1;
                    }
                    else {
                        if ((flag == MSG_OOB) || (flag == SRW_IPOPT))
                            Nprintf(" send(%d) returns[%d] [%s]\n", conno, status, testbuf);
                        else
                            Nprintf(" send(%d) returns[%d]\n", conno, status);

                    }
                    break;
                case CC_RST:
                    goto send_rst2;
                case CC_END:
                    goto srw_end1;
                }
            }
        }
        else {
            SOCKET_NOBLOCK(conno);
            while(1) {
#if (MT != 0)
                Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf(" input: command[*]\n");
#endif
                if (flag == MSG_PEEK)
                    Nprintf(" %c: set [MSG_PEEK]\n", CC_SET);
                else if (flag == MSG_OOB)
                    Nprintf(" %c: set [SO_OOBINLINE]\n", CC_SET);
                Nprintf(" %c: send [RST]\n", CC_RST);
                Nprintf(" %c: read\n", CC_READ);
                Nprintf(" %c: end\n", CC_END);
                Nprintf("->");
                while ((cc = data_get(task_id)) == 0)
                     YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_READ) {
                    status = recv(conno, testbuf, size, flag);
                    if ((errno != EWOULDBLOCK) && (status < 0)) {
                        Nprintf(" ERROR: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto srw_end1;
                    }
                    else if (status == 0){
                        Nprintf(" EOF: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto srw_end1;
                    }
                    else {
                        Nprintf(" recv(%d) -> [%d]byte\n", conno, status);
                    }
                }
                else if (cc == CC_SET) {
                    if (flag == MSG_PEEK) {
                        flag ^= MSG_PEEK;
                        Nprintf("  flag=[0x%04X]\n", flag);
                    }
                    else if (flag == MSG_OOB) {
                        status = setsockopt(conno, SOL_SOCKET, SO_OOBINLINE, 0, 0);
                        if (status < 0) {
                            Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n",
                                conno, status, errno);
                            goto srw_end1;
                        }
                       i2 = sizeof(i2);
                        status = getsockopt(conno, SOL_SOCKET, SO_OOBINLINE, (char *)&i1, &i2);
                        if (status < 0) {
                            Nprintf("ERROR: getsockopt(%d) returns[%d] errno[%d]\n",
                                conno, status, errno);
                            goto srw_end1;
                        }
                        Nprintf("  socp->sockopt=[0x%04X]\n", (unsigned short)i1);
                    }
                }
                else if (cc == CC_RST) {
                    goto send_rst2;
                }
                else if (cc == CC_END) {
                    goto srw_end1;
                }
            }
        }

srw_end1:
        closesocket(conno);

#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP READ/WRITE END\n");
#endif
    }
    else if (*protocol == 'u') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP READ/WRITE\n");
#endif
        conno = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno < 0) {
            Nprintf(" ERROR: socket() returns[%d]\n", conno);
            goto sock_rw_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto srw_end2;
        }

        memset((char *) &socka, 0, sizeof(socka));

        if (*rw == 'w') {
            while(1) {
                YIELD();
#if (MT != 0)
                Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf("input: command[*]\n");
#endif
                Nprintf("%c: write\n", CC_WRITE);
                Nprintf("%c: loop\n", CC_LOOP);
                Nprintf("%c: end\n", CC_END);
                Nprintf("->");
                while ((cc = data_get(task_id)) == 0)
                    YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if ((cc == CC_WRITE) || (cc == CC_LOOP)) {
sock_rw_retry2:
                    socka.sin_family      = AF_INET;
                    socka.sin_port        = htons(herport);
                    socka.sin_addr.s_addr = inet_addr(target);
                    status = sendto(conno, testbuf, size, flag, (struct sockaddr *)&socka, sizeof(socka));
                    if (status < 0){
                        Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto srw_end2;
                    }
                    else {
                        if (cc == CC_LOOP) {
                             YIELD();
                             if (data_get(task_id) != 0) {
                                 goto srw_end2;
                             }
                             goto sock_rw_retry2;
                        }
                        Nprintf(" sendto(%d) returns[%d]\n", conno, status);
                    }
                }
                else if (cc == CC_END) {
                    goto srw_end2;
                }
            }
        }
        else {
            SOCKET_NOBLOCK(conno);
            while(1) {
#if (MT != 0)
                Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
                Nprintf(" input: command[*]\n");
#endif
                Nprintf(" %c: read\n", CC_READ);
                Nprintf(" %c: end\n", CC_END);
                Nprintf("->");
                while ((cc = data_get(task_id)) == 0)
                    YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_READ) {
                    status = recvfrom(conno, testbuf, size, flag, (struct sockaddr *)&socka, &i1);
                    if ((errno != EWOULDBLOCK) && (status < 0)) {
                        Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto srw_end2;
                    }
                    else if (status > 0) {
                        Nprintf(" recvfrom(%d) -> [%d]byte\n", conno, status);
                    }
                }
                else if (cc == CC_END) {
                    goto srw_end2;
                }
            }
        }

srw_end2:
        closesocket(conno);

#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP READ/WRITE END\n");
#endif
    }

sock_rw_kill:
#if (MT != 0)
    relmem(testbuf);
sock_rw_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION sock_tcp(int argc, char **argv)
{
    char *mode;
    char *target;
    unsigned short myport, herport;
    int cc;
    int conno, sconno;
    int status, i1, i2=0;
    int patarn, prm1, prm2, prm3, prm4, prm5, prm6=0;
    unsigned long ul1, ul2=0, ul3=0, ul4=0;
    struct sockaddr_in socka;
    struct timeval timeout;
    fd_set readfds, writefds;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_tcp_kill2;
    }
#endif

    if (argc < 9) {
        if (*argv[1] == 's')
            comm_sock_tcp_serv();
        else if (*argv[1] == 'c')
            comm_sock_tcp_clnt();
        else
            Nprintf("argument invalid\n");
        goto sock_tcp_kill;
    }
    mode    = argv[1];
    target  = argv[2];
    myport  = (unsigned short)atoi(argv[3]);
    herport = (unsigned short)atoi(argv[4]);
    patarn  = atoi(argv[5]);
    prm1  = atoi(argv[6]);
    prm2  = atoi(argv[7]);
    prm3  = atoi(argv[8]);
    prm4  = atoi(argv[9]);
    if (argc > 10)
        prm6 = atoi(argv[11]);

    if (*mode == 's') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP SERVER\n");
#endif
        if (argc > 9)
            prm5 = atoi(argv[10]) * 1000;
        else
            prm5 = READ_WAIT;
st_next1:
#if DEBUG_LEVEL >= 3
        Nprintf("\npatarn[%d]", patarn);
#endif
        ul1 = (1 << patarn);

        sconno = socket(PF_INET, SOCK_STREAM, 0);
        if (sconno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", sconno);
            goto sock_tcp_kill;
        }

#if 1
        status = setsockopt(sconno, SOL_SOCKET, SO_REUSEADDR, 0, 0);
        if (status < 0) {
            Nprintf(" ERROR: setsockopt(%d) returns[%d] errno[%d]\n", sconno, status, errno);
            goto st_end2;
        }
#endif

#if DEBUG_LEVEL >= 3
        Nprintf(" -> bind(%d)", sconno);
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(sconno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", sconno, status, errno);
            goto st_end2;
        }

        if (ul1 & 0x000F) {
            i1 = 2;
        }
        else {
            i1 = 0;
        }

#if DEBUG_LEVEL >= 3
        Nprintf(" -> listen()");
#endif
        status = listen(sconno, i1);
        if (status < 0){
            Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", sconno, status, errno);
            goto st_end2;
        }

        SOCKET_RXTOUT(sconno, (READ_WAIT/3));
        if (ul1 & 0x000F) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> accept()\n");
#endif
st_accept:
            conno = accept(sconno, (struct sockaddr *)&socka, &i1);
            if (errno == EWOULDBLOCK) {
                errno = 0;
                if (data_get(task_id) != 0) {
                    goto st_end2;
                }
                goto st_accept;
            }
            if (conno < 0){
                Nprintf(" ERROR: accept(%d) returns[%d] errno[%d]\n", sconno, conno, errno);
                goto st_end2;
            }
        }
        else if (ul1 & 0x00F0) {
             conno = sconno;
        }

        if (ul1 & 0x0033) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> selectsocket()");
#endif
            do {
                timeout.tv_sec  = (READ_WAIT / 3000);
                timeout.tv_usec = 0;
                FD_ZERO(&readfds);
                FD_SET(conno, &readfds);
                i2 = 0;
                i2 = selectsocket(conno + 1, &readfds, 0, 0, &timeout);
                if (data_get(task_id) != 0) {
                    prm2 = 0;
                    goto st_end1;
                }
            }
            while ((i2 == 0) && !FD_ISSET(conno, &readfds));
            if (i2 <= 0) {
                Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                prm2 = 0;
                goto st_end1;
            }
        }
#if DEBUG_LEVEL >= 3
        Nprintf("\n");
#endif
        SOCKET_RXTOUT(conno, prm5);
        while (1) {
st_rw1:
            if (prm1 == 4) {
                while(1) {
                    YIELD();
#if (MT != 0)
                    Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
                    Nprintf("input: command[*]\n");
#endif
                    Nprintf("%c: recv\n", CC_READ);
                    Nprintf("%c: end\n", CC_END);
                    Nprintf("->");
                    while ((cc = data_get(task_id)) == 0)
                        YIELD();
                        Nprintf("%c\n", cc);
                    if (cc == CC_END)
                        goto st_end1;
                    if (cc == CC_READ)
                        break;
                }
            }
st_read:
            status = recv(conno, testbuf, BUFSIZE, 0);
            if (status <= 0){
                if (status == 0) {
                    Nprintf(" EOF: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else {
                    Nprintf(" ERROR: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                prm2 = 0;
                goto st_end1;
            }
            else if (prm6 != 0) {
                Nprintf(" -> recv(%d) -> [%d]byte\n", conno, status);
            }
            if (prm4 == 0) {
                if ((cc = data_get(task_id)) != 0) {
                    if (cc == CC_END)
                        goto st_end1;
                    goto st_rw1;
                }
                goto st_read;
            }

            switch (prm1) {
            case 1:
            case 3:
                if (ul1 & 0x0055) {
#if DEBUG_LEVEL >= 3
                    Nprintf(" -> selectsocket()");
#endif
                    do {
                        timeout.tv_sec  = (READ_WAIT / 3000);
                        timeout.tv_usec = 0;
                        FD_ZERO(&writefds);
                        FD_SET(conno, &writefds);
                        i2 = 0;
                        i2 = selectsocket(conno + 1, 0, &writefds, 0, &timeout);
                        if (data_get(task_id) != 0) {
                            prm2 = 0;
                            goto st_end1;
                        }
                    }
                    while ((i2 == 0) && !FD_ISSET(conno, &writefds));
                    if (i2 <= 0) {
                        Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                        prm2 = 0;
                        goto st_end1;
                    }
                }
                status = send(conno, testbuf, status, 0);
                if (status < 0){
                    Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else if (prm6 != 0) {
                    Nprintf(" -> send(%d) returns[%d]\n", conno, status);
                }
                if (prm1 == 1) {
                    goto st_end1;
                }
                break;
            case 2:
                if (status > 0)
                    ul4 += status;
                break;
            case 4:
                continue;
            default:
                prm2 = 0;
                goto st_end1;
            }
            if (data_get(task_id) != 0) {
                prm2 = 0;
                break;
            }
        }
st_end1:
        if (ul1 & 0x000F) {
            closesocket(conno);
        }

        if ((ul1 & 0x000F) && (++ul3 < prm4)) {
            goto st_accept;
        }
        ul3 = 0;

        if ((prm2 == 1) && (patarn < 7)) {
             if (++ul2 == prm3) {
                  patarn++;
                  ul2 = 0;
             }
             closesocket(sconno);
             goto st_next1;
        }
st_end2:
        if (prm1 == 2)
            Nprintf(" -> [%d]byte recved\n", ul4);

        closesocket(sconno);

#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP SERVER END\n");
#endif
    }
    else if (*mode == 'c') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP CLIENT\n");
#endif
        if (argc > 9)
            prm5 = atoi(argv[10]);
        else
            prm5 = RWSIZE;
st_next2:
#if DEBUG_LEVEL >= 3
        Nprintf("\npatarn[%d]", patarn);
#endif
        ul1 = (1 << patarn);

        conno = socket(PF_INET, SOCK_STREAM, 0);
        if (conno < 0) {
            Nprintf(" ERROR: socket() returns[%d]\n", conno);
            goto sock_tcp_kill;
        }

#if 1
        status = setsockopt(conno, SOL_SOCKET, SO_REUSEADDR, 0, 0);
        if (status < 0) {
            Nprintf(" ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto st_end2;
        }
#endif

#if DEBUG_LEVEL >= 3
        Nprintf(" -> bind(%d)", conno);
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            prm1 = 0;
            goto st_end3;
        }

#if DEBUG_LEVEL >= 3
        Nprintf(" -> connect()\n");
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        socka.sin_port        = htons(herport);
        socka.sin_addr.s_addr = inet_addr(target);
        status = connect(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: connect(%d) returns[%d] errno[%d]\n", conno, status, errno);
            prm1 = 0;
            goto st_end3;
        }

        if (ul1 & 0x0003) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> selectsocket()");
#endif
            do {
                timeout.tv_sec  = (READ_WAIT / 3000);
                timeout.tv_usec = 0;
                FD_ZERO(&writefds);
                FD_SET(conno, &writefds);
                i2 = 0;
                i2 = selectsocket(conno + 1, 0, &writefds, 0, &timeout);
                if (data_get(task_id) != 0) {
                    prm1 = 0;
                    goto st_end1;
                }
            }
            while ((i2 == 0) && !FD_ISSET(conno, &writefds));
            if (i2 <= 0) {
                Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                prm1 = 0;
                goto st_end3;
            }
        }

        SOCKET_RXTOUT(conno, READ_WAIT);
        while (1) {
st_rw2:
            status = send(conno, testbuf, prm5, 0);
            if (status < 0){
                Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno, status, errno);
                prm1 = 0;
                goto st_end3;
            }
            else if (prm6 != 0) {
                Nprintf(" -> send(%d)\n", status);
            }
            switch (prm1) {
            case 1:
            case 3:
                if (ul1 & 0x0005) {
#if DEBUG_LEVEL >= 3
                    Nprintf(" -> selectsocket()");
#endif
                    do {
                        timeout.tv_sec  = (READ_WAIT / 3000);
                        timeout.tv_usec = 0;
                        FD_ZERO(&readfds);
                        FD_SET(conno, &readfds);
                        i2 = 0;
                        i2 = selectsocket(conno + 1, &readfds, 0, 0, &timeout);
                        if (data_get(task_id) != 0) {
                            prm1 = 0;
                            goto st_end1;
                        }
                    }
                    while ((i2 == 0) && !FD_ISSET(conno, &readfds));
                    if (i2 <= 0) {
                        Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                        prm1 = 0;
                        goto st_end3;
                    }
                }

                status = recv(conno, testbuf, BUFSIZE, 0);
                if (status <= 0){
                    if (status == 0) {
                        Nprintf(" EOF: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    else {
                        Nprintf(" ERROR: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    prm1 = 0;
                    goto st_end3;
                }
                else if (prm6 != 0) {
                    Nprintf(" -> recv(%d)\n", status);
                }
                if (++ul3 < prm4) {
                    goto st_rw2;
                }
                ul3 = 0;
                if (prm1 == 1) {
                    goto st_end3;
                }
                break;
            case 2:
                break;
            default:
                prm1 = 0;
                goto st_end3;
            }
            if (data_get(task_id) != 0) {
                prm1 = 0;
                break;
            }
        }
st_end3:
        closesocket(conno);

        if ((prm2== 1) && (patarn < 3)) {
             if (++ul2 == prm3) {
                  patarn++;
                  ul2 = 0;
             }
             goto st_next2;
        }
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP CLIENT END\n");
#endif
    }

sock_tcp_kill:
#if (MT != 0)
    relmem(testbuf);
sock_tcp_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION sock_udp(int argc, char **argv)
{
    char *mode;
    char *target;
    unsigned short myport, herport;
    int cc;
    int conno, sconno;
    int status, i1, i2=0;
    int patarn, prm1, prm2, prm3, prm4, prm5=READ_WAIT, prm6=0;
    unsigned long ul1, ul2=0, ul3=0;
    struct sockaddr_in socka;
    struct timeval timeout;
    struct msghdr msg;
    fd_set readfds, writefds;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_udp_kill2;
    }
#endif

    if (argc < 9) {
        if (*argv[1] == 's')
            comm_sock_udp_serv();
        else if (*argv[1] == 'c')
            comm_sock_udp_clnt();
        else
            Nprintf("argument invalid\n");
        goto sock_udp_kill;
    }
    mode    = argv[1];
    target  = argv[2];
    myport  = (unsigned short)atoi(argv[3]);
    herport = (unsigned short)atoi(argv[4]);
    patarn  = atoi(argv[5]);
    prm1  = atoi(argv[6]);
    prm2  = atoi(argv[7]);
    prm3  = atoi(argv[8]);
    prm4  = atoi(argv[9]);
    if (argc > 10)
        prm6 = atoi(argv[11]);

    msg.msg_iov     = iovectbl;
    msg.msg_iovlen  = sizeof(iovectbl) / sizeof(struct iovec);
    msg.msg_name    = (char *)&socka;
    msg.msg_namelen = sizeof(struct sockaddr);

    if (*mode == 's') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP SERVER\n");
#endif
        if (argc > 9)
            prm5 = atoi(argv[10]) * 1000;
        else
            prm5 = READ_WAIT;
su_next1:
#if DEBUG_LEVEL >= 3
        Nprintf("\npatarn[%d]", patarn);
#endif
        ul1 = (1 << patarn);

        conno = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno);
            goto sock_udp_kill;
        }

#if DEBUG_LEVEL >= 3
        Nprintf(" -> bind()");
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf("ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            prm2 = 0;
            goto su_end1;
        }

        if (ul1 & 0x00FF) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> listen()");
#endif
            status = listen(conno, 0);
            if (status < 0){
                Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", conno, status, errno);
                prm2 = 0;
                goto su_end1;
            }
        }

        if (ul1 & 0x0F0F) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> selectsocket()");
#endif
            do {
                timeout.tv_sec  = (READ_WAIT / 3000);
                timeout.tv_usec = 0;
                FD_ZERO(&readfds);
                FD_SET(conno, &readfds);
                i2 = 0;
                i2 = selectsocket(conno + 1, &readfds, 0, 0, &timeout);
                if (data_get(task_id) != 0) {
                    prm2 = 0;
                    goto su_end1;
                }
            }
            while ((i2 == 0) && !FD_ISSET(conno, &readfds));
            if (i2 <= 0) {
                Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                prm2 = 0;
                goto su_end1;
            }
        }
#if DEBUG_LEVEL >= 3
        Nprintf("\n");
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        socka.sin_port        = htons(herport);
        socka.sin_addr.s_addr = inet_addr(target);
        i1 = sizeof(socka);

        SOCKET_RXTOUT(conno, prm5);
        while (1) {
su_read1:
            if (ul1 & 0x3333) {
                status = recvfrom(conno, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka, &i1);
            }
            else {
                memset(msgbuf1, 0, RWSIZE);
                memset(msgbuf2, 0, RWSIZE);
                status = recvmsg(conno, &msg, 0);
            }
            if (status < 0){
                if (ul1 & 0x3333) {
                    Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else {
                    Nprintf(" ERROR: recvmsg(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                prm2 = 0;
                goto su_end1;
            }
            else if (prm6 != 0) {
                if (ul1 & 0x3333) {
                    Nprintf("recvfrom(%d)\n", status);
                }
                else {
                    Nprintf("recvmsg(%d)\n", status);
                    Nprintf(" msgbuf1[%s]\n", msgbuf1);
                    Nprintf(" msgbuf2[%s]\n", msgbuf2);
                }
            }

            switch (prm1) {
            case 1:
            case 3:
#ifndef VER_25900
#ifdef IPOPTIONS
            case 4:
                if (prm1 == 4) {
                    if (connblo[conno].IPOrxlen) {
                        struct CONNECT *conp = &connblo[conno];
                        unsigned char *cp = (unsigned char *)conp->IPOrxopt;
                        int len, pos, flg;
                        union {
                            char c[4];
                            short s[2];
                            unsigned long l;
                        } UL1;
                        switch (*cp) {
                        case 7:
                            Nprintf(" Record Route\n");
                            Nprintf("  length : [%d]\n", len = conp->IPOrxopt[1]);
                            Nprintf("  pointer: [%d]\n", conp->IPOrxopt[2]);
                            pos=3;
                            cp = (unsigned char *)&conp->IPOrxopt[pos];
                            while (pos < len) {
                                Nprintf("  IP addr: [%03d.%03d.%03d.%03d]\n",
                                    cp[0], cp[1], cp[2], cp[3]);
                                pos += 4;
                                cp  += 4;
                            }
                            break;
                        case 68:
                            Nprintf(" Internet Timestamp\n");
                            Nprintf("  length  : [%d]\n", len = conp->IPOrxopt[1]);
                            Nprintf("  pointer : [%d]\n", conp->IPOrxopt[2]);
                            Nprintf("  overflow: [%d]\n", conp->IPOrxopt[3] >> 4);
                            Nprintf("  flag    : [%d]\n", flg = (conp->IPOrxopt[3] & 0xF));
                            pos=4;
                            cp = (unsigned char *)&conp->IPOrxopt[pos];
                            switch (flg) {
                            case 0:
                                while (pos < len) {
                                    GETLONG(UL1, cp);
                                    Nprintf("  time   : [%10lu]\n", UL1.l);
                                    pos += 4;
                                    cp  += 4;
                                }
                                break;
                            case 1:
                            case 3:
                                while (pos < len) {
                                    Nprintf("  IP addr: [%03d.%03d.%03d.%03d]",
                                        cp[0], cp[1], cp[2], cp[3]);
                                    GETLONG(UL1, (cp + 4));
                                    Nprintf("  time: [%10lu]\n", UL1.l);
                                    pos += 8;
                                    cp  += 8;
                                }
                                break;
                            }
                            break;
                        case 131:
                        case 137:
                            Nprintf(" %s Source and Record Route\n",
                                *cp == 131 ? "Loose" : "Strict");
                            Nprintf("  length : [%d]\n", len = conp->IPOrxopt[1]);
                            Nprintf("  pointer: [%d]\n", conp->IPOrxopt[2]);
                            pos=3;
                            cp = (unsigned char *)&conp->IPOrxopt[pos];
                            while (pos < len) {
                                Nprintf("  IP addr: [%03d.%03d.%03d.%03d]\n",
                                    cp[0], cp[1], cp[2], cp[3]);
                                pos += 4;
                                cp  += 4;
                            }
                            conp->IPOrxsropt[0] = conp->IPOrxopt[0];
                            conp->IPOrxsropt[1] = len;
                            conp->IPOrxsropt[2] = 4;
                            pos=3;
                            flg = len - 4;
                            cp = (unsigned char *)conp->IPOrxopt;
                            while (pos < flg) {
                                memcpy((char *)&conp->IPOrxsropt[pos], (cp + flg), Iid_SZ);
                                memcpy((char *)&conp->IPOrxsropt[flg], (cp + pos), Iid_SZ);
                                pos += 4;
                                flg -= 4;
                            }
                            conp->IPOrxsrlen = (len + 3) & ~3;

                            cp = (unsigned char *)conp->IPOrxsropt;
                            Nprintf("\n Set IP options (IPOrxsropt)\n");
                            Nprintf("  Type  : [0x%02X]\n", cp[0]);
                            Nprintf("  length: [%d]\n", cp[1]);
                            Nprintf("  point : [%d]\n", cp[2]);
                            len = cp[1] - 3;
                            cp = &cp[3];
                            for ( pos = 0; pos < len; pos += 4) {
                                Nprintf("  IPopt : [%03d.%03d.%03d.%03d]\n", cp[0], cp[1], cp[2], cp[3]);
                                cp += 4;
                            }
                            flg = setsockopt(conno, IPPROTO_IP, IP_OPTIONS, conp->IPOrxsropt, conp->IPOrxsrlen);
                            if (flg < 0) {
                                Nprintf("ERROR: setsockopt(%d) returns[%d] errno[%d]\n", conno, flg, errno);
                                prm2 = 0;
                                goto su_end1;
                            }
                            break;
                        }
                    }
                }
#endif
#endif
                if (ul1 & 0x5555) {
                    status = sendto(conno, testbuf, status, 0,
                                    (struct sockaddr *)&socka, sizeof(socka));
                }
                else {
                    status = sendmsg(conno, &msg, 0);
                }
                if (status < 0){
                    if (ul1 & 0x5555) {
                        Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    else {
                        Nprintf(" ERROR: sendmsg(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    prm2 = 0;
                    goto su_end1;
                }
                else if (prm6 != 0) {
                    if (ul1 & 0x5555) {
                        Nprintf("sendto(%d)\n", status);
                    }
                    else {
                        Nprintf("sendmsg(%d)\n", status);
                    }
                }
                if (++ul3 < prm4) {
                    goto su_read1;
                }
                ul3 = 0;
                if (prm1 == 1) {
                    prm2 = 0;
                    goto su_end1;
                }
                break;
            case 2:
                break;
            default:
                prm2 = 0;
                goto su_end1;
            }
            if (data_get(task_id) != 0) {
                prm2 = 0;
                break;
            }
        }
su_end1:
        closesocket(conno);

        if ((prm2== 1) && (patarn < 15)) {
             if (++ul2 == prm3) {
                  patarn++;
                  ul2 = 0;
             }
             goto su_next1;
        }
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP SERVER END\n");
#endif
    }
    else if (*mode == 'c') {
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP CLIENT\n");
#endif
        if (argc > 9)
            prm5 = atoi(argv[10]);
        else
            prm5 = RWSIZE;
su_next2:
#if DEBUG_LEVEL >= 3
        Nprintf("\npatarn[%d]", patarn);
#endif
        ul1 = (1 << patarn);

        conno = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno < 0) {
            Nprintf(" ERROR: socket() returns[%d]\n", conno);
            goto sock_udp_kill;
        }

#if DEBUG_LEVEL >= 3
        Nprintf(" -> bind()");
#endif
        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            prm2 = 0;
            goto su_end2;
        }

        if (ul1 & 0x00FF) {
#if DEBUG_LEVEL >= 3
            Nprintf(" -> listen()");
#endif
            status = listen(conno, 0);
            if (status < 0){
                Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", conno, status, errno);
                prm2 = 0;
                goto su_end2;
            }
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family      = AF_INET;
        i1 = sizeof(socka);

        SOCKET_RXTOUT(conno, READ_WAIT);
        while (1) {
su_read2:
            socka.sin_port        = htons(herport);
            socka.sin_addr.s_addr = inet_addr(target);

            if (ul1 & 0x0F0F) {
                if (prm6 != 0)
                    Nprintf(" -> sendto()");
                status = sendto(conno, testbuf, prm5, 0, (struct sockaddr *)&socka, sizeof(socka));
            }
            else {
                if (prm6 != 0)
                    Nprintf(" -> sendmsg()");
                memset(msgbuf1, 0, RWSIZE);
                memset(msgbuf2, 0, RWSIZE);
                status = sendmsg(conno, &msg, 0);
            }
            if (status < 0){
                if (ul1 & 0x0F0F) {
                    Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                else {
                    Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                }
                prm2 = 0;
                goto su_end2;
            }
            else if (prm6 != 0) {
                if (ul1 & 0x0F0F) {
                    Nprintf("sendto(%d)\n", status);
                }
                else {
                    Nprintf("sendmsg(%d)\n", status);
                }
            }
            switch (prm1) {
            case 1:
            case 3:
                if (ul1 & 0x3333) {
#if DEBUG_LEVEL >= 3
                    Nprintf(" -> selectsocket()");
#endif
                    do {
                        timeout.tv_sec  = (READ_WAIT / 3000);
                        timeout.tv_usec = 0;
                        FD_ZERO(&readfds);
                        FD_SET(conno, &readfds);
                        i2 = 0;
                        i2 = selectsocket(conno + 1, &readfds, 0, 0, &timeout);
                        if (data_get(task_id) != 0) {
                            prm2 = 0;
                            goto su_end2;
                        }
                    }
                    while ((i2 == 0) && !FD_ISSET(conno, &readfds));
                    if (i2 <= 0) {
                        Nprintf(" ERROR: selectsocket(%d) returns[%d] errno[%d]\n", conno, i2, errno);
                        prm2 = 0;
                        goto su_end2;
                    }
                }
                Nprintf("\n");

                if (ul1 & 0x5555) {
                    status = recvfrom(conno, testbuf, BUFSIZE, 0, (struct sockaddr *)&socka, &i1);
                }
                else {
                    status = recvmsg(conno, &msg, 0);
                }
                if (status < 0){
                    if (ul1 & 0x5555) {
                        Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    else {
                        Nprintf(" ERROR: recvmsg(%d) returns[%d] errno[%d]\n", conno, status, errno);
                    }
                    prm2 = 0;
                    goto su_end2;
                }
                else if (prm6 != 0) {
                    if (ul1 & 0x5555) {
                        Nprintf("recvfrom(%d)\n", status);
                    }
                    else {
                        Nprintf("recvmsg(%d)\n", status);
                        Nprintf(" msgbuf1[%s]\n", msgbuf1);
                        Nprintf(" msgbuf2[%s]\n", msgbuf2);
                    }
                }
                if (++ul3 < prm4) {
                    goto su_read2;
                }
                ul3 = 0;
                if (prm1 == 1) {
                    goto su_end2;
                }
                break;
            case 2:
                break;
            default:
                prm2 = 0;
                goto su_end2;
            }
            if (data_get(task_id) != 0) {
                prm2 = 0;
                break;
            }
        }
su_end2:
        closesocket(conno);

        if ((prm2== 1) && (patarn < 15)) {
             if (++ul2 == prm3) {
                  patarn++;
                  ul2 = 0;
             }
             goto su_next2;
        }
#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: UDP CLIENT END\n");
#endif
    }

sock_udp_kill:
#if (MT != 0)
    relmem(testbuf);
sock_udp_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION dpi_tcp(int argc, char **argv)
{
    char *mode;
    char *target;
    unsigned short myport, herport;
    int flag=0, prm1, prm2, prm3;
    int cc, conno, status;
    unsigned long ul1=0, ul2;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto dpi_tcp_kill2;
    }
#endif

    if (argc == 0) {
        Nprintf("argument invalid\n");
        goto dpi_tcp_kill;
    }
    if (argc < 7) {
        comm_dpi_tcp(*argv[1]);
        goto dpi_tcp_kill;
    }
    mode    = argv[1];
    target  = argv[2];
    myport  = (unsigned short)atoi(argv[3]);
    herport = (unsigned short)atoi(argv[4]);
    flag    = atoi(argv[5]);
    prm1  = atoi(argv[6]);
    prm2  = atoi(argv[7]);
    if (7 < argc) {
        prm3 = atoi(argv[8]);
    }
    if (myport == 0) {
        myport = Nportno();
    }
    switch (flag) {
    case 1:
        flag = S_KEEPA;
        break;
    case 2:
        flag = S_URG;
        break;
    case 3:
        flag = S_NOWA;
        break;
    case 4:
        ul1 = 1;
        break;
    default:
        flag = 0;
        break;
    }

    if (*mode == 's') {
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: TCP SERVER\n");
#endif
        conno = Nopen(target, "TCP/IP", myport, 0, flag);
        if (conno < 0) {
            Nprintf("ERROR: Nopen() returns[%d]\n", conno);
            goto dpi_tcp_kill;
        }

        if (ul1 != 0) {
            Nprintf("waiting Nclose(%d) start ...\n", conno);
#if (MT != 0)
            Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf("input: command[*]\n");
#endif
            Nprintf("%c: end\n", CC_END);
            Nprintf("->");
            while (1) {
                while ((cc = data_get(task_id)) == 0)
                    YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    break;
                Nprintf("->");
            }
            Nprintf("Nclose start\n");
            ul1 = TimeMS();
            Nclose(conno);
            ul2 = TimeMS();
            Nprintf("Nclose end / waited [%lu]ms\n", ul2 - ul1);
            goto dpi_tcp_kill;
        }

        SOCKET_RXTOUT(conno, READ_WAIT);
        while (1) {
dt_read1:
            status = Nread(conno, testbuf, BUFSIZE);
            if (status < 0){
                Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                goto dt_end1;
            }

            switch (prm1) {
            case 1:
                if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                status = Nwrite(conno, testbuf, status);
                if (status < 0){
                    Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                }
                else if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                goto dt_end1;
            case 2:
                break;
            case 3:
                status = Nwrite(conno, testbuf, status);
                if (status < 0){
                    Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                    goto dt_end1;
                }
                break;
            default:
                if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                goto dt_end1;
            }
            if (data_get(task_id) != 0) {
                break;
            }
        }
dt_end1:
        Nclose(conno);
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: TCP SERVER END\n");
#endif
    }
    else if (*mode == 'c') {
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: TCP CLIENT\n");
#endif
        conno = Nopen(target, "TCP/IP", myport, herport, flag);
        if (conno < 0) {
            Nprintf("ERROR: Nopen() returns[%d]\n", conno);
            goto dpi_tcp_kill;
        }

        if (ul1 != 0) {
            Nprintf("waiting Nclose(%d) start ...\n", conno);
#if (MT != 0)
            Nprintf("input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf("input: command[*]\n");
#endif
            Nprintf("%c: end\n", CC_END);
            Nprintf("->");
            while (1) {
                while ((cc = data_get(task_id)) == 0)
                    YIELD();
#if (MT == 0)
                Nprintf("%c\n", cc);
#endif
                if (cc == CC_END)
                    break;
                Nprintf("->");
            }
            Nprintf("Nclose start\n");
            ul1 = TimeMS();
            Nclose(conno);
            ul2 = TimeMS();
            Nprintf("Nclose end / waited [%lu]ms\n", ul2 - ul1);
            goto dpi_tcp_kill;
        }

        while (1) {
 
            if (prm1 == 4) {
                for ( ul1 = TimeMS(); TimeMS() - ul1 < 100000; )
                    YIELD();
                goto dt_end2;
            }
            status = Nwrite(conno, testbuf, prm2);
            switch (prm1) {
            case 0:
                if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                goto dt_end2;
            case 1:
                if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                status = Nread(conno, testbuf, BUFSIZE);
                if (status < 0){
                    Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                }
                else if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                goto dt_end2;
            case 2:
                break;
            case 3:
                status = Nread(conno, testbuf, BUFSIZE);
                if (status < 0){
                    Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                    goto dt_end2;
                }
                break;
            default:
                for ( ul1 = TimeMS(); TimeMS() - ul1 < prm1; )
                    YIELD();
                break;
            }
            if (data_get(task_id) != 0) {
                break;
            }
        }
dt_end2:
        Nclose(conno);
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: TCP CLIENT END\n");
#endif
    }

dpi_tcp_kill:
#if (MT != 0)
    relmem(testbuf);
dpi_tcp_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

TASKFUNCTION dpi_udp(int argc, char **argv)
{
    char *mode;
    char *target;
    unsigned short myport, herport;
    int flag=0, prm1, prm2, prm3=0;
    int cc, conno, status;
    unsigned long ul1;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto dpi_udp_kill2;
    }
#endif

    if (argc == 0) {
        Nprintf("argument invalid\n");
        goto dpi_udp_kill;
    }
    if (argc < 7) {
        comm_dpi_udp(*argv[1]);
        goto dpi_udp_kill;
    }
    mode    = argv[1];
    target  = argv[2];
    myport  = (unsigned short)atoi(argv[3]);
    herport = (unsigned short)atoi(argv[4]);
    prm1  = atoi(argv[6]);
    prm2  = atoi(argv[7]);
    if (7 < argc) {
        prm3 = atoi(argv[8]);
    }
    if (myport == 0) {
        myport = Nportno();
    }
    switch (atoi(argv[5])) {
    case 1:
        flag = S_NOWA;
        break;
    case 2:
        flag = S_NOCON;
        break;
    case 3:
        flag = (S_NOCON | S_NOWA);
        break;
    default:
        flag = 0;
        break;
    }

    conno = Nopen(target, "UDP/IP", myport, herport, flag);
    if (conno < 0) {
        Nprintf("ERROR: Nopen() returns[%d]\n", conno);
        goto dpi_udp_kill;
    }

    if (*mode == 's') {
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: UDP SERVER\n");
#endif
        prm2 *= 1000;
        SOCKET_RXTOUT(conno, prm2);

        while (1) {
du_read1:
            status = Nread(conno, testbuf, BUFSIZE);
            if (status < 0){
                Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                goto du_end1;
            }

            switch (prm1) {
            case 1:
                if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                status = Nwrite(conno, testbuf, status);
                if (status < 0){
                    Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                }
                else if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                goto du_end1;
            case 2:
                break;
            case 3:
                status = Nwrite(conno, testbuf, status);
                if (status < 0){
                    Nprintf("ERROR: Nwrite(%d) returns[%d]\n", conno, status);
                    goto du_end1;
                }
                break;
            default:
                if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                goto du_end1;
            }
            if (data_get(task_id) != 0) {
                break;
            }
        }
du_end1:
        Nclose(conno);
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: UDP SERVER END\n");
#endif
    }
    else if (*mode == 'c') {
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: UDP CLIENT\n");
#endif

        while (1) {
            if (prm1 == 4) {
                prm1 = 0;
                Nprintf(" SOCKET_CANSEND -> ");
                while ((cc = data_get(task_id)) == 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_END)
                        goto du_end2;
#if (MT == 0)
                    Nprintf("->");
#endif
                    if (SOCKET_CANSEND(conno, 0) != 0)
                        break;
                    YIELD();
                }
                Nprintf("OK\n");
            }

            status = Nwrite(conno, testbuf, prm2);
            if (status < 0){
                Nprintf("ERROR: Nwrite(%d) returns[%d] errno[%d]\n", conno, status, errno);
                goto du_end2;
            }
            switch (prm1) {
            case 0:
                if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                goto du_end2;
            case 1:
                if (prm3 != 0) {
                    Nprintf("Nwrite(%d)\n", status);
                }
                status = Nread(conno, testbuf, BUFSIZE);
                if (status < 0){
                    Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                }
                else if (prm3 != 0) {
                    Nprintf("Nread(%d)\n", status);
                }
                goto du_end2;
            case 2:
                break;
            case 3:
                status = Nread(conno, testbuf, BUFSIZE);
                if (status < 0){
                    Nprintf("ERROR: Nread(%d) returns[%d]\n", conno, status);
                    goto du_end2;
                }
                break;
            default:
                for ( ul1 = TimeMS(); TimeMS() - ul1 < prm1; )
                    YIELD();
                break;
            }
            if (data_get(task_id) != 0) {
                break;
            }
        }
du_end2:
        Nclose(conno);
#if DEBUG_LEVEL >= 5
        Nprintf("DPI: UDP CLIENT END\n");
#endif
    }

dpi_udp_kill:
#if (MT != 0)
    relmem(testbuf);
dpi_udp_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

#define GPORT_NUM   3000

unsigned short gportnum = GPORT_NUM;
char cvflag[NCONNS];

unsigned short gport(void)
{
    BLOCKPREE();
    gportnum++;
    if (gportnum < GPORT_NUM)
        gportnum = GPORT_NUM;
    RESUMEPREE();

    return gportnum;
}

TASKFUNCTION rst_socket(int argc, char **argv)
{
    char *mode, *target;
    int i1, sconno, cconno, status;
    unsigned short herport = 0;
    unsigned long ul1;
    struct sockaddr_in socka;
    struct linger linger_d;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto rst_socket_kill2;
    }
#endif

    if (argc < 2) {
        Nprintf("argument invalid\n");
        goto rst_socket_kill;
    }
    mode    = argv[1];
    target  = argv[2];

#if DEBUG_LEVEL >= 5
        Nprintf("SOCKET: TCP SERVER (RST)\n");
#endif
    if (*mode == 's') {
rst_socket_socket:
        sconno = socket(PF_INET, SOCK_STREAM, 0);
        if (sconno < 0) {
            if (sconno == ENOBUFS) {
                for (ul1=TimeMS(); TimeMS()-ul1<1000; );
                    YIELD();
                if (data_get(task_id) != 0)
                    goto rst_socket_kill;
                goto rst_socket_socket;
            }
            else {
                Nprintf("ERROR: Nopen() returns[%d]\n", sconno);
                goto rst_socket_kill;
            }
        }
        BLOCKPREE();
        if (cvflag[sconno] != 0) {
            Nprintf("conection[%d] duplicate (LISETN)!! TaskId[%d]", sconno, task_id);
            show_info(C_SHOW_CONN, 0);
            stop_process();
            goto rst_socket_end;
        }
        cvflag[sconno] = 1;
        RESUMEPREE();

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(gport());
        status = bind(sconno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", sconno, status, errno);
            goto rst_socket_end;
        }

        status = listen(sconno, 4);
        if (status < 0){
            Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", sconno, status, errno);
            goto rst_socket_end;
        }

        while (1) {
            errno = 0;
            cconno = accept(sconno, (struct sockaddr *)&socka, &i1);
            if (cconno < 0) {
                Nprintf(" ERROR: accept(%d) returns[%d] errno[%d]\n", sconno, cconno, errno);
                goto rst_socket_end;
            }
            BLOCKPREE();
            if (cvflag[cconno] != 0) {
                Nprintf("conection[%d] duplicate (ACCEPT) !! TaskId[%d]", cconno, task_id);
                show_info(C_SHOW_CONN, 0);
                stop_process();
                closesocket(cconno);
                goto rst_socket_end;
            }
            cvflag[cconno] = 1;
            RESUMEPREE();


            while (1) {
                status = send(cconno, testbuf, 5860, 0);
                if (status < 0){
                     break;
                }
            }

            cvflag[cconno] = 0;
            closesocket(cconno);

            if (data_get(task_id) != 0)
                break;
        }
    }
    else {
        if (argc >= 3)
            herport = (unsigned short)atoi(argv[3]);

        while (1) {
            errno = 0;
            sconno = socket(PF_INET, SOCK_STREAM, 0);
            if (sconno < 0) {
                if (sconno == ENOBUFS) {
                    for (ul1=TimeMS(); TimeMS()-ul1<1000; );
                        YIELD();
                    if (data_get(task_id) != 0)
                        break;
                    continue;
                }
                else {
                    Nprintf("ERROR: Nopen() returns[%d] errno[%d]\n", sconno, errno);
                    goto rst_socket_kill;
                }
            }
            BLOCKPREE();
            if (cvflag[sconno] != 0) {
                Nprintf("conection[%d] duplicate (CONNECT)!! TaskId[%d]", sconno, task_id);
                show_info(C_SHOW_CONN, 0);
                stop_process();
                goto rst_socket_end;
            }
            cvflag[sconno] = 1;
            RESUMEPREE();

            memset((char *) &socka, 0, sizeof(socka));
            socka.sin_family = AF_INET;
            socka.sin_port   = htons(Nportno());
            status = bind(sconno, (struct sockaddr *)&socka, sizeof(socka));
            if (status < 0) {
                Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", sconno, status, errno);
                goto rst_socket_end;
            }

            memset((char *) &socka, 0, sizeof(socka));
            socka.sin_family      = AF_INET;
            if (herport)
                socka.sin_port        = htons(herport);
            else
                socka.sin_port        = htons(gport());
            socka.sin_addr.s_addr = inet_addr(target);
            status = connect(sconno, (struct sockaddr *)&socka, sizeof(socka));
            if (status < 0) {
            }
            else {
                linger_d.l_onoff  = 1;
                linger_d.l_linger = 0;
                status = setsockopt(sconno, SOL_SOCKET, SO_LINGER, (char *)&linger_d, sizeof(struct linger));
                if (status < 0) {
                    Nprintf("ERROR: setsockopt(%d, SO_LINGER) returns[%d] errno[%d]\n", sconno, status, errno);
                }
#if (BOARD != MS7709RP01)
                for (ul1=TimeMS(); TimeMS()-ul1<5; );
                    YIELD();
#endif
            }

            cvflag[sconno] = 0;
            closesocket(sconno);

            if (data_get(task_id) != 0)
                goto rst_socket_kill;
        }
    }

#if DEBUG_LEVEL >= 5
    Nprintf("SOCKET: TCP SERVER (RST) END\n");
#endif
rst_socket_end:
    cvflag[sconno] = 0;
    closesocket(sconno);

rst_socket_kill:
#if (MT != 0)
    relmem(testbuf);
rst_socket_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}


TASKFUNCTION rst_dpi(int argc, char **argv)
{
    int conno, status;
    unsigned short herport = 0;
    unsigned long ul1;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto rst_dpi_kill2;
    }
#endif


#if DEBUG_LEVEL >= 5
    Nprintf("DPI: TCP SERVER (RST)\n");
#endif

    if (argc >= 1)
        herport = (unsigned short)atoi(argv[1]);
    else
        herport = gport();

    while (1) {
        conno = Nopen("*", "TCP/IP", herport, 0, 0);
        if (conno < 0) {
            if (conno == ENOBUFS) {
                for (ul1=TimeMS(); TimeMS()-ul1<1000; );
                    YIELD();
                if (data_get(task_id) != 0)
                    goto rst_dpi_kill;
                continue;
            }
            else {
                Nprintf("ERROR: Nopen() returns[%d]\n", conno);
                goto rst_dpi_kill;
            }
        }
        BLOCKPREE();
        if (cvflag[conno] != 0) {
            Nprintf("conection[%d] duplicate !! TaskId[%d]", conno, task_id);
            show_info(C_SHOW_CONN, 0);
            stop_process();
            Nclose(conno);
            goto rst_dpi_kill;
        }
        cvflag[conno] = 1;
        RESUMEPREE();

        SOCKET_RXTOUT(conno, 0xFFFFFFFF);
        while (1) {
            status = Nwrite(conno, testbuf, SOCKET_MAXDAT(conno));
            if (status < 0){
                break;
            }
        }

        cvflag[conno] = 0;
        Nclose(conno);

        if (data_get(task_id) != 0)
            break;
    }

#if DEBUG_LEVEL >= 5
    Nprintf("DPI: TCP SERVER (RST) END\n");
#endif

rst_dpi_kill:
#if (MT != 0)
    relmem(testbuf);
rst_dpi_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

#define BENCH_SIZE  10485760

#define UDP_SYNC_READY  "UDP-READY"
#define UDP_SYNC_OK     "UDP-OK"

TASKFUNCTION bench_sock(int argc, char **argv)
{
    char *mode, *protocol, *rw, *target;
    unsigned short myport, herport;
    int cc, conno, status, i1, i2=0, len, total=BENCH_SIZE, count=5;
    unsigned long ul1, ul2, tlen, val_bps, average=0;
    struct sockaddr_in socka;
    ID task_id;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto sock_bench_kill2;
    }
#endif

    if (argc < 6) {
       Nprintf("argument invalid\n");
       goto sock_bench_kill;
    }
    protocol = argv[1];
    mode     = argv[2];
    rw       = argv[3];
    target   = argv[4];
    myport   = (unsigned short)atoi(argv[5]);
    herport  = (unsigned short)atoi(argv[6]);

    if (argc >= 7)
        total = atoi(argv[7]);

    if (argc >= 8)
        count = atoi(argv[8]);

    if (*protocol == 't') {

        conno = socket(PF_INET, SOCK_STREAM, 0);
        if (conno < 0) {
            Nprintf("ERROR: socket() returns[%d]\n", conno);
            goto sock_bench_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_bench_end1;
        }

        if (*mode == 'c') {
            memset((char *) &socka, 0, sizeof(socka));
            socka.sin_family      = AF_INET;
            socka.sin_port        = htons(herport);
            socka.sin_addr.s_addr = inet_addr(target);
            status = connect(conno, (struct sockaddr *)&socka, sizeof(socka));
            if (status < 0) {
                Nprintf(" ERROR: connect(%d) returns[%d] errno[%d]\n", conno, status, errno);
                goto sock_bench_end1;
            }
        }
        else {
            status = listen(conno, 0);
            if (status < 0){
                Nprintf(" ERROR: listen(%d) returns[%d] errno[%d]\n", conno, status, errno);
                goto sock_bench_end1;
            }

            Nprintf("waiting ESTABLISHED ...\n");
#if (MT != 0)
            Nprintf(" input: TaskID[%d] command[*]\n", task_id);
#else
            Nprintf(" input: command[*]\n");
#endif
            Nprintf(" %c: end\n", CC_END);
            Nprintf("->");
            while (!SOCKET_ISOPEN(conno)) {
                YIELD();
                if ((cc = data_get(task_id)) != 0) {
#if (MT == 0)
                    Nprintf("%c\n", cc);
#endif
                    if (cc == CC_END)
                        goto sock_bench_end1;
#if (MT == 0)
                    Nprintf("->");
#endif
                }
            }
        }

        len = SOCKET_MAXDAT(conno);
        if (*rw == 'w') {
            while (i2 < count) {
                tlen = 0;
                ul1 = TimeMS();
                while(tlen < total) {
                    status = send(conno, testbuf, len, 0);
                    if (status <= 0){
                        Nprintf(" ERROR: send(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto sock_bench_end1;
                    }
                    tlen += status;
                }
                ul2 = TimeMS();
                ul2 -= ul1;
                val_bps = (tlen / ul2) * 8000;
                average += val_bps;
                Nprintf("TCP SEND (%d): [%d]bytes [%u]ms -> [%d]bps\n", ++i2, tlen, ul2, val_bps);
            }
        }
        else {
            SOCKET_RXTOUT(conno, READ_WAIT);
            while (i2 < count) {
                tlen = 0;
                ul1 = TimeMS();
                while(tlen < total) {
                    status = recv(conno, testbuf, len, 0);
                    if (status <= 0) {
                        Nprintf(" ERROR: recv(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto sock_bench_end1;
                    }
                    tlen += status;
                }
                ul2 = TimeMS();
                ul2 -= ul1;
                val_bps = (tlen / ul2) * 8000;
                average += val_bps;
                Nprintf("TCP RECV (%d): [%d]bytes [%u]ms -> [%d]bps\n", ++i2, tlen, ul2, val_bps);
            }
        }

sock_bench_end1:
        closesocket(conno);
    }
    else {

        conno = socket(PF_INET, SOCK_DGRAM, 0);
        if (conno < 0) {
            Nprintf(" ERROR: socket() returns[%d]\n", conno);
            goto sock_bench_kill;
        }

        memset((char *) &socka, 0, sizeof(socka));
        socka.sin_family = AF_INET;
        socka.sin_port   = htons(myport);
        status = bind(conno, (struct sockaddr *)&socka, sizeof(socka));
        if (status < 0) {
            Nprintf(" ERROR: bind(%d) returns[%d] errno[%d]\n", conno, status, errno);
            goto sock_bench_end2;
        }

        memset((char *) &socka, 0, sizeof(socka));

        len = SOCKET_MAXDAT(conno);
        if (*rw == 'w') {
            socka.sin_family      = AF_INET;
            socka.sin_port        = htons(herport);
            socka.sin_addr.s_addr = inet_addr(target);
            total *= 2;
            while (i2 < count) {
                tlen = 0;
                ul1 = TimeMS();
                while(tlen < total) {
                    status = sendto(conno, testbuf, len, 0, (struct sockaddr *)&socka, sizeof(socka));
                    if (status <= 0){
                        Nprintf(" ERROR: sendto(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        goto sock_bench_end2;
                    }
                    tlen += status;
                }
                ul2 = TimeMS();
                ul2 -= ul1;
                val_bps = (tlen / ul2) * 8000;
                average += val_bps;
                Nprintf("UDP SEND (%d): [%d]bytes [%u]ms -> [%d]bps\n", ++i2, tlen, ul2, val_bps);
                for (ul1=TimeMS(); TimeMS()-ul1<2000;)
                    YIELD();
            }
        }
        else {
            SOCKET_RXTOUT(conno, READ_WAIT);
            while (i2 < count) {

                tlen = 0;
                ul1 = TimeMS();
                while(tlen < total) {
                    status = recvfrom(conno, testbuf, len, 0, (struct sockaddr *)&socka, &i1);
                    if (status <= 0) {
                        Nprintf(" ERROR: recvfrom(%d) returns[%d] errno[%d]\n", conno, status, errno);
                        i2 = count;
                        break;
                    }
                    tlen += status;
                }
                ul2 = TimeMS();
                ul2 -= ul1;
                val_bps = (tlen / ul2) * 8000;
                average += val_bps;
                Nprintf("UDP RECV (%d): [%d]bytes [%u]ms -> [%d]bps\n", ++i2, tlen, ul2, val_bps);
                SOCKET_RXTOUT(conno, 500);
                while (1) {
                    status = recvfrom(conno, testbuf, len, 0, (struct sockaddr *)&socka, &i1);
                    if (status <= 0) {
                        errno = 0;
                        break;
                    }
                }
                SOCKET_RXTOUT(conno, TOUT_READ);
            }
        }

sock_bench_end2:
        closesocket(conno);
    }
    Nprintf(" average(%d)=[%d]bps\n", count, average / count);

sock_bench_kill:
#if (MT != 0)
    relmem(testbuf);
sock_bench_kill2:
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}

#if (DHCP >= 1)
TASKFUNCTION dhcp_get(int argc, char **argv)
{
    int i1, i2=0, status;
    unsigned long ul1=dhcpleasetime;
    ID task_id;


#if (MT != 0)
    get_tid(&task_id);
#endif

    if (argc == 0) {
        Nprintf("argument invalid\n");
        goto dhcp_get_kill;
    }
    i1  = atoi(argv[1]);
    if (argc >= 2) {
        ul1 = (unsigned)atol(argv[2]);
    }
    if (argc >= 3) {
        if (atol(argv[3]) == 1) {
            nets[i1].DHCPserver = 0;
        }
    }
    if (argc == 4) {
        i2 = atoi(argv[4]);
    }

    while (1) {
        status = DHCPget(i1, ul1);
        if (status < 0) {
            Nprintf("DHCPget: ERROR[%d]\n", status);
            break;
        }
        if ((data_get(task_id) != 0) || (i2 == 0)) {
            break;
        }
        YIELD();
    }

dhcp_get_kill:
#if (MT != 0)
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}
#endif

#ifdef INCLUDE_TELNET
#include "telnet.h"
static ID tnserv_task_id = 0;

#define REPORT_SIZE 32

const unsigned char mess1[]={IAC,WILL,NOGOAHEAD};
const unsigned char mess2[]={IAC,SB,TERMTYPE,SEND,IAC,SE};
const unsigned char mess3[]={IAC,WONT,ECHO};
const unsigned char mess4[]={IAC,DO,TERMTYPE};
const unsigned char greet[]="USNET skeleton Telnet server\n\r";

void command(int s, char *name)
{
     send(s, "echoing command ", 16, 0);
     send(s, name, strlen(name), 0);
     send(s, "\r\n", 2, 0);
}

TASKFUNCTION tnserv(int argc, char **argv)
{
    int i1, i2, s, ns;
    char *comp, par[32];
    unsigned char cc;
    unsigned long ul1;
    struct sockaddr_in socka;
    struct CONNECT *conp;
    char repbuf[REPORT_SIZE];

#if (MT != 0)
    if (tnserv_task_id != 0) {
        Nprintf("tnserv has already been up!\n");
        goto tnserv_kill;
    }
#endif

    if (argc != 1) {
        Nprintf("argument invalid\n");
        goto tnserv_kill;
    }
    if (NCONNS <= (i2 = atoi(argv[1]))) {
        i2 = NCONNS - 1;
    }

#if (MT != 0)
    get_tid(&tnserv_task_id);
#endif

#if DEBUG_LEVEL >= 5
    Nprintf("tnserv START\n");
#endif

loop1:
    memset(&socka, 0, sizeof(socka));
    socka.sin_port = htons(23);
    s = socket(PF_INET, SOCK_STREAM, 0);
    if (s < 0)
    {
        Nprintf("ERROR: socket [%d]\n", s);
        goto tnserv_kill;
    }
    i1 = bind(s, (struct sockaddr *)&socka, sizeof(socka));
    if (i1 < 0)
    {
        Nprintf("ERROR: bind [%d]\n", s);
        goto err1;
    }
    i1 = listen(s, i2);
    if (i1 < 0)
    {
        Nprintf("ERROR: listen [%d]\n", s);
        goto err1;
    }
    memset(&socka, 0, sizeof(socka));
    i1 = sizeof(socka);

    SOCKET_RXTOUT(s, (READ_WAIT/3));
loop2:
    ns = accept(s, (struct sockaddr *)&socka, &i1);
    if (errno == EWOULDBLOCK) {
        errno = 0;
        if (data_get(tnserv_task_id) != 0) {
            goto err1;
        }
        goto loop2;
    }
    if (ns < 0)
    {
        Nprintf("ERROR: accept [%d]\n", ns);
        goto err1;
    }
    i1 = send(ns, (char *)mess4, 3, 0);
    if (i1 != 3)
        goto err3;
#if NTRACE >= 1
        Nprintf("TN-TX IAC %d %d\n", mess4[1], mess4[2]);
#endif
    ul1 = TimeMS();

    send(ns, (char *)greet, sizeof(greet)-1, 0);
    comp = par;
    for (;;)
    {
        SOCKET_RXTOUT(ns, 10000);
        i1 = recv(ns, (char *)&cc, 1, 0);
        SOCKET_RXTOUT(ns, 2000);
        if (i1 != 1)
        {
            if (i1 == 0)
            {
#if DEBUG_LEVEL >= 5
                Nprintf("connection closed\n");
#endif
                goto err8;
            }
            if (errno != ETIMEDOUT)
            {
                Nprintf("\nconnection broken\n");
                goto err8;
            }
            memset(repbuf, 0, REPORT_SIZE);
            Nsprintf(repbuf, "Time=[%lu]\r\n", TimeMS() - ul1);
            send(ns, repbuf, strlen(repbuf), 0);
            goto cont;
        }
        switch(cc)
        {
        case IAC:
            i1 = recv(ns, par, 2, 0);
            if (i1 != 2)
                goto err2;
#if NTRACE >= 1
            Nprintf("TN-RX IAC %d %d\n", par[0], par[1]);
#endif
            switch(par[0])
            {
            case WILL:
                switch(par[1])
                {
                case TERMTYPE:
                    i1 = send(ns, (char *)mess2, sizeof(mess2), 0);
                    if (i1 != sizeof(mess2))
                        goto err3;
#if NTRACE >= 1
                        Nprintf("TN-TX IAC %d %d %d\n",mess2[1],mess2[2],mess2[3]);
#endif
                    break;
                }
                break;
            case WONT:
                break;
            case DO:
                switch(par[1])
                {
                case NOGOAHEAD:
                    i1 = send(ns, (char *)mess1, 3, 0);
                    if (i1 != 3)
                        goto err3;
#if NTRACE >= 1
                        Nprintf("TN-TX IAC %d %d\n", mess1[1], mess1[2]);
#endif
                    break;
                case TERMTYPE:
                    break;
                }
                break;
            case DONT:
                switch(par[1])
                {
                case ECHO:
                    i1 = send(ns, (char *)mess3, 3, 0);
                    if (i1 != 3)
                        goto err3;
#if NTRACE >= 1
                        Nprintf("TN-TX IAC %d %d\n", mess3[1], mess3[2]);
#endif
                    break;
                }
                break;
            case SB:
                switch(par[1])
                {
                case TERMTYPE:
#if NTRACE >= 1
                    Nprintf("TN-RX");
#endif
                    for (;;)
                    {
                        i1 = recv(ns, (char *)&cc, 1, 0);
                            if (i1 != 1)
                            goto err2;
#if NTRACE >= 1
                        Nprintf(" %x", cc);
#endif
                        if (cc == SE)
                            break;
                    }
#if NTRACE >= 1
                    Nprintf("\n");
#endif
                    send(ns, "USNET Telnet Server\r\n", 22, 0);
                    break;
                }
                break;
            }
            break;
        default:
            if (cc == '\n' || cc == '\r')
            {
                    *comp = 0;
                if (comp != par)
                    command(ns, par);
                comp = par;
            }
            else if (cc == ('H'&0x1f))
            {
                if (comp != par)
                    *(--comp) = 0;
            }
            else if (cc != 0)
            {
                if (comp >= par + sizeof(par) - 1)
                    comp = par;
                *comp++ = cc;
            }
            break;
        }
cont:   YIELD();
    }
err3:
    Nprintf("send\n");
    goto err8;
err2:
    Nprintf("recv\n");
err8:
    closesocket(ns);
goto loop2;
err1:
    closesocket(s);

#if DEBUG_LEVEL >= 5
    Nprintf("tnserv END\n");
#endif

#if (MT != 0)
    tnserv_task_id = 0;
#endif

tnserv_kill:
#if (MT != 0)
    relmem(argv[0]);
    relmem(argv);
    KILLTASK();
#else
    return;
#endif

}
#endif



enum ftpcmd {
    FTP_START = 0,
    FTP_USER  = 1,
    FTP_PASS  = 2,
    FTP_TYPE  = 3,
    FTP_PASV  = 4,
    FTP_DATA  = 5,
    FTP_DEND  = 6,
    FTP_QUIT  = 7
};

#define FTP_READY    220
#define FTP_USER_OK  331
#define FTP_LOGIN    230
#define FTP_CMD_OK   200
#define FTP_PASV_RES 227
#define FTP_DAT_OK   150
#define FTP_DSTART   125
#define FTP_END      221

static int shell_ftp(int argc, char **argv)
{
unsigned char   *user, *pass, *file;
char            *target;
char            *cp;
int              put;
int              c_sock = -1;
int              d_sock = -1;
int              len, i1 = 1, i2;
int              dport;
long             cmd;
long             fsize;
struct           sockaddr_in to;
struct timeval   tv;
fd_set           fd;
#if (MT != 0)
    char *testbuf;


    get_tid(&task_id);

    testbuf = (char *)reqmem(GLOBAL, BUFSIZE);
    if (!testbuf) {
        Nprintf(" reqmem() fails!\n");
        goto abort;
    }
#endif


    if (argc >= 2 && strcmp(argv[1], "--help") == 0) {
        goto abort;
    }
    
    if (argc < 6) {
        goto abort;
    }
    
    target = (unsigned char *)argv[i1++];
    
    if (strncmp(argv[i1], "get", 3) == 0)
        put = 0;
    else if (strncmp(argv[i1], "put", 3) == 0)
        put = 1;
    else
        goto abort;
    
    i1++;
    
    file = (unsigned char *)argv[i1++];
    user = (unsigned char *)argv[i1++];
    pass = (unsigned char *)argv[i1++];
    
    
    fsize = sizeof(testbuf);
    if (argc >= 6) {
        fsize = atol(argv[i1]);
        if (fsize <= 0) 
            fsize = sizeof(testbuf);
    }
    
    tv.tv_sec  = 1;
    tv.tv_usec = 0;


    c_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (c_sock < 0) {
        i1 = -1;
        goto end;
    }
    
    len = 1;
    i1 = setsockopt(c_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&len, sizeof (len));
    if (i1 < 0) {
        i1 = -1;
        goto end;
    }
    
    memset(&to, 0, sizeof(to));
    to.sin_family = AF_INET ;
    to.sin_port   = htons(21);
    to.sin_addr.s_addr = inet_addr(target);
    
    i1 = connect(c_sock, (struct sockaddr *)&to, sizeof (struct sockaddr_in));
    if (i1 < 0) {
        Nprintf("control connection connect error, errno = %l\n", errno);
        i1 = -1;
        goto end;
    }
    
    for (i2 = 0;;i2++) {
        
        switch (i2) {
        case FTP_START:
            len = 0;
            break;
        case FTP_USER:
            len = sprintf(testbuf, "USER %s\r\n", user);
            break;
        case FTP_PASS:
            len = sprintf(testbuf, "PASS %s\r\n", pass);
            break;
        case FTP_TYPE:
            len = sprintf(testbuf, "TYPE I\r\n");
            break;
        case FTP_PASV:
            len = sprintf(testbuf, "PASV\r\n");
            break;
        case FTP_DATA:
            len = sprintf(testbuf, "%s %s\r\n", (put?"STOR ":"RETR "), file);
            break;
        case FTP_DEND:
            len = 0;
            break;
        case FTP_QUIT:
            len = sprintf(testbuf, "QUIT\r\n");
            break;
        default:
            goto end;
        }
        
        if (len > 0) {
            FD_ZERO(&fd);
            FD_SET(c_sock, &fd);
            i1 = selectsocket(c_sock + 1, 0, &fd, 0, &tv);
            if (!FD_ISSET(c_sock, &fd))
                continue;

            i1 = send(c_sock, testbuf, len, 0);
            if (i1 <= 0) {
                 i1 = -1;
                 goto end;
            }
        }


        FD_ZERO(&fd);
        FD_SET(c_sock, &fd);
        i1 = selectsocket(c_sock + 1, &fd, 0, 0, &tv);
        if (i1 <= 0) {
            i1 = -1;
            goto end;
        }
    
        for (i1 = 0; i1 < sizeof(testbuf); i1++) {
            if (recv(c_sock, &testbuf[i1], 1, 0) <= 0)
                break;
            
            if (testbuf[i1] == '\r')
                break;
        
            if (testbuf[i1] == '\n') {
                if (i1 == 0)
                    continue;
                break;
            }
        }
        
        cmd = atol(testbuf);
        
        switch (i2) {
        case FTP_START:
            if (cmd != FTP_READY) {
                i1 = -1;
                goto end;
            }
            break;
        case FTP_USER:
            if (cmd != FTP_USER_OK) {
                i1 = -1;
                goto end;
            }
            break;
        case FTP_PASS:
            if (cmd != FTP_LOGIN) {
                i1 = -1;
                goto end;
            }
            break;
        case FTP_TYPE:
            if (cmd != FTP_CMD_OK) {
                i1 = -1;
                goto end;
            }
            break;
        case FTP_PASV:
            if (cmd != FTP_PASV_RES) {
                i1 = -1;
                goto end;
            }
            cp = strchr(testbuf, '(');
            if (!cp) {
                i1 = -1;
                goto end;
            }
            for (i1 = 0; i1 < 4; i1++) {
                cp = strchr(cp, ',');
                cp++;
            }
            
            
            dport = (atoi(cp) << 8);
            cp = strchr(cp, ',');
            cp++;
            dport |= atoi(cp);
            
            d_sock = socket(AF_INET, SOCK_STREAM, 0);
            if (d_sock < 0) {
                i1 = -1;
                goto end;
            }
        
            len = 1;
            i1 = setsockopt(d_sock, SOL_SOCKET, SO_REUSEADDR, (char *)&len, sizeof(len));
            if (i1 < 0) {
                i1 = -1;
                goto end;
            }
    
            memset(&to, 0, sizeof(to));
            to.sin_family = AF_INET;
            to.sin_port = htons(dport);
            to.sin_addr.s_addr = inet_addr(target);
    
            i1 = connect(d_sock, (struct sockaddr *)&to, sizeof(struct sockaddr_in));
            if (i1 < 0) {
                Nprintf("data connection connect error, errno = %l\n", errno);
                i1 = -1;
                goto end;
            }
            break;
        case FTP_DATA:
            if ((cmd != FTP_DAT_OK) && (cmd != FTP_DSTART)) {
                i1 = -1;
                goto end;
            }
            
            if (put) {
                for (i1 = 0; i1 < sizeof(testbuf); i1++)
                    testbuf[i1] = 0x30 + (i1 % 0x40);
                if (fsize > sizeof(testbuf))
                    len = sizeof(testbuf);
                else
                    len = fsize;
        
                
                while (1) { 
                    if (len <= 0)
                        break;
                    
                    
                    FD_ZERO(&fd);
                    FD_SET(c_sock, &fd);
                    i1 = selectsocket(d_sock + 1, 0, &fd, 0, &tv);
                    if (i1 <= 0) {
                        i1 = -1;
                        goto end;
                    }

                    i1 = send(d_sock, testbuf, len, 0);
                    if (i1 <= 0)
                        break;

                    fsize -= len;
                    if (fsize < sizeof(testbuf))
                        len = fsize;
                    
                    else
                        len = sizeof(testbuf);
                    
                }
            } 
            else {
                len = 0;
                fsize = 0;
                while (1) {
                    
                    memset(testbuf, 0x00, sizeof(testbuf));
                    FD_ZERO(&fd);
                    FD_SET(c_sock, &fd);
                    i1 = selectsocket(d_sock + 1, &fd, 0, 0, &tv);
                    if (i1 <= 0) {
                        i1 = -1;
                        goto end;
                    }
                    
                    len = recv(d_sock, testbuf, sizeof(testbuf), 0);
                    if (len <= 0)
                        break;
                    fsize += len;
                    
                    
 #if 1
                    i1 = 1;
                    cp = &testbuf[0];
                    while (*cp) {
                        Nprintf("%c", *cp);
                        if (!(i1 % 48)) {
                            Nprintf("\n");
                            i1 = 0;
                        }
                        i1++;
                        cp++;
                    }
 #endif
                    
                    
                    
                }
                Nprintf("\n\n");
                Nprintf(" %d byte receive\n", fsize);
            }
            
            if (d_sock >= 0) {
                closesocket (d_sock);
                d_sock = -1;
            }
            
            break;
        case FTP_DEND:
            break;
        case FTP_QUIT:
            if (cmd != FTP_END) {
                i1 = -1;
                goto end;
            }
            Nprintf("ftp end!\n");
            i1 = 0;
            break;
        default:
            break;
        }
        
    }
    
    
    
end:
    if (d_sock >= 0)
        closesocket (d_sock);
    
    if (c_sock >= 0)
        closesocket (c_sock);
    
    return i1;
    
abort:
    Nprintf ("Usage: ftptest <host> <get|put> <filename> <user id> <password> [file size]\n");
    return -1;
}


#ifdef USSW_DIRECTED_BROADCAST
TASKFUNCTION get_change_ip(int argc, char **argv)
{
    unsigned long addr;
    int i1;

    i1 = get_auto_detected_ip(&addr);
    Nprintf("ret = %d, addr = %x\n", i1, addr);
}

TASKFUNCTION set_change_ip(int argc, char **argv)
{
    struct SETIid addr;
    int i1;

    i1 = get_auto_detected_ip(&addr.addr.l);
    Nprintf("ret = %d, addr = %x\n", i1, addr.addr.l);
    if (0 < i1) {
        addr.no = 0;
        i1 = Nioctl(ussSetIaddr, &addr);
        Nprintf("ussSetIaddr ret = %d\n", i1);
    }
}

TASKFUNCTION start_detect_addr(int argc, char **argv)
{
    Iid addr;
    unsigned short port;
    int i1, i2;

    if (argc < 5) {
        Nprintf("argument error\n");
        return;
    }

    for (i1 = 0; i1 < 4; i1++) {
        addr.c[i1] = (char)atoi(argv[i1 + 1]) & 0xff;
    }
    port = atoi(argv[5]);

    i1 = start_ip_auto_detect(addr.l, port);
    Nprintf("ret = %d, addr = %d.%d.%d.%d(%04x), port = %d\n", 
        i1, addr.c[0], addr.c[1], addr.c[2], addr.c[3], addr.l, port);
}

TASKFUNCTION stop_detect_addr(int argc, char **argv)
{
    unsigned short port;
    int i1, i2;

    if (argc < 1) {
        Nprintf("argument error\n");
        return;
    }

    port = atoi(argv[1]);

    i1 = stop_ip_auto_detect(port);
    Nprintf("ret = %d, port = %d\n", i1,  port);
}

TASKFUNCTION get_detect_status(void)
{
    int i1;

    i1 = check_receive_broadcast();
    Nprintf("ret = %d\n", i1);
}

TASKFUNCTION set_ip_addr(int argc, char **argv)
{
    struct SETIid addr;
    int i1;

    if (argc < 5) {
        Nprintf("argument error\n");
        return;
    }

    addr.no = atoi(argv[1]);
    for (i1 = 0; i1 < 4; i1++) {
        addr.addr.c[i1] = (char)atoi(argv[i1 + 2]) & 0xff;
    }

    i1 = Nioctl(ussSetIaddr, &addr);
    Nprintf("ret = %d, addr = %d.%d.%d.%d(%x)\n", 
        i1, addr.addr.c[0], addr.addr.c[1], addr.addr.c[2], addr.addr.c[3], addr.addr.l);
}

TASKFUNCTION set_e_addr(int argc, char **argv)
{
    struct SETEid addr;
    int i1;

    if (argc < (Eid_SZ + 1)) {
        Nprintf("argument error\n");
        return;
    }

    addr.no = atoi(argv[1]);
    for (i1 = 0; i1 < Eid_SZ; i1++) {
        addr.addr.c[i1] = (char)atoi(argv[i1 + 2]) & 0xff;
    }

    i1 = Nioctl(ussSetEaddr, &addr);
    Nprintf("ret = %d, addr = %d:%d:%d:%d:%d:%d\n", 
        i1, addr.addr.c[0], addr.addr.c[1], addr.addr.c[2], 
        addr.addr.c[3], addr.addr.c[4], addr.addr.c[5]);
}

TASKFUNCTION set_ip_mask(int argc, char **argv)
{
    struct SETIid addr;
    int i1;

    if (argc < 5) {
        Nprintf("argument error\n");
        return;
    }

    addr.no = atoi(argv[1]);
    for (i1 = 0; i1 < 4; i1++) {
        addr.addr.c[i1] = (char)atoi(argv[i1 + 2]) & 0xff;
    }

    i1 = Nioctl(ussSetImask, &addr);
    Nprintf("ret = %d, mask = %d.%d.%d.%d(%x)\n", 
        i1, addr.addr.c[0], addr.addr.c[1], addr.addr.c[2], addr.addr.c[3], addr.addr.l);
}

TASKFUNCTION set_default_gateway(int argc, char **argv)
{
    struct SETIid addr;
    int i1;

    if (argc < 5) {
        Nprintf("argument error\n");
        return;
    }

    addr.no = atoi(argv[1]);
    for (i1 = 0; i1 < 4; i1++) {
        addr.addr.c[i1] = (char)atoi(argv[i1 + 2]) & 0xff;
    }

    i1 = Nioctl(ussSetGateway, &addr);
    Nprintf("ret = %d, gateway = %d.%d.%d.%d(%x)\n", 
        i1, addr.addr.c[0], addr.addr.c[1], addr.addr.c[2], addr.addr.c[3], addr.addr.l);
}
#endif


#if (MT != 0)
TASKFUNCTION shell( void )
#else
void main__ ( void )
#endif
{
    char cc;
    char *argv[ARG_MAX];
    int argc;
    int posX, insKey=0, backCount, command=0, tmpcmd=0;
    int i1, i2, i3, i4;
    int data;
    unsigned long ul1=0, ul2=0;
    Iid iid;

#if (MT != 0)
    for ( i1 = 0; i1 < NNETS; i1++ ) {
        nettask_id[i1] = 255;
    }

    get_tid(&shell_task_id);
#else
    init_board();

#endif

    if (init_usnet() < 0) {
        goto term;
    }

    for (i1 = 0; i1 < STOCK_NUM; i1++) {
        memset(cmdstock[i1], 0, CMDL_SIZE);
    }

    Nprintf("\n");

    Nprintf("############################\n");
    Nprintf("version 3.1200\n");
    Nprintf("############################\n");

retry:

    Nprintf("->");

    posX = 0;
    backCount=0;
    memset((char *)cmdline, 0, CMDL_SIZE);

    while (1) {
        if (Nchkchr() != 0) {
            data = Ngetchr();
            cc = (char)data;
            if (cc == '\n')
                break;
            if (cc == 0x08) {
                if (0 < posX) {
                    if (cmdline[posX]) {
                        memcpy(&cmdline[--posX], &cmdline[posX+1], strlen(&cmdline[posX+1]));
                        cmdline[(strlen(cmdline) - 1)] = 0;
                        Nprintf("\b");
                        Nprintf("%s ", &cmdline[posX]);
                        backCount = strlen(&cmdline[posX]) + 1;
                        while (0 < backCount--)
                            Nprintf("\b");
                    }
                    else {
                        cmdline[--posX] = 0;
                        Nprintf("\b \b");
                    }
                }
            }
            else if (cc == 0x1b) {
                while (Nchkchr() == 0);
                data = Ngetchr();
                while (Nchkchr() == 0);
                data = Ngetchr();
                cc = (char)data;
                if ((cc == 0x41) || (cc == 0x42)) {
                    i1 = i2 = command;
                    if (cc == 0x41) {
                        if (--i1 < 0)
                            i1 = STOCK_NUM - 1;
                        if (cmdstock[i1][0] != 0)
                            command = i1;
                    }
                    else if (cc == 0x42) {
                        if (++i1 == STOCK_NUM)
                            i1 = 0;
                        if (cmdstock[i1][0] != 0)
                            command = i1;
                    }
                    Nputchr(0x1b);
                    Nputchr('[');
                    Nputchr('2');
                    Nputchr('K');
                    if (command != i2) {
                        memcpy(cmdline, cmdstock[command], CMDL_SIZE);
                        posX = strlen(cmdline);
                        Nprintf("\r->%s", cmdline);
                    }
                    else {
                        command = tmpcmd;
                        memset((char *)cmdline, 0, CMDL_SIZE);
                        posX = 0;
                        Nprintf("\r->");
                    }
                }
                else if ((cc == 0x44) && (0 < posX)) {
                    Nprintf("\b");
                    posX--;
                }
                else if ((cc == 0x43) && (posX <= CMDL_SIZE)) {
                    if (cmdline[posX] != 0) {
                        Nputchr(0x1b);
                        Nputchr('[');
                        Nputchr('1');
                        Nputchr('C');
                        posX++;
                    }
                }
                else if ((cc >= 0x31) && (cc <= 0x35)) {
                    while (Nchkchr() == 0);
                    data = Ngetchr();
                    if ((cc == 0x32) && (0 < posX)) {
                        Nputchr(0x0D);
                        Nputchr(0x1b);
                        Nputchr('[');
                        Nputchr('2');
                        Nputchr('C');
                        posX = 0;
                    }
                    else if ((cc == 0x35) && (cmdline[posX] != 0)) {
                        i1 = strlen(cmdline);
                        if (posX < i1) {
                            Nputchr(0x1b);
                            Nputchr('[');
                            if ((i2 = i1 - posX) < 10) {
                                Nputchr(i2 + 0x30);
                            }
                            else {
                                i3 = i2 / 10;
                                Nputchr(i3 + 0x30);
                                i3 = i2 % 10;
                                Nputchr(i3 + 0x30);
                            }
                            Nputchr('C');
                            posX = i1;
                        }
                    }
                    else if (cc == 0x34) {
                        if (cmdline[posX] != 0) {
                            memcpy(&cmdline[posX], &cmdline[posX+1], strlen(&cmdline[posX+1]));
                            cmdline[strlen(cmdline) - 1] = 0;
                            Nputchr(0x1b);
                            Nputchr('[');
                            Nputchr('0');
                            Nputchr('K');
                            Nprintf("%s", &cmdline[posX]);
                            backCount = strlen(&cmdline[posX]);
                            while (0 < backCount--)
                                 Nprintf("\b");
                        }
                    }
                    else if (cc == 0x31) {
                        if (cmdline[posX]) {
                            if (insKey == 0) {
                                insKey = 1;
                            }
                            else {
                                insKey = 0;
                            }
                        }
                    }
                }
            }
            else if (0x20 <= cc) {
                if ( CMDL_SIZE <= posX || (CMDL_SIZE <= strlen(cmdline))) {
                    Nprintf("\ncommand too long\n");
                    goto retry;
                }
                else if ((insKey == 0) && (cmdline[posX] != 0)) {
                    memset((char *)cmdline2, 0, CMDL_SIZE);
                    memcpy(cmdline2, &cmdline[posX], strlen(&cmdline[posX]));
                    cmdline[posX] = cc;
                    memcpy(&cmdline[posX+1], cmdline2, strlen(cmdline2));
                    Nprintf("%c%s", cc, cmdline2);
                    i2 = strlen(cmdline2);
                    while (0 < i2--)
                        Nprintf("\b");
                    posX++;
                }
                else {
                    Nprintf("%c", cc);
                    cmdline[posX++] = cc;
                }
            }
        }
        YIELD();
    }
    Nprintf("\n");
    if (posX != 0) {
        memcpy(cmdstock[command], cmdline, CMDL_SIZE);
        if (++command == STOCK_NUM)
            command = 0;
         tmpcmd = command;
    }
    else {
        goto retry;
    }


    argc = 0;
    argv[0] = cmdline;

    for (i1=0, i2=1; (i1<CMDL_SIZE) && (cmdline[i1] != 0); i1++) {
        if (cmdline[i1] == ' ') {
            cmdline[i1] = 0;
            argv[i2] = &cmdline[i1+1];
            i2++;
            argc++;
        }
    }

    i3 = 0;
    for (i2=0; i2 <= C_END; i2++) {
        if (strcmp(argv[0], cmdarray[i2].cmdname) == 0) {
            i3 = cmdarray[i2].cmdnum;
            break;
        }
    }
    if (i3 == 0) {
        Nprintf("command invalid\n");
        goto retry;
    }

    switch (i3) {
    case C_GETTIME:
        Nprintf("TimeMS() = [%u]ms\n", TimeMS());
        break;
    case C_SETTIME:
        if (argc < 1) {
            Nprintf("argument invalid\n");
            goto retry;
        }
        Nsscanf(argv[1], "%x", &ul1);
        SetTimeMS(ul1);
        Nprintf("TimeMS() = [%u]ms\n", TimeMS());
        break;
    case C_COMM:
        command_dispaly();
        break;
#if (DHCP >= 1)
    case C_DHCPREL:
        if (argc != 1) {
            Nprintf("argument invalid\n");
            goto retry;
        }
        i1 = atoi(argv[1]);
        DHCPrelease(i1);
        break;
#endif
    case C_RARPGET:
    case C_EGP:
    case C_ICMP_SEND:
    case C_ICMP_RPLY:
    case C_PING:
    case C_SOCK_IP_OPT:
    case C_SOCK_FUNC:
    case C_SOCK_RW:
    case C_TCP_SOCK:
    case C_UDP_SOCK:
    case C_TCP_DPI:
    case C_UDP_DPI:
    case C_RST_SOCK:
    case C_RST_DPI:
    case C_BENCH_SOCK:
#ifdef INCLUDE_TELNET
    case C_TNSERV:
#endif
#if (DHCP >= 1)
    case C_DHCPGET:
#endif
#if (MT != 0)
    case C_TASK_KILL:
#endif
        exec_cmd(i3, cmdline, argc, argv);
        break;
#if (MT != 0)
    case C_TASK_SHOW:
        printtask();
        break;
    case C_INPUT:
        data_input(atoi(argv[1]), argv[2]);
        break;
#endif
    case C_SHOW_NET:
    case C_SHOW_NCON:
    case C_SHOW_CONN:
    case C_SHOW_MESS:
        if (argc >= 1) {
            i1 = atoi(argv[1]);
        }
        else {
            if ((i3 == C_SHOW_NCON) || (i3 == C_SHOW_CONN))
                i1 = -1;
            else
                i1 = 0;
        }
        show_info(i3, i1);
        break;
#ifdef DEBUG_FUNC
    case C_NAT_PORT:
        natport = atoi(argv[1]);
        if (natport != 0)
            Nprintf("NAT FAKE PORT: [%d]\n", natport);
        else
            Nprintf("NAT FAKE PORT: Nportno()\n");
        break;
#endif
    case C_MEM_EDIT:
    case C_MEM_READ:
        if (((i3 == C_MEM_EDIT) && (argc != 3)) ||
            ((i3 == C_MEM_READ) && (argc != 2))) {
            Nprintf("argument invalid\n");
            goto retry;
        }
        Nsscanf(argv[1], "%x", &ul1);

        if (i3 == C_MEM_EDIT) {
            if (argv[3][1] == 'x')
                Nsscanf(argv[3], "%x", &ul2);
            else
                ul2 = (unsigned)atol(argv[3]);
        }

        cc = argv[2][0];
        if (cc == 'b') {
            if (i3 == C_MEM_EDIT)
                *(unsigned char *)ul1 = (unsigned char)ul2;
            Nprintf("0x%08X: %02X\n", ul1, *(unsigned char *)ul1);
        }
        else if (cc == 'w') {
            if (ul1 & 1) {
                Nprintf("address error\n");
                goto retry;
            }
            if (i3 == C_MEM_EDIT)
                *(unsigned short *)ul1 = (unsigned short)ul2;
            Nprintf("0x%08X: %04X\n", ul1, *(unsigned short *)ul1);
        }
        else if (cc == 'l') {
            if (ul1 & 3) {
                Nprintf("address error\n");
                goto retry;
            }
            if (i3 == C_MEM_EDIT)
                *(unsigned long *)ul1 = ul2;
            Nprintf("0x%08X: %08X\n", ul1, *(unsigned long *)ul1);
        }
        else {
            Nprintf("type: b =  8bit\n");
            Nprintf("type: w = 16bit\n");
            Nprintf("type: l = 32bit\n");
        }
        break;
    case C_MEM_DUMP:
        if (argc < 1) {
            Nprintf("argument invalid\n");
            goto retry;
        }
        Nsscanf(argv[1], "%x", &ul1);
        if (argc >= 2) {
            if (argv[2][1] == 'x')
                Nsscanf(argv[2], "%x", &ul2);
            else
                ul2 = (unsigned)atol(argv[2]);
        }
        else {
            ul2 = 256;
        }
        data_dump((char *)ul1, ul2);
        break;
    case C_NINIT:
        Ninit();
        break;
    case C_PINIT:
        if (argc != 1) {
            Nprintf("argument invalid\n");
             goto retry;
        }
        Portinit(argv[1]);
        break;
    case C_PTERM:
        if (argc != 1) {
            Nprintf("argument invalid\n");
             goto retry;
        }
        Portterm(argv[1]);
        break;
    case C_NTERM:
        Nterm();
        break;
    case C_BLD_RT:
        BLOCKPREE();
        BuildRoutes();
        RESUMEPREE();
        break;
    case C_FTPTEST:
        shell_ftp(argc, argv);
        break;
#ifdef USSW_DIRECTED_BROADCAST
    case C_GET_CHG_IP:
        get_change_ip(argc, argv);
        break;
    case C_SET_CHG_IP:
        set_change_ip(argc, argv);
        break;
    case C_SET_IP:
        set_ip_addr(argc, argv);
        break;
    case C_SET_EADDR:
        set_e_addr(argc, argv);
        break;
    case C_SET_IMASK:
        set_ip_mask(argc, argv);
        break;
    case C_SET_GATEWAY:
        set_default_gateway(argc, argv);
        break;
    case C_START_DET_IP:
        start_detect_addr(argc, argv);
        break;
    case C_STOP_DET_IP:
        stop_detect_addr(argc, argv);
        break;
    case C_GET_DETSTAT:
        get_detect_status();
        break;
#endif
    case C_STOP:
        stop_process();
        break;
    case C_END:
        goto term;
    default:
        Nprintf("command invalid\n");
        goto retry;
    }

    goto retry;

term:
    Nterm();

#if (MT != 0)
    KILLTASK();
#else
    return;
#endif

}

typedef struct __TT3_TASK_TBL {
    int command;
    void (*function)(int argc, char *argv[]);
    char *name;
    PRI   prior;
} TT3_TASK_TBL;

TT3_TASK_TBL task_table[] = {

    {C_RARPGET     ,rarp_get    ,"rarp_get"    ,CLIENT_PRIOR},
    {C_EGP         ,send_egp    ,"send_egp"    ,CLIENT_PRIOR},
    {C_ICMP_SEND   ,icmp_send   ,"icmp_send"   ,CLIENT_PRIOR},
    {C_ICMP_RPLY   ,icmp_reply  ,"icmp_reply"  ,CLIENT_PRIOR},
    {C_PING        ,ping        ,"ping"        ,CLIENT_PRIOR},
    {C_SOCK_IP_OPT ,sock_ip_opt ,"sock_ipopt"  ,CLIENT_PRIOR},
    {C_SOCK_FUNC   ,sock_func   ,"sock_func"   ,CLIENT_PRIOR},
    {C_SOCK_RW     ,sock_rw     ,"sock_rw"     ,CLIENT_PRIOR},
    {C_TCP_SOCK    ,sock_tcp    ,"sock_tcp"    ,CLIENT_PRIOR},
    {C_UDP_SOCK    ,sock_udp    ,"sock_udp"    ,CLIENT_PRIOR},
    {C_TCP_DPI     ,dpi_tcp     ,"dpi_tcp"     ,CLIENT_PRIOR},
    {C_UDP_DPI     ,dpi_udp     ,"dpi_udp"     ,CLIENT_PRIOR},
    {C_RST_SOCK    ,rst_socket  ,"rst_socket"  ,CLIENT_PRIOR},
    {C_RST_DPI     ,rst_dpi     ,"rst_dpi"     ,CLIENT_PRIOR},
    {C_BENCH_SOCK  ,bench_sock  ,"bench_sock"  ,CLIENT_PRIOR},
#ifdef INCLUDE_TELNET
    {C_TNSERV      ,tnserv      ,"tnserv"      ,SERV_PRIOR  },
#endif
#if (DHCP >= 1)
    {C_DHCPGET     ,dhcp_get    ,"dhcp_get"    ,CLIENT_PRIOR},
#endif
#if (MT != 0)
    {C_TASK_KILL   ,kill        ,"kill"        ,1           }
#endif
};

#if (MT != 0)
static void print_tskst(UINT stat)
{

    switch (stat) {
    case TTS_RUN :
        Nprintf(" RUNNING           ");
        break;

    case TTS_RDY :
        Nprintf(" READY             ");
        break;

    case TTS_WAI :
        Nprintf(" WAITING           ");
        break;

    case TTS_SUS :
        Nprintf(" SUSPENDED         ");
        break;

    case TTS_WAS :
        Nprintf(" WAITING/SUSPENDED ");
        break;

    case TTS_DMT :
        Nprintf(" DORMANT           ");
        break;

    default:
        Nprintf("*ERROR             ");
        break;

    }

}

static void print_tskname(void *func)
{
int i1, max, len;
char   buf[18];


    max = sizeof(task_table)/sizeof(TT3_TASK_TBL) - 1;

    for ( i1 = 0; i1 < max; i1++ ) {
        if ( (void *)(task_table[i1].function) == func ) {
            memset(buf, 0, 10);
            strcat(buf, task_table[i1].name);
            len = strlen(task_table[i1].name);
            if ( len < 17 ) {
                memset(buf + len, ' ', 17 - len);
            }
            Nprintf(" %s", buf);
            return;
        }
    }

    Nprintf(" 0x%08x       ", func);

}

static void printtask(void)
{
ID     task_id_max, i1;
T_RTSK task_info;
ER     rc;


    BLOCKPREE();


    Nprintf("\n   ID   priority  status            wupcnt suscnt ");
    Nprintf(" taskname          stacksize");

#if 1
    for ( i1 = 0; i1 < TASK_NUM_MAX; i1++ ) {
        rc = ref_tsk(&task_info, i1);
        if ( rc != E_OK ) {
              continue;
        }
#else
    for ( i1 = 0; i1 < task_id_max; i1++ ) {
        rc = ref_tsk(&task_info, i1);
        if ( rc != E_OK ) {
            Nprintf("\n  [%02d] ***************************************", i1);
        }
#endif
        else {
            Nprintf("\n");
            Nprintf("  %04d ",  i1);
            Nprintf("    %3u   ", task_info.tskpri);
            print_tskst(task_info.tskstat);
            Nprintf(" %3d   ",    task_info.wupcnt);
            Nprintf(" %3d   ",    task_info.suscnt);
            if (i1 == (int)shell_task_id) {
                Nprintf(" shell            ");
            }
            else if (i1 == (int)nettask_id[0]) {
                Nprintf(" NetTask0         ");
            }
            else if (i1 == (int)nettask_id[1]) {
                Nprintf(" NetTask1         ");
            }
            else {
                print_tskname(task_info.task);
            }
            Nprintf(" %3d ",      task_info.stksz);
        }
    }

    Nprintf("\n");

    RESUMEPREE();

}

ER RUN_CMDTASK(FP task, PRI prior, int argc, char **argv)
{
ER      ercd;
ID      taskid;
T_CTSK  tsk;


    ercd = E_OK;
    taskid = 0;
    ercd = nxt_tid(&taskid);
    if (ercd < E_OK)
      return (ercd);

    if (
        (taskid < 1) ||
        (taskid > NUMTSK)
    )
        return E_ID;

    tsk.exinf   = NULL;
    tsk.tskatr  = TA_HLNG;
    tsk.task    = task;
    tsk.itskpri = prior;
    tsk.stksz   = TASK_STKSIZ;

    ercd = cre_tsk(taskid, &tsk, argc, argv);
    if (ercd < E_OK)
        return ercd;

    return (sta_tsk(taskid,0));
}
#endif

static void exec_cmd(int command, char *tmp_cmd, char tmp_argc, char **tmp_argv)
{
    int  argc;
    char *pcmd;
    char **argv;
    int i1, i2, max, status;
    TT3_TASK_TBL  *tbl;


#if (MT != 0)
    BLOCKPREE();
    argc = tmp_argc;

    pcmd = (char *)reqmem(GLOBAL, CMDL_SIZE);
    if (!pcmd) {
        Nprintf(" exec_cmd(): reqmem() fails!\n");
        return;
    }
    memset(pcmd, 0, CMDL_SIZE);
    memcpy(pcmd, tmp_cmd, CMDL_SIZE);

    argv = (char **)reqmem(GLOBAL, (sizeof(char *) * ARG_MAX));
    if (!argv) {
        Nprintf(" exec_cmd(): reqmem() fails!\n");
        relmem(pcmd);
        return;
    }
    memset(argv, 0, (sizeof(char *) * ARG_MAX));

    for (i1=0, i2=1; (i1<CMDL_SIZE); i1++) {
        if ((pcmd[i1] == 0) && (pcmd[i1+1] != 0)) {
            argv[i2] = &pcmd[i1+1];
            i2++;
         }
    }
    RESUMEPREE();
#else
    (void)*tmp_cmd;
#endif

    max = sizeof(task_table)/sizeof(TT3_TASK_TBL);
    for (i1 = 0; i1 < max; i1++) {
        tbl = &task_table[i1];
        if ( tbl->command == command) {
#if (MT != 0)
            status = RUN_CMDTASK( (FP)tbl->function, tbl->prior, argc, argv);
            if ( status != E_OK ) {
                Nprintf("  RUNTASK %s() fails\n", tbl->name);
                relmem(argv);
                relmem(pcmd);
            }
            else {
#if DEBUG_LEVEL >= 5
                Nprintf("  RUNTASK %s() is OK!\n", tbl->name);
#endif
            }
#else

            tbl->function(tmp_argc, tmp_argv);

#endif
            break;
        }
    }
}

#if (MT != 0)
TASKFUNCTION kill(int argc, char **argv)
{
    ID id1;
    ER rc;


    if (argc != 1) {
        goto end;
    }

    if ('0' <= *argv[1] && *argv[1] <= '9') {

        id1 = (ID)atoi(argv[1]);
        rc = ter_tsk(id1);
        if ( rc != E_OK ) {
            switch (rc) {
            case E_ID:
                Nprintf("  Task[%d] is out of range!\n", id1);
                break;

            case E_OBJ:
                Nprintf("  Task[%d] tried to terminate itself \n", id1);
                Nprintf("     or Task[%d] is in Dormant state!\n", id1);
                break;

            case E_NOEXS:
            default:
                Nprintf("  Task[%d] does not exist!\n", id1);
                break;

            }
        }
        else {
            del_tsk(id1);
            Nprintf("  Task[%d] is terminated!\n", id1);
        }
    }
    else {
end:
        Nprintf("  Please type \"kill <task id>\" !\n");
    }

    relmem(argv[0]);
    relmem(argv);
    exd_tsk();

}

TASKFUNCTION init_task(void)
{
int  status;

    status = RUNTASK(shell, (PRI) NET_PRIOR);
    if ( status != E_OK ) {
        Nprintf("RUNTASK shell() fails\n");
        goto quit;
    }

quit:
    exd_tsk();

}

void main(void)
{
int status;
ER  ercd;


    init_board();

    memory.p_sysmem = sysmem;
    memory.sysmsz   = SYSMEM_SZ;
    memory.p_mbfmem = mbfmem;
    memory.mbfmsz   = MESBF_SZ;
    memory.p_mplmem = mplmem;
    memory.mplmsz   = MEMPL_SZ;

    ercd = ini_trn(&memory);
    if ( ercd ) {
        Nprintf("ini_trn() fails!\n");
        return;
    }
    Nprintf("TT3! Loaded and initialized\n");

    status = RUNTASK(init_task, (PRI) CLIENT_PRIOR);
    if ( status != E_OK ) {
        Nprintf("RUNTASK init_task() fails\n");
        goto err1;
    }

    ercd = sta_trn();

err1:

    ter_trn();
    Nprintf("TT3! is terminated!\n");

}
#endif

