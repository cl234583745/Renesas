/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPRECEIVESM_1588_H__
#define __MDDELAYRESPRECEIVESM_1588_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID MDDelayRespReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDDelayRespReceiveSM_00_1588(PORTDATA* pstPort);
VOID MDDelayRespReceiveSM_01_1588(PORTDATA* pstPort);
VOID MDDelayRespReceiveSM_02_1588(PORTDATA* pstPort);
VOID MDDelayRespReceiveSM_NP_1588(PORTDATA* pstPort);

BOOL MDDRespRcv_NotEnable_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDDRespRcv_WtFrDResp_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL JugMDDelayResp_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

VOID SetMDDelayReqMgIngresTS_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

VOID computeMDMeanPathDelay_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
