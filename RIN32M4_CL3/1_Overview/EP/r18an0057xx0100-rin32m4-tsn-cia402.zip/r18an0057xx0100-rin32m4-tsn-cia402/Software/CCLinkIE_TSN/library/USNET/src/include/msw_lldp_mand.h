//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _MSW_LLDP_MAND_H_
#define _MSW_LLDP_MAND_H_


#define MSW_LLDP_MOD_MAND   1

#define MSW_CHASSIS_SUB_MIN 1
#define MSW_CHASSIS_SUB_MAX 7
#define MSW_PORTID_SUB_MIN 1
#define MSW_PORTID_SUB_MAX 7


void msw_mand_register(void);
void msw_mand_unregister(void);
int  msw_mand_gettlv(unsigned char *outframe, unsigned short *len, 
                    MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData);

#endif
