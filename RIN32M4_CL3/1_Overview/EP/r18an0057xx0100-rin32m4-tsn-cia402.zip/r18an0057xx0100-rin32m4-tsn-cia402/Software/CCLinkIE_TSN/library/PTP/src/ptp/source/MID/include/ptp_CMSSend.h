/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSSEND_H__
#define __PTP_CMSSEND_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	clockMasterSyncSend(USHORT usEvent, CLOCKDATA*	pstClockData);

CMSSENDSM_GD*		GetCMSSendSM_GD(CLOCKDATA*	pstClockData);
EN_EV_CMSS				GetCMSSendSM_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsCMSSendSM_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


