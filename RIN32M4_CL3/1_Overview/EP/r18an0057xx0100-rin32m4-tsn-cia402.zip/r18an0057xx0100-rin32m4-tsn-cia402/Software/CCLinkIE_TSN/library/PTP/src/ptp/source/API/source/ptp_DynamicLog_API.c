/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_MemManage.h"

#include "ptp_DynamicLog_API.h"
#include "ptp_LogRecord.h"












INT	ptp_LogOperate(
	USHORT		usLogID,
	LOGOPERATE	enOperate)
{
	INT					nRetCode			= RET_EINVAL;
	CLOCKDATA*			pstClockData		= gpstClockDataHPtr;
	LONG				lRet				= RET_ENOERR;


	if (usLogID > PTP_LOGID_DEBUG)
	{
		return nRetCode;
	}
	
	if (enOperate >=LOG_OPERATE_MAX)
	{
		return nRetCode;
	}
	
	if (pstClockData == NULL)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}
	
	lRet = ptp_SystemSemLockWait(pstClockData);
	if (lRet != RET_ENOERR)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}

	nRetCode = ptp_LRSetLogOperate(usLogID, enOperate);

	(VOID)ptp_SystemSemUnLock(pstClockData);
	
	return nRetCode;
}




INT	ptp_SetLogCallBack(
	USHORT		usLogID,
	LOGCB		pfnLogCBFunc)
{
	INT					nRetCode			= RET_EINVAL;
	CLOCKDATA*			pstClockData		= gpstClockDataHPtr;
	LONG				lRet				= RET_ENOERR;


	if (usLogID > PTP_LOGID_DEBUG)
	{
		return nRetCode;
	}
	
	if (pstClockData == NULL)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}
	
	lRet = ptp_SystemSemLockWait(pstClockData);
	if (lRet != RET_ENOERR)
	{
		nRetCode = RET_ESTATE;
		return nRetCode;
	}

	nRetCode = ptp_LRSetLogCallBack(usLogID, pfnLogCBFunc);

	(VOID)ptp_SystemSemUnLock(pstClockData);
	
	return nRetCode;
}









