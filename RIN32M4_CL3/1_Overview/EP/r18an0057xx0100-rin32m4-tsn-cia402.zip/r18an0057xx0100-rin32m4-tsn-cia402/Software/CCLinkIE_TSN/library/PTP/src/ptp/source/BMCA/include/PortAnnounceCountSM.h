/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTANNOUNCECOUNT_H__
#define __PORTANNOUNCECOUNT_H__

#include "ptp_Struct_Port.h"



#ifdef __cplusplus
extern "C" {
#endif

VOID	IncPortAnnGmChangeCount(PORTDATA *pstPort);
VOID	IncPortAnnTimOfLstGmChgEvt(PORTDATA *pstPort);
VOID	IncPortAnnTimOfLstGmPhaseChgEvt(PORTDATA *pstPort);
VOID	IncPortAnnTimOfLstGmFreqChgEvt(PORTDATA *pstPort);
VOID	IncPortAnnRxSyncCount(PORTDATA *pstPort);
VOID	IncPortAnnReceiptTimeoutCount(PAINFORMATIONSM_EV enEvent, PORTDATA *pstPort);
VOID	IncPortAnnRxPTPPktDiscardCnt(PORTDATA *pstPort);
VOID	IncPortAnnTxAnnounceCount(PORTDATA *pstPort);
VOID	IncPortAnnRxAnnounceCount(PORTDATA *pstPort);
ULONG	CalcPortAnnOneHundEtsLong(EXTENDEDTIMESTAMP* pstA_ETimestamp);


#ifdef __cplusplus
}
#endif

#endif
