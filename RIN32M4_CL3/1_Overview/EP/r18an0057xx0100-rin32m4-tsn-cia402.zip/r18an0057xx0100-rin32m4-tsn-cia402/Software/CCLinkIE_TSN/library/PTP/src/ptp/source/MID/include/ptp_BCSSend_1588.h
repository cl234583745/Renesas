/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_BCSSEND_1588_H__
#define __PTP_BCSSEND_1588_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	 boundaryClockSyncSend_1588(USHORT usEvent, CLOCKDATA*	pstClockData);

BCSSENDSM_1588_GD*		GetBCSSendSM_1588_GD(CLOCKDATA*	pstClockData);
EN_EV_BCSS_1588			GetBCSSendSM_1588_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsBCSSendSM_1588_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


