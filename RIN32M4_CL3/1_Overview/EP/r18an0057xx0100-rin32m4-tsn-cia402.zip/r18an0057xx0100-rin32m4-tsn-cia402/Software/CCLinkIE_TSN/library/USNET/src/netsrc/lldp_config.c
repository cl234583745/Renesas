//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#define MIB2
#ifdef MIB2
#include "snmpv3.h"

#if defined(USM_MD5) || defined(USM_SHA) || defined(USM_DES)
extern const MIB mib_usm;
#endif

extern const MIB mib_sys, mib_snmp, mib_engine;

#ifdef MIB2
extern const MIB mib_if, mib_at, mib_ip, mib_icmp, mib_udp;
#ifdef TCP
extern const MIB mib_tcp;
#endif
#endif
#ifdef USSW_LLDP_MIB
extern const MIB mib_lldp;
#endif

static const MIB *mibs[] =
{
    &mib_sys,
#ifdef MIB2
    &mib_if,
    &mib_at,
    &mib_ip,
    &mib_icmp,
#ifdef TCP
    &mib_tcp,
#endif
    &mib_udp,
#endif
#ifdef USSW_LLDP_MIB
    &mib_lldp,
#endif
    &mib_snmp,
    &mib_engine,

#if defined(USM_MD5) || defined(USM_SHA) || defined(USM_DES)
    &mib_usm
#endif
};
static TRAP_HOST primary;

static TRAP_HOST *thosts[] =
{
    &primary
};

#ifdef USNET
extern const TRANSPORT_MAPPING TM_DPI;
#endif
extern const TRANSPORT_MAPPING TM_BSD;



const AGENT_CONTEXT snmp_ac =
{
    mibs, (sizeof(mibs) / sizeof(MIB *)),
    thosts, (sizeof(thosts) / sizeof(TRAP_HOST)), 1, COLDSTART,
    &TM_BSD
};

#endif
