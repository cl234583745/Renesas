//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "lldp.h"
#include "msw_lldp.h"
#include "lldpd.h"
#include "lldpd_config.c"
#include "usnet_supply.h"

LLDPD_REM_TBL_T rem_tbl[LLDPD_REM_TBL_NUM];
LLDPD_MIB_T lldpdMib;
LLDPD_HWPORT_T lldpdhwport[LLDPD_PORT_NUM];

void (*usswLldpdLockFunc)(void) = NULL;
void (*usswLldpdUnLockFunc)(void) = NULL;

#ifdef LLDPD_DEBUG

static void lldpdSettingShow(LLDPD_SETTING_T *data)
{
    int ix, iy;

    LLDPD_LOG_DBG(("lldp_setting: \n"));
    LLDPD_LOG_DBG(("  Port Config: \n"));
    LLDPD_LOG_DBG(("    ifname=%s\n", data->ifname));
    LLDPD_LOG_DBG(("    portEnabled=%d\n", data->portEnabled));
    LLDPD_LOG_DBG(("    sysCap=0x%02x\n", data->sysCap));
    LLDPD_LOG_DBG(("    enblCap=0x%02x\n", data->enblCap));
    LLDPD_LOG_DBG(("  Local Config: \n"));
    LLDPD_LOG_DBG(("    mcBitmap=0x%x\n", data->mcBitmap));
    LLDPD_LOG_DBG(("    adminStatus=%d\n", data->adminStatus));
    LLDPD_LOG_DBG(("    msgTxInterval=%d\n", data->msgTxInterval));
    LLDPD_LOG_DBG(("    msgTxHold=%d\n", data->msgTxHold));
    LLDPD_LOG_DBG(("    reinitDelay=%d\n", data->reinitDelay));
    LLDPD_LOG_DBG(("    notifiyInterval=%d\n", data->notifiyInterval));
    LLDPD_LOG_DBG(("    txCreditMax=%d\n", data->txCreditMax));
    LLDPD_LOG_DBG(("    msgFastTx=%d\n", data->msgFastTx));
    LLDPD_LOG_DBG(("    txFastInit=%d\n", data->txFastInit));
    LLDPD_LOG_DBG(("    notifiyEnableV2=%d\n", data->notifiyEnableV2));
    LLDPD_LOG_DBG(("    tLVsTxEnableV2=0x%x\n", data->tLVsTxEnableV2));
    LLDPD_LOG_DBG(("    chassisSubtype=%d\n", data->chassisSubtype));
    LLDPD_LOG_DBG(("    chassisId=%s\n", data->chassisId));
    LLDPD_LOG_DBG(("    portSubtype=%d\n", data->portSubtype));
    LLDPD_LOG_DBG(("    portId=%s\n", data->portId));
    if (data->tLVsTxEnableV2 & TVLS_TX_EN_PORTDES) {
        LLDPD_LOG_DBG(("    portDes=%s\n", data->portDes));
    } else {
        LLDPD_LOG_DBG(("    portDes=Disable\n"));
    }
    if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSNAME) {
        LLDPD_LOG_DBG(("    sysName=%s\n", data->sysName));
    } else {
        LLDPD_LOG_DBG(("    sysName=Disable\n"));
    }
    if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSDES) {
        LLDPD_LOG_DBG(("    sysDes=%s\n", data->sysDes));
    } else {
        LLDPD_LOG_DBG(("    sysDes=Disable\n"));
    }
    if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSCAP) {
        LLDPD_LOG_DBG(("    syscap.id=%d\n", data->chassisSubtype));
        LLDPD_LOG_DBG(("    syscap.scap=0x%04x\n", 
            data->sysCap));
        LLDPD_LOG_DBG(("    syscap.enbl=0x%04x\n", 
            data->enblCap));
    } else {
        LLDPD_LOG_DBG(("    sysCap=Disable\n"));
    }
    for (ix = 0; ix < MSW_LLDP_MNGTLV_NUM; ix++) {
        if (data->maddrTlv[ix].status == 1) {
            LLDPD_LOG_DBG(("    ix=%d mAddrSubtype=%d\n", 
                ix, data->maddrTlv[ix].mAddrSubtype));
            LLDPD_LOG_DBG(("    ix=%d mAddr=%s\n", 
                ix, data->maddrTlv[ix].mAddr));
            LLDPD_LOG_DBG(("    ix=%d ifNumSubtype=%d\n", 
                ix, data->maddrTlv[ix].ifNumSubtype));
            LLDPD_LOG_DBG(("    ix=%d len=%d oid=", data->maddrTlv[ix].oid.len));
            for (iy = 0; iy < data->maddrTlv[ix].oid.len; iy++) {
                LLDPD_LOG_DBG(("0x%02x:", data->maddrTlv[ix].oid.id[iy]));
            }
            LLDPD_LOG_DBG(("\n"));
        }
    }
}
#endif

static int lldpdInit(void)
{
    int rc;
    int ret = MSW_EC_EPARAM;
    int ix, iy, iz, it;
    int count;
    int pidx, midx;
    int existFlag;
    LLDPD_SETTING_T *data;
    LLDPD_CONFIG_T *pLldpdConfig;
    MSW_LLDP_LOCAL_INFO_T info;

    count = sizeof(lldp_setting) / sizeof(LLDPD_SETTING_T);
#ifdef LLDPD_DEBUG
    LLDPD_LOG_DBG(("lldpdInit: count=%d\n", count));
    for (ix = 0; ix < count; ix++) {
        LLDPD_LOG_DBG(("lldp_setting index=%d\n", ix));
        lldpdSettingShow(&lldp_setting[ix]);
    }
#endif

    for (ix = 0; ix < NNETS; ix++) {
        if (nets[ix].netstat == 0) {
            continue;
        }

        for (iz = 0; iz < count; iz++) {
            if (strcmp(netconf[nets[ix].confix].pname, lldp_setting[iz].ifname)) {
                if (strcmp(netconf[nets[ix].confix].pname, lldp_setting[iz].ifname2)) {
                   continue;
                }
            }
            vUSN_SetLldpSetting(&lldp_setting[iz]);
            data = &lldp_setting[iz];
            
            if (!data->ifname[0]) {
                continue;
            }
            if (data->chassisSubtype != CHA_ID_SUBTYPE_MAC && data->chassisId[0] == 0) {
                continue;
            }
            if (data->portSubtype != POR_ID_SUBTYPE_MAC && data->portId[0] == 0) {
                continue;
            }
            if (data->msgTxInterval < LLDPD_MIN_TX_INTERVAL || 
                LLDPD_MAX_TX_INTERVAL < data->msgTxInterval) {
                continue;
            }
            if (data->msgTxHold < LLDPD_MIN_TX_HOLD || 
                LLDPD_MAX_TX_HOLD < data->msgTxHold) {
                continue;
            }
            if (data->reinitDelay < LLDPD_MIN_REINIT_DELAY || 
                LLDPD_MAX_REINIT_DELAY < data->reinitDelay) {
                continue;
            }
            if (data->notifiyInterval < LLDPD_MIN_NOTIFIY_INTERVAL || 
                LLDPD_MAX_NOTIFIY_INTERVAL < data->notifiyInterval) {
                continue;
            }
            if (data->txCreditMax < LLDPD_MIN_TX_CREDIT_MAX || 
                LLDPD_MAX_TX_CREDIT_MAX < data->txCreditMax) {
                continue;
            }
            if (data->msgFastTx < LLDPD_MIN_FAST_TX_INTERVAL || 
                LLDPD_MAX_FAST_TX_INTERVAL < data->msgFastTx) {
                continue;
            }
            if (data->txFastInit < LLDPD_MIN_TX_FAST_INIT || 
                LLDPD_MAX_TX_FAST_INIT < data->txFastInit) {
                continue;
            }
            if (data->portEnabled != TRUE && data->portEnabled != FALSE) {
                continue;
            }
            switch (data->chassisSubtype) {
                case CHA_ID_SUBTYPE_SHA:
                case CHA_ID_SUBTYPE_IFA:
                case CHA_ID_SUBTYPE_POR:
                case CHA_ID_SUBTYPE_MAC:
                case CHA_ID_SUBTYPE_ADR:
                case CHA_ID_SUBTYPE_IFN:
                case CHA_ID_SUBTYPE_LOC:
                    break;
                default:
                    continue;
            }
            switch (data->portSubtype) {
                case POR_ID_SUBTYPE_IFA:
                case POR_ID_SUBTYPE_POR:
                case POR_ID_SUBTYPE_MAC:
                case POR_ID_SUBTYPE_ADR:
                case POR_ID_SUBTYPE_IFN:
                case POR_ID_SUBTYPE_ACI:
                case POR_ID_SUBTYPE_LOC:
                    break;
                default:
                    continue;
            }
            switch (data->adminStatus) {
                case TX_ONLY:
                case RX_ONLY:
                case TX_AND_RX:
                case DISABLED:
                    break;
                default:
                    continue;
            }
            if (!data->mcBitmap) {
                continue;
            }
            
            lldpdhwport[iz].netno = netconf[nets[ix].confix].netno;
            strncpy(lldpdhwport[iz].ifname,lldp_setting[iz].ifname,sizeof(lldpdhwport[iz].ifname));
            
            it = 0;
            for (iy = 0; iy < MSW_LLDP_MNGTLV_NUM && !it; iy++) {
                if (data->maddrTlv[iy].status == 1) {
                    switch (data->maddrTlv[iy].mAddrSubtype) {
                        case ADDR_SUBTYPE_RESERVED:
                        case ADDR_SUBTYPE_IPV4:
                        case ADDR_SUBTYPE_IPV6:
                            break;
                        default:
                            it = 1;
                            break;
                    }
                    switch (data->maddrTlv[iy].ifNumSubtype) {
                        case IF_NUM_SUBTYPE_UNKNOWN:
                        case IF_NUM_SUBTYPE_IFINDEX:
                        case IF_NUM_SUBTYPE_PORTNUM:
                            break;
                        default:
                            it = 1;
                            break;
                    }
                    if (data->maddrTlv[iy].mAddrSubtype != ADDR_SUBTYPE_IPV4 && 
                        !data->maddrTlv[iy].mAddr[0]) {
                        it = 1;
                    }
                }
            }
            if (it) {
                continue;
            }

            existFlag = FALSE;
            for (iy = 0; iy < LLDPD_PORT_NUM; iy++) {
                if (lldpdMib.lldpdPort[iy].netno < 0) {
                    pidx = iy;
                    break;
                }

                if(!strcmp(lldpdhwport[iy].ifname,data->ifname)){
                    pidx = iy;
                    existFlag = TRUE;
                    break;
                }
            }
            if (iy >= LLDPD_PORT_NUM) {
                continue;
            }

            for (iy = 0; iy < LLDPD_MC_NUM; iy++) {
                if (lldpdMib.lldpdPort[pidx].lldpdAgent[iy].agentEnabled == FALSE) {
                    midx = iy;
                    break;
                }
                if (lldpdMib.lldpdPort[pidx].lldpdAgent[iy].mcBitmap == 
                    data->mcBitmap) {
                    midx = iy;
                    break;
                }
            }
            if (iy > LLDPD_MC_NUM) {
                continue;
            }

            usswLldpdLock();
            if (existFlag == FALSE) {
                if (ix == 0) {
                    lldpdMib.locSysCapSup = data->sysCap;
                    lldpdMib.locSysCapEna = data->enblCap;
                }

                memset(&(lldpdMib.lldpdPort[pidx]), 0x00, sizeof(LLDPD_PORT_T));

                lldpdMib.lldpdPort[pidx].netno = ix;
                lldpdMib.lldpdPort[pidx].portEnabled = data->portEnabled;
                lldpdMib.lldpdPort[pidx].prePortEnabled = data->portEnabled;
                lldpdMib.lldpdPort[pidx].portno = iz;

                lldpdMib.msgTxInterval = data->msgTxInterval;
                lldpdMib.msgTxHoldMult = data->msgTxHold;
                lldpdMib.reinitDelay = data->reinitDelay;
                lldpdMib.notifiyInterval = data->notifiyInterval;
                lldpdMib.txCreditMax = data->txCreditMax;
                lldpdMib.msgFastTx = data->msgFastTx;
                lldpdMib.txFastInit = data->txFastInit;
            }

            lldpdMib.lldpdPort[pidx].lldpdAgent[midx].agentEnabled = TRUE;
            lldpdMib.lldpdPort[pidx].lldpdAgent[midx].mcBitmap = data->mcBitmap;
            pLldpdConfig = &lldpdMib.lldpdPort[pidx].lldpdAgent[midx].lldpdConfig;
            pLldpdConfig->msgTxInterval = data->msgTxInterval;
            pLldpdConfig->msgTxHold = data->msgTxHold;
            pLldpdConfig->reinitDelay = data->reinitDelay;
            pLldpdConfig->notifiyInterval = data->notifiyInterval;
            pLldpdConfig->txCreditMax = data->txCreditMax;
            pLldpdConfig->msgFastTx = data->msgFastTx;
            pLldpdConfig->txFastInit = data->txFastInit;
            pLldpdConfig->notifiyEnableV2 = data->notifiyEnableV2;
            pLldpdConfig->tLVsTxEnableV2 = data->tLVsTxEnableV2;
            usswLldpdUnLock();

            lldpdTxTimSmInit(&lldpdMib.lldpdPort[pidx].lldpdAgent[midx]);
            lldpdTxSmInit(&lldpdMib.lldpdPort[pidx].lldpdAgent[midx]);
            lldpdRxSmInit(&lldpdMib.lldpdPort[pidx].lldpdAgent[midx]);

            memset(&info, 0, sizeof(info));
            strncpy(info.ifname, data->ifname, sizeof(info.ifname));
            info.mcBitmap = data->mcBitmap;
            info.adminStatus = data->adminStatus;

            info.tlv.chassis.iscreate = TRUE;
            info.tlv.chassis.subtype = data->chassisSubtype;
            if (data->chassisSubtype == CHA_ID_SUBTYPE_MAC) {
                memcpy(info.tlv.chassis.id, nets[ix].id.c, Eid_SZ);
                info.tlv.chassis.curlen = Eid_SZ + 1;
            } else {
                memcpy((char *)info.tlv.chassis.id, (char *)data->chassisId, 
                    sizeof(info.tlv.chassis.id));
                info.tlv.chassis.curlen = strlen((char *)info.tlv.chassis.id) + 1;
                if (sizeof(info.tlv.chassis.id) < info.tlv.chassis.curlen) {
                    info.tlv.chassis.curlen = sizeof(info.tlv.chassis.id) + 1;
                }
            }

            info.tlv.portid.iscreate = TRUE;
            info.tlv.portid.subtype = data->portSubtype;
            if (data->portSubtype == POR_ID_SUBTYPE_MAC) {
                memcpy(info.tlv.portid.id, nets[ix].id.c, Eid_SZ);
                info.tlv.portid.curlen = Eid_SZ + 1;
            } else {
                strncpy((char *)info.tlv.portid.id, (char *)data->portId, 
                    sizeof(info.tlv.portid.id));
                info.tlv.portid.curlen = strlen((char *)info.tlv.portid.id) + 1;
                if (sizeof(info.tlv.portid.id) < info.tlv.portid.curlen) {
                    info.tlv.portid.curlen = sizeof(info.tlv.portid.id) + 1;
                }
            }

            info.tlv.ttl.iscreate = TRUE;
            if ((int)data->msgTxInterval * data->msgTxHold < 0xffff) {
                info.tlv.ttl.ttl = (data->msgTxInterval * data->msgTxHold) + 1;
            }
            else {
                info.tlv.ttl.ttl = 0xffff;
            }

            if (data->tLVsTxEnableV2 & TVLS_TX_EN_PORTDES) {
                info.tlv.portdes.status = 1;
                info.tlv.portdes.curlen = strlen((char *)data->portDes);
                if (sizeof(data->portDes) < info.tlv.portdes.curlen) {
                    info.tlv.portdes.curlen = sizeof(data->portDes);
                }
                strncpy((char *)info.tlv.portdes.pdes, (char *)data->portDes, 
                    sizeof(info.tlv.portdes.pdes));
            }

            if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSNAME) {
                info.tlv.sysname.status = 1;
                info.tlv.sysname.curlen = strlen((char *)data->sysName);
                if (sizeof(data->sysName) < info.tlv.sysname.curlen) {
                    info.tlv.sysname.curlen = sizeof(data->sysName);
                }
                strncpy((char *)info.tlv.sysname.name, (char *)data->sysName, 
                    sizeof(info.tlv.sysname.name));
            }

            if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSDES) {
                info.tlv.sysdes.status = 1;
                info.tlv.sysdes.curlen = strlen((char *)data->sysDes);
                if (sizeof(data->sysDes) < info.tlv.sysdes.curlen) {
                    info.tlv.sysdes.curlen = sizeof(data->sysDes);
                }
                strncpy((char *)info.tlv.sysdes.sdes, (char *)data->sysDes, 
                    sizeof(info.tlv.sysdes.sdes));
            }

            if (data->tLVsTxEnableV2 & TVLS_TX_EN_SYSCAP) {
                info.tlv.syscap.status = 1;
                info.tlv.syscap.scap = lldpdMib.locSysCapSup;
                info.tlv.syscap.enbl = lldpdMib.locSysCapEna;
            }

            for (iy = 0; iy < MSW_LLDP_MNGTLV_NUM; iy++) {
                if (data->maddrTlv[iy].status == 1) {
                    info.tlv.mngaddr[iy].status = 1;
                    info.tlv.mngaddr[iy].addr.type = data->maddrTlv[iy].mAddrSubtype;
                    if (data->maddrTlv[iy].mAddrSubtype == ADDR_SUBTYPE_IPV4) {
                        memcpy((char *)info.tlv.mngaddr[iy].addr.addr, 
                            (char *)netconf[nets[ix].confix].Iaddr.c, Iid_SZ); 
                        info.tlv.mngaddr[iy].strlen = Iid_SZ + 1;
                    } else {
                        info.tlv.mngaddr[iy].strlen = strlen((char *)data->maddrTlv[iy].mAddr);
                        if (Max_SZMNG_ADDR < info.tlv.mngaddr[iy].strlen) {
                            info.tlv.mngaddr[iy].strlen = Max_SZMNG_ADDR;
                        }
                        info.tlv.mngaddr[iy].strlen += 1;

                        memcpy((char *)info.tlv.mngaddr[iy].addr.addr, 
                            (char *)data->maddrTlv[iy].mAddr, 
                            sizeof(info.tlv.mngaddr[iy].addr.addr));
                    }
                    info.tlv.mngaddr[iy].iftype = data->maddrTlv[iy].ifNumSubtype;
                    info.tlv.mngaddr[iy].ifnum = lldpdMib.lldpdPort[pidx].portno + 1;
                    info.tlv.mngaddr[iy].obj.len = data->maddrTlv[iy].oid.len;
                    memcpy((char *)info.tlv.mngaddr[iy].obj.id, 
                        (char *)data->maddrTlv[iy].oid.id, data->maddrTlv[iy].oid.len);
                    info.tlv.mngaddr[iy].curlen = info.tlv.mngaddr[iy].strlen + 
                                                   info.tlv.mngaddr[iy].obj.len + 7;
                }
            }

            info.rxCallback = lldpdRxFrameCb;
            info.txFunc = lldpsend;
            lldpdMib.lldpdPort[pidx].lldpdAgent[midx].port = (void *)&lldpdMib.lldpdPort[pidx];
            info.usrData = &(lldpdMib.lldpdPort[pidx].lldpdAgent[midx]);

            rc = mswLldpPortAdd(&info);
            if (rc == MSW_EC_NO_ERROR) {
                somethingChangedRemoteCbSet(ussLLDPAgentTrap);
                ret = MSW_EC_NO_ERROR;
            }
        }
    }

out:
    return ret;
}

int lldpdRun(void)
{
    int ret;

    ret = mswLldpInit();
    if (ret != MSW_EC_NO_ERROR) {
        LLDPD_LOG_ERR(("lldpdRun: mswLldpInit() error ret=%d\n", ret));
        goto END;
    }

    ret = lldpdInit();

    if (ret == MSW_EC_NO_ERROR) {
        lldpdTimerFlagSet(TRUE);
    } else {
        LLDPD_LOG_ERR(("lldpdRun: lldpdInit() error ret=%d\n", ret));
        goto END;
    }

END:
    return ret;
}

void lldpdPortReset(void)
{
    int ix;

    memset(&lldpdMib, 0, sizeof(lldpdMib));
    for (ix = 0; ix < LLDPD_PORT_NUM; ix++) {
        lldpdMib.lldpdPort[ix].netno = -1;
    }
}

void lldpdPortEnable(int netno)
{
    int ix, iy;

    for (ix = 0; ix < LLDPD_PORT_NUM; ix++) {
        if (lldpdMib.lldpdPort[ix].netno == netno) {
            if (lldpdMib.lldpdPort[ix].portEnabled == FALSE) {
                lldpdMib.lldpdPort[ix].portEnabled = TRUE;
            }
            break;
        }
    }
}
void lldpdPortDisable(int netno)
{
    int ix, iy;
    char *ifname;
    LLDPD_PORT_T *port = NULL;
    LLDPD_AGENT_T *agent = NULL;
    LLDPD_REM_TBL_T *tbl1, *tbl2;

    for (ix = 0; ix < LLDPD_PORT_NUM; ix++) {
        if (lldpdMib.lldpdPort[ix].netno == netno) {
            port = &lldpdMib.lldpdPort[ix];
            if (port->portEnabled == TRUE) {
                port->portEnabled = FALSE;
            }
            break;
        }
    }

    if (port == NULL) {
        return;
    }

    ifname = netconf[nets[netno].confix].pname;

    for (ix = 0, iy = 0; ix < LLDPD_MC_NUM; ix++) {
        agent = &port->lldpdAgent[ix];
        tbl1 = agent->pLldpdRemData;
        while (tbl1 != NULL) {
            tbl2 = tbl1->next;
            lldpdRemDataRel(tbl1);
            lldpdMib.remTblDeletes++;

            if (++iy >= LLDPD_REM_TBL_NUM) {
                break;
            }
            tbl1 = tbl2;
        }
        agent->pLldpdRemData = NULL;

        if (0 < iy) {
            mswLldpMibDelete(ifname, agent->mcBitmap); 

            lldpdLstChgTimSet(agent);

            if (lldpdMib.somethingChangedRemoteCb != NULL) {
                lldpdMib.somethingChangedRemoteCb((void *)agent);
            }
        }
    }
}

int lldpdSetLockFunc(void *func)
{
    LLDP_LOG_TRC(("mswSetLockFunc: func=%p\n", func));

    usswLldpdLockFunc = (void(*)(void))func;

    return MSW_EC_NO_ERROR;
}

int lldpdSetUnLockFunc(void *func)
{
    LLDP_LOG_TRC(("mswSetUnLockFunc: func=%p\n", func));

    usswLldpdUnLockFunc = (void(*)(void))func;

    return MSW_EC_NO_ERROR;
}

int lldpdStop(void)
{
    (void)mswLldpTerm();


    lldpdTimerFlagSet(FALSE);

    return MSW_EC_NO_ERROR;
}

