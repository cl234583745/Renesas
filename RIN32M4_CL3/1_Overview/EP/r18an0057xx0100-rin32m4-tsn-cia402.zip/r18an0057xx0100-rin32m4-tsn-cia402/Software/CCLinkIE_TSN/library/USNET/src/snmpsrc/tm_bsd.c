//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#if defined(UNIX)

#include <fcntl.h>
#include <netdb.h>
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/select.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <time.h>
#define closesocket close
extern int errno;
#define ERRNO errno
#define NSTR "TM_Unix"

#elif defined(_WIN32)

#include <winsock.h>
#include <time.h>
#define ERRNO WSAGetLastError()
#ifndef EWOULDBLOCK
#define EWOULDBLOCK WSAEWOULDBLOCK
#endif
#define NSTR "TM_Win32"

#else
#include <errno.h>

#include "net.h"
#include "local.h"
#include "support.h"
#include "socket.h"
extern struct NETCONF netconf[];
extern struct NET nets[];
#define ERRNO errno
#define NSTR "TM_USNET"
#define USNET

#endif

#include "snmpv3.h"

static int sockfd, tsockfd;
static struct sockaddr_in sai, tsai;
static sint16 passive_close(void);

int giHwPort = 0;

static sint16 init(uint8 *ip, uint32 *maxsize, uint8 *name)
{
    struct hostent *hptr;
    int i1;
#ifndef USNET
    char hn[64];

    i1 = gethostname(hn, sizeof(hn));
    if (i1 == 0)
        strcpy(name, hn);
#else
    strcpy((char *)name, localhostname);
#endif

    if (*maxsize > 576)
        *maxsize = 576;

    if (*ip == 0)
    {
        hptr = gethostbyname((char *)name);
        for (i1 = 0; hptr->h_addr_list[i1]; i1++)
        {
            if (*hptr->h_addr_list[i1] != 127)
            {
                memcpy(ip, hptr->h_addr_list[i1], 4);
#if NTRACE
                Nprintf("Host name '%s', IP %u.%u.%u.%u\n",
                    name,
                    (uint8)hptr->h_addr_list[i1][0],
                    (uint8)hptr->h_addr_list[i1][1],
                    (uint8)hptr->h_addr_list[i1][2],
                    (uint8)hptr->h_addr_list[i1][3]);
#endif
                break;
            }
        }
    }

    return 0;
}


static sint16 passive_open(void)
{
    int i1, i2;
    char cc;

    memset((char *)&sai, 0, sizeof(sai));
    sai.sin_family = AF_INET;
    sai.sin_port = htons(161);
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0)
    {
#if NTRACE
        Nprintf("%s: socket() failed %d!\n", NSTR, sockfd);
#endif
        return ERRNO;
    }

    cc = 1;
    i2 = setsockopt(sockfd, (int)SOL_SOCKET, SO_REUSEADDR, &cc, sizeof(i1));
    if (i2 < 0)
    {
#if NTRACE
        Nprintf("%s: setsockopt(SO_REUSEADDR) failed %d!\n", NSTR, i2);
#endif
        i1 = ERRNO;
        closesocket(sockfd);
        return i1;
    }

    i1 = bind(sockfd, (struct sockaddr *)&sai, sizeof(sai));
    if (i1 < 0)
    {
#if NTRACE
        Nprintf("TM_WIN32: bind() failed %d!\n", i1);
#endif
        i1 = ERRNO;
        closesocket(sockfd);
    }

    return i1;
}

static sint16 passive_read(uint8 *buff, uint16 len)
{
    int i1 = sizeof(sai), i2;

	fd_set				stReadFds;
	struct timeval		stTimeVal;
	int i3;
	
	i2 = 0;
	memset(&stReadFds, 0, sizeof(stReadFds));
	FD_SET(sockfd, &stReadFds);
	
	stTimeVal.tv_sec  = 0;
	stTimeVal.tv_usec = 0;
	
	i3 = selectsocket(sockfd + 1, &stReadFds, (void*)0, (void*)0, &stTimeVal);
	
	if (i3 > 0) {
    i2 = recvfrom(sockfd, (char *)buff, len, 0, (struct sockaddr *)&sai, &i1, &giHwPort);
    if (i2 < 0)
    {
        if (ERRNO == EWOULDBLOCK)
            i2 = 0;
        else
        {
#if NTRACE
            Nprintf("%s: recvfrom() failed %d!\n", NSTR, i2);
#endif

            passive_close();
            i2 = passive_open();
        }
    }
    }

    return i2;
}


static sint16 passive_write(const uint8 *buff, uint16 len)
{
    int i1;

    i1 = sendto(sockfd, (char *)buff, len, 0, (struct sockaddr *)&sai, sizeof(sai), giHwPort);
    if (i1 < 0)
    {
#if NTRACE
        Nprintf("TM_WIN32: sendto() failed %d!\n", ERRNO);
#endif

        passive_close();
        i1 = passive_open();
    }

    return i1;
}


static sint16 passive_close(void)
{
    closesocket(sockfd);

    return 0;
}


static sint16 active_open(const uint8 *rhost)
{
    memset((char *)&tsai, 0, sizeof(tsai));
    tsai.sin_family = AF_INET;
    tsai.sin_port = htons(162);
    tsai.sin_addr.s_addr = inet_addr((char *)rhost);
    tsockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (tsockfd < 0)
    {
#if NTRACE
        Nprintf("%s: socket() failed %d\n", NSTR, tsockfd);
#endif
        return ERRNO;
    }

    return 0;
}


static sint16 active_write(const uint8 *buff, uint16 len)
{
    int i1 = sizeof(tsai), i2;

    i2 = sendto(tsockfd, (char *)buff, len, 0, (struct sockaddr *)&tsai, i1, giHwPort);
    if (i2 < 0)
    {
#if NTRACE
        Nprintf("%s: sendto() failed %d\n", NSTR, i2);
#endif
        i2 = ERRNO;
    }

    return i2;
}


static sint16 active_close(void)
{
    closesocket(tsockfd);

    return 0;
}


static uint32 host_time(void)
{
#ifdef USNET
    return TimeMS() / 10;
#else
    return clock() / (CLOCKS_PER_SEC / 100);
#endif
}


const TRANSPORT_MAPPING TM_BSD =
{
    init,

    passive_open,
    passive_read,
    passive_write,
    passive_close,

    active_open,
    active_write,
    0,
    active_close,

    host_time
};

