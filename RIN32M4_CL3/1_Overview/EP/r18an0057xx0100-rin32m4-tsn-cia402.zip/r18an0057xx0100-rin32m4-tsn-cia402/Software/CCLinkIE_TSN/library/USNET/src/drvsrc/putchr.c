//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#if NTRACE > 0
#include "fm4.h"

STATIC UCHAR guchInitChar;

VOID Ninitchr (VOID)
{
	long k;
	
	if (guchInitChar != 0) {
		return;
	}
	
	bFM_MFS4_UART_SCR_TXE = 1;
	bFM_MFS4_UART_SCR_RXE = 1;
	bFM_MFS4_UART_SMR_SOE = 1;

  for ( k = 0; k < 10000; k++); 
	
	guchInitChar = 1;
	
	return;
}

VOID Nputchr (
	CHAR	chData
)
{
	Ninitchr();
	
	while (bFM_MFS4_UART_SSR_TDRE == 0);

	if (chData == '\n') {
		Nputchr('\r');
	}

	while (bFM_MFS4_UART_SSR_TDRE == 0);

	FM_MFS4_UART->TDR = chData;
	
	return;
}

CHAR Ngetchr (VOID)
{
	CHAR chData;
	
	Ninitchr();
	
	while (bFM_MFS4_UART_SSR_RDRF == 0);
	
	chData = FM_MFS4_UART->RDR;

	if (chData == '\r') {
		chData = '\n';
	}
	
	return chData;
}

 LONG Nchkchr (VOID)
{
	
	Ninitchr();

	if (bFM_MFS4_UART_SSR_RDRF == 1) {
		return 1;
	}

	return 0;
}
#endif
