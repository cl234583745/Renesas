/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCCOMMONSM_H__
#define __MDSYNCCOMMONSM_H__

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"

#ifdef __cplusplus
extern "C" {
#endif

BOOL SetMDSyncCorrectionPortIngress(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL SetMDSyncFollowUpCtPortIngress(PORTDATA* pstPort);
BOOL SetMDSyncCorrectionPortEgress(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
