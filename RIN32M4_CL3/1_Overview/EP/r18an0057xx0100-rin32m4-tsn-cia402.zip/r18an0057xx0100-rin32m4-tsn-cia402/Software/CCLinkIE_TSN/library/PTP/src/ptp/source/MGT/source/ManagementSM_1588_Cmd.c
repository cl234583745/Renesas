/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_API_Local.h"

#include "ManagementSM.h"

#ifdef	PTP_USE_MANAGEMENT

#include "ManagementSM_1588.h"

#include "mdtransinterface_msg.h"
#include "PortAnnounceInformationSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "PortStateSelectionSM.h"
#include "MDPdelayReq.h"

#define	MGT_ACT_CMDTBL_SZ				5

const MGT_ACT_SEL_TBL_1588	stMgt_Action_Cmd[MGT_ACT_CMDTBL_SZ] = {
	{MGT_MNM_NULL_MANAGEMENT, 		PTPM_MGT_NULL_MANAGEMENT,		MGT_APPLIES_PORT,	&cmdManagement_0000},
	{MGT_MNM_INITIALIZE,			PTPM_MGT_INITIALIZE,			MGT_APPLIES_PORT,	&cmdManagement_0005},
	{MGT_MNM_FAULT_LOG_RESET,		PTPM_MGT_FAULT_LOG_RESET,		MGT_APPLIES_CLOCK,	&cmdManagement_0007},
	{MGT_MNM_ENABLE_PORT,			PTPM_MGT_ENABLE_PORT,			MGT_APPLIES_PORT,	&cmdManagement_200D},
	{MGT_MNM_DISABLE_PORT,			PTPM_MGT_DISABLE_PORT,			MGT_APPLIES_PORT,	&cmdManagement_200E}
};

static	USHORT	usManageErrId_cmd = 0;

VOID ManagementSM_CMD(MANAGEMENTSM_GD* pstSmGbl, CLOCKDATA* pstClockData, PORTDATA* pstPortData, USHORT usRecvMsgLen)
{
	PTPMSG_MANAGEMENT_1588*	pstMsg			= (PTPMSG_MANAGEMENT_1588*)pstSmGbl->puchMgtRxMsg;
	static	PTPMSG_MANAGEMENT_TLV	stMsgTLV;
	USHORT					usTLVLen		= 0;
	UCHAR*					puchMsgPtr		= NULL;
	SHORT					sLength		= 0;
	SHORT					sLoopNum	= MGT_ACT_CMDTBL_SZ;
	SHORT					sLoop			= 0;

	BOOL					blRet	= FALSE;
	PTPMSG_MANAGEMENT_1588*	pstOutMsg = (PTPMSG_MANAGEMENT_1588*)&pstSmGbl->ulTxMgtMsg;

	PTPMSG_MANAGEMENT_TLV*			pstOutTLV	  = (PTPMSG_MANAGEMENT_TLV*)&pstOutMsg->stManagemant_TLV;
	PTPMSG_MANAGEMENT_ERRSTA_TLV*	pstOutErrTLV = (PTPMSG_MANAGEMENT_ERRSTA_TLV*)&pstOutMsg->stManagemant_TLV;

	puchMsgPtr	 = (UCHAR*)&pstMsg->stManagemant_TLV;


	pstOutMsg->stHeader.usMegLength = 0;

	if (pstMsg->stHeader.usMegLength > usRecvMsgLen)
	{
		sLength	 = usRecvMsgLen - PTPMSG_MANAGEMENT_SZ;
	}
	else
	{
		sLength	 = (SHORT)(pstMsg->stHeader.usMegLength - PTPMSG_MANAGEMENT_SZ);
	}

	while(sLength > 0)
	{
		usTLVLen = ptp_Mdl_ntohMsgManagTLV(puchMsgPtr, &stMsgTLV, sLength);
		if (usTLVLen == 0)
		{
			break;
		}
		blRet	= FALSE;
		if (stMsgTLV.usTLVType != PTPM_TLVTYP_MANAGEMENT)
		{
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_MGTSM_1588_GET, PTP_LOGVE_87000002);

			usTLVLen += stMsgTLV.usLengthField - PTPMSG_MGTTLV_MANAGEMENTID_SZ;

			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);
		}
		else {

			for (sLoop = 0; sLoop < sLoopNum; sLoop++)
			{
				if (stMsgTLV.usManagementId == stMgt_Action_Cmd[sLoop].usManagementId)
				{
					if ((stMgt_Action_Cmd[sLoop].enTypeApplies == MGT_APPLIES_PORT)
						&& (pstPortData != NULL))
					{
						blRet = (*stMgt_Action_Cmd[sLoop].pfnFunc)(pstPortData, &stMsgTLV, pstOutTLV);
					}
					else if (stMgt_Action_Cmd[sLoop].enTypeApplies == MGT_APPLIES_CLOCK)
					{
						blRet = (*stMgt_Action_Cmd[sLoop].pfnFunc)(pstClockData, &stMsgTLV, pstOutTLV);
					}
					else
					{
					}
					break;
				}
			}
			if (blRet)
			{
				SetTxManagementMsg(pstSmGbl, pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else if ((blRet == FALSE) && (sLoop == sLoopNum))
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, PTPM_MGTER_NO_SUCH_ID);
				SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV *)pstOutTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
			}
			else
			{
				SetManagementErrorTLVInfo(&stMsgTLV, (PTPMSG_MANAGEMENT_ERRSTA_TLV *)pstOutTLV, usManageErrId_cmd);
				SetTxManagementMsg(pstSmGbl, (PTPMSG_MANAGEMENT_TLV*)pstOutErrTLV, pstPortData);
				pstOutTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstOutMsg) + pstOutMsg->stHeader.usMegLength);
				break;
			}
			puchMsgPtr += usTLVLen;
			sLength = (SHORT)(sLength - usTLVLen);

		}
	}

	pstOutMsg = (PTPMSG_MANAGEMENT_1588 *)pstSmGbl->ulTxMgtMsg;
	if (pstOutMsg->stHeader.usMegLength)
	{
		TxManagementMsg(pstSmGbl, pstClockData);
	}

	return;
}

BOOL cmdManagement_0000(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL cmdManagement_0005(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{

	USHORT	usDataFieldLen = 0;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);
	return TRUE;
}

BOOL cmdManagement_0007(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	INT		nRet;
	USHORT	usInfoLen	= sizeof(MGT_PATH_TRACE_ENABLE);

	nRet = SetIe1588FaultLogReset(pvData, (UCHAR*)&pstInTLV->stDataField, usInfoLen, &usDataFieldLen);
	if (nRet != RET_ENOERR) {
		return FALSE;
	}

	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, 0);
	return TRUE;
}

BOOL cmdManagement_200D(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;
	PORTDATA*		pstPort		= (PORTDATA*)pvData;
	PORT_1588_DS*	pstPort_1588	= &pstPort->stPort_1588_DS;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);


	if (pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] == ENUM_PORTSTATE_DISABLED)
	{
#ifdef	PTP_USE_BMCA
		if ( pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
		{
			portAnnounceInformationSM( PTP_EV_BEGIN, (PORTDATA*)pvData );
		}
		else
#endif
		{
			portAnnounceInformationExtSM( PTP_EV_BEGIN, (PORTDATA*)pvData );
		}

		ptp_portenable_des((PORTDATA*)pvData);
		if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
		{
			MDPdelayReq(PTP_EV_BEGIN, pvData);
		}
	}
	return TRUE;
}

BOOL cmdManagement_200E(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	USHORT	usDataFieldLen = 0;

	PORTDATA*		pstPort 	= (PORTDATA*)pvData;
	PORT_1588_DS*	pstPort_1588 = &pstPort->stPort_1588_DS;
	SetMGT_TLVHeaderInfo(pstInTLV, pstOutTLV, usDataFieldLen);


	if (pstPort->pstClockData->stClock_GD.enSelectedState[pstPort->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_DISABLED)
	{
		if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == TRUE)
		{
			portAnnounceInformationExtSM(PTP_EV_BEGIN, (PORTDATA*)pvData);
		}
		else
		{
#ifdef	PTP_USE_BMCA
			pstPort->stPortBMC_GD.enInfoIs = DISABLED;
			pstPort->pstClockData->stBMC_GD.blReselect[pstPort->stPortDS.stPortIdentity.usPortNumber] = TRUE;
			pstPort->pstClockData->stBMC_GD.blSelected[pstPort->stPortDS.stPortIdentity.usPortNumber] = FALSE;
			pstPort->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_DESIGNATED_ENABLED;

			portStateSelectionSM(PTP_EV_RESELECT_PORT, pstPort);
			ptp_portdisable_des((PORTDATA*)pvData);

#endif
		}

		if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
		{
			MDPdelayReq(PTP_EV_CLOSE,pvData);
		}
	}
	return TRUE;
}

BOOL cmdManagement_NOP(VOID* pvData, PTPMSG_MANAGEMENT_TLV* pstInTLV, PTPMSG_MANAGEMENT_TLV* pstOutTLV)
{
	return FALSE;
}
#endif
