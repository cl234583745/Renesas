/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#include "AnnounceIntvalSet.h"
#ifdef	PTP_USE_IEEE802_1
#include "AnnounceIntvalSet_1AS.h"
#endif


VOID AnnounceIntervalSettingSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET, PTP_LOGVE_82080001);
#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		AnuncIntvalSetSM_1AS(usEvent, pstPort);
		return;
	}
#endif
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET, PTP_LOGVE_82000002);
	return;
}

AISSETTINGM_GD* GetAnuncIntvSetGlobal(PORTDATA* pstPort)
{
	return &pstPort->stAISSettingM_GD;
}

ANUNCINTVSET_EV GetAnuncIntvSetEvent(USHORT usEvent, PORTDATA* pstPort)
{
	ANUNCINTVSET_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = ANUNCI_E_BEGIN;
		break;
		case PTP_EV_USEMGTSETABLELOGANNINT_ON:
			enEvt = ANUNCI_E_USEMGTSETTLOGANNINT_ON;
		break;
		case PTP_EV_USEMGTSETABLELOGANNINT_OF:
			enEvt = ANUNCI_E_USEMGTSETTLOGANNINT_OF;
		break;
		case PTP_EV_RCVDSIGNALINGMSG2:
			enEvt = ANUNCI_E_RCVDSIGNALINGMSG2;
		break;
		case PTP_EV_CLOSE:
			enEvt = ANUNCI_E_CLOSE;
		break;

		default:
			enEvt = ANUNCI_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

ANUNCINTVSET_ST	GetAnuncIntvSetStatus(PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;
	ANUNCINTVSET_ST	enSts = ANUNCI_STATUS_MAX;

	pstGbl = GetAnuncIntvSetGlobal(pstPort);
	if (pstGbl->enStsAnnounceIntvalSet <  ANUNCI_STATUS_MAX)
	{
		enSts = pstGbl->enStsAnnounceIntvalSet;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_ANNINTVALSET, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetAnuncIntvSetStatus(ANUNCINTVSET_ST enSts, PORTDATA* pstPort)
{
	AISSETTINGM_GD*	pstGbl = NULL;

	pstGbl = GetAnuncIntvSetGlobal(pstPort);

	pstGbl->enStsAnnounceIntvalSet = enSts;
	return;
}
#endif
