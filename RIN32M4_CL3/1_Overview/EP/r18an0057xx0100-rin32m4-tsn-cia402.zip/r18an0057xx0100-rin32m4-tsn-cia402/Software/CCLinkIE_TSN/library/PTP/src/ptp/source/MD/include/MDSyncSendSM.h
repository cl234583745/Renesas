/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDSYNCSENDSM_H__
#define __MDSYNCSENDSM_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDSyncSendSM(USHORT usEvent, PORTDATA* pstPort);

MDSSENDSM_GD*		GetMDSyncSndSMGlobal(PORTDATA* pstPort);
MDSYNCSNDSM_EV		GetMDSyncSndEvent(USHORT usEvent, PORTDATA* pstPort);
MDSYNCSNDSM_ST		GetMDSyncSndStatus(PORTDATA* pstPort);
VOID				SetMDSyncSndStatus(MDSYNCSNDSM_ST enSts, PORTDATA* pstPort);

VOID	IncMDSyncSndTxSyncCount(PORTDATA* pstPort);
VOID	IncMDSyncSndTxFollowUpCount(PORTDATA* pstPort);
VOID	IncMDSyncSndTxOneStepSyncCount(PORTDATA* pstPort);

BOOL	SetMDSyncMgEgresTimestamp(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
