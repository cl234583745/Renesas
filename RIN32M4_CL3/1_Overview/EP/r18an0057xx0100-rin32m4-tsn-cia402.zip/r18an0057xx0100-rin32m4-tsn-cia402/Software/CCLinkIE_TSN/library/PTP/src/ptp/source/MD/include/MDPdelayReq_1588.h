/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDPDELAYREQ_1588_H__
#define __MDPDELAYREQ_1588_H__

#define IsDecMDPdelayTwoStep_1588(a)	 MPTPMSG_H_GET_FLAGS0_TWOSTEP(&a->stPdlyResp_1588.stHeader)

#ifdef __cplusplus
extern "C" {
#endif

VOID MDPdelayReq_1588(USHORT usEvent, PORTDATA* pstPort);
VOID MDPdelayReq_00_1588(PORTDATA* pstPort);
VOID MDPdelayReq_01_1588(PORTDATA* pstPort);
VOID MDPdelayReq_02_1588(PORTDATA* pstPort);
VOID MDPdelayReq_03_1588(PORTDATA* pstPort);
VOID MDPdelayReq_04_1588(PORTDATA* pstPort);
VOID MDPdelayReq_05_1588(PORTDATA* pstPort);
VOID MDPdelayReq_06_1588(PORTDATA* pstPort);
VOID MDPdelayReq_07_1588(PORTDATA* pstPort);
VOID MDPdelayReq_08_1588(PORTDATA* pstPort);
VOID MDPdelayReq_NP_1588(PORTDATA* pstPort);

BOOL MDPdlyReq_NotEnable_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_IntSndPDReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_Reset_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_SndPDReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_WtFrPDResp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_WtFrPDRpFollowUp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_TwoWtFrPDlyIntvl_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL MDPdlyReq_OneWtFrPDlyIntvl_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL ConMDPdelayResp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL ConMDPdelayRespFollowUp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL JugMDPdlyReq_PDRsp_1588(MDPREQSM_GD* pstSmGbl);
BOOL JugMDPdlyReq_PDRspFollowUp_1588(MDPREQSM_GD* pstSmGbl);

VOID SetMDPdlyReqMgIngresTmstmp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
VOID SetMDPdlyRespMgEgresTmstmp_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL SetPdelayReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL TxPdelayReq_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

BOOL computeMDPdelayRateRatio_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);
BOOL CalMDPdlyRateRatio_1588(MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort, DOUBLE* pdbRateRatio);

BOOL computeMDPdelayPropTime_1588(BOOL blTwoStepFlag, MDPREQSM_GD* pstSmGbl, PORTDATA* pstPort);

VOID SetCmptMDPdlyRatioStack_1588( MDPDLYREQSM_STACK_MANAGE* pstPdlyIntStackMan, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
