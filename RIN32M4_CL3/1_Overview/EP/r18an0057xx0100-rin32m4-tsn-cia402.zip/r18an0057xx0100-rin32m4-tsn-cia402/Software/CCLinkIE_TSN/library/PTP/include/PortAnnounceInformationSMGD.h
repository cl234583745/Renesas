/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTANNOUNCEINFORMATIONGD_H__
#define __PORTANNOUNCEINFORMATIONGD_H__
#include <ptp_type.h>
#include <ptp_Struct_Port.h>



typedef	enum tagPAINFORMATIONSM_ST
{
	PINFSM_NONE = 0,
	PINFSM_DISABLED,
	PINFSM_AGED,
	PINFSM_UPDATE,
	PINFSM_CURRENT,
	PINFSM_RECEIVE,
	PINFSM_SUPERIOR_MASTER_PORT,
	PINFSM_REPEATED_MASTER_PORT,
	PINFSM_INFERIOR_MASTER_OR_OTHER,
	PINFSM_STATUS_MAX
} PAINFORMATIONSM_ST;
#define	PAINFORMATIONSM_ST_MAX	9

typedef enum tagPAINFORMATIONSM_EV {
	PINF_EV_BEGIN = 0,
	PINF_EV_PER_PORT_RCVDMSG,
	PINF_EV_ASCAPABLE,
	PINF_EV_SELECTED_PORT,
	PINF_EV_ANNOUNCERECEIPTTIMEOUT,
	PINF_EV_SYNCRECEIPTTIMEOUT,
	PINF_EV_QUALIFICATIONTIMEOUT,
	PINF_EV_RCVDINFO_SUPERMASTER,
	PINF_EV_RCVDINFO_REPEDMASTER,
	PINF_EV_RCVINF_INFERIORMASTER,
	PINF_EV_RCVDINFO_OTHERINF,
	PINF_EV_CLOSE,
	PINF_EV_EVENT_MAX
} PAINFORMATIONSM_EV;
#define	PAINFORMATIONSM_EV_MAX	12

typedef struct tagPAINFORMATIONSM_GD
{
	USCALEDNS		stAnnounceReceiptTimeoutTime;
	PRIORITY_VECT	stMessagePriority;
	UCHAR			uchRcvdInfo;
	PAINFORMATIONSM_ST enStatus;
} PAINFORMATIONSM_GD;

#define	RCVINF_RT_RepeatedMasterInfo	0U
#define	RCVINF_RT_SuperiorMasterInfo	1U
#define	RCVINF_RT_InferiorMasterInfo	2U
#define	RCVINF_RT_OtherInfo				3U
#define	RCVINF_RT_SuperiorMaster_Fslv	4U

#endif
