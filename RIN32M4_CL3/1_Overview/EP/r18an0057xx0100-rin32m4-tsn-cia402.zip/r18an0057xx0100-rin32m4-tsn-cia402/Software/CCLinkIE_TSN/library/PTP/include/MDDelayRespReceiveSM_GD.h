/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPRECEIVESM_GD_H__
#define __MDDELAYRESPRECEIVESM_GD_H__

#include "ptp_Event.h"
#include "PTP_Message.h"

typedef enum tagMDDRESPRCVSM_ST {
	MDDRPR_NONE = 0,
	MDDRPR_NOT_ENABLED,
	MDDRPR_WAITING_FOR_DELAY_RESP,
	MDDRPR_STATUS_MAX

}	MDDRESPRCVSM_ST;
#define	DMDDRPR_STATUS_MAX			3

typedef enum tagMDDRESPRCVSM_EV {
	MDDRPR_E_BEGIN = 0,
	MDDRPR_E_RCVD_DELAY_RESP,
	MDDRPR_E_CLOSE,
	MDDRPR_E_EVENT_MAX

}	MDDRESPRCVSM_EV;
#define	DMDDRPR_E_EVENT_MAX			3

typedef struct tagMDDRESPRVSM_GD
{
	MDDRESPRCVSM_ST		enStsMDDRespRcv;
	
	BOOL				blRcvdDelayResp;
	PTPMSG*				pstRcvdDelayResp;

} MDDRESPRVSM_GD;

#endif
