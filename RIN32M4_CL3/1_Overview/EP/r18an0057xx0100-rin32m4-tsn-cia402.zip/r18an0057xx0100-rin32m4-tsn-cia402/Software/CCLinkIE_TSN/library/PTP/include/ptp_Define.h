/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_DEFINE_H__
#define __PTP_DEFINE_H__

#define	MAX_CLOCK					MAX_DOMAIN
#define	PTPMMANNOBLK_NUM			PTPMMFOREBLK_NUM * 3U

#define	PTP_MAX_PORT_NUMBER			(MAX_PORT)

#define	PTP_MAX_PATHTRACE			(179)


#ifndef TRUE
#define TRUE						(1)
#endif

#ifndef FALSE
#define FALSE						(0)
#endif


#define PTP_USE_DREQ_INTERVAL_ME

#ifndef ptp_dbg_msg

#define ptp_dbg_msg(sts, msg)

#endif


#endif
