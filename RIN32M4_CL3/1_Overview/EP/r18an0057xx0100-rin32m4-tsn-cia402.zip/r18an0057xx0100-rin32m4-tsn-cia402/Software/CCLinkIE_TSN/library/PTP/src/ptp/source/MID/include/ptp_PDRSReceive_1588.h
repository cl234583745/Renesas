/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRSRECEIVE_1588_H__
#define __PTP_PDRSRECEIVE_1588_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif

VOID	portDelayRespReceive_1588(USHORT usEvent, PORTDATA* pstPortData);

PDRSRECEIVESM_1588_GD*	GetPDRSReceiveSM_1588_GD(PORTDATA* pstPortData);
EN_EV_PDRSR				GetPDRSReceiveSM_1588_Event(USHORT usEvent, PORTDATA* pstPortData);
BOOL					IsPDRSReceiveSM_1588_Status(PORTDATA*	pstPortData);

#ifdef __cplusplus
}
#endif


#endif


