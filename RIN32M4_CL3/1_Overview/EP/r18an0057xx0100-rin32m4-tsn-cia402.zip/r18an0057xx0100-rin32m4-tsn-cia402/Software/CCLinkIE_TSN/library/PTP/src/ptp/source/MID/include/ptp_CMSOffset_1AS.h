/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CMSOFFSET_1AS_H__
#define __PTP_CMSOFFSET_1AS_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





#ifdef __cplusplus
extern "C" {
#endif

VOID	clockMasterSyncOffset_1AS(USHORT usEvent, CLOCKDATA*	pstClockData);

CMSOFFSETSM_1AS_GD*		GetCMSOffsetSM_1AS_GD(CLOCKDATA*	pstClockData);
EN_EV_CMSO				GetCMSOffsetSM_1AS_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL					IsCMSOffsetSM_1AS_Status(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif


