/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifndef __PTP_GLOBALDATA_H__
#define __PTP_GLOBALDATA_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_LCEntity_GD.h"
#include "ptp_CMLDS.h"


#if 1
#define	IS_PTP_STARTUP()	(	\
					(gblStartUpInit) && 	\
					(gblStartUpConfig)		\
)

#define	IS_PTP_OPEN()		(gblStartUpOpen)

#endif
#ifdef __cplusplus
extern "C" {
#endif


extern CLOCKDATA*		gpstClockDataHPtr;
extern USCALEDNS		gstCurrentTime;
extern BOOL				gblCurrentTimeInit;



extern VOID*			gpvLockHandleTimer;
extern VOID*			gpvLockHandlePTP;
#if 1
extern BOOL				gblStartUpInit;
extern BOOL				gblStartUpConfig;
extern BOOL				gblStartUpOpen;
#endif

extern CURRENTTIMEQUE*	gpstCurrentTimeQuePtr;
#ifdef PTP_USE_ME_HW_ASSIST
extern EXTENDEDTIMESTAMP gstMasterLocalOffset;
extern USCALEDNS		gstLocatTimeForMaster;
#endif
extern DOUBLE			gdbClockSourceFreqOffset;
extern SCALEDNS			gstClockSourcePhaseOffset;
extern USHORT			gusClockSourceTimeBaseIndicator;
extern USHORT			gusClockSourceTimeBaseIndOld;
extern SCALEDNS			gstClockSourceLastGmPhaseChange;
extern EXTENDEDTIMESTAMP	gstMasterTime;
extern USCALEDNS		gstCurrentMasterTime;
extern BOOL				gblCurrentMasterTimeInit;
extern CMLDS_MANAGE*	gpstCmldsPtr;
extern MDPDLYREQSM_STACK_MANAGE*	gpstMdPdlyTspStk;
extern CMLDSPORT_1AS_DS*			gpstCmldsPort_1AS_DS;
extern CMLDSPORTSTATISTICS_1AS_DS*	gpstCmldsPortStatistics_1AS_DS;


extern DOUBLE			gdbRateRatio;
extern DOUBLE			gdbClockSourceLastGmFreqChange;
extern DOUBLE			gdbGmRateRatio;
extern USCALEDNS		gstLocalTime;
extern DOUBLE			gdbCMFreqOffset;
extern SCALEDNS			gstCMPhaseOffset;
extern CLOCKDATA*		gpstBestDomain;
extern LOGRECORD_GD		gstLogRecord_GD;
extern MEMMANAGE_GD		gstMemManage_GD;
extern DREQTMOMAN 		gstDreqTmoManage[MAX_PORT];
extern SYNCTMOMAN 		gstSyncTmoManage[MAX_PORT];



#ifdef __cplusplus
}
#endif

#endif

