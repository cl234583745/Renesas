/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#define D_FUNC	0


#ifdef	PTP_USE_IEEE802_1

#include "MDLkDlyIntvalSet.h"
#include "MDLkDlyIntvalSet_1AS.h"

#include "PTP_GlobalData.h"

static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData );


VOID (*const MDLkDlyIntvalSet_1AS_Matrix[DMDLKDI_STATUS_MAX][DMDLKDI_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_NP_1AS},
	{&LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_02_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_00_1AS},
	{&LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_02_1AS, &LinkDelayIntvalSetSM_03_1AS, &LinkDelayIntvalSetSM_00_1AS},
	{&LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_01_1AS, &LinkDelayIntvalSetSM_NP_1AS, &LinkDelayIntvalSetSM_03_1AS, &LinkDelayIntvalSetSM_00_1AS}
};
static CMLDSPORT_1AS_DS* GetCmldsPortDS( PORTDATA* pstPortData )
{
	CMLDSPORT_1AS_DS *pstCmldsPortDS;
	INT nIndex;

	if (   (gpstCmldsPtr == NULL)
	    || (pstPortData == NULL ) )
	{
		return NULL;
	}
	nIndex = pstPortData->stPort_GD.lCmldsPortNumber;
	pstCmldsPortDS = &gpstCmldsPtr->stCmldsPortManage[nIndex].stCmldsPort_1AS_DS;

	return pstCmldsPortDS;
}

VOID LinkDelayIntvalSetSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	LDLYINTVSET_EV	enEvt = MDLKDI_E_EVENT_MAX;
	LDLYINTVSET_ST	enSts = MDLKDI_STATUS_MAX;
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET_1AS, PTP_LOGVE_82080001);
	enEvt = GetLkDlyIntvSetEvent(usEvent, pstPort);

	enSts = GetLkDlyIntvSetStatus(pstPort);

	if ((enSts != MDLKDI_STATUS_MAX) && (enEvt != MDLKDI_E_EVENT_MAX))
	{
		(*MDLkDlyIntvalSet_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET_1AS, PTP_LOGVE_82000006);
	}
	return;
}

VOID LinkDelayIntvalSetSM_00_1AS(PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "LinkDelayIntvalSetSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	LnkDlyIntSet_NotEnabled_1AS(pstGbl, pstPort);
	SetLkDlyIntvSetStatus(MDLKDI_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("LinkDelayIntvalSetSM_00_1AS::-\n") );

	return;
}

VOID LinkDelayIntvalSetSM_01_1AS(PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;
	BOOL				blRet;
	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	blRet = LnkDlyIntSet_NotEnabled_1AS(pstGbl, pstPort);
	if (blRet)
	{
		SetLkDlyIntvSetStatus(MDLKDI_NOT_ENABLED, pstPort);
	}
	else
	{
		LnkDlyIntSet_Initialize_1AS(pstGbl, pstPort);
		SetLkDlyIntvSetStatus(MDLKDI_INITIALIZE, pstPort);
	}
	return;
}

VOID LinkDelayIntvalSetSM_02_1AS(PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	LnkDlyIntSet_Initialize_1AS(pstGbl, pstPort);
	SetLkDlyIntvSetStatus(MDLKDI_INITIALIZE, pstPort);
	return;
}

VOID LinkDelayIntvalSetSM_03_1AS(PORTDATA* pstPort)
{
	LDISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetLkDlyIntvSetGlobal(pstPort);

	if (pstGbl->blRcvdSignalingMsg1 == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET_1AS, PTP_LOGVE_82000009);
		LnkDlyIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetLkDlyIntvSetStatus(MDLKDI_NOT_ENABLED, pstPort);
		return;
	}
	if (pstGbl->pstRcvdSignaling == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET_1AS, PTP_LOGVE_8200000A);
		LnkDlyIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetLkDlyIntvSetStatus(MDLKDI_NOT_ENABLED, pstPort);
		return;
	}

	LnkDlyIntSet_SetInterval_1AS(pstGbl, pstPort);
	SetLkDlyIntvSetStatus(MDLKDI_SET_INTERVAL, pstPort);
	return;
}

VOID LinkDelayIntvalSetSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDLDINTVALSET_1AS, PTP_LOGVE_82000007);
	return;
}


BOOL LnkDlyIntSet_NotEnabled_1AS(LDISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS* pstCmldsPortDS;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_NotEnabled_1AS::+\n"));

	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	if (pstCmldsPortDS->blUseMgtSttblLogPdReqInterval)
	{
		pstCmldsPortDS->chCurrentLogPdelayReqInterval
			= pstCmldsPortDS->chMgtSttblLogPdReqInterval;
		computeLnkDlyInterval_1AS(pstPort);

		pstPort->stMDPReqSM_GD.blNeighborRateRatioValid = TRUE;

		pstPort->stPort_GD.dbNeighborRateRatio = 1.0;

		pstCmldsPortDS->lNeighborRateRatio = 0;


	}

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_NotEnabled_1AS::-\n"));

	return pstCmldsPortDS->blUseMgtSttblLogPdReqInterval;
}

VOID LnkDlyIntSet_Initialize_1AS(LDISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS* pstCmldsPortDS;
	PORT_GD*		  pstPortGD	  = &pstPort->stPort_GD;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_Initialize_1AS::+\n"));

	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	pstCmldsPortDS->chCurrentLogPdelayReqInterval
		= pstCmldsPortDS->chInitialLogPdelayReqInterval;

	computeLnkDlyInterval_1AS(pstPort);

	pstPortGD->blComputeNeighborRateRatio = TRUE;

	pstPortGD->blComputeNeighborPropDelay = TRUE;

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_Initialize_1AS::-\n"));
	return;
}

VOID LnkDlyIntSet_SetInterval_1AS(LDISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS* pstCmldsPortDS;
	PORT_GD*		  pstPortGD	  = &pstPort->stPort_GD;
	PTPMSG_SIGNALING_1AS* pstMsg	  = &pstSmGbl->pstRcvdSignaling->stSignaling_1AS;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_SetInterval_1AS::+\n"));

	pstCmldsPortDS = GetCmldsPortDS( pstPort );

	CHAR chLkDlyInterval =
		pstSmGbl->pstRcvdSignaling->stSignaling_1AS.stIntervalReq_TLV.chLinkDelayInterval;
	switch(chLkDlyInterval)
	{
	case PTPM_TLV_LINK_DELAY_INTVAL_NCHG:
		break;
	case PTPM_TLV_LINK_DELAY_INTVAL_INIT:
		pstCmldsPortDS->chCurrentLogPdelayReqInterval
			= pstCmldsPortDS->chInitialLogPdelayReqInterval;

		computeLnkDlyInterval_1AS(pstPort);
		break;
	default:
		pstCmldsPortDS->chCurrentLogPdelayReqInterval = chLkDlyInterval;

		computeLnkDlyInterval_1AS(pstPort);
		break;
	}
	if ( MPTPM_ISFLAG_CNEIGHBORRATE(&pstMsg->stIntervalReq_TLV) )
	{
		pstPortGD->blComputeNeighborRateRatio = TRUE;
	}else{
		pstPortGD->blComputeNeighborRateRatio = FALSE;
	}
	
	if ( MPTPM_ISFLAG_CNEIGHBORPROP(&pstMsg->stIntervalReq_TLV) )
	{
		pstPortGD->blComputeNeighborPropDelay = TRUE;
	}else{
		pstPortGD->blComputeNeighborPropDelay = FALSE;
	}

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;

	ptp_dbg_msg(D_FUNC, ("LnkDlyIntSet_SetInterval_1AS::-\n"));
	return;
}

VOID computeLnkDlyInterval_1AS(PORTDATA* pstPort)
{
	CMLDSPORT_1AS_DS*	pstCmldsPortDS;
	PORTMD_GD*			pstPortMD		= &pstPort->stPortMD_GD;
	USCALEDNS			stA_USNs= {0};

	ptp_dbg_msg(D_FUNC, ("computeLnkDlyInterval_1AS::+\n"));

	pstCmldsPortDS = &gpstCmldsPtr->stCmldsPortManage[pstPort->stPort_GD.lCmldsPortNumber].stCmldsPort_1AS_DS;
	stA_USNs.ulNsec_lsb = CONST10_9;
	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstCmldsPortDS->chCurrentLogPdelayReqInterval,
		&pstPortMD->stPdelayReqInterval);

	ptp_dbg_msg(D_FUNC, ("computeLnkDlyInterval_1AS::-\n"));
	return;
}

#endif
#endif
