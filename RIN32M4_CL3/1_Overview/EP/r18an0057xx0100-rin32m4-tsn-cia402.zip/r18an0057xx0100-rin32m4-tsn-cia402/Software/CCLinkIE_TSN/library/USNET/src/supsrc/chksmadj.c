//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

void ussChecksumAdjust(unsigned char *chksum, unsigned char *optr, int olen,
    unsigned char *nptr, int nlen)
{
    long x, old, new;

    x = chksum[0] * 256 + chksum[1];
    x = ~x & 0xFFFF;
    while (olen) {
        old = optr[0] * 256 + optr[1];
        optr += 2;
        x -= old & 0xffff;
        if (x <= 0) {
            x--;
            x &= 0xffff;
        }
        olen -= 2;
    }
    while (nlen) {
        new = nptr[0] * 256 + nptr[1];
        nptr += 2;
        x += new & 0xffff;
        if (x & 0x10000) {
            x++;
            x &= 0xffff;
        }
        nlen -= 2;
    }
    x = ~x & 0xFFFF;
    chksum[0] = x / 256;
    chksum[1] = x & 0xff;
}

