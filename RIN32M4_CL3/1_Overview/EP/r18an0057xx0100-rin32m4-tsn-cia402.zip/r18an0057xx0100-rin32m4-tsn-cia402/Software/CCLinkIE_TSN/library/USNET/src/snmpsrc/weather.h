//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
#define Xlocation 0
#define Xlatitude 1
#define Xlongitude 2
#define Xaltitude 3

struct weatherTable
{
    int altitude;
};
extern char *location;
extern int latitude;
extern int longitude;
extern struct weatherTable weatherTable[];

extern const MIB weather;
