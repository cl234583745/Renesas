/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588
#include "PTP_GlobalData.h"

#include "MDDelayCommonSM.h"
#include "MDDelayRespReceiveSM.h"
#include "MDDelayRespReceiveSM_1588.h"

#include "ptp_PDRSReceive_1588.h"

#define D_FUNC	0

VOID (*const MDDelayRespReceiveSM_1588_Matrix[DMDDRPR_STATUS_MAX][DMDDRPR_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDDelayRespReceiveSM_01_1588, &MDDelayRespReceiveSM_NP_1588, &MDDelayRespReceiveSM_NP_1588},
	{&MDDelayRespReceiveSM_01_1588, &MDDelayRespReceiveSM_02_1588, &MDDelayRespReceiveSM_00_1588},
	{&MDDelayRespReceiveSM_01_1588, &MDDelayRespReceiveSM_02_1588, &MDDelayRespReceiveSM_00_1588}
};

VOID MDDelayRespReceiveSM_1588(USHORT usEvent, PORTDATA* pstPort)
{
	MDDRESPRCVSM_EV	enEvt = MDDRPR_E_EVENT_MAX;
	MDDRESPRCVSM_ST	enSts = MDDRPR_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82080001);

	enEvt = GetMDDRespRcvEvent(usEvent, pstPort);
	enSts = GetMDDRespRcvStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDDelayRespReceiveSM_1588====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDDRPR_STATUS_MAX) && (enEvt != MDDRPR_E_EVENT_MAX))
	{
		(*MDDelayRespReceiveSM_1588_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDDRespRcvStatus(pstPort);
	printf ("<END  > [%02d]MDDelayRespReceiveSM_1588====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDDelayRespReceiveSM_00_1588(PORTDATA* pstPort)
{
	MDDRESPRVSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDDelayRespReceiveSM_00_1588+",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDDRespRcvSMGlobal(pstPort);

	MDDRespRcv_NotEnable_1588(pstGbl, pstPort);
	SetMDDRespRcvStatus(MDDRPR_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDDelayRespReceiveSM_00_1588::-\n") );

	return;
}

VOID MDDelayRespReceiveSM_01_1588(PORTDATA* pstPort)
{
	MDDRESPRVSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDRespRcvSMGlobal(pstPort);

	MDDRespRcv_NotEnable_1588(pstGbl, pstPort);
	SetMDDRespRcvStatus(MDDRPR_NOT_ENABLED, pstPort);
	return;
}

VOID MDDelayRespReceiveSM_02_1588(PORTDATA* pstPort)
{
	MDDRESPRVSM_GD*	pstGbl = NULL;
	INT nIndex;

	ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::+\n"));

	pstGbl = GetMDDRespRcvSMGlobal(pstPort);

	if (ConMDDelayRespReceive_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82001408);
		MDDRespRcv_NotEnable_1588(pstGbl, pstPort);
		SetMDDRespRcvStatus(MDDRPR_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
		return;
	}


#ifdef	PTP_USE_TRANS

	if (IsMDCOMClockSupportTypTC_P2P(pstPort))
	{
		PTP_NOTICE_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82000012);
		MDDRespRcv_NotEnable_1588(pstGbl, pstPort);
		SetMDDRespRcvStatus(MDDRPR_NOT_ENABLED, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
		return;
	}

	else if (IsMDCOMClockSupportTypTC_E2E(pstPort))
	{
		USHORT	index = 0;
		if (JugMDDelayRespCorrectionPort(pstPort, &index) == FALSE)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82000013);
		}
		else
		{
			SetMDDelayReqMgIngresTS_1588(pstGbl, pstPort);
			{
				BOOL	blRet;

				blRet = GetMDDelayCorrectionPort(pstPort, index);
				if (blRet != TRUE)
				{
					SetMDDRespRcvStatus(MDDRPR_WAITING_FOR_DELAY_RESP, pstPort);
					return;
					ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
				}
			}
		}
		MDDRespRcv_WtFrDResp_1588(pstGbl, pstPort);
		SetMDDRespRcvStatus(MDDRPR_WAITING_FOR_DELAY_RESP, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
		return;
	}
	else
	{
	}

#endif

	if (JugMDDelayResp_1588(pstGbl, pstPort) == FALSE)
	{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82001400);
		MDDRespRcv_NotEnable_1588(pstGbl, pstPort);

		ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
		return;
	}

	if ( (pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_DREQ) != 0U )
	{
		nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
		
		if ( gstDreqTmoManage[nIndex].pstDreqSendPort == pstPort )
		{
			tsn_Wrapper_MemSet( (VOID *)&gstDreqTmoManage[nIndex], 0, sizeof(DREQTMOMAN) );
		}
	}

	SetMDDelayReqMgIngresTS_1588(pstGbl, pstPort);

	computeMDMeanPathDelay_1588(pstGbl, pstPort);
	MDDRespRcv_WtFrDResp_1588(pstGbl, pstPort);
	SetMDDRespRcvStatus(MDDRPR_WAITING_FOR_DELAY_RESP, pstPort);

	ptp_dbg_msg(D_FUNC, ("MDDelayRespReceiveSM_02_1588::-\n"));
	return;
}


VOID MDDelayRespReceiveSM_NP_1588(PORTDATA* pstPort)
{
		PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82000007);
	return;
}

BOOL MDDRespRcv_NotEnable_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdDelayResp = FALSE;
	return TRUE;
}

BOOL MDDRespRcv_WtFrDResp_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blRcvdDelayResp = FALSE;

	if (SetMDDelayRespReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxMDDelayRespReceive_1588(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	return TRUE;
}

BOOL JugMDDelayResp_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_DELAY_RESP_1588*	pstMsgDelayResp = &pstSmGbl->pstRcvdDelayResp->stDlyResp_1588;

	PORT_DS*				pstPortDS = &pstPort->stPortDS;
	PORTMD_GD*				pstPortMD = &pstPort->stPortMD_GD;

	if (pstPortMD->blTxDlySequencdIdChg != TRUE)
	{
		return FALSE;
	}

	if (pstMsgDelayResp->stHeader.usSequenceId != pstPortMD->usTxDlySequenceId)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgDelayResp->stReqPortIdentity.stClockIdentity,
		&pstPortDS->stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgDelayResp->stReqPortIdentity.usPortNumber
		!= pstPortDS->stPortIdentity.usPortNumber)
	{
		return FALSE;
	}
	if ( 0 != tsn_Wrapper_MemCmp(&pstMsgDelayResp->stHeader.stSrcPortIdentity.stClockIdentity,
		&pstPort->pstClockData->stParentDS.stParentPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY)))
	{
		return FALSE;
	}
	if (pstMsgDelayResp->stHeader.stSrcPortIdentity.usPortNumber
		!= pstPort->pstClockData->stParentDS.stParentPortIdentity.usPortNumber)
	{
		return FALSE;
	}

	pstPortMD->blTxDlySequencdIdChg = FALSE;

	return TRUE;
}

BOOL ConMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*		pstPortMD = &pstPort->stPortMD_GD;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	if (pstSmGbl->blRcvdDelayResp == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_82001409);
		return FALSE;
	}
	if (pstSmGbl->pstRcvdDelayResp == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPRECEIVESM_1588, PTP_LOGVE_8200140A);
		return FALSE;
	}
	tsn_Wrapper_MemCpy(&pstPortMD->stConDlyResp_1588,
		&pstSmGbl->pstRcvdDelayResp->stDlyResp_1588, sizeof(pstPortMD->stConDlyResp_1588));

#ifdef	PTP_USE_TRANS

	tsn_Wrapper_MemCpy(&pstClockGD->stDlyCorctionClock.stConDlyResp_1588,
						&pstSmGbl->pstRcvdDelayResp->stDlyResp_1588,
						sizeof(pstClockGD->stDlyCorctionClock.stConDlyResp_1588));

#endif

	return TRUE;
}

VOID SetMDDelayReqMgIngresTS_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PTPMSG_DELAY_RESP_1588*	pstMsgDlyResp
		= &pstSmGbl->pstRcvdDelayResp->stDlyResp_1588;
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stDelayReqIngressTimestamp,
		&pstMsgDlyResp->stRcvTimestamp, sizeof(TIMESTAMP));
	tsn_Wrapper_MemCpy(&pstPortGD->stDelayRespCorrectionField,
		&pstMsgDlyResp->stHeader.stCorrectionField, sizeof(FRAC_NSEC64));
	return;
}

BOOL SetMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDDELAYRESP*			pstDlyRespRcv = &pstPort->stPort_GD.stMdDelayRespRcv;
	PTPMSG_DELAY_RESP_1588*	pstRcvMsg = &pstSmGbl->pstRcvdDelayResp->stDlyResp_1588;
	PORTMD_GD*				pstPortMD	= &pstPort->stPortMD_GD;
	TIME_INTERVAL			stA_TInt = pstPortMD->stDlyCorrctionField;

	tsn_Wrapper_MemSet(pstDlyRespRcv, 0, sizeof(MDDELAYRESP));

	pstDlyRespRcv->uchClockNumber		= pstRcvMsg->stHeader.uchDomainNumber;
	ptpAddTInt_TInt((TIME_INTERVAL*)&pstRcvMsg->stHeader.stCorrectionField, &stA_TInt,
				&pstDlyRespRcv->stCorrectionField	);

	pstDlyRespRcv->stSourcePortIdentity	= pstRcvMsg->stHeader.stSrcPortIdentity;
	pstDlyRespRcv->usSequenceId			= pstRcvMsg->stHeader.usSequenceId;
	pstDlyRespRcv->chLogMessageInterval	= pstRcvMsg->stHeader.chLogMsgInterVal;
	pstDlyRespRcv->stReceiveTimestamp	= pstRcvMsg->stRcvTimestamp;
	pstDlyRespRcv->stRequestPortIdentity = pstRcvMsg->stReqPortIdentity;

	return TRUE;
}

BOOL TxMDDelayRespReceive_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PDRSRECEIVESM_1588_GD* pstMediaInd_GD = &pstPort->stUn_PSM_GD.stPsm1588_GD.stPDRSReceiveSM_1588_GD;
	pstMediaInd_GD->blRcvdMDDelayResp = TRUE;
	portDelayRespReceive_1588(PTP_EV_FOR_PDLRSRV_RCVMDDLRS, pstPort);
	return TRUE;
}

VOID computeMDMeanPathDelay_1588(MDDRESPRVSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	return;
}

#endif
