/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ManagementSM.h"
#include "ManagementSM_1AS.h"

INT ManagementAPI_AS( UCHAR  uchAction, 
					  USHORT usParamId_AS, 
					  UCHAR  uchDomainNumber, 
					  USHORT usPortNumber, 
					  UCHAR* puchInfo, 
					  USHORT usInfoSize )
{
	CLOCKDATA*	pstClock_DT	= NULL;
	PORTDATA*	pstPort_DT		= NULL;
	USHORT		usTblIndex	= 0;
	USHORT		usSize		= 0;
	BOOL		blRet		= FALSE;
	INT			nRet		= RET_ENOERR;


	pstClock_DT = GetMGTClockData( uchDomainNumber );
	if (pstClock_DT == NULL)
	{
		return RET_ESTATE;
	}
	if (pstClock_DT->stClock_GD.enSupportPTPType != ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		return RET_ESTATE;
	}


	if (uchAction > MGTAS_ACTION_MAX)
	{
		return RET_EINVAL;
	}
	if (usParamId_AS > MID_MID_MAX)
	{
		return RET_EINVAL;
	}
	if (puchInfo == NULL)
	{
		return RET_EINVAL;
	}
	pstPort_DT  = GetMGTPortData(pstClock_DT, usPortNumber);
	blRet = GetManagementASParamId(usParamId_AS, &usTblIndex, &usSize);
	if ((blRet == FALSE) || (usInfoSize != usSize))
	{
		return RET_EINVAL;
	}

	nRet =
	ManagementSM_1AS_API(uchAction, usTblIndex, pstClock_DT, pstPort_DT, puchInfo);
	return nRet;
}
