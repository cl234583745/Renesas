/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PSSSEND_GD_H__
#define __PTP_PSSSEND_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PSSS {
	ST_PSSS_NONE	= 0,
	ST_PSSS_TRANSMIT_INIT,
	ST_PSSS_SEND_MD_SYNC,
	ST_PSSS_SYNC_RECEIPT_TIMEOUT,
	ST_PSSS_MAX
} EN_ST_PSSS;

typedef	enum	tagEN_EV_PSSS {
	EV_PSSS_BEGIN = 0,
	EV_PSSS_FOR_PORTSYNSYNSD_RVPSYN,
	EV_PSSS_FOR_INTERVAL1TIMEOUT,
	EV_PSSS_SYNCRECEIPTTIMEOUT,
	EV_PSSS_CLOSE,
	EV_PSSS_EVENT_MAX
} EN_EV_PSSS;

typedef 	struct tagPSSSENDSM_GD
{
	EN_ST_PSSS			enStatusPSSS;
	BOOL				blRcvdPSSync;
	PORTSYNCSYNC		stRcvdPSSync;
	PORTSYNCSYNC*		pstRcvdPSSyncPtr;
	PORTSYNCSYNC		stLastRcvdPSSync;
	USCALEDNS			stLastSyncSentTime;
	MDSYNCSEND*			pstTxMDSyncSendPtr;
	USCALEDNS			stSyncReceiptTimeoutTime;
	UCHAR				uchNumberSyncTransmissions;
	USCALEDNS			stInterval1;
	USCALEDNS			stInterval1TimeoutTime;
	TMO_MANAGE_INF_BLK*	pstTMO_SyncReceiptTimeoutTime;
	TMO_MANAGE_INF_BLK*	pstTMO_Interval1;
} PSSSENDSM_GD;	




#endif


