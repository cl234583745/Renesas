/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_BCSSEND_1588_GD_H__
#define __PTP_BCSSEND_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_BCSS_1588 {
	ST_BCSS_1588_NONE	= 0,
	ST_BCSS_1588_INITIALIZING,
	ST_BCSS_1588_SEND_SYNC_INDICAT,
	ST_BCSS_1588_MAX
} EN_ST_BCSS_1588;

typedef	enum	tagEN_EV_BCSS_1588 {
	EV_BCSS_1588_BEGIN = 0,
	EV_BCSS_1588_SYNC_SENDTIME,
	EV_BCSS_1588_CLOSE,
	EV_BCSS_1588_EVENT_MAX
} EN_EV_BCSS_1588;

typedef	struct tagBCSSENDSM_1588_GD
{
	EN_ST_BCSS_1588		enStatusBCSS_1588;
	PORTSYNCSYNC*		pstTxPSSyncPtr;
	BOOL				blRcvdPSSync;
	PORTSYNCSYNC		stRcvdPSSync;
	USCALEDNS			stSyncSendTime_1588;
	TMO_MANAGE_INF_BLK*	pstTMO_SyncSendTime_1588;
	BOOL				blSyncSendTime;
} BCSSENDSM_1588_GD;	



#endif


