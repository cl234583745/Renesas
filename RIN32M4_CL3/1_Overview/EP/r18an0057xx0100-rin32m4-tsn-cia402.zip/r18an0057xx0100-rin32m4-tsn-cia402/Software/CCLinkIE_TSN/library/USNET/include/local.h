//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_LOCAL_H_
#define _USS_LOCAL_H_

#include "config.h"
#define PORT_NAME						"eth0"
#define NNETS 1
#define NCONNS 13
#define NCONFIGS 20
#define NBUFFS 16
#define MAXBUF 2080
#define USSBUFALIGN 4
#define FRAGMENTATION 3
#define IPOPTIONS
#define USS_IP_MC_LEVEL 2
#define KEEPALIVETIME 50000

#define RELAYING 2
#undef chksum_INASM
#define DHCP 1
#undef DNS
#undef TCP_SACK
#ifdef TCP_SACK
#define TCP_OPTIONS
#endif

#define NETNO_ASYS_PORT_ONE				0
#define NETNO_ASYS_PORT_TWO				1


#undef RARP
#undef PPP
#undef PPPOE
#define LOCALHOSTNAME(val) strcpy(val, "ussw")

#define USERID "test"
#define PASSWD "usnet"

int Nclkinit(void);
void Nclkterm(void);
extern unsigned int clocks_per_sec;


#define LOCALSETUP() 0, clocks_per_sec = 200, Nclkinit()
#define LOCALSHUTOFF() Nclkterm()

#define CC_RECV_THRESHOLD_TIME    3000

#endif

