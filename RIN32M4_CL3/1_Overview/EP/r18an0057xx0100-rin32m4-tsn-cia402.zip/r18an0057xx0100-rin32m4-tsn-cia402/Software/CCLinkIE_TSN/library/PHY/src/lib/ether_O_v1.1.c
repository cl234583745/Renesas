/**
 *******************************************************************************
 * @file  ether_E.c
 * @brief Gigabit Ethernet PHY Enhanced Mode Settings
 * 
 * @note 
 * Copyright (C) 2018 Renesas Electronics Corporation 
 * 
 * @par
 *  THIS FILE MUST NOT BE DISCLOSED OUTSIDE OF RENESAS
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
//#include "ether/ether_phy_init.h"
#include "ether_phy_init.h"
#include "kernel.h"
#include "R_IN32M4_CL3.h"
/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*===========================================================================*/
/* S T R U C T                                                               */
/*===========================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  Read phy register
  @param  phyadr -- Phy address
  @param  regadr -- Register address
  @retval Register value
 ******************************************************************************
*/

static uint32_t phy_read_reg(uint8_t phyadr, uint8_t regadr)
{
	uint32_t reg_tmp;
    
    // Read access phy register
    RIN_ETH->GMAC_MIIM = ((uint32_t)phyadr << 21) | ((uint32_t)regadr << 16);
    
    // Wait 
	while (1) {
		reg_tmp = RIN_ETH->GMAC_MIIM;
		if ((reg_tmp & 0x04000000) == 0x04000000) {
			return reg_tmp & 0xffff;
		}
	}
}

/**
 ******************************************************************************
  @brief  Write phy register
  @param  phyadr -- Phy address
  @param  regadr -- Register address
  @retval Register value
 ******************************************************************************
*/

static uint32_t phy_write_reg(uint8_t phyadr, uint8_t regadr, uint16_t val)
{
	uint32_t reg_tmp;
    
    // Read access phy register
    RIN_ETH->GMAC_MIIM = 0x04000000 | ((uint32_t)phyadr << 21) | ((uint32_t)regadr << 16) | val;
    
    // Wait 
	while (1) {
		reg_tmp = RIN_ETH->GMAC_MIIM;
		if ((reg_tmp & 0x04000000) == 0x04000000) {
			return reg_tmp & 0xffff;
		}
	}
}

/**
 ******************************************************************************
  @brief  Set Enhanced Mode for PHY
  @param  none
  @retval none
 ******************************************************************************
*/
void ether_script( void )
{
	// Enhanced Mode Settings
	phy_write_reg( 0, 31, 0x0);
	phy_write_reg( 0, 22, 0x3201);
	phy_write_reg( 0, 31, 0x2a30);
	phy_write_reg( 0, 5, 0x1b20);
	phy_write_reg( 0, 22, 0x3c0);
	phy_write_reg( 0, 24, 0xc38);
	phy_write_reg( 0, 31, 0x2);
	phy_write_reg( 0, 16, 0xacae);
	phy_write_reg( 0, 31, 0x2a30);
	phy_write_reg( 0, 8, 0x8012);
	phy_write_reg( 0, 31, 0x2a30);
	phy_write_reg( 0, 9, 0x18c0);
	phy_write_reg( 0, 31, 0x52b5);
	phy_write_reg( 0, 18, 0x90);
	phy_write_reg( 0, 17, 0x1c09);
	phy_write_reg( 0, 16, 0x8fec);
	phy_write_reg( 0, 18, 0xb0);
	phy_write_reg( 0, 17, 0x1807);
	phy_write_reg( 0, 16, 0x8ffe);
	phy_write_reg( 0, 18, 0x6);
	phy_write_reg( 0, 17, 0x298);
	phy_write_reg( 0, 16, 0x8fe0);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0xba);
	phy_write_reg( 0, 16, 0x8fe2);
	phy_write_reg( 0, 18, 0x10);
	phy_write_reg( 0, 17, 0xe494);
	phy_write_reg( 0, 16, 0x8486);
	phy_write_reg( 0, 18, 0x59);
	phy_write_reg( 0, 17, 0x6510);
	phy_write_reg( 0, 16, 0x8488);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x504);
	phy_write_reg( 0, 16, 0x848a);
	phy_write_reg( 0, 18, 0xd7);
	phy_write_reg( 0, 17, 0x7d73);
	phy_write_reg( 0, 16, 0x848c);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0xc30);
	phy_write_reg( 0, 16, 0x848e);
	phy_write_reg( 0, 18, 0x34);
	phy_write_reg( 0, 17, 0xd30c);
	phy_write_reg( 0, 16, 0x8490);
	phy_write_reg( 0, 18, 0x30);
	phy_write_reg( 0, 17, 0xc30c);
	phy_write_reg( 0, 16, 0x8492);
	phy_write_reg( 0, 18, 0x30);
	phy_write_reg( 0, 17, 0x79a7);
	phy_write_reg( 0, 16, 0x8494);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0xb73);
	phy_write_reg( 0, 16, 0x8496);
	phy_write_reg( 0, 18, 0xd7);
	phy_write_reg( 0, 17, 0x7d73);
	phy_write_reg( 0, 16, 0x8498);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0xc2d);
	phy_write_reg( 0, 16, 0x849a);
	phy_write_reg( 0, 18, 0x41);
	phy_write_reg( 0, 17, 0x410);
	phy_write_reg( 0, 16, 0x849c);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x3cf);
	phy_write_reg( 0, 16, 0x849e);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0xc);
	phy_write_reg( 0, 16, 0x84a0);
	phy_write_reg( 0, 18, 0x30);
	phy_write_reg( 0, 17, 0xc1c0);
	phy_write_reg( 0, 16, 0x84a2);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x0);
	phy_write_reg( 0, 16, 0x84a4);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x0);
	phy_write_reg( 0, 16, 0x84a6);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x0);
	phy_write_reg( 0, 16, 0x84a8);
	phy_write_reg( 0, 18, 0x0);
	phy_write_reg( 0, 17, 0x0);
	phy_write_reg( 0, 16, 0x84aa);
	phy_write_reg( 0, 18, 0x14);
	phy_write_reg( 0, 17, 0xe517);
	phy_write_reg( 0, 16, 0x84ac);
	phy_write_reg( 0, 18, 0x65);
	phy_write_reg( 0, 17, 0x9657);
	phy_write_reg( 0, 16, 0x84ae);
	phy_write_reg( 0, 18, 0x59);
	phy_write_reg( 0, 17, 0x44d0);
	phy_write_reg( 0, 16, 0x84b0);
	phy_write_reg( 0, 18, 0x3c);
	phy_write_reg( 0, 17, 0xf34d);
	phy_write_reg( 0, 16, 0x84b2);
	phy_write_reg( 0, 18, 0x34);
	phy_write_reg( 0, 17, 0xd34d);
	phy_write_reg( 0, 16, 0x84b4);
	phy_write_reg( 0, 31, 0x2a30);
	phy_write_reg( 0, 8, 0x12);
//	phy_write_reg( 0, 31, 0x0);
//	phy_write_reg( 0, 22, 0x3200);

//	phy_write_reg( 0, 31, 0x0);
//	phy_write_reg( 0, 22, 0x3201);

	phy_write_reg( 0, 31, 0x2a30);
	phy_write_reg( 0, 24, 0x0000);

	phy_write_reg( 0, 31, 0x52b5);
	phy_write_reg( 0, 18, 0x04);
	phy_write_reg( 0, 17, 0xaf54);
	phy_write_reg( 0, 16, 0x8fe4);

	phy_write_reg( 0, 31, 0x0);
	phy_write_reg( 0, 22, 0x3200);
}
