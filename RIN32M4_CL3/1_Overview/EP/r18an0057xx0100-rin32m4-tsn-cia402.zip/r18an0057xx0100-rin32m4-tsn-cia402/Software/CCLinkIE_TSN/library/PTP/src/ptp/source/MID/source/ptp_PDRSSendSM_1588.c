/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"

#ifdef	PTP_USE_IEEE1588

#include "MDDelayRespSendSM.h"
#include "MDDelayRespSendSM_1588.h"
#include "ptp_CDSend_1588.h"
#include "ptp_PDRSSend_1588.h"

#define D_FUNC	0


VOID	PDRSSend_1588_00(PORTDATA*	pstPortData);
VOID	PDRSSend_1588_01(PORTDATA*	pstPortData);
VOID	PDRSSend_1588_02(PORTDATA*	pstPortData);
MDDELAYRESP*	setMDDelayResp(MDDELAYRESP*	pstRcvdMDDRSSendPtr);
VOID  txMDDelayResp(MDDELAYRESP*	pstTxMDDRSSendPtr, PORTDATA*	pstPortData);





VOID (*const pfnPDRSSendMatrix[ST_PDRSS_MAX][EV_PDRSS_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PDRSSend_1588_01, &PDRSSend_1588_01, &PDRSSend_1588_00},
	{&PDRSSend_1588_01, &PDRSSend_1588_02, &PDRSSend_1588_00},
	{&PDRSSend_1588_01, &PDRSSend_1588_02, &PDRSSend_1588_00}
};



VOID	 portDelayRespSend_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRSS	enEvt = EV_PDRSS_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("PDRSSendSM_1588   Evt=%d Sts=%d\n", usEvent, pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD.enStatusPDRSS);
}
#endif
		enEvt = GetPDRSSendSM_1588_Event(usEvent, pstPortData);

		blSts = IsPDRSSendSM_1588_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PDRSS_EVENT_MAX))
		{
			(*pfnPDRSSendMatrix[pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD.enStatusPDRSS][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PDRSSENDSM_1588, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD.blRcvdMDDelayResp	= FALSE;
		}

	}
}




PDRSSENDSM_1588_GD*	GetPDRSSendSM_1588_GD(
	PORTDATA*		pstPortData)
{
	PDRSSENDSM_1588_GD*	pstPDRSSGlb = &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPDRSSendSM_1588_GD);
	return pstPDRSSGlb;
}




EN_EV_PDRSS	GetPDRSSendSM_1588_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PDRSS			enEvt				= EV_PDRSS_EVENT_MAX;
	PDRSSENDSM_1588_GD*	pstPDRSSGlb		= GetPDRSSendSM_1588_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PDRSS_BEGIN;
			break;

		case PTP_EV_FOR_PDLRSSND_RCVMDDLRS:
			if ((pstPDRSSGlb->blRcvdMDDelayResp) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PDRSS_BEGIN;
			}
			else if (pstPDRSSGlb->enStatusPDRSS == ST_PDRSS_TRANSMIT_INIT)
			{
				if ((pstPDRSSGlb->blRcvdMDDelayResp) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PDRSS_FOR_PDLRSSND_RCVMDDLRS;
				}
			}
			else if (pstPDRSSGlb->enStatusPDRSS == ST_PDRSS_SEND_MD_DELAYRESP)
			{
				if ((pstPDRSSGlb->blRcvdMDDelayResp) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PDRSS_FOR_PDLRSSND_RCVMDDLRS;
				}
			}
			else
			{
			}
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PDRSS_CLOSE;
			break;

		default:
			enEvt = EV_PDRSS_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsPDRSSendSM_1588_Status(
	PORTDATA*	pstPortData)
{
	PDRSSENDSM_1588_GD*	pstPDRSSGlb = GetPDRSSendSM_1588_GD(pstPortData);
	BOOL				blRet			= FALSE;


	if (pstPDRSSGlb->enStatusPDRSS < ST_PDRSS_MAX)
        {
		blRet = TRUE;
	}
	return blRet;
}






VOID	PDRSSend_1588_00(
	PORTDATA*		pstPortData)
{
	PDRSSENDSM_1588_GD*	pstPDRSSGlb = GetPDRSSendSM_1588_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PDRSSend_1588_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPDRSSGlb->blRcvdMDDelayResp	= FALSE;
	pstPDRSSGlb->enStatusPDRSS		= ST_PDRSS_NONE;

	ptp_dbg_msg( D_FUNC, ("PDRSSend_1588_00::-\n") );
}




VOID	PDRSSend_1588_01(
	PORTDATA*		pstPortData)
{
	PDRSSENDSM_1588_GD*	pstPDRSSGlb = GetPDRSSendSM_1588_GD(pstPortData);


	pstPDRSSGlb->blRcvdMDDelayResp	= FALSE;
	pstPDRSSGlb->enStatusPDRSS		= ST_PDRSS_TRANSMIT_INIT;
}




VOID	PDRSSend_1588_02(
	PORTDATA*		pstPortData)
{
	PDRSSENDSM_1588_GD*	pstPDRSSGlb				= GetPDRSSendSM_1588_GD(pstPortData);
	MDDELAYRESP*		pstRcvdMDDRespRcvPtr	= NULL;
	MDDELAYRESP*		pstTxMDDRSSendPtr		= NULL;


	pstRcvdMDDRespRcvPtr = &(pstPortData->stPort_GD.stMdDelayRespSnd);

	pstPDRSSGlb->blRcvdMDDelayResp = FALSE;
	pstPDRSSGlb->pstTxMDDRespSndPtr = pstRcvdMDDRespRcvPtr;

	pstTxMDDRSSendPtr = setMDDelayResp(pstRcvdMDDRespRcvPtr);

	txMDDelayResp(pstTxMDDRSSendPtr, pstPortData);

	pstPDRSSGlb->enStatusPDRSS	= ST_PDRSS_SEND_MD_DELAYRESP;

}




MDDELAYRESP*	setMDDelayResp(MDDELAYRESP*	pstRcvdMDDRSSendPtr)
{
	MDDELAYRESP*	pstTxMDDRSSendPtr = NULL;



	pstTxMDDRSSendPtr = pstRcvdMDDRSSendPtr;

	return pstTxMDDRSSendPtr;
}




VOID  txMDDelayResp(
	MDDELAYRESP*	pstTxMDDRSSendPtr,
	PORTDATA*		pstPortData)
{
	USHORT			usEvent				= PTP_EV_BASE;
	MDDRESPSDSM_GD*	pstMDDRESPSDSM_GD	= &(pstPortData->stMDDRespSndSM_GD);


	pstMDDRESPSDSM_GD->blRcvdMDDelayResp	= TRUE;

	usEvent = PTP_EV_FOR_MDDLRSSND_RCVDDLRS;
	MDDelayRespSendSM(usEvent, pstPortData);

}



#endif

