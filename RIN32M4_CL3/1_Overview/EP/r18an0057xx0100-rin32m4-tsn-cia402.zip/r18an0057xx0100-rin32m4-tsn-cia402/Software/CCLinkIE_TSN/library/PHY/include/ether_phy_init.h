/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef	ETHER_PHY_INIT_H__
#define	ETHER_PHY_INIT_H__

#include <stdint.h>




void ether_phy_init( void );
void ether_script( void );

#endif
