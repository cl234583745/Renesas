/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "PTP_GlobalData.h"
#include "ptp_LCEntity.h"

#include "MDCommonSM.h"

#include "MDSyncReceiveSM.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDSyncReceiveSM_1AS.h"
#endif
#ifdef	PTP_USE_IEEE1588
#include "MDSyncReceiveSM_1588.h"
#endif

VOID MDSyncReceiveSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82080001);
#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		MDSyncReceiveSM_1AS(usEvent, pstPort);
		return;
	}
#endif
#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDSyncReceiveSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000002);
	return;
}

MDSRECEIVESM_GD* GetMDSyncRcvSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDSReceiveSM_GD;
}

MDSYNCRCVSM_EV GetMDSyncRcvEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCRCVSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDSYCR_E_BEGIN;
		break;
		case PTP_EV_FOR_MDSYN_RCVSM_RCVDSYNC:
			enEvt = MDSYCR_E_FOR_MDSYN_RCV_RCVDSYNC;
		break;
		case PTP_EV_RCVDFOLLOWUP:
			enEvt = MDSYCR_E_RCVDFOLLOWUP;
		break;
		case PTP_EV_FOLLOWUPRECEIPTTIMEOUT:
			enEvt = MDSYCR_E_FOLLOWUPRECEIPTTIMEOUT;
			MDSyncTimeClear(pstPort);
		break;
		case PTP_EV_CLOSE:
			enEvt = MDSYCR_E_CLOSE;
		break;

		default:
			enEvt = MDSYCR_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDSYNCRCVSM_ST GetMDSyncRcvStatus(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	MDSYNCRCVSM_ST		enSts = MDSYCR_STATUS_MAX;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	if (pstGbl->enStsMDSyncReceive < MDSYCR_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDSyncReceive;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDSyncRcvStatus(MDSYNCRCVSM_ST enSts, PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	pstGbl->enStsMDSyncReceive = enSts;
	return;
}

VOID IncMDSyncRcvRxSyncCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulRxSyncCount++;
	return;
}

VOID IncMDSyncRcvRxFollowUpCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulRxFollowUpCount++;
	return;
}

VOID IncMDSyncRcvRxOneStpSyncCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulRxOneStepSyncCount++;
	return;
}

BOOL MDSynRcvTimeStart(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	if (pstSmGbl->pstTimeOutManage != NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000022);
		return FALSE;
	}

	pstSmGbl->pstTimeOutManage = ptp_TimeOut_Req(
							PTP_EV_FOLLOWUPRECEIPTTIMEOUT,
							(VOID*)pstPort,
							pstSmGbl->stFollowUpReceiptTimoutTime,
							(CallBackFunc)&MDSyncReceiveSM);
	if (pstSmGbl->pstTimeOutManage == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000021);
		return FALSE;
	}
	return TRUE;
}

BOOL MDSynRcvTimeStop(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	USHORT	usTimeRet = RET_ENOERR;

	if (pstSmGbl->enStsMDSyncReceive == MDSYCR_WAITING_FOR_FOLLOW_UP)
	{

		if (pstSmGbl->pstTimeOutManage == NULL)
		{
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000024);
			return TRUE;
		}
		usTimeRet = ptp_TimeOut_Can(pstSmGbl->pstTimeOutManage);
		if (usTimeRet != RET_ENOERR)
		{
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000023);
			return FALSE;
		}
		pstSmGbl->pstTimeOutManage = NULL;

	}
	return TRUE;
}

VOID MDSyncTimeClear(PORTDATA* pstPort)
{
	MDSRECEIVESM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncRcvSMGlobal(pstPort);

	if (pstGbl->pstTimeOutManage == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSRECEIVESM, PTP_LOGVE_82000024);
	}
	pstGbl->pstTimeOutManage = NULL;
	return;
}

BOOL SetMDSyncEvIngresTimestampSM(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;

	if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstSmGbl->stSyncIngTimestamp,
			&pstSmGbl->stIngMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstSmGbl->stSyncIngTimestamp, 0L, sizeof(TIMESTAMP));
	}
#ifdef	PTP_USE_ME_HW_ASSIST
		if (IS_TIMESTAMP_0(pstSmGbl->stIngMDTimestampReceive_Frun) == FALSE)
		{
			tsn_Wrapper_MemCpy(&pstSmGbl->stSyncIngTimestamp_Frun,
				&pstSmGbl->stIngMDTimestampReceive_Frun, sizeof(TIMESTAMP));
		}
		else
		{
			tsn_Wrapper_MemSet(&pstSmGbl->stSyncIngTimestamp_Frun, 0L, sizeof(TIMESTAMP));
			blRet = FALSE;
		}
#endif
	return blRet;
}

VOID SetMDSyncEvIngresTimestamp(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_GD* pstPortGD = &pstPort->stPort_GD;

	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventIngressTimestamp,
		&pstSmGbl->stSyncIngTimestamp, sizeof(TIMESTAMP));
#ifdef	PTP_USE_ME_HW_ASSIST
	tsn_Wrapper_MemCpy(&pstPortGD->stSyncEventIngressTimestamp_Frun,
		&pstSmGbl->stSyncIngTimestamp_Frun, sizeof(TIMESTAMP));
#endif
	return;
}

BOOL cmptMDSyncFollowUpReceiptTime(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort, CHAR chIntVal)
{
	USCALEDNS			stA_USNs= {0};
	USCALEDNS			stB_USNs= {0};
	CHAR				chA_Intval = 0;
	USCALEDNS			stCurrentTime = {0};

	ptp_GetCurrentTime(pstPort->pstClockData, &stCurrentTime);

	stA_USNs.ulNsec_lsb = CONST10_9;
	chA_Intval = (CHAR)chIntVal;
	ptpShiftUSNs_CHAR(&stA_USNs, chA_Intval, &stB_USNs);
	ptpAddUSNs_USNs( &stCurrentTime, &stB_USNs, &pstSmGbl->stFollowUpReceiptTimoutTime);

	return TRUE;
}


