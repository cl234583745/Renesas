/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_TICK_H__
#define __PTP_TICK_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"






#ifdef __cplusplus
extern "C" {
#endif

VOID	ptp_Tick(VOID);

#ifdef __cplusplus
}
#endif


#endif
