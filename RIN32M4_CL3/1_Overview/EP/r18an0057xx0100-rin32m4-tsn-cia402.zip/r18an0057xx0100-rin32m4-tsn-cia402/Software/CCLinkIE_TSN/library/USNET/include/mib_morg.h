//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef	__MIB_MORG_H_INCLUDED__
#define	__MIB_MORG_H_INCLUDED__


typedef enum {
    ST_SNC_MIBTYPE_NWCFG,
    ST_SNC_MIBTYPE_DEVDTL,
    ST_SNC_MIBTYPE_OTMDL,
    ST_SNC_MIBTYPE_STATS,
    ST_SNC_MIBTYPE_IPOVERLAP,
    ST_SNC_MIBTYPE_TOPOLOGY,
    ST_SNC_MIBTYPE_DATALINK,
    ST_SNC_MIBTYPE_COMTIMING,
    ST_SNC_MIBTYPE_CURERR,
#ifdef SWPS
    ST_SNC_MIBTYPE_LLDP,
    ST_SNC_MIBTYPE_LLDP_AGENT,
    ST_SNC_MIBTYPE_LLDP_LOCAL,
    ST_SNC_MIBTYPE_LLDP_REMOTE,
#endif
    ST_SNC_MIBTYPE_NONE,
    ST_SNC_MIBTYPE_MAX,
} ST_SNC_Mibtype;

typedef struct ST_SNC_ExecObj_TAG {
	void				*pvObj;
	unsigned char		uchNumber;
	unsigned char		uchPadding[3];
} ST_SNC_ExecObj;

typedef enum {
	ST_SNC_MEMCNT_1ST,
	ST_SNC_MEMCNT_2ND,
	ST_SNC_MEMCNT_MAX,
} ST_SNC_MemoryCount;

#ifdef SWPS
#else
typedef struct ST_SNC_MemoryCountObject_TAG {
	const unsigned char			ucUse;
	unsigned char				ucPadding[3];
	ST_SNC_MemoryCount			eRead;
	ST_SNC_MemoryCount			eWrite;
} ST_SNC_MemoryCountObject;

typedef struct ST_SNC_MemoryObject_TAG {
	ST_SNC_MemoryCountObject	stCnt;
	ST_SNC_ExecObj*				pstObj[ST_SNC_MEMCNT_MAX];
	void*						pvMib[ST_SNC_MEMCNT_MAX];
	unsigned long				ulSize;
} ST_SNC_MemoryObject;
#endif


#define ST_SNC_NETTYP_LEN                                (2)
#define ST_SNC_MAC_LEN                                   (6)
#define ST_SNC_IPV4V6_LEN                               (20)
#define ST_SNC_PORTCON_LEN                               (3)
#define ST_SNC_PORTSPD_LEN                               (6)
#define ST_SNC_TRSMITCYC_LEN                             (2)
#define ST_SNC_HOTLINE_LEN                               (3)
#define ST_SNC_CORRESPONDFUN_LEN                         (4)
#define ST_SNC_CYCLIC_STS_LEN                            (2)
#define ST_SNC_ALIAS_LEN                                (64)
#define ST_SNC_COMMENT_LEN                             (254)
#define ST_SNC_DEVMNAME_LEN                             (20)
#define ST_SNC_VENNAME_LEN                              (32)
#define ST_SNC_SERIALNUM_LEN                            (32)
#define ST_SNC_UNITIDENT_LEN                             (2)
#define ST_SNC_PORTCONALL_LEN                           (12)
#define ST_SNC_ERRFRMREPSTS_LEN                          (6)
#define ST_SNC_IPALL_LEN                                (45)
#define ST_SNC_TPLGCAUSE_LEN                             (2)
#define ST_SNC_DETECTIONACKIP_LEN                       (45)
#define ST_SNC_DLETYPE_LEN                               (2)
#define ST_SNC_ERRCONREG_LEN                            (64)
#define ST_SNC_ERRSTS_LEN                                (2)
#define ST_SNC_ERRTIME_LEN                              (10)

#ifdef SWPS
#define ST_SNC_NWCFG_CONSTN_SW_MAX                      (512)
#define ST_SNC_NWCFG_CONSTN_HW_MAX                      (256)
#define ST_SNC_NWCFG_CONSTN_MAX      (ST_SNC_NWCFG_CONSTN_SW_MAX)
#define ST_SNC_NWCFG_ADJACENT_MAX                        (24)
#define ST_SNC_DEVDTL_MASTER_MAX                         (64)
#define ST_SNC_DEVDTL_LED_MAX                           (255)
#define ST_SNC_DEVDTL_PORT_MAX                           (24)
#define ST_SNC_OTHER_OPT_SW_MAX                         (255)
#define ST_SNC_OTHER_OPT_HW_MAX                         (255)
#define ST_SNC_OTHER_OPT_MAX        (ST_SNC_OTHER_OPT_SW_MAX)
#define ST_SNC_IPOVLAP_ERR_MAX                          (512)
#define ST_SNC_TOPOLOGY_ERR_MAX                         (512)
#define ST_SNC_NOTIFYREG_MAX                            (512)
#define ST_SNC_DATALINK_ERR_MAX                         (512)
#define ST_SNC_COMTIMING_ERR_MAX                        (512)
#define ST_SNC_ERRREG_MAX                                (16)
#define ST_SNC_ERRDTLREG_MAX                             (10)
#else
#define ST_SNC_NWCFG_CONSTN_SW_MAX                      (  4)
#define ST_SNC_NWCFG_CONSTN_HW_MAX                      (  4)
#define ST_SNC_NWCFG_CONSTN_MAX      (ST_SNC_NWCFG_CONSTN_SW_MAX)
#define ST_SNC_NWCFG_ADJACENT_MAX                        ( 4)
#define ST_SNC_DEVDTL_MASTER_MAX                         ( 4)
#define ST_SNC_DEVDTL_LED_MAX                           (  8)
#define ST_SNC_DEVDTL_PORT_MAX                           ( 4)
#define ST_SNC_OTHER_OPT_SW_MAX                         (  4)
#define ST_SNC_OTHER_OPT_HW_MAX                         (  8)
#define ST_SNC_OTHER_OPT_MAX        (ST_SNC_OTHER_OPT_HW_MAX)
#define ST_SNC_IPOVLAP_ERR_MAX                          (  4)
#define ST_SNC_TOPOLOGY_ERR_MAX                         (  4)
#define ST_SNC_NOTIFYREG_MAX                            (  4)
#define ST_SNC_DATALINK_ERR_MAX                         (  4)
#define ST_SNC_COMTIMING_ERR_MAX                        (  4)
#define ST_SNC_ERRREG_MAX                                (16)
#define ST_SNC_ERRDTLREG_MAX                             (10)
#define ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN                (0)
#define ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX            (65535)
#endif

typedef struct ST_SNC_N2MibMasterStation_TAG {
    unsigned short                            usTotalStations;
    unsigned short                             usErrorStations;
    unsigned short                             usConfigurationPriodSeconds;
    unsigned long                              ulConfigurationPriodNanoLiw;
	unsigned char                              uchSyncType;
    unsigned short                             usPriodSeconds;
    unsigned long                              ulPriodNanoLiw;
    unsigned char                              auchGrandMasterIpAddress[ST_SNC_IPV4V6_LEN];
    unsigned short                             usUpdateSequenceNumber;
    unsigned short                             usStationNumber;
    unsigned char                              auchMacAddress[ST_SNC_MAC_LEN];
    unsigned short                             usNetworkType;
    unsigned char                              auchIpAddress[ST_SNC_IPV4V6_LEN];
    unsigned char                              uchCertificationClass;
    unsigned char                              uchNetworkNumber;
    unsigned char                              uchStationType;
    unsigned short                             usDeviceVersion;
    unsigned char                              uchOption;
    unsigned char                              uchFunction;
    unsigned char                              uchNumberOfPort;
    unsigned char                              uchDiagnosisInfo;
    unsigned long                              ulDeviceModelCode;
    unsigned short                             usExpansionModelCode;
    unsigned short                             usVendorCode;
    unsigned short                             usDeviceType;
    unsigned char                              auchPortCondition[ST_SNC_PORTCON_LEN];
    unsigned char                              auchPortComSpeed[ST_SNC_PORTSPD_LEN];
    unsigned char                              uchParameterErrorInfo;
    unsigned char                              auchHotLineInfo[ST_SNC_HOTLINE_LEN];
    unsigned char                              uchStatusFlag;
    unsigned char                              auchAlias[ST_SNC_ALIAS_LEN];
    unsigned char                              auchComment[ST_SNC_COMMENT_LEN];
    unsigned short                             usModeStatus;
} ST_SNC_N2MibMasterStation;

typedef struct ST_SNC_N3MibAdjacentStation_TAG {
    unsigned char                              uchDetectionReceivePortNumber;
    unsigned char                              uchBeforeDetectionTransmissionPortNumber;
    unsigned char                              auchBeforeNodeMacAddress[ST_SNC_MAC_LEN];
    unsigned char                              uchDetectionResponseReceivePortNumber;
} ST_SNC_N3MibAdjacentStation;

typedef struct ST_SNC_N2MibConnectedStation_TAG {
    unsigned char                              auchMacAddress[ST_SNC_MAC_LEN];
    unsigned char                              auchIpAddress[ST_SNC_IPV4V6_LEN];
    unsigned char                              uchCertificationClass;
    unsigned short                             usNetworkType;
    unsigned short                             usStationNumber;
    unsigned char                              uchStationType;
    unsigned short                             usDeviceVersion;
    unsigned long                              ulDeviceModelCode;
    unsigned short                             usExpansionModelCode;
    unsigned short                             usVendorCode;
    unsigned char                              uchOption;
    unsigned short                             usDeviceType;
    unsigned char                              uchFunction;
    unsigned char                              uchNumberOfPort;
    unsigned char                              auchPortCondition[ST_SNC_PORTCON_LEN];
    unsigned char                              auchPortComSpeed[ST_SNC_PORTSPD_LEN];
    unsigned short                             usStationSpecificMode;
    unsigned char                              auchTransmitCycle[ST_SNC_TRSMITCYC_LEN];
    unsigned char                              uchDiagnosisInfo;
    unsigned char                              uchParameterErrorInfo;
    unsigned char                              auchHotLineInfo[ST_SNC_HOTLINE_LEN];
    unsigned char                              auchCyclicStatus[ST_SNC_CYCLIC_STS_LEN];
    unsigned char                              uchStatusFlag;
    unsigned char                              uchNumberOfAdjacentStation;
    unsigned char                              auchAlias[ST_SNC_ALIAS_LEN];
    unsigned char                              auchComment[ST_SNC_COMMENT_LEN];
    ST_SNC_N3MibAdjacentStation        astAdjacent[ST_SNC_NWCFG_ADJACENT_MAX];
} ST_SNC_N2MibConnectedStation;


typedef struct ST_SNC_N1MibNetworkConfig_TAG {
    ST_SNC_N2MibMasterStation          stMaster;
    unsigned short                             usNumberOfConnectedStation;
    ST_SNC_N2MibConnectedStation       astConnected[ST_SNC_NWCFG_CONSTN_MAX];
} ST_SNC_N1MibNetworkConfig;


typedef struct ST_SNC_N3MibStatusMaster_TAG {
    unsigned char                    auchMacAddress[ST_SNC_MAC_LEN];
} ST_SNC_N3MibStatusMaster;

typedef struct ST_SNC_N3MibLed_TAG {
    unsigned char                    uchLedColor;
    unsigned char                    uchLedStatus;
} ST_SNC_N3MibLed;

typedef struct ST_SNC_N3MibStatusPortInfo {
    unsigned short                           usPortLinkDownCnt;
} ST_SNC_N3MibPort;

typedef struct ST_SNC_N2MibIdentifierInfo_TAG {
    unsigned char                            auchMacAddress[ST_SNC_MAC_LEN];
    unsigned short                           usStationNumber;
    unsigned char                            uchNetworkNumber;
    unsigned char                            uchOption;
    unsigned char                            auchIpAddress[ST_SNC_IPALL_LEN];
    unsigned char                            uchCertificationClass;
    unsigned char                            uchStationType;
    unsigned short                           usDeviceVersion;
    unsigned short                           usFwVersion;
    unsigned char                            uchHwVersion;
    unsigned short                           usDeviceType;
    unsigned long                            ulDeviceModelCode;
    unsigned short                           usExpansionModelCode;
    unsigned short                           usVendorCode;
    unsigned char                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    unsigned char                            auchVendorName[ST_SNC_VENNAME_LEN];
    unsigned char                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
    unsigned short                           usStationSpecificMode;
    unsigned char                            auchUnitIdentifier[ST_SNC_UNITIDENT_LEN];
} ST_SNC_N2MibIdentifierInfo;

typedef struct ST_SNC_N3MibStatusInfoBase_TAG {
    unsigned char                            auchPortCondition[ST_SNC_PORTCONALL_LEN];
	unsigned char                            auchErrorFrameReceptionStatus[ST_SNC_ERRFRMREPSTS_LEN];
    unsigned char                            uchDiagnosisInfo;
    unsigned char                            auchHotLineInfo[ST_SNC_HOTLINE_LEN];
	unsigned char                            uchCyclicStopInfo;
    unsigned char                            auchCorrespondingFunction[ST_SNC_CORRESPONDFUN_LEN];
    unsigned char                            uchAppInfo;
} ST_SNC_N3MibStatusInfoBase;

typedef struct ST_SNC_N2MibStatusInfo_TAG {
    ST_SNC_N3MibStatusInfoBase       stStatusInfoBase;
    unsigned char                            uchNumberOfPort;
    unsigned char                            uchNumberOfMasterTable;
    unsigned char                            uchNumberOfLedTable;
    ST_SNC_N3MibStatusMaster         astMasterTable[ST_SNC_DEVDTL_MASTER_MAX];
    ST_SNC_N3MibLed                  astLedTable[ST_SNC_DEVDTL_LED_MAX];
    ST_SNC_N3MibPort                 astPortTable[ST_SNC_DEVDTL_PORT_MAX];
} ST_SNC_N2MibStatusInfo;

typedef struct ST_SNC_N1MibDeviceDetail_TAG {
    ST_SNC_N2MibIdentifierInfo         stIdentifier;
    ST_SNC_N2MibStatusInfo             stStatus;
} ST_SNC_N1MibDeviceDetail;


typedef struct ST_SNC_N2MibController_TAG {
    unsigned char                            uchDeviceVersion;
    unsigned char                            uchFwVersion;
    unsigned char                            uchHwVersion;
    unsigned char                            uchPadding;
    unsigned long                            ulDeviceModelCode;
    unsigned short                           usExpansionModelCode;
    unsigned short                           usDeviceType;
    unsigned short                           usVendorCode;
    unsigned char                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    unsigned char                            auchVendorName[ST_SNC_VENNAME_LEN];
    unsigned char                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
} ST_SNC_N2MibController;

typedef struct ST_SNC_N2MibOptionInfo_TAG {
    unsigned long                            ulDeviceModelCode;
    unsigned short                           usExpansionModelCode;
    unsigned short                           usVendorCode;
    unsigned char                            uchDeviceVersion;
    unsigned char                            uchPadding;
    unsigned char                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    unsigned char                            auchVendorName[ST_SNC_VENNAME_LEN];
    unsigned char                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
} ST_SNC_N2MibOptionInfo;

typedef struct ST_SNC_N1MibOtherModule_TAG {
    ST_SNC_N2MibController           stController;
    unsigned short                           usNumberOfTable;
    unsigned short                           usPadding;
    ST_SNC_N2MibOptionInfo           astOptTable[ST_SNC_OTHER_OPT_MAX];
} ST_SNC_N1MibOtherModule;


typedef struct ST_SNC_N1MibStatisticalInfo_TAG {
    unsigned short                           usCyclicReceiveCounter;
    unsigned short                           usCyclicReceiveDiscardCounter;
    unsigned short                           usCyclicFrameReceiveCounter;
    unsigned short                           usNonCyclicReceiveCounter;
    unsigned short                           usNonCyclicReceiveDiscardCounter;
    unsigned short                           usNumberOfHecErrorFrame;
    unsigned short                           usNumberOfDcsErrorFrame;
    unsigned short                           usNumberOfFcsErrorFrame;
    unsigned short                           usNumberOfSdcrcErrorFrame;
    unsigned short                           usNumberOfShortPacketFrame;
    unsigned short                           usNumberOfJumboPacketFrame;
    unsigned short                           usNumberOfLongPacketFrame;
    unsigned short                           usNumberOfFailedCcLinkIePduSize;
    unsigned short                           usNumberOfFlagmentErrorFrame;
    unsigned short                           usNumberOfPriorityControlFrame;
    unsigned short                           usNumberOfIpFrame;
    unsigned short                           usNumberOfIeee802or1588Frame;
    unsigned short                           usNumberOfLldpFrame;
    unsigned short                           usNumberOfSyncFrame;
    unsigned short                           usPadding;
} ST_SNC_N1MibStatisticalInfo;


typedef struct ST_SNC_N2MibIpOverlapReg_TAG {
    unsigned char                            uchPortIdentifier;
    unsigned char                            uchStatus;
    unsigned char                            auchMacAddress[ST_SNC_MAC_LEN];
    unsigned char                            auchIpAddress[ST_SNC_IPV4V6_LEN];
} ST_SNC_N2MibIpOverlapReg;

typedef struct ST_SNC_N1MibIpOverlapError_TAG {
    unsigned short                           usNumberOfTable;
	unsigned short                           usPadding;
	ST_SNC_N2MibIpOverlapReg         astRegTable[ST_SNC_IPOVLAP_ERR_MAX];
} ST_SNC_N1MibIpOverlapError;


typedef struct ST_SNC_N2MibTopologyReg_TAG {
    unsigned char                            uchType;
    unsigned char                            auchCause[ST_SNC_TPLGCAUSE_LEN];
    unsigned char                            auchMacAddress[ST_SNC_MAC_LEN];
    unsigned char                            auchIpAddress[ST_SNC_DETECTIONACKIP_LEN];
    unsigned char                            uchStationType;
    unsigned char                            uchPadding;
    unsigned short                           usVendorCode;
    unsigned short                           usDeviceType;
    unsigned long                            ulDeviceModelCode;
} ST_SNC_N2MibTopologyReg;

typedef struct ST_SNC_N1MibIpTopologyError_TAG {
    unsigned short                           usNumberOfTable;
	unsigned short                           usPadding;
	ST_SNC_N2MibTopologyReg          astRegTable[ST_SNC_TOPOLOGY_ERR_MAX];
} ST_SNC_N1MibIpTopologyError;





typedef struct ST_SNC_N2MibDatalinkErrorReg_TAG {
    unsigned char                            auchType[ST_SNC_DLETYPE_LEN];
    unsigned char                            uchNetworkNumber;
    unsigned char                            uchStationNumber;
    unsigned char                            auchIpAddress[ST_SNC_IPV4V6_LEN];
} ST_SNC_N2MibDatalinkErrorReg;

typedef struct ST_SNC_N1MibDatalinkError_TAG {
    unsigned short                           usNumberOfTable;
    unsigned short                           usPadding;
	ST_SNC_N2MibDatalinkErrorReg     astErrorTable[ST_SNC_DATALINK_ERR_MAX];
} ST_SNC_N1MibDatalinkError;



typedef struct ST_SNC_N1MibCommTimingError_TAG {
    unsigned char                            uchTimeslotNumber;
} ST_SNC_N1MibCommTimingError;

typedef struct ST_SNC_N3MibErrorDetailReg_TAG {
    unsigned short                   usDetailInfo;
} ST_SNC_N3MibErrorDetailReg;

#pragma pack(1)
typedef struct ST_SNC_N2MibErrorReg_TAG {
    unsigned long long                       ullOccurrenceTimeSeconds;
    unsigned long                            ulOccurrenceTimeNanoLiw;
    unsigned short                           usErrorCode;
	unsigned short                           usErrorOccurrenceOrderNo;
	signed short                            sUtcOffset;
	signed short                            sSummerTimeOffset;
    unsigned char                            uchNumberOfTable;
    ST_SNC_N3MibErrorDetailReg       astDetailTable[ST_SNC_ERRDTLREG_MAX];
} ST_SNC_N2MibErrorReg;

typedef struct ST_SNC_N1MibCurrentError_TAG {
    unsigned short                   usNumberOfTable;
    unsigned short                   usPadding;
    ST_SNC_N2MibErrorReg             astErrorTable[ST_SNC_ERRREG_MAX];
} ST_SNC_N1MibCurrentError;
#pragma pack()

#endif

