/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_MD_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"
#include "ptp_CSSync_1588.h"
#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_GM

#include "ptp_CMSOffset_1AS.h"
#include "ptp_CMSReceive.h"
#include "ptp_SSSync_1AS.h"
#include "ptp_SSSync_1588.h"
#include "ptp_CMSSend.h"

#include "ptp_CSSync_1AS.h"
#include "ptp_GetDetailCurrentTime.h"
#include "ptp_UserAdjust.h"
#include "MDSyncReceiveSM_1AS.h"
#include "ptp_GetDetailCurrentTime.h"
#define D_FUNC	0
#define D_DBG	0
#define D_SYNCTO	0


VOID	CMSSend_00(CLOCKDATA*	pstClockData);
VOID	CMSSend_01(CLOCKDATA*	pstClockData);
VOID	CMSSend_02(CLOCKDATA*	pstClockData);
PORTSYNCSYNC*	setPSSyncCMSS(DOUBLE	dbRateRatio, CLOCKDATA*	pstClockData);
VOID	txPSSyncCMSS(PORTSYNCSYNC*	pstTxPSSyncPtr, CLOCKDATA*	pstClockData);
CHAR	setLogMessageInterval(CLOCKDATA*	pstClockData);
VOID	setCMSyncInterval(CLOCKDATA*	pstClockData);





VOID (*const pfnCMSSendMatrix[ST_CMSS_MAX][EV_CMSS_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CMSSend_01, &CMSSend_01, &CMSSend_00},
	{&CMSSend_01, &CMSSend_02, &CMSSend_00},
	{&CMSSend_01, &CMSSend_02, &CMSSend_00}
};



VOID	clockMasterSyncSend(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSS	enEvt = EV_CMSS_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_MD_PRINT
{
#define	MID_OutUScaledNs(c ,a)	printf(" %s [USNs = 0x%04x 0x%08x 0x%08x 0x%04x ]\n", (c),\
														(a)->usNsec_msb,			\
														(a)->ulNsec_2nd,			\
														(a)->ulNsec_lsb,			\
														(a)->usFrcNsec);

	printf("CMSSendSM SState = [%d] [%d] [%d]\n",
				pstClockData->stClock_GD.enSelectedState[0],
				pstClockData->stClock_GD.enSelectedState[1],
				pstClockData->stClock_GD.enSelectedState[2]);
	MID_OutUScaledNs("stCurrentMasterTime", &pstClockData->stClock_GD.stCurrentMasterTime);
	MID_OutUScaledNs("gstCurrentTime     ", &gstCurrentTime);
}
#endif
		enEvt = GetCMSSendSM_Event(usEvent, pstClockData);

		blSts = IsCMSSendSM_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CMSS_EVENT_MAX))
		{
			(*pfnCMSSendMatrix[pstClockData->stCMSSendSM_GD.enStatusCMSS][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CMSSENDSM, PTP_LOGVE_84000010);
		}

	}
}




CMSSENDSM_GD*	GetCMSSendSM_GD(
	CLOCKDATA*	pstClockData)
{
	CMSSENDSM_GD*	pstCMSSGlb = &(pstClockData->stCMSSendSM_GD);
	return pstCMSSGlb;
}




EN_EV_CMSS	GetCMSSendSM_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CMSS	enEvt = EV_CMSS_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CMSS_BEGIN;
			break;

		case PTP_EV_SYNC_SENDTIME:
			enEvt = EV_CMSS_SYNC_SENDTIME;
			pstClockData->stCMSSendSM_GD.pstTMO_SyncSendTime = NULL;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CMSS_CLOSE;
			break;

		default:
			enEvt = EV_CMSS_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsCMSSendSM_Status(
	CLOCKDATA*	pstClockData)
{
	CMSSENDSM_GD*	pstCMSSGlb	= GetCMSSendSM_GD(pstClockData);
	BOOL			blRet			= FALSE;


	if(pstCMSSGlb->enStatusCMSS < ST_CMSS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}




VOID	CMSSend_00(
	CLOCKDATA*	pstClockData)
{
	CMSSENDSM_GD*	pstCMSSGlb		= GetCMSSendSM_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CMSSend_00",
				  pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	if (pstCMSSGlb->pstTMO_SyncSendTime != NULL)
	{
		(VOID)ptp_TimeOut_Can(pstCMSSGlb->pstTMO_SyncSendTime);
		pstCMSSGlb->pstTMO_SyncSendTime = NULL;
	}

	pstCMSSGlb->enStatusCMSS = ST_CMSS_NONE;

	ptp_dbg_msg( D_FUNC, ("CMSSend_00::-\n") );

}




VOID	CMSSend_01(
	CLOCKDATA*	pstClockData)
{
	CMSSENDSM_GD*	pstCMSSGlb		= GetCMSSendSM_GD(pstClockData);
	USHORT			usSSTimeEvent	= PTP_EV_SYNC_SENDTIME;
	USCALEDNS		stCurrentTime	= {0};

	gdbClockSourceFreqOffset = 1.0;

	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (pstCMSSGlb->pstTMO_SyncSendTime != NULL)
	{
		(VOID)ptp_TimeOut_Can(pstCMSSGlb->pstTMO_SyncSendTime);
		pstCMSSGlb->pstTMO_SyncSendTime = NULL;
	}

	setCMSyncInterval(pstClockData);
	(VOID)ptpAddUSNs_USNs(&stCurrentTime,
							&(pstClockData->stClock_GD.stClockMasterSyncInterval),
							&(pstCMSSGlb->stSyncSendTime));

	pstCMSSGlb->pstTMO_SyncSendTime = ptp_TimeOut_Req(usSSTimeEvent,
														pstClockData,
														pstCMSSGlb->stSyncSendTime,
														(CallBackFunc)&clockMasterSyncSend);

	pstCMSSGlb->enStatusCMSS = ST_CMSS_INITIALIZING;

}




VOID	CMSSend_02(
	CLOCKDATA*	pstClockData)
{
	CMSSENDSM_GD*	pstCMSSGlb		= GetCMSSendSM_GD(pstClockData);
	USHORT			usSSTimeEvent	= PTP_EV_SYNC_SENDTIME;
	USCALEDNS		stCurrentTime	= {0};
	BOOL			blSyncReSend	= FALSE;
	BOOL			blRet			= FALSE;

#ifdef	PTP_USE_IEEE802_1
	CSSYNCSM_1AS_GD*	pstCSSGlb_1AS = GetCSSyncSM_1AS_GD(pstClockData);
#endif

#ifdef	PTP_USE_IEEE1588
	CSSYNCSM_1588_GD*	pstCSSGlb = GetCSSyncSM_1588_GD(pstClockData);
#endif

	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] == ENUM_PORTSTATE_SLAVE)
	{
		SyncTransChkTmo ( pstClockData );

		blRet = ChkSyncTransProcessing( pstClockData );
		if(blRet != FALSE)
		{
			blSyncReSend = TRUE;
		}
		else
		{
			if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
			{
#ifdef	PTP_USE_IEEE802_1
				if (pstClockData->stDefault_1AS_DS.blGmCapable == TRUE)
				{
					if ((pstClockData->stClock_GD.enSelectedState[PORT_NO_0] != pstCSSGlb_1AS->enSelectedState0_Old) 
														&& (pstCSSGlb_1AS->enSelectedState0_Old != ENUM_PORTSTATE_DISABLED))
					{
						pstClockData->stClock_GD.dbCurMasterLastFreqChange    = 
														pstClockData->stClock_GD.dbCurMasterLastFreqChangeForGM / gdbGmRateRatio;
						pstClockData->stClock_GD.usCurMasterTimeBaseIndicator = pstClockData->stClock_GD.usCurMasterTimeBaseIndicator + 1;
						pstClockData->stClock_GD.stCurMasterLastPhaseChange   = pstClockData->stClock_GD.stCurMasterLastPhaseChangeForGM;
					}
					pstCSSGlb_1AS->enSelectedState0_Old = pstClockData->stClock_GD.enSelectedState[PORT_NO_0];
					pstCMSSGlb->pstTxPSSyncPtr = setPSSyncCMSS( gdbGmRateRatio, pstClockData );
					txPSSyncCMSS(pstCMSSGlb->pstTxPSSyncPtr, pstClockData);
				}
#endif
			}
			else
			{
#ifdef	PTP_USE_IEEE1588
				if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] == ENUM_PORTSTATE_SLAVE)
				{
#ifndef	PTP_USE_ME_HW_ASSIST
					if (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] != pstCSSGlb->enSelectedState0_Old)
					{
						EXTENDEDTIMESTAMP	stMasterTime;
						USCALEDNS			stCurrentMasterTime;
						USCALEDNS			stCurrentMasterTime2;
						SCALEDNS			stOffset;
						ULONG				ulPropDelayNumber = { 0 };
						USCALEDNS			stNeighborPropDelay = { 0 };
						DOUBLE				dbRateRatio;

						ptp_GetMasterTime(pstClockData, &stMasterTime);
						ptp_GetCurrentMasterTime(pstClockData, &stCurrentMasterTime);

						ptpSubETS_USNs_SNs(&stMasterTime, &stCurrentMasterTime, &stOffset);
						dbRateRatio = 1.0 / gdbGmRateRatio;

#ifdef PTP_USERADJUST_EXTEND
						ulPropDelayNumber = 0U;
						tsn_Wrapper_MemSet((VOID *)&stNeighborPropDelay, 0x00, sizeof(USCALEDNS));
						pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
						ptp_useradjust2( pstClockData->stDefaultDS.uchDomainNumber,
										 &stOffset,
										 &dbRateRatio,
										 gpstBestDomain->stDefaultDS.uchDomainNumber,
										 &gpstBestDomain->stParentDS,
										 &gpstBestDomain->stCurrentDS,
										 &(pstClockData->stClock_GD.stDelayInfo),
										 &stNeighborPropDelay,
										 ulPropDelayNumber );


#else
						ptp_useradjust( pstClockData->stDefaultDS.uchDomainNumber, 
									    &stOffset, 
							            &dbRateRatio, 
										gpstBestDomain->stDefaultDS.uchDomainNumber );
#endif
						pstCSSGlb->enSelectedState0_Old = pstClockData->stClock_GD.enSelectedState[PORT_NO_0];

						if( dbRateRatio != 0.0 )
						{
							gdbCMFreqOffset = (1.0 / dbRateRatio) - 1.0;
							gdbRateRatio    = gdbCMFreqOffset + 1.0;
							gdbGmRateRatio  = gdbRateRatio;
						}

						if (!IS_SCALEDNS_0(stOffset))
						{
							ptp_TimerSemLockWait();

							(VOID)ptpAddUSNs_SNs(&stCurrentMasterTime, &stOffset, &stCurrentMasterTime2);
							gstCurrentMasterTime = stCurrentMasterTime2;
							(VOID)ptpConvUSNs_ETS(&gstCurrentMasterTime, &gstMasterTime);
							(VOID)ptp_TimerSemUnLock();
						}
					}
#endif
					pstCMSSGlb->pstTxPSSyncPtr = setPSSyncCMSS( gdbGmRateRatio, pstClockData );
					txPSSyncCMSS(pstCMSSGlb->pstTxPSSyncPtr, pstClockData);
				}
#endif
			}
		}
	}
	if (blSyncReSend)
	{
		tsn_Wrapper_MemSet( (VOID *)&pstClockData->stClock_GD.stClockMasterSyncInterval, (INT)0, sizeof(USCALEDNS));
		pstClockData->stClock_GD.stClockMasterSyncInterval = pstClockData->stClock_GD.stSyncSendHoldTime;
	}
	else
	{
		setCMSyncInterval(pstClockData);
	}
	(VOID)ptpAddUSNs_USNs(&stCurrentTime,
							&(pstClockData->stClock_GD.stClockMasterSyncInterval),
							&(pstCMSSGlb->stSyncSendTime));
	ptp_dbg_msg( D_SYNCTO, 
	             ("domain(%d)::sync timer. interval= %04x.%08x.%08x.%04x\n",
	              pstClockData->stDefaultDS.uchDomainNumber,
	              pstClockData->stClock_GD.stClockMasterSyncInterval.usNsec_msb,
				  pstClockData->stClock_GD.stClockMasterSyncInterval.ulNsec_2nd,
				  pstClockData->stClock_GD.stClockMasterSyncInterval.ulNsec_lsb,
				  pstClockData->stClock_GD.stClockMasterSyncInterval.usFrcNsec) );

	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		pstCSSGlb_1AS->enSelectedState0_Old = pstClockData->stClock_GD.enSelectedState[PORT_NO_0];
#endif
	}

	pstCMSSGlb->pstTMO_SyncSendTime = ptp_TimeOut_Req(usSSTimeEvent,
														pstClockData,
														pstCMSSGlb->stSyncSendTime,
														(CallBackFunc)&clockMasterSyncSend);

	pstCMSSGlb->enStatusCMSS = ST_CMSS_SEND_SYNC_INDICATION;

}




PORTSYNCSYNC*  setPSSyncCMSS(
	DOUBLE		dbRateRatio,
	CLOCKDATA*	pstClockData)
{
	PORTSYNCSYNC*	pstTxPSSyncPtr = NULL;
	USCALEDNS			stUSNs				= {0xFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0xFFFF};

#ifndef	PTP_USE_ME_HW_ASSIST
	SCALEDNS			stSNs			= {0};
	USCALEDNS			stA_USNs		= {0};
	SCALEDNS			stB_SNs			= {0};
	USCALEDNS			stC_USNs		= {0};
	USCALEDNS			stCurrentTime	= {0};
	EXTENDEDTIMESTAMP	stMasterTime	= {0};
#else
	USCALEDNS			stC_USNs		= {0};
#endif
	USCALEDNS			stLocalTime		= {0};

	ptp_dbg_msg(D_FUNC,("setPSSyncCMSS::+\n") );

#ifndef	PTP_USE_ME_HW_ASSIST
	USCALEDNS			stDetailCurTime = {0};
	ptp_GetMasterTime(pstClockData, &stMasterTime);
	ptp_GetCurrentTime(pstClockData, &stCurrentTime);
	ptp_GetLocalTime(pstClockData, &stLocalTime);
	ptp_GetDetailCurrentTime(&stDetailCurTime);
#else
	ptp_GetCurrentMasterTime((CLOCKDATA*)NULL, &stLocalTime);
#endif
	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		pstTxPSSyncPtr = &(pstClockData->stUn_CSM_GD.stCsm1as_GD.
													stSSSyncSM_1AS_GD.stRcvdPSSyncDat);
	}
	else
	{
		pstTxPSSyncPtr = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.
													stSSSyncSM_1588_GD.stRcvdPSSyncDat);
	}

	pstTxPSSyncPtr->uchClockNumber				= pstClockData->stDefaultDS.uchDomainNumber;
	pstTxPSSyncPtr->usLocalPortNumber			= PORT_NO_0;

	pstTxPSSyncPtr->stSyncReceiptTimeoutTime	= stUSNs;

#ifndef	PTP_USE_ME_HW_ASSIST
	(VOID)ptpConvETS_TS(&(stMasterTime),
							&(pstTxPSSyncPtr->stPreciseOriginTimestamp));

	(VOID)ptpSubUSNs_USNs(&stDetailCurTime,
							&(stLocalTime),
							&stSNs);


	(VOID)ptpMultSNs_Doub( &stSNs, gdbGmRateRatio, &stB_SNs );


	stA_USNs.usNsec_msb = 0;
	stA_USNs.ulNsec_2nd = 0;
	stA_USNs.ulNsec_lsb = 0;
	stA_USNs.usFrcNsec	= stMasterTime.stNsec.usFrcNsec;

	(VOID)ptpAddUSNs_SNs(&stA_USNs,
							&stB_SNs,
							&stC_USNs);

	(VOID)ptpConvUSNs_SNs(&stC_USNs,
							&(pstTxPSSyncPtr->stFollowUpCorrectionField));

#else

	(VOID)ptpConvUSNs_TS(&(stLocalTime),
							&(pstTxPSSyncPtr->stPreciseOriginTimestamp));

	(VOID)ptpConvUSNs_SNs(&stC_USNs,
							&(pstTxPSSyncPtr->stFollowUpCorrectionField));

#endif

	pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity = pstClockData->stDefaultDS.stClockIdentity;
	pstTxPSSyncPtr->stSourcePortIdentity.usPortNumber	 = PORT_NO_0;

	pstTxPSSyncPtr->chLogMessageInterval	= setLogMessageInterval(pstClockData);
	pstTxPSSyncPtr->stUpstreamTxTime		= stLocalTime;
	pstTxPSSyncPtr->dbRateRatio				= dbRateRatio;


	pstTxPSSyncPtr->usGmTimeBaseIndicator	= gusClockSourceTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange		= gstClockSourceLastGmPhaseChange;
	pstTxPSSyncPtr->dbLastGmFreqChange		= gdbClockSourceLastGmFreqChange;

	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.domainNumber=[%d] defaultDS.domainNumber=[%d]\n", pstTxPSSyncPtr->uchClockNumber, pstClockData->stDefaultDS.uchDomainNumber));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.usLocalPortNumber=[%d]\n", pstTxPSSyncPtr->usLocalPortNumber));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.syncReceiptTimeoutTime=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.usNsec_msb
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.ulNsec_2nd
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.ulNsec_lsb
		, pstTxPSSyncPtr->stSyncReceiptTimeoutTime.usFrcNsec
	));
	ptp_dbg_msg(D_DBG, ("stFollowUpCorrectionField=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stFollowUpCorrectionField.sNsec_msb
		, pstTxPSSyncPtr->stFollowUpCorrectionField.ulNsec_2nd
		, pstTxPSSyncPtr->stFollowUpCorrectionField.ulNsec_lsb
		, pstTxPSSyncPtr->stFollowUpCorrectionField.usFrcNsec
	));
ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.sourcePortIdentity=[%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x(%d)]\n"
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[0]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[1]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[2]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[3]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[4]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[5]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[6]
		, pstTxPSSyncPtr->stSourcePortIdentity.stClockIdentity.uchId[7]
		, pstTxPSSyncPtr->stSourcePortIdentity.usPortNumber
	));
	ptp_dbg_msg(D_DBG, (" defaultDS.sourcePortIdentity=[%02x:%02x:%02x:%02x:%02x:%02x:%02x:%02x]\n"
		, pstClockData->stDefaultDS.stClockIdentity.uchId[0]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[1]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[2]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[3]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[4]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[5]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[6]
		, pstClockData->stDefaultDS.stClockIdentity.uchId[7]
	));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.chLogMessageInterval=[%d]\n", pstTxPSSyncPtr->chLogMessageInterval));
	ptp_dbg_msg(D_DBG, ("gstLocalTime=[%04x:%08x:%08x:%04x]\n"
		, gstLocalTime.usNsec_msb
		, gstLocalTime.ulNsec_2nd
		, gstLocalTime.ulNsec_lsb
		, gstLocalTime.usFrcNsec
		));
#ifndef	PTP_USE_ME_HW_ASSIST
	ptp_dbg_msg(D_DBG, ("stDetailCurTime =[%04x:%08x:%08x:%04x]\n"
		, stDetailCurTime.usNsec_msb
		, stDetailCurTime.ulNsec_2nd
		, stDetailCurTime.ulNsec_lsb
		, stDetailCurTime.usFrcNsec
		));
#endif
	ptp_dbg_msg(D_DBG, ("gstMasterTime=[%04x:%08x:%08x:%04x]\n"
		, gstMasterTime.stSec.usSec_msb
		, gstMasterTime.stSec.ulSec_lsb
		, gstMasterTime.stNsec.ulNsec
		, gstMasterTime.stNsec.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.stPreciseOriginTimestamp=[%04x:%08x:%08x]\n"
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.stSeconds.usSec_msb
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.stSeconds.ulSec_lsb
		, pstTxPSSyncPtr->stPreciseOriginTimestamp.ulNanoseconds
	));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.stUpstreamTxTime=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stUpstreamTxTime.usNsec_msb
		, pstTxPSSyncPtr->stUpstreamTxTime.ulNsec_2nd
		, pstTxPSSyncPtr->stUpstreamTxTime.ulNsec_lsb
		, pstTxPSSyncPtr->stUpstreamTxTime.usFrcNsec
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.dbRateRatio=[%f] gbGmRateRatio=[%f]\n", pstTxPSSyncPtr->dbRateRatio, gdbGmRateRatio));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.usGmTimeBaseIndicator=[%d] gusClockSourceTimeBaseIndicator=[%d]\n", pstTxPSSyncPtr->usGmTimeBaseIndicator, gusClockSourceTimeBaseIndicator));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.stLastGmPhaseChange=[%04x:%08x:%08x:%04x]\n"
		, pstTxPSSyncPtr->stLastGmPhaseChange.sNsec_msb
		, pstTxPSSyncPtr->stLastGmPhaseChange.ulNsec_2nd
		, pstTxPSSyncPtr->stLastGmPhaseChange.ulNsec_lsb
		, pstTxPSSyncPtr->stLastGmPhaseChange.usFrcNsec
	));
	ptp_dbg_msg(D_DBG, ("gstClockSourceLastGmPhaseChange=[%04x:%08x:%08x:%04x]\n"
		, gstClockSourceLastGmPhaseChange.sNsec_msb
		, gstClockSourceLastGmPhaseChange.ulNsec_2nd
		, gstClockSourceLastGmPhaseChange.ulNsec_lsb
		, gstClockSourceLastGmPhaseChange.sNsec_msb
		));
	ptp_dbg_msg(D_DBG, ("PORTSYNCSYNC.dbLastGmFreqChange=[%f] gdbClockSourceLastGmFreqChange=[%f]\n", pstTxPSSyncPtr->dbLastGmFreqChange, gdbClockSourceLastGmFreqChange));


	return pstTxPSSyncPtr;

}




VOID  txPSSyncCMSS(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	CLOCKDATA*		pstClockData)
{
	USHORT				usEvent			= PTP_EV_BASE;
	SSSYNCSM_1AS_GD*	pstSSS_1AS_GD	= NULL;
	SSSYNCSM_1588_GD*	pstSSS_1588_GD	= NULL;


	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{

#ifdef	PTP_USE_IEEE802_1
		pstSSS_1AS_GD = &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD);
		pstSSS_1AS_GD->pstRcvdPSSyncPtr = pstTxPSSyncPtr;
		pstSSS_1AS_GD->blRcvdPSSync = TRUE;

		usEvent = PTP_EV_FOR_STSYNSYN_RCVSYNC;
		siteSyncSync_1AS(usEvent, pstClockData);
#endif

	}
	else
	{

#ifdef	PTP_USE_IEEE1588
		pstSSS_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD);
		pstSSS_1588_GD->pstRcvdPSSyncPtr = pstTxPSSyncPtr;
		pstSSS_1588_GD->blRcvdPSSync = TRUE;

		usEvent = PTP_EV_FOR_STSYNSYN_RCVSYNC;
		siteSyncSync_1588(usEvent, pstClockData);
#endif

	}
}




CHAR	setLogMessageInterval(
	CLOCKDATA*	pstClockData)
{
	PORTDATA*	pstPortData		= pstClockData-> pstPortData;
	CHAR		chCMLSInterval	= 0;


	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		chCMLSInterval = pstPortData->stPort_1AS_DS.chCurrentLogSyncInterval;

		while (pstPortData != NULL)
		{
			if (pstPortData->stPort_GD.blPortValid == TRUE)
			{
				if (chCMLSInterval > pstPortData->stPort_1AS_DS.chCurrentLogSyncInterval)
				{
					chCMLSInterval = pstPortData->stPort_1AS_DS.chCurrentLogSyncInterval;
				}
			}
			pstPortData = pstPortData->pstNextPortDataPtr;
		}
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE1588

		chCMLSInterval = pstPortData->stPort_1588_DS.chLogSyncInterval;

		while (pstPortData != NULL)
		{
			if (pstPortData->stPort_GD.blPortValid == TRUE)
			{
				if (chCMLSInterval > pstPortData->stPort_1588_DS.chLogSyncInterval)
				{
					chCMLSInterval = pstPortData->stPort_1588_DS.chLogSyncInterval;
				}
			}
			pstPortData = pstPortData->pstNextPortDataPtr;
		}
#endif
	}
	pstClockData->stClock_GD.chClockMasterLogSyncInterval = chCMLSInterval;

	return chCMLSInterval;
}



VOID	setCMSyncInterval(
	CLOCKDATA*	pstClockData)
{
	CHAR			chCMLSInterval		= 0;
	USCALEDNS		stInitCMSInterval	= {0, 0, CONST10_9, 0};

	chCMLSInterval = setLogMessageInterval(pstClockData);

	if ((chCMLSInterval >= -CONS_SHIFT16) &&
		(chCMLSInterval <= CONS_SHIFT16))
	{
		(VOID)ptpShiftUSNs_CHAR(&stInitCMSInterval,
								chCMLSInterval,
								&(pstClockData->stClock_GD.stClockMasterSyncInterval));
	}
	else
	{
		pstClockData->stClock_GD.stClockMasterSyncInterval = stInitCMSInterval;
	}
}



#endif

