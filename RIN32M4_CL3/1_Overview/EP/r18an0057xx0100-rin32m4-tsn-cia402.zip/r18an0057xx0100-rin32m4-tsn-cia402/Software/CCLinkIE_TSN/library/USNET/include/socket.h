//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef _USS_SOCKET_H_
#define _USS_SOCKET_H_

#ifndef errno
extern int      errno;
#endif
#ifdef  INET6
#include "socket6.h"
#endif


#define	PF_UNSPEC	0
#define	PF_INET		2
#define	AF_UNSPEC	0
#define	AF_INET		2


#define	SOCK_STREAM	1
#define	SOCK_DGRAM	2
#define	SOCK_RAW	3


#define	SOL_SOCKET	0xffff
#define	IPPROTO_TCP	0x0001
#define	IPPROTO_IP	0x0002

#define SO_DEBUG        0x0001
#define	SO_REUSEADDR	0x0004
#define	SO_KEEPALIVE	0x0008
#define	SO_DONTROUTE	0x0010
#define	SO_BROADCAST	0x0020
#define SO_BINDTODEVICE 0x0040
#define SO_LINGER       0x0080
#define	SO_OOBINLINE	0x0100
#define SO_SNDBUF       0x1001
#define SO_RCVBUF       0x1002
#define SO_ERROR        0x1007
#define SO_TYPE         0x1008

#define	TCP_MAXSEG	0x2000
#define	TCP_NODELAY	0x2001

#define	IP_OPTIONS	0x0001


#define MSG_OOB		0x01
#define MSG_PEEK	0x02
#define MSG_DONTROUTE	0x04


#define O_NDELAY 	0x04
#define FNDELAY O_NDELAY
#define F_GETFL		3
#define F_SETFL		4


#define SIOCATMARK	7
#define FIONBIO		126
#define FIONREAD	127


struct sockaddr {
    unsigned short  sa_family;
    char            sa_data[14];
};
struct in_addr {
    unsigned long   s_addr;
};
struct sockaddr_in {
    short           sin_family;
    unsigned short  sin_port;
    struct in_addr  sin_addr;
    char            sin_zero[8];
};

struct iovec {
    char           *iov_base;
    int             iov_len;
};
struct msghdr {
    char           *msg_name;
    int             msg_namelen;
    struct iovec   *msg_iov;
    int             msg_iovlen;
    char           *msg_accrights;
    int             msg_accrightslen;
};

struct hostent {
    char           *h_name;
    char          **h_aliases;
    int             h_addrtype;
    int             h_length;
    char          **h_addr_list;
#define	h_addr h_addr_list[0]
};

struct servent {
    char           *s_name;
    char          **s_aliases;
    int             s_port;
    char           *s_proto;
};

struct linger {
    int             l_onoff;
    int             l_linger;
};

#define FD_SETSIZE NCONNS
#define FD_SET(n, p) ((p)->fds_bits[(n)>>3] |= (1 << ((n) & 7)))
#define FD_CLR(n, p) ((p)->fds_bits[(n)>>3] &= ~(1 << ((n) & 7)))
#define FD_ISSET(n, p) ((p)->fds_bits[(n)>>3] & (1 << ((n) & 7)))
#define FD_ZERO(p) memset((void *)(p), 0, sizeof(*(p)))
typedef struct {
    unsigned char fds_bits [(FD_SETSIZE + 7) / 8];
} fd_set;

struct timeval {
    long            tv_sec;
    long            tv_usec;
};


struct ip_mreq {
    struct in_addr imr_multiaddr;
    struct in_addr imr_interface;
};
#define IP_MULTICAST_IF     0x0006
#define IP_ADD_MEMBERSHIP   0x0009
#define IP_DROP_MEMBERSHIP  0x000a



#define NE_PARAM	-10
#define EHOSTUNREACH	-11
#define ETIMEDOUT	-12
#define ECONNABORTED	-14
#define ENOBUFS		-15
#define EBADF		-16
#define EFAULT		-17
#define	EWOULDBLOCK	-18
#define	EMSGSIZE	-19
#define	ENOPROTOOPT	-20

#define	EDESTADDRREQ	-50
#define	EPROTOTYPE	-52
#define	EPROTONOSUPPORT	-54
#define	ESOCKTNOSUPPORT	-55
#define	EOPNOTSUPP	-56
#define	EPFNOSUPPORT	-57
#define	EAFNOSUPPORT	-58
#define	EADDRINUSE	-59
#define	EADDRNOTAVAIL	-60
#define	ENETDOWN	-61
#define	ENETUNREACH	-62
#define	ENETRESET	-63
#define	ECONNRESET	-65
#define	EISCONN		-67
#define	ENOTCONN	-68
#define	ESHUTDOWN	-69
#define	ECONNREFUSED	-72
#define	EHOSTDOWN	-73
#define	EALREADY	-76
#define	EINPROGRESS	-77

#define	RECEIVED_LANPORT_1			0
#define	RECEIVED_LANPORT_2			1
#define	RECEIVED_LANPORT_UNKNOWN	-1


int             Ninit(void);
int             Nterm(void);
int             Portinit(char *port);
int             Portterm(char *port);
int             Nprintf(char *form,...);

int             selectsocket(int nfds, fd_set * readfds, fd_set * writefds,
                              fd_set * exceptfds, struct timeval * timeout);
int             accept(int s, struct sockaddr * name, int *namelen, int* piPortno);

int             bind(int s, struct sockaddr * name, int namelen);
int             connect(int s, struct sockaddr * name, int namelen, int iPort);
int             getsockname(int s, struct sockaddr * name, int *namelen);
int             getpeername(int s, struct sockaddr * peer, int *addrlen);
int             getsockopt(int s, int level, int optname, char *optval, int *optlen);
int             setsockopt(int s, int level, int optname, char *optval, int optlen);
int             listen(int s, int backlog);
int             recv(int s, char *buf, int len, int flags);
#define readsocket(s, buf, len) recv(s, buf, len, 0)
int             recvfrom(int s, char *buf, int len, int flags,
                         struct sockaddr * from, int *fromlen, int* npHWport);
int             recvmsg(int s, struct msghdr * msg, int flags);
int             send(int s, char *buf, int len, int flags, int iPortno);
#define writesocket(s, buf, len, iPortno) send(s, buf, len, 0, iPortno)
int             sendto(int s, char *buf, int len, int flags,
                         struct sockaddr * to, int tolen, int iPortno);
int             sendmsg(int s, struct msghdr * msg, int flags);
int             shutdown(int s, int how);
int             socket(int domain, int type, int protocol);
int             closesocket(int conno);
struct hostent *gethostbyname_r(char *hnp, struct hostent * result,
                                   char *buffer, int buflen, int *h_errnop);
struct hostent *gethostbyname(char *hnp);
struct hostent *gethostbyaddr_r(char *addr, int len, int type,
                                                struct hostent * result, char *buffer, int buflen, int *h_errnop);
struct hostent *gethostbyaddr(char *addr, int len, int type);
int             fcntlsocket(int fildes, int cmd, int arg);
int             ioctlsocket(int fildes, int request,...);
void            sleepsocket(int sec);
char           *inet_ntoa(struct in_addr addr);
#endif
