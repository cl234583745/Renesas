/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ANNOUNCEINTVALSET_1AS_H__
#define __ANNOUNCEINTVALSET_1AS_H__

#ifdef __cplusplus
extern "C" {
#endif

VOID AnuncIntvalSetSM_1AS(USHORT usEvent, PORTDATA* pstPort);

VOID AnuncIntvalSetSM_00_1AS(PORTDATA* pstPort);
VOID AnuncIntvalSetSM_01_1AS(PORTDATA* pstPort);
VOID AnuncIntvalSetSM_02_1AS(PORTDATA* pstPort);
VOID AnuncIntvalSetSM_03_1AS(PORTDATA* pstPort);
VOID AnuncIntvalSetSM_NP_1AS(PORTDATA* pstPort);

BOOL AnuncIntSet_NotEnabled_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort);
VOID AnuncIntSet_Initialize_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort);
VOID AnuncIntSet_SetInterval_1AS(AISSETTINGM_GD* pstSmGbl, PORTDATA* pstPort);

VOID computeAnuncInterval_1AS(PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
