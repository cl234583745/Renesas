/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __TCPWRAP_PROTO_H__
#define __TCPWRAP_PROTO_H__

#ifdef __cplusplus
extern "C" {
#endif


INT	tcpwrap_send(UINT		unInterfaceId,
				 UCHAR		uchPort,
				 UCHAR *	puchFramPtr,
				 USHORT		usFramLen);

BOOL tcpwrap_recv(UCHAR		uchPort,
				  UCHAR *	puchFramPtr,
				  USHORT	usFramLen);

VOID tcpwrap_sendcomp(UCHAR	uchPort);

VOID tcpwrap_sbuffree(VOID *	pvPacketId);

INT	ethwrap_send(UCHAR		uchPort,
				 UCHAR *	puchFramPtr,
				 USHORT		usFramLen);


#ifdef __cplusplus
}
#endif

#endif
