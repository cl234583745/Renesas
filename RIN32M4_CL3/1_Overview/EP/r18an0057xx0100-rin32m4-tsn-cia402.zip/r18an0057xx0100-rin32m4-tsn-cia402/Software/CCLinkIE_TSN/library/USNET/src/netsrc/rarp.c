//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"

#define MAXDELAY 30000

struct ARM {
    char message_header[MESSH_SZ];
    char link_header[LHDRSZ];
    short hardware;
    short protocol;
    char halen, ialen;
    short opcode;
    unsigned char shadd[Eid_SZ];
    unsigned char siadd[Iid_SZ];
    unsigned char thadd[Eid_SZ];
    unsigned char tiadd[Iid_SZ];
};
#define ARM_SZ 28
#define EA_REQ       3
#define EA_RES       4
#define ET_IP   0x0800
#define ET_RARP 0x8035

#define MH(mb) ((struct ARM *)mb)

extern struct NET nets[];
extern struct NETCONF netconf[];

#define RARPSERVER


int RARPget(int netno)
{
    int conno, stat = 0;
    unsigned long delay;
    struct NET *netp;
    struct NETCONF *confp;

    netp = &nets[netno];
    confp = &netconf[netp->confix];
    if (confp->Iaddr.l != 0)
        return 1;
    conno = Nopen("*", "RARP", 0, 0, 0);
    if (conno < 0)
        return conno;
    for (delay = netp->tout; delay < MAXDELAY; delay <<= 1) {
        stat = Nwrite(conno, 0, 0);
        if (stat < 0)
            break;
        WAITFOR(confp->Iaddr.l != 0, SIG_WN(netno), delay, stat);
        if (stat == 0) {
            stat = 1;
            break;
        }
        stat = ETIMEDOUT;
    }
    Nclose(conno);
    return stat;
}


static int writE(int conno, MESS *mess)
{
    mess->offset = MESSH_SZ + LHDRSZ;
    mess->mlen = MESSH_SZ + LHDRSZ + ARM_SZ;
    mess->confix = 255;
    MH(mess)->opcode = NC2(EA_REQ);
    MH(mess)->hardware = NC2(1);
    MH(mess)->protocol = NC2(ET_IP);
    MH(mess)->halen = Eid_SZ;
    MH(mess)->ialen = Iid_SZ;
    memcpy((char *)&MH(mess)->thadd,
        (char *)&nets[connblo[conno].netno].id, Eid_SZ);
    memcpy((char *)&MH(mess)->shadd, (char *)&MH(mess)->thadd, Eid_SZ);
    memset((char *)&MH(mess)->tiadd, 0, Iid_SZ);
    *(short *)((char *)mess + MESSH_SZ+12) = NC2(ET_RARP);
    return nets[mess->netno].protoc[0]->writE(conno, mess);
}


static int screen(MESS *mess)
{
    int i1, status;
    struct NETCONF *confp;
    struct NET *netp;

    status = -2;
    netp = &nets[mess->netno];
    for (i1 = 0; i1 < NCONFIGS; i1++) {
        confp = &netconf[i1];
        if (memcmp((char *)&confp->Eaddr, (char *)&MH(mess)->thadd,
                MH(mess)->halen) == 0) {
            if (confp->Iaddr.l == 0) {
                memcpy((char *)&confp->Iaddr, (char *)&MH(mess)->tiadd,
                    Iid_SZ);
                WAITNOMORE(SIG_WN(mess->netno));
            }
#ifdef RARPSERVER
            if (NC2(MH(mess)->opcode) == EA_REQ) {
                memcpy((char *)&MH(mess)->tiadd, (char *)&confp->Iaddr, Iid_SZ);
                memcpy((char *)&MH(mess)->shadd, (char *)&netp->id, Eid_SZ);
                memcpy((char *)&MH(mess)->siadd,
                    (char *)&netconf[netp->confix].Iaddr, Iid_SZ);
                MH(mess)->opcode = NC2(EA_RES);
                status = -3;
            }
#endif
#if NTRACE >= 1
            Nprintf("RARP %02x%02x%02x%02x%02x%02x -> %d.%d.%d.%d\n",
                confp->Eaddr.c[0], confp->Eaddr.c[1], confp->Eaddr.c[2],
                confp->Eaddr.c[3], confp->Eaddr.c[4], confp->Eaddr.c[5], 
                confp->Iaddr.c[0], confp->Iaddr.c[1], confp->Iaddr.c[2],
                confp->Iaddr.c[3]);
#endif
            break;
        }
    }
    return status;
}



static int opeN(int conno, int flag)
{
    (void) conno, (void) flag;
    return 0;
}



static int closE(int conno)
{
    (void) conno;
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}



GLOBALCONST
PTABLE ussRARPTable = {"RARP", 0, 0, screen, opeN, closE, reaDD, writE,
    ioctl, ET_RARP, 0};

