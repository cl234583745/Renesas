//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "msw_lldp.h"
#include "lldpd.h"

static void mibInitObjects(LLDPD_AGENT_T *agent);

void lldpdRxUpdateTimer(LLDPD_AGENT_T *agent)
{
   int ix = 0;
    LLDPD_REM_TBL_T *remTbl;

    remTbl = agent->pLldpdRemData;
    while (remTbl != NULL) {
        if (remTbl->rxinfoTTL) {
            remTbl->rxinfoTTL--;
            if (remTbl->rxinfoTTL == 0) {
                agent->rxState.rxInfoAge = TRUE;
                agent->lldpdStat.rxAgeoutsTotal++;
                lldpdMib.remTblAgeouts++;
                if (agent->rxState.tooManyNghbrsTimer != 0) {
                    LLDPD_LOG_DBG(("lldpdRxUpdateTimer: clear tooManyNghbrsTimer\n"));
                    agent->rxState.tooManyNghbrsTimer = 0;
                    agent->rxState.tooManyNghbrs = FALSE;
                }
            }
        }
        if (++ix >= LLDPD_REM_TBL_NUM) {
            break;
        }
        remTbl = remTbl->next;
    }

    if (agent->rxState.tooManyNghbrsTimer) {
        agent->rxState.tooManyNghbrsTimer--;
        if (agent->rxState.tooManyNghbrsTimer == 0) {
            LLDPD_LOG_DBG(("lldpdRxUpdateTimer: tooManyNghbrsTimer timeout\n"));
            agent->rxState.tooManyNghbrs = FALSE;
        }
    }
    return;
}

void lldpdRxSmInit(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("lldpdRxSmInit: agent=0x%p\n", agent));
    agent->rxState.state = LLDP_WAIT_PORT_OPERATIONAL;
    agent->rxState.rxInfoAge = FALSE;
    mibInitObjects(agent);
    return;
}

static void mibInitObjects(LLDPD_AGENT_T *agent)
{
    LLDPD_REM_TBL_T *tbl;
    LLDPD_REM_TBL_T *relTbl;

    LLDPD_LOG_TRC(("mibInitObjects: agent=0x%p\n", agent));
    tbl = agent->pLldpdRemData;
    while (tbl != NULL) {
        relTbl = tbl;
        tbl = tbl->next;
        lldpdRemDataRel(relTbl);
    }
    return;
}

static int mibUpdateObjects(LLDPD_AGENT_T *agent)
{
    int ret = 0;
    unsigned short us;
    LLDPD_REM_TBL_T *remTbl = NULL;

    LLDPD_LOG_TRC(("mibUpdateObjects: agent=0x%p\n", agent));

    remTbl = lldpdRemTblGet(agent, &agent->rxState.tlvs);
    if (remTbl == NULL) {
        remTbl = lldpdRemTblAdd(agent);
        if (remTbl != NULL) {
            agent->rxState.newNghbr = TRUE;
        }
    }

    if (remTbl != NULL) {
        remTbl->tlvs = agent->rxState.tlvs;
        remTbl->rxinfoTTL = agent->rxState.tlvs.ttl.ttl;

        lldpdLstChgTimSet(agent);

        if (agent->lldpdStat.statInfo.unknownTLV[0] != 0) {
            us = ((agent->lldpdStat.statInfo.unknownTLV[0] & 0x01) << 8 | 
                  (agent->lldpdStat.statInfo.unknownTLV[1] & 0xff)) + 2; 
            if (us != 0) {
                memcpy(remTbl->remUnknownTLV, 
                    agent->lldpdStat.statInfo.unknownTLV, us);
                memset(agent->lldpdStat.statInfo.unknownTLV, 0x00, us);
            }
        }
        else if (remTbl->remUnknownTLV[0] != 0) {
            memset(remTbl->remUnknownTLV, 0x00, sizeof(remTbl->remUnknownTLV));
        }

        if (agent->lldpdStat.statInfo.orgDefInfo[0] != 0) {
            us = ((agent->lldpdStat.statInfo.orgDefInfo[0] & 0x01) << 8 | 
                  (agent->lldpdStat.statInfo.orgDefInfo[1] & 0xff)) + 2; 
            if (us != 0) {
                memcpy(remTbl->orgDefInfo, 
                    agent->lldpdStat.statInfo.orgDefInfo, us);
                memset(agent->lldpdStat.statInfo.orgDefInfo, 0x00, us);
            }
        }
        else if (remTbl->orgDefInfo[0] != 0) {
            memset(remTbl->orgDefInfo, 0x00, sizeof(remTbl->orgDefInfo));
        }
    } else {
        agent->rxState.tooManyNghbrs = TRUE;
        agent->lldpdStat.statInfo.stsFrmDiscarded++;
        if (agent->rxState.tooManyNghbrsTimer < agent->rxState.rxTTL) {
            agent->rxState.tooManyNghbrsTimer = agent->rxState.rxTTL;
        }
        ret = 1;
    }
    memset(&agent->rxState.tlvs, 0x00, sizeof(MSW_INFO_T));

    return ret;
}

static int mibDeleteObjects(LLDPD_AGENT_T *agent)
{
    char *ifname;
    LLDPD_REM_TBL_T *tbl;
    LLDPD_REM_TBL_T *relTbl;
    int ret;

    LLDPD_LOG_TRC(("mibDeleteObjects: agent=0x%p\n", agent));

    ifname = lldpdhwport[((LLDPD_PORT_T *)agent->port)->portno].ifname;
    mswLldpMibDelete(ifname, agent->mcBitmap);

    ret = lldpdRemTblDel(agent, &agent->rxState.tlvs);
    memset(&agent->rxState.tlvs, 0x00, sizeof(MSW_INFO_T));

    while(!lldpdRemTblDel(agent, NULL)) {
        ret = 0;
    }

    return ret;
}

static void rxInitializeLLDP(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("rxInitializeLLDP: agent=0x%p\n", agent));

    agent->rxState.rcvFrame = FALSE;
    agent->rxState.badFrame = FALSE;
    agent->rxState.tooManyNghbrs = FALSE;
    agent->rxState.rxInfoAge = FALSE;

    memset(agent->rxState.inFrame, 0x00, sizeof(agent->rxState.inFrame));
    agent->rxState.frameLen = 0;
    agent->rxState.rxTTL = 0;

    mibDeleteObjects(agent);
    return;
}

static void somethingChangedRemote(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("somethingChangedRemote: agent=0x%p\n", agent));

    agent->rxState.remoteChange = TRUE;

    if (lldpdMib.somethingChangedRemoteCb != NULL) {
        lldpdMib.somethingChangedRemoteCb((void *)agent);
    }
    return;
}

static void rxProcessFrame(LLDPD_AGENT_T *agent)
{
    int ret;
    int len;
    LLDPD_REM_TBL_T *rTbl;

    LLDPD_LOG_TRC(("rxProcessFrame: ifname=%s agentPtr=0x%p\n", 
        lldpdhwport[((LLDPD_PORT_T *)agent->port)->portno].ifname,
        agent));
    len = agent->rxState.frameLen;
    if (len <= 0) {
        return;
    }

    memset(&agent->rxState.tlvs, 0x00, sizeof(MSW_INFO_T));
    memset(agent->lldpdStat.statInfo.unknownTLV, 0x00, sizeof(agent->lldpdStat.statInfo.unknownTLV));
    memset(agent->lldpdStat.statInfo.orgDefInfo, 0x00, sizeof(agent->lldpdStat.statInfo.orgDefInfo));
    ret = mswLldpduAnalysis((unsigned char *)(agent->rxState.inFrame + ETH_HDR_SZ), 
              len - ETH_HDR_SZ, &agent->rxState.tlvs, &agent->lldpdStat.statInfo, (void *)agent);

    if (ret == MSW_EC_NO_ERROR) {
#ifdef LLDPD_DEBUG
        lldpdTlvDump(&agent->rxState.tlvs);
#endif
        rTbl = lldpdRemTblGet(agent, &agent->rxState.tlvs);
        if (rTbl != NULL) {
            if (!memcmp(&agent->rxState.tlvs, &rTbl->tlvs, sizeof(MSW_TLVS_T)) &&
                !memcmp(agent->lldpdStat.statInfo.unknownTLV, 
                    rTbl->remUnknownTLV, 
                    sizeof(rTbl->remUnknownTLV)) &&
                !memcmp(agent->lldpdStat.statInfo.orgDefInfo, 
                    rTbl->orgDefInfo, 
                    sizeof(rTbl->orgDefInfo))) {
                rTbl->rxinfoTTL = rTbl->tlvs.ttl.ttl;
                agent->rxState.rxTTL = rTbl->tlvs.ttl.ttl;
                memset(agent->rxState.inFrame, 0x00, sizeof(agent->rxState.inFrame));
                agent->rxState.frameLen = 0;
                goto END;
            }
        }
         agent->rxState.rxTTL = agent->rxState.tlvs.ttl.ttl;
        if (agent->rxState.rxTTL != 0) {
            agent->rxState.rxChanges = TRUE;
        }
    } else {
        agent->rxState.badFrame = TRUE;
    }

END:
#ifdef LLDPD_DEBUG
    lldpdInfoDump(&agent->lldpdStat);
#endif

    return;
}

static void lldpdRxSmDeleteAgentInfoProc(LLDPD_AGENT_T *agent)
{
    int ret;
    LLDPD_LOG_TRC(("lldpdRxSmDeleteAgentInfoProc: agent=0x%p\n", agent));

    ret = mibDeleteObjects(agent);
    agent->rxState.rxInfoAge = FALSE;
    if (!ret) {
        somethingChangedRemote(agent);
    }
}

static void lldpdRxSmRxLldpInitializeProc(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("lldpdRxSmRxLldpInitializeProc: agent=0x%p\n", agent));

    rxInitializeLLDP(agent);
    agent->rxState.rcvFrame = FALSE;
    return;
}

static void lldpdRxSmWaitForFrameProc(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("lldpdRxSmWaitForFrameProc: agent=0x%p\n", agent));

    agent->rxState.badFrame  = FALSE;
    agent->rxState.rxInfoAge = FALSE;
    return;
}

static void lldpdRxSmRxFramProc(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("lldpdRxSmRxFramProc: agent=0x%p\n", agent));

    agent->rxState.remoteChange = FALSE;
    agent->rxState.rxChanges = FALSE;
    agent->rxState.rcvFrame = FALSE;

    rxProcessFrame(agent);
    return;
}

static void lldpdRxSmDeleteInfoProc(LLDPD_AGENT_T *agent)
{
    int ret;
    LLDPD_LOG_TRC(("lldpdRxSmDeleteInfoProc: agent=0x%p\n", agent));

    ret = mibDeleteObjects(agent);

    memset(agent->rxState.inFrame, 0x00, sizeof(agent->rxState.inFrame));
    agent->rxState.frameLen = 0;

    if (!ret) {
        somethingChangedRemote(agent);
    }
    return;
}

static void lldpdRxSmUpdateInfoProc(LLDPD_AGENT_T *agent)
{
    LLDPD_LOG_TRC(("lldpdRxSmUpdateInfoProc: agent=0x%p\n", agent));

    if (mibUpdateObjects(agent) == 0) {
        somethingChangedRemote(agent);
    }
    return;
}

static void lldpdRxSmStatChange(LLDPD_AGENT_T *agent, int newstate)
{
    switch (newstate) {
    case LLDP_WAIT_PORT_OPERATIONAL:
    case DELETE_AGED_INFO:
    case RX_LLDP_INITIALIZE:
    case RX_WAIT_FOR_FRAME:
    case RX_FRAME:
    case UPDATE_INFO:
    case DELETE_INFO:
        break;
    default:
        LLDPD_LOG_DBG(("lldpdRxSmStatChange: unknown state(%d)\n", newstate));
    }

    LLDPD_LOG_INF(("lldpdRxSmStatChange: state %d -> %d\n", 
        agent->rxState.state, newstate));
    agent->rxState.state = newstate;
    return;
}

static int lldpdRxSmStatUpdate(LLDPD_AGENT_T *agent)
{
    int ret = FALSE;
    unsigned char adminStatus = DISABLED;
    LLDPD_PORT_T *port = agent->port;

    if ((port->portEnabled == FALSE) && (agent->rxState.rxInfoAge == FALSE)) {
        lldpdRxSmStatChange(agent, LLDP_WAIT_PORT_OPERATIONAL);
    }

    switch(agent->rxState.state) {
    case LLDP_WAIT_PORT_OPERATIONAL:
        if (agent->rxState.rxInfoAge == TRUE) {
            lldpdRxSmStatChange(agent, DELETE_AGED_INFO);
            ret =  TRUE;
            break;
        } else if (port->portEnabled == TRUE) {
            lldpdRxSmStatChange(agent, RX_LLDP_INITIALIZE);
            ret = TRUE;
        }
        break;
    case DELETE_AGED_INFO:
        lldpdRxSmStatChange(agent, LLDP_WAIT_PORT_OPERATIONAL);
        ret =  TRUE;
        break;
    case RX_LLDP_INITIALIZE:
        lldpdAdminStatusGet(lldpdhwport[port->portno].ifname, 
          agent->mcBitmap, &adminStatus);
        if ((adminStatus == TX_AND_RX) || (adminStatus == RX_ONLY)) {
            lldpdRxSmStatChange(agent, RX_WAIT_FOR_FRAME);
            ret =  TRUE;
        }
        break;
    case RX_WAIT_FOR_FRAME:
        lldpdAdminStatusGet(lldpdhwport[port->portno].ifname, 
          agent->mcBitmap, &adminStatus);
        if ((adminStatus == DISABLED) || (adminStatus == TX_ONLY)) {
            lldpdRxSmStatChange(agent, RX_LLDP_INITIALIZE);
            ret =  TRUE;
            break;
        }
        if (agent->rxState.rxInfoAge == TRUE) {
            lldpdRxSmStatChange(agent, DELETE_INFO);
            ret =  TRUE;
            break;
        } else if (agent->rxState.rcvFrame == TRUE) {
            lldpdRxSmStatChange(agent, RX_FRAME);
            ret =  TRUE;
        }
        break;
    case DELETE_INFO:
        lldpdRxSmStatChange(agent, RX_WAIT_FOR_FRAME);
        ret = TRUE;
        break;
    case RX_FRAME:
        if ((agent->rxState.badFrame == FALSE) &&
            (agent->rxState.rxTTL == 0)) {
            lldpdRxSmStatChange(agent, DELETE_INFO);
            ret = TRUE;
            break;
        } else if ((agent->rxState.badFrame == FALSE) &&
            (agent->rxState.rxTTL != 0) &&
            (agent->rxState.rxChanges == TRUE)) {
            lldpdRxSmStatChange(agent, UPDATE_INFO);
            ret = TRUE;
            break;
        }
        lldpdRxSmStatChange(agent, RX_WAIT_FOR_FRAME);
        ret = TRUE;
        break;
    case UPDATE_INFO:
        lldpdRxSmStatChange(agent, RX_WAIT_FOR_FRAME);
        ret = TRUE;
        break;
    default:
        LLDPD_LOG_DBG(("lldpdRxSmStatUpdate: ERROR unknown state(%d)\n", 
            agent->rxState.state));
        ret = FALSE;
        break;
    }
    return ret;
}

void lldpdRxSmRun(LLDPD_AGENT_T *agent)
{

    lldpdRxSmStatUpdate(agent);
    do {
        switch(agent->rxState.state) {
        case LLDP_WAIT_PORT_OPERATIONAL:
            break;
        case DELETE_AGED_INFO:
            lldpdRxSmDeleteAgentInfoProc(agent);
            break;
        case RX_LLDP_INITIALIZE:
            lldpdRxSmRxLldpInitializeProc(agent);
            break;
        case RX_WAIT_FOR_FRAME:
            lldpdRxSmWaitForFrameProc(agent);
            break;
        case RX_FRAME:
            lldpdRxSmRxFramProc(agent);
            break;
        case DELETE_INFO:
            lldpdRxSmDeleteInfoProc(agent);
            break;
        case UPDATE_INFO:
            lldpdRxSmUpdateInfoProc(agent);
            break;
        default:
            LLDPD_LOG_DBG(("lldpdRxSmRun: ERROR unknown state(%d)\n", 
                agent->rxState.state));
        }
    } while (lldpdRxSmStatUpdate(agent) == TRUE);
    return;
}
