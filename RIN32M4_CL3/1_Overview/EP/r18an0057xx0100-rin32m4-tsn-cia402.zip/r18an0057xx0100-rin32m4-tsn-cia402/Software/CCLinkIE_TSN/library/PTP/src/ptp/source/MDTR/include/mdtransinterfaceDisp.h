/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDTRANSINTERFACEDISP_H__
#define __MDTRANSINTERFACEDISP_H__
#ifdef DEBUG_LOG_MDTR
#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Proto.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"
#include "ptp_MemManage.h"
#include "ptp_LCEntity.h"

#ifdef __cplusplus
extern "C" {
#endif

INT	Disp_MessageField(UCHAR *puchMsgPtr);

VOID Display_PtpMsgHeader( INT *pnIndex, VOID* pvMsg);
VOID Display_PtpMsgFollowUpTLV_AS( INT *pnIndex, VOID* pvMsg);
VOID Display_PtpMsgSync2_AS( VOID* pvMsg);
VOID Display_PtpMsgSync1_AS( VOID* pvMsg);
VOID Display_PtpMsgFollowUp_AS( VOID* pvMsg);
VOID Display_PtpMsgPdlyReq_AS( VOID* pvMsg);
VOID Display_PtpMsgPdlyResp_AS( VOID* pvMsg);
VOID Display_PtpMsgPDRespFlwUp_AS( VOID* pvMsg);
VOID Display_PtpMsgSignaling_AS( VOID* pvMsg);

VOID Display_PtpMsgSync_1588( VOID* pvMsg);
VOID Display_PtpMsgFollowUp_1588( VOID* pvMsg);
VOID Display_PtpMsgDlyReq_1588( VOID* pvMsg);
VOID Display_PtpMsgDlyResp_1588( VOID* pvMsg);
VOID Display_PtpMsgPdlyReq_1588( VOID* pvMsg);
VOID Display_PtpMsgPdlyResp_1588( VOID* pvMsg);
VOID Display_PtpMsgPDRespFlwUp_1588( VOID* pvMsg);

VOID Display_PtpMsgManagement_1588( VOID* pvMsg);
VOID Display_PtpMsgMgtDataField_1588( PTPMSG_MANAGEMENT_TLV* );

VOID Display_PtpMgt_NullManagement(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_ClockDescription(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_UserDescription(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_Initialize(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_FaultLog(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_FaultLogReset(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_DefaultDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_CurrentDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_ParentDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_TimePropertiesDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PortDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_Priority1(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_Priority2(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_Domain(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_SlaveOnly(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_LogannounceInterval(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_AnnounceReceiptTimeOut(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_LogSyncInterval(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_VersionNumber(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_EnablePort(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_DisablePort(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_Time(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_ClockAccuracy(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_UTCProperties(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_TracebilityProperties(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_TimescaleProperties(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_UnicastNegotiationEnable(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PathTraceList(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PathTraceEnable(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_GrandmasterClusterTable(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_UnicastMasterTable(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_UnicastMasterMaxTableSize(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PortStatisticsCount(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_CMLDPortStatisticsCount(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PortStatisticsErrorCount(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_TransparentClockDefaultDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_TransparentClockPortDataSet(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_PrimaryDomain(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_DelayMechanism(MGT_DATAFIELD* pTlvDt);
VOID Display_PtpMgt_LogMinPdelayReqInterval(MGT_DATAFIELD* pTlvDt);

#ifdef __cplusplus
}
#endif
#endif
#endif
