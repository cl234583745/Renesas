//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "msw_lldp.h"
#include "msw_lldp_basman.h"

static const MSW_LLDP_OPS_T basman_ops = {
    msw_basman_register,
    msw_basman_unregister,
    msw_basman_gettlv,
    NULL,
    NULL,
};

void msw_basman_register(void)
{
    MSW_LLDP_MOD_INFO_T info;

    info.id = MSW_LLDP_MOD_BASIC;
    info.ops = &basman_ops;
    mswLldpModuleAdd(&info);
}

void msw_basman_unregister(void)
{
    mswLldpModuleDel(MSW_LLDP_MOD_BASIC);
}

static int basman_portdes_tlv(unsigned char *outframe, unsigned short *len,
                              MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    LLDP_LOG_TRC(("basman_portdes_tlv: \n"));

    if (tlv->portdes.curlen > Max_SZPORTDES_INFO){
        LLDP_LOG_ERR(("basman_portdes_tlv: port description length error\n"));
        goto out_err;
    }
    
    if (*len < (sizeof(header) + tlv->portdes.curlen)) {
        LLDP_LOG_ERR(("basman_portdes_tlv: Frame overflow error\n"));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_PORTDES, tlv->portdes.curlen);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    memcpy(&outframe[sizeof(header)], &(tlv->portdes.pdes), tlv->portdes.curlen);
    *len -= tlv->portdes.curlen;
    
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int basman_sysname_tlv(unsigned char *outframe, unsigned short *len,
                              MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    LLDP_LOG_TRC(("basman_sysname_tlv: \n"));

    if (tlv->sysname.curlen > Max_SZSYSNAME_INFO){
        LLDP_LOG_ERR(("basman_sysname_tlv: system name length error\n"));
        goto out_err;
    }
    
    if (*len < (sizeof(header) + tlv->sysname.curlen)) {
        LLDP_LOG_ERR(("basman_sysname_tlv: Frame overflow error\n"));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_SYSNAME, tlv->sysname.curlen);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    memcpy(&outframe[sizeof(header)], &(tlv->sysname.name), tlv->sysname.curlen);
    *len -= tlv->sysname.curlen;
    
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int basman_sysdes_tlv(unsigned char *outframe, unsigned short *len,
                              MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    LLDP_LOG_TRC(("basman_sysdes_tlv: \n"));

    if (tlv->sysdes.curlen > Max_SZSYSDES_INFO) {
        LLDP_LOG_ERR(("basman_sysdes_tlv: system description length error\n"));
        goto out_err;
    }
    
    if (*len < (sizeof(header) + tlv->sysdes.curlen)) {
        LLDP_LOG_ERR(("basman_sysdes_tlv: Frame overflow error\n"));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_SYSDES, tlv->sysdes.curlen);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    memcpy(&outframe[sizeof(header)], &(tlv->sysdes.sdes), tlv->sysdes.curlen);
    *len -= tlv->sysdes.curlen;
    
    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int basman_syscap_tlv(unsigned char *outframe, unsigned short *len,
                           MSW_TLVS_T * tlv)
{
    unsigned short header = 0;
    unsigned short tmpus;
    LLDP_LOG_TRC(("basman_syscap_tlv: \n"));

    if (*len < (sizeof(header) + Fix_SZCAP_INFO)) {
        LLDP_LOG_ERR(("basman_syscap_tlv: Frame overflow error\n"));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_SYSCAP, Fix_SZCAP_INFO);
    memcpy(outframe, &header, sizeof(header));
    *len -= sizeof(header);
    tmpus = htons(tlv->syscap.scap);
    memcpy(&outframe[sizeof(header)], &tmpus, sizeof(tmpus));
    tmpus = htons(tlv->syscap.enbl);
    memcpy(&outframe[sizeof(header)+sizeof(tlv->syscap.scap)], 
        &tmpus, sizeof(tmpus));
    *len -= Fix_SZCAP_INFO;

    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

static int basman_mngaddr_tlv(unsigned char *outframe, unsigned short *len,
                           MSW_TLVS_T * tlv, unsigned int index)
{
    unsigned short header = 0;
    unsigned char offset = 0;
    unsigned long tmpul;

    LLDP_LOG_TRC(("basman_mngaddr_tlv: \n"));
    
    if ((tlv->mngaddr[index].curlen < Min_SZMNG_INFO) || (tlv->mngaddr[index].curlen > Max_SZMNG_INFO)){
        LLDP_LOG_ERR(("basman_mngaddr_tlv: infomation string length error(curlen=%d)\n", 
            tlv->mngaddr[index].curlen));
        goto out_err;
    }
    if (((tlv->mngaddr[index].strlen - sizeof(tlv->mngaddr[index].addr.type)) < Min_SZMNG_ADDR) ||
        ((tlv->mngaddr[index].strlen - sizeof(tlv->mngaddr[index].addr.type)) > Max_SZMNG_ADDR)){
        LLDP_LOG_ERR(("basman_mngaddr_tlv: management address length error(len=%d)\n", 
            tlv->mngaddr[index].strlen));
        goto out_err;
    }
    if ((tlv->mngaddr[index].iftype < IF_NUM_SUBTYPE_UNKNOWN) || 
        (tlv->mngaddr[index].iftype > IF_NUM_SUBTYPE_PORTNUM)){
        LLDP_LOG_ERR(("basman_mngaddr_tlv: interface numbering sybtype error(iftype=%d)\n", 
            tlv->mngaddr[index].iftype));
        goto out_err;
    }
    if ((tlv->mngaddr[index].obj.len < Min_SZMNG_OBJ) || (tlv->mngaddr[index].obj.len > Max_SZMNG_OBJ)){
        LLDP_LOG_ERR(("basman_mngaddr_tlv: object indentifier length error(len=%d)\n", 
            tlv->mngaddr[index].obj.len));
        goto out_err;
    }
    
    if (*len < (sizeof(header) + tlv->mngaddr[index].curlen)) {
        LLDP_LOG_ERR(("basman_mngaddr_tlv: basman_mngaddr_tlv fail(len=%d curlen=%d)\n", 
            *len, tlv->mngaddr[index].curlen));
        goto out_err;
    }
    CREATE_LLDP_HDR(header, TYPE_MNGADDR, tlv->mngaddr[index].curlen);
    memcpy(outframe, &header, sizeof(header));
    offset += sizeof(header);
    *len -= sizeof(header);
    memcpy(&outframe[offset], &(tlv->mngaddr[index].strlen), sizeof(tlv->mngaddr[index].strlen));
    offset += sizeof(tlv->mngaddr[index].strlen);
    memcpy(&outframe[offset],
                   &(tlv->mngaddr[index].addr.type),
                   sizeof(tlv->mngaddr[index].addr.type));
    offset += sizeof(tlv->mngaddr[index].addr.type);
    memcpy(&outframe[offset],
                   &(tlv->mngaddr[index].addr.addr),
                   tlv->mngaddr[index].strlen - sizeof(tlv->mngaddr[index].addr.type));
    offset += tlv->mngaddr[index].strlen - sizeof(tlv->mngaddr[index].addr.type);
    memcpy(&outframe[offset],
                   &(tlv->mngaddr[index].iftype),
                   sizeof(tlv->mngaddr[index].iftype));
    offset += sizeof(tlv->mngaddr[index].iftype);
    tmpul = htonl(tlv->mngaddr[index].ifnum);
    memcpy(&outframe[offset], &tmpul, sizeof(tmpul));
    offset += Max_SZMNG_IF;
    memcpy(&outframe[offset],
                   &(tlv->mngaddr[index].obj.len),
                   sizeof(tlv->mngaddr[index].obj.len));
    offset += sizeof(tlv->mngaddr[index].obj.len);
    memcpy(&outframe[offset],
                   &(tlv->mngaddr[index].obj.id),
                   tlv->mngaddr[index].obj.len);
    *len -= tlv->mngaddr[index].curlen;

    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}

int msw_basman_gettlv(unsigned char *outframe, unsigned short *len, MSW_TLVS_T * tlv,
                   MSW_INFO_T * info, void * usrData)
{
    int ret;
    unsigned short length = *len;
    unsigned int idx;

    (void)info;
    (void)usrData;
    LLDP_LOG_TRC(("msw_basman_gettlv: \n"));

    if (tlv->portdes.status == 1) {
    ret = basman_portdes_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
        goto out_err;
    }
    }

    if (tlv->sysname.status == 1) {
    ret = basman_sysname_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
            LLDP_LOG_ERR(("msw_basman_gettlv: basman_sysname_tlv fail\n"));
        goto out_err;
    }
    }

    if (tlv->sysdes.status == 1) {
    ret = basman_sysdes_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
            LLDP_LOG_ERR(("msw_basman_gettlv: basman_sysdes_tlv fail\n"));
        goto out_err;
    }
    }

    if (tlv->syscap.status == 1) {
    ret = basman_syscap_tlv(&outframe[length - *len], len, tlv);
    if (ret < 0) {
            LLDP_LOG_ERR(("msw_basman_gettlv: basman_syscap_tlv fail\n"));
        goto out_err;
    }
    }

    for (idx = 0; idx < MSW_LLDP_MNGTLV_NUM; idx++) {
        if (tlv->mngaddr[idx].status == 1) {
            ret = basman_mngaddr_tlv(&outframe[length - *len], len, tlv, idx);
    if (ret < 0) {
                LLDP_LOG_ERR(("msw_basman_gettlv: basman_mngaddr_tlv fail\n"));
        goto out_err;
    }
        }
    }

    return MSW_EC_NO_ERROR;
out_err:
    return MSW_EC_ERROR;
}
