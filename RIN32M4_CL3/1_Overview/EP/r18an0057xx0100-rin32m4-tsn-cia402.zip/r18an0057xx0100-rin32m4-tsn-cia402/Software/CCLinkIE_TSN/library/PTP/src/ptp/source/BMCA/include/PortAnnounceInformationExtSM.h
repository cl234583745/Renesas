/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PORTANNOUNCEINFORMEXT_H__
#define __PORTANNOUNCEINFORMEXT_H__
#include "ptp_type.h"
#include "ptp_Struct_Port.h"



#ifdef __cplusplus
extern "C" {
#endif

VOID 	portAnnounceInformationExtSM(USHORT usEvent, PORTDATA* pstPort);
PAIEXTSM_EV	GetportAnnAnnInfExtEvt(USHORT usEvent);
VOID	PortAnnounceInfoExt_00(PORTDATA *pstPort);
VOID	PortAnnounceInfoExt_01(PORTDATA* pstPort);
VOID	PortAnnounceInfoExt_02(PORTDATA* pstPort);
VOID	PortAnnounceInfoExt_nop(PORTDATA* pstPort);
VOID	rcvInfoExt(PORTDATA *pstPort);
VOID	updtPortState(PORTDATA *pstPort);
VOID 	selBestDomain( VOID );
#ifdef __cplusplus
}
#endif

#endif
