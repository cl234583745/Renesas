/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/
/*******************************************************************************
* System Name  : PHY Init program(NGN)
* File Name    : ether_phy_init.c
* Version      : 1.0
* Device       :
* Abstract     : Main program for JADE Init program
* Tool-Chain   : IAR Embedded Workbench for ARM
* OS           : not use
* H/W Platform : 
* Description  : Initialize the peripheral settings of JADE
* Limitation   : none
*******************************************************************************/
/*******************************************************************************
* History      : DD.MM.YYYY Version  Description
*              : 25.04.2018 1.0      First Release
*******************************************************************************/

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
/* [Modify]:1st:D:2018/11/14:MSW �͍�:[D09-21]PHY�̏����ݒ�t�@�C����Ver.1.4�ɍX�V */
/* �����[�gI/O�̃t�H���_�\���ɍ��킹��ether_phy_init.h�̊i�[�ꏊ��ύX����		*/
//#include "ether/ether_phy_init.h"
#include "ether_phy_init.h"
/* [Modify End]:1st:D:2018/11/14:MSW �͍�:[D09-21]PHY�̏����ݒ�t�@�C����Ver.1.4�ɍX�V */
#include "kernel.h"
#include "R_IN32M4_CL3.h"
/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define CPU_WRW( addr, data )  (*((volatile unsigned long  *)(unsigned long)(addr)) = ((unsigned long )(data)))

/*===========================================================================*/
/* S T R U C T                                                               */
/*===========================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  Read phy register
  @param  phyadr -- Phy address
  @param  regadr -- Register address
  @retval Register value
 ******************************************************************************
*/

static uint32_t phy_read_reg(uint8_t phyadr, uint8_t regadr)
{
	uint32_t reg_tmp;
    
    // Read access phy register
    RIN_ETH->GMAC_MIIM = ((uint32_t)phyadr << 21) | ((uint32_t)regadr << 16);
    
    // Wait 
	while (1) {
		reg_tmp = RIN_ETH->GMAC_MIIM;
		if ((reg_tmp & 0x04000000) == 0x04000000) {
			return reg_tmp & 0xffff;
		}
	}
}

/**
 ******************************************************************************
  @brief  Write phy register
  @param  phyadr -- Phy address
  @param  regadr -- Register address
  @retval Register value
 ******************************************************************************
*/

static uint32_t phy_write_reg(uint8_t phyadr, uint8_t regadr, uint16_t val)
{
	uint32_t reg_tmp;
    
    // Read access phy register
    RIN_ETH->GMAC_MIIM = 0x04000000 | ((uint32_t)phyadr << 21) | ((uint32_t)regadr << 16) | val;
    
    // Wait 
	while (1) {
		reg_tmp = RIN_ETH->GMAC_MIIM;
		if ((reg_tmp & 0x04000000) == 0x04000000) {
			return reg_tmp & 0xffff;
		}
	}
}

/**
 ******************************************************************************
  @brief  Init_sub for PHY
  @param  none
  @retval none
 ******************************************************************************
*/
void ether_phy_init( void )
{
	uint32_t bk_MACSEL;
	uint32_t bk_PHRSTCH;

	// release PHY reset by CCLinkIE
	CPU_WRW( 0x40100700, 0x00000001 );

	// protect off
	RIN_SYS->SYSPCMD = 0x00a5;
	RIN_SYS->SYSPCMD = 0x0001;
	RIN_SYS->SYSPCMD = 0xfffe;
	RIN_SYS->SYSPCMD = 0x0001;
	
	bk_MACSEL		= RIN_SYS->MACSEL;
	bk_PHRSTCH		= RIN_SYS->PHYRSTCH;
	RIN_SYS->MACSEL = 0x00000003;	// MACSEL select GbEtherMAC
	RIN_SYS->PHYRSTCH = 0x0001;		// PHYRSTCH select GbEtherMAC
	RIN_SYS->PHYRST = 0x0001;		// release PHY reset by GbEtherMAC

	// protect on
	RIN_SYS->SYSPCMD = 0x0000;
	// Reset-OFF check
	while(phy_read_reg( 0, 0x0001) == 0xffff) // After CPU count 105ms
	{
	};

	// GbEtherPHY init_script
        ether_script();

	phy_write_reg( 0, 31, 0x0);  	// Set to Main Page 0
	phy_write_reg( 0, 22, 0x3201);

	phy_write_reg( 0, 23, 0x0000);  //Synchronize RX_CLK to recovered clock
	phy_write_reg( 0, 0, 0x9040);   //Software reset

	phy_write_reg( 0, 31, 0x0);  	// Set to Main Page 0
	phy_write_reg( 0, 22, 0x3200); 	// TurnOffBroadcast

	RIN_SYS->PHYLINK_EN = 0x0001;	// set PHY Link Enable

	// protect off
	RIN_SYS->SYSPCMD = 0x00a5;
	RIN_SYS->SYSPCMD = 0x0001;
	RIN_SYS->SYSPCMD = 0xfffe;
	RIN_SYS->SYSPCMD = 0x0001;

	RIN_SYS->MACSEL		= bk_MACSEL;
	RIN_SYS->PHYRSTCH	= bk_PHRSTCH;

	// protect on
	RIN_SYS->SYSPCMD = 0x0000;
}
