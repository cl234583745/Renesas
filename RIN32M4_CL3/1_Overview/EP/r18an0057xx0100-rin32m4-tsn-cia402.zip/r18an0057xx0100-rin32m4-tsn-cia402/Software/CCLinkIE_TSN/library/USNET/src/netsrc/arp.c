//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "usnet_supply.h"

#ifdef ARP

#define TAKEALL 0

struct ARM {
    char            message_header[MESSH_SZ];
    char            link_header[LHDRSZ];
    short           hardware;
    short           protocol;
    char            halen,
                    ialen;
    short           opcode;
    unsigned char   shadd[Eid_SZ];
    unsigned char   siadd[Iid_SZ];
    unsigned char   thadd[Eid_SZ];
    unsigned char   tiadd[Iid_SZ];
};
#define ARM_SZ 28
#define EA_REQ 1
#define EA_RES 2
#define ET_IP  0x0800
#define ET_ARP 0x0806

#define MH(mb) ((struct ARM *)mb)

extern struct NET nets[];
extern struct NETCONF netconf[];
extern struct CONNECT connblo[];


static int writE(int conno, MESS * mess)
{
    int             netno,
                    confix;

    netno = mess->netno;
    confix = mess->confix;
    mess->mlen = MESSH_SZ + LHDRSZ + ARM_SZ;
    MH(mess)->opcode = NC2(EA_REQ);
    MH(mess)->hardware = NC2(1);
    MH(mess)->protocol = NC2(ET_IP);
    MH(mess)->halen = Eid_SZ;
    MH(mess)->ialen = Iid_SZ;
    Nmemcpy((char *) &MH(mess)->thadd, (char *) &netconf[confix].Eaddr, Eid_SZ);
    Nmemcpy((char *) &MH(mess)->tiadd, (char *) &netconf[confix].Iaddr, Iid_SZ);
    Nmemcpy((char *) &MH(mess)->shadd, (char *) &netconf[nets[netno].confix].Eaddr,
           Eid_SZ);
    Nmemcpy((char *) &MH(mess)->siadd, (char *) &netconf[nets[netno].confix].Iaddr,
           Iid_SZ);
    *(short *) ((char *) mess + MESSH_SZ + 12) = NC2(ET_ARP);
    if (conno < 0)
        return 0;
    mess->confix = 255;
    return nets[netno].protoc[0]->writE(conno, mess);
}


static int screen(MESS * mess)
{
    int             nottous,
                    confix;
    int             stat;
    struct NETCONF *netcfp;
    struct NET     *netp;
    Iid             iid;
    int             portno;
	unsigned char   auchOtherMacAddr[Eid_SZ];
	unsigned long   lSndSts;
	portno = mess->portno;

    netp = &nets[mess->netno];
    nottous = memcmp((char *) &netconf[netp->confix].Iaddr,
                     (char *) &MH(mess)->tiadd, Iid_SZ);
                     
#ifdef USS_PROXYARP
    {
        int i;
        
        for (i = 0; i < NCONFIGS; i++) {
            if ((!memcmp((char *) &netconf[i].Iaddr, &MH(mess)->tiadd, Iid_SZ)) &&
                   (netconf[i].flags & PROXYARP)) {
                nottous = 0;
                break;
            }
        }
    }
#endif

#if TAKEALL == 0
    if (nottous)
        return -2;
#endif

       
    Nmemcpy((char *) &iid, MH(mess)->siadd, Iid_SZ);
    confix = GetHostData(iid.l, !nottous, mess->netno);
    if (confix >= 0) {
        netcfp = &netconf[confix];
#ifdef GARP
        if (netcfp->flags & (LOCALHOST)) {
            if (memcmp((char *) &netcfp->Eaddr, (char *) &MH(mess)->shadd, Eid_SZ)) {
                if (NC2(MH(mess)->opcode) == EA_RES) {
                    if (netcfp->Iconflict[portno] == 0) {
                        vUSN_GetCycSndSts(&lSndSts);
                        if (0 == lSndSts) {
                            netcfp->Iconflict[portno] = 1;
                            Nmemcpy((char *) &auchOtherMacAddr[0], (char *) &MH(mess)->shadd, Eid_SZ);
                            vUSN_GetIpOverlapErrInfo(portno, 2, &auchOtherMacAddr[0]);
                        }
                    }
                    else {
                    }
                } else {
                    if (netcfp->Iconflict[portno] != 1) {
                       netcfp->Iconflict[portno] = 2;
                        Nmemcpy((char *) &auchOtherMacAddr[0], (char *) &MH(mess)->shadd, Eid_SZ);
                        vUSN_GetIpOverlapErrInfo(portno, 1, &auchOtherMacAddr[0]);
                    }
                    else {
                    }
                }
            } else {
                return -2;
            }
        } else {
#endif

        Nmemcpy((char *) &netcfp->Eaddr, (char *) &MH(mess)->shadd, Eid_SZ);
        netcfp->hwaddyes = 1;
        netcfp->timems = TimeMS();
        WAITNOMORE(SIG_ARP);
#ifdef GARP
       }
#endif
#if NTRACE >= 1
        Nprintf("ARP %02x%02x%02x%02x%02x%02x -> %d.%d.%d.%d\n",
                netcfp->Eaddr.c[0], netcfp->Eaddr.c[1], netcfp->Eaddr.c[2],
                netcfp->Eaddr.c[3], netcfp->Eaddr.c[4], netcfp->Eaddr.c[5],
                netcfp->Iaddr.c[0], netcfp->Iaddr.c[1], netcfp->Iaddr.c[2],
                netcfp->Iaddr.c[3]);
#endif
        if (netcfp->ARPwait) {
            if (netp->protoc[0]->writE(netcfp->ARPwait, netcfp->ARPwaitmp))
                if (netcfp->ARPwait != (char)-5)
                    Nrelbuf(netcfp->ARPwaitmp);
            netcfp->ARPwait = 0;
        }
    }
#ifdef GARP
    if (confix >= 0) {
        netcfp = &netconf[confix];
        if (netcfp->Iconflict[portno] == 1) {
            return -2;
        }
        else {
        }
    }
#endif

    
    if (NC2(MH(mess)->opcode) == EA_REQ && !nottous) {
        char temp_ia[Iid_SZ];
        Nmemcpy(temp_ia, (char *) &MH(mess)->tiadd, Iid_SZ);
        Nmemcpy((char *) &MH(mess)->thadd, (char *) &MH(mess)->shadd,
               Eid_SZ + Iid_SZ);
        Nmemcpy((char *) &MH(mess)->shadd, (char *) &netp->id, Eid_SZ);
        Nmemcpy((char *) &MH(mess)->siadd, temp_ia, Iid_SZ);
        MH(mess)->opcode = NC2(EA_RES);
        mess->id = bRELEASE;
        stat = netp->protoc[0]->writE(-1, mess);
        if (stat == 0) {
            return -4;
        }
    }
    return -2;
}



static int opeN(int conno, int flag)
{
    (void) conno, (void) flag;
    return 0;
}



static int closE(int conno)
{
    (void) conno;
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}



GLOBALCONST
PTABLE ussARPTable = {
    "ARP", 0, 0, screen, opeN, closE, reaDD, writE, ioctl,
        ET_ARP, 0
};

#endif
