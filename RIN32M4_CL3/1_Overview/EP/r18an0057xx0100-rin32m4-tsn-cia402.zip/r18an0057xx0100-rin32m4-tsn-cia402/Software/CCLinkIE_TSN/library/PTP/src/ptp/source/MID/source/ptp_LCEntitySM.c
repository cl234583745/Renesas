/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/



#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct.h"
#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"


#include "ptp_CMSOffset_1AS.h"
#include "ptp_CMSSend.h"
#include "ptp_LCEntity.h"
#include "ptp_MemManage.h"
#include "ptp_CMSReceive.h"
#include "ptp_CSSync_1AS.h"
#include "ptp_CSSync_1588.h"
#include "ptp_tsn_Wrapper.h"
#include "ptp_GetDetailCurrentTime.h"

static VOID	LCEntity_00(CLOCKDATA*	pstClockData);
static VOID	LCEntity_01(CLOCKDATA*	pstClockData);
static VOID	LCEntity_02(CLOCKDATA*	pstClockData);
LCENTITYSM_GD*		GetLCEntitySM_GD(CLOCKDATA*	pstClockData);
EN_EV_LCE			GetLCEntitySM_Event(USHORT usEvent, CLOCKDATA*	pstClockData);
BOOL				IsLCEntitySM_Status(CLOCKDATA*	pstClockData);
VOID	detachCurrentTimeQue(CURRENTTIMEQUE*	pstCTQuePtr);
static VOID	ptp_updateLCETime2(CLOCKDATA*	pstClockData, USCALEDNS*	pstDetailCurTime);
static VOID CleanGlobalData( VOID );




VOID (*const pfnLCEntityMatrix[ST_LCE_MAX][EV_LCE_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&LCEntity_01, &LCEntity_01, &LCEntity_00},
	{&LCEntity_01, &LCEntity_02, &LCEntity_00},
	{&LCEntity_01, &LCEntity_02, &LCEntity_00}
};

#define D_FUNC		0
#define D_DBG		0


VOID	localClockEntity(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_LCE	enEvt					= EV_LCE_EVENT_MAX;
	BOOL 		blSts					= FALSE;
	CLOCKDATA*	pstClockDataW		= pstClockData;
	EN_ST_LCE	enStatusLCE_W		= ST_LCE_NONE;


	if (gpstClockDataHPtr == NULL)
	{
		if (usEvent == PTP_EV_BEGIN)
		{
			enEvt = EV_LCE_BEGIN;
			blSts = TRUE;
		}
		else if (usEvent == PTP_EV_TICK)
		{
			enEvt = EV_LCE_TICK;
			blSts = TRUE;
		}
		else
		{
		}
		pstClockDataW = NULL;
		enStatusLCE_W = ST_LCE_NONE;
	}

	if (pstClockDataW != NULL)
	{
		enEvt = GetLCEntitySM_Event(usEvent, pstClockData);

		blSts = IsLCEntitySM_Status(pstClockData);
		enStatusLCE_W = pstClockData->stLCEntitySM_GD.enStatusLCE;

	}
	if ((blSts == TRUE) &&
		(enEvt < EV_LCE_EVENT_MAX))
	{
		(*pfnLCEntityMatrix[enStatusLCE_W][enEvt])(pstClockData);

	}
	else
	{
		PTP_ERROR_LOGRECORD(pstClockDataW, PTP_LOG_LCENTITYSM, PTP_LOGVE_84000010);
	}

}





LCENTITYSM_GD*	GetLCEntitySM_GD(
	CLOCKDATA*	pstClockData)
{
	LCENTITYSM_GD*	pstLCEGlb = &(pstClockData->stLCEntitySM_GD);
	return pstLCEGlb;
}



EN_EV_LCE	GetLCEntitySM_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_LCE	enEvt = EV_LCE_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_LCE_BEGIN;
			break;

		case PTP_EV_TICK:
			enEvt = EV_LCE_TICK;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_LCE_CLOSE;
			break;

		default:
			enEvt = EV_LCE_EVENT_MAX;
			break;
	}

	return	enEvt;
}



BOOL	IsLCEntitySM_Status(
	CLOCKDATA*	pstClockData)
{
	LCENTITYSM_GD*	pstLCEGlb	= GetLCEntitySM_GD(pstClockData);
	BOOL			blRet			= FALSE;


	if (pstLCEGlb->enStatusLCE < ST_LCE_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}



static VOID	LCEntity_00( CLOCKDATA*	pstClockData )
{
	LCENTITYSM_GD*	pstLCEGlb		= NULL;
	CURRENTTIMEQUE*	pstCTQuePtr		= NULL;
	CURRENTTIMEQUE*	pstNextCTQuePtr = NULL;


	if (pstClockData != NULL)
	{
		pstLCEGlb = GetLCEntitySM_GD(pstClockData);

		gblCurrentMasterTimeInit = FALSE;
		gdbRateRatio			 = DBCONST1_0;

		pstClockData->stClock_GD.usCurMasterTimeBaseIndicator          = 0U;
		pstClockData->stClock_GD.stCurMasterLastPhaseChange.sNsec_msb = (USHORT)0U;
		pstClockData->stClock_GD.stCurMasterLastPhaseChange.ulNsec_2nd = 0LU;
		pstClockData->stClock_GD.stCurMasterLastPhaseChange.ulNsec_lsb = 0LU;
		pstClockData->stClock_GD.stCurMasterLastPhaseChange.usFrcNsec  = (USHORT)0U;
		pstClockData->stClock_GD.dbCurMasterLastFreqChange             = (DOUBLE)1.0;

		pstClockData->stParent_1AS_DS.lCumulativeRateRatio	= 0;


		SET_USCALEDNS( gstCurrentMasterTime, 0, 0, 0, 0 );
		SET_ETIMESTAMP( gstMasterTime, 0, 0, 0, 0 );
		gdbGmRateRatio				= DBCONST1_0;

		SET_USCALEDNS( gstLocalTime, 0, 0, 0, 0 );


		pstLCEGlb->enStatusLCE = ST_LCE_INITIALIZING;



		for ( pstCTQuePtr = gpstCurrentTimeQuePtr;
			  pstCTQuePtr != NULL;
			  pstCTQuePtr = pstNextCTQuePtr )
		{
			pstNextCTQuePtr = pstCTQuePtr->pstNextCTQuePtr;

			ptp_MMfree( CLOCK_NUM_0, PTP_MM_CTQUE, (VOID*)pstCTQuePtr );
		}
		gpstCurrentTimeQuePtr = NULL;
	}

}

static VOID CleanGlobalData( VOID )
{
	
	
	tsn_Wrapper_MemSet( &gstCurrentTime, 0, sizeof(USCALEDNS) );

	gblCurrentTimeInit			= FALSE;
	gpstCurrentTimeQuePtr		= NULL;

#ifdef PTP_USE_ME_HW_ASSIST
	tsn_Wrapper_MemSet( &gstMasterLocalOffset, 0, sizeof(EXTENDEDTIMESTAMP) );
	tsn_Wrapper_MemSet( &gstLocatTimeForMaster, 0, sizeof(USCALEDNS) );
#endif

	gdbClockSourceFreqOffset			= DBCONST1_0;
	tsn_Wrapper_MemSet( &gstClockSourcePhaseOffset, 0, sizeof(SCALEDNS) );
	gusClockSourceTimeBaseIndicator	= 0U;
	gusClockSourceTimeBaseIndOld	= 0U;

	tsn_Wrapper_MemSet( &gstClockSourceLastGmPhaseChange, 0, sizeof(SCALEDNS) );
	tsn_Wrapper_MemSet( &gstMasterTime, 0, sizeof(EXTENDEDTIMESTAMP) );
	tsn_Wrapper_MemSet( &gstCurrentMasterTime, 0, sizeof(USCALEDNS) );

	gblCurrentMasterTimeInit		= TRUE;
	gdbRateRatio					= DBCONST1_0;
	gdbClockSourceLastGmFreqChange	= DBCONST0_0;
	gdbGmRateRatio					= DBCONST1_0;

	tsn_Wrapper_MemSet( &gstLocalTime, 0, sizeof(USCALEDNS) );

	gdbCMFreqOffset					= DBCONST0_0;

	tsn_Wrapper_MemSet( &gstCMPhaseOffset, 0, sizeof(SCALEDNS) );

	gpstBestDomain					= NULL;

	tsn_Wrapper_MemSet( &gstDreqTmoManage, 0, sizeof(gstDreqTmoManage) );
	tsn_Wrapper_MemSet( &gstSyncTmoManage, 0, sizeof(gstSyncTmoManage) );
	
	return ;
}


static VOID	LCEntity_01( CLOCKDATA*	pstClockData )
{
	LCENTITYSM_GD*	pstLCEGlb = NULL;

	if ( pstClockData != NULL )
	{
		pstClockData->stParent_1AS_DS.lCumulativeRateRatio = 0;
		pstClockData->stClock_GD.dbRateRatio               = DBCONST1_0;
		pstLCEGlb = GetLCEntitySM_GD(pstClockData);
		pstLCEGlb->enStatusLCE = ST_LCE_INITIALIZING;
	}
	else
	{
		CleanGlobalData( );
	}

	return;
}

static VOID	LCEntity_02( CLOCKDATA*	pstClockData )
{
}








VOID	ptp_updateLCETime(
	CLOCKDATA*	pstClockData)
{
	LONG				lRet			= RET_ESTATE;
	USCALEDNS			stDetailCurTime	= {0};


	lRet = ptp_TimerSemLockWait();
	if (lRet != RET_ENOERR)
	{
		return;
	}

	ptp_GetDetailCurrentTime(&stDetailCurTime);
	ptp_updateLCETime2(pstClockData,
						&stDetailCurTime);

	(VOID)ptp_TimerSemUnLock();

	if (pstClockData	  != NULL)
	{
		lRet = ptp_SystemSemLock(pstClockData);
		if (lRet == RET_ENOERR)
		{
			ptp_chkCurrentTimeTimeout(pstClockData);

			(VOID)ptp_SystemSemUnLock(pstClockData);

		}
		else
		{
		}
	}
}






#ifndef PTP_USE_ME_HW_ASSIST
static VOID	ptp_updateLCETime2(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstDetailCurTime)
{
	SCALEDNS  stSNs;
	SCALEDNS  stDtSNs;
	USCALEDNS stAnsUSNs;
	EXTENDEDTIMESTAMP stAnsTs;

	(VOID)ptpSubUSNs_USNs( pstDetailCurTime, &gstCurrentTime, &stSNs );

	(VOID)ptpMultSNs_Doub( &stSNs, gdbRateRatio, &stDtSNs );
	(VOID)ptpAddUSNs_SNs( &gstCurrentMasterTime, &stDtSNs, &stAnsUSNs );
	gstCurrentMasterTime = stAnsUSNs;

	(VOID)ptpMultSNs_Doub( &stSNs, gdbGmRateRatio, &stDtSNs );
	(VOID)ptpAddETS_SNs( &gstMasterTime, &stDtSNs, &stAnsTs );
	gstMasterTime = stAnsTs;

	gstLocalTime = *pstDetailCurTime;
	gstCurrentTime = *pstDetailCurTime;

	return ;
}
#else
static VOID	ptp_updateLCETime2(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstDetailCurTime)
{

	gstCurrentTime = *pstDetailCurTime;
	gstLocalTime = *pstDetailCurTime;
	
	return ;
}
#endif






LONG	ptp_TimerSemLockWait(VOID)
{
	LONG		lRet				= RET_ESTATE;
	VOID*		pvLockHandleTimer	= gpvLockHandleTimer;


	if (pvLockHandleTimer != NULL)
	{
		lRet = (LONG)tsn_Wrapper_LockWait(pvLockHandleTimer);
		if (lRet != RET_ENOERR)
		{
			PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_OSERROR);
		}
	}
	else
	{
		PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_RESPTRNULL);
	}


	return	lRet;
}




LONG	ptp_TimerSemLock(VOID)
{
	LONG		lRet				= RET_ESTATE;
	VOID*		pvLockHandleTimer	= gpvLockHandleTimer;


	if (pvLockHandleTimer != NULL)
	{
		lRet = (LONG)tsn_Wrapper_Lock(pvLockHandleTimer);
		if ((lRet != RET_ENOERR) &&
			(lRet != RET_ETMO))
		{
			PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_OSERROR);
		}
	}
	else
	{
		PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_RESPTRNULL);
	}


	return	lRet;
}




LONG	ptp_TimerSemUnLock(VOID)
{
	LONG		lRet				= RET_ESTATE;
	VOID*		pvLockHandleTimer	= gpvLockHandleTimer;


	if (pvLockHandleTimer != NULL)
	{
		lRet = tsn_Wrapper_UnLock(pvLockHandleTimer);
		if (lRet != RET_ENOERR)
		{
			PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_OSERROR);
		}
	}
	else
	{
		PTP_EMERG_LOGRECORD (gpstClockDataHPtr, PTP_LOG_LCENTITYSM, PTP_LOGVE_RESPTRNULL);
	}


	return	lRet;
}




VOID	ptp_GetCurrentTime(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstCurrentTime)
{

	(VOID)ptp_TimerSemLockWait();

	(*pstCurrentTime) = gstCurrentTime;

	(VOID)ptp_TimerSemUnLock();

}




#ifndef	PTP_USE_ME_HW_ASSIST
VOID	ptp_GetCurrentMasterTime(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstCurrentMasterTime)
{
	USCALEDNS			stDetailCurTime	= {0};

	ptp_GetCurrentMasterTime2(pstClockData,
								pstCurrentMasterTime,
								&stDetailCurTime);

}
#endif




VOID	ptp_GetCurrentMasterTime2(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstCurrentMasterTime,
	USCALEDNS*	pstDetailCurTime)
{
	USCALEDNS			stDetailCurTime	= {0};
	SCALEDNS			stInt_SNs		= {0};
	SCALEDNS			stIntB_SNs		= {0};
	USCALEDNS			stB_USNs		= {0};

	(VOID)ptp_TimerSemLockWait();

	ptp_GetDetailCurrentTime(&stDetailCurTime);
	(VOID)ptpSubUSNs_USNs(&stDetailCurTime,
							&gstCurrentTime,
							&stInt_SNs);

	(VOID)ptpMultSNs_Doub(&stInt_SNs, gdbRateRatio, &stIntB_SNs );
	(VOID)ptpAddUSNs_SNs( &gstCurrentMasterTime, &stIntB_SNs, &stB_USNs );


	(*pstCurrentMasterTime) = stB_USNs;

	(*pstDetailCurTime)		= stDetailCurTime;

	(VOID)ptp_TimerSemUnLock();

}


#ifndef	PTP_USE_ME_HW_ASSIST
VOID	ptp_SetCurrentMasterTime(
	CLOCKDATA*	pstClockData,
	SCALEDNS*	pstCMPhaseOffset,
	USCALEDNS*	pstNewCurrentMasterTime)
{
	USCALEDNS			stUSNs_CSTime		= {0};
	SCALEDNS			stSNs_CMT_CSTOffset	= {0};
	USCALEDNS			stC_USNs			= {0};


	(VOID)ptp_TimerSemLockWait();


	(VOID)ptpAddUSNs_SNs( &gstCurrentMasterTime, pstCMPhaseOffset, &stC_USNs );
	gstCurrentMasterTime     = stC_USNs;
	*pstNewCurrentMasterTime = stC_USNs;


	(VOID)ptp_TimerSemUnLock();

}



VOID	ptp_GetCurrentDriverTime(
	UCHAR				uchClockNumber,
	EXTENDEDTIMESTAMP*	pstCurrentDriverTime)
{
	EXTENDEDTIMESTAMP	stETS_CDTime	= {0};
	CLOCKDATA*			pstClockData;
	USCALEDNS			stDetailCurTime	= {0};
	SCALEDNS			stA_SNs			= {0};
	SCALEDNS			stB_SNs			= {0};
	USCALEDNS			stC_USNs		= {0};

	if (!gblStartUpInit)
		return;

	if (uchClockNumber != CLOCK_NUM_0)
	{
		(*pstCurrentDriverTime) = stETS_CDTime;
		return;
	}
	pstClockData	= gpstClockDataHPtr;

	ptp_dbg_msg(D_FUNC, ("ptp_GetCurrentDriverTime2::+\n"));

	(VOID)ptp_TimerSemLockWait();

	if ((pstClockData != NULL )&&
		(pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588))
	{
#ifdef	PTP_USE_IEEE1588

		ptp_GetDetailCurrentTime(&stDetailCurTime);
		(VOID)ptpSubUSNs_USNs(&stDetailCurTime,
								&gstCurrentTime,
								&stA_SNs);
		(VOID)ptpMultSNs_Doub( &stA_SNs, gdbRateRatio, &stB_SNs );
		(VOID)ptpAddUSNs_SNs( &gstCurrentMasterTime, &stB_SNs, &stC_USNs );

		(VOID)ptpConvUSNs_ETS(&stC_USNs,
								&stETS_CDTime);


#endif

	}
	else
	{
		ptp_GetDetailCurrentTime(&stDetailCurTime);
		(VOID)ptpConvUSNs_ETS(&(stDetailCurTime),
								&stETS_CDTime);

	}
	(*pstCurrentDriverTime) = stETS_CDTime;

	ptp_dbg_msg(D_DBG, ("gstCurrentMasterTime  =[%04x:%08x:%08x:%04x]\n"
		, gstCurrentMasterTime.usNsec_msb
		, gstCurrentMasterTime.ulNsec_2nd
		, gstCurrentMasterTime.ulNsec_lsb
		, gstCurrentMasterTime.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("gstCurrentTime        =[%04x:%08x:%08x:%04x]\n"
		, gstCurrentTime.usNsec_msb
		, gstCurrentTime.ulNsec_2nd
		, gstCurrentTime.ulNsec_lsb
		, gstCurrentTime.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("stDetailCurTime       =[%04x:%08x:%08x:%04x]\n"
		, stDetailCurTime.usNsec_msb
		, stDetailCurTime.ulNsec_2nd
		, stDetailCurTime.ulNsec_lsb
		, stDetailCurTime.usFrcNsec
	) );
	ptp_dbg_msg(D_DBG, ("gdbRateRatio          =[%f]\n", gdbRateRatio) );
	ptp_dbg_msg(D_DBG, ("*pstCurrentDriverTime =[%04x:%08x:%08x:%04x]\n"
		, stETS_CDTime.stSec.usSec_msb
		, stETS_CDTime.stSec.ulSec_lsb
		, stETS_CDTime.stNsec.ulNsec
		, stETS_CDTime.stNsec.usFrcNsec
	) );

	ptp_updateLCETime2(pstClockData,
						&stDetailCurTime);
	(VOID)ptp_TimerSemUnLock();

	ptp_dbg_msg(D_FUNC, ("ptp_GetCurrentDriverTime::-\n"));

}

#endif








VOID	ptp_chkCurrentTimeTimeout(
	CLOCKDATA*	pstClockData)
{
	CURRENTTIMEQUE*	pstCTQuePtr			= NULL;
	CURRENTTIMEQUE*	pstNextCTQuePtr		= NULL;
	CHAR			chRet				= COMP_EQUAL;
	USCALEDNS		stChkCurrentTime	= {0};
	LONG			lRet				= RET_ESTATE;


	ptp_GetCurrentTime(pstClockData, &stChkCurrentTime);

	lRet = ptp_TimerSemLockWait();
	if (lRet != RET_ENOERR)
	{
		return;
	}
	{

		for ( pstCTQuePtr = gpstCurrentTimeQuePtr;
			  pstCTQuePtr != NULL;
			  pstCTQuePtr = pstNextCTQuePtr)
		{
			pstNextCTQuePtr = pstCTQuePtr->pstNextCTQuePtr;

			chRet = ptpCompUSNs_USNs(&stChkCurrentTime,
										&(pstCTQuePtr->stTMO_Manage_Inf_BLK.stTimeoutTime));
			if ((chRet == COMP_A_GREAT) ||
				 (chRet == COMP_EQUAL))
			{
				detachCurrentTimeQue(pstCTQuePtr);
				(VOID)ptp_TimerSemUnLock();


				(*(pstCTQuePtr->stTMO_Manage_Inf_BLK.pfnCallBack))
									(pstCTQuePtr->stTMO_Manage_Inf_BLK.usEvent,
										pstCTQuePtr->stTMO_Manage_Inf_BLK.pvParam);

				(VOID)ptp_TimerSemLockWait();
				ptp_MMfree(CLOCK_NUM_0, PTP_MM_CTQUE, pstCTQuePtr);

				pstCTQuePtr = gpstCurrentTimeQuePtr;
			}
			else
			{
				break;
			}

		}
	}
	(VOID)ptp_TimerSemUnLock();
}




TMO_MANAGE_INF_BLK*	ptp_TimeOut_Req(
	USHORT		usEvent,
	VOID*		pvParam,
	USCALEDNS	stTimeoutTime,
	CallBackFunc	pfnCallBack)
{
	TMO_MANAGE_INF_BLK*	pstRetTMO			= NULL;
	CURRENTTIMEQUE*		pstCTQuePtr			= NULL;
	CURRENTTIMEQUE*		pstNewCTQuePtr		= NULL;
	CURRENTTIMEQUE*		pstNextCTQuePtr		= NULL;
	CURRENTTIMEQUE*		pstLastCTQuePtr		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	CHAR				chRet				= COMP_EQUAL;
	LONG			lRet				= RET_ESTATE;


	if (gpstClockDataHPtr == NULL)
	{
		return pstRetTMO;
	}
	pstClockData = gpstClockDataHPtr;

	if ((usEvent >= PTP_EV_MAX) ||
		(pvParam == NULL) ||
		(pfnCallBack == NULL))
	{
		return pstRetTMO;
	}


	lRet = ptp_TimerSemLockWait();
	if (lRet != RET_ENOERR)
	{
		return pstRetTMO;
	}
	pstNewCTQuePtr = (CURRENTTIMEQUE*)ptp_MMalloc(CLOCK_NUM_0, PTP_MM_CTQUE);

	if (pstNewCTQuePtr != NULL)
	{
		pstNewCTQuePtr->stTMO_Manage_Inf_BLK.usEvent = usEvent;
		pstNewCTQuePtr->stTMO_Manage_Inf_BLK.pvParam = pvParam;
		pstNewCTQuePtr->stTMO_Manage_Inf_BLK.stTimeoutTime = stTimeoutTime;
		pstNewCTQuePtr->stTMO_Manage_Inf_BLK.pfnCallBack = pfnCallBack;

		if ( gpstCurrentTimeQuePtr != NULL )
		{
			for ( pstCTQuePtr = gpstCurrentTimeQuePtr;
				  pstCTQuePtr != NULL;
				  pstCTQuePtr = pstNextCTQuePtr )
			{
				pstNextCTQuePtr = pstCTQuePtr->pstNextCTQuePtr;

				pstLastCTQuePtr = pstCTQuePtr;
				chRet = ptpCompUSNs_USNs(&(pstCTQuePtr->stTMO_Manage_Inf_BLK.stTimeoutTime),
											&stTimeoutTime);
				if ((chRet == COMP_A_GREAT) ||
					 (chRet == COMP_EQUAL))
				{
					pstNewCTQuePtr->pstNextCTQuePtr = pstCTQuePtr;
					pstNewCTQuePtr->pstPrevCTQuePtr =  pstCTQuePtr->pstPrevCTQuePtr;
					pstCTQuePtr->pstPrevCTQuePtr = pstNewCTQuePtr;
					pstNewCTQuePtr->pstPrevCTQuePtr->pstNextCTQuePtr = pstNewCTQuePtr;

					break;
				}
			}
			if (pstCTQuePtr == NULL)
			{
				pstLastCTQuePtr->pstNextCTQuePtr = pstNewCTQuePtr;
				pstNewCTQuePtr->pstNextCTQuePtr = NULL;
				pstNewCTQuePtr->pstPrevCTQuePtr =  pstLastCTQuePtr;
			}
		}
		else
		{

			gpstCurrentTimeQuePtr = pstNewCTQuePtr;
			pstNewCTQuePtr->pstNextCTQuePtr = NULL;
			pstNewCTQuePtr->pstPrevCTQuePtr = (CURRENTTIMEQUE*)&(gpstCurrentTimeQuePtr);
		}

		pstRetTMO = &(pstNewCTQuePtr->stTMO_Manage_Inf_BLK);
	}
	(VOID)ptp_TimerSemUnLock();

	return pstRetTMO;
}




USHORT	ptp_TimeOut_Can(
	TMO_MANAGE_INF_BLK*	pstTmoMan_cansel)
{
	CURRENTTIMEQUE*		pstCTQuePtr			= NULL;
	CURRENTTIMEQUE*		pstNextCTQuePtr		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	USHORT				usRet				= (USHORT)RET_EINVAL;
	LONG				lRet				= RET_ESTATE;


	if (gpstClockDataHPtr == NULL)
	{
		return usRet;
	}
	pstClockData = gpstClockDataHPtr;

	if (pstTmoMan_cansel == NULL)
	{
		return usRet;
	}

	lRet = ptp_TimerSemLockWait();
	if (lRet != RET_ENOERR)
	{
		return usRet;
	}
	{
		for ( pstCTQuePtr = gpstCurrentTimeQuePtr; 
			  pstCTQuePtr != NULL; 
			  pstCTQuePtr = pstNextCTQuePtr )
		{
			pstNextCTQuePtr = pstCTQuePtr->pstNextCTQuePtr;

			if (pstTmoMan_cansel == &(pstCTQuePtr->stTMO_Manage_Inf_BLK))
			{
				detachCurrentTimeQue(pstCTQuePtr);

				ptp_MMfree(CLOCK_NUM_0, PTP_MM_CTQUE, (VOID*)pstCTQuePtr);

				usRet = RET_ENOERR;

				break;
			}
		}
	}
	(VOID)ptp_TimerSemUnLock();

	return usRet;

}




VOID	detachCurrentTimeQue(
	CURRENTTIMEQUE*	pstCTQuePtr)
{



	pstCTQuePtr->pstPrevCTQuePtr->pstNextCTQuePtr = pstCTQuePtr->pstNextCTQuePtr;
	if (pstCTQuePtr->pstNextCTQuePtr != NULL)
	{
		pstCTQuePtr->pstNextCTQuePtr->pstPrevCTQuePtr = pstCTQuePtr->pstPrevCTQuePtr;
	}

}




