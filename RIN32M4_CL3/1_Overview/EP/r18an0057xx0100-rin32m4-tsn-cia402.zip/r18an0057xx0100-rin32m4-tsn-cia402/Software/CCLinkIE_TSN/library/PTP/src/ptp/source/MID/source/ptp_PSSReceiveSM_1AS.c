/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_MD_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct.h"
#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"

#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_IEEE802_1

#include "MDSyncReceiveSM.h"
#include "MDSyncReceiveSM_1AS.h"
#include "ptp_SSSync_1AS.h"
#include "ptp_PSSReceive_1AS.h"

#include "ptp_CSSync_1AS.h"

#define D_FUNC	0


VOID	PSSReceive_1AS_00(PORTDATA*	pstPortData);
VOID	PSSReceive_1AS_01(PORTDATA*	pstPortData);
VOID	PSSReceive_1AS_02(PORTDATA*	pstPortData);
PORTSYNCSYNC*  setPSSyncPSSR_1AS(MDSYNCRECEIVE *  pstRcvdMDSyncPtr,
							 PORTDATA*	pstPortData,
							 USCALEDNS*	pstSyncReceiptTTimeInterval,
							 DOUBLE		dbRateRatio);
VOID  txPSSyncPSSR(PORTSYNCSYNC* pstTxPSSyncPtr, PORTDATA* pstPortData);
VOID  setDelayInfo_P2P(PORTDATA*		pstPortData);



#ifdef	DEBUG_MID_MD_PRINT

#define	DEBMID_RZ_DBPRINT(c, a)		printf(" %s = %.15e \n", (c), (a));

#define	MID_OutUScaledNs(c ,a)	printf(" %s [USNs = 0x%04x 0x%08x 0x%08x 0x%04x ]\n", (c),\
														(a)->usNsec_msb,			\
														(a)->ulNsec_2nd,			\
														(a)->ulNsec_lsb,			\
														(a)->usFrcNsec);

#endif


VOID (*const pfnPSSReceiveMatrix[ST_PSSR_MAX][EV_PSSR_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PSSReceive_1AS_01, &PSSReceive_1AS_01, &PSSReceive_1AS_00},
	{&PSSReceive_1AS_01, &PSSReceive_1AS_02, &PSSReceive_1AS_00},
	{&PSSReceive_1AS_01, &PSSReceive_1AS_02, &PSSReceive_1AS_00}
};



VOID	portSyncSyncReceive_1AS(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSR	enEvt = EV_PSSR_EVENT_MAX;
	BOOL 		blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_MD_PRINT
{
	printf("PSSReceiveSM_1AS SState = [%d] [%d] [%d]\n",
				pstPortData->pstClockData->stClock_GD.enSelectedState[0],
				pstPortData->pstClockData->stClock_GD.enSelectedState[1],
				pstPortData->pstClockData->stClock_GD.enSelectedState[2]);
	MID_OutUScaledNs("CurrentMasterTime  ", (&pstPortData->pstClockData->stClock_GD.stCurrentMasterTime));
	DEBMID_RZ_DBPRINT("GD_dbRateRatio     ", pstPortData->pstClockData->stClock_GD.dbRateRatio);
	DEBMID_RZ_DBPRINT("SYNC_dbRateRatio   ", pstPortData->stPort_GD.stMdSyncReceive.dbRateRatio);
	DEBMID_RZ_DBPRINT("dbNeighborRateRatio", pstPortData->stPort_GD.dbNeighborRateRatio);
}
#endif
		enEvt = GetPSSReceiveSM_1AS_Event(usEvent, pstPortData);

		blSts = IsPSSReceiveSM_1AS_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PSSR_EVENT_MAX))
		{
			(*pfnPSSReceiveMatrix[pstPortData->stUn_PSM_GD.stPsm1as_GD.stPSSReceiveSM_1AS_GD.enStatusPSSR][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1AS, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1as_GD.stPSSReceiveSM_1AS_GD.blRcvdMDSync = FALSE;
		}

	}
}




PSSRECEIVESM_1AS_GD*	GetPSSReceiveSM_1AS_GD(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb = &(pstPortData->stUn_PSM_GD.stPsm1as_GD.stPSSReceiveSM_1AS_GD);
	return pstPSSRGlb;
}




EN_EV_PSSR	GetPSSReceiveSM_1AS_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSR				enEvt				= EV_PSSR_EVENT_MAX;
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb		= GetPSSReceiveSM_1AS_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PSSR_BEGIN;
			break;

		case PTP_EV_FOR_PSYNSYNRV_RCVMDSYNC:
			if ((pstPSSRGlb->blRcvdMDSync) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PSSR_BEGIN;
			}
			else if (pstPSSRGlb->enStatusPSSR == ST_PSSR_DISCARD)
			{
				if ((pstPSSRGlb->blRcvdMDSync) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PSSR_FOR_PSYNSYNRV_RCVMDSYNC;
				}
			}
			else if (pstPSSRGlb->enStatusPSSR == ST_PSSR_RECEIVED_SYNC)
			{
				if ((pstPSSRGlb->blRcvdMDSync) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PSSR_FOR_PSYNSYNRV_RCVMDSYNC;
				}
			}
			else
			{
			}
		break;

		case PTP_EV_CLOSE:
			enEvt = EV_PSSR_CLOSE;
			break;

		default:
			enEvt = EV_PSSR_EVENT_MAX;
		break;
	}

	return	enEvt;
}

BOOL	IsPSSReceiveSM_1AS_Status(
	PORTDATA*	pstPortData)
{
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb	= GetPSSReceiveSM_1AS_GD(pstPortData);
	BOOL					blRet			= FALSE;


	if (pstPSSRGlb->enStatusPSSR < ST_PSSR_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	PSSReceive_1AS_00(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb = GetPSSReceiveSM_1AS_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PSSReceive_1AS_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPSSRGlb->blRcvdMDSync	= FALSE;
	pstPSSRGlb->enStatusPSSR	= ST_PSSR_NONE;

	ptp_dbg_msg( D_FUNC, ("PSSReceive_1AS_00::-\n") );

}



VOID	PSSReceive_1AS_01(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb = GetPSSReceiveSM_1AS_GD(pstPortData);


	pstPSSRGlb->blRcvdMDSync	= FALSE;
	pstPSSRGlb->enStatusPSSR	= ST_PSSR_DISCARD;
}



VOID	PSSReceive_1AS_02(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1AS_GD*	pstPSSRGlb					= GetPSSReceiveSM_1AS_GD(pstPortData);
	MDSYNCRECEIVE*			pstRcvdMDSyncPtr			= &(pstPortData->stPort_GD.stMdSyncReceive);
	CLOCKDATA*				pstClockData				= pstPortData->pstClockData;
	USCALEDNS				stA_USNs					= {0};
	USCALEDNS				stSyncReceiptTimeoutTimeInt	= {0};
	ULONG					ulC_msb						= 0;
	ULONG					ulC_lsb						= 0;
	CHAR					chA							= 0;
	DOUBLE					dbRateRatioW				= DBCONST0_0;

	PORTDATA*				pstPdelayPort				= pstPortData;

	pstPdelayPort = GetPdelayPort_1AS(pstClockData, pstPortData->stPortDS.stPortIdentity.usPortNumber);

	pstPSSRGlb->blRcvdMDSync	= FALSE;
	pstPSSRGlb->pstRcvdMDSyncPtr = pstRcvdMDSyncPtr;

	if ((pstRcvdMDSyncPtr->dbRateRatio > DBCONST_RATE_MIN) &&
		(pstRcvdMDSyncPtr->dbRateRatio < DBCONST_RATE_MAX))
	{
		dbRateRatioW = pstRcvdMDSyncPtr->dbRateRatio;
		dbRateRatioW += (pstPdelayPort->stPort_GD.dbNeighborRateRatio - DBCONST1_0);
		if ((dbRateRatioW > DBCONST_RATE_MIN) &&
			(dbRateRatioW < DBCONST_RATE_MAX))
		{
			pstClockData->stClock_GD.dbRateRatio = dbRateRatioW;
		}
		else
		{
			PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1AS, PTP_LOGVE_84000006);
		}
	}
	else
	{
		PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1AS, PTP_LOGVE_84000006);
	}

	pstClockData->stClock_GD.usCurMasterTimeBaseIndicator   = pstRcvdMDSyncPtr->usGmTimeBaseIndicator;
	pstClockData->stClock_GD.dbCurMasterLastFreqChangeForGM = pstClockData->stClock_GD.dbRateRatio;
	pstClockData->stClock_GD.dbCurMasterLastFreqChange      = pstRcvdMDSyncPtr->dbLastGmFreqChange;
	pstClockData->stClock_GD.stCurMasterLastPhaseChange     = pstRcvdMDSyncPtr->stLastGmPhaseChange;

	pstClockData->stParent_1AS_DS.lCumulativeRateRatio
		= (LONG)((pstClockData->stClock_GD.dbRateRatio - DBCONST1_0)
				* DBCONST2_41);

	(VOID)ptpMultUL_UL((ULONG)(pstPortData->stPort_1AS_DS.uchSyncReceiptTimeout + 1),
						(ULONG)CONST10_9,
						&ulC_msb,
						&ulC_lsb);
	stA_USNs.usFrcNsec	= (USHORT)(ulC_lsb & (ULONG)MASK_FFFF);
	stA_USNs.ulNsec_lsb	= ((ulC_msb & (ULONG)MASK_FFFF) << CONS_SHIFT16) + (ulC_lsb >> CONS_SHIFT16);
	stA_USNs.ulNsec_2nd = (ulC_msb >> CONS_SHIFT16);

	chA = CONS_SHIFT16 + pstRcvdMDSyncPtr->chLogMessageInterval;

	(VOID)ptpShiftUSNs_CHAR(&stA_USNs,
								chA,
								&stSyncReceiptTimeoutTimeInt);
	pstPortData->stPort_1AS_DS.stSyncReceiptTimeoutTimeInterval = stSyncReceiptTimeoutTimeInt;

	pstPSSRGlb->pstTxPSSyncPtr = setPSSyncPSSR_1AS(pstRcvdMDSyncPtr,
													pstPortData,
													&stSyncReceiptTimeoutTimeInt,
													pstClockData->stClock_GD.dbRateRatio);

	if (pstPSSRGlb->pstTxPSSyncPtr != NULL)
	{
		setDelayInfo_P2P(pstPortData);
		txPSSyncPSSR(pstPSSRGlb->pstTxPSSyncPtr,
						pstPortData);
	}
	pstPSSRGlb->enStatusPSSR	= ST_PSSR_RECEIVED_SYNC;

}




PORTSYNCSYNC*  setPSSyncPSSR_1AS(
	MDSYNCRECEIVE*	pstRcvdMDSyncPtr,
	PORTDATA*		pstPortData,
	USCALEDNS*		pstSyncReceiptTTimeInterval,
	DOUBLE			dbRateRatio)
{
	CLOCKDATA*				pstClockData	= pstPortData->pstClockData;
	PORTSYNCSYNC*			pstTxPSSyncPtr	= NULL;
	USCALEDNS				stUSNs			= {0};
	BOOL					blRet			= FALSE;
	USCALEDNS				stCurrentTime	= {0};


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);


	pstTxPSSyncPtr	= &(pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.stRcvdPSSyncDat);
	pstTxPSSyncPtr->uchClockNumber				= pstRcvdMDSyncPtr->uchClockNumber;
	pstTxPSSyncPtr->usLocalPortNumber			= pstPortData->stPort_GD.usThisPort;
	pstTxPSSyncPtr->stFollowUpCorrectionField	= pstRcvdMDSyncPtr->stFollowUpCorrectionField;
	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdMDSyncPtr->stSourcePortIdentity;
	pstTxPSSyncPtr->chLogMessageInterval		= pstRcvdMDSyncPtr->chLogMessageInterval;
	pstTxPSSyncPtr->stPreciseOriginTimestamp	= pstRcvdMDSyncPtr->stPreciseOriginTimestamp;
	pstTxPSSyncPtr->stUpstreamTxTime			= pstRcvdMDSyncPtr->stUpstreamTxTime;
	pstTxPSSyncPtr->dbRateRatio 				= dbRateRatio;
 	pstTxPSSyncPtr->usGmTimeBaseIndicator 		= pstRcvdMDSyncPtr->usGmTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange 		= pstRcvdMDSyncPtr->stLastGmPhaseChange;
	pstTxPSSyncPtr->dbLastGmFreqChange 			= pstRcvdMDSyncPtr->dbLastGmFreqChange;

	blRet = ptpAddUSNs_USNs(&stCurrentTime,
							 pstSyncReceiptTTimeInterval,
							 &stUSNs);
	if(blRet == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_PSSRECEIVESM_1AS, PTP_LOGVE_OVERFLOW);
		return NULL;
	}
	pstTxPSSyncPtr->stSyncReceiptTimeoutTime = stUSNs;
	pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD.pstRcvdPSSyncPtr = pstTxPSSyncPtr;


	return pstTxPSSyncPtr;

}





VOID  txPSSyncPSSR(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	PORTDATA*		pstPortData)
{

	USHORT				usEvent			= PTP_EV_BASE;
	SSSYNCSM_1AS_GD*	pstSSS_1AS_GD	= &(pstPortData->pstClockData->stUn_CSM_GD.stCsm1as_GD.stSSSyncSM_1AS_GD);


	pstSSS_1AS_GD->pstRcvdPSSyncPtr = pstTxPSSyncPtr;
	pstSSS_1AS_GD->blRcvdPSSync		= TRUE;

	pstSSS_1AS_GD->dbRcvdCumulativeRateRatio
									= pstPortData->stPort_GD.stMdSyncReceive.dbRateRatio;

	usEvent = PTP_EV_FOR_STSYNSYN_RCVSYNC;
	siteSyncSync_1AS(usEvent, pstPortData->pstClockData);

}



VOID  setDelayInfo_P2P(
	PORTDATA*		pstPortData)
{
	CLOCKDATA*			pstClockData		= pstPortData->pstClockData;
	DELAYINFO_P2P*		pstDelayInfo_P2P	= NULL;

	CSSYNCSM_1AS_GD*		pstCSSGlb		= GetCSSyncSM_1AS_GD(pstClockData);
	PORTDATA*				pstPdelayPort	= pstPortData;

	pstDelayInfo_P2P = &(pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P);

	pstDelayInfo_P2P->stSyncOriginTimeStamp			= pstPortData->stPort_GD.stSyncEventEgressTimestamp;
	pstDelayInfo_P2P->stSyncCorrectionField			= pstPortData->stPort_GD.stSyncCorrectionField;
	pstDelayInfo_P2P->stSyncReceiveTime				= pstPortData->stPort_GD.stSyncEventIngressTimestamp;


	pstPdelayPort = GetPdelayPort_1AS(pstClockData, pstCSSGlb->pstRcvdPSSyncPtr->usLocalPortNumber);

	pstDelayInfo_P2P->stPdlyReqSendtime				= pstPdelayPort->stPort_GD.stPdlyReqSendtime;
	pstDelayInfo_P2P->stPdlyRespReqRecpTimeStamp	= pstPdelayPort->stPort_GD.stPdlyRespReqRecpTimeStamp;
	pstDelayInfo_P2P->stPdlyRespCorrectionField		= pstPdelayPort->stPort_GD.stPdlyRespCorrectionField;
	pstDelayInfo_P2P->stPdlyRespFupReqRecpTimeStamp	= pstPdelayPort->stPort_GD.stPdlyRespFupReqRecpTimeStamp;
	pstDelayInfo_P2P->stPdlyRespFupCorrectionField	= pstPdelayPort->stPort_GD.stPdlyRespFupCorrectionField;
	pstDelayInfo_P2P->stPdlyRespReceiveTime			= pstPdelayPort->stPort_GD.stPdlyRespReceiveTime;

	pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_P2P;

}




#endif
