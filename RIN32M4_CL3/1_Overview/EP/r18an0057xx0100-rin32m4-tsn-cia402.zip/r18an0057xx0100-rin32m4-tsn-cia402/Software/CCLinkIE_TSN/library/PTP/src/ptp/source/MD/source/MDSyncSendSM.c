/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDSyncSendSM.h"
#ifdef	PTP_USE_IEEE802_1
#include "MDSyncSendSM_1AS.h"
#endif
#ifdef	PTP_USE_IEEE1588
#include "MDSyncSendSM_1588.h"
#endif


VOID MDSyncSendSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE802_1
	if (IsMDCOMSupportPTPTyp802_1AS(pstPort))
	{
		MDSyncSendSM_1AS(usEvent, pstPort);
		return;
	}
#endif
#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDSyncSendSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM, PTP_LOGVE_82000002);
	return;
}

MDSSENDSM_GD* GetMDSyncSndSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDSSendSM_GD;
}

MDSYNCSNDSM_EV GetMDSyncSndEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCSNDSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDSYCS_E_BEGIN;
		break;
		case PTP_EV_FOR_MDSYNCSENDSM_RCVDSYNC:
			enEvt = MDSYCS_E_FOR_MDSYNCSND_RCVDSYNC;
		break;
		case PTP_EV_RCVDMDTIMESTAMPRECEIVE:
			enEvt = MDSYCS_E_RCVD_MDTIMESTAMP_RCV;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDSYCS_E_CLOSE;
		break;

		default:
			enEvt = MDSYCS_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDSYNCSNDSM_ST 	GetMDSyncSndStatus(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;
	MDSYNCSNDSM_ST	enSts = MDSYCS_STATUS_MAX;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);
	if (pstGbl->enStsMDSyncSend < MDSYCS_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDSyncSend;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDSyncSndStatus(MDSYNCSNDSM_ST enSts, PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	pstGbl->enStsMDSyncSend = enSts;
	return;
}

VOID IncMDSyncSndTxSyncCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulTxSyncCount++;
	return;
}

VOID IncMDSyncSndTxFollowUpCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulTxFollowUpCount++;
	return;
}

VOID IncMDSyncSndTxOneStepSyncCount(PORTDATA* pstPort)
{
	pstPort->stPortStatistics_1AS_DS.ulTxOneStepSyncCount++;
	return;
}

BOOL SetMDSyncMgEgresTimestamp(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	BOOL	blRet = FALSE;

	if (IS_TIMESTAMP_0(pstSmGbl->stEgMDTimestampReceive) == FALSE)
	{
		tsn_Wrapper_MemCpy(&pstSmGbl->stSyncEgTimestamp,
			&pstSmGbl->stEgMDTimestampReceive, sizeof(TIMESTAMP));
		blRet = TRUE;
	}
	else
	{
		tsn_Wrapper_MemSet(&pstSmGbl->stSyncEgTimestamp, 0L, sizeof(TIMESTAMP));
	}
#ifdef PTP_USE_ME_HW_ASSIST
	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		if (IS_TIMESTAMP_0(pstSmGbl->stEgMDTimestampReceive_Frun) == FALSE)
		{
			tsn_Wrapper_MemCpy(&pstSmGbl->stSyncEgTimestamp_Frun,
				&pstSmGbl->stEgMDTimestampReceive_Frun, sizeof(TIMESTAMP));
		}
		else
		{
			tsn_Wrapper_MemSet(&pstSmGbl->stSyncEgTimestamp_Frun, 0L, sizeof(TIMESTAMP));
			blRet = FALSE;
		}
	}
#endif
	return blRet;
}
