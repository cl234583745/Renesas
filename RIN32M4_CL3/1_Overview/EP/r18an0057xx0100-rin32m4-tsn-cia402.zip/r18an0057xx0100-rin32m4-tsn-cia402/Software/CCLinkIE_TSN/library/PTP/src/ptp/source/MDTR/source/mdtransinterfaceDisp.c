/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifdef DEBUG_LOG_MDTR
#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Type.h"
#include "ptpwrap_Proto.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"
#include "ptp_MemManage.h"
#include "ptp_LCEntity.h"

#include "mdtransinterfaceDisp.h"

extern BOOL blTestASPtpType(VOID);
extern BOOL blTest1588PtpType(VOID);

INT	Disp_MessageField(UCHAR *puchMsgPtr)
{
	INT			iRet=0;
	PTPMSG*		txpvMsg = (PTPMSG*)puchMsgPtr;

	if (blTestASPtpType()) {
		printf ("  DUMP IEEE802.1AS MESSAGE FIELD \n");
		switch ( MPTPMSG_H_GET_MSG_TYPE(&txpvMsg->stHeader) )
		{
		case 0x0:
			if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(&txpvMsg->stHeader) )
				Display_PtpMsgSync2_AS( (VOID*)puchMsgPtr );
			else
				Display_PtpMsgSync1_AS( (VOID*)puchMsgPtr );
			break;
		case 0x8:
			Display_PtpMsgFollowUp_AS( (VOID*)puchMsgPtr );
			break;

		case 0x2:
			Display_PtpMsgPdlyReq_AS( (VOID*)puchMsgPtr );
			break;
		case 0x3:
			Display_PtpMsgPdlyResp_AS( (VOID*)puchMsgPtr );
			break;
		case 0xA:
			Display_PtpMsgPDRespFlwUp_AS( (VOID*)puchMsgPtr );
			break;

		default:
			break;
		}
	}
	if (blTest1588PtpType()) {
		printf ("  DUMP IEEE1588 MESSAGE FIELD \n");
		switch ( MPTPMSG_H_GET_MSG_TYPE(&txpvMsg->stHeader) )
		{
		case 0x0:
			Display_PtpMsgSync_1588( (VOID*)puchMsgPtr );
			break;
		case 0x8:
			Display_PtpMsgFollowUp_1588( (VOID*)puchMsgPtr );
			break;

		case 0x1:
			Display_PtpMsgDlyReq_1588( (VOID*)puchMsgPtr );
			break;
		case 0x9:
			Display_PtpMsgDlyResp_1588( (VOID*)puchMsgPtr );
			break;

		case 0x2:
			Display_PtpMsgPdlyReq_1588( (VOID*)puchMsgPtr );
			break;
		case 0x3:
			Display_PtpMsgPdlyResp_1588( (VOID*)puchMsgPtr );
			break;
		case 0xA:
			Display_PtpMsgPDRespFlwUp_1588( (VOID*)puchMsgPtr );
			break;
		case 0xD:
			Display_PtpMsgManagement_1588( (VOID*)puchMsgPtr );
			break;

		default:
			break;
		}
	}
	return (iRet);
}

VOID Display_PtpMsgHeader( INT *pnIndex, VOID* pvMsg )
{
	INT nIndex = *pnIndex;
	PTPMSG*	pmsg = (PTPMSG*)pvMsg;
	printf( " [stHeader] \n" );
	printf( " %04d + byMajorSdoId                      = 0x%X, \n",	nIndex , MPTPMSG_H_GET_MAJORSDO_ID(&pmsg->stHeader) );
	printf( " %04d + byMsgType                         = 0x%X, \n",	nIndex , MPTPMSG_H_GET_MSG_TYPE(&pmsg->stHeader) );
														   nIndex += sizeof(pmsg->stHeader.byMjSdoIdAndMsgTyp);
	printf( " %04d + byMinorVer                        = 0x%X, \n",	nIndex , MPTPMSG_H_GET_MINOR_VER(&pmsg->stHeader) );
	printf( " %04d + byVersionPTP                      = 0x%X, \n",	nIndex , MPTPMSG_H_GET_VER_PTP(&pmsg->stHeader) );
														   nIndex += sizeof(pmsg->stHeader.byMiVerAndVerPTP);

	printf( " %04d + usMegLength                       = 0x%04X(%03d),\n"	,nIndex ,pmsg->stHeader.usMegLength, pmsg->stHeader.usMegLength );
																	nIndex += sizeof(pmsg->stHeader.usMegLength);
	printf( " %04d + uchDomainNumber                   = 0x%02X, \n"		,nIndex ,pmsg->stHeader.uchDomainNumber );
																	nIndex += sizeof(pmsg->stHeader.uchDomainNumber);
	printf( " %04d + uchMinorSdoId                     = 0x%02X, \n"		,nIndex ,pmsg->stHeader.uchMinorSdoId );
																	nIndex += sizeof(pmsg->stHeader.uchMinorSdoId);
	printf( " %04d + stFlags0.byPTPprofileSpecific2     = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS0_PTP_PROSPCFC2(&pmsg->stHeader) );
	printf( " %04d +         .byPTPprofileSpecific1     = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS0_PTP_PROSPCFC1(&pmsg->stHeader) );
	printf( " %04d +         .byUnicastFlag             = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS0_UNICAST(&pmsg->stHeader) );
	printf( " %04d +         .byTwoStepFlag             = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS0_TWOSTEP(&pmsg->stHeader) );
	printf( " %04d +         .byAlternateMasterFlag     = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS0_ALTMASTER(&pmsg->stHeader) );
														   nIndex += sizeof(pmsg->stHeader.byFlags0);

	printf( " %04d +   stFlags1.byFrequencyTraceable    = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_FQTRACEABLE(&pmsg->stHeader) );
	printf( " %04d +           .byTimeTraceable         = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_TMTRACEABLE(&pmsg->stHeader) );
	printf( " %04d +           .byPtpTimescale          = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_PTPTIMESCALE(&pmsg->stHeader) );
	printf( " %04d +           .byCurrentUtcOffsetValid = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_CRNT_UTCOFSVAL(&pmsg->stHeader) );
	printf( " %04d +           .byLeap59                = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_LEAP59(&pmsg->stHeader) );
	printf( " %04d +           .byLeap61                = %x, \n",	nIndex , MPTPMSG_H_GET_FLAGS1_LEAP61(&pmsg->stHeader) );
														   nIndex += sizeof(pmsg->stHeader.byFlags1);

	printf( " %04d + stCorrectionField.sNsec_msb       = 0x%04x, \n",	nIndex , pmsg->stHeader.stCorrectionField.sNsec_msb );
																nIndex += sizeof(pmsg->stHeader.stCorrectionField.sNsec_msb);
	printf( " %04d +                  .ulNsec_lsb      = 0x%08x, \n",	nIndex , pmsg->stHeader.stCorrectionField.ulNsec_lsb );
																nIndex += sizeof(pmsg->stHeader.stCorrectionField.ulNsec_lsb);
	printf( " %04d +                  .usFrcNsec       = 0x%04x, \n",	nIndex , pmsg->stHeader.stCorrectionField.usFrcNsec );
																nIndex += sizeof(pmsg->stHeader.stCorrectionField.usFrcNsec);
	printf( " %04d + uchMsgTypSpecific                 = 0x%02x 0x%02x 0x%02x 0x%02x, \n", nIndex ,
															pmsg->stHeader.uchMsgTypSpecific[0],
															pmsg->stHeader.uchMsgTypSpecific[1],
															pmsg->stHeader.uchMsgTypSpecific[2],
															pmsg->stHeader.uchMsgTypSpecific[3] );
											nIndex += sizeof(pmsg->stHeader.uchMsgTypSpecific);
	printf( " %04d + stSrcPortIdentity.stClockIdentity = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n", nIndex ,
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[0],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[1],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[2],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[3],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[4],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[5],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[6],
															pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId[7] );
											nIndex += sizeof(pmsg->stHeader.stSrcPortIdentity.stClockIdentity.uchId);
	printf( " %04d + stSrcPortIdentity.usPortNumber    = 0x%04x, \n",nIndex ,pmsg->stHeader.stSrcPortIdentity.usPortNumber );
															nIndex += sizeof(pmsg->stHeader.stSrcPortIdentity.usPortNumber );
	printf( " %04d + usSequenceId                      = 0x%04x, \n",nIndex ,pmsg->stHeader.usSequenceId );
															nIndex += sizeof(pmsg->stHeader.usSequenceId );
	printf( " %04d + uchControl                        = 0x%02x, \n",nIndex ,pmsg->stHeader.uchControl );
															nIndex += sizeof(pmsg->stHeader.uchControl );
	printf( " %04d + chLogMsgInterVal                  = 0x%02x, \n",nIndex ,pmsg->stHeader.chLogMsgInterVal );
															nIndex += sizeof(pmsg->stHeader.chLogMsgInterVal );
	*pnIndex = nIndex;
}

VOID Display_PtpMsgSync2_AS( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_SYNC_TWO_STEP_1AS*	pmsg = (PTPMSG_SYNC_TWO_STEP_1AS*)pvMsg;

	printf( " [Display SYNC Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + uchReserved                             = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n", nIndex,
							pmsg->uchReserved[0],
							pmsg->uchReserved[1],
							pmsg->uchReserved[2],
							pmsg->uchReserved[3],
							pmsg->uchReserved[4],
							pmsg->uchReserved[5],
							pmsg->uchReserved[6],
							pmsg->uchReserved[7],
							pmsg->uchReserved[8],
							pmsg->uchReserved[9] );
			nIndex += sizeof(pmsg->uchReserved );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgFollowUpTLV_AS( INT *pnIndex, PTPMSG_FOLLOWUP_TLV* pmsg )
{
	INT	nIndex = *pnIndex;
	printf( " [Display FollowUp TLV] \n" );
	printf( " %04d +  usTLVType                              = 0x%04x, \n", nIndex, pmsg->usTLVType );
																   nIndex += sizeof(pmsg->usTLVType );
	printf( " %04d +  usLengthField                          = 0x%04x(%03d), \n", nIndex, pmsg->usLengthField, pmsg->usLengthField );
																		 nIndex += sizeof(pmsg->usLengthField );
	printf( " %04d +  uchOrgnzationID                        = 0x%02x 0x%02x 0x%02x, \n", nIndex,
							pmsg->uchOrgnzationID[0],
							pmsg->uchOrgnzationID[1],
							pmsg->uchOrgnzationID[2] );
			nIndex += sizeof(pmsg->uchOrgnzationID );
	printf( " %04d +  uchOrgnzationSubType                   = 0x%02x 0x%02x 0x%02x, \n", nIndex,
							pmsg->uchOrgnzationSubType[0],
							pmsg->uchOrgnzationSubType[1],
							pmsg->uchOrgnzationSubType[2] );
			nIndex += sizeof(pmsg->uchOrgnzationSubType );
	printf( " %04d +  lCmltvScaledRateOffset                 = 0x%08x, \n", nIndex, pmsg->lCmltvScaledRateOffset );
																   nIndex += sizeof(pmsg->lCmltvScaledRateOffset );
	printf( " %04d +  usGMTmBaseIndicator                    = 0x%04x, \n", nIndex, pmsg->usGMTmBaseIndicator );
																   nIndex += sizeof(pmsg->usGMTmBaseIndicator );
	printf( " %04d +  stLstGMPhsChange.sNsec_msb             = 0x%04x, \n", nIndex, pmsg->stLstGMPhsChange.sNsec_msb );
																   nIndex += sizeof(pmsg->stLstGMPhsChange.sNsec_msb );
	printf( " %04d +                  .ulNsec_2nd            = 0x%08x, \n", nIndex, pmsg->stLstGMPhsChange.ulNsec_2nd );
																   nIndex += sizeof(pmsg->stLstGMPhsChange.ulNsec_2nd );
	printf( " %04d +                  .ulNsec_lsb            = 0x%08x, \n", nIndex, pmsg->stLstGMPhsChange.ulNsec_lsb );
																   nIndex += sizeof(pmsg->stLstGMPhsChange.ulNsec_lsb );
	printf( " %04d +                  .usFrcNsec             = 0x%04x, \n", nIndex, pmsg->stLstGMPhsChange.usFrcNsec );
																   nIndex += sizeof(pmsg->stLstGMPhsChange.usFrcNsec );
	printf( " %04d +  lScaledLstGMFrqChange                  = 0x%08x, \n", nIndex, pmsg->lScaledLstGMFrqChange );
																   nIndex += sizeof(pmsg->lScaledLstGMFrqChange );
	*pnIndex = nIndex;
}

VOID Display_PtpMsgSync1_AS( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_SYNC_ONE_STEP_1AS*	pmsg = (PTPMSG_SYNC_ONE_STEP_1AS*)pvMsg;

	printf( " [Display SYNC Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stOriginTimestamp.stSeconds.usSec_msb   = 0x%04x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                  .stSeconds.ulSec_lsb   = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                  .ulNanoseconds         = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stOriginTimestamp.ulNanoseconds );
	Display_PtpMsgFollowUpTLV_AS( &nIndex, &pmsg->stFollowUP_TLV );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgFollowUp_AS( VOID* pvMsg)
{
	INT	nIndex = 0;
	PTPMSG_FOLLOWUP_1AS*	pmsg = (PTPMSG_FOLLOWUP_1AS*)pvMsg;

	printf( " [Display FOLLOWUP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stPrcsOrgnTimestamp.stSeconds.usSec_msb = 0x%04x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                    .stSeconds.ulSec_lsb = 0x%08x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                    .ulNanoseconds       = 0x%08x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.ulNanoseconds );
	Display_PtpMsgFollowUpTLV_AS( &nIndex, &pmsg->stFollowUP_TLV );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPdlyReq_AS( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDELAY_REQ_1AS*	pmsg = (PTPMSG_PDELAY_REQ_1AS*)pvMsg;

	printf( " [Display PDELAY REQ Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + uchReserved1                            = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n",nIndex,
							pmsg->uchReserved1[0],
							pmsg->uchReserved1[1],
							pmsg->uchReserved1[2],
							pmsg->uchReserved1[3],
							pmsg->uchReserved1[4],
							pmsg->uchReserved1[5],
							pmsg->uchReserved1[6],
							pmsg->uchReserved1[7],
							pmsg->uchReserved1[8],
							pmsg->uchReserved1[9] );
			nIndex += sizeof(pmsg->uchReserved1 );

	printf( " %04d + uchReserved2                            = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n",nIndex,
							pmsg->uchReserved2[0],
							pmsg->uchReserved2[1],
							pmsg->uchReserved2[2],
							pmsg->uchReserved2[3],
							pmsg->uchReserved2[4],
							pmsg->uchReserved2[5],
							pmsg->uchReserved2[6],
							pmsg->uchReserved2[7],
							pmsg->uchReserved2[8],
							pmsg->uchReserved2[9] );
			nIndex += sizeof(pmsg->uchReserved2 );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPdlyResp_AS( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDELAY_RESP_1AS*	pmsg = (PTPMSG_PDELAY_RESP_1AS*)pvMsg;

	printf( " [Display PDELAY RESP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stReqRcptTimestamp.stSeconds.usSec_msb  = 0x%04x, \n",nIndex, pmsg->stReqRcptTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                   .stSeconds.ulSec_lsb  = 0x%08x, \n",nIndex, pmsg->stReqRcptTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                   .ulNanoseconds        = 0x%08x, \n",nIndex, pmsg->stReqRcptTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.ulNanoseconds );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stReqPortIdentity.stClockIdentity.uchId[0],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[1],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[2],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[3],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[4],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[5],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[6],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stReqPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stReqPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stReqPortIdentity.usPortNumber );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPDRespFlwUp_AS( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDRESP_FOLLOWUP_1AS*	pmsg = (PTPMSG_PDRESP_FOLLOWUP_1AS*)pvMsg;

	printf( " [Display PDELAY RESP FollowUP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stRespOrgnTimestamp.stSeconds.usSec_msb = 0x%04x, \n",nIndex, pmsg->stRespOrgnTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                    .stSeconds.ulSec_lsb = 0x%08x, \n",nIndex, pmsg->stRespOrgnTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                    .ulNanoseconds       = 0x%08x, \n",nIndex, pmsg->stRespOrgnTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.ulNanoseconds );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stReqPortIdentity.stClockIdentity.uchId[0],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[1],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[2],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[3],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[4],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[5],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[6],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stReqPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stReqPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stReqPortIdentity.usPortNumber );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgSync_1588( VOID* pvMsg)
{
	INT	nIndex = 0;
	PTPMSG_SYNC_1588*	pmsg = (PTPMSG_SYNC_1588*)pvMsg;

	printf( " [Display SYNC Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + SstOriginTimestamp.stSeconds.usSec_msb  = 0x%04x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                   .stSeconds.ulSec_lsb  = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                   .ulNanoseconds        = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stOriginTimestamp.ulNanoseconds );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgFollowUp_1588( VOID* pvMsg)
{
	INT	nIndex = 0;
	PTPMSG_FOLLOWUP_1588*	pmsg = (PTPMSG_FOLLOWUP_1588*)pvMsg;

	printf( " [Display FOLLOW UP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stPrcsOrgnTimestamp.stSeconds.usSec_msb = 0x%04x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                    .stSeconds.ulSec_lsb = 0x%08x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                    .ulNanoseconds       = 0x%08x, \n",nIndex, pmsg->stPrcsOrgnTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stPrcsOrgnTimestamp.ulNanoseconds );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgDlyReq_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_DELAY_REQ_1588*	pmsg = (PTPMSG_DELAY_REQ_1588*)pvMsg;

	printf( " [Display DELAY REQ Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stOriginTimestamp.stSeconds.usSec_msb   = 0x%04x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                  .stSeconds.ulSec_lsb   = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                  .ulNanoseconds         = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stOriginTimestamp.ulNanoseconds );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgDlyResp_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_DELAY_RESP_1588*	pmsg = (PTPMSG_DELAY_RESP_1588*)pvMsg;

	printf( " [Display DELAY RESP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stRcvTimestamp.stSeconds.usSec_msb      = 0x%04x, \n",nIndex, pmsg->stRcvTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stRcvTimestamp.stSeconds.usSec_msb );
	printf( " %04d +               .stSeconds.ulSec_lsb      = 0x%08x, \n",nIndex, pmsg->stRcvTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stRcvTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +               .ulNanoseconds            = 0x%08x, \n",nIndex, pmsg->stRcvTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stRcvTimestamp.ulNanoseconds );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stReqPortIdentity.stClockIdentity.uchId[0],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[1],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[2],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[3],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[4],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[5],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[6],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stReqPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stReqPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stReqPortIdentity.usPortNumber );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPdlyReq_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDELAY_REQ_1588*	pmsg = (PTPMSG_PDELAY_REQ_1588*)pvMsg;

	printf( " [Display PDELAY REQ Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stOriginTimestamp.stSeconds.usSec_msb   = 0x%04x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                  .stSeconds.ulSec_lsb   = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stOriginTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                  .ulNanoseconds         = 0x%08x, \n",nIndex, pmsg->stOriginTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stOriginTimestamp.ulNanoseconds );
	printf( " %04d + uchReserved                             = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x \n",nIndex,
							pmsg->uchReserved[0],
							pmsg->uchReserved[1],
							pmsg->uchReserved[2],
							pmsg->uchReserved[3],
							pmsg->uchReserved[4],
							pmsg->uchReserved[5],
							pmsg->uchReserved[6],
							pmsg->uchReserved[7],
							pmsg->uchReserved[8],
							pmsg->uchReserved[9] );
			nIndex += sizeof(pmsg->uchReserved );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPdlyResp_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDELAY_RESP_1588*	pmsg = (PTPMSG_PDELAY_RESP_1588*)pvMsg;

	printf( " [Display PDELAY RESP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stReqRcptTimestamp.stSeconds.usSec_msb  = 0x%04x, \n",nIndex, pmsg->stReqRcptTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                   .stSeconds.ulSec_lsb  = 0x%08x, \n",nIndex, pmsg->stReqRcptTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                   .ulNanoseconds        = 0x%08x, \n",nIndex, pmsg->stReqRcptTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stReqRcptTimestamp.ulNanoseconds );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stReqPortIdentity.stClockIdentity.uchId[0],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[1],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[2],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[3],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[4],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[5],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[6],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stReqPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stReqPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stReqPortIdentity.usPortNumber );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgPDRespFlwUp_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_PDRESP_FOLLOWUP_1588*	pmsg = (PTPMSG_PDRESP_FOLLOWUP_1588*)pvMsg;

	printf( " [Display PDELAY RESP FOLLOWUP Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stRespOrgnTimestamp.stSeconds.usSec_msb = 0x%04x, \n",nIndex, pmsg->stRespOrgnTimestamp.stSeconds.usSec_msb );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.stSeconds.usSec_msb );
	printf( " %04d +                    .stSeconds.ulSec_lsb = 0x%08x, \n",nIndex, pmsg->stRespOrgnTimestamp.stSeconds.ulSec_lsb );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.stSeconds.ulSec_lsb );
	printf( " %04d +                    .ulNanoseconds       = 0x%08x, \n",nIndex, pmsg->stRespOrgnTimestamp.ulNanoseconds );
																  nIndex += sizeof(pmsg->stRespOrgnTimestamp.ulNanoseconds );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stReqPortIdentity.stClockIdentity.uchId[0],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[1],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[2],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[3],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[4],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[5],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[6],
							pmsg->stReqPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stReqPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stReqPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stReqPortIdentity.usPortNumber );
	printf( " %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMsgManagement_1588( VOID* pvMsg )
{
	INT	nIndex = 0;
	PTPMSG_MANAGEMENT_1588*	pmsg = (PTPMSG_MANAGEMENT_1588*)pvMsg;
	PTPMSG_MANAGEMENT_TLV*			tlv;
	PTPMSG_MANAGEMENT_ERRSTA_TLV*	errtlv;

	printf( " [Display Management Message ] \n" );
	Display_PtpMsgHeader( &nIndex, pvMsg );

	printf( " [BODY] \n" );
	printf( " %04d + stReqPortIdentity.stClockIdentity       = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[0],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[1],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[2],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[3],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[4],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[5],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[6],
							pmsg->stTargetPortIdentity.stClockIdentity.uchId[7] );
			nIndex += sizeof(pmsg->stTargetPortIdentity.stClockIdentity.uchId );
	printf( " %04d + stReqPortIdentity.usPortNumber          = 0x%04x, \n",nIndex, pmsg->stTargetPortIdentity.usPortNumber );
																  nIndex += sizeof(pmsg->stTargetPortIdentity.usPortNumber );
	printf( " %04d + uchStartBoundaryHops                    = 0x%02x, \n",nIndex, pmsg->uchStartBoundaryHops );
																  nIndex += sizeof(pmsg->uchStartBoundaryHops );
	printf( " %04d + uchBoundaryHops                         = 0x%02x, \n",nIndex, pmsg->uchBoundaryHops );
																  nIndex += sizeof(pmsg->uchBoundaryHops );
	printf( " %04d + stActionField                           = 0x%01x, \n",nIndex, pmsg->byActionField );
																  nIndex += sizeof(pmsg->byActionField );

	printf( " %04d + uchReserved                             = 0x%02x, \n",nIndex, pmsg->uchReserved );
																  nIndex += sizeof(pmsg->uchReserved );

	tlv		= (PTPMSG_MANAGEMENT_TLV*)&pmsg->stManagemant_TLV;
	errtlv	= (PTPMSG_MANAGEMENT_ERRSTA_TLV*)&pmsg->stManagemant_TLV;
	if (tlv->usTLVType==1)
	{
		printf( " [Display Management-TLV] \n" );
		printf( " %04d + usTLVType                    = 0x%04x, \n",nIndex, tlv->usTLVType );
														   nIndex += sizeof(tlv->usTLVType );
		printf( " %04d + usLengthField                = 0x%04x,(%03d) \n",nIndex, tlv->usLengthField, tlv->usLengthField );
														   nIndex += sizeof(tlv->usLengthField );
		printf( " %04d + usManagementId               = 0x%04x, \n",nIndex, tlv->usManagementId );
														   nIndex += sizeof(tlv->usManagementId );
		printf( " %04d + ----- Message \n",	nIndex );
		if (tlv->usLengthField > PTPM_MGTTVL_LENGTH_FIXMIN)
		{
			Display_PtpMsgMgtDataField_1588(tlv);
		}
	}
	else
	{
		printf( " [Display Management-TLV] \n" );
		printf( " %04d + usTLVType                    = 0x%04x, \n",nIndex, errtlv->usTLVType );
														   nIndex += sizeof(errtlv->usTLVType );
		printf( " %04d + usLengthField                = 0x%04x,(%03d) \n",nIndex, errtlv->usLengthField, errtlv->usLengthField );
														   nIndex += sizeof(errtlv->usLengthField );
		printf( " %04d + usManagementErrorId          = 0x%04x, \n",nIndex, errtlv->usManagementErrorId );
														   nIndex += sizeof(errtlv->usManagementErrorId );
		printf( " %04d + usManagementId               = 0x%04x, \n",nIndex, errtlv->usManagementId );
														   nIndex += sizeof(errtlv->usManagementId );
		printf( " %04d + ----- Message \n",	nIndex );
	}
}

VOID Display_PtpMsgMgtDataField_1588( PTPMSG_MANAGEMENT_TLV* pTlvDt)
{
	switch(pTlvDt->usManagementId)
	{
	case PTPM_MGT_NULL_MANAGEMENT			:
		Display_PtpMgt_NullManagement(&pTlvDt->stDataField);
		break;
	case PTPM_MGT_CLOCK_DESCRIPTION			:
		Display_PtpMgt_ClockDescription(&pTlvDt->stDataField);
		break;
	case PTPM_MGT_USER_DESCRIPTION			:
		Display_PtpMgt_UserDescription(&pTlvDt->stDataField);
		break;
	case PTPM_MGT_INITIALIZE				:
		Display_PtpMgt_Initialize(&pTlvDt->stDataField);
		break;
	case PTPM_MGT_FAULT_LOG					:
		Display_PtpMgt_FaultLog(&pTlvDt->stDataField);
		break;
	case PTPM_MGT_FAULT_LOG_RESET			:
		Display_PtpMgt_FaultLogReset(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_DEFAULT_DATA_SET		:
		Display_PtpMgt_DefaultDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_CURRENT_DATA_SET		:
		Display_PtpMgt_CurrentDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PARENT_DATA_SET		:
		Display_PtpMgt_ParentDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TIME_PROPERT_DATA_SET	:
		Display_PtpMgt_TimePropertiesDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PORT_DATA_SET			:
		Display_PtpMgt_PortDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PRIORITY1				:
		Display_PtpMgt_Priority1(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PRIORITY2				:
		Display_PtpMgt_Priority2(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_DOMAIN					:
		Display_PtpMgt_Domain(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_SLAVE_ONLY				:
		Display_PtpMgt_SlaveOnly(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_LOG_ANNOUNCE_INTERVAL	:
		Display_PtpMgt_LogannounceInterval(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_ANNOUNCE_RECEIPT_TMOUT	:
		Display_PtpMgt_AnnounceReceiptTimeOut(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_LOG_SYNC_INTERVAL		:
		Display_PtpMgt_LogSyncInterval(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_VERSION_NUMBER			:
		Display_PtpMgt_VersionNumber(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_ENABLE_PORT			:
		Display_PtpMgt_EnablePort(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_DISABLE_PORT			:
		Display_PtpMgt_DisablePort(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TIME					:
		Display_PtpMgt_Time(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_CLOCK_ACCURACY			:
		Display_PtpMgt_ClockAccuracy(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_UTC_PROPERTIES			:
		Display_PtpMgt_UTCProperties(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TRACEABILITY_PROPERT	:
		Display_PtpMgt_TracebilityProperties(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TIMESCALE_PROPERTIES	:
		Display_PtpMgt_TimescaleProperties(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_UNICAST_NEGOTI_ENABLE	:
		Display_PtpMgt_UnicastNegotiationEnable(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PATH_TRACE_LIST		:
		Display_PtpMgt_PathTraceList(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PATH_TRACE_ENABLE		:
		Display_PtpMgt_PathTraceEnable(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_GM_CLUSTER_TBL			:
		Display_PtpMgt_GrandmasterClusterTable(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_UNICAST_MSTR_TBL		:
		Display_PtpMgt_UnicastMasterTable(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_UNICAST_MSTR_MAX_TBLSZ	:
		Display_PtpMgt_UnicastMasterMaxTableSize(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PORT_STAT_COUNT		:
		Display_PtpMgt_PortStatisticsCount(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_CMLD_PORT_STAT_COUNT	:
		Display_PtpMgt_CMLDPortStatisticsCount(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PORT_STAT_ERRCOUNT		:
		Display_PtpMgt_PortStatisticsErrorCount(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TCLK_DEFAULT_DATA_SET	:
		Display_PtpMgt_TransparentClockDefaultDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_TCLK_PORT_DATA_SET		:
		Display_PtpMgt_TransparentClockPortDataSet(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_PRIMARY_DOMAIN			:
		Display_PtpMgt_PrimaryDomain(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_DELAY_MECHANISM		:
		Display_PtpMgt_DelayMechanism(&pTlvDt->stDataField);
		break;
	case	PTPM_MGT_LOG_MIN_PDREQ_INTERVAL	:
		Display_PtpMgt_LogMinPdelayReqInterval(&pTlvDt->stDataField);
		break;
	default:
		Display_PtpMgt_NullManagement(&pTlvDt->stDataField);
		break;
	}
}

VOID Display_PtpMgt_NullManagement(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  NULL_MANAGEMENT\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_ClockDescription(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  CLOCK_DESCRIPTION\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_UserDescription(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  USER_DESCRIPTION\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_Initialize(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  INITIALIZE\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_FaultLog(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  FAULT_LOG\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_FaultLogReset(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  FAULT_LOG_RESET\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_DefaultDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_DEFAULT_DATA_SET* dt = (MGT_DEFAULT_DATA_SET*)&pTlvDt->stDefaultDS;

	printf("<<<  DEFAULT_DATA_SET\n");
	printf(" [Display ManagementID-DataField] \n" );
	printf(" %04d + stDefaultDS.stFlags             = 0x%02x \n",nIndex,	dt->byFlags);			nIndex += sizeof(dt->byFlags);
	printf(" **< TSC:0/SO:1/x:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stDefaultDS.stFlags.byBit0      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stDefaultDS.stFlags.byBit1      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stDefaultDS.stFlags.byBit2      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stDefaultDS.stFlags.byBit3      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stDefaultDS.stFlags.byBit4      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stDefaultDS.stFlags.byBit5      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stDefaultDS.stFlags.byBit6      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stDefaultDS.stFlags.byBit7      = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stDefaultDS.uchReserved1        = 0x%02x \n",nIndex,	dt->uchReserved1);	nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + stDefaultDS.usNumPorts          = 0x%02x \n",nIndex,	dt->usNumPorts);	nIndex += sizeof(dt->usNumPorts);
	printf(" %04d + stDefaultDS.uchPriority1        = 0x%02x \n",nIndex,	dt->uchPriority1);	nIndex += sizeof(dt->uchPriority1);
	printf(" %04d + stDefaultDS.stClockQuality.uchClockClass             = 0x%02x \n",nIndex,	dt->stClockQuality.uchClockClass);				nIndex += sizeof(dt->stClockQuality.uchClockClass);
	printf(" %04d + stDefaultDS.stClockQuality.uchClockAccuracy          = 0x%02x \n",nIndex,	dt->stClockQuality.uchClockAccuracy);			nIndex += sizeof(dt->stClockQuality.uchClockAccuracy);
	printf(" %04d + stDefaultDS.stClockQuality.usOffsetScaledLogVariance = 0x%02x \n",nIndex,	dt->stClockQuality.usOffsetScaledLogVariance);	nIndex += sizeof(dt->stClockQuality.usOffsetScaledLogVariance);
	printf(" %04d + stDefaultDS.uchPriority2        = 0x%02x \n",nIndex,	dt->uchPriority2);	nIndex += sizeof(dt->uchPriority2);
	printf(" %04d + stDefaultDS.stClockIdentity     = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stClockIdentity.uchId[0],
							dt->stClockIdentity.uchId[1],
							dt->stClockIdentity.uchId[2],
							dt->stClockIdentity.uchId[3],
							dt->stClockIdentity.uchId[4],
							dt->stClockIdentity.uchId[5],
							dt->stClockIdentity.uchId[6],
							dt->stClockIdentity.uchId[7]);									nIndex += sizeof(dt->stClockIdentity.uchId);
	printf(" %04d + stDefaultDS.uchDomainNum        = 0x%02x \n",nIndex,	dt->uchDomainNum);	nIndex += sizeof(dt->uchDomainNum);
	printf(" %04d + stDefaultDS.uchReserved2        = 0x%02x \n",nIndex,	dt->uchReserved2);	nIndex += sizeof(dt->uchReserved2);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_CurrentDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_CURRENT_DATA_SET* dt = (MGT_CURRENT_DATA_SET*)&pTlvDt->stCurrentDS;

	printf("<<<  CURRENT_DATA_SET\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stCurrentDS.usStepsRemoved  = 0x%04x \n",nIndex,	dt->usStepsRemoved);		nIndex += sizeof(dt->usStepsRemoved);
	printf(" %04d + stCurrentDS.stOffsetFromMaster.sNsec_msb  = 0x%04x, \n",	nIndex , dt->stOffsetFromMaster.sNsec_msb );		nIndex += sizeof(dt->stOffsetFromMaster.sNsec_msb);
	printf(" %04d +                               .ulNsec_lsb = 0x%08x, \n",	nIndex , dt->stOffsetFromMaster.ulNsec_lsb );	nIndex += sizeof(dt->stOffsetFromMaster.ulNsec_lsb);
	printf(" %04d +                               .usFrcNsec  = 0x%04x, \n",	nIndex , dt->stOffsetFromMaster.usFrcNsec );		nIndex += sizeof(dt->stOffsetFromMaster.usFrcNsec);
	printf(" %04d + stCurrentDS.stMeanPathDelay.sNsec_msb     = 0x%04x, \n",	nIndex , dt->stMeanPathDelay.sNsec_msb );		nIndex += sizeof(dt->stMeanPathDelay.sNsec_msb);
	printf(" %04d +                            .ulNsec_lsb    = 0x%08x, \n",	nIndex , dt->stMeanPathDelay.ulNsec_lsb );		nIndex += sizeof(dt->stMeanPathDelay.ulNsec_lsb);
	printf(" %04d +                            .usFrcNsec     = 0x%04x, \n",	nIndex , dt->stMeanPathDelay.usFrcNsec );		nIndex += sizeof(dt->stMeanPathDelay.usFrcNsec);

	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_ParentDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PARENT_DATA_SET* dt = (MGT_PARENT_DATA_SET*)&pTlvDt->stParentDS;

	printf("<<<  PARENT_DATA_SET\n");
	printf(" [Display ManagementID-DataField] \n" );

	printf(" %04d + stParentDS.stPrntPortIdentity.stClockIdentity  = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stPrntPortIdentity.stClockIdentity.uchId[0],
							dt->stPrntPortIdentity.stClockIdentity.uchId[1],
							dt->stPrntPortIdentity.stClockIdentity.uchId[2],
							dt->stPrntPortIdentity.stClockIdentity.uchId[3],
							dt->stPrntPortIdentity.stClockIdentity.uchId[4],
							dt->stPrntPortIdentity.stClockIdentity.uchId[5],
							dt->stPrntPortIdentity.stClockIdentity.uchId[6],
							dt->stPrntPortIdentity.stClockIdentity.uchId[7]);	nIndex += sizeof(dt->stPrntPortIdentity.stClockIdentity.uchId);
	printf(" %04d +                              .usPortNumber     = 0x%04x, \n",nIndex, dt->stPrntPortIdentity.usPortNumber );	nIndex += sizeof(dt->stPrntPortIdentity.usPortNumber);
	printf(" %04d + stParentDS.stFlags                    = 0x%02x, \n",	nIndex , dt->byFlags );						nIndex += sizeof(dt->byFlags);
	printf(" **< PS:0/x:1/x:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stParentDS.stFlags.byBit0             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stParentDS.stFlags.byBit1             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stParentDS.stFlags.byBit2             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stParentDS.stFlags.byBit3             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stParentDS.stFlags.byBit4             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stParentDS.stFlags.byBit5             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stParentDS.stFlags.byBit6             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stParentDS.stFlags.byBit7             = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stParentDS.uchReserved1               = 0x%02x, \n",	nIndex , dt->uchReserved1 );					nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + stParentDS.usObsPrentOfsetScalLogVrnc = 0x%04x, \n",	nIndex , dt->usObsPrentOfsetScalLogVrnc );	nIndex += sizeof(dt->usObsPrentOfsetScalLogVrnc);
	printf(" %04d + stParentDS.lObsPrentClockPhsChngRate  = 0x%08x, \n",	nIndex , dt->lObsPrentClockPhsChngRate );	nIndex += sizeof(dt->lObsPrentClockPhsChngRate);
	printf(" %04d + stParentDS.uchGMasterPriority1        = 0x%02x, \n",	nIndex , dt->uchGMasterPriority1 );			nIndex += sizeof(dt->uchGMasterPriority1);
	printf(" %04d + stParentDS.stGMasterClockQuality.uchClockClass             = 0x%02x \n",nIndex,	dt->stGMasterClockQuality.uchClockClass);				nIndex += sizeof(dt->stGMasterClockQuality.uchClockClass);
	printf(" %04d + stParentDS.stGMasterClockQuality.uchClockAccuracy          = 0x%02x \n",nIndex,	dt->stGMasterClockQuality.uchClockAccuracy);			nIndex += sizeof(dt->stGMasterClockQuality.uchClockAccuracy);
	printf(" %04d + stParentDS.stGMasterClockQuality.usOffsetScaledLogVariance = 0x%02x \n",nIndex,	dt->stGMasterClockQuality.usOffsetScaledLogVariance);	nIndex += sizeof(dt->stGMasterClockQuality.usOffsetScaledLogVariance);
	printf(" %04d + stParentDS.uchGMasterPriority2        = 0x%02x, \n",	nIndex , dt->uchGMasterPriority2 );			nIndex += sizeof(dt->uchGMasterPriority2);
	printf(" %04d + stParentDS.stGMasterIdentity.stClockIdentity  = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stGMasterIdentity.uchId[0],
							dt->stGMasterIdentity.uchId[1],
							dt->stGMasterIdentity.uchId[2],
							dt->stGMasterIdentity.uchId[3],
							dt->stGMasterIdentity.uchId[4],
							dt->stGMasterIdentity.uchId[5],
							dt->stGMasterIdentity.uchId[6],
							dt->stGMasterIdentity.uchId[7]);	nIndex += sizeof(dt->stGMasterIdentity.uchId);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_TimePropertiesDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TIME_PROPERTIES_DATA_SET* dt = (MGT_TIME_PROPERTIES_DATA_SET*)&pTlvDt->stParentDS;

	printf("<<<  TIME_PROPERTIES_DATA_SET\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stTimePropertiesDS.sCrentUtcOffset = 0x%02x, \n",	nIndex , dt->sCrentUtcOffset );		nIndex += sizeof(dt->sCrentUtcOffset);

	printf(" %04d + stTimePropertiesDS.stFlags         = 0x%02x, \n",	nIndex , dt->byFlags );				nIndex += sizeof(dt->byFlags);
	printf(" **< LI-61:0/LI-59:1/UTCV:2/PTP:3/TTRA:4/FTRA:5/x:6/x:7 \n");
	printf(" %04d + stTimePropertiesDS.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stTimePropertiesDS.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );


	printf(" %04d + stParentDS.uchTimeSource           = 0x%02x, \n",	nIndex , dt->uchTimeSource );		nIndex += sizeof(dt->uchTimeSource);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_PortDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PORT_DATA_SET* dt = (MGT_PORT_DATA_SET*)&pTlvDt->stParentDS;

	printf("<<<  PORT_DATA_SET\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPortDS.stPortIdentity.stClockIdentity  = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stPortIdentity.stClockIdentity.uchId[0],
							dt->stPortIdentity.stClockIdentity.uchId[1],
							dt->stPortIdentity.stClockIdentity.uchId[2],
							dt->stPortIdentity.stClockIdentity.uchId[3],
							dt->stPortIdentity.stClockIdentity.uchId[4],
							dt->stPortIdentity.stClockIdentity.uchId[5],
							dt->stPortIdentity.stClockIdentity.uchId[6],
							dt->stPortIdentity.stClockIdentity.uchId[7]);	nIndex += sizeof(dt->stPortIdentity.stClockIdentity.uchId);
	printf(" %04d +                        .usPortNumber     = 0x%04x, \n",nIndex, dt->stPortIdentity.usPortNumber );	nIndex += sizeof(dt->stPortIdentity.usPortNumber);
	printf(" %04d + stPortDS.uchPortState           = 0x%02x, \n",	nIndex , dt->uchPortState );				nIndex += sizeof(dt->uchPortState);
	printf(" %04d + stPortDS.chLogMinDReqInterval   = 0x%02x, \n",	nIndex , dt->chLogMinDReqInterval );		nIndex += sizeof(dt->chLogMinDReqInterval);
	printf(" %04d + stPortDS.stPerMeanPathDelay.sNsec_msb     = 0x%04x, \n",	nIndex , dt->stPerMeanPathDelay.sNsec_msb );		nIndex += sizeof(dt->stPerMeanPathDelay.sNsec_msb);
	printf(" %04d +                            .ulNsec_lsb    = 0x%08x, \n",	nIndex , dt->stPerMeanPathDelay.ulNsec_lsb );	nIndex += sizeof(dt->stPerMeanPathDelay.ulNsec_lsb);
	printf(" %04d +                            .usFrcNsec     = 0x%04x, \n",	nIndex , dt->stPerMeanPathDelay.usFrcNsec );		nIndex += sizeof(dt->stPerMeanPathDelay.usFrcNsec);
	printf(" %04d + stPortDS.chLogAnounceInterval   = 0x%02x, \n",	nIndex , dt->chLogAnounceInterval );		nIndex += sizeof(dt->chLogAnounceInterval);
	printf(" %04d + stPortDS.uchAnounceRcptTimeout  = 0x%02x, \n",	nIndex , dt->uchAnounceRcptTimeout );	nIndex += sizeof(dt->uchAnounceRcptTimeout);
	printf(" %04d + stPortDS.chLogSyncInterval      = 0x%02x, \n",	nIndex , dt->chLogSyncInterval );		nIndex += sizeof(dt->chLogSyncInterval);
	printf(" %04d + stPortDS.uchDelayMechanism      = 0x%02x, \n",	nIndex , dt->uchDelayMechanism );		nIndex += sizeof(dt->uchDelayMechanism);
	printf(" %04d + stPortDS.chLogMinPDReqInterval  = 0x%02x, \n",	nIndex , dt->chLogMinPDReqInterval );	nIndex += sizeof(dt->chLogMinPDReqInterval);
	printf(" %04d + stPortDS.byVerNum               = 0x%02x, \n",	nIndex , dt->byVerNum );					nIndex += sizeof(dt->byVerNum);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_Priority1(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PRIORITY1* dt = (MGT_PRIORITY1*)&pTlvDt->stPriority1;

	printf("<<<  PRIORITY1\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPriority1.uchPriority1  = 0x%02x \n",nIndex,	dt->uchPriority1);		nIndex += sizeof(dt->uchPriority1);
	printf(" %04d + stPriority1.uchReserved1  = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_Priority2(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PRIORITY2* dt = (MGT_PRIORITY2*)&pTlvDt->stPriority2;

	printf("<<<  PRIORITY2\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPriority2.uchPriority2  = 0x%02x \n",nIndex,	dt->uchPriority2);		nIndex += sizeof(dt->uchPriority2);
	printf(" %04d + stPriority2.uchReserved1  = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_Domain(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_DOMAIN* dt = (MGT_DOMAIN*)&pTlvDt->stDomain;

	printf("<<<  DOMAIN\n");
	printf( " [Display ManagementID-DataField] \n" );
	printf(" %04d + stDomain.uchDomainNum  = 0x%02x \n",nIndex,	dt->uchDomainNum);		nIndex += sizeof(dt->uchDomainNum);
	printf(" %04d + stDomain.uchReserved1  = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_SlaveOnly(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_SLAVE_ONLY* dt = (MGT_SLAVE_ONLY*)&pTlvDt->stSlaveOnly;

	printf("<<<  SLAVE_ONLY\n");
	printf( " [Display ManagementID-DataField] \n" );
	printf(" %04d + stSlaveOnly.stFlags         = 0x%02x, \n",	nIndex , dt->byFlags );		nIndex += sizeof(dt->byFlags);
	printf(" **< SO:0/x:1/x:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stSlaveOnly.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stSlaveOnly.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stSlaveOnly.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stSlaveOnly.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stSlaveOnly.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stSlaveOnly.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stSlaveOnly.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stSlaveOnly.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stSlaveOnly.uchReserved1    = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_LogannounceInterval(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_LOG_ANNOUNCE_INTERVAL* dt = (MGT_LOG_ANNOUNCE_INTERVAL*)&pTlvDt->stLogAnnounceIntv;

	printf("<<<  LOG_ANNOUNCE_INTERVAL\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stLogAnnounceIntv.chLogAnounceInterval  = 0x%02x \n",nIndex,	dt->chLogAnounceInterval);		nIndex += sizeof(dt->chLogAnounceInterval);
	printf(" %04d + stLogAnnounceIntv.uchReserved1          = 0x%02x \n",nIndex,	dt->uchReserved1);				nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_AnnounceReceiptTimeOut(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT* dt = (MGT_ANNOUNCE_RECEIPT_TIMEOUT*)&pTlvDt->stAnnounceReceiptTout;

	printf("<<<  ANNOUNCE_RECEIPT_TIMEOUT\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stAnnounceReceiptTout.uchAnounceRcptTimeout  = 0x%02x \n",nIndex,	dt->uchAnounceRcptTimeout);		nIndex += sizeof(dt->uchAnounceRcptTimeout);
	printf(" %04d + stAnnounceReceiptTout.uchReserved1           = 0x%02x \n",nIndex,	dt->uchReserved1);				nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_LogSyncInterval(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_LOG_SYNC_INTERVAL* dt = (MGT_LOG_SYNC_INTERVAL*)&pTlvDt->stLogSyncInterval;

	printf("<<<  LOG_SYNC_INTERVAL\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stLogSyncInterval.chLogSyncInterval  = 0x%02x \n",nIndex,	dt->chLogSyncInterval);		nIndex += sizeof(dt->chLogSyncInterval);
	printf(" %04d + stLogSyncInterval.uchReserved1       = 0x%02x \n",nIndex,	dt->uchReserved1);			nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_VersionNumber(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_VERSION_NUMBER* dt = (MGT_VERSION_NUMBER*)&pTlvDt->stVersionNum;

	printf("<<<  VERSION_NUMBER\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stVersionNum.byVerNum     = 0x%02x \n",nIndex,	dt->byVerNum);		nIndex += sizeof(dt->byVerNum);
	printf(" %04d + stVersionNum.uchReserved1 = 0x%02x \n",nIndex,	dt->uchReserved1);	nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_EnablePort(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  ENABLE_PORT\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_DisablePort(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  DISABLE_PORT\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_Time(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TIME* dt = (MGT_TIME*)&pTlvDt->stTime;

	printf("<<<  TIME\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stTime.stSeconds.usSec_msb = 0x%04x \n",nIndex,	dt->stTime.stSeconds.usSec_msb);	nIndex += sizeof(dt->stTime.stSeconds.usSec_msb);
	printf(" %04d +                 .ulSec_lsb = 0x%08x \n",nIndex,	dt->stTime.stSeconds.ulSec_lsb);	nIndex += sizeof(dt->stTime.stSeconds.ulSec_lsb);
	printf(" %04d +       .ulNanoseconds       = 0x%08x \n",nIndex,	dt->stTime.ulNanoseconds);			nIndex += sizeof(dt->stTime.ulNanoseconds);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_ClockAccuracy(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_CLOCK_ACCURACY* dt = (MGT_CLOCK_ACCURACY*)&pTlvDt->stClockAccuracy;

	printf("<<<  CLOCK_ACCURACY\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stClockAccuracy.uchClockAccuracy = 0x%02x \n",nIndex,	dt->uchClockAccuracy);	nIndex += sizeof(dt->uchClockAccuracy);
	printf(" %04d + stClockAccuracy.uchReserved1     = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_UTCProperties(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_UTC_PROPERTIES* dt = (MGT_UTC_PROPERTIES*)&pTlvDt->stUTC_Properties;

	printf("<<<  UTC_PROPERTIES\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stUTC_Properties.sCrentUtcOffset = 0x%04x \n",nIndex,	dt->sCrentUtcOffset);	nIndex += sizeof(dt->sCrentUtcOffset);
	printf(" %04d + stUTC_Properties.stFlags         = 0x%02x \n",nIndex,	dt->byFlags);			nIndex += sizeof(dt->byFlags);
	printf(" **< LI-61:0/LI-59:1/UTCV:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stUTC_Properties.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stUTC_Properties.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stUTC_Properties.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stUTC_Properties.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stUTC_Properties.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stUTC_Properties.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stUTC_Properties.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stUTC_Properties.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stUTC_Properties.uchReserved1    = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_TracebilityProperties(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TRACEABILITY_PROPERTIES* dt = (MGT_TRACEABILITY_PROPERTIES*)&pTlvDt->stTrcebltyProperties;

	printf("<<<  TRACEABILITY_PROPERTIES\n");
	printf( " [Display ManagementID-DataField] \n" );
	printf(" %04d + stTrcebltyProperties.stFlags         = 0x%02x \n",nIndex,	dt->byFlags);			nIndex += sizeof(dt->byFlags);
	printf(" **< x:0/x:1/x:2/x:3/TTRA:4/FTRA:5/x:6/x:7 \n");
	printf(" %04d + stTrcebltyProperties.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stTrcebltyProperties.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stTrcebltyProperties.uchReserved1    = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_TimescaleProperties(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TIMESCALE_PROPERTIES* dt = (MGT_TIMESCALE_PROPERTIES*)&pTlvDt->stTimScaleProperties;

	printf("<<<  TIMESCALE_PROPERTIES\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stTimScaleProperties.stFlags         = 0x%02x \n",nIndex,	dt->byFlags);			nIndex += sizeof(dt->byFlags);
	printf(" **< x:0/x:1/x:2/PTP:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stTimScaleProperties.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stTimScaleProperties.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stTimScaleProperties.uchTimeSource   = 0x%02x \n",nIndex,	dt->uchTimeSource);		nIndex += sizeof(dt->uchTimeSource);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_UnicastNegotiationEnable(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  UNICAST_NEGOTIATION_ENABLE\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_PathTraceList(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	INT i = 0;
	MGT_PATH_TRACE_LIST* dt = (MGT_PATH_TRACE_LIST*)&pTlvDt->stPathTraceList;

	printf("<<<  PATH_TRACE_LIST\n");
	printf( " [Display ManagementID-DataField] \n" );


	for( i = 0 ; i < 4 ; i++ )
	{
		printf(" %04d + %02d stPathTraceList.stClockIdentity = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n"
								,nIndex, i,
								dt->stPathSequence[i].uchId[0],
								dt->stPathSequence[i].uchId[1],
								dt->stPathSequence[i].uchId[2],
								dt->stPathSequence[i].uchId[3],
								dt->stPathSequence[i].uchId[4],
								dt->stPathSequence[i].uchId[5],
								dt->stPathSequence[i].uchId[6],
								dt->stPathSequence[i].uchId[7]);
		nIndex += sizeof(dt->stPathSequence[0].uchId);
	}



}
VOID Display_PtpMgt_PathTraceEnable(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PATH_TRACE_ENABLE* dt = (MGT_PATH_TRACE_ENABLE*)&pTlvDt->stPathTraceEnable;

	printf("<<<  PATH_TRACE_ENABLE\n");
	printf( " [Display ManagementID-DataField] \n" );
	printf(" %04d + stPathTraceEnable.stFlags         = 0x%02x \n",nIndex,	dt->byFlags);			nIndex += sizeof(dt->byFlags);
	printf(" **< EN:0/x:1/x:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stPathTraceEnable.stFlags.byBit0  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit1  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit2  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit3  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit4  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit5  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit6  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stPathTraceEnable.stFlags.byBit7  = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stPathTraceEnable.uchReserved1    = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_GrandmasterClusterTable(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  GRANDMASTER_CLUSTER_TABLE\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_UnicastMasterTable(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  UNICAST_MASTER_TABLE\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_UnicastMasterMaxTableSize(MGT_DATAFIELD* pTlvDt)
{
	printf("<<<  UNICAST_MASTER_MAX_TABLE_SIZE\n");
	printf( " [Display ManagementID-DataField] \n" );
}
VOID Display_PtpMgt_PortStatisticsCount(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PORT_STATISTICS_COUNT* dt = (MGT_PORT_STATISTICS_COUNT*)&pTlvDt->stPortStatisticsCnt;

	printf("<<<  PORT_STATISTICS_COUNT\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPortStatisticsCnt.ulRxSyncCount              = 0x%08x \n",nIndex,	dt->ulRxSyncCount);				nIndex += sizeof(dt->ulRxSyncCount);
	printf(" %04d + stPortStatisticsCnt.ulRxOneStepSyncCount       = 0x%08x \n",nIndex,	dt->ulRxOneStepSyncCount);		nIndex += sizeof(dt->ulRxOneStepSyncCount);
	printf(" %04d + stPortStatisticsCnt.ulRxFollowUpCount          = 0x%08x \n",nIndex,	dt->ulRxFollowUpCount);			nIndex += sizeof(dt->ulRxFollowUpCount);
	printf(" %04d + stPortStatisticsCnt.ulRxAnnounceCount          = 0x%08x \n",nIndex,	dt->ulRxAnnounceCount);			nIndex += sizeof(dt->ulRxAnnounceCount);
	printf(" %04d + stPortStatisticsCnt.ulRxPTPPacketDiscardCount  = 0x%08x \n",nIndex,	dt->ulRxPTPPacketDiscardCount);	nIndex += sizeof(dt->ulRxPTPPacketDiscardCount);
	printf(" %04d + stPortStatisticsCnt.ulSyncReceiptTimeoutCount  = 0x%08x \n",nIndex,	dt->ulSyncReceiptTimeoutCount);	nIndex += sizeof(dt->ulSyncReceiptTimeoutCount);
	printf(" %04d + stPortStatisticsCnt.ulAnnounceReceiptTimeoutCount  = 0x%08x \n",nIndex,	dt->ulAnnounceReceiptTimeoutCount);	nIndex += sizeof(dt->ulAnnounceReceiptTimeoutCount);
	printf(" %04d + stPortStatisticsCnt.ulTxSyncCount              = 0x%08x \n",nIndex,	dt->ulTxSyncCount);				nIndex += sizeof(dt->ulTxSyncCount);
	printf(" %04d + stPortStatisticsCnt.ulTxOneStepSyncCount       = 0x%08x \n",nIndex,	dt->ulTxOneStepSyncCount);		nIndex += sizeof(dt->ulTxOneStepSyncCount);
	printf(" %04d + stPortStatisticsCnt.ulTxFollowUpCount          = 0x%08x \n",nIndex,	dt->ulTxFollowUpCount);			nIndex += sizeof(dt->ulTxFollowUpCount);
	printf(" %04d + stPortStatisticsCnt.ulTxAnnounceCount          = 0x%08x \n",nIndex,	dt->ulTxAnnounceCount);			nIndex += sizeof(dt->ulTxAnnounceCount);
	printf(" %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMgt_CMLDPortStatisticsCount(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_CMLD_PORT_STATIS_COUNT* dt = (MGT_CMLD_PORT_STATIS_COUNT*)&pTlvDt->stCMLD_PortStatisticsCnt;

	printf("<<<  CMLD_PORT_STATISTICS_COUNT\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stCMLD_PortStatisticsCnt.ulRxPDReqCount            = 0x%08x \n",nIndex,	dt->ulRxPDReqCount);			nIndex += sizeof(dt->ulRxPDReqCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulRxPDRespCount           = 0x%08x \n",nIndex,	dt->ulRxPDRespCount);			nIndex += sizeof(dt->ulRxPDRespCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulRxPDRespFollowUpCount   = 0x%08x \n",nIndex,	dt->ulRxPDRespFollowUpCount);	nIndex += sizeof(dt->ulRxPDRespFollowUpCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulRxPTPPacketDiscardCount = 0x%08x \n",nIndex,	dt->ulRxPTPPacketDiscardCount);	nIndex += sizeof(dt->ulRxPTPPacketDiscardCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulPDAllowedLostRespExceedCount  = 0x%08x \n",nIndex,	dt->ulPDAllowedLostRespExceedCount);	nIndex += sizeof(dt->ulPDAllowedLostRespExceedCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulTxPDReqCount            = 0x%08x \n",nIndex,	dt->ulTxPDReqCount);			nIndex += sizeof(dt->ulTxPDReqCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulTxPDRespCount           = 0x%08x \n",nIndex,	dt->ulTxPDRespCount);			nIndex += sizeof(dt->ulTxPDRespCount);
	printf(" %04d + stCMLD_PortStatisticsCnt.ulTxPDRespFollowUpCount   = 0x%08x \n",nIndex,	dt->ulTxPDRespFollowUpCount);	nIndex += sizeof(dt->ulTxPDRespFollowUpCount);
	printf(" %04d + ----- Message \n",	nIndex );
}

VOID Display_PtpMgt_PortStatisticsErrorCount(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PORT_STATISTICS_ERRCOUNT* dt = (MGT_PORT_STATISTICS_ERRCOUNT*)&pTlvDt->stPortStatisticsErrCnt;

	printf("<<<  PORT_STATISTICS_ERRCOUNT\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPortStatisticsErrCnt.ulTxMessageErrCount = 0x%08x \n",nIndex,	dt->ulTxMessageErrCount);	nIndex += sizeof(dt->ulTxMessageErrCount);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_TransparentClockDefaultDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TCLK_DEFAULT_DATA_SET* dt = (MGT_TCLK_DEFAULT_DATA_SET*)&pTlvDt->stTCLK_DefaultDS;

	printf("<<<  TRANSPARENT_CLOCK_DEFAULT_DATA_SET\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stTCLK_DefaultDS.stClockIdentity    = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stClockIdentity.uchId[0],
							dt->stClockIdentity.uchId[1],
							dt->stClockIdentity.uchId[2],
							dt->stClockIdentity.uchId[3],
							dt->stClockIdentity.uchId[4],
							dt->stClockIdentity.uchId[5],
							dt->stClockIdentity.uchId[6],
							dt->stClockIdentity.uchId[7]);	nIndex += sizeof(dt->stClockIdentity.uchId);
	printf(" %04d + stTCLK_DefaultDS.usNumberPorts      = 0x%04x, \n",	nIndex, dt->usNumberPorts );			nIndex += sizeof(dt->usNumberPorts);
	printf(" %04d + stTCLK_DefaultDS.uchDelayMechanism  = 0x%02x, \n",	nIndex , dt->uchDelayMechanism );	nIndex += sizeof(dt->uchDelayMechanism);
	printf(" %04d + stTCLK_DefaultDS.uchPrimaryDomain   = 0x%02x, \n",	nIndex , dt->uchPrimaryDomain );		nIndex += sizeof(dt->uchPrimaryDomain);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_TransparentClockPortDataSet(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_TCLK_PORT_DATA_SET* dt = (MGT_TCLK_PORT_DATA_SET*)&pTlvDt->stTCLK_PortDS;

	printf("<<<  TRANSPARENT_CLOCK_PORT_DATA_SET\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stTCLK_PortDS.stPortIdentity.stClockIdentity  = 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x 0x%02x, \n",nIndex,
							dt->stPortIdentity.stClockIdentity.uchId[0],
							dt->stPortIdentity.stClockIdentity.uchId[1],
							dt->stPortIdentity.stClockIdentity.uchId[2],
							dt->stPortIdentity.stClockIdentity.uchId[3],
							dt->stPortIdentity.stClockIdentity.uchId[4],
							dt->stPortIdentity.stClockIdentity.uchId[5],
							dt->stPortIdentity.stClockIdentity.uchId[6],
							dt->stPortIdentity.stClockIdentity.uchId[7]);	nIndex += sizeof(dt->stPortIdentity.stClockIdentity.uchId);
	printf(" %04d +                             .usPortNumber     = 0x%04x, \n",nIndex, dt->stPortIdentity.usPortNumber );	nIndex += sizeof(dt->stPortIdentity.usPortNumber);
	printf(" %04d + stTCLK_PortDS.stFlags                   = 0x%02x \n",nIndex,	dt->byFlags);						nIndex += sizeof(dt->byFlags);
	printf(" **< FLT:0/x:1/x:2/x:3/x:4/x:5/x:6/x:7 \n");
	printf(" %04d + stTCLK_PortDS.stFlags.byBit0            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,0,0) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit1            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,1,1) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit2            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,2,2) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit3            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,3,3) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit4            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,4,4) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit5            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,5,5) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit6            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,6,6) );
	printf(" %04d + stTCLK_PortDS.stFlags.byBit7            = 0x%02x \n",nIndex,	PTP_GET_BITS(&dt->byFlags,7,7) );

	printf(" %04d + stTCLK_PortDS.chLogMinPdelayReqInterval = 0x%02x \n",nIndex,	dt->chLogMinPdelayReqInterval);		nIndex += sizeof(dt->chLogMinPdelayReqInterval);
	printf(" %04d + stTCLK_PortDS.stPeerMeanPathDelay.sNsec_msb     = 0x%04x, \n",	nIndex , dt->stPeerMeanPathDelay.sNsec_msb );	nIndex += sizeof(dt->stPeerMeanPathDelay.sNsec_msb);
	printf(" %04d +                                  .ulNsec_lsb    = 0x%08x, \n",	nIndex , dt->stPeerMeanPathDelay.ulNsec_lsb );	nIndex += sizeof(dt->stPeerMeanPathDelay.ulNsec_lsb);
	printf(" %04d +                                  .usFrcNsec     = 0x%04x, \n",	nIndex , dt->stPeerMeanPathDelay.usFrcNsec );	nIndex += sizeof(dt->stPeerMeanPathDelay.usFrcNsec);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_PrimaryDomain(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_PRIMARY_DOMAIN* dt = (MGT_PRIMARY_DOMAIN*)&pTlvDt->stPrimaryDomain;

	printf("<<<  PRIMARY_DOMAIN\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stPrimaryDomain.uchPrimaryDomain = 0x%02x \n",nIndex,	dt->uchPrimaryDomain);	nIndex += sizeof(dt->uchPrimaryDomain);
	printf(" %04d + stPrimaryDomain.uchReserved1     = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_DelayMechanism(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_DELAY_MECHANISM* dt = (MGT_DELAY_MECHANISM*)&pTlvDt->stDelayMechanism;

	printf("<<<  DELAY_MECHANISM\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stDelayMechanism.uchDelayMechanism = 0x%02x \n",nIndex,	dt->uchDelayMechanism);	nIndex += sizeof(dt->uchDelayMechanism);
	printf(" %04d + stDelayMechanism.uchReserved1      = 0x%02x \n",nIndex,	dt->uchReserved1);		nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
VOID Display_PtpMgt_LogMinPdelayReqInterval(MGT_DATAFIELD* pTlvDt)
{
	INT	nIndex = 0;
	MGT_LOG_MIN_PDREQ_INTERVAL* dt = (MGT_LOG_MIN_PDREQ_INTERVAL*)&pTlvDt->stLogMinPdelayReqIntv;

	printf("<<<  LOG_MIN_PDELAY_REQ_INTERVAL\n");
	printf( " [Display ManagementID-DataField] \n" );

	printf(" %04d + stLogMinPdelayReqIntv.chLogMinPdelayReqInterval = 0x%02x \n",nIndex,	dt->chLogMinPdelayReqInterval);	nIndex += sizeof(dt->chLogMinPdelayReqInterval);
	printf(" %04d + stLogMinPdelayReqIntv.uchReserved1              = 0x%02x \n",nIndex,	dt->uchReserved1);				nIndex += sizeof(dt->uchReserved1);
	printf(" %04d + ----- Message \n",	nIndex );
}
#endif
