//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "snmpv3.h"
#include "mib_morg.h"

extern ST_SNC_N1MibNetworkConfig         gaST_SNC_MibNetCnf[];
extern ST_SNC_N1MibDeviceDetail          gaST_SNC_MibDevDtl[];
extern ST_SNC_N1MibOtherModule           gST_SNC_MibOthMod;
extern ST_SNC_N1MibStatisticalInfo       gST_SNC_MibStaInf;
extern ST_SNC_N1MibIpOverlapError        gST_SNC_MibOvrErr;
extern ST_SNC_N1MibIpTopologyError       gST_SNC_MibTopErr;
extern ST_SNC_N1MibDatalinkError         gST_SNC_MibDatErr;
extern ST_SNC_N1MibCommTimingError       gST_SNC_MibComErr;
extern ST_SNC_N1MibCurrentError          gST_SNC_MibCurErr;

extern ST_SNC_MemoryObject gaST_SNC_MemObjTbl[];

unsigned char	guchBuffer[128];

const MIBVAR mibvar_cclinkien[] = {
{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 1, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchMacAddress      )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchMacAddress       }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 2, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usStationNumber     )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usStationNumber     )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 3, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.uchNetworkNumber    )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.uchNetworkNumber    )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 4, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchIpAddress       )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchIpAddress        }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 5, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.uchCertificationClass)+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.uchCertificationClass)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 6, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.uchStationType      )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.uchStationType      )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 7, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usDeviceVersion     )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usDeviceVersion     )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 8, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usFwVersion         )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usFwVersion         )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1, 9, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.uchHwVersion        )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.uchHwVersion        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,10, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usDeviceType        )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usDeviceType        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,11, 0     }}, CAR, Gauge      , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.ulDeviceModelCode   )  , &(gaST_SNC_MibDevDtl[0].stIdentifier.ulDeviceModelCode   )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,12, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usExpansionModelCode)+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usExpansionModelCode)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,13, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usVendorCode        )+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usVendorCode        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,14, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchDeviceModelName )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchDeviceModelName  }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,15, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchVendorName      )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchVendorName       }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,16, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchSerialNumber    )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchSerialNumber     }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,17, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.uchOption           )  , &(gaST_SNC_MibDevDtl[0].stIdentifier.uchOption           )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,18, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.usStationSpecificMode)+1, &(gaST_SNC_MibDevDtl[0].stIdentifier.usStationSpecificMode)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 1,19, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stIdentifier.auchUnitIdentifier  )  ,   gaST_SNC_MibDevDtl[0].stIdentifier.auchUnitIdentifier   }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 1, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfPort                    )+1, &(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfPort                    )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 2, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.auchPortCondition )  ,   gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.auchPortCondition  }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 4, 0     }}, CAR, OctetString, sizeof(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchDiagnosisInfo  )  , &(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchDiagnosisInfo  )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 6, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfMasterTable             )+1, &(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfMasterTable             )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 7, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchCyclicStopInfo )+1, &(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchCyclicStopInfo )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 8, 0     }}, CAR, Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfLedTable                )+1, &(gaST_SNC_MibDevDtl[0].stStatus.uchNumberOfLedTable                )}
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 9, 1, 1  }}, SX          , Integer    , 1                                                                        , 0                                                                 }
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 9, 1, 2  }}, (CAR+SCALAR), OctetString, sizeof(gaST_SNC_MibDevDtl[0].stStatus.astMasterTable[0].auchMacAddress)  ,   gaST_SNC_MibDevDtl[0].stStatus.astMasterTable[0].auchMacAddress }
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,10, 1, 1  }}, SX          , Integer    , 1                                                                        , 0                                                                 }
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,10, 1, 2  }}, (CAR+SCALAR), Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.astLedTable[0].uchLedColor      )+1, &(gaST_SNC_MibDevDtl[0].stStatus.astLedTable[0].uchLedColor      )}
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,10, 1, 3  }}, (CAR+SCALAR), Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.astLedTable[0].uchLedStatus     )+1, &(gaST_SNC_MibDevDtl[0].stStatus.astLedTable[0].uchLedStatus     )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,11, 0     }}, CAR         , OctetString, sizeof(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.auchCorrespondingFunction)  , &(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.auchCorrespondingFunction)}
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,12, 1, 1  }}, SX          , Integer    , 1                                                                         , 0                                                                  }
,{{13,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,12, 1, 2  }}, (CAR+SCALAR), Integer    , sizeof(gaST_SNC_MibDevDtl[0].stStatus.astPortTable[0].usPortLinkDownCnt)+1, &(gaST_SNC_MibDevDtl[0].stStatus.astPortTable[0].usPortLinkDownCnt)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,13, 0     }}, CAR		  , OctetString, sizeof(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchAppInfo     ), &(gaST_SNC_MibDevDtl[0].stStatus.stStatusInfoBase.uchAppInfo     )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 1, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.uchDeviceVersion    )+1, &(gST_SNC_MibOthMod.stController.uchDeviceVersion    )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 2, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.uchFwVersion        )+1, &(gST_SNC_MibOthMod.stController.uchFwVersion        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 3, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.uchHwVersion        )+1, &(gST_SNC_MibOthMod.stController.uchHwVersion        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 4, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.usDeviceType        )+1, &(gST_SNC_MibOthMod.stController.usDeviceType        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 5, 0     }}, 0  , Gauge      , sizeof(gST_SNC_MibOthMod.stController.ulDeviceModelCode   )  , &(gST_SNC_MibOthMod.stController.ulDeviceModelCode   )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 6, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.usExpansionModelCode)+1, &(gST_SNC_MibOthMod.stController.usExpansionModelCode)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 7, 0     }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.stController.usVendorCode        )+1, &(gST_SNC_MibOthMod.stController.usVendorCode        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 8, 0     }}, 0  , OctetString, sizeof(gST_SNC_MibOthMod.stController.auchDeviceModelName )  ,   gST_SNC_MibOthMod.stController.auchDeviceModelName }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1, 9, 0     }}, 0  , OctetString, sizeof(gST_SNC_MibOthMod.stController.auchVendorName      )  ,   gST_SNC_MibOthMod.stController.auchVendorName      }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 1,10, 0     }}, 0  , OctetString, sizeof(gST_SNC_MibOthMod.stController.auchSerialNumber    )  ,   gST_SNC_MibOthMod.stController.auchSerialNumber    }
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 2, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibOthMod.usNumberOfTable                  )+1, &(gST_SNC_MibOthMod.usNumberOfTable                  )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 1     }}, SX          , Integer    , 1                                                              , 0                                                       }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 2     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibOthMod.astOptTable[0].uchDeviceVersion    )+1, &(gST_SNC_MibOthMod.astOptTable[0].uchDeviceVersion    )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 3     }}, 0           , Gauge      , sizeof(gST_SNC_MibOthMod.astOptTable[0].ulDeviceModelCode   )  , &(gST_SNC_MibOthMod.astOptTable[0].ulDeviceModelCode   )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 4     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibOthMod.astOptTable[0].usExpansionModelCode)+1, &(gST_SNC_MibOthMod.astOptTable[0].usExpansionModelCode)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 5     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibOthMod.astOptTable[0].usVendorCode        )+1, &(gST_SNC_MibOthMod.astOptTable[0].usVendorCode        )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 6     }}, 0           , OctetString, sizeof(gST_SNC_MibOthMod.astOptTable[0].auchDeviceModelName )  ,   gST_SNC_MibOthMod.astOptTable[0].auchDeviceModelName  }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 7     }}, 0           , OctetString, sizeof(gST_SNC_MibOthMod.astOptTable[0].auchVendorName      )  ,   gST_SNC_MibOthMod.astOptTable[0].auchVendorName       }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3, 1, 8     }}, 0           , OctetString, sizeof(gST_SNC_MibOthMod.astOptTable[0].auchSerialNumber    )  ,   gST_SNC_MibOthMod.astOptTable[0].auchSerialNumber     }
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 1, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usCyclicReceiveCounter          )+1, &(gST_SNC_MibStaInf.usCyclicReceiveCounter          )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 2, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usCyclicReceiveDiscardCounter   )+1, &(gST_SNC_MibStaInf.usCyclicReceiveDiscardCounter   )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 3, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usCyclicFrameReceiveCounter     )+1, &(gST_SNC_MibStaInf.usCyclicFrameReceiveCounter     )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 4, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNonCyclicReceiveCounter       )+1, &(gST_SNC_MibStaInf.usNonCyclicReceiveCounter       )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 5, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNonCyclicReceiveDiscardCounter)+1, &(gST_SNC_MibStaInf.usNonCyclicReceiveDiscardCounter)}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 6, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfHecErrorFrame         )+1, &(gST_SNC_MibStaInf.usNumberOfHecErrorFrame         )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 7, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfDcsErrorFrame         )+1, &(gST_SNC_MibStaInf.usNumberOfDcsErrorFrame         )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 8, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfFcsErrorFrame         )+1, &(gST_SNC_MibStaInf.usNumberOfFcsErrorFrame         )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4, 9, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfSdcrcErrorFrame       )+1, &(gST_SNC_MibStaInf.usNumberOfSdcrcErrorFrame       )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,10, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfShortPacketFrame      )+1, &(gST_SNC_MibStaInf.usNumberOfShortPacketFrame      )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,11, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfJumboPacketFrame      )+1, &(gST_SNC_MibStaInf.usNumberOfJumboPacketFrame      )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,12, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfLongPacketFrame       )+1, &(gST_SNC_MibStaInf.usNumberOfLongPacketFrame       )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,13, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfFailedCcLinkIePduSize )+1, &(gST_SNC_MibStaInf.usNumberOfFailedCcLinkIePduSize )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,14, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfFlagmentErrorFrame    )+1, &(gST_SNC_MibStaInf.usNumberOfFlagmentErrorFrame    )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,15, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfPriorityControlFrame  )+1, &(gST_SNC_MibStaInf.usNumberOfPriorityControlFrame  )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,16, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfIpFrame               )+1, &(gST_SNC_MibStaInf.usNumberOfIpFrame               )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,17, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfIeee802or1588Frame    )+1, &(gST_SNC_MibStaInf.usNumberOfIeee802or1588Frame    )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,18, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfLldpFrame             )+1, &(gST_SNC_MibStaInf.usNumberOfLldpFrame             )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 4,19, 0        }}, CAR, Integer    , sizeof(gST_SNC_MibStaInf.usNumberOfSyncFrame             )+1, &(gST_SNC_MibStaInf.usNumberOfSyncFrame             )}
,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 1, 0        }}, CAR         , Integer    , sizeof(gST_SNC_MibCurErr.usNumberOfTable                                )+1, &(gST_SNC_MibCurErr.usNumberOfTable                                )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 1     }}, SX          , Integer    , 1                                                                          , 0                                                                   }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 2     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].usErrorCode                   )+1, &(gST_SNC_MibCurErr.astErrorTable[0].usErrorCode                   )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 3     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].usErrorOccurrenceOrderNo                   )+1, &(gST_SNC_MibCurErr.astErrorTable[0].usErrorOccurrenceOrderNo                   )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 4     }}, 0           , OctetString, sizeof(gST_SNC_MibCurErr.astErrorTable[0].ullOccurrenceTimeSeconds      )  , &(gST_SNC_MibCurErr.astErrorTable[0].ullOccurrenceTimeSeconds      )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 5     }}, 0           , Gauge      , sizeof(gST_SNC_MibCurErr.astErrorTable[0].ulOccurrenceTimeNanoLiw       )  , &(gST_SNC_MibCurErr.astErrorTable[0].ulOccurrenceTimeNanoLiw       )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 6     }}, 0           , Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].sUtcOffset                    )  , &(gST_SNC_MibCurErr.astErrorTable[0].sUtcOffset                    )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 7     }}, 0           , Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].sSummerTimeOffset             )  , &(gST_SNC_MibCurErr.astErrorTable[0].sSummerTimeOffset             )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2, 1, 8     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].uchNumberOfTable              )+1, &(gST_SNC_MibCurErr.astErrorTable[0].uchNumberOfTable              )}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 3, 1, 1     }}, (CAR+SCALAR), Integer    , 1                                                                          , guchBuffer                                                          }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 3, 1, 2     }}, (CAR+SCALAR), Integer    , sizeof(gST_SNC_MibCurErr.astErrorTable[0].astDetailTable[0].usDetailInfo)+1, &(gST_SNC_MibCurErr.astErrorTable[0].astDetailTable[0].usDetailInfo)}
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,99,99, 1, 1     }}, CAR         , Integer    , 1, guchBuffer }
,{{12,{0x2b,6,1,4,1,0x83,0x92,0x28,99,99, 1, 2     }}, CAR         , Integer    , 1, guchBuffer }
};

enum mibvar_cclinkien_index {
DevDtl_auchMacAddress
,DevDtl_usStationNumber
,DevDtl_uchNetworkNumber
,DevDtl_auchIpAddress
,DevDtl_uchCertificationClass
,DevDtl_uchStationType
,DevDtl_uchDeviceVersion
,DevDtl_uchFwVersion
,DevDtl_uchHwVersion
,DevDtl_usDeviceType
,DevDtl_ulDeviceModelCode
,DevDtl_usExpansionModelCode
,DevDtl_usVendorCode
,DevDtl_auchDeviceModelName
,DevDtl_auchVendorName
,DevDtl_auchSerialNumber
,DevDtl_uchOption
,DevDtl_usStationSpecificMode
,DevDtl_auchUnitIdentifier
,DevDtl_uchNumberOfPort
,DevDtl_auchPortCondition
,DevDtl_uchDiagnosisInfo
,DevDtl_uchNumberOfMasterTable
,DevDtl_uchCyclicStopInfo
,DevDtl_uchNumberOfLedTable
,DevDtl_MstN
,DevDtl_Mst_auchMacAddress
,DevDtl_LedN
,DevDtl_Led_uchLedColor
,DevDtl_Led_uchLedStatus
,DevDtl_auchCorrespondingFunction
,DevDtl_PorN
,DevDtl_Por_usPortLinkDownCnt
,DevDtl_App_Info
,OthMod_uchDeviceVersion
,OthMod_uchFwVersion
,OthMod_uchHwVersion
,OthMod_usDeviceType
,OthMod_ulDeviceModelCode
,OthMod_usExpansionModelCode
,OthMod_usVendorCode
,OthMod_auchDeviceModelName
,OthMod_auchVendorName
,OthMod_auchSerialNumber
,OthMod_usNumberOfTable
,OthMod_OptN
,OthMod_Opt_uchDeviceVersion
,OthMod_Opt_ulDeviceModelCode
,OthMod_Opt_usExpansionModelCode
,OthMod_Opt_usVendorCode
,OthMod_Opt_auchDeviceModelName
,OthMod_Opt_auchVendorName
,OthMod_Opt_auchSerialNumber
,StaInf_usCyclicReceiveCounter
,StaInf_usCyclicReceiveDiscardCounter
,StaInf_usCyclicFrameReceiveCounter
,StaInf_usNonCyclicReceiveCounter
,StaInf_usNonCyclicReceiveDiscardCounter
,StaInf_usNumberOfHecErrorFrame
,StaInf_usNumberOfDcsErrorFrame
,StaInf_usNumberOfFcsErrorFrame
,StaInf_usNumberOfSdcrcErrorFrame
,StaInf_usNumberOfShortPacketFrame
,StaInf_usNumberOfJumboPacketFrame
,StaInf_usNumberOfLongPacketFrame
,StaInf_usNumberOfFailedCcLinkIePduSize
,StaInf_usNumberOfFlagmentErrorFrame
,StaInf_usNumberOfPriorityControlFrame
,StaInf_usNumberOfIpFrame
,StaInf_usNumberOfIeee802or1588Frame
,StaInf_usNumberOfLldpFrame
,StaInf_usNumberOfSyncFrame
,CurErr_usNumberOfTable
,CurErr_InfN
,CurErr_Inf_usErrorCode
,CurErr_Inf_usErrorOccurrenceOrderNo
,CurErr_Inf_ullOccurrenceTimeSeconds
,CurErr_Inf_ulOccurrenceTimeNanoLiw
,CurErr_Inf_sUtcOffset
,CurErr_Inf_sSummerTimeOffset
,CurErr_Inf_uchNumberOfTable
,CurErr_Inf_DtlN
,CurErr_Inf_Dtl_usDetailInfo
,CurErr_Inf2N
};

const MIBTAB mibtab_cclinkien[] = {
       {{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2, 9   }}, 1,{DevDtl_MstN                          }, sizeof(ST_SNC_N3MibStatusMaster      )}
       ,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,10   }}, 1,{DevDtl_LedN                          }, sizeof(ST_SNC_N3MibLed               )}
       ,{{11,{0x2b,6,1,4,1,0x83,0x92,0x28, 2, 2,12   }}, 1,{DevDtl_PorN                          }, sizeof(ST_SNC_N3MibPort              )}
       ,{{10,{0x2b,6,1,4,1,0x83,0x92,0x28, 3, 3      }}, 1,{OthMod_OptN                          }, sizeof(ST_SNC_N2MibOptionInfo        )}
       ,{{10,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 2      }}, 1,{CurErr_InfN                          }, sizeof(ST_SNC_N2MibErrorReg          )}
       ,{{10,{0x2b,6,1,4,1,0x83,0x92,0x28,11, 3      }}, 2,{CurErr_Inf2N,CurErr_Inf_DtlN         }, 0                                     }
       ,{{10,{0x2b,6,1,4,1,0x83,0x92,0x28,99,99      }}, 1,{CurErr_Inf2N                         }, 0                                     }
};

sint16 mibvarsize_cclinkien(void){
    return( sizeof(mibvar_cclinkien) / sizeof(MIBVAR) );
}

sint16 mibtabsize_cclinkien(void){
    return( sizeof(mibtab_cclinkien) / sizeof(MIBTAB) );
}

void mibget_cclinkien( sint16 varix, sint16 tabix, uint8 **vvptr ){
	long	lIdx11,lIdx22;
	unsigned char	*puchD;
	if( CurErr_Inf_DtlN == varix ){
		puchD  = ((unsigned char*)(*vvptr));
		*puchD = ((unsigned char)( tabix % ST_SNC_ERRDTLREG_MAX ) + 1 );
	}
	else if ( CurErr_Inf2N == varix ){
		puchD  = ((unsigned char*)(*vvptr));
		*puchD = ((unsigned char)( tabix / ST_SNC_ERRDTLREG_MAX ) + 1 );
	}
	else if( ( DevDtl_auchMacAddress        <= varix )
	     &&  ( DevDtl_App_Info >= varix ) ){
		*vvptr = *vvptr + ( sizeof(ST_SNC_N1MibDeviceDetail) * gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_DEVDTL].stCnt.eRead );
		if( ( DevDtl_Mst_auchMacAddress == varix ) ){
			*vvptr = *vvptr + ( sizeof(ST_SNC_N3MibStatusMaster) * tabix );
		}
		else if( ( DevDtl_Led_uchLedColor  <= varix )
		     &&  ( DevDtl_Led_uchLedStatus >= varix ) ){
			*vvptr = *vvptr + ( sizeof(ST_SNC_N3MibLed) * tabix );
		}
		else if( ( DevDtl_Por_usPortLinkDownCnt == varix ) ){
			*vvptr = *vvptr + ( sizeof(ST_SNC_N3MibPort) * tabix );
		}
		else{
			;
		}
	}
	else if( ( OthMod_Opt_uchDeviceVersion <= varix )
	     &&  ( OthMod_Opt_auchSerialNumber >= varix ) ){
		*vvptr = *vvptr + ( sizeof(ST_SNC_N2MibOptionInfo) * tabix );
	}
	else if( ( CurErr_Inf_usErrorCode      <= varix )
	     &&  ( CurErr_Inf_uchNumberOfTable >= varix ) ){
		*vvptr = *vvptr + ( sizeof(ST_SNC_N2MibErrorReg) * tabix );
	}
	else if( CurErr_Inf_Dtl_usDetailInfo == varix ){
		lIdx11 = tabix / ST_SNC_ERRDTLREG_MAX;
		lIdx22 = tabix % ST_SNC_ERRDTLREG_MAX;
		*vvptr = *vvptr + ( sizeof(ST_SNC_N2MibErrorReg      ) * lIdx11 )
		                + ( sizeof(ST_SNC_N3MibErrorDetailReg) * lIdx22 );
	}
	else{
		;
	}
	switch( varix ){
	case	CurErr_Inf_DtlN:
	case	CurErr_Inf2N:
		;
		break;
	default:
		if( Integer == mibvar_cclinkien[varix].type ){
			memcpy( guchBuffer, *vvptr, ( mibvar_cclinkien[varix].len - 1 ) );
			guchBuffer[ ( mibvar_cclinkien[varix].len - 1 ) ] = 0x00;
			*vvptr = guchBuffer;
		}
		else{
			;
		}
		break;
	}
	return;
}

sint16 mibindex_cclinkien( sint16 varix, sint16 tabix ){
	sint16	siRst = -1;
	long	lIdx11,lIdx22;
	if( ( DevDtl_MstN               <= varix )
	     &&  ( DevDtl_Mst_auchMacAddress >= varix ) ){
		if( ST_SNC_DEVDTL_MASTER_MAX <= tabix ){
			siRst = -1;
		}
		else if( tabix < gaST_SNC_MibDevDtl[gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_DEVDTL].stCnt.eRead
		                                    ].stStatus.uchNumberOfMasterTable ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( ( DevDtl_LedN             <= varix )
	     &&  ( DevDtl_Led_uchLedStatus >= varix ) ){
		if( ST_SNC_DEVDTL_LED_MAX <= tabix ){
			siRst = -1;
		}
		else if( tabix < gaST_SNC_MibDevDtl[gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_DEVDTL].stCnt.eRead
		                                    ].stStatus.uchNumberOfLedTable ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( ( DevDtl_PorN                  <= varix )
	     &&  ( DevDtl_Por_usPortLinkDownCnt >= varix ) ){
		if( ST_SNC_DEVDTL_PORT_MAX <= tabix ){
			siRst = -1;
		}
		else if( tabix < gaST_SNC_MibDevDtl[gaST_SNC_MemObjTbl[ST_SNC_MIBTYPE_DEVDTL].stCnt.eRead
		                                    ].stStatus.uchNumberOfPort ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( ( OthMod_OptN                 <= varix )
	     &&  ( OthMod_Opt_auchSerialNumber >= varix ) ){
		if( ST_SNC_OTHER_OPT_MAX <= tabix ){
			siRst = -1;
		}
		else if( tabix < gST_SNC_MibOthMod.usNumberOfTable ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( ( CurErr_InfN                 <= varix )
	     &&  ( CurErr_Inf_uchNumberOfTable >= varix ) ){
		if( ST_SNC_ERRREG_MAX <= tabix ){
			siRst = -1;
		}
		else if( tabix < gST_SNC_MibCurErr.usNumberOfTable ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( ( CurErr_Inf_DtlN             <= varix )
	     &&  ( CurErr_Inf_Dtl_usDetailInfo >= varix ) ){
		lIdx11 = tabix / ST_SNC_ERRDTLREG_MAX;
		lIdx22 = tabix % ST_SNC_ERRDTLREG_MAX;
		if( ( ST_SNC_ERRREG_MAX * ST_SNC_ERRDTLREG_MAX ) <= tabix ){
			siRst = -1;
		}
		else if( ( lIdx11 < gST_SNC_MibCurErr.usNumberOfTable )
		     &&  ( lIdx22 < gST_SNC_MibCurErr.astErrorTable[ lIdx11
		                                                    ].uchNumberOfTable ) ){
			siRst = 1;
		}
		else{
			siRst = 0;
		}
	}
	else if( CurErr_Inf2N >= varix ){
		siRst = -1;
	}
	else{
		;
	}
	return( siRst );
}

const MIB mib_CCLINKIEN = {
    mibvar_cclinkien,
    mibvarsize_cclinkien,
    mibtab_cclinkien,
    mibtabsize_cclinkien,
    mibget_cclinkien,
    0,
    mibindex_cclinkien,
    0,
    0
};
