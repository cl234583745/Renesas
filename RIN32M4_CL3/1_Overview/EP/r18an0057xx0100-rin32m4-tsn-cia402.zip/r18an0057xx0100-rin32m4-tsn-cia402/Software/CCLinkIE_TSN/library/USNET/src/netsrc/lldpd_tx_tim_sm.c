//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "msw_lldp.h"
#include "lldpd.h"

void lldpdTxUpdateTimer(LLDPD_AGENT_T *agent)
{
    if (agent->txTimState.txTTR) {
        agent->txTimState.txTTR--;
    }
    if (agent->txState.txShutdownWhile) {
        agent->txState.txShutdownWhile--;
    }
    agent->txTimState.txTick = TRUE;
    return;
}

void lldpdTxTimSmInit(LLDPD_AGENT_T *agent)
{
    agent->txTimState.state  = TX_TIMER_BEGIN;
    agent->txTimState.txTick = FALSE;
    agent->txTimState.txTTR  = 0;
    return;
}

static void lldpdTxTimInit(LLDPD_AGENT_T *agent)
{
    usswLldpdLock();
    agent->txTimState.txTick = FALSE;
    agent->txState.txNow = FALSE;
    agent->txState.localChange = FALSE;
    agent->txTimState.txTTR = 0;
    agent->txState.txFast = 0;
    agent->rxState.newNghbr = FALSE;
    agent->lldpdConfig.txCreditMax = lldpdMib.txCreditMax;
    agent->txState.txCredit = lldpdMib.txCreditMax;
    agent->lldpdConfig.txFastInit = lldpdMib.txFastInit;
    agent->txTimState.state = TX_TIMER_INITIALIZE;
    usswLldpdUnLock();
    return;
}

static void lldpdTxTimSmStatChange(LLDPD_AGENT_T *agent, int newstate)
{
    switch (newstate) {
    case TX_TIMER_INITIALIZE:
    case TX_TIMER_IDLE:
    case TX_TIMER_EXPIRES:
    case TX_TICK:
    case SIGNAL_TX:
    case TX_FAST_START:
        break;
    default:
        LLDPD_LOG_DBG(("lldpdTxTimSmStatChange: unknown state(%d)\n", newstate));
    }

    LLDPD_LOG_INF(("lldpdTxTimSmStatChange: state %d -> %d\n", 
        agent->txTimState.state, newstate));
    agent->txTimState.state = newstate;
    return;
}

static int lldpdTxTimSmStatUpdate(LLDPD_AGENT_T *agent)
{
    int ret = FALSE;
    unsigned char adminStatus = DISABLED;
    LLDPD_PORT_T *port = agent->port;

    lldpdAdminStatusGet(lldpdhwport[port->portno].ifname, 
      agent->mcBitmap, &adminStatus);
    if ((agent->txTimState.state == TX_TIMER_BEGIN) ||
        (port->portEnabled == FALSE) || (adminStatus == DISABLED) ||
        (adminStatus == RX_ONLY)) {
        lldpdTxTimSmStatChange(agent, TX_TIMER_INITIALIZE);
    }

    switch (agent->txTimState.state) {
    case TX_TIMER_INITIALIZE:
        if ((port->portEnabled != FALSE) && 
            ((adminStatus == TX_AND_RX) || (adminStatus == TX_ONLY))) {
            lldpdTxTimSmStatChange(agent, TX_TIMER_IDLE);
            ret = TRUE;
            break;
        }
        break;
    case TX_TIMER_IDLE:
        if (agent->txState.localChange == TRUE) {
            lldpdTxTimSmStatChange(agent, SIGNAL_TX);
            ret = TRUE;
            break;
        }

        if (agent->txTimState.txTTR == 0) {
            lldpdTxTimSmStatChange(agent, TX_TIMER_EXPIRES);
            ret = TRUE;
            break;
        }

        if (agent->rxState.newNghbr == TRUE) {
            lldpdTxTimSmStatChange(agent, TX_FAST_START);
            ret = TRUE;
            break;
        }

        if (agent->txTimState.txTick == TRUE) {
            lldpdTxTimSmStatChange(agent, TX_TICK);
            ret = TRUE;
            break;
        }
        break;
    case TX_TIMER_EXPIRES:
        lldpdTxTimSmStatChange(agent, SIGNAL_TX);
        ret = TRUE;
        break;
    case SIGNAL_TX:
    case TX_TICK:
        lldpdTxTimSmStatChange(agent, TX_TIMER_IDLE);
        ret = TRUE;
        break;
    case TX_FAST_START:
        lldpdTxTimSmStatChange(agent, TX_TIMER_EXPIRES);
        ret = TRUE;
        break;
    default:
        LLDPD_LOG_DBG(("lldpdTxTimSmStatUpdate: ERROR unknown state(%d)\n", 
            agent->txTimState.state));
        break;
    }
    return ret;
}

void lldpdTxTimSmRun(LLDPD_AGENT_T *agent)
{
    lldpdTxTimSmStatUpdate(agent);
    do {
        switch (agent->txTimState.state) {
        case TX_TIMER_INITIALIZE:
            lldpdTxTimInit(agent);
            break;
        case TX_TIMER_IDLE:
            break;
        case TX_TIMER_EXPIRES:
            if (agent->txState.txFast) {
                agent->txState.txFast--;
            }
            break;
        case TX_TICK:
            agent->txTimState.txTick = FALSE;
            if (agent->txState.txCredit < agent->lldpdConfig.txCreditMax) {
                agent->txState.txCredit++;
            }
            break;
        case SIGNAL_TX:
            usswLldpdLock();
            agent->txState.txNow = TRUE;
            agent->txState.localChange = FALSE;
            if (agent->txState.txFast) {
                agent->txTimState.txTTR = agent->lldpdConfig.msgFastTx;
            } else {
                agent->txTimState.txTTR = agent->lldpdConfig.msgTxInterval;
            }
            usswLldpdUnLock();
            break;
        case TX_FAST_START:
            agent->rxState.newNghbr = FALSE;
            if (agent->txState.txFast == 0) {
                agent->txState.txFast = agent->lldpdConfig.txFastInit;
            }
            break;
        default:
            LLDPD_LOG_DBG(("lldpdTxTimSmRun: ERROR unknown state(%d)\n", 
                agent->txTimState.state));
        }
    } while (lldpdTxTimSmStatUpdate(agent) == TRUE);
    return;
}

