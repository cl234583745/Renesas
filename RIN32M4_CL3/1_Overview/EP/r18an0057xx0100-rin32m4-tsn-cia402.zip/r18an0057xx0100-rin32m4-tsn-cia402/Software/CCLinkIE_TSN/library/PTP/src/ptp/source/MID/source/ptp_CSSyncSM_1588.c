/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"

#include "ptp_PSSSend.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CSSync_1AS.h"

#ifdef	PTP_USE_IEEE1588

#include "ptp_UserAdjust.h"
#include "PortStateSelectionSM.h"
#include "ptp_SSSync_1588.h"
#include "ptp_CSSync_1588.h"

#include "ptp_CMSReceive.h"

#define D_FUNC	0
#define D_DBG	0


VOID	CSSync_1588_00(CLOCKDATA*	pstClockData);
VOID	CSSync_1588_01(CLOCKDATA*	pstClockData);
VOID	CSSync_1588_02(CLOCKDATA*	pstClockData);
VOID	setSyncReceiptTime(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
BOOL	setSyncReceiptTime_1588(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData);
VOID	txSRTimeToCMSO_1588(CLOCKDATA*	pstClockData);
VOID	offsetCurrentMasterTime_1588(CLOCKDATA*	pstClockData, PORTDATA*	pstPortData, USCALEDNS*	pstNewCurrentMasterTime, BOOL blT1T4clrFlag);
DOUBLE	computeCMFreqOffset_1588(CLOCKDATA*	pstClockData);
ULONG	calcChangeEventLong_1588(USCALEDNS* pstCMUSNs);
PORTDATA*	GetPstPortData_1588(CLOCKDATA*	pstClockData, USHORT	usPortNum);
VOID	txBMCAupdtStatesTree_1588(CLOCKDATA*	pstClockData);





VOID (*const pfnCSSync_1588_Matrix[ST_CSS_1588_MAX][EV_CSS_1588_EVENT_MAX])(CLOCKDATA*	pstClockData) = {
	{&CSSync_1588_01, &CSSync_1588_01, &CSSync_1588_01, &CSSync_1588_00},
	{&CSSync_1588_01, &CSSync_1588_02, &CSSync_1588_02, &CSSync_1588_00},
	{&CSSync_1588_01, &CSSync_1588_02, &CSSync_1588_02, &CSSync_1588_00}
};



VOID	clockSlaveSync_1588(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CSS_1588	enEvt = EV_CSS_1588_EVENT_MAX;
	BOOL 			blSts = FALSE;


	if (pstClockData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("CSSyncSM_1588   Evt=%d Sts=%d\n", usEvent, pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD.enStatusCSS_1588);
}
#endif
		enEvt = GetCSSyncSM_1588_Event(usEvent, pstClockData);

		blSts = IsCSSyncSM_1588_Status(pstClockData);

		if ((blSts == TRUE) &&
			(enEvt < EV_CSS_1588_EVENT_MAX))
		{
			(*pfnCSSync_1588_Matrix[pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD.enStatusCSS_1588][enEvt])(pstClockData);
		}
		else
		{
			PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000010);
			pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD.blRcvdPSSync		= FALSE;
		}

	}
}



CSSYNCSM_1588_GD*	GetCSSyncSM_1588_GD(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stCSSyncSM_1588_GD);
	return pstCSSGlb;
}




EN_EV_CSS_1588	GetCSSyncSM_1588_Event(
	USHORT		usEvent,
	CLOCKDATA*	pstClockData)
{
	EN_EV_CSS_1588	enEvt = EV_CSS_1588_EVENT_MAX;


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_CSS_1588_BEGIN;
			break;

		case PTP_EV_FOR_CLKSLVSYN_RVPSYNC:
			enEvt = EV_CSS_1588_FOR_CSS_RVPSYNC;
			break;

		case PTP_EV_FOR_CLKSLVSYN_RVLCLKTICK:
			enEvt = EV_CSS_1588_FOR_CSS_RVLCLKTICK;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_CSS_1588_CLOSE;
			break;

		default:
			enEvt = EV_CSS_1588_EVENT_MAX;
			break;
	}

	return	enEvt;
}




BOOL	IsCSSyncSM_1588_Status(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb	= GetCSSyncSM_1588_GD(pstClockData);
	BOOL				blRet			= FALSE;


		if (pstCSSGlb->enStatusCSS_1588 < ST_CSS_1588_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	CSSync_1588_00(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb = GetCSSyncSM_1588_GD(pstClockData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d]\n", 
                  "CSSync_1588_00+",
					 pstClockData->stDefaultDS.uchDomainNumber
                  ) );

	pstCSSGlb->blRcvdPSSync		= FALSE;
	pstCSSGlb->enStatusCSS_1588	= ST_CSS_1588_NONE;
	pstCSSGlb->enSelectedState0_Old	= ENUM_PORTSTATE_DISABLED;

	ptp_dbg_msg( D_FUNC, ("CSSync_1588_00::-\n") );
}




VOID	CSSync_1588_01(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb = GetCSSyncSM_1588_GD(pstClockData);


	pstCSSGlb->blRcvdPSSync		= FALSE;
	pstCSSGlb->enStatusCSS_1588	= ST_CSS_1588_INITIALIZING;
	pstCSSGlb->enSelectedState0_Old	= ENUM_PORTSTATE_DISABLED;
}




VOID	CSSync_1588_02(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= NULL;
	USCALEDNS			stCurrentMasterTime	= {0};
	BOOL				blRet				= FALSE;
#ifndef	PTP_USE_ME_HW_ASSIST
	USCALEDNS			stCurrentDetailTime	= {0};
	SCALEDNS			stE_SNs				= {0};
	USCALEDNS			stF_USNs			= {0};
	LONG				lRet				= RET_ESTATE;
	SCALEDNS			stLTInt_SNs			= {0};
	SCALEDNS			stLTInt2_SNs		= {0};
	EXTENDEDTIMESTAMP	stETimestamp		= {0};
	USCALEDNS			stB_USNs			= {0};
#endif

	ptp_dbg_msg(D_FUNC, ("CSSync_1588_02::+\n"));
	ptp_dbg_msg(D_DBG,  ("   --(Domain=%d)\n", pstClockData->stDefaultDS.uchDomainNumber) );

#if D_DBG
	gdbGmRateRatio += 0.0001;
#endif


#ifndef	PTP_USE_ME_HW_ASSIST
	ptp_GetCurrentMasterTime2(pstClockData,
								&stCurrentMasterTime,
								&stCurrentDetailTime);
#endif

	if (!(IS_OD_BC_1588(pstClockData)))
	{
		pstCSSGlb->blRcvdPSSync			= FALSE;
		pstCSSGlb->blRcvdLocalClockTick	= FALSE;
		return;
	}

	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

	if (pstCSSGlb->blRcvdPSSync)
	{
		if ((pstRcvdPSSyncPtr->usLocalPortNumber != 0) &&
		((pstClockData->stClock_GD.enSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber] == ENUM_PORTSTATE_SLAVE) ||
			(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstRcvdPSSyncPtr->usLocalPortNumber]
																												== (UCHAR)PS_EX_UNCALIBRATED))
		)
		{
			pstPortData = GetPstPortData_1588(pstClockData, pstRcvdPSSyncPtr->usLocalPortNumber);

			blRet = setSyncReceiptTime_1588(pstClockData, pstPortData);
			{

				pstClockData->stClock_GD.stSyncReceiptCMTime = pstClockData->stClock_GD.stSyncReceiptLocalTime;

				offsetCurrentMasterTime_1588(pstClockData, pstPortData, &stCurrentMasterTime, blRet);
			}
		}
		else
		{
			setSyncReceiptTime(pstClockData, pstPortData);

#ifndef	PTP_USE_ME_HW_ASSIST
			lRet = ptp_TimerSemLockWait();
			if (lRet != RET_ENOERR)
			{
				return;
			}
			pstClockData->stClock_GD.dbRateRatio = gdbGmRateRatio;

			ptp_dbg_msg(D_DBG,
				("pstCSSGlb->enSelectedState0_Old = [%d]\n", pstCSSGlb->enSelectedState0_Old));

			if ((pstClockData->stClock_GD.enSelectedState[PORT_NO_0] == ENUM_PORTSTATE_SLAVE) &&
				 (pstClockData->stClock_GD.enSelectedState[PORT_NO_0] != pstCSSGlb->enSelectedState0_Old))
			{

				(VOID)ptpSubUSNs_USNs( &stCurrentDetailTime,  &gstLocalTime, &stLTInt_SNs );
				(VOID)ptpMultSNs_Doub( &stLTInt_SNs, gdbGmRateRatio, &stLTInt2_SNs );
				(VOID)ptpAddETS_SNs( &gstMasterTime, &stLTInt2_SNs, &stETimestamp );
				(VOID)ptpConvETS_USNs( &stETimestamp, &stB_USNs );
	
				gstCurrentMasterTime = stB_USNs;

				stCurrentMasterTime = stB_USNs;
			}

			(VOID)ptp_TimerSemUnLock();
			ptp_GetCurrentMasterTime2(pstClockData,
										&stCurrentMasterTime,
										&stCurrentDetailTime);
			(VOID)ptpSubUSNs_USNs(&stCurrentMasterTime,
									&stCurrentDetailTime,
									&stE_SNs);
			(VOID)ptpAddUSNs_SNs(&(pstClockData->stClock_GD.stSyncReceiptLocalTime),
									&stE_SNs,
									&stF_USNs);
			pstClockData->stClock_GD.stSyncReceiptCMTime = stF_USNs;

			ptp_dbg_msg(D_FUNC, ("stCurrentDetailTime =[%04x:%08x:%08x:%04x]\n"
				, stCurrentDetailTime.usNsec_msb, stCurrentDetailTime.ulNsec_2nd, stCurrentDetailTime.ulNsec_lsb, stCurrentDetailTime.usFrcNsec));

			offsetCurrentMasterTime_1588(pstClockData, pstPortData, &stCurrentMasterTime, FALSE);
#else
			pstClockData->stClock_GD.dbRateRatio = gdbGmRateRatio;

			offsetCurrentMasterTime_1588(pstClockData, pstPortData, &stCurrentMasterTime, FALSE);
#endif

		}

		txSRTimeToCMSO_1588(pstClockData);
	}


	pstCSSGlb->blRcvdPSSync			= FALSE;
	pstCSSGlb->blRcvdLocalClockTick	= FALSE;
	pstCSSGlb->enStatusCSS_1588	= ST_CSS_1588_SEND_SYNC_INDICAT;
	pstCSSGlb->enSelectedState0_Old = pstClockData->stClock_GD.enSelectedState[0];

	ptp_dbg_msg(D_DBG,
		("(E)pstCSSGlb->enSelectedState0_Old = [%d]\n", pstCSSGlb->enSelectedState0_Old));

	ptp_dbg_msg(D_FUNC, ("CSSync_1588_02::-\n"));
}




VOID	setSyncReceiptTime(
	CLOCKDATA*	pstClockData,
	PORTDATA*	pstPortData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	EXTENDEDTIMESTAMP	stC_ETStamp			= {0};


	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

		(VOID)ptpAddTS_SNs(&(pstRcvdPSSyncPtr->stPreciseOriginTimestamp),
							&(pstRcvdPSSyncPtr->stFollowUpCorrectionField),
							&stC_ETStamp);
		pstClockData->stClock_GD.stSyncReceiptTime = stC_ETStamp;

		pstClockData->stClock_GD.stSyncReceiptLocalTime = pstRcvdPSSyncPtr->stUpstreamTxTime;

}




BOOL	setSyncReceiptTime_1588(
	CLOCKDATA*	pstClockData,
	PORTDATA*	pstPortData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	USCALEDNS			stB_USNs			= {0};
	EXTENDEDTIMESTAMP	stC_ETStamp			= {0};
	EXTENDEDTIMESTAMP	stD_ETStamp			= {0};
#ifndef	PTP_USE_ME_HW_ASSIST
	DOUBLE				dbA_Ratio			= DBCONST1_0;
	TIME_INTERVAL		stB_TInt			= {0};
#endif
	PORT_1588_DS*		pstPortDS1588 = &pstPortData->stPort_1588_DS;
	BOOL				blRet				= FALSE;


	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

	if( pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE )
	{
		if ((IS_TIMESTAMP_0(pstPortData->stPort_GD.stDelayReqEgressTimestamp)) ||
			(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventEgressTimestamp)) ||
			(IS_TIMESTAMP_0(pstPortData->stPort_GD.stDelayReqIngressTimestamp)) ||
			(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventIngressTimestamp)))
		{
			PTP_NOTICE_LOGRECORD((pstPortData->pstClockData), PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000003);

		}
		else
		{
			blRet = TRUE;
		}

		(VOID)ptpAddTS_SNs(&(pstRcvdPSSyncPtr->stPreciseOriginTimestamp),
							&(pstRcvdPSSyncPtr->stFollowUpCorrectionField),
							&stC_ETStamp);
		(VOID)ptpAddETS_SNs(&stC_ETStamp,
								&(pstPortData->stPort_GD.stD3_DelayTime),
								&stD_ETStamp);
		(VOID)ptpAddETS_SNs(&stD_ETStamp,
								&(pstPortData->stPort_GD.stDelayAsymmetry),
								&stC_ETStamp);

		pstClockData->stClock_GD.stSyncReceiptTime = stC_ETStamp;


		(VOID)ptpConvTS_USNs(&(pstPortData->stPort_GD.stSyncEventIngressTimestamp),
								&stB_USNs);

		pstClockData->stClock_GD.stSyncReceiptLocalTime = stB_USNs;

	}
	else
	{
		if (IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventEgressTimestamp))
		{
			PTP_NOTICE_LOGRECORD((pstPortData->pstClockData), PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000005);

		}
		else
		{
			blRet = TRUE;
		}

#ifndef PTP_USE_ME_HW_ASSIST

		if ((pstPortData->stPort_GD.dbNeighborRateRatio > DBCONST_RATE_MIN) &&
			(pstPortData->stPort_GD.dbNeighborRateRatio < DBCONST_RATE_MAX))
		{
			dbA_Ratio = pstRcvdPSSyncPtr->dbRateRatio / pstPortData->stPort_GD.dbNeighborRateRatio;
		}
		else
		{
			dbA_Ratio = pstRcvdPSSyncPtr->dbRateRatio;
			PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000007);
		}

		(VOID)ptpMultTInt_Doub(&(pstPortDS1588->stPeerMeanPathDelay),
								dbA_Ratio,
								&stB_TInt);

#endif

		(VOID)ptpAddTS_SNs(&(pstRcvdPSSyncPtr->stPreciseOriginTimestamp),
							&(pstRcvdPSSyncPtr->stFollowUpCorrectionField),
							&stC_ETStamp);
		(VOID)ptpAddETS_TInt(&stC_ETStamp,
								&(pstPortDS1588->stPeerMeanPathDelay),
								&stD_ETStamp);
		(VOID)ptpAddETS_SNs(&stD_ETStamp,
								&(pstPortData->stPort_GD.stDelayAsymmetry),
								&stC_ETStamp);

		pstClockData->stClock_GD.stSyncReceiptTime = stC_ETStamp;


		(VOID)ptpConvTS_USNs(&(pstPortData->stPort_GD.stSyncEventIngressTimestamp),
								&stB_USNs);

		pstClockData->stClock_GD.stSyncReceiptLocalTime = stB_USNs;

	}
	return	blRet;
}




VOID	txSRTimeToCMSO_1588(
	CLOCKDATA*	pstClockData)
{
}




VOID	offsetCurrentMasterTime_1588(
	CLOCKDATA*		pstClockData,
	PORTDATA*		pstPortData,
	USCALEDNS*		pstNewCurrentMasterTime,
	BOOL			blT1T4ClrFlag)
{
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	DOUBLE				dbCMFrecRateCand	= DBCONST1_0;
	SCALEDNS			stA_SNs				= {0};
	SCALEDNS			stB_SNs				= {0};
	TIME_INTERVAL		stD_TInt			= {0};
	BOOL				blRet				= FALSE;
	USCALEDNS stUSNs = {0};
	USCALEDNS			stNeighborPropDelay	= {0};
	ULONG				ulPropDelayNumber ={0};

	ptp_dbg_msg(D_FUNC, ("offsetCurrentMasterTime_1588::+\n"));

	ptp_dbg_msg(D_DBG,
		("pstClockData->stClock_GD.dbRateRatio = [%f]\n", pstClockData->stClock_GD.dbRateRatio) );
	ptp_dbg_msg(D_DBG,
		("gdbGmRateRatio                       = [%f]\n", gdbGmRateRatio) );
	ptp_dbg_msg(D_DBG,
		("gstMasterTime                        = [%04x:%08x:%08x:%04x]\n"
		, gstMasterTime.stSec.usSec_msb, gstMasterTime.stSec.ulSec_lsb, gstMasterTime.stNsec.ulNsec, gstMasterTime.stNsec.usFrcNsec) );
	ptp_dbg_msg(D_DBG,
		("gstLocalTime                         = [%04x:%08x:%08x:%04x]\n"
		, gstLocalTime.usNsec_msb, gstLocalTime.ulNsec_2nd, gstLocalTime.ulNsec_lsb, gstLocalTime.usFrcNsec) );
	ptp_dbg_msg(D_DBG,
		("gstCurrentMasterTime                 = [%04x:%08x:%08x:%04x]\n"
		, gstCurrentMasterTime.usNsec_msb, gstCurrentMasterTime.ulNsec_2nd, gstCurrentMasterTime.ulNsec_lsb, gstCurrentMasterTime.usFrcNsec) );


	if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
	{
		(VOID)ptpSubETS_USNs_SNs(&(pstClockData->stClock_GD.stSyncReceiptTime),
								 &(pstClockData->stClock_GD.stSyncReceiptCMTime),
								 &stA_SNs);
	}
	else
	{
#ifndef	PTP_USE_ME_HW_ASSIST
		ptp_TimerSemLockWait();
		(VOID)ptpSubETS_USNs_SNs( &gstMasterTime, &gstCurrentMasterTime, &stA_SNs );



		(VOID)ptp_TimerSemUnLock();
#endif
	}
	pstCSSGlb->stCMPhaseOffsetCand = stA_SNs;

	(VOID)ptp2sComplementSNs(&pstCSSGlb->stCMPhaseOffsetCand,
								&stB_SNs);
	blRet = ptpConvSNs_TInt(&stB_SNs,
							&stD_TInt);
	if (blRet == FALSE)
	{
		SET_TIME_INTERVAL(stD_TInt, 0, 0, 0);
	}

	pstClockData->stCurrentDS.stOffsetFromMaster = stD_TInt;

	pstCSSGlb->dbCMFreqOffsetCand	= pstClockData->stClock_GD.dbRateRatio - DBCONST1_0;

	if (!IS_EPSILON0_0((pstCSSGlb->dbCMFreqOffsetCand + DBCONST1_0)))
	{
		dbCMFrecRateCand = DBCONST1_0 / (pstCSSGlb->dbCMFreqOffsetCand + DBCONST1_0);
	}


#ifdef	PTP_USERADJUST_EXTEND

	if (pstClockData->stCurrent_1588_DS.stMeanPathDelay.sNsec_msb >= 0)
	{
		SET_USCALEDNS(stNeighborPropDelay,
						0,
						((ULONG)pstClockData->stCurrent_1588_DS.stMeanPathDelay.sNsec_msb),
						pstClockData->stCurrent_1588_DS.stMeanPathDelay.ulNsec_lsb,
						pstClockData->stCurrent_1588_DS.stMeanPathDelay.usFrcNsec);
	}
	else
	{
		SET_USCALEDNS(stNeighborPropDelay,
						-1,
						((ULONG)((LONG)pstClockData->stCurrent_1588_DS.stMeanPathDelay.sNsec_msb)),
						pstClockData->stCurrent_1588_DS.stMeanPathDelay.ulNsec_lsb,
						pstClockData->stCurrent_1588_DS.stMeanPathDelay.usFrcNsec);
	}

	if (!pstPortData)
	{
		ulPropDelayNumber = 0;
		tsn_Wrapper_MemSet((VOID *)&stNeighborPropDelay, 0x00, sizeof(USCALEDNS));
		pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
	}
	else
	{
		if (pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
		{
			ulPropDelayNumber   = pstPortData->stPort_GD.ulPropDelayNumber;
			(VOID)ptpAddUSNs_TInt( &stUSNs, 
								   &pstClockData->stCurrent_1588_DS.stMeanPathDelay, 
								   &stNeighborPropDelay );
			if (pstClockData->stClock_GD.stDelayInfo.enClockDelay == DELAY_P2P)
			{
				pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.stSyncOriginTimeStamp = 
																pstPortData->stPort_GD.stSyncEventEgressTimestamp;
				pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P.stSyncCorrectionField = 
																pstPortData->stPort_GD.stSyncCorrectionField;
			}
		}
		else
		{
			ulPropDelayNumber = 0U;
			tsn_Wrapper_MemSet((VOID *)&stNeighborPropDelay, 0x00, sizeof(USCALEDNS));
			pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_DISABLED;
		}
	}
	
	
	pstClockData->stClock_GD.stDelayInfo.usSlavePortNumber = serchSlavePort(pstClockData);
	ptp_useradjust2( pstClockData->stDefaultDS.uchDomainNumber,
					 &(pstCSSGlb->stCMPhaseOffsetCand),
					 &dbCMFrecRateCand,
					 gpstBestDomain->stDefaultDS.uchDomainNumber,
					 &pstClockData->stParentDS,
					 &pstClockData->stCurrentDS,
					 &(pstClockData->stClock_GD.stDelayInfo),
					 &stNeighborPropDelay,
					 ulPropDelayNumber );




#else

	ptp_useradjust( pstClockData->stDefaultDS.uchDomainNumber,
					&(pstCSSGlb->stCMPhaseOffsetCand),
					&dbCMFrecRateCand,
					gpstBestDomain->stDefaultDS.uchDomainNumber );


#endif

#ifndef	PTP_USE_ME_HW_ASSIST

	gstCMPhaseOffset = pstCSSGlb->stCMPhaseOffsetCand;

	if (!IS_EPSILON0_0(dbCMFrecRateCand))
	{
		gdbCMFreqOffset	= (DBCONST1_0 / dbCMFrecRateCand) - DBCONST1_0;
		gdbRateRatio    = gdbCMFreqOffset + 1.0;
		gdbGmRateRatio  = gdbRateRatio;
	}

	ptp_dbg_msg(D_DBG,
		("(after useradjust)dbCMFrecRateCand                     = [%f]\n", dbCMFrecRateCand));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gdbRateRatio                         = [%f]\n", gdbRateRatio));
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gdbGmRateRatio                       = [%f]\n", gdbGmRateRatio));


	ptp_dbg_msg(D_DBG, ("(after useradjust)gstCMPhaseOffset = [%04x:%08x:%08x:%04x]\n", gstCMPhaseOffset.sNsec_msb, gstCMPhaseOffset.ulNsec_2nd, gstCMPhaseOffset.ulNsec_lsb, gstCMPhaseOffset.usFrcNsec) );


	if ( !IS_SCALEDNS_0(gstCMPhaseOffset) )
	{
		EXTENDEDTIMESTAMP	stMasterTimeW;

		ptp_SetCurrentMasterTime( pstClockData, &gstCMPhaseOffset, pstNewCurrentMasterTime );

		(VOID)ptpConvUSNs_ETS(pstNewCurrentMasterTime, &stMasterTimeW);

		ptp_SetMasterTime (pstClockData, &stMasterTimeW);


		SET_SCALEDNS(gstCMPhaseOffset, 0, 0, 0, 0);
		gdbCMFreqOffset		= DBCONST0_0;

		if ((pstPortData != NULL) && (blT1T4ClrFlag))
		{
			txBMCAupdtStatesTree_1588(pstClockData);
		}
	}
#else
	SET_SCALEDNS( gstCMPhaseOffset, 0, 0, 0, 0);
	gdbCMFreqOffset = DBCONST0_0;

	if ((pstPortData != NULL) && (blT1T4ClrFlag))
	{
		txBMCAupdtStatesTree_1588(pstClockData);
	}
#endif

	ptp_dbg_msg(D_DBG,
		("(after useradjust)gstCurrentMasterTime = [%04x:%08x:%08x:%04x]\n", gstCurrentMasterTime.usNsec_msb, gstCurrentMasterTime.ulNsec_2nd, gstCurrentMasterTime.ulNsec_lsb, gstCurrentMasterTime.usFrcNsec) );
	ptp_dbg_msg(D_DBG,
		("(after useradjust)gstMasterTime        = [%04x:%08x:%08x:%04x]\n", gstMasterTime.stSec.usSec_msb, gstMasterTime.stSec.ulSec_lsb, gstMasterTime.stNsec.ulNsec, gstMasterTime.stNsec.usFrcNsec) );

	ptp_dbg_msg(D_FUNC, ("offsetCurrentMasterTime_1588::-\n"));
}




VOID	txBMCAupdtStatesTree_1588(
	CLOCKDATA*	pstClockData)
{
#ifdef	PTP_USE_BMCA
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	PORTSYNCSYNC*		pstRcvdPSSyncPtr	= NULL;
	PORTDATA*			pstPortData			= NULL;

	pstRcvdPSSyncPtr = pstCSSGlb->pstRcvdPSSyncPtr;

	pstPortData = GetPstPortData_1588(pstClockData, pstRcvdPSSyncPtr->usLocalPortNumber);


	pstPortData->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_MASTER_SELECTED;
	if (pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE)
	{
#ifdef	PTP_USE_BMCA
		updtStatesTree(pstPortData);
#endif
	}
	else
	{
	}

#endif
}




DOUBLE computeCMFreqOffset_1588(
	CLOCKDATA*	pstClockData)
{
	CSSYNCSM_1588_GD*	pstCSSGlb			= GetCSSyncSM_1588_GD(pstClockData);
	SCALEDNS			stSubCMTimeFO		= {0};
	SCALEDNS			stSubSRTimeFO		= {0};
	SCALEDNS			stSubSRTimeFO_0		= {0};
	DOUBLE				dbClockCMFOffset	= DBCONST0_0;
	CHAR				chRet				= 0;
	USCALEDNS			stCurrentMasterTime	= {0};
	DOUBLE				dbClockCMRateRatio	= DBCONST1_0;
	BOOL				blRet				= FALSE;


	ptp_GetCurrentMasterTime(pstClockData, &stCurrentMasterTime);

	pstCSSGlb->stCurrentMasterTimeFOOld = pstCSSGlb->stCurrentMasterTimeFO;
	pstCSSGlb->stCMSyncReceiptTimeFOOld = pstCSSGlb->stCMSyncReceiptTimeFO;
	pstCSSGlb->stCurrentMasterTimeFO = stCurrentMasterTime;
	pstCSSGlb->stCMSyncReceiptTimeFO = pstClockData->stClock_GD.stSyncReceiptTime;

	if (pstCSSGlb->blCMFOffsetOld)
	{
		(VOID)ptpSubUSNs_USNs(&(pstCSSGlb->stCurrentMasterTimeFO),
								&(pstCSSGlb->stCurrentMasterTimeFOOld),
								&stSubCMTimeFO);

		(VOID)ptpSubETS_ETS(&(pstCSSGlb->stCMSyncReceiptTimeFO),
							 &(pstCSSGlb->stCMSyncReceiptTimeFOOld),
							 &stSubSRTimeFO);

		chRet = ptpCompSNs_SNs(&stSubCMTimeFO, &stSubSRTimeFO_0);

		if (chRet != COMP_EQUAL)
		{
			blRet = ptpDivSNs_SNs(&stSubCMTimeFO, &stSubSRTimeFO, &dbClockCMRateRatio);
			if (blRet == FALSE)
			{
				dbClockCMRateRatio = DBCONST1_0;
				PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000008);
			}
		}
		else
		{
			dbClockCMRateRatio = DBCONST1_0;
		}

		if (dbClockCMRateRatio >= DBCONST_RATE_MAX)
		{
			dbClockCMRateRatio = DBCONST1_0;
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000008);
		}
		else if (dbClockCMRateRatio <= DBCONST_RATE_MIN)
		{
			dbClockCMRateRatio = DBCONST1_0;
			PTP_WARNING_LOGRECORD(pstClockData, PTP_LOG_CSSYNCSM_1588, PTP_LOGVE_84000008);
		}
		else
		{
		}

		dbClockCMFOffset = dbClockCMRateRatio - DBCONST1_0;
	}

	pstCSSGlb->blCMFOffsetOld = TRUE;

	return dbClockCMFOffset;

}




ULONG	calcChangeEventLong_1588(USCALEDNS* pstCMUSNs)
{
	ULONG	ulChangeEvent;
	EXTENDEDTIMESTAMP	stCMETS ={0};
	ULONG	ulLSec	= 0;
	ULONG	ulNsec	= 0;


	(VOID)ptpConvUSNs_ETS(pstCMUSNs, &stCMETS);
	ulNsec = stCMETS.stNsec.ulNsec;
	ulLSec = stCMETS.stSec.ulSec_lsb;

	ulChangeEvent =  (ulLSec * CONST10_2) + (ulNsec / CONST10_7);

	return ulChangeEvent;
}




PORTDATA*	GetPstPortData_1588(
	CLOCKDATA*	pstClockData,
	USHORT		usPortNum)
{
	PORTDATA*	pstPortData	= pstClockData->pstPortData;


	while (pstPortData != NULL)
	{
		if (pstPortData->stPort_GD.usThisPort == usPortNum)
		{
			break;
		}
		pstPortData = pstPortData->pstNextPortDataPtr;
	}

	return	pstPortData;
}




#endif

