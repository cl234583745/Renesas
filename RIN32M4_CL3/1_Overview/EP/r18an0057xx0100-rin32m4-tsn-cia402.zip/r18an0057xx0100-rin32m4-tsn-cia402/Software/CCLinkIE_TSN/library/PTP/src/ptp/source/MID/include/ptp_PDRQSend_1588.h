/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PDRQSEND_1588_H__
#define __PTP_PDRQSEND_1588_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif

VOID	portDelayReqSend_1588(USHORT usEvent, PORTDATA* pstPortData);

PDRQSENDSM_1588_GD*		GetPDRQSendSM_1588_GD(PORTDATA* pstPortData);
EN_EV_PDRQS				GetPDRQSendSM_1588_Event(USHORT usEvent, PORTDATA* pstPortData);
BOOL					IsPDRQSendSM_1588_Status(PORTDATA*	pstPortData);

#ifdef __cplusplus
}
#endif


#endif


