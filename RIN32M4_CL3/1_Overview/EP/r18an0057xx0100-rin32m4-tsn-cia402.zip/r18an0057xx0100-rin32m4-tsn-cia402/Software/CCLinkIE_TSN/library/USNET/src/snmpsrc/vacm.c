//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================




#include "snmpv3.h"
#include "string.h"

typedef struct
{
    uint32 mask;
    const OID *oid;
} VIEW;

typedef struct
{
    const uint8 *group;
    const uint8 *context;
    const VIEW *readview;
    const VIEW *writeview;
    uint16 level;
} ACCESS;


static const OID sys_oid = {6, {0x2b, 6, 1, 2, 1, 1}};
static const OID mgmt_oid = {4, {0x2b, 6, 1, 2}};
static const OID snmp_oid = {4, {0x2b, 6, 1, 6}};
#ifdef USSW_LLDP_MIB
static const OID lldp_oid = {7, {0x2b, 111, 2, 134, 34, 1, 1}};
#endif
static const OID private_oid = {5, {0x2b, 6, 1, 4, 1}};



static const VIEW sys_view[] =
{
    {0xffffffff, &sys_oid},
    {0, 0}
};
static const VIEW mib2_view[] =
{
    {0xffffffff, &mgmt_oid},
    {0xffffffff, &snmp_oid},
    {0, 0}
};
static const VIEW admin_view[] =
{
    {0xffffffff, &mgmt_oid},
    {0xffffffff, &snmp_oid},
#ifdef USSW_LLDP_MIB
    {0xffffffff, &lldp_oid},
#endif
    {0xffffffff, &private_oid},
    {0, 0}
};



static const ACCESS vacmAccessTable[] =
{
#if defined(USM_MD5) || defined(USM_SHA) || defined(USM_DES)
    {(const uint8 *)"", (const uint8 *)"public", sys_view, 0, noAuthNoPriv},

    {(const uint8 *)"initial", (const uint8 *)"public", mib2_view, 0, noAuthNoPriv},

    {(const uint8 *)"admin-md5", (const uint8 *)"public", mib2_view, 0, noAuthNoPriv},
    {(const uint8 *)"admin-sha", (const uint8 *)"public", mib2_view, 0, noAuthNoPriv},

    {(const uint8 *)"admin-md5", (const uint8 *)"admin", admin_view, mib2_view, authNoPriv},
    {(const uint8 *)"admin-sha", (const uint8 *)"admin", admin_view, mib2_view, authNoPriv}
#else
    {(const uint8 *)"", (const uint8 *)"public", admin_view, 0, noAuthNoPriv},

    {(const uint8 *)"", (const uint8 *)"admin", admin_view, admin_view, noAuthNoPriv},
#endif
};

#define ACNUM ((sint16)(sizeof(vacmAccessTable) / sizeof(ACCESS)))


sint16 isAccessAllowed(const uint8 *securityName, uint16 securityLevel,
    uint8 type, const uint8 *contextName, const MIBVAR *mvp)
{
    const ACCESS *acp;
    const VIEW *vp;
    sint16 i1, i2;

    for (i1 = 0; i1 < ACNUM; i1++)
    {
        i2 = slength(vacmAccessTable[i1].context);
        if (sncompare(contextName, vacmAccessTable[i1].context, i2) == 0)
            break;
    }
    if (i1 == ACNUM)
        return noSuchContext;

    for (i1 = 0; i1 < ACNUM; i1++)
        if (scompare(securityName, vacmAccessTable[i1].group) == 0)
            break;
    if (i1 == ACNUM)
        return noGroupName;

    for (i1 = 0; i1 < ACNUM; i1++)
    {
        acp = &vacmAccessTable[i1];
        i2 = slength(acp->context);
        if (sncompare(acp->context, contextName, i2) == 0 &&
            scompare(acp->group, securityName) == 0 &&
            slength(acp->group) == slength(securityName) &&
            acp->level <= securityLevel)
        {
            if (type == AC_READ)
                vp = acp->readview;
            else if (type == AC_WRITE)
                vp = acp->writeview;
            else
                vp = 0;

            if (vp == 0 || vp->oid == 0)
                if (securityLevel == acp->level)
                    return noSuchView;
                else
                    continue;

            for ( ; vp->oid; vp++)
            {
                for (i2 = 0; i2 < vp->oid->nlen; i2++)
                {
                    if (vp->mask & ((uint32)1 << i2) &&
                        vp->oid->name[i2] - mvp->oid.name[i2])
                    {
                        break;
                    }
                }
                if (i2 == vp->oid->nlen)
                    return accessAllowed;
            }
            if (acp->level == securityLevel)
                return notInView;
        }
    }
    if (i1 == ACNUM)
        return noAccessEntry;

    return noSuchView;
}

