/**
 *******************************************************************************
 * @file  system_R_IN32M4_CL3.h
 * @brief sample program for R-IN32M4-CL3
 *
 * @note
 * Copyright (C) 2015 Renesas Electronics Corporation
 * Copyright (C) 2015 Renesas System Design Co., Ltd.
 *
 * @par
 *  This is a sample program.
 *  Mitsubishi Electric assumes no responsibility for any losses incurred. 
 *
 *******************************************************************************
 */
#ifndef __SYSTEM_R_IN32M4_CL3_H
#define __SYSTEM_R_IN32M4_CL3_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#if defined ( __ICCARM__ )
#include <arm_itm.h>
#endif

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
#define R_IN32M4_CL3_SYSCLK	100000000			/* System clock freq.(Hz) */
#define SYS_UART_CH		1					/* UART channel           */

#define RIN_PACKAGE_VERSION		"1.0.0"
#define RIN_DRIVER_VERSION		"1.1.0"
#define RIN_HWOS_VERSION		"2.0.3"

/*********************************************************************************/
/* Functions                                                                     */
/*********************************************************************************/
extern uint32_t SystemCoreClock;

extern void SystemInit(void);

extern void SystemCoreClockUpdate(void);

extern char *rin_package_get_version(uint8_t mode);
extern char *rin_driver_get_version(uint8_t mode);

#ifdef __cplusplus
}
#endif

#else
#endif
