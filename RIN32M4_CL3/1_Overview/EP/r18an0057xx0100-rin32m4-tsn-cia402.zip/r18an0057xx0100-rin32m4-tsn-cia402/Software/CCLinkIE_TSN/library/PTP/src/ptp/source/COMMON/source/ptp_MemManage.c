/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/



#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_tsn_Wrapper.h"
#include "ptp_api.h"
#include "ptp_LogRecord.h"
#include "ptp_bmca.h"

#include "ptp_MemManage.h"



MEMMANAGE_GD*	GetPTP_MManage_GD(CLOCKDATA*	pstClockData);
VOID*	ptp_MMPortAlloc(UCHAR	uchClockNumber);
VOID*	ptp_MMCTQueAlloc(UCHAR	uchClockNumber);
VOID*	ptp_MMAnnoAlloc(UCHAR	uchClockNumber);
VOID*	ptp_MMForeAlloc(UCHAR	uchClockNumber);
VOID	ptp_MMPortFree(UCHAR	uchClockNumber, PORTDATA*	pstPortData);
VOID	ptp_MMCTQueFree(UCHAR	uchClockNumber, CURRENTTIMEQUE*	pstCurrentTimeQue);
VOID	ptp_MMAnnoFree(UCHAR	uchClockNumber, ANNOUNCE_INFO*	pstAnnounceInfo);
VOID	ptp_MMForeFree(UCHAR	uchClockNumber, FOREIGN_MASTER_INFO*	pstForeignMasterInfo);
static VOID intLink( PTPMMLNK* pstPtpMMLnk );
VOID	attachLink(PTPMMLNK* pstPtpMMLnk, 	PTPMMLNK* pstPtpMMLnkAdd);
VOID	detachLink(PTPMMLNK* pstPtpMMLnk);

static VOID ptp_MMBeginPort( PTPMMPORTBLK* pstPtpMMPortBlk, 
                             CLOCKDATA*	   pstClockData, 
                             USHORT	       usPtpMMPortNum );
static VOID ptp_MMBeginClock( PTPMMPTPBLK* 	pstPtpMMPtpBlk,
							  UCHAR		    uchClockNumber,
							  USHORT		usPtpMMPortNum );





typedef	struct tagMEMMANAGE_BLK
{
	PTPMMPTPBLK*		pstPtpMMPtpBlkPtr;
	USHORT				usPtpMMClockMax;
	USHORT				usPtpMMPortMax;
} MEMMANAGE_BLK;


MEMMANAGE_BLK		gstMemManage_Blk = {0};

static PTPMMPTPBLK	gstPtp_MemArea;





BOOL	ptp_MMInit(
	UCHAR		uchClockNumber)
{
	BOOL				blRet 				= FALSE;
	ULONG				ulMMSize 			= 0;


	if (uchClockNumber != CLOCK_NUM_0)
	{
		return	blRet;
	}

	gstMemManage_Blk.usPtpMMClockMax	= MAX_CLOCK;
	gstMemManage_Blk.usPtpMMPortMax		= MAX_PORT;


 	gstMemManage_Blk.pstPtpMMPtpBlkPtr = &gstPtp_MemArea;

	ulMMSize = sizeof(gstPtp_MemArea);

	(VOID)tsn_Wrapper_MemSet((VOID*)gstMemManage_Blk.pstPtpMMPtpBlkPtr,
										0,
										(size_t)ulMMSize);

	blRet = TRUE;

	return	blRet;
}




static VOID ptp_MMBeginPort( PTPMMPORTBLK*	pstPtpMMPortBlk,
							 CLOCKDATA*		pstClockData,
							 USHORT			usPtpMMPortNum )
{
	UINT unIndex;
	PORTDATA* pstPortData;
	PORTDATA* pstPortDataPrev;

	pstPortDataPrev = pstClockData->pstPortData;
	for ( unIndex = 0U; unIndex < (UINT)usPtpMMPortNum; unIndex++ )
	{
		pstPortData  = &pstPtpMMPortBlk[unIndex].stPortData;

		pstPortData->pstNextPortDataPtr = &pstPtpMMPortBlk[unIndex+1].stPortData;
		pstPortData->pstPrevPortDataPtr = pstPortDataPrev;
		
		pstPortDataPrev = pstPortData;
	}
	pstPortData->pstNextPortDataPtr = NULL;
	
	return ;
}
static VOID ptp_MMBeginClock( PTPMMPTPBLK* 	pstPtpMMPtpBlk,
							  UCHAR		    uchClockNumber,
							  USHORT		usPtpMMPortNum )
{
	UINT unIndex;
	CLOCKDATA*		pstClockData;
	CLOCKDATA*		pstClockDataPrev;
	PTPMMPORTBLK*	pstPtpMMPortBlk;


	pstClockDataPrev  = gpstClockDataHPtr;

	for ( unIndex = 0U; unIndex < (UINT)uchClockNumber; unIndex++ )
	{
		pstClockData    = &pstPtpMMPtpBlk->stPtpMMClockBlk[unIndex].stClockData;
		pstPtpMMPortBlk = &pstPtpMMPtpBlk->stPtpMMPortBlk[unIndex * usPtpMMPortNum];
		if((unIndex+1) == uchClockNumber )
		{
			pstClockData->pstNextClockDataPtr = NULL;
		}
		else
		{
			pstClockData->pstNextClockDataPtr = &pstPtpMMPtpBlk->stPtpMMClockBlk[unIndex+1].stClockData;
		}
		pstClockData->pstPrevClockDataPtr = pstClockDataPrev;
		
		pstClockData->pstPortData     = &pstPtpMMPortBlk->stPortData;
		pstClockData->pstPortAddrInfo = &pstPtpMMPtpBlk->stPortAddrInfo;
		
		ptp_MMBeginPort( pstPtpMMPortBlk, pstClockData, usPtpMMPortNum );

		pstClockDataPrev = pstClockData;
	}

	return ;
}
BOOL	ptp_MMBegin(
	UCHAR		uchClockNumber,
	USHORT		usPtpMMPortNum )
{
	UINT unIndex;
	PTPMMPTPBLK* 	pstPtpMMPtpBlk;
	MEMMANAGE_GD*	pstPTPMMGlb;

	if (   (uchClockNumber < UCHCONST_1) 
	    || (uchClockNumber > (UCHAR)MAX_CLOCK) )
	{
		return	FALSE;
	}
	if (   (usPtpMMPortNum < USCONST_1) 
	    || (usPtpMMPortNum > (USHORT)MAX_PORT) )
	{
		return	FALSE;
	}

	pstPtpMMPtpBlk = gstMemManage_Blk.pstPtpMMPtpBlkPtr;
	
	gpstClockDataHPtr	= &pstPtpMMPtpBlk->stPtpMMClockBlk[0].stClockData;
	gpstCmldsPtr        = &pstPtpMMPtpBlk->stCmldsManage;

	gpstMdPdlyTspStk 				= &pstPtpMMPtpBlk->stMdPdlyTspStk[0];
	gpstCmldsPort_1AS_DS			= &pstPtpMMPtpBlk->stCmldsPort_1AS_DS[0];
	gpstCmldsPortStatistics_1AS_DS	= &pstPtpMMPtpBlk->stCmldsPortStatistics_1AS_DS[0];

	ptp_MMBeginClock( pstPtpMMPtpBlk, uchClockNumber, usPtpMMPortNum );

	pstPtpMMPtpBlk->stPortAddrInfo.pvAddrInfo = (VOID *)&pstPtpMMPtpBlk->stPtpMMPortAddrBlk;
	
	pstPTPMMGlb = GetPTP_MManage_GD(gpstClockDataHPtr);


	intLink( &pstPTPMMGlb->stPtpMMClockLnkH );
	for ( unIndex = (UINT)uchClockNumber; unIndex < MAX_CLOCK; unIndex++ )
	{
		attachLink( &pstPTPMMGlb->stPtpMMClockLnkH,
				    &pstPtpMMPtpBlk->stPtpMMClockBlk[unIndex].stPtpMmClockLnk );
	}

	intLink( &pstPTPMMGlb->stPtpMMPortLnkH );
	for ( unIndex = (UINT)usPtpMMPortNum * (UINT)uchClockNumber; 
		  unIndex < (MAX_CLOCK * MAX_PORT); 
		  unIndex++ )
	{
		attachLink( &pstPTPMMGlb->stPtpMMPortLnkH,
				    &pstPtpMMPtpBlk->stPtpMMPortBlk[unIndex].stPtpMmPortLnk );
	}

	intLink( &pstPTPMMGlb->stPtpMMTimeLnkH );

	for ( unIndex = 0U; unIndex < PTPMMTIMEBLK_NUM; unIndex++ )
	{
		attachLink( &pstPTPMMGlb->stPtpMMTimeLnkH,
				    &pstPTPMMGlb->stPtpMMTimeBlk[unIndex].stPtpMmTimeLnk );
	}

	intLink( &pstPTPMMGlb->stPtpMMAnnoLnkH );
	for ( unIndex = 0U; unIndex < PTPMMANNOBLK_NUM; unIndex++ )
	{
		attachLink( &pstPTPMMGlb->stPtpMMAnnoLnkH,
				    &pstPTPMMGlb->stPtpMMAnnoBlk[unIndex].stPtpMmAnnoLnk );
	}

	intLink( &pstPTPMMGlb->stPtpMMForeLnkH );
	for ( unIndex = 0U; unIndex < PTPMMFOREBLK_NUM; unIndex++ )
	{
		attachLink( &pstPTPMMGlb->stPtpMMForeLnkH,
				    &pstPTPMMGlb->stPtpMMForeBlk[unIndex].stPtpMmForeLnk );
	}

	ptp_LogRecordInit(gpstClockDataHPtr);

	return TRUE;
}



VOID*	ptp_MMalloc(
	UCHAR				uchClockNumber,
	PTPMMALLOCID		enPtpMMId)
{
	VOID*		pvTagPara = NULL;


	if (uchClockNumber != CLOCK_NUM_0)
	{
		return	pvTagPara;
	}

	if ((gstMemManage_Blk.pstPtpMMPtpBlkPtr == NULL) ||
		(gpstClockDataHPtr == NULL))
	{
		return	pvTagPara;
	}

	switch (enPtpMMId)
	{
		case PTP_MM_CLOCK:
			pvTagPara = NULL;
			break;

		case PTP_MM_PORT:
			pvTagPara = ptp_MMPortAlloc(uchClockNumber);
			break;

		case PTP_MM_CTQUE:
			pvTagPara = ptp_MMCTQueAlloc(uchClockNumber);
			break;

		case PTP_MM_ANNO:
			pvTagPara = ptp_MMAnnoAlloc(uchClockNumber);
			break;

		case PTP_MM_FORE:
			pvTagPara = ptp_MMForeAlloc(uchClockNumber);
			break;

		default:
			pvTagPara = NULL;
			break;
	}

	return	pvTagPara;
}




VOID	ptp_MMfree(
	UCHAR				uchClockNumber,
	PTPMMALLOCID		enPtpMMId,
	VOID*				pvPtpMMPtr)
{

	if (uchClockNumber != CLOCK_NUM_0)
	{
		return;
	}

	if (pvPtpMMPtr == NULL)
	{
		return;
	}

	if ((gstMemManage_Blk.pstPtpMMPtpBlkPtr == NULL) ||
		(gpstClockDataHPtr == NULL))
	{
		return;
	}

	switch (enPtpMMId)
	{
		case PTP_MM_CLOCK:
			break;

		case PTP_MM_PORT:
			ptp_MMPortFree(uchClockNumber, (PORTDATA*)pvPtpMMPtr);
			break;

		case PTP_MM_CTQUE:
			ptp_MMCTQueFree(uchClockNumber, (CURRENTTIMEQUE*)pvPtpMMPtr);
			break;

		case PTP_MM_ANNO:
			ptp_MMAnnoFree(uchClockNumber, (ANNOUNCE_INFO*)pvPtpMMPtr);
			break;

		case PTP_MM_FORE:
			ptp_MMForeFree(uchClockNumber, (FOREIGN_MASTER_INFO*)pvPtpMMPtr);
			break;

		default:
			break;
	}

}




BOOL	ptp_MMClose(
	UCHAR		uchClockNumber)
{
	BOOL				blRet 		= FALSE;
	ULONG				ulMMSize	= 0;


	if (uchClockNumber != CLOCK_NUM_0)
	{
		return	blRet;
	}

	if (gpstClockDataHPtr == NULL)
	{
		return	blRet;
	}

	ulMMSize = sizeof(gstPtp_MemArea);

	(VOID)tsn_Wrapper_MemSet((VOID*)gstMemManage_Blk.pstPtpMMPtpBlkPtr,
										0,
										(size_t)ulMMSize);

	(VOID)tsn_Wrapper_MemSet((VOID*)&gstLogRecord_GD, 0, sizeof(LOGRECORD_GD) );

	gpstClockDataHPtr					= NULL;

	blRet = TRUE;

	return	blRet;
}




LONG	ptp_SystemSemLockWait(
	CLOCKDATA*	pstClockData)
{
	LONG		lRet			= RET_ESTATE;
	VOID*		pvLockHandlePTP	= gpvLockHandlePTP;


	if (pvLockHandlePTP != NULL)
	{
		lRet = (LONG)tsn_Wrapper_LockWait(pvLockHandlePTP);
		if (lRet != RET_ENOERR)
		{
			PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_OSERROR);
			return	lRet;
		}
	}
	else
	{
		PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_RESPTRNULL);
		return	lRet;
	}

	lRet = RET_ENOERR;

	return	lRet;
}

LONG	ptp_SystemSemLock(
	CLOCKDATA*	pstClockData)
{
	LONG		lRet			= RET_ESTATE;
	VOID*		pvLockHandlePTP	= gpvLockHandlePTP;


	if (pvLockHandlePTP != NULL)
	{
		lRet = (LONG)tsn_Wrapper_Lock(pvLockHandlePTP);
		if ((lRet != RET_ENOERR) &&
			(lRet != RET_ETMO))
		{
			PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_OSERROR);
			return	lRet;
		}
	}
	else
	{
			PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_RESPTRNULL);
		return	lRet;
	}


	return	lRet;
}




LONG	ptp_SystemSemUnLock(
	CLOCKDATA*	pstClockData)
{
	LONG		lRet			= RET_ESTATE;
	VOID*		pvLockHandlePTP	= gpvLockHandlePTP;


	if (pvLockHandlePTP != NULL)
	{
		lRet = tsn_Wrapper_UnLock(pvLockHandlePTP);
		if (lRet != RET_ENOERR)
		{
			PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_OSERROR);
			return	lRet;
		}
	}
	else
	{
			PTP_EMERG_LOGRECORD (pstClockData, PTP_LOG_MEMMANAGE, PTP_LOGVE_RESPTRNULL);
		return	lRet;
	}

	lRet = RET_ENOERR;

	return	lRet;
}







MEMMANAGE_GD*	GetPTP_MManage_GD(
	CLOCKDATA*	pstClockData)
{

	MEMMANAGE_GD*	pstPTPMMGlb = &gstMemManage_GD;

	return pstPTPMMGlb;
}




VOID*	ptp_MMPortAlloc(
	UCHAR	uchClockNumber)
{
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	PORTDATA*			pstPortData			= NULL;
	PTPMMPORTBLK*		pstPtpMMPortBlk		= NULL;
	PTPMMLNK*			pstPtpMMPortLnk		= NULL;
	PTPMMLNK*			pstPtpMMPortLnkH	= NULL;


	pstClockData		= gpstClockDataHPtr;
	pstPTPMMGlb			= GetPTP_MManage_GD(pstClockData);
	pstPtpMMPortLnkH	= &(pstPTPMMGlb->stPtpMMPortLnkH);
	pstPtpMMPortLnk		= pstPTPMMGlb->stPtpMMPortLnkH.pstNextMmLnkPtr;

	if (pstPtpMMPortLnk != pstPtpMMPortLnkH)
	{
		pstPtpMMPortBlk = (PTPMMPORTBLK*)pstPtpMMPortLnk;
		pstPortData		= &(pstPtpMMPortBlk->stPortData);

		detachLink(pstPtpMMPortLnk);

	}

	return	(VOID*)pstPortData;
}




VOID*	ptp_MMCTQueAlloc(
	UCHAR	uchClockNumber)
{
	CURRENTTIMEQUE*		pstCurrentTimeQue	= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	PTPMMTIMEBLK*		pstPtpMMTimeBlk		= NULL;
	PTPMMLNK*			pstPtpMMTimeLnk		= NULL;
	PTPMMLNK*			pstPtpMMTimeLnkH	= NULL;


	pstClockData		= gpstClockDataHPtr;
	pstPTPMMGlb			= GetPTP_MManage_GD(pstClockData);

	pstPtpMMTimeLnkH	= &(pstPTPMMGlb->stPtpMMTimeLnkH);
	pstPtpMMTimeLnk		= pstPTPMMGlb->stPtpMMTimeLnkH.pstNextMmLnkPtr;

	if (pstPtpMMTimeLnk != pstPtpMMTimeLnkH)
	{
		pstPtpMMTimeBlk		= (PTPMMTIMEBLK*)pstPtpMMTimeLnk;
		pstCurrentTimeQue	= &(pstPtpMMTimeBlk->stCurrentTimeQue);

		detachLink(pstPtpMMTimeLnk);

	}

	return	(VOID*)pstCurrentTimeQue;
}

VOID*	ptp_MMAnnoAlloc(
	UCHAR	uchClockNumber)
{
	ANNOUNCE_INFO*		pstAnnounceInfo		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	PTPMMANNOBLK*		pstPtpMMAnnoBlk		= NULL;
	PTPMMLNK*			pstPtpMMAnnoLnk		= NULL;
	PTPMMLNK*			pstPtpMMAnnoLnkH	= NULL;


	pstClockData		= gpstClockDataHPtr;
	pstPTPMMGlb			= GetPTP_MManage_GD(pstClockData);

	pstPtpMMAnnoLnkH	= &(pstPTPMMGlb->stPtpMMAnnoLnkH);
	pstPtpMMAnnoLnk		= pstPTPMMGlb->stPtpMMAnnoLnkH.pstNextMmLnkPtr;

	if (pstPtpMMAnnoLnk != pstPtpMMAnnoLnkH)
	{
		pstPtpMMAnnoBlk		= (PTPMMANNOBLK*)pstPtpMMAnnoLnk;
		pstAnnounceInfo		= &(pstPtpMMAnnoBlk->stAnnounceInfo);

		detachLink(pstPtpMMAnnoLnk);

	}

	return	(VOID*)pstAnnounceInfo;
}

VOID*	ptp_MMForeAlloc(
	UCHAR	uchClockNumber)
{
	FOREIGN_MASTER_INFO* pstForeignMaterInfo = NULL;
	CLOCKDATA*			pstClockData		= NULL;
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	PTPMMFOREBLK*		pstPtpMMForeBlk		= NULL;
	PTPMMLNK*			pstPtpMMForeLnk		= NULL;
	PTPMMLNK*			pstPtpMMForeLnkH	= NULL;


	pstClockData		= gpstClockDataHPtr;
	pstPTPMMGlb			= GetPTP_MManage_GD(pstClockData);

	pstPtpMMForeLnkH	= &(pstPTPMMGlb->stPtpMMForeLnkH);
	pstPtpMMForeLnk		= pstPTPMMGlb->stPtpMMForeLnkH.pstNextMmLnkPtr;

	if (pstPtpMMForeLnk != pstPtpMMForeLnkH)
	{
		pstPtpMMForeBlk		= (PTPMMFOREBLK*)pstPtpMMForeLnk;
		pstForeignMaterInfo	= &(pstPtpMMForeBlk->stForeignMasterInfo);

		detachLink(pstPtpMMForeLnk);

	}

	return	(VOID*)pstForeignMaterInfo;
}




VOID	ptp_MMPortFree(
	UCHAR		uchClockNumber,
	PORTDATA*	pstPortData)
{
	USHORT				usCount				= 0;
	CLOCKDATA*			pstClockData		= NULL;
	PTPMMPORTBLK*		pstPtpMMPortBlk		= NULL;
	PTPMMLNK*			pstPtpMMPortLnk		= NULL;
	PTPMMLNK*			pstPtpMMPortLnkH	= NULL;
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;


	pstClockData	= gpstClockDataHPtr;
	pstPTPMMGlb		= GetPTP_MManage_GD(pstClockData);

	pstPtpMMPortBlk		= &(gstMemManage_Blk.pstPtpMMPtpBlkPtr->stPtpMMPortBlk[0]);
	for (usCount = 0; usCount < gstMemManage_Blk.usPtpMMPortMax; usCount++)
	{
		if (pstPortData == &(pstPtpMMPortBlk->stPortData))
		{
			pstPtpMMPortLnk		= &(pstPtpMMPortBlk->stPtpMmPortLnk);
			pstPtpMMPortLnkH	= &(pstPTPMMGlb->stPtpMMPortLnkH);
			attachLink(pstPtpMMPortLnkH, pstPtpMMPortLnk);
			break;

		}
		pstPtpMMPortBlk++;
	}

	return;
}




VOID	ptp_MMCTQueFree(
	UCHAR	uchClockNumber,
	CURRENTTIMEQUE*		pstCurrentTimeQue)
{
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	USHORT				usCount				= 0;
	PTPMMTIMEBLK*		pstPtpMMTimeBlk		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	PTPMMLNK*			pstPtpMMTimeLnk		= NULL;
	PTPMMLNK*			pstPtpMMTimeLnkH	= NULL;


	pstClockData	= gpstClockDataHPtr;
	pstPTPMMGlb		= GetPTP_MManage_GD(pstClockData);

	pstPtpMMTimeBlk = &(pstPTPMMGlb->stPtpMMTimeBlk[0]);
	for (usCount = 0; usCount < (USHORT)PTPMMTIMEBLK_NUM; usCount++)
	{
		if (pstCurrentTimeQue == &(pstPtpMMTimeBlk->stCurrentTimeQue))
		{
			pstPtpMMTimeLnk		= &(pstPtpMMTimeBlk->stPtpMmTimeLnk);
			pstPtpMMTimeLnkH	= &(pstPTPMMGlb->stPtpMMTimeLnkH);
			attachLink(pstPtpMMTimeLnkH, pstPtpMMTimeLnk);
			break;

		}
		pstPtpMMTimeBlk++;
	}

	return;
}

VOID	ptp_MMAnnoFree(
	UCHAR	uchClockNumber,
	ANNOUNCE_INFO*		pstAnnounceInfo)
{
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	USHORT				usCount				= 0;
	PTPMMANNOBLK*		pstPtpMMAnnoBlk		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	PTPMMLNK*			pstPtpMMAnnoLnk		= NULL;
	PTPMMLNK*			pstPtpMMAnnoLnkH	= NULL;

	pstClockData	= gpstClockDataHPtr;
	pstPTPMMGlb		= GetPTP_MManage_GD(pstClockData);

	pstPtpMMAnnoBlk = &(pstPTPMMGlb->stPtpMMAnnoBlk[0]);
	for (usCount = 0; usCount < (USHORT)PTPMMANNOBLK_NUM; usCount++)
	{
		if (pstAnnounceInfo == &(pstPtpMMAnnoBlk->stAnnounceInfo))
		{
			pstPtpMMAnnoLnk		= &(pstPtpMMAnnoBlk->stPtpMmAnnoLnk);
			pstPtpMMAnnoLnkH	= &(pstPTPMMGlb->stPtpMMAnnoLnkH);
			attachLink(pstPtpMMAnnoLnkH, pstPtpMMAnnoLnk);
			break;

		}
		pstPtpMMAnnoBlk++;
	}

	return;
}

VOID	ptp_MMForeFree(
	UCHAR	uchClockNumber,
	FOREIGN_MASTER_INFO* pstForeignMasterInfo)
{
	MEMMANAGE_GD*		pstPTPMMGlb 		= NULL;
	USHORT				usCount				= 0;
	PTPMMFOREBLK*		pstPtpMMForeBlk		= NULL;
	CLOCKDATA*			pstClockData		= NULL;
	PTPMMLNK*			pstPtpMMForeLnk		= NULL;
	PTPMMLNK*			pstPtpMMForeLnkH	= NULL;

	pstClockData	= gpstClockDataHPtr;
	pstPTPMMGlb		= GetPTP_MManage_GD(pstClockData);

	pstPtpMMForeBlk = &(pstPTPMMGlb->stPtpMMForeBlk[0]);
	for (usCount = 0; usCount < (USHORT)PTPMMFOREBLK_NUM; usCount++)
	{
		if (pstForeignMasterInfo == &(pstPtpMMForeBlk->stForeignMasterInfo))
		{
			pstPtpMMForeLnk		= &(pstPtpMMForeBlk->stPtpMmForeLnk);
			pstPtpMMForeLnkH	= &(pstPTPMMGlb->stPtpMMForeLnkH);
			attachLink(pstPtpMMForeLnkH, pstPtpMMForeLnk);
			break;

		}
		pstPtpMMForeBlk++;
	}

	return;
}

static VOID intLink( PTPMMLNK* pstPtpMMLnk )
{
	
	if ( pstPtpMMLnk == NULL )
	{
		return ;
	}
	pstPtpMMLnk->pstNextMmLnkPtr = pstPtpMMLnk;
	pstPtpMMLnk->pstPrevMmLnkPtr = pstPtpMMLnk;
	
	return ;
}

VOID	attachLink(
	PTPMMLNK* pstPtpMMLnk,
	PTPMMLNK* pstPtpMMLnkAdd)
{
	PTPMMLNK*			pstPtpMMLnkChk		= NULL;
	BOOL				blChkExist			= FALSE;


	for (pstPtpMMLnkChk = pstPtpMMLnk->pstNextMmLnkPtr;
			pstPtpMMLnkChk != pstPtpMMLnk;
			pstPtpMMLnkChk = pstPtpMMLnkChk->pstNextMmLnkPtr)
	{
		if (pstPtpMMLnkChk == pstPtpMMLnkAdd)
		{
			blChkExist = TRUE;
			break;
		}
	}

	if (blChkExist == FALSE)
	{
		pstPtpMMLnkAdd->pstNextMmLnkPtr	= pstPtpMMLnk->pstNextMmLnkPtr;
		pstPtpMMLnk->pstNextMmLnkPtr	= pstPtpMMLnkAdd;

		pstPtpMMLnkAdd->pstPrevMmLnkPtr	= pstPtpMMLnkAdd->pstNextMmLnkPtr->pstPrevMmLnkPtr;
		pstPtpMMLnkAdd->pstNextMmLnkPtr->pstPrevMmLnkPtr	= pstPtpMMLnkAdd;

	}
}




VOID	detachLink(
	PTPMMLNK* pstPtpMMLnk)
{

	pstPtpMMLnk->pstPrevMmLnkPtr->pstNextMmLnkPtr	= pstPtpMMLnk->pstNextMmLnkPtr;
	pstPtpMMLnk->pstNextMmLnkPtr->pstPrevMmLnkPtr	= pstPtpMMLnk->pstPrevMmLnkPtr;

}







