//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
#include "snmpv3.h"
#include "weather.h"

static sint16 mibindex(sint16 varix, sint16 tabix);
static void mibget(sint16 varix, sint16 tabix, uint8 **vvptr);
static sint16 mibset(sint16 varix, sint16 tabix);
static sint16 mibcheck(sint16 varix, sint16 tabix, const uint8 *inp);


char *location = "USSW";
int latitude = 5;
int longitude;
int altitude;
struct weatherTable weatherTable[]= {1} ;


static const MIBVAR mibvar[] =
{
    {{9,{0x2b,6,1,4,1,123,3,1,0}}, W+CAW, String, 0, &location},
    {{9,{0x2b,6,1,4,1,123,3,2,0}}, W+CAW, Integer, sizeof(int), &latitude},
    {{9,{0x2b,6,1,4,1,123,3,3,0}}, W+CAW+CAR, Integer, sizeof(int), &longitude},
    {{10,{0x2b,6,1,4,1,123,3,4,1,1}}, W+CAW+CAR, Integer, sizeof(int), &weatherTable[0].altitude},
};

static sint16 mibvarsize(void)
{
    return sizeof(mibvar) / sizeof(MIBVAR);
}

static const MIBTAB mibtab[] =
{
    {{8,{0x2b,6,1,4,1,123,3,4}}, 1,{Xaltitude}, sizeof(struct weatherTable)},
};

static sint16 mibtabsize(void)
{
    return sizeof(mibtab) / sizeof(MIBTAB);
}

const MIB mib_weather =
{
    mibvar,
    mibvarsize,
    mibtab,
    mibtabsize,
    mibget,
    mibset,
    mibindex,
    0,
    mibcheck
};

static void mibget(sint16 varix, sint16 tabix, uint8 **vvptr)
{

    switch (varix)
    {
    case 2:
        *(uint32 *)*vvptr = (uint32)7;
        break;
    default:
        break;
    }
}


static sint16 mibindex(sint16 varix, sint16 tabix)
{
    uint8 *cp;
    uint16 us1;
    sint16 i1;
    
    cp = (uint8 *)mibvar[varix].oid.name + 7;
    us1 = *cp++ << 8;
    us1 += *cp;
    
    if (varix > 3)
        return -1;

    switch (us1)
    {
    case 0x0100:
        if (tabix >= 4)
            goto lab2;
        goto lab1;

    case 0x0200:
        if (tabix >= 4)
            goto lab2;
        goto lab1;
        
    case 0x0300:
        if (tabix >= 4)
            goto lab2;
        goto lab1;
        
    case 0x040101:
        if (tabix >= 4)
            goto lab2;
        goto lab1;
        
    default:
        if (tabix >= 4)
            goto lab2;
            
        cp = (uint8 *)mibvar[varix].oid.name + 8;
        us1 = *cp++ << 8;
        us1 += *cp;

        if (us1 == 0x0101)
            goto lab1;
    }
    return 0;
lab1:
    return 1;
lab2:
    return -1;
    
}


static sint16 mibset(sint16 varix, sint16 tabix)
{
	
    uint8 *bytevp = mibvar[tabix].ptr;
    sint16 errcode = 0;

    if (tabix < 0)
        errcode = inconsistentValue;
    switch (varix)
    {
    case 3:
        if (*(uint32 *)*bytevp ==3 ) { 
            *(uint32 *)*bytevp = 0;
            return badValue;
        }
        break;
    default:
        break;
    }

    return errcode;
}

static sint16 mibcheck(sint16 varix, sint16 tabix, const uint8 *inp)
{
    uint32 ul1 = 0;
    sint16 i1;

    (void)tabix;

    if (varix == 1)
    {
        i1 = snmpReadInt(&ul1, sizeof(ul1), &inp, mibvar[varix].type);
        if (i1 < 0 || ul1 == 0 || ul1 > 11)
            return wrongValue;
    }
    return 0;
}
