/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTSTATESELECTION_H__
#define __PORTSTATESELECTION_H__

#include "ptp_Struct_Port.h"



#ifdef __cplusplus
extern "C" {
#endif


VOID 	portStateSelectionSM(USHORT usEvent, PORTDATA* pstPort);
VOID 	PortStateSelection_00(PORTDATA* pstPort);
VOID 	PortStateSelection_01(PORTDATA* pstPort);
VOID 	PortStateSelection_02(PORTDATA* pstPort);
VOID 	PortStateSelection_03(PORTDATA* pstPort);
VOID 	PortStateSelection_04(PORTDATA* pstPort);
VOID 	PortStateSelection_05(PORTDATA* pstPort);
VOID 	PortStateSelection_nop(PORTDATA* pstPort);
UCHAR	datasetCompalgorithm(BMCA_CMP_INF_DATA *pstCmpClkInfoA, BMCA_CMP_INF_DATA *pstCmpClkInfoB);
VOID	updtStateDisabledTree(PORTDATA *pstPort);
VOID	clearReselectTree(PORTDATA *pstPort);
VOID	setSelectedTree(PORTDATA *pstPort);
VOID	updtStatesTree(PORTDATA *pstPort);
UCHAR	statedecision (CLOCKDATA *pstClockData, PORTDATA *pstPort);
VOID	updateDsForGrandMaster(CLOCKDATA *pstClockData);
VOID	updateDsForGrandMasterAS(CLOCKDATA *pstClockData);
VOID	updateDsForslaveAS(PORTDATA *pstPort);
PSSELECTIONSM_EV	GetportStatSelectionEvent(USHORT usEvent);
VOID	updateDsForslave(CLOCKDATA *pstClockData);
VOID	updtStatesTree_AS(PORTDATA *pstPort);
VOID	updtStatesTree_1588(PORTDATA *pstPort);
BOOL	GetErbest(PORTDATA* pstPort);
VOID	stateMachine_1588(PORTDATA* pstPort, UCHAR uchBmcaEvent, BOOL blMasterChange);
VOID	getBmcaCmpDatFromAnno(BMCA_CMP_INF_DATA* pstBmcaCmpDat, PTPMSG_ANNOUNCE* pstAnnounceMessage, PORTDATA* pstPort);
VOID	getBmcaCmpDatFromAnno2(BMCA_CMP_INF_DATA* pstBmcaCmpDat, ANNO_CMP_INF_DATA* pstAnnoCmpInfo, PORTDATA* pstPort);
VOID	updateTimepropertiesDS_1588(PORTDATA *pstPort);
VOID	updateTimepropertiesDS_AS(PORTDATA *pstPort);
VOID	updateTimepropertiesDS_1588(PORTDATA *pstPort);
VOID	check_ASCapable(PORTDATA *pstPort, BOOL blAsCapable);
VOID 	PortStateSelection_06(PORTDATA* pstPort);
VOID 	PortStateSelection_07(PORTDATA* pstPort);
BOOL	cmpPortRcvAndGm(PORTDATA* pstPort);
BOOL	getBmcaCmpDatFromParentDS(PORTDATA* pstPort, BMCA_CMP_INF_DATA* pstBmcaCmpDat);
INT	compVector(PRIORITY_VECT* pstPriority1, PRIORITY_VECT* pstPriority2);
#ifdef __cplusplus
}
#endif

#endif
