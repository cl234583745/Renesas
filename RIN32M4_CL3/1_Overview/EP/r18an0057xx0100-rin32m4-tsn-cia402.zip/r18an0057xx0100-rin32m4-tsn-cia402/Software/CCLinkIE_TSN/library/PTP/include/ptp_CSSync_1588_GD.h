/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_CSSYNC_1588_GD_H__
#define __PTP_CSSYNC_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_CSS_1588 {
	ST_CSS_1588_NONE	= 0,
	ST_CSS_1588_INITIALIZING,
	ST_CSS_1588_SEND_SYNC_INDICAT,
	ST_CSS_1588_MAX
} EN_ST_CSS_1588;

typedef	enum	tagEN_EV_CSS_1588 {
	EV_CSS_1588_BEGIN = 0,
	EV_CSS_1588_FOR_CSS_RVPSYNC,
	EV_CSS_1588_FOR_CSS_RVLCLKTICK,
	EV_CSS_1588_CLOSE,
	EV_CSS_1588_EVENT_MAX
} EN_EV_CSS_1588;

typedef	struct tagCSSYNCSM_1588_GD
{
	EN_ST_CSS_1588	enStatusCSS_1588;
	BOOL			blRcvdPSSync;
	BOOL			blRcvdLocalClockTick;
	PORTSYNCSYNC	stRcvdPSSyncDat;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr;

	USCALEDNS			stCurrentMasterTimeFO;
	USCALEDNS			stCurrentMasterTimeFOOld;
	EXTENDEDTIMESTAMP	stCMSyncReceiptTimeFO;
	EXTENDEDTIMESTAMP	stCMSyncReceiptTimeFOOld;
	BOOL				blCMFOffsetOld;
	DOUBLE				dbCMFreqOffsetCand;
	SCALEDNS			stCMPhaseOffsetCand;
	ENUM_PORTSTATE		enSelectedState0_Old;
} CSSYNCSM_1588_GD;	




#endif


