//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "icmp.h"

#define IP_ICMP 1
#define IP_VER  4

extern struct NET nets[];
extern struct NETCONF netconf[];
extern struct CONNECT connblo[];
extern PTABLE  *const P_tab[];
extern PTABLE   ussICMPTable,
                ussIPTable;

#ifdef MIB2
struct ICMPgroup ICMPgroup;
#endif

#ifdef ICMP


static int opeN(int conno, int flags)
{
    return connblo[conno].protoc[1]->opeN(conno, flags);
}



static int closE(int conno)
{
    return connblo[conno].protoc[1]->closE(conno);
}


static int writE(int conno, MESS * mess)
{
    int             mlen;
    struct ICMPhdr *hdrp;

    hdrp = (struct ICMPhdr *) ((char *) mess + mess->offset);
#ifdef MIB2
    ICMPgroup.icmpOutMsgs++;
    if (hdrp->type < sizeof(ICMPgroup.icmptx) / sizeof(long))
        ICMPgroup.icmptx[hdrp->type]++;
#endif
    mlen = mess->mlen - mess->offset;
    hdrp->chksum = 0;
    if (mlen & 1)
        *((char *) hdrp + mlen) = 0;
    hdrp->chksum = ~Nchksum((unsigned short *) hdrp, (mlen + 1) / 2);
    *((char *) mess + MESSH_SZ + LHDRSZ + 9) = IP_ICMP;
    mess->id = bRELEASE;
    return ussIPTable.writE(conno, mess);
}

int ICMPreply(MESS * mess, int type, int scode)
{
    int             ihdrsz;
    struct ICMPhdr *icmpp;

    if (*(short *) ((char *) mess + MESSH_SZ + LHDRSZ + 6) & NC2(0x1fff))
        return -2;
    ihdrsz = (*((char *) mess + MESSH_SZ + LHDRSZ) & 0xf) << 2;
    mess->offset = MESSH_SZ + LHDRSZ + ihdrsz;
    icmpp = (struct ICMPhdr *) ((char *) mess + MESSH_SZ + LHDRSZ + ihdrsz);
    Nmemcpy((char *) &icmpp->param[1], (char *) mess + MESSH_SZ + LHDRSZ, ihdrsz + 8);
    icmpp->type = type;
    icmpp->scode = scode;
    *(short *) icmpp->param = 0;
    if ((type == 3) && (scode == 4))
        mess->mlen = 0;
    *((short *) icmpp->param + 1) = NC2(mess->mlen);
    mess->mlen = ihdrsz + 8 + MESSH_SZ + LHDRSZ + ihdrsz + ICMPhdr_SZ;
    return writE(-1, mess);
}


static int screen(MESS * mess)
{
    int             i1,
                    conno,
                    mlen,
                    confix,
                    confix2,
                    myport,
                    herport;
    Iid             iid;
    struct CONNECT *conp;
    struct ICMPhdr *hdrp;
    int ihdrsz;

#ifdef MIB2
    ICMPgroup.icmpInMsgs++;
#endif
    iid.l = TimeMS();

    hdrp = (struct ICMPhdr *) ((char *) mess + mess->offset);
    mlen = mess->mlen - mess->offset;

    if (mlen < ICMPhdr_SZ) {
        goto err1;
    }

    if (mlen & 1)
        *((char *) hdrp + mlen) = 0;
    if (Nchksum((unsigned short *) hdrp, (mlen + 1) / 2) != 0xffff)
        goto err1;

#ifdef MIB2
    if (hdrp->type < sizeof(ICMPgroup.icmprx) / sizeof(long))
        ICMPgroup.icmprx[hdrp->type]++;
#endif

    if (hdrp->type == IC_ECHO)
        goto lab2;


    for (conno = 0; conno < NCONNS; conno++) {
        conp = &connblo[conno];
        if (conp->blockstat == 0)
            continue;
        if (mess->target != conp->heriid.l &&
            conp->heriid.l != 0xffffffff &&
          conp->heriid.l != (mess->target | ~netconf[mess->confix].Imask.l))
            continue;
        if (conp->protoc[0] == &ussICMPTable)
            return conno;
    }

lab2:
#if NTRACE >= 2
    Nprintf("ICMP: type %d code %d\n", hdrp->type, hdrp->scode);
#endif
    switch (hdrp->type) {
    case IC_ECHO:
        hdrp->type = IC_EREP;
        mess->id = bRELEASE;
        if (writE(-1, mess))
            return -2;
        return -4;
    case IC_QUEN:
    case IC_TIMEX:
    case IC_UNRE:
    case IC_PARAM:
        i1 = *((char *) hdrp + 17);
        ihdrsz = (*((char *) hdrp + ICMPhdr_SZ) & 0xf) << 2;
        myport = *(unsigned short *) ((char *) hdrp + ICMPhdr_SZ + ihdrsz);
        herport = *(unsigned short *) ((char *) hdrp + ICMPhdr_SZ + ihdrsz + 2);
        Nmemcpy(iid.c, (char *) hdrp + ICMPhdr_SZ + 16, Iid_SZ);
        for (conno = 0; conno < NCONNS; conno++) {
            conp = &connblo[conno];
            if (conp->blockstat == 0 || conp->myport != myport ||
                conp->herport != herport)
                continue;
            if (mess->netno != conp->netno)
                continue;
            if (conp->protoc[0]->Eprotoc != i1)
                continue;
            if (iid.l != conp->heriid.l)
                continue;
            if (hdrp->type == IC_PARAM)
                conp->rxstat |= S_FATAL;
            else if (hdrp->type == IC_UNRE) {
                conp->rxstat |= S_UNREA;
                if (hdrp->scode >= 1 && hdrp->scode <= 4)
                    conp->rxstat |= S_FATAL;
                WAITNOMORE(SIG_RC(conno));
            } else if (hdrp->type == IC_TIMEX) {
                conp->rxstat |= S_TIMEX;
                WAITNOMORE(SIG_RC(conno));
            } else if (hdrp->type == IC_QUEN) {
                conp->wackslow = conp->wackmax / 2;
                if (conp->wackslow < MAXWACK)
                    conp->wackslow = MAXWACK;
                conp->wackmax = MAXWACK;
            }
            break;
        }
        return -2;
    case IC_REDI:
        Nmemcpy(iid.c, (char *) &hdrp->param[0], Iid_SZ);
        if ((confix = GetHostData(iid.l, 3, mess->netno)) < 0)
            break;

        Nmemcpy(iid.c, (char *) &hdrp->param[5], Iid_SZ);
        if ((confix2 = GetHostData(iid.l, 3, mess->netno)) < 0)
            break;

        if ( ussHostUsed(confix2) > 0 ) {
          ussHostAcquire(confix);
          if( netconf[confix2].nexthix !=
              confix2 )
            ussHostRelease( netconf[confix2].nexthix);
        }

        netconf[confix2].nexthix = confix;
        return -2;
    case IC_TIMEQ:
        if ((netconf[nets[mess->netno].confix].flags & TIMESERVER) == 0)
            break;
        hdrp->type = IC_TIMER;
        PUTLONG(iid, hdrp->param[2]);
        mess->id = bRELEASE;
        iid.l = TimeMS();
        PUTLONG(iid, hdrp->param[3]);
        if (writE(-1, mess))
            return -2;
        return -4;
    case IC_TIMER:
        GETLONG(iid, hdrp->param[2]);
        SetTimeMS(iid.l);
        return -2;
    }
err1:
#ifdef MIB2
    ICMPgroup.icmpInErrors++;
#endif
    return -1;
}



static MESS *reaD(int conno)
{
    return ussIPTable.reaD(conno);
}



static int init(int netno, char *params)
{
    (void) netno, (void) params;
#ifdef MIB2
    memset(&ICMPgroup, 0, sizeof(ICMPgroup));
#endif
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;

    return ussErrInval;
}



GLOBALCONST
PTABLE ussICMPTable = {
    "ICMP", init, 0, screen, opeN, closE, reaD, writE, ioctl, IP_ICMP, 0
};

#endif
