/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588

#include "MDSyncCommonSM.h"


BOOL SetMDSyncCorrectionPortIngress(MDSRECEIVESM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*			pstPortMD  = &pstPort->stPortMD_GD;
	PTPMSG_SYNC_1588*	pstMsg	= &pstPortMD->stConSync_1588;
	USHORT				usSrchSeqId	= pstMsg->stHeader.usSequenceId;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	pstClockGD->stSynCorctionClock.stCrrctionPort.usSequenceId = usSrchSeqId;
	tsn_Wrapper_MemCpy(&pstClockGD->stSynCorctionClock.stCrrctionPort.stIngressTimestamp,
		&pstSmGbl->stSyncIngTimestamp,
		sizeof(pstClockGD->stSynCorctionClock.stCrrctionPort.stIngressTimestamp));
	tsn_Wrapper_MemCpy(&pstClockGD->stSynCorctionClock.stConSync_1588,
		pstMsg, sizeof(pstClockGD->stSynCorctionClock.stConSync_1588));

	pstClockGD->stSynCorctionClock.stCrrctionPort.blFlg = TRUE;

	return TRUE;
}

BOOL SetMDSyncFollowUpCtPortIngress(PORTDATA* pstPort)
{
	PORTMD_GD*			pstPortMD  = &pstPort->stPortMD_GD;
	PTPMSG_FOLLOWUP_1588*	pstMsg	= &pstPortMD->stConFollowUp_1588;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	if (pstClockGD->stSynCorctionClock.stCrrctionPort.blFlg)
	{
		tsn_Wrapper_MemCpy(&pstClockGD->stSynCorctionClock.stConFollowUp_1588,
			pstMsg, sizeof(pstClockGD->stSynCorctionClock.stConFollowUp_1588));

	}
	return TRUE;
}

BOOL SetMDSyncCorrectionPortEgress(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;


	if (pstClockGD->stSynCorctionClock.stCrrctionPort.blFlg)
	{
		tsn_Wrapper_MemCpy(&pstClockGD->stSynCorctionClock.stCrrctionPort.stEgressTimestamp,
			&pstSmGbl->stSyncEgTimestamp,
			sizeof(TIMESTAMP));

		return TRUE;
	}

	return FALSE;
}

#endif
