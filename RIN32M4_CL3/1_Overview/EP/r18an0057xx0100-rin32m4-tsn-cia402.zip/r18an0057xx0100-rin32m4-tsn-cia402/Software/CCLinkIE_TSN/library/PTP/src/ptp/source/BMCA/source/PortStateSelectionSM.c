/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_tsn_Wrapper.h"
#include "ptp_Struct_Port.h"
#include "ptp_bmca.h"
#include "ptp_Macro.h"
#include "ptp_LogRecord.h"

#include "PortStateSelectionSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "PortAnnounceReceiveSM.h"
#include "ptp_LCEntity.h"

#define	GRANDMASTER_CLOCKCLASS_LOW	127

#define	OWN_STEPSREMOVED			0
#define	OWN_PORTNUMBER				0

#define	REALSTATE_TO_1588STATE_OFS	(-2)


#define D_FUNC	0
#define D_VALID	0

VOID (*const PortStateSelectionSM_Matrix[PSSELECTIONSM_ST_MAX][PSSELECTIONSM_EV_MAX])(PORTDATA* pstPortData) =
{
	{&PortStateSelection_01, &PortStateSelection_nop, &PortStateSelection_nop, &PortStateSelection_nop, &PortStateSelection_00, &PortStateSelection_06, &PortStateSelection_07},
	{&PortStateSelection_01, &PortStateSelection_nop, &PortStateSelection_05,  &PortStateSelection_nop, &PortStateSelection_00, &PortStateSelection_06, &PortStateSelection_07},
	{&PortStateSelection_01, &PortStateSelection_03 , &PortStateSelection_05,  &PortStateSelection_03,	&PortStateSelection_00, &PortStateSelection_06, &PortStateSelection_07}
};

UCHAR	uchExtStatEvtToNewStateNorm[PS_EX_MAX_NORM_STAT][EXT_EV_MAX] = {
	{PS_EX_DISABLED , PS_EX_LISTENING,	 PS_EX_LISTENING, PS_EX_LISTENING,	  PS_EX_LISTENING,	  PS_EX_LISTENING, PS_EX_LISTENING,  PS_EX_LISTENING,	 PS_EX_LISTENING, PS_EX_LISTENING},
	{PS_EX_DISABLED , PS_EX_FAULTY,		 PS_EX_FAULTY,	  PS_EX_LISTENING,	  PS_EX_FAULTY,		  PS_EX_FAULTY,    PS_EX_FAULTY, 	 PS_EX_FAULTY,		 PS_EX_FAULTY,	  PS_EX_FAULTY},
	{PS_EX_DISABLED , PS_EX_LISTENING,	 PS_EX_DISABLED,  PS_EX_DISABLED,	  PS_EX_DISABLED,	  PS_EX_DISABLED,  PS_EX_DISABLED,	 PS_EX_DISABLED, 	 PS_EX_DISABLED,  PS_EX_DISABLED},
	{PS_EX_DISABLED , PS_EX_LISTENING,	 PS_EX_FAULTY,	  PS_EX_LISTENING,	  PS_EX_LISTENING,	  PS_EX_MASTER,	   PS_EX_PRE_MASTER, PS_EX_UNCALIBRATED, PS_EX_PASSIVE,	  PS_EX_LISTENING},
	{PS_EX_DISABLED , PS_EX_PRE_MASTER,	 PS_EX_FAULTY,	  PS_EX_PRE_MASTER,   PS_EX_MASTER,		  PS_EX_MASTER,	   PS_EX_PRE_MASTER, PS_EX_UNCALIBRATED, PS_EX_PASSIVE,	  PS_EX_PRE_MASTER},
	{PS_EX_DISABLED , PS_EX_MASTER,		 PS_EX_FAULTY,	  PS_EX_MASTER,	  	  PS_EX_MASTER,	  	  PS_EX_MASTER,	   PS_EX_MASTER,	 PS_EX_UNCALIBRATED, PS_EX_PASSIVE,	  PS_EX_MASTER},
	{PS_EX_DISABLED , PS_EX_PASSIVE,	 PS_EX_FAULTY,	  PS_EX_PASSIVE,	  PS_EX_PASSIVE,	  PS_EX_MASTER,	   PS_EX_PRE_MASTER, PS_EX_UNCALIBRATED, PS_EX_PASSIVE,	  PS_EX_PASSIVE},
	{PS_EX_DISABLED , PS_EX_UNCALIBRATED,PS_EX_FAULTY,	  PS_EX_UNCALIBRATED, PS_EX_UNCALIBRATED, PS_EX_MASTER,	   PS_EX_PRE_MASTER, PS_EX_UNCALIBRATED, PS_EX_PASSIVE,	  PS_EX_SLAVE},
	{PS_EX_DISABLED , PS_EX_SLAVE,		 PS_EX_FAULTY,	  PS_EX_SLAVE,		  PS_EX_SLAVE,		  PS_EX_MASTER,	   PS_EX_PRE_MASTER, PS_EX_SLAVE, 		 PS_EX_PASSIVE,	  PS_EX_SLAVE}

};


ENUM_PORTSTATE	uchStatEvtToNewStateNorm[PS_EX_MAX_NORM_STAT][EXT_EV_MAX] = {
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_MASTER,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_MASTER,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_MASTER,  ENUM_PORTSTATE_MASTER,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_MASTER,   ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_MASTER},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_SLAVE,	  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,   ENUM_PORTSTATE_SLAVE,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_SLAVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_SLAVE,	  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,   ENUM_PORTSTATE_SLAVE,	ENUM_PORTSTATE_MASTER,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_SLAVE}
};

UCHAR	uchExtStatEvtToNewStateSlave[PS_EX_MAX_NORM_STAT][EXT_EV_MAX] = {
	{PS_EX_DISABLED,  PS_EX_LISTENING,	 PS_EX_LISTENING, PS_EX_LISTENING,	  PS_EX_LISTENING,	  PS_EX_LISTENING, PS_EX_LISTENING,	PS_EX_LISTENING,	PS_EX_LISTENING, PS_EX_LISTENING},
	{PS_EX_DISABLED,  PS_EX_FAULTY,		 PS_EX_FAULTY,	  PS_EX_LISTENING,	  PS_EX_FAULTY,		  PS_EX_FAULTY,    PS_EX_FAULTY, 	PS_EX_FAULTY,		PS_EX_FAULTY,	 PS_EX_FAULTY},
	{PS_EX_DISABLED,  PS_EX_LISTENING,	 PS_EX_DISABLED,  PS_EX_DISABLED,	  PS_EX_DISABLED,	  PS_EX_DISABLED,  PS_EX_DISABLED,	PS_EX_DISABLED, 	PS_EX_DISABLED,  PS_EX_DISABLED},
	{PS_EX_DISABLED,  PS_EX_LISTENING,	 PS_EX_FAULTY,	  PS_EX_LISTENING,	  PS_EX_LISTENING,	  PS_EX_LISTENING, PS_EX_LISTENING,	PS_EX_UNCALIBRATED,	PS_EX_LISTENING, PS_EX_LISTENING},
	{PS_EX_DISABLED,  PS_EX_DISABLED,  	 PS_EX_DISABLED,  PS_EX_DISABLED,	  PS_EX_DISABLED,	  PS_EX_DISABLED,  PS_EX_DISABLED,	PS_EX_DISABLED,		PS_EX_DISABLED,	 PS_EX_DISABLED},
	{PS_EX_DISABLED,  PS_EX_DISABLED,  	 PS_EX_DISABLED,  PS_EX_DISABLED,	  PS_EX_DISABLED,	  PS_EX_DISABLED,  PS_EX_DISABLED,	PS_EX_DISABLED,		PS_EX_DISABLED,	 PS_EX_DISABLED},
	{PS_EX_DISABLED,  PS_EX_DISABLED,  	 PS_EX_DISABLED,  PS_EX_DISABLED,	  PS_EX_DISABLED,	  PS_EX_DISABLED,  PS_EX_DISABLED,	PS_EX_DISABLED,		PS_EX_DISABLED,	 PS_EX_DISABLED},
	{PS_EX_DISABLED,  PS_EX_UNCALIBRATED, PS_EX_FAULTY,	  PS_EX_UNCALIBRATED, PS_EX_UNCALIBRATED, PS_EX_LISTENING, PS_EX_LISTENING,	PS_EX_UNCALIBRATED, PS_EX_LISTENING, PS_EX_SLAVE},
	{PS_EX_DISABLED,  PS_EX_SLAVE,		 PS_EX_FAULTY,	  PS_EX_SLAVE,		  PS_EX_SLAVE,		  PS_EX_LISTENING, PS_EX_LISTENING,	PS_EX_SLAVE, 		PS_EX_LISTENING, PS_EX_SLAVE}
};

UCHAR	uchStatEvtToNewStateSlave[PS_EX_MAX_NORM_STAT][EXT_EV_MAX] = {
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE, ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE,	 ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_PASSIVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,	ENUM_PORTSTATE_DISABLED},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,	ENUM_PORTSTATE_DISABLED},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_DISABLED,	ENUM_PORTSTATE_DISABLED},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_SLAVE,	  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,   ENUM_PORTSTATE_SLAVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_SLAVE},
	{ENUM_PORTSTATE_DISABLED, ENUM_PORTSTATE_SLAVE,	  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,   ENUM_PORTSTATE_SLAVE,	ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_PASSIVE,  ENUM_PORTSTATE_SLAVE,    ENUM_PORTSTATE_PASSIVE,	ENUM_PORTSTATE_SLAVE}
};

VOID	portStateSelectionSM(USHORT usEvent, PORTDATA *pstPort)
{
	PSSELECTIONSM_GD*	pstSMGlb;
	PSSELECTIONSM_EV	enEvt;

	CLOCKDATA*	pstClock;

	enEvt =	GetportStatSelectionEvent(usEvent);

	if (enEvt == PSSE_EV_SYSTEMIDENTITYCHANGE)
	{
		pstClock = pstPort->pstClockData;
		pstSMGlb = &(pstClock->pstPortData->stPSSelectionSM_GD);
		
		if ((pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration) == TRUE)
		{
			makeSystemPrioVector(pstPort);
			updtPortState(pstPort);
		}
	}
	else
	{
		pstSMGlb = &(pstPort->stPSSelectionSM_GD);
	}

	if (enEvt < PSSE_EV_EVENT_MAX)
	{
		if (pstSMGlb->enStatus < PSSE_STATUS_MAX)
		{
			(*PortStateSelectionSM_Matrix[pstSMGlb->enStatus][enEvt])(pstPort);
			return;
		}
	}
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PSSELECTIONSM, (ULONG)PTP_LOGVE_81000003);

}

PSSELECTIONSM_EV	GetportStatSelectionEvent(USHORT usEvent)
{
	PSSELECTIONSM_EV	enEvt;
	switch (usEvent)
	{
		case (USHORT)PTP_EV_BEGIN:
			enEvt = PSSE_EV_BEGIN;
			break;
		case (USHORT)PTP_EV_RESELECT_PORT:
			enEvt = PSSE_EV_RESELECT_PORT;
			break;
		case (USHORT)PTP_EV_SYSTEMIDENTITYCHANGE:
			enEvt = PSSE_EV_SYSTEMIDENTITYCHANGE;
			break;
		case (USHORT)PTP_EV_ASYMMESUREMODECHANGE:
			enEvt = PSSE_EV_ASYMMETRYMESUREMODECHG;
			break;
		case (USHORT)PTP_EV_CLOSE:
			enEvt = PSSE_EV_CLOSE;
			break;
		case (USHORT)PTP_EV_ASCAPABLE:
			enEvt = PSSE_EV_ASCAPABLE_ON;
			break;
		case (USHORT)PTP_EV_ASCAPABLE_OFF:
			enEvt = PSSE_EV_ASCAPABLE_OFF;
			break;
		default:
			enEvt = PSSE_EV_EVENT_MAX;
		break;
	}
	return(enEvt);
}

VOID	PortStateSelection_00(PORTDATA *pstPort)
{
	PSSELECTIONSM_GD*	pstSMGlb;
#ifdef	PTP_USE_IEEE1588
	BOOL				blRet;
#endif

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PortStateSelection_00",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstSMGlb	 = &(pstPort->stPSSelectionSM_GD);

	pstSMGlb->enStatus = PSSE_INIT_BRIDGE;

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
#ifdef	PTP_USE_IEEE1588
		if (pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstTOQualification != NULL)
		{
			blRet = (BOOL)ptp_TimeOut_Can(pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstTOQualification);
			if (blRet)
			{
				PTP_ERROR_LOGRECORD(pstPort->pstClockData, (USHORT)PTP_LOG_PSSELECTIONSM, (ULONG)PTP_LOGVE_81000023);
			}
			pstPort->stUn_Port_GD.stPortBMC_1588_GD.pstTOQualification = NULL;
		}
#endif
	}

	ptp_dbg_msg( D_FUNC, ("PortStateSelection_00::-\n") );

}

VOID	PortStateSelection_01(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGD;
	PSSELECTIONSM_GD*	pstSMGlb;

	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);
	pstSMGlb	 = &(pstPort->stPSSelectionSM_GD);

	ptp_dbg_msg( D_FUNC, ("PortStateSelection_01::+\n") );

	if (!(pstBmcGD->blExternalPortConfiguration))
	{
		pstSMGlb->enStatus = PSSE_INIT_BRIDGE;

		PortStateSelection_04(pstPort);
	}

	ptp_dbg_msg( D_FUNC, ("PortStateSelection_01::-\n") );
}

VOID	PortStateSelection_03(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGD;
	PSSELECTIONSM_GD*	pstSMGlb;
	
	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);
	pstSMGlb	 = &(pstPort->stPSSelectionSM_GD);

	pstSMGlb->blSystemIdentityChange = FALSE;
	pstSMGlb->blAasymmetryMeasurModeChange = FALSE;

	clearReselectTree(pstPort);

	if (!(pstBmcGD->blExternalPortConfiguration))
	{
#ifdef	PTP_USE_BMCA
		updtStatesTree(pstPort);
#endif

		selBestDomain( );
	}

	setSelectedTree(pstPort);
}

VOID	PortStateSelection_04(PORTDATA *pstPort)
{
	PSSELECTIONSM_GD*	pstSMGlb;

	pstSMGlb	 = &(pstPort->stPSSelectionSM_GD);

	updtStateDisabledTree(pstPort);

	pstSMGlb->enStatus = PSSE_STATE_SELECTION;
}

VOID	PortStateSelection_05(PORTDATA *pstPort)
{


	makeSystemPrioVector(pstPort);

	PortStateSelection_03(pstPort);

	if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE)
	{
#ifdef	PTP_USE_BMCA
		exec_PortAnnInfo04_allPort(pstPort);
#endif
	}

}


VOID	PortStateSelection_06(PORTDATA *pstPort)
{
		check_ASCapable(pstPort, TRUE);
}

VOID	PortStateSelection_07(PORTDATA *pstPort)
{
		check_ASCapable(pstPort, FALSE);
}

VOID	updtStateDisabledTree(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGD;
	CLOCK_GD	*pstClockGD;
	DEFAULT_DS	*pstDefaultDS;

	USHORT		usLoopCnt;

	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);
	pstClockGD	 = &(pstPort->pstClockData->stClock_GD);
	pstDefaultDS = &(pstPort->pstClockData->stDefaultDS);

	for(usLoopCnt=0; usLoopCnt < (USHORT)PTP_MAX_PORT_NUMBER; usLoopCnt++)
	{
		pstClockGD->enSelectedState[usLoopCnt] = ENUM_PORTSTATE_DISABLED;

	}

	tsn_Wrapper_MemSet (&pstBmcGD->stLastGmPriority, (INT)0xff, sizeof(PRIORITY_VECT));

	pstBmcGD->uchPathTraceCount = 1;
	tsn_Wrapper_MemCpy (&pstBmcGD->stPathTrace[0], &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
}

VOID	clearReselectTree(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGD;
	USHORT		usLoopCnt;

	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);

	for(usLoopCnt=0; usLoopCnt <= (USHORT)PTP_MAX_PORT_NUMBER; usLoopCnt++)
	{
		pstBmcGD->blReselect[usLoopCnt] = FALSE;
	}

}

VOID	setSelectedTree(PORTDATA *pstPort)
{
	BMC_GD*		pstBmcGD;
	USHORT		usLoopCnt;

	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);

	for(usLoopCnt=0; usLoopCnt <= (USHORT)PTP_MAX_PORT_NUMBER; usLoopCnt++)
	{
		pstBmcGD->blSelected[usLoopCnt] = TRUE;
	}

}

#ifdef	PTP_USE_BMCA
VOID	updtStatesTree(PORTDATA *pstPort)
{
	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		updtStatesTree_AS(pstPort);
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE1588
		updtStatesTree_1588(pstPort);
#endif
	}
}

#ifdef	PTP_USE_IEEE802_1
VOID	updtStatesTree_AS(PORTDATA *pstPort)
{
	BMC_GD		*pstBmcGD;
	PRIORITY_VECT stGmPathPriorityVector;
	CLOCK_GD	*pstClockGD;
	USHORT		usPortNumber;
	PORTBMC_GD	*pstPortBmcGD = NULL;
	PORTBMC_GD	*pstPortBmcGD_GmPathPrio = NULL;
	DEFAULT_DS	*pstDefaultDS;
	PORT_GD*	pstPortGd;

	BOOL		blGmEqSystem;

	LONG		lCmpRet;
	PORTDATA	*pstPortWork;
	pstPortWork = pstPort->pstClockData->pstPortData;

	pstClockGD	= &(pstPort->pstClockData->stClock_GD);
	pstBmcGD	= &(pstPort->pstClockData->stBMC_GD);
	pstPortGd	= &(pstPort->stPort_GD);

	pstPortBmcGD = &(pstPort->stPortBMC_GD);

	pstDefaultDS = &(pstPort->pstClockData->stDefaultDS);

	tsn_Wrapper_MemCpy (&pstBmcGD->stLastGmPriority, &pstBmcGD->stGmPriority, sizeof(PRIORITY_VECT));

	tsn_Wrapper_MemSet (&stGmPathPriorityVector, (INT)0xff, sizeof(PRIORITY_VECT));

	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(gm Path PriorityVector). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			pstPortBmcGD = &(pstPortWork->stPortBMC_GD);

			if (pstPortBmcGD->enInfoIs == RECEIVED)
			{
				pstPortBmcGD->stGmPathPriority = pstPortBmcGD->stPortPriority;
				pstPortBmcGD->stGmPathPriority.usStepsRemoved++;
				lCmpRet = tsn_Wrapper_MemCmp(&pstPortBmcGD->stGmPathPriority.stSourcePortIdentity, &pstPortWork->pstClockData->stDefaultDS.stClockIdentity, sizeof(CLOCKIDENTITY));
				if (lCmpRet != 0)
				{

					lCmpRet = compVector(&pstPortBmcGD->stGmPathPriority, &stGmPathPriorityVector);
					if (lCmpRet < 0)
					{
						tsn_Wrapper_MemCpy(&stGmPathPriorityVector, &pstPortBmcGD->stGmPathPriority, sizeof(PRIORITY_VECT));
						pstPortBmcGD_GmPathPrio = pstPortBmcGD;
					}
				}
			}
		}

		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}
	
	if (pstPortBmcGD_GmPathPrio != NULL) {
		lCmpRet = compVector(&stGmPathPriorityVector, &pstBmcGD->stSystemPriority);
	}
	else {
		lCmpRet = 0;
	}
	if (lCmpRet < 0)
	{
		tsn_Wrapper_MemCpy (&pstBmcGD->stGmPriority, &stGmPathPriorityVector, sizeof(PRIORITY_VECT));

		pstBmcGD->blLeap61 = pstPortBmcGD_GmPathPrio->blAnnLeap61;
		pstBmcGD->blLeap59 = pstPortBmcGD_GmPathPrio->blAnnLeap59;
		pstBmcGD->blCurrentUtcOffsetValid = pstPortBmcGD_GmPathPrio->blAnnCurrentUtcOffsetValid;
		pstBmcGD->blPtpTimescale = pstPortBmcGD_GmPathPrio->blAnnPtpTimescale;
		pstBmcGD->blTimeTraceable = pstPortBmcGD_GmPathPrio->blAnnTimeTraceable;
		pstBmcGD->blFrequencyTraceable = pstPortBmcGD_GmPathPrio->blAnnFrequencyTraceable;
		pstBmcGD->sCurrentUtcOffset = pstPortBmcGD_GmPathPrio->sAnnCurrentUtcOffset;
		pstBmcGD->uchTimeSource = pstPortBmcGD_GmPathPrio->uchAnnTimeSource;

		blGmEqSystem = FALSE;
	}
	else
	{
		tsn_Wrapper_MemCpy (&pstBmcGD->stGmPriority, &(pstBmcGD->stSystemPriority), sizeof(PRIORITY_VECT));

		pstBmcGD->blLeap61 = pstBmcGD->blSysLeap61;
		pstBmcGD->blLeap59 = pstBmcGD->blSysLeap59;
		pstBmcGD->blCurrentUtcOffsetValid = pstBmcGD->blSysCurrentUTCOffsetValid;
		pstBmcGD->blPtpTimescale = pstBmcGD->blSysPtpTimescale;
		pstBmcGD->blTimeTraceable = pstBmcGD->blSysTimeTraceable;
		pstBmcGD->blFrequencyTraceable = pstBmcGD->blSysFrequencyTraceable;
		pstBmcGD->sCurrentUtcOffset = pstBmcGD->sSysCurrentUtcOffset;
		pstBmcGD->uchTimeSource = pstBmcGD->uchSysTimeSource;

		blGmEqSystem = TRUE;
	}

	pstPortWork = pstPort->pstClockData->pstPortData;

	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(masterPriorityVector). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			if (blGmEqSystem)
			{
				tsn_Wrapper_MemCpy(&pstPortWork->stPortBMC_GD.stMasterPriority, &pstBmcGD->stSystemPriority, sizeof(PRIORITY_VECT));
				tsn_Wrapper_MemCpy(&pstPortWork->stPortBMC_GD.stMasterPriority.stSourcePortIdentity, &pstPortWork->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));
				pstPortWork->stPortBMC_GD.stMasterPriority.usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;
				pstPortWork->stPortBMC_GD.usMessageStepsRemoved = 0;
			}
			else
			{
				tsn_Wrapper_MemCpy(&pstPortWork->stPortBMC_GD.stMasterPriority, &stGmPathPriorityVector, sizeof(PRIORITY_VECT));
				tsn_Wrapper_MemCpy(&pstPortWork->stPortBMC_GD.stMasterPriority.stSourcePortIdentity, &pstPortWork->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));
				pstPortWork->stPortBMC_GD.stMasterPriority.usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;
				pstPortWork->stPortBMC_GD.usMessageStepsRemoved = stGmPathPriorityVector.usStepsRemoved;
			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	if (pstPortBmcGD_GmPathPrio != NULL) {
		lCmpRet = tsn_Wrapper_MemCmp(&pstBmcGD->stGmPriority.stRootSystemIdentity.stClockIdentity, &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
	}
	else {
		lCmpRet = 0;
	}
	if (lCmpRet)
	{
		pstBmcGD->usMasterStepsRemoved = pstPortBmcGD_GmPathPrio->usMessageStepsRemoved;
	}
	else
	{
		pstBmcGD->usMasterStepsRemoved = 0;
	}

	pstPortWork = pstPort->pstClockData->pstPortData;

	
	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			pstPortBmcGD = &(pstPortWork->stPortBMC_GD);
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

			if (pstPortBmcGD->enInfoIs == DISABLED)
			{
				pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_DISABLED;
			}

			if (pstPortGd->blAsymmetryMeasurementMode == TRUE)
			{
				pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_PASSIVE;
				pstPortBmcGD->blUpdtInfo = FALSE;
			}

			if (pstPortBmcGD->enInfoIs == AGED)
			{
				pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_MASTER;
				pstPortBmcGD->blUpdtInfo = TRUE;
			}

			if (pstPortBmcGD->enInfoIs == MINE)
			{
				pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_MASTER;

				lCmpRet = compVector(&pstPortBmcGD->stMasterPriority, &pstPortBmcGD->stPortPriority);

				if (lCmpRet)
				{
					pstPortBmcGD->blUpdtInfo = TRUE;
				}
				else
				{
					if (pstPortBmcGD->usPortStepsRemoved != pstBmcGD->usMasterStepsRemoved)
					{
						pstPortBmcGD->blUpdtInfo = TRUE;
					}
				}
			}

			if (pstPortBmcGD->enInfoIs == RECEIVED)
			{
				if (pstBmcGD->stGmPriority.usPortNumber == pstPortBmcGD->stPortPriority.usPortNumber)
				{
					pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_SLAVE;
					pstPortBmcGD->blUpdtInfo = FALSE;
				}
				else
				{
					lCmpRet = compVector(&pstPortBmcGD->stMasterPriority, &pstPortBmcGD->stPortPriority);
					if (lCmpRet >= 0)
					{
						pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_PASSIVE;
						pstPortBmcGD->blUpdtInfo = FALSE;
					}
					else
					{
						pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_MASTER;
						pstPortBmcGD->blUpdtInfo = TRUE;
					}
				}
			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	if (pstBmcGD->stGmPriority.stRootSystemIdentity.uchPriority1 < 255)
	{
		pstClockGD->blGmPresent = TRUE;
	}
	else
	{
		pstClockGD->blGmPresent = FALSE;
	}

	pstPortWork = pstPort->pstClockData->pstPortData;

	pstClockGD->enSelectedState[0] = ENUM_PORTSTATE_SLAVE;
	
	while (pstPortWork != NULL)
	{
		usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(port0 SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			if (pstClockGD->enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
			{
				pstClockGD->enSelectedState[0] = ENUM_PORTSTATE_PASSIVE;
				break;
			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	if (pstClockGD->enSelectedState[0] == ENUM_PORTSTATE_PASSIVE)
	{
		updateDsForslaveAS(pstPort);
	}
	else
	{
		updateDsForGrandMasterAS(pstPort->pstClockData);
		tsn_Wrapper_MemCpy(&pstBmcGD->stPathTrace[0], &pstPort->stPortDS.stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
		pstBmcGD->uchPathTraceCount = (UCHAR)1;
	}
}
#endif

#ifdef	PTP_USE_IEEE1588
VOID	updtStatesTree_1588(PORTDATA *pstPort)
{
	CLOCK_GD	*pstClockGD;
	USHORT		usPortNumber;
	PORTBMC_GD	*pstPortBmcGD;

	UCHAR		uchRet;
	PORTDATA	*pstPortWork;

	PORTBMC_1588_GD	*pstPortBmc1588GD;

	BMC_1588_GD	*pstBmc1588GD;

	UCHAR		uchBmcaEvent = (UCHAR)EXT_EV_MAX + (UCHAR)1;

	BOOL		blMasterChange = FALSE;
	BOOL		blRet = 0;

	INT			nRet = 0;

	static	CLOCKIDENTITY	stOldGmClockId;

	pstPortBmc1588GD = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);

	pstClockGD	= &(pstPort->pstClockData->stClock_GD);
	pstPortBmcGD = &(pstPort->stPortBMC_GD);

	pstBmc1588GD = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	uchBmcaEvent = pstPortBmc1588GD->enBmca1588Evnet;

	if (uchBmcaEvent == (UCHAR)EXT_EV_ANNOUNCE_RECEIPT_TIMEOUT_EXPIRES)
	{
		pstPortBmcGD->blUpdtInfo = TRUE;
	}


	if (uchBmcaEvent < (UCHAR)EXT_EV_MAX) {
		stateMachine_1588(pstPort, uchBmcaEvent, 0);
	}

	blMasterChange = GetErbest(pstPort);

	tsn_Wrapper_MemCpy(&stOldGmClockId, (const void *)&pstPort->pstClockData->stParentDS.stGrandmasterIdentity, sizeof(CLOCKIDENTITY));

	pstPortWork = pstPort->pstClockData->pstPortData;

	while(pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

			if (pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] != ENUM_PORTSTATE_DISABLED)
			{

				uchRet = statedecision (pstPortWork->pstClockData, pstPortWork);

				if((uchRet == (UCHAR)STATE_M1) || (uchRet == (UCHAR)STATE_M2))
				{
					updateDsForGrandMaster(pstPortWork->pstClockData);
					uchBmcaEvent = (UCHAR)EXT_EV_RS_MASTER;
				}
				else if (uchRet == (UCHAR)STATE_S1)
				{
					updateDsForslave(pstPortWork->pstClockData);
					uchBmcaEvent = (UCHAR)EXT_EV_RS_SLAVE;
				}
				else if (uchRet == (UCHAR)STATE_M3)
				{
					uchBmcaEvent = (UCHAR)EXT_EV_RS_MASTER;
				}
				else if(uchRet == (UCHAR)STATE_L)
				{
					pstBmc1588GD->uchExtSelectedState[usPortNumber] = (UCHAR)PS_EX_LISTENING;
					pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_PASSIVE;
					uchBmcaEvent = (UCHAR)EXT_EV_MAX;
				}
				else
				{
					uchBmcaEvent = (UCHAR)EXT_EV_RS_PASSIVE;
				}

				if (uchBmcaEvent < (UCHAR)EXT_EV_MAX)
				{
					stateMachine_1588(pstPortWork, uchBmcaEvent, blMasterChange);
				}

				pstPortBmc1588GD->enBmca1588Evnet = (BMCA_1588_EVT)EXT_EV_MAX;

				if(pstBmc1588GD->uchExtSelectedState[usPortNumber] == (UCHAR)PS_EX_PRE_MASTER)
				{
					if( (uchRet == (UCHAR)STATE_M3) && (!(pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)) )
					{
					}
					else
					{
						pstBmc1588GD->uchExtSelectedState[usPortNumber] = (UCHAR)PS_EX_MASTER;
						pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_MASTER;
					}
				}
				else
				{
					pstPortBmc1588GD = &pstPortWork->stUn_Port_GD.stPortBMC_1588_GD;

					if (pstPortBmc1588GD->pstTOQualification)
					{
						blRet = (BOOL)ptp_TimeOut_Can(pstPortBmc1588GD->pstTOQualification);
						if (blRet != RET_ENOERR)
						{
							PTP_ERROR_LOGRECORD(pstPortWork->pstClockData, (USHORT)PTP_LOG_PSSELECTIONSM, (ULONG)PTP_LOGVE_81000023);
						}
					}
					pstPortBmc1588GD->pstTOQualification = NULL;
				}

			}
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
		pstPortBmcGD = &pstPortWork->stPortBMC_GD;
	}

	pstPortWork = pstPort->pstClockData->pstPortData;

	pstClockGD->enSelectedState[0] = ENUM_PORTSTATE_SLAVE;

	while (pstPortWork != NULL)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(port0 SelectedState). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

			if (pstClockGD->enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
			{
				if (pstBmc1588GD->uchExtSelectedState[usPortNumber] == (UCHAR)PS_EX_SLAVE)
				{
					nRet = tsn_Wrapper_MemCmp(&stOldGmClockId,
						(const VOID *)&pstPort->pstClockData->stParentDS.stGrandmasterIdentity, sizeof(CLOCKIDENTITY));
					if (nRet)
					{
						pstBmc1588GD->uchExtSelectedState[usPortNumber] = (UCHAR)PS_EX_UNCALIBRATED;
						pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_PASSIVE;
					}
				}
				pstClockGD->enSelectedState[0] = ENUM_PORTSTATE_PASSIVE;
			}

			if(pstBmc1588GD->uchExtSelectedState[usPortNumber] == (UCHAR)PS_EX_PRE_MASTER)
			{
				set_qualification_tmo_1588(pstPortWork);
			}
		}

		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	if ((pstClockGD->enSelectedState[0] == ENUM_PORTSTATE_SLAVE) && (pstPort->pstClockData->stBMC_GD.blPathTraceEnable))
	{
		tsn_Wrapper_MemCpy(&pstPort->pstClockData->stBMC_GD.stPathTrace[0], &pstPort->stPortDS.stPortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
		pstPort->pstClockData->stBMC_GD.uchPathTraceCount = (UCHAR)1;
	}
}


UCHAR	datasetCompalgorithm(BMCA_CMP_INF_DATA *pstCmpClkInfoA, BMCA_CMP_INF_DATA *pstCmpClkInfoB)
{
	LONG		lCmpRet;
	UCHAR		uchRet;
	
	
	if ((pstCmpClkInfoA == NULL) && (pstCmpClkInfoB != NULL))
	{
		uchRet = (UCHAR)B_BETTER;
	}
	else if ((pstCmpClkInfoA != NULL) && (pstCmpClkInfoB == NULL))
	{
		uchRet = (UCHAR)A_BETTER;
	}
	else if ((pstCmpClkInfoA == NULL) && (pstCmpClkInfoB == NULL))
	{
		uchRet = A_B_EQUAL;
	}
	else
	{
		lCmpRet = tsn_Wrapper_MemCmp(&pstCmpClkInfoA->stClockIdentity, &pstCmpClkInfoB->stClockIdentity, sizeof(CLOCKIDENTITY));

		if (lCmpRet == 0)
		{
			if (pstCmpClkInfoA->usStepsRemoved + 1 < pstCmpClkInfoB->usStepsRemoved)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->usStepsRemoved > pstCmpClkInfoB->usStepsRemoved + 1)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (pstCmpClkInfoA->usStepsRemoved > pstCmpClkInfoB->usStepsRemoved)
			{
				lCmpRet = tsn_Wrapper_MemCmp(&pstCmpClkInfoA->stSenderPort.stClockIdentity,
					&pstCmpClkInfoA->stReceiverPort.stClockIdentity, sizeof(CLOCKIDENTITY));
				if (lCmpRet == 0)
				{
					uchRet = EQUAL;
				}
				else if (lCmpRet < 0)
				{
					uchRet = (UCHAR)B_BETTER_TOPO;
				}
				else
				{
					uchRet = (UCHAR)B_BETTER;
				}
			}
			else if (pstCmpClkInfoA->usStepsRemoved < pstCmpClkInfoB->usStepsRemoved)
			{
				lCmpRet = tsn_Wrapper_MemCmp(&pstCmpClkInfoB->stSenderPort.stClockIdentity,
					&pstCmpClkInfoB->stReceiverPort.stClockIdentity, sizeof(CLOCKIDENTITY));
				if (lCmpRet == 0)
				{
					uchRet = EQUAL;
				}
				else if (lCmpRet < 0)
				{
					uchRet = (UCHAR)A_BETTER_TOPO;
				}
				else
				{
					uchRet = (UCHAR)A_BETTER;
				}
			}
			else
			{
				lCmpRet = tsn_Wrapper_MemCmp(&pstCmpClkInfoA->stSenderPort.stClockIdentity,
					&pstCmpClkInfoB->stSenderPort.stClockIdentity, sizeof(CLOCKIDENTITY));
				if (lCmpRet < 0)
				{
					uchRet = (UCHAR)A_BETTER_TOPO;
				}
				else if (lCmpRet > 0)
				{
					uchRet = (UCHAR)B_BETTER_TOPO;
				}
				else
				{
					if (pstCmpClkInfoA->stReceiverPort.usPortNumber < pstCmpClkInfoB->stReceiverPort.usPortNumber)
					{
						uchRet = (UCHAR)A_BETTER_TOPO;
					}
					else if (pstCmpClkInfoA->stReceiverPort.usPortNumber > pstCmpClkInfoB->stReceiverPort.usPortNumber)
					{
						uchRet = (UCHAR)B_BETTER_TOPO;
					}
					else
					{
						uchRet = EQUAL;
					}
				}
			}
		}
		else
		{
			if (pstCmpClkInfoA->uchPriority1 < pstCmpClkInfoB->uchPriority1)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->uchPriority1 > pstCmpClkInfoB->uchPriority1)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.uchClockClass < pstCmpClkInfoB->stClockQuality.uchClockClass)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.uchClockClass > pstCmpClkInfoB->stClockQuality.uchClockClass)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.uchClockAccuracy < pstCmpClkInfoB->stClockQuality.uchClockAccuracy)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.uchClockAccuracy > pstCmpClkInfoB->stClockQuality.uchClockAccuracy)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.usOffsetScaledLogVariance < pstCmpClkInfoB->stClockQuality.usOffsetScaledLogVariance)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->stClockQuality.usOffsetScaledLogVariance > pstCmpClkInfoB->stClockQuality.usOffsetScaledLogVariance)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (pstCmpClkInfoA->uchPriority2 < pstCmpClkInfoB->uchPriority2)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else if (pstCmpClkInfoA->uchPriority2 > pstCmpClkInfoB->uchPriority2)
			{
				uchRet = (UCHAR)B_BETTER;
			}
			else if (lCmpRet < 0)
			{
				uchRet = (UCHAR)A_BETTER;
			}
			else
			{
				uchRet = (UCHAR)B_BETTER;
			}
		}
	}
	return uchRet;
}

UCHAR statedecision (CLOCKDATA *pstClockData, PORTDATA *pstPort)
{
	BMC_1588_GD	*pstBmc1588GD;
	PORTBMC_1588_GD	*pstPortBmc1588GD;
	UCHAR		uchPortStat;
	UCHAR		uchRet;
	UCHAR		uchCmpRet;
	DEFAULT_DS	*pstDefaultDS;
	USHORT		usPortNumber;

	BMCA_CMP_INF_DATA	*pstClockBest;
	BMCA_CMP_INF_DATA	*pstPortBest;
	BMCA_CMP_INF_DATA	stDefaultDsBest;


	pstPortBmc1588GD = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);
	pstBmc1588GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	pstDefaultDS = &(pstClockData->stDefaultDS);

	if (pstPortBmc1588GD->pstForeignBestClock)
	{
		pstPortBest = &(pstPortBmc1588GD->pstForeignBestClock->stBmcaCmpDat);
	}
	else
	{
		pstPortBest = NULL;
	}

	if (pstBmc1588GD->pstClkForeignBestClock)
	{
		pstClockBest = &(pstBmc1588GD->pstClkForeignBestClock->stBmcaCmpDat);
	}
	else
	{
		pstClockBest = NULL;
	}

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;
	uchPortStat = pstBmc1588GD->uchExtSelectedState[usPortNumber];

	if((pstPortBest==NULL)&&(uchPortStat == (UCHAR)PS_EX_LISTENING))
	{
		uchRet = (UCHAR)STATE_L;
	}
	else
	{
		stDefaultDsBest.uchPriority1 = pstDefaultDS->uchPriority1;
		tsn_Wrapper_MemCpy (&stDefaultDsBest.stClockIdentity,
									&pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
		tsn_Wrapper_MemCpy (&stDefaultDsBest.stClockQuality,
									&pstDefaultDS->stClockQuality, sizeof(CLOCKQUALITY));
		stDefaultDsBest.uchPriority2 = pstDefaultDS->uchPriority2;
		stDefaultDsBest.usStepsRemoved = OWN_STEPSREMOVED;
		tsn_Wrapper_MemCpy (&stDefaultDsBest.stSenderPort.stClockIdentity,
									&pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
		stDefaultDsBest.stSenderPort.usPortNumber = OWN_PORTNUMBER;
		tsn_Wrapper_MemCpy (&stDefaultDsBest.stReceiverPort.stClockIdentity,
									&pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));
		stDefaultDsBest.stReceiverPort.usPortNumber = OWN_PORTNUMBER;

		if(pstDefaultDS->stClockQuality.uchClockClass <= GRANDMASTER_CLOCKCLASS_LOW)
		{
			uchCmpRet = datasetCompalgorithm(&stDefaultDsBest, pstPortBest);
			
			if(uchCmpRet == (UCHAR)A_BETTER)
			{
				uchRet = STATE_M1;
			}
			else
			{
				uchRet = (UCHAR)STATE_P1;
			}
		}
		else
		{
			uchCmpRet = datasetCompalgorithm(&stDefaultDsBest, pstClockBest);

			if(uchCmpRet == (UCHAR)A_BETTER)
			{
				uchRet = (UCHAR)STATE_M2;
			}
			else if (pstPortBest == NULL)
			{
				uchRet = (UCHAR)STATE_M3;
			}
			else if (pstClockBest->stReceiverPort.usPortNumber == pstPortBest->stReceiverPort.usPortNumber)
			{
				uchRet = (UCHAR)STATE_S1;
			}
			else
			{
				uchCmpRet = datasetCompalgorithm(pstClockBest, pstPortBest);

				if(uchCmpRet == (UCHAR)A_BETTER_TOPO)
				{
					uchRet = (UCHAR)STATE_P2;
				}
				else
				{
					uchRet = (UCHAR)STATE_M3;
				}
			}
		}
	}
	return uchRet;
}
#endif
#endif
#ifdef	PTP_USE_IEEE1588

VOID	updateDsForGrandMaster(CLOCKDATA *pstClockData)
{
	DEFAULT_DS	*pstDefaultDS;
	CURRENT_DS	*pstCurrentDs;
	PARENT_DS	*pstParentDs;
	CURRENT_1588_DS	*pstCurrent1588Ds;
	TIMEPROPERTIES_DS *pstTimePropDs;
	BMC_GD 		*pstBmcGD;

	pstDefaultDS = &(pstClockData->stDefaultDS);
	pstCurrentDs = &(pstClockData->stCurrentDS);
	pstParentDs  = &(pstClockData->stParentDS);
	pstCurrent1588Ds = &(pstClockData->stCurrent_1588_DS);

	pstTimePropDs = &(pstClockData->stTimePropertiesDS);
	pstBmcGD 	 = &(pstClockData->stBMC_GD);

	pstCurrentDs->usStepsRemoved = OWN_STEPSREMOVED;

	pstCurrentDs->stOffsetFromMaster.sNsec_msb	= 0;
	pstCurrentDs->stOffsetFromMaster.ulNsec_lsb = 0;
	pstCurrentDs->stOffsetFromMaster.usFrcNsec = 0;

	pstCurrent1588Ds->stMeanPathDelay.ulNsec_lsb = 0;
	pstCurrent1588Ds->stMeanPathDelay.usFrcNsec	= 0;
	pstCurrent1588Ds->stMeanPathDelay.sNsec_msb	= 0;

	tsn_Wrapper_MemCpy(&(pstParentDs->stParentPortIdentity.stClockIdentity), &(pstDefaultDS->stClockIdentity), sizeof(CLOCKIDENTITY));
	
	pstParentDs->stParentPortIdentity.usPortNumber = OWN_PORTNUMBER;

	tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterIdentity, &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));

	tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterClockQuality, &pstDefaultDS->stClockQuality, sizeof(CLOCKQUALITY));

	if(pstParentDs->stGrandmasterClockQuality.uchClockClass < 255)
	{
		pstClockData->stClock_GD.blGmPresent = TRUE;
	}
	else
	{
		pstClockData->stClock_GD.blGmPresent = FALSE;
	}

	pstParentDs->uchGrandmasterPriority1 = pstDefaultDS->uchPriority1;
	pstParentDs->uchGrandmasterPriority2 = pstDefaultDS->uchPriority2;

	pstTimePropDs->sCurrentUtcOffset = pstBmcGD->sSysCurrentUtcOffset;

	pstTimePropDs->blPtpTimescale = pstBmcGD->blSysPtpTimescale;

	pstTimePropDs->blCurrentUtcOffsetValid = pstBmcGD->blSysCurrentUTCOffsetValid;

	pstTimePropDs->blLeap59 = pstBmcGD->blSysLeap59;

	pstTimePropDs->blLeap61 = pstBmcGD->blSysLeap61;

	pstTimePropDs->blTimeTraceable = pstBmcGD->blSysTimeTraceable;

	pstTimePropDs->blFrequencyTraceable = pstBmcGD->blSysFrequencyTraceable;

	pstTimePropDs->uchTimeSource = pstBmcGD->uchSysTimeSource;
}
#endif

VOID	updateDsForGrandMasterAS(CLOCKDATA *pstClockData)
{
	DEFAULT_DS	*pstDefaultDS;
	CURRENT_DS	*pstCurrentDs;
	PARENT_DS	*pstParentDs;
	TIMEPROPERTIES_DS *pstTimePropDs;
	BMC_GD 		*pstBmcGD;

	pstDefaultDS = &(pstClockData->stDefaultDS);
	pstCurrentDs = &(pstClockData->stCurrentDS);
	pstParentDs  = &(pstClockData->stParentDS);
	pstTimePropDs = &(pstClockData->stTimePropertiesDS);
	pstBmcGD 	 = &(pstClockData->stBMC_GD);

	pstCurrentDs->usStepsRemoved = OWN_STEPSREMOVED;

	pstCurrentDs->stOffsetFromMaster.sNsec_msb = 0;
	pstCurrentDs->stOffsetFromMaster.ulNsec_lsb= 0;
	pstCurrentDs->stOffsetFromMaster.usFrcNsec = 0;

	tsn_Wrapper_MemCpy(&(pstParentDs->stParentPortIdentity.stClockIdentity), &(pstDefaultDS->stClockIdentity), sizeof(CLOCKIDENTITY));
	
	pstParentDs->stParentPortIdentity.usPortNumber = OWN_PORTNUMBER;

	tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterIdentity, &pstDefaultDS->stClockIdentity, sizeof(CLOCKIDENTITY));

	tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterClockQuality, &pstDefaultDS->stClockQuality, sizeof(CLOCKQUALITY));

	if(pstParentDs->stGrandmasterClockQuality.uchClockClass < 255)
	{
		pstClockData->stClock_GD.blGmPresent = TRUE;
	}
	else
	{
		pstClockData->stClock_GD.blGmPresent = FALSE;
	}

	pstParentDs->uchGrandmasterPriority1 = pstDefaultDS->uchPriority1;
	pstParentDs->uchGrandmasterPriority2 = pstDefaultDS->uchPriority2;

	pstTimePropDs->sCurrentUtcOffset = pstBmcGD->sSysCurrentUtcOffset;

	pstTimePropDs->blPtpTimescale = pstBmcGD->blSysPtpTimescale;

	pstTimePropDs->blCurrentUtcOffsetValid = pstBmcGD->blSysCurrentUTCOffsetValid;

	pstTimePropDs->blLeap59 = pstBmcGD->blSysLeap59;

	pstTimePropDs->blLeap61 = pstBmcGD->blSysLeap61;

	pstTimePropDs->blTimeTraceable = pstBmcGD->blSysTimeTraceable;

	pstTimePropDs->blFrequencyTraceable = pstBmcGD->blSysFrequencyTraceable;

	pstTimePropDs->uchTimeSource = pstBmcGD->uchSysTimeSource;
}

VOID	updateDsForslave(CLOCKDATA *pstClockData)
{
	FOREIGN_MASTER_INFO	*pstClockForeignMasterInfo;
	PARENT_DS			*pstParentDs;
	CURRENT_DS			*pstCurrentDs;
	TIMEPROPERTIES_DS	*pstTimePropDs;
	ANNOUNCE_INFO*		pstAnnounceInfo;

	pstParentDs  = &(pstClockData->stParentDS);
	pstCurrentDs = &(pstClockData->stCurrentDS);
	pstTimePropDs = &(pstClockData->stTimePropertiesDS);

	if(pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.pstClkForeignBestClock)
	{
		pstClockForeignMasterInfo = pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.pstClkForeignBestClock;
		if(pstClockForeignMasterInfo->stAnnounceMessageChain.pstAnnounceChain_Foreword)
		{
			pstAnnounceInfo = (ANNOUNCE_INFO*)pstClockForeignMasterInfo->stAnnounceMessageChain.pstAnnounceChain_Foreword;

			pstCurrentDs->usStepsRemoved = pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.usStepsRemoved;

			tsn_Wrapper_MemCpy(&pstParentDs->stParentPortIdentity,
													&pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stSenderPort, sizeof(PORTIDENTITY));
			tsn_Wrapper_MemCpy (&pstParentDs->stGrandmasterIdentity, &pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockIdentity, sizeof(CLOCKIDENTITY));

			tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterClockQuality, &pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.stClockQuality, sizeof(CLOCKQUALITY));

			if(pstParentDs->stGrandmasterClockQuality.uchClockClass < 255)
			{
				pstClockData->stClock_GD.blGmPresent = TRUE;
			}
			else
			{
				pstClockData->stClock_GD.blGmPresent = FALSE;
			}

			pstParentDs->uchGrandmasterPriority1 = pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority1;
			pstParentDs->uchGrandmasterPriority2 = pstAnnounceInfo->stAnnoCmpInfoData.stBmcaCmpInfoData.uchPriority2;

			pstTimePropDs->sCurrentUtcOffset = pstAnnounceInfo->stAnnoCmpInfoData.sCurrentUtcOffset;

            pstTimePropDs->blLeap61                = MPTPMSG_H_GET_FLAGS1_LEAP61( &pstAnnounceInfo->stAnnoCmpInfoData );
            pstTimePropDs->blLeap59                = MPTPMSG_H_GET_FLAGS1_LEAP59( &pstAnnounceInfo->stAnnoCmpInfoData );
            pstTimePropDs->blCurrentUtcOffsetValid = MPTPMSG_H_GET_FLAGS1_CRNT_UTCOFSVAL( &pstAnnounceInfo->stAnnoCmpInfoData );
            pstTimePropDs->blPtpTimescale          = MPTPMSG_H_GET_FLAGS1_PTPTIMESCALE( &pstAnnounceInfo->stAnnoCmpInfoData );
            pstTimePropDs->blTimeTraceable         = MPTPMSG_H_GET_FLAGS1_TMTRACEABLE( &pstAnnounceInfo->stAnnoCmpInfoData );
            pstTimePropDs->blFrequencyTraceable    = MPTPMSG_H_GET_FLAGS1_FQTRACEABLE( &pstAnnounceInfo->stAnnoCmpInfoData );


			pstTimePropDs->uchTimeSource = pstAnnounceInfo->stAnnoCmpInfoData.uchTimeSource;

		}
		else
		{
		}
	}
	else
	{
	}
}

VOID	updateDsForslaveAS(PORTDATA *pstPort)
{
	PARENT_DS			*pstParentDs;
	CURRENT_DS			*pstCurrentDs;
	BMC_GD*				pstBmcGD;
	TIMEPROPERTIES_DS	*pstTimePropDs;

	pstParentDs  = &(pstPort->pstClockData->stParentDS);
	pstCurrentDs = &(pstPort->pstClockData->stCurrentDS);
	pstBmcGD 	 = &(pstPort->pstClockData->stBMC_GD);
	pstTimePropDs = &(pstPort->pstClockData->stTimePropertiesDS);

	pstCurrentDs->usStepsRemoved = pstBmcGD->usMasterStepsRemoved  - 1;

	tsn_Wrapper_MemCpy (&pstParentDs->stParentPortIdentity,
											&pstBmcGD->stGmPriority.stSourcePortIdentity, sizeof(PORTIDENTITY));

	tsn_Wrapper_MemCpy (&pstParentDs->stGrandmasterIdentity,
											&pstBmcGD->stGmPriority.stRootSystemIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));

	tsn_Wrapper_MemCpy(&pstParentDs->stGrandmasterClockQuality,
											&pstBmcGD->stGmPriority.stRootSystemIdentity.stClockQuality, sizeof(CLOCKQUALITY));

	pstParentDs->uchGrandmasterPriority1 = pstBmcGD->stGmPriority.stRootSystemIdentity.uchPriority1;
	pstParentDs->uchGrandmasterPriority2 = pstBmcGD->stGmPriority.stRootSystemIdentity.uchPriority2;

	pstTimePropDs->sCurrentUtcOffset = pstBmcGD->sCurrentUtcOffset;

	pstTimePropDs->blPtpTimescale = pstBmcGD->blPtpTimescale;

	pstTimePropDs->blLeap59 = pstBmcGD->blLeap59;

	pstTimePropDs->blLeap61 = pstBmcGD->blLeap61;

	pstTimePropDs->blTimeTraceable = pstBmcGD->blTimeTraceable;

	pstTimePropDs->blFrequencyTraceable = pstBmcGD->blFrequencyTraceable;
}

#ifdef	PTP_USE_IEEE1588
VOID	updateTimepropertiesDS_1588(PORTDATA *pstPort)
{
	PTPMSG_ANNOUNCE		*pstAnnounce;
	TIMEPROPERTIES_DS	*pstTimePropDs;

	pstTimePropDs = &(pstPort->pstClockData->stTimePropertiesDS);

	pstAnnounce = pstPort->stPortBMC_GD.pstRcvdAnnouncePtr;

	pstTimePropDs->sCurrentUtcOffset = pstAnnounce->sCurrentUtcOffset;

    pstTimePropDs->blLeap61                = MPTPMSG_H_GET_FLAGS1_LEAP61( &pstAnnounce->stHeader );
    pstTimePropDs->blLeap59                = MPTPMSG_H_GET_FLAGS1_LEAP59( &pstAnnounce->stHeader );
    pstTimePropDs->blCurrentUtcOffsetValid = MPTPMSG_H_GET_FLAGS1_CRNT_UTCOFSVAL( &pstAnnounce->stHeader );
    pstTimePropDs->blPtpTimescale          = MPTPMSG_H_GET_FLAGS1_PTPTIMESCALE( &pstAnnounce->stHeader );
    pstTimePropDs->blTimeTraceable         = MPTPMSG_H_GET_FLAGS1_TMTRACEABLE( &pstAnnounce->stHeader );
    pstTimePropDs->blFrequencyTraceable    = MPTPMSG_H_GET_FLAGS1_FQTRACEABLE( &pstAnnounce->stHeader );

}
#endif

#ifdef	PTP_USE_IEEE802_1
VOID	updateTimepropertiesDS_AS(PORTDATA *pstPort)
{
	BMC_GD*				pstBmcGD;
	TIMEPROPERTIES_DS	*pstTimePropDs;

	pstTimePropDs = &(pstPort->pstClockData->stTimePropertiesDS);
	pstBmcGD 	  = &(pstPort->pstClockData->stBMC_GD);

	pstTimePropDs->sCurrentUtcOffset = pstBmcGD->sCurrentUtcOffset;

	pstTimePropDs->blCurrentUtcOffsetValid = pstBmcGD->blCurrentUtcOffsetValid;

	pstTimePropDs->blPtpTimescale = pstBmcGD->blPtpTimescale;

	pstTimePropDs->blLeap59 = pstBmcGD->blLeap59;

	pstTimePropDs->blLeap61 = pstBmcGD->blLeap61;

	pstTimePropDs->blTimeTraceable = pstBmcGD->blTimeTraceable;

	pstTimePropDs->blFrequencyTraceable = pstBmcGD->blFrequencyTraceable;
}
#endif

#ifdef	PTP_USE_BMCA

#ifdef	PTP_USE_IEEE1588
BOOL	GetErbest(PORTDATA* pstPort)
{
	PORTDATA*		pstPortWork;
	UCHAR			uchRet;
	PORTBMC_1588_GD* pstPortBmc1588GD;
	FOREIGN_MASTER_INFO* pstForeignMasterInfo;
	FOREIGN_MASTER_CHAIN* pstForeignHdr;
	ANNOUNCE_INFO* 	pstAnnounceChain;
	BOOL			blMasterChange = FALSE;
	BMC_1588_GD*	pstBmc1588GD;
	FOREIGN_MASTER_INFO* pstClkForeignMasterInfo;
	PORTDATA*		pstPortBest = NULL;
	ANNOUNCE_INFO* 	pstAnnounceChain_work;
	USHORT	usPortNumber;
	pstClkForeignMasterInfo = NULL;
	pstPortBmc1588GD = &(pstPort->stUn_Port_GD.stPortBMC_1588_GD);
	pstBmc1588GD = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	blMasterChange = FALSE;

	if (pstBmc1588GD->pstClkForeignBestClock != NULL)
	{	if(pstBmc1588GD->pstClkForeignBestClock->usAnnMsgCnt == 0)
		{
			pstBmc1588GD->pstClkForeignBestClock = NULL;
		}
		else
		{ 	usPortNumber = pstBmc1588GD->pstClkForeignBestClock->pstPortData->stPortDS.stPortIdentity.usPortNumber;
			if (pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_DISABLED)
			{
				pstBmc1588GD->pstClkForeignBestClock = NULL;
			}
		}
	}

	for( pstPortWork = pstPort->pstClockData->pstPortData;
											pstPortWork != NULL;
														pstPortWork = pstPortWork->pstNextPortDataPtr)
	{
		if (pstPortWork->stPort_GD.blPortValid == TRUE)
		{
			ptp_dbg_msg( D_VALID, 
						 ("check port(ForeignBestClock). domain,port=[%d,%d]\n",
				          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
				          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );

			pstPortBmc1588GD = &(pstPortWork->stUn_Port_GD.stPortBMC_1588_GD);
			pstPortBmc1588GD->pstForeignBestClock = NULL;

			pstForeignHdr = &pstPortWork->stUn_Port_GD.stPortBMC_1588_GD.stForeignMasterChain;

			pstForeignMasterInfo = (FOREIGN_MASTER_INFO *)pstForeignHdr->pstForeignMaster_next;

			if (pstPortWork->pstClockData->stClock_GD.enSelectedState[pstPortWork->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_DISABLED)
			{


				while (pstForeignMasterInfo != (FOREIGN_MASTER_INFO *)pstForeignHdr)
				{
					pstAnnounceChain = (ANNOUNCE_INFO *)(pstForeignMasterInfo->stAnnounceMessageChain.pstAnnounceChain_Foreword);
					if (pstAnnounceChain != (ANNOUNCE_INFO *)&(pstForeignMasterInfo->stAnnounceMessageChain))
					{
						oganaizeAnnounceForForeign(pstForeignMasterInfo, pstPortWork);
						if ( ((!(pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER)) &&
								(pstForeignMasterInfo->usAnnMsgCnt >= (USHORT)FOREIGN_MASTER_THRESHOLD)) ||
								 	((pstPort->pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_STR_MASTER) &&
								 		(pstForeignMasterInfo->usAnnMsgCnt >= 1)) )
						{
							getBmcaCmpDatFromAnno2(&(pstForeignMasterInfo->stBmcaCmpDat), &pstAnnounceChain->stAnnoCmpInfoData, pstForeignMasterInfo->pstPortData);

							if (pstPortBmc1588GD->pstForeignBestClock)
							{
								pstAnnounceChain_work = (ANNOUNCE_INFO *)pstPortBmc1588GD->pstForeignBestClock->stAnnounceMessageChain.pstAnnounceChain_Foreword;
								getBmcaCmpDatFromAnno2(&(pstPortBmc1588GD->pstForeignBestClock->stBmcaCmpDat), &pstAnnounceChain_work->stAnnoCmpInfoData, pstPortBmc1588GD->pstForeignBestClock->pstPortData);
								uchRet = datasetCompalgorithm(&pstPortBmc1588GD->pstForeignBestClock->stBmcaCmpDat,
									&pstForeignMasterInfo->stBmcaCmpDat);
								if (uchRet == A_B_EQUAL)
								{
								}
								else if ((uchRet == (UCHAR)B_BETTER) || (uchRet == (UCHAR)B_BETTER_TOPO))
								{
									pstPortBmc1588GD->pstForeignBestClock = pstForeignMasterInfo;
								}
								else
								{
									releaseAnnounceForForeignMaster(pstForeignMasterInfo);
									pstForeignMasterInfo->usAnnMsgCnt = 0;
								}
							}
							else
							{
								pstPortBmc1588GD->pstForeignBestClock = pstForeignMasterInfo;
							}
						}
					}
					pstForeignMasterInfo = (FOREIGN_MASTER_INFO *)pstForeignMasterInfo->stForeignMasterChain.pstForeignMaster_next;
				}

				if (pstClkForeignMasterInfo == NULL)
				{
					if (pstPortBmc1588GD->pstForeignBestClock != NULL)
					{
						pstClkForeignMasterInfo = pstPortBmc1588GD->pstForeignBestClock;
						pstPortBest = pstPortWork;
					}

				}
				else
				{
					if (pstPortBmc1588GD->pstForeignBestClock)
					{
						pstAnnounceChain = (ANNOUNCE_INFO*)pstClkForeignMasterInfo->stAnnounceMessageChain.pstAnnounceChain_Foreword;
						getBmcaCmpDatFromAnno2(&(pstClkForeignMasterInfo->stBmcaCmpDat), &pstAnnounceChain->stAnnoCmpInfoData, pstClkForeignMasterInfo->pstPortData);

						uchRet = datasetCompalgorithm(&pstClkForeignMasterInfo->stBmcaCmpDat,
							&pstPortBmc1588GD->pstForeignBestClock->stBmcaCmpDat);
						if ((uchRet == (UCHAR)B_BETTER) || (uchRet == (UCHAR)B_BETTER_TOPO))
						{
							pstClkForeignMasterInfo = pstPortBmc1588GD->pstForeignBestClock;
							pstPortBest = pstPortWork;
						}
					}
				}
			}
		}
	}

	if (pstClkForeignMasterInfo)
	{
		if(pstClkForeignMasterInfo != pstBmc1588GD->pstClkForeignBestClock)
		{
			pstBmc1588GD->pstClkForeignBestClock = pstClkForeignMasterInfo;
			blMasterChange = TRUE;
			pstPortBest->stPortBMC_GD.enInfoIs = RECEIVED;
		}
	}
	else
	{
		if (pstBmc1588GD->pstClkForeignBestClock != pstClkForeignMasterInfo)
		{
			blMasterChange = TRUE;
		}
		pstBmc1588GD->pstClkForeignBestClock = pstClkForeignMasterInfo;

		if (pstPortBest != NULL)
		{
			pstPortBest->stPortBMC_GD.enInfoIs = RECEIVED;
		}
	}
	return (blMasterChange);
}

VOID	stateMachine_1588(PORTDATA* pstPort, UCHAR uchBmcaEvent, BOOL blMasterChange)
{
	CLOCK_GD	*pstClockGD;
	USHORT		usPortNumber;

	BMC_1588_GD	*pstBmc1588GD;
	UCHAR		uchState;

	pstClockGD	= &(pstPort->pstClockData->stClock_GD);

	pstBmc1588GD = &(pstPort->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD);
	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if ((!blMasterChange) && (pstBmc1588GD->uchExtSelectedState[usPortNumber] == (UCHAR)PS_EX_SLAVE) && (uchBmcaEvent == (UCHAR)EXT_EV_RS_SLAVE))
	{
		pstBmc1588GD->uchExtSelectedState[usPortNumber] = (UCHAR)PS_EX_SLAVE;
		pstClockGD->enSelectedState[usPortNumber] = ENUM_PORTSTATE_SLAVE;
	}
	else if (pstPort->pstClockData->stDefault_1588_DS.blSlaveOnly)
	{

		uchState = pstBmc1588GD->uchExtSelectedState[usPortNumber];

		pstBmc1588GD->uchExtSelectedState[usPortNumber] = 
				uchExtStatEvtToNewStateSlave[((pstBmc1588GD->uchExtSelectedState[usPortNumber])-PS_EX_INITIALIZING)][uchBmcaEvent];

		pstClockGD->enSelectedState[usPortNumber] = 
		(ENUM_SELECTEDSTATE)uchStatEvtToNewStateSlave[(uchState - PS_EX_INITIALIZING)][uchBmcaEvent];

	}
	else
	{
		uchState = pstBmc1588GD->uchExtSelectedState[usPortNumber];
		pstBmc1588GD->uchExtSelectedState[usPortNumber] =
				uchExtStatEvtToNewStateNorm[((pstBmc1588GD->uchExtSelectedState[usPortNumber])-PS_EX_INITIALIZING)][uchBmcaEvent];
		pstClockGD->enSelectedState[usPortNumber] = 

		uchStatEvtToNewStateNorm[(uchState - PS_EX_INITIALIZING)][uchBmcaEvent];

	}
}

VOID	getBmcaCmpDatFromAnno(BMCA_CMP_INF_DATA* pstBmcaCmpDat, PTPMSG_ANNOUNCE* pstAnnounceMessage, PORTDATA* pstPort)
{
	pstBmcaCmpDat->uchPriority1 = pstAnnounceMessage->uchGrandmasterPriority1;
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockIdentity,
								&pstAnnounceMessage->stGrandmasterIdentity, sizeof(CLOCKIDENTITY));
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockQuality,
								&pstAnnounceMessage->stGrandmasterClockQuality, sizeof(CLOCKQUALITY));
	pstBmcaCmpDat->uchPriority2 = pstAnnounceMessage->uchGrandmasterPriority2;
	pstBmcaCmpDat->usStepsRemoved = pstAnnounceMessage->usStepsRemoved;
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stSenderPort,
								&pstAnnounceMessage->stHeader.stSrcPortIdentity, sizeof(PORTIDENTITY));
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stReceiverPort,
								&pstPort->stPortDS.stPortIdentity, sizeof(PORTIDENTITY));
}

VOID	getBmcaCmpDatFromAnno2(BMCA_CMP_INF_DATA* pstBmcaCmpDat, ANNO_CMP_INF_DATA* pstAnnoCmpInfo, PORTDATA* pstPort)
{
	pstBmcaCmpDat->uchPriority1 = pstAnnoCmpInfo->stBmcaCmpInfoData.uchPriority1;
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockIdentity,
								&pstAnnoCmpInfo->stBmcaCmpInfoData.stClockIdentity, sizeof(CLOCKIDENTITY));
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockQuality,
								&pstAnnoCmpInfo->stBmcaCmpInfoData.stClockQuality, sizeof(CLOCKQUALITY));
	pstBmcaCmpDat->uchPriority2 = pstAnnoCmpInfo->stBmcaCmpInfoData.uchPriority2;
	pstBmcaCmpDat->usStepsRemoved = pstAnnoCmpInfo->stBmcaCmpInfoData.usStepsRemoved;
	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stSenderPort,
								&pstAnnoCmpInfo->stBmcaCmpInfoData.stSenderPort, sizeof(PORTIDENTITY));

	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stReceiverPort,
								&pstAnnoCmpInfo->stBmcaCmpInfoData.stReceiverPort, sizeof(PORTIDENTITY));
}


BOOL	cmpPortRcvAndGm(PORTDATA* pstPort)
{
	USHORT				usPortNumber;
	PTPMSG_ANNOUNCE*	pstAnnounce;
	UCHAR				uchRet;

	BOOL				blRet = FALSE;

	static	BMCA_CMP_INF_DATA	stBmcaCmpDatGM;
	static	BMCA_CMP_INF_DATA	stBmcaCmpDatAnno;

	usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

	if (pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] != ENUM_PORTSTATE_DISABLED)
	{
		blRet = getBmcaCmpDatFromParentDS(pstPort, &stBmcaCmpDatGM);

		if (blRet == TRUE)
		{
			pstAnnounce = pstPort->stPortBMC_GD.pstRcvdAnnouncePtr;

			getBmcaCmpDatFromAnno(&stBmcaCmpDatAnno, pstAnnounce, pstPort);

			uchRet = datasetCompalgorithm(&stBmcaCmpDatAnno, &stBmcaCmpDatGM);

			if( (uchRet == A_BETTER) || (uchRet == A_BETTER_TOPO) )
			{
				blRet = TRUE;
			}
			else
			{
				blRet = FALSE;
			}
		}
		else
		{
			blRet = TRUE;
		}
	}
	return	blRet;
}

BOOL	getBmcaCmpDatFromParentDS(PORTDATA* pstPort, BMCA_CMP_INF_DATA* pstBmcaCmpDat)
{
	USHORT				usPortNumber;
	INT 				nRet;
	PORTDATA* 			pstPortWork;

	BOOL				blRet = FALSE;

	pstBmcaCmpDat->uchPriority1 = pstPort->pstClockData->stParentDS.uchGrandmasterPriority1;

	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockIdentity,
								&pstPort->pstClockData->stParentDS.stGrandmasterIdentity,
										sizeof(CLOCKIDENTITY));

	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stClockQuality,
								&pstPort->pstClockData->stParentDS.stGrandmasterClockQuality,
										sizeof(CLOCKQUALITY));

	pstBmcaCmpDat->uchPriority2 = pstPort->pstClockData->stParentDS.uchGrandmasterPriority2;

	pstBmcaCmpDat->usStepsRemoved = 0;

	tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stReceiverPort.stClockIdentity,
								 &pstPort->pstClockData->stDefaultDS.stClockIdentity,
								 		sizeof(CLOCKIDENTITY));

	nRet = tsn_Wrapper_MemCmp (&pstPort->pstClockData->stParentDS.stGrandmasterIdentity,
								 &pstPort->pstClockData->stDefaultDS.stClockIdentity,
								 		sizeof(CLOCKIDENTITY));

	if (!nRet)
	{
		tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stSenderPort.stClockIdentity,
									 &pstPort->pstClockData->stDefaultDS.stClockIdentity,
									 		sizeof(CLOCKIDENTITY));

		pstBmcaCmpDat->stReceiverPort.usPortNumber = 0;

		pstBmcaCmpDat->stSenderPort.usPortNumber = 0;

		blRet = TRUE;
	}
	else
	{
		pstPortWork = pstPort->pstClockData->pstPortData;

		while (pstPortWork != NULL)
		{
			usPortNumber = pstPortWork->stPortDS.stPortIdentity.usPortNumber;

			if (pstPortWork->stPort_GD.blPortValid == TRUE)
			{
				ptp_dbg_msg( D_VALID, 
							 ("check port(SenderPort). domain,port=[%d,%d]\n",
					          pstPortWork->pstClockData->stDefaultDS.uchDomainNumber,
					          pstPortWork->stPortDS.stPortIdentity.usPortNumber) );
				if (pstPortWork->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_SLAVE)
				{
					pstBmcaCmpDat->stReceiverPort.usPortNumber = usPortNumber;

					if(pstPortWork->stUn_Port_GD.stPortBMC_1588_GD.pstForeignBestClock != NULL)
					{
						tsn_Wrapper_MemCpy (&pstBmcaCmpDat->stSenderPort,
												&pstPortWork->stUn_Port_GD.stPortBMC_1588_GD.pstForeignBestClock->stBmcaCmpDat.stSenderPort,
													 		sizeof(PORTIDENTITY));
						blRet = TRUE;
					}
					break;
				}
			}
			pstPortWork = pstPortWork->pstNextPortDataPtr;
		}
	}
	return blRet;
}


#endif

#endif

VOID	PortStateSelection_nop(PORTDATA *pstPort)
{
	return;
}

VOID	check_ASCapable(PORTDATA *pstPort, BOOL	blAsCapable)
{
	USHORT		usPortNumber;

	if (pstPort->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
		usPortNumber = pstPort->stPortDS.stPortIdentity.usPortNumber;

		if((blAsCapable == FALSE) && (pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] != ENUM_PORTSTATE_DISABLED))
		{
			pstPort->stPort_GD.ulAsCapableChangeOFFCnt ++;

#ifdef	PTP_USE_BMCA
			if (pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE)
			{
				portAnnounceInformationSM(PTP_EV_CLOSE, pstPort);

				pstPort->stPortBMC_GD.enInfoIs = DISABLED;
				pstPort->pstClockData->stBMC_GD.blReselect[pstPort->stPortDS.stPortIdentity.usPortNumber] = TRUE;
				pstPort->pstClockData->stBMC_GD.blSelected[pstPort->stPortDS.stPortIdentity.usPortNumber] = FALSE;
				portStateSelectionSM(PTP_EV_RESELECT_PORT, pstPort);

				exec_PortAnnInfo04_allPort(pstPort);
			}
			else
#endif
			{
				portAnnounceInformationExtSM(PTP_EV_CLOSE, pstPort);
			}
		}
		else if ((blAsCapable == TRUE) && (pstPort->pstClockData->stClock_GD.enSelectedState[usPortNumber] == ENUM_PORTSTATE_DISABLED))
		{

			pstPort->stPort_GD.ulAsCapableChangeONCnt ++;

#ifdef	PTP_USE_BMCA
			if ( pstPort->pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
			{
				portAnnounceInformationSM( PTP_EV_BEGIN, pstPort );
			}
			else
#endif
			{
				portAnnounceInformationExtSM( PTP_EV_BEGIN, pstPort );
			}
		}
	}
}

INT	compVector(PRIORITY_VECT* pstPriority1, PRIORITY_VECT* pstPriority2)
{
	INT	nRet = 0;

	nRet = pstPriority1->stRootSystemIdentity.uchPriority1 - pstPriority2->stRootSystemIdentity.uchPriority1;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->stRootSystemIdentity.stClockQuality.uchClockClass - pstPriority2->stRootSystemIdentity.stClockQuality.uchClockClass;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->stRootSystemIdentity.stClockQuality.uchClockAccuracy - pstPriority2->stRootSystemIdentity.stClockQuality.uchClockAccuracy;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->stRootSystemIdentity.stClockQuality.usOffsetScaledLogVariance - pstPriority2->stRootSystemIdentity.stClockQuality.usOffsetScaledLogVariance;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->stRootSystemIdentity.uchPriority2 - pstPriority2->stRootSystemIdentity.uchPriority2;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = tsn_Wrapper_MemCmp(&pstPriority1->stRootSystemIdentity.stClockIdentity, &pstPriority2->stRootSystemIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->usStepsRemoved - pstPriority2->usStepsRemoved;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = tsn_Wrapper_MemCmp(&pstPriority1->stSourcePortIdentity.stClockIdentity, &pstPriority2->stSourcePortIdentity.stClockIdentity, sizeof(CLOCKIDENTITY));
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->stSourcePortIdentity.usPortNumber - pstPriority2->stSourcePortIdentity.usPortNumber;
	if (nRet != 0)
	{
		return nRet;
	}
	nRet = pstPriority1->usPortNumber - pstPriority2->usPortNumber;
	return nRet;
}
