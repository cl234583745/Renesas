//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _MSW_LLDP_BASMAN_H_
#define _MSW_LLDP_BASMAN_H_


#define MSW_LLDP_MOD_BASIC   2


void msw_basman_register(void);
void msw_basman_unregister(void);
int  msw_basman_gettlv(unsigned char *outframe, unsigned short *len, 
                    MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData);

#endif
