/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_API_MANAGEMENT_H__
#define __PTP_API_MANAGEMENT_H__

#ifdef __cplusplus
extern "C" {
#endif
INT	ptp_get_para_AS( USHORT usParamId_AS, 
					 UCHAR  uchDomainNumber, 
					 UCHAR  uchPortNum, 
					 UCHAR* puchInfo, 
					 USHORT usInfoBufSize );
INT	ptp_set_para_AS( USHORT usParamId_AS, 
					 UCHAR  uchDomainNumber, 
					 UCHAR  uchPortNum, 
					 UCHAR* puchInfo, 
					 USHORT usInfoBufSize );

INT	ptp_get_para_1588( USHORT usParamId_1588, 
					   UCHAR  uchDomainNumber, 
					   UCHAR  uchPortNum, 
					   UCHAR *puchInfo, 
					   USHORT usInfoBufSize );
INT	ptp_set_para_1588( USHORT usParamId_1588, 
					   UCHAR  uchDomainNumber, 
					   UCHAR  uchPortNum, 
					   UCHAR *puchInfo, 
					   USHORT usInfoBufSize );


#ifdef __cplusplus
}
#endif

#endif
