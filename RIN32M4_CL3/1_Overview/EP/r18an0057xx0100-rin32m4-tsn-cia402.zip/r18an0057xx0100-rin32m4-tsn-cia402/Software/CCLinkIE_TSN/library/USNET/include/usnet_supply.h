//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================
#ifndef	__USNET_SUPPLY_H_INCLUDED__
#define	__USNET_SUPPLY_H_INCLUDED__

#include "msw_lldp.h"
#include "lldpd.h"

#define		USNET_LINKUP	(0x00000004)
#define		USNET_LINKDOWN	(0x00000000)

unsigned long	ulUSN_GetLifeTime(void);
void			vUSN_vDisableDispatch(void);
void			vUSN_vEnableDispatch(void);
void			vUSN_GetLinkSts (unsigned short usPort, unsigned long* pulLinkSts);
void			vUSN_GetIpOverlapErrInfo (unsigned short usPort, unsigned short usIpErrSts, unsigned char* puchOtherMacAddr);
void			vUSN_SetLldpSetting (LLDPD_SETTING_T* pstLldpSetting);
void			vUSN_GetModelNameMib (unsigned char* puchStrData);
void			vUSN_GetCycSndSts (unsigned long* pulSndSts);
#endif

