/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDLKDLYINTVALSET_H__
#define __MDLKDLYINTVALSET_H__

#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID 	LinkDelayIntervalSettingSM(USHORT usEvent, PORTDATA* pstPort);

LDISETTINGSM_GD*	GetLkDlyIntvSetGlobal(PORTDATA* pstPort);
LDLYINTVSET_EV		GetLkDlyIntvSetEvent(USHORT usEvent, PORTDATA* pstPort);
LDLYINTVSET_ST		GetLkDlyIntvSetStatus(PORTDATA* pstPort);
VOID				SetLkDlyIntvSetStatus(LDLYINTVSET_ST enSts, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
