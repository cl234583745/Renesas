//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include "net.h"
#include "local.h"
#include "support.h"
#ifdef  INET6
#include "socket6.h"
#endif


extern PTABLE * const P_tab[];
#ifdef  INET6
extern int inet6_addr(struct in6_addr *addr,  char *s);
extern int DNSresolve6(char *fullname, I6id *i6idp);
#endif


int Nopen(char *to, char *protoc, int p1, int p2, int flags)
{
    int i1, i2, i3, i4, conno, confix = 0, sconfix;
    char *cp1, *cp2, name[32], pname[16], pname2[16];
    Iid iid;
#ifdef  INET6
    I6id i6id;
    int protoc_ipv6 = 0;
    int ipv6 = 0;
    int scope_id = 0;
#endif
    struct NETCONF *confp;
    register struct CONNECT *conp = NULL;
    int netno = 0;

    name[0] = pname[0] = 0;
    sconfix = -1;

#ifdef  INET6
    if (protoc && strstr (protoc, "IPv6") != NULL)
        protoc_ipv6 = 1;
#endif
    if (flags & IPADDR)
        iid = *(Iid *) to;
#ifdef  INET6
    else if (flags & IP6ADDR) {
        ip6acpy (&i6id, to);
        ipv6 = protoc_ipv6;
    }
    else if (inet6_addr ((struct in6_addr *)&i6id, to) == 0) {
        if ((cp1 = strchr (to, '%')) != NULL) {
            i1 = atoi (cp1  + 1);
            if (0 < i1 && i1 <= NNETS && nets[i1-1].netstat == 0)
                scope_id = i1;
        }
        ipv6 = protoc_ipv6;
    }
#endif
    else if ((conno = Nsscanf(to, "%d.%d.%d.%d", &i1, &i2, &i3, &i4)) == 4)
        iid.c[0] = i1, iid.c[1] = i2, iid.c[2] = i3, iid.c[3] = i4;
    else {
#if NTRACE>=2
        Nprintf("Nopen: to=`%s` \n", to);
#endif
#ifdef  INET6
        ipv6 = protoc_ipv6;
#endif
        name[0] = pname[0] = '*';
        Nsscanf(to, "%[^/]/%s", name, pname);
        for (i1 = 0, i3 = 255; i1 < NCONFIGS; i1++) {
            confp = &netconf[i1];
            if (confp->ncstat == 0)
                continue;
            if (pname[0] != '*' && strcmp(pname, confp->pname) != 0)
                continue;
            else if (strcmp(pname, confp->pname) == 0) {
                netno = confp->netno;
            }
            if (name[0] == '*') {
                sconfix = i1;
                if (pname[0] == '*') {
#ifdef  INET6
                if (ipv6) {
                    memset (&i6id, 0xff, sizeof (i6id));
                    confix = ussBroadcastIndex;
                    goto lab11;
                }
#endif
                    iid.l = 0xffffffff;
                }
                else
                    iid.l = confp->Iaddr.l | ~confp->Imask.l;
                goto lab1;
            }
            if (strcmp(confp->name, name) != 0)
                continue;
#ifdef  INET6
            if (ipv6)
                continue;
#endif
            if (confp->hops < i3) {
                iid = confp->Iaddr;
                confix = i1;
                i3 = confp->hops;
            }
        }
        if (i3 == 255) {
#ifdef DNS
#if DNS == 2
#ifdef  INET6
        if (ipv6)
            i1 = DNSresolve6(name, &i6id);
        else
#endif
            i1 = DNSresolve(name, &iid);
            if (i1 >= 0)
                goto lab1;
#endif
#endif
#if NTRACE >= 1
            Nprintf("Nopen: remote computer `%s` is not in NETCONF.C or unreachable\n", to);
#endif
            goto err1;
        }
        if (iid.l == 0 && netconf[confix].ncstat == 4)
            goto lab11;
    }
lab1:
#ifdef  INET6
    if (ipv6)
        confix = GetHostData6(i6id.c, 1, netno);
    else
        confix = GetHostData(iid.l, 1, netno);
    if (confix < 0) {
#else
    if ((confix = GetHostData(iid.l, 1, netno)) < 0) {
#endif
#if NTRACE >= 1
        Nprintf("Nopen: no route to host %s\n", to);
#endif
        goto err1;
    }
lab11:
    BLOCKPREE();
    for (conno = 0; conno < NCONNS; conno++)
        if (!connblo[conno].blockstat) {
            conp = &connblo[conno];
            if ( conp->refcount == 0 && conp->refsock == 0 ) {
                memset((void *) conp, 0, sizeof(struct CONNECT));
                conp->blockstat = (char) 0x81;
                conp->refcount = 1;
                break;
            }
        }
    RESUMEPREE();
    if (conno == NCONNS)
        return ENOBUFS;
    for (i1 = 0, cp1 = protoc; *cp1; i1++) {
        for (cp2 = pname2; *cp1; cp2++)
            if ((*cp2 = *cp1++) == '/')
                break;
        *cp2 = 0;
        for (i2 = 0; P_tab[i2]; i2++)
        {
            if (strcmp(pname2, P_tab[i2]->name) == 0)
            {
                conp->protoc[i1] = P_tab[i2];
                goto lab2;
            }
        }
        goto err5;
lab2:   ;
    }
    conp->confix = confix;
    if (confix == ussBroadcastIndex)
    {
        if (sconfix == -1) {
            for (sconfix = 0; sconfix < NCONFIGS; sconfix++) {
                if (iid.l == 0xffffffff)
                    break;
                if (netconf[sconfix].ncstat == 0)
                    continue;
                if ((netconf[sconfix].Iaddr.l & netconf[sconfix].Imask.l) ==
                    (iid.l & netconf[sconfix].Imask.l))
                    break;
            }
            if (sconfix == NCONFIGS)
                for (sconfix = 0; sconfix < NCONFIGS; sconfix++)
                    if (netconf[sconfix].flags & ROUTER)
                        break;
            if (sconfix == NCONFIGS) {
#if NTRACE
                Nprintf("Nopen: Cannot establish broadcast route!\n");
#endif
                goto err5;
            }
        }
        conp->netno = netconf[sconfix].netno;
    }
#if USS_IP_MC_LEVEL > 0
    else if (confix == ussMulticastIndex)
        conp->netno = ussDfltMcNetno;
#endif
#ifdef  INET6
    else if (conp->ipv6.family == PF_INET6 && scope_id != 0)
        conp->netno = scope_id - 1;
#endif
    else
        conp->netno = netconf[confix].netno;
#ifdef  INET6
    if (pname[0] != '*' && ipv6) {
        ip6acpy (&conp->ipv6.offeredi6id, 
                &netconf[nets[conp->netno].confix].ipv6.I6addr);
    } else
#endif
    if (pname[0] != '*')
        conp->offerediid.l = netconf[nets[conp->netno].confix].Iaddr.l;
    else
        conp->offerediid.l = 0;
#ifdef  INET6
if (ipv6) {
    conp->ipv6.family = PF_INET6;
    conp->ipv6.flags = 0;
    Nsetheri6id (conno, i6id.c);
    Nsetmyi6id (conno, NULL);
    conp->heriid.l = 0xffffffffL;
} else
#endif
    conp->heriid = iid;
    conp->myport = NC2(p1);
    conp->herport = NC2(p2);
    conp->doffset = MESSH_SZ + LHDRSZ;
    for (i1 = 0; conp->protoc[i1]; i1++)
        conp->doffset += conp->protoc[i1]->hdrsiz;
#ifdef  INET6
if (ipv6) {
    conp->maxdat = Ngetmaxblo6(conp->netno) - 
        conp->doffset + MESSH_SZ + LHDRSZ;
} else
#endif
    conp->maxdat = nets[conp->netno].maxblo - conp->doffset + MESSH_SZ +
        LHDRSZ;
    conp->blockstat = 1;
    i2 = conp->protoc[0]->opeN(conno, flags);
    if (i2 < 0) {
        if (SOCKET_ISFATAL(conno))
            i2 = ECONNABORTED;
        conp->protoc[0]->closE(conno);
        BLOCKPREE();
        conp->refcount = 0;
        conp->blockstat = 0;
        RESUMEPREE();
        return i2;
    }
    ussHostAcquire(conp->confix);
    BLOCKPREE();
    conp->refcount = 0;
    conp->rxtout = TOUT_READ;
    RESUMEPREE();
    return conno;
err5:
    BLOCKPREE();
    conp->refcount = 0;
    conp->blockstat = 0;
    RESUMEPREE();
err1:
    return EHOSTUNREACH;
}


int Nclose(int conno)
{
    int stat;
    MESS *mess;
    struct CONNECT *conp;

    if ((unsigned int) conno >= NCONNS)
        return EBADF;
    conp = &connblo[conno];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        return EBADF;
    }
    conp->refcount = 1;
    if (conp->blockstat != 1) {
        conp->refcount = 0;
        RESUMEPREE();
        return EBADF;
    }
    conp->blockstat = 2;
    RESUMEPREE();

    while ((mess = conp->first) != 0) {
        conp->first = mess->next;
        conp->ninque--;
        Nrelbuf(mess);
    }
    WAITNOMORE(SIG_RC(conno));

    stat = conp->protoc[0]->closE(conno);
    BLOCKPREE();
    conp->refcount = 0;
    if ((stat & 1) == 0) {
        conp->blockstat = 0;
        ussHostRelease(conp->confix);
    }
    RESUMEPREE();

    return stat & 2 ? ECONNABORTED : 0;
}


int Nwrite(int conno, char *buff, int len)
{
    int stat;
    unsigned long ul1;
    MESS *mp;
    struct NET *netp;
    register struct CONNECT *conp;

    if ((unsigned int) conno >= NCONNS)
        return EBADF;
    conp = &connblo[conno];
    if (conp->blockstat != 1)
        return EBADF;
    if (conp->rxstat & S_FATAL)
        return ECONNABORTED;
    if (len + conp->doffset > MAXBUF)
        return EMSGSIZE;
    if ((mp = Ngetbuf()) == 0)
        return ENOBUFS;
    BLOCKPREE( );
    if (conp->refcount > 0) {
        RESUMEPREE();
        return EBADF;
    }
    conp->refcount = 1;
    RESUMEPREE( );
    mp->offset = conp->doffset;
    Nmemcpy((char *) mp + conp->doffset, buff, len);
    mp->mlen = len + conp->doffset;
    mp->netno = conp->netno;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    Nsetmyi6id (conno, (unsigned char *)&conp->ipv6.heri6id);
    ip6acpy (mp->ipv6.target6, &conp->ipv6.heri6id);
    mp->target = 0;
} else
#endif
    mp->target = conp->heriid.l;
    netp = &nets[conp->netno];
    ul1 = conp->txstat & S_NOWA ? 0 : netp->tout;
    WAITFOR(((netp->depart[0].mtail - netp->depart[0].mhead) & 15) < MAXOUTQLEN,
            SIG_WN(conp->netno), ul1, stat);
    if (stat)
        stat = ETIMEDOUT;
    else
        stat = conp->protoc[0]->writE(conno, mp);
    if (stat)
        Nrelbuf(mp);
#if MT != 2
    YIELD();
#endif
    if (stat >= 0)
        stat = len;
    conp->refcount = 0;
    return stat;
}


int Nread(int conno, char *buff, int len)
{
    int i1, mlen;
    MESS *mp;
    struct CONNECT *conp;

    if ((unsigned int) conno >= NCONNS)
        return EBADF;

    conp = &connblo[conno];
    if (conp->blockstat != 1)
        return EBADF;

    BLOCKPREE( );
    if (conp->refcount > 0) {
        RESUMEPREE();
        return EBADF;
    }
    conp->refcount = 1;
    RESUMEPREE( );
    mp = conp->protoc[0]->reaD(conno);
    if (mp == 0)
    {
        conp->refcount = 0;
        if (conp->rxstat & S_FATAL)
            return ECONNABORTED;
        if (conp->rxstat & S_EOF)
            return 0;
        if (conp->txstat & S_NOWA)
            return EWOULDBLOCK;
        else
            return ETIMEDOUT;
    }

    i1 = mp->offset;
    mlen = mp->mlen - i1;
    if (mlen < 0 || mlen > len)
        mlen = EMSGSIZE;
    else
        Nmemcpy(buff, (char *) mp + i1, mlen);
    Nrelbuf(mp);

    conp->refcount = 0;
    return mlen;
}

