/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __MDDELAYRESPSENDSM_H__
#define __MDDELAYRESPSENDSM_H__
#ifdef DEBUG_LOG_MD
#include <stdio.h>
#endif
#include "ptp_Event.h"
#include "PTP_Message.h"
#include "ptp_Struct_Port.h"
#include "ptp_LogRecord.h"

#ifdef __cplusplus
extern "C" {
#endif

VOID 	MDDelayRespSendSM(USHORT usEvent, PORTDATA* pstPort);

MDDRESPSDSM_GD*	GetMDDRespSndSMGlobal(PORTDATA* pstPort);
MDDRESPSNDSM_EV	GetMDDRespSndEvent(USHORT usEvent, PORTDATA* pstPort);
MDDRESPSNDSM_ST	GetMDDRespSndStatus(PORTDATA* pstPort);
VOID			SetMDDRespSndStatus(MDDRESPSNDSM_ST enSts, PORTDATA* pstPort);

#ifdef __cplusplus
}
#endif

#endif
