/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_API_Local.h"

#include "PTP_GlobalData.h"

#include "ManagementSM.h"
#include "ManagementAPI_1588.h"

#include "PortStateSelectionSM.h"
#include "PortAnnounceInformationSM.h"
#include "PortAnnounceInformationExtSM.h"
#include "MDPdelayReq.h"

#define	PTP_PHYSICAL_LAYER_PROTOCOL	"IEEE 802.1"

#ifndef	PTP_RESTRICT_GETSET
#define MGT_ACT_API_TBLSIZE		(MID_1588_MAX + 2)
#else
#define MGT_ACT_API_TBLSIZE		2
#endif

static
const MGT_ACT_API_TBL_1588	stMgt_Action[MGT_ACT_API_TBLSIZE] =
{
#ifndef	PTP_RESTRICT_GETSET
	{"CLOCK_DESCRIPTION					"	,MID_1588_CLOCK_DESCRIPTION		,MID1588_APPLIES_PORT,	{&GetIe1588ClockDescription		,&NopIe1588_NOP}				,sizeof(MGT_CLOCK_DESCRIPTION)},
	{"USER_DESCRIPTION					"	,MID_1588_USER_DESCRIPTION		,MID1588_APPLIES_CLOCK,	{&GetIe1588UserDescription		,&SetIe1588UserDescription}		,sizeof(MGT_USER_DESCRIPTION)},
	{"FAULT_LOG							"	,MID_1588_FAULT_LOG				,MID1588_APPLIES_CLOCK,	{&GetIe1588FaultLog				,&NopIe1588_NOP}				,sizeof(MGT_FAULT_LOG)},
	{"FAULT_LOG_RESET					"	,MID_1588_FALULTLOG_RESET		,MID1588_APPLIES_CLOCK,	{&NopIe1588_NOP					,&SetIe1588FaultLogReset}		,0},
	{"DEFAULT_DATA_SET					"	,MID_1588_DEFAULT_DATA_SET		,MID1588_APPLIES_CLOCK,	{&GetIe1588DefaultDS			,&NopIe1588_NOP}				,sizeof(MGT_DEFAULT_DATA_SET)},
#endif
	{"CURRENT_DATA_SET					"	,MID_1588_CURRENT_DATA_SET		,MID1588_APPLIES_CLOCK,	{&GetIe1588CurrentDS			,&NopIe1588_NOP}				,sizeof(MGT_CURRENT_DATA_SET)},
	{"PARENT_DATA_SET					"	,MID_1588_PARENT_DATA_SET		,MID1588_APPLIES_CLOCK,	{&GetIe1588ParentDS				,&NopIe1588_NOP}				,sizeof(MGT_PARENT_DATA_SET)},
#ifndef	PTP_RESTRICT_GETSET
	{"TIME_PROPERTIES_DATA_SET			"	,MID_1588_TIME_PROP_DATA_SET	,MID1588_APPLIES_CLOCK,	{&GetIe1588TimePropertiesDS		,&NopIe1588_NOP}				,sizeof(MGT_TIME_PROPERTIES_DATA_SET)},
	{"PORT_DATA_SET						"	,MID_1588_PORT_DATA_SET			,MID1588_APPLIES_PORT,	{&GetIe1588PortDS				,&NopIe1588_NOP}				,sizeof(MGT_PORT_DATA_SET)},
	{"PRIORITY1							"	,MID_1588_PRIORITY1				,MID1588_APPLIES_CLOCK,	{&GetIe1588Priority1			,&SetIe1588Priority1}			,sizeof(MGT_PRIORITY1)},
	{"PRIORITY2							"	,MID_1588_PRIORITY2				,MID1588_APPLIES_CLOCK,	{&GetIe1588Priority2			,&SetIe1588Priority2}			,sizeof(MGT_PRIORITY2)},
	{"SLAVE_ONLY						"	,MID_1588_SLAVE_ONLY			,MID1588_APPLIES_CLOCK,	{&GetIe1588SlaveOnly			,&SetIe1588SlaveOnly}			,sizeof(MGT_SLAVE_ONLY)},
	{"LOG_ANNOUNCE_INTERVAL				"	,MID_1588_LOG_ANN_INT			,MID1588_APPLIES_PORT,	{&GetIe1588LogAnnounInterval	,&SetIe1588LogAnnounInterval}	,sizeof(MGT_LOG_ANNOUNCE_INTERVAL)},
	{"ANNOUNCE_RECEIPT_TIMEOUT			"	,MID_1588_ANN_RECEIPT_TMO		,MID1588_APPLIES_PORT,	{&GetIe1588AnnounReceiptTimeout	,&SetIe1588AnnounReceiptTimeout},sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT)},
	{"LOG_SYNC_INTERVAL					"	,MID_1588_LOG_SYNC_INT			,MID1588_APPLIES_PORT,	{&GetIe1588LogSyncInterval		,&SetIe1588LogSyncInterval}		,sizeof(MGT_LOG_SYNC_INTERVAL)},
	{"VERSION_NUMBER					"	,MID_1588_VERSION_NUMBER		,MID1588_APPLIES_PORT,	{&GetIe1588VersionNum			,&SetIe1588VersionNum}			,sizeof(MGT_VERSION_NUMBER)},
	{"ENABLE_PORT						"	,MID_1588_ENABLE_PORT			,MID1588_APPLIES_PORT,	{&NopIe1588_NOP					,&SetIe1588EnablePort}			,0},
	{"DISABLE_PORT						"	,MID_1588_DISABLE_PORT			,MID1588_APPLIES_PORT,	{&NopIe1588_NOP					,&SetIe1588DisablePort}			,0},
	{"TIME								"	,MID_1588_TIME					,MID1588_APPLIES_CLOCK,	{&GetIe1588Time					,&SetIe1588Time}				,sizeof(MGT_TIME)},
	{"CLOCK_ACCURACY					"	,MID_1588_CLOCK_ACCURACY		,MID1588_APPLIES_CLOCK,	{&GetIe1588ClockAccuracy		,&SetIe1588ClockAccuracy}		,sizeof(MGT_CLOCK_ACCURACY)},
	{"UTC_PROPERTIES					"	,MID_1588_UTC_PROPERTIES		,MID1588_APPLIES_CLOCK,	{&GetIe1588UtcProperties		,&SetIe1588UtcProperties}		,sizeof(MGT_UTC_PROPERTIES)},
	{"TRACEABILITY_PROPERTIES			"	,MID_1588_TRACE_PROP			,MID1588_APPLIES_CLOCK,	{&GetIe1588TraceProperties		,&SetIe1588TraceProperties}		,sizeof(MGT_TRACEABILITY_PROPERTIES)},
	{"TIMESCALE_PROPERTIES				"	,MID_1588_TIMESCALE_PROP		,MID1588_APPLIES_CLOCK,	{&GetIe1588TimesProperties		,&SetIe1588TimesProperties}		,sizeof(MGT_TIMESCALE_PROPERTIES)},
	{"PATH_TRACE_LIST					"	,MID_1588_PATH_TRACE_LIST		,MID1588_APPLIES_CLOCK,	{&GetIe1588PathTraceList		,&NopIe1588_NOP}				,sizeof(MGT_PATH_TRACE_LIST)},
	{"PATH_TRACE_ENABLE					"	,MID_1588_PATH_TRACE_ENBLE		,MID1588_APPLIES_CLOCK,	{&GetIe1588PathTraceEnable		,&SetIe1588PathTraceEnable}		,sizeof(MGT_PATH_TRACE_ENABLE)},
	{"PORT_STATISTICS_COUNT				"	,MID_1588_PORT_STAT_CNT			,MID1588_APPLIES_PORT,	{&GetIe1588PortStatCount		,&NopIe1588_NOP}				,sizeof(MGT_PORT_STATISTICS_COUNT)},
	{"CMLD_PORT_STATISTICS_COUNT		"	,MID_1588_CMLD_PORT_STAT_CNT	,MID1588_APPLIES_PORT,	{&GetIe1588CmldStatPortCount	,&NopIe1588_NOP}				,sizeof(MGT_CMLD_PORT_STATIS_COUNT)},
	{"TRANSPARENT_CLOCK_DEFAULT_DATA_SET"	,MID_1588_TRANS_DEFAULT_DS		,MID1588_APPLIES_CLOCK,	{&GetIe1588TransClockDefaultDS	,&NopIe1588_NOP}				,sizeof(MGT_TCLK_DEFAULT_DATA_SET)},
	{"TRANSPARENT_CLOCK_PORT_DATA_SET	"	,MID_1588_TRANS_PORT_DS			,MID1588_APPLIES_PORT,	{&GetIe1588TransClockPortDS		,&NopIe1588_NOP}				,sizeof(MGT_TCLK_PORT_DATA_SET)},
	{"PRIMARY_DOMAIN					"	,MID_1588_PRIMARY_DOMAIN		,MID1588_APPLIES_CLOCK,	{&GetIe1588PrimaryDomain		,&SetIe1588PrimaryDomain}		,sizeof(MGT_PRIMARY_DOMAIN)},
	{"DELAY_MECHANISM					"	,MID_1588_DELAY_MECHANISM		,MID1588_APPLIES_PORT,	{&GetIe1588DelayMechanism		,&SetIe1588DelayMechanism}		,sizeof(MGT_DELAY_MECHANISM)},
	{"DELAY_MECHANISM					"	,MID_1588_DELAY_MECHANISM		,MID1588_APPLIES_CLOCK,	{&GetIe1588DelayMechanismTC		,&SetIe1588DelayMechanismTC}	,sizeof(MGT_DELAY_MECHANISM)}, 
	{"LOG_MIN_PDELAY_REQ_INTERVAL		"	,MID_1588_MIN_PDELAY_REQ_INT	,MID1588_APPLIES_PORT,	{&GetIe1588LogMinPDReqInterval	,&SetIe1588LogMinPDReqInterval}	,sizeof(MGT_LOG_MIN_PDREQ_INTERVAL)}
#endif
};

INT ManagementSM_1588_API(UCHAR uchAction, USHORT usParamId_1588, CLOCKDATA* pstClockData, PORTDATA* pstPortData, UCHAR* puchInfo, USHORT usInfoSize)
{
	INT		nRet	= RET_ENOERR;
	USHORT	usDLen	= 0;

	if (stMgt_Action[usParamId_1588].enTypeApplies == MID1588_APPLIES_CLOCK)
	{
		nRet = (*stMgt_Action[usParamId_1588].pfnFunc[uchAction])((VOID*)pstClockData, puchInfo, usInfoSize, &usDLen);
	}
	else if ((stMgt_Action[usParamId_1588].enTypeApplies == MID1588_APPLIES_PORT)
			 && (pstPortData != NULL))
	{
		nRet = (*stMgt_Action[usParamId_1588].pfnFunc[uchAction])((VOID*)pstPortData , puchInfo, usInfoSize, &usDLen);
	}
	else
	{
		nRet = RET_EINVAL;
	}
#if 1
	if((nRet == RET_SAMEVAL) && (uchAction == MGT1588_ACTION_SET))
	{
		nRet = RET_ENOERR;
	}
#endif
	else if ((nRet == RET_ENOERR) && (uchAction == MGT1588_ACTION_SET))
	{
#if 1
		if (!IS_PTP_OPEN())
		{
			return nRet;
		}
#endif
		switch(usParamId_1588)
		{
		case MID_1588_PRIORITY1:
		case MID_1588_PRIORITY2:
			{
			portStateSelectionSM(PTP_EV_SYSTEMIDENTITYCHANGE, pstClockData->pstPortData);
			}
			break;
#if 1
		case MID_1588_ENABLE_PORT:
			if (pstPortData->pstClockData->stClock_GD.enSelectedState[pstPortData->stPortDS.stPortIdentity.usPortNumber] == ENUM_PORTSTATE_DISABLED)
			{
#ifdef	PTP_USE_BMCA
				if ( pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
				{
					portAnnounceInformationSM( PTP_EV_BEGIN, (PORTDATA*)pstPortData );
				}
				else
#endif
				{
					portAnnounceInformationExtSM( PTP_EV_BEGIN, (PORTDATA*)pstPortData );
				}
			}
			{
				PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;
				if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
				{
					MDPdelayReq(PTP_EV_BEGIN, pstPortData);
				}
			}
			break;
		case MID_1588_DISABLE_PORT:

			if (pstPortData->pstClockData->stClock_GD.enSelectedState[pstPortData->stPortDS.stPortIdentity.usPortNumber] != ENUM_PORTSTATE_DISABLED)
			{
#ifdef PTP_USE_BMCA
				if ( pstClockData->stBMC_GD.blExternalPortConfiguration == FALSE )
				{
					portAnnounceInformationSM( PTP_EV_CLOSE, pstPortData );
				}
				else
#endif
				{
					portAnnounceInformationExtSM( PTP_EV_CLOSE, (PORTDATA*)pstPortData );
				}
				pstPortData->stPortBMC_GD.enInfoIs = DISABLED;
				pstPortData->pstClockData->stBMC_GD.blReselect[pstPortData->stPortDS.stPortIdentity.usPortNumber] = TRUE;
				pstPortData->pstClockData->stBMC_GD.blSelected[pstPortData->stPortDS.stPortIdentity.usPortNumber] = FALSE;
				pstPortData->stUn_Port_GD.stPortBMC_1588_GD.enBmca1588Evnet = EXT_EV_DESIGNATED_DISABLED;

					portStateSelectionSM(PTP_EV_RESELECT_PORT, pstPortData);
			}
			{
				PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;
				if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
				{
					MDPdelayReq(PTP_EV_CLOSE,pstPortData);
				}
			}
			break;
#endif
#if 1
		case MID_1588_DELAY_MECHANISM:
		case MID_1588_DELAY_MECHANISM + 1:
			{
				PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;
				if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_E2E)
				{
					MDPdelayReq(PTP_EV_CLOSE,pstPortData);
				}
				else if (pstPort_1588->enDelayMechanism == ENUM_DELAYMECHANISM_P2P)
				{
					MDPdelayReq(PTP_EV_BEGIN,pstPortData);
				}
				else
				{
				}

			}
			break;
#endif
		default:
			break;
		}
	}
	return nRet;
}

BOOL GetManagement1588ParamId(ENUM_CLOCKSUPPORTTYPE_1588 enClockSupporType, USHORT usParamId_1588, USHORT* pusTblIndex, USHORT* pusSize)
{
	USHORT	usIndex;
	BOOL	blRet = FALSE;

	for (usIndex = 0; usIndex < MGT_ACT_API_TBLSIZE; usIndex++)
	{
		if (stMgt_Action[usIndex].usManagementId == usParamId_1588)
		{
			blRet = TRUE;
			if ( (stMgt_Action[usIndex].usManagementId == MID_1588_DELAY_MECHANISM) &&
				((enClockSupporType == ENUM_CSTYPE_TRANSCLOCKE2E_1588) ||
				 (enClockSupporType == ENUM_CSTYPE_TRANSCLOCKP2P_1588)))
			{
				usIndex++;
			}
			break;
		}
	}
	if (usIndex < MGT_ACT_API_TBLSIZE)
	{
		*pusTblIndex = usIndex;
		*pusSize = stMgt_Action[usIndex].usMoldTypeSize;
	}
	return blRet;
}

#ifndef	PTP_RESTRICT_GETSET
INT GetIe1588ClockDescription(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData		= (PORTDATA*)pvData;
	CLOCKDATA* 				pstClockData	= pstPortData->pstClockData;
	MGT_CLOCK_DESCRIPTION*	pstInfo			= (MGT_CLOCK_DESCRIPTION*)puchInfo;
	USHORT					usPortNumber;
	IPV6ADDR*				pstL4Ipv6;
	IPV4ADDR*				pstL4Ipv4;
	MACADDR*				pstL2;

	CLOCK_1588_GD*			pstClockGD1588	= &pstClockData->stUn_Clock_GD.stClock_1588_GD;
	MGD_CLOCK_DESCRIPTION*	pstDescription	= &pstClockData->stManagementSM_GD.stMGTClockDscrption;
    pstInfo->byClockType[0] = 0;
    pstInfo->byClockType[1] = 0;
    switch ( pstClockGD1588->enClockSupportType_1588 )
    {
        case ENUM_CSTYPE_ORDINARYCLOCK_1588:
            PTP_SET_BITS( &pstInfo->byClockType[0], 7, 7, TRUE );
            break;
        case ENUM_CSTYPE_BOUNDARYCLOCK_1588:
            PTP_SET_BITS( &pstInfo->byClockType[0], 6, 6, TRUE );
            break;
        case ENUM_CSTYPE_TRANSCLOCKP2P_1588:
            PTP_SET_BITS( &pstInfo->byClockType[0], 5, 5, TRUE );
            break;
        case ENUM_CSTYPE_TRANSCLOCKE2E_1588:
            PTP_SET_BITS( &pstInfo->byClockType[0], 4, 4, TRUE );
            break;
        case ENUM_CSTYPE_MANAGEMENT_1588:
            PTP_SET_BITS( &pstInfo->byClockType[0], 3, 3, TRUE );
            break;
        default:
            break;
    }

	usPortNumber = pstPortData->stPortDS.stPortIdentity.usPortNumber;

	pstInfo->stPhyLyrProtocol.uchTextLength = (USHORT)sizeof(PTP_PHYSICAL_LAYER_PROTOCOL) - 1U;
	tsn_Wrapper_MemCpy( pstInfo->stPhyLyrProtocol.uchTextField, PTP_PHYSICAL_LAYER_PROTOCOL,
						sizeof(PTP_PHYSICAL_LAYER_PROTOCOL));

	pstInfo->usPhyAddressLength = pstDescription->usPhyAddrLength;
	tsn_Wrapper_MemCpy( pstInfo->uchPhyAddress, pstDescription->uchPhysAddress,
						pstInfo->usPhyAddressLength);

	if (pstClockData->pstPortAddrInfo->enClockTrans == CLK_TRANS_IEEE1588_L4_IPV6)
	{
		pstInfo->stProtocolAddress.usNetworkProtcol = PORTADDRESS_PROTOCOL_IPV6;
		pstL4Ipv6 = (IPV6ADDR*)pstClockData->pstPortAddrInfo->pvAddrInfo;
		pstL4Ipv6 = pstL4Ipv6 + (usPortNumber - 1);
		pstInfo->stProtocolAddress.usAddressLength = (USHORT)sizeof(struct ptp_in6_addr);
		tsn_Wrapper_MemCpy( (VOID *)pstInfo->stProtocolAddress.uchAddressField, 
							(VOID *)&pstL4Ipv6->stSrcIpv6Addr.ip6Addr.ip6U8[0],
							sizeof(struct ptp_in6_addr) );
	}
	else if (pstClockData->pstPortAddrInfo->enClockTrans == CLK_TRANS_IEEE1588_L4_IPV4)
	{
		pstInfo->stProtocolAddress.usNetworkProtcol = PORTADDRESS_PROTOCOL_IPV4;
		pstL4Ipv4 = (IPV4ADDR*)pstClockData->pstPortAddrInfo->pvAddrInfo;
		pstL4Ipv4 = pstL4Ipv4 + (usPortNumber - 1);
		pstInfo->stProtocolAddress.usAddressLength = (USHORT)sizeof(ULONG);
		tsn_Wrapper_MemCpy( (VOID *)pstInfo->stProtocolAddress.uchAddressField, 
							(VOID *)&pstL4Ipv4->ulSrcIpv4Addr,
							sizeof(ULONG) );
	}
	else if ((pstClockData->pstPortAddrInfo->enClockTrans == CLK_TRANS_IEEE1588_L2) ||
				(pstClockData->pstPortAddrInfo->enClockTrans == CLK_TRANS_IEEE802_1_AS))
	{
		pstInfo->stProtocolAddress.usNetworkProtcol = PORTADDRESS_PROTOCOL_IEEE802_3;
		pstL2 = (MACADDR*)pstClockData->pstPortAddrInfo->pvAddrInfo;
		pstL2 = pstL2 + (usPortNumber - 1);
		pstInfo->stProtocolAddress.usAddressLength = (USHORT)sizeof(MACADDR);
		tsn_Wrapper_MemCpy( (VOID *)pstInfo->stProtocolAddress.uchAddressField, 
							(VOID *)&pstL2->uchMac[0],
							sizeof(MACADDR) );
	}
	else
	{
		pstInfo->stProtocolAddress.usNetworkProtcol = PORTADDRESS_PROTOCOL_UNKNOWN;
		pstInfo->stProtocolAddress.usAddressLength = 2U;
	}

	tsn_Wrapper_MemCpy(pstInfo->uchManufacturerIdentity, pstDescription->uchManufctrId,
				sizeof(pstInfo->uchManufacturerIdentity));
	pstInfo->stProductDescription.uchTextLength = pstDescription->stPrdctDscrption.uchTextLength;
	tsn_Wrapper_MemCpy( pstInfo->stProductDescription.uchTextField, pstDescription->stPrdctDscrption.uchTextField,
						pstInfo->stProductDescription.uchTextLength);
	pstInfo->stRevisionData.uchTextLength = pstDescription->stRevisionData.uchTextLength;
	tsn_Wrapper_MemCpy( pstInfo->stRevisionData.uchTextField, pstDescription->stRevisionData.uchTextField,
						pstInfo->stRevisionData.uchTextLength);
	pstInfo->stUserDescription.uchTextLength = pstDescription->stUserDscrption.uchTextLength;
	tsn_Wrapper_MemCpy( pstInfo->stUserDescription.uchTextField, pstDescription->stUserDscrption.uchTextField,
						pstInfo->stUserDescription.uchTextLength);
	tsn_Wrapper_MemCpy(pstInfo->uchProfileIdentity, &pstDescription->uchProfileId,
				sizeof(pstInfo->uchProfileIdentity));

	*pusDLen = (SHORT)sizeof(MGT_CLOCK_DESCRIPTION);
	return RET_ENOERR;
}
INT GetIe1588UserDescription(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*				pstClockData	= (CLOCKDATA*)pvData;
	MGT_USER_DESCRIPTION*	pstInfo			= (MGT_USER_DESCRIPTION*)puchInfo;

	MGD_CLOCK_DESCRIPTION*	pstDescription	= &pstClockData->stManagementSM_GD.stMGTClockDscrption;

	pstInfo->stUserDescription.uchTextLength = pstDescription->stUserDscrption.uchTextLength;
	tsn_Wrapper_MemCpy( pstInfo->stUserDescription.uchTextField, pstDescription->stUserDscrption.uchTextField,
						pstInfo->stUserDescription.uchTextLength);

	*pusDLen = (sizeof(MGT_USER_DESCRIPTION));
	return RET_ENOERR;
}

#define	MAX_USER_DESCRIPTION_LEN	128
INT SetIe1588UserDescription(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*				pstClockData	= (CLOCKDATA*)pvData;
	MGT_USER_DESCRIPTION*	pstInfo			= (MGT_USER_DESCRIPTION*)puchInfo;

	MGD_CLOCK_DESCRIPTION*	pstDescription	= &pstClockData->stManagementSM_GD.stMGTClockDscrption;

	pstDescription->stUserDscrption.uchTextLength = pstInfo->stUserDescription.uchTextLength;
	tsn_Wrapper_MemCpy( pstDescription->stUserDscrption.uchTextField, pstInfo->stUserDescription.uchTextField,
						pstDescription->stUserDscrption.uchTextLength);

	*pusDLen = (pstDescription->stUserDscrption.uchTextLength + 1);
	return RET_ENOERR;
}
INT GetIe1588FaultLog(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{

	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	MGT_FAULT_LOG*	pstInfo			= (MGT_FAULT_LOG*)puchInfo;
	LOGRECORD_GD*	pstLogRecord		= &gstLogRecord_GD;

	USHORT			usInCnt			= 0U;
	USHORT			usLoop;
	USHORT			usLogCount;

	usLogCount = 0U;
	usInCnt = usInfoLen / sizeof(MGT_FAULT_RECORD);
	if (usInCnt >= pstLogRecord->usLogRecordBufMax)
	{
		if (pstLogRecord->usLogRecordBufMax == pstLogRecord->usLogRecordNum)
		{
			usLogCount = pstLogRecord->usLogRecordCount;
		}
		else
		{
		}
	}
	else
	{
		if ((pstLogRecord->usLogRecordCount - usInCnt) >= 0 )
		{
			usLogCount = pstLogRecord->usLogRecordCount - usInCnt;
		}
		else if (pstLogRecord->usLogRecordBufMax == pstLogRecord->usLogRecordNum)
		{
			usLogCount	= pstLogRecord->usLogRecordNum - usInCnt;
			usLogCount += pstLogRecord->usLogRecordCount;
		}
		else
		{
		}
	}
	for (usLoop = 0U; ((usLoop < pstLogRecord->usLogRecordNum) && (usLoop < usInCnt)); usLoop++)
	{
		if (usLogCount >= pstLogRecord->usLogRecordBufMax)
		{
			usLogCount = 0U;
		}
		pstInfo->stFaultRecords[usLoop].usFaultRecordLength = 0x1a;
		pstInfo->stFaultRecords[usLoop].stFaultTimestamp	= pstLogRecord->stLogRecordBuf[usLogCount].stLogRcrdTime;
		pstInfo->stFaultRecords[usLoop].uchSeverityCode	= (UCHAR)pstLogRecord->stLogRecordBuf[usLogCount].usLogID;
		pstInfo->stFaultRecords[usLoop].stFaultName.uchTextLength	= 4U;
		HextoShortChar(pstInfo->stFaultRecords[usLoop].stFaultName.uchTextField,
												pstLogRecord->stLogRecordBuf[usLogCount].usLogNameID);
		pstInfo->stFaultRecords[usLoop].stFaultValue.uchTextLength = 8U;
		HextoLongChar(pstInfo->stFaultRecords[usLoop].stFaultValue.uchTextField,
												pstLogRecord->stLogRecordBuf[usLogCount].ulLogVal);
		pstInfo->stFaultRecords[usLoop].stFaultDescription.uchTextLength = 2U;
		HextoCharChar( pstInfo->stFaultRecords[usLoop].stFaultDescription.uchTextField,
					   pstLogRecord->stLogRecordBuf[usLogCount].uchDomainNum );

		usLogCount++;
	}
	pstInfo->usNumOfFaultRecords =	usLoop;
	*pusDLen = (usLoop * (pstInfo->stFaultRecords[0].usFaultRecordLength + 2)) + 2;

	return RET_ENOERR;
}
INT SetIe1588FaultLogReset(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	LOGRECORD_GD*	pstLogRecord		= &gstLogRecord_GD;
	pstLogRecord->usLogRecordNum = 0U;
	pstLogRecord->usLogRecordCount = 0U;

	*pusDLen = (USHORT)sizeof(MGT_FAULT_LOG);
	return RET_ENOERR;
}
INT GetIe1588DefaultDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 				pstClockData	= (CLOCKDATA*)pvData;
	MGT_DEFAULT_DATA_SET*	pstInfo			= (MGT_DEFAULT_DATA_SET*)puchInfo;

	DEFAULT_DS*				pstDefaultDS		= &pstClockData->stDefaultDS;
	DEFAULT_1588_DS*		pstDefaultDS1588	= &pstClockData->stDefault_1588_DS;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstDefaultDS1588->blTwoStepFlag );
    PTP_SET_BITS( &pstInfo->byFlags, 1, 1, pstDefaultDS1588->blSlaveOnly );

	pstInfo->uchReserved1		= 0;
	pstInfo->usNumPorts			= pstDefaultDS->usNumberPorts;
	pstInfo->uchPriority1		= pstDefaultDS->uchPriority1;
	pstInfo->stClockQuality		= pstDefaultDS->stClockQuality;
	pstInfo->uchPriority2		= pstDefaultDS->uchPriority2;
	pstInfo->stClockIdentity	= pstDefaultDS->stClockIdentity;
	pstInfo->uchDomainNum		= pstDefaultDS->uchDomainNumber;
	pstInfo->uchReserved2		= 0;

	*pusDLen = (sizeof(MGT_DEFAULT_DATA_SET));
	return RET_ENOERR;
}
#endif
INT GetIe1588CurrentDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 				pstClockData	= (CLOCKDATA*)pvData;
	MGT_CURRENT_DATA_SET*	pstInfo			= (MGT_CURRENT_DATA_SET*)puchInfo;

	CURRENT_DS*		 pstCurrentDS		= &pstClockData->stCurrentDS;
	CURRENT_1588_DS* pstCurrentDS1588	= &pstClockData->stCurrent_1588_DS;
	pstInfo->usStepsRemoved		= pstCurrentDS->usStepsRemoved;
	pstInfo->stOffsetFromMaster	= pstCurrentDS->stOffsetFromMaster;
	pstInfo->stMeanPathDelay	= pstCurrentDS1588->stMeanPathDelay;

	*pusDLen = (sizeof(MGT_CURRENT_DATA_SET));
	return RET_ENOERR;
}
INT GetIe1588ParentDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 				pstClockData	= (CLOCKDATA*)pvData;
	MGT_PARENT_DATA_SET*	pstInfo			= (MGT_PARENT_DATA_SET*)puchInfo;

	PARENT_DS*		pstParentDS	 = &pstClockData->stParentDS;
	PARENT_1588_DS*	pstParentDS1588 = &pstClockData->stParent_1588_DS;
	pstInfo->stPrntPortIdentity			= pstParentDS->stParentPortIdentity;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstParentDS1588->blParentStats );

	pstInfo->uchReserved1				= 0;
	pstInfo->usObsPrentOfsetScalLogVrnc = pstParentDS1588->usObservedPOSLogVariance;
	pstInfo->lObsPrentClockPhsChngRate	= (LONG)pstParentDS1588->ulObservedPCPhChangeRate;
	pstInfo->uchGMasterPriority1		= pstParentDS->uchGrandmasterPriority1;
	pstInfo->stGMasterClockQuality		= pstParentDS->stGrandmasterClockQuality;
	pstInfo->uchGMasterPriority2		= pstParentDS->uchGrandmasterPriority2;
	pstInfo->stGMasterIdentity			= pstParentDS->stGrandmasterIdentity;

	*pusDLen = (sizeof(MGT_PARENT_DATA_SET));
	return RET_ENOERR;
}
#ifndef	PTP_RESTRICT_GETSET
INT GetIe1588TimePropertiesDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 						pstClockData	= (CLOCKDATA*)pvData;
	MGT_TIME_PROPERTIES_DATA_SET*	pstInfo			= (MGT_TIME_PROPERTIES_DATA_SET*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
	pstInfo->sCrentUtcOffset	= pstTimePropertiesDS->sCurrentUtcOffset;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstTimePropertiesDS->blLeap61 );
    PTP_SET_BITS( &pstInfo->byFlags, 1, 1, pstTimePropertiesDS->blLeap59 );
    PTP_SET_BITS( &pstInfo->byFlags, 2, 2, pstTimePropertiesDS->blCurrentUtcOffsetValid );
    PTP_SET_BITS( &pstInfo->byFlags, 3, 3, pstTimePropertiesDS->blPtpTimescale );
    PTP_SET_BITS( &pstInfo->byFlags, 4, 4, pstTimePropertiesDS->blTimeTraceable );
    PTP_SET_BITS( &pstInfo->byFlags, 5, 5, pstTimePropertiesDS->blFrequencyTraceable );

	pstInfo->uchTimeSource	= pstTimePropertiesDS->uchTimeSource;

	*pusDLen = (sizeof(MGT_TIME_PROPERTIES_DATA_SET));
	return RET_ENOERR;
}
INT GetIe1588PortDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*			pstPortData = (PORTDATA*)pvData;
	MGT_PORT_DATA_SET*	pstInfo		= (MGT_PORT_DATA_SET*)puchInfo;

	PORT_DS*		pstPortDS	   = &pstPortData->stPortDS;
	PORT_1588_DS*	pstPortDS1588 = &pstPortData->stPort_1588_DS;
	BMC_1588_GD*	pstBmc1588Gd = &pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD;

	pstInfo->stPortIdentity			= pstPortDS->stPortIdentity;
	pstInfo->uchPortState			= pstBmc1588Gd->uchExtSelectedState[pstPortDS->stPortIdentity.usPortNumber];
	pstInfo->chLogMinDReqInterval	= pstPortDS1588->chLogMinDelayReqInterval;
	pstInfo->stPerMeanPathDelay		= pstPortDS1588->stPeerMeanPathDelay;
	pstInfo->chLogAnounceInterval	= pstPortDS1588->chLogAnnounceInterval;
	pstInfo->uchAnounceRcptTimeout	= pstPortDS->uchAnnounceReceiptTimeout;
	pstInfo->chLogSyncInterval		= pstPortDS1588->chLogSyncInterval;
	pstInfo->uchDelayMechanism		= (UCHAR)pstPortDS1588->enDelayMechanism;
	pstInfo->chLogMinPDReqInterval	= pstPortDS1588->chLogMinPdelayReqInterval;
	pstInfo->byVerNum				= pstPortDS->byVersionNumber;

	*pusDLen = (sizeof(MGT_PORT_DATA_SET));
	return RET_ENOERR;
}
INT GetIe1588Priority1(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIORITY1*	pstInfo			= (MGT_PRIORITY1*)puchInfo;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	pstInfo->uchPriority1		= pstDefaultDS->uchPriority1;
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_PRIORITY1));
	return RET_ENOERR;
}
INT SetIe1588Priority1(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIORITY1*	pstInfo			= (MGT_PRIORITY1*)puchInfo;
	INT				nRet			= RET_ENOERR;

	UCHAR			uchOldPriority;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	uchOldPriority = pstDefaultDS->uchPriority1;

	pstDefaultDS->uchPriority1 = pstInfo->uchPriority1;
#if 1
	if (uchOldPriority == pstDefaultDS->uchPriority1)
	{
		nRet = RET_SAMEVAL;
	}
#endif
	*pusDLen = (sizeof(MGT_PRIORITY1));
	return nRet;
}
INT GetIe1588Priority2(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIORITY2*	pstInfo			= (MGT_PRIORITY2*)puchInfo;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	pstInfo->uchPriority2		= pstDefaultDS->uchPriority2;
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_PRIORITY2));
	return RET_ENOERR;
}
INT SetIe1588Priority2(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIORITY2*	pstInfo			= (MGT_PRIORITY2*)puchInfo;
	INT				nRet			= RET_ENOERR;

	UCHAR			uchOldPriority;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	uchOldPriority = pstDefaultDS->uchPriority2;
	pstDefaultDS->uchPriority2 = pstInfo->uchPriority2;

#if 1
	if (uchOldPriority == pstDefaultDS->uchPriority2)
	{
		nRet = RET_SAMEVAL;
	}
#endif
	*pusDLen = (sizeof(MGT_PRIORITY2));
	return nRet;
}




INT GetIe1588SlaveOnly(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 		pstClockData	= (CLOCKDATA*)pvData;
	MGT_SLAVE_ONLY*	pstInfo			= (MGT_SLAVE_ONLY*)puchInfo;

	DEFAULT_1588_DS* pstDefaultDS1588	= &pstClockData->stDefault_1588_DS;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstDefaultDS1588->blSlaveOnly );

	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_SLAVE_ONLY));
	return RET_ENOERR;
}
INT SetIe1588SlaveOnly(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*		pstClockData	= (CLOCKDATA*)pvData;
	MGT_SLAVE_ONLY*	pstInfo			= (MGT_SLAVE_ONLY*)puchInfo;

	DEFAULT_1588_DS* pstDefaultDS1588	= &pstClockData->stDefault_1588_DS;
    pstDefaultDS1588->blSlaveOnly = PTP_GET_BITS( &pstInfo->byFlags, 0, 0 );

	*pusDLen = (sizeof(MGT_SLAVE_ONLY));
	return RET_ENOERR;
}
INT GetIe1588LogAnnounInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_LOG_ANNOUNCE_INTERVAL*	pstInfo		= (MGT_LOG_ANNOUNCE_INTERVAL*)puchInfo;

	PORT_1588_DS*	pstPortDS1588 = &pstPortData->stPort_1588_DS;
	pstInfo->chLogAnounceInterval	= pstPortDS1588->chLogAnnounceInterval;
	pstInfo->uchReserved1			= 0;

	*pusDLen = (sizeof(MGT_LOG_ANNOUNCE_INTERVAL));
	return RET_ENOERR;
}
INT SetIe1588LogAnnounInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_LOG_ANNOUNCE_INTERVAL*	pstInfo		= (MGT_LOG_ANNOUNCE_INTERVAL*)puchInfo;

	PORT_1588_DS*	pstPortDS1588 = &pstPortData->stPort_1588_DS;
	pstPortDS1588->chLogAnnounceInterval = pstInfo->chLogAnounceInterval;

	*pusDLen = (sizeof(MGT_LOG_ANNOUNCE_INTERVAL));
	return RET_ENOERR;
}
INT GetIe1588AnnounReceiptTimeout(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*						pstPortData = (PORTDATA*)pvData;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT*	pstInfo		= (MGT_ANNOUNCE_RECEIPT_TIMEOUT*)puchInfo;

	PORT_DS*		pstPortDS	   = &pstPortData->stPortDS;
	pstInfo->uchAnounceRcptTimeout	= pstPortDS->uchAnnounceReceiptTimeout;
	pstInfo->uchReserved1			= 0;

	*pusDLen = (sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT));
	return RET_ENOERR;
}
INT SetIe1588AnnounReceiptTimeout(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*						pstPortData = (PORTDATA*)pvData;
	MGT_ANNOUNCE_RECEIPT_TIMEOUT*	pstInfo		= (MGT_ANNOUNCE_RECEIPT_TIMEOUT*)puchInfo;

	PORT_DS*		pstPortDS	   = &pstPortData->stPortDS;
	pstPortDS->uchAnnounceReceiptTimeout = pstInfo->uchAnounceRcptTimeout;

	*pusDLen = (sizeof(MGT_ANNOUNCE_RECEIPT_TIMEOUT));
	return RET_ENOERR;
}
INT GetIe1588LogSyncInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData = (PORTDATA*)pvData;
	MGT_LOG_SYNC_INTERVAL*	pstInfo		= (MGT_LOG_SYNC_INTERVAL*)puchInfo;

	PORT_1588_DS*	pstPortDS1588 = &pstPortData->stPort_1588_DS;
	pstInfo->chLogSyncInterval	= pstPortDS1588->chLogSyncInterval;
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_LOG_SYNC_INTERVAL));
	return RET_ENOERR;
}
INT SetIe1588LogSyncInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData = (PORTDATA*)pvData;
	MGT_LOG_SYNC_INTERVAL*	pstInfo		= (MGT_LOG_SYNC_INTERVAL*)puchInfo;

	PORT_1588_DS*	pstPortDS1588 = &pstPortData->stPort_1588_DS;
	pstPortDS1588->chLogSyncInterval = pstInfo->chLogSyncInterval;

	*pusDLen = (sizeof(MGT_LOG_SYNC_INTERVAL));
	return RET_ENOERR;
}
INT GetIe1588VersionNum(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*			pstPortData = (PORTDATA*)pvData;
	MGT_VERSION_NUMBER*	pstInfo		= (MGT_VERSION_NUMBER*)puchInfo;

	PORT_DS*		pstPortDS	   = &pstPortData->stPortDS;
	pstInfo->byVerNum				= pstPortDS->byVersionNumber;
	pstInfo->uchReserved1			= 0;

	*pusDLen = (sizeof(MGT_LOG_SYNC_INTERVAL));
	return RET_ENOERR;
}
INT SetIe1588VersionNum(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*			pstPortData = (PORTDATA*)pvData;
	MGT_VERSION_NUMBER*	pstInfo		= (MGT_VERSION_NUMBER*)puchInfo;

	PORT_DS*		pstPortDS	   = &pstPortData->stPortDS;
	pstPortDS->byVersionNumber		= pstInfo->byVerNum;

	*pusDLen = (sizeof(MGT_LOG_SYNC_INTERVAL));
	return RET_ENOERR;
}
INT SetIe1588EnablePort(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{

#if 1
	INT		iRet = RET_ENOERR;
#endif
	if (ptp_portStatus_des((PORTDATA*)pvData))
	{
		iRet = RET_SAMEVAL;
	}

	ptp_portenable_des((PORTDATA*)pvData);

	*pusDLen = 0;

	return iRet;
}
INT SetIe1588DisablePort(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{

#if 1
	INT		iRet = RET_ENOERR;
#endif
	if (!ptp_portStatus_des((PORTDATA*)pvData))
	{
		iRet = RET_SAMEVAL;
	}

	ptp_portdisable_des((PORTDATA*)pvData);

	*pusDLen = 0;

	return iRet;
}
INT GetIe1588Time(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 	pstClockData	= (CLOCKDATA*)pvData;
	MGT_TIME*	pstInfo			= (MGT_TIME*)puchInfo;

	USCALEDNS		stA_USNs	= {0};
	TIMESTAMP		stB_TS		= {0};

	ptp_GetCurrentMasterTime(pstClockData, &stA_USNs);
	ptpConvUSNs_TS(&stA_USNs, &stB_TS);

	pstInfo->stTime = stB_TS;

	*pusDLen = (sizeof(MGT_TIME));
	return RET_ENOERR;
}
INT SetIe1588Time(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*	pstClockData	= (CLOCKDATA*)pvData;
	MGT_TIME*	pstInfo			= (MGT_TIME*)puchInfo;

	USCALEDNS		stA_USNs	= {0};
	TIMESTAMP		stB_TS		= {0};

	stB_TS = pstInfo->stTime;
	ptpConvTS_USNs(&stB_TS, &stA_USNs);
	(VOID)ptp_TimerSemLockWait();

	gstCurrentMasterTime = stA_USNs;
	(VOID)ptp_TimerSemUnLock();

	*pusDLen = (sizeof(MGT_TIME));
	return RET_ENOERR;
}
INT GetIe1588ClockAccuracy(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 			pstClockData	= (CLOCKDATA*)pvData;
	MGT_CLOCK_ACCURACY*	pstInfo			= (MGT_CLOCK_ACCURACY*)puchInfo;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	pstInfo->uchClockAccuracy	= pstDefaultDS->stClockQuality.uchClockAccuracy;
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_CLOCK_ACCURACY));
	return RET_ENOERR;
}
INT SetIe1588ClockAccuracy(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*			pstClockData	= (CLOCKDATA*)pvData;
	MGT_CLOCK_ACCURACY*	pstInfo			= (MGT_CLOCK_ACCURACY*)puchInfo;

	DEFAULT_DS*		 pstDefaultDS		= &pstClockData->stDefaultDS;
	pstDefaultDS->stClockQuality.uchClockAccuracy	= pstInfo->uchClockAccuracy;

	if (pstClockData->stClock_GD.enSelectedState[0]==ENUM_PORTSTATE_SLAVE)
	{
		pstClockData->stParentDS.stGrandmasterClockQuality.uchClockAccuracy	= pstInfo->uchClockAccuracy;
	}
	else
	{
	}

	*pusDLen = (sizeof(MGT_CLOCK_ACCURACY));
	return RET_ENOERR;
}
INT GetIe1588UtcProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 			pstClockData	= (CLOCKDATA*)pvData;
	MGT_UTC_PROPERTIES*	pstInfo			= (MGT_UTC_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
	pstInfo->sCrentUtcOffset	= pstTimePropertiesDS->sCurrentUtcOffset;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstTimePropertiesDS->blLeap61 );
    PTP_SET_BITS( &pstInfo->byFlags, 1, 1, pstTimePropertiesDS->blLeap59 );
    PTP_SET_BITS( &pstInfo->byFlags, 2, 2, pstTimePropertiesDS->blCurrentUtcOffsetValid );

	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_UTC_PROPERTIES));
	return RET_ENOERR;
}
INT SetIe1588UtcProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*			pstClockData	= (CLOCKDATA*)pvData;
	MGT_UTC_PROPERTIES*	pstInfo			= (MGT_UTC_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
	pstTimePropertiesDS->sCurrentUtcOffset	= pstInfo->sCrentUtcOffset;
    pstTimePropertiesDS->blLeap61                = PTP_GET_BITS( &pstInfo->byFlags, 0, 0 );
    pstTimePropertiesDS->blLeap59                = PTP_GET_BITS( &pstInfo->byFlags, 1, 1 );
    pstTimePropertiesDS->blCurrentUtcOffsetValid = PTP_GET_BITS( &pstInfo->byFlags, 2, 2 );

	*pusDLen = (sizeof(MGT_UTC_PROPERTIES));
	return RET_ENOERR;
}
INT GetIe1588TraceProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 						pstClockData	= (CLOCKDATA*)pvData;
	MGT_TRACEABILITY_PROPERTIES*	pstInfo			= (MGT_TRACEABILITY_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
    PTP_SET_BITS( &pstInfo->byFlags, 4, 4, pstTimePropertiesDS->blTimeTraceable );
    PTP_SET_BITS( &pstInfo->byFlags, 5, 5, pstTimePropertiesDS->blFrequencyTraceable );
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_TRACEABILITY_PROPERTIES));
	return RET_ENOERR;
}
INT SetIe1588TraceProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*						pstClockData	= (CLOCKDATA*)pvData;
	MGT_TRACEABILITY_PROPERTIES*	pstInfo			= (MGT_TRACEABILITY_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
    pstTimePropertiesDS->blTimeTraceable      = PTP_GET_BITS( &pstInfo->byFlags, 4, 4 );
    pstTimePropertiesDS->blFrequencyTraceable = PTP_GET_BITS( &pstInfo->byFlags, 5, 5 );

	*pusDLen = (sizeof(MGT_TRACEABILITY_PROPERTIES));
	return RET_ENOERR;
}
INT GetIe1588TimesProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 					pstClockData	= (CLOCKDATA*)pvData;
	MGT_TIMESCALE_PROPERTIES*	pstInfo			= (MGT_TIMESCALE_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
    PTP_SET_BITS( &pstInfo->byFlags, 3, 3, pstTimePropertiesDS->blPtpTimescale );
	pstInfo->uchTimeSource	= pstTimePropertiesDS->uchTimeSource;

	*pusDLen = (sizeof(MGT_TIMESCALE_PROPERTIES));
	return RET_ENOERR;
}
INT SetIe1588TimesProperties(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*					pstClockData	= (CLOCKDATA*)pvData;
	MGT_TIMESCALE_PROPERTIES*	pstInfo			= (MGT_TIMESCALE_PROPERTIES*)puchInfo;

	TIMEPROPERTIES_DS*	pstTimePropertiesDS = &pstClockData->stTimePropertiesDS;
    pstTimePropertiesDS->blPtpTimescale = PTP_GET_BITS( &pstInfo->byFlags, 3, 3 );
	pstTimePropertiesDS->uchTimeSource	= pstInfo->uchTimeSource;

	*pusDLen = (sizeof(MGT_TIMESCALE_PROPERTIES));
	return RET_ENOERR;
}
INT GetIe1588PathTraceList(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 				pstClockData	= (CLOCKDATA*)pvData;
	MGT_PATH_TRACE_LIST*	pstInfo			= (MGT_PATH_TRACE_LIST*)puchInfo;

	USHORT	usPathTraceLen = 0;

	BMC_GD*	pstPathTraceGD = &pstClockData->stBMC_GD;

#if 1
	pstInfo->usPathSequenceNum = 0;
#endif
	if (pstPathTraceGD->uchPathTraceCount != 0)
	{
		usPathTraceLen = (USHORT)((sizeof(CLOCKIDENTITY) * pstPathTraceGD->uchPathTraceCount));
		tsn_Wrapper_MemCpy(pstInfo->stPathSequence, pstPathTraceGD->stPathTrace, usPathTraceLen);
#if 1
		pstInfo->usPathSequenceNum = pstPathTraceGD->uchPathTraceCount;
#endif
	}
	*pusDLen = usPathTraceLen;
	return RET_ENOERR;
}
INT GetIe1588PathTraceEnable(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA* 				pstClockData	= (CLOCKDATA*)pvData;
	MGT_PATH_TRACE_ENABLE*	pstInfo			= (MGT_PATH_TRACE_ENABLE*)puchInfo;

	BMC_GD*	pstPathTraceGD = &pstClockData->stBMC_GD;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstPathTraceGD->blPathTraceEnable );
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_PATH_TRACE_ENABLE));
	return RET_ENOERR;
}
INT SetIe1588PathTraceEnable(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	CLOCKDATA*				pstClockData	= (CLOCKDATA*)pvData;
	MGT_PATH_TRACE_ENABLE*	pstInfo			= (MGT_PATH_TRACE_ENABLE*)puchInfo;

	BMC_GD*	pstPathTraceGD = &pstClockData->stBMC_GD;
    pstPathTraceGD->blPathTraceEnable = PTP_GET_BITS( &pstInfo->byFlags, 0, 0 );

	*pusDLen = (sizeof(MGT_PATH_TRACE_ENABLE));
	return RET_ENOERR;
}
INT GetIe1588PortStatCount(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_PORT_STATISTICS_COUNT*	pstInfo		= (MGT_PORT_STATISTICS_COUNT*)puchInfo;

	PORTSTATISTICS_1AS_DS*	pstPortStatistics = &pstPortData->stPortStatistics_1AS_DS;
	pstInfo->ulRxSyncCount					= pstPortStatistics->ulRxSyncCount;
	pstInfo->ulRxOneStepSyncCount			= pstPortStatistics->ulRxOneStepSyncCount;
	pstInfo->ulRxFollowUpCount				= pstPortStatistics->ulRxFollowUpCount;
	pstInfo->ulRxAnnounceCount				= pstPortStatistics->ulRxAnnounceCount;
	pstInfo->ulRxPTPPacketDiscardCount		= pstPortStatistics->ulRxPTPPacketDiscardCount;
	pstInfo->ulSyncReceiptTimeoutCount		= pstPortStatistics->ulSyncReceiptTimeoutCount;
	pstInfo->ulAnnounceReceiptTimeoutCount	= pstPortStatistics->ulAnnounceReceiptTimeoutCount;
	pstInfo->ulTxSyncCount					= pstPortStatistics->ulTxSyncCount;
	pstInfo->ulTxOneStepSyncCount			= pstPortStatistics->ulTxOneStepSyncCount;
	pstInfo->ulTxFollowUpCount				= pstPortStatistics->ulTxFollowUpCount;
	pstInfo->ulTxAnnounceCount				= pstPortStatistics->ulTxAnnounceCount;

	*pusDLen = (sizeof(MGT_PORT_STATISTICS_COUNT));
	return RET_ENOERR;
}
INT GetIe1588CmldStatPortCount(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_CMLD_PORT_STATIS_COUNT*	pstInfo		= (MGT_CMLD_PORT_STATIS_COUNT*)puchInfo;
	CMLDSPORTSTATISTICS_1AS_DS*	pstPortStatistics = pstPortData->stPort_1588_GD.pstCmldsPortStatDs;
	
	pstInfo->ulRxPDReqCount					= pstPortStatistics->ulRxPdelayRequestCount;
	pstInfo->ulRxPDRespCount				= pstPortStatistics->ulRxPdelayResponseCount;
	pstInfo->ulRxPDRespFollowUpCount		= pstPortStatistics->ulRxPdelayResponseFollowUpCount;
	pstInfo->ulRxPTPPacketDiscardCount		= pstPortStatistics->ulRxPTPPacketDiscardCount;
	pstInfo->ulPDAllowedLostRespExceedCount = pstPortStatistics->ulPdelayAllwLostRespExcdCount;
	pstInfo->ulTxPDReqCount					= pstPortStatistics->ulTxPdelayRequestCount;
	pstInfo->ulTxPDRespCount				= pstPortStatistics->ulTxPdelayResponseCount;
	pstInfo->ulTxPDRespFollowUpCount		= pstPortStatistics->ulTxPdelayResponseFollowUpCount;

	*pusDLen = (sizeof(MGT_CMLD_PORT_STATIS_COUNT));
	return RET_ENOERR;
}
INT GetIe1588TransClockDefaultDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
#ifdef	PTP_USE_TRANS
	CLOCKDATA* 					pstClockData	= (CLOCKDATA*)pvData;
	MGT_TCLK_DEFAULT_DATA_SET*	pstInfo			= (MGT_TCLK_DEFAULT_DATA_SET*)puchInfo;

	TCDEFAULT_1588_DS* pstTCDefault1588 = &pstClockData->stTCDefault_1588_DS;
	pstInfo->stClockIdentity	= pstTCDefault1588->stClockIdentity;
	pstInfo->usNumberPorts		= pstTCDefault1588->usNumberPorts;
	pstInfo->uchDelayMechanism	= pstTCDefault1588->enDdelayMechanism;
	pstInfo->uchPrimaryDomain	= pstTCDefault1588->uchPprimaryDomain;

	*pusDLen = (sizeof(MGT_CMLD_PORT_STATIS_COUNT));
	return RET_ENOERR;
#else
	return	RET_EINVAL;
#endif
}
INT GetIe1588TransClockPortDS(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData = (PORTDATA*)pvData;
	MGT_TCLK_PORT_DATA_SET*	pstInfo		= (MGT_TCLK_PORT_DATA_SET*)puchInfo;

	TRANSPARENTCLOCKPORT_1588_DS*	pstTCPortDS1588 = &pstPortData->stTransparentClockPort_1588_DS;
	pstInfo->stPortIdentity				= pstTCPortDS1588->stPortIdentity;
    PTP_SET_BITS( &pstInfo->byFlags, 0, 0, pstTCPortDS1588->blFaultyFlag );
	pstInfo->chLogMinPdelayReqInterval	= pstTCPortDS1588->chLogMinPdelayReqInterval;
	pstInfo->stPeerMeanPathDelay		= pstTCPortDS1588->stPeerMeanPathDelay;

	*pusDLen = (sizeof(MGT_TCLK_PORT_DATA_SET));
	return RET_ENOERR;
}
INT GetIe1588PrimaryDomain(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
#ifdef	PTP_USE_TRANS
	CLOCKDATA* 			pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIMARY_DOMAIN*	pstInfo			= (MGT_PRIMARY_DOMAIN*)puchInfo;

	TCDEFAULT_1588_DS* pstTCDefault1588 = &pstClockData->stTCDefault_1588_DS;
	pstInfo->uchPrimaryDomain	= pstTCDefault1588->uchPprimaryDomain;
	pstInfo->uchReserved1		= 0;

	*pusDLen = (sizeof(MGT_PRIMARY_DOMAIN));
	return RET_ENOERR;
#else
	return	RET_EINVAL;
#endif
}
INT SetIe1588PrimaryDomain(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
#ifdef	PTP_USE_TRANS
	CLOCKDATA*			pstClockData	= (CLOCKDATA*)pvData;
	MGT_PRIMARY_DOMAIN*	pstInfo			= (MGT_PRIMARY_DOMAIN*)puchInfo;

	TCDEFAULT_1588_DS* pstTCDefault1588 = &pstClockData->stTCDefault_1588_DS;
	pstTCDefault1588->uchPprimaryDomain	= pstInfo->uchPrimaryDomain;

	*pusDLen = 0;
	return RET_ENOERR;
#else
	return	RET_EINVAL;
#endif
}
INT GetIe1588DelayMechanism(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData = (PORTDATA*)pvData;
	MGT_DELAY_MECHANISM*	pstInfo		= (MGT_DELAY_MECHANISM*)puchInfo;

	PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;
	pstInfo->uchDelayMechanism = (UCHAR)pstPort_1588->enDelayMechanism;
	pstInfo->uchReserved1		 = 0;

	*pusDLen = (sizeof(MGT_DELAY_MECHANISM));
	return RET_ENOERR;
}
INT SetIe1588DelayMechanism(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*				pstPortData = (PORTDATA*)pvData;
	MGT_DELAY_MECHANISM*	pstInfo		= (MGT_DELAY_MECHANISM*)puchInfo;

	CMLDSPORT_1AS_DS*		pstCmldsPortDS = pstPortData->stPort_1588_GD.pstCmldsPortDs;

	PORT_1588_DS* pstPort_1588 = &pstPortData->stPort_1588_DS;
#if 1
	if (pstPort_1588->enDelayMechanism == (ENUM_DELAYMECHANISM)pstInfo->uchDelayMechanism)
	{
		return	RET_SAMEVAL;
	}
#endif


	switch( (INT)pstInfo->uchDelayMechanism )
	{
		case ENUM_DELAYMECHANISM_E2E:
			pstCmldsPortDS->blCmldsPortEnabled = FALSE;
			break;
		case ENUM_DELAYMECHANISM_P2P:
			pstCmldsPortDS->blCmldsPortEnabled = TRUE;
			break;
		default:
			return	RET_EINVAL;
	}
	pstPort_1588->enDelayMechanism	= (ENUM_DELAYMECHANISM)pstInfo->uchDelayMechanism;


	*pusDLen = (sizeof(MGT_DELAY_MECHANISM));
	return RET_ENOERR;
}
INT GetIe1588DelayMechanismTC(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
#ifdef	PTP_USE_TRANS
	CLOCKDATA*				pstClockData	= (CLOCKDATA*)pvData;
	MGT_DELAY_MECHANISM*	pstInfo			= (MGT_DELAY_MECHANISM*)puchInfo;

	TCDEFAULT_1588_DS* pstTCDefault1588 = &pstClockData->stTCDefault_1588_DS;
	pstInfo->uchDelayMechanism = pstTCDefault1588->enDdelayMechanism;
	pstInfo->uchReserved1		 = 0;

	*pusDLen = (sizeof(MGT_DELAY_MECHANISM));
	return RET_ENOERR;
#else
	return	RET_EINVAL;
#endif
}
INT SetIe1588DelayMechanismTC(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
#ifdef	PTP_USE_TRANS
	CLOCKDATA*			pstClockData	= (CLOCKDATA*)pvData;
	MGT_DELAY_MECHANISM*	pstInfo		= (MGT_DELAY_MECHANISM*)puchInfo;
	PORTDATA*				pstPortWork;

	TCDEFAULT_1588_DS* pstTCDefault1588 = &pstClockData->stTCDefault_1588_DS;

	switch( (INT)pstInfo->uchDelayMechanism )
	{
		case ENUM_DELAYMECHANISM_E2E:
			pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_TRANSCLOCKE2E_1588;
			break;
		case ENUM_DELAYMECHANISM_P2P:
			pstClockData->stUn_Clock_GD.stClock_1588_GD.enClockSupportType_1588 = ENUM_CSTYPE_TRANSCLOCKP2P_1588;
			break;
		default:
			return RET_EINVAL;
	}
	pstTCDefault1588->enDdelayMechanism	= (ENUM_DELAYMECHANISM)pstInfo->uchDelayMechanism;


	pstPortWork = pstClockData->pstPortData;

	while (pstPortWork != NULL)
	{
		if (pstTCDefault1588->enDdelayMechanism == ENUM_DELAYMECHANISM_E2E)
		{
			pstPortWork->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled = FALSE;
		}
		else
		{
			pstPortWork->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled = TRUE;
		}
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}


	*pusDLen = (sizeof(MGT_DELAY_MECHANISM));
	return RET_ENOERR;
#else
	return RET_EINVAL;
#endif
}
INT GetIe1588LogMinPDReqInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_LOG_MIN_PDREQ_INTERVAL*	pstInfo		= (MGT_LOG_MIN_PDREQ_INTERVAL*)puchInfo;

	TRANSPARENTCLOCKPORT_1588_DS*	pstTCPortDS1588 = &pstPortData->stTransparentClockPort_1588_DS;
	pstInfo->chLogMinPdelayReqInterval	= pstTCPortDS1588->chLogMinPdelayReqInterval;
	pstInfo->uchReserved1				= 0;

	*pusDLen = (sizeof(MGT_LOG_MIN_PDREQ_INTERVAL));
	return RET_ENOERR;
}
INT SetIe1588LogMinPDReqInterval(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	PORTDATA*					pstPortData = (PORTDATA*)pvData;
	MGT_LOG_MIN_PDREQ_INTERVAL*	pstInfo		= (MGT_LOG_MIN_PDREQ_INTERVAL*)puchInfo;

	TRANSPARENTCLOCKPORT_1588_DS*	pstTCPortDS1588 = &pstPortData->stTransparentClockPort_1588_DS;
	pstTCPortDS1588->chLogMinPdelayReqInterval	= pstInfo->chLogMinPdelayReqInterval;
	pstPortData->stPort_1588_DS.chLogMinPdelayReqInterval = pstInfo->chLogMinPdelayReqInterval;

	*pusDLen = (sizeof(MGT_LOG_MIN_PDREQ_INTERVAL));
	return RET_ENOERR;
}
#endif


INT NopIe1588_NOP(VOID* pvData, UCHAR* puchInfo, USHORT usInfoLen, USHORT* pusDLen)
{
	*pusDLen = 0;
	return RET_EINVAL;
}
