//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#ifndef _MSW_LLDP_H_
#define _MSW_LLDP_H_

#include "msw_lldp_depend.h"



#define MSW_LLDP_MODULE_NUM     5
#define MSW_LLDP_PORT_NUM       2
#define MSW_LLDP_MNGTLV_NUM     3
#define MSW_LLDP_IFNAME_LEN     32

#define MSW_DISABLE             0
#define MSW_ENABLE              1

#define MSW_EC_NO_ERROR         0
#define MSW_EC_ERROR            -1
#define MSW_EC_NOT_INIT         -2
#define MSW_EC_NOT_FOUND        -3
#define MSW_EC_EXIST            -4
#define MSW_EC_FULL             -5
#define MSW_EC_EPARAM           -6
#define MSW_EC_SUBTYPE          -7
#define MSW_EC_LLDPERR          -8

#define ETH_ADR_SZ              6
#define ETH_HDR_SZ              14
#if MSW_USE_ALAXALA
#define ETH_TYPE_LLDP           0xe0eb
#else
#define ETH_TYPE_LLDP           0x88cc
#endif

#define LLDPDU_MAX_SZ           1500
#define LLDPD_MAX_TLV_SZ        513

#define FIX_TTL_SZ              2
#define FIX_EOL_SZ              2

#define TYPE_EOL                0
#define TYPE_CHASSISID          1
#define TYPE_PORTID             2
#define TYPE_TIMETOLIVE         3
#define TYPE_PORTDES            4
#define TYPE_SYSNAME            5
#define TYPE_SYSDES             6
#define TYPE_SYSCAP             7
#define TYPE_MNGADDR            8
#define TYPE_ORGANIZE           127

enum lldp_mc_type {
    NEAREST_BRIDGE = 0,
    NEAREST_NONTPMR_BRIDGE,
    NEAREST_CUSTOMER_BRIDGE,
    MSW_LLDP_MC_NUM
};

#define MSW_LLDP_LINFO_NUM (MSW_LLDP_PORT_NUM*MSW_LLDP_MC_NUM)

#define RX_NEAREST_BRIDGE                (1 << 0)
#define RX_NEAREST_NONTPMR_BRIDGE        (1 << 1)
#define RX_NEAREST_CUSTOMER_BRIDGE       (1 << 2)
#define RX_NEAREST_ALL                   (RX_NEAREST_BRIDGE | \
                                          RX_NEAREST_NONTPMR_BRIDGE | \
                                          RX_NEAREST_CUSTOMER_BRIDGE)
#define TX_NEAREST_BRIDGE                (1 << 4)
#define TX_NEAREST_NONTPMR_BRIDGE        (1 << 5)
#define TX_NEAREST_CUSTOMER_BRIDGE       (1 << 6)
#define TX_NEAREST_ALL                   (TX_NEAREST_BRIDGE | \
                                          TX_NEAREST_NONTPMR_BRIDGE | \
                                          TX_NEAREST_CUSTOMER_BRIDGE)
#define ACCEPT_DEF_MCBITMAP              (1 << 7)

enum status_admin {
    TX_ONLY   = 1,
    RX_ONLY   = 2,
    TX_AND_RX = 3,
    DISABLED  = 4,
};


#define LLDPH2LEN(x)  (x & 0x01FF)
#define LLDPH2TYPE(x) ((x >> 9) & 0x7F)

#define CREATE_LLDP_HDR(header, type, len) {\
        header = 0; \
        header = (((type & 0x007F) << 9) | (len & 0x01FF)); \
        header = htons(header); }\


#define CHA_ID_SUBTYPE_SHA      1
#define CHA_ID_SUBTYPE_IFA      2
#define CHA_ID_SUBTYPE_POR      3
#define CHA_ID_SUBTYPE_MAC      4
#define CHA_ID_SUBTYPE_ADR      5
#define CHA_ID_SUBTYPE_IFN      6
#define CHA_ID_SUBTYPE_LOC      7

#define Max_SZCHASSIS           258
#define Max_SZCHASSIS_INFO      255
#define Min_SZCHASSIS_INFO      1
typedef struct MSW_TLV_CHASIIS {
    unsigned char   iscreate;
    unsigned short  curlen;
    unsigned char   subtype;
    unsigned char   id[Max_SZCHASSIS_INFO];
} MSW_TLV_CHASIIS_T;

#define POR_ID_SUBTYPE_IFA      1
#define POR_ID_SUBTYPE_POR      2
#define POR_ID_SUBTYPE_MAC      3
#define POR_ID_SUBTYPE_ADR      4
#define POR_ID_SUBTYPE_IFN      5
#define POR_ID_SUBTYPE_ACI      6
#define POR_ID_SUBTYPE_LOC      7

#define Max_SZPORTID            258
#define Max_SZPORTID_INFO       255
#define Min_SZPORTID_INFO       1
typedef struct MSW_TLV_PORTID {
    unsigned char   iscreate;
    unsigned short  curlen;
    unsigned char   subtype;
    unsigned char   id[Max_SZPORTID_INFO];
} MSW_TLV_PORTID_T;

#define Fix_SZTTL               4
#define Fix_SZTTL_INFO          2
typedef struct MSW_TLV_TTL {
    unsigned char   iscreate;
    unsigned short  ttl;
} MSW_TLV_TTL_T;

#define Max_SZPORTDES           257
#define Max_SZPORTDES_INFO      255
#define Min_SZPORTDES_INFO      0
typedef struct MSW_TLV_PORTDES {
    unsigned char   status;
    unsigned short  curlen;
    unsigned char   pdes[Max_SZPORTDES_INFO];
} MSW_TLV_PORTDES_T;

#define Max_SZSYSNAME           257
#define Max_SZSYSNAME_INFO      255
#define Min_SZSYSNAME_INFO      0
typedef struct MSW_TLV_SYSNAME {
    unsigned char   status;
    unsigned short  curlen;
    unsigned char   name[Max_SZSYSNAME_INFO];
} MSW_TLV_SYSNAME_T;

#define Max_SZSYSDES             257
#define Max_SZSYSDES_INFO        255
#define Min_SZSYSDES_INFO        0
typedef struct MSW_TLV_SYSDES {
    unsigned char   status;
    unsigned short  curlen;
    unsigned char   sdes[Max_SZSYSDES_INFO];
} MSW_TLV_SYSDES_T;

#define SYSTEM_CAP_OTHER        (1 << 0)
#define SYSTEM_CAP_REP          (1 << 1)
#define SYSTEM_CAP_MAC          (1 << 2)
#define SYSTEM_CAP_WLAN         (1 << 3)
#define SYSTEM_CAP_ROT          (1 << 4)
#define SYSTEM_CAP_TEL          (1 << 5)
#define SYSTEM_CAP_DOC          (1 << 6)
#define SYSTEM_CAP_STA          (1 << 7)
#define SYSTEM_CAP_CVLAN        (1 << 8)
#define SYSTEM_CAP_SVLAN        (1 << 9)
#define SYSTEM_CAP_TPMR         (1 << 10)

#define Fix_SZCAP               6
#define Fix_SZCAP_INFO          4
typedef struct MSW_TLV_CAP {
    unsigned char   status;
    unsigned short  scap;
    unsigned short  enbl;
} MSW_TLV_CAP_T;

#define ADDR_SUBTYPE_RESERVED   0
#define ADDR_SUBTYPE_IPV4       1
#define ADDR_SUBTYPE_IPV6       2

#define Max_SZMNG_ADDR          31
#define Min_SZMNG_ADDR 1
typedef struct MSW_TLV_MNGADDR {
    unsigned char   type;
    unsigned char   addr[Max_SZMNG_ADDR];
} MSW_TLV_MNGADDR_T;

#define Max_SZMNG_OBJ           128
#define Min_SZMNG_OBJ           0
typedef struct MSW_TLV_MNGOBJ {
    unsigned char   len;
    unsigned char   id[Max_SZMNG_OBJ];
} MSW_TLV_MNGOBJ_T;

#define IF_NUM_SUBTYPE_UNKNOWN   1
#define IF_NUM_SUBTYPE_IFINDEX   2
#define IF_NUM_SUBTYPE_PORTNUM   3

#define Max_SZMNG_IF             4
typedef struct MSW_TLV_MNG {
    unsigned char   status;
    unsigned short  curlen;
    unsigned char   strlen;
    MSW_TLV_MNGADDR_T addr;
    unsigned char   iftype;
    unsigned long   ifnum;
    MSW_TLV_MNGOBJ_T  obj;
} MSW_TLV_MNG_T;

#define Max_SZMNG               169
#define Max_SZMNG_INFO          167
#define Min_SZMNG_INFO          9
typedef struct MSW_TLVS {
    MSW_TLV_CHASIIS_T  chassis;
    MSW_TLV_PORTID_T   portid;
    MSW_TLV_TTL_T      ttl;
    MSW_TLV_PORTDES_T  portdes;
    MSW_TLV_SYSNAME_T  sysname;
    MSW_TLV_SYSDES_T   sysdes;
    MSW_TLV_CAP_T      syscap;
    MSW_TLV_MNG_T      mngaddr[MSW_LLDP_MNGTLV_NUM];
} MSW_TLVS_T;

typedef struct MSW_TLVINFO {
    unsigned int     stsTlvDiscarded;
    unsigned int     stsTlvUnrecognized;
} MSW_TLVINFO_T;

typedef struct MSW_INFO {
    unsigned int     stsFrmIn;
    unsigned int     stsFrmDiscarded;
    unsigned int     stsFrmInErr;
    MSW_TLVINFO_T    tlvinfo;
    unsigned int     stsFrmOut;
    unsigned int     stsLenErr;
    char unknownTLV[LLDPD_MAX_TLV_SZ];
    char orgDefInfo[LLDPD_MAX_TLV_SZ];
} MSW_INFO_T;

typedef struct MSW_LLDP_LOCAL_INFO MSW_LLDP_LOCAL_INFO_T;
struct MSW_LLDP_LOCAL_INFO {
    char ifname[MSW_LLDP_IFNAME_LEN];
    unsigned char mcBitmap;
    unsigned char adminStatus;
    MSW_TLVS_T tlv;
    void (* rxCallback)(unsigned char *inframe, unsigned short len, 
        const MSW_LLDP_LOCAL_INFO_T *info);
    void (* txFunc)(char *port, unsigned char *outframe, 
        unsigned short len, void *usrData);
    void *usrData;
};


typedef struct MSW_LLDP_OPS {
    void (* lldp_register)(void);
    void (* lldp_unregister)(void);
    int  (* lldp_gettlv)(unsigned char *, unsigned short *, MSW_TLVS_T *, 
        MSW_INFO_T *, void *);
    int  (* lldp_notify_recv)(unsigned char *, unsigned short *,
        MSW_TLVINFO_T *, void *);
    int  (* lldp_notify_deletemib)(void *);
} MSW_LLDP_OPS_T;

typedef struct MSW_LLDP_MOD_INFO {
    int status;
    int id;
    const MSW_LLDP_OPS_T *ops;
} MSW_LLDP_MOD_INFO_T;

extern const unsigned char nearest_bridge[ETH_ADR_SZ];
extern const unsigned char nearest_nontpmr_bridge[ETH_ADR_SZ];
extern const unsigned char nearest_customer_bridge[ETH_ADR_SZ];

extern int mswLldpInit(void);
extern int mswLldpTerm(void);
extern int mswLldpPortAdd(MSW_LLDP_LOCAL_INFO_T *localInfo);
extern int mswLldpPortDel(char *ifname, unsigned char mcBitmap);
extern int mswLldpModuleAdd(MSW_LLDP_MOD_INFO_T *module);
extern int mswLldpModuleDel(int id);
extern int mswLldpLocalDataGet(MSW_LLDP_LOCAL_INFO_T *localInfo);
extern int mswLldpLocalDataPtrGet(char *ifname, unsigned char mcBitmap, 
            MSW_LLDP_LOCAL_INFO_T **info);
extern int mswLldpLocalDataSet(MSW_LLDP_LOCAL_INFO_T *localInfo);
extern int mswLldpduAnalysis(unsigned char *inlldpdu, unsigned short len,
            MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData);
extern int mswLldpduCreate(unsigned char *outlldpdu, unsigned short *len,
            MSW_TLVS_T *tlv, MSW_INFO_T *info, void *usrData);
extern int mswLldpduShutdownCreate(unsigned char *outlldpdu, unsigned short *len,
            MSW_TLVS_T *tlv, MSW_INFO_T *info);
extern void mswLldpRecv(char *ifname, unsigned char *inframe, 
            unsigned short len);
extern int mswLldpSend(char *ifname, unsigned char dstMc, unsigned char *outframe, 
            unsigned short len, MSW_INFO_T *info);
extern int mswLldpShutdownSend(char *ifname, unsigned char dstMc, unsigned char *outframe, 
            unsigned short len, MSW_INFO_T *info);
extern int mswLldpMibDelete(char *ifname, unsigned char mcBitMap);
extern int mswSetLockFunc(void *func);
extern int mswSetUnLockFunc(void *func);
extern char *mswGetVersion(void);
extern void mswLldpDump(char *data, int length);

#endif
