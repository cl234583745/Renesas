/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTPWRAP_MACRO_H__
#define __PTPWRAP_MACRO_H__



#define	MAX_EMSGID					4

#define	MAX_SENDCB_LING				4
#define	MAX_SENDCB_LINGMASK			(MAX_SENDCB_LING - 1)

#define	MAX_RECVAD_LING				8
#define	MAX_RECVAD_LINGMASK			(MAX_RECVAD_LING - 1)

#define	MAX_SPORT_LING				16
#define	MAX_SPORT_LINGMASK			(MAX_SPORT_LING - 1)

#define	PTPLWS_CLOSE				0
#define	PTPLWS_L2OPEN				1
#define	PTPLWS_L4V4OPEN				2
#define	PTPLWS_L4V6OPEN				3

#define PTP_ETHER_TYPE				0xF788

#define	PTP_PORT_EVENT				htons(319)
#define	PTP_PORT_GENERAL			htons(320)

#define PTP_DST_NORMAL				"224.0.1.129"
#define PTP_DST_PDELAY				"224.0.0.107"
#define PTP_6_DST_NORMAL			"FF0E::181"
#define PTP_6_DST_PDELAY			"FF02::6B"

#define PTP_DSTMAC_NORMAL			{0x01, 0x1b, 0x19, 0x00, 0x00, 0x00}
#define PTP_DSTMAC_PDELAY			{0x01, 0x80, 0xc2, 0x00, 0x00, 0x0e}

#define	MIN_6_PREFIX				4
#define	MAX_6_PREFIX				128
#define	SHIFT_6_TRACLS				20

#define	MIN_PTP_MSG					1
#define	MAX_PTP_MSG					1472

#define IS_PTP_PDELAY_MSG(msg) \
			((msg == PTPM_MSGTYPE_PDELAY_REQ) \
		||	 (msg == PTPM_MSGTYPE_PDELAY_RESP) \
		||	 (msg == PTPM_MSGTYPE_PDLY_RESP_FOLLOWUP))

#define IS_PTP_EVENT_MSG(msg) \
			((msg == PTPM_MSGTYPE_SYNC) \
		||	 (msg == PTPM_MSGTYPE_DELAY_REQ) \
		||	 (msg == PTPM_MSGTYPE_PDELAY_REQ) \
		||	 (msg == PTPM_MSGTYPE_PDELAY_RESP))

#define IS_V4_RECVKEY_MATCH(pulKey1, pulKey2) \
			((pulKey1[0] == pulKey2[0]) \
		&&	 (pulKey1[1] == pulKey2[1]))

#define IS_V6_RECVKEY_MATCH(pulKey1, pulKey2) \
			((pulKey1[0] == pulKey2[0]) \
		&&	 (pulKey1[1] == pulKey2[1]) \
		&&	 (pulKey1[2] == pulKey2[2]) \
		&&	 (pulKey1[3] == pulKey2[3]) \
		&&	 (pulKey1[4] == pulKey2[4]))

#define ptp_16bit_lt(seq1, seq2)		(((ttS16Bit)((seq1)-(seq2))) <	TM_L(0))
#define ptp_16bit_gt(seq1, seq2)		(((ttS16Bit)((seq1)-(seq2))) >	TM_L(0))

#define ptp_sqn_lt(x,y)					ptp_16bit_lt(x,y)
#define ptp_sqn_gt(x,y)					ptp_16bit_gt(x,y)

#ifdef TM_WRAP_GLOBAL
#define TM_WRAP_EXTERN
#else
#define TM_WRAP_EXTERN extern
#endif

#endif
