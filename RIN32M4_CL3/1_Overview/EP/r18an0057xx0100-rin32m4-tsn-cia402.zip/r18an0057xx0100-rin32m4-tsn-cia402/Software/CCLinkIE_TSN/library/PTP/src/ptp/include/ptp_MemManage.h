/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_MEMMANAGE_H__
#define __PTP_MEMMANAGE_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_MemManage_GD.h"




 typedef	enum	tagPTPMMALLOCID
{
	PTP_MM_CLOCK = 0,
	PTP_MM_PORT,
	PTP_MM_CTQUE,
	PTP_MM_ANNO,
	PTP_MM_FORE,

	PTP_MM_MAX
} PTPMMALLOCID; 


typedef	struct	tagPTPMMCLOCKBLK
{
	PTPMMLNK			stPtpMmClockLnk;
	CLOCKDATA			stClockData;
} PTPMMCLOCKBLK; 




typedef	struct	tagPTPMMPORTBLK
{
	PTPMMLNK			stPtpMmPortLnk;
	PORTDATA			stPortData;
} PTPMMPORTBLK; 




typedef	struct	tagPTPMMPORTADDRBLK
{
	PORTADDRDATA		stPortAddrData;
} PTPMMPORTADDRBLK; 





typedef	struct	tagPTPMMPTPBLK
{
	PTPMMCLOCKBLK				stPtpMMClockBlk[MAX_CLOCK];
	PTPMMPORTBLK				stPtpMMPortBlk[MAX_CLOCK * MAX_PORT];
	PTPMMPORTADDRBLK			stPtpMMPortAddrBlk[MAX_PORT];
	PORTADDRINFO 				stPortAddrInfo;
	CMLDS_MANAGE				stCmldsManage;
	MDPDLYREQSM_STACK_MANAGE	stMdPdlyTspStk[ MAX_CLOCK * MAX_PORT];
	CMLDSPORT_1AS_DS			stCmldsPort_1AS_DS[MAX_CLOCK * MAX_PORT];
	CMLDSPORTSTATISTICS_1AS_DS	stCmldsPortStatistics_1AS_DS[MAX_CLOCK * MAX_PORT];
} PTPMMPTPBLK;






#ifdef __cplusplus
extern "C" {
#endif
BOOL	ptp_MMInit(UCHAR	uchClockNumber);
BOOL	ptp_MMBegin(UCHAR	uchClockNumber, USHORT	usPtpMMPortNum);
VOID*	ptp_MMalloc(UCHAR	uchClockNumber, PTPMMALLOCID enPtpMMId);
VOID	ptp_MMfree(UCHAR	uchClockNumber, PTPMMALLOCID enPtpMMId, VOID* pvPtpMMPtr);
BOOL	ptp_MMClose(UCHAR	uchClockNumber);
LONG	ptp_SystemSemLock(CLOCKDATA*	pstClockData);
LONG	ptp_SystemSemLockWait(CLOCKDATA*	pstClockData);
LONG	ptp_SystemSemUnLock(CLOCKDATA*	pstClockData);

#ifdef __cplusplus
}
#endif


#endif
