/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_SIGNALING

#define D_ERR	0
#define D_STS	0
#define D_FUNC	0
#define D_STATE	0


#ifdef	PTP_USE_IEEE802_1

#include "MDSyncIntvalSet.h"
#include "MDSyncIntvalSet_1AS.h"

VOID (*const SyncIntvalSetSM_1AS_Matrix[DMDSYCI_STATUS_MAX][DMDSYCI_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_NP_1AS},
	{&SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_02_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_00_1AS},
	{&SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_02_1AS, &SyncIntvalSetSM_03_1AS, &SyncIntvalSetSM_00_1AS},
	{&SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_01_1AS, &SyncIntvalSetSM_NP_1AS, &SyncIntvalSetSM_03_1AS, &SyncIntvalSetSM_00_1AS}
};

VOID SyncIntvalSetSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	SYNCINTVSET_EV	enEvt = MDSYCI_E_EVENT_MAX;
	SYNCINTVSET_ST	enSts = MDSYCI_STATUS_MAX;
	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET_1AS, PTP_LOGVE_82080001);
	enEvt = GetSyncIntvSetEvent(usEvent, pstPort);

	enSts = GetSyncIntvSetStatus(pstPort);

	if ((enSts != MDSYCI_STATUS_MAX) && (enEvt != MDSYCI_E_EVENT_MAX))
	{
		(*SyncIntvalSetSM_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET_1AS, PTP_LOGVE_82000006);
	}
	return;
}

VOID SyncIntvalSetSM_00_1AS(PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "SyncIntvalSetSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	SyncIntSet_NotEnabled_1AS(pstGbl, pstPort);
	SetSyncIntvSetStatus(MDSYCI_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("SyncIntvalSetSM_00_1AS::-\n") );

	return;
}

VOID SyncIntvalSetSM_01_1AS(PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;
	BOOL			blRet;

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	blRet = SyncIntSet_NotEnabled_1AS(pstGbl, pstPort);
	if (blRet)
	{
		SetSyncIntvSetStatus(MDSYCI_NOT_ENABLED, pstPort);
	}
	else
	{
		SyncIntSet_Initialize_1AS(pstGbl, pstPort);
		SetSyncIntvSetStatus(MDSYCI_INITIALIZE, pstPort);
	}
	return;
}

VOID SyncIntvalSetSM_02_1AS(PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	SyncIntSet_Initialize_1AS(pstGbl, pstPort);
	SetSyncIntvSetStatus(MDSYCI_INITIALIZE, pstPort);
	return;
}

VOID SyncIntvalSetSM_03_1AS(PORTDATA* pstPort)
{
	SISETTINGSM_GD*	pstGbl = NULL;

	pstGbl = GetSyncIntvSetGlobal(pstPort);

	if (pstGbl->blRcvdSignalingMsg1 == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET_1AS, PTP_LOGVE_82000009);
		SyncIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetSyncIntvSetStatus(MDSYCI_NOT_ENABLED, pstPort);
		return;
	}
	if (pstGbl->pstRcvdSignaling == NULL)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET_1AS, PTP_LOGVE_8200000A);
		SyncIntSet_NotEnabled_1AS(pstGbl, pstPort);
		SetSyncIntvSetStatus(MDSYCI_NOT_ENABLED, pstPort);
		return;
	}

	SyncIntSet_SetInterval_1AS(pstGbl, pstPort);
	SetSyncIntvSetStatus(MDSYCI_SET_INTERVAL, pstPort);
	return;
}

VOID SyncIntvalSetSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSINTVALSET_1AS, PTP_LOGVE_82000007);
	return;
}


BOOL SyncIntSet_NotEnabled_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS* pstPortDS = &pstPort->stPort_1AS_DS;
	if (pstPortDS->blUseMgtSettableLogSyncInterval)
	{
		pstPortDS->chCurrentLogSyncInterval
			= pstPortDS->chMgtSettableLogSyncInterval;
		computeSyncInterval_1AS(pstPort);
	}

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;

	return pstPortDS->blUseMgtSettableLogSyncInterval;
}

VOID SyncIntSet_Initialize_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORT_GD*		pstPortGD	= &pstPort->stPort_GD;

	pstPortDS->chCurrentLogSyncInterval
		= pstPortDS->chInitialLogSyncInterval;

	computeSyncInterval_1AS(pstPort);

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;
	tsn_Wrapper_MemCpy(&pstPortGD->stOldSyncInterval,
		&pstPortGD->stSyncInterval, sizeof(pstPortGD->stOldSyncInterval));

	pstPortGD->blSyncSlowdown = FALSE;

	return;
}

VOID SyncIntSet_SetInterval_1AS(SISETTINGSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	CHAR chTimeSyncInterval =
		pstSmGbl->pstRcvdSignaling->stSignaling_1AS.stIntervalReq_TLV.chTimeSyncInterval;
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORT_GD*		pstPortGD	= &pstPort->stPort_GD;

	switch(chTimeSyncInterval)
	{
	case PTPM_TLV_TIME_SYNC_INTVAL_NCHG:
		break;
	case PTPM_TLV_TIME_SYNC_INTVAL_INIT:
		pstPortDS->chCurrentLogSyncInterval
			= pstPortDS->chInitialLogSyncInterval;

		computeSyncInterval_1AS(pstPort);
		break;
	default:
		pstPortDS->chCurrentLogSyncInterval = chTimeSyncInterval;

		computeSyncInterval_1AS(pstPort);
		break;
	}

	pstSmGbl->blRcvdSignalingMsg1 = FALSE;

	if (ptpCompUSNs_USNs(&pstPortGD->stSyncInterval,
	 		 &pstPortGD->stOldSyncInterval) == COMP_A_LESS)
	{
		pstPortGD->blSyncSlowdown = TRUE;
	}
	else
	{
		pstPortGD->blSyncSlowdown = FALSE;
	}
	return;
}
VOID computeSyncInterval_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;
	PORT_GD*		pstPortGD	= &pstPort->stPort_GD;
	USCALEDNS		stA_USNs= {0};

	stA_USNs.ulNsec_lsb = CONST10_9;
	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstPortDS->chCurrentLogSyncInterval,
		&pstPortGD->stSyncInterval);
	return;
}

#endif
#endif
