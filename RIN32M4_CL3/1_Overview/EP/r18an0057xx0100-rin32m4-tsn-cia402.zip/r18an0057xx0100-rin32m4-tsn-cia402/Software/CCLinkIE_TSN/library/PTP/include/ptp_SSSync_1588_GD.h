/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_SSSYNC_1588_GD_H__
#define __PTP_SSSYNC_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_SSS_1588 {
	ST_SSS_1588_NONE	= 0,
	ST_SSS_1588_INITIALIZING,
	ST_SSS_1588_RECEIVING_SYNC,
	ST_SSS_1588_MAX
} EN_ST_SSS_1588;

typedef	enum	tagEN_EV_SSS_1588 {
	EV_SSS_1588_BEGIN = 0,
	EV_SSS_1588_FOR_STSYNSYN_RCVSYN,
	EV_SSS_1588_SSS_RCVSYNC_1588,
	EV_SSS_1588_CLOSE,
	EV_SSS_1588_EVENT_MAX
} EN_EV_SSS_1588;

typedef	struct tagSSSYNCSM_1588_GD
{
	EN_ST_SSS_1588	enStatusSSS_1588;
	BOOL			blRcvdPSSync;
	BOOL			blRcvdPSSync_1588;
	PORTSYNCSYNC	stRcvdPSSyncDat;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr;
	PORTSYNCSYNC	stTxPSSyncDat;
	PORTSYNCSYNC*	pstTxPSSyncPtr;
} SSSYNCSM_1588_GD;	




#endif


