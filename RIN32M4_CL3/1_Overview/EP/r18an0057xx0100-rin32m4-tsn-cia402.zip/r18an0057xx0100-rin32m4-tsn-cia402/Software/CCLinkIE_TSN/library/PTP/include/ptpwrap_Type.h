/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __PTPWRAP_TYPE_H__
#define __PTPWRAP_TYPE_H__

#include <ptp_System.h>
#include <PTP_Message.h>
#include <qbv_global.h>
#include "ptpwrap_Macro.h"

#ifndef	__PTPAPI_H__
typedef struct	tagMACADDR
{
	UCHAR				uchMac[6];
} MACADDR;

typedef struct	tagIPV4ADDR
{
	ULONG				ulSrcIpv4Addr;
	ULONG				ulDstIpv4Addr;
} IPV4ADDR;

typedef struct	tagIPV6ADDR
{
	struct ptp_in6_addr		stSrcIpv6Addr;
	UINT					unInterfaceId;
	struct ptp_in6_addr		stDstIpv6Addr;
} IPV6ADDR;
#endif


typedef struct	tagSENDCB_LING
{
	USHORT				usSeqId;
	SENDTIMESCB			stSendCBFunc;
	VOID *				pvLinkId;
} SENDCB_LING;

typedef struct	tagRECVADD_KEY
{
#ifndef TM_USE_IPV6
	ULONG				ulSrcIpv4Addr;
#else
	struct ptp_in6_addr		stSrcIpv6Addr;
#endif
	USHORT				usMsgType;
	USHORT				usSeqId;
} RECVADD_KEY;

typedef struct	tagRECVEVT_LING
{
	RECVADD_KEY			stKey;
#ifndef	PTP_USE_ME_HW_ASSIST
	EXTENDEDTIMESTAMP 	stRecvTimeS;
#else
	EXTENDEDTIMESTAMP 	stRecvTimeS[2];
#endif
	USCALEDNS 			stRecvLTimeS;
	USHORT				usPortNo;
} RECVEVT_LING;

typedef struct	tagRECVGEN_LING
{
	RECVADD_KEY			stKey;
	USHORT				usPortNo;
} RECVGEN_LING;

typedef struct	tagSENDCB_INF
{
	SENDCB_LING	stSendCB[MAX_SENDCB_LING];
	SHORT		sSCB_writeId;
	SHORT		sSCB_readId;
} SENDCB_INF;

typedef struct	tagRECVEVT_INF
{
	RECVEVT_LING stRecvEvt[MAX_RECVAD_LING];
	SHORT		 sRAD_writeId;
	SHORT		 sRAD_readId;
} RECVEVT_INF;

typedef struct	tagRECVGEN_INF
{
	RECVEVT_LING stRecvGen[MAX_RECVAD_LING];
	SHORT		 sRAD_writeId;
	SHORT		 sRAD_readId;
} RECVGEN_INF;

typedef struct	tagPTP_LOWWRAP_INF
{
	ULONG				ulMagicNo;
	USHORT				usMaxPort;
	USHORT				usState;
	ULONG				ulNetMask;
	VOID *				pvAddr;
	INT					nEventSocket;
	INT					nGeneralSocket;
#ifdef TM_USE_IPV4
	ULONG				stDstNormal;
	ULONG				stDstPdelay;
#endif
#ifdef TM_USE_IPV6
	struct ptp_in6_addr		st6DstNormal;
	struct ptp_in6_addr		st6DstPdelay;
#endif
	UCHAR				uchBefPort;
	UCHAR				uchBefTraClsNo;
	UCHAR				uchRecvBuf[1500];
#ifndef	PTP_USE_ME_HW_ASSIST
	EXTENDEDTIMESTAMP 	stRecvTimeS;
#else
	EXTENDEDTIMESTAMP 	stRecvTimeS[2];
#endif
	USCALEDNS		 	stRecvLTimeS;
} PTP_LOWWRAP_INF;

typedef struct	tagSCOMP_PORT
{
	UCHAR				uchSPort[MAX_SPORT_LING];
	SHORT				sWriteId;
	SHORT				sReadId;
} SCOMP_PORT;

#endif
