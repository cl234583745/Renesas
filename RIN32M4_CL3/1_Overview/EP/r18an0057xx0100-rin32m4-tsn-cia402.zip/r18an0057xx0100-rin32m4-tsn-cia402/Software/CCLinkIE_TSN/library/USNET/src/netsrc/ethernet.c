//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "ethernet.h"
#ifdef  INET6
#include "nd6.h"
#endif

#define MH(mb) ((struct Ehdr *)mb)

extern struct NET nets[];
extern struct NETCONF netconf[];
extern const struct NETDATA netdata[];
extern struct CONNECT connblo[];
extern PTABLE  *const P_tab[];
#ifdef ARP
extern PTABLE   ussARPTable;
#endif

#if USS_IP_MC_LEVEL > 0
static const char mcastmac[] = {0x01, 0x00, 0x5e};
#endif

static int      writE(int conno, MESS * mess)
{
    int             i1,
                    netno,
                    confix;
    unsigned short  us1;
    MESS           *mp;
    struct NETCONF *confp;
    register struct NET *netp;

    netno = mess->netno;
    netp = &nets[netno];
    mess->offset = MESSH_SZ;

    if (conno == -1) {
        memcpy((char *) &MH(mess)->to, (char *) &MH(mess)->from, Eid_SZ);
        goto lab2;
    }
    if (mess->confix == ussBroadcastIndex) {
        memset((char *) &MH(mess)->to, 0xff, Eid_SZ);
        goto lab2;
    }
#ifdef  INET6
    else if ((mess->ipv6.flag6 & FLAG6_IPV6) &&
         mess->confix == ussMulticastIndex) {
        MH(mess)->to[0] = MH(mess)->to[1] = 0x33;
        memcpy(&MH(mess)->to[2], (char *)&(mess->ipv6.target6[12]), 4);
        goto lab2;
    }
#endif
#if USS_IP_MC_LEVEL > 0
    else if (mess->confix == ussMulticastIndex) {
        memcpy((char *) &MH(mess)->to, mcastmac, sizeof(mcastmac));
        memcpy(&MH(mess)->to[3], (char *)&mess->target + 1, 3);
        MH(mess)->to[3] &= 0x7f;
        goto lab2;
    }
#endif
    confix = netconf[mess->confix].nexthix;
    confp = &netconf[confix];
#ifdef  INET6
    if (mess->ipv6.flag6 & FLAG6_IPV6) {
        i1 = nd6_send_event(conno, mess, confix);
        if (i1 <= 0)
            return i1;
    } else {
#endif
    if (confp->hwaddyes == 0) {
#ifdef ARP
        if ((mp = Ngetbuf()) == 0)
            goto lab8;
        mp->netno = netno;
        mp->confix = confix;
        ussARPTable.writE(-1, mp);
        memset((char *) &MH(mp)->to, 0xff, Eid_SZ);
        memcpy((char *) &MH(mp)->from, (char *) &netp->id, Eid_SZ);
        mp->offset = MESSH_SZ;
        mp->id = bRELEASE;
        mp->portno = mess->portno;
        i1 = netp->protoc[1]->writE(netno, mp);
        if (i1)
            Nrelbuf(mp);
        if (conno < 0) {
            i1 = ETIMEDOUT;
            BLOCKPREE();
            if (confp->ARPwait == 0) {
                confp->ARPwait = (char) conno;
                confp->ARPwaitmp = mess;
                confp->timems = TimeMS();
                i1 = 0;
            } else
                mess->offset = boTXDONE;
            RESUMEPREE();
            return i1;
        }
        WAITFOR(confp->hwaddyes, SIG_ARP, ET_TOUT, i1);
        if (i1) {
    lab8:   mess->offset = boTXDONE;
            return ETIMEDOUT;
        }
#else
#if NTRACE >= 1
        Nprintf("no ARP and Ethernet address 0\n");
#endif
        return EHOSTUNREACH;
#endif
    }
#ifdef  INET6
    }
#endif
    memcpy((char *) &MH(mess)->to, (char *) &confp->Eaddr, Eid_SZ);

lab2:
    memcpy((char *) &MH(mess)->from, (char *) &netp->id, Eid_SZ);

#ifdef MIB2
    netp->ifOutOctets += mess->mlen - mess->offset;
    if (MH(mess)->to[0] & 0x01)
        netp->ifOutNUcastPkts++;
    else
        netp->ifOutUcastPkts++;
#endif

    us1 = mess->id;
    i1 = netp->protoc[1]->writE(netno, mess);
    if (i1 != 0 || us1 <= bWACK)
        return i1;
    WAITFOR(mess->offset == boTXDONE, SIG_WN(netno), ET_TOUT, i1);
    return 1;
}


static int      screen(MESS * mess)
{
    int             i1,
                    nxtlev;

    mess->conno = MH(mess)->to[0] & 0x01;
#ifdef MIB2
    nets[mess->netno].ifInOctets += mess->mlen - MESSH_SZ;
    if ((char) MH(mess)->to[0] & 0x01)
        nets[mess->netno].ifInNUcastPkts++;
    else
        nets[mess->netno].ifInUcastPkts++;
#endif
    for (nxtlev = 1; P_tab[nxtlev]; nxtlev++)
        if (NC2(MH(mess)->type) == P_tab[nxtlev]->Eprotoc) {
            mess->offset = MESSH_SZ + Ehdr_SZ;
            i1 = P_tab[nxtlev]->screen(mess);
            if (i1 == -3) {
                mess->id = bRELEASE;
                i1 = writE(-1, mess);
                if (i1 == 0) {
                  i1 = -4;
                }
            }
            return i1;
        }
#ifdef MIB2
    nets[mess->netno].ifInUnknownProtos++;
#endif
    return -1;
}


static int      init(int netno, char *params)
{
    int             i1;
    struct NET     *netp;

    netp = &nets[netno];
#ifdef USSW_NIOCTL
    for (i1 = 0; i1 < Eid_SZ; i1++) {
        if (netp->id.c[i1] != 0) {
            break;
        }
    }
    if (Eid_SZ <= i1) {
        netp->id = netdata[netp->confix].Eaddr;
    }
#else
    netp->id = netdata[netp->confix].Eaddr;
#endif


    netp->maxblo = ( ( ET_MAXLEN <= (MAXBUF - MESSH_SZ - Ehdr_SZ ) ) ?
                     ( ET_MAXLEN ) :
                     ( MAXBUF - MESSH_SZ - Ehdr_SZ ) );

    i1 = netp->protoc[1]->init(netno, params);
    if (i1 < 0)
        return i1;
    netconf[netp->confix].Eaddr = netp->id;
    netp->sndoff = MESSH_SZ + Eid_SZ;
    netp->tout = ET_TOUT;
#ifdef MIB2
    netp->ifType = 6;
#endif
    return i1;
}

static void     shut(int netno)
{
    nets[netno].protoc[1]->shut(netno);
}



static int      opeN(int conno, int flags)
{
    (void)conno;
    (void)flags;
    return 1;
}



static int      closE(int conno)
{
    (void)conno;
    return 0;
}


static int ioctl(void *handle, enum ioctlreq request, void *arg, size_t size)
{
#if USS_IP_MC_LEVEL != 2
    (void)handle;
    (void)request;
    (void)arg;
    (void)size;
#else
    unsigned char macaddr[Eid_SZ];
    (void)size;
#endif

    switch (request) {

#if USS_IP_MC_LEVEL == 2
    case ussMcastGroupJoinE:
    case ussMcastGroupLeaveE:
        memcpy(macaddr, mcastmac, sizeof(mcastmac));
        memcpy(&macaddr[3], (char *) arg + 1, 3);
        macaddr[3] &= 0x7f;
        return ((struct NET *) handle)->protoc[ussDriverIndex]->ioctl(handle,
                request, macaddr, sizeof(macaddr));
#endif

    default:
        return ussErrInval;
    }
}



GLOBALCONST
PTABLE ussEthernetTable = {
    "Ethernet", init, shut, screen, opeN, closE,
        reaDD, writE, ioctl, ET_IP, LHDRSZ
};
