/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE1588
#ifdef	PTP_USE_TRANS
#include "MDDelayCommonSM.h"


BOOL JugMDDelayRespCorrectionPort(PORTDATA* pstPort, USHORT *pusIndex)
{
	PORTIDENTITY* pstSrchPort = &pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.
									stDlyCorctionClock.stConDlyResp_1588.stReqPortIdentity;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	USHORT	usLoop;

	for (usLoop = 0; usLoop < pstClockGD->stDlyCorctionClock.uchCrrctionCount; usLoop++)
	{
		if (!(tsn_Wrapper_MemCmp(pstSrchPort,
			&pstClockGD->stDlyCorrctionInfo.stCrrctionPortIdentity[usLoop], sizeof(*pstSrchPort))))
		{
			break;
		}
	}
	if (usLoop >= pstClockGD->stDlyCorctionClock.uchCrrctionCount)
	{
		return FALSE;
	}

	if (pstClockGD->stDlyCorctionClock.stCrrctionPort[usLoop].blFlg)
	{
		*pusIndex = usLoop;
		return TRUE;
	}
	else
	{
		if (pstClockGD->stDlyCorctionClock.uchCrrctionCount >= MDDELAYCRRCTION_ADDMAX)
		{
			return FALSE;
		}
	}
	pstClockGD->stDlyCorctionClock.stCrrctionPort[usLoop].blFlg = TRUE;
	*pusIndex = usLoop;

	return TRUE;
}
BOOL JugMDDelayCorrectionPort(PORTDATA* pstPort, USHORT *pusIndex)
{

	PORTIDENTITY* pstSrchPort = &pstPort->pstClockData->stUn_Clock_GD.stClock_1588_GD.
		stDlyCorctionClock.stConDlyReq_1588.stHeader.stSrcPortIdentity;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	USHORT	usLoop;

	for (usLoop = 0; usLoop < pstClockGD->stDlyCorctionClock.uchCrrctionCount; usLoop++)
	{
		if (!(tsn_Wrapper_MemCmp(pstSrchPort,
			&pstClockGD->stDlyCorrctionInfo.stCrrctionPortIdentity[usLoop], sizeof(*pstSrchPort))))
		{
			break;
		}
	}
	if (usLoop >= pstClockGD->stDlyCorctionClock.uchCrrctionCount)
	{
		return FALSE;
	}

	if (pstClockGD->stDlyCorctionClock.stCrrctionPort[usLoop].blFlg)
	{
		*pusIndex = usLoop;
		return TRUE;
	}
	else
	{
		if (pstClockGD->stDlyCorctionClock.uchCrrctionCount >= MDDELAYCRRCTION_ADDMAX)
		{
			return FALSE;
		}
	}
	pstClockGD->stDlyCorctionClock.stCrrctionPort[usLoop].blFlg = TRUE;
	*pusIndex = usLoop;

	return TRUE;
}
BOOL JugAndAddMDDelayCorrectionPort(PORTDATA* pstPort, USHORT *pusIndex)
{
	PORTMD_GD*				pstPortMD	= &pstPort->stPortMD_GD;
	PTPMSG_DELAY_REQ_1588*	pstMsg	= &pstPortMD->stConDlyReq_1588;

	PORTIDENTITY* pstSrchPort	= &pstMsg->stHeader.stSrcPortIdentity;

	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	USHORT	usLoop;

	PORTDATA*		pstPortWork;

	for (usLoop = 0; usLoop < pstClockGD->stDlyCorctionClock.uchCrrctionCount; usLoop++)
	{
		if (tsn_Wrapper_MemCmp(pstSrchPort,
			&pstClockGD->stDlyCorrctionInfo.stCrrctionPortIdentity[usLoop], sizeof(PORTIDENTITY)) == 0)
		{
			break;
		}
	}

	if (usLoop >= pstClockGD->stDlyCorctionClock.uchCrrctionCount)
	{
		if (pstClockGD->stDlyCorctionClock.uchCrrctionCount < MDDELAYCRRCTION_ADDMAX)
		{
			pstClockGD->stDlyCorctionClock.uchCrrctionCount++;
		}

		pstClockGD->stDlyCorctionClock.stCrrctionPort[pstClockGD->stDlyCorctionClock.uchCrrctionLocation].blFlg = TRUE;

		usLoop = pstClockGD->stDlyCorctionClock.uchCrrctionLocation;

		pstClockGD->stDlyCorctionClock.uchCrrctionLocation ++;

		if (pstClockGD->stDlyCorctionClock.uchCrrctionLocation >= MDDELAYCRRCTION_ADDMAX)
		{
			pstClockGD->stDlyCorctionClock.uchCrrctionLocation = 0;
		}
	}

	tsn_Wrapper_MemCpy(&pstClockGD->stDlyCorrctionInfo.stCrrctionPortIdentity[usLoop], pstSrchPort, sizeof(PORTIDENTITY));
	pstClockGD->stDlyCorctionClock.stCrrctionPort[usLoop].blFlg = TRUE;
	pstPortWork = pstClockDT->pstPortData;

	while (pstPortWork != NULL)
	{
		pstPortWork->stPortMD_GD.stDlyCorctionPortInfo.stCrrctionPort[usLoop].blFlg = TRUE;
		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}
	*pusIndex = usLoop;
	return TRUE;
}

BOOL SetMDDelayCorrectionPortIngress(PORTDATA* pstPort, USHORT usIndex)
{
	PORTMD_GD*				pstPortMD  = &pstPort->stPortMD_GD;
	PTPMSG_DELAY_REQ_1588*	pstMsg	= &pstPortMD->stConDlyReq_1588;

	USHORT					usSrchSeqId	= pstMsg->stHeader.usSequenceId;




	PORTDATA*		pstPortWork;

	pstPortWork = pstPort->pstClockData->pstPortData;

	while (pstPortWork != NULL)
	{
		tsn_Wrapper_MemCpy(&pstPortWork->stPortMD_GD.stDlyCorctionPortInfo.stCrrctionPort[usIndex].stIngressTimestamp,
			&pstPort->stPort_GD.stDelayReqIngressTimestamp, sizeof(TIMESTAMP));
		pstPortWork->stPortMD_GD.stDlyCorctionPortInfo.stCrrctionPort[usIndex].usSequenceId = usSrchSeqId;

		pstPortWork->stPortMD_GD.stDlyCorctionPortInfo.stCrrctionPort[usIndex].blFlg = TRUE;

		pstPortWork = pstPortWork->pstNextPortDataPtr;
	}

	return TRUE;
}

BOOL SetMDDelayCorrectionPortEgress(PORTDATA* pstPort, USHORT usIndex)
{
	PORTMD_GD*		pstPortMD  = &pstPort->stPortMD_GD;
	PORT_GD*		pstPortGD	= &pstPort->stPort_GD;

	if (pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].blFlg)
	{
		tsn_Wrapper_MemCpy(&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stEgressTimestamp,
			&pstPortGD->stDelayReqEgressTimestamp, sizeof(TIMESTAMP));

		return TRUE;
	}

	return FALSE;
}

BOOL GetMDDelayCorrectionPort(PORTDATA* pstPort, USHORT usIndex)
{
	CLOCKDATA*		pstClockDT	= pstPort->pstClockData;
	CLOCK_1588_GD*	pstClockGD = &pstClockDT->stUn_Clock_GD.stClock_1588_GD;

	PORTMD_GD*		pstPortMD  = &pstPort->stPortMD_GD;
	SCALEDNS		stA_Ns;
	TIME_INTERVAL	stB_TInt;

	if (pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].blFlg)
	{
		if (IS_TIMESTAMP_0(pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stEgressTimestamp) == TRUE)
		{
			pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].blFlg = FALSE;
			pstClockGD->stDlyCorctionClock.stCrrctionPort[usIndex].blFlg = FALSE;

			tsn_Wrapper_MemSet(&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stEgressTimestamp, 0, sizeof(TIMESTAMP));
			tsn_Wrapper_MemSet(&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stIngressTimestamp, 0, sizeof(TIMESTAMP));

			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_8200230B);
			return FALSE;
		}
		ptpSubTS_TS(
			&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stEgressTimestamp,
			&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stIngressTimestamp,
			&stA_Ns);
		ptpConvSNs_TInt(&stA_Ns, &stB_TInt);
#ifdef	PTP_USE_ME_HW_ASSIST
		{
			SCALEDNS		stB_Ns;

			ptpMultSNs_Doub(&stA_Ns, pstClockDT->stClock_GD.dbRateRatio, &stB_Ns);
			ptpConvSNs_TInt(&stB_Ns, &stB_TInt);
		}
#endif
		tsn_Wrapper_MemCpy(&pstPortMD->stDlyCorrctionField, &stB_TInt,
			sizeof(pstPortMD->stDlyCorrctionField));

		pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].blFlg = FALSE;

		pstClockGD->stDlyCorctionClock.stCrrctionPort[usIndex].blFlg = FALSE;
		tsn_Wrapper_MemSet(&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stEgressTimestamp, 0, sizeof(TIMESTAMP));
		tsn_Wrapper_MemSet(&pstPortMD->stDlyCorctionPortInfo.stCrrctionPort[usIndex].stIngressTimestamp, 0, sizeof(TIMESTAMP));


		return TRUE;
	}
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDREQSENDSM_1588, PTP_LOGVE_82000013);
	return FALSE;
}

#endif
#endif
