//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include <stdio.h>
#include <stdarg.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "socket.h"

struct SOCBLOCK {
    int error;
    unsigned short sndbuf;
    unsigned short rcvbuf;
    int sockopt;
    int doffsetsav;
    unsigned int maxdatsav;
    struct linger linger;
};

#define soDEBUG         0x0001
#define soREUSEADDR     0x0002
#define soDONTROUTE     0x0008
#define soBROADCAST     0x0010
#define soOOBINLINE     0x0040
#define soLISTEN        0x0080
#define soSHUTRECV      0x0100
#define soSHUTSEND      0x0200
#define soNODELAY       0x0400

extern struct NETCONF netconf[];
extern struct NET nets[];
extern PTABLE *const P_tab[];
extern PTABLE ussIPTable;
#ifdef  INET6
extern PTABLE ussIP6Table;
#endif
#ifdef TCP
extern PTABLE ussTCPTable;
#endif
#ifdef UDP
extern PTABLE ussUDPTable;
#endif
#ifdef DNS
extern Iid DNSiid[2];
#endif

extern int ussSelectFlag;

struct SOCBLOCK socblock[NCONNS];

#ifndef USNET_UNLOCK
#define R_FTYP1_ADR (0x40140070UL)
#define R_FTYP2_ADR (0x40140074UL)
#define R_FTYP3_ADR (0x40140078UL)
#define R_FTYP1_VAL (0xC3C2C1C0UL)
#define R_FTYP2_VAL (0xC7C6C5C4UL)
#define R_FTYP3_VAL (0x000000C8UL)
#endif

int socket(int domain, int type, int protocol)
{
    int i1, conno;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

#ifndef USNET_UNLOCK
	volatile unsigned long	*ulreg_1;
	volatile unsigned long	*ulreg_2;
	volatile unsigned long	*ulreg_3;

	ulreg_1 = (unsigned long *)R_FTYP1_ADR;
	ulreg_2 = (unsigned long *)R_FTYP2_ADR;
	ulreg_3 = (unsigned long *)R_FTYP3_ADR;
	
	while (1) {
		if ((R_FTYP1_VAL == *ulreg_1) && (R_FTYP2_VAL == *ulreg_2) && (R_FTYP3_VAL == *ulreg_3)) {
			break;
		}
	}
#endif

    if (domain == PF_UNSPEC)
        domain = PF_INET;
#ifdef  INET6
if (domain != PF_INET6) 
#endif
    if (domain != PF_INET) {
        errno = EPROTONOSUPPORT;
        return -1;
    }
    BLOCKPREE();
    for (conno = 0; conno < NCONNS; conno++) {
        conp = &connblo[conno];
        if ( ! conp->blockstat )
        {
            if ( conp->refcount == 0 && conp->refsock == 0 )
            {
                memset((void *) conp, 0, sizeof(struct CONNECT));
                conp->blockstat = (char) 0x81;
                conp->refsock = 1;
                break;
            }
        }
    }
    RESUMEPREE();
    if (conno == NCONNS) {
        errno = ENOBUFS;
        return -1;
    }
    socp = &socblock[conno];
    memset((void *) socp, 0, sizeof(struct SOCBLOCK));
    if (type == SOCK_STREAM) {
#ifdef TCP
        if (protocol == 0)
            protocol = TCP;
        if (protocol != TCP) {
            errno = EPROTONOSUPPORT;
            goto err9;
        }
        conp->txstat |= S_STRM;
        conp->protoc[0] = &ussTCPTable, conp->protoc[1] = &ussIPTable;
#else
        errno = EPROTONOSUPPORT;
        goto err9;
#endif
    } else if (type == SOCK_DGRAM) {
        conp->txstat |= S_NOCON;
#ifdef UDP
        if (protocol == 0)
            protocol = UDP;
        if (protocol != UDP)
#endif
#ifdef ICMP
#ifdef  INET6
        if (protocol != ICMP6)
#endif
            if (protocol != ICMP)
#endif
            {
                errno = EPROTONOSUPPORT;
                goto err9;
            }
        conp->protoc[0] = P_tab[protocol], conp->protoc[1] = &ussIPTable;
    }
    else if (type == SOCK_RAW)
    {
        errno = EPROTONOSUPPORT;
        goto err9;
    }
#ifdef  INET6
    if (domain == PF_INET6)
        conp->protoc[1] = &ussIP6Table;
#endif
    conp->doffset = MESSH_SZ + LHDRSZ;
    for (i1 = 0; conp->protoc[i1]; i1++)
        conp->doffset += conp->protoc[i1]->hdrsiz;
#ifdef  INET6
if (domain == PF_INET6)
    conp->maxdat = Ngetmaxblo6(conp->netno) -
         conp->doffset + MESSH_SZ + LHDRSZ;
else
#endif
    conp->maxdat = nets[conp->netno].maxblo - conp->doffset + MESSH_SZ +
        LHDRSZ;
    socp->doffsetsav = conp->doffset;
    socp->maxdatsav = conp->maxdat;
    socp->sndbuf = socp->rcvbuf = conp->maxdat;
    conp->heriid.l = conp->rxtout = 0xffffffff;
#ifdef  INET6
    conp->ipv6.family = domain;
    conp->ipv6.flags = 0;
    Nsetheri6id (conno, NULL);
    Nsetmyi6id (conno, NULL);
#endif
    conp->confix = 255;
    conp->blockstat = 1;
    return conno;
err9:
    conp->blockstat = 0;
    return -1;
}

int connect(int s, struct sockaddr * name, int namelen, int iPort)
{
    int i2, confix;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    Iid iid;
#ifdef  INET6
    I6id *i6id = NULL;
#endif
    unsigned short us1;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE( );
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if ( conp->blockstat != 1 )
    {
        RESUMEPREE( );
        goto errbs;
    }
    conp->refcount++;
    RESUMEPREE( );
    if (namelen == 0 || name == 0)
    {
        socp->error = errno = EFAULT;
        goto err1;
    }
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (namelen < sizeof (struct sockaddr_in6) ||
     ((struct sockaddr_in6 *) name)->sin6_family != PF_INET6) {
        socp->error = errno = EFAULT;
        goto err1;
    }
    i6id = (I6id *) & ((struct sockaddr_in6 *) name)->sin6_addr;
    confix = GetHostData6(i6id->c, 1, conp->netno);
} else {
    iid = *(Iid *) & ((struct sockaddr_in *) name)->sin_addr;
    confix = GetHostData(iid.l, 1, conp->netno);
}
    if (confix < 0)
#else
    iid = *(Iid *) & ((struct sockaddr_in *) name)->sin_addr;
    if ((confix = GetHostData(iid.l, 1, conp->netno)) < 0)
#endif
    {
        socp->error = errno = EHOSTUNREACH;
        goto err1;
    }
    conp->rxstat = 0;
    conp->netno = netconf[confix].netno;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (((struct sockaddr_in6 *) name)->sin6_scope_id != 0) {
        i2 = ((struct sockaddr_in6 *) name)->sin6_scope_id - 1;
        if (0 <= i2 && i2 < NNETS && nets[i2].netstat != 0)
            conp->netno = i2;
        else {
            socp->error = errno = EHOSTUNREACH;
            goto err1;
        }
    }
}
#endif
    conp->confix = confix;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (i6id)
        Nsetheri6id (s, i6id->c);
    conp->heriid.l = 0;
    if (conp->myport == 0)
        us1 = Nportno(), conp->myport = NC2(us1);
    conp->herport = ((struct sockaddr_in6 *) name)->sin6_port;
} else {
#endif
    conp->heriid = iid;
    if (conp->myport == 0)
        us1 = Nportno(), conp->myport = NC2(us1);
    conp->herport = ((struct sockaddr_in *) name)->sin_port;
#ifdef  INET6
}
#endif
	conp->portno = iPort;
    i2 = conp->protoc[0]->opeN(s, 0);
    if (i2 > 0)
    {
        ussHostAcquire(conp->confix);
        conp->refcount--;
        return 0;
    }
    if (i2 == 0)
        i2 = EINPROGRESS;
    else if (SOCKET_ISFATAL(s))
        i2 = ECONNREFUSED;
    socp->error = errno = i2;
err1:
    conp->refcount--;
    return -1;
errbs:
    errno = EBADF;
    return -1;
}


int bind(int s, struct sockaddr * name, int namelen)
{
    int i1, netno;
    int interface;
    struct NET *netp;
    struct CONNECT *conp, *conp2;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if (conp->blockstat != 1)
        goto errbs;
    socp = &socblock[s];
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (namelen < sizeof(struct sockaddr_in6) || name == 0) {
        socp->error = errno = EFAULT;
        return -1;
    }
    conp->myport = ((struct sockaddr_in6 *) name)->sin6_port;
    netno = -1;
    memcpy (&conp->ipv6.offeredi6id,
        &(((struct sockaddr_in6 *) name)->sin6_addr), I6id_SZ);

    if (memcmp (&(((struct sockaddr_in6 *) name)->sin6_addr),
                in6addr_any, I6id_SZ) == 0) {
        interface = 0;
        goto lab3;
    }
} else {
#endif
    if (namelen < sizeof(struct sockaddr_in) || name == 0) {
        socp->error = errno = EFAULT;
        return -1;
    }
    conp->myport = ((struct sockaddr_in *) name)->sin_port;
    netno = -1;
    conp->offerediid = *((Iid *) & ((struct sockaddr_in *) name)->sin_addr);
    if (((struct sockaddr_in *) name)->sin_addr.s_addr == 0) {
        interface = 0;
        goto lab3;
    }
#ifdef  INET6
}
#endif

    interface = 1;
    for (netno = 0; netno < NNETS; netno++) {
        netp = &nets[netno];
        if (netp->netstat == 0)
            continue;
#ifdef  INET6
    if (conp->ipv6.family == PF_INET6) {
        if (!EQI6ID(&netconf[netp->confix].ipv6.I6addr,
                   ((struct sockaddr_in6 *) name)->sin6_addr.s6_addr) &&
            ip6_get_my_addr (netno, 
                ((struct sockaddr_in6 *) name)->sin6_addr.s6_addr) == NULL)
            continue;
    } else
#endif
        if (!EQIID(netconf[netp->confix].Iaddr,
                   *(Iid *) & ((struct sockaddr_in *) name)->sin_addr))
            continue;
        conp->netno = netno;
        goto lab3;
    }
    socp->error = errno = EADDRNOTAVAIL;
    return -1;
lab3:
    if ((socp->sockopt & soREUSEADDR) == 0) {
        BLOCKPREE();
        for (i1 = 0; i1 < NCONNS; i1++) {
            conp2 = &connblo[i1];
            if (i1 == s)
                continue;
            if (conp2->blockstat == 0)
                continue;
            if (conp2->protoc[0] != conp->protoc[0])
                continue;
            if (conp2->myport != conp->myport)
                continue;
            if (interface != 0) {
                if (conp2->netno != netno)
                    continue;
            }
            RESUMEPREE();
            socp->error = errno = EADDRINUSE;
            return -1;
        }
        RESUMEPREE();
    }
    return 0;
errbs:
    errno = EBADF;
    return -1;
}

int listen(int s, int backlog)
{
    struct CONNECT *conp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if (conp->blockstat != 1)
        goto errbs;
    socblock[s].sockopt |= soLISTEN;
    if (conp->state == 0)
        conp->state = 16;
    conp->backlog = backlog;
    return 0;
errbs:
    errno = EBADF;
    return -1;
}

int accept(int s, struct sockaddr * name, int *namelen, int* piPortno)
{
    int i2, conno;
    struct CONNECT *conp;
    struct CONNECT *conp2;
    struct sockaddr_in sa;
#ifdef  INET6
    struct sockaddr_in6 sa6;
#endif
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS) {
        goto errbs;
    }
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if (conp->blockstat != 1) {
        RESUMEPREE();
        goto errbs;
    }
    RESUMEPREE();

    WAITFOR(
        conp->next || conp->blockstat != 1,
        SIG_CC(s),
        conp->rxtout,
        i2
    );

    BLOCKPREE();
    if (conp->blockstat != 1) {
        RESUMEPREE();
        goto errbs;
    }
    if (!conp->next) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    conp2 = conp->next;
    conp->next = conp2->next;
    conp->icqcur--;
    conp2->next = 0;
    conp2->backlog = -1;
    conp2->refcount++;
    conno = conp2 - &connblo[0];
    ussHostAcquire(conp2->confix);
    memset((void *) &socblock[conno], 0, sizeof(struct SOCBLOCK));
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    sa6.sin6_len = sizeof (struct sockaddr_in6);
    sa6.sin6_family = PF_INET6;
    sa6.sin6_port = conp2->herport;
    sa6.sin6_flowinfo = 0;
    ip6acpy(&sa6.sin6_addr, &conp2->ipv6.reali6id);
    sa6.sin6_scope_id = conp2->netno + 1;
    if (name && namelen) {
        i2 = *namelen;
        if (i2 > sizeof(sa6))
            i2 = sizeof(sa6);
        memcpy((char *) name, (char *) &sa6, i2);
        *namelen = sizeof(struct sockaddr_in6);
    }
} else {
#endif
    sa.sin_port = conp2->herport;
    sa.sin_addr = *(struct in_addr *) & conp2->realiid;
    sa.sin_family = PF_INET;
    if (name && namelen) {
        i2 = *namelen;
        if (i2 > sizeof(sa))
            i2 = sizeof(sa);
        memcpy((char *) name, (char *) &sa, i2);
        *namelen = sizeof(struct sockaddr_in);
    }
#ifdef  INET6
}
#endif
    conp2->refcount--;
    *piPortno = conp2->portno;
    RESUMEPREE();
    return conno;
errbs:
    errno = EBADF;
    return -1;
}


int closesocket(int s)
{
    int stat;
    MESS *mess;
    struct CONNECT *conp, *conp2;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        conp->refsock = 0;
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if ((conp->blockstat & 0x9f) != 1) {
        RESUMEPREE();
        conp->refsock = 0;
        goto errbs;
    }
    conp->blockstat = 2;
    conp->refcount++;

    if (conp->istreamc) {
        Nrelbuf(conp->istreamb);
        conp->istreamb = 0;
        conp->istreamc = 0;
    }

    while ( ( mess = conp->first ) != 0 )
    {
        conp->first = mess->next;
        conp->ninque--;
        Nrelbuf(mess);
    }
    RESUMEPREE();

    WAITNOMORE(SIG_RC(s));
    if (socp->linger.l_onoff && socp->linger.l_linger == 0 &&
        (conp->txstat & S_STRM))
    {
        BLOCKPREE();
        if (conp->ostreamb) {
            Nrelbuf(conp->ostreamb);
            conp->ostreamb = 0;
        }
        RESUMEPREE();

        if (conp->state != 8 && conp->state != 9 && conp->state != 16)
            if ((mess = Ngetbuf()) != 0) {
                mess->mlen = 0x8000 | 4;
                mess->netno = conp->netno;
                mess->confix = conp->confix;
                mess->portno = conp->portno;
#ifdef  INET6
            if (conp->ipv6.family == PF_INET6) {
                Nsetmyi6id(s, (unsigned char *)&conp->ipv6.heri6id);
                ip6acpy(mess->ipv6.target6, &conp->ipv6.heri6id);
                mess->target = 0;
            } else
#endif
                mess->target = conp->heriid.l;
                mess->id = bRELEASE;
                if (conp->protoc[0]->writE(s, mess))
                    Nrelbuf(mess);
            }
        conp->state = 7;
        conp->blockstat = 4;
        conp->refcount--;
        conp->refsock = 0;
        return 0;
    }

    BLOCKPREE();
    if (conp->ostreamb)
    {
        MESS * myostreamb;

        myostreamb = conp->ostreamb;
        conp->ostreamb = 0;

        RESUMEPREE();
        if (conp->txstat & S_NOWA)
        {
            conp->wackmax = MAXWACK * MAXWACK;
        }

        stat = conp->protoc[0]->writE(s, myostreamb);
        if (stat)
        {
            Nrelbuf(myostreamb);
        }
         BLOCKPREE();
    }
    RESUMEPREE();


    if (socp->linger.l_onoff == 0) {
        conp->txstat |= S_NOWA;
    }
    else {
        conp->txstat &= ~S_NOWA;
        conp->l_linger = socp->linger.l_linger * 1000;
    }

    if ((socp->sockopt & soLISTEN)) {
        BLOCKPREE();
        while (conp->next) {
            conp2 = conp->next;
            conp->next = conp2->next;
            conp2->next = 0;
            conp->icqcur--;
            conp2->txstat |= S_NOWA;
            conp2->rxtout = 0;
            RESUMEPREE();

            closesocket(conp2 - &connblo[0]);
            BLOCKPREE();
        }
        RESUMEPREE();
    }

    if (conp->blockstat != 2)
    {
        conp->refcount--;
        conp->refsock = 0;
        goto errbs;
    }

    stat = conp->protoc[0]->closE(s);
    if ((stat & 1) == 0)
    {
        conp->blockstat = 0;
        ussHostRelease(conp->confix);
        WAITNOMORE(SIG_CC(s));
    }
    conp->refcount--;
    conp->refsock = 0;
    return 0;
errbs:
    errno = EBADF;
    return -1;
}

int getsockname(int s, struct sockaddr * name, int *namelen)
{
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if ((conp->blockstat & 0x9f) != 1)
        goto errbs;
    socp = &socblock[s];
    if (name == 0 || namelen == 0) {
        socp->error = errno = EFAULT;
        return -1;
    }
#ifdef  INET6
    Nsetsockaddr (s, name, namelen);
#else
    ((struct sockaddr_in *) name)->sin_port = conp->myport;
    ((struct sockaddr_in *) name)->sin_addr =
        *(struct in_addr *) & (netconf[nets[conp->netno].confix].Iaddr);
    ((struct sockaddr_in *) name)->sin_family = PF_INET;
    *namelen = sizeof(struct sockaddr_in);
#endif
    return 0;
errbs:
    errno = EBADF;
    return -1;
}

int getpeername(int s, struct sockaddr * peer, int *addrlen)
{
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if ((conp->blockstat & 0x9f) != 1)
        goto errbs;
    socp = &socblock[s];
    if (peer == 0 || addrlen == 0) {
        socp->error = errno = EFAULT;
        return -1;
    }
#ifdef  INET6
    Nsetpeeraddr (s, peer, addrlen);
#else
    ((struct sockaddr_in *) peer)->sin_port = conp->herport;
    ((struct sockaddr_in *) peer)->sin_addr.s_addr = conp->realiid.l;
    *addrlen = sizeof(struct sockaddr_in);
#endif
    return 0;
errbs:
    errno = EBADF;
    return -1;
}

int getsockopt(int s, int level, int optname, char *optval, int *optlen)
{
    int actlen;
    unsigned int ui1;
    char *actval;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if ((conp->blockstat & 0x9f) != 1)
        goto errbs;
    socp = &socblock[s];
    if (level == 0)
        level = SOL_SOCKET;
    ui1 = 0;
    actlen = sizeof(int);
    actval = (char *) &ui1;

    if (level == IPPROTO_IP) {
#ifdef IPOPTIONS
        if (optname == IP_OPTIONS) {
            if (optval == 0 || optlen == 0 || *optlen < conp->IPOtxlen)
                goto badarg;
            memcpy(optval, conp->IPOtxopt, conp->IPOtxlen);
            *optlen = conp->IPOtxlen;
            return 0;
        }
#endif
#if USS_IP_MC_LEVEL
        if (optname == IP_MULTICAST_IF) {
            actval = (char *)netconf[nets[conp->netno].confix].Iaddr.c;
            actlen = sizeof(struct in_addr);
            goto ret1;
        }
#endif
    }

    if (level == IPPROTO_TCP) {
        if (optname == TCP_NODELAY) {
            ui1 = socp->sockopt & soNODELAY;
            goto ret1;
        }
        if (optname == TCP_MAXSEG) {
            ui1 = conp->maxdat;
            goto ret1;
        }
    }

    if (level != (int) SOL_SOCKET)
        goto errop;
    switch (optname) {
    case SO_DEBUG:
        ui1 = socp->sockopt & soDEBUG;
        goto ret1;
    case SO_REUSEADDR:
        ui1 = socp->sockopt & soREUSEADDR;
        goto ret1;
    case SO_KEEPALIVE:
        ui1 = conp->txstat & S_KEEPA;
        goto ret1;
    case SO_DONTROUTE:
        ui1 = socp->sockopt & soDONTROUTE;
        goto ret1;
    case SO_BROADCAST:
        ui1 = socp->sockopt & soBROADCAST;
        goto ret1;
    case SO_LINGER:
        actlen = sizeof(struct linger);
        actval = (char *) &socp->linger;
        goto ret1;
    case SO_OOBINLINE:
        ui1 = socp->sockopt & soOOBINLINE;
        goto ret1;
    case SO_SNDBUF:
        ui1 = socp->sndbuf;
        goto ret1;
    case SO_RCVBUF:
        ui1 = socp->rcvbuf;
        goto ret1;
    case SO_ERROR:
        ui1 = socp->error;
        socp->error = 0;
        goto ret1;
    case SO_TYPE:
        if (conp->txstat & S_STRM)
            ui1 = SOCK_STREAM;
        else if (conp->protoc[0] != 0)
            ui1 = SOCK_DGRAM;
        else
            ui1 = SOCK_RAW;
ret1:
        if (optval == 0 || optlen == 0 || *optlen < actlen)
            goto badarg;
        memcpy(optval, actval, actlen);
        *optlen = actlen;
        return 0;
    }
errop:
    socp->error = errno = ENOPROTOOPT;
    return -1;
errbs:
    errno = EBADF;
    return -1;
badarg:
    socp->error = errno = EFAULT;
    return -1;
}

int setsockopt(int s, int level, int optname, char *optval, int optlen)
{
    unsigned int ui1;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    if (conp->blockstat != 1)
        goto errbs;
    socp = &socblock[s];
    if (level == 0)
        level = SOL_SOCKET;

    if (level == IPPROTO_IP) {
        if (optval == 0)
            goto badarg;
#ifdef IPOPTIONS
        if (optname == IP_OPTIONS) {
            if (optlen > sizeof(conp->IPOtxopt))
                goto badarg;
            memset(conp->IPOtxopt, 0, sizeof(conp->IPOtxopt));
            memcpy(conp->IPOtxopt, optval, optlen);
            optlen = (optlen + 3) & ~3;
            conp->IPOtxlen = optlen;
            conp->doffset = socp->doffsetsav + optlen;
            conp->maxdat = socp->maxdatsav - optlen;
            return 0;
        }
#endif
#if USS_IP_MC_LEVEL
        if (optname == IP_MULTICAST_IF) {
            if (optlen != sizeof(struct in_addr))
                goto badarg;
            if (((struct in_addr *)optval)->s_addr == 0)
                conp->netno = ussDfltMcNetno;
            else {
                for (ui1 = 0; ui1 < NCONFIGS; ui1++)
                    if (netconf[ui1].flags & LOCALHOST &&
                        netconf[ui1].Iaddr.l ==
                        ((struct in_addr *)optval)->s_addr)
                    {
                        break;
                    }
                if (ui1 == NCONFIGS)
                    goto badarg;
                conp->netno = netconf[ui1].netno;
            }
            return 0;
        }
        else if (optname == IP_ADD_MEMBERSHIP) {
            if (optlen != sizeof(struct ip_mreq))
                goto badarg;
            if (((struct ip_mreq *)optval)->imr_interface.s_addr == 0)
                conp->netno = ussDfltMcNetno;
            else {
                for (ui1 = 0; ui1 < NCONFIGS; ui1++)
                    if (netconf[ui1].flags & LOCALHOST &&
                        netconf[ui1].Iaddr.l ==
                            ((struct ip_mreq *)optval)->imr_interface.s_addr)
                    {
                        break;
                    }
                if (ui1 == NCONFIGS)
                    goto badarg;
                conp->netno = netconf[ui1].netno;
            }
            return ussHostGroupJoin(
                *(Iid *)&((struct ip_mreq *)optval)->imr_multiaddr.s_addr,
                conp->netno);
        }
        else if (optname == IP_DROP_MEMBERSHIP) {
            if (optlen != sizeof(struct ip_mreq))
                goto badarg;
            return ussHostGroupLeave(
                *(Iid *)&((struct ip_mreq *)optval)->imr_multiaddr.s_addr,
                conp->netno);
        }
#endif
    }

    if (level == IPPROTO_TCP) {
        if (optname == TCP_NODELAY) {
            socp->sockopt ^= soNODELAY;
            return 0;
        }
    }
    if (level != (int) SOL_SOCKET)
        goto errop;
    switch (optname) {
    case SO_DEBUG:
        socp->sockopt ^= soDEBUG;
        return 0;
    case SO_REUSEADDR:
        socp->sockopt ^= soREUSEADDR;
        return 0;
    case SO_KEEPALIVE:
        conp->txstat ^= S_KEEPA;
        return 0;
    case SO_DONTROUTE:
        socp->sockopt ^= soDONTROUTE;
        return 0;
    case SO_BINDTODEVICE:
        if (optval == 0)
            goto badarg;
        for (ui1 = 0; ui1 < NCONFIGS; ui1++)
            if (strcmp(netconf[ui1].pname, optval) == 0)
                if (strcmp(localhostname, netconf[ui1].name) == 0)
                    break;
        conp->netno = (ui1 == NCONFIGS) ? 0 : netconf[ui1].netno;
        conp->offerediid.l = (ui1 == NCONFIGS) ? netconf[0].Iaddr.l :
                                                 netconf[ui1].Iaddr.l;
        return 0;
    case SO_BROADCAST:
        socp->sockopt ^= soBROADCAST;
        return 0;
    case SO_LINGER:
        if (optval == 0 || optlen != sizeof(struct linger))
            goto badarg;
        memcpy((char *) &socp->linger, optval, sizeof(struct linger));
        return 0;
    case SO_OOBINLINE:
        socp->sockopt ^= soOOBINLINE;
        return 0;
    case SO_SNDBUF:
    case SO_RCVBUF:
        if (optval == 0 || optlen != sizeof(int))
            goto badarg;
        ui1 = *(unsigned int *) optval;
        if (optname == SO_SNDBUF)
            socp->sndbuf = ui1;
        else
            socp->rcvbuf = ui1;
        return 0;
    }
errop:
    socp->error = errno = ENOPROTOOPT;
    return -1;
errbs:
    errno = EBADF;
    return -1;
badarg:
    socp->error = errno = EFAULT;
    return -1;
}

static int _recv(int s, char *buf, int len, int flags, int ref, int* npHWport)
{
    int i1, tlen, lalen;
    unsigned char *laptr;
    MESS *mp = NULL;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    int myistreamc;
    MESS * myistreamb;
    char * myistreamp;
    int remain_flag = 0;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE( );
    if (ref && conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if ((conp->blockstat & 0x9f) != 1)
    {
        RESUMEPREE( );
        goto errbs;
    }
    if (ref)
        conp->refcount++;
    RESUMEPREE( );

    if (flags & MSG_OOB && (socp->sockopt & soOOBINLINE) == 0) {
        YIELD();
        if (conp->urgflag == 0)
            goto ret8;
        *buf = conp->urgdata;
        if ((flags & MSG_PEEK) == 0)
            conp->urgflag = 0;
        if (ref)
            conp->refcount--;
        return 1;
    }

    BLOCKPREE();
    if ( conp->blockstat )
    {
        myistreamc = conp->istreamc;
        myistreamb = conp->istreamb;
        myistreamp = conp->istreamp;
        conp->istreamc = 0;
        conp->istreamb = 0;
        conp->istreamp = 0;
        if(myistreamc)
            remain_flag = 1;
    }
    else
    {
        RESUMEPREE();
        if (ref)
            conp->refcount--;
        goto errbs;
    }
    RESUMEPREE();

    for (tlen = 0; tlen < len;) {
        if (!myistreamc) {
            myistreamb = mp = conp->protoc[0]->reaD(s);
            if (mp == 0) {
                if (tlen)
                    break;
                if (conp->rxstat & S_FATAL)
                    goto ret9;
                if (ref)
                    conp->refcount--;
                if (conp->rxstat & S_EOF)
                {
                    return 0;
                }
                YIELD();
                socp->error = errno =
                    conp->txstat & S_NOWA ? EWOULDBLOCK : ETIMEDOUT;
                return -1;
            }
            myistreamc = mp->mlen - mp->offset;
            if (myistreamc < 0)
                goto err1;
            myistreamp = (char *) mp + mp->offset;
            if (conp->tcpflags & S_URG) {
#if 1
                if(conp->urgcnt > myistreamc)
                    conp->urgcnt = myistreamc;
#endif
                if ((socp->sockopt & soOOBINLINE) == 0) {
                    myistreamc -= conp->urgcnt;
                    myistreamp += conp->urgcnt;
                    conp->tcpflags = 0;
                }
            }
        }
        i1 = myistreamc > len - tlen ? len - tlen : myistreamc;

        if ((conp->tcpflags & S_URG) != 0) {
            if(remain_flag){
                if (((myistreamb->mlen - myistreamb->offset) - myistreamc) 
                                                             < conp->urgcnt)
                    i1 = conp->urgcnt;
                else
                    conp->tcpflags = 0;
            } else {
                if (((mp->mlen - mp->offset) - myistreamc) < conp->urgcnt)
                    i1 = conp->urgcnt;
                else
                    conp->tcpflags = 0;
            }
        }
        Nmemcpy(buf, myistreamp, i1);

        if (npHWport) {
            switch( mp->portno ){
            case NETNO_ASYS_PORT_ONE:
                *npHWport = RECEIVED_LANPORT_1;
                break;
            case NETNO_ASYS_PORT_TWO:
                *npHWport = RECEIVED_LANPORT_2;
                break;
            default:
                *npHWport =RECEIVED_LANPORT_UNKNOWN;
                break;
            }
        }

        buf += i1;
        tlen += i1;

        if (flags & MSG_PEEK) {
            if (conp->txstat & S_STRM) {
                mp = conp->first;

                while ((tlen < len) && mp) {
                    laptr = (unsigned char *) mp + mp->offset;
                    laptr += ((*(laptr + 12) >> 4) << 2);
                    lalen = mp->mlen - (laptr - (unsigned char *) mp);
                    i1 = lalen > len - tlen ? len - tlen : lalen;
                    Nmemcpy(buf, laptr, i1);
                    buf += i1;
                    tlen += i1;
                    mp = mp->next;
                }
            }
            BLOCKPREE();
            if (conp->blockstat)
            {
                conp->istreamc = myistreamc;
                conp->istreamb = myistreamb;
                conp->istreamp = myistreamp;
            }
            RESUMEPREE();
            if (ref)
                conp->refcount--;
            return tlen;
        }
        myistreamp += i1;
        if ((myistreamc -= i1) == 0) {
            mp = myistreamb;
            myistreamb = 0;
            Nrelbuf(mp);
        }
        if ((conp->txstat & S_STRM) == 0)
            break;
        if (conp->first == 0)
            break;
    }

    BLOCKPREE();
    if (conp->blockstat)
    {
        conp->istreamc = myistreamc;
        conp->istreamb = myistreamb;
        conp->istreamp = myistreamp;
    }
    else
    {
        RESUMEPREE();
        goto err1;
    }
    RESUMEPREE();

    if (ref)
        conp->refcount--;
    return tlen;
err1:
    if ( myistreamc != 0 )
    {
        Nrelbuf(myistreamb);
    }
ret9:
    if (ref)
        conp->refcount--;
    socp->error = errno = ECONNABORTED;
    return -1;
ret8:
    if (ref)
        conp->refcount--;
    socp->error = errno = EOPNOTSUPP;
    return -1;
errbs:
    errno = EBADF;
    return -1;
}


int recv(int s, char *buf, int len, int flags)
{
    return _recv(s, buf, len, flags, 1, NULL);
}

int recvfrom(int s, char *buf, int len, int flags, struct sockaddr *from,
    int *fromlen, int* npHWport)
{
    int i1;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if ((conp->blockstat & 0x9f) != 1) {
        RESUMEPREE();
        goto errbs;
    }
    conp->refcount++;
    RESUMEPREE();
    do
    {
        conp->rxstat = 0;
        i1 = _recv(s, buf, len, flags, 0, npHWport);
    } while ( (i1 < 0) && (socp->error == ECONNABORTED) );
    if (i1 < 0)
    {
        conp->refcount--;
        return -1;
    }
    if (from != 0) {
#ifdef  INET6
        Nsetpeeraddr (s, from, fromlen);
#else
        ((struct sockaddr_in *) from)->sin_port = conp->herport;
        ((struct sockaddr_in *) from)->sin_addr.s_addr = conp->realiid.l;
        *fromlen = sizeof(struct sockaddr_in);
#endif
    }
    conp->refcount--;
    return i1;
errbs:
    errno = EBADF;
    return -1;
}

int recvmsg(int s, struct msghdr * msg, int flags)
{
    int i1, msgix, tbytes;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    struct iovec *iovp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if ((conp->blockstat & 0x9f) != 1) {
        RESUMEPREE();
        goto errbs;
    }
    conp->refcount++;
    RESUMEPREE();
    if (msg->msg_name == 0)
        goto lab1;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (msg->msg_namelen < sizeof (struct sockaddr_in6) ||
       ((struct sockaddr_in6 *) msg->msg_name)->sin6_family != PF_INET6) {
         goto err1;
    }
    conp->herport = ((struct sockaddr_in6 *) msg->msg_name)->sin6_port;
    Nsetheri6id (s, 
        ((struct sockaddr_in6 *) msg->msg_name)->sin6_addr.s6_addr);
    conp->heriid.l = 0;
} else {
#endif
    conp->herport = ((struct sockaddr_in *) msg->msg_name)->sin_port;
    conp->heriid.l = ((struct sockaddr_in *) msg->msg_name)->sin_addr.s_addr;
#ifdef  INET6
}
#endif
lab1:
    for (tbytes = msgix = 0; msgix < msg->msg_iovlen; msgix++) {
        iovp = &msg->msg_iov[msgix];
        i1 = _recv(s, iovp->iov_base, iovp->iov_len, flags, 0, NULL);
        if (i1 < 0)
            goto err1;
        tbytes += i1;
    }
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    ((struct sockaddr_in6 *) msg->msg_name)->sin6_port = conp->herport;
    ip6acpy(&(((struct sockaddr_in6 *) msg->msg_name)->sin6_addr), 
                &conp->ipv6.reali6id);
    msg->msg_namelen = sizeof(struct sockaddr_in6);
} else {
#endif
    ((struct sockaddr_in *) msg->msg_name)->sin_port = conp->herport;
    ((struct sockaddr_in *) msg->msg_name)->sin_addr.s_addr =
        conp->realiid.l;
    msg->msg_namelen = sizeof(struct sockaddr_in);
    conp->refcount--;
#ifdef  INET6
}
#endif
    return tbytes;
err1:
    socp->error = errno = ECONNABORTED;
    conp->refcount--;
    return -1;
errbs:
    errno = EBADF;
    return -1;
}


static int _send(int s, char *buf, int len, int flags, int ref, int iPort)
{
    int i1, stat = 0, tlen;
    unsigned int maxlen;
    unsigned long ul1;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    struct NET *netp;
    MESS *mp;
    MESS * myostreamb;

    myostreamb = 0;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE( );
    if (ref && conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if (conp->blockstat != 1)
    {
        RESUMEPREE( );
        goto errbs;
    }
    if (ref)
        conp->refcount++;
    RESUMEPREE( );
    if (socp->sockopt & soSHUTSEND) {
        socp->error = errno = ESHUTDOWN;
        if (ref)
            conp->refcount--;
        return -1;
    }
    if (conp->rxstat & S_FATAL) {
        socp->error = errno = ECONNABORTED;
        if (ref)
            conp->refcount--;
        return -1;
    }
    tlen = 0;
    BLOCKPREE();
    if (conp->blockstat == 1)
        conp->blockstat = 0x21;
    else {
        RESUMEPREE();
        if (ref)
            conp->refcount--;
        goto errbs;
    }

    myostreamb = conp->ostreamb;
    conp->ostreamb = 0;
    RESUMEPREE();

    while (tlen < len) {
        if (conp->txstat & S_STRM) {
            maxlen = conp->maxdat + conp->doffset;
            if (flags & MSG_OOB)
                conp->txstat |= S_URG;
            if (len - tlen <= conp->maxdat)
                conp->txstat |= S_PSH;
        } else {
            if (len + conp->doffset > MAXBUF) {
                socp->error = errno = EMSGSIZE;
                goto erret;
            }
            maxlen = len + conp->doffset;
        }
        if ((mp = myostreamb) == 0) {
            if ((mp = myostreamb = Ngetbuf()) == 0) {
                socp->error = errno = ENOBUFS;
                goto erret;
            }
            mp->netno = conp->netno;
            mp->portno = iPort;
#ifdef  INET6
        if (conp->ipv6.family == PF_INET6) {
            Nsetmyi6id (s, (unsigned char *)&conp->ipv6.heri6id);
            ip6acpy(mp->ipv6.target6, &conp->ipv6.heri6id);
            mp->target = 0;
        } else
#endif
            mp->target = conp->heriid.l;
            mp->mlen = mp->offset = conp->doffset;
        }

        i1 = maxlen - mp->mlen > len - tlen ? len - tlen :
            maxlen - mp->mlen;
        Nmemcpy((char *) mp + mp->mlen, buf + tlen, i1);
        tlen += i1;
        mp->mlen += i1;

        if (mp->mlen >= maxlen || conp->nwacks == 0 || (flags & MSG_OOB) ||
            (socp->sockopt & soNODELAY))
        {
            netp = &nets[conp->netno];
            ul1 = conp->txstat & S_NOWA ? 0 : netp->tout;
            WAITFOR(((netp->depart[iPort].mtail - netp->depart[iPort].mhead) & 15) <
                    MAXOUTQLEN, SIG_WN(conp->netno), ul1, stat);
            if (stat)
                stat = ETIMEDOUT;
            else
                stat = conp->protoc[0]->writE(s, mp);

            if ( (conp->txstat & S_STRM) &&
                 (stat == ETIMEDOUT || stat == EWINZERO) )
            {
                if ( tlen == 0 ) {
                    if ( (conp->txstat & S_NOWA) ) {
                        socp->error = errno = (stat == ETIMEDOUT) ? EWOULDBLOCK : stat;
                        stat = -1;
                    }
                    else
                        continue;
                }
                else
                    stat = tlen;
                break;
            }

            myostreamb = 0;
            if (stat)
            {
               Nrelbuf(mp);
            }

            if (stat < 0) {
                socp->error = errno = (stat == ETIMEDOUT) ? EWOULDBLOCK : stat;
                stat = -1;
                break;
            }
        }
        stat = len;
    }

#if MT != 2
    YIELD();
#endif
    BLOCKPREE();
    if (conp->blockstat != 0)
    {
        conp->ostreamb = myostreamb;
#if 1
        conp->blockstat &= 4;
        conp->blockstat |= 1;
#else
        conp->blockstat = 1;
#endif
    }
    else
    {
        if (myostreamb)
        {
            Nrelbuf(myostreamb);
        }
        socp->error = errno = ECONNABORTED;
        stat = -1;
    }
    RESUMEPREE();
    if (ref)
        conp->refcount--;
    return stat;
erret:
    stat = -1;
    BLOCKPREE();
    if (conp->blockstat != 0)
#if 1
    {
        conp->blockstat &= 4;
        conp->blockstat |= 1;
    }
#else
        conp->blockstat = 1;
#endif
    else
        socp->error = errno = ECONNABORTED;
    RESUMEPREE();
    if (ref)
        conp->refcount--;
    return stat;
errbs:
    errno = EBADF;
    return -1;
}

int send(int s, char *buf, int len, int flags, int iPort)
{
    return _send(s, buf, len, flags, 1, iPort);
}

int sendto(int s, char *buf, int len, int flags, struct sockaddr *to, int tolen, int iPort)
{
    int i1, confix;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    unsigned short us1;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if (conp->blockstat != 1) {
        RESUMEPREE();
        goto errbs;
    }
    conp->refcount++;
    RESUMEPREE();
    if (conp->txstat & S_STRM)
        goto lab3;
#ifdef  INET6
    if (to == 0 || 
        (conp->ipv6.family == PF_INET6 && tolen < sizeof (struct sockaddr_in6))) {
        socp->error = errno = EDESTADDRREQ;
        return -1;
    } else
#endif
    if (to == 0 || tolen < Iid_SZ) {
        socp->error = errno = EDESTADDRREQ;
        conp->refcount--;
        return -1;
    }
    conp->blockstat = 0x21;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (tolen < sizeof (struct sockaddr_in6) ||
        ((struct sockaddr_in6 *) to)->sin6_family != PF_INET6) {
        goto errbs;
    }
    Nsetheri6id (s, ((struct sockaddr_in6 *) to)->sin6_addr.s6_addr);
    conp->heriid.l = 0;
} else
#endif
    conp->heriid.l = ((struct sockaddr_in *) to)->sin_addr.s_addr;
    i1 = socp->sockopt & soBROADCAST ? 1 : 3;
    if (socp->sockopt & soDONTROUTE || flags & MSG_DONTROUTE)
        i1 |= 8;
#ifdef  INET6
    if (conp->ipv6.family == PF_INET6)
        confix = GetHostData6(&conp->ipv6.heri6id.c[0], i1, conp->netno);
    else
        confix = GetHostData(conp->heriid.l, i1, conp->netno);
    if (confix < 0) {
#else
    if ((confix = GetHostData(conp->heriid.l, i1, conp->netno)) < 0) {
#endif
        socp->error = errno = EHOSTUNREACH;
        conp->blockstat = 1;
        conp->refcount--;
        return -1;
    }
    if (confix != ussBroadcastIndex)
#if USS_IP_MC_LEVEL
      if (confix != ussMulticastIndex)
#endif
        conp->netno = netconf[confix].netno;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (((struct sockaddr_in6 *) to)->sin6_scope_id) {
        i1 = ((struct sockaddr_in6 *) to)->sin6_scope_id - 1;
        if (0 <= i1 && i1 < NNETS && nets[i1].netstat != 0)
            conp->netno = i1;
        else {
            socp->error = errno = EHOSTUNREACH;
            conp->blockstat = 1;
            return -1;
        }
    }
}
#endif
    conp->confix = confix;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6)
    conp->herport = ((struct sockaddr_in6 *) to)->sin6_port;
else
#endif
    conp->herport = ((struct sockaddr_in *) to)->sin_port;
    if (conp->myport == 0)
        us1 = Nportno(), conp->myport = NC2(us1);
    conp->rxstat = 0;
    conp->state = 1;
    conp->blockstat = 1;
lab3:
    i1 = _send(s, buf, len, flags, 0, iPort);
    conp->refcount--;
    return i1;
errbs:
    errno = EBADF;
    return -1;
}

int sendmsg(int s, struct msghdr * msg, int flags)
{
    int i1, confix, msgix, tbytes;
    unsigned short us1;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;
    struct iovec *iovp;

    if ((unsigned int) s >= NCONNS)
        goto errbs;
    conp = &connblo[s];
    socp = &socblock[s];
    BLOCKPREE();
    if (conp->refcount > 0) {
        RESUMEPREE();
        socp->error = errno = EWOULDBLOCK;
        return -1;
    }
    if (conp->blockstat != 1) {
        RESUMEPREE();
        goto errbs;
    }
    conp->refcount++;
    RESUMEPREE();
    if (conp->txstat & S_STRM)
        goto lab3;
    conp->blockstat = 0x21;
#ifdef  INET6
if (conp->ipv6.family == PF_INET6) {
    if (msg->msg_namelen < sizeof (struct sockaddr_in6) ||
        ((struct sockaddr_in6 *) msg->msg_name)->sin6_family != PF_INET6) {
        goto errbs;
    }
    conp->herport = ((struct sockaddr_in6 *) msg->msg_name)->sin6_port;
    Nsetheri6id (s, 
        ((struct sockaddr_in6 *) msg->msg_name)->sin6_addr.s6_addr);
    conp->heriid.l = 0;
} else {
#endif
    conp->herport = ((struct sockaddr_in *) msg->msg_name)->sin_port;
    conp->heriid.l = ((struct sockaddr_in *) msg->msg_name)->sin_addr.s_addr;
#ifdef  INET6
}
#endif
    i1 = socp->sockopt & soBROADCAST ? 1 : 3;
    if (socp->sockopt & soDONTROUTE || flags & MSG_DONTROUTE)
        i1 |= 8;
#ifdef  INET6
    if (conp->ipv6.family == PF_INET6)
        confix = GetHostData6(conp->ipv6.heri6id.c, i1, conp->netno);
    else
        confix = GetHostData(conp->heriid.l, i1, conp->netno);
    if (confix < 0) {
#else
    if ((confix = GetHostData(conp->heriid.l, i1, conp->netno)) < 0) {
#endif
        socp->error = errno = EHOSTUNREACH;
        conp->blockstat = 1;
        conp->refcount--;
        return -1;
    }
    conp->confix = confix;
    conp->netno = netconf[confix].netno;
    if (conp->myport == 0)
        us1 = Nportno(), conp->myport = NC2(us1);
    conp->rxstat = 0;
    conp->state = 1;
    conp->blockstat = 1;
lab3:
    for (tbytes = msgix = 0; msgix < msg->msg_iovlen; msgix++) {
        iovp = &msg->msg_iov[msgix];
        i1 = _send(s, iovp->iov_base, iovp->iov_len, flags, 0, -1);
        if (i1 < 0) {
            conp->refcount--;
            return i1;
        }
        tbytes += i1;
    }
    conp->refcount--;
    return tbytes;
errbs:
    errno = EBADF;
    return -1;
}

int shutdown(int s, int how)
{
    MESS *mp;
    struct CONNECT *conp;
    struct SOCBLOCK *socp;

    if ((unsigned int) s >= NCONNS || (unsigned int) how > 2)
        goto errbs;
    conp = &connblo[s];
    if ((conp->blockstat & 0x9f) != 1)
        goto errbs;
    socp = &socblock[s];
    if (socp->sockopt & soLISTEN) {
        return 0;
    }
    if ((how & 1) == 0)
        socblock[s].sockopt |= soSHUTRECV;
    if (how != 0) {
        socblock[s].sockopt |= soSHUTSEND;
        if (conp->txstat & S_STRM) {
            SOCKET_FIN(s);
            SOCKET_PUSH(s);

            BLOCKPREE();
            if (conp->ostreamb) {
                mp = conp->ostreamb;
                conp->ostreamb = 0;
            }
            else {
                RESUMEPREE();
                if ((mp = Ngetbuf()) == 0) {
                    socp->error = errno = ENOBUFS;
                    return -1;
                }
                mp->mlen = conp->doffset;
                BLOCKPREE();
            }
            RESUMEPREE();
            mp->netno = conp->netno;
#ifdef  INET6
        if (conp->ipv6.family == PF_INET6) {
            Nsetmyi6id(s, (unsigned char *)&conp->ipv6.heri6id);
            ip6acpy(mp->ipv6.target6, &conp->ipv6.heri6id);
            mp->target = 0;
        } else 
#endif
            mp->target = conp->heriid.l;
            mp->portno = conp->portno;
            if (conp->protoc[0]->writE(s, mp))
                Nrelbuf(mp);
        }
    }
    return 0;
errbs:
    errno = EBADF;
    return -1;
}


static int selectcheck(int nfds, fd_set *readfds, fd_set *writefds,
    fd_set *exceptfds)
{
    int changes;
    fd_set rd, wr, ex;
    struct CONNECT *conp;

    if (readfds)
        rd = *readfds;
    if (writefds)
        wr = *writefds;
    if (exceptfds)
        ex = *exceptfds;

    for (changes = 0, nfds--; nfds >= 0; nfds--) {
        conp = &connblo[nfds];
#ifdef UDP
        if (conp->protoc[0] == &ussUDPTable) {
            if (conp->rxstat & S_FATAL)
                conp->rxstat &= ~S_FATAL;
        }
#endif
        if (readfds)
            if (FD_ISSET(nfds, readfds)) {
                if (conp->first ||
                         conp->istreamc ||
                         ((socblock[nfds].sockopt & soLISTEN) && conp->next))
                {
                    changes++;
                }
                else if ((conp->blockstat == 0) ||
                    ((conp->rxstat & S_EOF) && (!conp->first)) ||
                    (conp->rxstat & S_FATAL))
                {
                    changes++;
                }
                else {
                   FD_CLR(nfds, &rd);
                }
            }
        if (writefds)
            if (FD_ISSET(nfds, writefds)) {
                if (conp->blockstat == 0 ||
                    (conp->rxstat & S_FATAL) ||
                    (conp->blockstat & 4))
                {
                    changes++;
                }
                else if (SOCKET_CANSEND(nfds, 100))
                {
                    changes++;
                }
                else {
                    FD_CLR(nfds, &wr);
                }
            }
        if (exceptfds)
            if (FD_ISSET(nfds, exceptfds)) {
                if (conp->blockstat == 0 ||
                    (conp->rxstat & S_FATAL))
                {
                    changes++;
                }
                else if (conp->urgflag)
                {
                    changes++;
                }
                else {
                    FD_CLR(nfds, &ex);
                }
            }
    }

    if (changes) {
        if (readfds)
            *readfds = rd;
        if (writefds)
            *writefds = wr;
        if (exceptfds)
            *exceptfds = ex;
    }

    return changes;

}


int selectsocket(int nfds, fd_set *readfds, fd_set *writefds,
    fd_set *exceptfds, struct timeval *timeout)
{
    int i1, i2;
    unsigned long tout;

    if (timeout)
        tout = (timeout->tv_sec * 1000) + ((timeout->tv_usec + 500) / 1000);
    else
        tout = 0xffffffff;

    if (nfds > NCONNS)
        nfds = NCONNS;

    ussSelectFlag++;
    WAITFOR((i2 = selectcheck(nfds, readfds, writefds, exceptfds)),
            SIG_SEL, tout, i1);
    ussSelectFlag--;

    if ( i2 == 0 )
    {
        if ( readfds )
        {
            memset( readfds, 0, sizeof( * readfds ) );
        }
        if ( writefds )
        {
            memset( writefds, 0, sizeof( * writefds ) );
        }
        if ( exceptfds )
        {
            memset( exceptfds, 0, sizeof( * exceptfds ) );
        }
    }

    return i2;
}


struct hostent *gethostbyname_r(char *hnp, struct hostent *result,
    char *buffer, int buflen, int *h_errnop)
{
    int retstat, netno, remix, len, hops;
#ifdef DNS
    char name[64], pname[16];
#else
    char name[16], pname[16];
#endif
    Iid iid;
    struct NETCONF *confp;

    retstat = -1;
    name[0] = pname[0] = '*';
    Nsscanf(hnp, "%[^/]/%s", name, pname);
    len = strlen(name) + 1;
    if (buflen < Iid_SZ + len + 11)
        goto err1;
    strcpy(buffer, name);
    for (remix = 0, hops = 255; remix < NCONFIGS; remix++) {
        confp = &netconf[remix];
        if (confp->ncstat == 0)
            continue;
        if (pname[0] != '*' && strcmp(pname, confp->pname) != 0)
            continue;
        if (name[0] == '*') {
            if (pname[0] == '*')
                iid.l = 0xffffffff;
            else
                iid.l = confp->Iaddr.l | ~confp->Imask.l;
            goto lab1;
        }
        if (strcmp(confp->name, name) != 0)
            continue;
        if (confp->hops < (unsigned int) hops) {
            iid = confp->Iaddr;
            hops = confp->hops;
        }
    }
    if (hops == 255) {
#ifdef DNS
#if DNS == 2
        retstat = DNSresolve(name, &iid);
        if (retstat >= 0)
            goto lab1;
#endif
#endif
        goto err1;
    }
lab1:
    result->h_name = buffer;
    result->h_aliases = 0;
    result->h_addrtype = AF_INET;
    result->h_length = Iid_SZ;
    netno = (4 - (int) buffer) & 3;
    len = netno + ((len + 3) & ~3);
    memcpy(buffer + len, (char *) &iid, Iid_SZ);
    result->h_addr_list = (char **) (buffer + len + Iid_SZ);
    result->h_addr_list[0] = buffer + len;
    result->h_addr_list[1] = 0;
    *h_errnop = 0;
    return result;
err1:
    *h_errnop = retstat;
    return 0;
}

static struct hostent hostent;
static char     buff[64];
struct hostent *gethostbyname(char *hnp)
{
    int             stat;

    gethostbyname_r(hnp, &hostent, buff, sizeof(buff), &stat);
    if (stat >= 0)
        return &hostent;
    return 0;
}

struct hostent *gethostbyaddr_r(char *addr, int len, int type,
    struct hostent *result, char *buffer, int buflen, int *h_errnop)
{
    int retstat, netno, remix, wlen;
    struct NETCONF *confp;

    retstat = -1;
    if (len != Iid_SZ)
        goto err1;
    if (type != AF_INET)
        goto err1;
    for (remix = 0; remix < NCONFIGS; remix++) {
        confp = &netconf[remix];
        if (confp->ncstat == 0)
            continue;
        if (confp->Iaddr.l == ((struct in_addr *) addr)->s_addr)
            goto lab1;
    }
    goto err1;
lab1:
    wlen = strlen(confp->name) + 1;
    if (buflen < Iid_SZ + wlen + 11)
        goto err1;
    strcpy(buffer, confp->name);
    result->h_name = buffer;
    result->h_aliases = 0;
    result->h_addrtype = AF_INET;
    result->h_length = Iid_SZ;
    netno = (4 - (int) buffer) & 3;
    wlen = netno + ((wlen + 3) & ~3);
    memcpy(buffer + wlen, addr, Iid_SZ);
    result->h_addr_list = (char **) (buffer + wlen + Iid_SZ);
    result->h_addr_list[0] = buffer + wlen;
    result->h_addr_list[1] = 0;
    *h_errnop = 0;
    return result;
err1:
    *h_errnop = retstat;
    return 0;
}

static struct hostent hostent2;
static char     buff2[80];
struct hostent *gethostbyaddr(char *addr, int len, int type)
{
    int stat;

    gethostbyaddr_r(addr, len, type, &hostent2, buff2, sizeof(buff2), &stat);
    if (stat >= 0)
        return &hostent2;
    return 0;
}

int fcntlsocket(int fildes, int cmd, int arg)
{
    int status;
    struct CONNECT *conp;

    if ((unsigned int) fildes >= NCONNS)
        goto errbs;
    conp = &connblo[fildes];
    if (conp->blockstat != 1)
        goto errbs;
    status = -1;
    switch (cmd) {
    case F_GETFL:
        status = conp->txstat & S_NOWA ? O_NDELAY : 0;
        break;
    case F_SETFL:
        if (arg & O_NDELAY)
            conp->txstat |= S_NOWA, conp->rxtout = 0;
        else
            conp->txstat &= ~S_NOWA, conp->rxtout = 0xffffffff;
        status = 0;
        break;
    }
    return status;
errbs:
    errno = EBADF;
    return -1;
}

int ioctlsocket(int fildes, int request,...)
{
    int status;
    int thdrsz;
    int *ip;
    va_list args;
    MESS *mp;
    struct CONNECT *conp;

    va_start(args, request);

    if ((unsigned int) fildes >= NCONNS)
        goto errbs;
    conp = &connblo[fildes];
    if (conp->blockstat != 1)
        goto errbs;
    switch (request) {
    default:
        status = -1;
        break;
    case FIONBIO:
        if (*(int *) va_arg(args, int *) !=0)
            conp->txstat |= S_NOWA, conp->rxtout = 0;
        else
            conp->txstat &= ~S_NOWA, conp->rxtout = 0xffffffff;
        status = 0;
        break;
    case FIONREAD:
        ip = va_arg(args, int *);
        BLOCKPREE();
        status = conp->istreamc;
        for (mp = conp->first; mp; mp = mp->next) {
            thdrsz = 0;
            if (conp->txstat & S_STRM)
                thdrsz = ((*((unsigned char *) mp + mp->offset + 12) >> 4) << 2);
#ifdef UDP
            else if (conp->protoc[0] == &ussUDPTable)
                thdrsz = 8;
#endif
            status += mp->mlen - mp->offset - thdrsz;
        }
        RESUMEPREE();
        *ip = status;
        status = 0;
        break;
    case SIOCATMARK:
        ip = va_arg(args, int *);
        if (conp->tcpflags & S_URG)
            *ip = 1;
        else
            *ip = 0;
        status = 0;
        break;
    }
    return status;
errbs:
    errno = EBADF;
    return -1;
}

void sleepsocket(int sec)
{
    unsigned long ul1, ul2;

    ul2 = sec * 1000;
    for (ul1 = TimeMS(); TimeMS() - ul1 < ul2;)
        YIELD();
}


static char ntoabuf[16];
char *inet_ntoa(struct in_addr addr)
{
    Nsprintf(ntoabuf, "%d.%d.%d.%d", ((unsigned char *) &addr.s_addr)[0],
    ((unsigned char *) &addr.s_addr)[1], ((unsigned char *) &addr.s_addr)[2],
             ((unsigned char *) &addr.s_addr)[3]);
    return ntoabuf;
}

