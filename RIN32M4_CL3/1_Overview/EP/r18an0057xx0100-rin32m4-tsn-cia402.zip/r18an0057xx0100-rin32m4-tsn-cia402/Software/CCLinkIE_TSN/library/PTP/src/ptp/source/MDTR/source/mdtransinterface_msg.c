/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"

#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "PTP_GlobalData.h"

#include "ptpwrap_Type.h"
#include "ptpwrap_Proto.h"
#include "ptp_tsn_Wrapper.h"

#include "ptp_CommonFunction.h"

#include "mdtransinterface.h"
#include "mdtransinterface_msg.h"

union to_usval
{
	USHORT	usVal;
	UCHAR	uchVal[2];
};
union to_ulval
{
	ULONG	ulVal;
	UCHAR	uchVal[4];
};
static BOOL ptp_Mdl_ntohMsgSignalTLV( UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg );



BOOL ptp_Mdl_ntohMsgHeader(UCHAR* puchMsgPtr, PTPMSG_HEADER* pstPtpmsgHdr)
{
	USHORT	usMsgLen = 0;
    pstPtpmsgHdr->byMjSdoIdAndMsgTyp = (BYTE)*puchMsgPtr;
	puchMsgPtr += PTPMSG_HEAD_MJSDOIDANDMSGTYP_SZ;

	pstPtpmsgHdr->byMiVerAndVerPTP = (BYTE)*puchMsgPtr;

	puchMsgPtr += PTPMSG_HEAD_MIVERANDVERPTP_SZ;

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsgHdr->usMegLength);
	puchMsgPtr += (PTPMSG_HEAD_MEGLENGTH_SZ);
	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	if (pstPtpmsgHdr->usMegLength < usMsgLen )
	{
		return FALSE;
	}
	pstPtpmsgHdr->uchDomainNumber	 = *puchMsgPtr;
	puchMsgPtr += (PTPMSG_HEAD_DOMAINNUMBER_SZ);

	pstPtpmsgHdr->uchMinorSdoId		 = *puchMsgPtr;
	puchMsgPtr += (PTPMSG_HEAD_MINORSDOID_SZ);

	pstPtpmsgHdr->byFlags0 = (BYTE)*puchMsgPtr;
	puchMsgPtr += PTPMSG_HEAD_FLAGS0_SZ;

	pstPtpmsgHdr->byFlags1 = (BYTE)*puchMsgPtr;

	puchMsgPtr += PTPMSG_HEAD_FLAGS1_SZ;

	mdtra_ntoh_FracN64(puchMsgPtr, &pstPtpmsgHdr->stCorrectionField);
	puchMsgPtr += (PTPMSG_HEAD_CORRECTIONFIELD_SZ);

	tsn_Wrapper_MemCpy(pstPtpmsgHdr->uchMsgTypSpecific, puchMsgPtr,
		(PTPMSG_HEAD_MSGTYPSPECIFIC_SZ));
	puchMsgPtr += (PTPMSG_HEAD_MSGTYPSPECIFIC_SZ);

	mdtra_ntoh_PortID(puchMsgPtr, &pstPtpmsgHdr->stSrcPortIdentity);
	puchMsgPtr += (PTPMSG_HEAD_SRCPORTIDENTITY_SZ);

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsgHdr->usSequenceId);
	puchMsgPtr += (PTPMSG_HEAD_SEQUENCEID_SZ);

	pstPtpmsgHdr->uchControl = *puchMsgPtr;
	puchMsgPtr += (PTPMSG_HEAD_CONTROL_SZ);

	pstPtpmsgHdr->chLogMsgInterVal = (CHAR)*puchMsgPtr;

	return TRUE;
}


#ifdef	PTP_USE_IEEE802_1
BOOL ptp_Mdl_ntohMsgSyncAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		= 0;
	USHORT			usMsghLen		= 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(pstPtpmsgHdr) )
	{
		tsn_Wrapper_MemCpy(pstPtpmsg->stSyncTwo_1AS.uchReserved,
			puchTomsg, (PTPMSG_AS_SYNC_TWOS_RESERVED_SZ));
		GetPTPMSG_SYNC_TWO_STEP_1AS(pstPtpmsg->stSyncTwo_1AS, usMsgLen);
	}
	else
	{
		mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stSyncOne_1AS.stOriginTimestamp);
		puchTomsg += (PTPMSG_AS_SYNC_ONES_ORIGINTS_SZ);

		if (ptp_Mdl_ntohMsgFollowUpTLV(puchTomsg,
			(PTPMSG_FOLLOWUP_TLV*)&pstPtpmsg->stSyncOne_1AS.stFollowUP_TLV) == FALSE)
		{
			return FALSE;
		}
		GetPTPMSG_SYNC_ONE_STEP_1AS(pstPtpmsg->stSyncOne_1AS, usMsgLen);
		GetPTPMSG_FOLLOWUP_TLV(pstPtpmsg->stSyncOne_1AS.stFollowUP_TLV, usMsgLen);
	}

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsghLen);
	usMsgLen += usMsghLen;
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}


BOOL ptp_Mdl_ntohMsgFollowUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		= 0;
	PTPMSG_HEADER*	pstPtpmsgHdr	= (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg	=  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stFollowUp_1AS.stPrcsOrgnTimestamp);
	puchTomsg += (PTPMSG_AS_FLLWUP_PRCSORGNTS_SZ);

	if (ptp_Mdl_ntohMsgFollowUpTLV(puchTomsg,
		(PTPMSG_FOLLOWUP_TLV*)&pstPtpmsg->stFollowUp_1AS.stFollowUP_TLV) == FALSE)
	{
		return FALSE;
	}

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_FOLLOWUP_1AS(pstPtpmsg->stFollowUp_1AS, usMsgLen);
	GetPTPMSG_FOLLOWUP_TLV(pstPtpmsg->stFollowUp_1AS.stFollowUP_TLV, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return	TRUE;
}
#endif


BOOL ptp_Mdl_ntohMsgFollowUpTLV(UCHAR* puchMsgPtr, PTPMSG_FOLLOWUP_TLV* pstPtpmsg)
{
	USHORT			usMsgTlvLen		 = 0;
	USHORT	usDtFld = 0;

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsg->usTLVType);
	puchMsgPtr += (PTPMSG_FLWUPT_TLVTYPE_SZ);
	usDtFld += (PTPMSG_FLWUPT_TLVTYPE_SZ);

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsg->usLengthField);
	puchMsgPtr += (PTPMSG_FLWUPT_TLVLENGTH_SZ);
	usDtFld += (PTPMSG_FLWUPT_TLVLENGTH_SZ);

	GetPTPMSG_FOLLOWUP_TLV(*pstPtpmsg, usMsgTlvLen);
	if (pstPtpmsg->usLengthField !=
		(usMsgTlvLen - PTPMSG_FLWUPT_TLVTYPE_SZ - PTPMSG_FLWUPT_TLVLENGTH_SZ))
	{
		return FALSE;
	}

	tsn_Wrapper_MemCpy(pstPtpmsg + usDtFld, puchMsgPtr,
		PTPMSG_FLWUPT_ORGANIZATIONID_SZ);
	puchMsgPtr += PTPMSG_FLWUPT_ORGANIZATIONID_SZ;
	usDtFld += PTPMSG_FLWUPT_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy(pstPtpmsg + usDtFld, puchMsgPtr,
		PTPMSG_FLWUPT_ORGSUBTYPE_SZ);
	puchMsgPtr += PTPMSG_FLWUPT_ORGSUBTYPE_SZ;

	mdtra_ntoh_ul(puchMsgPtr, (ULONG*)&pstPtpmsg->lCmltvScaledRateOffset);
	puchMsgPtr += (PTPMSG_FLWUPT_CMSCLDRATEOFS_SZ);

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsg->usGMTmBaseIndicator);
	puchMsgPtr += (PTPMSG_FLWUPT_GMTMBASEINDCTR_SZ);

	mdtra_ntoh_SNs(puchMsgPtr, &pstPtpmsg->stLstGMPhsChange);
	puchMsgPtr += (PTPMSG_FLWUPT_LSTGMPHSCHG_SZ);

	mdtra_ntoh_ul(puchMsgPtr, (ULONG*)&pstPtpmsg->lScaledLstGMFrqChange);

	return TRUE;
}


#ifdef	PTP_USE_IEEE802_1
BOOL ptp_Mdl_ntohMsgPDlyReqAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen			= 0;
	PTPMSG_HEADER*	pstPtpmsgHdr	= (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	tsn_Wrapper_MemCpy(pstPtpmsg->stPdlyReq_1AS.uchReserved1, puchTomsg,
		(PTPMSG_AS_PDELAYREQ_RESERVED1_SZ));
	puchTomsg += (PTPMSG_AS_PDELAYREQ_RESERVED1_SZ);

	tsn_Wrapper_MemCpy(pstPtpmsg->stPdlyReq_1AS.uchReserved2, puchTomsg,
		(PTPMSG_AS_PDELAYREQ_RESERVED2_SZ));

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDELAY_REQ_1AS(pstPtpmsg->stPdlyReq_1AS, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}


BOOL ptp_Mdl_ntohMsgPDlyRespAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stPdlyResp_1AS.stReqRcptTimestamp);
	puchTomsg += (PTPMSG_AS_PDELAYRESP_REQRCPTS_SZ);

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stPdlyResp_1AS.stReqPortIdentity);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDELAY_RESP_1AS(pstPtpmsg->stPdlyResp_1AS, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}


BOOL ptp_Mdl_ntohMsgPDlyRespFllwUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stPDRespFlwUp_1AS.stRespOrgnTimestamp);
	puchTomsg += (PTPMSG_AS_PDLYRESPFL_RSPORGTS_SZ);

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stPDRespFlwUp_1AS.stReqPortIdentity);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDRESP_FOLLOWUP_1AS(pstPtpmsg->stPDRespFlwUp_1AS, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}



static BOOL ptp_Mdl_ntohMsgSignalTLV( UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg )
{
	USHORT			            usMsgTlvLen		 = 0U;
	USHORT			            usDtFld = 0U;
	PTPMSG_INTERVAL_TLV*        pstIntervalTLV;
	PTPMSG_GPTPCAPABLE_TLV*     pstGptpCapTLV;
	PTPMSG_GPTPCAPABLE_INT_TLV* pstGptpCapIntTLV;
	UINT unSubType;


	pstIntervalTLV = &pstPtpmsg->stSignaling_1AS.stIntervalReq_TLV;

	(VOID)mdtra_ntoh_us( puchMsgPtr, &pstIntervalTLV->usTLVType );
	puchMsgPtr += PTPMSG_INTVL_TVLTYPE_SZ;
	usDtFld    += PTPMSG_INTVL_TVLTYPE_SZ;

	(VOID)mdtra_ntoh_us( puchMsgPtr, &pstIntervalTLV->usLengthField );
	puchMsgPtr += PTPMSG_INTVL_TLVLENGTH_SZ;
	usDtFld    += PTPMSG_INTVL_TLVLENGTH_SZ;
	
	tsn_Wrapper_MemCpy( (VOID *)&pstIntervalTLV->uchOrganizationID,
						(VOID *)puchMsgPtr,
					    PTPMSG_INTVL_ORGANIZATIONID_SZ );
	puchMsgPtr += PTPMSG_INTVL_ORGANIZATIONID_SZ;
	usDtFld    += PTPMSG_INTVL_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy( (VOID *)pstIntervalTLV->uchOrganizationSubType, 
						(VOID *)puchMsgPtr,
		                PTPMSG_INTVL_ORGSUBTYPE_SZ );
	puchMsgPtr += PTPMSG_INTVL_ORGSUBTYPE_SZ;

	
	unSubType  = (UINT)pstIntervalTLV->uchOrganizationSubType[0] << 16;
	unSubType += (UINT)pstIntervalTLV->uchOrganizationSubType[1] << 8;
	unSubType += (UINT)pstIntervalTLV->uchOrganizationSubType[2];
	
	switch( unSubType )
	{
		case PTPMSG_TLV_ORGSUBTYPE_INTERVAL:
			GetPTPMSG_INTERVAL_TLV( *pstIntervalTLV, usMsgTlvLen );
			usMsgTlvLen -= PTPMSG_GPTPCAP_TVLTYPE_SZ;
			usMsgTlvLen -= PTPMSG_GPTPCAP_TLVLENGTH_SZ;
			if ( pstIntervalTLV->usLengthField != usMsgTlvLen )
			{
				return FALSE;
			}
			pstIntervalTLV->chLinkDelayInterval = (CHAR)*puchMsgPtr;
			puchMsgPtr += PTPMSG_INTVL_LKDLYINTVAL_SZ;

			pstIntervalTLV->chTimeSyncInterval = (CHAR)*puchMsgPtr;
			puchMsgPtr += PTPMSG_INTVL_TMSYNINTVAL_SZ;

			pstIntervalTLV->chAnnounceInterval = (CHAR)*puchMsgPtr;
			puchMsgPtr += PTPMSG_INTVL_ANUNCINTVAL_SZ;

			pstIntervalTLV->byFlags = (BYTE)*puchMsgPtr;
			puchMsgPtr += PTPMSG_INTVL_FLAGS_SZ;

			tsn_Wrapper_MemCpy( (VOID *)&pstIntervalTLV->uchReserved, 
								(VOID *)puchMsgPtr,
								PTPMSG_INTVL_RESERVED_SZ );
			break;

		case PTPMSG_TLV_ORGSUBTYPE_GPTPCAP:
			pstGptpCapTLV = &pstPtpmsg->stSignaling_1AS.stGptpCap_TLV;

			GetPTPMSG_GPTPCAPABLE_TLV( *pstGptpCapTLV, usMsgTlvLen );
			usMsgTlvLen -= PTPMSG_GPTPCAP_TVLTYPE_SZ;
			usMsgTlvLen -= PTPMSG_GPTPCAP_TLVLENGTH_SZ;
			if ( pstGptpCapTLV->usLengthField != usMsgTlvLen )
			{
				return FALSE;
			}
			pstGptpCapTLV->chlogGptpCapableMessageInterval = (CHAR)*puchMsgPtr;
			puchMsgPtr += PTPMSG_GPTPCAP_LOGGPTPCAPMSGINT_SZ;

			pstGptpCapTLV->byFlags = (BYTE)*puchMsgPtr;
			puchMsgPtr += PTPMSG_INTVL_FLAGS_SZ;

			tsn_Wrapper_MemCpy( (VOID *)&pstGptpCapTLV->uchReserved, 
								(VOID *)puchMsgPtr,
								PTPMSG_GPTPCAP_RESERVED_SZ );

			break;
		case PTPMSG_TLV_ORGSUBTYPE_GPTPCAPINT:
			pstGptpCapIntTLV = &pstPtpmsg->stSignaling_1AS.stGptpCapInt_TLV;

			GetPTPMSG_GPTPCAPABLE_INT_TLV( *pstGptpCapIntTLV, usMsgTlvLen );
			usMsgTlvLen -= PTPMSG_GPTPCAPINT_TVLTYPE_SZ;
			usMsgTlvLen -= PTPMSG_GPTPCAPINT_TLVLENGTH_SZ;
			if ( pstGptpCapIntTLV->usLengthField != usMsgTlvLen )
			{
				return FALSE;
			}
			pstGptpCapIntTLV->chlogGptpCapableMessageInterval = (CHAR)*puchMsgPtr;
			puchMsgPtr += PTPMSG_GPTPCAPINT_LOGGPTPCAPMSGINT_SZ;

			tsn_Wrapper_MemCpy( (VOID *)&pstGptpCapIntTLV->uchReserved, 
								(VOID *)puchMsgPtr,
								PTPMSG_GPTPCAPINT_RESERVED_SZ );
			break;
		default:
			return FALSE;
	}
	
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgSignalAS( UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg )
{
	USHORT	usMsgLen  = 0U;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	BOOL blRet;

	(VOID)mdtra_ntoh_PortID( puchTomsg, &pstPtpmsg->stSignaling_1AS.stTargetPortIdentity );
	puchTomsg += PTPMSG_AS_SGNL_TGTPORTID_SZ;
	
	blRet = ptp_Mdl_ntohMsgSignalTLV( puchTomsg, pstPtpmsg );

	return blRet;
}

#endif


#ifdef	PTP_USE_IEEE802_1

BOOL ptp_Mdl_ntohMsgAnnounceAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg, USHORT usMsgLen)
{
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	BOOL	blRet;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stAnnounce.stOriginTimestamp);
	puchTomsg += (PTPMSG_ANUNC_RESERVEDAS_SZ);

	(VOID)mdtra_ntoh_us(puchTomsg, (USHORT*)&pstPtpmsg->stAnnounce.sCurrentUtcOffset);
	puchTomsg += (PTPMSG_ANUNC_CRNTUTCOFS_SZ);

	pstPtpmsg->stAnnounce.uchReserved = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_RESERVED_SZ);

	pstPtpmsg->stAnnounce.uchGrandmasterPriority1 = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY1_SZ);

	mdtra_ntoh_CLKQLTY(puchTomsg, &pstPtpmsg->stAnnounce.stGrandmasterClockQuality);
	puchTomsg += (PTPMSG_ANUNC_GMCLKQUALITY_SZ);

	pstPtpmsg->stAnnounce.uchGrandmasterPriority2 = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY2_SZ);

	tsn_Wrapper_MemCpy(&pstPtpmsg->stAnnounce.stGrandmasterIdentity,
		puchTomsg, (PTPMSG_ANUNC_GMCLKID_SZ));
	puchTomsg += (PTPMSG_ANUNC_GMCLKID_SZ);

	(VOID)mdtra_ntoh_us(puchTomsg, &pstPtpmsg->stAnnounce.usStepsRemoved);
	puchTomsg += (PTPMSG_ANUNC_STPSREMOVED_SZ);

	pstPtpmsg->stAnnounce.uchTimeSource = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_TIMESRC_SZ);

	blRet = ptp_Mdl_ntohMsgAnnounceTLV(puchTomsg, &pstPtpmsg->stAnnounce.stAnnounce_TLV, usMsgLen);
	return blRet;
}
#endif

BOOL ptp_Mdl_ntohMsgAnnounceTLV(UCHAR* puchMsgPtr, PTPMSG_ANNOUNCE_TLV* pstPtpmsg, USHORT usMsgLen)
{
	ULONG	ulAllSize;

	if (usMsgLen < PTPMSG_ANUNC_SZ+PTPMSG_ANNUNCETLV_TLVTYPE_SZ+PTPMSG_ANNUNCETLV_TLVLENGTH_SZ)
	{
		pstPtpmsg->usTLVType = PTPM_TLVTYP_ANNOUNCE;
		pstPtpmsg->usLengthField = 0;

		return TRUE;
	}
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsg->usTLVType);
	puchMsgPtr += (PTPMSG_ANNUNCETLV_TLVTYPE_SZ);

	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstPtpmsg->usLengthField);
	puchMsgPtr += (PTPMSG_ANNUNCETLV_TLVLENGTH_SZ);

	if (pstPtpmsg->usLengthField/sizeof(CLOCKIDENTITY) > PTP_MAX_PATHTRACE )
	{
		return FALSE;
	}

	ulAllSize = (ULONG)pstPtpmsg->usLengthField;
	ulAllSize = ulAllSize + (ULONG)(PTPMSG_ANNUNCETLV_TLVLENGTH_SZ+PTPMSG_ANNUNCETLV_TLVLENGTH_SZ+PTPMSG_ANUNC_SZ);

	if (usMsgLen < ulAllSize)
	{
		return FALSE;
	}

	tsn_Wrapper_MemCpy(pstPtpmsg->stPathSequence, puchMsgPtr,
		pstPtpmsg->usLengthField);
	return TRUE;
}

#ifdef	PTP_USE_IEEE1588
BOOL ptp_Mdl_ntohMsgSync(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stSync_1588.stOriginTimestamp);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_SYNC_1588(pstPtpmsg->stSync_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgFollowUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stFollowUp_1588.stPrcsOrgnTimestamp);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_FOLLOWUP_1588(pstPtpmsg->stFollowUp_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stDlyReq_1588.stOriginTimestamp);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_DELAY_REQ_1588(pstPtpmsg->stDlyReq_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stDlyResp_1588.stRcvTimestamp);
	puchTomsg += (PTPMSG_DELAYRESP_RCVTS_SZ);

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stDlyResp_1588.stReqPortIdentity);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_DELAY_RESP_1588(pstPtpmsg->stDlyResp_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgPDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stPdlyReq_1588.stOriginTimestamp);
	puchTomsg += (PTPMSG_PDELAYREQ_ORGTS_SZ);

	tsn_Wrapper_MemCpy(pstPtpmsg->stPdlyReq_1588.uchReserved, puchTomsg,
		(PTPMSG_PDELAYREQ_RESERVED_SZ));

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDELAY_REQ_1588(pstPtpmsg->stPdlyReq_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

BOOL ptp_Mdl_ntohMsgPDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stPdlyResp_1588.stReqRcptTimestamp);
	puchTomsg += (PTPMSG_PDELAYRESP_REQRCPTS_SZ);

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stPdlyResp_1588.stReqPortIdentity);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDELAY_RESP_1588(pstPtpmsg->stPdlyResp_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}
#endif

BOOL ptp_Mdl_ntohMsgPDlyRespFllwUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	USHORT			usMsgLen		 = 0;
	PTPMSG_HEADER*	pstPtpmsgHdr = (PTPMSG_HEADER*)pstPtpmsg;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stPDRespFlwUp_1588.stRespOrgnTimestamp);
	puchTomsg += (PTPMSG_PDLYRESPFL_RSPORGTS_SZ);

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stPDRespFlwUp_1588.stReqPortIdentity);

	GetPTPMSG_HEADER(*pstPtpmsgHdr, usMsgLen);
	GetPTPMSG_PDRESP_FOLLOWUP_1588(pstPtpmsg->stPDRespFlwUp_1588, usMsgLen);
	if (pstPtpmsgHdr->usMegLength != usMsgLen )
	{
		return FALSE;
	}
	return TRUE;
}

#ifdef	PTP_USE_MANAGEMENT
VOID ptp_Mdl_ntohMsgManagement(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	SHORT	sMsgLen = 0;

	mdtra_ntoh_PortID(puchTomsg, &pstPtpmsg->stManagement_1588.stTargetPortIdentity);
	sMsgLen = (SHORT)pstPtpmsgHdr->usMegLength;
	puchTomsg += (PTPMSG_MANAGEMENT_TGTPORTID_SZ);

	pstPtpmsg->stManagement_1588.uchStartBoundaryHops = (*puchTomsg);
	puchTomsg += (PTPMSG_MANAGEMENT_SBUNDRYHOPS_SZ);

	pstPtpmsg->stManagement_1588.uchBoundaryHops = (*puchTomsg);
	puchTomsg += (PTPMSG_MANAGEMENT_BUNDRYHOPS_SZ);

	pstPtpmsg->stManagement_1588.byActionField = (BYTE)*puchTomsg;

	puchTomsg += (PTPMSG_MANAGEMENT_ACTIONFLD_SZ);

	tsn_Wrapper_MemCpy(&pstPtpmsg->stManagement_1588.uchReserved, puchTomsg,
		(PTPMSG_MANAGEMENT_RESERVED_SZ));
	puchTomsg += (PTPMSG_MANAGEMENT_RESERVED_SZ);

	sMsgLen -= (SHORT)PTPMSG_MANAGEMENT_SZ;
	tsn_Wrapper_MemCpy(&pstPtpmsg->stManagement_1588.stManagemant_TLV.uchManagemant_TLV, puchTomsg, sMsgLen);
}
#endif

#ifdef	PTP_USE_IEEE1588
VOID ptp_Mdl_ntohMsgAnnounce(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	mdtra_ntoh_TS(puchTomsg, &pstPtpmsg->stAnnounce.stOriginTimestamp);
	puchTomsg += (PTPMSG_PDLYRESPFL_RSPORGTS_SZ);

	(VOID)mdtra_ntoh_us(puchTomsg, (USHORT*)&pstPtpmsg->stAnnounce.sCurrentUtcOffset);
	puchTomsg += (PTPMSG_ANUNC_CRNTUTCOFS_SZ);

	pstPtpmsg->stAnnounce.uchReserved = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_RESERVED_SZ);

	pstPtpmsg->stAnnounce.uchGrandmasterPriority1 = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY1_SZ);

	mdtra_ntoh_CLKQLTY(puchTomsg, &pstPtpmsg->stAnnounce.stGrandmasterClockQuality);
	puchTomsg += (PTPMSG_ANUNC_GMCLKQUALITY_SZ);

	pstPtpmsg->stAnnounce.uchGrandmasterPriority2 = (*puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY2_SZ);

	tsn_Wrapper_MemCpy(&pstPtpmsg->stAnnounce.stGrandmasterIdentity,
		puchTomsg, (PTPMSG_ANUNC_GMCLKID_SZ));
	puchTomsg += (PTPMSG_ANUNC_GMCLKID_SZ);

	(VOID)mdtra_ntoh_us(puchTomsg, &pstPtpmsg->stAnnounce.usStepsRemoved);
	puchTomsg += (PTPMSG_ANUNC_STPSREMOVED_SZ);

	pstPtpmsg->stAnnounce.uchTimeSource = (*puchTomsg);
}
#endif


VOID ptp_Mdl_htonMsgHeader(UCHAR* puchMsgPtr, PTPMSG_HEADER* pstPtpmsgHdr)
{
	*puchMsgPtr = (UCHAR)pstPtpmsgHdr->byMjSdoIdAndMsgTyp;

	puchMsgPtr += PTPMSG_HEAD_MJSDOIDANDMSGTYP_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsgHdr->byMiVerAndVerPTP;

	puchMsgPtr += PTPMSG_HEAD_MIVERANDVERPTP_SZ;

	(VOID)mdtra_hton_us(pstPtpmsgHdr->usMegLength, puchMsgPtr);
	puchMsgPtr += (PTPMSG_HEAD_MEGLENGTH_SZ);

	*puchMsgPtr = pstPtpmsgHdr->uchDomainNumber;
	puchMsgPtr += (PTPMSG_HEAD_DOMAINNUMBER_SZ);

	*puchMsgPtr = pstPtpmsgHdr->uchMinorSdoId;
	puchMsgPtr += (PTPMSG_HEAD_MINORSDOID_SZ);


	*puchMsgPtr = (UCHAR)pstPtpmsgHdr->byFlags0;

	puchMsgPtr += PTPMSG_HEAD_FLAGS0_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsgHdr->byFlags1;
	puchMsgPtr += PTPMSG_HEAD_FLAGS1_SZ;

	mdtra_hton_FracN64(&pstPtpmsgHdr->stCorrectionField, puchMsgPtr);
	puchMsgPtr += (PTPMSG_HEAD_CORRECTIONFIELD_SZ);

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsgHdr->uchMsgTypSpecific,
		(PTPMSG_HEAD_MSGTYPSPECIFIC_SZ));
	puchMsgPtr += (PTPMSG_HEAD_MSGTYPSPECIFIC_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsgHdr->stSrcPortIdentity, puchMsgPtr);
	puchMsgPtr += (PTPMSG_HEAD_SRCPORTIDENTITY_SZ);

	(VOID)mdtra_hton_us(pstPtpmsgHdr->usSequenceId, puchMsgPtr);
	puchMsgPtr += (PTPMSG_HEAD_SEQUENCEID_SZ);

	*puchMsgPtr = pstPtpmsgHdr->uchControl;
	puchMsgPtr += (PTPMSG_HEAD_CONTROL_SZ);

	*puchMsgPtr = (UCHAR)pstPtpmsgHdr->chLogMsgInterVal;
}


#ifdef	PTP_USE_IEEE802_1
VOID ptp_Mdl_htonMsgSyncAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);
	if ( MPTPMSG_H_GET_FLAGS0_TWOSTEP(pstPtpmsgHdr) )
	{
		tsn_Wrapper_MemCpy(puchTomsg, pstPtpmsg->stSyncTwo_1AS.uchReserved,
			(PTPMSG_AS_SYNC_TWOS_RESERVED_SZ));
	}
	else
	{
		mdtra_hton_TS(&pstPtpmsg->stSyncOne_1AS.stOriginTimestamp, puchTomsg);
		puchTomsg += (PTPMSG_AS_SYNC_ONES_ORIGINTS_SZ);

		ptp_Mdl_htonMsgFollowUpTLV(puchTomsg,
			(PTPMSG_FOLLOWUP_TLV*)&pstPtpmsg->stSyncOne_1AS.stFollowUP_TLV);
	}
}


VOID ptp_Mdl_htonMsgFollowUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stFollowUp_1AS.stPrcsOrgnTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_AS_FLLWUP_PRCSORGNTS_SZ);

	ptp_Mdl_htonMsgFollowUpTLV(puchTomsg,
		(PTPMSG_FOLLOWUP_TLV*)&pstPtpmsg->stFollowUp_1AS.stFollowUP_TLV);
}
#endif


VOID ptp_Mdl_htonMsgFollowUpTLV(UCHAR* puchMsgPtr, PTPMSG_FOLLOWUP_TLV* pstPtpmsg)
{
	USHORT		usDtFld = 0;

	(VOID)mdtra_hton_us(pstPtpmsg->usTLVType, puchMsgPtr);
	puchMsgPtr += (PTPMSG_FLWUPT_TLVTYPE_SZ);
	usDtFld += (PTPMSG_FLWUPT_TLVTYPE_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->usLengthField, puchMsgPtr);
	puchMsgPtr += (PTPMSG_FLWUPT_TLVLENGTH_SZ);
	usDtFld += (PTPMSG_FLWUPT_TLVLENGTH_SZ);

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsg->uchOrganizationID,
		PTPMSG_FLWUPT_ORGANIZATIONID_SZ);
	puchMsgPtr += PTPMSG_FLWUPT_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsg->uchOrganizationSubType,
		PTPMSG_FLWUPT_ORGSUBTYPE_SZ);
	puchMsgPtr += PTPMSG_FLWUPT_ORGSUBTYPE_SZ;

	mdtra_hton_ul((ULONG)pstPtpmsg->lCmltvScaledRateOffset, puchMsgPtr);
	puchMsgPtr += (PTPMSG_FLWUPT_CMSCLDRATEOFS_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->usGMTmBaseIndicator, puchMsgPtr);
	puchMsgPtr += (PTPMSG_FLWUPT_GMTMBASEINDCTR_SZ);

	mdtra_hton_SNs(&pstPtpmsg->stLstGMPhsChange, puchMsgPtr);
	puchMsgPtr += (PTPMSG_FLWUPT_LSTGMPHSCHG_SZ);

	mdtra_hton_ul((ULONG)pstPtpmsg->lScaledLstGMFrqChange, puchMsgPtr);
}


#ifdef	PTP_USE_IEEE802_1
VOID ptp_Mdl_htonMsgPDlyReqAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	tsn_Wrapper_MemCpy(puchTomsg, pstPtpmsg->stPdlyReq_1AS.uchReserved1,
		(PTPMSG_AS_PDELAYREQ_RESERVED1_SZ));
	puchTomsg += (PTPMSG_AS_PDELAYREQ_RESERVED1_SZ);

	tsn_Wrapper_MemCpy(puchTomsg, pstPtpmsg->stPdlyReq_1AS.uchReserved2,
		(PTPMSG_AS_PDELAYREQ_RESERVED2_SZ));
}


VOID ptp_Mdl_htonMsgPDlyRespAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stPdlyResp_1AS.stReqRcptTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_AS_PDELAYRESP_REQRCPTS_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stPdlyResp_1AS.stReqPortIdentity, puchTomsg);
}


VOID ptp_Mdl_htonMsgPDlyRespFllwUpAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stPDRespFlwUp_1AS.stRespOrgnTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_AS_PDLYRESPFL_RSPORGTS_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stPDRespFlwUp_1AS.stReqPortIdentity, puchTomsg);
}
#endif


VOID ptp_Mdl_htonMsgSignalAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stSignaling_1AS.stTargetPortIdentity, puchTomsg);
	puchTomsg += PTPMSG_AS_SGNL_TGTPORTID_SZ;

	switch( pstPtpmsg->stSignaling_1AS.stGptpCap_TLV.uchOrganizationSubType[2] )
	{
		case PTPMSG_TLV_ORGSUBTYPE_INTERVAL:
			ptp_Mdl_htonMsgIntvalTLV(puchTomsg,
				(PTPMSG_INTERVAL_TLV*)&pstPtpmsg->stSignaling_1AS.stIntervalReq_TLV);
			break;
		case  PTPMSG_TLV_ORGSUBTYPE_GPTPCAP:
			ptp_Mdl_htonMsgGptpCapTLV( puchTomsg,
									   &pstPtpmsg->stSignaling_1AS.stGptpCap_TLV );
			break;
		case  PTPMSG_TLV_ORGSUBTYPE_GPTPCAPINT:
			ptp_Mdl_htonMsgGptpCapIntTLV( puchTomsg,
										  &pstPtpmsg->stSignaling_1AS.stGptpCapInt_TLV );
			break;
		default:
			break;
	}
	
	return ;
}

VOID ptp_Mdl_htonMsgGptpCapTLV(UCHAR* puchMsgPtr, PTPMSG_GPTPCAPABLE_TLV* pstPtpmsg)
{
	USHORT	usDtFld = 0U;

	(VOID)mdtra_hton_us( pstPtpmsg->usTLVType, puchMsgPtr );
	puchMsgPtr += PTPMSG_GPTPCAP_TVLTYPE_SZ;
	usDtFld    += PTPMSG_GPTPCAP_TVLTYPE_SZ;

	(VOID)mdtra_hton_us( pstPtpmsg->usLengthField, puchMsgPtr );
	puchMsgPtr += PTPMSG_GPTPCAP_TLVLENGTH_SZ;
	usDtFld    += PTPMSG_GPTPCAP_TLVLENGTH_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						(VOID *)&pstPtpmsg->uchOrganizationID,
						PTPMSG_GPTPCAP_ORGANIZATIONID_SZ );
	puchMsgPtr += PTPMSG_GPTPCAP_ORGANIZATIONID_SZ;
	usDtFld    += PTPMSG_GPTPCAP_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						(VOID *)pstPtpmsg->uchOrganizationSubType,
						PTPMSG_GPTPCAP_ORGSUBTYPE_SZ );
	puchMsgPtr += PTPMSG_GPTPCAP_ORGSUBTYPE_SZ;
	usDtFld    += PTPMSG_GPTPCAP_ORGSUBTYPE_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsg->chlogGptpCapableMessageInterval;
	puchMsgPtr += PTPMSG_GPTPCAP_LOGGPTPCAPMSGINT_SZ;
	usDtFld    += PTPMSG_GPTPCAP_LOGGPTPCAPMSGINT_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsg->byFlags;
	puchMsgPtr += PTPMSG_GPTPCAP_FLAGS_SZ;
	usDtFld    += PTPMSG_GPTPCAP_FLAGS_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						(VOID *)&pstPtpmsg->uchReserved,
						PTPMSG_GPTPCAP_RESERVED_SZ );

	return ;
}

VOID ptp_Mdl_htonMsgGptpCapIntTLV(UCHAR* puchMsgPtr, PTPMSG_GPTPCAPABLE_INT_TLV* pstPtpmsg)
{
	USHORT	usDtFld = 0U;

	(VOID)mdtra_hton_us(pstPtpmsg->usTLVType, puchMsgPtr);
	puchMsgPtr += PTPMSG_GPTPCAPINT_TVLTYPE_SZ;
	usDtFld    += PTPMSG_GPTPCAPINT_TVLTYPE_SZ;

	(VOID)mdtra_hton_us(pstPtpmsg->usLengthField, puchMsgPtr);
	puchMsgPtr += PTPMSG_GPTPCAPINT_TLVLENGTH_SZ;
	usDtFld    += PTPMSG_GPTPCAPINT_TLVLENGTH_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						pstPtpmsg + usDtFld,
						PTPMSG_GPTPCAPINT_ORGANIZATIONID_SZ );
	puchMsgPtr += PTPMSG_GPTPCAPINT_ORGANIZATIONID_SZ;
	usDtFld    += PTPMSG_GPTPCAPINT_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						pstPtpmsg + usDtFld,
						PTPMSG_GPTPCAPINT_ORGSUBTYPE_SZ );
	puchMsgPtr += PTPMSG_GPTPCAPINT_ORGSUBTYPE_SZ;
	usDtFld    += PTPMSG_GPTPCAPINT_ORGSUBTYPE_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsg->chlogGptpCapableMessageInterval;
	puchMsgPtr += PTPMSG_GPTPCAPINT_LOGGPTPCAPMSGINT_SZ;
	usDtFld    += PTPMSG_GPTPCAPINT_LOGGPTPCAPMSGINT_SZ;

	tsn_Wrapper_MemCpy( (VOID *)puchMsgPtr, 
						(VOID *)&pstPtpmsg->uchReserved,
						PTPMSG_GPTPCAPINT_RESERVED_SZ );

	return ;
}

VOID ptp_Mdl_htonMsgIntvalTLV(UCHAR* puchMsgPtr, PTPMSG_INTERVAL_TLV* pstPtpmsg)
{
	USHORT	usDtFld = 0U;

	(VOID)mdtra_hton_us(pstPtpmsg->usTLVType, puchMsgPtr);
	puchMsgPtr += (PTPMSG_INTVL_TVLTYPE_SZ);
	usDtFld += (PTPMSG_INTVL_TVLTYPE_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->usLengthField, puchMsgPtr);
	puchMsgPtr += (PTPMSG_INTVL_TLVLENGTH_SZ);
	usDtFld += (PTPMSG_INTVL_TLVLENGTH_SZ);

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsg + usDtFld,
		PTPMSG_INTVL_ORGANIZATIONID_SZ);
	puchMsgPtr += PTPMSG_INTVL_ORGANIZATIONID_SZ;
	usDtFld += PTPMSG_INTVL_ORGANIZATIONID_SZ;

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsg + usDtFld,
		PTPMSG_INTVL_ORGSUBTYPE_SZ);
	puchMsgPtr += PTPMSG_INTVL_ORGSUBTYPE_SZ;

	*puchMsgPtr = (UCHAR)pstPtpmsg->chLinkDelayInterval;
	puchMsgPtr += (PTPMSG_INTVL_LKDLYINTVAL_SZ);

	*puchMsgPtr = (UCHAR)pstPtpmsg->chTimeSyncInterval;
	puchMsgPtr += (PTPMSG_INTVL_TMSYNINTVAL_SZ);

	*puchMsgPtr = (UCHAR)pstPtpmsg->chAnnounceInterval;
	puchMsgPtr += (PTPMSG_INTVL_ANUNCINTVAL_SZ);

	*puchMsgPtr = (UCHAR)pstPtpmsg->byFlags;


	puchMsgPtr += (PTPMSG_INTVL_FLAGS_SZ);

	tsn_Wrapper_MemCpy(puchMsgPtr, &pstPtpmsg->uchReserved,
		(PTPMSG_INTVL_RESERVED_SZ));
}


#ifdef	PTP_USE_IEEE802_1
VOID ptp_Mdl_htonMsgAnnounceAS(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stAnnounce.stOriginTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_RESERVEDAS_SZ);

	(VOID)mdtra_hton_us((USHORT)pstPtpmsg->stAnnounce.sCurrentUtcOffset, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_CRNTUTCOFS_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchReserved;
	puchTomsg += (PTPMSG_ANUNC_RESERVED_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchGrandmasterPriority1;
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY1_SZ);

	mdtra_hton_CLKQLTY(&pstPtpmsg->stAnnounce.stGrandmasterClockQuality, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMCLKQUALITY_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchGrandmasterPriority2;
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY2_SZ);

	tsn_Wrapper_MemCpy(puchTomsg, &pstPtpmsg->stAnnounce.stGrandmasterIdentity,
		(PTPMSG_ANUNC_GMCLKID_SZ));
	puchTomsg += (PTPMSG_ANUNC_GMCLKID_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->stAnnounce.usStepsRemoved, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_STPSREMOVED_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchTimeSource;
	puchTomsg += (PTPMSG_ANUNC_TIMESRC_SZ);

	ptp_Mdl_htonMsgAnnounceTLV(puchTomsg, &pstPtpmsg->stAnnounce.stAnnounce_TLV);
}
#endif

VOID ptp_Mdl_htonMsgAnnounceTLV(UCHAR* puchMsgPtr, PTPMSG_ANNOUNCE_TLV* pstPtpmsg)
{
#if 1
	if ((pstPtpmsg->usTLVType != PTPM_TLVTYP_ANNOUNCE) ||
		(pstPtpmsg->usLengthField == 0U) ||
		(pstPtpmsg->usLengthField > (PTP_MAX_PATHTRACE * sizeof(CLOCKIDENTITY))))
	{
		return;
	}
#endif
	(VOID)mdtra_hton_us(pstPtpmsg->usTLVType, puchMsgPtr);
	puchMsgPtr += (PTPMSG_ANNUNCETLV_TLVTYPE_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->usLengthField, puchMsgPtr);
	puchMsgPtr += (PTPMSG_ANNUNCETLV_TLVLENGTH_SZ);

	tsn_Wrapper_MemCpy(puchMsgPtr, pstPtpmsg->stPathSequence,
		pstPtpmsg->usLengthField);
}

#ifdef	PTP_USE_IEEE1588
VOID ptp_Mdl_htonMsgSync(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stSync_1588.stOriginTimestamp, puchTomsg);
}

VOID ptp_Mdl_htonMsgFollowUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stFollowUp_1588.stPrcsOrgnTimestamp, puchTomsg);
}

VOID ptp_Mdl_htonMsgDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stDlyReq_1588.stOriginTimestamp, puchTomsg);
}

VOID ptp_Mdl_htonMsgDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stDlyResp_1588.stRcvTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_DELAYRESP_RCVTS_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stDlyResp_1588.stReqPortIdentity, puchTomsg);
}

VOID ptp_Mdl_htonMsgPDlyReq(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stPdlyReq_1588.stOriginTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_PDELAYREQ_ORGTS_SZ);

	tsn_Wrapper_MemCpy(puchTomsg, pstPtpmsg->stPdlyReq_1588.uchReserved,
		(PTPMSG_PDELAYREQ_RESERVED_SZ));
}

VOID ptp_Mdl_htonMsgPDlyResp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stPdlyResp_1588.stReqRcptTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_PDELAYRESP_REQRCPTS_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stPdlyResp_1588.stReqPortIdentity, puchTomsg);
}

VOID ptp_Mdl_htonMsgPDlyRespFllwUp(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stPDRespFlwUp_1588.stRespOrgnTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_PDLYRESPFL_RSPORGTS_SZ);

	(VOID)mdtra_hton_PortID(&pstPtpmsg->stPDRespFlwUp_1588.stReqPortIdentity, puchTomsg);
}

#ifdef	PTP_USE_MANAGEMENT
VOID ptp_Mdl_htonMsgManagement(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;
	USHORT	usTLVLen = 0U;
	SHORT	sMsgLen = 0;

	USHORT	usAllSize = 0U;
	PTPMSG_MANAGEMENT_TLV*	pstInTLV;

	pstInTLV = (PTPMSG_MANAGEMENT_TLV*)&pstPtpmsg->stManagement_1588.stManagemant_TLV;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);
	sMsgLen = (SHORT)pstPtpmsgHdr->usMegLength;
	(VOID)mdtra_hton_PortID(&pstPtpmsg->stManagement_1588.stTargetPortIdentity, puchTomsg);
	puchTomsg += (PTPMSG_MANAGEMENT_TGTPORTID_SZ);

	*puchTomsg = pstPtpmsg->stManagement_1588.uchStartBoundaryHops;
	puchTomsg += (PTPMSG_MANAGEMENT_SBUNDRYHOPS_SZ);

	*puchTomsg = pstPtpmsg->stManagement_1588.uchBoundaryHops;
	puchTomsg += (PTPMSG_MANAGEMENT_BUNDRYHOPS_SZ);

	*puchTomsg = (UCHAR)pstPtpmsg->stManagement_1588.byActionField;

	puchTomsg += PTPMSG_MANAGEMENT_ACTIONFLD_SZ;

	tsn_Wrapper_MemCpy(puchTomsg, &pstPtpmsg->stManagement_1588.uchReserved,
		(PTPMSG_MANAGEMENT_RESERVED_SZ));
	puchTomsg += (PTPMSG_MANAGEMENT_RESERVED_SZ);

	sMsgLen -= (sizeof(PTPMSG_MANAGEMENT_1588) - sizeof(PTPMSG_MGTTLV_1588));

	while ( sMsgLen > 0)
	{
		usTLVLen = ptp_Mdl_htonMsgManagTLV(puchTomsg,
			(PTPMSG_MANAGEMENT_TLV*)pstInTLV);

		usAllSize += usTLVLen;
		puchTomsg += usTLVLen;
		usTLVLen = pstInTLV->usLengthField + PTPMSG_MGTTLV_TLVTYPE_SZ + PTPMSG_MGTTLV_TLVLENGTH_SZ;
		sMsgLen = (SHORT)(sMsgLen - usTLVLen);
		pstInTLV = (PTPMSG_MANAGEMENT_TLV*)(((UCHAR *)pstInTLV) + usTLVLen);
	}
	usAllSize += PTPMSG_MANAGEMENT_SZ;
	(VOID)mdtra_hton_us(usAllSize, (puchMsgPtr + PTPMSG_HEAD_MJSDOIDANDMSGTYP_SZ + PTPMSG_HEAD_MIVERANDVERPTP_SZ));
}
#endif

VOID ptp_Mdl_htonMsgAnnounce(UCHAR* puchMsgPtr, PTPMSG* pstPtpmsg)
{
	PTPMSG_HEADER*	pstPtpmsgHdr = &pstPtpmsg->stHeader;
	UCHAR*	puchTomsg =  puchMsgPtr + PTPMSG_HEAD_SZ;

	ptp_Mdl_htonMsgHeader(puchMsgPtr, pstPtpmsgHdr);

	mdtra_hton_TS(&pstPtpmsg->stAnnounce.stOriginTimestamp, puchTomsg);
	puchTomsg += (PTPMSG_PDLYRESPFL_RSPORGTS_SZ);

	(VOID)mdtra_hton_us((USHORT)pstPtpmsg->stAnnounce.sCurrentUtcOffset, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_CRNTUTCOFS_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchReserved;
	puchTomsg += (PTPMSG_ANUNC_RESERVED_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchGrandmasterPriority1;
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY1_SZ);

	mdtra_hton_CLKQLTY(&pstPtpmsg->stAnnounce.stGrandmasterClockQuality, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_GMCLKQUALITY_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchGrandmasterPriority2;
	puchTomsg += (PTPMSG_ANUNC_GMPRIORITY2_SZ);

	tsn_Wrapper_MemCpy(puchTomsg, &pstPtpmsg->stAnnounce.stGrandmasterIdentity,
		(PTPMSG_ANUNC_GMCLKID_SZ));
	puchTomsg += (PTPMSG_ANUNC_GMCLKID_SZ);

	(VOID)mdtra_hton_us(pstPtpmsg->stAnnounce.usStepsRemoved, puchTomsg);
	puchTomsg += (PTPMSG_ANUNC_STPSREMOVED_SZ);

	*puchTomsg = pstPtpmsg->stAnnounce.uchTimeSource;
	puchTomsg += (PTPMSG_ANUNC_TIMESRC_SZ);
#if 1
	ptp_Mdl_htonMsgAnnounceTLV(puchTomsg, &pstPtpmsg->stAnnounce.stAnnounce_TLV);
#endif
}
#endif




USHORT mdtra_ntoh_us(UCHAR* puchMsgPtr, USHORT* pusVal)
{
	union to_usval val;
#ifdef PTP_BIG_ENDIAN
	val.uchVal[0] = puchMsgPtr[0];
	val.uchVal[1] = puchMsgPtr[1];
#else
	val.uchVal[1] = puchMsgPtr[0];
	val.uchVal[0] = puchMsgPtr[1];
#endif
	*pusVal = val.usVal;
	return (sizeof(USHORT));
}
USHORT mdtra_ntoh_ul(UCHAR* puchMsgPtr, ULONG* pulVal)
{
	union to_ulval val;
#ifdef PTP_BIG_ENDIAN
	val.uchVal[0] = puchMsgPtr[0];
	val.uchVal[1] = puchMsgPtr[1];
	val.uchVal[2] = puchMsgPtr[2];
	val.uchVal[3] = puchMsgPtr[3];
#else
	val.uchVal[3] = puchMsgPtr[0];
	val.uchVal[2] = puchMsgPtr[1];
	val.uchVal[1] = puchMsgPtr[2];
	val.uchVal[0] = puchMsgPtr[3];
#endif
	*pulVal = val.ulVal;
	return (sizeof(ULONG));
}
USHORT mdtra_ntoh_FracN64(UCHAR* puchMsgPtr, FRAC_NSEC64* pstVal)
{
	(VOID)mdtra_ntoh_us(puchMsgPtr, (USHORT*)&pstVal->sNsec_msb);
	puchMsgPtr += sizeof(USHORT);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->ulNsec_lsb);
	puchMsgPtr += sizeof(ULONG);
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->usFrcNsec);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_ntoh_TInt(UCHAR* puchMsgPtr, TIME_INTERVAL* pstVal)
{
	(VOID)mdtra_ntoh_us(puchMsgPtr, (USHORT*)&pstVal->sNsec_msb);
	puchMsgPtr += sizeof(USHORT);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->ulNsec_lsb);
	puchMsgPtr += sizeof(ULONG);
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->usFrcNsec);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_ntoh_TS(UCHAR* puchMsgPtr, TIMESTAMP* pstVal)
{
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->stSeconds.usSec_msb);
	puchMsgPtr += sizeof(USHORT);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->stSeconds.ulSec_lsb);
	puchMsgPtr += sizeof(ULONG);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->ulNanoseconds);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(ULONG));
}
USHORT mdtra_ntoh_SNs(UCHAR* puchMsgPtr, SCALEDNS* pstVal)
{
	(VOID)mdtra_ntoh_us(puchMsgPtr, (USHORT*)&pstVal->sNsec_msb);
	puchMsgPtr += sizeof(USHORT);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->ulNsec_2nd);
	puchMsgPtr += sizeof(ULONG);
	mdtra_ntoh_ul(puchMsgPtr, &pstVal->ulNsec_lsb);
	puchMsgPtr += sizeof(ULONG);
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->usFrcNsec);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_ntoh_PortID(UCHAR* puchMsgPtr, PORTIDENTITY* pstVal)
{
	tsn_Wrapper_MemCpy(&pstVal->stClockIdentity, puchMsgPtr,
		sizeof(pstVal->stClockIdentity));
	puchMsgPtr += sizeof(pstVal->stClockIdentity);
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->usPortNumber);

	return (sizeof(pstVal->stClockIdentity) + sizeof(USHORT));
}
USHORT mdtra_ntoh_CLKQLTY(UCHAR* puchMsgPtr, CLOCKQUALITY* pstVal)
{
	pstVal->uchClockClass = (*puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->uchClockClass);
	pstVal->uchClockAccuracy = (*puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->uchClockAccuracy);
	(VOID)mdtra_ntoh_us(puchMsgPtr, &pstVal->usOffsetScaledLogVariance);
	return (sizeof(UCHAR) + sizeof(UCHAR) + sizeof(USHORT));
}


USHORT mdtra_hton_us(USHORT usVal, UCHAR* puchMsgPtr)
{
	union to_usval val;
	val.usVal = usVal;
#ifdef PTP_BIG_ENDIAN
	puchMsgPtr[0] = val.uchVal[0];
	puchMsgPtr[1] = val.uchVal[1];
#else
	puchMsgPtr[0] = val.uchVal[1];
	puchMsgPtr[1] = val.uchVal[0];
#endif
	return (sizeof(USHORT));
}
USHORT mdtra_hton_ul(ULONG ulVal, UCHAR* puchMsgPtr)
{
	union to_ulval val;
	val.ulVal = ulVal;
#ifdef PTP_BIG_ENDIAN
	puchMsgPtr[0] = val.uchVal[0];
	puchMsgPtr[1] = val.uchVal[1];
	puchMsgPtr[2] = val.uchVal[2];
	puchMsgPtr[3] = val.uchVal[3];
#else
	puchMsgPtr[0] = val.uchVal[3];
	puchMsgPtr[1] = val.uchVal[2];
	puchMsgPtr[2] = val.uchVal[1];
	puchMsgPtr[3] = val.uchVal[0];
#endif
	return (sizeof(ULONG));
}
USHORT mdtra_hton_FracN64(FRAC_NSEC64* pstVal, UCHAR* puchMsgPtr)
{
	(VOID)mdtra_hton_us((USHORT)pstVal->sNsec_msb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->sNsec_msb);
	mdtra_hton_ul(pstVal->ulNsec_lsb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->ulNsec_lsb);
	(VOID)mdtra_hton_us(pstVal->usFrcNsec, puchMsgPtr);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_hton_TInt(TIME_INTERVAL* pstVal, UCHAR* puchMsgPtr)
{
	(VOID)mdtra_hton_us((USHORT)pstVal->sNsec_msb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->sNsec_msb);
	mdtra_hton_ul(pstVal->ulNsec_lsb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->ulNsec_lsb);
	(VOID)mdtra_hton_us(pstVal->usFrcNsec, puchMsgPtr);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_hton_TS(TIMESTAMP* pstVal, UCHAR* puchMsgPtr)
{
	(VOID)mdtra_hton_us(pstVal->stSeconds.usSec_msb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->stSeconds.usSec_msb);
	mdtra_hton_ul(pstVal->stSeconds.ulSec_lsb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->stSeconds.ulSec_lsb);
	mdtra_hton_ul(pstVal->ulNanoseconds, puchMsgPtr);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(ULONG));
}
USHORT mdtra_hton_SNs(SCALEDNS* pstVal, UCHAR* puchMsgPtr)
{
	(VOID)mdtra_hton_us((USHORT)pstVal->sNsec_msb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->sNsec_msb);
	mdtra_hton_ul(pstVal->ulNsec_2nd, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->ulNsec_2nd);
	mdtra_hton_ul(pstVal->ulNsec_lsb, puchMsgPtr);
	puchMsgPtr += sizeof(pstVal->ulNsec_lsb);
	(VOID)mdtra_hton_us(pstVal->usFrcNsec, puchMsgPtr);
	return (sizeof(USHORT) + sizeof(ULONG) + sizeof(ULONG) + sizeof(USHORT));
}
USHORT mdtra_hton_PortID(PORTIDENTITY* pstVal, UCHAR* puchMsgPtr)
{
	tsn_Wrapper_MemCpy(puchMsgPtr, &pstVal->stClockIdentity,
		sizeof(pstVal->stClockIdentity));
	puchMsgPtr += sizeof(pstVal->stClockIdentity);
	(VOID)mdtra_hton_us(pstVal->usPortNumber, puchMsgPtr);
	return (sizeof(pstVal->stClockIdentity) + sizeof(USHORT));
}
USHORT mdtra_hton_CLKQLTY(CLOCKQUALITY* pstVal, UCHAR* puchMsgPtr)
{
	*puchMsgPtr = pstVal->uchClockClass;
	puchMsgPtr += sizeof(pstVal->uchClockClass);
	*puchMsgPtr = pstVal->uchClockAccuracy;
	puchMsgPtr += sizeof(pstVal->uchClockAccuracy);
	(VOID)mdtra_hton_us(pstVal->usOffsetScaledLogVariance, puchMsgPtr);
	return (sizeof(UCHAR) + sizeof(UCHAR) + sizeof(USHORT));
}
