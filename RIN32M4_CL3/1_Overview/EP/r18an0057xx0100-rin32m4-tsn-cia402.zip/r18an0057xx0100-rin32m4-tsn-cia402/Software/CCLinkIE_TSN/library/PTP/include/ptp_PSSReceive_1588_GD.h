/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_PSSRECEIVE_1588_GD_H__
#define __PTP_PSSRECEIVE_1588_GD_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"





typedef	enum	tagEN_ST_PSSR_1588 {
	ST_PSSR_1588_NONE	= 0,
	ST_PSSR_1588_DISCARD,
	ST_PSSR_1588_RECEIVED_SYNC,
	ST_PSSR_1588_MAX,
} EN_ST_PSSR_1588;

typedef	enum	tagEN_EV_PSSR_1588 {
	EV_PSSR_1588_BEGIN = 0,
	EV_PSSR_1588_FOR_PSSR_RCVMDSYNC,
	EV_PSSR_1588_CLOSE,
	EV_PSSR_1588_EVENT_MAX
} EN_EV_PSSR_1588;

typedef	struct tagPSSRECEIVESM_1588_GD
{
	EN_ST_PSSR_1588	enStatusPSSR_1588;
	BOOL			blRcvdMDSync;
	MDSYNCRECEIVE*	pstRcvdMDSyncPtr;
	PORTSYNCSYNC*	pstTxPSSyncPtr;
	PORTSYNCSYNC*	pstTxPSSyncBCSS;
} PSSRECEIVESM_1588_GD;	



#endif


