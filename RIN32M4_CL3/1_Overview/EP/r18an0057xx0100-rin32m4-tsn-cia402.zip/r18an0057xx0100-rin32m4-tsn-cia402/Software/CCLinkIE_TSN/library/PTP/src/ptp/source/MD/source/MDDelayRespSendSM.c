/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#include "MDDelayRespSendSM.h"
#ifdef	PTP_USE_IEEE1588
#include "MDDelayRespSendSM_1588.h"
#endif

VOID MDDelayRespSendSM(USHORT usEvent, PORTDATA* pstPort)
{
	if (pstPort == NULL)
	{
		return;
	}

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM, PTP_LOGVE_82080001);

#ifdef	PTP_USE_IEEE1588
	if (IsMDCOMSupportPTPTyp1588(pstPort))
	{
		MDDelayRespSendSM_1588(usEvent, pstPort);
		return;
	}
#endif
	PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM, PTP_LOGVE_82000002);
	return;
}

MDDRESPSDSM_GD* GetMDDRespSndSMGlobal(PORTDATA* pstPort)
{
	return &pstPort->stMDDRespSndSM_GD;
}

MDDRESPSNDSM_EV GetMDDRespSndEvent(USHORT usEvent, PORTDATA* pstPort)
{
	MDDRESPSNDSM_EV	enEvt;
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = MDDRPS_E_BEGIN;
		break;
		case PTP_EV_FOR_MDDLRSSND_RCVDDLRS:
			enEvt = MDDRPS_E_RCVD_MDDELAY_RESP;
		break;
		case PTP_EV_CLOSE:
			enEvt = MDDRPS_E_CLOSE;
		break;

		default:
			enEvt = MDDRPS_E_EVENT_MAX;
			PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM, PTP_LOGVE_82000003);
		break;
	}

	return(enEvt);
}

MDDRESPSNDSM_ST GetMDDRespSndStatus(PORTDATA* pstPort)
{
	MDDRESPSDSM_GD*	pstGbl = NULL;
	MDDRESPSNDSM_ST	enSts = MDDRPS_STATUS_MAX;

	pstGbl = GetMDDRespSndSMGlobal(pstPort);
	if (pstGbl->enStsMDDRespSnd < MDDRPS_STATUS_MAX)
	{
		enSts = pstGbl->enStsMDDRespSnd;
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDDRESPSENDSM, PTP_LOGVE_82000004);
	}
	return enSts;
}

VOID SetMDDRespSndStatus(MDDRESPSNDSM_ST enSts, PORTDATA* pstPort)
{
	MDDRESPSDSM_GD*	pstGbl = NULL;

	pstGbl = GetMDDRespSndSMGlobal(pstPort);

	pstGbl->enStsMDDRespSnd = enSts;
	return;
}
