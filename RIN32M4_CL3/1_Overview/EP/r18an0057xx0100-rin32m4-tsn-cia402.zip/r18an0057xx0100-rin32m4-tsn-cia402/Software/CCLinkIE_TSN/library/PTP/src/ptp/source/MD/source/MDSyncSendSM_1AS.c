/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "MDCommonSM.h"

#ifdef	PTP_USE_IEEE802_1

#include "PTP_GlobalData.h"

#include "MDSyncSendSM.h"
#include "MDSyncSendSM_1AS.h"

#include "ptp_tsn_Wrapper.h"
#include "ptp_LCEntity.h"


#include "ptp_SSSync_1AS.h"
#define	D_FUNC		0
#define	D_SYNCTO	0

#ifdef	OFFSET_DEBUG
extern	BOOL	blPtpOffsetUnder50Flag;

#define	MAX_CORRECTIONTLOG	64

typedef	struct	tagCORRECTIONLOG	{
	USHORT		ulType;
	USHORT		usPortNo;
	USCALEDNS	stSyncEventIngressTimestamp_Frun;
	TIMESTAMP	stSyncEventIngressTimestamp;
	USCALEDNS	stNeighborPropDelay;
	DOUBLE		dbNeighborRateRatio;
	USCALEDNS	stNeighborPropDelay2;
	USCALEDNS	stUpstreamTxTime;
	USCALEDNS	stSyncEgTimestamp_Frun;
	TIMESTAMP	stSyncEgTimestamp;
	USCALEDNS	stUpstreamTxTime2;
	SCALEDNS	ststayTime;
	DOUBLE		dbRateRatio;
	FRAC_NSEC64	stCorrectionField;
	TIMESTAMP	stSyncEventIngressTimestamp_Frun_TS;
	USHORT		usSequenceId;
	USHORT		usPortNumber;
	USHORT		usCorrectiontLogCount;
}	CORRECTIONLOG;

extern	CORRECTIONLOG	stCorrectiontLog[];

extern	USHORT	usCorrectiontLogCount;
#endif

VOID (*const MDSyncSendSM_1AS_Matrix[DMDSYCS_STATUS_MAX][DMDSYCS_E_EVENT_MAX])(PORTDATA* pstPort) =
{
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_NP_1AS ,&MDSyncSendSM_NP_1AS, &MDSyncSendSM_NP_1AS},
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_02_1AS ,&MDSyncSendSM_NP_1AS, &MDSyncSendSM_00_1AS},
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_02_1AS ,&MDSyncSendSM_03_1AS, &MDSyncSendSM_00_1AS},
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_02_1AS ,&MDSyncSendSM_NP_1AS, &MDSyncSendSM_00_1AS},
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_02_1AS ,&MDSyncSendSM_04_1AS, &MDSyncSendSM_00_1AS},
	{&MDSyncSendSM_01_1AS ,&MDSyncSendSM_02_1AS ,&MDSyncSendSM_NP_1AS, &MDSyncSendSM_00_1AS}
};

VOID MDSyncSendSM_1AS(USHORT usEvent, PORTDATA* pstPort)
{
	MDSYNCSNDSM_EV	enEvt = MDSYCS_E_EVENT_MAX;
	MDSYNCSNDSM_ST	enSts = MDSYCS_STATUS_MAX;

	PTP_DEBUG_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82080001);

	enEvt = GetMDSyncSndEvent(usEvent, pstPort);
	enSts = GetMDSyncSndStatus(pstPort);

#ifdef DEBUG_LOG_MD
	printf ("<START> [%02d]MDSyncSendSM_1AS         ====  :Status=%02d / Event=0x%02x \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts, enEvt);
#endif
	if ((enSts != MDSYCS_STATUS_MAX) && (enEvt != MDSYCS_E_EVENT_MAX))
	{
		(*MDSyncSendSM_1AS_Matrix[enSts][enEvt])(pstPort);
	}
	else
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82000006);
	}
#ifdef DEBUG_LOG_MD
	enSts = GetMDSyncSndStatus(pstPort);
	printf ("<END  > [%02d]MDSyncSendSM_1AS         ====  :Status=%02d \n"
		,pstPort->stPortDS.stPortIdentity.usPortNumber, enSts);
#endif
	return;
}

VOID MDSyncSendSM_00_1AS(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "MDSyncSendSM_00_1AS",
					 pstPort->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPort->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	MDSynSnd_Initial_1AS(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_NONE, pstPort);

	ptp_dbg_msg( D_FUNC, ("MDSyncSendSM_00_1AS::-\n") );

	return;
}

VOID MDSyncSendSM_01_1AS(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	MDSynSnd_Initial_1AS(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
	return;
}

VOID MDSyncSendSM_02_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS = &pstPort->stPort_1AS_DS;
	MDSSENDSM_GD*	pstGbl = NULL;
	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	if (pstGbl->blRcvdMDSync == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82003101);
		MDSynSnd_Initial_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	if (pstPortDS->blOneStepTxOper)
	{
		MDSynSnd_SyncOneStep_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_ONE_STEP, pstPort);
	}
	else
	{
		MDSynSnd_SyncTwoStep_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_SEND_SYNC_TWO_STEP, pstPort);
	}
	return;
}

VOID MDSyncSendSM_03_1AS(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;
	INT  nIndex;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	if ( gstSyncTmoManage[nIndex].pstSyncSendPort == pstPort )
	{
		ptp_dbg_msg( D_SYNCTO, 
		             ("domain(%d)::del sync timeout timer. port=[%d]\n", 
		              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
		              pstPort->stPort_GD.usThisPort) );

		tsn_Wrapper_MemSet( (VOID *)&gstSyncTmoManage[nIndex], 0, sizeof(SYNCTMOMAN) );
	}


	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_8200210C);
		MDSynSnd_Initial_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	if (SetMDSyncMgEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	MDSynSnd_FollowUp_1AS(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SEND_FOLLOW_UP, pstPort);
	return;
}

VOID MDSyncSendSM_04_1AS(PORTDATA* pstPort)
{
	MDSSENDSM_GD*	pstGbl = NULL;
	INT  nIndex;

	pstGbl = GetMDSyncSndSMGlobal(pstPort);

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	if ( gstSyncTmoManage[nIndex].pstSyncSendPort == pstPort )
	{
		ptp_dbg_msg( D_SYNCTO, 
		             ("domain(%d)::del sync timeout timer. port=[%d]\n", 
		              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
		              pstPort->stPort_GD.usThisPort) );

		tsn_Wrapper_MemSet( (VOID *)&gstSyncTmoManage[nIndex], 0, sizeof(SYNCTMOMAN) );
	}

	if (pstGbl->blEgMDTimestampReceive == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_8200210C);
		MDSynSnd_Initial_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	if (SetMDSyncMgEgresTimestamp(pstGbl, pstPort) == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_8200210B);
		MDSynSnd_Initial_1AS(pstGbl, pstPort);
		SetMDSyncSndStatus(MDSYCS_INITIALIZING, pstPort);
		return;
	}
	MDSynSnd_StCrectionField_1AS(pstGbl, pstPort);
	SetMDSyncSndStatus(MDSYCS_SET_CORRECTION_FIELD, pstPort);
	return;
}

VOID MDSyncSendSM_NP_1AS(PORTDATA* pstPort)
{
	PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82000007);
	return;
}

BOOL MDSynSnd_Initial_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDSync = FALSE;
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	pstPortMD->usSyncSequenceId = (USHORT)tsn_Wrapper_Rand();
#ifndef PTP_USE_SIGNALING
	syncIntSet_1AS(pstPort);
	oneStepTxOpSet_1AS(pstPort);
#endif

	return TRUE;
}

BOOL MDSynSnd_SyncTwoStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	USCALEDNS	stCurrentTime={0};
	USCALEDNS	stInterval={0};
	USCALEDNS	stUSNs={0};
	INT  nIndex;
	BOOL blRet;

	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncTwoStep_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	
	tsn_Wrapper_MemCpy( (VOID *)&stInterval,
	                    (VOID *)&pstPort->pstClockData->stClock_GD.stSyncTransTimeout,
	                    sizeof(USCALEDNS) );
	
	ptp_dbg_msg( D_SYNCTO, 
	             ("domain(%d)::add sync timeout timer. port=[%d]\n", 
	              pstPort->pstClockData->stDefaultDS.uchDomainNumber,
	              pstPort->stPort_GD.usThisPort) );

	nIndex = (INT)pstPort->stPort_GD.usThisPort - 1;
	gstSyncTmoManage[nIndex].pstSyncSendPort = pstPort;
	
	ptp_GetCurrentTime( pstPort->pstClockData, &stCurrentTime );

	blRet = ptpAddUSNs_USNs( &stCurrentTime, 
							 &stInterval, 
							 &gstSyncTmoManage[nIndex].stSyncTransTimeoutTime );
	if ( !blRet )
	{
		PTP_ERROR_LOGRECORD( pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, (ULONG)PTP_LOGVE_OVERFLOW );
	}


	pstPortMD->usSyncSequenceId++;

	IncMDSyncSndTxSyncCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_FollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	if (SetFollowUp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxFollowUp_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	IncMDSyncSndTxFollowUpCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_SyncOneStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	PORTMD_GD*	pstPortMD	= &pstPort->stPortMD_GD;

	pstSmGbl->blRcvdMDSync = FALSE;

	if (SetSyncOneStep_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}
	if (TxSync_1AS(pstSmGbl, pstPort) == FALSE)
	{
		return FALSE;
	}

	pstPortMD->usSyncSequenceId++;

	IncMDSyncSndTxSyncCount(pstPort);
	IncMDSyncSndTxOneStepSyncCount(pstPort);
	return TRUE;
}

BOOL MDSynSnd_StCrectionField_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	pstSmGbl->blEgMDTimestampReceive = FALSE;

	return TRUE;
}

BOOL	SetSyncTwoStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCSEND*			pstSyncSnd		= &pstPort->stPort_GD.stMdSyncSend;
	PORTMD_GD*			pstPortMD		= &pstPort->stPortMD_GD;

	PTPMSG_SYNC_TWO_STEP_1AS*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSyncTwoAS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));

	MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_SYNC) ;
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	pstMsg->stHeader.uchDomainNumber	= pstSyncSnd->uchClockNumber;
	pstMsg->stHeader.usMegLength		= 0;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;

    MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, TRUE );


	tsn_Wrapper_MemSet(&pstMsg->stHeader.stCorrectionField, 0,
		sizeof(pstMsg->stHeader.stCorrectionField));
	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_SYNC,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstSyncSnd->stSourcePortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstPortMD->usSyncSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_SYNC;
	pstMsg->stHeader.chLogMsgInterVal	= pstSyncSnd->chLogMessageInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemSet(&pstMsg->uchReserved, 0, sizeof(pstMsg->uchReserved));
	GetPTPMSG_SYNC_TWO_STEP_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL	SetSyncOneStep_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCSEND*			pstSyncSnd		= &pstPort->stPort_GD.stMdSyncSend;
	PORTMD_GD*			pstPortMD		= &pstPort->stPortMD_GD;

	PTPMSG_SYNC_ONE_STEP_1AS*	pstMsg = NULL;
	pstMsg = &pstSmGbl->stTxSyncOneAS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));

	MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_SYNC );
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	pstMsg->stHeader.uchDomainNumber	= pstSyncSnd->uchClockNumber;
	pstMsg->stHeader.usMegLength		= 0;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;
	MPTPMSG_H_SET_FLAGS0_TWOSTEP( &pstMsg->stHeader, FALSE );

	ptpConvSNs_TInt(&pstSyncSnd->stFollowUpCorrectionField, &pstMsg->stHeader.stCorrectionField);

	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_SYNC,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstSyncSnd->stSourcePortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstPortMD->usSyncSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_SYNC;
	pstMsg->stHeader.chLogMsgInterVal	= pstSyncSnd->chLogMessageInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stOriginTimestamp, &pstSyncSnd->stPreciseOriginTimestamp,
		sizeof(pstMsg->stOriginTimestamp));
	GetPTPMSG_SYNC_ONE_STEP_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	pstMsg->stFollowUP_TLV.usTLVType = PTPM_TLVTYP_ORGANIZATION_EXTEN;
	GetPTPMSG_FOLLOWUP_TLV(pstMsg->stFollowUP_TLV, pstMsg->stFollowUP_TLV.usLengthField);
	pstMsg->stFollowUP_TLV.usLengthField = pstMsg->stFollowUP_TLV.usLengthField
						- PTPMSG_FLWUPT_TLVTYPE_SZ - PTPMSG_FLWUPT_TLVLENGTH_SZ;
	PTPM_TLV_ORGANIZATION_ID(pstMsg->stFollowUP_TLV.uchOrganizationID);
	PTPM_TLV_ORGANIZATION_SUBTYP(pstMsg->stFollowUP_TLV.uchOrganizationSubType);

	{
		DOUBLE				dbA = 0.0;
		dbA = DBCONST2_41;
		dbA = dbA * (pstSyncSnd->dbRateRatio - DBCONST1_0);
		if (dbA >= DBCONST2_31)
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)DBCONST2_31;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else if (dbA <= DBCONST2_31M)
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)DBCONST2_31M;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)dbA;
		}
	}
	pstMsg->stFollowUP_TLV.usGMTmBaseIndicator = pstSyncSnd->usGmTimeBaseIndicator;
	pstMsg->stFollowUP_TLV.stLstGMPhsChange = pstSyncSnd->stLastGmPhaseChange;

	{
		DOUBLE				dbA = 0.0;
		dbA = DBCONST2_41;
		dbA = dbA * (pstSyncSnd->dbLastGmFreqChange - DBCONST1_0);
		if (dbA >= DBCONST2_31)
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)DBCONST2_31;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else if (dbA <= DBCONST2_31M)
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)DBCONST2_31M;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)dbA;
		}
	}
	GetPTPMSG_FOLLOWUP_TLV(pstMsg->stFollowUP_TLV, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL	TxSync_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT				nPtpSend	= 0;
	USHORT			usLength	= 0;
	UCHAR*			pucMsg	= NULL;

	PORT_1AS_DS*	pstPortDS	= &pstPort->stPort_1AS_DS;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;

	pstCallback->pblTimeStampFlag	= &pstSmGbl->blEgMDTimestampReceive;
	pstCallback->pstTimeStamp		= &pstSmGbl->stEgMDTimestampReceive;
	pstCallback->pfnCall			= (TMSCB_FUNC_PTR)&MDSyncSendSM;
	pstCallback->usEvent			= PTP_EV_RCVDMDTIMESTAMPRECEIVE;
	pstCallback->pstPortData		= pstPort;
	if (pstPortDS->blOneStepTxOper)
	{
		usLength = pstSmGbl->stTxSyncOneAS.stHeader.usMegLength;
		pucMsg = (UCHAR*)&pstSmGbl->stTxSyncOneAS;
	}
	else
	{
		usLength = pstSmGbl->stTxSyncTwoAS.stHeader.usMegLength;
		pucMsg = (UCHAR*)&pstSmGbl->stTxSyncTwoAS;
	}
	nPtpSend = MD_ptp_send(pucMsg, usLength, pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82002108);
		return FALSE;
	}
	return TRUE;
}

BOOL	SetFollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	MDSYNCSEND*			pstSyncSnd		= &pstPort->stPort_GD.stMdSyncSend;


	FRAC_NSEC64			stFrecNsec64;

	PTPMSG_SYNC_TWO_STEP_1AS*	pstTxMsgSync = &pstSmGbl->stTxSyncTwoAS;

	PTPMSG_FOLLOWUP_1AS*	pstMsg = NULL;

	SSSYNCSM_1AS_GD*	pstSSSGlb		= GetSSSyncSM_1AS_GD(pstPort->pstClockData);

	pstMsg = &pstSmGbl->stTxFollowUpAS;
	tsn_Wrapper_MemSet(pstMsg, 0x00, sizeof(*pstMsg));

	MPTPMSG_H_SET_MAJORSDO_ID( &pstMsg->stHeader, PTPM_MAJOR_SDOID_1 );
	MPTPMSG_H_SET_MSG_TYPE( &pstMsg->stHeader, PTPM_MSGTYPE_FOLLOWUP );
	MPTPMSG_H_SET_MINOR_VER( &pstMsg->stHeader, PTPM_MINOR_VER_PTP_1 );
	MPTPMSG_H_SET_VER_PTP( &pstMsg->stHeader, PTPM_VER_PTP_2 );

	pstMsg->stHeader.uchDomainNumber	= pstSyncSnd->uchClockNumber;
	pstMsg->stHeader.usMegLength		= 0;
	pstMsg->stHeader.uchMinorSdoId		= PTPM_MINOR_SDOID_0;
	{
		USCALEDNS			stA_uSN;
		SCALEDNS			stA_SN;
		SCALEDNS			stB_SN;

#ifndef	PTP_USE_ME_HW_ASSIST
		ptpConvTS_USNs(&pstSmGbl->stSyncEgTimestamp, &stA_uSN);
		ptpSubUSNs_USNs(&stA_uSN, &pstSyncSnd->stUpstreamTxTime, &stA_SN);
#else
		if(pstPort->pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE)
		{
			pstSyncSnd->stPreciseOriginTimestamp = pstSmGbl->stSyncEgTimestamp;
			tsn_Wrapper_MemSet(&stB_SN, 0, sizeof(USCALEDNS));
		}
		else
		{
			ptpConvTS_USNs(&pstSmGbl->stSyncEgTimestamp_Frun, &stA_uSN);
			ptpSubUSNs_USNs(&stA_uSN, &pstSyncSnd->stUpstreamTxTime, &stA_SN);
			ptpMultSNs_Doub(&stA_SN, pstSyncSnd->dbRateRatio, &stB_SN);
#ifdef	OFFSET_DEBUG

			if (blPtpOffsetUnder50Flag)
			{
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].ulType	= 2;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stSyncEgTimestamp_Frun
											= stA_uSN;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stSyncEgTimestamp
											= pstSmGbl->stSyncEgTimestamp;
			}
#endif
		}
#endif

#ifndef	PTP_USE_ME_HW_ASSIST
		ptpMultSNs_Doub(&stA_SN, pstSyncSnd->dbRateRatio, &stB_SN);
#endif

		ptpConvSNs_TInt(&stB_SN, &stFrecNsec64);
		ptpAddTInt_SNs(&stFrecNsec64, &pstSyncSnd->stFollowUpCorrectionField, &pstMsg->stHeader.stCorrectionField);

#ifdef	OFFSET_DEBUG
		if(pstPort->pstClockData->stClock_GD.enSelectedState[0] != ENUM_PORTSTATE_SLAVE)
		{
			if (blPtpOffsetUnder50Flag)
			{
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stUpstreamTxTime2
											= pstSyncSnd->stUpstreamTxTime;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].ststayTime
											= stB_SN;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].dbRateRatio
											= pstSyncSnd->dbRateRatio;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].stCorrectionField
											= pstMsg->stHeader.stCorrectionField;
				stCorrectiontLog[usCorrectiontLogCount%MAX_CORRECTIONTLOG].usCorrectiontLogCount
											= usCorrectiontLogCount;
				usCorrectiontLogCount ++;
			}
		}
#endif

	}

	tsn_Wrapper_MemSet(&pstMsg->stHeader.uchMsgTypSpecific, PTPM_MTYPE_SPCFC_FOLLOWUP,
		sizeof(pstMsg->stHeader.uchMsgTypSpecific));
	tsn_Wrapper_MemCpy(&pstMsg->stHeader.stSrcPortIdentity,
		&pstSyncSnd->stSourcePortIdentity,sizeof(pstMsg->stHeader.stSrcPortIdentity));
	pstMsg->stHeader.usSequenceId		= pstTxMsgSync->stHeader.usSequenceId;
	pstMsg->stHeader.uchControl		= PTPM_CONTROL_FOLLOWUP;
	pstMsg->stHeader.chLogMsgInterVal	= pstSyncSnd->chLogMessageInterval;
	GetPTPMSG_HEADER(pstMsg->stHeader,pstMsg->stHeader.usMegLength);

	tsn_Wrapper_MemCpy(&pstMsg->stPrcsOrgnTimestamp,
		&pstSyncSnd->stPreciseOriginTimestamp, sizeof(pstMsg->stPrcsOrgnTimestamp));
	GetPTPMSG_FOLLOWUP_1AS(*pstMsg, pstMsg->stHeader.usMegLength);

	pstMsg->stFollowUP_TLV.usTLVType = PTPM_TLVTYP_ORGANIZATION_EXTEN;
	GetPTPMSG_FOLLOWUP_TLV(pstMsg->stFollowUP_TLV, pstMsg->stFollowUP_TLV.usLengthField);
	pstMsg->stFollowUP_TLV.usLengthField = pstMsg->stFollowUP_TLV.usLengthField
						- PTPMSG_FLWUPT_TLVTYPE_SZ - PTPMSG_FLWUPT_TLVLENGTH_SZ;
	PTPM_TLV_ORGANIZATION_ID(pstMsg->stFollowUP_TLV.uchOrganizationID);
	PTPM_TLV_ORGANIZATION_SUBTYP(pstMsg->stFollowUP_TLV.uchOrganizationSubType);

	if (pstSSSGlb->blCumulativeRateRatioValid == FALSE)
	{
		pstSyncSnd->dbRateRatio = DBCONST1_0;
	}


	{
		DOUBLE				dbA = 0.0;
		dbA = DBCONST2_41;
		dbA = dbA * (pstSyncSnd->dbRateRatio - DBCONST1_0);

		if (dbA >= DBCONST2_31)
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)CONST2_31;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else if (dbA <= DBCONST2_31M)
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)CONST2_31M;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else
		{
			pstMsg->stFollowUP_TLV.lCmltvScaledRateOffset = (LONG)dbA;
		}
	}

	pstMsg->stFollowUP_TLV.usGMTmBaseIndicator = pstSyncSnd->usGmTimeBaseIndicator;
	pstMsg->stFollowUP_TLV.stLstGMPhsChange = pstSyncSnd->stLastGmPhaseChange;

	{
		DOUBLE				dbA = 0.0;
		dbA = DBCONST2_41;
		dbA = dbA * (pstSyncSnd->dbLastGmFreqChange - DBCONST1_0);
		if (dbA >= DBCONST2_31)
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)CONST2_31;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else if (dbA <= DBCONST2_31M)
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)CONST2_31M;
			PTP_WARNING_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_OVERFLOW);
		}
		else
		{
			pstMsg->stFollowUP_TLV.lScaledLstGMFrqChange = (LONG)dbA;
		}
	}
	GetPTPMSG_FOLLOWUP_TLV(pstMsg->stFollowUP_TLV, pstMsg->stHeader.usMegLength);

	return TRUE;
}

BOOL	TxFollowUp_1AS(MDSSENDSM_GD* pstSmGbl, PORTDATA* pstPort)
{
	INT		nPtpSend = 0;

	TIMESTAMP_CALLBK_INF	stCallback;
	TIMESTAMP_CALLBK_INF*	pstCallback = &stCallback;
	pstCallback->pblTimeStampFlag	= NULL;
	pstCallback->pstTimeStamp		= NULL;
	pstCallback->pfnCall			= NULL;
	pstCallback->usEvent			= 0;
	pstCallback->pstPortData		= pstPort;
	nPtpSend = MD_ptp_send(
		(UCHAR*)&pstSmGbl->stTxFollowUpAS,
		pstSmGbl->stTxFollowUpAS.stHeader.usMegLength,
		pstCallback);
	if (nPtpSend != 0)
	{
		PTP_ERROR_LOGRECORD(pstPort->pstClockData, PTP_LOG_MDSSENDSM_1AS, PTP_LOGVE_82002208);
		return FALSE;
	}
	return TRUE;
}

#endif

#ifndef PTP_USE_SIGNALING
VOID syncIntSet_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS;
	USCALEDNS		stA_USNs = { 0 };

	pstPortDS = &pstPort->stPort_1AS_DS;

	if (pstPortDS->blUseMgtSettableLogSyncInterval)
	{
		pstPortDS->chCurrentLogSyncInterval
			= pstPortDS->chMgtSettableLogSyncInterval;
	}
	else
	{
		pstPortDS->chCurrentLogSyncInterval
			= pstPortDS->chInitialLogSyncInterval;
	}

	stA_USNs.ulNsec_lsb = CONST10_9;

	ptpShiftUSNs_CHAR(
		&stA_USNs,
		pstPortDS->chCurrentLogSyncInterval,
		&pstPort->stPort_GD.stSyncInterval);

	return;
}

VOID oneStepTxOpSet_1AS(PORTDATA* pstPort)
{
	PORT_1AS_DS*	pstPortDS;
	USCALEDNS		stA_USNs = { 0 };

	pstPortDS = &pstPort->stPort_1AS_DS;

	if (pstPortDS->blUseMgtSettableOneStepTxOper)
	{
		pstPortDS->blCurrentOneStepTxOper
			= pstPortDS->blMgtSettableOneStepTxOper;
	}
	else
	{
		pstPortDS->blCurrentOneStepTxOper
			= pstPortDS->blInitialOneStepTxOper;
	}

	pstPortDS->blOneStepTxOper = (BOOL)(pstPortDS->blCurrentOneStepTxOper && pstPortDS->blOneStepTransmit);

	return;
}

#endif
