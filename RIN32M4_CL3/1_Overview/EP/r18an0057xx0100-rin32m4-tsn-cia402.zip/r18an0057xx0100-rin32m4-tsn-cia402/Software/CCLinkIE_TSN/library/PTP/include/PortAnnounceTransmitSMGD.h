/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PORTANNOUNCETRANSMITGD_H__
#define __PORTANNOUNCETRANSMITGD_H__
#include "ptp_ddt.h"



typedef	enum tagPATRANSMITSM_ST
{
	PATRANSM_NONE = 0,
	PATRANSM_TRANSMIT_INIT,
	PATRANSM_IDLE,
	PATRANSM_TRANSMIT_PERIODIC,
	PATRANSM_TRANSMIT_ANNOUNCE,
	PATRANSM_STATUS_MAX
} PATRANSMITSM_ST;
#define	PATRANSMITSM_ST_MAX	5

typedef enum tagPATRANSMITSM_EV {
	PATRAN_EV_BEGIN = 0,
	PATRAN_EV_ANNOUNCESENDTIME,
	PATRAN_EV_NEWINFO,
	PATRAN_EV_CLOSE,
	PATRAN_EV_EVENT_MAX
} PATRANSMITSM_EV;
#define	PATRANSMITSM_EV_MAX	4

typedef struct tagPATRANSMITSM_GD
{
	USCALEDNS		stAnnounceSendTime;
	UCHAR			uchNumberAnnounceTransmissions;
	USCALEDNS		stInterval2;
	PATRANSMITSM_ST	enStatus;
	TMO_MANAGE_INF_BLK* pstTOAnnounceTransmit;
} PATRANSMITSM_GD;

#endif
