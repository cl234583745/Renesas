//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "net.h"
#include "local.h"
#include "support.h"

#ifndef Ethernet
#define Ethernet &ussSLIPTable
extern PTABLE   ussSLIPTable;
#endif

#if NTRACE == 0 || MT != 0
#define CNTBUF()
#else
#define CNTBUF() Ncntbuf()
#endif


extern struct CONNECT connblo[];
extern struct NET nets[];
extern PTABLE   ussWRAPTable;

#define NRECS 20
#define RECSIZ 468

static int      nrecs;

#define TESTDATA 0x47821295
static const long testdata = TESTDATA;
static char     buff[RECSIZ],
                buff2[3 * RECSIZ];
static union {
    char            c[2];
    short           s;
}               un;


extern unsigned int clocks_per_sec;
static unsigned long ticks;
#if MT == -1
unsigned long   Nclock(void)
{
    return ++ticks;
}
#endif

#ifdef	INET6
int             main(int argn, char *argv[])
#else
int             main(void)
#endif
{
    int             i1,
                    i2,
                    lc,
                    len,
                    myport,
                    conn1,
                    conn2;
    unsigned long   ul1,
                    ul2;
    unsigned short  us1;
    long            li1;
    struct CONNECT *conp1,
                   *conp2;
    struct NET     *netp;
#ifdef	INET6
    int ipv6 = 0;
    char hostname[42];
    for (i1=1; i1<argn; i1++) {
        if (argv[i1][0] == '-') {
            if (argv[i1][1] == '6')
                ipv6 = 1;
        }
    }
#endif
    {
    }
		
    Nprintf("LTest -- local loopback test program \n");


    Nprintf("   checking that initialized RAM was \n");
    if (testdata != TESTDATA) {
        Nprintf("! failed RAM init -- check linker command file and boot code \n");
        return -1;
    }

    Nprintf("   checking endian info \n");
    un.c[0] = 1, un.c[1] = 2;
    if (NC2(un.s) != 0x0102) {
        Nprintf("! failed endian check -- check LITTLE and NC2 in source \n");
        return -2;
    }


    nrecs = NRECS;

    Nprintf("   starting ticker \n");
#if MT == 0
    ticks = 0;
    clocks_per_sec = 1000;
#endif
    {
        signed          j = Ninit();
        if (j < 0) {
            Nprintf("! failed to start ticker/interrupts/network %d \n", j);
            return -1;
        }
    }
    {
        unsigned long j = Nclock();
        unsigned long k = 1000000;
        while (Nclock() == j && --k) {
        }
        if (Nclock() == j) {
            Nprintf("! clock isn't ticking \n");
            return -1;
        }
    }


    Nprintf("   starting fake network \n");

    if (Portinit("*") < 0) {
        Nterm();
        Nprintf("! 'Portinit(\"*\")' failed \n");
        return -1;
    }

#ifdef	INET6
    Nprintf("   opening %snetwork ports \n", ipv6 ? "IPv6 " : "");
#else
    Nprintf("   opening network ports \n");
#endif

#ifdef	INET6
    if (ipv6)
        inet_ntop(28, netconf[0].ipv6.I6addr.c, hostname, sizeof (hostname));
    else 
        strcpy (hostname, localhostname);
    conn2 = Nopen(hostname, ipv6 ? "TCP/IPv6" : "TCP/IP", 21, 0, S_NOWA);
#else
    conn2 = Nopen(localhostname, "TCP/IP", 21, 0, S_NOWA);
#endif
    if (conn2 != 0)
        goto err1;
    myport = Nportno();
#ifdef	INET6
    conn1 = Nopen(hostname, ipv6 ? "TCP/IPv6" : "TCP/IP", myport, 21, 0);
#else
    conn1 = Nopen(localhostname, "TCP/IP", myport, 21, 0);
#endif
    if (conn1 < 0)
        goto err2;
    conp1 = &connblo[conn1];
    conp2 = &connblo[conn2];
    netp = &nets[0];


    Nprintf("***SEND AND RECEIVE %d MESSAGES\n", nrecs);
    for (lc = 0; lc < nrecs; lc++) {
        for (i2 = 0; i2 < sizeof(buff); i2++)
            buff[i2] = lc + i2;
        i1 = Nwrite(conn1, buff, sizeof(buff));
        if (i1 < 0)
            goto werr;
        YIELD();
        i1 = Nread(conn2, buff2, RECSIZ);
        if (i1 != RECSIZ)
            goto rerr;
        for (i1 = 0; i1 < sizeof(buff); i1++)
            if (buff2[i1] != (i2 = buff[i1]))
                goto derr;
        YIELD();
        YIELD();
        for (li1 = TimeMS(); TimeMS() - li1 < 300;);
    }
    CNTBUF();
    Nprintf("---%d MESSAGES OK\n", nrecs);

#if FRAGMENTATION

    Nprintf("***FRAGMENTATION\n");
#ifdef	INET6
    if (ipv6) {
        us1 = nets[conp1->netno].ipv6.maxblo6;
        nets[conp1->netno].ipv6.maxblo6 = RECSIZ;
    } else {
        us1 = nets[conp1->netno].maxblo;
        nets[conp1->netno].maxblo = RECSIZ;
    }
#else
    us1 = nets[conp1->netno].maxblo;
    nets[conp1->netno].maxblo = RECSIZ;
#endif
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = 11 + i2;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    YIELD();
    i1 = Nread(conn2, buff2, RECSIZ);
    if (i1 != RECSIZ)
        goto rerr;
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    for (i1 = 0; i1 < sizeof(buff); i1++)
        if (buff2[i1] != (char) (i2 = (11 + i1)))
            goto derr;
    if (conp1->wackf)
        goto aerr;
    if (conp1->future)
        goto ferr;
    CNTBUF();

    Nprintf("***FRAGMENTATION WITH RETRANSMIT\n");
    ul1 = conp2->rxseq;
    conp2->rxseq = 0x55555555;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = 17 + i2;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    if (conp2->first)
        goto neerr;
    conp2->rxseq = ul1;
    i2 = nets[conp1->netno].tout;
    for (ul2 = TimeMS(); TimeMS() - ul2 <= i2;)
        YIELD();
    i1 = Nread(conn2, buff2, RECSIZ);
    if (i1 != RECSIZ)
        goto rerr;
    YIELD();
    YIELD();
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    for (i1 = 0; i1 < sizeof(buff); i1++)
        if (buff2[i1] != (char) (i2 = (17 + i1)))
            goto derr;
    if (conp1->wackf)
        goto aerr;
    if (conp1->future)
        goto ferr;
    CNTBUF();
#ifdef	INET6
    if (ipv6)
        nets[conp1->netno].ipv6.maxblo6 = us1;
    else
#endif
    nets[conp1->netno].maxblo = us1;
    Nprintf("---FRAGMENTATION OK\n");
#endif


    Nprintf("***SEQUENCE NUMBER ROLLOVER\n");
    nrecs = 3;
    conp1->txseq = conp2->rxseq = conp1->ackno = conp2->ackno =
        conp2->seqtoack = 0xfffffdd0;
    for (lc = 0; lc < nrecs; lc++) {
        for (i2 = 0; i2 < sizeof(buff); i2++)
            buff[i2] = lc + i2;
        i1 = Nwrite(conn1, buff, sizeof(buff));
        if (i1 < 0)
            goto werr;
        YIELD();
        i1 = Nread(conn2, buff2, RECSIZ);
        if (i1 != RECSIZ)
            goto rerr;
        YIELD();
        YIELD();
        for (i1 = 0; i1 < sizeof(buff); i1++)
            if (buff2[i1] != (i2 = buff[i1]))
                goto derr;
    }
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    CNTBUF();
    if (conp1->wackf)
        goto aerr;
    Nprintf("---ROLLOVER OK\n");


    Nprintf("***OVERLAPPING MESSAGES\n");
    conp1->txseq = conp2->rxseq =
        conp1->ackno = conp2->ackno = conp2->seqtoack = 0x200;
    ul1 = conp1->txseq;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    memset(buff2, 0, sizeof(buff2));
    i1 = Nwrite(conn1, buff, 40);
    if (i1 != 40)
        goto werr;
    conp1->txseq = ul1;
    i1 = Nwrite(conn1, buff, RECSIZ - 30);
    if (i1 != RECSIZ - 30)
        goto werr;
    i1 = Nwrite(conn1, buff + RECSIZ - 30, 30);
    if (i1 != 30)
        goto werr;
    i1 = Nread(conn2, buff2, RECSIZ);
    if (i1 != RECSIZ)
        goto rerr;
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp2->ackdseq != ul1 + RECSIZ)
        goto seqerr;
    for (i1 = 0; i1 < RECSIZ; i1++)
        if (buff2[i1] != (char) (i2 = (i1 + ul1)))
            goto derr;
    memset(buff2, 0, sizeof(buff2));
    conp1->txseq = conp2->rxseq =
        conp1->ackno = conp2->ackno = conp2->seqtoack = 0x200;
    ul1 = conp1->txseq;
    i1 = Nwrite(conn1, buff, 40);
    if (i1 != 40)
        goto werr;
    i1 = Nread(conn2, buff2, 40);
    if (i1 != 40)
        goto rerr;
    YIELD();
    YIELD();
    conp1->txseq = ul1;
    i1 = Nwrite(conn1, buff, RECSIZ - 30);
    if (i1 != RECSIZ - 30)
        goto werr;
    i1 = Nread(conn2, buff2 + 40, RECSIZ - 70);
    if (i1 != RECSIZ - 70)
        goto rerr;
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp2->ackdseq != ul1 + RECSIZ - 30)
        goto seqerr;
    i1 = Nwrite(conn1, buff + RECSIZ - 30, 30);
    if (i1 != 30)
        goto werr;
    i1 = Nread(conn2, buff2 + RECSIZ - 30, 30);
    if (i1 != 30)
        goto rerr;
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp2->ackdseq != ul1 + RECSIZ)
        goto seqerr;
    for (i1 = 0; i1 < RECSIZ; i1++)
        if (buff2[i1] != (char) (i2 = (i1 + ul1)))
            goto derr;
    for (lc = 0; lc < 4; lc++) {
        conp1->txseq = conp2->rxseq =
            conp1->ackno = conp2->ackno = conp2->seqtoack = 0x200;
        len = 0;
        ul1 = conp1->txseq;
        for (i2 = 0; i2 < sizeof(buff); i2++)
            buff[i2] = i2 + conp1->txseq;
        memset(buff2, 0, sizeof(buff2));
        i1 = Nwrite(conn1, buff, 100);
        if (i1 < 0)
            goto werr;
        if (lc & 1) {
            i1 = Nread(conn2, buff2 + len, sizeof(buff2) - len);
            if (i1 <= 0)
                goto rerr;
            len += i1;
        }
        YIELD();
        YIELD();
        conp1->txseq = ul1 + 40;
        i1 = Nwrite(conn1, buff + 40, sizeof(buff) - 40);
        if (i1 < 0)
            goto werr;
        for (; len < RECSIZ;) {
            i1 = Nread(conn2, buff2 + len, sizeof(buff2) - len);
            if (i1 <= 0)
                goto rerr;
            len += i1;
        }
        conp2->sendack = netp->worktodo = 5;
        WAITNOMORE(SIG_RN(0));
        for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
            YIELD();
        for (i1 = 0; i1 < RECSIZ; i1++)
            if (buff2[i1] != (char) (i2 = (i1 + ul1)))
                goto derr;
        if (conp1->wackf)
            goto aerr;
        if (conp1->future)
            goto ferr;
    }
    CNTBUF();
    Nprintf("---OVERLAP OK\n");


    Nprintf("***OUT OF ORDER MESSAGES\n");
    conp1->txtout = 1000;
    ul1 = conp1->txseq;
    conp1->txseq = ul1 + 2 * RECSIZ;
    conp1->window = 4 * RECSIZ;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    conp1->window = sizeof(buff) * 4;
    conp1->txseq = ul1;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    conp1->window = sizeof(buff) * 4;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    for (len = 0; len < 3 * RECSIZ;) {
        i1 = Nread(conn2, buff2, sizeof(buff2));
        if (i1 <= 0)
            goto rerr;
        for (lc = 0; lc < i1; lc++)
            if (buff2[lc] != (char) (i2 = (len + lc + ul1)))
                goto derr;
        len += i1;
    }
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp1->wackf)
        goto aerr;
    if (conp1->future)
        goto ferr;
    CNTBUF();
    Nprintf("---OUT OF ORDER OK\n");


    Nprintf("***DUPLICATE MESSAGES\n");
    conp1->txseq = conp2->rxseq = conp1->ackno = conp2->ackno =
        conp2->seqtoack = 0x200;
    ul1 = conp1->txseq;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    conp1->txseq = ul1;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = i2 + conp1->txseq;
    conp2->sendack = netp->worktodo = 5;
    conp2->seqtoack = conp2->rxseq;
    WAITNOMORE(SIG_RN(0));
    YIELD();
    YIELD();
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    for (len = 0; len < 3 * RECSIZ;) {
        i1 = Nread(conn2, buff2, sizeof(buff2));
        if (i1 <= 0)
            goto rerr;
        for (lc = 0; lc < i1; lc++)
            if (buff2[lc] != (char) (i2 = (len + lc + ul1)))
                goto derr;
        len += i1;
        YIELD();
        YIELD();
    }
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp1->wackf)
        goto aerr;
    if (conp1->future)
        goto ferr;
    CNTBUF();
    Nprintf("---DUPLICATE OK\n");


    Nprintf("***RETRANSMISSION\n");
    ul1 = conp2->rxseq;
    conp2->rxseq = 0x55555555;
    for (i2 = 0; i2 < sizeof(buff); i2++)
        buff[i2] = 7 + i2;
    conp1->txstat |= S_FIN;
    i1 = Nwrite(conn1, buff, sizeof(buff));
    if (i1 < 0)
        goto werr;
    YIELD();
    if (conp2->first)
        goto neerr;
    conp2->rxseq = ul1;
    i2 = conp1->txtout;
    for (i1 = 0; i1 < i2; i1++)
        YIELD();
    i1 = Nread(conn2, buff2, RECSIZ);
    if (i1 != RECSIZ)
        goto rerr;
    for (i1 = 0; i1 < sizeof(buff); i1++)
        if (buff2[i1] != (char) (i2 = (7 + i1)))
            goto derr;
    for (ul2 = TimeMS(); TimeMS() - ul2 < 350;)
        YIELD();
    if (conp1->wackf)
        goto aerr;
    if (conp1->future)
        goto ferr;
    CNTBUF();
    Nprintf("---RETRANSMISSION OK\n");

    Nclose(conn2);
    Nclose(conn1);
    Nterm();
    Nprintf("\nno errors in LTEST\n");
    return 0;
err2:
    Nclose(conn2);
err1:
    Nterm();
    return -1;
werr:
    Nprintf("FAILURE: Nwrite\n");
    goto err1;
rerr:
    Nprintf("FAILURE: Nread\n");
    goto err1;
derr:
    Nprintf("FAILURE: data byte %d = %x should be %x\n", i1,
            (unsigned char) buff2[i1], (unsigned char) i2);
    goto err1;
aerr:
    Nprintf("FAILURE: wait for ack queue not empty\n");
    goto err1;
ferr:
    Nprintf("FAILURE: future queue not empty\n");
    goto err1;
neerr:
    Nprintf("FAILURE: bad message got through\n");
    goto err1;
seqerr:
    Nprintf("FAILURE: bad ackdseq sequence number\n");
    goto err1;
}
