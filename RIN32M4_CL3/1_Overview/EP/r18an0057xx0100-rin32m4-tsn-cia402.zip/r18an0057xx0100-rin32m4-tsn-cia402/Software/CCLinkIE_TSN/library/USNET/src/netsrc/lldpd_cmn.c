//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <stdio.h>
#include "net.h"
#include "local.h"
#include "support.h"
#include "msw_lldp.h"
#include "lldpd.h"

static int lldpdTimerFlag;

void lldpdTimerFlagSet(int flag)
{
    lldpdTimerFlag = flag;
    return;
}

void lldpdTimer(int netno)
{
    int ix, iy;
    int count;
    static unsigned long preTime[NNETS];
    unsigned long now = TimeMS();
    LLDPD_PORT_T *port;
    LLDPD_AGENT_T *agent;

    if (lldpdTimerFlag != TRUE) {
        return;
    }

    if ((now - preTime[netno]) < LLDPD_TIMER_PERIOD) {
        return;
    }
    preTime[netno] = (now / LLDPD_TIMER_PERIOD) * LLDPD_TIMER_PERIOD;

    for (ix = 0; ix < LLDPD_PORT_NUM; ix++) {
        if (lldpdMib.lldpdPort[ix].netno == netno) {
           for (iy = 0; iy < LLDPD_MC_NUM; iy++) {
               agent = &(lldpdMib.lldpdPort[ix].lldpdAgent[iy]);
               if (agent->agentEnabled == 0) {
                   continue;
               }

               lldpdTxUpdateTimer(agent);

               lldpdTxTimSmRun(agent);
               lldpdTxSmRun(agent);
               lldpdRxSmRun(agent);

               lldpdRxUpdateTimer(agent);
           }
        }
    }
    if (ix == LLDPD_PORT_NUM) {
        return;
    }

}

void lldpdLstChgTimSet(LLDPD_AGENT_T *agent)
{
    (void)agent;
    lldpdMib.tblLastChangeTime = TimeMS();
    return;
}

int lldpdAdminStatusGet(char *ifname, unsigned char mcBitmap, 
    unsigned char *adminStatus)
{
    int ret;
    const MSW_LLDP_LOCAL_INFO_T *info;

    ret = mswLldpLocalDataPtrGet(ifname, mcBitmap, &info);
    if (ret == MSW_EC_NO_ERROR) {
       *adminStatus = info->adminStatus;
    }

    return ret;
}

#ifdef LLDPD_DEBUG
void lldpdTlvDump(MSW_TLVS_T *tlv)
{
    unsigned int idx;

    Nprintf("--------TLV DATA TOP-----------\n");
    Nprintf("--------MSW_TLV_CHASIIS-----------\n");
    Nprintf("chassis curlen: %d\n", tlv->chassis.curlen);
    Nprintf("chassis subtype: %d\n", tlv->chassis.subtype);
    Nprintf("chassis id:\n");
    mswLldpDump((char *)tlv->chassis.id,tlv->chassis.curlen-sizeof(tlv->chassis.subtype));
    Nprintf("--------MSW_TLV_PORTID-----------\n");
    Nprintf("portid curlen: %d\n", tlv->portid.curlen);
    Nprintf("portid subtype: %d\n", tlv->portid.subtype);
    Nprintf("portid id:\n");
    mswLldpDump((char *)tlv->portid.id,tlv->portid.curlen-sizeof(tlv->portid.subtype));
    Nprintf("--------MSW_TLV_TTL-----------\n");
    Nprintf("ttl ttl: %d\n", tlv->ttl.ttl);
    if (tlv->portdes.status != 0) {
        Nprintf("--------MSW_TLV_PORTDES-----------\n");
        Nprintf("portdesc curlen: %d\n", tlv->portdes.curlen);
        Nprintf("portdesc pdes:\n");
        mswLldpDump((char *)tlv->portdes.pdes,tlv->portdes.curlen);
    }
    if (tlv->sysname.status != 0) {
        Nprintf("--------MSW_TLV_SYSNAME-----------\n");
        Nprintf("sysname curlen: %d\n", tlv->sysname.curlen);
        Nprintf("sysname name:\n");
        mswLldpDump((char *)tlv->sysname.name,tlv->sysname.curlen);
    }
    if (tlv->sysdes.status != 0) {
        Nprintf("--------MSW_TLV_SYSDES-----------\n");
        Nprintf("sysdes curlen: %d\n", tlv->sysdes.curlen);
        Nprintf("sysdes sdes\n");
        mswLldpDump((char *)tlv->sysdes.sdes,tlv->sysdes.curlen);
    }
    if (tlv->syscap.status != 0) {
        Nprintf("--------MSW_TLV_CAP-----------\n");
        Nprintf("syscap scap: 0x%04x\n", tlv->syscap.scap);
        Nprintf("syscap enbl: 0x%04x\n", tlv->syscap.enbl);
    }
    for (idx = 0; idx < MSW_LLDP_MNGTLV_NUM; idx++) {
        if (tlv->mngaddr[idx].status != 0) {
            Nprintf("--------MSW_TLV_MNG-----------\n");
            Nprintf("mngaddr[%d]\n",idx);
            Nprintf("mngaddr status: %d\n", tlv->mngaddr[idx].status);
            Nprintf("mngaddr curlen: %d\n", tlv->mngaddr[idx].curlen);
            Nprintf("mngaddr strlen: %d\n", tlv->mngaddr[idx].strlen);
            Nprintf("mngaddr addr type: %d\n", tlv->mngaddr[idx].addr.type);
            Nprintf("mngaddr addr addr\n");
            mswLldpDump((char *)tlv->mngaddr[idx].addr.addr,tlv->mngaddr[idx].strlen);
            Nprintf("mngaddr iftype: %d\n", tlv->mngaddr[idx].iftype);
            Nprintf("mngaddr ifnum:  %ld\n", tlv->mngaddr[idx].ifnum);
            Nprintf("mngaddr obj len: %d\n", tlv->mngaddr[idx].obj.len);
            Nprintf("mngaddr obj id\n");
            mswLldpDump((char *)tlv->mngaddr[idx].obj.id, tlv->mngaddr[idx].obj.len);
        }
    }
    Nprintf("--------TLV DATA END-----------\n\n");
}


void lldpdInfoDump(LLDPD_STAT_T *lldpdStat)
{
    int len;

    MSW_INFO_T *info = &lldpdStat->statInfo;
    Nprintf("--------INFO TOP-----------\n");
    Nprintf("stsFrmIn:           %d\n", info->stsFrmIn);
    Nprintf("stsFrmDiscarded:    %d\n", info->stsFrmDiscarded);
    Nprintf("stsFrmInErr:        %d\n", info->stsFrmInErr);
    Nprintf("stsTlvDiscarded:    %d\n", info->tlvinfo.stsTlvDiscarded);
    Nprintf("stsTlvUnrecognized: %d\n", info->tlvinfo.stsTlvUnrecognized);
    Nprintf("stsFrmOut:          %d\n", info->stsFrmOut);
    Nprintf("stsLenErr:          %d\n", info->stsLenErr);
    Nprintf("rxAgeoutsTotal:     %d\n", lldpdStat->rxAgeoutsTotal);
    Nprintf("--------INFO END-----------\n\n");

    len = ((info->unknownTLV[0] & 0x01) << 8) | info->unknownTLV[1];
    if (len == 0) {
        Nprintf("unknownTLV:         None\n");
    } else {
        Nprintf("unknownTLV:\n");
        mswLldpDump((char *)info->unknownTLV, len + 2);
    }
    len = ((info->orgDefInfo[0] & 0x01) << 8) | info->orgDefInfo[1];
    if (len == 0) {
        Nprintf("orgDefInfo:         None\n");
    } else {
        Nprintf("orgDefInfo:\n");
        mswLldpDump((char *)info->orgDefInfo, len + 2);
    }
}

void lldpdRemDataShow(int pix, int mix, int flag)
{
    int ix = 0;
    LLDPD_PORT_T *port;
    LLDPD_AGENT_T *agent;
    LLDPD_REM_TBL_T *tbl = NULL;

    LLDPD_LOG_TRC(("lldpdRemDataShow: pix=%d mix=%d flag=%d\n", pix, mix, flag));

    if (pix == -1) {
        Nprintf("Config(Default)\n");
        Nprintf("  msgTxInterval     = %d\n", lldpdMib.msgTxInterval);
        Nprintf("  msgTxHoldMult     = %d\n", lldpdMib.msgTxHoldMult);
        Nprintf("  reinitDelay       = %d\n", lldpdMib.reinitDelay);
        Nprintf("  notifiyInterval   = %d\n", lldpdMib.notifiyInterval);
        Nprintf("  txCreditMax       = %d\n", lldpdMib.txCreditMax);
        Nprintf("  msgFastTx         = %d\n", lldpdMib.msgFastTx);
        Nprintf("  txFastInit        = %d\n", lldpdMib.txFastInit);
        Nprintf("  locSysCapSup      = 0x%04x\n", lldpdMib.locSysCapSup);
        Nprintf("  locSysCapEna      = 0x%04x\n", lldpdMib.locSysCapEna);
        Nprintf("STATS\n");
        Nprintf("  tblLastChangeTime = %d\n", lldpdMib.tblLastChangeTime);
        Nprintf("  remTblInserts     = %d\n", lldpdMib.remTblInserts);
        Nprintf("  remTblDeletes     = %d\n", lldpdMib.remTblDeletes);
        Nprintf("  remTblDrops       = %d\n", lldpdMib.remTblDrops);
        Nprintf("  remTblAgeouts     = %d\n", lldpdMib.remTblAgeouts);
        Nprintf("remoteSystemMIB Pool\n");
        for (ix = 0; ix < LLDPD_REM_TBL_NUM; ix++) {
            Nprintf("  rem_tbl[%d] = 0x%p state = %d\n", ix, &rem_tbl[ix], rem_tbl[ix].state);
        }
    } else {
        if ((pix >= LLDPD_PORT_NUM) || (mix >= LLDPD_MC_NUM)) {
            LLDPD_LOG_ERR(("lldpdRemDataShow: invalid parameter(pix=%d mix=%d flag=%d)\n", 
                pix, mix, flag));
            return;
        }
        if (flag == 0) {
            tbl = lldpdMib.lldpdPort[pix].lldpdAgent[mix].pLldpdRemData;
            Nprintf("pLldpdRemData=0x%p\n", tbl);
            while (tbl != NULL) {
                Nprintf("  -->0x%p\n", tbl->next);
                tbl = tbl->next;
            }
        } else {
            port = &lldpdMib.lldpdPort[pix];
            agent = &lldpdMib.lldpdPort[pix].lldpdAgent[mix];
            tbl = lldpdMib.lldpdPort[pix].lldpdAgent[mix].pLldpdRemData;
            Nprintf("pix=%d mix=%d\n", pix, mix);
            Nprintf("PORT\n");
            Nprintf("  portEnabled        = %d\n", port->portEnabled);
            Nprintf("  prePortEnabled     = %d\n", port->prePortEnabled);
            Nprintf("  netno              = %d\n", port->netno);
            Nprintf("AGENT\n");
            Nprintf("  agentEnabled       = %d\n", agent->agentEnabled);
            Nprintf("  mcBitmap           = 0x%02x\n", agent->mcBitmap);
            Nprintf("AGENT STAT\n");
            Nprintf("  stsFrmIn           = %d\n", agent->lldpdStat.statInfo.stsFrmIn);
            Nprintf("  stsFrmDiscarded    = %d\n", agent->lldpdStat.statInfo.stsFrmDiscarded);
            Nprintf("  stsFrmInErr        = %d\n", agent->lldpdStat.statInfo.stsFrmInErr);
            Nprintf("  stsFrmOut          = %d\n", agent->lldpdStat.statInfo.stsFrmOut);
            Nprintf("  stsLenErr          = %d\n", agent->lldpdStat.statInfo.stsLenErr);
            Nprintf("  stsTlvDiscarded    = %d\n", agent->lldpdStat.statInfo.tlvinfo.stsTlvDiscarded);
            Nprintf("  stsTlvUnrecognized = %d\n", agent->lldpdStat.statInfo.tlvinfo.stsTlvUnrecognized);
            Nprintf("  rxAgeoutsTotal     = %d\n", agent->lldpdStat.rxAgeoutsTotal);
            Nprintf("  tooManyNghbrs      = %d\n", agent->rxState.tooManyNghbrs);
            Nprintf("REMOTE SYSTEM MIB\n");
            while (tbl != NULL) {
                Nprintf("  remIndex           = %ld\n", tbl->remIndex);
                Nprintf("  rxinfoTTL          = %ld\n", tbl->rxinfoTTL);
                if (flag != 2) {
                    lldpdTlvDump(&tbl->tlvs);
                    Nprintf("  remUnknownTLV\n");
                    mswLldpDump(tbl->remUnknownTLV, LLDPD_UNKOWN_TLV_SIZE);
                    Nprintf("  orgDefInfo\n");
                    mswLldpDump(tbl->orgDefInfo, LLDPD_ORGDEF_TLV_SIZE);
                }
                else {
                    Nprintf("--------------------------\n");
                }

                if (++ix >= LLDPD_REM_TBL_NUM) {
                    tbl = NULL;
                    break;
                }
                tbl = tbl->next;
            }
        }
    }
    return;
}
#endif

LLDPD_REM_TBL_T *lldpdRemDataGet(void)
{
    int ix;
    LLDPD_REM_TBL_T *tbl = NULL;

    LLDPD_LOG_TRC(("lldpdRemDataGet: \n"));

    for (ix = 0; ix < LLDPD_REM_TBL_NUM; ix++) {
        if (rem_tbl[ix].state == LLDPD_REMDATA_NOUSE) {
            tbl = &rem_tbl[ix];
            tbl->state = LLDPD_REMDATA_INUSE;
            break;
        }
    }

    return tbl;
}


void lldpdRemDataRel(LLDPD_REM_TBL_T *remTbl)
{
    LLDPD_LOG_TRC(("lldpdRemDataRel: remTbl=0x%p\n", remTbl));
    memset(remTbl, 0x00, sizeof(LLDPD_REM_TBL_T));
    return;
}

static int lldpdMsapCmp(MSW_TLVS_T *tlv1, MSW_TLVS_T *tlv2)
{
    int ret = 0;

    if (memcmp(&tlv1->chassis, &tlv2->chassis, sizeof(MSW_TLV_CHASIIS_T))) {
        ret = -1;
    }
    if (memcmp(&tlv1->portid, &tlv2->portid, sizeof(MSW_TLV_PORTID_T))) {
        ret = -1;
    }
    return ret;
}


LLDPD_REM_TBL_T *lldpdRemTblAdd(LLDPD_AGENT_T *agent)
{
    static int rindex = 0;
    LLDPD_REM_TBL_T *remTbl;
    LLDPD_REM_TBL_T *tbl;

    LLDPD_LOG_TRC(("lldpdRemTblAdd: agent=0x%p\n", agent));

    remTbl = lldpdRemDataGet();
    if (remTbl != NULL) {
        remTbl->remIndex = rindex++;
        tbl = agent->pLldpdRemData;
        if (tbl == NULL) {
            agent->pLldpdRemData = remTbl;
            remTbl->prev = NULL;

        } else {
            while (tbl->next != NULL) {
                tbl = tbl->next;
            }
            tbl->next = remTbl;
            remTbl->prev = tbl;
        }
        remTbl->next = NULL;
        lldpdMib.remTblInserts++;
    } else {
        lldpdMib.remTblDrops++;
    }

#ifdef LLDPD_DEBUG
    tbl = agent->pLldpdRemData;
    LLDPD_LOG_DBG(("pLldpdRemData=0x%p\n", tbl));
    while (tbl != NULL) {
        LLDPD_LOG_DBG(("  -->0x%p\n", tbl->next));
        tbl = tbl->next;
    }
#endif
    return remTbl;
}

int lldpdRemTblDel(LLDPD_AGENT_T *agent, MSW_TLVS_T *tlvs)
{
    int ix = 0;
    int deleteFlag;
    int ret = -1;
    LLDPD_REM_TBL_T *tbl;

    LLDPD_LOG_TRC(("lldpdRemTblDel: agent=0x%p tlvs=%s\n", 
        agent, tlvs==NULL?"NULL":"!NULL"));

    tbl = agent->pLldpdRemData;
    while (tbl != NULL) {
        deleteFlag = FALSE;
        if (tlvs != NULL) {
            if (!lldpdMsapCmp(&tbl->tlvs, tlvs)) {
                deleteFlag = TRUE;
            }
        } else {
            if (tbl->rxinfoTTL == 0) {
                deleteFlag = TRUE;
            }
        }
        if (deleteFlag == TRUE) {
            if (tbl->prev == NULL) {
                if (tbl->next == NULL) {
                    agent->pLldpdRemData = NULL;
                } else {
                    agent->pLldpdRemData = tbl->next;
                    agent->pLldpdRemData->prev = NULL;
                }
            } else {
                tbl->prev->next = tbl->next;
                if (tbl->next != NULL) {
                    tbl->next->prev = tbl->prev;
                }
            }

            lldpdRemDataRel(tbl);
            ret = 0;
            lldpdMib.remTblDeletes++;

            lldpdLstChgTimSet(agent);
            break;
        }
        if (++ix >= LLDPD_REM_TBL_NUM) {
            break;
        }
        tbl = tbl->next;
    }
#ifdef LLDPD_DEBUG
    tbl = agent->pLldpdRemData;
    LLDPD_LOG_DBG(("pLldpdRemData=0x%p\n", tbl));
    while (tbl != NULL) {
        LLDPD_LOG_DBG(("  -->0x%p\n", tbl->next));
        tbl = tbl->next;
    }
#endif
    return ret;
}


LLDPD_REM_TBL_T *lldpdRemTblGet(LLDPD_AGENT_T *agent, MSW_TLVS_T *tlvs)
{
    int ix = 0;
    LLDPD_REM_TBL_T *tbl;

    LLDPD_LOG_TRC(("lldpdRemTblGet: agent=0x%p\n", agent));

    tbl = agent->pLldpdRemData;
    while (tbl != NULL) {
        if (!lldpdMsapCmp(&tbl->tlvs, tlvs)) {
            break;
        }
        if (++ix >= LLDPD_REM_TBL_NUM) {
            tbl = NULL;
            break;
        }
        tbl = tbl->next;
    }
    return tbl;
}

void lldpdRxFrameCb(unsigned char *inframe, unsigned short len,
        const MSW_LLDP_LOCAL_INFO_T *info)
{
    LLDPD_AGENT_T *agent = (LLDPD_AGENT_T *)(info->usrData);

    LLDPD_LOG_TRC(("lldpdRxFrameCb: agentPtr=0x%p\n", agent));
    LLDPD_LOG_DMP((char *)inframe, len);

    if (len <= LLDPD_FRAME_LENGTH) {
        memcpy(agent->rxState.inFrame, inframe, len);
        agent->rxState.frameLen = len;
        agent->rxState.rcvFrame = TRUE;

        lldpdRxSmRun(agent);
    }
}


void somethingChangedRemoteCbSet(void (*func)(void *))
{
    LLDPD_LOG_TRC(("somethingChangedRemoteCbSet: func=0x%p\n", func));

    lldpdMib.somethingChangedRemoteCb = func;
    return;
}

