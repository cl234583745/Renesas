/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_Struct.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"

#include "MDSyncSendSM.h"
#include "MDSyncSendSM_1AS.h"
#include "ptp_SSSync_1AS.h"
#include "ptp_SSSync_1588.h"
#include "ptp_PSSSend.h"
#include "ptp_LCEntity.h"
#include "PortAnnounceInformationSM.h"

#define D_FUNC	0


VOID	PSSSend_00(PORTDATA*	pstPortData);
VOID	PSSSend_01(PORTDATA*	pstPortData);
VOID	PSSSend_02(PORTDATA*	pstPortData);
VOID	PSSSend_03(PORTDATA*	pstPortData);
MDSYNCSEND*  setMDSync(PORTDATA* pstPortData);
VOID  txMDSync(MDSYNCSEND*	pstTxMDSyncPtr, PORTDATA*	pstPortData);
VOID  txPAInformation(PORTDATA*	pstPortData);





VOID (*const pfnPSSSendMatrix[ST_PSSS_MAX][EV_PSSS_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PSSSend_01, &PSSSend_01, &PSSSend_01, &PSSSend_01, &PSSSend_00},
	{&PSSSend_01, &PSSSend_02, &PSSSend_02, &PSSSend_03, &PSSSend_00},
	{&PSSSend_01, &PSSSend_02, &PSSSend_02, &PSSSend_03, &PSSSend_00},
	{&PSSSend_01, &PSSSend_02, &PSSSend_02, NULL,		 &PSSSend_00}
};



VOID	portSyncSyncSend(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSS	enEvt										= EV_PSSS_EVENT_MAX;
	BOOL 		blSts										= FALSE;
	VOID		(*pfnPSSSendFunc)(PORTDATA*	pstPortData)	= NULL;
	CLOCKDATA*	pstClockData								= NULL;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_PRINT
{
	printf("PSSSendSM   Evt=%d Sts=%d\n", usEvent, pstPortData->stPSSSendSM_GD.enStatusPSSS);
}
#endif
		pstClockData = pstPortData->pstClockData;
		if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
		{
			enEvt = GetPSSSendSM_Event(usEvent, pstPortData);
		}
		else
		{
			enEvt = GetPSSSendSM_Event_1588(usEvent, pstPortData);
		}
		blSts = IsPSSSendSM_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PSSS_EVENT_MAX))
		{
			pfnPSSSendFunc = pfnPSSSendMatrix[pstPortData->stPSSSendSM_GD.enStatusPSSS][enEvt];
			if (pfnPSSSendFunc != NULL)
			{
				pfnPSSSendFunc(pstPortData);
			}
			else
			{
			}
		}
		else
		{
		}

	}
}




PSSSENDSM_GD*	GetPSSSendSM_GD(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb = &(pstPortData->stPSSSendSM_GD);
	return pstPSSSGlb;
}




EN_EV_PSSS	GetPSSSendSM_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSS		enEvt					= EV_PSSS_EVENT_MAX;

#ifdef	PTP_USE_IEEE802_1
	PSSSENDSM_GD*	pstPSSSGlb			= GetPSSSendSM_GD(pstPortData);
	CLOCKDATA*		pstClockData		= pstPortData->pstClockData;
	PORTSYNCSYNC*	pstLastPSSyncPtr	= NULL;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr	= NULL;


	pstLastPSSyncPtr	= &(pstPSSSGlb->stLastRcvdPSSync);
	pstRcvdPSSyncPtr	= &(pstPSSSGlb->stRcvdPSSync);
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PSSS_BEGIN;
			break;

		case PTP_EV_FOR_PORTSYNSYNSD_RVPSYNC:
			if ((pstPSSSGlb->blRcvdPSSync) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PSSS_BEGIN;
			}
			else if ((pstRcvdPSSyncPtr->usLocalPortNumber != pstPortData->stPort_GD.usThisPort) &&
					 (IS_PORTOK(pstPortData)) &&
					 (pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER))
			{
				if ((pstPSSSGlb->enStatusPSSS == ST_PSSS_TRANSMIT_INIT) ||
					(pstPSSSGlb->enStatusPSSS == ST_PSSS_SYNC_RECEIPT_TIMEOUT))
				{
					enEvt = EV_PSSS_FOR_PORTSYNSYNSD_RVPSYN;
				}
				else if (pstPSSSGlb->enStatusPSSS == ST_PSSS_SEND_MD_SYNC)
				{
					if (pstPortData->stPort_1AS_DS.blSyncLocked)
					{
						enEvt = EV_PSSS_FOR_PORTSYNSYNSD_RVPSYN;
					}
				}
				else
				{
				}
			}
			else
			{
			}
			break;

		case PTP_EV_FOR_INTERVAL1TIMEOUT:
			if (pstPSSSGlb->enStatusPSSS == ST_PSSS_SEND_MD_SYNC)
			{
				if ((!(pstPortData->stPort_1AS_DS.blSyncLocked)) &&
					(pstLastPSSyncPtr->usLocalPortNumber != pstPortData->stPort_GD.usThisPort) &&
					(IS_PORTOK(pstPortData)) &&
					(pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER))
				{
					enEvt = EV_PSSS_FOR_INTERVAL1TIMEOUT;
				}
			}
			pstPSSSGlb->pstTMO_Interval1 = NULL;
			break;

		case PTP_EV_SYNCRECEIPTTIMEOUT:
			enEvt = EV_PSSS_SYNCRECEIPTTIMEOUT;
			pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PSSS_CLOSE;
			break;

		default:
			enEvt = EV_PSSS_EVENT_MAX;
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSSENDSM, PTP_LOGVE_84000010);
			break;
	}
#endif

	return	enEvt;
}




EN_EV_PSSS	GetPSSSendSM_Event_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSS		enEvt					= EV_PSSS_EVENT_MAX;

#ifdef	PTP_USE_IEEE1588
	PSSSENDSM_GD*	pstPSSSGlb			= GetPSSSendSM_GD(pstPortData);
	CLOCKDATA*		pstClockData		= pstPortData->pstClockData;
	PORTSYNCSYNC*	pstLastPSSyncPtr	= NULL;
	PORTSYNCSYNC*	pstRcvdPSSyncPtr	= NULL;


	pstLastPSSyncPtr	= &(pstPSSSGlb->stLastRcvdPSSync);
	pstRcvdPSSyncPtr	= &(pstPSSSGlb->stRcvdPSSync);
	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PSSS_BEGIN;
			break;

		case PTP_EV_FOR_PORTSYNSYNSD_RVPSYNC:
			if ((pstPSSSGlb->blRcvdPSSync) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PSSS_BEGIN;
			}
			else if (IS_OD_BC_1588(pstClockData))
			{
				if ((pstRcvdPSSyncPtr->usLocalPortNumber != pstPortData->stPort_GD.usThisPort) &&
					(IS_PORTOK(pstPortData)) &&
					(pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER))
				{
					if ((pstPSSSGlb->enStatusPSSS == ST_PSSS_TRANSMIT_INIT) ||
						(pstPSSSGlb->enStatusPSSS == ST_PSSS_SYNC_RECEIPT_TIMEOUT) ||
						(pstPSSSGlb->enStatusPSSS == ST_PSSS_SEND_MD_SYNC))
					{
						enEvt = EV_PSSS_FOR_PORTSYNSYNSD_RVPSYN;
					}
				}
			}
			else
			{
				if ((pstRcvdPSSyncPtr->usLocalPortNumber != pstPortData->stPort_GD.usThisPort) &&
					(IS_PORTOK(pstPortData)))
				{
					enEvt = EV_PSSS_FOR_PORTSYNSYNSD_RVPSYN;
				}
			}
			break;

		case PTP_EV_FOR_INTERVAL1TIMEOUT:
			if (IS_OD_BC_1588(pstClockData))
			{
				if ((pstLastPSSyncPtr->usLocalPortNumber != pstPortData->stPort_GD.usThisPort) &&
					(IS_PORTOK(pstPortData)) &&
					(pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_MASTER))
				{
					if (pstPSSSGlb->enStatusPSSS == ST_PSSS_SEND_MD_SYNC)
					{
						enEvt = EV_PSSS_FOR_INTERVAL1TIMEOUT;
					}
				}
			}
			pstPSSSGlb->pstTMO_Interval1 = NULL;

			break;

		case PTP_EV_SYNCRECEIPTTIMEOUT:
			enEvt = EV_PSSS_SYNCRECEIPTTIMEOUT;
			pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;
			break;

		case PTP_EV_CLOSE:
			enEvt = EV_PSSS_CLOSE;
			break;

		default:
			enEvt = EV_PSSS_EVENT_MAX;
			break;
	}
#endif

	return	enEvt;
}




BOOL	IsPSSSendSM_Status(
	PORTDATA*	pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb	= GetPSSSendSM_GD(pstPortData);
	BOOL			blRet			= FALSE;


	if (pstPSSSGlb->enStatusPSSS < ST_PSSS_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	PSSSend_00(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb = GetPSSSendSM_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PSSSend_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPortData->stPort_GD.blSyncSlowdown = FALSE;

	pstPSSSGlb->uchNumberSyncTransmissions = 0;
	if (pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime));
		pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;
	}

	if (pstPSSSGlb->pstTMO_Interval1 != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_Interval1));
		pstPSSSGlb->pstTMO_Interval1 = NULL;
	}

	pstPSSSGlb->enStatusPSSS = ST_PSSS_NONE;
	pstPSSSGlb->blRcvdPSSync = FALSE;

	ptp_dbg_msg( D_FUNC, ("PSSSend_00::-\n") );

}




VOID	PSSSend_01(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb = GetPSSSendSM_GD(pstPortData);


	pstPortData->stPort_GD.blSyncSlowdown = FALSE;

	pstPSSSGlb->uchNumberSyncTransmissions = 0;
	if (pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime));
		pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;
	}

	if (pstPSSSGlb->pstTMO_Interval1 != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_Interval1));
		pstPSSSGlb->pstTMO_Interval1 = NULL;
	}

	pstPSSSGlb->enStatusPSSS = ST_PSSS_TRANSMIT_INIT;
	pstPSSSGlb->blRcvdPSSync = FALSE;

}




VOID	PSSSend_02(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb			= GetPSSSendSM_GD(pstPortData);
	PORTSYNCSYNC*	pstRcvdPSSyncPtr	= NULL;
	USHORT			usSSTimeEvent		= PTP_EV_SYNCRECEIPTTIMEOUT;
	USCALEDNS		stCurrentTime		= {0};
	CLOCKDATA*		pstClockData		= pstPortData->pstClockData;


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	pstRcvdPSSyncPtr = pstPSSSGlb->pstRcvdPSSyncPtr;

	if (pstPSSSGlb->blRcvdPSSync)
	{
		pstPSSSGlb->stLastRcvdPSSync = *pstRcvdPSSyncPtr;

		if (pstPortData->stPort_GD.chParentLogSyncInterval
				== pstPortData->stPort_1AS_DS.chCurrentLogSyncInterval)
		{
			pstPortData->stPort_1AS_DS.blSyncLocked = TRUE;
		}
		else
		{
			pstPortData->stPort_1AS_DS.blSyncLocked = FALSE;
		}
	}
	pstPSSSGlb->blRcvdPSSync = FALSE;
	pstPSSSGlb->stLastSyncSentTime = stCurrentTime;

	pstPSSSGlb->pstTxMDSyncSendPtr = setMDSync(pstPortData);

	txMDSync((pstPSSSGlb->pstTxMDSyncSendPtr), pstPortData);


	pstPSSSGlb->enStatusPSSS	= ST_PSSS_SEND_MD_SYNC;

	if (pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE1588)
	{
		return;
	}

	if (pstPortData->stPort_GD.blSyncSlowdown)
	{
		if (pstPSSSGlb->uchNumberSyncTransmissions >= pstPortData->stPort_1AS_DS.uchSyncReceiptTimeout)
		{
			pstPSSSGlb->stInterval1 = pstPortData->stPort_GD.stSyncInterval;
			pstPSSSGlb->uchNumberSyncTransmissions = 0;
			pstPortData->stPort_GD.blSyncSlowdown = FALSE;
		}
		else
		{
			pstPSSSGlb->uchNumberSyncTransmissions++;
			pstPSSSGlb->stInterval1 = pstPortData->stPort_GD.stOldSyncInterval;
		}
	}
	else
	{
		pstPSSSGlb->uchNumberSyncTransmissions = 0;
		pstPSSSGlb->stInterval1 = pstPortData->stPort_GD.stSyncInterval;
	}

	if (pstPSSSGlb->pstTMO_Interval1 != NULL)
	{
		(VOID)ptp_TimeOut_Can((pstPSSSGlb->pstTMO_Interval1));
		pstPSSSGlb->pstTMO_Interval1 = NULL;
	}

	usSSTimeEvent = PTP_EV_FOR_INTERVAL1TIMEOUT;
	(VOID)ptpAddUSNs_USNs(&stCurrentTime,
							 &(pstPSSSGlb->stInterval1),
							 &(pstPSSSGlb->stInterval1TimeoutTime));
	pstPSSSGlb->pstTMO_Interval1 = ptp_TimeOut_Req(usSSTimeEvent,
													pstPortData,
													pstPSSSGlb->stInterval1TimeoutTime,
													(CallBackFunc)&portSyncSyncSend);

}



VOID	PSSSend_03(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb = GetPSSSendSM_GD(pstPortData);


	pstPSSSGlb->blRcvdPSSync	= FALSE;
	pstPSSSGlb->pstTMO_SyncReceiptTimeoutTime = NULL;

	txPAInformation(pstPortData);

}




MDSYNCSEND*  setMDSync(
	PORTDATA*		pstPortData)
{
	PSSSENDSM_GD*	pstPSSSGlb			= GetPSSSendSM_GD(pstPortData);
	PORTSYNCSYNC*	pstLastPSSyncPtr	= NULL;
	MDSYNCSEND*		pstTxMDSyncPtr		= &(pstPortData->stPort_GD.stMdSyncSend);


	pstLastPSSyncPtr	= &(pstPSSSGlb->stLastRcvdPSSync);

	pstTxMDSyncPtr->uchClockNumber				= pstLastPSSyncPtr->uchClockNumber;
	pstTxMDSyncPtr->stFollowUpCorrectionField	= pstLastPSSyncPtr->stFollowUpCorrectionField;
	pstTxMDSyncPtr->stSourcePortIdentity		= pstPortData->stPortDS.stPortIdentity;
	pstTxMDSyncPtr->chLogMessageInterval		= pstPortData->stPort_1AS_DS.chCurrentLogSyncInterval;
	pstTxMDSyncPtr->stPreciseOriginTimestamp	= pstLastPSSyncPtr->stPreciseOriginTimestamp;
	pstTxMDSyncPtr->stUpstreamTxTime			= pstLastPSSyncPtr->stUpstreamTxTime;
	if (pstPortData->pstClockData->stClock_GD.enSupportPTPType == ENUM_SUPPORTPTPTYPE_IEEE802_1AS)
	{
#ifdef	PTP_USE_IEEE802_1
		pstTxMDSyncPtr->dbRateRatio					= pstLastPSSyncPtr->dbRateRatio;
#endif
	}
	else
	{
#ifdef	PTP_USE_IEEE1588
		pstTxMDSyncPtr->dbRateRatio					= DBCONST1_0 / pstLastPSSyncPtr->dbRateRatio;
#endif
	}
	pstTxMDSyncPtr->usGmTimeBaseIndicator		= pstLastPSSyncPtr->usGmTimeBaseIndicator;
	pstTxMDSyncPtr->stLastGmPhaseChange			= pstLastPSSyncPtr->stLastGmPhaseChange;
	pstTxMDSyncPtr->dbLastGmFreqChange			= pstLastPSSyncPtr->dbLastGmFreqChange;

	return pstTxMDSyncPtr;

}




VOID  txMDSync(
	MDSYNCSEND*		pstTxMDSyncPtr,
	PORTDATA*		pstPortData)
{
	USHORT			usEvent			= PTP_EV_BASE;
	MDSSENDSM_GD*	pstMDSSENDSM_GD = &(pstPortData->stMDSSendSM_GD);


	pstMDSSENDSM_GD->blRcvdMDSync = TRUE;

	usEvent = PTP_EV_FOR_MDSYNCSENDSM_RCVDSYNC;
	MDSyncSendSM(usEvent, pstPortData);

}





VOID  txPAInformation(
	PORTDATA*		pstPortData)
{
#ifdef	PTP_USE_BMCA
	USHORT		usEvent = PTP_EV_BASE;


	usEvent = PTP_EV_SYNCRECEIPTTIMEOUT;
	portAnnounceInformationSM(usEvent, pstPortData);

#endif
}


