/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifdef	DEBUG_MID_PRINT
#include <stdlib.h>
#include <stdio.h>
#endif

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"
#include "ptp_Macro.h"

#include "ptp_Struct.h"
#include "ptp_Struct_Port.h"
#include "ptp_Struct_Clock.h"
#include "ptp_CommonFunction.h"
#include "PTP_GlobalData.h"
#include "ptp_LogRecord.h"
#include "ptp_LCEntity.h"

#include "ptp_BCSSend_1588.h"

#include "ptp_tsn_Wrapper.h"

#ifdef	PTP_USE_IEEE1588

#include "MDSyncReceiveSM.h"
#include "MDSyncReceiveSM_1588.h"
#include "ptp_SSSync_1588.h"
#include "ptp_PSSReceive_1588.h"

#define D_FUNC	0
#define D_DBG	0


VOID	PSSReceive_1588_00(PORTDATA*	pstPortData);
VOID	PSSReceive_1588_01(PORTDATA*	pstPortData);
VOID	PSSReceive_1588_02(PORTDATA*	pstPortData);
PORTSYNCSYNC*	setPSSyncPSSR(MDSYNCRECEIVE *  pstRcvdMDSyncPtr,
								PORTDATA*		pstPortData,
								USCALEDNS*	pstSyncReceiptTTimeInterval,
								DOUBLE	  dbRateRatio);
PORTSYNCSYNC*	setPSSyncToBCSS_1588(PORTSYNCSYNC*	pstTxPSSyncPtr, PORTDATA*	pstPortData);
VOID	txPSSyncPSSR_1588(PORTSYNCSYNC* pstTxPSSyncPtr, PORTDATA* pstPortData);
VOID  setDelayInfo_P2P_1588(PORTDATA*	pstPortData);
VOID  setDelayInfo_E2E_1588(PORTDATA*	pstPortData);



#ifdef	DEBUG_MID_MD_PRINT

#define	DEBMID_RZ_DBPRINT(c, a)		printf(" %s = %.15e \n", (c), (a));

#define	MID_OutUScaledNs(c ,a)	printf(" %s [USNs = 0x%04x 0x%08x 0x%08x 0x%04x ]\n", (c),\
														(a)->usNsec_msb,			\
														(a)->ulNsec_2nd,			\
														(a)->ulNsec_lsb,			\
														(a)->usFrcNsec);

#endif


VOID (*const pfnPSSReceive_1588_Matrix[ST_PSSR_1588_MAX][EV_PSSR_1588_EVENT_MAX])(PORTDATA*	pstPortData) = {
	{&PSSReceive_1588_01, &PSSReceive_1588_01, &PSSReceive_1588_00},
	{&PSSReceive_1588_01, &PSSReceive_1588_02, &PSSReceive_1588_00},
	{&PSSReceive_1588_01, &PSSReceive_1588_02, &PSSReceive_1588_00}
};



VOID	portSyncSyncReceive_1588(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSR_1588	enEvt = EV_PSSR_1588_EVENT_MAX;
	BOOL 			blSts = FALSE;


	if (pstPortData != NULL)
	{
#ifdef	DEBUG_MID_MD_PRINT
{
	printf("PSSReceiveSM_1588 SState = [%d] [%d] [%d]\n",
				pstPortData->pstClockData->stClock_GD.enSelectedState[0],
				pstPortData->pstClockData->stClock_GD.enSelectedState[1],
				pstPortData->pstClockData->stClock_GD.enSelectedState[2]);
	MID_OutUScaledNs("CurrentMasterTime  ", (&pstPortData->pstClockData->stClock_GD.stCurrentMasterTime));
	DEBMID_RZ_DBPRINT("GD_dbRateRatio     ", pstPortData->pstClockData->stClock_GD.dbRateRatio);
	DEBMID_RZ_DBPRINT("SYNC_dbRateRatio   ", pstPortData->stPort_GD.stMdSyncReceive.dbRateRatio);
	DEBMID_RZ_DBPRINT("dbNeighborRateRatio", pstPortData->stPort_GD.dbNeighborRateRatio)
}
#endif
		enEvt = GetPSSReceiveSM_1588_Event(usEvent, pstPortData);

		blSts = IsPSSReceiveSM_1588_Status(pstPortData);

		if ((blSts == TRUE) &&
			(enEvt < EV_PSSR_1588_EVENT_MAX))
		{
			(*pfnPSSReceive_1588_Matrix[pstPortData->stUn_PSM_GD.stPsm1588_GD.stPSSReceiveSM_1588_GD.enStatusPSSR_1588][enEvt])(pstPortData);
		}
		else
		{
			PTP_ERROR_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_84000010);
			pstPortData->stUn_PSM_GD.stPsm1588_GD.stPSSReceiveSM_1588_GD.blRcvdMDSync		= FALSE;
		}

	}
}




PSSRECEIVESM_1588_GD*	GetPSSReceiveSM_1588_GD(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1588_GD*	pstPSSRGlb = &(pstPortData->stUn_PSM_GD.stPsm1588_GD.stPSSReceiveSM_1588_GD);
	return pstPSSRGlb;
}




EN_EV_PSSR_1588	GetPSSReceiveSM_1588_Event(
	USHORT		usEvent,
	PORTDATA*	pstPortData)
{
	EN_EV_PSSR_1588			enEvt				= EV_PSSR_1588_EVENT_MAX;
	PSSRECEIVESM_1588_GD*	pstPSSRGlb		= GetPSSReceiveSM_1588_GD(pstPortData);


	switch (usEvent)
	{
		case PTP_EV_BEGIN:
			enEvt = EV_PSSR_1588_BEGIN;
			break;

		case PTP_EV_FOR_PSYNSYNRV_RCVMDSYNC:
			if ((pstPSSRGlb->blRcvdMDSync) &&
				 (!IS_PORTOK(pstPortData)))
			{
				enEvt = EV_PSSR_1588_BEGIN;
			}
			else if (pstPSSRGlb->enStatusPSSR_1588 == ST_PSSR_1588_DISCARD)
			{
				if ((pstPSSRGlb->blRcvdMDSync) &&
					IS_PORTOK(pstPortData))
				{
					enEvt = EV_PSSR_1588_FOR_PSSR_RCVMDSYNC;
				}
			}
			else if (pstPSSRGlb->enStatusPSSR_1588 == ST_PSSR_1588_RECEIVED_SYNC)
			{
				if ((pstPSSRGlb->blRcvdMDSync) &&
					IS_PORTOK(pstPortData) &&
					(!(pstPortData->stPort_GD.blAsymmetryMeasurementMode)))
				{
					enEvt = EV_PSSR_1588_FOR_PSSR_RCVMDSYNC;
				}
			}
			else
			{
			}
		break;

		case PTP_EV_CLOSE:
			enEvt = EV_PSSR_1588_CLOSE;
			break;

		default:
			enEvt = EV_PSSR_1588_EVENT_MAX;
		break;
	}

	return	enEvt;
}




BOOL	IsPSSReceiveSM_1588_Status(
	PORTDATA*	pstPortData)
{
	PSSRECEIVESM_1588_GD*	pstPSSRGlb	= GetPSSReceiveSM_1588_GD(pstPortData);
	BOOL					blRet			= FALSE;


	if (pstPSSRGlb->enStatusPSSR_1588 < ST_PSSR_1588_MAX)
	{
		blRet = TRUE;
	}
	return blRet;
}





VOID	PSSReceive_1588_00(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1588_GD*	pstPSSRGlb = GetPSSReceiveSM_1588_GD(pstPortData);

    ptp_dbg_msg( D_FUNC, 
    			 ("%s::domain=[%d],port=[%d}\n", 
                  "PSSReceive_1588_00+",
					 pstPortData->pstClockData->stDefaultDS.uchDomainNumber,
					 pstPortData->stPortDS.stPortIdentity.usPortNumber
                  ) );

	pstPSSRGlb->blRcvdMDSync		= FALSE;
	pstPSSRGlb->enStatusPSSR_1588	= ST_PSSR_1588_NONE;

	ptp_dbg_msg( D_FUNC, ("PSSReceive_1588_00::-\n") );
}




VOID	PSSReceive_1588_01(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1588_GD*	pstPSSRGlb = GetPSSReceiveSM_1588_GD(pstPortData);


	pstPSSRGlb->blRcvdMDSync		= FALSE;
	pstPSSRGlb->enStatusPSSR_1588	= ST_PSSR_1588_DISCARD;
}




VOID	PSSReceive_1588_02(
	PORTDATA*		pstPortData)
{
	PSSRECEIVESM_1588_GD*	pstPSSRGlb							= GetPSSReceiveSM_1588_GD(pstPortData);
	MDSYNCRECEIVE*			pstRcvdMDSyncPtr					= &(pstPortData->stPort_GD.stMdSyncReceive);
	CLOCKDATA*				pstClockData						= pstPortData->pstClockData;
	USCALEDNS				stA_USNs							= {0};
	USCALEDNS				stSReceiptTimeoutTimeInterval		= {0};
	ULONG					ulC_msb								= 0;
	ULONG					ulC_lsb								= 0;
	CHAR					chA									= 0;
	DOUBLE					dbRate_W							= DBCONST1_0;

	ptp_dbg_msg(D_FUNC, ("PSSReceive_1588_02::+\n"));

	pstPSSRGlb->blRcvdMDSync	= FALSE;
	pstPSSRGlb->pstRcvdMDSyncPtr = pstRcvdMDSyncPtr;


	if ((pstRcvdMDSyncPtr->dbRateRatio > DBCONST_RATE_MIN) &&
		(pstRcvdMDSyncPtr->dbRateRatio < DBCONST_RATE_MAX))
	{
#ifdef	PTP_USE_ME_HW_ASSIST
		dbRate_W = 1.0 / pstRcvdMDSyncPtr->dbRateRatio;
#else
		dbRate_W = pstClockData->stClock_GD.dbRateRatio + (DBCONST1_0 - pstRcvdMDSyncPtr->dbRateRatio);
#endif
		if ((dbRate_W > DBCONST_RATE_MIN) &&
			(dbRate_W < DBCONST_RATE_MAX))
		{
			pstClockData->stClock_GD.dbRateRatio = dbRate_W;
		}
		else
		{
			PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_84000006);
		}
	}
	else
	{
		PTP_WARNING_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_84000006);
	}


	pstClockData->stParent_1AS_DS.lCumulativeRateRatio
		= (LONG)((pstClockData->stClock_GD.dbRateRatio - DBCONST1_0)
				* DBCONST2_41);


	(VOID)ptpMultUL_UL((ULONG)(pstPortData->stPort_1AS_DS.uchSyncReceiptTimeout + 1),
						(ULONG)CONST10_9,
						&ulC_msb,
						&ulC_lsb);
	stA_USNs.usFrcNsec	= (USHORT)(ulC_lsb & UL_MASK_0000FFFF);
	stA_USNs.ulNsec_lsb	= ((ulC_msb & UL_MASK_0000FFFF) << CONS_SHIFT16) + (ulC_lsb >> CONS_SHIFT16);
	stA_USNs.ulNsec_2nd = (ulC_msb >> CONS_SHIFT16);

	chA = CONS_SHIFT16 + pstRcvdMDSyncPtr->chLogMessageInterval;

	(VOID)ptpShiftUSNs_CHAR(&stA_USNs,
								chA,
								&stSReceiptTimeoutTimeInterval);

	pstPSSRGlb->pstTxPSSyncPtr = setPSSyncPSSR(pstRcvdMDSyncPtr,
												pstPortData,
												&stSReceiptTimeoutTimeInterval,
												pstClockData->stClock_GD.dbRateRatio);

	if (pstPSSRGlb->pstTxPSSyncPtr != NULL)
	{
		if (   IS_OD_BC_1588(pstClockData) 
		    && (pstPortData->stPort_1588_GD.pstCmldsPortDs->blCmldsPortEnabled == FALSE) )
		{
			ptp_dbg_msg(D_DBG, ("[E2E]\n"));

			if ((pstClockData->stClock_GD.enSelectedState[pstPortData->stPort_GD.usThisPort] == ENUM_PORTSTATE_SLAVE) ||
				(pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stBMC_1588_GD.uchExtSelectedState[pstPortData->stPort_GD.usThisPort]
																												== (UCHAR)PS_EX_UNCALIBRATED))
			{
				calcPDRSRDelayTime_PSSR(pstPortData);

				pstPSSRGlb->pstTxPSSyncBCSS = setPSSyncToBCSS_1588(pstPSSRGlb->pstTxPSSyncPtr,
																	pstPortData);
			}
		}
		else
		{
			ptp_dbg_msg(D_DBG, ("[P2P]\n"));
			if ((IS_TIMESTAMP_0(pstPortData->stPort_GD.stPdlyRespReceiveTime)) ||
				(IS_TIMESTAMP_0(pstPortData->stPort_GD.stPdlyReqSendtime)) ||
				(IS_TIMESTAMP_0(pstPortData->stPort_GD.stPdlyRespFupReqRecpTimeStamp)) ||
				(IS_TIMESTAMP_0(pstPortData->stPort_GD.stPdlyRespReqRecpTimeStamp)))
			{
				PTP_NOTICE_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_84000001);
			}
			setDelayInfo_P2P_1588(pstPortData);
		}
		txPSSyncPSSR_1588(pstPSSRGlb->pstTxPSSyncPtr,
							pstPortData);

		if (pstClockData->stClock_GD.ulME_extend & USE_ME_EXTEND_1588_SYNC_LOCKED)
		{
			if (!(pstClockData->stClock_GD.enSelectedState[0] == ENUM_PORTSTATE_SLAVE))
			{
				pstClockData->stUn_CSM_GD.stCsm1588_GD.stBCSSendSM_1588_GD.blSyncSendTime = TRUE;
				boundaryClockSyncSend_1588(PTP_EV_SYNC_SENDTIME_1588, pstClockData);
			}
		}

	}

	pstPSSRGlb->enStatusPSSR_1588	= ST_PSSR_1588_RECEIVED_SYNC;

	ptp_dbg_msg(D_FUNC, ("PSSReceive_1588_02::-\n"));
}




PORTSYNCSYNC*  setPSSyncPSSR(
	MDSYNCRECEIVE*	pstRcvdMDSyncPtr,
	PORTDATA*		pstPortData,
	USCALEDNS*		pstSyncReceiptTTimeInterval,
	DOUBLE			dbRateRatio)
{
	CLOCKDATA*				pstClockData	= pstPortData->pstClockData;
	PORTSYNCSYNC*			pstTxPSSyncPtr	= NULL;
	USCALEDNS				stUSNs			= {0};
	BOOL					blRet			= FALSE;
	USCALEDNS		stCurrentTime	= {0};


	ptp_GetCurrentTime(pstClockData, &stCurrentTime);

	pstTxPSSyncPtr	= &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.stRcvdPSSyncDat);
	pstTxPSSyncPtr->uchClockNumber				= pstRcvdMDSyncPtr->uchClockNumber;
	pstTxPSSyncPtr->usLocalPortNumber			= pstPortData->stPort_GD.usThisPort;
	pstTxPSSyncPtr->stFollowUpCorrectionField	= pstRcvdMDSyncPtr->stFollowUpCorrectionField;
	pstTxPSSyncPtr->stSourcePortIdentity		= pstRcvdMDSyncPtr->stSourcePortIdentity;
	pstTxPSSyncPtr->chLogMessageInterval		= pstRcvdMDSyncPtr->chLogMessageInterval;
	pstTxPSSyncPtr->stPreciseOriginTimestamp	= pstRcvdMDSyncPtr->stPreciseOriginTimestamp;
	pstTxPSSyncPtr->stUpstreamTxTime			= pstRcvdMDSyncPtr->stUpstreamTxTime;
	pstTxPSSyncPtr->dbRateRatio 				= dbRateRatio;
 	pstTxPSSyncPtr->usGmTimeBaseIndicator 		= pstRcvdMDSyncPtr->usGmTimeBaseIndicator;
	pstTxPSSyncPtr->stLastGmPhaseChange 		= pstRcvdMDSyncPtr->stLastGmPhaseChange;
	pstTxPSSyncPtr->dbLastGmFreqChange 			= pstRcvdMDSyncPtr->dbLastGmFreqChange;

	blRet = ptpAddUSNs_USNs(&stCurrentTime,
							 pstSyncReceiptTTimeInterval,
							 &stUSNs);
	if (blRet == FALSE)
	{
		PTP_ERROR_LOGRECORD(pstClockData, PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_OVERFLOW);
		return NULL;
	}
	pstTxPSSyncPtr->stSyncReceiptTimeoutTime = stUSNs;

	return pstTxPSSyncPtr;

}




PORTSYNCSYNC*  setPSSyncToBCSS_1588(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	PORTDATA*		pstPortData)
{
	BCSSENDSM_1588_GD*		pstBCSSendSM_1588_GD	= &(pstPortData->pstClockData->stUn_CSM_GD.
																		stCsm1588_GD.stBCSSendSM_1588_GD);
	PORTSYNCSYNC*			pstTxPSSyncBCSS			= NULL;


	pstTxPSSyncBCSS = &(pstBCSSendSM_1588_GD->stRcvdPSSync);
	(*pstTxPSSyncBCSS) = *pstTxPSSyncPtr;

	pstBCSSendSM_1588_GD->blRcvdPSSync = TRUE;

	return pstTxPSSyncBCSS;

}




VOID  txPSSyncPSSR_1588(
	PORTSYNCSYNC*	pstTxPSSyncPtr,
	PORTDATA*		pstPortData)
{
	USHORT				usEvent			= PTP_EV_BASE;
	CLOCKDATA*			pstClockData	= pstPortData->pstClockData;
	SSSYNCSM_1588_GD*	pstSSS_1588_GD	= NULL;


	pstSSS_1588_GD = &(pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD);

	if (IS_OD_BC_1588(pstClockData))
	{
		pstSSS_1588_GD->pstRcvdPSSyncPtr	= pstTxPSSyncPtr;
		pstSSS_1588_GD->blRcvdPSSync_1588	= TRUE;

	}
	else
	{
		pstSSS_1588_GD->pstRcvdPSSyncPtr	= pstTxPSSyncPtr;
		pstSSS_1588_GD->blRcvdPSSync		= TRUE;

	}
	usEvent = PTP_EV_FOR_STSYNSYN_RCVSYNC;
	siteSyncSync_1588(usEvent, pstClockData);

}




VOID	calcPDRSRDelayTime_PSSR(
	PORTDATA*		pstPortData)
{
	SCALEDNS				stA_SNs				= {0};
	SCALEDNS				stB_SNs				= {0};
	SCALEDNS				stD_SNs				= {0};
	EXTENDEDTIMESTAMP		stT1_ETS			= {0};
	EXTENDEDTIMESTAMP		stT4_ETS			= {0};
#ifndef	PTP_USE_ME_HW_ASSIST
	EXTENDEDTIMESTAMP		stT3_ETS			= {0};
	EXTENDEDTIMESTAMP		stT2_ETS			= {0};
#endif

	PORTSYNCSYNC*		pstTxPSSyncPtr	= &(pstPortData->pstClockData->stUn_CSM_GD.stCsm1588_GD.stSSSyncSM_1588_GD.stRcvdPSSyncDat);

#ifdef	PTP_USE_ME_HW_ASSIST
	USCALEDNS				stE_USNs			= {0};
	USCALEDNS				stF_USNs			= {0};
	TIME_INTERVAL			stTInttemp			= {0};
	TIME_INTERVAL			stTInttemp1			= {0};

	BOOL					blRet				= TRUE;
#endif


	CHAR					chCmpAB;
	USCALEDNS				stTemp_UNs;

	if ((IS_TIMESTAMP_0(pstPortData->stPort_GD.stDelayReqEgressTimestamp)) ||
		(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventEgressTimestamp)) ||
		(IS_TIMESTAMP_0(pstPortData->stPort_GD.stDelayReqIngressTimestamp)) ||
		(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventIngressTimestamp)))
	{
		PTP_NOTICE_LOGRECORD((pstPortData->pstClockData), PTP_LOG_PDRSRECEIVESM_1588, PTP_LOGVE_84000001);
		if ((IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventEgressTimestamp) == FALSE) &&
			(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventIngressTimestamp) == FALSE))
		{
			pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncOriginTimeStamp = 
																	pstPortData->stPort_GD.stSyncEventEgressTimestamp;
			pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncCorrectionField	=
																	pstPortData->stPort_GD.stSyncCorrectionField;
			pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncReceiveTime =
																	pstPortData->stPort_GD.stSyncEventIngressTimestamp;
		}
	}
	else
	{
#ifndef	PTP_USE_ME_HW_ASSIST
		(VOID)ptpAddTS_SNs(&(pstPortData->stPort_GD.stSyncEventEgressTimestamp),
							&(pstTxPSSyncPtr->stFollowUpCorrectionField),
							&stT1_ETS);
		SET_ETIMESTAMP(stT4_ETS,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.stSeconds.usSec_msb,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.stSeconds.ulSec_lsb,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.ulNanoseconds,
						0);
		(VOID)ptpSubETS_ETS(&stT4_ETS,
								&stT1_ETS,
								&stA_SNs);

		(VOID)ptpAddTS_TInt(&(pstPortData->stPort_GD.stDelayReqEgressTimestamp),
							&(pstPortData->stPort_GD.stDelayRespCorrectionField),
							&stT3_ETS);
		SET_ETIMESTAMP(stT2_ETS,
						pstPortData->stPort_GD.stSyncEventIngressTimestamp.stSeconds.usSec_msb,
						pstPortData->stPort_GD.stSyncEventIngressTimestamp.stSeconds.ulSec_lsb,
						pstPortData->stPort_GD.stSyncEventIngressTimestamp.ulNanoseconds,
						0);

		(VOID)ptpSubETS_ETS(&stT3_ETS,
								&stT2_ETS,
								&stB_SNs);

		(VOID)ptpSubSNs_SNs(&stA_SNs,
								&stB_SNs,
								&stD_SNs);
#else
		blRet = ptpAddTS_SNs(&(pstPortData->stPort_GD.stSyncEventEgressTimestamp),
							&(pstTxPSSyncPtr->stFollowUpCorrectionField),
							&stT1_ETS);
		SET_ETIMESTAMP(stT4_ETS,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.stSeconds.usSec_msb,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.stSeconds.ulSec_lsb,
						pstPortData->stPort_GD.stDelayReqIngressTimestamp.ulNanoseconds,
						0);
		blRet &= ptpSubETS_ETS(&stT4_ETS,
								&stT1_ETS,
								&stA_SNs);

		blRet &= ptpConvTS_USNs(&pstPortData->stPort_GD.stSyncEventIngressTimestamp_Frun, 
																				&stE_USNs);

		blRet &= ptpConvTS_USNs(&pstPortData->stPort_GD.stDelayReqEgressTimestamp, 
																			&stF_USNs);

		blRet &= ptpSubUSNs_USNs(&stF_USNs, &stE_USNs, &stB_SNs);

		blRet &= ptpDivSNs_Doub(&stB_SNs, pstPortData->stMDSReceiveSM_GD.dbCmptRatio, &stD_SNs);

		blRet &= ptpSubSNs_SNs(&stA_SNs, &stD_SNs, &stB_SNs);

		blRet &= ptpConvSNs_TInt(&stB_SNs, &stTInttemp);

		blRet &= ptpSubTInt_TInt(&stTInttemp, &(pstPortData->stPort_GD.stDelayRespCorrectionField), &stTInttemp1);

		stTInttemp.sNsec_msb = 0;
		stTInttemp.ulNsec_lsb = 0;
		stTInttemp.usFrcNsec = 0;

		blRet &= ptpAddTInt_TInt(&stTInttemp1, &stTInttemp, &stD_SNs);

		if (blRet != TRUE)
		{
			PTP_ERROR_LOGRECORD(pstPortData->pstClockData, PTP_LOG_PSSRECEIVESM_1588, PTP_LOGVE_OVERFLOW);
		}

#endif
		if (stD_SNs.sNsec_msb < 0)
		{
			if ((IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventEgressTimestamp) == FALSE) &&
				(IS_TIMESTAMP_0(pstPortData->stPort_GD.stSyncEventIngressTimestamp) == FALSE))
			{
				pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncOriginTimeStamp = 
																		pstPortData->stPort_GD.stSyncEventEgressTimestamp;
				pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncCorrectionField	=
																		pstPortData->stPort_GD.stSyncCorrectionField;
				pstPortData->pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E.stSyncReceiveTime =
																		pstPortData->stPort_GD.stSyncEventIngressTimestamp;
			}
			return;
		}

		setDelayInfo_E2E_1588(pstPortData);

		(VOID)ptpShiftSNs_CHAR(&stD_SNs,
								CHSHIFT_m1,
								&(pstPortData->stPort_GD.stD3_DelayTime));


		chCmpAB = ptpCompUSNs_SNs(&pstPortData->pstClockData->stClock_GD.stAveDelayTrash, &(pstPortData->stPort_GD.stD3_DelayTime));
		if (chCmpAB != COMP_A_LESS)
		{

			if (pstPortData->stPort_GD.ulPropDelayNumber == 0)
			{
			ptpConvSNs_USNs (&pstPortData->stPort_GD.stD3_DelayTime, &pstPortData->stPort_GD.stAveDelayTime);
			ptpConvSNs_TInt (&pstPortData->stPort_GD.stD3_DelayTime, &pstPortData->pstClockData->stCurrent_1588_DS.stMeanPathDelay);

				pstPortData->stPort_GD.ulPropDelayNumber ++;
			}
			else
			{
				ptpAddUSNs_SNs(&pstPortData->stPort_GD.stAveDelayTime, &pstPortData->stPort_GD.stD3_DelayTime, &stTemp_UNs);
				ptpShiftUSNs_CHAR(&stTemp_UNs, (CHAR)-1, &pstPortData->stPort_GD.stAveDelayTime);
				ptpConvUSNs_SNs(&pstPortData->stPort_GD.stAveDelayTime, &stD_SNs);
				ptpConvSNs_TInt(&stD_SNs, &pstPortData->pstClockData->stCurrent_1588_DS.stMeanPathDelay);
				ptpConvUSNs_SNs(&pstPortData->stPort_GD.stAveDelayTime, &pstPortData->stPort_GD.stD3_DelayTime);

				if ((pstPortData->stPort_GD.ulPropDelayNumber + 1) != 0)
				{
					pstPortData->stPort_GD.ulPropDelayNumber ++;
				}
			}


		}
		else
		{
			ptpConvUSNs_SNs(&pstPortData->stPort_GD.stAveDelayTime, &pstPortData->stPort_GD.stD3_DelayTime);

		}

	}
}




VOID  setDelayInfo_P2P_1588(
	PORTDATA*		pstPortData)
{
	CLOCKDATA*			pstClockData		= pstPortData->pstClockData;
	DELAYINFO_P2P*		pstDelayInfo_P2P	= NULL;


	pstDelayInfo_P2P = &(pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_P2P);

	pstDelayInfo_P2P->stSyncOriginTimeStamp			= pstPortData->stPort_GD.stSyncEventEgressTimestamp;
	pstDelayInfo_P2P->stSyncCorrectionField			= pstPortData->stPort_GD.stSyncCorrectionField;
	pstDelayInfo_P2P->stSyncReceiveTime				= pstPortData->stPort_GD.stSyncEventIngressTimestamp;

	pstDelayInfo_P2P->stPdlyReqSendtime				= pstPortData->stPort_GD.stPdlyReqSendtime;
	pstDelayInfo_P2P->stPdlyRespReqRecpTimeStamp	= pstPortData->stPort_GD.stPdlyRespReqRecpTimeStamp;
	pstDelayInfo_P2P->stPdlyRespCorrectionField		= pstPortData->stPort_GD.stPdlyRespCorrectionField;
	pstDelayInfo_P2P->stPdlyRespFupReqRecpTimeStamp	= pstPortData->stPort_GD.stPdlyRespFupReqRecpTimeStamp;
	pstDelayInfo_P2P->stPdlyRespFupCorrectionField	= pstPortData->stPort_GD.stPdlyRespFupCorrectionField;
	pstDelayInfo_P2P->stPdlyRespReceiveTime			= pstPortData->stPort_GD.stPdlyRespReceiveTime;

	pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_P2P;

}




VOID  setDelayInfo_E2E_1588(
	PORTDATA*		pstPortData)
{
	CLOCKDATA*			pstClockData		= pstPortData->pstClockData;
	DELAYINFO_E2E*		pstDelayInfo_E2E	= NULL;


	pstDelayInfo_E2E = &(pstClockData->stClock_GD.stDelayInfo.stDelayTimeInfo.stDelayInfo_E2E);

	pstDelayInfo_E2E->stSyncOriginTimeStamp			= pstPortData->stPort_GD.stSyncEventEgressTimestamp;
	pstDelayInfo_E2E->stSyncCorrectionField			= pstPortData->stPort_GD.stSyncCorrectionField;
	pstDelayInfo_E2E->stSyncReceiveTime				= pstPortData->stPort_GD.stSyncEventIngressTimestamp;

	pstDelayInfo_E2E->stDelayReqSendTime			= pstPortData->stPort_GD.stDelayReqEgressTimestamp;
	pstDelayInfo_E2E->stDelayRespOriginTime			= pstPortData->stPort_GD.stDelayReqIngressTimestamp;
	pstDelayInfo_E2E->stDelayRespCorrectionField	= pstPortData->stPort_GD.stDelayRespCorrectionField;

	pstClockData->stClock_GD.stDelayInfo.enClockDelay = DELAY_E2E;

}




#endif

