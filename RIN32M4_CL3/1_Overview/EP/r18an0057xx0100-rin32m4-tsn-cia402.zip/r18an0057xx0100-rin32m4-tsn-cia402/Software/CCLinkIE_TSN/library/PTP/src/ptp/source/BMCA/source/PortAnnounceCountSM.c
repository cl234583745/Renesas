/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "ptp_Struct_Clock.h"
#include "ptp_Struct_Port.h"
#include "ptp_CMSReceive.h"
#include "ptp_CommonFunction.h"

#include "PortAnnounceCountSM.h"

VOID	IncPortAnnGmChangeCount(PORTDATA *pstPort)
{
#ifdef	PTP_USE_GM
	CURRENT_1AS_DS*	pstCrnt_1AS_DS = &pstPort->pstClockData->stCurrent_1AS_DS;
	pstCrnt_1AS_DS->ulGmChangeCount++;
#endif
}

VOID	IncPortAnnTimOfLstGmChgEvt(PORTDATA *pstPort)
{
#ifdef	PTP_USE_GM
	CURRENT_1AS_DS*		pstCrnt_1AS_DS	= &pstPort->pstClockData->stCurrent_1AS_DS;
	EXTENDEDTIMESTAMP	stMasterTime	= {0};
	
	ptp_GetMasterTime(pstPort->pstClockData, &stMasterTime);
	pstCrnt_1AS_DS->ulTimeOfLastGmChangeEvent = CalcPortAnnOneHundEtsLong(&stMasterTime);
#endif
}

VOID	IncPortAnnTimOfLstGmPhaseChgEvt(PORTDATA *pstPort)
{
#ifdef	PTP_USE_GM
	CURRENT_1AS_DS*		pstCrnt_1AS_DS	= &pstPort->pstClockData->stCurrent_1AS_DS;
	EXTENDEDTIMESTAMP	stMasterTime	= {0};
	
	ptp_GetMasterTime(pstPort->pstClockData, &stMasterTime);
	pstCrnt_1AS_DS->ulTimeOfLastGmPhaseChangeEvent = CalcPortAnnOneHundEtsLong(&stMasterTime);
#endif
}

VOID	IncPortAnnTimOfLstGmFreqChgEvt(PORTDATA *pstPort)
{
#ifdef	PTP_USE_GM
	CURRENT_1AS_DS*		pstCrnt_1AS_DS	= &pstPort->pstClockData->stCurrent_1AS_DS;
	EXTENDEDTIMESTAMP	stMasterTime	= {0};
	
	ptp_GetMasterTime(pstPort->pstClockData, &stMasterTime);
	pstCrnt_1AS_DS->ulTimeOfLastGmFreqChangeEvent = CalcPortAnnOneHundEtsLong(&stMasterTime);
#endif
}

VOID	IncPortAnnRxAnnounceCount(PORTDATA *pstPort)
{
	PORTSTATISTICS_1AS_DS*	pstPortStat_AS_DS = &pstPort->stPortStatistics_1AS_DS;
	pstPortStat_AS_DS->ulRxAnnounceCount++;
}

VOID	IncPortAnnRxPTPPktDiscardCnt(PORTDATA *pstPort)
{
	PORTSTATISTICS_1AS_DS*	pstPortStat_AS_DS = &pstPort->stPortStatistics_1AS_DS;
	pstPortStat_AS_DS->ulRxPTPPacketDiscardCount++;
}

VOID	IncPortAnnReceiptTimeoutCount(PAINFORMATIONSM_EV enEvent, PORTDATA *pstPort)
{
	PORTSTATISTICS_1AS_DS*	pstPortStat_AS_DS = &pstPort->stPortStatistics_1AS_DS;

	if (enEvent == PINF_EV_ANNOUNCERECEIPTTIMEOUT)
	{
		pstPortStat_AS_DS->ulAnnounceReceiptTimeoutCount++;
	}
	if (enEvent == PINF_EV_SYNCRECEIPTTIMEOUT)
	{
		pstPortStat_AS_DS->ulSyncReceiptTimeoutCount++;
	}
}

VOID	IncPortAnnTxAnnounceCount(PORTDATA *pstPort)
{
	PORTSTATISTICS_1AS_DS*	pstPortStat_AS_DS = &pstPort->stPortStatistics_1AS_DS;
	pstPortStat_AS_DS->ulTxAnnounceCount++;
}


ULONG	CalcPortAnnOneHundEtsLong(EXTENDEDTIMESTAMP* pstA_ETimestamp)
{
	ULONG	ulAnsTime;
	ULONG	LSec	= pstA_ETimestamp->stSec.ulSec_lsb;
	ULONG	ulNsec	= pstA_ETimestamp->stNsec.ulNsec;

	ulAnsTime =  (LSec * CONST10_2) + (ulNsec / CONST10_7);
	return ulAnsTime;
}
