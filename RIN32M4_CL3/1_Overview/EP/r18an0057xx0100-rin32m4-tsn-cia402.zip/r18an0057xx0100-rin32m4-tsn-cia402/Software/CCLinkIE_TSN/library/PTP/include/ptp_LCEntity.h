/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __PTP_LCENTITY_H__
#define __PTP_LCENTITY_H__

#include "ptp_System.h"
#include "ptp_type.h"
#include "ptp_ddt.h"




#ifdef __cplusplus
extern "C" {
#endif

VOID	localClockEntity(USHORT usEvent, CLOCKDATA*	pstClockData);

VOID	ptp_updateLCETime(CLOCKDATA*	pstClockData);
LONG	ptp_TimerSemLockWait(VOID);
LONG	ptp_TimerSemLock(VOID);
LONG	ptp_TimerSemUnLock(VOID);
VOID	ptp_GetCurrentTime(CLOCKDATA*	pstClockData, USCALEDNS*	pstCurrentTime);
VOID	ptp_GetCurrentMasterTime(CLOCKDATA*	pstClockData, USCALEDNS*	pstCurrentMasterTime);
VOID	ptp_GetCurrentMasterTime2(CLOCKDATA*	pstClockData, USCALEDNS*	pstCurrentMasterTime, USCALEDNS*	pstDetailCurTime);
VOID	ptp_SetCurrentMasterTime(CLOCKDATA*	pstClockData, SCALEDNS*	pstCMPhaseOffset, USCALEDNS*	pstNewCurrentMasterTime);
VOID	ptp_GetCurrentDriverTime(UCHAR	uchClockNumber, EXTENDEDTIMESTAMP*	pstCurrentDriverTime);
VOID	ptp_chkCurrentTimeTimeout(CLOCKDATA*	pstClockData);
TMO_MANAGE_INF_BLK*	ptp_TimeOut_Req(
	USHORT		usEvent,
	VOID*		pvParam,
	USCALEDNS	stTimeoutTime,
	CallBackFunc	pfnCallBack);
USHORT	ptp_TimeOut_Can(TMO_MANAGE_INF_BLK*	pstTmoMan_cansel);

#ifdef __cplusplus
}
#endif


#endif


