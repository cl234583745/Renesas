//============================================
//      Copyright (C) 2003 By
//
//      Lantronix, Inc.
//      15353 Barranca Parkway
//      Irvine, California 92618, USA
//
//      Nissin Systems Co.,Ltd.
//      Horikawa-dori Shijyo Sagaru Higashigawa
//      Shimogyo-ku, Kyoto, Japan
//============================================
//      Copyright (C) 2019 By
//
//      MITSUBISHI ELECTRIC CORPORATION.
//============================================

#include <string.h>
#include "snmpv3.h"


sint16 snmpReadLength(const uint8 **pp, uint16 type)
{
    const uint8 *p;
    sint16 len, i1;

    p = *pp;
    if (*p++ != type)
        return -1;

    len = *p++;
    if (len & 0x80)
    {
        i1 = len & 0x7f;
        if (i1 == 0 || i1 > (sint16)sizeof(sint16))
            return -1;
        for (len = 0; i1--; )
            len = (len << 8) | (*p++);
    }
    *pp = p;

    return len;
}


sint16 snmpReadInt(uint32 *outp, sint16 olen, const uint8 **inp, uint16 type)
{
    const uint8 *p;
    sint16 i1, len, sign;
    uint32 ul1;

    ul1 = 0;
    len = snmpReadLength(inp, type);
    if (len >= 0 && len <= olen + 1)
    {
        p = *inp;
        sign = *p >> 7;
        for (i1 = len; i1; i1--)
            ul1 = (ul1 << 8) + *p++;
        *inp = p;
        if (type == Integer && sign && len)
            ul1 |= 0xffffffff << (8 * len);
    }
    *outp = ul1;

    return len;
}


sint16 snmpReadVal(uint8 *outp, sint16 olen, const uint8 **inp, uint16 type)
{
    sint16 len;

    len = snmpReadLength(inp, type);
    if (len >= 0 && len <= olen)
    {
        memcpy(outp, *inp, len);
        *inp += len;
    }

    return len;
}


void snmpRWriteLength(uint8 **pp, uint16 type, sint16 len)
{
    uint8 *p = *pp;
    sint16 i1;

    if (len > 0x7f)
    {
        i1 = (len > 255) ? 2 : 1;
        if (i1 == 2)
        {
            *--p = len;
            len >>= 8;
        }
        *--p = len;
        *--p = i1 | 0x80;
    }
    else
        *--p = len;

    *--p = type;
    *pp = p;
}


void snmpRWriteInt(uint8 **pp, uint32 val, uint16 type, sint16 len)
{
    uint8 *p;
    sint16 i1, nn;

    p = *pp;

    nn = 1;

    if (type == Integer)
    {
        i1 = len - 1;
        if ((val >> i1 * 8) & 0x80) {
            for (i1 = len - 1; i1 > 0; i1--)
                if ((uint8)(val >> i1 * 8) == 0xff && val >> 8 * (i1 - 1) & 0x80)
                    len--;
                else
                    break;
            nn = 0;
        }
    }

    i1 = len;
    do
    {
        *--p = (uint8)val;
        val >>= 8;
        i1--;
    }
    while ((val && i1 > 0) || (nn && *p & 0x80));
    *pp = p;

    snmpRWriteLength(pp, type, len - i1);
}


void snmpRWriteVal(uint8 **pp, const uint8 *vp, uint16 type, sint16 len)
{
    uint8 *p;
    sint16 i1;

    p = *pp;
    for (i1 = len, vp += len; i1; i1--)
        *--p = *--vp;
    *pp = p;

    snmpRWriteLength(pp, type, len);
}


sint32 snmpVCompare(const uint8 *op1, sint16 len1,
    const uint8 *op2, sint16 len2)
{
    sint16 i1, len;
    sint32 cmp;

    len = (len1 > len2) ? len2 : len1;

    for (i1 = 0, cmp = 0; i1 < len && cmp == 0; i1++)
        cmp = *op1++ - *op2++;

    cmp <<= 16;
    if (len - i1)
#if 1
        cmp |= (len - i1) << 24;
#else
        cmp *= len - i1;
#endif

    cmp += len1;
    cmp -= len2;

    return cmp;
}


sint32 snmpFindOID(const uint8 **retp, const uint8 *base, sint16 osize,
    sint16 onum, const uint8 *valp, sint16 vlen)
{
    const uint8 *low, *high, *mid;
    sint32 r;

    low = base;
    mid = high = base + (onum - 1) * osize;

    while (low <= high)
    {
        r = snmpVCompare(valp, vlen, ((OID *)mid)->name, ((OID *)mid)->nlen);

        if (r == 0)
            break;
        else if (r < 0)
            high = mid - osize;
        else
            low = mid + osize;

        if (low <= high)
            mid = low + (((high - low) / osize) / 2) * osize;
    }

    if (high < base)
        mid = 0;
    else
    {
        if (r < 0)
        {
            mid -= osize;
            if (mid < base)
                mid = 0;
            else
                r = snmpVCompare(valp, vlen,
                        ((OID *)mid)->name, ((OID *)mid)->nlen);
        }
    }

    *retp = mid;
    return r;
}


uint32 snmpDecodeID(const uint8 **inp)
{
    const uint8 *p;
    uint32 val;

    p = *inp;
    val = 0;
    while (*p & 0x80)
        val = (val << 7) | (*p++ & 0x7f);
    val = (val << 7) |  *p++;
    *inp = p;

    return val;
}


void snmpEncodeID(uint8 **pp, sint16 olen, uint32 val)
{
    uint8 *p;

    p = *pp;
    while (olen--)
    {
        *--p = val | 0x80;
        val >>= 7;
        if (val == 0)
            break;
    }
    *(*pp - 1) &= ~0x80;
    *pp = p;
}


void snmpEncodeIndex(uint8 **pp, const MIB *mibp, const MIBTAB *mtp,
    sint16 tabix)
{
    const MIBVAR *mvp;
    uint8 *p, *vptr;
    uint32 ul1;
    sint16 i1, i2;

    p = *pp;
    for (i1 = mtp->nix; i1; i1--)
    {
        mvp = &mibp->mvp[mtp->ix[i1 - 1]];
        if (mvp->opt & SX)
        {
            if(1 + tabix > 127)
                snmpEncodeID(&p, 2, 1 + tabix);
            else
                snmpEncodeID(&p, 1, 1 + tabix);
        }
        else
        {
            vptr = (uint8 *)mvp->ptr;

            if ((mvp->opt & SCALAR) == 0)
                vptr += mtp->len * tabix;

            if (mvp->opt & CAR)
                mibp->get(mvp - mibp->mvp, tabix, &vptr);

            if ((mvp->opt & BASE1) == BASE1)
                snmpEncodeID(&p, 1, (*vptr) + 1);
            else if (mvp->type == Integer)
            {
                ul1 = 0;
#ifdef LITTLE
                if ((mvp->opt & NWORDER) == 0)
                {
                    switch (mvp->len)
                    {
                        case 1:
                            ul1 = *(uint8 *)vptr;
                            break;
                        case 2:
                            ul1 = *(uint16 *)vptr;
                            break;
                        case 4:
                            ul1 = *(uint32 *)vptr;
                            break;
                        default:
                            break;
                    }
                }
                else
#endif
                {
                    for (i2 = mvp->len; i2; i2--)
                        ul1 = (ul1 << 8) + *vptr++;
                }
                snmpEncodeID(&p, mvp->len + 1, ul1);
            }
            else
                for (i2 = mvp->len - 1; i2 >= 0; i2--)
                    snmpEncodeID(&p, 2, vptr[i2]);
        }

#if CHOICE
        if (mvp->opt & CHOICE)
            snmpEncodeID(&p, 1, 1);
#endif
    }
    *pp = p;
}


sint32 snmpFindIndex(sint16 *tabixp, const MIBTAB *mtp,
    const MIB *mibp, const MIBVAR *mvp,
    const uint8 *reqixname, uint8 reqixlen, uint8 nflag)
{
    uint8 *cp, *cp2;
    sint32 sl1, sl2, sl3;
    sint16 i1, i3;
    uint8 ixname[MAXKLEN], bixname[MAXKLEN];

    *tabixp = -1;
    sl2 = 0x7fffffff;

    for (i1 = 0; ; i1++)
    {
        i3 = mibp->index(mvp - mibp->mvp, i1);
        if (i3 < 0)
            break;
        if (i3 == 0)
            continue;

        cp = ixname + MAXKLEN;
        snmpEncodeIndex(&cp, mibp, mtp, i1);

        sl1 = snmpVCompare(cp, (const uint8 *)&ixname[MAXKLEN] - cp,
                           reqixname, reqixlen);

        if (sl1 >= (sint32)nflag)
        {
            if (*tabixp != -1 && nflag != 0 && (sl1 < 255 || sl1 == sl2))
            {
                cp2 = bixname + MAXKLEN;
                snmpEncodeIndex(&cp2, mibp, mtp, *tabixp);
                sl3 = snmpVCompare(cp, (const uint8 *)&ixname[MAXKLEN] - cp,
                                   cp2, (const uint8 *)&bixname[MAXKLEN] - cp2);
                if (sl3 < 0)
                {
                    *tabixp = i1;
                    sl2 = sl1;
                }
            }
            else if (sl1 < sl2)
            {
                *tabixp = i1;
                sl2 = sl1;
            }
        }
    }

    return sl2;
}

