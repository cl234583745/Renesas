/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __TXN_BUF_H_INCLUDE__
#define __TXN_BUF_H_INCLUDE__
#include "nx_common.h"
#include "TXN_api.h"

#define	BUFFID_NCYC_TX_BUF_SYNC_S	(0x0000 << 12 |	0x0000 << 8	| 0x0000 )
#define	BUFFID_NCYC_TX_BUF_SYNC_L	(0x0000 << 12 |	0x0001 << 8	| 0x0000 )
#define	BUFFID_NCYC_TX_BUF_S		(0x0001 << 12 |	0x0000 << 8	| 0x0000 )
#define	BUFFID_NCYC_TX_BUF_L		(0x0001 << 12 |	0x0001 << 8	| 0x0000 )

#define	BUFFIDMASK_INDEX		((NX_USHORT)0x00FF)
#define	BUFFIDMASK_SIZE			((NX_USHORT)0x0F00)
#define	BUFFIDMASK_FRAME		((NX_USHORT)0xF000)

#define	NCYC_TX_SYNC_NUM_S		((NX_USHORT)16)
#define	NCYC_TX_SYNC_NUM_L		((NX_USHORT)4)

#define	NCYC_TX_NUM_S			((NX_USHORT)16)
#define	NCYC_TX_NUM_L			((NX_USHORT)4)

#define	NCYC_MAXNUM				(NCYC_TX_SYNC_NUM_S + NCYC_TX_SYNC_NUM_L + NCYC_TX_NUM_S + NCYC_TX_NUM_L)

#define	NCYC_TX_FRAME_SIZE_S	((NX_USHORT)256)
#define	NCYC_TX_FRAME_SIZE_L	((NX_USHORT)1536)

#define	NCYC_TX_NUM_S_BIT		((NX_ULONG)0xFFFF0000)
#define	NCYC_TX_NUM_L_BIT		((NX_ULONG)0xFFFFFFF0)

#define	NCYC_TX_FREEAREASIZE	((NX_USHORT)32)

typedef struct NCYC_TX_FRAME_S_TAG {
	T_MSG	stMsg;
	NX_USHORT	usBuffId;
	NX_USHORT	usTsNo;
	NX_USHORT	usPort;
	NX_USHORT	usRelFlg;
	NX_USHORT	usFramFormat;
	NX_USHORT	usVLAN;
	NX_USHORT	usHeaderSize;
	NX_USHORT	usDataSize;
	NX_ULONG	ulFreeDataType;
	NX_UCHAR	auchFreeData[NCYC_TX_FREEAREASIZE];
	NCYC_TX_CALLBACK	pvCbfunc;
	NX_UCHAR	auchData[NCYC_TX_FRAME_SIZE_S];
} NCYC_TX_FRAME_S;

typedef struct NCYC_TX_FRAME_L_TAG {
	T_MSG	stMsg;
	NX_USHORT	usBuffId;
	NX_USHORT	usTsNo;
	NX_USHORT	usPort;
	NX_USHORT	usRelFlg;
	NX_USHORT	usFramFormat;
	NX_USHORT	usVLAN;
	NX_USHORT	usHeaderSize;
	NX_USHORT	usDataSize;
	NX_ULONG	ulFreeDataType;
	NX_UCHAR	auchFreeData[NCYC_TX_FREEAREASIZE];
	NCYC_TX_CALLBACK	pvCbfunc;
	NX_UCHAR	auchData[NCYC_TX_FRAME_SIZE_L];
} NCYC_TX_FRAME_L;

typedef struct NCYC_TX_BUF_S_TAG {
	NX_ULONG		ulUsedFlg;
	NCYC_TX_FRAME_S astFrame[NCYC_TX_SYNC_NUM_S];
} NCYC_TX_BUF_S;

typedef struct NCYC_TX_BUF_L_TAG {
	NX_ULONG		ulUsedFlg;
	NCYC_TX_FRAME_L astFrame[NCYC_TX_SYNC_NUM_L];
} NCYC_TX_BUF_L;

typedef struct NCYC_TX_BUF_SYNC_S_TAG {
	NX_ULONG		ulUsedFlg;
	NCYC_TX_FRAME_S astFrame[NCYC_TX_NUM_S];
} NCYC_TX_BUF_SYNC_S;

typedef struct NCYC_TX_BUF_SYNC_L_TAG {
	NX_ULONG		ulUsedFlg;
	NCYC_TX_FRAME_L astFrame[NCYC_TX_NUM_L];
} NCYC_TX_BUF_SYNC_L;

typedef struct TXN_SND_BUFFADD_TAG {
	NX_ULONG	ulTxnHeadBuffAdd;
	NX_ULONG	ulTxnSndBuffAdd;
} TXN_NCYC_BUFFADD;

NX_EXTERN	TXN_NCYC_BUFFADD gstTXNSndNonCyclicBuffAdd[64];

NX_VOID vTXN_InitNonCycTxBuf (NX_VOID);
NX_ULONG ulTXN_AllocTxNonCycBuf (NX_ULONG, NX_USHORT, NCYC_TX_FRAME**);
NX_VOID vTXN_ReleaseNonCycTxBuf (NX_USHORT);
#endif
/*[EOF]*/
