/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __ST_SNC_MIB_H_INCLUDED__
#define __ST_SNC_MIB_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#endif
#endif

typedef enum {
    ST_SNC_MIBTYPE_NWCFG,
    ST_SNC_MIBTYPE_DEVDTL,
    ST_SNC_MIBTYPE_OTMDL,
    ST_SNC_MIBTYPE_STATS,
    ST_SNC_MIBTYPE_IPOVERLAP,
    ST_SNC_MIBTYPE_TOPOLOGY,
    ST_SNC_MIBTYPE_DATALINK,
    ST_SNC_MIBTYPE_COMTIMING,
    ST_SNC_MIBTYPE_CURERR,
#ifdef SWPS
    ST_SNC_MIBTYPE_LLDP,
    ST_SNC_MIBTYPE_LLDP_AGENT,
    ST_SNC_MIBTYPE_LLDP_LOCAL,
    ST_SNC_MIBTYPE_LLDP_REMOTE,
#endif
    ST_SNC_MIBTYPE_NONE,
    ST_SNC_MIBTYPE_MAX,
} ST_SNC_Mibtype;


#ifdef SWPS
#define ST_SNC_MIBTYPE_EXTMIB_MAX   ST_SNC_MIBTYPE_LLDP
#else
#define ST_SNC_MIBTYPE_EXTMIB_MAX   ST_SNC_MIBTYPE_NONE
#endif

#ifdef SWPS
#define ST_SNC_LLDPMIB_MIB                               (0)
#define ST_SNC_LLDPMIB_AGENT                             (1)
#define ST_SNC_LLDPMIB_LOCAL                             (2)
#define ST_SNC_LLDPMIB_REMOTE                            (3)
#endif

#define ST_SNC_NETTYP_LEN                                (2)
#define ST_SNC_MAC_LEN                                   (6)
#define ST_SNC_IPV4V6_LEN                               (20)
#define ST_SNC_PORTCON_LEN                               (3)
#define ST_SNC_PORTSPD_LEN                               (6)
#define ST_SNC_TRSMITCYC_LEN                             (2)
#define ST_SNC_HOTLINE_LEN                               (3)
#define ST_SNC_CORRESPONDFUN_LEN                         (4)
#define ST_SNC_CYCLIC_STS_LEN                            (2)
#define ST_SNC_ALIAS_LEN                                (64)
#define ST_SNC_COMMENT_LEN                             (254)
#define ST_SNC_DEVMNAME_LEN                             (20)
#define ST_SNC_VENNAME_LEN                              (32)
#define ST_SNC_SERIALNUM_LEN                            (32)
#define ST_SNC_UNITIDENT_LEN                             (2)
#define ST_SNC_PORTCONALL_LEN                           (12)
#define ST_SNC_ERRFRMREPSTS_LEN                          (6)
#define ST_SNC_IPALL_LEN                                (45)
#define ST_SNC_TPLGCAUSE_LEN                             (2)
#define ST_SNC_DETECTIONACKIP_LEN                       (45)
#define ST_SNC_DLETYPE_LEN                               (2)
#define ST_SNC_ERRCONREG_LEN                            (64)
#define ST_SNC_ERRSTS_LEN                                (2)
#define ST_SNC_ERRTIME_LEN                              (10)

#ifdef SWPS
#define ST_SNC_NWCFG_CONSTN_SW_MAX                      (512)
#define ST_SNC_NWCFG_CONSTN_HW_MAX                      (256)
#define ST_SNC_NWCFG_CONSTN_MAX      (ST_SNC_NWCFG_CONSTN_SW_MAX)
#define ST_SNC_NWCFG_ADJACENT_MAX                        (24)
#define ST_SNC_DEVDTL_MASTER_MAX                         (64)
#define ST_SNC_DEVDTL_LED_MAX                           (255)
#define ST_SNC_DEVDTL_PORT_MAX                           (24)
#define ST_SNC_OTHER_OPT_SW_MAX                         (255)
#define ST_SNC_OTHER_OPT_HW_MAX                         (255)
#define ST_SNC_OTHER_OPT_MAX        (ST_SNC_OTHER_OPT_SW_MAX)
#define ST_SNC_IPOVLAP_ERR_MAX                          (512)
#define ST_SNC_TOPOLOGY_ERR_MAX                         (512)
#define ST_SNC_NOTIFYREG_MAX                            (512)
#define ST_SNC_DATALINK_ERR_MAX                         (512)
#define ST_SNC_COMTIMING_ERR_MAX                        (512)
#define ST_SNC_ERRREG_MAX                                (16)
#define ST_SNC_ERRDTLREG_MAX                             (10)
#else
#define ST_SNC_NWCFG_CONSTN_SW_MAX                      (  4)
#define ST_SNC_NWCFG_CONSTN_HW_MAX                      (  4)
#define ST_SNC_NWCFG_CONSTN_MAX      (ST_SNC_NWCFG_CONSTN_SW_MAX)
#define ST_SNC_NWCFG_ADJACENT_MAX                        ( 4)
#define ST_SNC_DEVDTL_MASTER_MAX                         ( 4)
#define ST_SNC_DEVDTL_LED_MAX                           (  8)
#define ST_SNC_DEVDTL_PORT_MAX                           ( 4)
#define ST_SNC_OTHER_OPT_SW_MAX                         (  4)
#define ST_SNC_OTHER_OPT_HW_MAX                         (  8)
#define ST_SNC_OTHER_OPT_MAX        (ST_SNC_OTHER_OPT_HW_MAX)
#define ST_SNC_IPOVLAP_ERR_MAX                          (  4)
#define ST_SNC_TOPOLOGY_ERR_MAX                         (  4)
#define ST_SNC_NOTIFYREG_MAX                            (  4)
#define ST_SNC_DATALINK_ERR_MAX                         (  4)
#define ST_SNC_COMTIMING_ERR_MAX                        (  4)
#define ST_SNC_ERRREG_MAX                                (16)
#define ST_SNC_ERRDTLREG_MAX                             (10)
#define ST_SNC_ERR_OCCURRENCE_ORDER_NO_MIN                (0)
#define ST_SNC_ERR_OCCURRENCE_ORDER_NO_MAX            (65535)
#endif

#define ST_SNC_STATISTICS_CLEAR_IDLE				(0)
#define ST_SNC_STATISTICS_CLEAR_REQUESTED			(1)
#define ST_SNC_STATISTICS_CLEAR_EXECTUING			(2)

typedef struct ST_SNC_N2MibMasterStation_TAG {
    NX_USHORT                             usTotalStations;
    NX_USHORT                             usErrorStations;
    NX_USHORT                             usConfigurationPriodSeconds;
    NX_ULONG                              ulConfigurationPriodNanoLiw;
	NX_UCHAR                              uchSyncType;
    NX_USHORT                             usPriodSeconds;
    NX_ULONG                              ulPriodNanoLiw;
    NX_UCHAR                              auchGrandMasterIpAddress[ST_SNC_IPV4V6_LEN];
    NX_USHORT                             usUpdateSequenceNumber;
    NX_USHORT                             usStationNumber;
    NX_UCHAR                              auchMacAddress[ST_SNC_MAC_LEN];
    NX_USHORT                             usNetworkType;
    NX_UCHAR                              auchIpAddress[ST_SNC_IPV4V6_LEN];
    NX_UCHAR                              uchCertificationClass;
    NX_UCHAR                              uchNetworkNumber;
    NX_UCHAR                              uchStationType;
    NX_USHORT                             usDeviceVersion;
    NX_UCHAR                              uchOption;
    NX_UCHAR                              uchFunction;
    NX_UCHAR                              uchNumberOfPort;
    NX_UCHAR                              uchDiagnosisInfo;
    NX_ULONG                              ulDeviceModelCode;
    NX_USHORT                             usExpansionModelCode;
    NX_USHORT                             usVendorCode;
    NX_USHORT                             usDeviceType;
    NX_UCHAR                              auchPortCondition[ST_SNC_PORTCON_LEN];
    NX_UCHAR                              auchPortComSpeed[ST_SNC_PORTSPD_LEN];
    NX_UCHAR                              uchParameterErrorInfo;
    NX_UCHAR                              auchHotLineInfo[ST_SNC_HOTLINE_LEN];
    NX_UCHAR                              uchStatusFlag;
    NX_UCHAR                              auchAlias[ST_SNC_ALIAS_LEN];
    NX_UCHAR                              auchComment[ST_SNC_COMMENT_LEN];
    NX_USHORT                             usModeStatus;
} ST_SNC_N2MibMasterStation;

typedef struct ST_SNC_N3MibAdjacentStation_TAG {
    NX_UCHAR                              uchDetectionReceivePortNumber;
    NX_UCHAR                              uchBeforeDetectionTransmissionPortNumber;
    NX_UCHAR                              auchBeforeNodeMacAddress[ST_SNC_MAC_LEN];
    NX_UCHAR                              uchDetectionResponseReceivePortNumber;
} ST_SNC_N3MibAdjacentStation;

typedef struct ST_SNC_N2MibConnectedStation_TAG {
    NX_UCHAR                              auchMacAddress[ST_SNC_MAC_LEN];
    NX_UCHAR                              auchIpAddress[ST_SNC_IPV4V6_LEN];
    NX_UCHAR                              uchCertificationClass;
    NX_USHORT                             usNetworkType;
    NX_USHORT                             usStationNumber;
    NX_UCHAR                              uchStationType;
    NX_USHORT                             usDeviceVersion;
    NX_ULONG                              ulDeviceModelCode;
    NX_USHORT                             usExpansionModelCode;
    NX_USHORT                             usVendorCode;
    NX_UCHAR                              uchOption;
    NX_USHORT                             usDeviceType;
    NX_UCHAR                              uchFunction;
    NX_UCHAR                              uchNumberOfPort;
    NX_UCHAR                              auchPortCondition[ST_SNC_PORTCON_LEN];
    NX_UCHAR                              auchPortComSpeed[ST_SNC_PORTSPD_LEN];
    NX_USHORT                             usStationSpecificMode;
    NX_UCHAR                              auchTransmitCycle[ST_SNC_TRSMITCYC_LEN];
    NX_UCHAR                              uchDiagnosisInfo;
    NX_UCHAR                              uchParameterErrorInfo;
    NX_UCHAR                              auchHotLineInfo[ST_SNC_HOTLINE_LEN];
    NX_UCHAR                              auchCyclicStatus[ST_SNC_CYCLIC_STS_LEN];
    NX_UCHAR                              uchStatusFlag;
    NX_UCHAR                              uchNumberOfAdjacentStation;
    NX_UCHAR                              auchAlias[ST_SNC_ALIAS_LEN];
    NX_UCHAR                              auchComment[ST_SNC_COMMENT_LEN];
    ST_SNC_N3MibAdjacentStation        astAdjacent[ST_SNC_NWCFG_ADJACENT_MAX];
} ST_SNC_N2MibConnectedStation;


typedef struct ST_SNC_N1MibNetworkConfig_TAG {
    ST_SNC_N2MibMasterStation          stMaster;
    NX_USHORT                             usNumberOfConnectedStation;
    ST_SNC_N2MibConnectedStation       astConnected[ST_SNC_NWCFG_CONSTN_MAX];
} ST_SNC_N1MibNetworkConfig;


typedef struct ST_SNC_N3MibStatusMaster_TAG {
    NX_UCHAR                            auchMacAddress[ST_SNC_MAC_LEN];
} ST_SNC_N3MibStatusMaster;

typedef struct ST_SNC_N3MibLed_TAG {
    NX_UCHAR                            uchLedColor;
    NX_UCHAR                            uchLedStatus;
} ST_SNC_N3MibLed;

typedef struct ST_SNC_N3MibStatusPortInfo {
    NX_USHORT                           usPortLinkDownCnt;
} ST_SNC_N3MibPort;

typedef struct ST_SNC_N2MibIdentifierInfo_TAG {
    NX_UCHAR                            auchMacAddress[ST_SNC_MAC_LEN];
    NX_USHORT                           usStationNumber;
    NX_UCHAR                            uchNetworkNumber;
    NX_UCHAR                            uchOption;
    NX_UCHAR                            auchIpAddress[ST_SNC_IPALL_LEN];
    NX_UCHAR                            uchCertificationClass;
    NX_UCHAR                            uchStationType;
    NX_USHORT                           usDeviceVersion;
    NX_USHORT                           usFwVersion;
    NX_UCHAR                            uchHwVersion;
    NX_USHORT                           usDeviceType;
    NX_ULONG                            ulDeviceModelCode;
    NX_USHORT                           usExpansionModelCode;
    NX_USHORT                           usVendorCode;
    NX_UCHAR                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    NX_UCHAR                            auchVendorName[ST_SNC_VENNAME_LEN];
    NX_UCHAR                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
    NX_USHORT                           usStationSpecificMode;
    NX_UCHAR                            auchUnitIdentifier[ST_SNC_UNITIDENT_LEN];
} ST_SNC_N2MibIdentifierInfo;

typedef struct ST_SNC_N3MibStatusInfoBase_TAG {
    NX_UCHAR                            auchPortCondition[ST_SNC_PORTCONALL_LEN];
	NX_UCHAR                            auchErrorFrameReceptionStatus[ST_SNC_ERRFRMREPSTS_LEN];
    NX_UCHAR                            uchDiagnosisInfo;
    NX_UCHAR                            auchHotLineInfo[ST_SNC_HOTLINE_LEN];
	NX_UCHAR                            uchCyclicStopInfo;
    NX_UCHAR                            auchCorrespondingFunction[ST_SNC_CORRESPONDFUN_LEN];
	NX_UCHAR                            uchAppInfo;
} ST_SNC_N3MibStatusInfoBase;

typedef struct ST_SNC_N2MibStatusInfo_TAG {
    ST_SNC_N3MibStatusInfoBase       stStatusInfoBase;
    NX_UCHAR                            uchNumberOfPort;
    NX_UCHAR                            uchNumberOfMasterTable;
    NX_UCHAR                            uchNumberOfLedTable;
    ST_SNC_N3MibStatusMaster         astMasterTable[ST_SNC_DEVDTL_MASTER_MAX];
    ST_SNC_N3MibLed                  astLedTable[ST_SNC_DEVDTL_LED_MAX];
    ST_SNC_N3MibPort                 astPortTable[ST_SNC_DEVDTL_PORT_MAX];
} ST_SNC_N2MibStatusInfo;

typedef struct ST_SNC_N1MibDeviceDetail_TAG {
    ST_SNC_N2MibIdentifierInfo         stIdentifier;
    ST_SNC_N2MibStatusInfo             stStatus;
} ST_SNC_N1MibDeviceDetail;


typedef struct ST_SNC_N2MibController_TAG {
    NX_UCHAR                            uchDeviceVersion;
    NX_UCHAR                            uchFwVersion;
    NX_UCHAR                            uchHwVersion;
    NX_UCHAR                            uchPadding;
    NX_ULONG                            ulDeviceModelCode;
    NX_USHORT                           usExpansionModelCode;
    NX_USHORT                           usDeviceType;
    NX_USHORT                           usVendorCode;
    NX_UCHAR                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    NX_UCHAR                            auchVendorName[ST_SNC_VENNAME_LEN];
    NX_UCHAR                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
} ST_SNC_N2MibController;

typedef struct ST_SNC_N2MibOptionInfo_TAG {
    NX_ULONG                            ulDeviceModelCode;
    NX_USHORT                           usExpansionModelCode;
    NX_USHORT                           usVendorCode;
    NX_UCHAR                            uchDeviceVersion;
    NX_UCHAR                            uchPadding;
    NX_UCHAR                            auchDeviceModelName[ST_SNC_DEVMNAME_LEN];
    NX_UCHAR                            auchVendorName[ST_SNC_VENNAME_LEN];
    NX_UCHAR                            auchSerialNumber[ST_SNC_SERIALNUM_LEN];
} ST_SNC_N2MibOptionInfo;

typedef struct ST_SNC_N1MibOtherModule_TAG {
    ST_SNC_N2MibController           stController;
    NX_USHORT                           usNumberOfTable;
    NX_USHORT                           usPadding;
    ST_SNC_N2MibOptionInfo           astOptTable[ST_SNC_OTHER_OPT_MAX];
} ST_SNC_N1MibOtherModule;


typedef struct ST_SNC_N1MibStatisticalInfo_TAG {
    NX_USHORT                           usCyclicReceiveCounter;
    NX_USHORT                           usCyclicReceiveDiscardCounter;
    NX_USHORT                           usCyclicFrameReceiveCounter;
    NX_USHORT                           usNonCyclicReceiveCounter;
    NX_USHORT                           usNonCyclicReceiveDiscardCounter;
    NX_USHORT                           usNumberOfHecErrorFrame;
    NX_USHORT                           usNumberOfDcsErrorFrame;
    NX_USHORT                           usNumberOfFcsErrorFrame;
    NX_USHORT                           usNumberOfSdcrcErrorFrame;
    NX_USHORT                           usNumberOfShortPacketFrame;
    NX_USHORT                           usNumberOfJumboPacketFrame;
    NX_USHORT                           usNumberOfLongPacketFrame;
    NX_USHORT                           usNumberOfFailedCcLinkIePduSize;
    NX_USHORT                           usNumberOfFlagmentErrorFrame;
    NX_USHORT                           usNumberOfPriorityControlFrame;
    NX_USHORT                           usNumberOfIpFrame;
    NX_USHORT                           usNumberOfIeee802or1588Frame;
    NX_USHORT                           usNumberOfLldpFrame;
    NX_USHORT                           usNumberOfSyncFrame;
    NX_USHORT                           usPadding;
} ST_SNC_N1MibStatisticalInfo;


typedef struct ST_SNC_N2MibIpOverlapReg_TAG {
    NX_UCHAR                            uchPortIdentifier;
    NX_UCHAR                            uchStatus;
    NX_UCHAR                            auchMacAddress[ST_SNC_MAC_LEN];
    NX_UCHAR                            auchIpAddress[ST_SNC_IPV4V6_LEN];
} ST_SNC_N2MibIpOverlapReg;

typedef struct ST_SNC_N1MibIpOverlapError_TAG {
    NX_USHORT                           usNumberOfTable;
	NX_USHORT                           usPadding;
	ST_SNC_N2MibIpOverlapReg         astRegTable[ST_SNC_IPOVLAP_ERR_MAX];
} ST_SNC_N1MibIpOverlapError;


typedef struct ST_SNC_N2MibTopologyReg_TAG {
    NX_UCHAR                            uchType;
    NX_UCHAR                            auchCause[ST_SNC_TPLGCAUSE_LEN];
    NX_UCHAR                            auchMacAddress[ST_SNC_MAC_LEN];
    NX_UCHAR                            auchIpAddress[ST_SNC_DETECTIONACKIP_LEN];
    NX_UCHAR                            uchStationType;
    NX_UCHAR                            uchPadding;
    NX_USHORT                           usVendorCode;
    NX_USHORT                           usDeviceType;
    NX_ULONG                            ulDeviceModelCode;
} ST_SNC_N2MibTopologyReg;

typedef struct ST_SNC_N1MibIpTopologyError_TAG {
    NX_USHORT                           usNumberOfTable;
	NX_USHORT                           usPadding;
	ST_SNC_N2MibTopologyReg          astRegTable[ST_SNC_TOPOLOGY_ERR_MAX];
} ST_SNC_N1MibIpTopologyError;





typedef struct ST_SNC_N2MibDatalinkErrorReg_TAG {
    NX_UCHAR                            auchType[ST_SNC_DLETYPE_LEN];
    NX_UCHAR                            uchNetworkNumber;
    NX_UCHAR                            uchStationNumber;
    NX_UCHAR                            auchIpAddress[ST_SNC_IPV4V6_LEN];
} ST_SNC_N2MibDatalinkErrorReg;

typedef struct ST_SNC_N1MibDatalinkError_TAG {
    NX_USHORT                           usNumberOfTable;
    NX_USHORT                           usPadding;
	ST_SNC_N2MibDatalinkErrorReg     astErrorTable[ST_SNC_DATALINK_ERR_MAX];
} ST_SNC_N1MibDatalinkError;



typedef struct ST_SNC_N1MibCommTimingError_TAG {
    NX_UCHAR                            uchTimeslotNumber;
} ST_SNC_N1MibCommTimingError;

typedef struct ST_SNC_N3MibErrorDetailReg_TAG {
    NX_USHORT                           usDetailInfo;
} ST_SNC_N3MibErrorDetailReg;

#pragma pack(1)
typedef struct ST_SNC_N2MibErrorReg_TAG {
    NX_ULONGLONG                           ullOccurrenceTimeSeconds;
    NX_ULONG                            ulOccurrenceTimeNanoLiw;
    NX_USHORT                           usErrorCode;
	NX_USHORT                           usErrorOccurrenceOrderNo;
	NX_SHORT                            sUtcOffset;
	NX_SHORT                            sSummerTimeOffset;
    NX_UCHAR                            uchNumberOfTable;
    ST_SNC_N3MibErrorDetailReg       astDetailTable[ST_SNC_ERRDTLREG_MAX];
} ST_SNC_N2MibErrorReg;

typedef struct ST_SNC_N1MibCurrentError_TAG {
    NX_USHORT                           usNumberOfTable;
    NX_USHORT                           usPadding;
    ST_SNC_N2MibErrorReg             astErrorTable[ST_SNC_ERRREG_MAX];
} ST_SNC_N1MibCurrentError;
#pragma pack()


#ifdef SWPS
typedef struct ST_SNC_MibLldpSend_TAG {
    NX_UCHAR                            uchType;
    NX_UCHAR                            uchIndex;
    NX_VOID*                            pvAddr;
	NX_ULONG                            ulDataSize;
} ST_SNC_MibLldpSend;
#endif

#endif
