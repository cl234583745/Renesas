/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/


/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "R_IN32M4_CL3Driver.h"

#include "cdif_ex.h"
#include "cyclics_ex.h"
#include "unitinfo_ex.h"
#include "fatalerrornotify_ex.h"
#include "fatalerrorcontrol_ex.h"
#include "reset_ex.h"
#include "mibinterface_ex.h"
#include "resetstatus_ex.h"
#include "regaccess_ex.h"
#include "eventdetection_ex.h"
#include "SlmpCmdCommon_ex.h"
#include "UnitState_ex.h"
#include "tool_ex.h"
#include "HwTest_ex.h"
#include "ledcontrol_ex.h"
#include "clockcontrol_ex.h"
#include "timecounter_ex.h"
#include "ccienx_const.h"
#include "phy_ex.h"
#include "ccienx_task.h"
#include "platformctrl_ex.h"
#include "ComplianceTest_ex.h"
#include "ErrHis_ex.h"
#include "SLMP_api.h"
#include "ccienx_supply.h"
#include "CbCtrl_ex.h"


#include "wdc_ex.h"
#include "sync_ex.h"
#ifdef TSN_CAN_ENABLE
#include "Can_ex.h"
#endif

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
#define R_IN_FRAME_TYPE_6E_RES				(0x00E8)		/* Response frame								*/
#define R_IN_SLMP_SPLIT_FRAME_SIZE_MAX		(4360)			/* SLMP maximum send size						*/
#define R_IN_SLMP_REQUEST_MONITORING_NUM	(5)				/* Number of request monitoring information		*/


/*********************************************************************************/
/* Functions                                                                     */
/*********************************************************************************/
extern void regist_ip_filr_func(ULONG (*pfunc)(ULONG));


/*********************************************************************************/
/** @brief  Get reset status                                                     */
/** @retval R_IN_RESET_PWRON    :Power on reset                                  */
/** @retval R_IN_RESET_SYSTEM   :System reset                                    */
/*********************************************************************************/
ULONG   gulR_IN_GetResetStatus( VOID )
{
	ULONG	ulResetLevel;									/* Reset state									*/

	ulResetLevel = gulRstGetResetStatus();					/* Get reset state (driver layer)				*/
	if ( ulResetLevel == R_IN_RST_RESET_SYSTEM ) {
		ulResetLevel = R_IN_RESET_SYSTEM;
	}
	else {
		ulResetLevel = R_IN_RESET_PWRON;
	}

	return ulResetLevel;
}


/*********************************************************************************/
/** @brief  Initialize R-IN32M4-CL3                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @warning:When a fatal error occurs in R-IN32M4-CL3, this function calls the  */
/**          user-created gR_IN_CallbackFatalError function, so obtain the       */
/**          fatal error in R-IN32M4-CL3                                         */
/*********************************************************************************/
ERRCODE gerR_IN_Initialize(
	const UCHAR*			puchMACAddress,					/**< Own station MAC address						*/
	const R_IN_UNITINFO_T*	pstUnitInfo, 					/**< R-IN32M4-CL3 module information initialization		*/
	const R_IN_UNITINIT_T*	pstUnitInit 					/**< R-IN32M4-CL3 initial configuration					*/
)
{
	ERRCODE			erRet	= R_IN_OK;						/* Return value										*/
	CYCS_SIZE_EX_T	stCycSize;								/* Cyclic size										*/

	/* Parameter check */
	if ((NULL == puchMACAddress) || (NULL == pstUnitInfo) || (NULL == pstUnitInit)) {
		/* Abnormal end (parameter error) */
		return R_IN_ERR;
	}

	/* Check values specified in structures */
	erRet = gerUnitInfoCheckParam(pstUnitInfo, pstUnitInit);
	if (R_IN_OK != erRet) {
		return erRet;
	}

	/* Intialze functions */
	gvComdriverSupplyFunctionsInit();						/* Initialization processing of a group of functions provided to the communication driver	*/
	gvCbCtrlInit();											/* Callback processing function initialization		*/
	gvCdifInit();											/* Communication driver I/F initialization			*/
	gvFecInit();											/* Fatal error management buffer initialization		*/
	gvUnitInfoClear();										/* Module information initialization				*/
	gvCycsInit();											/* Cyclic function initialization					*/
	gvSlmpTranInitial();									/* SLMP send/receive initialization					*/
	gvSlmpInitial();										/* SLMP command initialization						*/
	gvLedControlInit();										/* LED function initialization						*/
	gvPhyInit();											/* PHY function initialization						*/
	gvMibLedInfoInit();										/* LED status information MIB initialization		*/
	gvWdcInit();											/* WDC control function initialzation				*/
	gvSyncInit();											/* Synchronization control function initialization	*/

	/* Set module information */
	(VOID)gerUnitInfoSetUnitInfoData(puchMACAddress, pstUnitInfo, pstUnitInit);

	/* Set module function information */
	(VOID)gerUnitInfoSetFuncData(pstUnitInit);

	/* Set maximum cyclic data size */
	stCycSize.ulRySize  = pstUnitInfo->usMaxRySize;			/* RX maximum data size (byte)						*/
	stCycSize.ulRWwSize = pstUnitInfo->usMaxRWwSize * 2;	/* RWw maximum data size (byte)						*/
	stCycSize.ulRxSize  = pstUnitInfo->usMaxRxSize;			/* RY maximum data size (byte)						*/
	stCycSize.ulRWrSize = pstUnitInfo->usMaxRWrSize * 2;	/* RWr maximum data size (byte)						*/
	(VOID)gerCycsSetMaxCyclicSize(&stCycSize);				/* Maximum data size setting						*/

	/* Set watchdog counter information */
	if (R_IN_BIT2 == (pstUnitInfo->ulCorrespondingFunction & R_IN_BIT2)) {
		/* Set WDC information when using watchdog counter function */
		erRet = gerWdcSetInfo(&pstUnitInfo->stWdcInfo);
		if (R_IN_OK != erRet) {
			return erRet;
		}
	}

	/* Set the process state (initialized) */
	(VOID)gerUnitStateSetState(UNITSTATE_STATE_INITIALIZED);

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Set IP address                                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetIPAddress(
	ULONG		ulIPAddress,								/**< IP address					*/
	ULONG		ulSubnetmask,								/**< Subnet mask				*/
	ULONG		ulDefaultGateway							/**< Default gateway			*/
)
{
	ULONG	ulState = C_ZERO;								/* Current processing state		*/
	ERRCODE	erRet = R_IN_OK;								/* Error code					*/

	/* Check the processing state */
	(VOID)gerUnitStateGetState(&ulState);					/* Process status acquisition	*/
	if ((UNITSTATE_STATE_INITIALIZED != ulState) && (UNITSTATE_STATE_SET_IPADDRESS != ulState)) {
		return R_IN_ERR;
	}
	else{
	}

	/* Set a initial IP address */
	erRet = gerUnitInfoSetIPAddress(ulIPAddress, ulSubnetmask, ulDefaultGateway);
	if (R_IN_OK != erRet) {
		return erRet;
	}

	/* Set the processing state (IP address configured) */
	(VOID)gerUnitStateSetState(UNITSTATE_STATE_SET_IPADDRESS);

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Start R-IN32M4-CL3 communication                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_Start( VOID )
{
	ULONG ulState = C_ZERO;									/* Current processing state					*/
	ULONG ulIPAddress = C_ZERO;								/* IP address								*/
	ULONG ulSubnetmask = C_ZERO;							/* Subnet mask								*/
	ULONG ulDefaultGateway = C_ZERO;						/* Default gateway							*/

	/* Check the processing state */
	(VOID)gerUnitStateGetState(&ulState);					/* Process status acquisition				*/
	if ((UNITSTATE_STATE_SET_IPADDRESS != ulState) && (UNITSTATE_STATE_INITIALIZED != ulState)) {
		return R_IN_ERR;
	}
	else {
	}

	/* Initialize the event detection function */
	(VOID)gerUnitInfoGetIPAddress(&ulIPAddress, &ulSubnetmask, &ulDefaultGateway);
	gvEvtdtctInitial(ulIPAddress, ulSubnetmask, ulDefaultGateway);

	vNX_CcienxInit();										/* Communication driver initialization		*/
	gvMibSetOtherUnitInfo();								/* Other module information MIB settings	*/

	/* Set the processing state (R-IN32M4-CL3 communication start processed) */
	(VOID)gerUnitStateSetState(UNITSTATE_STATE_START_DLINK);

	return R_IN_OK;
}



/*********************************************************************************/
/** @brief  Reset R-IN32M4-CL3 internal WDT                                      */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_ResetWDT( VOID )
{
	/* WDT clearing process */
	vNX_ClearWdt();

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Disable R-IN32M4-CL3 internal WDT                                    */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_DisableWDT( VOID )
{
	/* WDT operation stop processing */
	vNX_StopWdt();

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Enable R-IN32M4-CL3 internal WDT                                     */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_EnableWDT( VOID )
{
	/* WDT operation start processing */
	vNX_StartWdt();

	return R_IN_OK;
}

/*********************************************************************************/
/** @brief  IEEE802.3ab Compliance test                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_IEEETest(
	USHORT usMode											/**< IEEE802.3ab compliance test mode	*/
															/**<  R_IN_IEEE_MODE1(0)�FMODE1			*/
															/**<  R_IN_IEEE_MODE2(1)�FMODE2			*/
															/**<  R_IN_IEEE_MODE3(2)�FMODE3			*/
															/**<  R_IN_IEEE_MODE4(3)�FMODE4			*/
															/**<  R_IN_IEEE_END  (4)�FTest end		*/
)
{
	static const USHORT ausModeTbl[] = {
							COMPLIANCE_TEST_MODE1,
							COMPLIANCE_TEST_MODE2,
							COMPLIANCE_TEST_MODE3,
							COMPLIANCE_TEST_MODE4,
							COMPLIANCE_TEST_MODE_END
						};

	ERRCODE erRet = R_IN_OK;

	erRet = gerComplianceTest(ausModeTbl[usMode]);

	return erRet;
}

/*********************************************************************************/
/** @brief  loopback test Initialization                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_InitializeLoopBackTest(VOID)
{
	ERRCODE erRet = R_IN_OK;

	/* Process status update (hardware testing in progress) */
	(VOID)gerUnitStateSetState(UNITSTATE_STATE_HWTEST);

	/* Loopback test initialization */
	erRet = gerLBTInitialize();

	return erRet;
}


/*********************************************************************************/
/** @brief  Loopback test transmission process                                   */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SendLoopBackTest(
	ULONG ulPort											/**< Test target port			*/
)
{
	ERRCODE erRet = R_IN_OK;

	/* Argument check */
	if (R_IN_PORT2 >= ulPort) {

		/* Send loopback test data */
		erRet = gerLBTSendTestData(ulPort);
	}
	else {
		erRet = R_IN_ERR_OUTOFRANGE;						/* Abnormal end (out of range)	*/
	}

		return erRet;
	}


/*********************************************************************************/
/** @brief  Loopback test reception process                                      */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no data)                          */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/** @retval R_IN_ERR_TIMEOUT    :Abnormal end (timeout)                          */
/*********************************************************************************/
ERRCODE gerR_IN_ReceiveLoopBackTest(
	ULONG ulPort											/**< Test target port			*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* Argument check */
	if (R_IN_PORT2 >= ulPort) {

		/* Loopback test reception process */
		erRet = gerLBTReceivedTestData(ulPort);
	}
	else {
		erRet = R_IN_ERR_OUTOFRANGE;						/* Abnormal end (out of range)	*/
	}

	return erRet;
}


/*********************************************************************************/
/** @brief  Set R-IN32M4-CL3 internal WDT limit time                             */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_SetWDT(
	USHORT usWDTCOUNT										/**< WDT time setting			*/
)
{
	ULONG	ulWDTCount;										/* WDT count					*/

	/* Check the value of WDT limit time */
	if (R_IN_WDT_MAX_COUNT < usWDTCOUNT) {
		usWDTCOUNT = R_IN_WDT_MAX_COUNT;
	}
	else {
	}

	/* usWDTCOUNT =  0 -> WDT limit time 100 msec			*/
	/* usWDTCOUNT =  1 -> WDT limit time 200 msec			*/
	/* usWDTCOUNT = 31 -> WDT limit time 3.2 sec (maximum)	*/
	ulWDTCount = (ULONG)usWDTCOUNT + 1;

	/* WDT initialization processing */
	vNX_InitWdt(ulWDTCount);

	return R_IN_OK;
}


#ifndef TSN_CAN_ENABLE
/*********************************************************************************/
/** @brief  Get received cyclic data (bulk)                                      */
/** @retval R_IN_OK             :Normal end (received data present)              */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetReceivedCyclicData (
	VOID* pRyDst,											/**< start address in RY area (4byte alignment)		*/
	VOID* pRWwDst,											/**< start address in RWw area (4byte alignment)	*/
	BOOL blEnable											/**< Copy enable/disable							*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pRyDst) {
		return R_IN_ERR;
	}

	if (NULL == pRWwDst) {
		return R_IN_ERR;
	}

	if (R_IN_TRUE == blEnable) {
		erRet = gerCycsGetRyRWw(pRyDst, pRWwDst);

		if (R_IN_OK != erRet) {
			erRet = R_IN_ERR;
		}
		else {
			/* No action */
		}
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}



/*********************************************************************************/
/** @brief  Update received cyclic data                                          */
/** @retval R_IN_OK             :Normal end (received data present)              */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/*********************************************************************************/
ERRCODE gerR_IN_UpdateReceivedCyclicData ( VOID )
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsUpdateRcvData();

	return erRet;
}



/*********************************************************************************/
/** @brief  Finish received cyclic data acquisition                              */
/** @retval R_IN_OK             :Normal end (received data present)              */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/*********************************************************************************/
ERRCODE gerR_IN_FinishReceivedCyclicDataAcquisition ( VOID )
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsFinishRcvDataAcquisition();

	return erRet;
}



/*********************************************************************************/
/** @brief  Get received cyclic data (RY)                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_BOUNDARY   :Abnormal end (boundary violation)               */
/*********************************************************************************/
ERRCODE gerR_IN_GetReceivedCyclicRY (
	ULONG   ulPosi,											/**< RY acquisition start position			*/
	ULONG   ulNum,											/**< Number of acquired data of RY (word)	*/
	USHORT* pusDst											/**< Storage area of RY						*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pusDst) {
		return R_IN_ERR;
	}

	erRet = gerCycsGetRy(ulPosi, ulNum, pusDst);

	return erRet;
}

/*********************************************************************************/
/** @brief  Get received cyclic data (RWw)                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_BOUNDARY   :Abnormal end (boundary violation)               */
/*********************************************************************************/
ERRCODE gerR_IN_GetReceivedCyclicRWw (
	ULONG   ulPosi,											/**< RWw acquisition start position			*/
	ULONG   ulNum,											/**< Number of acquired data of RWw (word)	*/
	USHORT* pusDst											/**< Storage area for RWw					*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pusDst) {
		return R_IN_ERR;
	}

	erRet = gerCycsGetRWw(ulPosi, ulNum, pusDst);

	return erRet;
}


/*********************************************************************************/
/** @brief  Get received cyclic buffer                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/*********************************************************************************/
ERRCODE gerR_IN_GetReceivedCyclicBuffer (
	ULONG* pulRyBuffer,										/**< RY destination address			*/
	ULONG* pulRWwBuffer										/**< RWw destination address		*/
)
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsGetRyRWwBuffer(pulRyBuffer, pulRWwBuffer);

	return erRet;
}

/*********************************************************************************/
/** @brief  Finish received cyclic buffer                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no received data)                 */
/*********************************************************************************/
ERRCODE gerR_IN_FinishReceivedCyclicBuffer ( VOID )
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsFinishRcvDataAcquisition();

	return erRet;
}
#endif


/*********************************************************************************/
/** @brief  Get the master node status                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetMasterNodeStatus (
	BOOL*  pblRunSts,										/**< Application status			*/
	BOOL*  pblErrSts										/**< Application error status	*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pblRunSts) {
		return R_IN_ERR;
	}

	if (NULL == pblErrSts) {
		return R_IN_ERR;
	}

	erRet = gerCycsGetMasterUserAppStatus(pblRunSts, pblErrSts);

	if (R_IN_OK != erRet) {
		erRet = R_IN_ERR;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Get Hold/Clear flag                                                  */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetHoldClearFlag (
	BOOL* pblHoldClearFlag									/**< HOLD/CLEAR flag			*/
)
{
	/* NULL check for arguments */
	if (NULL == pblHoldClearFlag) {
		return R_IN_ERR;
	}

	(VOID)gerCycsGetHoldClearFlag(pblHoldClearFlag);

	return R_IN_OK;
}


#ifndef TSN_CAN_ENABLE
/*********************************************************************************/
/** @brief  Set cyclic sending data (bulk)                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_SetSendCyclicData (
	const VOID* pRxSrc,										/**< start address in RX area (4byte alignment)		*/
	const VOID* pRWrSrc,									/**< start address in RWr area (4byte alignment)	*/
	BOOL  blEnable											/**< Copy enable/disable							*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pRxSrc) {
		return R_IN_ERR;
	}

	if (NULL == pRWrSrc) {
		return R_IN_ERR;
	}

	if (R_IN_TRUE == blEnable) {
		erRet = gerCycsSetRxRWr(pRxSrc, pRWrSrc);

		if (R_IN_OK != erRet) {
			erRet = R_IN_ERR;
		}
		else {
			/* No action */
		}
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Finish send cyclic data setting                                      */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_FinishSendCyclicDataSetting( VOID )
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsFinishSndDataSetting();

	return erRet;
}

/*********************************************************************************/
/** @brief  Set cyclic sending data (RX)                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_BOUNDARY   :Abnormal end (boundary violation)               */
/*********************************************************************************/
ERRCODE gerR_IN_SetSendCyclicRX (
	const USHORT* pusSrc,									/**< RX source address					*/
	ULONG   ulPosi,											/**< Setting start position of RX		*/
	ULONG   ulNum											/**< Number of set data of RX (word)	*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pusSrc) {
		return R_IN_ERR;
	}

	erRet = gerCycsSetRx(pusSrc, ulPosi, ulNum);

	return erRet;
}

/*********************************************************************************/
/** @brief  Set cyclic sending data (RWr)                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_BOUNDARY   :Abnormal end (boundary violation)               */
/*********************************************************************************/
ERRCODE gerR_IN_SetSendCyclicRWr (
	const USHORT* pusSrc,									/**< RWr source address					*/
	ULONG   ulPosi,											/**< Setting start position of RWr		*/
	ULONG   ulNum											/**< Number of set data of RWr (word)	*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pusSrc) {
		return R_IN_ERR;
	}

	erRet = gerCycsSetRWr(pusSrc, ulPosi, ulNum);

	return erRet;
}

/*********************************************************************************/
/** @brief  Get send cyclic buffer                                               */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetSendCyclicBuffer (
	ULONG* pulRxBuffer,										/**< RX buffer address					*/
	ULONG* pulRWrBuffer										/**< RWr buffer address					*/
)
{
	ERRCODE erRet = R_IN_ERR;

	R_IN_SEND_CYCLIC_BUFFER_T stBuffer;

	/* NULL check for arguments */
	if (NULL == pulRxBuffer) {
		return R_IN_ERR;
	}

	if (NULL == pulRWrBuffer) {
		return R_IN_ERR;
	}

	erRet = gerCycsGetRxRWrBuffer(&stBuffer);

	if (R_IN_OK == erRet) {
		if ((1 != stBuffer.usRxNum) || (1 != stBuffer.usRWrNum))
		{
			erRet = R_IN_ERR;
		}
		else {
			*pulRxBuffer  = stBuffer.stRx[0].ulAddr;
			*pulRWrBuffer = stBuffer.stRWr[0].ulAddr;
		}
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Get split send cyclic buffer                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetSplitSendCyclicBuffer (
	R_IN_SEND_CYCLIC_BUFFER_T* pstBuffer					/**< Cyclic send buffer	*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* NULL check for arguments */
	if (NULL == pstBuffer) {
		return R_IN_ERR;
	}

	erRet = gerCycsGetRxRWrBuffer(pstBuffer);

	return erRet;
}

/*********************************************************************************/
/** @brief  Finish send cyclic buffer                                            */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_FinishSendCyclicBuffer ( VOID )
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsFinishRxRWrBuffer();

	return erRet;
}
#endif


/*********************************************************************************/
/** @brief  Sets own station status                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetNodeStatus(
	ULONG ulErrSts											/**< Application error status			*/
)
{
	ERRCODE erRet = R_IN_ERR;

	erRet = gerCycsSetDiagErr(ulErrSts);

	return erRet;
}



/*********************************************************************************/
/** @brief  Get IP address                                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetIPAddress (
	ULONG*	pulIPAddress,									/**< IP address							*/
	ULONG*	pulSubnetmask,									/**< Subnet mask						*/
	ULONG*	pulDefaultGateway								/**< Default gateway					*/
)
{
	ERRCODE erRet = R_IN_OK;
	ULONG   ulState = C_ZERO;

	/* NULL check for arguments */
	if (NULL == pulIPAddress) {
		return R_IN_ERR;
	}

	if (NULL == pulSubnetmask) {
		return R_IN_ERR;
	}

	if (NULL == pulDefaultGateway) {
		return R_IN_ERR;
	}

	(VOID)gerUnitStateGetState(&ulState);					/* Process status acquisition			*/

	if (UNITSTATE_STATE_START_DLINK == ulState) {
		erRet = gerCdifGetIPAddress(pulIPAddress, pulSubnetmask, pulDefaultGateway);
	}

	if ((UNITSTATE_STATE_START_DLINK != ulState) || (R_IN_OK != erRet)) {
		(VOID)gerUnitInfoGetIPAddress(pulIPAddress, pulSubnetmask, pulDefaultGateway);
	}

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Get master IP address                                                */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetMasterIPAddress (
	ULONG*	pulIPAddress,									/**< IP address							*/
	USHORT* pusPhysicalPort									/**< Physical port number				*/
)
{
	ERRCODE erRet = R_IN_ERR;

	/* Validate arguments */
	if(( NULL == pulIPAddress )
		|| (NULL == pusPhysicalPort)) {
		/* Abnormal case */

	}
	else {
		/* Normal case */

		/* Get master IP address */
		erRet = gerCdifGetMstIPAddress(pulIPAddress, pusPhysicalPort);

	}

	return erRet;
}


/*********************************************************************************/
/** @brief  Gets specified cyclic communication size from master station         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetCurrentCyclicSize (
	R_IN_CYCLIC_SIZE_T* pstCyclicSize						/**< Current cyclic size			*/
)
{
	ERRCODE erRet = R_IN_OK;
	CYCS_SIZE_EX_T stSize;

	/* NULL check for arguments */
	if (NULL == pstCyclicSize) {
		return R_IN_ERR;
	}

	(VOID)gerCycsGetCurrentCyclicSize(&stSize);

	pstCyclicSize->ulRxSize  = stSize.ulRxSize;
	pstCyclicSize->ulRySize  = stSize.ulRySize;
	pstCyclicSize->ulRWrSize = stSize.ulRWrSize;
	pstCyclicSize->ulRWwSize = stSize.ulRWwSize;

	return erRet;
}



/*********************************************************************************/
/** @brief  Get data link status                                                 */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetCommumicationStatus (
	ULONG* pulCommSts										/**< communication status				*/
)
{
	ERRCODE erRet     = R_IN_OK;
	ULONG   ulCommSts = R_IN_COMMSTS_DISCONNECT;

	/* NULL check for arguments */
	if (NULL == pulCommSts) {
		return R_IN_ERR;
	}

#ifndef TSN_CAN_ENABLE
	(VOID)gerCdifGetCommState(&ulCommSts);
#else
	(VOID)gerCanGetCommState(&ulCommSts);
#endif

	if (CDIF_COMMSTS_CYC_DLINK == ulCommSts) {
		*pulCommSts = R_IN_COMMSTS_CYC_DLINK;
	}
	else if(CDIF_COMMSTS_CYC_STOP == ulCommSts) {
		*pulCommSts = R_IN_COMMSTS_CYC_STOP;
	}
	else {
		*pulCommSts = R_IN_COMMSTS_DISCONNECT;
	}

	return erRet;
}


/*********************************************************************************/
/** @brief  Get the PHY link status                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_GetPortStatus (
	ULONG  ulPort,											/**< Port specification					*/
	ULONG* pulLinkStatus,									/**< Link state							*/
	ULONG* pulSpeed,										/**< Speed								*/
	ULONG* pulDuplex										/**< Full duplex/Half duplex			*/
)
{
	ERRCODE	erRet		 = R_IN_OK;
	ULONG	ulPortTmp	 = C_ZERO;
	ULONG   ulLinkStatus = C_ZERO;
	ULONG   ulSpeed		 = C_ZERO;
	ULONG   ulDuplex	 = C_ZERO;
	ULONG   ulStatus	 = UNITSTATE_STATE_WAITFORINITIALIZE;

	/* NULL check for arguments */
	if (NULL == pulLinkStatus) {
		return R_IN_ERR;
	}

	if (NULL == pulSpeed) {
		return R_IN_ERR;
	}

	if (NULL == pulDuplex) {
		return R_IN_ERR;
	}

	if (R_IN_PORT1 == ulPort) {
		ulPortTmp = CDIF_PORT1;
	}
	else if (R_IN_PORT2 == ulPort) {
		ulPortTmp = CDIF_PORT2;
	}
	else {
		return R_IN_ERR_OUTOFRANGE;
	}

	(VOID)gerUnitStateGetState(&ulStatus);					/* Process status acquisition			*/

	/* Hardware testing in progress */
	if (UNITSTATE_STATE_HWTEST == ulStatus) {

		/* Retrieve PHY link status from PHY register */
		erRet = gerLBTGetPhyStatus(ulPortTmp, &ulLinkStatus, &ulSpeed, &ulDuplex);

		if (R_IN_OK != erRet) {
			return erRet;
		}
		else {
		}
	}
	/* Data link start */
	else if (UNITSTATE_STATE_START_DLINK == ulStatus) {

		/* Obtain the PHY link state */
		(VOID)gerCdifGetPhyState(ulPortTmp, &ulLinkStatus, &ulSpeed, &ulDuplex);
	}
	else {
		return R_IN_ERR;
	}

	if (CDIF_LINKUP == ulLinkStatus) {
		*pulLinkStatus = R_IN_LINKUP;
	}
	else {
		*pulLinkStatus = R_IN_LINKDOWN;
	}

	if (CDIF_SPEED_1G == ulSpeed) {
		*pulSpeed = R_IN_SPEED_1G;
	}
	else if (CDIF_SPEED_100M == ulSpeed) {
		*pulSpeed = R_IN_SPEED_100M;
	}
	else {
		*pulSpeed = R_IN_SPEED_10M;
	}

	if (CDIF_DUPLEX_FULL == ulDuplex) {
		*pulDuplex = R_IN_DUPLEX_FULL;
	}
	else {
		*pulDuplex = R_IN_DUPLEX_HALF;
	}

	return erRet;
}



/*********************************************************************************/
/** @brief  Get cyclic communication status                                      */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetCyclicStatus (
	UCHAR* puchCyclicStatus									/**< Cyclic communication status		*/
)
{
	ERRCODE erRet = R_IN_OK;

	/* NULL check for arguments */
	if (NULL == puchCyclicStatus) {
		return R_IN_ERR;
	}
	else {
	}

	erRet = gerCycsGetCyclicStopInfo(puchCyclicStatus);

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (ERR)                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetERRLED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE		erRet		= R_IN_OK;
	USHORT		usSetLed	= NX_LED_OFF;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
		usSetLed = NX_LED_OFF;
		break;
	case R_IN_LED_ON:										/* LED ON								*/
		usSetLed = NX_LED_ON;
		break;
	case R_IN_LED_BLINK_1000:								/* LED blinks in 1 second cycle			*/
		usSetLed = NX_LED_BLINK_1S;
		break;
	case R_IN_LED_BLINK_500:								/* LED blinks in 500 msec cycle			*/
		usSetLed = NX_LED_BLINK_500MS;
		break;
	case R_IN_LED_BLINK_200:								/* LED blinks in 200 msec cycle			*/
		usSetLed = NX_LED_BLINK_200MS;
		break;
	default:
		return R_IN_ERR_OUTOFRANGE;
		break;
	}

	/* Dispatch prohibited */
	vNX_vDisableDispatch();

	/* ERR LED control */
	vNX_SetErrLed(usSetLed);

	/* Dispatch permission */
	vNX_vEnableDispatch();

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (User LED1)                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetUSER1LED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
	case R_IN_LED_ON:										/* LED ON								*/
	case R_IN_LED_BLINK_1000:								/* LED blinks in 1 second cycle			*/
	case R_IN_LED_BLINK_500:								/* LED blinks in 500 msec cycle			*/
	case R_IN_LED_BLINK_200:								/* LED blinks in 200 msec cycle			*/
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* User LED1 control */
		(VOID)gerLedSetUser1Led((USHORT)ulCtrl);

		/* Dispatch permission */
		vNX_vEnableDispatch();
		break;
	default:
		erRet = R_IN_ERR_OUTOFRANGE;
		break;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (User LED2)                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetUSER2LED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
	case R_IN_LED_ON:										/* LED ON								*/
	case R_IN_LED_BLINK_1000:								/* LED blinks in 1 second cycle			*/
	case R_IN_LED_BLINK_500:								/* LED blinks in 500 msec cycle			*/
	case R_IN_LED_BLINK_200:								/* LED blinks in 200 msec cycle			*/
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* User LED2 control */
		(VOID)gerLedSetUser2Led((USHORT)ulCtrl);

		/* Dispatch permission */
		vNX_vEnableDispatch();
		break;
	default:
		erRet = R_IN_ERR_OUTOFRANGE;
		break;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (RUN)                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetRUNLED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE		erRet		= R_IN_OK;
	USHORT		usSetLed	= NX_LED_OFF;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
		usSetLed = NX_LED_OFF;
		break;
	case R_IN_LED_ON:										/* LED ON								*/
		usSetLed = NX_LED_ON;
		break;
	case R_IN_LED_BLINK_1000:								/* LED blinks in 1 second cycle			*/
		usSetLed = NX_LED_BLINK_1S;
		break;
	case R_IN_LED_BLINK_500:								/* LED blinks in 500 msec cycle			*/
		usSetLed = NX_LED_BLINK_500MS;
		break;
	case R_IN_LED_BLINK_200:								/* LED blinks in 200 msec cycle			*/
		usSetLed = NX_LED_BLINK_200MS;
		break;
	default:
		return R_IN_ERR_OUTOFRANGE;
		break;
	}

	/* Dispatch prohibited */
	vNX_vDisableDispatch();

	/* RUN LED control */
	vNX_SetRunLed(usSetLed);

	/* Dispatch permission */
	vNX_vEnableDispatch();

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (L ER1)                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetLERR1LED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
	case R_IN_LED_ON:										/* LED ON								*/
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* LERR1 LED control */
		(VOID)gerLedSetLer1Led((USHORT)ulCtrl);

		/* Dispatch permission */
		vNX_vEnableDispatch();
		break;
	default:
		erRet = R_IN_ERR_OUTOFRANGE;
		break;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  LED lighting control (L ER2)                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetLERR2LED(
	ULONG	ulCtrl											/**< LED control parameters				*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	switch (ulCtrl) {
	case R_IN_LED_OFF:										/* LED OFF								*/
	case R_IN_LED_ON:										/* LED ON								*/
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* LERR2 LED control */
		(VOID)gerLedSetLer2Led((USHORT)ulCtrl);

		/* Dispatch permission */
		vNX_vEnableDispatch();
		break;
	default:
		erRet = R_IN_ERR_OUTOFRANGE;
		break;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Disbale to LED lighting function                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_DisableLED(
	USHORT	usDisable										/**< Disbale to LED lighting function (ON: turn to disable, OFF: keep state) */
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	if (R_IN_LED_DISABLEPARAMETER_NORMAL == (usDisable & ~R_IN_LED_DISABLE_ALL)) {
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* LED mask setting */
		gvLedSetLedMask(usDisable);

		/* Dispatch permission */
		vNX_vEnableDispatch();
	}
	else {
		erRet = R_IN_ERR_OUTOFRANGE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Enable to LED lighting function                                      */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_EnableLED(
	USHORT	usEnable										/**< Enable to LED lighting function (ON: turn to enale, OFF: keep state) */
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	if (R_IN_LED_ENABLEPARAMETER_NORMAL == (usEnable & ~R_IN_LED_ENABLE_ALL)) {
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* LED mask clearing */
		gvLedClearLedMask(usEnable);

		/* Dispatch permission */
		vNX_vEnableDispatch();
	}
	else {
		erRet = R_IN_ERR_OUTOFRANGE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Update communication status LED                                      */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_UpdateLedStatus(VOID)
{
	ERRCODE		erRet		= R_IN_OK;
	ULONG		ulCommSts	= R_IN_COMMSTS_DISCONNECT;		/* Data link state				*/
	USHORT		usDlinkCtrl	= NX_LED_OFF;					/* D LINK LED status			*/

	/* Get data link status */
	(VOID)gerR_IN_GetCommumicationStatus(&ulCommSts);

	/* Branch according to data link status */
	switch (ulCommSts) {
	case R_IN_COMMSTS_CYC_DLINK:
		/* Data link (cyclic communication in progress) */
		usDlinkCtrl = NX_LED_ON;
		break;

	case R_IN_COMMSTS_CYC_STOP:
		/* Data link (cyclic communication is stopped) */
		usDlinkCtrl = NX_LED_BLINK_500MS;
		break;

	case R_IN_COMMSTS_DISCONNECT:
		/* Disconnected */
		usDlinkCtrl = NX_LED_OFF;
		break;

	default:
		/* Do nothing */
		break;
	}
	/* Dispatch prohibited */
	vNX_vDisableDispatch();

	/* Data link LED control */
	vNX_SetDlinkLed(usDlinkCtrl);

	/* LED update processing */
	vNX_UpdateLed();

	/* Dispatch permission */
	vNX_vEnableDispatch();

	return erRet;
}

/*********************************************************************************/
/** @brief  Set SD/RD LED mode                                                   */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetSDRDLEDMode(
	ULONG	ulMode											/**< SD/RD lighting mode		*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* Argument check */
	switch (ulMode) {
	case R_IN_LEDMODE_SD_RD:								/* Lighting mode: SD/RD			*/
	case R_IN_LEDMODE_SDRD1_SDRD2:							/* Lighting mode: SDRD1/SDRD2	*/
		/* Dispatch prohibited */
		vNX_vDisableDispatch();

		/* Set SD/RD LED mode */
		(VOID)gerLedSetSDRDLedMode(ulMode);

		/* Dispatch permission */
		vNX_vEnableDispatch();
		break;
	default:
		erRet = R_IN_ERR_OUTOFRANGE;
		break;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Start LED test                                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_StartTestLED(
	USHORT	usTestMode										/**< Test function enable/disable specification		*/
)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information							*/

	/* Argument check */
	if (R_IN_LED_TESTPARAMETER_NORMAL != (usTestMode & ~R_IN_LED_TESTMODE_ALL)) {
		return R_IN_ERR_OUTOFRANGE;
	}

	/* Enable MAC IP access */
	erRet = gerR_IN_EnableMACIPAccess();

	if (R_IN_OK == erRet) {

		/* Start LED test */
		erRet = gerTestLedStartCtrl(usTestMode);

		if (R_IN_ERR_FATAL == erRet) {
			/* Fatal error registration */
			stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
			stFatalError.ulErrorInfo = (ULONG)gerTestLedStartCtrl;
			(VOID)gerFecSetFatalError(&stFatalError);

			/* Fatal error notification */
			(VOID)gulFenNotifyFatalError();
		}

		/* Disable MAC IP access */
		(VOID)gerR_IN_DisableMACIPAccess();
	}
	else {
		erRet = R_IN_ERR_SEMAPHORE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Execute LED test                                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_ExecuteTestLED(
	USHORT	usTestLed										/**< Forced on/off specified	*/
)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information		*/

	/* Argument check */
	if (R_IN_LED_TESTPARAMETER_NORMAL != (usTestLed & ~R_IN_LED_TEST_ALL)) {
		return R_IN_ERR_OUTOFRANGE;
	}

	/* Enable MAC IP access */
	erRet = gerR_IN_EnableMACIPAccess();

	if (R_IN_OK == erRet) {
		/* Execute LED test */
		erRet = gerTestLedExeCtrl(usTestLed);

		if (R_IN_ERR_FATAL == erRet) {
			/* Fatal error registration */
			stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
			stFatalError.ulErrorInfo = (ULONG)gerTestLedExeCtrl;
			(VOID)gerFecSetFatalError(&stFatalError);

			/* Fatal error notification */
			(VOID)gulFenNotifyFatalError();
		}

		/* Disable MAC IP access */
		(VOID)gerR_IN_DisableMACIPAccess();
	}
	else {
		erRet = R_IN_ERR_SEMAPHORE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Stop LED test                                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_StopTestLED(VOID)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information		*/

	/* Enable MAC IP access */
	erRet = gerR_IN_EnableMACIPAccess();

	if (R_IN_OK == erRet) {
		/* Stop LED test */
		erRet = gerTestLedStopCtrl();

		if (R_IN_ERR_FATAL == erRet) {
			/* Fatal error registration */
			stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
			stFatalError.ulErrorInfo = (ULONG)gerTestLedStopCtrl;
			(VOID)gerFecSetFatalError(&stFatalError);

			/* Fatal error notification */
			(VOID)gulFenNotifyFatalError();
		}

		/* Disable MAC IP access */
		(VOID)gerR_IN_DisableMACIPAccess();
	}
	else {
		erRet = R_IN_ERR_SEMAPHORE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Get the network time (serial value)                                  */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_GetNetworkTime(
	USHORT*	pusSerial										/**< Network time (serial)			*/
)
{
	ERRCODE				erRet		= R_IN_OK;				/* Conversion error information		*/
	R_IN_UNIX_TIME_T	stUnixTime;							/* UNIX time						*/

	/* NULL check for arguments */
	if (NULL != pusSerial) {
		/* Get the network time (UNIX time) */
		(VOID)gerTmcReadTimeCounter(&stUnixTime);

		/* Network time (UNIX time) -> Network time (serial) conversion */
		erRet = gerClkCnvUnixTimeToSerial(&stUnixTime, pusSerial);
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Convert network time (serial value) to clock information             */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_NetworkTimeToDate(
	R_IN_TIMEINFO_T*	pstTimeInfo,						/**< Clock information				*/
	const USHORT*		pusSerial							/**< Network time (serial)			*/
)
{
	ERRCODE				erRet		= R_IN_OK;				/* Conversion error information		*/
	R_IN_UNIX_TIME_T	stUnixTime;							/* UNIX time						*/

	/* NULL check for arguments */
	if (NULL == pstTimeInfo) {
		return R_IN_ERR;
	}

	if (NULL == pusSerial) {
		return R_IN_ERR;
	}

	/* Network time (serial) -> Network time (UNIX time) conversion */
	erRet = gerClkCnvSerialToUnixTime(pusSerial, &stUnixTime);

	/* Network time (serial) within range */
	if (R_IN_OK == erRet) {
		/* Network time (UNIX time) -> Clock information conversion */
		erRet = gerClkCnvUnixTimeToDate(&stUnixTime, pstTimeInfo);
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Convert clock information to network time (serial value)             */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_DateToNetworkTime(
	const R_IN_TIMEINFO_T*	pstTimeInfo,					/**< Clock information				*/
	USHORT*					pusSerial						/**< Network time (serial)			*/
)
{
	ERRCODE				erRet		= R_IN_OK;				/* Conversion error information		*/
	R_IN_UNIX_TIME_T	stUnixTime;							/* UNIX time						*/

	/* NULL check for arguments */
	if (NULL == pstTimeInfo) {
		return R_IN_ERR;
	}

	if (NULL == pusSerial) {
		return R_IN_ERR;
	}

	/* Clock information -> Network time (UNIX time) conversion */
	erRet = gerClkCnvDateToUnixTime(pstTimeInfo, &stUnixTime);

	/* Check if the clock information is within the valid range */
	if (R_IN_OK == erRet) {
		/* Network time (UNIX time) -> Network time (serial) conversion */
		erRet = gerClkCnvUnixTimeToSerial(&stUnixTime, pusSerial);
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Get the network time (UNIX time)                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetUnixTime(
	R_IN_UNIX_TIME_T*	pstUnixTime							/**< Network time (UNIX time)		*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* NULL check for arguments */
	if (NULL != pstUnixTime) {
		/* Time counter value acquisition */
		(VOID)gerTmcReadTimeCounter(pstUnixTime);
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Convert network time (UNIX time) to clock information                */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_UnixTimeToDate(
	R_IN_TIMEINFO_T*		pstTimeInfo,					/**< Clock information				*/
	const R_IN_UNIX_TIME_T*	pstUnixTime						/**< Network time (UNIX time)		*/
)
{
	ERRCODE	erRet	= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL != pstTimeInfo)
	&& (NULL != pstUnixTime)) {
		/* Convert network time (UNIX time) to clock information */
		erRet = gerClkCnvUnixTimeToDate(pstUnixTime, pstTimeInfo);
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Convert clock information to network time (UNIX time)                */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_DateToUnixTime(
	const R_IN_TIMEINFO_T*	pstTimeInfo,					/**< Clock information				*/
	R_IN_UNIX_TIME_T*		pstUnixTime						/**< Network time (UNIX time)		*/
)
{
	ERRCODE	erRet	= R_IN_OK;								/* Conversion error information		*/

	/* NULL check for arguments */
	if ((NULL != pstTimeInfo)
	&& (NULL != pstUnixTime)) {
		/* Clock information -> Network time (UNIX time) */
		erRet = gerClkCnvDateToUnixTime(pstTimeInfo, pstUnixTime);
	}
	else {
		erRet = R_IN_ERR;
	}

	return erRet;
}


/*********************************************************************************/
/** @brief  Set network time offset                                              */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_SetUnixOffsetTime(
	LONGLONG	llOffsetSec,								/**< Offset (sec)							*/
	LONG		lOffsetNsec,								/**< Offset (nanosecond)					*/
	SHORT		sUtcOffsetMin,								/**< UTC offset (min)						*/
	SHORT		sSummerTimeOffsetMin						/**< Daylight savings time offset (min)		*/
)
{

	/* Set clock offset information	*/
	vNX_SetClockOffset(llOffsetSec,							/* Offset (sec)								*/
		lOffsetNsec,										/* Offset (nanosecond)						*/
		sUtcOffsetMin,										/* UTC offset (min)							*/
		sSummerTimeOffsetMin);								/* Daylight savings time offset (min)		*/

	return;
}


/*********************************************************************************/
/** @brief  Get network time offset                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no data)                          */
/*********************************************************************************/
ERRCODE gerR_IN_GetUnixOffsetTime(
	LONGLONG*	pllOffsetSec,								/**< Offset (sec)							*/
	LONG*		plOffsetNsec,								/**< Offset (nanosecond)					*/
	SHORT*		psUtcOffsetMin,								/**< UTC offset (min)						*/
	SHORT*		psSummerTimeOffsetMin						/**< Daylight savings time offset (min)		*/
)
{
	NX_ULONG ulRet    = NX_OFF;
	ERRCODE  erReturn = R_IN_ERR;

	/* NULL check for arguments */
	if ((NULL == pllOffsetSec)
		|| (NULL == plOffsetNsec)
		|| (NULL == psUtcOffsetMin)
		|| (NULL == psSummerTimeOffsetMin)) {
		/* If either is NULL */

		return erReturn;
	}
	else {
		/* In cases other than the above */

	}

	/* Get setting existence of clock offset	*/
	ulRet = ulNX_GetClockOffsetRecvFlag();

	/* Determine setting existence	*/
	if (NX_ON == ulRet) {
		/* If there is a setting	*/

		/* Clock offset send data retrieval process	*/
		vNX_GetClockOffset(pllOffsetSec,					/* Offset (sec)								*/
			plOffsetNsec,									/* Offset (nanosecond)						*/
			psUtcOffsetMin,									/* UTC offset (min)							*/
			psSummerTimeOffsetMin);							/* Daylight savings time offset (min)		*/

		erReturn = R_IN_OK;
	}
	else {
		/* In the case of no setting	*/

		erReturn = R_IN_ERR_NODATA;
	}

	return erReturn;
}

/*********************************************************************************/
/** @brief  Get statistical information                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetStatisticalInformation(
	R_IN_STATISTICS_T* pstStatisticalInformation			/**<  Statistical information			*/
)
{
	if (NULL == pstStatisticalInformation) {
		return R_IN_ERR;
	}
	else{
	}
	/* Get statistical information */
	(VOID)gerMibGetStatisticalInfo(pstStatisticalInformation);

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Clear statistical information                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_BUSY           :Processing                                      */
/*********************************************************************************/
ERRCODE gerR_IN_ClearStatisticalInformation( VOID )
{
	ERRCODE	erRet;											/* Return value			*/

	/* Clear statistical information */
	erRet = gerMibClearStatisticalInfo();

	return erRet;
}


/*********************************************************************************/
/** @brief  Detect R-IN32M4-CL3 events                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetEvent(
	R_IN_EVTPRM_INTERRUPT_T* pstEvent						/**< Interrupt factor	*/
)
{
	/* Parameter check */
	if (NULL == pstEvent) {
		return R_IN_ERR;
	}

	/* Detect events */
	(VOID)gerEvtdtctGetEvent((EVTDTCT_EVENT_EX_T*)pstEvent);

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Main R-IN32M4-CL3 event detection processing                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_Main(
	const R_IN_EVTPRM_INTERRUPT_T* pstEvent					/**< Interrupt factor	*/
)
{
	/* Parameter check */
	if (NULL == pstEvent) {
		return R_IN_ERR;
	}

	/* Communication disconnection event check */
	if (R_IN_ON == pstEvent->uniFlag.stBit.b1ZCommDisconnect) {
		/* Communication disconnection event processing */
		(VOID)gerCycsSetSndStopRequest(CYCS_CYCSTOP_LEAVE);	/* Cyclic transmission stop request setting			*/
	}

	/* Communication participation event check */
	if (R_IN_ON == pstEvent->uniFlag.stBit.b1ZCommConnect) {
		/* Communication participation event processing */
		(VOID)gerCycsClrSndStopRequest(CYCS_CYCSTOP_LEAVE);	/* Cyclic transmission stop request cancellation	*/
	}

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief  Restart detection R-IN32M4-CL3 events                                */
/** @retval R_IN_OK             :Normal end                                      */
/*********************************************************************************/
ERRCODE gerR_IN_RestartEvent( VOID )
{
	/* No processing required because there is no interrupt factor to be masked in event detection */
	return R_IN_OK;
}

/*********************************************************************************/
/** @brief  Regist IP address filtering function                                 */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_RegistIPAddressFilteringFunction(
	R_IN_IP_FILTERING_FUNCTION fpulFunction					/**< IP address filtering function	*/
)
{
	regist_ip_filr_func(fpulFunction);

	return;
}

/*********************************************************************************/
/** @brief  SLMP receive main processing                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_ReceivedSlmpMain(VOID)
{
	ERRCODE erReturn = R_IN_OK;								/* Return value	*/

	/* SLMP receive main processing */
	erReturn = gerSlmpTranReceiveMain();

	return erReturn;
}


/*********************************************************************************/
/** @brief  SLMP receive command execution                                       */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_ReceivedSlmpExecution(VOID)
{

	/* SLMP receive command execution */
	gvSlmpTranReceivedSlmp();

	return;
}


/*********************************************************************************/
/** @brief  Obtaining SLMP reception permission setting status by user reason    */
/** @retval R_IN_TRUE           :Receive allowed                                 */
/** @retval R_IN_FALSE          :Receive not allowed                             */
/*********************************************************************************/
BOOL gblR_IN_GetReceiveSlmpStatus(VOID)
{
	BOOL blRet = R_IN_FALSE;								/* Return value	*/

	/* Obtaining SLMP reception permission setting status by user reason */
	blRet = gblSlmpTranGetReceiveStatus();

	return blRet;
}


/*********************************************************************************/
/** @brief  SLMP reception permission setting by user reason                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetReceiveSlmpStatus(
	BOOL blEnable											/**< Receiving permission setting	*/
)
{
	ERRCODE erReturn = R_IN_ERR_OUTOFRANGE;					/* Return value						*/

	/* Validate arguments */
	if ((R_IN_FALSE == blEnable)
		|| (R_IN_TRUE == blEnable)) {
		/* If the argument is normal */

		/* SLMP reception permission setting by user reason */
		erReturn = gerSlmpTranSetReceiveStatus(blEnable);
	}
	else {
		/* If the argument is abnormal */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  SLMP Command decision registration process                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_SetSlmpCommand(
	const R_IN_SLMP_EXECUTION_RECEIVE_TBL_T*	pstUserSlmpReceiveFunctionTable	/**< SLMP receive and execute function table pointer */
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value					*/

	/* Validate arguments */
	if (NULL != pstUserSlmpReceiveFunctionTable) {
		/* Normal case */

		/* SLMP compatible command registration process */
		erReturn = gerSlmpTranSetSlmpCommand((R_IN_SLMP_EXECUTION_RECEIVE_TBL_T*)pstUserSlmpReceiveFunctionTable);

	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Send SLMP frame                                                      */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_SendSlmpFrame(VOID)
{
	ERRCODE erReturn = R_IN_OK;								/* Return value					*/

	/* Send SLMP frame */
	erReturn = gerSlmpTranSendRequest();

	return erReturn;
}


/*********************************************************************************/
/** @brief  Write SLMP send buffer                                               */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_WriteSlmpSendBuffer(
	const VOID*	pvReceiveBuffer,							/**< Receive buffer				*/
	USHORT		usSize,										/**< Send size (byte)			*/
	ULONG		ulIpAddress,								/**< Destination IP address		*/
	USHORT		usPort,										/**< Destination port number	*/
	USHORT		usPhysicalPort,								/**< Physical port number		*/
	VOID*		pvSendBuffer								/**< Transmit buffer			*/
)
{
	ERRCODE	erReturn		= R_IN_ERR;						/* Return value					*/
	USHORT*	pusFrameType	= pvSendBuffer;					/* Frame type					*/


	/* Validate arguments */
	/* Determine if transmit buffer is NULL */
	if (NULL == pvSendBuffer) {
		/* If null  */

		return R_IN_ERR;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Determine send size */
	if ((C_ZERO == usSize)
		|| (R_IN_SLMP_SPLIT_FRAME_SIZE_MAX < usSize)) {
		/* Exceeding the maximum size */

		return R_IN_ERR_OUTOFRANGE;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Determine physical port number */
	if (R_IN_MAX_PORT_NUMBER <= usPhysicalPort) {
		/* Physical port number out of range */

		return R_IN_ERR_OUTOFRANGE;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Determine whether the receive buffer is NULL and the transmit buffer is a response frame */
	if ((NULL == pvReceiveBuffer)
		&& ((R_IN_FRAME_TYPE_6E_RES == *pusFrameType)
			|| (R_IN_SLMP_FRAME_TYPE_4E_RES == *pusFrameType)
			|| (R_IN_SLMP_FRAME_TYPE_3E_RES == *pusFrameType))) {
		/* The receive buffer is not set in spite of the response frame */

		return R_IN_ERR;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Determine the frame type of the transmit buffer */
	if ((R_IN_SLMP_FRAME_TYPE_5E_REQ == *pusFrameType)
		|| (R_IN_SLMP_FRAME_TYPE_5E_RES == *pusFrameType)) {
		/* SLMP request/response frames not disclosure-kit capable */

		return R_IN_ERR;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Determine destination port number */
	if (SLMP_PORT_NW == usPort) {
		/* Port number used by communication driver */

		return R_IN_ERR;
	}
	else {
		/* In cases other than the above */

		/* No action */
	}

	/* Send Write */
	erReturn = gerSlmpTranWriteSendBuffer(
				pvSendBuffer,									/* Transmit buffer			*/
				usSize,											/* Send size (byte)			*/
				ulIpAddress,									/* Destination IP address	*/
				usPort,											/* Destination port number	*/
				usPhysicalPort,									/* Physical port number		*/
				pvReceiveBuffer);								/* Receive buffer			*/

	return erReturn;
}


/*********************************************************************************/
/** @brief  SLMP response frame send request processing                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_SetSlmpResponseFrameSendRequest(
	VOID*							pvResponseDataTopAddress,	/**< Top address of the response data				*/
	R_IN_SLMP_SEND_INFORMATION_T*	pstReceiveInformation		/**< Response data (send) additional information	*/
)
{
	ERRCODE	erReturn		= R_IN_ERR;							/* Return value						*/


	/* Validate arguments */
	if ((NULL == pvResponseDataTopAddress)
		|| (NULL == pstReceiveInformation)) {
		/* Top address is NULL */

		return erReturn;
	}
	else {
		/* Top address is not NULL */

		/* No action */
	}


	/* SLMP response frame send request processing */
	erReturn = gerSlmpTranSetResponseFrameSendRequest(
				pvResponseDataTopAddress,						/* Top address of the response data				*/
				pstReceiveInformation);							/* Response data (send) additional information	*/

		return erReturn;
}


/*********************************************************************************/
/** @brief  Release SLMP receive buffer                                          */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_ReleaseSlmpReceiveFrame(VOID)
{
	/* Release SLMP receive buffer */
	gvSlmpTranReleaseSlmpReceiveFrame();

	return;
}


/*********************************************************************************/
/** @brief  Get SLMP send buffer usage status                                    */
/** @retval R_IN_TRUE           :Data is in SLMP send buffer                     */
/** @retval R_IN_FALSE          :No data in SLMP send buffer                     */
/*********************************************************************************/
BOOL gblR_IN_GetSlmpSendBufferUsed(VOID)
{
	BOOL	blRet	= R_IN_FALSE;							/* Return value	*/

	/* Get SLMP transmission buffer usage status */
	blRet = gblSlmpTranGetSendBufferUsed();

	return blRet;
}


/*********************************************************************************/
/** @brief  Reset of own station                                                 */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_ExecuteReset(VOID)
{
	/* Reset of own station */
	gvSlmpReset();

	return;
}


/*********************************************************************************/
/** @brief  Start SLMP request timer                                             */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_StartSlmpRequestTimer(
	const R_IN_TIMEOUT_FUNCTION	fpvTimeoutFunction,			/**< Time-out execution function	*/
	ULONG						ulLimitTime,				/**< Timer duration (msec)			*/
	USHORT						usTimerId					/**< Timer ID (0 to 4)				*/
)
{
	ERRCODE erReturn = R_IN_ERR_OUTOFRANGE;					/* Return value						*/

	/* Validate arguments */
	/* Determine timeout execution function */
	if (NULL == fpvTimeoutFunction) {
		/* Abnormal case */

		return R_IN_ERR;
	}
	else {
		/* Normal case */

		/* No action */
	}

	/* Determine timer ID, timer duration */
	if ((usTimerId < R_IN_SLMP_REQUEST_MONITORING_NUM) && (C_ZERO != ulLimitTime)) {
		/* Normal case */

		/* Start SLMP request timer */
		erReturn = gerSlmpStartRequestTimer(
					fpvTimeoutFunction,						/* Timeout execution function		*/
					ulLimitTime,							/* Timer duration (msec)			*/
					usTimerId);								/* Timer ID							*/
	}
	else {
		/* Abnormal case */

		/* Set out of range to return value */
		erReturn = R_IN_ERR_OUTOFRANGE;
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Stop SLMP request timer                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_StopSlmpRequestTimer(
	USHORT	usTimerId										/**< Timer ID						*/
)
{
	ERRCODE erReturn = R_IN_ERR_OUTOFRANGE;					/* Return value						*/

	/* Validate arguments */
	if (usTimerId < R_IN_SLMP_REQUEST_MONITORING_NUM) {
		/* Normal case */

		/* Stop SLMP request timer */
		erReturn = gerSlmpStopRequestTimer(usTimerId);
	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Check IP address                                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CheckIpAddressSlmp(
	ULONG ulIPAddress,										/**< IP address			*/
	ULONG ulSubnetMask										/**< Subnet mask		*/
) {
	ERRCODE  erReturn = R_IN_ERR;							/* Return value			*/
	NX_ULONG ulReq	  = NX_UL_NG;							/* Processing result	*/

	/* IP address error checking process */
	ulReq = ulNX_ChkIpAddress(ulIPAddress, ulSubnetMask);

	/* Determine the processing result */
	if (NX_UL_OK == ulReq) {
		/* Normal case */
		erReturn = R_IN_OK;
	}
	else {
		/* Abnormal case */
		erReturn = R_IN_ERR;
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Copy memory                                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CopyMemory(
	VOID* pvDestination,									/**< Destination data address	*/
	const VOID* pvSource,									/**< Source data address		*/
	ULONG ulSize											/**< Copy data size (byte)		*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value					*/

	/* Validate arguments */
	if ((NULL != pvDestination)								/* Destination data address		*/
		&& (NULL != pvSource)								/* Source data address			*/
		&& (C_ZERO != ulSize)) {							/* Copy data size (byte)		*/
		/* Normal case */

		/* Copy memory */
		erReturn = gerMemcpy(
					pvDestination,							/* Destination data address		*/
					pvSource,								/* Source data address			*/
					ulSize);								/* Copy data size (byte)		*/
	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Fill memory (8bit)                                                   */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_FillMemory(
	VOID* pvDestination,									/**< Destination data address		*/
	UCHAR uchFillData,										/**< Fill data (00h to FFh)			*/
	ULONG ulSize											/**< Fill data size (byte)			*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value						*/

	/* Validate arguments */
	if ((NULL != pvDestination)
		&& (C_ZERO != ulSize)) {
		/* Normal case */

		/* Fill memory */
		erReturn = gerFillMemory(
					pvDestination,							/* Destination data address			*/
					uchFillData,							/* Fill data						*/
					ulSize);								/* Fill data size (byte)			*/
	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Fill memory (16bit)                                                  */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_FillMemory16(
	VOID* pvDestination,									/**< Destination data address		*/
	USHORT usFillData,										/**< Fill data (0000h to FFFFh)		*/
	ULONG ulSize											/**< Fill data size (word)			*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value						*/

	/* Validate arguments */
	if ((NULL != pvDestination)								/* Destination data address			*/
		&& (C_ZERO != ulSize)) {							/* Fill data size (word)			*/
		/* Normal case */

		/* Fill memory */
		erReturn = gerFillMemory16(
					pvDestination,							/* Destination data address			*/
					usFillData,								/* Fill data (0000h to FFFFh)		*/
					ulSize);								/* Fill data size (word)			*/
	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Fill memory (32bit)                                                  */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_FillMemory32(
	VOID* pvDestination,									/**< Destination data address				*/
	ULONG ulFillData,										/**< Fill data (00000000h to FFFFFFFFh)		*/
	ULONG ulSize											/**< Fill data size (double word)			*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value								*/

	/* Validate arguments */
	if ((NULL != pvDestination)								/* Destination data address					*/
		&& (C_ZERO != ulSize)) {							/* Fill data size (double word)				*/
		/* Normal case */

		/* Fill memory */
		erReturn = gerFillMemory32(
					pvDestination,							/* Destination data address					*/
					ulFillData,								/* Fill data (00000000h to FFFFFFFFh)		*/
					ulSize);								/* Fill data size (double word)				*/
	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Disable interrupt                                                    */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_DisableInt(VOID)
{
	/* Interrupt inhibit process */
	vNX_vDisableInterrupt();
	return;
}


/*********************************************************************************/
/** @brief  Enable interrupt                                                     */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_EnableInt(VOID)
{
	/* Interrupt authorization process */
	vNX_vEnableInterrupt();

	return;
}


/*********************************************************************************/
/** @brief  Disable dispatch                                                     */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_DisableDispatch(VOID)
{
	/* Dispatch inhibit process */
	vNX_vDisableDispatch();

	return;
}


/*********************************************************************************/
/** @brief  Enable dispatch                                                      */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_EnableDispatch(VOID)
{
	/* Dispatch authorization process */
	vNX_vEnableDispatch();

	return;
}


/*********************************************************************************/
/** @brief  Endian conversion (USHORT)                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_EndianShort(
	USHORT* pusVal											/**< Target of conversion	*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value				*/

	/* Validate arguments */
	if (NULL != pusVal) {
		/* Normal case */

		/* Endian conversion (USHORT) */
		*pusVal = usNX_CnvEndianShort(*pusVal);

		erReturn = R_IN_OK;

	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Endian conversion (ULONG)                                            */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_EndianLong(
	ULONG* pulVal											/**< Target of conversion	*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value				*/

	/* Validate arguments */
	if (NULL != pulVal) {
		/* Normal case */

		/* Endian conversion (ULONG) */
		*pulVal = ulNX_CnvEndianLong(*pulVal);

		erReturn = R_IN_OK;

	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}


/*********************************************************************************/
/** @brief  Endian conversion (ULONGULONG)                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_EndianLongLong(
	ULONGLONG* pullVal										/**< Target of conversion	*/
)
{
	ERRCODE erReturn = R_IN_ERR;							/* Return value				*/

	/* Validate arguments */
	if (NULL != pullVal) {
		/* Normal case */

		/* Endian conversion (ULONGULONG) */
		*pullVal = ullNX_CnvEndianLongLong(*pullVal);

		erReturn = R_IN_OK;

	}
	else {
		/* Abnormal case */

		/* No action */
	}

	return erReturn;
}

/*********************************************************************************/
/** @brief  Enable MAC IP access                                                 */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_SEMAPHORE  :Abnormal end (semaphore acquisition failure)    */
/*********************************************************************************/
ERRCODE gerR_IN_EnableMACIPAccess(VOID)
{
	ERRCODE erRet = R_IN_OK;

	/* Semaphore acquisition */
	erRet = gerSemGetSemaphoreWait(SEMID_NX_PHYACCESS);

	if (R_IN_OK != erRet) {
		erRet = R_IN_ERR_SEMAPHORE;
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Disable MAC IP access                                                */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_DisableMACIPAccess(VOID)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information	*/

	/* PHY register page write back processing */
	erRet = gerPhyWriteBackPage();

	if (R_IN_ERR_FATAL == erRet) {
		/* Fatal error registration */
		stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
		stFatalError.ulErrorInfo = (ULONG)gerPhyWriteRegistar;
		(VOID)gerFecSetFatalError(&stFatalError);

		/* Fatal error notification */
		(VOID)gulFenNotifyFatalError();
	}

	/* Semaphore return */
	(VOID)gerSemReleaseSemaphore(SEMID_NX_PHYACCESS);

	return erRet;
}

/*********************************************************************************/
/** @brief  Read PHY internal register                                           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_ReadPHY(
	ULONG	ulPort,											/**< Register read port			*/
	ULONG	ulAddr,											/**< PHY register address		*/
	ULONG*	pulData											/**< Data read from the PHY		*/
)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information		*/

	/* NULL check for arguments */
	if (NULL == pulData) {
		return R_IN_ERR;
	}

	/* Argument check */
	if ((R_IN_PORT1 != ulPort) && (R_IN_PORT2 != ulPort)) {
		return R_IN_ERR_OUTOFRANGE;
	}

	if (PHY_REGADR_MAX < ulAddr) {
		return R_IN_ERR_OUTOFRANGE;
	}

	/* PHY register reading */
	erRet = gerPhyReadRegistar(ulPort, ulAddr, pulData);

	/* Check for fatal errors */
	if (R_IN_ERR_FATAL == erRet) {
		/* Fatal error registration */
		stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
		stFatalError.ulErrorInfo = (ULONG)gerPhyReadRegistar;
		(VOID)gerFecSetFatalError(&stFatalError);

		/* Fatal error notification */
		(VOID)gulFenNotifyFatalError();
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Write to PHY internal register                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/** @retval R_IN_ERR_FATAL      :Abnormal end (fatal error occurred)             */
/*********************************************************************************/
ERRCODE gerR_IN_WritePHY(
	ULONG	ulPort,											/**< Register write port		*/
	ULONG	ulAddr,											/**< PHY register address		*/
	ULONG	ulData											/**< Data to be written to PHY	*/
)
{
	ERRCODE				erRet			= R_IN_OK;
	FATALERROR_EX_T		stFatalError;						/* Fatal error information		*/

	/* Argument check */
	if ((R_IN_PORT1 != ulPort) && (R_IN_PORT2 != ulPort)) {
		return R_IN_ERR_OUTOFRANGE;
	}

	if (PHY_REGADR_MAX < ulAddr) {
		return R_IN_ERR_OUTOFRANGE;
	}

	/* Setting PHY register page rewriting occurrence */
	(VOID)gerPhySetPageChangeOccur(ulAddr, ulPort);

	/* PHY register write */
	erRet = gerPhyWriteRegistar(ulPort, ulAddr, ulData);

	/* Check for fatal errors */
	if (R_IN_ERR_FATAL == erRet) {
		/* Fatal error registration */
		stFatalError.ulErrorCode = R_IN_FATALERROR_MDIOCOMMAND_TIMEOUT_ERROR;
		stFatalError.ulErrorInfo = (ULONG)gerPhyWriteRegistar;
		(VOID)gerFecSetFatalError(&stFatalError);

		/* Fatal error notification */
		(VOID)gulFenNotifyFatalError();
	}

	return erRet;
}

/*********************************************************************************/
/** @brief  Set MIB LED table                                                    */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_MIBLedTableDefine(
	UCHAR						uchNumberOfLED,				/**< Number of LED entry			*/
	const R_IN_MIBLEDDEFINE_T	*pstMIBLedDefine			/**< LED definition information		*/
)
{
	ERRCODE				erRet		= R_IN_OK;				/* Return value						*/

	/* NULL check */
	if (NULL == pstMIBLedDefine) {
		erRet = R_IN_ERR;
	}
	else {
	}

	/* LED entry count check */
	if ((R_IN_OK == erRet) && (R_IN_MIBLED_MAX < uchNumberOfLED)) {
		erRet = R_IN_ERR_OUTOFRANGE;
	}
	else {
	}

	/* LED status MIB information definition */
	if (R_IN_OK == erRet) {
		erRet = gerMibSetLedInfo(uchNumberOfLED, (MIB_LEDINFO_EX_T *)pstMIBLedDefine);
	}

	return erRet;
}


/*********************************************************************************/
/** @brief  Set error history                                                    */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetErrorHistory(
	R_IN_ERROR_INFORMATION_T* pstErrorInformation			/**< Error information				*/
)
{
	ERRCODE	erRet	= R_IN_OK;								/* Return value						*/

	/* Argument check */
	/* NULL judgment */
	if (NULL == pstErrorInformation) {
		/* If NULL */
		return R_IN_ERR;
	}
	else {
		/* If not NULL */
	}

	/* Determine error detail size */
	if (R_IN_ERROR_DETAIL_SIZE < pstErrorInformation->uchErrorDetailSize) {
		/* Out of range */
		return R_IN_ERR_OUTOFRANGE;
	}
	else {
		/* Within range */
	}

	/* Set error history */
	erRet = gerErrHisRegist(pstErrorInformation);

	return erRet;
}


/*********************************************************************************/
/** @brief  Clear error history                                                  */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_ClearErrorHistory(VOID)
{

	/* Clear error history */
	gvErrHisClear();

	return;
}

/*********************************************************************************/
/** @brief  Callback function registration                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_RegistCallback(
	ULONG ulFunctionType,												/**< Callback function type			*/
	R_IN_CALLBACK_FUNCTION fpulFunction									/**< Callback function entry point	*/
)
{
	ERRCODE erRet;														/* Return value						*/

	erRet = gerCbCtrlRegistFunc(ulFunctionType, fpulFunction);

	return erRet;
}


/*********************************************************************************/
/** @brief  Get own station operation mode                                       */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetNodeOperationMode(
	R_IN_NODE_OPERATION_MODE_T* pstMode		/**< Own station operation mode */
)
{
	USHORT	usSyncMode;						/* Operation mode */

	/* NULL check for arguments */
	if (NULL == pstMode) {
		return R_IN_ERR;
	}

	/* Get synchronous control mode */
	(VOID)gerSyncGetSyncMode(&usSyncMode);
	if (SYNC_MODE_UNSYNC == usSyncMode) {
		/* Operation mode: Asynchronous */
		pstMode->usSyncMode = R_IN_ASYNCHRONOUS;
	}
	else {
		/* Operation mode: Synchronous */
		pstMode->usSyncMode = R_IN_SYNCHRONOUS;
	}

	return R_IN_OK;
}

/*********************************************************************************/
/** @brief  Get synchronization loss flag                                        */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetSyncDeviationFlag(
	BOOL* pblSyncDeviationFlag			/**< Syncrhonization loss flag */
)
{
	ULONG ulSyncFlag = C_ZERO;			/* Synchronization loss flag */

	/* NULL check for arguments */
	if (NULL == pblSyncDeviationFlag) {
		return R_IN_ERR;
	}

	/* Get time synchronization loss detected status */
	ulSyncFlag = ulNX_GetOutOfTimeSyncSts();
	if (NX_TIMESYNC_CHK_NG != ulSyncFlag) {
		/* Undetect synchronization loss */
		*pblSyncDeviationFlag = R_IN_FALSE;
	}
	else {
		/* Detected synchronization loss */
		*pblSyncDeviationFlag = R_IN_TRUE;
	}

	return R_IN_OK;
}

/*********************************************************************************/
/** @brief  Request to stop the synchronization signal output                    */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_StopAppSyncSignal(
	USHORT* pusResult				/**< Execution result */
)
{
	USHORT usResult = NX_US_OK;		/* Synchronization loss flag */

	/* NULL check for arguments */
	if (NULL == pusResult) {
		return R_IN_ERR;
	}

	/* Synchronous signal output stop processing */
	usResult = usNX_StopAppSyncSig();
	if (NX_US_OK == usResult) {
		/* Normal termination of synchronization signal output stop */
		*pusResult = R_IN_SUCCEED;
	}
	else {
		/* Abnormal termination of synchronization signal output stop */
		*pusResult = R_IN_FAIL;
	}

	return R_IN_OK;
}


/*********************************************************************************/
/** @brief Set watchdog counter check error continuous error threshold           */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR_OUTOFRANGE :Abnormal end (out of range)                     */
/*********************************************************************************/
ERRCODE gerR_IN_SetWdcThreshold(
	USHORT	usWdcThreshold				/**< Watchdog counter check error continuous error threshold */
)
{
	ERRCODE	erRet	= R_IN_OK;			/* Return value                                              */

	/* Set watchdog counter check error continuous error threshold */
	erRet = gerWdcSetThreshold(usWdcThreshold);
	return erRet;
}


/*********************************************************************************/
/** @brief  Set Watchdog counter Info response data creation process             */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/** @retval R_IN_ERR_NODATA     :Abnormal end (no data)                          */
/*********************************************************************************/
ERRCODE gerR_IN_MakeResponseWdcInfomation(
	VOID*	pvResponseData,				/**< Response data      */
	USHORT*	pusDataSize					/**< Response data size */
)
{
	ERRCODE	erRet	= R_IN_OK;			/* Return value         */

	/* NULL check for arguments */
	if ((NULL == pvResponseData) || (NULL == pusDataSize)) {
		return R_IN_ERR;
	}

	/* Set Watchdog counter Info response data creation process */
	erRet = gerWdcMakeResponse(pvResponseData, pusDataSize);

	return erRet;
}


/*********************************************************************************/
/** @brief  WDC increment (for transfer)                                         */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_IncrementWdcUL(VOID)
{
	/* WDC increment (for transfer) */
	gvWdcIncSndWdc();
	return;
}


/*********************************************************************************/
/** @brief  Update WDC latch value (for tranfer)                                 */
/** @retval VOID                                                                 */
/*********************************************************************************/
VOID gvR_IN_LatchWdcUL(VOID)
{
	/* Update WDC latch value (for tranfer) */
	gvWdcLatchSndWdc();
	return;
}


/*********************************************************************************/
/** @brief  Get Watchdog counter UL                                              */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_GetWdcUL(
	BOOL	blWdcULValidFlag,				/**< WDC valid/invalid flag transmission control flag */
	USHORT* pusWdcUL						/**< WDC (for transfer)                               */
)
{
	ERRCODE	erRet			= R_IN_OK;		/* Return value                                       */
	USHORT	usSendWdcValid	= C_ZERO;		/* Valid flag                                         */
	USHORT	usSendWdc		= C_ZERO;		/* WDC latch value                                    */
	/* NULL check for arguments */
	if (NULL == pusWdcUL) {
		return R_IN_ERR;
	}
	else {
	}

	/* Get WDC valid/invalid (for transfer) */
	erRet = gerWdcGetSndWdcValid(blWdcULValidFlag, &usSendWdcValid);
	if (R_IN_OK != erRet) {
		/* When abnormal end */
		return erRet;
	}
	else {
	}

	/* Get WDC Latch value */
	erRet = gerWdcGetSndWdc(&usSendWdc);
	if (R_IN_OK != erRet) {
		/* When abnormal end */
		return erRet;
	}
	else {
	}

	/* Create watchdog counter UL */
	usSendWdcValid	= usSendWdcValid << R_IN_SHIFT15;
	*pusWdcUL		= (usSendWdc & ~R_IN_BIT15) | usSendWdcValid;

	return erRet;
}


/*********************************************************************************/
/** @brief  Check received WDC                                                   */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CheckWdcDL(
	USHORT	usWdc,							/**< Received WDC */
	USHORT*	pusCheckResult					/**< Check result */
)
{
	ERRCODE	erRet	= R_IN_OK;				/* Return value   */

	/* NULL check for arguments */
	if (NULL == pusCheckResult) {
		return R_IN_ERR;
	}

	/* Check received WDC */
	erRet = gerWdcCheckRcvWdc(usWdc, pusCheckResult);
	return erRet;
}

/*********************************************************************************/
/** @brief  Get network topology information                                     */
/** @retval R_IN_NETWORK_TOPOLOGY_UNKNOWN   :Undetermined network topology       */
/** @retval R_IN_NETWORK_TOPOLOGY_OTHER     :Other network topology              */
/** @retval R_IN_NETWORK_TOPOLOGY_RING      :Ring connection                     */
/*********************************************************************************/
ULONG gulR_IN_GetNetworkTopology( VOID )
{
	NX_ULONG ulTopology	= NX_TOPOLOGY_UNKNOWN;				/* Topology information	*/
	ULONG ulReturn 		= R_IN_NETWORK_TOPOLOGY_UNKNOWN;	/* Return value			*/

	/* Get topology information */
	ulTopology = ulNX_GetTopology();
	if (NX_TOPOLOGY_RING == ulTopology) {
		ulReturn	= R_IN_NETWORK_TOPOLOGY_RING;
	}
	else if (NX_TOPOLOGY_NOT_RING == ulTopology) {
		ulReturn	= R_IN_NETWORK_TOPOLOGY_OTHER;
	}
	else {
		ulReturn	= R_IN_NETWORK_TOPOLOGY_UNKNOWN;
	}

	return ulReturn;
}

#ifdef TSN_CAN_ENABLE
/*********************************************************************************/
/** @brief  Initialization of TSN CAN function                                   */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanInit(
	const R_IN_CAN_OD_TABLE_T*	pstObjectDictionary,	/**< Object Dictionary Table address		*/
	USHORT						usObjectNumber,			/**< Number of Object Dictionary (1 Fixed)	*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information				*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == pstObjectDictionary)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* Initialization	*/
	erResult = gerCanInit(
				pstObjectDictionary,					/* Object Dictionary Table address			*/
				usObjectNumber,							/* Number of Object Dictionary (1 Fixed)	*/
				pstErrorDetail);						/* Error details information				*/

	return erResult;
}


/*********************************************************************************/
/** @brief  Get ObjectDictionary handle                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanGetObjectHandle(
	USHORT						usObjectDictionaryNo,	/**< Object Dictionary Number (0 Fixed)			*/
	USHORT						usIndex,				/**< Index										*/
	R_IN_CAN_OD_T**				pstObject,				/**< Object address								*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information					*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == pstObject)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* Get OD handle */
	erResult = gerCanOdGetObjectHandle(
				usObjectDictionaryNo,					/* Object Dictionary Number (0 Fixed)	*/
				usIndex,								/* Index								*/
				pstObject,								/* Object address						*/
				pstErrorDetail);						/* Error details information			*/

	return erResult;
}


/*********************************************************************************/
/** @brief  ObjectDictionary read                                                */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanReadObject(
	USHORT						usObjectDictionaryNo,	/**< OD number						*/
	USHORT						usIndex,				/**< Index							*/
	UCHAR						uchSubIndex,			/**< SubIndex						*/
	USHORT						usRequestDataSize,		/**< Data read instruction size		*/
	USHORT*						pusDataSize,			/**< Data read size					*/
	UCHAR*						puchReadData,			/**< Read data						*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information		*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == pusDataSize)
		|| (NULL == puchReadData)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* OD read main	*/
	erResult = gerCanOdReadObjectMain(
				usObjectDictionaryNo,					/* OD number						*/
				usIndex,								/* Index							*/
				uchSubIndex,							/* SubIndex							*/
				usRequestDataSize,						/* Data read instruction size		*/
				pusDataSize,							/* Data read size					*/
				puchReadData,							/* Read data						*/
				pstErrorDetail);						/* Error details information		*/

	return erResult;
}


/*********************************************************************************/
/** @brief  ObjectDictionary write                                               */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanWriteObject(
	USHORT						usObjectDictionaryNo,	/**< OD number						*/
	USHORT						usIndex,				/**< Index							*/
	UCHAR						uchSubIndex,			/**< SubIndex						*/
	USHORT						usDataSize,				/**< Data write size				*/
	UCHAR*						puchWriteData,			/**< Write Data						*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information		*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == puchWriteData)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* OD write main	*/
	erResult = gerCanOdWriteObjectMain(
				usObjectDictionaryNo,					/* OD number						*/
				usIndex,								/* Index							*/
				uchSubIndex,							/* SubIndex							*/
				usDataSize,								/* Data write size					*/
				puchWriteData,							/* Write Data						*/
				pstErrorDetail);						/* Error details information		*/

	return erResult;
}


/*********************************************************************************/
/** @brief  ObjectDictionary block read                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanReadBlockObject(
	USHORT						usObjectDictionaryNo,	/**< OD number					*/
	USHORT						usIndex,				/**< Index						*/
	UCHAR						uchSubIndex,			/**< SubIndex					*/
	USHORT						usDataSize,				/**< Data read size				*/
	UCHAR*						puchReadData,			/**< Read data					*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information	*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == puchReadData)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* OD block read main	*/
	erResult = gerCanOdReadBlockObjectMain(
				usObjectDictionaryNo,					/* OD number					*/
				usIndex,								/* Index						*/
				uchSubIndex,							/* SubIndex						*/
				usDataSize,								/* Data read size				*/
				puchReadData,							/* Read data					*/
				pstErrorDetail);						/* Error details information	*/

	return erResult;
}


/*********************************************************************************/
/** @brief  Write ObjectDictionary block                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanWriteBlockObject(
	USHORT						usObjectDictionaryNo,	/**< OD number					*/
	USHORT						usIndex,				/**< Index						*/
	UCHAR						uchSubIndex,			/**< SubIndex					*/
	USHORT						usDataSize,				/**< Data write size			*/
	UCHAR*						puchWriteData,			/**< Write Data					*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail			/**< Error details information	*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == puchWriteData)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* OD block write main	*/
	erResult = gerCanOdWriteBlockObjectMain(
				usObjectDictionaryNo,					/* OD number					*/
				usIndex,								/* Index						*/
				uchSubIndex,							/* SubIndex						*/
				usDataSize,								/* Data write size				*/
				puchWriteData,							/* Write Data					*/
				pstErrorDetail);						/* Error details information	*/

	return erResult;
}


/*********************************************************************************/
/** @brief  Get NMTState                                                         */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanGetNmtState(
	USHORT*						pusCurrentNmtState,			/**< Current NMTState						*/
	USHORT*						pusMasterRequestedNmtState,	/**< NMTState received from master station	*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail				/**< Error details information				*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if ((NULL == pusCurrentNmtState)
		|| (NULL == pusMasterRequestedNmtState)
		|| (NULL == pstErrorDetail)) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* Get NMTState	*/
	erResult = gerCanNmtGetState(
				pusCurrentNmtState,							/* Current NMTState							*/
				pusMasterRequestedNmtState,					/* NMTState received from master station	*/
				pstErrorDetail);							/* Error details information				*/

	return erResult;
}


/*********************************************************************************/
/** @brief  NMTState setting                                                     */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanSetNmtState(
	USHORT						usMasterRequestNmtState,	/**< NMT State received from master station		*/
	R_IN_CAN_ERROR_DETAIL_T*	pstErrorDetail				/**< Error details information					*/
)
{
	ERRCODE	erResult			= R_IN_OK;

	/* NULL check for arguments */
	if (NULL == pstErrorDetail) {
		/* If NULL */

		return R_IN_ERR;
	}

	/* NMTState setting	*/
	erResult = gerCanNmtSetState(
				usMasterRequestNmtState,					/* NMT State received from master station		*/
				pstErrorDetail);							/* Error details information					*/

	return erResult;
}

/*********************************************************************************/
/** @brief  Update RPDO                                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanUpdateRPDO(
	R_IN_CAN_ERROR_DETAIL_T *pstErrorDetail					/* Error details information					*/
)
{
	ERRCODE	erRet = R_IN_OK;

	/* NULL check for arguments */
	if (NULL == pstErrorDetail) {
		/* If NULL */

		return R_IN_ERR;
	}

	erRet = gerCanPdoUpdateRPDO(pstErrorDetail);
	return erRet;
}

/*********************************************************************************/
/** @brief  Update TPDO                                                          */
/** @retval R_IN_OK             :Normal end                                      */
/** @retval R_IN_ERR            :Abnormal end                                    */
/*********************************************************************************/
ERRCODE gerR_IN_CanUpdateTPDO(
	R_IN_CAN_ERROR_DETAIL_T *pstErrorDetail					/* Error details information					*/
)
{
	ERRCODE	erRet = R_IN_OK;

	/* NULL check for arguments */
	if (NULL == pstErrorDetail) {
		/* If NULL */

		return R_IN_ERR;
	}

	erRet = gerCanPdoUpdateTPDO(pstErrorDetail);
	return erRet;
}

#endif

/*** EOF ***/
