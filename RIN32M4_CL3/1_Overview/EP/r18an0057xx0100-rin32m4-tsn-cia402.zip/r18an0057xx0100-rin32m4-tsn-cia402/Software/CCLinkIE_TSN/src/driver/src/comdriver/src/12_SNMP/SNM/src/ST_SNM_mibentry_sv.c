/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNC_errcode.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNM_lldpmib_sv_l.h"
#include <snmp.h>
#include "ST_SNC_debug_com_l.h"
#else
#include <common.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif
#ifdef MASTER
#else
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
#endif




#ifdef SWPS
NX_ULONG ulST_SNM_SelectTblSet(
	NX_VOID*					pAsn,
	ST_SNM_MibTblSet** 		pstTblSet
)
{
	ST_SNM_MibTblSet*	pastComp[ST_SNM_MIBCLASS_MAX];
	NX_ULONG				bOK		= TRUE;
	NX_UCHAR				uchCnt	= 0;

	ST_SNM_GetExtMibTbl(&pastComp[ST_SNM_MIBCLASS_EXT]);
	ST_SNM_GetLldpMibTbl(&pastComp[ST_SNM_MIBCLASS_LLDP]);

	for(uchCnt = ST_SNM_MIBCLASS_EXT; uchCnt < ST_SNM_MIBCLASS_MAX; uchCnt++ ) {
		if(NX_NULL != pastComp[uchCnt]->checkOidPre) {
			bOK = pastComp[uchCnt]->checkOidPre(pAsn);
			if(TRUE == bOK){

				DBGTRACE("%s %s", __FUNCTION__,
					((uchCnt==ST_SNM_MIBCLASS_EXT) ?  "EXTMIB" :
					((uchCnt==ST_SNM_MIBCLASS_LLDP) ? "LLDMIB" : "OTHRMIB")));
				*pstTblSet = pastComp[uchCnt]; 
				return ST_SNC_OK;

			}
			else {
				;
			}
		}
		else {
			;
		}		
	}

	return ST_SNC_NG_PARAM_RANGE;
}
#endif

NX_ULONG ulST_SNM_GetAddr(NX_UCHAR uchMibClass)
{
	ST_SNM_MibTblSet*		pstExec = NX_NULL;
	NX_ULONG					ulRet	= ST_SNC_OK;

	switch(uchMibClass) {
	case ST_SNM_MIBCLASS_EXT:
		ST_SNM_GetExtMibTbl(&pstExec);
		break;

#ifdef SWPS
	case ST_SNM_MIBCLASS_LLDP:
		ST_SNM_GetLldpMibTbl(&pstExec);
		break;
#endif

	default:
		return	ST_SNC_NG_PARAM_RANGE;
	}
	
	if(NX_NULL != pstExec->updateAddr) {
		ulRet = pstExec->updateAddr();
	}
	else {
		;
	}

	return ulRet;
}


NX_ULONG ulST_SNM_Oidmap2Mibtype(
	NX_UCHAR				uchMibClass,
	NX_USHORT				usOidmap,
	ST_SNC_Mibtype* 	peMibType
)
{
	ST_SNM_GetItem			stItem;
	ST_SNM_MibTblSet*		pstExec  = NX_NULL;
	NX_ULONG					ulRet	 = ST_SNC_OK;

	switch(uchMibClass) {
	case ST_SNM_MIBCLASS_EXT:
		ST_SNM_GetExtMibTbl(&pstExec);
		break;

#ifdef SWPS
	case ST_SNM_MIBCLASS_LLDP:
		ST_SNM_GetLldpMibTbl(&pstExec);
		break;
#endif

	default:
		return	ST_SNC_NG_PARAM_RANGE;
	}
	
	if(NX_NULL != pstExec->getItem) {
		ST_SNM_SetGetItem(&stItem, ST_SNM_MIBENTRY_TYPE, usOidmap, 0, FALSE, peMibType);
		ulRet = pstExec->getItem(&stItem);
	}
	else {
		;
	}

	return ulRet;
}

NX_ULONG ulST_SNM_Oidmap2MibAttr(
	NX_UCHAR 				uchMibClass,
	NX_USHORT 				usOidmap,
	NX_UCHAR 				uchIdxArayInf,
	ST_SNC_MibAttr*		pstAttr
)
{
	ST_SNM_GetItem			stItem;
	ST_SNM_MibTblSet*		pstExec  = NX_NULL;
	NX_ULONG					ulRet	 = ST_SNC_OK;

	switch(uchMibClass) {
	case ST_SNM_MIBCLASS_EXT:
		ST_SNM_GetExtMibTbl(&pstExec);
		break;

#ifdef SWPS
	case ST_SNM_MIBCLASS_LLDP:
		ST_SNM_GetLldpMibTbl(&pstExec);
		break;
#endif

	default:
		return	ST_SNC_NG_PARAM_RANGE;
	}
	
	if(NX_NULL != pstExec->getItem) {
		ST_SNM_SetGetItem(&stItem, ST_SNM_MIBENTRY_ATTR, usOidmap, uchIdxArayInf, FALSE, pstAttr);
		ulRet = pstExec->getItem(&stItem);
	}
	else {
		;
	}

	return ulRet;
}


NX_VOID ST_SNM_SetGetItem(
	ST_SNM_GetItem* 	pstItem,
	NX_UCHAR				uchItemType,
	NX_USHORT				usOidmap,
	NX_UCHAR				uchIdxAryInf,
	NX_ULONG				bCallSnmpReq,
	NX_VOID*				pObj
)
{
	pstItem->uchItemType		= uchItemType;
	pstItem->usOidmap			= usOidmap;
	pstItem->uchIdxAryInf		= uchIdxAryInf;
	pstItem->bCallSnmpReq		= bCallSnmpReq;
	pstItem->pObj				= pObj;
	return ;
}

