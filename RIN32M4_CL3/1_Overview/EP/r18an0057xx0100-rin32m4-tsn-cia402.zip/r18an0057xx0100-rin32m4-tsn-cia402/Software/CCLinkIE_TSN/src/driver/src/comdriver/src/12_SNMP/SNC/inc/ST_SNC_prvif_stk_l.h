/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __ST_SNC_PRVIF_STK_L_H_INCLUDED__
#define __ST_SNC_PRVIF_STK_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_stk_l.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_stk_l.h>
#else
#include "ST_SNC_oidmap.h"
#include "ST_SNC_stk_l.h"
#endif
#endif

#define ST_SNC_START_INSTRUCTION                        (0x00)
#define ST_SNC_STOP_INSTRUCTION                         (0x01)
#define ST_SNC_CONFIG_INSTRUCTION                       (0x02)

#define ST_SNC_COMMUNITY_NAME_LEN                       (256)
#define ST_SNC_NUMBER_OF_COMMUNITY_MAX                  (4)

typedef struct ST_SNC_ConfigSnmp_TAG {
    const NX_CHAR*     pacCommunity[ST_SNC_NUMBER_OF_COMMUNITY_MAX];
    NX_USHORT          usRcvPort;
    NX_USHORT          usPadding;
} ST_SNC_ConfigSnmp;


NX_ULONG ulST_SNC_Instruction(
	NX_UCHAR ucType,
	const ST_SNC_ConfigSnmp* pstConfig,
	NX_ULONG* pulDtlErrorCode
);
NX_ULONG ulST_SNC_MibSet(
	NX_USHORT				usOidmap,
	NX_USHORT				usMesType,
	NX_UCHAR				ucCtlType,
	NX_USHORT				usIdx,
	const NX_VOID* 		pData,
	NX_ULONG				ulDataSize,
	NX_ULONG*				pulDtlErrorCode
);
NX_VOID ST_SNC_MibSetMibMng(
	ST_SNC_MibMng*		pstMib,
	NX_USHORT 				usOidmap,
	NX_UCHAR 				ucCtlType,
	NX_USHORT 				usIdx
);



#endif
