/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_txn.h"
#include "TOOL_api.h"
#include "INTR_api.h"
#include "ccienx_task.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "INTR_common.h"



NX_VOID vINTR_SndAbnormalEnd (NX_VOID);
NX_VOID vINTR_NonCyclicSndEndTS1_7 (NX_VOID);
NX_VOID vINTR_NonCyclicSndEndTS0 (NX_VOID);
NX_VOID vINTR_DiscriptHWMenChgEnd (NX_VOID);

NX_STATIC INTFUNCDATA gstIntHighTxnFuncList[] ={
	{INTR_TXH_ERR,	vINTR_SndAbnormalEnd},
	{TABLE_END,		NULL},
};

NX_STATIC INTFUNCDATA gstIntLowTxnFuncList[] ={
	{INTR_TXL_NCYC_COMPTS1_7,	vINTR_NonCyclicSndEndTS1_7},
	{INTR_TXL_NCYC_COMPTS0,		vINTR_NonCyclicSndEndTS0},
	{INTR_TXL_CHANGE_HWAREA,	vINTR_DiscriptHWMenChgEnd},
	{TABLE_END,					NULL}
};

NX_ULONG gulIntTxnHighCount = 0;



NX_VOID vINTR_IntHighTx (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	
	ulFactorInt = NGN_CN_TN1_REG->R_TNINTH.DATA;
	ulFactorIntMask = NGN_CN_TN1_REG->R_TNINTHMSK.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	gulIntTxnHighCount |= ulFactorIntWork;
	NGN_CN_TN1_REG->R_TNINTH.DATA = ulFactorIntWork;
	
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntHighTxnFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntHighTxnFuncList[usCount].ulBitNo) {
			gstIntHighTxnFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntHighTxnFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_VOID vINTR_IntLowTx (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	
	ulFactorInt = NGN_CN_TN1_REG->R_TNINTL.DATA;
	ulFactorIntMask = NGN_CN_TN1_REG->R_TNINTLMSK.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	NGN_CN_TN1_REG->R_TNINTL.DATA = ulFactorIntWork;
	
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntLowTxnFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntLowTxnFuncList[usCount].ulBitNo) {
			gstIntLowTxnFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntLowTxnFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_VOID vINTR_SndAbnormalEnd (NX_VOID)
{
	NX_ULONG	ulTnmustWork;
	
	ulTnmustWork =  NGN_CN_TN1_REG->R_TNMUST.DATA;
	ulTnmustWork &= (NX_ULONG)0x0000FF00;
	ulTnmustWork |= ulTnmustWork >> 8;
	set_flg(EVFLGID_NX_NOCYCTXCOMP, ulTnmustWork);
	return;
}

NX_VOID vINTR_NonCyclicSndEndTS1_7 (NX_VOID)
{
	NX_ULONG	ulTnmustWork;
	
	ulTnmustWork =  NGN_CN_TN1_REG->R_TNMUST.DATA;
	ulTnmustWork &= (NX_ULONG)0x000000FE;
	set_flg(EVFLGID_NX_NOCYCTXCOMP, ulTnmustWork);
	return;
}

NX_VOID vINTR_NonCyclicSndEndTS0 (NX_VOID)
{
	NX_ULONG	ulTnmustWork;
	
	ulTnmustWork =  NGN_CN_TN1_REG->R_TNMUST.DATA;
	ulTnmustWork &= (NX_ULONG)0x00000001;
	set_flg(EVFLGID_NX_NOCYCTXCOMP, ulTnmustWork);
	return;
}

NX_VOID vINTR_DiscriptHWMenChgEnd (NX_VOID)
{
	set_flg(EVFLGID_NX_TXDISC_UPD, FLGP_TXDISC_UPD);
	return;
}

NX_ULONG ulINTR_CheckIntLowTx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_CN_TN1_REG->R_TNINTL.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntLowTx (
	NX_ULONG	ulCheckTarget
)
{
	NGN_CN_TN1_REG->R_TNINTL.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntLowTx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLow_TXMask;
	vNX_vDisableDispatch();
	ulLow_TXMask = NGN_CN_TN1_REG->R_TNINTLMSK.DATA;
	NGN_CN_TN1_REG->R_TNINTLMSK.DATA = ulLow_TXMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntLowTx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLow_TXMask;
	
	vNX_vDisableDispatch();
	ulLow_TXMask = NGN_CN_TN1_REG->R_TNINTLMSK.DATA;
	NGN_CN_TN1_REG->R_TNINTLMSK.DATA = ulLow_TXMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_ULONG ulINTR_CheckIntHighTx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_CN_TN1_REG->R_TNINTH.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntHighTx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_CN_TN1_REG->R_TNINTH.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntTxnHighCount |= ulCountTarget;
	}
	NGN_CN_TN1_REG->R_TNINTH.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntHighTx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHigh_TXMask;
	vNX_vDisableDispatch();
	ulHigh_TXMask = NGN_CN_TN1_REG->R_TNINTHMSK.DATA;
	NGN_CN_TN1_REG->R_TNINTHMSK.DATA = ulHigh_TXMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntHighTx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHigh_TXMask;
	
	vNX_vDisableDispatch();
	ulHigh_TXMask = NGN_CN_TN1_REG->R_TNINTHMSK.DATA;
	NGN_CN_TN1_REG->R_TNINTHMSK.DATA = ulHigh_TXMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}
