/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "JADE.h"
#include "R_IN32M4_CL3.h"
#include "nx_mpu_common.h"

#define	NGN_PART_SHIFT_2		NX_SHIFT2
#define	PHYRST_PORT_SHIFT_3		NX_SHIFT3
#define	NGN_PART_MSK			((NX_USHORT)1)
#define	RELAY_PART_MSK			((NX_USHORT)2)
#define	MAC_SET_MSK				((NX_USHORT)6)
#define	PHYRST_PORT1_MSK		((NX_USHORT)1)
#define	PHYRST_PORT2_MSK		((NX_USHORT)2)
#define	PHYRST_PORT_SET_MSK		((NX_USHORT)24)
#define	SYSRST_ON				((NX_USHORT)0)
#define	SYSRST_OFF				((NX_USHORT)1)
#define	PHYRST_ON				((NX_ULONG)0)
#define	PHYRST_OFF				((NX_ULONG)1)

NX_VOID vNX_CtrlSystemReset (
	NX_USHORT usResetValue
)
{
	NX_USHORT	usSet	= (NX_USHORT)NX_ZERO;

	if ((NX_USHORT)NX_RESET_ON == usResetValue) {
		usSet = SYSRST_ON;
	}
	else {
		usSet = SYSRST_OFF;
	}

	NX_SYSTEMPROTECT_UNLOCK();
	RIN_SYS->SYSRESET = usSet;
	NX_SYSTEMPROTECT_LOCK();

	return;
}

NX_VOID vNX_CtrlMacReset (
	NX_USHORT usResetValue
)
{
	NX_ULONG	ulRegSet	= NX_ZERO;

	ulRegSet |= (NX_ULONG)(usResetValue & RELAY_PART_MSK);
	ulRegSet |= (NX_ULONG)((usResetValue & NGN_PART_MSK) << NGN_PART_SHIFT_2);

	NX_JADE_SYS->R_MACPHY_RST |= ulRegSet & MAC_SET_MSK;

	return;
}

NX_VOID vNX_CtrlPhyReset (
	NX_USHORT usResetValue
)
{
	NX_USHORT	usSet	= (NX_USHORT)NX_ZERO;

	if ((NX_USHORT)NX_RESET_ON == usResetValue) {
		usSet = (NX_USHORT)PHYRST_ON;
	}
	else {
		usSet = (NX_USHORT)PHYRST_OFF;
	}

	NX_SYSTEMPROTECT_UNLOCK();
	RIN_SYS->PHYRST = usSet;
	NX_SYSTEMPROTECT_LOCK();

	return;
}

NX_VOID vNX_CtrlPhyPortReset (
	NX_USHORT usResetValue
)
{
	NX_ULONG	ulRegSet	= NX_ZERO;

	ulRegSet |= (NX_ULONG)((usResetValue & PHYRST_PORT1_MSK) << PHYRST_PORT_SHIFT_3);
	ulRegSet |= (NX_ULONG)((usResetValue & PHYRST_PORT2_MSK) << PHYRST_PORT_SHIFT_3);

	NX_JADE_SYS->R_MACPHY_RST |= ulRegSet & PHYRST_PORT_SET_MSK;

	return;
}

