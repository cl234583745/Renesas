/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_EXCLUSION_COM_L_H_INCLUDED__
#define __ST_SNC_EXCLUSION_COM_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#endif
#endif

typedef enum ST_SNC_ExecNo_TAG {
	ST_SNC_EXECNO_00,
	ST_SNC_EXECNO_01,
	ST_SNC_EXECNO_02,
	ST_SNC_EXECNO_03,
	ST_SNC_EXECNO_04,
	ST_SNC_EXECNO_05,
	ST_SNC_EXECNO_06,
	ST_SNC_EXECNO_07,
	ST_SNC_EXECNO_08,
	ST_SNC_EXECNO_09,
	ST_SNC_EXECNO_10,
	ST_SNC_EXECNO_11,
	ST_SNC_EXECNO_12,
	ST_SNC_EXECNO_13,
	ST_SNC_EXECNO_14,
	ST_SNC_EXECNO_15,
	ST_SNC_EXECNO_16,
	ST_SNC_EXECNO_17,
	ST_SNC_EXECNO_18,
	ST_SNC_EXECNO_19,
	ST_SNC_EXECNO_20,
	ST_SNC_EXECNO_21,
	ST_SNC_EXECNO_22,
	ST_SNC_EXECNO_23,
	ST_SNC_EXECNO_24,
	ST_SNC_EXECNO_25,
	ST_SNC_EXECNO_26,
	ST_SNC_EXECNO_27,
	ST_SNC_EXECNO_28,
	ST_SNC_EXECNO_29,
	ST_SNC_EXECNO_30,
	ST_SNC_EXECNO_31,
	ST_SNC_EXECNO_32,
	ST_SNC_EXECNO_33,
	ST_SNC_EXECNO_34,
	ST_SNC_EXECNO_35,
	ST_SNC_EXECNO_36,
	ST_SNC_EXECNO_37,
	ST_SNC_EXECNO_38,
	ST_SNC_EXECNO_39,
	ST_SNC_EXECNO_40,
	ST_SNC_EXECNO_41,
	ST_SNC_EXECNO_42,
	ST_SNC_EXECNO_43,
	ST_SNC_EXECNO_44,
	ST_SNC_EXECNO_45,
} ST_SNC_ExecNo; 

typedef struct ST_SNC_ExecObj_TAG {
	NX_VOID		*pvObj;
	NX_UCHAR		uchNumber;
	NX_UCHAR		uchPadding[3];
} ST_SNC_ExecObj;

extern NX_ULONG ulST_SNC_ExecCreate(ST_SNC_ExecObj* pstObj);
extern NX_ULONG ulST_SNC_ExecFinal(ST_SNC_ExecObj* pstObj);
extern NX_ULONG ulST_SNC_ExecLock(ST_SNC_ExecObj* pstObj);
extern NX_ULONG ulST_SNC_ExecUnlock(ST_SNC_ExecObj* pstObj);

#endif
