/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNC.h"
#include "ST_SNC_stk_l.h"
#include "ST_SNC_prvif_stk_l.h"
#include "ST_SNC_sync_com_l.h"
#else
#include <common.h>
#include <28_NPS/Include/ST_SNC.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_stk_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_prvif_stk_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_sync_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNC.h"
#include "ST_SNC_stk_l.h"
#include "ST_SNC_prvif_stk_l.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNM_sv_l.h"

#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
#endif

typedef enum {
	ST_SNC_STS_INIT,
	ST_SNC_STS_WAIT,
	ST_SNC_STS_EXEC,
} ST_SNC_Status;

typedef enum {
	ST_SNC_EVT_INIT,
	ST_SNC_EVT_START,
	ST_SNC_EVT_STOP,
	ST_SNC_EVT_TERM,
} ST_SNC_Event;

static NX_UCHAR guchST_SNC_Status = ST_SNC_STS_INIT;

static NX_ULONG gulST_SNC_StateMachine(ST_SNC_Event eEvent, NX_ULONG bUpdate);
static NX_ULONG gulST_SNC_CheckOidmap(NX_USHORT usOidmap, NX_UCHAR ucType);

NX_ULONG ulST_SNC_ConvErrCode(NX_ULONG ulErrCode,	ST_SNC_Event eEvent);



static NX_ULONG gulST_SNC_StateMachine(ST_SNC_Event eEvent, NX_ULONG bUpdate)
{
	NX_ULONG	ulRet				= ST_SNC_OK;
	NX_UCHAR	uchUpdateStatus		= guchST_SNC_Status;

	switch(uchUpdateStatus) {
	case ST_SNC_STS_INIT:

		switch(eEvent){
		case ST_SNC_EVT_INIT:
			uchUpdateStatus = ST_SNC_STS_WAIT;
			break;
		case ST_SNC_EVT_TERM:
			ulRet = ST_SNC_NG_IGNORE;
			break;
		case ST_SNC_EVT_START:
		case ST_SNC_EVT_STOP:
		default:
			ulRet = ST_SNC_NG_EVENT;
			break;
		}
		break;

	case ST_SNC_STS_WAIT:

		switch(eEvent){
		case ST_SNC_EVT_INIT:
		case ST_SNC_EVT_STOP:
			ulRet = ST_SNC_NG_IGNORE;
			break;
		case ST_SNC_EVT_START:
			uchUpdateStatus = ST_SNC_STS_EXEC;
			break;
		case ST_SNC_EVT_TERM:
			uchUpdateStatus = ST_SNC_STS_INIT;
			break;
		default:
			ulRet = ST_SNC_NG_EVENT;
			break;
		}
		break;

	case ST_SNC_STS_EXEC:

		switch(eEvent){
		case ST_SNC_EVT_INIT:
		case ST_SNC_EVT_START:
		case ST_SNC_EVT_TERM:
			ulRet = ST_SNC_NG_IGNORE;
			break;
		case ST_SNC_EVT_STOP:
			uchUpdateStatus = ST_SNC_STS_WAIT;
			break;
		default:
			ulRet = ST_SNC_NG_EVENT;
			break;
		}
		break;

	default:
		ulRet = ST_SNC_NG_STATE;
		break;
	}

	if(TRUE == bUpdate) {
		guchST_SNC_Status = uchUpdateStatus;
	}
	else {
		;
	}

	return ulRet;
}

static NX_ULONG gulST_SNC_CheckOidmap(
	NX_USHORT				usOidmap,
	NX_UCHAR				ucType
)
{
	if (ST_SNC_MAP_MAX <= usOidmap) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	switch (ucType) {
	case ST_SNC_ARRAY_NON:
	case ST_SNC_ARRAY_ADD:
	case ST_SNC_ARRAY_MOD:
	case ST_SNC_ARRAY_DEL:
		break;
	default:
		return ST_SNC_NG_PARAM_RANGE;
	}
	

	return ST_SNC_OK;
}

#ifdef MASTER
NX_ULONG gulST_SNC_Initialize(
	const	CCIEN_INIT_PLATFORM_PARMS_TAG*	pPlatformParms
)
#else
NX_ULONG gulST_SNC_Initialize(NX_VOID)
#endif
{
	NX_ULONG	ulRet = ST_SNC_OK;

#ifdef SWPS
#else
	ulRet = ulST_SNM_Start();
#ifdef MASTER
	if(ST_SNC_OK == ulRet) {
#endif
#endif
#ifdef MASTER
	ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_INIT, TRUE);
	if(ulRet == ST_SNC_OK) {
		;
	}
	else {
		if(ST_SNC_NG_IGNORE == ulRet){
			ulRet = ST_SNC_OK;
		}
	}
#ifdef SWPS
#else
	}
	else {
		;
	}
#endif
	return ulST_SNC_ConvErrCode(ulRet, ST_SNC_EVT_INIT);
#else
	return ulRet;
#endif
}

NX_ULONG gulST_SNC_Terminate( NX_VOID )
{
	NX_ULONG	ulRet = ST_SNC_OK;

#ifdef SWPS
#else
	ulRet = ulST_SNM_Stop();
	if(ST_SNC_OK == ulRet) {
#endif
	ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_TERM, TRUE);
	if(ulRet == ST_SNC_OK) {
		;
	}
	else {
		if(ST_SNC_NG_IGNORE == ulRet){
			ulRet = ST_SNC_OK;
		}
	}
#ifdef SWPS
#else
	}
	else {
		;
	}
#endif

#ifdef MASTER
	return ulST_SNC_ConvErrCode(ulRet, ST_SNC_EVT_TERM);
#else
	return ulRet;
#endif
}


NX_ULONG gulST_SNC_Start(NX_VOID)
{
	NX_ULONG	ulRet			=	ST_SNC_OK;
	NX_ULONG	ulDtlErrorCode	=	0;

#ifdef MASTER
	ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_START, FALSE);
	if(ST_SNC_OK == ulRet) {

		ulRet = ulST_SNC_Instruction(ST_SNC_START_INSTRUCTION, NULL, &ulDtlErrorCode);
		if(ST_SNC_OK == ulRet) {

			ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_START, TRUE);
		}
		else {
			;
		}

	}
	else {
		if(ST_SNC_NG_IGNORE == ulRet){
			ulRet = ST_SNC_OK;
		}
	}
	return ulST_SNC_ConvErrCode(ulRet, ST_SNC_EVT_START);
#else
		ulRet = ulST_SNC_Instruction(ST_SNC_START_INSTRUCTION, NX_NULL, &ulDtlErrorCode);
	return ulRet;
#endif
}

NX_ULONG gulST_SNC_Stop(NX_VOID)
{
	NX_ULONG	ulRet			=	ST_SNC_OK;
	NX_ULONG	ulDtlErrorCode	=	0;

	ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_STOP, FALSE);
	if(ST_SNC_OK == ulRet) {

		ulRet = ulST_SNC_Instruction(ST_SNC_STOP_INSTRUCTION, NX_NULL, &ulDtlErrorCode);

		if(ST_SNC_OK == ulRet) {

			ulRet = gulST_SNC_StateMachine(ST_SNC_EVT_STOP, TRUE);
		}
		else {
			;
		}

	}
	else {
		if(ST_SNC_NG_IGNORE == ulRet){
			ulRet = ST_SNC_OK;
		}
	}

#ifdef MASTER
	return ulST_SNC_ConvErrCode(ulRet, ST_SNC_EVT_STOP);
#else
	return ulRet;
#endif
}

NX_ULONG gulST_SNC_Config(
	const NX_CHAR*		pucCommunity1,
	const NX_CHAR*		pucCommunity2,
	const NX_CHAR*		pucCommunity3,
	const NX_CHAR*		pucCommunity4,
	NX_USHORT 			usRcvPort
)
{
	const ST_SNC_ConfigSnmp	stConfig	= {{pucCommunity1, pucCommunity2, pucCommunity3, pucCommunity4}, usRcvPort};
	NX_ULONG	ulDtlErrorCode	=	0;

	return ulST_SNC_Instruction(ST_SNC_CONFIG_INSTRUCTION, &stConfig, &ulDtlErrorCode);
}


NX_ULONG gulST_SNC_MibSetNetConfMaster(
	const ST_SNC_N2MibMasterStation*	pstData,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_NWCFG_MASTER;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetNetConfConnect(
	const ST_SNC_N2MibConnectedStation*	pstData,
	NX_USHORT								usIndex,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_NWCFG_CONTED;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_NWCFG_CONSTN_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}


	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}


NX_ULONG gulST_SNC_MibClearNetworkConfig(NX_ULONG* pulDtlErrorCode)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_NWCFG_MASTER;

	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBDEL,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				NX_NULL,
				0,
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetDevDtlIdent(
	const ST_SNC_N2MibIdentifierInfo*	pstData,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DEVDTL_IDINFO;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetDevDtlStsinfo(
	const ST_SNC_N3MibStatusInfoBase*	pstData,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DEVDTL_STSINFO;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}


NX_ULONG gulST_SNC_MibSetDevDtlStsMaster(
	const ST_SNC_N3MibStatusMaster*	pstData,
	NX_USHORT							usIndex,
	NX_ULONG* 							pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DEVDTL_STSINFO_MASTAB;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_DEVDTL_MASTER_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetDevDtlStsLed(
	const ST_SNC_N3MibLed*	pstData,
	NX_USHORT					usIndex,
	NX_ULONG* 					pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DEVDTL_STSINFO_LEDTAB;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_DEVDTL_LED_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}


NX_ULONG gulST_SNC_MibSetDevDtlStsPort(
	const ST_SNC_N3MibPort*	pstData,
	NX_USHORT					usIndex,
	NX_ULONG* 					pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DEVDTL_STSINFO_PORTTAB;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_DEVDTL_PORT_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetOtModCntl(
	const ST_SNC_N2MibController*	pstData,
	NX_ULONG* 							pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_OTMDL_CNTL;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetOtModOpt(
	const ST_SNC_N2MibOptionInfo*	pstData,
	NX_USHORT							usIndex,
	NX_ULONG* 							pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_OTMDL_OPT;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_OTHER_OPT_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetStatisticalInfo(
	NX_USHORT			usOidmap,
	NX_USHORT			usNumber,
	NX_ULONG* 			pulDtlErrorCode
)
{
	switch (usOidmap) {
	case ST_SNC_MAP_STATS_CYCLIC_RECEIVE_COUNTER :
	case ST_SNC_MAP_STATS_CYCLIC_RECEIVEDISCARD_COUNTER :
	case ST_SNC_MAP_STATS_CYCLIC_FRAMERECEIVE_COUNTER :
	case ST_SNC_MAP_STATS_NONCYCLIC_RECEIVE_COUNTER :
	case ST_SNC_MAP_STATS_NONCYCLIC_RECEIVEDISCARD_COUNTER :
	case ST_SNC_MAP_STATS_NUMBER_OF_HECERROR_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_DCSERROR_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_FCSERROR_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_SDCRCERROR_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_SHORTPACKET_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_JUMBOPACKET_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_LONGPACKET_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_FAILEDCCLINKIEPDUSIZE :
	case ST_SNC_MAP_STATS_NUMBER_OF_FLAGMENTERROR_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_PRIORITYCONTROL_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_IP_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_IEEE802OR1588_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_LLDP_FRAME :
	case ST_SNC_MAP_STATS_NUMBER_OF_SYNC_FRAME :
		break;
	default:
		return ST_SNC_NG_PARAM_RANGE;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				&usNumber,
				sizeof(usNumber),
				pulDtlErrorCode);
}


NX_ULONG gulST_SNC_MibSetIpOverlapError(
	const ST_SNC_N2MibIpOverlapReg*	pstData,
	NX_USHORT							usIndex,
	NX_ULONG* 							pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_IPOVERLAP_REG;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_IPOVLAP_ERR_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetTopologyError(
	const ST_SNC_N2MibTopologyReg*	pstData,
	NX_USHORT							usIndex,
	NX_ULONG* 							pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_TOPOLOGY_REG;

	if(NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_TOPOLOGY_ERR_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}













NX_ULONG gulST_SNC_MibSetDataLinkError(
	const ST_SNC_N2MibDatalinkErrorReg*	pstData,
	NX_USHORT								usIndex,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_DATALINK_REG;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	} 
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if(ST_SNC_DATALINK_ERR_MAX <= usIndex) {
		return ST_SNC_NG_PARAM_RANGE;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				usIndex,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetCommunicationTimingError(
	NX_UCHAR									uchTimeslotNumber,
	NX_ULONG* 									pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_COMTIMING_REG_TIMESLOT_NUMBER;

	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				&uchTimeslotNumber,
				sizeof(uchTimeslotNumber),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetCurrentError(
	const ST_SNC_N2MibErrorReg*			pstData,
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_CURERR_REG;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBSET,
				ST_SNC_ARRAY_ADD,
				ST_SNC_IDX_0,
				pstData,
				sizeof(*pstData),
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibClearCurrentError(
	NX_ULONG* 								pulDtlErrorCode
)
{
	NX_USHORT	usOidmap	= ST_SNC_MAP_CURERR_REG;

	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBDEL,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				NX_NULL,
				0,
				pulDtlErrorCode);
}

NX_ULONG gulST_SNC_MibSetID (
	NX_USHORT 			usOidmap,
	NX_UCHAR			uchCntlType,
	NX_USHORT			usIndex,
	const NX_VOID*		pData,
	NX_ULONG			ulDataSize,
	NX_ULONG* 			pulDtlErrorCode
)
{
	NX_ULONG				ulRet		= ST_SNC_OK;

	ulRet = gulST_SNC_CheckOidmap(usOidmap, uchCntlType);
	if(ST_SNC_OK != ulRet){
		return ulRet;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}


	return ulST_SNC_MibSet(
			usOidmap,
			ST_SNC_PMSG_CLMIBSET,
			uchCntlType,
			usIndex,
			pData,
			ulDataSize,
			pulDtlErrorCode);

}
#ifdef MASTER
NX_ULONG ulST_SNC_ConvErrCode(
	NX_ULONG			ulErrCode,
	ST_SNC_Event 	eEvent
)
{
	ULONG	ulRet = CCIET_E_NOERROR;

	switch (eEvent)
	{
	case ST_SNC_EVT_INIT:

		switch (ulErrCode)
		{
		case ST_SNC_OK:
			ulRet = CCIET_E_NOERROR;
			break;
		case ST_SNC_NG_PARAM_ADDR:
			ulRet = CCIET_E_INIFAIL_SNC_PRM;
			break;
		case ST_SNC_NG_EVENT:
		case ST_SNC_NG_STATE:
			ulRet = CCIET_E_INVALIDSTATE;
			break;
		default:
			ulRet = ulErrCode;
			break;
		}
		break;

	case ST_SNC_EVT_START:

		switch (ulErrCode)
		{
		case ST_SNC_OK:
			ulRet = CCIET_E_NOERROR;
			break;
		case ST_SNC_NG_PARAM_RANGE:
			ulRet = CCIET_E_STFAIL_SNC_PRM;
			break;
		case ST_SNC_NG_MTX_CREATE:
		case ST_SNC_NG_MTX_EXIST:
			ulRet = CCIET_E_STFAIL_SNC_CRE_MTX;
			break;
		case ST_SNC_NG_SERVICE_NOT_STARTED:
			ulRet = CCIET_E_STFAIL_SNC_SERVICE_NOT_STARTED;
			break;
		case ST_SNC_NG_WRITE:
		case ST_SNC_NG_READ:
		case ST_SNC_NG_PIPE_MAX_INSTANCE:
		case ST_SNC_NG_PIPE_OPEN:
		case ST_SNC_NG_HEAD:
		case ST_SNC_NG_HEAD_DT:
		case ST_SNC_NG_HEAD_TY:
		case ST_SNC_NG_HEAD_ST:
			ulRet = CCIET_E_STFAIL_SNC_PROC;
			break;
		case ST_SNC_NG_EVENT:
		case ST_SNC_NG_STATE:
			ulRet = CCIET_E_INVALIDSTATE;
			break;
		default:
			ulRet = ulErrCode;
			break;
		}
		break;

	case ST_SNC_EVT_STOP:

		switch (ulErrCode)
		{
		case ST_SNC_OK:
			ulRet = CCIET_E_NOERROR;
			break;
		case ST_SNC_NG_PARAM_RANGE:
			ulRet = CCIET_E_STPFAIL_SNC_INTERNAL;
			break;
		case ST_SNC_NG_MTX_CREATE:
		case ST_SNC_NG_MTX_NOCRE:
			ulRet = CCIET_E_STPFAIL_SNC_CRE_MTX;
			break;
		case ST_SNC_NG_WRITE:
		case ST_SNC_NG_READ:
		case ST_SNC_NG_SERVICE_NOT_STARTED:
		case ST_SNC_NG_PIPE_MAX_INSTANCE:
		case ST_SNC_NG_PIPE_OPEN:
		case ST_SNC_NG_HEAD:
		case ST_SNC_NG_HEAD_DT:
		case ST_SNC_NG_HEAD_TY:
		case ST_SNC_NG_HEAD_ST:
			ulRet = CCIET_E_STPFAIL_SNC_PROC;
			break;
		case ST_SNC_NG_EVENT:
		case ST_SNC_NG_STATE:
			ulRet = CCIET_E_INVALIDSTATE;
			break;
		default:
			ulRet = ulErrCode;
			break;
		}
		break;

	case ST_SNC_EVT_TERM:

		switch (ulErrCode)
		{
		case ST_SNC_OK:
			ulRet = CCIET_E_NOERROR;
			break;
		case ST_SNC_NG_EVENT:
		case ST_SNC_NG_STATE:
			ulRet = CCIET_E_INVALIDSTATE;
			break;
		default:
			ulRet = ulErrCode;
			break;
		}
		break;

	default:
		ulRet = ulErrCode;
		break;
	}

	return ulRet;
}
#endif

#ifdef SWPS
NX_ULONG gulST_SNC_MibSetLLDP(
	NX_UCHAR						uchCtrlType,
	const ST_SNC_MibLldpSend*	pstData,
	NX_ULONG* 						pulDtlErrorCode
)
{
	const NX_VOID* 	pvData   = NX_NULL;
	NX_ULONG 			ulSize   = 0;
	NX_USHORT			usOidmap = ST_SNC_MAP_LLDP_MIB;
	NX_USHORT			usSetIdx = ST_SNC_IDX_0;

	if (NX_NULL == pstData) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	switch(pstData->uchType) {

	case ST_SNC_LLDPMIB_MIB :

		switch(uchCtrlType) {

		case ST_SNC_ARRAY_NON :
			pvData = pstData->pvAddr;
			ulSize = pstData->ulDataSize;
			break;
		default :
			return ST_SNC_NG_PARAM_RANGE;
		}
		break;

	case ST_SNC_LLDPMIB_AGENT :

		switch(uchCtrlType) {
		case ST_SNC_ARRAY_ADD :
		case ST_SNC_ARRAY_MOD :
			pvData   = pstData->pvAddr;
			ulSize   = pstData->ulDataSize;

			usSetIdx = pstData->uchIndex;
			usOidmap = ST_SNC_MAP_LLDP_AGENT;
			break;
		default:
			return ST_SNC_NG_PARAM_RANGE;
		}
		break;

	case ST_SNC_LLDPMIB_LOCAL :

		switch(uchCtrlType) {

		case ST_SNC_ARRAY_ADD :
			pvData = pstData->pvAddr;
			ulSize = pstData->ulDataSize;
			usOidmap = ST_SNC_MAP_LLDP_LOCAL;
			break;
		default:
			return ST_SNC_NG_PARAM_RANGE;
		}
		break;
	case ST_SNC_LLDPMIB_REMOTE :

		switch(uchCtrlType) {
		case ST_SNC_ARRAY_ADD :
		case ST_SNC_ARRAY_MOD :
			pvData   = pstData->pvAddr;
			ulSize   = pstData->ulDataSize;

			usSetIdx = pstData->uchIndex;
			usOidmap = ST_SNC_MAP_LLDP_REMOTE;
			break;
		default:
			return ST_SNC_NG_PARAM_RANGE;
		}
	default:
		return ST_SNC_NG_PARAM_RANGE;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLLLDPMIBSET,
				uchCtrlType,
				usSetIdx,
				pvData,
				ulSize,
				pulDtlErrorCode);
}
#endif


NX_ULONG gulST_SNC_MibCommit(NX_ULONG* pulDtlErrorCode)
{
	NX_USHORT			usOidmap = ST_SNC_MAP_COMMIT;

	if (NX_NULL == pulDtlErrorCode) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

	return ulST_SNC_MibSet(
				usOidmap,
				ST_SNC_PMSG_CLMIBCOMMIT,
				ST_SNC_ARRAY_NON,
				ST_SNC_IDX_0,
				NX_NULL,
				0,
				pulDtlErrorCode);
}
