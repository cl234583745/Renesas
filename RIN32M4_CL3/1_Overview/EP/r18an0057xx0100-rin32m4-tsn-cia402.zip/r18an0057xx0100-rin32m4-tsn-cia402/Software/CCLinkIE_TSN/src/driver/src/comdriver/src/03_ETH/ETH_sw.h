/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef	__ETHER_SW_H_INCLUDED__
#define	__ETHER_SW_H_INCLUDED__



NX_EXTERN NX_CONST NX_UCHAR gauchLLDPMultiMac[MAC_ADDR_SIZE];

NX_VOID vETH_EtherSwInit (NX_VOID);

#endif

