/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __INTR_MAIN_H_INCLUDE__
#define __INTR_MAIN_H_INCLUDE__

#include "nx_common.h"

#define	TABLE_END						(0xFFFFFFFF)
#define	INTR_COUNT_MAX					(0xFFFFFFFF)




#endif
/*[EOF]*/
