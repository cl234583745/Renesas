/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#define STATION_NUM_INIT 0xFF
#define NETWORK_NUM_INIT 0xFF
#define OPTION_NONE 0x0
#define STATION_TYPE_SLAVE 0x01
#define DEVICE_TYPE_NOUSE 0x0000
#define MITSUBISHIFSYS {0x0,0x0}
#include "nx_common.h"
#include "ccienx_api.h"
#include "SNMP_mib_api.h"
#include "USN_api.h"
#include "NMG_common.h"
#include "NMG_self_spec.h"
#include "nx_frame_detection.h"
#include "ST_SNC.h"
#include "ST_SNC_prvif_stk_l.h"
#include "ST_SNC_sync_com_l.h"
#include "CYC_api.h"
#include "ccienx_app_supply.h"
#include "NGN_ASIC.h"
#include "LOG_api.h"
#include "NMG_api.h"

#define	NX_LED_SIZE		(8)
#define		SNMP_PER_100						((NX_ULONG)100)
#define		SNMP_PER_20							((NX_ULONG)20)
#define		SNMP_PER_10							((NX_ULONG)10)
#define		SNMP_TWICE							((NX_ULONG)10)

#define		STATIST_TIME_CNT					((NX_USHORT)200)

#define		ERR_FRAME_RCV_IDX_0					((NX_USHORT)0)
#define		ERR_FRAME_RCV_IDX_1					((NX_USHORT)1)
#define		ERR_FRAME_RCV_IDX_2					((NX_USHORT)2)
#define		ERR_FRAME_RCV_IDX_3					((NX_USHORT)3)
#define		ERR_FRAME_RCV_IDX_4					((NX_USHORT)4)
#define		ERR_FRAME_RCV_IDX_5					((NX_USHORT)5)

#define		MIB_STATICS_WAITTIME				((NX_ULONG)200)

typedef struct tagMIB_CTRL {
	NX_USHORT	usErrInfoNum;
	NX_USHORT	usRsv;
	NX_ULONG	ulIpv4Addr;
	NX_UCHAR	uchPort1_2LinkSts;
	NX_UCHAR	uchDiagnosisInfo;
	NX_UCHAR	ausMasterMacAddr[NX_MAC_ADDR_SIZE];
	NX_UCHAR	uchCyclicStopInfo;
	NX_UCHAR	uchAppFuncInfo;
	NX_UCHAR	auchRsv[2];
	NX_ULONG	ulMasterEntryFlg;
	NX_USHORT	usLinkDownCnt[NX_PORT_SIZE];
	NX_ULONG	ulPreLinkSts[NX_PORT_SIZE];
	NX_UCHAR	auchErrFrameRcvSts[NX_PORT_SIZE];
	NX_UCHAR	auchPreErrFrameRcvSts[NX_PORT_SIZE];
	NX_ULONG	ulNowTime;
} MIB_CTRL;

typedef struct tagDEV_DTL_IP_ADDR {
	NX_UCHAR	auchIpAddress[ST_SNC_IPALL_LEN];
} DEV_DTL_IP_ADDR;

MIB_CTRL	gstMibCtrl;

NX_LED_STATUS		gastLedStatus[NX_LED_SIZE];

STATISTICS_CNT_INFO			gstStatistictInfo;
ST_SNC_N1MibStatisticalInfo	gstPreStatistictInfo;
NX_ULONG						gulReqStatisticClear;
#ifdef ACCUMULATE_STATISTICS_INFORMATION
NX_STATIC STATISTICS_CNT_INFO	gstStatistictInfoInteg;
#endif
NX_CONST NX_STATIC NX_USHORT	gusStatistictOidList[] = {
							ST_SNC_MAP_STATS_CYCLIC_RECEIVE_COUNTER,
							ST_SNC_MAP_STATS_CYCLIC_RECEIVEDISCARD_COUNTER,
							ST_SNC_MAP_STATS_CYCLIC_FRAMERECEIVE_COUNTER,
							ST_SNC_MAP_STATS_NONCYCLIC_RECEIVE_COUNTER,
							ST_SNC_MAP_STATS_NONCYCLIC_RECEIVEDISCARD_COUNTER,
							ST_SNC_MAP_STATS_NUMBER_OF_HECERROR_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_DCSERROR_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_FCSERROR_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_SDCRCERROR_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_SHORTPACKET_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_JUMBOPACKET_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_LONGPACKET_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_FAILEDCCLINKIEPDUSIZE,
							ST_SNC_MAP_STATS_NUMBER_OF_FLAGMENTERROR_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_PRIORITYCONTROL_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_IP_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_IEEE802OR1588_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_LLDP_FRAME,
							ST_SNC_MAP_STATS_NUMBER_OF_SYNC_FRAME
						};


NX_VOID vSNMP_SetDevDtlIdentInit(NX_VOID);
NX_VOID vSNMP_SetDevDtlStsInfoInit(NX_VOID);
NX_VOID vSNMP_SetDevDtlMasterInfoInit(NX_VOID);
NX_VOID vSNMP_SetDevDtlLedInfoInit(NX_VOID);
NX_VOID vSNMP_SetStatisticsInit(NX_VOID);
NX_VOID vSNMP_UpdateDevDtlIpAddr(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlLinSts(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlDiagInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlLedInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_SetDevDtlPortInfoInit(NX_VOID);
NX_VOID vSNMP_UpdateDevDtlCycStopInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlMasterInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlPortInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateDevDtlErrFrameRcv(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_UpdateAppFuncInfo(NX_ULONG* pulUpdateFlg);
NX_VOID vSNMP_GetStatisticsCnt(NX_VOID);
NX_USHORT usSNMP_ChkStatistictCnt(NX_ULONG ulStatisticsCnt);
NX_VOID vSNMP_ChkErrFrameRcvSts(NX_VOID);
NX_VOID vSNMP_SetErrFrameInfo (NX_USHORT, NX_USHORT, NX_USHORT, NX_USHORT, NX_USHORT, NX_USHORT);

NX_UCHAR vSNMP_GetCyclicStopInfo(VOID);

NX_VOID vSNMP_mib_Init(NX_VOID)
{
	NX_ULONG					ulErrDetailCode;
	NX_USHORT					usLoop;

	vNX_FillMemory32(&gstMibCtrl, NX_L_ZERO, (sizeof(MIB_CTRL) / sizeof(NX_ULONG)));
	

	vNX_FillMemory32(&gstStatistictInfo, NX_L_ZERO, (sizeof(STATISTICS_CNT_INFO) / sizeof(NX_ULONG)));
	vNX_FillMemory16(&gstPreStatistictInfo, NX_S_ZERO, (sizeof(ST_SNC_N1MibStatisticalInfo) / sizeof(NX_USHORT)));
	
	(NX_VOID)gulST_SNC_Initialize();
	(NX_VOID)gulST_SNC_Start();
	
	vSNMP_SetDevDtlIdentInit();
	
	vSNMP_SetDevDtlStsInfoInit();
	
	vSNMP_SetDevDtlMasterInfoInit();
	
	vSNMP_SetDevDtlLedInfoInit();
	
	vSNMP_SetDevDtlPortInfoInit();

	vSNMP_SetStatisticsInit();
	

	
	(NX_VOID)gulST_SNC_MibCommit(&ulErrDetailCode);

	gstMibCtrl.ulNowTime =  ulNX_GetLifeTime();

	return;
}

NX_VOID vSNMP_SetDevDtlIdentInit(NX_VOID)
{
	
	ST_SNC_N2MibIdentifierInfo	stDevDtlifierInfo;
	NX_ULONG					ulErrDetailCode;
	
	vNX_FillMemory(&stDevDtlifierInfo, NX_C_ZERO, sizeof(ST_SNC_N2MibIdentifierInfo));
	
	vNX_CopyMemory(&stDevDtlifierInfo.auchMacAddress[0], &gstAppInfo.stEthInfo.auchMacAddress[0], NX_MAC_ADDR_SIZE);
	
	stDevDtlifierInfo.usStationNumber = NX_STATION_NO;
	stDevDtlifierInfo.uchNetworkNumber = NX_NETWORK_NO;
	
	stDevDtlifierInfo.auchIpAddress[0] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT24) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[1] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT16) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[2] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT8) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[3] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[4] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT24) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[5] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT16) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[6] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT8) & NX_BIT00_07);
	stDevDtlifierInfo.auchIpAddress[7] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask) & NX_BIT00_07);

	gstMibCtrl.ulIpv4Addr = gstNET.stSelf.ulIPAddress;
	
	stDevDtlifierInfo.uchCertificationClass = CERTIFICATION_CLASS_B;
	
	stDevDtlifierInfo.uchStationType = gstAppInfo.stCieDevInfo.uchStationType;
	
	stDevDtlifierInfo.usDeviceVersion = gstAppInfo.stCieDevInfo.usDeviceVersion;
	stDevDtlifierInfo.usFwVersion = gstAppInfo.stCieDevInfo.usFwVersion;
	stDevDtlifierInfo.uchHwVersion = (NX_UCHAR)gstAppInfo.stCieDevInfo.usHwVersion;
	stDevDtlifierInfo.usDeviceType = gstAppInfo.stCieDevInfo.usDeviceType;
	stDevDtlifierInfo.ulDeviceModelCode = gstAppInfo.stCieDevInfo.ulModelCode;
	stDevDtlifierInfo.usExpansionModelCode = gstAppInfo.stCieDevInfo.usExModelCode;
	stDevDtlifierInfo.usVendorCode = gstAppInfo.stCieDevInfo.usVendorCode;
	
	vNX_CopyMemory(&stDevDtlifierInfo.auchDeviceModelName, &gstAppInfo.stCieDevInfo.auchDeviceModelName[0],
					NX_MODEL_NAME_SIZE);
	
	vNX_CopyMemory(&stDevDtlifierInfo.auchVendorName[0],&gstAppInfo.stCieDevInfo.auchVendorName[0],
					NX_VENDER_NAME_SIZE);
	
	vNX_CopyMemory(&stDevDtlifierInfo.auchSerialNumber, &gstAppInfo.stCieDevInfo.auchSerialNumber[0],
					NX_SERIAL_SIZE);

	stDevDtlifierInfo.uchOption = gstAppInfo.stCieDevInfo.uchOption;
	
	stDevDtlifierInfo.usStationSpecificMode = gstAppInfo.stCieDevInfo.usStationMode;
	
	stDevDtlifierInfo.auchUnitIdentifier[0] |= (NX_UCHAR)(gstAppInfo.stCieDevInfo.usUnitIdentifier & MIB_MASK_2BIT);
	stDevDtlifierInfo.auchUnitIdentifier[1] |= ((MIB_NETWORK_TYPE_CCIET_CCIET & MIB_MASK_3BIT) << NX_SHIFT5);
	
	(NX_VOID)gulST_SNC_MibSetDevDtlIdent(&stDevDtlifierInfo, &ulErrDetailCode);
	
	return;
}

NX_VOID vSNMP_SetDevDtlStsInfoInit(NX_VOID)
{
	ST_SNC_N3MibStatusInfoBase	stDevDtlStsInfo;
	NX_ULONG					ulErrDetailCode;

	vNX_FillMemory(&stDevDtlStsInfo, NX_C_ZERO, sizeof(ST_SNC_N3MibStatusInfoBase));
	
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_0] = uchNMG_CreatePortLinkStsData_Mib((USHORT)NX_OFF);
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_1] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_2] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_3] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_4] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_5] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_6] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_7] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_8] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_9] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_10] = NX_ZERO;
	stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_11] = NX_ZERO;
	
	gstMibCtrl.uchPort1_2LinkSts = stDevDtlStsInfo.auchPortCondition[NX_MY_PORT_LINK_STATUS_IDX_0];

	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_0] = (NX_UCHAR)((RX_FRAME_STS_NO_USE << NX_SHIFT2) | RX_FRAME_STS_NO_USE);
	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_1] = (NX_UCHAR)NX_ZERO;
	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_2] = (NX_UCHAR)NX_ZERO;
	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_3] = (NX_UCHAR)NX_ZERO;
	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_4] = (NX_UCHAR)NX_ZERO;
	stDevDtlStsInfo.auchErrorFrameReceptionStatus[ERR_FRAME_RCV_IDX_5] = (NX_UCHAR)NX_ZERO;
	
	gstMibCtrl.auchErrFrameRcvSts[NX_PORT1] = RX_FRAME_STS_NO_USE;
	gstMibCtrl.auchErrFrameRcvSts[NX_PORT2] = RX_FRAME_STS_NO_USE;
	gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT1] = RX_FRAME_STS_NO_USE;
	gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT2] = RX_FRAME_STS_NO_USE;

	stDevDtlStsInfo.uchDiagnosisInfo = uchCYC_GetDiagnosisData();
	gstMibCtrl.uchDiagnosisInfo = stDevDtlStsInfo.uchDiagnosisInfo;

	stDevDtlStsInfo.uchCyclicStopInfo = uchCYC_GetCyclicStopInfo();
	gstMibCtrl.uchCyclicStopInfo = stDevDtlStsInfo.uchCyclicStopInfo;

	stDevDtlStsInfo.uchAppInfo = NX_APPINFO_UNSYNC;

	vNX_CopyMemory(&stDevDtlStsInfo.auchCorrespondingFunction, gstAppInfo.stCieDevInfo.auchCorresPondFunc, ST_SNC_CORRESPONDFUN_LEN);
	
	(NX_VOID)gulST_SNC_MibSetDevDtlStsinfo(&stDevDtlStsInfo, &ulErrDetailCode);
	
	return;
}

NX_VOID vSNMP_SetDevDtlMasterInfoInit(NX_VOID)
{
	gstMibCtrl.ulMasterEntryFlg = NX_OFF;

	return;
}

NX_VOID vSNMP_SetDevDtlLedInfoInit(NX_VOID)
{
	NX_ULONG					ulErrDetailCode;
	NX_USHORT					usLoop;
	
	for (usLoop = NX_ZERO; usLoop < NX_LED_SIZE; usLoop++) {
		vNX_GetLedStatus((NX_ULONG)usLoop, &gastLedStatus[usLoop]);
		(NX_VOID)gulST_SNC_MibSetDevDtlStsLed((ST_SNC_N3MibLed*)&gastLedStatus[usLoop], usLoop, &ulErrDetailCode);
	}
	return;
}

NX_VOID vSNMP_SetDevDtlPortInfoInit(NX_VOID)
{
	NX_USHORT			usLoop = (NX_USHORT)NX_ZERO;
	ST_SNC_N3MibPort	stMibPort;
	NX_ULONG			ulErrDetailCode;
	
	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < NX_PORT_SIZE; usLoop++) {
		stMibPort.usPortLinkDownCnt = (NX_USHORT)NX_ZERO;
		
		(NX_VOID)gulST_SNC_MibSetDevDtlStsPort(&stMibPort, usLoop, &ulErrDetailCode);
	}
	
	return;
}

NX_VOID vSNMP_SetStatisticsInit(NX_VOID)
{
#ifdef ACCUMULATE_STATISTICS_INFORMATION
	vNX_FillMemory(&gstStatistictInfoInteg, NX_ZERO, sizeof(gstStatistictInfoInteg));
#endif
	gulReqStatisticClear = ST_SNC_STATISTICS_CLEAR_IDLE;
	
	return;
}

NX_VOID vSNMP_UpdateDevDtl(NX_VOID)
{
	NX_ULONG			ulUpdateFlg = NX_OFF;
	NX_ULONG			ulErrDetailCode;
	
	vSNMP_UpdateDevDtlIpAddr(&ulUpdateFlg);
	vSNMP_UpdateDevDtlLinSts(&ulUpdateFlg);
	vSNMP_UpdateDevDtlDiagInfo(&ulUpdateFlg);
	vSNMP_UpdateDevDtlLedInfo(&ulUpdateFlg);
	vSNMP_UpdateDevDtlErrFrameRcv(&ulUpdateFlg);
	vSNMP_UpdateDevDtlCycStopInfo(&ulUpdateFlg);
	vSNMP_UpdateDevDtlMasterInfo(&ulUpdateFlg);
	vSNMP_UpdateDevDtlPortInfo(&ulUpdateFlg);
	vSNMP_UpdateAppFuncInfo(&ulUpdateFlg);
	
	if (NX_ON == ulUpdateFlg) {
		(NX_VOID)gulST_SNC_MibCommit(&ulErrDetailCode);
	}
	
	return;
}
NX_VOID vSNMP_UpdateDevDtlIpAddr(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulErrDetailCode;
	DEV_DTL_IP_ADDR				stDevDtlIpAddr;
	
	if (gstMibCtrl.ulIpv4Addr != gstNET.stSelf.ulIPAddress) {
		vNX_FillMemory(&stDevDtlIpAddr, NX_C_ZERO, sizeof(DEV_DTL_IP_ADDR));
	
		stDevDtlIpAddr.auchIpAddress[0] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT24) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[1] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT16) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[2] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress >> NX_SHIFT8) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[3] = (NX_UCHAR)((gstNET.stSelf.ulIPAddress) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[4] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT24) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[5] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT16) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[6] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask >> NX_SHIFT8) & NX_BIT00_07);
		stDevDtlIpAddr.auchIpAddress[7] = (NX_UCHAR)((gstNET.stSelf.ulSubnetMask) & NX_BIT00_07);
		
		(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_IDINFO_IPADDRESS, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &stDevDtlIpAddr, sizeof(DEV_DTL_IP_ADDR), &ulErrDetailCode);

		*pulUpdateFlg = NX_ON;
		gstMibCtrl.ulIpv4Addr = gstNET.stSelf.ulIPAddress;
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlLinSts(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulErrDetailCode;
	NX_UCHAR					uchPort1_2LinkSts;
	NX_UCHAR					auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_SIZE];
	

	uchPort1_2LinkSts = uchNMG_CreatePortLinkStsData_Mib((USHORT)NX_OFF);
	
	if (gstMibCtrl.uchPort1_2LinkSts != uchPort1_2LinkSts) {
		
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_0] = uchPort1_2LinkSts;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_1] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_2] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_3] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_4] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_5] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_6] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_7] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_8] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_9] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_10] = NX_ZERO;
		auchAllPortCondition[NX_MY_PORT_LINK_STATUS_IDX_11] = NX_ZERO;
		
		(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_PORT_CONDITION, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &auchAllPortCondition[0], NX_MY_PORT_LINK_STATUS_IDX_SIZE, &ulErrDetailCode);

		*pulUpdateFlg = NX_ON;
		gstMibCtrl.uchPort1_2LinkSts = uchPort1_2LinkSts;
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlDiagInfo(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulErrDetailCode;
	NX_UCHAR					uchDiagnosisInfo;
	
	uchDiagnosisInfo = uchCYC_GetDiagnosisData();
	
	if (gstMibCtrl.uchDiagnosisInfo != uchDiagnosisInfo) {
		
		(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_DIAGNOSIS_INFO, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &uchDiagnosisInfo, sizeof(NX_UCHAR), &ulErrDetailCode);

		*pulUpdateFlg = NX_ON;
		gstMibCtrl.uchDiagnosisInfo = uchDiagnosisInfo;
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlCycStopInfo(NX_ULONG* pulUpdateFlg)
{
	NX_UCHAR	uchCyclicStopInfo;
	NX_ULONG	ulErrDetailCode;
	
	uchCyclicStopInfo = uchCYC_GetCyclicStopInfo();
	
	if (gstMibCtrl.uchCyclicStopInfo != uchCyclicStopInfo) {
		(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_CYCLIC_STOP_INFO, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &uchCyclicStopInfo, sizeof(NX_UCHAR), &ulErrDetailCode);

		*pulUpdateFlg = NX_ON;
		
		gstMibCtrl.uchCyclicStopInfo = uchCyclicStopInfo;
	}
	
	return;
}


NX_VOID vSNMP_UpdateDevDtlMasterInfo(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulRslt = NX_NG;
	NX_ULONG					lRslt = NX_NG;
	NX_ULONG					ulErrDetailCode;
	ST_SNC_N3MibStatusMaster	stDevDtlMasterInfo;
	NX_UCHAR					auchCtrlMasterMacAddr[NX_MAC_ADDR_SIZE];
	NX_USHORT					usLoop;

	
	ulRslt = ulNMG_CtrlMstMacAddr(auchCtrlMasterMacAddr);
	
	if (NX_OK == ulRslt) {
		for (usLoop = NX_ZERO; usLoop < NX_MAC_ADDR_SIZE; usLoop++) {
			stDevDtlMasterInfo.auchMacAddress[usLoop] = auchCtrlMasterMacAddr[NX_MAC_ADDR_SIZE - usLoop - 1];
		}
		if (NX_OFF == gstMibCtrl.ulMasterEntryFlg) {
			(NX_VOID)gulST_SNC_MibSetDevDtlStsMaster(&stDevDtlMasterInfo, NX_ZERO, &ulErrDetailCode);
			
			gstMibCtrl.ulMasterEntryFlg = NX_ON;
			
			vNX_CopyMemory(gstMibCtrl.ausMasterMacAddr, stDevDtlMasterInfo.auchMacAddress, NX_MAC_ADDR_SIZE);
			*pulUpdateFlg = NX_ON;
		}
		else {
			lRslt = lNX_CompareMemory(gstMibCtrl.ausMasterMacAddr, stDevDtlMasterInfo.auchMacAddress, NX_MAC_ADDR_SIZE);
			
			if (NX_NG == lRslt) {
				(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_MASTAB, ST_SNC_ARRAY_MOD,
						 NX_ZERO, &stDevDtlMasterInfo, sizeof(ST_SNC_N3MibStatusMaster), &ulErrDetailCode);

				vNX_CopyMemory(gstMibCtrl.ausMasterMacAddr, stDevDtlMasterInfo.auchMacAddress, NX_MAC_ADDR_SIZE);
				*pulUpdateFlg = NX_ON;
			}
		}
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlLedInfo(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulErrDetailCode;
	NX_USHORT					usLoop;
	NX_LED_STATUS				stLedStatus;
	
	for (usLoop = NX_ZERO; usLoop < NX_LED_SIZE; usLoop++) {
		vNX_GetLedStatus((NX_ULONG)usLoop, &stLedStatus);
		if ((stLedStatus.uchStatus != gastLedStatus[usLoop].uchStatus)
		 || (stLedStatus.uchColor != gastLedStatus[usLoop].uchColor)) {
			gastLedStatus[usLoop] = stLedStatus;
			(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_LEDTAB, ST_SNC_ARRAY_MOD,
					 usLoop, (ST_SNC_N3MibLed*)&gastLedStatus[usLoop], sizeof(ST_SNC_N3MibLed), &ulErrDetailCode);

			*pulUpdateFlg = NX_ON;
		}
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlPortInfo(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG			ulErrDetailCode;
	NX_USHORT			usLoop = (NX_USHORT)NX_ZERO;
	NX_ULONG			ulLinkSts;
	ST_SNC_N3MibPort	stMibPort;
	
	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < NX_PORT_SIZE; usLoop++) {
		
		ulLinkSts = (gstNET.stPhyReg[usLoop].ulModeSts & PHYREG_MODESTS_BIT_LINKUPSTS);
		
		if ((PHYREG_MODESTS_LINKUP == gstMibCtrl.ulPreLinkSts[usLoop])
			 && (PHYREG_MODESTS_LINKDOWN == ulLinkSts)) {
				
			if (gstMibCtrl.usLinkDownCnt[usLoop] < LINK_DOWN_CNT_MAX) {
				gstMibCtrl.usLinkDownCnt[usLoop]++;
				
				stMibPort.usPortLinkDownCnt = gstMibCtrl.usLinkDownCnt[usLoop];
				
				(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_PORTTAB_PORTLINKDOWNCNT, ST_SNC_ARRAY_MOD,
											 usLoop, &stMibPort, sizeof(ST_SNC_N3MibPort), &ulErrDetailCode);
				*pulUpdateFlg = NX_ON;
			}
		}
		gstMibCtrl.ulPreLinkSts[usLoop] = ulLinkSts;
	}
	
	return;
}

NX_VOID vSNMP_UpdateDevDtlErrFrameRcv(NX_ULONG* pulUpdateFlg)
{
	NX_ULONG					ulErrDetailCode;
	NX_UCHAR					auchErrFrameRcvSts[ST_SNC_ERRFRMREPSTS_LEN];
	
	if ((gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT1] != gstMibCtrl.auchErrFrameRcvSts[NX_PORT1])
		|| (gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT2] != gstMibCtrl.auchErrFrameRcvSts[NX_PORT2])) {
		
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_0] = (NX_UCHAR)((gstMibCtrl.auchErrFrameRcvSts[NX_PORT2] << (NX_UCHAR)NX_SHIFT2)
													 | gstMibCtrl.auchErrFrameRcvSts[NX_PORT1]);
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_1] = (NX_UCHAR)NX_ZERO;
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_2] = (NX_UCHAR)NX_ZERO;
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_3] = (NX_UCHAR)NX_ZERO;
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_4] = (NX_UCHAR)NX_ZERO;
		auchErrFrameRcvSts[ERR_FRAME_RCV_IDX_5] = (NX_UCHAR)NX_ZERO;

		(NX_VOID)gulST_SNC_MibSetID(ST_SNC_MAP_DEVDTL_STSINFO_ERRORFRAME_RECEPTION_STATUS, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &auchErrFrameRcvSts[0], ST_SNC_ERRFRMREPSTS_LEN, &ulErrDetailCode);

		*pulUpdateFlg = NX_ON;
		
		gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT1] = gstMibCtrl.auchErrFrameRcvSts[NX_PORT1];
		gstMibCtrl.auchPreErrFrameRcvSts[NX_PORT2] = gstMibCtrl.auchErrFrameRcvSts[NX_PORT2];
	}
	
	return;
}

NX_VOID vSNMP_UpdateStatisticsInfo(NX_VOID)
{
	ST_SNC_N1MibStatisticalInfo stMibStatisticalInfo;
	NX_ULONG			ulTmpData;
	NX_ULONG			ulErrDetailCode;
	NX_ULONG			ulTimeOutResult;
	
	volatile NX_ULONG	ulRegData;
	NX_USHORT	usZERO		= NX_ZERO;
	NX_ULONG	ulCnt;
#ifdef ACCUMULATE_STATISTICS_INFORMATION
	NX_ULONG	*pulCnt;
	NX_ULONG	*pulCntInteg;
#endif
	
	if (ST_SNC_STATISTICS_CLEAR_REQUESTED == gulReqStatisticClear) {
		gulReqStatisticClear = ST_SNC_STATISTICS_CLEAR_EXECTUING;
		NGN_CN_REG->R_RESTCCLR.BITS.b01ZCounterClear = NX_ON;
	
		ulRegData = NGN_RN->ulR_RNCYCCT;
		ulRegData = NGN_RN->ulR_RNCYCER;
		ulRegData = NGN_RN->ulR_RNCFLMCT;
		ulRegData = NGN_RN_NCyc->astNCycPortDatas[NX_PORT1].ulR_RNNCCT;
		ulRegData = NGN_RN_NCyc->astNCycPortDatas[NX_PORT2].ulR_RNNCCT;
		ulRegData = NGN_RN_NCyc->astNCycPortDatas[NX_PORT1].ulR_RNNCER;
		ulRegData = NGN_RN_NCyc->astNCycPortDatas[NX_PORT2].ulR_RNNCER;
		
#ifdef ACCUMULATE_STATISTICS_INFORMATION
		vNX_FillMemory( &gstStatistictInfoInteg, NX_ZERO, sizeof(gstStatistictInfoInteg));
#endif
		
		for (ulCnt = 0; ulCnt < sizeof(gusStatistictOidList)/sizeof(gusStatistictOidList[0]); ulCnt++) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(gusStatistictOidList[ulCnt], (USHORT)NX_ZERO, &ulErrDetailCode);
		}
		gulReqStatisticClear = ST_SNC_STATISTICS_CLEAR_IDLE;
	}

	vNX_FillMemory16(&stMibStatisticalInfo, NX_S_ZERO, (sizeof(ST_SNC_N1MibStatisticalInfo) / sizeof(NX_USHORT)));

	ulTimeOutResult = ulNX_WaitLifeTime(gstMibCtrl.ulNowTime, MIB_STATICS_WAITTIME);
	
	if (NX_UL_OK != ulTimeOutResult) {
		gstMibCtrl.ulNowTime =  ulNX_GetLifeTime();
		vSNMP_GetStatisticsCnt();

#ifdef ACCUMULATE_STATISTICS_INFORMATION
		pulCnt      = (NX_ULONG*)&gstStatistictInfo;
		pulCntInteg = (NX_ULONG*)&gstStatistictInfoInteg;
		for (ulCnt = 0; ulCnt < sizeof(gstStatistictInfo) / sizeof(NX_ULONG); ulCnt++) {
			ulTmpData = *pulCntInteg + *pulCnt++;
			*pulCntInteg++ = (NX_ULONG)usSNMP_ChkStatistictCnt(ulTmpData);
		}
#endif

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		stMibStatisticalInfo.usCyclicReceiveCounter = (NX_USHORT)gstStatistictInfo.ulCycRecvCnt;
#else
		stMibStatisticalInfo.usCyclicReceiveCounter = (NX_USHORT)gstStatistictInfoInteg.ulCycRecvCnt;
#endif
		if (gstPreStatistictInfo.usCyclicReceiveCounter != stMibStatisticalInfo.usCyclicReceiveCounter) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_CYCLIC_RECEIVE_COUNTER,
													 stMibStatisticalInfo.usCyclicReceiveCounter, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		stMibStatisticalInfo.usCyclicReceiveDiscardCounter = (NX_USHORT)gstStatistictInfo.ulCycRecvDicardCnt;
#else
		stMibStatisticalInfo.usCyclicReceiveDiscardCounter = (NX_USHORT)gstStatistictInfoInteg.ulCycRecvDicardCnt;
#endif
		if (gstPreStatistictInfo.usCyclicReceiveDiscardCounter != stMibStatisticalInfo.usCyclicReceiveDiscardCounter) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_CYCLIC_RECEIVEDISCARD_COUNTER,
													 stMibStatisticalInfo.usCyclicReceiveDiscardCounter, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		stMibStatisticalInfo.usCyclicFrameReceiveCounter = (NX_USHORT)gstStatistictInfo.ulCycFrameRecvCnt;
#else
		stMibStatisticalInfo.usCyclicFrameReceiveCounter = (NX_USHORT)gstStatistictInfoInteg.ulCycFrameRecvCnt;
#endif
		if (gstPreStatistictInfo.usCyclicFrameReceiveCounter != stMibStatisticalInfo.usCyclicFrameReceiveCounter) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_CYCLIC_FRAMERECEIVE_COUNTER,
													 stMibStatisticalInfo.usCyclicFrameReceiveCounter, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulNonCycRecvCnt[NX_PORT1] + gstStatistictInfo.ulNonCycRecvCnt[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulNonCycRecvCnt[NX_PORT1] + gstStatistictInfoInteg.ulNonCycRecvCnt[NX_PORT2];
#endif
		stMibStatisticalInfo.usNonCyclicReceiveCounter = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNonCyclicReceiveCounter != stMibStatisticalInfo.usNonCyclicReceiveCounter) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NONCYCLIC_RECEIVE_COUNTER,
													 stMibStatisticalInfo.usNonCyclicReceiveCounter, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT1] + gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulNonCycRecvDicardCnt[NX_PORT1] + gstStatistictInfoInteg.ulNonCycRecvDicardCnt[NX_PORT2];
#endif
		stMibStatisticalInfo.usNonCyclicReceiveDiscardCounter = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNonCyclicReceiveDiscardCounter != stMibStatisticalInfo.usNonCyclicReceiveDiscardCounter) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NONCYCLIC_RECEIVEDISCARD_COUNTER,
													 stMibStatisticalInfo.usNonCyclicReceiveDiscardCounter, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulHecErrFrameNum[NX_PORT1] + gstStatistictInfo.ulHecErrFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulHecErrFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulHecErrFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfHecErrorFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfHecErrorFrame != stMibStatisticalInfo.usNumberOfHecErrorFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_HECERROR_FRAME,
													 stMibStatisticalInfo.usNumberOfHecErrorFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulDcsErrFrameNum[NX_PORT1] + gstStatistictInfo.ulDcsErrFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulDcsErrFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulDcsErrFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfDcsErrorFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfDcsErrorFrame != stMibStatisticalInfo.usNumberOfDcsErrorFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_DCSERROR_FRAME,
													 stMibStatisticalInfo.usNumberOfDcsErrorFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulFcsErrFrameNum[NX_PORT1] + gstStatistictInfo.ulFcsErrFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulFcsErrFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulFcsErrFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfFcsErrorFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfFcsErrorFrame != stMibStatisticalInfo.usNumberOfFcsErrorFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_FCSERROR_FRAME,
													 stMibStatisticalInfo.usNumberOfFcsErrorFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT1] + gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulSdcrcErrFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulSdcrcErrFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfSdcrcErrorFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfSdcrcErrorFrame != stMibStatisticalInfo.usNumberOfSdcrcErrorFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_SDCRCERROR_FRAME,
													 stMibStatisticalInfo.usNumberOfSdcrcErrorFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulShortPacketFrameNum[NX_PORT1] + gstStatistictInfo.ulShortPacketFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulShortPacketFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulShortPacketFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfShortPacketFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfShortPacketFrame != stMibStatisticalInfo.usNumberOfShortPacketFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_SHORTPACKET_FRAME,
													 stMibStatisticalInfo.usNumberOfShortPacketFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT1] + gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulJumboPacketFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulJumboPacketFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfJumboPacketFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfJumboPacketFrame != stMibStatisticalInfo.usNumberOfJumboPacketFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_JUMBOPACKET_FRAME,
													 stMibStatisticalInfo.usNumberOfJumboPacketFrame, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulLongPacketFrameNum[NX_PORT1] + gstStatistictInfo.ulLongPacketFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulLongPacketFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulLongPacketFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfLongPacketFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfLongPacketFrame != stMibStatisticalInfo.usNumberOfLongPacketFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_LONGPACKET_FRAME,
													 stMibStatisticalInfo.usNumberOfLongPacketFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT1] + gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulCCIEErrPduSizeNum[NX_PORT1] + gstStatistictInfoInteg.ulCCIEErrPduSizeNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfFailedCcLinkIePduSize = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfFailedCcLinkIePduSize != stMibStatisticalInfo.usNumberOfFailedCcLinkIePduSize) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_FAILEDCCLINKIEPDUSIZE,
													 stMibStatisticalInfo.usNumberOfFailedCcLinkIePduSize, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT1] + gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulFlagmentErrFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulFlagmentErrFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfFlagmentErrorFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfFlagmentErrorFrame != stMibStatisticalInfo.usNumberOfFlagmentErrorFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_FLAGMENTERROR_FRAME,
													 stMibStatisticalInfo.usNumberOfFlagmentErrorFrame, &ulErrDetailCode);
		}
		
#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT1] + gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulPriorityCtrlFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulPriorityCtrlFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfPriorityControlFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfPriorityControlFrame != stMibStatisticalInfo.usNumberOfPriorityControlFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_PRIORITYCONTROL_FRAME,
													 stMibStatisticalInfo.usNumberOfPriorityControlFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulIpFrameNum[NX_PORT1] + gstStatistictInfo.ulIpFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulIpFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulIpFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfIpFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfIpFrame != stMibStatisticalInfo.usNumberOfIpFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_IP_FRAME,
													 stMibStatisticalInfo.usNumberOfIpFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulIeeeFrameNum[NX_PORT1] + gstStatistictInfo.ulIeeeFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulIeeeFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulIeeeFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfIeee802or1588Frame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfIeee802or1588Frame != stMibStatisticalInfo.usNumberOfIeee802or1588Frame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_IEEE802OR1588_FRAME,
													 stMibStatisticalInfo.usNumberOfIeee802or1588Frame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulLldpFrameNum[NX_PORT1] + gstStatistictInfo.ulLldpFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulLldpFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulLldpFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfLldpFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfLldpFrame != stMibStatisticalInfo.usNumberOfLldpFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_LLDP_FRAME,
													 stMibStatisticalInfo.usNumberOfLldpFrame, &ulErrDetailCode);
		}

#ifndef ACCUMULATE_STATISTICS_INFORMATION
		ulTmpData = gstStatistictInfo.ulSyncFrameNum[NX_PORT1] + gstStatistictInfo.ulSyncFrameNum[NX_PORT2];
#else
		ulTmpData = gstStatistictInfoInteg.ulSyncFrameNum[NX_PORT1] + gstStatistictInfoInteg.ulSyncFrameNum[NX_PORT2];
#endif
		stMibStatisticalInfo.usNumberOfSyncFrame = usSNMP_ChkStatistictCnt(ulTmpData);
		if (gstPreStatistictInfo.usNumberOfSyncFrame != stMibStatisticalInfo.usNumberOfSyncFrame) {
			(NX_VOID)gulST_SNC_MibSetStatisticalInfo(ST_SNC_MAP_STATS_NUMBER_OF_SYNC_FRAME,
													 stMibStatisticalInfo.usNumberOfSyncFrame, &ulErrDetailCode);
		}
		vSNMP_ChkErrFrameRcvSts();

		gstPreStatistictInfo = stMibStatisticalInfo;
		
	}
	
	return;
}

NX_VOID vSNMP_UpdateAppFuncInfo (
    NX_ULONG* pulUpdateFlg
)
{
	NX_ULONG	ulCycSendSts;
	NX_ULONG	ulErrDetailCode;
	NX_UCHAR	uchAppFuncInfo;
	
	ulCycSendSts = ulNX_GetCycSendSts();
	if ((NX_ULONG)NX_ON == ulCycSendSts) {
		uchAppFuncInfo = uchNX_GetAppInfo_SyncSts();
	}
	else {
		uchAppFuncInfo = NX_APPINFO_UNSYNC;
	}
	
	if (uchAppFuncInfo != gstMibCtrl.uchAppFuncInfo) {
		(NX_VOID)gulST_SNC_MibSetID((NX_USHORT)ST_SNC_MAP_DEVDTL_STSINFO_APPINFO, ST_SNC_ARRAY_NON,
									 ST_SNC_IDX_0, &uchAppFuncInfo, sizeof(NX_UCHAR), &ulErrDetailCode);
		
		gstMibCtrl.uchAppFuncInfo = uchAppFuncInfo;
		*pulUpdateFlg = NX_ON;
	}
	return;
}


NX_ULONG ulNX_SetMibCurrentErr (
	NX_VOID* pvData
)
{
	NX_ULONG					ulRet = NX_UL_NG;
	NX_ULONG					ulErrDetailCode;
	NX_ULONG					ulRslt = NX_UL_NG;
	
	ulRslt = gulST_SNC_MibSetCurrentError(pvData, &ulErrDetailCode);
			
	if (ST_SNC_OK == ulRslt) {
		ulRet = NX_UL_OK;
	}
	
	return ulRet;
}

NX_VOID vNX_DelMibCurrentErr(NX_VOID)
{
	NX_ULONG	ulErrDetailCode;
	
	(NX_VOID)gulST_SNC_MibClearCurrentError(&ulErrDetailCode);

	return;
}

NX_VOID vSNMP_GetStatisticsCnt(NX_VOID)
{
	gstStatistictInfo.ulCycRecvCnt = NGN_RN->ulR_RNCYCCT & NX_BIT00_15;
	
	gstStatistictInfo.ulCycRecvDicardCnt = NGN_RN->ulR_RNCYCER & NX_BIT00_15;
	
	gstStatistictInfo.ulCycFrameRecvCnt = NGN_RN->ulR_RNCFLMCT & NX_BIT00_15;
	
	gstStatistictInfo.ulNonCycRecvCnt[NX_PORT1] = NGN_RN_NCyc->astNCycPortDatas[NX_PORT1].ulR_RNNCCT & NX_BIT00_15;
	
	gstStatistictInfo.ulNonCycRecvCnt[NX_PORT2] = NGN_RN_NCyc->astNCycPortDatas[NX_PORT2].ulR_RNNCCT & NX_BIT00_15;
	
	gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT1] = NGN_RN_NCyc->astNCycPortDatas[NX_PORT1].ulR_RNNCER & NX_BIT00_15;
	
	gstStatistictInfo.ulNonCycRecvDicardCnt[NX_PORT2] = NGN_RN_NCyc->astNCycPortDatas[NX_PORT2].ulR_RNNCER & NX_BIT00_15;
	
	gstStatistictInfo.ulHecErrFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_HECE_DCSE.BITS.b10ZHECErrFrameNum;
	
	gstStatistictInfo.ulHecErrFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_HECE_DCSE.BITS.b10ZHECErrFrameNum;
	
	gstStatistictInfo.ulDcsErrFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_HECE_DCSE.BITS.b10ZDCSErrFrameNum;
	
	gstStatistictInfo.ulDcsErrFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_HECE_DCSE.BITS.b10ZDCSErrFrameNum;
	
	gstStatistictInfo.ulFcsErrFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_FCSE_SDCE.BITS.b10ZFCSErrFrameNum;
	
	gstStatistictInfo.ulFcsErrFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_FCSE_SDCE.BITS.b10ZFCSErrFrameNum;
	
	gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_FCSE_SDCE.BITS.b10ZSDCErrFrameNum;
	
	gstStatistictInfo.ulSdcrcErrFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_FCSE_SDCE.BITS.b10ZSDCErrFrameNum;
	
	gstStatistictInfo.ulShortPacketFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_SHTP_JMBF.BITS.b10ZShortPacketNum;
	
	gstStatistictInfo.ulShortPacketFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_SHTP_JMBF.BITS.b10ZShortPacketNum;
	
	gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_SHTP_JMBF.BITS.b10ZJumboFrameNum;
	
	gstStatistictInfo.ulJumboPacketFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_SHTP_JMBF.BITS.b10ZJumboFrameNum;
	
	gstStatistictInfo.ulLongPacketFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_LNGP_PDLE.BITS.b10ZLongPacketNum;
	
	gstStatistictInfo.ulLongPacketFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_LNGP_PDLE.BITS.b10ZLongPacketNum;
	
	gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_PDPE_FRGE.BITS.b10ZPDULengthErrNum;
	
	gstStatistictInfo.ulCCIEErrPduSizeNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_PDPE_FRGE.BITS.b10ZPDULengthErrNum;
	
	gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_PDPE_FRGE.BITS.b10ZFragmentErrNum;
	
	gstStatistictInfo.ulFlagmentErrFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_PDPE_FRGE.BITS.b10ZFragmentErrNum;
	
	gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_TSEF.BITS.b10ZTSErrFrameNum;
	
	gstStatistictInfo.ulPriorityCtrlFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_TSEF.BITS.b10ZTSErrFrameNum;
	
	gstStatistictInfo.ulIpFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_TRNF_ASF.BITS.b10ZIPFrameNum;
	
	gstStatistictInfo.ulIpFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_TRNF_ASF.BITS.b10ZIPFrameNum;
	
	gstStatistictInfo.ulIeeeFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_TRNF_ASF.BITS.b10ZIEEEFrameNum;
	
	gstStatistictInfo.ulIeeeFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_TRNF_ASF.BITS.b10ZIEEEFrameNum;

	gstStatistictInfo.ulLldpFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_LLDPF.BITS.b10ZLLDPFrameNum;
	
	gstStatistictInfo.ulLldpFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_LLDPF.BITS.b10ZLLDPFrameNum;
	
	gstStatistictInfo.ulSyncFrameNum[NX_PORT1] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT1].R_RE_SYNCC.BITS.b10ZSyncFrameNum;
	
	gstStatistictInfo.ulSyncFrameNum[NX_PORT2] = NGN_CN_RE_REG->R_RE_FRMREG[NX_PORT2].R_RE_SYNCC.BITS.b10ZSyncFrameNum;
	
	gstStatistictInfo.ulRecvSfdDetCnt[NX_PORT1] = NGN_ES_REG->R_ESSFDDET1.DATA & NX_BIT00_15;
	
	gstStatistictInfo.ulRecvSfdDetCnt[NX_PORT2] = NGN_ES_REG->R_ESSFDDET2.DATA & NX_BIT00_15;

	gstStatistictInfo.ulMinIfgDetCnt[NX_PORT1] = NGN_ES_REG->R_ESIFGDET1.DATA & NX_BIT00_15;

	gstStatistictInfo.ulMinIfgDetCnt[NX_PORT2] = NGN_ES_REG->R_ESIFGDET2.DATA & NX_BIT00_15;

	vLOG_GetLogData();

	NGN_CN_REG->R_RESTCCLR.BITS.b01ZCounterClear = NX_ON;

	return;
}

NX_USHORT usSNMP_ChkStatistictCnt(
	NX_ULONG ulStatisticsCnt
)
{
	NX_USHORT	usStatisticsCnt;
	
	if (STATISTICS_CNT_MAX <= ulStatisticsCnt) {
		usStatisticsCnt = STATISTICS_CNT_MAX;
	}
	else {
		usStatisticsCnt = (NX_USHORT)ulStatisticsCnt;
	}
	
	return usStatisticsCnt;
}

NX_VOID vSNMP_ChkErrFrameRcvSts(NX_VOID)
{
	NX_USHORT	usLoop;
	NX_ULONG	ulRcvFrameNum;
	NX_ULONG	ulRcvErrFrameNum;
	NX_ULONG	ulCalcRslt;
	NX_ULONG	ulDenominator;
	NX_ULONG	ulMolecule;
	NX_ULONG	ulLinkSts;
	NX_USHORT	usCycFrameRecvCnt_log;
	NX_USHORT	usNonCycRecvCnt_log;
	
	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < NX_PORT_SIZE; usLoop++) {

		ulLinkSts = (gstNET.stPhyReg[usLoop].ulModeSts & PHYREG_MODESTS_BIT_LINKUPSTS);
		
		if (PHYREG_MODESTS_LINKUP == ulLinkSts) {
			if ((NGN_PORTROLE_INIT != gstNET.stPort[usLoop].usPortRole) 
				&& (NGN_PORTROLE_DOWN != gstNET.stPort[usLoop].usPortRole)) {
				ulRcvFrameNum = gstStatistictInfo.ulCycFrameRecvCnt + gstStatistictInfo.ulNonCycRecvCnt[usLoop];
				ulRcvErrFrameNum = gstStatistictInfo.ulFcsErrFrameNum[usLoop]
									 + gstStatistictInfo.ulShortPacketFrameNum[usLoop] + gstStatistictInfo.ulLongPacketFrameNum[usLoop];
				usCycFrameRecvCnt_log = (NX_USHORT)gstStatistictInfo.ulCycFrameRecvCnt;
				usNonCycRecvCnt_log = (NX_USHORT)gstStatistictInfo.ulNonCycRecvCnt[usLoop];
			}
			else {
				ulRcvFrameNum = gstStatistictInfo.ulNonCycRecvCnt[usLoop];
				ulRcvErrFrameNum = gstStatistictInfo.ulFcsErrFrameNum[usLoop]
									 + gstStatistictInfo.ulShortPacketFrameNum[usLoop] + gstStatistictInfo.ulLongPacketFrameNum[usLoop];
				usCycFrameRecvCnt_log = (NX_USHORT)NX_ZERO;
				usNonCycRecvCnt_log = (NX_USHORT)gstStatistictInfo.ulNonCycRecvCnt[usLoop];
			}
			if ((NX_ZERO != ulRcvFrameNum) && (NX_ZERO != ulRcvErrFrameNum)) {
				ulMolecule = (ulRcvErrFrameNum * SNMP_PER_100);
				ulDenominator = ulRcvFrameNum;
				ulCalcRslt = ulMolecule / ulDenominator;
				
				if (((ulMolecule - (ulDenominator * ulCalcRslt)) * SNMP_TWICE) >= ulDenominator) {
					ulCalcRslt = ulCalcRslt + (NX_ULONG)1;
				}
				
				if (ulCalcRslt < SNMP_PER_10){
					gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_OK;
				}
				else if ((SNMP_PER_10 <= ulCalcRslt) && (ulCalcRslt < SNMP_PER_20)) {
					gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_NOTE;
					
					vSNMP_SetErrFrameInfo(usLoop,
										(NX_USHORT)gstStatistictInfo.ulFcsErrFrameNum[usLoop],
										(NX_USHORT)gstStatistictInfo.ulShortPacketFrameNum[usLoop],
										(NX_USHORT)gstStatistictInfo.ulLongPacketFrameNum[usLoop],
										usCycFrameRecvCnt_log,
										usNonCycRecvCnt_log
										);
				}
				else {
					gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_WARNING;
					
					vSNMP_SetErrFrameInfo(usLoop,
										(NX_USHORT)gstStatistictInfo.ulFcsErrFrameNum[usLoop],
										(NX_USHORT)gstStatistictInfo.ulShortPacketFrameNum[usLoop],
										(NX_USHORT)gstStatistictInfo.ulLongPacketFrameNum[usLoop],
										usCycFrameRecvCnt_log,
										usNonCycRecvCnt_log
										);
				}
			}
			else if ((NX_ZERO == ulRcvFrameNum) && (NX_ZERO != ulRcvErrFrameNum)) {
				gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_WARNING;
				
				vSNMP_SetErrFrameInfo(usLoop,
									(NX_USHORT)gstStatistictInfo.ulFcsErrFrameNum[usLoop],
									(NX_USHORT)gstStatistictInfo.ulShortPacketFrameNum[usLoop],
									(NX_USHORT)gstStatistictInfo.ulLongPacketFrameNum[usLoop],
									usCycFrameRecvCnt_log,
									usNonCycRecvCnt_log
									);
			}
			else if ((NX_ZERO != ulRcvFrameNum) && (NX_ZERO == ulRcvErrFrameNum)) {
				gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_OK;
			}
			else {
				gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_OK;
			}
		}
		else {
			gstMibCtrl.auchErrFrameRcvSts[usLoop] = RX_FRAME_STS_NO_USE;
		}
	}
	
	return;
}

NX_VOID vSNMP_GetGlbErrFrameRcvSts (
	NX_USHORT usPhysicalPort,
	NX_UCHAR* puchErrFrameRcvSts
)
{
	*puchErrFrameRcvSts = gstMibCtrl.auchErrFrameRcvSts[usPhysicalPort];
	return;
}

NX_VOID vSNMP_SetErrFrameInfo (
	NX_USHORT	usPort,
	NX_USHORT	usFcsErrFrameNum,
	NX_USHORT	usShortPacketFrameNum,
	NX_USHORT	usLongPacketFrameNum,
	NX_USHORT	usCycFrameRecvCnt,
	NX_USHORT	usNonCycRecvCnt
)
{
	gstNET.stLibSts.stData.ausFcsErrFrameNum[usPort]		=	usFcsErrFrameNum;
	gstNET.stLibSts.stData.ausShortPacketFrameNum[usPort]	=	usShortPacketFrameNum;
	gstNET.stLibSts.stData.ausLongPacketFrameNum[usPort]	=	usLongPacketFrameNum;
	gstNET.stLibSts.stData.ausCycFrameRecvCnt[usPort]		=	usCycFrameRecvCnt;
	gstNET.stLibSts.stData.ausNonCycRecvCnt[usPort]			=	usNonCycRecvCnt;
	
	return;
}

NX_UCHAR vSNMP_GetCyclicStopInfo(NX_VOID)
{
	return gstMibCtrl.uchCyclicStopInfo;
}
