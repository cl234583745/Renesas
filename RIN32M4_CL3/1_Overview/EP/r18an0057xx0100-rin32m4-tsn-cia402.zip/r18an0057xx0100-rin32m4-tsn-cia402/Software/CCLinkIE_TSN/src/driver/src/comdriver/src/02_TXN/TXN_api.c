/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "kernel.h"
#include "TXN_api.h"
#include "TXN_buf.h"
#include "TOOL_api.h"
#include "TXN_main.h"



NX_EXTERN NX_ULONG	gulTsState;



NX_LONG lTXN_AllocBuf_NonCycTx (
	NX_ULONG		ulFrameType,
	NX_USHORT		usSize,
	NCYC_TX_FRAME**	pstTxFrame
)
{
	NX_ULONG	ulResultSub;
	NX_LONG	lResult;
	ulResultSub = ulTXN_AllocTxNonCycBuf(ulFrameType, usSize, pstTxFrame);
	if (ulResultSub == NX_UL_OK) {
		lResult = NCYC_TX_BUF_RSLT_OK;
	}
	else {
		lResult = NCYC_TX_BUF_RSLT_BUF_FULL;
	}
	
	return lResult;
}


NX_VOID vTXN_ReleaseBuf_NonCycTx (
	NCYC_TX_FRAME	stTxFrame
)
{
	vTXN_ReleaseNonCycTxBuf(stTxFrame.usBuffId);
	
	return;
}

NX_VOID vTXN_NotifyStore_TxNonCycBuf (
	NX_USHORT		usTsNo,
	NCYC_TX_FRAME*	pstTxFrame
)
{
	(NX_VOID)snd_mbx(MailBoxIdList[usTsNo], (T_MSG*)(pstTxFrame));
	return;
}
NX_ULONG ulTXN_ChangeReqTsState (
	NX_ULONG	ulReqState
)
{
	NX_ULONG ulResult;
	
	
	ulResult = (NX_ULONG)CHANGE_COMP;
	switch (ulReqState) {
	case TSREQ_DITOEN_REQ:
		if (((NX_ULONG)TSSTATE_DI == gulTsState) ||
			((NX_ULONG)TSSTATE_DI_REQ == gulTsState)) {
			gulTsState = (NX_ULONG)TSSTATE_EI_REQ;
		}
		else {
			ulResult = (NX_ULONG)CHANGE_ERR;
		}
		break;
	case TSREQ_ENCOMP:
		if ((NX_ULONG)TSSTATE_DI_REQWAIT == gulTsState) {
			gulTsState = (NX_ULONG)TSSTATE_EN;
		}
		else {
			ulResult = (NX_ULONG)CHANGE_ERR;
		}
		break;
	case TSREQ_DI_REQ:
		if (gulTsState == (NX_ULONG)TSSTATE_EN) {
			gulTsState = (NX_ULONG)TSSTATE_DI_REQ;
		}
		else {
			
		}
		break;
	default:
		ulResult = (NX_ULONG)CHANGE_ERR;
		break;
	}
	return ulResult;
}

NX_ULONG ulTXN_GetTsState (NX_VOID)
{
	return gulTsState;
}

