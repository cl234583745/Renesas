/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNC_H_INCLUDED__
#define __ST_SNC_H_INCLUDED__

#ifdef MASTER
#ifdef SWPS
#include "CCIEN.h"
#include "ST_Common.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_errcode.h"
#else
#include <28_NPS/API/CCIEN.h>
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#endif
#else
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_errcode.h"
#endif

#define ST_SNC_ARRAY_NON       (0x01)
#define ST_SNC_ARRAY_ADD       (0x02)
#define ST_SNC_ARRAY_MOD       (0x04)
#define ST_SNC_ARRAY_DEL       (0x08)


#if MASTER
NX_ULONG gulST_SNC_Initialize(const CCIEN_INIT_PLATFORM_PARMS_TAG *pPlatformParms);
#else
NX_ULONG gulST_SNC_Initialize(NX_VOID);
#endif

NX_ULONG gulST_SNC_Terminate(NX_VOID);
NX_ULONG gulST_SNC_Start(NX_VOID);
NX_ULONG gulST_SNC_Stop(NX_VOID);
NX_ULONG gulST_SNC_Config(
	const NX_CHAR*		pucCommunity1,
	const NX_CHAR*		pucCommunity2,
	const NX_CHAR*		pucCommunity3,
	const NX_CHAR*		pucCommunity4,
	NX_USHORT			usRcvPort
);

NX_ULONG gulST_SNC_MibSetNetConfMaster(const ST_SNC_N2MibMasterStation* pstData, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetNetConfConnect(const ST_SNC_N2MibConnectedStation* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibClearNetworkConfig(NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetDevDtlIdent(const ST_SNC_N2MibIdentifierInfo* pstData, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetDevDtlStsinfo(const ST_SNC_N3MibStatusInfoBase* pstData, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetDevDtlStsMaster(const ST_SNC_N3MibStatusMaster* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetDevDtlStsLed(const ST_SNC_N3MibLed* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetDevDtlStsPort(const ST_SNC_N3MibPort* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibCommit(NX_ULONG* pulDtlErrorCode);


NX_ULONG gulST_SNC_MibSetOtModCntl(const ST_SNC_N2MibController* pstCntl, NX_ULONG* pulDtlErrorCode);
NX_ULONG gulST_SNC_MibSetOtModOpt(const ST_SNC_N2MibOptionInfo* pstOpt, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetStatisticalInfo(
	NX_USHORT	usOidmap,
	NX_USHORT	usNumber,
	NX_ULONG* pulDtlErrorCode
);

NX_ULONG gulST_SNC_MibSetIpOverlapError(const ST_SNC_N2MibIpOverlapReg* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetTopologyError(const ST_SNC_N2MibTopologyReg* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);


NX_ULONG gulST_SNC_MibSetDataLinkError(const ST_SNC_N2MibDatalinkErrorReg* pstData, NX_USHORT usIndex, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetCommunicationTimingError(NX_UCHAR uchTimeslotNumber, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetCurrentError(const ST_SNC_N2MibErrorReg* pstData, NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibClearCurrentError(NX_ULONG* pulDtlErrorCode);

NX_ULONG gulST_SNC_MibSetID(
	NX_USHORT 				usOidmap,
	NX_UCHAR				uchCntlType,
	NX_USHORT				usIndex,
	const NX_VOID* 		pData,
	NX_ULONG 				ulDataSize,
	NX_ULONG* 				pulDtlErrorCode
);

#ifdef SWPS
NX_ULONG gulST_SNC_MibSetLLDP(
	NX_UCHAR uchCtrlType,
	const ST_SNC_MibLldpSend* pstData,
	NX_ULONG* pulDtlErrorCode
);
#endif

#endif

