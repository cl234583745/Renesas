/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNP_EXTMIB_SV_L_H_INCLUDED__
#define __ST_SNP_EXTMIB_SV_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include <snmp.h>
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#endif
#endif

typedef enum {
	ST_SNM_IDX_NONE,
	ST_SNM_IDX_NWCFG_CONTED,
	ST_SNM_IDX_NWCFG_ADJACENT,
	ST_SNM_IDX_DEVDTL_MASTER,
	ST_SNM_IDX_DEVDTL_LED,
	ST_SNM_IDX_DEVDTL_PORT,
	ST_SNM_IDX_OTMDL_OPT,
	ST_SNM_IDX_IPOVERLAP_REG,
	ST_SNM_IDX_TOPOLOGY_REG,
	ST_SNM_IDX_DATALINK_REG,
	ST_SNM_IDX_CURERR_ERRREG,
	ST_SNM_IDX_CURERR_ERRDTLREG,
	ST_SNM_IDX_TYPE_MAX,
} ST_SNM_IndexType;

#ifdef SWPS
struct ST_SNM_MibTblSet_TAG;
typedef struct ST_SNM_MibTblSet_TAG ST_SNM_MibTblSet;
struct ST_SNM_MibEntry_TAG;
typedef struct ST_SNM_MibEntry_TAG ST_SNM_MibEntry;
#endif

extern NX_VOID		ST_SNM_GetExtMibTbl(ST_SNM_MibTblSet**	pstTblSet);
extern NX_ULONG	ulST_SNM_ExtMib_UpdateAddrForMibType(NX_UCHAR	uchMibType);
#ifdef SWPS
extern BOOL		bST_SNM_CheckStationUnitLock(SnmpVarBind* pVarBind, DWORD dwRequestType);
extern ULONG ulST_SNM_ExtMib_GetForLong(
				USHORT		usOidmap,
				ULONG		ulTabix,
				UCHAR**		puchPtr,
				BOOL		bIndex
);
extern ULONG	ulST_SNM_ExtMib_IndexForLong(USHORT usOidmap, ULONG ulTabix);
extern BOOL		bST_SNM_CheckIndexLongRange(const ST_SNM_MibEntry* pstMib, const ST_SNM_MibTblSet* pstTblSet);
#endif

#endif
