/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3FUNCTION_H__
#define __R_IN32M4_CL3FUNCTION_H__

/* F/W Version:Ver 1.03D   */

/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "R_IN32M4_CL3Types.h"
#include "R_IN32M4_CL3TypesSlmp.h"
#include "R_IN32M4_CL3Struct.h"

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/

#define R_IN_BASE_ADR					0x40100000			/* R-IN32M4-CL3 top address										*/
#define R_IN_WAITUS_PHYRESET_ASSERT		10000UL				/* PHY reset assert time									*/
#define R_IN_WAITUS_PHYRESET_END		5000UL				/* Time until normal operation after releasing PHY reset	*/
#define R_IN_TRANSIENT_BUFFER_NUM		(64)				/* Transient receive buffer count							*/

/* Reset state */
#define R_IN_RESET_PWRON				1					/* Power-on reset											*/
#define R_IN_RESET_SYSTEM				2					/* System reset												*/

/* Data link state */
#define R_IN_COMMSTS_DISCONNECT			0					/* Disconnected												*/
#define R_IN_COMMSTS_CYC_STOP			1					/* Data link (cyclic communication is stopped)				*/
#define R_IN_COMMSTS_CYC_DLINK			2					/* Data link (cyclic communication in progress)				*/

/* Port state */
#define R_IN_LINKDOWN					0					/* Link down												*/
#define R_IN_LINKUP						1					/* Link up													*/

/* Port enable/disable specification */
#define R_IN_MYPORT_PORTALL				0x00				/* Enable all ports owned									*/
#define R_IN_MYPORT_PORT_1				0x01				/* Only port1 enabled										*/
#define R_IN_MYPORT_PORT_2				0x02				/* Only port2 enabled										*/

/* Port full duplex/half duplex */
#define R_IN_DUPLEX_FULL				0					/* Full duplex												*/
#define R_IN_DUPLEX_HALF				1					/* Half duplex												*/

/* LED lighting control */
#define R_IN_LED_DISABLE_RUN				0x0001			/* LED lighting function disabled RUN LED					*/
#define R_IN_LED_DISABLE_USER2				0x0002			/* LED lighting function disabled USER LED2					*/
#define R_IN_LED_DISABLE_ERR				0x0008			/* LED lighting function disabled ERR LED					*/
#define R_IN_LED_DISABLE_USER1				0x0020			/* LED lighting function disabled USER LED1					*/
#define R_IN_LED_DISABLE_DLINK				0x0040			/* LED lighting function disabled DLINK LED					*/
#define R_IN_LED_DISABLE_LER1				0x0200			/* LED lighting function disabled L ER1 LED					*/
#define R_IN_LED_DISABLE_LER2				0x0400			/* LED lighting function disabled L ER2 LED					*/
#define R_IN_LED_DISABLE_ALL				(R_IN_LED_DISABLE_RUN	|	R_IN_LED_DISABLE_USER2	|	\
											 R_IN_LED_DISABLE_ERR 	|	R_IN_LED_DISABLE_USER1	|	\
											 R_IN_LED_DISABLE_DLINK	|	R_IN_LED_DISABLE_LER1	|	\
											 R_IN_LED_DISABLE_LER2									)
															/* LED lighting function disabled all LEDs					*/
#define R_IN_LED_DISABLEPARAMETER_NORMAL	0				/* LED lighting function valid specified value normal		*/

#define R_IN_LED_ENABLE_RUN					0x0001			/* LED lighting function enabled RUN LED					*/
#define R_IN_LED_ENABLE_USER2				0x0002			/* LED lighting function enabled USER LED2					*/
#define R_IN_LED_ENABLE_ERR					0x0008			/* LED lighting function enabled ERR LED					*/
#define R_IN_LED_ENABLE_USER1				0x0020			/* LED lighting function enabled USER LED1					*/
#define R_IN_LED_ENABLE_DLINK				0x0040			/* LED lighting function enabled DLINK LED					*/
#define R_IN_LED_ENABLE_LER1				0x0200			/* LED lighting function enabled L ER1 LED					*/
#define R_IN_LED_ENABLE_LER2				0x0400			/* LED lighting function enabled L ER2 LED					*/
#define R_IN_LED_ENABLE_ALL					(R_IN_LED_ENABLE_RUN	|	R_IN_LED_ENABLE_USER2	|	\
											 R_IN_LED_ENABLE_ERR 	|	R_IN_LED_ENABLE_USER1	|	\
											 R_IN_LED_ENABLE_DLINK	|	R_IN_LED_ENABLE_LER1	|	\
											 R_IN_LED_ENABLE_LER2									)
															/* LED lighting function enabled all LEDs					*/
#define R_IN_LED_ENABLEPARAMETER_NORMAL		0				/* LED lighting function valid specified value normal		*/

#define R_IN_LED_TESTMODE_RUN				0x0001			/* Test function enable/disable RUN LED						*/
#define R_IN_LED_TESTMODE_MODE				0x0002			/* Test function enable/disable MODE LED					*/
#define R_IN_LED_TESTMODE_REM				0x0004			/* Test function enable/disable REM LED						*/
#define R_IN_LED_TESTMODE_DLINK				0x0008			/* Test function enable/disable DLINK LED					*/
#define R_IN_LED_TESTMODE_ERR				0x0010			/* Test function enable/disable ERR LED						*/
#define R_IN_LED_TESTMODE_SD_SDRD1			0x0020			/* Test function enable/disable SD_SDRD1 LED				*/
#define R_IN_LED_TESTMODE_RD_SDRD2			0x0040			/* Test function enable/disable RD_SDRD2 LED				*/
#define R_IN_LED_TESTMODE_LER1				0x0080			/* Test function enable/disable LER1 LED					*/
#define R_IN_LED_TESTMODE_LER2				0x0100			/* Test function enable/disable LER2 LED					*/
#define R_IN_LED_TESTMODE_LINK1				0x4000			/* Test function enable/disable LINK1 LED					*/
#define R_IN_LED_TESTMODE_LINK2				0x8000			/* Test function enable/disable LINK2 LED					*/
#define R_IN_LED_TESTMODE_ALL				(R_IN_LED_TESTMODE_RUN		|	R_IN_LED_TESTMODE_MODE		|	\
											 R_IN_LED_TESTMODE_REM		|	R_IN_LED_TESTMODE_DLINK		|	\
											 R_IN_LED_TESTMODE_ERR		|	R_IN_LED_TESTMODE_SD_SDRD1	|	\
											 R_IN_LED_TESTMODE_RD_SDRD2	|	R_IN_LED_TESTMODE_LER1		|	\
											 R_IN_LED_TESTMODE_LER2		|	R_IN_LED_TESTMODE_LINK1		|	\
											 R_IN_LED_TESTMODE_LINK2										)
															/* Test function enables / disables all LED					*/

#define R_IN_LED_TEST_RUN					0x0001			/* Forced on/off RUN LED									*/
#define R_IN_LED_TEST_MODE					0x0002			/* Forced on/off MODE LED									*/
#define R_IN_LED_TEST_REM					0x0004			/* Forced on/off REM LED									*/
#define R_IN_LED_TEST_DLINK					0x0008			/* Forced on/off DLINK LED									*/
#define R_IN_LED_TEST_ERR					0x0010			/* Forced on/off ERR LED									*/
#define R_IN_LED_TEST_SD_SDRD1				0x0020			/* Forced on/off SD_SDRD1 LED								*/
#define R_IN_LED_TEST_RD_SDRD2				0x0040			/* Forced on/off RD_SDRD2 LED								*/
#define R_IN_LED_TEST_LER1					0x0080			/* Forced on/off LER1 LED									*/
#define R_IN_LED_TEST_LER2					0x0100			/* Forced on/off LER2 LED									*/
#define R_IN_LED_TEST_LINK1					0x4000			/* Forced on/off LINK1 LED									*/
#define R_IN_LED_TEST_LINK2					0x8000			/* Forced on/off LINK2 LED									*/
#define R_IN_LED_TEST_ALL					(R_IN_LED_TEST_RUN		|	R_IN_LED_TEST_MODE		|	\
											 R_IN_LED_TEST_REM		|	R_IN_LED_TEST_DLINK		|	\
											 R_IN_LED_TEST_ERR		|	R_IN_LED_TEST_SD_SDRD1	|	\
											 R_IN_LED_TEST_RD_SDRD2	|	R_IN_LED_TEST_LER1		|	\
											 R_IN_LED_TEST_LER2		|	R_IN_LED_TEST_LINK1		|	\
											 R_IN_LED_TEST_LINK2									)
															/* Forced on/off all LED									*/
#define R_IN_LED_TESTPARAMETER_NORMAL		0				/* Test LED parameters OK									*/

/* Enable/Disable */
#define R_IN_ENABLE							1				/* Enable													*/
#define R_IN_DISABLE						0				/* Disable													*/


/* Interrupt factor */
#define	R_IN_EVTPRM_INTERRUPT_CONNECT			(0x00000001UL)
#define	R_IN_EVTPRM_INTERRUPT_DISCONNECT		(0x00000002UL)
#define R_IN_EVTPRM_INTERRUPT_CHANGE_IPADDRESS	(0x00000080UL)


#define R_IN_DISCONNECTFACTOR_NOFACTOR			(0x00000000UL)
#define R_IN_DISCONNECTFACTOR_PERSUASION		(0x00000001UL)

/* WDT */
#define R_IN_WDT_MAX_COUNT				0x001F				/* WDT time maximum value									*/

/* MIB LED status information maximum entries */
#define R_IN_MIBLED_MAX					(8)

/* LED type for MIB LED status information definition */
#define R_IN_LED_ID_NOTUSE				(0)
#define R_IN_LED_ID_RUN					(1)
#define R_IN_LED_ID_USER1				(2)
#define R_IN_LED_ID_USER2				(3)
#define R_IN_LED_ID_DLINK				(4)
#define R_IN_LED_ID_ERR					(5)
#define R_IN_LED_ID_SD_SDRD1			(6)
#define R_IN_LED_ID_RD_SDRD2			(7)
#define R_IN_LED_ID_LER1				(8)
#define R_IN_LED_ID_LER2				(9)
#define R_IN_LED_ID_LINK1				(10)
#define R_IN_LED_ID_LINK2				(11)
#define R_IN_LED_ID_LINK				(12)				/* Indicates the logical sum of the ON states of LINK1 and LINK2 */

/* LED color for MIB LED status information definition */
#define R_IN_LED_NOTUSE					(0)
#define R_IN_LED_COLOR_GREEN			(1)
#define R_IN_LED_COLOR_RED				(2)
#define R_IN_LED_COLOR_ORANGE			(3)
#define R_IN_LED_COLOR_OTHER			(4)

/* Synchronous control Mode */
#define R_IN_ASYNCHRONOUS				(0)					/* Asynchronous mode  */
#define R_IN_SYNCHRONOUS				(1)					/* Synchronous mode   */
/* Execution result */
#define R_IN_SUCCEED					(0)					/* Processing success */
#define R_IN_FAIL						(1)					/* Processing failed  */
/* Topology information */
#define R_IN_NETWORK_TOPOLOGY_UNKNOWN	(0UL)
#define R_IN_NETWORK_TOPOLOGY_OTHER		(1UL)
#define R_IN_NETWORK_TOPOLOGY_RING		(2UL)



/*********************************************************************************/
/* Structures                                                                    */
/*********************************************************************************/

/* Interrupt factor */
typedef struct R_IN_EVTPRM_INTERRUPT_TAG {
	union {
		ULONG ulAll;
		struct {
			ULONG b1ZCommConnect:				1;			/* b0: Participation in communication						*/
			ULONG b1ZCommDisconnect:			1;			/* b1: Communication disconnection							*/
			ULONG b5ZReserve1:					5;			/* b2-6: Reservation										*/
			ULONG b1ZChangeIPAddress:			1;			/* b7: IP address update									*/
			ULONG b24ZReserve2:					24;			/* b8-31: Reservation										*/
		} stBit;
	} uniFlag;
} R_IN_EVTPRM_INTERRUPT_T;

/* MIB information LED status output target LED specification */
typedef struct R_IN_MIBLEDDEFINE_TAG {
	UCHAR	uchIdentification;								/* LED type													*/
	UCHAR	uchColor;										/* LED color												*/
} R_IN_MIBLEDDEFINE_T;

/* Own station operation mode */
typedef struct R_IN_NODE_OPERATION_MODE_TAG {
	USHORT	usSyncMode;										/* Sync/Async mode state									*/
} R_IN_NODE_OPERATION_MODE_T;


/*********************************************************************************/
/* Functions                                                                     */
/*********************************************************************************/
extern ULONG   gulR_IN_GetResetStatus( VOID );
extern ERRCODE gerR_IN_Initialize( const UCHAR *puchMACAddress, const R_IN_UNITINFO_T *pstUnitInfo, const R_IN_UNITINIT_T *pstUnitInit );
extern ERRCODE gerR_IN_SetIPAddress( ULONG ulIPAddress, ULONG ulSubnetmask, ULONG ulDefaultGateway );
extern ERRCODE gerR_IN_Start( VOID );
extern ERRCODE gerR_IN_GetStatisticalInformation( R_IN_STATISTICS_T* pstStatisticalInformation );
extern ERRCODE gerR_IN_ClearStatisticalInformation( VOID );
extern ERRCODE gerR_IN_ResetWDT( VOID );
extern ERRCODE gerR_IN_DisableWDT( VOID );
extern ERRCODE gerR_IN_EnableWDT( VOID );
extern ERRCODE gerR_IN_SetWDT( USHORT usWDTCOUNT );
#ifndef TSN_CAN_ENABLE
extern ERRCODE gerR_IN_GetReceivedCyclicData( VOID* pRyDst, VOID* pRWwDst, BOOL blEnable );
extern ERRCODE gerR_IN_UpdateReceivedCyclicData( VOID );
extern ERRCODE gerR_IN_FinishReceivedCyclicDataAcquisition( VOID );
extern ERRCODE gerR_IN_GetReceivedCyclicRY( ULONG ulPosi, ULONG ulNum, USHORT* pusDst );
extern ERRCODE gerR_IN_GetReceivedCyclicRWw( ULONG ulPosi, ULONG ulNum, USHORT* pusDst );
extern ERRCODE gerR_IN_GetReceivedCyclicBuffer( ULONG* pulRyBuffer, ULONG* pulRWwBuffer );
extern ERRCODE gerR_IN_FinishReceivedCyclicBuffer( VOID );
#endif
extern ERRCODE gerR_IN_GetMasterNodeStatus( BOOL* pblRunSts, BOOL* pblErrSts);
extern ERRCODE gerR_IN_GetHoldClearFlag( BOOL* pblHoldClearFlag );
#ifndef TSN_CAN_ENABLE
extern ERRCODE gerR_IN_SetSendCyclicData( const VOID* pRxSrc, const VOID* pRWrSrc, BOOL blEnable );
extern ERRCODE gerR_IN_FinishSendCyclicDataSetting( VOID );
extern ERRCODE gerR_IN_SetSendCyclicRX( const USHORT* pusSrc, ULONG ulPosi, ULONG ulNum );
extern ERRCODE gerR_IN_SetSendCyclicRWr( const USHORT* pusSrc, ULONG ulPosi, ULONG ulNum );
extern ERRCODE gerR_IN_GetSendCyclicBuffer( ULONG* pulRxBuffer, ULONG* pulRWrBuffer );
extern ERRCODE gerR_IN_GetSplitSendCyclicBuffer( R_IN_SEND_CYCLIC_BUFFER_T* pstBuffer );
extern ERRCODE gerR_IN_FinishSendCyclicBuffer( VOID );
#endif
extern ERRCODE gerR_IN_SetNodeStatus( ULONG ulErrSts );
extern ERRCODE gerR_IN_GetIPAddress( ULONG* pulIPAddress, ULONG* pulSubnetmask, ULONG* pulDefaultGateway );
extern ERRCODE gerR_IN_GetCurrentCyclicSize( R_IN_CYCLIC_SIZE_T* pstCyclicSize );
extern ERRCODE gerR_IN_GetCommumicationStatus( ULONG* pulCommSts );
extern ERRCODE gerR_IN_GetPortStatus( ULONG ulPort, ULONG* pulLinkStatus, ULONG* pulSpeed, ULONG* pulDuplex );
extern ERRCODE gerR_IN_GetCyclicStatus( UCHAR* puchCyclicStatus );
extern ERRCODE gerR_IN_GetEvent( R_IN_EVTPRM_INTERRUPT_T* pstEvent );
extern ERRCODE gerR_IN_Main(const R_IN_EVTPRM_INTERRUPT_T* pstEvent );
extern ERRCODE gerR_IN_RestartEvent( VOID );
extern ERRCODE gerR_IN_SetERRLED(ULONG ulCtrl);
extern ERRCODE gerR_IN_SetLERR1LED(ULONG ulCtrl);
extern ERRCODE gerR_IN_SetLERR2LED(ULONG ulCtrl);
extern ERRCODE gerR_IN_SetUSER1LED(ULONG ulCtrl);
extern ERRCODE gerR_IN_SetUSER2LED(ULONG ulCtrl);
extern ERRCODE gerR_IN_SetRUNLED(ULONG ulCtrl);
extern ERRCODE gerR_IN_DisableLED(USHORT usDisable);
extern ERRCODE gerR_IN_EnableLED(USHORT usEnable);
extern ERRCODE gerR_IN_UpdateLedStatus(VOID);
extern ERRCODE gerR_IN_SetSDRDLEDMode(ULONG ulMode);
extern ERRCODE gerR_IN_StartTestLED(USHORT usTestMode);
extern ERRCODE gerR_IN_ExecuteTestLED(USHORT usTestLed);
extern ERRCODE gerR_IN_StopTestLED(VOID);
extern ERRCODE gerR_IN_GetNetworkTime(USHORT* pusSerial);
extern ERRCODE gerR_IN_NetworkTimeToDate(R_IN_TIMEINFO_T* pstTimeInfo, const USHORT* pusSerial);
extern ERRCODE gerR_IN_DateToNetworkTime(const R_IN_TIMEINFO_T* pstTimeInfo, USHORT* pusSerial);
extern ERRCODE gerR_IN_GetUnixTime(R_IN_UNIX_TIME_T* pstUnixTime);
extern ERRCODE gerR_IN_UnixTimeToDate(R_IN_TIMEINFO_T* pstTimeInfo, const R_IN_UNIX_TIME_T* pstUnixTime);
extern ERRCODE gerR_IN_DateToUnixTime(const R_IN_TIMEINFO_T* pstTimeInfo, R_IN_UNIX_TIME_T* pstUnixTime);
extern VOID    gvR_IN_SetUnixOffsetTime(LONGLONG llOffsetSec, LONG lOffsetNsec, SHORT sUtcOffsetMin, SHORT sSummerTimeOffsetMin);
extern ERRCODE gerR_IN_GetUnixOffsetTime(LONGLONG* pllOffsetSec, LONG* plOffsetNsec, SHORT* psUtcOffsetMin, SHORT* psSummerTimeOffsetMin);
extern VOID    gvR_IN_RegistIPAddressFilteringFunction(R_IN_IP_FILTERING_FUNCTION fpulFunction);
extern ERRCODE gerR_IN_SendSlmpFrame(VOID);
extern ERRCODE gerR_IN_WriteSlmpSendBuffer(const VOID* pvReceiveBuffer, USHORT usSize,
					ULONG ulIpAddress, USHORT usPort, USHORT usPhysicalPort, VOID* pvSendBuffer);
extern ERRCODE gerR_IN_SetSlmpResponseFrameSendRequest(VOID* pvResponseDataTopAddress,
					R_IN_SLMP_SEND_INFORMATION_T* pstReceiveInformation);
extern VOID    gvR_IN_ReleaseSlmpReceiveFrame(VOID);
extern ERRCODE gerR_IN_ReceivedSlmpMain(VOID);
extern VOID    gvR_IN_ReceivedSlmpExecution(VOID);
extern ERRCODE gerR_IN_SetReceiveSlmpStatus(BOOL blEnable);
extern ERRCODE gerR_IN_SetSlmpCommand(const R_IN_SLMP_EXECUTION_RECEIVE_TBL_T* pstUserSlmpReceiveFunctionTable);
extern BOOL    gblR_IN_GetSlmpSendBufferUsed(VOID);
extern BOOL    gblR_IN_GetReceiveSlmpStatus(VOID);
extern VOID    gvR_IN_ExecuteReset(VOID);
extern ERRCODE gerR_IN_CheckIpAddressSlmp(ULONG ulIPAddress, ULONG ulSubnetMask);
extern ERRCODE gerR_IN_CopyMemory( VOID* pvDestination, const VOID* pvSource, ULONG ulSize );
extern ERRCODE gerR_IN_FillMemory( VOID* pvDestination, UCHAR uchFillData, ULONG ulSize );
extern ERRCODE gerR_IN_FillMemory16( VOID* pvDestination, USHORT usFillData, ULONG ulSize );
extern ERRCODE gerR_IN_FillMemory32( VOID* pvDestination, ULONG ulFillData, ULONG ulSize );
extern VOID    gvR_IN_DisableInt(VOID);
extern VOID    gvR_IN_EnableInt(VOID);
extern VOID    gvR_IN_DisableDispatch(VOID);
extern VOID    gvR_IN_EnableDispatch(VOID);
extern ERRCODE gerR_IN_EndianShort( USHORT* pusVal );
extern ERRCODE gerR_IN_EndianLong( ULONG* pulVal );
extern ERRCODE gerR_IN_EndianLongLong( ULONGLONG* pullVal );
extern ERRCODE gerR_IN_GetMasterIPAddress( ULONG* pulIPAddress, USHORT* pusPhysicalPort);
extern ERRCODE gerR_IN_IEEETest(USHORT usMode);
extern ERRCODE gerR_IN_InitializeLoopBackTest(VOID);
extern ERRCODE gerR_IN_SendLoopBackTest(ULONG ulPort);
extern ERRCODE gerR_IN_ReceiveLoopBackTest(ULONG ulPort);
extern ERRCODE gerR_IN_StartSlmpRequestTimer(const R_IN_TIMEOUT_FUNCTION fpvTimeoutFunction, ULONG ulLimitTime, USHORT usTimerId);
extern ERRCODE gerR_IN_StopSlmpRequestTimer(USHORT usTimerId);
extern ERRCODE gerR_IN_EnableMACIPAccess(VOID);
extern ERRCODE gerR_IN_DisableMACIPAccess(VOID);
extern ERRCODE gerR_IN_ReadPHY(ULONG ulPort, ULONG ulAddr, ULONG* pulData);
extern ERRCODE gerR_IN_WritePHY(ULONG ulPort, ULONG ulAddr, ULONG ulData);
extern ERRCODE gerR_IN_SetErrorHistory(R_IN_ERROR_INFORMATION_T* pstErrorInformation);
extern VOID    gvR_IN_ClearErrorHistory(VOID);
extern ERRCODE gerR_IN_MIBLedTableDefine(UCHAR uchNumberOfLED, const R_IN_MIBLEDDEFINE_T *pstMIBLedDefine);
extern ERRCODE gerR_IN_RegistCallback(ULONG ulFunctionType, R_IN_CALLBACK_FUNCTION fpulFunction);
extern ERRCODE gerR_IN_GetNodeOperationMode(R_IN_NODE_OPERATION_MODE_T* pstMode);
extern ERRCODE gerR_IN_GetSyncDeviationFlag(BOOL* pblSyncDeviationFlag);
extern ERRCODE gerR_IN_StopAppSyncSignal(USHORT* pusResult);
extern ERRCODE gerR_IN_SetWdcThreshold(USHORT usWdcThreshold);
extern ERRCODE gerR_IN_MakeResponseWdcInfomation(VOID* pvResponseData, USHORT* pusDataSize);
extern VOID    gvR_IN_IncrementWdcUL(VOID);
extern VOID    gvR_IN_LatchWdcUL(VOID);
extern ERRCODE gerR_IN_GetWdcUL(BOOL blWdcULValidFlag, USHORT* pusWdcUL);
extern ERRCODE gerR_IN_CheckWdcDL(USHORT usWdc, USHORT* pusCheckResult);
extern ULONG gulR_IN_GetNetworkTopology(VOID);

#endif

/*** EOF ***/
