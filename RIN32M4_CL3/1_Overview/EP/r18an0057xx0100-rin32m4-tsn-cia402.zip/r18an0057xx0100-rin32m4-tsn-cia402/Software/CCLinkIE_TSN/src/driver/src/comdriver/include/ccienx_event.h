/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_EVENT_H_INCLUDE__
#define __CCIENX_EVENT_H_INCLUDE__
#include "ccienx_type.h"
#include "ccienx_struct.h"

#define	EVENTCODE_NONE				((NX_USHORT)0x0000)
#define	EVENTCODE_NETSETTING1		((NX_USHORT)0x0001)
#define	EVENTCODE_NETSETTING2		((NX_USHORT)0x0002)
#define	EVENTCODE_SYNCSETTING		((NX_USHORT)0x0003)
#define	EVENTCODE_DUPLICATIONIP	    ((NX_USHORT)0x0004)
#define	EVENTCODE_USNET_ERR			((NX_USHORT)0x0005)
#define	EVENTCODE_AXI_BUS_ERR		((NX_USHORT)0x0006)
#define	EVENTCODE_RXRY_SIZEERR		((NX_USHORT)0x0007)
#define	EVENTCODE_RWRRWW_SIZEERR	((NX_USHORT)0x0008)
#define	EVENTCODE_SET_IP_ERR		((NX_USHORT)0x0009)
#define	EVENTCODE_ETHERMAC_ERR		((NX_USHORT)0x000A)
#define	EVENTCODE_RW_SETERR			((NX_USHORT)0x000B)
#define	EVENTCODE_SYNC_CYC_SETERR	((NX_USHORT)0x000C)
#define EVENTCODE_SYNC_CHANGE_ERR	((NX_USHORT)0x000D)
#define	EVENTCODE_1G_COMCYCLE_ERR	((NX_USHORT)0x000F)
#define	EVENTCODE_100M_COMCYCLE_ERR	((NX_USHORT)0x0010)






#endif
/*[EOF]*/
