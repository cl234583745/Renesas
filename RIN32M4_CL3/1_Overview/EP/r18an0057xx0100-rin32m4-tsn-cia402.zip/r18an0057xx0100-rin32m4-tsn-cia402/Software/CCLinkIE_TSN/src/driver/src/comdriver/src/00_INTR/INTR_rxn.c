/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_rxn.h"
#include "TOOL_api.h"
#include "INTR_api.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "INTR_common.h"



NX_VOID vINTR_CycRcvP01 (NX_VOID);
NX_VOID vINTR_CycRcvP02 (NX_VOID);

NX_STATIC INTFUNCDATA gstIntHighRxnFuncList[] ={
	{TABLE_END,	NULL}                   
};

NX_STATIC INTFUNCDATA gstIntLowRxnFuncList[] ={
	{TABLE_END,	NULL},
};

NX_ULONG gulIntRxnErrCount = 0;
NX_ULONG gulIntRxnCount = 0;




NX_VOID vINTR_IntErrRx (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	ulFactorInt = NGN_RN->R_RNINTE.DATA;
	ulFactorIntMask = NGN_RN->R_RNINTEM.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	gulIntRxnErrCount |= ulFactorIntWork;
	NGN_RN->R_RNINTE.DATA = ulFactorIntWork;
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntHighRxnFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntHighRxnFuncList[usCount].ulBitNo) {
			gstIntHighRxnFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntHighRxnFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_VOID vINTR_IntLowRx (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	ulFactorInt = NGN_RN->R_RNINT.DATA;
	ulFactorIntMask = NGN_RN->R_RNINTM.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	gulIntRxnCount |= ulFactorIntWork;
	NGN_RN->R_RNINT.DATA = ulFactorIntWork;
	vNX_vEnableDispatch();
	
	for (usCount = NX_ZERO; gstIntLowRxnFuncList[usCount].ulBitNo != TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntLowRxnFuncList[usCount].ulBitNo) {
			gstIntLowRxnFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntLowRxnFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_ULONG ulINTR_CheckIntLowRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_RN->R_RNINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntLowRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_RN->R_RNINT.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntRxnCount |= ulCountTarget;
	}
	NGN_RN->R_RNINT.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntLowRx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLow_RxMask;
	vNX_vDisableDispatch();
	ulLow_RxMask = NGN_RN->R_RNINTM.DATA;
	NGN_RN->R_RNINTM.DATA = ulLow_RxMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntLowRx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLow_RxMask;
	
	vNX_vDisableDispatch();
	ulLow_RxMask = NGN_RN->R_RNINTM.DATA;
	NGN_RN->R_RNINTM.DATA = ulLow_RxMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_ULONG ulINTR_CheckIntHighRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_RN->R_RNINTE.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntHighRx (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_RN->R_RNINTE.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntRxnErrCount |= ulCountTarget;
	}
	NGN_RN->R_RNINTE.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntHighRx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHigh_RXMask;
	vNX_vDisableDispatch();
	ulHigh_RXMask = NGN_RN->R_RNINTEM.DATA;
	NGN_RN->R_RNINTEM.DATA = ulHigh_RXMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntHighRx (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHigh_RXMask;
	
	vNX_vDisableDispatch();
	ulHigh_RXMask = NGN_RN->R_RNINTEM.DATA;
	NGN_RN->R_RNINTEM.DATA = ulHigh_RXMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}


