/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNM_get_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNR_sv_l.h"
#include "ST_SNP_sv_l.h"
#include "ST_SNW_sv_l.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_mmng_sv_l.h"

#include <Windows.h>
#include <process.h>
#include <snmp.h>
#include <tchar.h>
#include "ST_SNM_extmib_sv_l.h"

#include "ST_SNC_debug_com_l.h"
#ifdef SNC_DEBUG
#define DBG_FILE_NAME	"C:\\Users\\UT01412\\Documents\\SNMP_SERVICE.log"
#endif
#else
#include <common.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_sync_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNP/inc/ST_SNP_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNP_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif
#ifdef SWPS
#define ST_SNM_SNMPV1					0x00
#define ST_SNM_SNMPV2C					0x01
#define ST_SNM_MAX_AGENT_MESSAGE_SIZE	1500

typedef enum {
	ST_SNM_THRD_SNR,
	ST_SNM_THRD_SNP,
	ST_SNM_THRD_SNW,
	ST_SNM_THRD_MAX,
} ST_SNM_Thrdkind;

typedef struct ST_SNM_ThrdCntl_TAG {
	HANDLE		hHandle;
	unsigned	(WINAPI *pfunc)(NX_VOID* pvHandle);
} ST_SNM_ThrdCntl;
#endif

#ifdef SWPS
static unsigned WINAPI unST_SNM_RequestStanbyThrStart(NX_VOID* pvHandle);
static unsigned WINAPI unST_SNM_RequestExecuteThrStart(NX_VOID* pvHandle);
static unsigned WINAPI unST_SNM_AliveMonitorThrStart(NX_VOID* pvHandle);
#endif
#ifdef SWPS
static NX_ULONG ulST_SNM_Start(NX_VOID);
static NX_ULONG ulST_SNM_Stop(NX_VOID);
static NX_ULONG ulST_SNM_StationObjLock(NX_VOID);
static NX_ULONG ulST_SNM_StationObjUnlock(NX_VOID);
#endif


#ifdef SWPS
HANDLE	ghST_SNM_ThrdEndEvt = NX_NULL;
ST_SNM_ThrdCntl gastST_SHM_ThrdTbl[ST_SNM_THRD_MAX] = {
	{ NX_NULL, unST_SNM_RequestStanbyThrStart	},
	{ NX_NULL, unST_SNM_RequestExecuteThrStart	},
	{ NX_NULL, unST_SNM_AliveMonitorThrStart	},
};
#endif


#ifdef SWPS
static unsigned WINAPI unST_SNM_RequestStanbyThrStart(
	NX_VOID*	pvHandle
)
{
	ST_SNR_RequestStanbyThr(pvHandle);
	return 0;
}

static unsigned WINAPI unST_SNM_RequestExecuteThrStart(
	NX_VOID*	pvHandle
)
{
	ST_SNP_RequestExecuteThr(pvHandle);
	return 0;
}

static unsigned WINAPI unST_SNM_AliveMonitorThrStart(
	NX_VOID*	pvHandle
)
{
	ST_SNW_AliveMonitorThr(pvHandle);
	return 0;
}
#endif


#ifdef SWPS
static NX_ULONG ulST_SNM_Start(NX_VOID)
#else
NX_ULONG ulST_SNM_Start(NX_VOID)
#endif
{
#ifdef SWPS
	SECURITY_DESCRIPTOR		stDesc;
	SECURITY_ATTRIBUTES		stAttr;
#endif
	NX_ULONG					ulRet	= ST_SNC_OK;
#ifdef SWPS
	DWORD					dwError	= 0;
#endif
	NX_UCHAR					uchClass = 0;
#ifdef SWPS
	NX_UCHAR					uchThrdCount = 0;
#endif

#ifdef SWPS
	DBGTRACE("%s", __FUNCTION__);
	ST_SNC_SetSecAttr(&stDesc, &stAttr);
	ghST_SNM_ThrdEndEvt = CreateEvent(&stAttr, TRUE, FALSE, NX_NULL);
	if(NX_NULL == ghST_SNM_ThrdEndEvt){

		dwError = GetLastError();
		DBGTRACE("%s CreateEvent error (error=%d)", __FUNCTION__, dwError);
		ulRet = ST_SNC_NG_CREATE_EVENT;

	}
	else {
#endif

		ulRet = ulST_SNC_MibAlloc();
		if(ST_SNC_OK == ulRet) {

			for(uchClass=ST_SNM_MIBCLASS_EXT; uchClass<ST_SNM_MIBCLASS_MAX; uchClass++) {
				ulRet = ulST_SNM_GetAddr(uchClass);
				if(ST_SNC_OK != ulRet){
					DBGTRACE("%s ulST_SNM_GetAddr error (error=%d)", __FUNCTION__, ulRet);
					break;
				}
				else {
					;
				}
			}

#ifdef SWPS
			if(ST_SNC_OK == ulRet) {

				for(uchThrdCount=0; uchThrdCount<ST_SNM_THRD_MAX; uchThrdCount++ ) {

					gastST_SHM_ThrdTbl[uchThrdCount].hHandle = 
						(HANDLE)_beginthreadex(
							&stAttr,
							0,
							gastST_SHM_ThrdTbl[uchThrdCount].pfunc,
							ghST_SNM_ThrdEndEvt,
							0,
							NX_NULL);

					if(NX_NULL == gastST_SHM_ThrdTbl[uchThrdCount].hHandle) {

						DBGTRACE("request stanby thread_%d failed = %d", uchThrdCount, errno);
						ulRet = ST_SNC_NG_BEGINTHREAD;
						break;

					}
					else {
						;
					}
				}
			}
			else {
				;
			}
#endif
		}
		else {
			;
		}
#ifdef SWPS
	}
#endif

	if(ST_SNC_OK != ulRet) {
		ulST_SNM_Stop();
	}
	else {
		;
	}


	return  ulRet;
}

#ifdef SWPS
static NX_ULONG ulST_SNM_Stop(NX_VOID)
#else
NX_ULONG ulST_SNM_Stop(NX_VOID)
#endif
{
#ifdef SWPS
	HANDLE			ahHandle[ST_SNM_THRD_MAX];
#endif
	NX_ULONG			ulRet		= ST_SNC_OK;
#ifdef SWPS
	DWORD			dwObjs		= 0;
	DWORD			dwError		= 0;
	NX_ULONG			bRc			= TRUE;
	NX_UCHAR			ucCount		= 0;
	NX_UCHAR			ucHandle	= 0;
#endif

#ifdef SWPS
	DBGTRACE("%s", __FUNCTION__);
	if(NX_NULL != ghST_SNM_ThrdEndEvt) {

		bRc = SetEvent(ghST_SNM_ThrdEndEvt);
		if(TRUE == bRc) {
			
			DBGTRACE("%s SetEvent(%x)",__FUNCTION__, ghST_SNM_ThrdEndEvt);

			for(ucCount=0; ucCount<ST_SNM_THRD_MAX; ucCount++) {
				if(NX_NULL != gastST_SHM_ThrdTbl[ucCount].hHandle) {
					ahHandle[ucCount] = gastST_SHM_ThrdTbl[ucCount].hHandle;
					ucHandle++;
				}
				else {
					;
				}
			}

			if(0 < ucHandle) {

				DBGTRACE("%s --> WaitForMultipleObjects",__FUNCTION__);
				dwObjs = WaitForMultipleObjects(
							ucHandle,
							ahHandle,
							TRUE,
							INFINITE
							) - WAIT_OBJECT_0;
				DBGTRACE("%s <-- WaitForMultipleObjects(%d)",__FUNCTION__, dwObjs);
				if(dwObjs < ucHandle )	{

					for(ucCount=0; ucCount<ST_SNM_THRD_MAX; ucCount++) {

						if (NX_NULL != gastST_SHM_ThrdTbl[ucCount].hHandle) {
							CloseHandle(gastST_SHM_ThrdTbl[ucCount].hHandle);
						}
						else {
							;
						}
					}
#endif

					DBGTRACE("%s  --> ulST_SNC_MibAllClear",__FUNCTION__);
					ulRet = ulST_SNC_MibAllClear();
					DBGTRACE("%s  <-- ulST_SNC_MibAllClear(0x%x)",__FUNCTION__, ulRet);
					if(ST_SNC_OK == ulRet) {
						ulRet = ulST_SNC_MibFree();
					}
					else {
#ifdef SWPS
						DBGTRACE("%s(%d) failed rc=%d rs=%d",__FUNCTION__, __LINE__, ulRet, dwError);
#endif
						ulST_SNC_MibFree();
					}
#ifdef SWPS
				}
				else {
					dwError = GetLastError();
					ulRet = ST_SNC_NG_EVENT_WAIT;
				}

			}
			else {
			}

			CloseHandle(ghST_SNM_ThrdEndEvt);
			ghST_SNM_ThrdEndEvt = NX_NULL;

		}
		else {
			ulRet = ST_SNC_NG_SET_EVENT;
		}
	}
	else {
		ulRet = ST_SNC_NG_SEQUENCE;
	}

	if(ST_SNC_OK != ulRet) {
		DBGTRACE("%s(%d) failed rc=%d rs=%d",__FUNCTION__, __LINE__, ulRet, dwError);
	}
	else {
		;
	}

	DBGTRACE("%s END", __FUNCTION__);
	DBGTRACECLOSE();
#endif

	return ulRet;
}


#ifdef SWPS
static NX_ULONG ulST_SNM_StationObjLock(NX_VOID)
{
	return ulST_SNC_StationObjLock(ST_SNC_MIBTYPE_NWCFG, TRUE);
}


static NX_ULONG ulST_SNM_StationObjUnlock(NX_VOID)
{
	return ulST_SNC_StationObjUnlock(ST_SNC_MIBTYPE_NWCFG,TRUE);
}
#endif

#ifdef SWPS
NX_ULONG WINAPI DLLMain(
	HINSTANCE	hinstDLL,
	DWORD		fdwReason,
	LPVOID		lpvReserved
)
{
	switch(fdwReason){
	case DLL_PROCESS_ATTACH:
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	default:
		break;
	}
	return TRUE;
}
#endif



#ifdef SWPS
NX_ULONG SNMP_FUNC_TYPE SnmpExtensionInit(
		DWORD					dwUptimeReference,
		HANDLE*					phSubagentTrapEvent,
		AsnObjectIdentifier*	pFirstSupportedRegion
)
{
	NX_ULONG	ulRet			  = ST_SNC_OK;
	NX_ULONG	bRc				  = TRUE;

	DBGTRACEOPEN(_TEXT(DBG_FILE_NAME), NX_NULL);
	DBGTRACE("%s", __FUNCTION__);

	ulRet = ulST_SNM_Start();
	if(ST_SNC_OK == ulRet) {

		*phSubagentTrapEvent = NX_NULL;

		ST_SNM_ExtMib_GetAsnPrefix(pFirstSupportedRegion, TRUE);

	}
	else {
		bRc = FALSE;
	}

	return bRc;
}



NX_ULONG SNMP_FUNC_TYPE SnmpExtensionInitEx(
		AsnObjectIdentifier*	pNextSupportedRegion
)
{
	static NX_ULONG	bParamInit	= FALSE;

	DBGTRACE("%s START(%d)", __FUNCTION__, bParamInit);

	DBGTRACE("%s END(%d)", __FUNCTION__, bParamInit);
	return bParamInit;
}
#endif


#ifdef SWPS
NX_ULONG SNMP_FUNC_TYPE SnmpExtensionQueryEx(
	NX_ULONG				dwRequestType,
	NX_ULONG				dwTransactionId,
	SnmpVarBindList*	pVarBindList,
	AsnOctetString*		pContextInfo,
	AsnInteger32*		pErrorStatus,
	AsnInteger32*		pErrorIndex
)
{
	ST_SNM_MibTblSet*	pstTblSet;
	SnmpVarBind*		pVarBind = NX_NULL;
	NX_LONG 				lCnt = 0;
	NX_ULONG				uiMessageSize = 0;
	int					iRc = ST_SNM_OK;
	NX_ULONG				ulRet = ST_SNC_OK;
	NX_ULONG				bRc = TRUE;
	NX_ULONG				bLock = FALSE;

	DBGTRACE("%s [PDU=%d]", __FUNCTION__, dwRequestType);



	*pErrorStatus = SNMP_ERRORSTATUS_NOERROR;

	for(lCnt=0; (NX_ULONG)lCnt<pVarBindList->len; lCnt++) {
		bRc = bST_SNM_CheckStationUnitLock(&pVarBindList->list[lCnt], dwRequestType);
		if(TRUE == bRc) {
			ulRet = ulST_SNM_StationObjLock();
			if(ST_SNC_OK == ulRet) {
				bLock = TRUE;
			}
			else {
				*pErrorStatus = SNMP_ERRORSTATUS_GENERR;
			}
			break;
		}
		else {
			;
		}
	}

	if(SNMP_ERRORSTATUS_NOERROR == *pErrorStatus) {

		for(lCnt=0; (NX_ULONG)lCnt<pVarBindList->len; lCnt++) {

			pVarBind = &pVarBindList->list[lCnt];
			ulRet = ulST_SNM_SelectTblSet(&pVarBind->name, &pstTblSet);
			if(ST_SNC_OK != ulRet) {
				*pErrorStatus = SNMP_ERRORSTATUS_NOSUCHNAME;
			}
			else {
				;
			}

			if(SNMP_ERRORSTATUS_NOSUCHNAME != *pErrorStatus) {

				switch(dwRequestType) {
				case SNMP_EXTENSION_GET:
					*pErrorStatus = lST_SNM_GetRequest_SNMPv2c(pVarBind, pstTblSet);
					if(SNMP_ERRORSTATUS_NOERROR != *pErrorStatus) {
						*pErrorIndex = lCnt;
					}
					else {
						;
					}
					break;
				case SNMP_EXTENSION_GET_NEXT:
					*pErrorStatus = lST_SNM_GetNextRequest_SNMPv2c(pVarBind, pstTblSet);
					if(SNMP_ERRORSTATUS_NOERROR != *pErrorStatus){
						*pErrorIndex = lCnt;
					}
					else {
						;
					}
					break;
				default:
					*pErrorStatus = SNMP_ERRORSTATUS_GENERR;
					*pErrorIndex = lCnt;
				};

				if(SNMP_ERRORSTATUS_NOERROR != *pErrorStatus) {
					break;
				}
				else {
					;
				}
			}
			else {
				;
			}
		}
	}
	else {
		;
	}

	if(SNMP_ERRORSTATUS_NOERROR == *pErrorStatus) {
		iRc = nST_SNM_CalcEncodeGetResponseLen(pVarBindList->list, pVarBindList->len, &uiMessageSize);
		if(ST_SNM_OK == iRc) {
			if(ST_SNM_MAX_AGENT_MESSAGE_SIZE < uiMessageSize) {
				*pErrorStatus = SNMP_ERRORSTATUS_TOOBIG;
			}
			else {
				;
			}
		}
		else {
			*pErrorStatus = SNMP_ERRORSTATUS_GENERR;
		}
	}
	else if(SNMP_ERRORSTATUS_NOSUCHNAME == *pErrorStatus ){


	}
	else {
		;
	}

	if(TRUE == bLock){
		ulST_SNM_StationObjUnlock();
	}
	else {
		;
	}



	DBGTRACE("%s END(%d:%d:%d)", __FUNCTION__, dwRequestType, *pErrorStatus, *pErrorIndex);
	return SNMPAPI_NOERROR;
}


void SNMP_FUNC_TYPE SnmpExtensionClose(void)
{
	ulST_SNM_Stop();
}
#endif
