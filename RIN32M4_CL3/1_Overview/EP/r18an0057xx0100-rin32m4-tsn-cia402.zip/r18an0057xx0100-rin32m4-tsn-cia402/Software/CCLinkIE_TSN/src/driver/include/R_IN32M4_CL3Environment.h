/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3ENVIRONMENT_H__
#define __R_IN32M4_CL3ENVIRONMENT_H__

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/

#ifdef __GNUC__
/* For the GNU compiler */
#define ALIGN_4_DIRECTION			__attribute__((aligned (4)))
#define ALIGN_2_DIRECTION			__attribute__((aligned (2)))
#define PACKED_DIRECTION			__attribute__((packed))
#define NONCYC_RX_DATA_P1			__attribute__((section("noncyc_rx_data_p1")))
#define NONCYC_RX_DATA_P2			__attribute__((section("noncyc_rx_data_p2")))
#define NONCYC_TX_HEADER_L			__attribute__((section("noncyc_tx_header_l")))
#define NONCYC_TX_HEADER_S			__attribute__((section("noncyc_tx_header_s")))
#define NONCYC_TX_HEADER_SYNC_L		__attribute__((section("noncyc_tx_header_sync_l")))
#define NONCYC_TX_HEADER_SYNC_S		__attribute__((section("noncyc_tx_header_sync_s")))
#define NONCYC_TX_DATA_L			__attribute__((section("noncyc_tx_data_l")))
#define NONCYC_TX_DATA_S			__attribute__((section("noncyc_tx_data_s")))
#define NONCYC_TX_DATA_SYNC_L		__attribute__((section("noncyc_tx_data_sync_l")))
#define NONCYC_TX_DATA_SYNC_S		__attribute__((section("noncyc_tx_data_sync_s")))

#else  /* __GNUC__ */
/* For non-GNU compilers */
#ifdef __ICCARM__
#define ALIGN_4_DIRECTION			_Pragma("data_alignment = 4")
#define ALIGN_2_DIRECTION			_Pragma("data_alignment = 2")
#define NONCYC_RX_DATA_P1			_Pragma("location=\"noncyc_rx_data_p1\"")
#define NONCYC_RX_DATA_P2			_Pragma("location=\"noncyc_rx_data_p2\"")
#define NONCYC_TX_HEADER_L			_Pragma("location=\"noncyc_tx_header_l\"")
#define NONCYC_TX_HEADER_S			_Pragma("location=\"noncyc_tx_header_s\"")
#define NONCYC_TX_HEADER_SYNC_L		_Pragma("location=\"noncyc_tx_header_sync_l\"")
#define NONCYC_TX_HEADER_SYNC_S		_Pragma("location=\"noncyc_tx_header_sync_s\"")
#define NONCYC_TX_DATA_L			_Pragma("location=\"noncyc_tx_data_l\"")
#define NONCYC_TX_DATA_S			_Pragma("location=\"noncyc_tx_data_s\"")
#define NONCYC_TX_DATA_SYNC_L		_Pragma("location=\"noncyc_tx_data_sync_l\"")
#define NONCYC_TX_DATA_SYNC_S		_Pragma("location=\"noncyc_tx_data_sync_s\"")
#else
#define ALIGN_DIRECTION(a)
#define PACKED_DIRECTION
#endif

#endif
#endif

/*** EOF ***/
