/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include <math.h>
#include "PTP_GlobalData.h"
#include "ptp_CommonFunction.h"
#include "nx_common.h"
#include "ptp_api.h"
#include "ptp_api_management.h"
#include "mdtransinterface.h"
#include "ptp_GetDetailCurrentTime.h"
#include "ptp_tick.h"
#include "ptp_ClockSource_API.h"
#include "ptpwrap_Type.h"
#include "ptpwrap_Proto.h"
#include "ptpwrap_Global.h"
#include "RXN_api.h"
#include "TOOL_api.h"
#include "NMG_api.h"
#include "NMG_common.h"
#include "kernel.h"
#include "NGN_ASIC.h"
#include "ptp_managementid_as.h"
#include "ptp_managementid_1588.h"
#include "ccienx_task.h"
#include "ccienx_api.h"
#include "tsn.h"
#include "tsn_common.h"					
#include "TSN_api.h"
#include "TXN_api.h"
#include "LSM_api.h"
#include "PTP_Message.h"
#include "CYC_api.h"
#include "nx_frame_sync.h"
#if TSN_LOG_FRAME
#include "LOG_api.h"
#endif

#define	PTP_PORT_NUM	NX_PORT_SIZE
#define	TH_TSNRUN_FOLLOWUPTIMES		(4)


#define	PTP_GET_PRM_SIZE	(5)
#define	PTP_GET_PRM_VALID	(0)
#define	PTP_GET_PRM_INVALID	(1)

#define TSN_CLOSE		(0)
#define TSN_OPEN		(1)
#define SigMsg_NoUse	(TRUE)
#define ONE_STEP_POSSIBLE (TRUE)

#define PRIORITY_TSN_MIN (15)

#define	GMTIME_NS			((NX_ULONG)0)
#define	GMTIME_SEC			((NX_ULONG)4)
#define	GMTIME_SIZE_NS		((NX_ULONG)4)
#define	GMTIME_SIZE_SEC		((NX_ULONG)6)
#define	MASK_NS				((NX_ULONG)0xFFFFFFF8)
#define	MASK_S				((NX_ULONGLONG)0x00000000FFFFFFFF)


#define	TSN_ADD_TMING_THRESHOLD		((NX_ULONGLONG)2000000)
#define	TSN_ADD_TMING_BASELINE		((NX_ULONGLONG)5000000)


#define	OFFSET_BORDER_TIMESLOT_PTP_18US		((NX_LONGLONG)18000)
#define	OFFSET_BORDER_TIMESLOT_PTP_3US		((NX_LONGLONG)3000)

#define	OFFSET_MARGIN_TIMESLOT_PTP_18US		((NX_LONGLONG)5000)
#define	OFFSET_MARGIN_TIMESLOT_PTP_3US		((NX_LONGLONG)500)


#define	TSN_ADJ_TS_NUM				((NX_UCHAR)2)
#define	PTP_MSGNUM_TIMECHECK		(PTP_MSGTYPE_PDELAY_REQ + 1)
#define	PTP_MSGTYPE_SYNC			((NX_UCHAR)0x00)
#define	PTP_MSGTYPE_DELAY_REQ		((NX_UCHAR)0x01)
#define	PTP_MSGTYPE_PDELAY_REQ		((NX_UCHAR)0x02)
#define	PTP_MSGTYPE_PDELAY_RESP		((NX_UCHAR)0x03)
#define	PTP_MSGTYPE_FOLLOWUP		((NX_UCHAR)0x08)
#define	PTP_MSGTYPE_DELAY_RESP		((NX_UCHAR)0x09)
#define	PTP_MSGTYPE_PDELAY_RES_FUP	((NX_UCHAR)0x0A)
#define	PTP_MSGTYPE_ANNOUNCE		((NX_UCHAR)0x0B)
#define	PTP_MSGTYPE_SIGNALING		((NX_UCHAR)0x0C)
#define	PTP_MSGTYPE_MANAGEMENT		((NX_UCHAR)0x0D)

#define	MULTI_DOMAIN_VALUE			((NX_UCHAR)0x80)

#define	SYNCSEND_HOLDTIME			((NX_LONG)1000)
#define	LOG_GPTPCAPABLE_MSG_INT		((NX_CHAR)0)
#define	DREQSEND_HOLDTIME			((NX_LONG)1000)
#define	DELAYRESP_TIMEOUT			((NX_LONG)500000)

#define OFFSET_STABLE_TIME_SINGLE			(3)
#define OFFSET_STABLE_TIME_MULTI			(6)
#define DOMAIN_NUMBER_0						(0)
#define	PRIORITY_TSN_MAX			(255)
#define	CLOCKCLASS_MAX				(255)
#define	TIME_MASTER_SLAVE_CONF_0	(0)
#define	TIME_MASTER_SLAVE_CONF_1	(1)
#define	TIME_MASTER_SLAVE_CONF_2	(2)
#define	AVERAGE_RESET_TIMEOUT		(3)
typedef struct PTP_GET_PRM_T {
	ULONG	ulValid;
	ULONG	ulPrmId;
	ULONG	ulPort;
	ULONG	ulSize;
} PTP_GET_PRM;

typedef struct tagPTPCONFIG_IEEE {
	CLOCKKNDINF		stClockKndInfo;
	IEEE1588_L2		stTransAdrInfo;
	MACADDR			stMacAddr[PTP_PORT_NUM];
	CLOCKASINFSET	astClockInfoAS[MAX_DOMAIN];
	PORTASINFSET	astPortInfoAS[MAX_DOMAIN][PTP_PORT_NUM];
	CLOCKINFSET		astClockInfo1588[MAX_DOMAIN];
	PORTINFSET		astPortInfo1588[MAX_DOMAIN][PTP_PORT_NUM];
	ULONG			ulME_extend;
} PTPCONFIG_IEEE;

PTPCONFIG_IEEE		gstPtpConf;
PTPINFSET			gstPtpInfSet;
CLKSOURCEINFO		gstClockSourceInfo;
CLKSOURCETIME		gstClockSourceTime;
NCF_TSN_INFO gstNcfTsnInf;

NCYC_TX_FRAME	*gpstTestFrame;

NX_CONST	PTP_GET_PRM	gstPtpGetPrm[PTP_GET_PRM_SIZE] = {
	{PTP_GET_PRM_VALID,		MID_PORTDS_PORTSTAT,		1,	1},
	{PTP_GET_PRM_VALID,		MID_PORTDS_PORTSTAT,		2,	1},
	{PTP_GET_PRM_VALID,		MID_PARENTDS_GMPRIORITY1,	0,	1},
	{PTP_GET_PRM_VALID,		MID_PARENTDS_GRANDMASTERID,	0,	sizeof(CLOCKIDENTITY)},
	{PTP_GET_PRM_INVALID,	MID_PARENTDS_GMPRIORITY1 ,	0,	0}
};
TSN_CTRL	gastTsnCtrl[2];

NX_STATIC	NX_UNIX_TIME_KEEP	gastTimerCounter[TSN_TIMCNT_SIZE];
NX_EXTERN	NX_ULONG			gulOutOfTimeSyncSts;

const NX_ULONG gaulTSN_LeapSecondTable[] = 
{
	1483228837, 1435708836, 1341100835, 1230768034, 1136073633, 915148832, 867715231,
	820454430, 773020829, 741484828, 709948827, 662688026, 631152025, 567993624,
	489024023, 425865622, 394329621, 362793620, 315532819, 283996818, 252460817,
	220924816, 189302415, 157766414, 126230413, 94694412, 78796811, 63072010
};

const NX_SHORT gasTSN_LeapOffsetTable[] = 
{
	37, 36, 35, 34, 33, 32, 31,
	30, 29, 28, 27, 26, 25, 24,
	23, 22, 21, 20, 19, 18, 17,
	16, 15, 14, 13, 12, 11, 10
};

EXTENDEDTIMESTAMP gstRcvTimeLast[NX_PORT_SIZE][PTP_MSGNUM_TIMECHECK][2];

NX_VOID	vTsn_InitClock (NCF_TSN_INFO* pstNcfTsn);
NX_VOID	vTsn_SetPtpInfAS (NCF_TSN_INFO *pstNcfTsn);
NX_VOID	vTsn_SetPtpInf1588 (NCF_TSN_INFO *pstNcfTsn);
NX_VOID vTsn_Stop(NX_VOID);

NX_SHORT sTSN_ConvTimetoUtcOffset(NX_ULONG ullUnixTime);

NX_VOID vTsn_Refresh_SndTimeStamp(NX_VOID);
NX_VOID vTsn_Refresh_RcvTimeStamp(NX_VOID);

NX_VOID	vTsn_SetGlobal100M (NX_VOID);
NX_VOID	vTsn_GetAdjCycTime100M (NX_ULONGLONG, NX_ULONGLONG, NX_ULONGLONG*, NX_ULONGLONG*);
NX_VOID	vTsn_GetAdjRange100M (NX_ULONGLONG, NX_ULONGLONG, NX_ULONGLONG, NX_ULONGLONG, NX_ULONGLONG*, NX_ULONGLONG* );

NX_ULONG ulTsn_CheckRcvTime ( NX_UCHAR, NX_UCHAR, EXTENDEDTIMESTAMP* );
NX_ULONG ulTsn_RefreshTime  ( EXTENDEDTIMESTAMP*, EXTENDEDTIMESTAMP* );

NX_VOID vTsn_UpdateOutOfTimeSyncStatus (NX_UCHAR);


NX_VOID	vTsn_SetPtpInf (
	NCF_TSN_INFO	*pstNcfTsn
)
{
	gstNcfTsnInf = *pstNcfTsn;
	NX_UCHAR uchPtpProto;
	NX_UCHAR uchDomainNo;
	NX_USHORT usPortIndex;
	uchPtpProto = pstNcfTsn->uchTimeSynchronizationMethod;
	uchDomainNo  = pstNcfTsn->uchDomainNo;
	
	if (uchDomainNo == MULTI_DOMAIN_VALUE) {
		gstPtpConf.stClockKndInfo.uchDomainNum	=	NX_TWO;
		gstTsnStatusMng.uchDomainStatus			=	MULTI_DOMAIN;
		gstTsnStatusMng.ulOffsetStabletime		=	OFFSET_STABLE_TIME_MULTI;
	}
	else {
		gstPtpConf.stClockKndInfo.uchDomainNum	=	NX_ONE;
		gstTsnStatusMng.uchDomainStatus			=	SINGLE_DOMAIN;
		gstTsnStatusMng.ulOffsetStabletime		=	OFFSET_STABLE_TIME_SINGLE;
	}
	
	if(uchPtpProto == TSN_IEEE1588){
		vNX_vDisableDispatch();
		vNX_vDisableInterrupt();
		NGN_CN_REG->R_REIPSET.BITS.b01ZTimeSyncMode		=	1;
		
		vNX_vEnableInterrupt();
		vNX_vEnableDispatch();
		gstPtpCtrl.uchPtpProto							=	0;
		gstPtpConf.stClockKndInfo.enClockPtpProtcol		=	PROTOCOL_IEEE1588;
		gstPtpConf.stClockKndInfo.enClockTrpProtocol	=	CLK_TRANS_IEEE1588_L2;
		vTsn_SetPtpInf1588(pstNcfTsn);
		gstPtpConf.ulME_extend =	(ULONG)( USE_ME_EXTEND_1588_STR_MASTER
											|USE_ME_EXTEND_1588_SYNC_LOCKED
											|USE_ME_EXTEND_1588_DREQ		);
		
	}else if(uchPtpProto == TSN_IEEE802_1_AS){
		
		vNX_vDisableDispatch();
		vNX_vDisableInterrupt();
		NGN_CN_REG->R_REIPSET.BITS.b01ZTimeSyncMode		=	0;
		vNX_vEnableInterrupt();
		vNX_vEnableDispatch();
		gstPtpCtrl.uchPtpProto							=	1;
		gstPtpConf.stClockKndInfo.enClockPtpProtcol		=	PROTOCOL_IEEE802_1_AS;
		gstPtpConf.stClockKndInfo.enClockTrpProtocol	=	CLK_TRANS_IEEE802_1_AS;
		vTsn_SetPtpInfAS(pstNcfTsn);
		gstPtpConf.ulME_extend = (ULONG)(USE_ME_EXTEND_AS_GPTP_CAPABLE_1);
	}
	gstPtpConf.stClockKndInfo.enClockKind				=	CLK_KIND_BOUND_ORDI;
	gstPtpConf.stClockKndInfo.uchInterfaceNum			=	PTP_PORT_NUM;

	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[0] = gstAppInfo.stEthInfo.auchMacAddress[0];
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[1] = gstAppInfo.stEthInfo.auchMacAddress[1];
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[2] = gstAppInfo.stEthInfo.auchMacAddress[2];
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[3] = 0xFF;
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[4] = 0xFE;
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[5] = gstAppInfo.stEthInfo.auchMacAddress[3];
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[6] = gstAppInfo.stEthInfo.auchMacAddress[4];
	gstPtpConf.stClockKndInfo.stClockIdentity.uchId[7] = gstAppInfo.stEthInfo.auchMacAddress[5];
	
	for (usPortIndex = (NX_USHORT)NX_ZERO; usPortIndex < (NX_USHORT)PTP_PORT_NUM; usPortIndex++) {
		vNX_CopyMemory(	&(gstPtpConf.stMacAddr[usPortIndex].uchMac[0]),
						gstAppInfo.stEthInfo.auchMacAddress,
						NX_MAC_ADDR_SIZE
						);
	}
	
	gstPtpConf.stTransAdrInfo.pstMacAdd = 	&(gstPtpConf.stMacAddr[NX_ZERO]);		
	
	return;
}

NX_VOID	vTsn_SetPtpInfAS (
	NCF_TSN_INFO	*pstNcfTsn
)
{
	NX_USHORT usDomainIndex = 0;
	NX_USHORT usPortIndex = 0;
	USCALEDNS stAveDelayTrash_Local;
	NX_USHORT		usDomainNum		=	NX_ONE;
	PORTASINFSET*	pstPtpConf;
	NX_LONG lResult_Priority = (NX_LONG)NX_ZERO;
	NX_UCHAR uchClockClass = (NX_UCHAR)NX_ZERO;
	NX_UCHAR uchPriority1  = (NX_UCHAR)NX_ZERO;
	NX_UCHAR uchPriority2  = (NX_UCHAR)NX_ZERO;
	BOOL	 blGmCapable   = (BOOL)NX_ZERO;
	stAveDelayTrash_Local.usNsec_msb = (NX_USHORT) NX_ZERO;
	stAveDelayTrash_Local.ulNsec_2nd = NX_ZERO;
	stAveDelayTrash_Local.ulNsec_lsb = 3000;
	stAveDelayTrash_Local.usFrcNsec = (NX_USHORT) NX_ZERO;
	

	if (gstTsnStatusMng.uchDomainStatus == SINGLE_DOMAIN) {
		usDomainNum	=	NX_ONE;
	}
	else {
		usDomainNum	=	NX_TWO;
	}
		



	lResult_Priority = lNX_CompareMemory(pstNcfTsn->auchGrandMasterClockIdentity,gstPtpConf.stClockKndInfo.stClockIdentity.uchId, sizeof(NX_UCHAR[8]));	
		
	if ((pstNcfTsn->uchTimeMasterSlaveConf == TIME_MASTER_SLAVE_CONF_1)
	|| ((pstNcfTsn->uchTimeMasterSlaveConf == TIME_MASTER_SLAVE_CONF_2) && (lResult_Priority != NX_OK))) {
		uchClockClass	=	CLOCKCLASS_MAX;
		uchPriority1	=	PRIORITY_TSN_MAX;
		uchPriority2	=	PRIORITY_TSN_MAX;
		blGmCapable		=	FALSE;
	}
	else if ((pstNcfTsn->uchTimeMasterSlaveConf == TIME_MASTER_SLAVE_CONF_2) && (lResult_Priority == NX_OK)) {
		uchClockClass	=	gstAppInfo.stPtpInfo.stClockQuality.mbr.uchClockClass;
		uchPriority1	=	PRIORITY_TSN_MIN;
		uchPriority2	=	PRIORITY_TSN_MIN;
		blGmCapable		=	TRUE;
	}
	else {
		uchClockClass	=	gstAppInfo.stPtpInfo.stClockQuality.mbr.uchClockClass;
		if (lResult_Priority == NX_OK) {
			uchPriority1	=	PRIORITY_TSN_MIN;
			uchPriority2	=	PRIORITY_TSN_MIN;
		}
		else {
			uchPriority1	=	gstAppInfo.stPtpInfo.uchPriority1;
			uchPriority2	=	gstAppInfo.stPtpInfo.uchPriority2;
		}
		blGmCapable			=	TRUE;
	}
	for (usDomainIndex = 0; usDomainIndex < usDomainNum; usDomainIndex++) {
		gstPtpConf.astClockInfoAS[usDomainIndex].stClockQuality.uchClockClass				=	uchClockClass;
		gstPtpConf.astClockInfoAS[usDomainIndex].stClockQuality.uchClockAccuracy			=	gstAppInfo.stPtpInfo.stClockQuality.mbr.uchClockAccuracy;
		gstPtpConf.astClockInfoAS[usDomainIndex].stClockQuality.usOffsetScaledLogVariance	=	gstAppInfo.stPtpInfo.stClockQuality.mbr.usOffsetScaledLogVariance;
		gstPtpConf.astClockInfoAS[usDomainIndex].ulSyncSendHoldTime			=	SYNCSEND_HOLDTIME;
		gstPtpConf.astClockInfoAS[usDomainIndex].uchDomainNum				=	(NX_UCHAR)usDomainIndex;
	
		gstPtpConf.astClockInfoAS[usDomainIndex].uchPriority1				=	uchPriority1;
		gstPtpConf.astClockInfoAS[usDomainIndex].uchPriority2				=	uchPriority2;
		
		gstPtpConf.astClockInfoAS[usDomainIndex].blGmCapable					=	blGmCapable;
		gstPtpConf.astClockInfoAS[usDomainIndex].blExternalPortConfiguration	=	FALSE;
		gstPtpConf.astClockInfoAS[usDomainIndex].stAveDelayTrash				=	stAveDelayTrash_Local;
		gstPtpConf.astClockInfoAS[usDomainIndex].ulSyncTransTimeout			=	(NX_ULONG)(pow((NX_DOUBLE)NX_TWO,(NX_DOUBLE)(pstNcfTsn->chSyncTransmitCycle)) * (NX_DOUBLE)(pstNcfTsn->uchSyncReceiveTimeout) * (NX_DOUBLE)(1000 * 1000));
		gstPtpConf.astClockInfoAS[usDomainIndex].uchRateCalDatNum				=	MDPDLYRATIO_STACK_N;
	}


	for (usDomainIndex = (NX_USHORT)NX_ZERO; usDomainIndex < usDomainNum; usDomainIndex++) {
		for (usPortIndex = (NX_USHORT)NX_ZERO; usPortIndex < (NX_USHORT)PTP_PORT_NUM; usPortIndex++) {
			pstPtpConf	=	&gstPtpConf.astPortInfoAS[usDomainIndex][usPortIndex];
			
			pstPtpConf->chInitialLogAnnounceInt			=	pstNcfTsn->chAnnounceTransmitCycle;
			pstPtpConf->blUseMgtSettableLogAnnounceInt	=	TRUE;
			pstPtpConf->chMgtSettableLogAnnounceInt		=	pstNcfTsn->chAnnounceTransmitCycle;
			pstPtpConf->chInitialLogSyncInt				=	pstNcfTsn->chSyncTransmitCycle;
			pstPtpConf->blUseMgtSettableLogSyncInt		=	TRUE;
			pstPtpConf->chMgtSettableLogSyncInt			=	pstNcfTsn->chSyncTransmitCycle;
			pstPtpConf->uchAnnounceReceiptTimeout		=	pstNcfTsn->uchAnnounceReceiveTimeout;
			pstPtpConf->uchSyncReceiptTimeout			=	pstNcfTsn->uchSyncReceiveTimeout;
			pstPtpConf->blOneStepTransmit				=	FALSE;
			pstPtpConf->blInitialOneStepTxOper			=	FALSE;
			pstPtpConf->blUseMgtSettableOneStepTxOper	=	TRUE;
			pstPtpConf->blMgtSettableOneStepTxOper		=	FALSE;
			pstPtpConf->chInitialLogPdelayReqInt		=	pstNcfTsn->chPropagationDelayTransmitCycle;
			pstPtpConf->blUseMgtSettableLogPdelayReqInt	=	FALSE;
			pstPtpConf->chMgtSettableLogPdelayReqInt	=	pstNcfTsn->chPropagationDelayTransmitCycle;
			pstPtpConf->usAllowedLostResponses			=	0xFFFF;
			pstPtpConf->usAllowedFaults					=	0xFFFF;
			pstPtpConf->enPortState						=	DisabledPort;
			pstPtpConf->blPortValid						=	TRUE;
			pstPtpConf->chLogGptpCapMsgInt				=	LOG_GPTPCAPABLE_MSG_INT;
			pstPtpConf->uchGptpCapReceiptTimeout		=	pstNcfTsn->uchAnnounceReceiveTimeout;

		}
	}
}

NX_VOID	vTsn_SetPtpInf1588 (
	NCF_TSN_INFO	*pstNcfTsn
)
{
	NX_USHORT usDomainIndex = 0;
	NX_USHORT usPortIndex = 0;
	USCALEDNS stAveDelayTrash_Local;
	NX_USHORT		usDomainNum		=	NX_ONE;
	PORTINFSET*		pstPtpConf;
	NX_LONG lResult_Priority = (NX_LONG)NX_ZERO;
	stAveDelayTrash_Local.usNsec_msb = (NX_USHORT) NX_ZERO;
	stAveDelayTrash_Local.ulNsec_2nd = NX_ZERO;
	stAveDelayTrash_Local.ulNsec_lsb = 3000;
	stAveDelayTrash_Local.usFrcNsec = (NX_USHORT) NX_ZERO;

	if (gstTsnStatusMng.uchDomainStatus == SINGLE_DOMAIN) {
		usDomainNum	=	NX_ONE;
	}
	else {
		usDomainNum	=	NX_TWO;
	}

	for (usDomainIndex = 0; usDomainIndex < usDomainNum; usDomainIndex++) {
		gstPtpConf.astClockInfo1588[usDomainIndex].blTwoStepFlag = TRUE;
		gstPtpConf.astClockInfo1588[usDomainIndex].stClockQuality.uchClockClass				=	gstAppInfo.stPtpInfo.stClockQuality.mbr.uchClockClass;
		gstPtpConf.astClockInfo1588[usDomainIndex].stClockQuality.uchClockAccuracy			=	gstAppInfo.stPtpInfo.stClockQuality.mbr.uchClockAccuracy;
		gstPtpConf.astClockInfo1588[usDomainIndex].stClockQuality.usOffsetScaledLogVariance	=	gstAppInfo.stPtpInfo.stClockQuality.mbr.usOffsetScaledLogVariance;
		gstPtpConf.astClockInfo1588[usDomainIndex].ulSyncSendHoldTime				=	SYNCSEND_HOLDTIME;
		gstPtpConf.astClockInfo1588[usDomainIndex].ulDReqSendHoldTime				=	DREQSEND_HOLDTIME;
		gstPtpConf.astClockInfo1588[usDomainIndex].ulDelayRespTimeout				=	DELAYRESP_TIMEOUT;
		gstPtpConf.astClockInfo1588[usDomainIndex].uchDomainNum					=	(NX_UCHAR)usDomainIndex;
		lResult_Priority = lNX_CompareMemory(pstNcfTsn->auchGrandMasterClockIdentity,gstPtpConf.stClockKndInfo.stClockIdentity.uchId, sizeof(NX_UCHAR[8]));	
		if(lResult_Priority == NX_OK){
			gstPtpConf.astClockInfo1588[usDomainIndex].uchPriority1				=	PRIORITY_TSN_MIN;
			gstPtpConf.astClockInfo1588[usDomainIndex].uchPriority2				=	PRIORITY_TSN_MIN;
		}else { 
			gstPtpConf.astClockInfo1588[usDomainIndex].uchPriority1				=	gstAppInfo.stPtpInfo.uchPriority1;
			gstPtpConf.astClockInfo1588[usDomainIndex].uchPriority2				=	gstAppInfo.stPtpInfo.uchPriority2;
		}
		
		gstPtpConf.astClockInfo1588[usDomainIndex].blSlaveOnly					=	FALSE;
		gstPtpConf.astClockInfo1588[usDomainIndex].blExternalPortConfiguration	=	FALSE;
		gstPtpConf.astClockInfo1588[usDomainIndex].stAveDelayTrash				=	stAveDelayTrash_Local;
		gstPtpConf.astClockInfo1588[usDomainIndex].uchRateCalDatNum				=	MDSYCR_STACK_N;
		gstPtpConf.astClockInfo1588[usDomainIndex].ulSyncTransTimeout			=	(NX_ULONG)(pow((NX_DOUBLE)NX_TWO,(NX_DOUBLE)(pstNcfTsn->chSyncTransmitCycle)) * (NX_DOUBLE)(pstNcfTsn->uchSyncReceiveTimeout) * (NX_DOUBLE)(1000 * 1000));
	}
	for (usDomainIndex = (NX_USHORT)NX_ZERO; usDomainIndex < usDomainNum; usDomainIndex++) {
		for (usPortIndex = (NX_USHORT)NX_ZERO; usPortIndex < (NX_USHORT)PTP_PORT_NUM; usPortIndex++) {
			pstPtpConf	=	&gstPtpConf.astPortInfo1588[usDomainIndex][usPortIndex];
			
			pstPtpConf->chInitialLogAnnounceInt		= pstNcfTsn->chAnnounceTransmitCycle;
			pstPtpConf->uchAnnounceReceiptTimeout	= pstNcfTsn->uchAnnounceReceiveTimeout;
			pstPtpConf->chInitialLogSyncInt			= pstNcfTsn->chSyncTransmitCycle;
			pstPtpConf->chLogMinDelayReqInt			= pstNcfTsn->chPropagationDelayTransmitCycle;
			pstPtpConf->enDelayMechanism			= DELAY_E2E;
			pstPtpConf->chLogMinPdelayReqInt		= pstNcfTsn->chPropagationDelayTransmitCycle;
			pstPtpConf->enPortState					= DisabledPort;
			pstPtpConf->blUnicast					= FALSE;
			pstPtpConf->blPortValid					= TRUE;
		}
	}
}

NX_VOID	vTsn_InitClock (
	NCF_TSN_INFO	*pstNcfTsn
)
{
	NX_USHORT	usSecmsb = 0;
	NX_ULONG	ulSeclsb = 0;
	NX_ULONG	ulNsec	 = 0;
	

	NX_SHORT	 sUtcOffset = (NX_SHORT)NX_ZERO;
	gstClockSourceTime.uchDomainNumber					=	DOMAIN_NUMBER_0;
	vNX_CopyMemory16(&usSecmsb, &pstNcfTsn->auchMasterNodeTime[8], sizeof(usSecmsb)/sizeof(NX_USHORT));
	vNX_CopyMemory32(&ulSeclsb, &pstNcfTsn->auchMasterNodeTime[4], sizeof(ulSeclsb)/sizeof(NX_ULONG));
	vNX_CopyMemory32(&ulNsec, &pstNcfTsn->auchMasterNodeTime[0], sizeof(ulNsec)/sizeof(NX_ULONG));
	
	gstClockSourceTime.stSourceTime.stSec.usSec_msb		=	usSecmsb;
	gstClockSourceTime.stSourceTime.stSec.ulSec_lsb		=	ulSeclsb;
	gstClockSourceTime.stSourceTime.stNsec.ulNsec		=	ulNsec;
	gstClockSourceTime.stSourceTime.stNsec.usFrcNsec	=	0x0000;
	
	sUtcOffset = sTSN_ConvTimetoUtcOffset(ulSeclsb);
	
	gstClockSourceTime.usTimeBaseIndicator	=	0;
	gstClockSourceTime.stLastGmPhaseChange.sNsec_msb	=	0;
	gstClockSourceTime.stLastGmPhaseChange.ulNsec_2nd	=	0;											
	gstClockSourceTime.stLastGmPhaseChange.ulNsec_lsb	=	0;
	gstClockSourceTime.stLastGmPhaseChange.usFrcNsec	=	0;
	gstClockSourceTime.dbLastGmFreqChange				=	0;

	gstClockSourceInfo.uchDomainNumber			=	DOMAIN_NUMBER_0;
	gstClockSourceInfo.sCurrentUtcOffset		=	sUtcOffset;
	gstClockSourceInfo.blLeap61					=	FALSE;
	gstClockSourceInfo.blLeap59					=	FALSE;
	gstClockSourceInfo.blCurrentUtcOffsetValid	=	TRUE;
	gstClockSourceInfo.blPtpTimescale			=	TRUE;
	gstClockSourceInfo.blTimeTraceable			=	FALSE;
	gstClockSourceInfo.blFrecuencyTraceable		=	FALSE;
	gstClockSourceInfo.uchTimeSource			=	0x00;
	return;
}
NX_VOID vTsn_SetGlobal ( NX_VOID )
{
	NX_ULONG		ulMLTSStart_Ns	=	0;
	NX_ULONG		ulMLTSStart_S	=	0;
	NX_ULONG		ulMLTSEnd_Ns	=	0;
	NX_ULONG		ulMLTSEnd_S		=	0;
	NX_ULONGLONG	ullMLTSStart	=	0;
	NX_ULONGLONG	ullMLTSEnd		=	0;
	NX_LONGLONG		llTSTime_PTP	=	0;
	NX_LONGLONG		llTSMargin_PTP	=	0;
	NX_USHORT	usLinkSpdSta = NX_LINKSPD_STA_1G;
		
	usLinkSpdSta	=	usLSM_GetLinkSpd();
	
	if (usLinkSpdSta == NX_LINKSPD_STA_1G) {
		vNX_vDisableDispatch();
		ulMLTSStart_Ns	= NGN_CN_TS_P1_REG->R_TCPXSOnN[2].DATA;
		ulMLTSStart_S	= NGN_CN_TS_P1_REG->R_TCPXSOnS[2].DATA;
		ulMLTSEnd_Ns	= NGN_CN_TS_P1_REG->R_TCPXEOnN[2].DATA;
		ulMLTSEnd_S		= NGN_CN_TS_P1_REG->R_TCPXEOnS[2].DATA;
		vNX_vEnableDispatch();
		
		ullMLTSStart	=	((NX_ULONGLONG)ulMLTSStart_S * 1000000000ULL) + ulMLTSStart_Ns;
		ullMLTSEnd		=	((NX_ULONGLONG)ulMLTSEnd_S * 1000000000ULL) + ulMLTSEnd_Ns;
		
		gstNET.stPtp.ullMLTSCenter = (ullMLTSStart + ullMLTSEnd) / 2;




		gstNET.stPtp.ullComCycle = gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
		
		if (gstNET.stPtp.ullComCycle <= TSN_ADD_TMING_THRESHOLD) {
			gstNET.stPtp.ullTimeAdjustOffset = ((TSN_ADD_TMING_BASELINE / gstNET.stPtp.ullComCycle) * gstNET.stPtp.ullComCycle) + gstNET.stPtp.ullMLTSCenter;
		} else {
			gstNET.stPtp.ullTimeAdjustOffset = (gstNET.stPtp.ullComCycle * 2) + gstNET.stPtp.ullMLTSCenter;
		}
		
	
		llTSTime_PTP = (NX_LONGLONG)(ullMLTSEnd - ullMLTSStart);
		if ( llTSTime_PTP >= OFFSET_BORDER_TIMESLOT_PTP_18US ) {
			llTSMargin_PTP = OFFSET_MARGIN_TIMESLOT_PTP_18US;
		} else if ( llTSTime_PTP >= OFFSET_BORDER_TIMESLOT_PTP_3US ) {
			llTSMargin_PTP = OFFSET_MARGIN_TIMESLOT_PTP_3US;
		} else {
			llTSMargin_PTP = (NX_LONGLONG)NX_ZERO;
		}
		gstNET.stPtp.llMLAdjustLength = (llTSTime_PTP / 2) - llTSMargin_PTP;
	}
	else {
		vTsn_SetGlobal100M();
	}
	
	vNX_FillMemory32(gastTsnCtrl, 0x00000000, (sizeof(TSN_CTRL)*2 / sizeof(NX_ULONG)));
	gstTsnStatusMng.ullAveRstTimeout	=	(NX_ULONGLONG)(pow((NX_DOUBLE)NX_TWO,(NX_DOUBLE)(gstNM.stNetworkConfigMain.stNcfTsn.chSyncTransmitCycle))
												       * (NX_DOUBLE)(1000ULL * 1000ULL * 1000ULL))
										  * (NX_ULONGLONG)AVERAGE_RESET_TIMEOUT;							;
	vNX_FillMemory(&gstRcvTimeLast, NX_ZERO, sizeof(EXTENDEDTIMESTAMP) * NX_PORT_SIZE * PTP_MSGNUM_TIMECHECK * NX_TWO);
	
	return;
}

NX_VOID	vTsn_Start (
	NCF_TSN_INFO	*pstNcfTsn
)
{	
	INT	iResult = 0;
	NX_ULONG		ulNs_Temp;
	NX_ULONGLONG	ullSec_Temp;
	NX_ULONGLONG	ullNs_Temp;
	
	ulNs_Temp = 0;
	ullSec_Temp = 0;
	
	vTsn_PTP_Reset();
	
	vTsn_SetGlobal();
	vTsn_SetPtpInf(pstNcfTsn);
	vTsn_InitClock(pstNcfTsn);
	
	gstPtpInfSet.pstClockKndInfo	=	(CLOCKKNDINF*)&(gstPtpConf.stClockKndInfo);
	gstPtpInfSet.pvTransAdrInfo		=	(NX_VOID*)&(gstPtpConf.stTransAdrInfo);
	gstPtpInfSet.ulME_extend		=	gstPtpConf.ulME_extend;
	if(gstPtpInfSet.pstClockKndInfo->enClockPtpProtcol == PROTOCOL_IEEE802_1_AS){
		gstPtpInfSet.pvClockInfo	=	(NX_VOID*)&(gstPtpConf.astClockInfoAS); 
		gstPtpInfSet.pvPortInfo		=	(NX_VOID*)&(gstPtpConf.astPortInfoAS);
	}else{
		gstPtpInfSet.pvClockInfo	=	(NX_VOID*)&(gstPtpConf.astClockInfo1588); 
		gstPtpInfSet.pvPortInfo		=	(NX_VOID*)&(gstPtpConf.astPortInfo1588);
	
	}
	
	
	if(gstNET.stPtp.ulPtpSts == PTPSTS_STARTUP){
		vTsn_Stop();
		
	}
	iResult= ptp_config(&gstPtpInfSet);

	vTsn_Refresh_SndTimeStamp();
	vTsn_Refresh_RcvTimeStamp();
	
	iResult= ptp_open();
	
	vNX_CopyMemory(&ulNs_Temp,   &pstNcfTsn->auchMasterNodeTime[GMTIME_NS],  GMTIME_SIZE_NS);
	vNX_CopyMemory(&ullSec_Temp, &pstNcfTsn->auchMasterNodeTime[GMTIME_SEC], GMTIME_SIZE_SEC);

	gastTimerCounter[TSN_TIMCNT_START_TIME].ulUnixTime_ns = ulNs_Temp & MASK_NS;
	gastTimerCounter[TSN_TIMCNT_START_TIME].ulUnixTime_s  = (NX_ULONG)(ullSec_Temp & MASK_S);

	vNX_vDisableDispatch();
	NGN_SN_REG->R_SNTM0 = gastTimerCounter[TSN_TIMCNT_START_TIME].ulUnixTime_ns;
	NGN_SN_REG->R_SNTM1 = gastTimerCounter[TSN_TIMCNT_START_TIME].ulUnixTime_s;
	gulTSN_GetFreeRunCnt(NX_OFF, &gastTimerCounter[TSN_TIMCNT_START_FREE].ulUnixTime_s,
								 &gastTimerCounter[TSN_TIMCNT_START_FREE].ulUnixTime_ns);
	vNX_vEnableDispatch();
	
	iResult= ptp_clockSourceSetInfo(&gstClockSourceInfo);
	iResult= ptp_clockSourceSetTime(&gstClockSourceTime);
	
	gstNET.stPtp.ulPtpSts = PTPSTS_STARTUP;
	return;
}
NX_VOID  vTsn_GetDetailSndTime(NX_UCHAR uchMsgType, NX_UCHAR uchPort, EXTENDEDTIMESTAMP *pstTimeStamp)
{
	EXTENDEDTIMESTAMP* pstTimeStamp_Next = pstTimeStamp + 1;

	pstTimeStamp->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
	pstTimeStamp->stNsec.ulNsec		= NX_ZERO;
	pstTimeStamp->stSec.ulSec_lsb = NX_ZERO;
	pstTimeStamp->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
	if (0 == uchPort){
		
		if (uchMsgType == 0x0){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNSTXTC0P1;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNSTXTC1P1;
			
			pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
			pstTimeStamp_Next->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNSTX0PX;
			pstTimeStamp_Next->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNSTX1PX;
			pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		} else if (uchMsgType == 0x1){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNQTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNQTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		} else if (uchMsgType == 0x2){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNQTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNQTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		} else if (uchMsgType == 0x3){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNPTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNPTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
		
		}else {
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
			
		}
		
	}else if(1 == uchPort){
		
		if(uchMsgType == 0x0){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNSTXTC0P1;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNSTXTC1P1;

			pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
			pstTimeStamp_Next->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNSTX0PX;
			pstTimeStamp_Next->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNSTX1PX;
			pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
		
		} else if (uchMsgType == 0x1){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNQTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNQTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();

		} else if(uchMsgType == 0x2){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNQTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNQTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x3){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNPTX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNPTX1PX;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
		
		}else {
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
			
		}
	}else{
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
	}
}

NX_VOID vTsn_GetDetailRcvTime(NX_UCHAR uchMsgType, NX_UCHAR uchPort, EXTENDEDTIMESTAMP *pstTimeStamp)
{
	NX_ULONG uldummy0;
	NX_ULONG uldummy1;
	NX_ULONG uldummy2;
	NX_ULONG uldummy3;
	NX_ULONG uldummy4;
	NX_ULONG uldummy5;
	NX_ULONG uldummy6;
	NX_ULONG uldummy7;
	EXTENDEDTIMESTAMP* pstTimeStamp_Next = pstTimeStamp + 1;

	pstTimeStamp->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
	pstTimeStamp->stNsec.ulNsec		= NX_ZERO;
	pstTimeStamp->stSec.ulSec_lsb = NX_ZERO;
	pstTimeStamp->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
	NX_ULONG test;
	
	
	if(0 == uchPort){
		
		if(uchMsgType == 0x0){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			uldummy0 = NGN_SN_REG->PORT1.R_SNSRX0PX;
			uldummy1 = NGN_SN_REG->PORT1.R_SNSRX1PX;
			uldummy2 = NGN_SN_REG->PORT1.R_SNFRHD0SPX.DATA;
			uldummy3 = NGN_SN_REG->PORT1.R_SNFRHD1SPX;
			uldummy4 = NGN_SN_REG->PORT1.R_SNFRHD2SPX;
			uldummy5 = NGN_SN_REG->PORT1.R_SNFRHD3SPX.DATA;
			uldummy6 = NGN_SN_REG->PORT1.R_SNSRXTC0P1;
			uldummy7 = NGN_SN_REG->PORT1.R_SNSRXTC1P1;
			gastTsnCtrl[uchPort].ulSyncRcvFreeCnt_NS = uldummy0;
			gastTsnCtrl[uchPort].ulSyncRcvFreeCnt_S = uldummy1;
			gastTsnCtrl[uchPort].ulSyncRcvTime_NS = uldummy6;
			gastTsnCtrl[uchPort].ulSyncRcvTime_S = uldummy7;
			pstTimeStamp->stNsec.ulNsec = uldummy6;
			pstTimeStamp->stSec.ulSec_lsb = uldummy7;

			pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
			pstTimeStamp_Next->stNsec.ulNsec = uldummy0;
			pstTimeStamp_Next->stSec.ulSec_lsb = uldummy1;
			pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x1){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			
			test = NGN_CN_REG->R_REIPSET.DATA;
			
			uldummy0 = NGN_SN_REG->PORT1.R_SNQRX0PX;
			uldummy1 = NGN_SN_REG->PORT1.R_SNQRX1PX;
			uldummy2 = NGN_SN_REG->PORT1.R_SNFRHD0PX.DATA;
			uldummy3 = NGN_SN_REG->PORT1.R_SNFRHD1PX;
			uldummy4 = NGN_SN_REG->PORT1.R_SNFRHD2PX;
			uldummy5 = NGN_SN_REG->PORT1.R_SNFRHD3PX.DATA;
			
			pstTimeStamp->stNsec.ulNsec = uldummy0;
			pstTimeStamp->stSec.ulSec_lsb = uldummy1;
			if(gstPtpConf.stClockKndInfo.enClockPtpProtcol == PROTOCOL_IEEE1588){
				pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
				pstTimeStamp_Next->stNsec.ulNsec = 0xFFFFFFFF;
				pstTimeStamp_Next->stSec.ulSec_lsb = 0xFFFFFFFF;
				pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			}

			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x2){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNQRX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNQRX1PX;
			uldummy0 = NGN_SN_REG->PORT1.R_SNFRHD0PX.DATA;
			uldummy1 = NGN_SN_REG->PORT1.R_SNFRHD1PX;
			uldummy2 = NGN_SN_REG->PORT1.R_SNFRHD2PX;
			uldummy3 = NGN_SN_REG->PORT1.R_SNFRHD3PX.DATA;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x3){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT1.R_SNPRX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT1.R_SNPRX1PX;
			uldummy0 = NGN_SN_REG->PORT1.R_SNFRHD0PPX.DATA;
			uldummy1 = NGN_SN_REG->PORT1.R_SNFRHD1PPX;
			uldummy2 = NGN_SN_REG->PORT1.R_SNFRHD2PPX;
			uldummy3 = NGN_SN_REG->PORT1.R_SNFRHD3PPX.DATA;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else {
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
		}
		
	}else if(1 == uchPort){
		
		if(uchMsgType == 0x0){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			uldummy0 = NGN_SN_REG->PORT2.R_SNSRX0PX;
			uldummy1 = NGN_SN_REG->PORT2.R_SNSRX1PX;
			uldummy2 = NGN_SN_REG->PORT2.R_SNFRHD0SPX.DATA;
			uldummy3 = NGN_SN_REG->PORT2.R_SNFRHD1SPX;
			uldummy4 = NGN_SN_REG->PORT2.R_SNFRHD2SPX;
			uldummy5 = NGN_SN_REG->PORT2.R_SNFRHD3SPX.DATA;
			uldummy6 = NGN_SN_REG->PORT2.R_SNSRXTC0P1;
			uldummy7 = NGN_SN_REG->PORT2.R_SNSRXTC1P1;
			gastTsnCtrl[uchPort].ulSyncRcvFreeCnt_NS = uldummy0;
			gastTsnCtrl[uchPort].ulSyncRcvFreeCnt_S = uldummy1;
			gastTsnCtrl[uchPort].ulSyncRcvTime_NS = uldummy6;
			gastTsnCtrl[uchPort].ulSyncRcvTime_S = uldummy7;
			pstTimeStamp->stNsec.ulNsec = uldummy6;
			pstTimeStamp->stSec.ulSec_lsb = uldummy7;
			
			pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
			pstTimeStamp_Next->stNsec.ulNsec = uldummy0;
			pstTimeStamp_Next->stSec.ulSec_lsb = uldummy1;
			pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x1){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			
			test = NGN_CN_REG->R_REIPSET.DATA;
			uldummy0 = NGN_SN_REG->PORT2.R_SNQRX0PX;
			uldummy1 = NGN_SN_REG->PORT2.R_SNQRX1PX;
			uldummy2 = NGN_SN_REG->PORT2.R_SNFRHD0PX.DATA;
			uldummy3 = NGN_SN_REG->PORT2.R_SNFRHD1PX;
			uldummy4 = NGN_SN_REG->PORT2.R_SNFRHD2PX;
			uldummy5 = NGN_SN_REG->PORT2.R_SNFRHD3PX.DATA;
			pstTimeStamp->stNsec.ulNsec = uldummy0;
			pstTimeStamp->stSec.ulSec_lsb = uldummy1;
			
			if(gstPtpConf.stClockKndInfo.enClockPtpProtcol == PROTOCOL_IEEE1588){
				pstTimeStamp_Next->stNsec.usFrcNsec = (NX_USHORT) NX_ZERO;
				pstTimeStamp_Next->stNsec.ulNsec = 0xFFFFFFFF;
				pstTimeStamp_Next->stSec.ulSec_lsb = 0xFFFFFFFF;
				pstTimeStamp_Next->stSec.usSec_msb = (NX_USHORT) NX_ZERO;
			}
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x2){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNQRX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNQRX1PX;
			uldummy0 = NGN_SN_REG->PORT2.R_SNFRHD0PX.DATA;
			uldummy1 = NGN_SN_REG->PORT2.R_SNFRHD1PX;
			uldummy2 = NGN_SN_REG->PORT2.R_SNFRHD2PX;
			uldummy3 = NGN_SN_REG->PORT2.R_SNFRHD3PX.DATA;
			vNX_vEnableInterrupt();	
			vNX_vEnableDispatch();
			
		}else if(uchMsgType == 0x3){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
			pstTimeStamp->stNsec.ulNsec = NGN_SN_REG->PORT2.R_SNPRX0PX;
			pstTimeStamp->stSec.ulSec_lsb = NGN_SN_REG->PORT2.R_SNPRX1PX;
			uldummy0 = NGN_SN_REG->PORT2.R_SNFRHD0PPX.DATA;
			uldummy1 = NGN_SN_REG->PORT2.R_SNFRHD1PPX;
			uldummy2 = NGN_SN_REG->PORT2.R_SNFRHD2PPX;
			uldummy3 = NGN_SN_REG->PORT2.R_SNFRHD3PPX.DATA;
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
			
#if REC_TSN_INF
		}else if(uchMsgType == 0xB){
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
#endif
		}else {
			pstTimeStamp->stNsec.ulNsec = 0;
			pstTimeStamp->stSec.ulSec_lsb = 0;
		}
		
	}else{
		pstTimeStamp->stNsec.ulNsec = 0;
		pstTimeStamp->stSec.ulSec_lsb = 0;
	}
}
NX_ULONG ulTsn_CheckRcvTime ( NX_UCHAR uchMsgType, NX_UCHAR uchPort, EXTENDEDTIMESTAMP* pstTime )
{
	NX_ULONG           ulRetrun     = NX_UL_OK;
	EXTENDEDTIMESTAMP* pstTime_Next = pstTime + 1;
	
	switch (uchMsgType) {
	case PTP_MSGTYPE_SYNC:
		ulRetrun = ulTsn_RefreshTime( &(gstRcvTimeLast[uchPort][uchMsgType][0]), pstTime      );
		ulRetrun = ulTsn_RefreshTime( &(gstRcvTimeLast[uchPort][uchMsgType][1]), pstTime_Next );
		break;
	case PTP_MSGTYPE_DELAY_REQ:
		ulRetrun = ulTsn_RefreshTime( &(gstRcvTimeLast[uchPort][uchMsgType][0]), pstTime      );
		break;
	case PTP_MSGTYPE_PDELAY_REQ:
		ulRetrun = ulTsn_RefreshTime( &(gstRcvTimeLast[uchPort][uchMsgType][0]), pstTime      );
		break;
	default:
		break;
	}
	
	return ulRetrun;
}
NX_ULONG ulTsn_RefreshTime ( EXTENDEDTIMESTAMP* pstDstTime, EXTENDEDTIMESTAMP* pstSrcTime )
{
	NX_LONG 	lIsSame  = NX_OK;
	NX_ULONG 	ulRetrun = NX_UL_OK;
	
	lIsSame = lNX_CompareMemory( pstDstTime, pstSrcTime, sizeof(EXTENDEDTIMESTAMP) );
	if ( lIsSame == NX_OK ) {
		ulRetrun = NX_UL_NG;
	} else {
		ulRetrun = NX_UL_OK;
		pstDstTime->stNsec.usFrcNsec = (NX_USHORT)NX_ZERO;
		pstDstTime->stNsec.ulNsec    = pstSrcTime->stNsec.ulNsec;
		pstDstTime->stSec.ulSec_lsb  = pstSrcTime->stSec.ulSec_lsb;
		pstDstTime->stSec.usSec_msb  = (NX_USHORT)NX_ZERO;
	}
	
	return ulRetrun;
}
NX_VOID vTsn_TsnPeriodicMain ( NX_VOID )
{
	NX_LONG lResult = NX_ZERO;
	if (gstTsnStatusMng.ulStopReq_Status == NX_ON){
		vTsn_Stop();
	}
	
	vTsn_recv();
	
#if REC_TSN_INF
	if(gstNET.stPtp.ulPtpSts == PTPSTS_INITIAL){
			vNX_SetRunLed(NX_LED_OFF);
		
	}else {
		lResult = lTsn_isGM();
		if(lResult == NX_OK){		
			vNX_SetRunLed(NX_LED_BLINK_500MS);
		}else if(lResult == NX_NG) {
			vNX_SetRunLed(NX_LED_ON);
		}else{
			vNX_SetRunLed(NX_LED_OFF);
		}	
	}
#endif
		
	if (gstNET.stPtp.ulPtpSts != PTPSTS_INITIAL) {
		ptp_Tick();
	}

	
	return;
}

NX_VOID vTsn_Stop(NX_VOID){
	gstNET.stPtp.ulPtpSts = PTPSTS_INITIAL;
	
	ptp_close();
	vTsn_PTP_Reset();
	
	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();

	gulTSN_GetTimeCnt(NX_OFF, &gastTimerCounter[TSN_TIMCNT_STOP_TIME].ulUnixTime_s,
							  &gastTimerCounter[TSN_TIMCNT_STOP_TIME].ulUnixTime_ns);
	
	gulTSN_GetFreeRunCnt(NX_OFF, &gastTimerCounter[TSN_TIMCNT_STOP_FREE].ulUnixTime_s,
								 &gastTimerCounter[TSN_TIMCNT_STOP_FREE].ulUnixTime_ns);
	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();
	
	vNMG_DataLinkDownCmp();
	gstTsnStatusMng.ulStopReq_Status = NX_OFF;

}
NX_VOID vTsn_recv(NX_VOID)
{
	NX_LONG			lFrmExist		=	NCYC_RX_BUF_RSLT_NO_MAIL;
	NCYC_RX_FRAME	*pstData = NULL;
	UCHAR* puchMsgPtr;
	USHORT usMsgLen;
	EXTENDEDTIMESTAMP pstRcvTimeStamp[2];
	UCHAR uchport;
	UCHAR uchMsgType;
	NX_ULONG ulIsRcvTimeValid;
	
	lFrmExist = lRXN_PollingRxNonCycFrame(MBXID_NX_RECEIVE_IEEE, &pstData);
	
	if (lFrmExist == NCYC_RX_BUF_RSLT_OK) {
		if (gstNET.stPtp.ulPtpSts != PTPSTS_INITIAL) {
			puchMsgPtr = 0;
			usMsgLen = 0;
			uchport = 0;
			uchMsgType = 0;
			vNX_FillMemory(pstRcvTimeStamp, 0x00, sizeof(EXTENDEDTIMESTAMP)*2);
			puchMsgPtr = (UCHAR*)(pstData->auchData + pstData->usEtherOffset + (NX_UCHAR)NX_TWO) ;
			usMsgLen = pstData->usSize - pstData->usEtherOffset - (NX_UCHAR)NX_TWO;
			uchMsgType = (UCHAR)(*puchMsgPtr) & (UCHAR)0x0F;
			uchport = pstData->usPort;
			
			vTsn_GetDetailRcvTime(uchMsgType, uchport, pstRcvTimeStamp);
			ulIsRcvTimeValid = ulTsn_CheckRcvTime(uchMsgType, uchport, pstRcvTimeStamp);
			if ( ulIsRcvTimeValid == NX_UL_OK ) {
#if TSN_LOG_FRAME
				vTSNFRAMELOG_setevent(TSNFRAMELOG_PTPRECV, (NX_ULONGLONG)uchport, puchMsgPtr);
#endif
				ptp_recv(uchport, puchMsgPtr, usMsgLen, pstRcvTimeStamp);
			}
			vTsn_UpdateOutOfTimeSyncStatus(uchMsgType);
		}
		(NX_VOID)vRXN_RelRxNonCycFrameBuf(pstData);
	}
	else {
		
	}
	return;
	
	
}
NX_VOID vTsn_Callback(NX_ULONG pstTxFrame, NX_ULONG ulResult)
{
	EXTENDEDTIMESTAMP pstTimeStamp[2];
	vNX_FillMemory(pstTimeStamp, 0x00, sizeof(EXTENDEDTIMESTAMP)*2);
	
	NCYC_TX_FRAME* pstTxPTPFrame = (NCYC_TX_FRAME*)pstTxFrame;
	
	PTP_CTRL* pstPtpInfo = (PTP_CTRL*)&(pstTxPTPFrame->uchFreeData);

	if((gstNET.stPtp.ulPtpSts != PTPSTS_INITIAL) && (gstTsnStatusMng.ulStopReq_Status == NX_OFF)){		
		vTsn_UpdateOutOfTimeSyncStatus(pstPtpInfo->uchMsgType);
		if (pstPtpInfo->fpPTPCallback != 0) {
			vTsn_GetDetailSndTime(pstPtpInfo->uchMsgType, pstPtpInfo->uchPort, pstTimeStamp);
			INT nErrorCode = 0;
			pstPtpInfo->fpPTPCallback(nErrorCode, pstPtpInfo->uchPort, pstTimeStamp, (VOID*)pstPtpInfo->pvLinkId);
#if TSN_LOG_FRAME
			vTSNFRAMELOG_setevent(TSNFRAMELOG_CALLBACK, (NX_ULONGLONG)pstTxPTPFrame->usPort, (NX_UCHAR*)(pstTxPTPFrame->auchData + pstTxPTPFrame->usHeaderSize));
#endif
		}
	}
	return;
}
NX_VOID vTSN_getACKINFO(ACK_TSN_INFO* pstAckTsn){
	if(pstAckTsn == NULL){
		return;
	}
	pstAckTsn->uchSyncType 			= 3;
	pstAckTsn->chAnnounceRelayTime	= -6;
	pstAckTsn->chDelaySetTime 		= -3;
	pstAckTsn->chPdealyResTime 		= -3;


}
NX_VOID vTSN_getACKINFO_VER1(ACK_TSN_INFO* pstAckTsn){
	if(pstAckTsn == NULL){
		return;
	}
	pstAckTsn->uchSyncType 			= 0x0B;
	pstAckTsn->chAnnounceRelayTime	= -6;
	pstAckTsn->chDelaySetTime 		= -3;
	pstAckTsn->chPdealyResTime 		= -3;

	return;
}
NX_ULONG gulTSN_GetFreeRunCnt (
	NX_USHORT	usInterruptReq,
	NX_ULONG*	pulCounterHigh,
	NX_ULONG*	pulCounterLow
)
{
	NX_ULONG		ulRet	= (NX_ULONG)NX_NG;
#if NX_ASIC_ES2 == 0
	ULONG		ulCounterTmp[4];
	USHORT		usRetry;

	*pulCounterHigh	= (ULONG)NX_ZERO;
	*pulCounterLow	= (ULONG)NX_ZERO;
	ulRet = (ULONG)NX_NG;
	usRetry = (USHORT)2;
#endif

	if (( NULL == pulCounterHigh )||( NULL == pulCounterLow )){
	}
	else{
		if ((USHORT)NX_ON == usInterruptReq ){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
		}
#if NX_ASIC_ES2 == 1
		*pulCounterLow	= NGN_SN_REG->R_SNCNT0;
		*pulCounterHigh	= NGN_SN_REG->R_SNCNT1;
		ulRet = (ULONG)NX_OK;
#else
		ulCounterTmp[0] = NGN_SN_REG->R_SNCNT0;
		ulCounterTmp[1] = NGN_SN_REG->R_SNCNT1;
		if( (ULONG)999999992 <= ulCounterTmp[0] ){
			ulCounterTmp[0] = NGN_SN_REG->R_SNCNT0;
			ulCounterTmp[1] = NGN_SN_REG->R_SNCNT1;
		}
		ulCounterTmp[2] = NGN_SN_REG->R_SNCNT0;
		ulCounterTmp[3] = NGN_SN_REG->R_SNCNT1;

		do{
			if( ulCounterTmp[1] == ulCounterTmp[3] ){
				if( ulCounterTmp[0] < ulCounterTmp[2] ){
					*pulCounterHigh	= ulCounterTmp[3];
					*pulCounterLow	= ulCounterTmp[2];
					usRetry = (USHORT)NX_ZERO;
					ulRet = (ULONG)NX_OK;
				}
				else{
					usRetry--;
				}
			}
			else{
				usRetry--;
			}
			if ((USHORT)NX_ZERO != usRetry ){
				ulCounterTmp[0] = NGN_SN_REG->R_SNCNT0;
				ulCounterTmp[1] = NGN_SN_REG->R_SNCNT1;
				if( (ULONG)999999992  <= ulCounterTmp[0] ){
					ulCounterTmp[0] = NGN_SN_REG->R_SNCNT0;
					ulCounterTmp[1] = NGN_SN_REG->R_SNCNT1;
				}
				else{
				}
				ulCounterTmp[2] = NGN_SN_REG->R_SNCNT0;
				ulCounterTmp[3] = NGN_SN_REG->R_SNCNT1;
			}
			else{
				break;
			}
		}while(1);
#endif
		if ((USHORT)NX_ON == usInterruptReq ){
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
		}
	}
	return(ulRet);
}
NX_ULONG gulTSN_GetTimeCnt (
	NX_USHORT usInterruptReq,
	NX_ULONG* pulCounterHigh,
	NX_ULONG* pulCounterLow
)
{
	NX_ULONG		ulRet	= (NX_ULONG)NX_NG;
#if NX_ASIC_ES2 == 0
	NX_ULONG		ulCounterTmp[4];
	NX_USHORT		usRetry;

	*pulCounterHigh	= (ULONG)NX_ZERO;
	*pulCounterLow	= (ULONG)NX_ZERO;
	ulRet = (ULONG)NX_NG;
	usRetry = (USHORT)2;
#endif

	if (( NULL == pulCounterHigh )||( NULL == pulCounterLow )){
	}
	else{
		if ((USHORT)NX_ON == usInterruptReq ){
			vNX_vDisableDispatch();
			vNX_vDisableInterrupt();
		}
#if NX_ASIC_ES2 == 1
		*pulCounterLow	= NGN_SN_REG->R_SNTM0;
		*pulCounterHigh	= NGN_SN_REG->R_SNTM1;
		ulRet = (ULONG)NX_OK;
#else
		ulCounterTmp[0] = NGN_SN_REG->R_SNTM0;
		ulCounterTmp[1] = NGN_SN_REG->R_SNTM1;
		if( (ULONG)999999992 <= ulCounterTmp[0] ){
			ulCounterTmp[0] = NGN_SN_REG->R_SNTM0;
			ulCounterTmp[1] = NGN_SN_REG->R_SNTM1;
		}
		else{
		}
		ulCounterTmp[2] = NGN_SN_REG->R_SNTM0;
		ulCounterTmp[3] = NGN_SN_REG->R_SNTM1;

		do{
			if( ulCounterTmp[1] == ulCounterTmp[3] ){
				if( ulCounterTmp[0] < ulCounterTmp[2] ){
					*pulCounterHigh	= ulCounterTmp[3];
					*pulCounterLow	= ulCounterTmp[2];
					usRetry = (USHORT)NX_ZERO;
					ulRet = (ULONG)NX_OK;
				}
				else{
					usRetry--;
				}
			}
			else{
				usRetry--;
			}
			if ((USHORT)NX_ZERO != usRetry ){
				ulCounterTmp[0] = NGN_SN_REG->R_SNTM0;
				ulCounterTmp[1] = NGN_SN_REG->R_SNTM1;
				if( (ULONG)999999992 <= ulCounterTmp[0] ){
					ulCounterTmp[0] = NGN_SN_REG->R_SNTM0;
					ulCounterTmp[1] = NGN_SN_REG->R_SNTM1;
				}
				else{
				}
				ulCounterTmp[2] = NGN_SN_REG->R_SNTM0;
				ulCounterTmp[3] = NGN_SN_REG->R_SNTM1;
			}
			else{
				break;
			}
		}while(1);
#endif
		if ((USHORT)NX_ON == usInterruptReq ){
			vNX_vEnableInterrupt();
			vNX_vEnableDispatch();
		}
	}
	return(ulRet);
}
NX_VOID vTSN_Init (NX_VOID)
{
	vTsn_PTP_Init();
	ptp_init();
	
#if REC_TSN_INF
	gstTsnRecord.ullOffset_Max = 0x0;
	gstTsnRecord.ullOffset_Min = 0xFFFFFFFFFFFFFFFF;
	gstTsnRecord.llOffset_Latest = 0x0;
	gstTsnRecord.ulTsnWindowFlg = 0x0;

#endif
}

NX_ULONG ulTsn_GetTsnErrStatus (NX_VOID)
{
	return NX_UL_OK;
}

NX_VOID vTsn_StopReq (NX_VOID)
{
	gstTsnStatusMng.ulStopReq_Status = NX_ON;
	
	return;
}

NX_VOID vTsn_GetGMMacAddr (NX_UCHAR*	puchMacAddress , NX_UCHAR uchDomainNumber){
	CLOCKIDENTITY clockIdentity;
	MGT_PARENT_DATA_SET stDataSet;
	vNX_FillMemory(&stDataSet, NX_ZERO, sizeof(MGT_PARENT_DATA_SET));
	vNX_FillMemory(&clockIdentity, NX_ZERO, sizeof(CLOCKIDENTITY));
	
	if (gstPtpConf.stClockKndInfo.enClockPtpProtcol == PROTOCOL_IEEE802_1_AS) {

		ptp_get_para_AS(MID_PARENTDS_GRANDMASTERID,
						uchDomainNumber,
						NX_ZERO,
						(NX_UCHAR*)&clockIdentity,
						sizeof(CLOCKIDENTITY));
		puchMacAddress[0] = clockIdentity.uchId[0];
		puchMacAddress[1] = clockIdentity.uchId[1];
		puchMacAddress[2] = clockIdentity.uchId[2];
		puchMacAddress[3] = clockIdentity.uchId[5];
		puchMacAddress[4] = clockIdentity.uchId[6];
		puchMacAddress[5] = clockIdentity.uchId[7];
	}
	else if (gstPtpConf.stClockKndInfo.enClockPtpProtcol == PROTOCOL_IEEE1588) {

		ptp_get_para_1588(MID_1588_PARENT_DATA_SET,
							uchDomainNumber,
							NX_ZERO,
							(NX_UCHAR*)&stDataSet,
							sizeof(MGT_PARENT_DATA_SET));
		puchMacAddress[0] = stDataSet.stGMasterIdentity.uchId[0];
		puchMacAddress[1] = stDataSet.stGMasterIdentity.uchId[1];
		puchMacAddress[2] = stDataSet.stGMasterIdentity.uchId[2];
		puchMacAddress[3] = stDataSet.stGMasterIdentity.uchId[5];
		puchMacAddress[4] = stDataSet.stGMasterIdentity.uchId[6];
		puchMacAddress[5] = stDataSet.stGMasterIdentity.uchId[7];
	}
	else {
	}

	return;
}

#if REC_TSN_INF
NX_VOID vNX_SetCyclicTsnInf (NX_USHORT* pusAddrRWr)
{
	NX_ULONG		*pulTrnRWr;
	
	pulTrnRWr = (NX_ULONG*)pusAddrRWr;
	vNX_CopyMemory32(pulTrnRWr, &gstTsnRecord, sizeof(TSN_RECORD)/sizeof(NX_ULONG));
	
	return;
}

NX_LONG lTsn_isGM (NX_VOID)
{
	ENUM_SELECTEDSTATE enState = gpstClockDataHPtr->stClock_GD.enSelectedState[0];
	if(PS_EX_SLAVE == enState ){
		return NX_OK;
	}else if(PS_EX_PASSIVE == enState){
		return NX_NG;
	}else{
		return RET_EINVAL;
	}
}
#endif
NX_LONG lCompGMMAC(NX_UCHAR* puchMacAddr){
	NX_LONG lResult = NX_ZERO;
	NX_CHAR auchMacAddr_GM[6];
	NX_UCHAR uchIndex			=	NX_ZERO;
	NX_UCHAR uchDomainNum		=	NX_ZERO;
	
	vNX_FillMemory(auchMacAddr_GM, NX_ZERO, sizeof(NX_UCHAR[6]));

	
	if (gstTsnStatusMng.uchDomainStatus == SINGLE_DOMAIN) {
		uchDomainNum	=	NX_ONE;
	}
	else {
		uchDomainNum	=	NX_TWO;
	}
	
	for (uchIndex = NX_ZERO; uchIndex < uchDomainNum; uchIndex++) {
		vTsn_GetGMMacAddr((NX_UCHAR *)auchMacAddr_GM, uchIndex);
		lResult = lNX_CompareMemory(puchMacAddr, auchMacAddr_GM, sizeof(NX_UCHAR[6]));
		
		if (lResult == NX_OK) {
			break;
		}
	}

	return lResult;
}

NX_ULONG ulTsn_Notify_BMCAFinished (
	NX_UCHAR* puchMacAddr
)
{
	NX_ULONG	ulRet		= TSN_NOT_STARTED;
	NX_LONG		lResult_GM	= NX_NG;

	if (gstNET.stPtp.ulPtpSts == PTPSTS_STARTUP) {
		lResult_GM = lCompGMMAC(puchMacAddr);
		if (lResult_GM == NX_OK) {
			ulRet	= TSN_CORRECT_GMMAC;
			vNX_CopyMemory((NX_UCHAR*)gstTsnStatusMng.auchBMCACompGmMac, puchMacAddr, sizeof(NX_UCHAR[NX_MAC_ADDR_SIZE]));
			
			gstTsnStatusMng.auchBMCACompClockIdentity[0] = gstTsnStatusMng.auchBMCACompGmMac[0];
			gstTsnStatusMng.auchBMCACompClockIdentity[1] = gstTsnStatusMng.auchBMCACompGmMac[1];
			gstTsnStatusMng.auchBMCACompClockIdentity[2] = gstTsnStatusMng.auchBMCACompGmMac[2];
			gstTsnStatusMng.auchBMCACompClockIdentity[3] = 0xFF;
			gstTsnStatusMng.auchBMCACompClockIdentity[4] = 0xFE;
			gstTsnStatusMng.auchBMCACompClockIdentity[5] = gstTsnStatusMng.auchBMCACompGmMac[3];
			gstTsnStatusMng.auchBMCACompClockIdentity[6] = gstTsnStatusMng.auchBMCACompGmMac[4];
			gstTsnStatusMng.auchBMCACompClockIdentity[7] = gstTsnStatusMng.auchBMCACompGmMac[5];
			
			gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp 	= NX_ON;
			gstTsnStatusMng.ulTSN_BMCA_Status 			= NX_OK;
		}
		else {
			ulRet	= TSN_NOT_GMMAC;
		}
	}
	else {
		ulRet	= TSN_NOT_STARTED;
	}

	return ulRet;
}

NX_VOID vTSN_GetTimerCounter(
	NX_ULONG	ulKind,
	NX_ULONG*	pulCnt_S,
	NX_ULONG*	pulCnt_NS
)
{
	if (ulKind < TSN_TIMCNT_SIZE) {
		*pulCnt_NS = gastTimerCounter[ulKind].ulUnixTime_ns;
		*pulCnt_S  = gastTimerCounter[ulKind].ulUnixTime_s;
	}
	else {
	}
	
	return;
}
NX_ULONG ulNX_GetSynDeviationInf( NX_VOID){
	return gstTsnStatusMng.ulTsnWindowFlg;
}

NX_SHORT sTSN_ConvTimetoUtcOffset(NX_ULONG ulTimeCnt)
{
	NX_ULONG ulIndex;
	NX_ULONG ulIndex_Max = sizeof(gasTSN_LeapOffsetTable)/sizeof(NX_SHORT);
	NX_ULONG sUtcOffset = (NX_SHORT)NX_ZERO;
	
	for(ulIndex = NX_ZERO; ulIndex < ulIndex_Max; ulIndex++){
		if(ulTimeCnt >= gaulTSN_LeapSecondTable[ulIndex]){
			sUtcOffset = gasTSN_LeapOffsetTable[ulIndex];
			break;
		}
	}
	return sUtcOffset;
}

NX_VOID vTsn_Refresh_RcvTimeStamp(NX_VOID){
	NX_ULONG uldummy = NX_ZERO;

	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();
	
	uldummy = NGN_SN_REG->PORT1.R_SNSRX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNSRX1PX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD0SPX.DATA;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD1SPX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD2SPX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD3SPX.DATA;
	uldummy = NGN_SN_REG->PORT1.R_SNSRXTC0P1;
	uldummy = NGN_SN_REG->PORT1.R_SNSRXTC1P1;
	
	uldummy = NGN_SN_REG->PORT1.R_SNQRX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNQRX1PX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD0PX.DATA;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD1PX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD2PX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD3PX.DATA;
	
	uldummy = NGN_SN_REG->PORT1.R_SNPRX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNPRX1PX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD0PPX.DATA;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD1PPX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD2PPX;
	uldummy = NGN_SN_REG->PORT1.R_SNFRHD3PPX.DATA;
	
	uldummy = NGN_SN_REG->PORT2.R_SNSRX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNSRX1PX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD0SPX.DATA;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD1SPX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD2SPX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD3SPX.DATA;
	uldummy = NGN_SN_REG->PORT2.R_SNSRXTC0P1;
	uldummy = NGN_SN_REG->PORT2.R_SNSRXTC1P1;
	
	uldummy = NGN_SN_REG->PORT2.R_SNQRX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNQRX1PX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD0PX.DATA;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD1PX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD2PX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD3PX.DATA;
	
	uldummy = NGN_SN_REG->PORT2.R_SNPRX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNPRX1PX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD0PPX.DATA;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD1PPX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD2PPX;
	uldummy = NGN_SN_REG->PORT2.R_SNFRHD3PPX.DATA;

	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();
}

NX_VOID vTsn_Refresh_SndTimeStamp(NX_VOID){
	NX_ULONG uldummy = NX_ZERO;

	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();
	
	uldummy = NGN_SN_REG->PORT1.R_SNSTXTC0P1;
	uldummy = NGN_SN_REG->PORT1.R_SNSTXTC1P1;
	uldummy = NGN_SN_REG->PORT1.R_SNSTX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNSTX1PX;
	
	uldummy = NGN_SN_REG->PORT1.R_SNQTX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNQTX1PX;
	
	uldummy = NGN_SN_REG->PORT1.R_SNPTX0PX;
	uldummy = NGN_SN_REG->PORT1.R_SNPTX1PX;
	
	uldummy = NGN_SN_REG->PORT2.R_SNSTXTC0P1;
	uldummy = NGN_SN_REG->PORT2.R_SNSTXTC1P1;
	uldummy = NGN_SN_REG->PORT2.R_SNSTX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNSTX1PX;
	
	uldummy = NGN_SN_REG->PORT2.R_SNQTX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNQTX1PX;
	
	uldummy = NGN_SN_REG->PORT2.R_SNPTX0PX;
	uldummy = NGN_SN_REG->PORT2.R_SNPTX1PX;

	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();
}

NX_VOID vTsn_SetGlobal100M (NX_VOID)
{
	NMG_OFFSET_TS_INFO	stTsInfo;
	NX_ULONGLONG		ull1GbpsCommCycle = 0;
	NX_ULONGLONG		ullTs2StaOffset = 0;
	NX_ULONGLONG		ullTs2EndOffset = 0;
	NX_ULONGLONG		ull1GbpsStaCommCycle = 0;
	NX_ULONGLONG		ull1GbpsEndCommCycle = 0;
	NX_ULONGLONG		ullTimeCorrectSta = 0;
	NX_ULONGLONG		ullTimeCorrectEnd = 0;
	NX_ULONGLONG		ullOffset = 0;
	NX_ULONGLONG		ullPTPComCycle = 0;
	NX_LONGLONG			llTSTime_PTP = 0;
	NX_LONGLONG			llTSMargin_PTP = 0;
	
	vNMG_GetOffsetTslt(TSN_ADJ_TS_NUM, &stTsInfo);
	
	ullTs2StaOffset = 
		((NX_ULONGLONG)stTsInfo.ulTSStartOffset_s * NX_NSEC_1000000000) + (NX_ULONGLONG)stTsInfo.ulTSStartOffset_ns;
	ullTs2EndOffset = 
		((NX_ULONGLONG)stTsInfo.ulTSEndOffset_s * NX_NSEC_1000000000) + (NX_ULONGLONG)stTsInfo.ulTSEndOffset_ns;
	
	gstNET.stPtp.ullMLTSCenter = (ullTs2StaOffset + ullTs2EndOffset) / (NX_ULONGLONG)2;
	
	gstNET.stPtp.ullComCycle = gstNM.stNetworkConfigMain.stNcfComCyc.ullComCycle;
	ullPTPComCycle = gstNET.stPtp.ullComCycle;
	
	ull1GbpsCommCycle = ullPTPComCycle / (NX_ULONGLONG)TSLT_10TIMES;
	
	if (gstNET.stPtp.ullComCycle <= TSN_ADD_TMING_THRESHOLD) {
		ullOffset = (TSN_ADD_TMING_BASELINE / ullPTPComCycle) * ullPTPComCycle;
	}
	else {
		ullOffset = ullPTPComCycle * (NX_ULONGLONG)2;
	}
	
	vTsn_GetAdjCycTime100M (
			ull1GbpsCommCycle,
			gstNET.stPtp.ullMLTSCenter,
			&ull1GbpsStaCommCycle,
			&ull1GbpsEndCommCycle
	);

	vTsn_GetAdjRange100M (
			ullTs2StaOffset,
			ullTs2EndOffset,
			ull1GbpsStaCommCycle,
			ull1GbpsEndCommCycle,
			&ullTimeCorrectSta,
			&ullTimeCorrectEnd
	);
	
	gstNET.stPtp.ullTimeAdjustOffset = 
		ullOffset + ((ullTimeCorrectSta + ullTimeCorrectEnd) / (NX_ULONGLONG)2);
	
	llTSTime_PTP = (NX_LONGLONG)(ullTimeCorrectEnd - ullTimeCorrectSta);
	if ( llTSTime_PTP >= OFFSET_BORDER_TIMESLOT_PTP_18US ) {
		llTSMargin_PTP = OFFSET_MARGIN_TIMESLOT_PTP_18US;
	} else if ( llTSTime_PTP >= OFFSET_BORDER_TIMESLOT_PTP_3US ) {
		llTSMargin_PTP = OFFSET_MARGIN_TIMESLOT_PTP_3US;
	} else {
		llTSMargin_PTP = (NX_LONGLONG)NX_ZERO;
	}
	gstNET.stPtp.llMLAdjustLength = (llTSTime_PTP / 2) - llTSMargin_PTP;
	
	return;
}

NX_VOID vTsn_GetAdjCycTime100M (
	NX_ULONGLONG	ullComCycleTime1G,
	NX_ULONGLONG	ullTargetTime,
	NX_ULONGLONG	*pullCycleStartTime1G,
	NX_ULONGLONG	*pullCycleEndTime1G
)
{
	NX_ULONGLONG	ullComCycStartTime	= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullComCycEndTime	= (NX_ULONGLONG)NX_ZERO;
	NX_ULONG		ulLoop				= (NX_ULONG)NX_ZERO;
	
	for (ulLoop = (NX_ULONG)NX_ZERO; ulLoop < TSLT_10TIMES; ulLoop++) {
		ullComCycStartTime	= ullComCycleTime1G * ulLoop;
		ullComCycEndTime	= ullComCycleTime1G * (ulLoop + NX_ONE);
		
		if ((ullTargetTime >= ullComCycStartTime)
		 && (ullTargetTime < ullComCycEndTime)) {
			break;
		}
	}

	*pullCycleStartTime1G	= ullComCycStartTime;
	*pullCycleEndTime1G		= ullComCycEndTime;

	return;
}

NX_VOID vTsn_GetAdjRange100M (
	NX_ULONGLONG	ullTSStartTime,
	NX_ULONGLONG	ullTSEndTime,
	NX_ULONGLONG	ullCycleStartTime1G,
	NX_ULONGLONG	ullCycleEndTime1G,
	NX_ULONGLONG	*pullAdjStartTime,
	NX_ULONGLONG	*pullAdjEndTime
)
{
	if (ullTSStartTime >= ullCycleStartTime1G) {
		*pullAdjStartTime	= ullTSStartTime;
	}
	else {
		*pullAdjStartTime	= ullCycleStartTime1G;
	}

	if (ullTSEndTime >= ullCycleEndTime1G) {
		*pullAdjEndTime	= ullCycleEndTime1G;
	}
	else {
		*pullAdjEndTime	= ullTSEndTime;
	}

	return;
}

NX_VOID vTsn_Notify_WatchAdjustStart (NX_VOID)
{
	gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp2 = (NX_ULONG)NX_ON;
	
	return;
}

NX_VOID vTsn_Notify_WatchAdjustStop (NX_VOID)
{
	gstTsnStatusMng.ulFlg_OutOfTimeSync = (NX_ULONG)NX_OFF;

	return;
}

NX_VOID vTsn_UpdateOutOfTimeSyncStatus (
	NX_UCHAR uchMsgType
)
{
	NX_LONG		lResult_GM	= NX_NG;

	if ((gstTsnStatusMng.ulFlg_OutOfTimeSync == (NX_ULONG)NX_ON)
	 && (uchMsgType == PTPM_MSGTYPE_ANNOUNCE)) {
		lResult_GM = lCompGMMAC((NX_UCHAR*)gstTsnStatusMng.auchBMCACompGmMac);
		if (lResult_GM == NX_NG) {
			gstTsnStatusMng.ulFlg_OutOfTimeSync		= (NX_ULONG)NX_OFF;
			gulOutOfTimeSyncSts = NX_TIMESYNC_CHK_NG;
		}
	}

	return;
}

/*[EOF]*/
