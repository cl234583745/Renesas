/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNM_SV_L_H_INCLUDED__
#define __ST_SNM_SV_L_H_INCLUDED__

#ifdef SWPS
#include <winsock2.h>
#include <snmp.h>
#endif
#define ST_SNM_OK								(0)
#define ST_SNM_SNMP_UTILMEMREALLOC_ERROR		(1)
#define ST_SNM_SNMP_UTILVARBINDCPY_ERROR		(2)
#define ST_SNM_SNMP_UTILOIDCPY					(3)
#define ST_SNM_SNMP_ASNTYPE_ERROR				(4)
#define ST_SNM_SNMP_MALLOC_ERROR				(5)
#define ST_SNM_SNMP_ASNINT_ERROR				(6)





#ifdef SWPS
extern INT nST_SNM_CalcEncodeGetResponseLen(
	const SnmpVarBind* pVarBind,
	NX_ULONG uiNumberOfVarBind,
	NX_ULONG* puiSize);
#endif
#ifdef SWPS
#else
NX_ULONG ulST_SNM_Start(NX_VOID);
NX_ULONG ulST_SNM_Stop(NX_VOID);
#endif

#endif
