/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __CCIENX_TYPE_H_INCLUDE__
#define __CCIENX_TYPE_H_INCLUDE__

#define NX_VOID		void
#define NX_VOLATILE	volatile
#define NX_CONST		const
#define NX_EXTERN		extern
#define NX_STATIC		static

typedef	  signed char		NX_CHAR;
typedef	unsigned char		NX_UCHAR;
typedef	  signed short		NX_SHORT;
typedef unsigned short		NX_USHORT;
typedef	  signed long		NX_LONG;
typedef unsigned long		NX_ULONG;
typedef	  signed long long	NX_LONGLONG;
typedef	unsigned long long	NX_ULONGLONG;
typedef	double				NX_DOUBLE;

typedef	NX_USHORT (* P_NX_SLMP_FUNC)(NX_USHORT, NX_USHORT, NX_USHORT);

typedef union tagNX_UN_UCHAR {
	struct {
		NX_UCHAR	b0:1;
		NX_UCHAR	b1:1;
		NX_UCHAR	b2:1;
		NX_UCHAR	b3:1;
		NX_UCHAR	b4:1;
		NX_UCHAR	b5:1;
		NX_UCHAR	b6:1;
		NX_UCHAR	b7:1;
	} bt;
	NX_UCHAR uc;
} NX_UN_UCHAR;

typedef union tagNX_UN_USHORT {
	struct {
		NX_UCHAR	b0:1;
		NX_UCHAR	b1:1;
		NX_UCHAR	b2:1;
		NX_UCHAR	b3:1;
		NX_UCHAR	b4:1;
		NX_UCHAR	b5:1;
		NX_UCHAR	b6:1;
		NX_UCHAR	b7:1;
		NX_UCHAR	b8:1;
		NX_UCHAR	b9:1;
		NX_UCHAR	bA:1;
		NX_UCHAR	bB:1;
		NX_UCHAR	bC:1;
		NX_UCHAR	bD:1;
		NX_UCHAR	bE:1;
		NX_UCHAR	bF:1;
	} bt;
	struct {
		NX_UCHAR	b0to3:4;
		NX_UCHAR	b4to7:4;
		NX_UCHAR	b8toB:4;
		NX_UCHAR	bCtoF:4;
	} uhc;
	struct {
		NX_UCHAR	l;
		NX_UCHAR	h;
	} uc;
	NX_USHORT	us;
} NX_UN_USHORT;

typedef union tagNX_UN_ULONG {
	NX_UCHAR	auc[4];
	struct {
		NX_USHORT	l;
		NX_USHORT	h;
	} us;
	NX_ULONG	ul;
} NX_UN_ULONG;

#endif
/*[EOF]*/
