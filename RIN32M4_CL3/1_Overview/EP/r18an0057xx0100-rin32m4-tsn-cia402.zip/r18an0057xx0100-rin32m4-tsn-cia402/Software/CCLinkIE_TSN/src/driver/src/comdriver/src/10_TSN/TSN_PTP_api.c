/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/


#include	<stdlib.h>
#include	<math.h>
#include	"ptp_type.h"
#include	"ptpwrap_Type.h"
#include	"ptpwrap_Proto.h"
#include	"ptpwrap_Global.h"
#include	"TXN_api.h"
#include	"ptp_ddt.h"
#include	"ptp_CommonFunction.h"
#include	"ptp_Struct_clock.h"
#include	"ptp_LogRecord.h"
#include	"kernel.h"
#include	"nx_common.h"
#include	"ptp_tool.h"
#include 	"ptp_api.h"
#include 	"ptp_UserAdjust.h"
#include 	"PTP_GlobalData.h"
#include 	"ptp_CommonFunction.h"

#include 	"NGN_ASIC.h"
#include 	"TOOL_api.h"
#include 	"ccienx_api.h"
#include 	"NMG_common.h"
#include 	"ccienx_task.h"

#include 	"tsn_common.h"
#include	"tsn.h"
#include	"TSN_api.h"

#include 	"ptp_CMSReceive.h"
#include	"ptp_LCEntity.h"
#include	"CYC_api.h"
#if TSN_LOG_ADJUST | TSN_LOG_FRAME
#include	"LOG_api.h"
#endif
#include "nx_frame_sync.h"



#define TSN_SEM_1					(128)
#define TSN_SEM_2					(127)

#define	INT_MASK_ADJUST_COMPLETE	( 1 << 17 )
#define MAX_CALC_TIME_S				(   		  0 )
#define MAX_CALC_TIME_NS			( 100*1000*1000 )

#define	MINOR_VERSION_PTP_802_1AS	(0x10)

#define TM_SOCKET_ERROR 			(0)
#define TM_GLOBAL_MAGIC_NUMBER 		(0)
#define ETHER_HEADER_SIZE 			(14)
#define TM_ETHER_MIN_PACKET 		(60)
#define ETHER_ADDRESS_LENGTH 		(6)
#define CONVERTER_NStoS (1000ULL * 1000ULL * 1000ULL)
#define ONE_CLOCK_NS				(8)
#define ADJUST_ASIC_FILTER (0xFFFFFFFFFFFFFFF8)

#define ST_SYN_AVE_SYNC_SAMPLING_MAX		(8)
#define ST_SYN_AVE_DELAY_SAMPLING_MAX		(256)
#define	ST_SYN_AVE_FREQRATE_SAMPING_MAX		(256)

#define	ST_SYN_LONGLONG_MAX_ABS		((NX_LONGLONG)0x7FFFFFFFFFFFFFFF)
#define	ST_SYN_LONGLONG_MIN_ABS		((NX_LONGLONG)0x8000000000000000)

#define TIMCNT_INC2 0x00010000
#define TIMCNT_STOP 0x00000000
#define TENOFELVTHPOW ((NX_ULONGLONG) 100000000000)
#define NX_DB_TWO ((NX_DOUBLE) 2.0)
#define NX_ULONG_MAX ((NX_ULONG) 0xFFFFFFFF)
#pragma pack(1)
typedef struct tagPTP_FRAME {
	UCHAR	ethDstAddr[ETHER_ADDRESS_LENGTH];
	UCHAR 	ethSrcAddr[ETHER_ADDRESS_LENGTH];
	USHORT	ethType;
	PTPMSG_HEADER stPtpMsg;
} PTP_FRAME;
#pragma pack()

typedef struct _ST_AVE_TMSP_96T_TAG {
	NX_ULONGLONG	ullSec;
	NX_ULONG		ulNsec;
} ST_AVE_TMSP_96T;

typedef struct _ST_AVE_TMSP_64T_TAG {
	NX_ULONG	ulSec;
	NX_ULONG	ulNsec;
} ST_AVE_TMSP_64T;

typedef struct _ST_AVE_CALC_TAG {
	ST_AVE_TMSP_96T		stSum_SyncReceive_Frun;
	ST_AVE_TMSP_96T		stSum_SyncSend;
	ST_AVE_TMSP_96T		stSum_NeighborPropDelay;
	ST_AVE_TMSP_64T		stLast_SyncReceive_Frun;
	ST_AVE_TMSP_64T		stLast_SyncSend;
	ST_AVE_TMSP_64T		stLast_NeighborPropDelay;
} ST_AVE_CALC_T;

typedef struct _ST_AVE_RESULT_TAG {
	NX_ULONGLONG				ullAveSyncReceive_Frun;
	NX_ULONGLONG				ullAveSyncSend;
	NX_ULONGLONG				ullAveNeighborPropDelay;
} ST_AVE_RESULT_T;


PTP_LOWWRAP_INF gPtpLowWrapTbl;
PTP_CTRL gstPtpCtrl;
ST_TSN_STATUS_MNG gstTsnStatusMng;




NX_ULONG gaulST_AVE_SamplingNum_Sync[MAX_DOMAIN];
NX_ULONG gaulST_AVE_Index_Sync[MAX_DOMAIN];
NX_ULONG gaulST_AVE_SamplingNum_Delay[MAX_DOMAIN];
NX_ULONG gaulST_AVE_Index_Delay[MAX_DOMAIN];
ST_AVE_CALC_T gastST_AveCalc[MAX_DOMAIN];
ST_AVE_TMSP_64T gastST_Rec_SyncRecv[MAX_DOMAIN][ST_SYN_AVE_SYNC_SAMPLING_MAX];
ST_AVE_TMSP_64T	gastST_Rec_SyncRecv_Frun[MAX_DOMAIN][ST_SYN_AVE_SYNC_SAMPLING_MAX];
ST_AVE_TMSP_64T	gastST_Rec_SyncSend[MAX_DOMAIN][ST_SYN_AVE_SYNC_SAMPLING_MAX];
ST_AVE_TMSP_64T	gastST_Rec_NeighborPropDelay[MAX_DOMAIN][ST_SYN_AVE_DELAY_SAMPLING_MAX];
ST_AVE_RESULT_T gastAveragingRslt[MAX_DOMAIN];		

NX_USHORT gausFreqRateCnt[MAX_DOMAIN];
NX_ULONG  gaulFreqRateFullCntFlag[MAX_DOMAIN];
NX_DOUBLE gadbFreqRateForCalc[MAX_DOMAIN][ST_SYN_AVE_FREQRATE_SAMPING_MAX];
NX_DOUBLE gadbFreqRateSum[MAX_DOMAIN];
NX_DOUBLE gadbFreqRateAve[MAX_DOMAIN];
NX_DOUBLE gadbFreqRateForCalc_Oldest[MAX_DOMAIN];
NX_DOUBLE gdbCurrentFreqRate;
NX_ULONG	gulOutOfTimeSyncSts;
NX_ULONGLONG gaullSyncRcvFreeCntPre[MAX_DOMAIN];
#if REC_TSN_INF
TSN_RECORD	gstTsnRecord;
#endif

VOID vPTP_CopyMemory (
	VOID*			pvDst,
	const VOID*		pvSrc,
	ULONG			ulSize
);
NX_VOID vPTP_FillMemory (
	VOID*		pvDst,
	CHAR		chData,
	ULONG		ulSize
);
static INT	ptp_send_L2(UCHAR			uchPort,
			 			UCHAR			uchTraClsNo,
			 			UCHAR *			puchMsgPtr,
			 			USHORT			usMsgLen,
			 			SENDTIMESCB		stSendCBFunc,
			 			VOID *			pvLinkId);

static INT	ptp_send_L4V4(UCHAR			uchPort,
			 			  UCHAR			uchTraClsNo,
			 			  UCHAR *		puchMsgPtr,
			 			  USHORT		usMsgLen,
						  INT			nSocketDesc,
						  USHORT		usPort);

static INT	ptp_send_L4V6(UCHAR			uchPort,
			 			  UCHAR			uchTraClsNo,
			 			  UCHAR *		puchMsgPtr,
			 			  USHORT		usMsgLen,
						  INT			nSocketDesc,
						  USHORT		usPort);
VOID sub_useradjustTime_once(	NX_LONGLONG*	pllOffset, 
								DOUBLE*			pdbFreqRate, 
								DELAYINFO* 		pstDelyInfo, 
								USCALEDNS* 		pstNeigqhborPropDelay, 
								ULONG 			ulPropDelayNumber,
								NX_USHORT		usPortNum);
NX_VOID sub_useradjustTime_Average(		NX_LONGLONG*	pllOffset,
									 	NX_DOUBLE*		pdbFreqRate,
									 	DELAYINFO*		pstDelyInfo,
									 	USCALEDNS*		pstNeigqhborPropDelay,
									 	NX_ULONG 		ulPropDelayNumber,
									 	NX_USHORT 		usPortNum,
									 	NX_UCHAR		uchDomainNumber);
NX_VOID vTsn_AverageProcessing(NX_DOUBLE* pdbFreqRate, DELAYINFO* pstDelyInfo, USCALEDNS* pstNeighborPropDelay, NX_USHORT usPortNum, NX_UCHAR uchDomainNumber);
NX_VOID vTsn_CalcSum(ST_AVE_TMSP_96T* pstSum,ST_AVE_TMSP_64T* pstNew,ST_AVE_TMSP_64T* pstOld);
NX_VOID vTsn_TimeDivide96(NX_ULONGLONG* pullResult, ST_AVE_TMSP_96T* pstTimestamp, NX_ULONG ulTblNum);
NX_VOID vTsn_ROUNDING_3down_4up(NX_ULONGLONG ullInputTime, NX_ULONGLONG* pullResult);
NX_VOID vTsn_SetRegister_SnAdjCnt(NX_DOUBLE* pdbFreqRate);
NX_LONG lTsn_ChkAdjustDomain (PARENT_DS *pstDomainParentDS);
NX_VOID  vTsn_RstAverageProcessing (NX_UCHAR uchDomainNumber);
NX_LONG  lTsn_ChkClockRateValid (DELAYINFO* pstDelyInfo, NX_UCHAR uchDomainNumber);
#if REC_TSN_INF
#define INDEX_OFFSET_MAX 300
NX_ULONG gulDbgFlg;


typedef struct PTP_ADJUST_REC_TAG {
	NX_ULONG ulIndex_offset;
	NX_ULONG ulisGMs[INDEX_OFFSET_MAX];
	NX_ULONG ulPortRole1[INDEX_OFFSET_MAX];
	NX_ULONG ulPortRole2[INDEX_OFFSET_MAX];
	NX_ULONG ulDLINKSts[INDEX_OFFSET_MAX];
	NX_LONGLONG llOffsets[INDEX_OFFSET_MAX];
	NX_ULONGLONG ullNeighborPropDelays[INDEX_OFFSET_MAX];
	NX_ULONGLONG ullSyncSendTimes[INDEX_OFFSET_MAX];
} PTP_ADJUST_REC;

PTP_ADJUST_REC gstPTP_AdjustRecord;

#endif

void ptp_GetDetailCurrentTime(USCALEDNS* pstDetailCurTime) 
{
	EXTENDEDTIMESTAMP stTimeStamp;
	NX_ULONG ulFrcNsec;
	NX_ULONG ulFrcSec;
	
	gulTSN_GetFreeRunCnt(NX_ON, &ulFrcSec, &ulFrcNsec);
	stTimeStamp.stNsec.usFrcNsec 	= (USHORT) 0;
	stTimeStamp.stNsec.ulNsec 		= ulFrcNsec;
	stTimeStamp.stSec.ulSec_lsb		= ulFrcSec;
	stTimeStamp.stSec.usSec_msb 	= (USHORT) 0;
	ptpConvETS_USNs(&stTimeStamp,pstDetailCurTime);
}
void ptp_GetDetailCurrentClockTime(USCALEDNS* pstDetailCurTime){
	EXTENDEDTIMESTAMP stTimeStamp;					
	NX_ULONG ulSec_lsb;
	NX_ULONG ulNsec;
	
	gulTSN_GetTimeCnt(NX_ON, &ulSec_lsb, &ulNsec);
	
	stTimeStamp.stNsec.usFrcNsec = (USHORT) 0;
	stTimeStamp.stNsec.ulNsec = ulNsec;
	stTimeStamp.stSec.ulSec_lsb = ulSec_lsb;
	stTimeStamp.stSec.usSec_msb = (USHORT) 0;
	ptpConvETS_USNs(&stTimeStamp,pstDetailCurTime);

}
VOID vPTP_CopyMemory (
	VOID*		pvDst,
	const VOID*		pvSrc,
	ULONG		ulSize
)
{
	CHAR*	pchDst;
	CHAR*	pchSrc;
	ULONG	ulLoop;
	
	pchDst = (CHAR*)pvDst;
	pchSrc = (CHAR*)pvSrc;
	
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*pchDst = *pchSrc;
		
		pchDst++;
		pchSrc++;
	}
}
NX_VOID vPTP_FillMemory (
	VOID*		pvDst,
	CHAR		chData,
	ULONG		ulSize
)	
{
	CHAR*	pchDst;
	ULONG	ulLoop;
	pchDst = (CHAR*)pvDst;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		*pchDst = chData;
		pchDst++;
	}
}
VOID*	tsn_Wrapper_MemCpy(
		VOID *pvDst,
		const VOID *pvSrc,
		size_t iN
	)
{
	vPTP_CopyMemory(pvDst,pvSrc,iN);
	return 0;
}
VOID*	tsn_Wrapper_MemSet(
		VOID *pvBuf,
		INT iCh,
		size_t iN
	)
{
	vPTP_FillMemory(pvBuf, (CHAR)iCh, iN);
	return 0;
}
INT	tsn_Wrapper_LockCreate(VOID **pvLockHandle)
{
	INT	lRet;
	lRet = RET_ENOERR;
	if (gstTsnStatusMng.ul_SEM_Counter == 0) {
		*pvLockHandle = (VOID*)SEMID_NX_TSN_1;	
		
	} else if (gstTsnStatusMng.ul_SEM_Counter == 1) {
		*pvLockHandle = (VOID*)SEMID_NX_TSN_2;	
	}
	else {
							
		lRet = RET_ENOERR + 1;
	}
	gstTsnStatusMng.ul_SEM_Counter++;
	return lRet;
}
INT	tsn_Wrapper_LockDelete(VOID *pvLockHandle)
{
	INT			lRet;

	lRet = RET_ENOERR;
	
	del_sem(*(ID*)pvLockHandle);
	
	return lRet;
}
INT	tsn_Wrapper_LockWait(VOID *pvLockHandle)
{
	INT			lRet;
	
	lRet = RET_ENOERR;
	wai_sem((ID)pvLockHandle);
	
	return lRet;
}
INT	tsn_Wrapper_Lock(VOID *pvLockHandle)
{
	ER			lResult;
	INT			lRet;
	
	
	lRet = RET_ENOERR;
	
	lResult = pol_sem((ID)pvLockHandle);
	if (lResult == E_TMOUT) {
		lRet = -1;
	}
	
	return lRet;
}
LONG tsn_Wrapper_UnLock(VOID *pvLockHandle)
{
	INT			lRet;
	
	lRet = RET_ENOERR;
	
	sig_sem((ID)pvLockHandle);
	
	return lRet;

}
INT tsn_Wrapper_MemCmp(const VOID * pvBuf1, const VOID * pvBuf2, size_t iN)
{
	UCHAR*	puchDataA;
	UCHAR*	puchDataB;
	ULONG	ulLoop;
	ULONG	ulSize = 0;
	LONG	lResult = 0;
	
	puchDataA = (UCHAR*)pvBuf1;
	puchDataB = (UCHAR*)pvBuf2;
	ulSize = (ULONG)iN;
	
	for (ulLoop = 0; ulLoop < ulSize; ulLoop++) {
		if (*puchDataA > *puchDataB) {
										
			lResult = 1;
			break;
		}
		else if (*puchDataA < *puchDataB) {
			
			lResult = -1;
			break;
		}
		else {
			
		}
		puchDataA++;
		puchDataB++;
	}
	return lResult;
}
INT	tsn_Wrapper_Rand(VOID) {
	INT a = 0;
	
	a = (INT)rand();
	
	return a;
}
VOID	tsn_Wrapper_RandInit(VOID) {
	srand(1);
	return;
}
DOUBLE tsn_Wrapper_Pow (DOUBLE dbX, DOUBLE dbY)
{
	DOUBLE	dbRet = 0;
	
	dbRet = pow(dbX, dbY);
	
	return dbRet;
}
VOID ptp_useradjust(UCHAR uchDomainNumber,SCALEDNS* pOffset, DOUBLE* dbFreqRate, UCHAR	uchPriDomainNumber)
{
}
VOID ptp_useradjust2 (UCHAR uchDomainNumber, SCALEDNS *pstOffset, DOUBLE* pdbFreqRate,
                      UCHAR uchPriDomainNumber, PARENT_DS* pstParentDS,
                      CURRENT_DS* pstCurrentDS, DELAYINFO* pstDelyInfo,
                      USCALEDNS* pstNeighborPropDelay, ULONG ulPropDelayNumber)
{
	NX_USHORT usPortNum = NX_ZERO;
	NX_LONG  lAdjustDomain	 		= 	NX_ZERO;
	NX_LONG	lClockRateValid 	= (NX_LONG)NX_OK;

	
	NX_LONGLONG llOffset;
	NX_SHORT sOffset_highest = pstOffset->sNsec_msb;
	NX_ULONG ulOffset_high	= pstOffset->ulNsec_2nd;
	NX_ULONG ulOffset_low 	= pstOffset->ulNsec_lsb;

	ENUM_SELECTEDSTATE enState;
	
#if TSN_LOG_ADJUST
	vADJUSTLOG_go_next();
#endif
	
	NX_ULONG ulSynxSendTime_high = pstDelyInfo->stDelayTimeInfo.stDelayInfo_P2P.stSyncOriginTimeStamp.stSeconds.ulSec_lsb;
	NX_ULONG ulSynxSendTime_low = pstDelyInfo->stDelayTimeInfo.stDelayInfo_P2P.stSyncOriginTimeStamp.ulNanoseconds;
	NX_ULONGLONG ullSyncSendTime = (NX_ULONGLONG)ulSynxSendTime_high *CONVERTER_NStoS + (NX_ULONGLONG)ulSynxSendTime_low;
	NX_ULONGLONG ullNeighborPropDelay;
	NX_ULONG ulIndex_offset = NX_ZERO;
	NX_ULONG ulNeighborPropDelay_high = pstNeighborPropDelay->ulNsec_2nd;
	NX_ULONG ulNeighborPropDelayt_low = pstNeighborPropDelay->ulNsec_lsb;
	
	if(gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp == NX_ON){
		enState = gpstClockDataHPtr->stClock_GD.enSelectedState[0];
		if(PS_EX_SLAVE == enState){	
			vNMG_AdjustTsnTimeCmp();
			gstTsnStatusMng.ulTSN_Status = NX_OK;
			gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp = NX_OFF;
			gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
			gstNET.stPtp.ulPtpSts = PTPSTS_RUNNING;
			gstNM.stNet.ulTimeSetFlg = (NX_ULONG)NX_ON;
		}
	}
	if (gstTsnStatusMng.ulTSN_BMCA_Status == NX_UL_OK){
		lAdjustDomain = lTsn_ChkAdjustDomain(pstParentDS);
		
		if (lAdjustDomain == NX_NG) {
			
			if (gstTsnStatusMng.auchFlg_AverageProcessingLastTime[uchDomainNumber] == (NX_UCHAR)NX_ON) {
				vTsn_RstAverageProcessing(uchDomainNumber);
				
				gstTsnStatusMng.auchFlg_AverageProcessingLastTime[uchDomainNumber]	=	(NX_UCHAR)NX_OFF;
			}
#if TSN_LOG_ADJUST
			vADJUSTLOG_useradjust2(	USERADJST2_RESULT_NOTDMAIN,
									uchDomainNumber,
									pstOffset,
									pdbFreqRate, 
									uchPriDomainNumber,
									pstParentDS,
									pstCurrentDS,
									pstDelyInfo,
									pstNeighborPropDelay,
									ulPropDelayNumber);
#endif
			return;
		}
		else {
			gstTsnStatusMng.auchFlg_AverageProcessingLastTime[uchDomainNumber]		=	(NX_UCHAR)NX_ON;
		}
	}
	else {
	}

	if((sOffset_highest != (NX_SHORT)0x0)&&(sOffset_highest != (NX_SHORT)0xFFFF)){
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_OFFSET_OVER,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		return;
	}
	llOffset = (NX_LONGLONG)(((NX_ULONGLONG)(ulOffset_high) << 32) | (NX_ULONGLONG)(ulOffset_low));

#if REC_TSN_INF	
	if(gulDbgFlg == NX_ON){
		ulIndex_offset = gstPTP_AdjustRecord.ulIndex_offset;
		ullNeighborPropDelay = ((NX_ULONGLONG)(ulNeighborPropDelay_high) << 32) | (NX_ULONGLONG)(ulNeighborPropDelayt_low);
		gstPTP_AdjustRecord.llOffsets[ulIndex_offset] = llOffset;
		gstPTP_AdjustRecord.ullNeighborPropDelays[ulIndex_offset] = ullNeighborPropDelay;
		gstPTP_AdjustRecord.ullSyncSendTimes[ulIndex_offset] = ullSyncSendTime;
		
		gstPTP_AdjustRecord.ulisGMs[ulIndex_offset] = (NX_ULONG)gpstClockDataHPtr->stClock_GD.enSelectedState[0];
		gstPTP_AdjustRecord.ulPortRole1[ulIndex_offset] = (NX_ULONG)gpstClockDataHPtr->stClock_GD.enSelectedState[1];
		gstPTP_AdjustRecord.ulPortRole2[ulIndex_offset] = (NX_ULONG)gpstClockDataHPtr->stClock_GD.enSelectedState[2];
		gstPTP_AdjustRecord.ulDLINKSts[ulIndex_offset] = gstNM.stNet.usNetSts;
		if(ulIndex_offset == (INDEX_OFFSET_MAX-1)){
			gstPTP_AdjustRecord.ulIndex_offset = 0;
		}else{
			gstPTP_AdjustRecord.ulIndex_offset++;	
		}
	}
#endif

	if(*pdbFreqRate == (NX_DOUBLE)NX_ZERO){
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_OFFSET_OVER,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		return;
	}
	
	usPortNum = pstDelyInfo->usSlavePortNumber;
	if(usPortNum == (NX_USHORT)NX_ONE || usPortNum == (NX_USHORT)NX_TWO){
		usPortNum -= (NX_USHORT)NX_ONE;
	}else{
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_PORTNUM_WRONG,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		return;
	}

	lClockRateValid = lTsn_ChkClockRateValid(pstDelyInfo, uchDomainNumber);


	if ((NGN_CN_TS_P1_REG->R_TCPXTON.DATA & 0x00000100) != 0x00000100) {
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_ADJUST_ONCE,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		sub_useradjustTime_once(&llOffset, pdbFreqRate, pstDelyInfo, pstNeighborPropDelay, ulPropDelayNumber, usPortNum);
	}else if((NGN_CN_TS_P1_REG->R_TCPXTON.DATA & 0x00000100) == 0x00000100){
	
		if (lClockRateValid == (NX_LONG)NX_NG) {
#if TSN_LOG_ADJUST
			vADJUSTLOG_useradjust2(	USERADJST2_RESULT_CLOCK_RATE_INVALID,
									uchDomainNumber,
									pstOffset,
									pdbFreqRate, 
									uchPriDomainNumber,
									pstParentDS,
									pstCurrentDS,
									pstDelyInfo,
									pstNeighborPropDelay,
									ulPropDelayNumber);
#endif
			return;
		}
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_ADJUST_AVERAGE,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		sub_useradjustTime_Average(&llOffset, pdbFreqRate, pstDelyInfo, pstNeighborPropDelay, ulPropDelayNumber, usPortNum, uchDomainNumber);
	}else{
		pstOffset->sNsec_msb = 0;
		pstOffset->ulNsec_2nd = 0;												
		pstOffset->ulNsec_lsb = 0;		
		pstOffset->usFrcNsec = 0;
#if TSN_LOG_ADJUST
		vADJUSTLOG_useradjust2(	USERADJST2_RESULT_TSLT_ENDIS,
								uchDomainNumber,
								pstOffset,
								pdbFreqRate, 
								uchPriDomainNumber,
								pstParentDS,
								pstCurrentDS,
								pstDelyInfo,
								pstNeighborPropDelay,
								ulPropDelayNumber);
#endif
		return;
	}
	
	if(llOffset < 0){
		pstOffset->sNsec_msb  = 0xFFFF;
	}else{
		pstOffset->sNsec_msb = 0x0;
	}
	pstOffset->ulNsec_2nd = (NX_LONG)(llOffset >> 32);
	pstOffset->ulNsec_lsb = (NX_LONG)(llOffset & 0x00000000FFFFFFFF);
	pstOffset->usFrcNsec  = 0;
	
	if(gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp == NX_ON){
		if ( ((pstDelyInfo->enClockDelay != DELAY_P2P) && (pstDelyInfo->enClockDelay != DELAY_E2E))
		||   (lClockRateValid == (NX_LONG)NX_NG)) {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
		}
		else if (llOffset < ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting * -1)) {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
		}
		else if (llOffset > (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting) {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
		}else{
			gstTsnStatusMng.ulOffset_Stable_CurrentTime++;
		}
		if(gstTsnStatusMng.ulOffset_Stable_CurrentTime >= gstTsnStatusMng.ulOffsetStabletime){
			vNMG_AdjustTsnTimeCmp();
			gstTsnStatusMng.ulTSN_Status = NX_OK;
			gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp = NX_OFF;
			gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
			gstNET.stPtp.ulPtpSts = PTPSTS_RUNNING;
			gstNM.stNet.ulTimeSetFlg = (NX_ULONG)NX_ON;
		}
	}
	return;
}


VOID sub_useradjustTime_once(NX_LONGLONG *pllOffset, DOUBLE *pdbFreqRate, DELAYINFO* pstDelyInfo, USCALEDNS* pstNeigqhborPropDelay, ULONG ulPropDelayNumber, USHORT usPortNum)
{
	ULONG	ulTiming_Ns			= NX_ZERO;
	ULONG	ulTiming_S			= NX_ZERO;
	ULONG	ulCurrentTime_Ns	= NX_ZERO;
	ULONG	ulCurrentTime_S		= NX_ZERO;
	NX_ULONGLONG ullTiming		= NX_ZERO;
	NX_ULONGLONG ullCurrentTime = NX_ZERO;
	NX_ULONGLONG ullCycleStart 	= NX_ZERO;
	NX_ULONGLONG ullTimingOffset= NX_ZERO;
	NX_ULONGLONG ullAdjustTiming= NX_ZERO;
	NX_ULONGLONG ullAdjustTime 	= NX_ZERO;
	NX_ULONGLONG ullShiftTime 	= NX_ZERO;
	NX_ULONGLONG ullPropDelay	= NX_ZERO;
	NX_ULONGLONG ullAdjustTime_Round = NX_ZERO;
	NX_ULONGLONG ullAdjustTiming_Round = NX_ZERO;
	
	NX_ULONGLONG ullSyncRcvTime		= NX_ZERO;
	NX_ULONG ulSyncRcvTime_NS		= NX_ZERO;
	NX_ULONG ulSyncRcvTime_S		= NX_ZERO;
	NX_ULONGLONG ullSyncRcvFreeCnt	= NX_ZERO;
	NX_ULONG ulSyncRcvFreeCnt_NS	= NX_ZERO;
	NX_ULONG ulSyncRcvFreeCnt_S		= NX_ZERO;
	NX_ULONG ulCounterSts			= NX_ZERO;
#if TSN_LOG_ADJUST
	NX_ULONGLONG	ullWindowCheck	=	(NX_ULONGLONG)NX_ZERO;
	NX_LONGLONG		llOffsetWindow	=	(NX_LONGLONG)NX_ZERO;
#endif

	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();

	NGN_SN_REG->R_SNCTR.DATA		=	(NX_ULONG)0x00000103;

	gulTSN_GetFreeRunCnt(NX_OFF, &ulTiming_S, &ulTiming_Ns);
	ulSyncRcvFreeCnt_S = gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S;
	ulSyncRcvFreeCnt_NS = gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS;

	ulSyncRcvTime_S = gastTsnCtrl[usPortNum].ulSyncRcvTime_S;
	ulSyncRcvTime_NS = gastTsnCtrl[usPortNum].ulSyncRcvTime_NS;	

	ullTiming = (NX_ULONGLONG)ulTiming_S * CONVERTER_NStoS + ulTiming_Ns;
	ullSyncRcvTime = (NX_ULONGLONG)ulSyncRcvTime_S * CONVERTER_NStoS + ulSyncRcvTime_NS;
	ullSyncRcvFreeCnt = (NX_ULONGLONG)ulSyncRcvFreeCnt_S * CONVERTER_NStoS + ulSyncRcvFreeCnt_NS;

	ullCurrentTime = ullSyncRcvTime + (NX_ULONGLONG)((NX_DOUBLE)(ullTiming - ullSyncRcvFreeCnt) / gdbCurrentFreqRate) ;
	if ((NGN_CN_TS_P1_REG->R_TCPXTON.DATA & 0x00000100) == 0x00000100) {
		if (*pllOffset < ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting * -1)) {
			*pllOffset = ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting * -1);
		}
		else if (*pllOffset > (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting) {
			*pllOffset = (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting;
		}
	}
	ullCycleStart = (ullCurrentTime / gstNET.stPtp.ullComCycle) * (gstNET.stPtp.ullComCycle) ;
	ullShiftTime = ullCycleStart + gstNET.stPtp.ullTimeAdjustOffset;
	
	ullTimingOffset = ullShiftTime - ullCurrentTime;
	
	ullAdjustTiming = ullTiming + (NX_ULONGLONG)((NX_DOUBLE)ullTimingOffset * gdbCurrentFreqRate);
		
	
	ullAdjustTime = ullShiftTime + *pllOffset;
	
#if 1
	if((ullAdjustTiming % 8) >= 4){
		ullAdjustTiming_Round = (ullAdjustTiming & ADJUST_ASIC_FILTER) + ONE_CLOCK_NS;
	}else{
		ullAdjustTiming_Round = ullAdjustTiming & ADJUST_ASIC_FILTER;
	}
	ullAdjustTime += ullAdjustTiming_Round - ullAdjustTiming;

#endif
#if 1
	if((ullAdjustTime % 8) >= 4){
		ullAdjustTime_Round = (ullAdjustTime & ADJUST_ASIC_FILTER) + ONE_CLOCK_NS;
	}else{
		ullAdjustTime_Round = ullAdjustTime & ADJUST_ASIC_FILTER;
	}
	ullAdjustTime_Round = ullAdjustTime_Round + ONE_CLOCK_NS;
#endif
				
	vTsn_SetRegister_SnAdjCnt(pdbFreqRate);
	gdbCurrentFreqRate = *pdbFreqRate;

		
																												;
		
																												;


	ulCounterSts = NGN_SN_REG->R_SNTMSTS.BITS.b01ZTimeCntStat;
	if (ulCounterSts == (NX_ULONG)NX_ZERO) {
		NGN_SN_REG->R_SNTM0 = (NX_ULONG)(ullAdjustTime_Round % CONVERTER_NStoS);
		NGN_SN_REG->R_SNTM1 = (NX_ULONG)(ullAdjustTime_Round / CONVERTER_NStoS);
																													;
		NGN_SN_REG->R_SNTMUP0 = (NX_ULONG)(ullAdjustTiming_Round % CONVERTER_NStoS);
		NGN_SN_REG->R_SNTMUP1 = (NX_ULONG)(ullAdjustTiming_Round / CONVERTER_NStoS);
		
		NGN_SN_REG->R_SNTMUPD.BITS.b01ZTimeCntAdj = NX_ON;
	}
	else {
	}
	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();
#if TSN_LOG_ADJUST
	vADJUSTLOG_sub_useradjustTime_Once (
			ullAdjustTiming_Round,
			ullAdjustTime_Round
	);
#endif
}
NX_VOID sub_useradjustTime_Average(NX_LONGLONG *pllOffset, DOUBLE *pdbFreqRate, DELAYINFO* pstDelyInfo,
                                   USCALEDNS* pstNeigqhborPropDelay, ULONG ulPropDelayNumber, NX_USHORT usPortNum, UCHAR uchDomainNumber)
{
	ULONG	ulTiming_Ns			= NX_ZERO;
	ULONG	ulTiming_S			= NX_ZERO;
	NX_ULONGLONG ullTiming		= NX_ZERO;
	NX_ULONGLONG ullCurrentTime = NX_ZERO;
	NX_ULONGLONG ullAdjustTiming= NX_ZERO;
	NX_ULONGLONG ullAdjustTime 	= NX_ZERO;
		
	NX_ULONGLONG ullSyncRcvTime		= NX_ZERO;
	NX_ULONG ulSyncRcvTime_NS		= NX_ZERO;
	NX_ULONG ulSyncRcvTime_S		= NX_ZERO;
	NX_ULONGLONG ullSyncRcvFreeCnt	= NX_ZERO;
	NX_ULONG ulSyncRcvFreeCnt_NS	= NX_ZERO;
	NX_ULONG ulSyncRcvFreeCnt_S		= NX_ZERO;
	
	NX_LONGLONG llOffset;

	NX_ULONGLONG ullAdjustTime_Pre 	= NX_ZERO;
	
	NX_ULONGLONG ullRoundResult_Time 	= NX_ZERO;
	NX_ULONGLONG ullRoundResult_FrnCnt 	= NX_ZERO;
	
	NX_ULONG ulTrueTimeHigh 		= NX_ZERO;
	NX_ULONG ulTrueTimeLow 			= NX_ZERO;
	NX_ULONG ulUpdateTimeHigh 		= NX_ZERO;
	NX_ULONG ulUpdateTimeLow 		= NX_ZERO;
#if TSN_LOG_ADJUST
	NX_ULONGLONG	ullWindowCheck	=	(NX_ULONGLONG)NX_ZERO;
	NX_LONGLONG		llOffsetRaw		=	(NX_LONGLONG)NX_ZERO;
	NX_LONGLONG		llOffsetWindow	=	(NX_LONGLONG)NX_ZERO;
#endif
	NX_ULONGLONG	ullSyncRcvFreeCntNow 		= (NX_ULONGLONG)NX_ZERO;
	NX_ULONGLONG	ullElapsedTimeSinceSyncRcv 	= (NX_ULONGLONG)NX_ZERO;

	
	NX_ULONGLONG ullOffset_abs		= NX_ZERO;
	NX_ULONG ulCounterSts			= NX_ZERO;
	ullSyncRcvFreeCntNow = (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S * CONVERTER_NStoS + (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS;
	if (gaullSyncRcvFreeCntPre[uchDomainNumber] != (NX_ULONGLONG)NX_ZERO) {
		ullElapsedTimeSinceSyncRcv = ullSyncRcvFreeCntNow - gaullSyncRcvFreeCntPre[uchDomainNumber];
		if (ullElapsedTimeSinceSyncRcv > gstTsnStatusMng.ullAveRstTimeout) {
			vTsn_RstAverageProcessing(uchDomainNumber);
		}
		else {
		}
	}
	gaullSyncRcvFreeCntPre[uchDomainNumber] = ullSyncRcvFreeCntNow;
	vTsn_AverageProcessing(pdbFreqRate, pstDelyInfo, pstNeigqhborPropDelay, usPortNum, uchDomainNumber);
	NGN_SN_REG->R_SNCTR.DATA		=	(NX_ULONG)0x00000103;
	
	gulTSN_GetFreeRunCnt(NX_ON, &ulTiming_S, &ulTiming_Ns);
	ullTiming = (NX_ULONGLONG)ulTiming_S * CONVERTER_NStoS + (NX_ULONGLONG)ulTiming_Ns;
	ullAdjustTime = (gastAveragingRslt[uchDomainNumber].ullAveSyncSend + gastAveragingRslt[uchDomainNumber].ullAveNeighborPropDelay)
					 + (NX_ULONGLONG)((DOUBLE)(ullTiming - gastAveragingRslt[uchDomainNumber].ullAveSyncReceive_Frun) / (*pdbFreqRate));
	ullAdjustTiming = ullTiming;

	ulSyncRcvTime_S = gastTsnCtrl[usPortNum].ulSyncRcvTime_S;
	ulSyncRcvTime_NS = gastTsnCtrl[usPortNum].ulSyncRcvTime_NS;
	ullSyncRcvTime = (NX_ULONGLONG)ulSyncRcvTime_S * CONVERTER_NStoS + ulSyncRcvTime_NS;

	ulSyncRcvFreeCnt_S = gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S;
	ulSyncRcvFreeCnt_NS = gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS;
	ullSyncRcvFreeCnt = (NX_ULONGLONG)ulSyncRcvFreeCnt_S * CONVERTER_NStoS + ulSyncRcvFreeCnt_NS;
	
	ullCurrentTime = ullSyncRcvTime + (NX_ULONGLONG)((NX_DOUBLE)(ullTiming - ullSyncRcvFreeCnt) / gdbCurrentFreqRate);
	
	llOffset =  (NX_LONGLONG)(ullAdjustTime - (ullCurrentTime + (ullAdjustTiming - ullTiming)));

	if(ullAdjustTime >= ullCurrentTime){
		ullOffset_abs = ullAdjustTime - ullCurrentTime;
		if(ullOffset_abs < (NX_ULONGLONG)ST_SYN_LONGLONG_MAX_ABS){
			llOffset = (NX_ULONGLONG)ullOffset_abs;
		}
		else{
			llOffset = (NX_LONGLONG)ST_SYN_LONGLONG_MAX_ABS;
		}
	}
	else{
		ullOffset_abs = ullCurrentTime - ullAdjustTime;
		if(ullOffset_abs < (NX_ULONGLONG)ST_SYN_LONGLONG_MIN_ABS){
			llOffset = (-1) * (NX_LONGLONG)ullOffset_abs;
		}
		else{
			llOffset = (NX_LONGLONG)ST_SYN_LONGLONG_MIN_ABS;
		}
	}





#if REC_TSN_INF
	if(llOffset >= 0){
		ullOffset_abs = (NX_ULONG)llOffset;
	}else if(llOffset < 0){
		ullOffset_abs = (NX_ULONG)(llOffset * -1);
	}

	vNX_vDisableDispatch();
	vNX_vDisableInterrupt();
	
	gstTsnRecord.llOffset_Latest = llOffset;
	if(gstTsnRecord.ullOffset_Max < ullOffset_abs){
		gstTsnRecord.ullOffset_Max = ullOffset_abs;
	}else if((gstTsnRecord.ullOffset_Min > ullOffset_abs) && (ullOffset_abs != NX_ZERO)){
		gstTsnRecord.ullOffset_Min = ullOffset_abs;
	}
	vNX_vEnableInterrupt();
	vNX_vEnableDispatch();
#endif

	if(gstTsnStatusMng.ulTsnWindowFlg == NX_OFF){
		if(llOffset > (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting){
			gstTsnStatusMng.ulTimesOfConsecutiveOutliers++;

#if REC_TSN_INF		
			gstTsnRecord.ulTsnWindowFlg = NX_ON;
			gulDbgFlg = NX_OFF;
#endif
			
#if TSN_LOG_ADJUST
			ullWindowCheck	=	1;
#endif
		
		}else if(llOffset < ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting)*(-1)){
			gstTsnStatusMng.ulTimesOfConsecutiveOutliers++;

#if REC_TSN_INF		
			gstTsnRecord.ulTsnWindowFlg = 0x3;
			gulDbgFlg = NX_OFF;
#endif
			
#if TSN_LOG_ADJUST
			ullWindowCheck	=	2;
#endif
			
		}else {
			gstTsnStatusMng.ulTimesOfConsecutiveOutliers = NX_ZERO;
			
#if TSN_LOG_ADJUST
			ullWindowCheck	=	0;
#endif
			
		}
		if(gstTsnStatusMng.ulTimesOfConsecutiveOutliers >= (NX_ULONG)gstNcfTsnInf.uchThresholdOfConsecutiveOutliers){
			gstTsnStatusMng.ulTsnWindowFlg = NX_ON;
		}
	}
	
	if(llOffset > gstNET.stPtp.llMLAdjustLength){
		ullAdjustTime -= (llOffset - gstNET.stPtp.llMLAdjustLength);
		
#if TSN_LOG_ADJUST
		llOffsetWindow = gstNET.stPtp.llMLAdjustLength;
#endif
		
	}else if(llOffset < (gstNET.stPtp.llMLAdjustLength*(-1))){
	 	ullAdjustTime -= (llOffset + gstNET.stPtp.llMLAdjustLength);
#if TSN_LOG_ADJUST
		llOffsetWindow = gstNET.stPtp.llMLAdjustLength;
#endif
	}else{
		
#if TSN_LOG_ADJUST
		llOffsetWindow = llOffset;
#endif
		
	}
	
	
	ullAdjustTime_Pre = ullAdjustTime;
	ullAdjustTime = (ullAdjustTime_Pre / gstNET.stPtp.ullComCycle) * gstNET.stPtp.ullComCycle;
	ullAdjustTime += gstNET.stPtp.ullTimeAdjustOffset;

	vTsn_ROUNDING_3down_4up(ullAdjustTime, &ullRoundResult_Time);
	
	ullAdjustTiming += (NX_ULONGLONG)((NX_DOUBLE)(ullAdjustTime - ullAdjustTime_Pre) * gdbCurrentFreqRate);
	vTsn_ROUNDING_3down_4up(ullAdjustTiming + (ullRoundResult_Time - ullAdjustTime), &ullRoundResult_FrnCnt);

	ulUpdateTimeHigh = ullRoundResult_FrnCnt / (1000ULL * 1000ULL * 1000ULL);
	ulUpdateTimeLow = ullRoundResult_FrnCnt % (1000ULL * 1000ULL * 1000ULL);
	
	ullRoundResult_Time += (NX_ULONGLONG)ONE_CLOCK_NS;
	ulTrueTimeHigh = ullRoundResult_Time / (1000ULL * 1000ULL * 1000ULL);
	ulTrueTimeLow = ullRoundResult_Time % (1000ULL * 1000ULL * 1000ULL);
	
	vTsn_SetRegister_SnAdjCnt(pdbFreqRate);
	gdbCurrentFreqRate = *pdbFreqRate;



	ulCounterSts = NGN_SN_REG->R_SNTMSTS.BITS.b01ZTimeCntStat;
	if (ulCounterSts == (NX_ULONG)NX_ZERO) {
		NGN_SN_REG->R_SNTM0 = ulTrueTimeLow;
		NGN_SN_REG->R_SNTM1 = ulTrueTimeHigh;
		NGN_SN_REG->R_SNTMUP0 =ulUpdateTimeLow;
		NGN_SN_REG->R_SNTMUP1 = ulUpdateTimeHigh;
		NGN_SN_REG->R_SNTMUPD.BITS.b01ZTimeCntAdj = NX_ON;
	}
	else {
	}

	if (gstTsnStatusMng.ulFlg_OutOfTimeSync == (NX_ULONG)NX_ON) {
		if ((llOffset < ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting * -1)) ||
			(llOffset > (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting)) {
			gstTsnStatusMng.ulFlg_OutOfTimeSync		= (NX_ULONG)NX_OFF;
			gulOutOfTimeSyncSts = NX_TIMESYNC_CHK_NG;
		}
		else {
			gulOutOfTimeSyncSts = NX_TIMESYNC_CHK_OK;
		}
	}
	else {
	}
#if TSN_LOG_ADJUST
	vADJUSTLOG_sub_useradjustTime_Average (
			gastAveragingRslt[uchDomainNumber].ullAveSyncSend,
			gastAveragingRslt[uchDomainNumber].ullAveNeighborPropDelay,
			gastAveragingRslt[uchDomainNumber].ullAveSyncReceive_Frun,
			*pdbFreqRate,
			ullWindowCheck,
			llOffset,
			llOffsetWindow,
			ullRoundResult_FrnCnt,
			ullRoundResult_Time
	);
#endif

	if (gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp2 == NX_ON) {
		if (llOffset < ((NX_LONGLONG)gstNcfTsnInf.ulWindowSetting * -1)) {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime2 = NX_ZERO;
		}
		else if (llOffset > (NX_LONGLONG)gstNcfTsnInf.ulWindowSetting) {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime2 = NX_ZERO;
		}
		else {
			gstTsnStatusMng.ulOffset_Stable_CurrentTime2++;
		}
		if (gstTsnStatusMng.ulOffset_Stable_CurrentTime2 >= gstTsnStatusMng.ulOffsetStabletime){
			gstTsnStatusMng.ulFlg_OutOfTimeSync = (NX_ULONG)NX_ON;
			gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp2 = NX_OFF;
			gstTsnStatusMng.ulOffset_Stable_CurrentTime2 = NX_ZERO;
		}
	}
}
NX_LONG lTsn_ChkAdjustDomain (PARENT_DS *pstDomainParentDS)
{
	NX_LONG		lRet	=	NX_NG;
	
	lRet = lNX_CompareMemory(gstTsnStatusMng.auchBMCACompClockIdentity, &pstDomainParentDS->stGrandmasterIdentity, sizeof(NX_UCHAR[8]));
	
	return lRet;
}
NX_LONG lTsn_ChkClockRateValid (DELAYINFO* pstDelyInfo, NX_UCHAR uchDomainNumber)
{
	NX_LONG	lResult = (NX_LONG)NX_NG;
	
	if(DELAY_P2P == pstDelyInfo->enClockDelay){
		
		if (pstDelyInfo->stDelayTimeInfo.stDelayInfo_P2P.blClockRateValid == FALSE) {
			if (gstTsnStatusMng.aulClockRateValidPre[uchDomainNumber] == (NX_ULONG)NX_ON) {
				gaulST_AVE_SamplingNum_Delay[uchDomainNumber] 	=	(NX_ULONG)NX_ZERO;
				gaulST_AVE_Index_Delay[uchDomainNumber]	 		=	(NX_ULONG)NX_ZERO;
				vNX_FillMemory32(&gastST_Rec_NeighborPropDelay[uchDomainNumber][NX_ZERO], 		NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)*(NX_ULONG)ST_SYN_AVE_DELAY_SAMPLING_MAX	/ sizeof(NX_ULONG)));
				vNX_FillMemory32(&gastAveragingRslt[uchDomainNumber].ullAveNeighborPropDelay,	NX_L_ZERO, (sizeof(NX_ULONGLONG) 								 			/ sizeof(NX_ULONG)));
				vNX_FillMemory32(&gastST_AveCalc[uchDomainNumber].stSum_NeighborPropDelay,		NX_L_ZERO, (sizeof(ST_AVE_TMSP_96T)	 				  						/ sizeof(NX_ULONG)));
				vNX_FillMemory32(&gastST_AveCalc[uchDomainNumber].stLast_NeighborPropDelay,		NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)	 				  						/ sizeof(NX_ULONG)));
				
				if (gstNcfTsnInf.uchTimeSynchronizationMethod == (NX_UCHAR)TSN_IEEE1588) {
					gausFreqRateCnt[uchDomainNumber] 				=	(NX_USHORT)NX_ZERO;
					gaulFreqRateFullCntFlag[uchDomainNumber] 		=	(NX_ULONG)NX_ZERO;
					gadbFreqRateSum[uchDomainNumber] 				=	(NX_DOUBLE)NX_ZERO;
					gadbFreqRateAve[uchDomainNumber]	 			=	(NX_DOUBLE)NX_ZERO;
					gadbFreqRateForCalc_Oldest[uchDomainNumber]		=	(NX_DOUBLE)NX_ZERO;
					vNX_FillMemory32(&gadbFreqRateForCalc[uchDomainNumber][NX_ZERO], 			NX_L_ZERO, (sizeof(NX_DOUBLE)	*(NX_ULONG)ST_SYN_AVE_FREQRATE_SAMPING_MAX	/ sizeof(NX_ULONG)));
				}
			}
			gstTsnStatusMng.aulClockRateValidPre[uchDomainNumber] = (NX_ULONG)NX_OFF;
			lResult												  = (NX_LONG)NX_NG;
		}
		else {
			gstTsnStatusMng.aulClockRateValidPre[uchDomainNumber] = (NX_ULONG)NX_ON;
			lResult												  = (NX_LONG)NX_OK;
		}
	}
	else {
		lResult  = (NX_LONG)NX_OK;
	}
	return lResult;
}
NX_ULONG ulTsn_GetStatus(NX_VOID){
	return gstTsnStatusMng.ulTSN_Status;
}

static UCHAR gMacAddrNormal[ETHER_ADDRESS_LENGTH] = PTP_DSTMAC_NORMAL;
static UCHAR gMacAddrPdelay[ETHER_ADDRESS_LENGTH] = PTP_DSTMAC_PDELAY;
UCHAR msgBuffer[1518] ;
MACADDR *	pstMacAddr;

INT	layer2_open(USHORT		usMaxPort,
				MACADDR *	pstMacAddr)
{

	if ((usMaxPort < START_PORT_NO) || (MAX_PORT < usMaxPort) || (pstMacAddr == (MACADDR *)0))
	{
		return (RET_EINVAL);
	}

	if (gPtpLowWrapTbl.ulMagicNo == (ULONG)TM_GLOBAL_MAGIC_NUMBER)
	{
		if (gPtpLowWrapTbl.usState != PTPLWS_CLOSE)
		{
			
			return (RET_ESTATE);
		}
		vNX_FillMemory((void *)&gPtpLowWrapTbl,NX_ZERO, sizeof(gPtpLowWrapTbl));				
		gPtpLowWrapTbl.ulMagicNo = (ULONG)TM_GLOBAL_MAGIC_NUMBER;
		gPtpLowWrapTbl.nEventSocket = TM_SOCKET_ERROR;
		gPtpLowWrapTbl.nGeneralSocket = TM_SOCKET_ERROR;

	}
	else
	{
		vNX_FillMemory((void *)&gPtpLowWrapTbl, NX_ZERO, sizeof(gPtpLowWrapTbl));
		gPtpLowWrapTbl.ulMagicNo = (ULONG)TM_GLOBAL_MAGIC_NUMBER;
		gPtpLowWrapTbl.nEventSocket = TM_SOCKET_ERROR;
		gPtpLowWrapTbl.nGeneralSocket = TM_SOCKET_ERROR;

	}
	
	gPtpLowWrapTbl.usMaxPort = usMaxPort;
	gPtpLowWrapTbl.pvAddr = (VOID *)pstMacAddr;
	gPtpLowWrapTbl.usState = PTPLWS_L2OPEN;
	

	return (RET_ENOERR);
}
INT	layer2_close(VOID)
{
	if (	(gPtpLowWrapTbl.ulMagicNo != (ULONG)TM_GLOBAL_MAGIC_NUMBER)
		 || (gPtpLowWrapTbl.usState != PTPLWS_L2OPEN) )
	{
		return (RET_ESTATE);
	}
	

	gPtpLowWrapTbl.usState = PTPLWS_CLOSE;

	return (RET_ENOERR);
}
INT	layer4V4_open(USHORT	   usMaxPort,
				  ULONG		   ulNetMask,
				  IPV4ADDR *   pstIpv4Addr)
{
	return 0;
}
INT	layer4V4_close(VOID)
{
	return 0;
}
INT	layer4V6_open(USHORT	   usMaxPort,
				  ULONG		   ulPrefixLen,
				  IPV6ADDR *   pstIpv6Addr)
{
	return 0;
}
INT	layer4V6_close(VOID)
{
	return 0;
}
INT	ptp_send(UCHAR			uchPort,
			 UCHAR			uchTraClsNo,
			 UCHAR *		puchMsgPtr,
			 USHORT			usMsgLen,
			 SENDTIMESCB	stSendCBFunc,
			 VOID *			pvLinkId)
{
	INT			nErrorCode = 0;
	if (   (gPtpLowWrapTbl.usMaxPort < uchPort)
		|| ((uchTraClsNo < START_CLASS_NO)
		|| (MAX_TRAFFIC_CLASS < uchTraClsNo))
		|| (puchMsgPtr == (UCHAR *)0)
		|| ((usMsgLen < MIN_PTP_MSG)
		|| (MAX_PTP_MSG < usMsgLen)) )
	{
		return (RET_EINVAL);
	}
	
	if (   (gPtpLowWrapTbl.ulMagicNo != (ULONG)TM_GLOBAL_MAGIC_NUMBER))
	{
		return (RET_ESTATE);
	}

	if (gPtpLowWrapTbl.usState == PTPLWS_L2OPEN)
	{
		nErrorCode = ptp_send_L2(uchPort, uchTraClsNo, puchMsgPtr,
									usMsgLen, stSendCBFunc, pvLinkId);
		return (nErrorCode);
	}
	return (RET_EINVAL);

}
static INT	ptp_send_L2(UCHAR			uchPort,
			 			UCHAR			uchTraClsNo,
			 			UCHAR *			puchMsgPtr,
			 			USHORT			usMsgLen,
			 			SENDTIMESCB		stSendCBFunc,
			 			VOID *			pvLinkId)
{
	INT					nErrorCode = 0;
	NX_USHORT				usPacketLen;
	PTP_FRAME* pstPtpFrame;
	NCYC_TX_FRAME *pstNcycTcFrame = NULL;
	NX_LONG				lResult;
	NX_UCHAR uchMsgType = (UCHAR)(*puchMsgPtr) & (UCHAR)0x0F;
	PTP_CTRL 			*pstPtpInfo;

	usPacketLen = usMsgLen + (USHORT)ETHER_HEADER_SIZE;

	lResult = lTXN_AllocBuf_NonCycTx(NCYC_TXFRAME_TYPE_TSN, usPacketLen, &pstNcycTcFrame);
	
	
	if (lResult == NCYC_TX_BUF_RSLT_BUF_FULL) {
		return (1);
	}
	
	pstNcycTcFrame->usTsNo = NCYC_TXFRAME_TS2;
	pstNcycTcFrame->usPort = (USHORT) uchPort;
	pstNcycTcFrame->usRelFlg = 1;
	pstNcycTcFrame->usFramFormat = 0;
	pstNcycTcFrame->usHeaderSize = ETHER_HEADER_SIZE;
	pstNcycTcFrame->pvCbfunc = (NCYC_TX_CALLBACK)vTsn_Callback;
	pstNcycTcFrame->usDataSize = usMsgLen;
	
	
	pstPtpInfo = (PTP_CTRL*)&(pstNcycTcFrame->uchFreeData);
	
	pstPtpInfo->fpPTPCallback = stSendCBFunc;
	pstPtpInfo->pvLinkId = pvLinkId;
	pstPtpInfo->uchMsgType = uchMsgType;
	pstPtpInfo->uchPort = uchPort;
	pstPtpInfo->uchPtpProto = gstPtpCtrl.uchPtpProto;
	
	
	pstPtpFrame = (PTP_FRAME *)pstNcycTcFrame->auchData;
	
	if (gstPtpCtrl.uchPtpProto == TSN_IEEE802_1_AS) {
		
		vNX_CopyMemory(pstPtpFrame->ethDstAddr, gMacAddrPdelay, ETHER_ADDRESS_LENGTH);
	}
	else {	
		if(0){
			vNX_CopyMemory(pstPtpFrame->ethDstAddr, gMacAddrPdelay, ETHER_ADDRESS_LENGTH);
			
		}else{
			vNX_CopyMemory(pstPtpFrame->ethDstAddr, gMacAddrNormal, ETHER_ADDRESS_LENGTH);
		
		}
	}

	vNX_CopyMemory(pstPtpFrame->ethSrcAddr, gstAppInfo.stEthInfo.auchMacAddress, ETHER_ADDRESS_LENGTH);
	
	pstPtpFrame->ethType = PTP_ETHER_TYPE;
	
	vNX_CopyMemory(&pstPtpFrame->stPtpMsg, puchMsgPtr, usMsgLen);

	
	(VOID)vTXN_NotifyStore_TxNonCycBuf(NCYC_TXFRAME_TS2, pstNcycTcFrame);
	
#if TSN_LOG_FRAME
	vTSNFRAMELOG_setevent(TSNFRAMELOG_PTPSEND, (NX_ULONGLONG)pstNcycTcFrame->usPort, (NX_UCHAR*)(pstNcycTcFrame->auchData + pstNcycTcFrame->usHeaderSize));
#endif
	
	return (nErrorCode);
}

static INT	ptp_send_L4V4(UCHAR			uchPort,
			 			  UCHAR			uchTraClsNo,
			 			  UCHAR *		puchMsgPtr,
			 			  USHORT		usMsgLen,
						  INT			nSocketDesc,
						  USHORT		usPort)
{
	return 0;
}
static INT	ptp_send_L4V6(UCHAR			uchPort,
			 			  UCHAR			uchTraClsNo,
			 			  UCHAR *		puchMsgPtr,
			 			  USHORT		usMsgLen,
						  INT			nSocketDesc,
						  USHORT		usPort)
{
	return 0;
}

void ptp_EmergLogCallBack(PTP_LOGRECORD*	pstLogRecord)
{

}
VOID ptp_SetMasterTime(CLOCKDATA*	pstClockData, EXTENDEDTIMESTAMP*	pstMasterTime){

}

VOID ptp_GetCurrentMasterTime(
	CLOCKDATA*	pstClockData,
	USCALEDNS*	pstCurrentMasterTime)
{
	ptp_GetDetailCurrentClockTime(pstCurrentMasterTime);

}
NX_VOID vTsn_AverageProcessing( NX_DOUBLE* pdbFreqRate, DELAYINFO* pstDelyInfo, USCALEDNS* pstNeighborPropDelay, USHORT usPortNum,  UCHAR uchDomainNumber)
{

	TIMESTAMP*						pstSyncReceiveTime		= 	NULL;
	TIMESTAMP*						pstSyncOriginTimeStamp	= 	NULL;
	FRAC_NSEC64*					pstSyncCorrectionField	= 	NULL;
	EXTENDEDTIMESTAMP				stSyncSendTime;
	TIMESTAMP						stNeighborPropDelayTS;
	
						


	if(DELAY_P2P == pstDelyInfo->enClockDelay){
		pstSyncOriginTimeStamp	= &pstDelyInfo->stDelayTimeInfo.stDelayInfo_P2P.stSyncOriginTimeStamp;
		pstSyncCorrectionField	= &pstDelyInfo->stDelayTimeInfo.stDelayInfo_P2P.stSyncCorrectionField;
	}
	else if(DELAY_E2E == pstDelyInfo->enClockDelay){
		pstSyncOriginTimeStamp	= &pstDelyInfo->stDelayTimeInfo.stDelayInfo_E2E.stSyncOriginTimeStamp;
		pstSyncCorrectionField	= &pstDelyInfo->stDelayTimeInfo.stDelayInfo_E2E.stSyncCorrectionField;
	}
	else{
#if TSN_LOG_ADJUST
		vADJUSTLOG_AverageProcessing (	AVEPROC_RESULT_DELAYUNKOWN,
										(NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S * CONVERTER_NStoS + (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS,	
										(NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvTime_S * CONVERTER_NStoS + (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvTime_NS,
										(NX_ULONGLONG)ADJUSTLOG_INVALID_VALUE,
										(NX_ULONGLONG)ADJUSTLOG_INVALID_VALUE,
										(NX_ULONGLONG)ADJUSTLOG_INVALID_VALUE
		);
#endif
		return;
	}


	if (gstNcfTsnInf.uchTimeSynchronizationMethod == (NX_UCHAR)TSN_IEEE1588){
		if(gausFreqRateCnt[uchDomainNumber] >= (NX_USHORT)ST_SYN_AVE_FREQRATE_SAMPING_MAX){
			gausFreqRateCnt[uchDomainNumber] = (NX_USHORT)NX_ZERO;
			gaulFreqRateFullCntFlag[uchDomainNumber] = NX_ON;
		}
		if(gaulFreqRateFullCntFlag[uchDomainNumber] == NX_ON){
			gadbFreqRateForCalc_Oldest[uchDomainNumber] = gadbFreqRateForCalc[uchDomainNumber][gausFreqRateCnt[uchDomainNumber]];
			gadbFreqRateSum[uchDomainNumber] -= gadbFreqRateForCalc_Oldest[uchDomainNumber];
		}
		gadbFreqRateForCalc[uchDomainNumber][gausFreqRateCnt[uchDomainNumber]] = *pdbFreqRate;
		gadbFreqRateSum[uchDomainNumber] += *pdbFreqRate;
		if(gaulFreqRateFullCntFlag[uchDomainNumber] == (NX_ULONG)NX_OFF){
			if(gausFreqRateCnt[uchDomainNumber] == (NX_USHORT) NX_ZERO){
				gadbFreqRateAve[uchDomainNumber] = gadbFreqRateSum[uchDomainNumber];
			}else{
				gadbFreqRateAve[uchDomainNumber] = gadbFreqRateSum[uchDomainNumber] / (NX_DOUBLE)(gausFreqRateCnt[uchDomainNumber] + 1);
			}
		}
		else{
			gadbFreqRateAve[uchDomainNumber] = gadbFreqRateSum[uchDomainNumber] / (NX_DOUBLE)ST_SYN_AVE_FREQRATE_SAMPING_MAX;
		}
		*pdbFreqRate = gadbFreqRateAve[uchDomainNumber];
		gausFreqRateCnt[uchDomainNumber]++;
	}
		
	
	gastST_AveCalc[uchDomainNumber].stLast_SyncReceive_Frun.ulSec  = gastST_Rec_SyncRecv_Frun[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulSec;
	gastST_AveCalc[uchDomainNumber].stLast_SyncReceive_Frun.ulNsec = gastST_Rec_SyncRecv_Frun[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulNsec;
	gastST_Rec_SyncRecv[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulSec  		= gastTsnCtrl[usPortNum].ulSyncRcvTime_S;
	gastST_Rec_SyncRecv[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulNsec		= gastTsnCtrl[usPortNum].ulSyncRcvTime_NS;
	gastST_Rec_SyncRecv_Frun[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulSec 	= gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S;
	gastST_Rec_SyncRecv_Frun[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulNsec 	= gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS;
	vTsn_CalcSum(&gastST_AveCalc[uchDomainNumber].stSum_SyncReceive_Frun, &gastST_Rec_SyncRecv_Frun[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]],
				 &gastST_AveCalc[uchDomainNumber].stLast_SyncReceive_Frun);
	
	gastST_AveCalc[uchDomainNumber].stLast_SyncSend.ulSec	= gastST_Rec_SyncSend[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulSec;
	gastST_AveCalc[uchDomainNumber].stLast_SyncSend.ulNsec	= gastST_Rec_SyncSend[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulNsec;
	ptpAddTS_TInt(pstSyncOriginTimeStamp, pstSyncCorrectionField, &stSyncSendTime);
	gastST_Rec_SyncSend[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulSec  = stSyncSendTime.stSec.ulSec_lsb;
	gastST_Rec_SyncSend[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]].ulNsec = stSyncSendTime.stNsec.ulNsec;
	vTsn_CalcSum(&gastST_AveCalc[uchDomainNumber].stSum_SyncSend,  &gastST_Rec_SyncSend[uchDomainNumber][gaulST_AVE_Index_Sync[uchDomainNumber]],  &gastST_AveCalc[uchDomainNumber].stLast_SyncSend );
	
	if ((NX_ULONG)ST_SYN_AVE_SYNC_SAMPLING_MAX > gaulST_AVE_SamplingNum_Sync[uchDomainNumber]) {
		gaulST_AVE_SamplingNum_Sync[uchDomainNumber]++;
	}
	else {
	}
	
	gastST_AveCalc[uchDomainNumber].stLast_NeighborPropDelay.ulSec  = gastST_Rec_NeighborPropDelay[uchDomainNumber][gaulST_AVE_Index_Delay[uchDomainNumber]].ulSec;
	gastST_AveCalc[uchDomainNumber].stLast_NeighborPropDelay.ulNsec = gastST_Rec_NeighborPropDelay[uchDomainNumber][gaulST_AVE_Index_Delay[uchDomainNumber]].ulNsec;
	ptpConvUSNs_TS(pstNeighborPropDelay, &stNeighborPropDelayTS);
	gastST_Rec_NeighborPropDelay[uchDomainNumber][gaulST_AVE_Index_Delay[uchDomainNumber]].ulSec  = stNeighborPropDelayTS.stSeconds.ulSec_lsb;
	gastST_Rec_NeighborPropDelay[uchDomainNumber][gaulST_AVE_Index_Delay[uchDomainNumber]].ulNsec = stNeighborPropDelayTS.ulNanoseconds;
	vTsn_CalcSum(&gastST_AveCalc[uchDomainNumber].stSum_NeighborPropDelay,  &gastST_Rec_NeighborPropDelay[uchDomainNumber][gaulST_AVE_Index_Delay[uchDomainNumber]], 
	             &gastST_AveCalc[uchDomainNumber].stLast_NeighborPropDelay);
	
	if ((NX_ULONG)ST_SYN_AVE_DELAY_SAMPLING_MAX > gaulST_AVE_SamplingNum_Delay[uchDomainNumber]) {
		gaulST_AVE_SamplingNum_Delay[uchDomainNumber]++;
	}
	else {
	}
	
	vTsn_TimeDivide96(&gastAveragingRslt[uchDomainNumber].ullAveSyncReceive_Frun, 	 &gastST_AveCalc[uchDomainNumber].stSum_SyncReceive_Frun, 	gaulST_AVE_SamplingNum_Sync[uchDomainNumber]);
	vTsn_TimeDivide96(&gastAveragingRslt[uchDomainNumber].ullAveSyncSend,			 &gastST_AveCalc[uchDomainNumber].stSum_SyncSend, 			gaulST_AVE_SamplingNum_Sync[uchDomainNumber]);
	vTsn_TimeDivide96(&gastAveragingRslt[uchDomainNumber].ullAveNeighborPropDelay,	 &gastST_AveCalc[uchDomainNumber].stSum_NeighborPropDelay, 	gaulST_AVE_SamplingNum_Delay[uchDomainNumber]);
	
	gaulST_AVE_Index_Sync[uchDomainNumber]++;
	if ((NX_ULONG)ST_SYN_AVE_SYNC_SAMPLING_MAX <= gaulST_AVE_Index_Sync[uchDomainNumber]) {
		gaulST_AVE_Index_Sync[uchDomainNumber] = NX_ZERO;
	}
	gaulST_AVE_Index_Delay[uchDomainNumber]++;
	if ((NX_ULONG)ST_SYN_AVE_DELAY_SAMPLING_MAX <= gaulST_AVE_Index_Delay[uchDomainNumber]) {
		gaulST_AVE_Index_Delay[uchDomainNumber] = NX_ZERO;
	}
#if TSN_LOG_ADJUST
	vADJUSTLOG_AverageProcessing (	AVEPROC_RESULT_SUCCESS,
									(NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_S * CONVERTER_NStoS + (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvFreeCnt_NS,	
									(NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvTime_S * CONVERTER_NStoS + (NX_ULONGLONG)gastTsnCtrl[usPortNum].ulSyncRcvTime_NS,
									(NX_ULONGLONG)stSyncSendTime.stSec.ulSec_lsb * CONVERTER_NStoS + (NX_ULONGLONG)stSyncSendTime.stNsec.ulNsec,
									(NX_ULONGLONG)pstSyncOriginTimeStamp->stSeconds.ulSec_lsb * CONVERTER_NStoS + (NX_ULONGLONG)pstSyncOriginTimeStamp->ulNanoseconds,
									(NX_ULONGLONG)pstSyncCorrectionField->sNsec_msb * CONVERTER_NStoS + (NX_ULONGLONG)pstSyncCorrectionField->ulNsec_lsb
	);
#endif

}
NX_VOID vTsn_CalcSum(
			ST_AVE_TMSP_96T* pstSum,
			ST_AVE_TMSP_64T* pstNew,
			ST_AVE_TMSP_64T* pstOld
			)
{
	NX_ULONGLONG	ullSumSec  = 0;
	NX_LONGLONG	llSumNsec = 0;
	NX_LONGLONG	llOverSec = 0;
	
	ullSumSec  = pstSum->ullSec + pstNew->ulSec - pstOld->ulSec;
	llSumNsec = (NX_LONGLONG)pstSum->ulNsec + (NX_LONGLONG)pstNew->ulNsec - (NX_LONGLONG)pstOld->ulNsec;
	if(llSumNsec < 0){
		llSumNsec = (NX_LONGLONG)(1000*1000*1000) + llSumNsec;
		ullSumSec -= (NX_ULONGLONG)1;
	}
	else{	
		llOverSec  = llSumNsec / (NX_LONGLONG)(1000*1000*1000);
		if(llOverSec > 0){
			ullSumSec += (NX_ULONGLONG)llOverSec;
			llSumNsec -= llOverSec * (NX_LONGLONG)(1000*1000*1000);
		}
	}
	pstSum->ullSec  = ullSumSec;
	pstSum->ulNsec = (NX_ULONG)llSumNsec;
	return;
}
NX_VOID vTsn_TimeDivide96(NX_ULONGLONG* pullResult, ST_AVE_TMSP_96T* pstTimestamp, NX_ULONG ulTblNum)
{
	NX_ULONGLONG ullTs_ns;
	NX_ULONGLONG ullDev0;
	NX_ULONGLONG ullDev1;

	ST_AVE_TMSP_64T tsw;

	if( ulTblNum > 0 ){
		ullDev0 = pstTimestamp->ullSec / (NX_ULONGLONG)ulTblNum;

		tsw.ulSec = pstTimestamp->ullSec % ulTblNum;
		tsw.ulNsec = pstTimestamp->ulNsec;
		ullTs_ns = tsw.ulSec * (1000ULL*1000ULL*1000ULL) + tsw.ulNsec;
		ullDev1 = ullTs_ns / ulTblNum;
		
		*pullResult = ullDev0 * (1000ULL*1000ULL*1000ULL) + ullDev1;
	} else {
		*pullResult	= 0;
	}

	return;
}
NX_VOID vTsn_ROUNDING_3down_4up(NX_ULONGLONG ullInputTime, NX_ULONGLONG* pullResult)
{
	NX_ULONGLONG ullTemp;
	
	ullTemp = ullInputTime % 8;
	if(0 == ullTemp){
		*pullResult = ullInputTime;
	}
	else{
		if(ullTemp <= 3 ){
			*pullResult = ullInputTime - ullTemp;
		}
		else{
			*pullResult = ullInputTime - ullTemp + 8;
		}
	}
	return;
}
NX_VOID vTsn_PTP_Init(NX_VOID){

	gstTsnStatusMng.ul_SEM_Counter				 = NX_ZERO;
	
	gdbCurrentFreqRate = (NX_DOUBLE)NX_ONE;
#if REC_TSN_INF
	gulDbgFlg = NX_ON;
#endif
	return;
}
NX_VOID vTsn_PTP_Reset(NX_VOID){
	NX_UCHAR	uchIndex	=	NX_ZERO;
	vNX_FillMemory(&gstPtpCtrl, NX_ZERO, sizeof(PTP_CTRL));
	gstTsnStatusMng.ulOffset_Stable_CurrentTime = NX_ZERO;
	gstTsnStatusMng.ulOffset_Stable_CurrentTime2 = NX_ZERO;
	gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp 	 = NX_OFF;
	gstTsnStatusMng.ulFlg_WatchAdjustTimeCmp2 	 = NX_OFF;
	gstTsnStatusMng.ulTSN_Status = NX_NG;
	gstTsnStatusMng.ulTSN_BMCA_Status = NX_NG;
	gstTsnStatusMng.ulTsnWindowFlg = NX_OFF;
	gstTsnStatusMng.ulTimesOfConsecutiveOutliers = NX_ZERO;
	gstTsnStatusMng.ulFlg_OutOfTimeSync			= (NX_ULONG)NX_OFF;
	vNX_FillMemory(gstTsnStatusMng.auchBMCACompGmMac, NX_ZERO, NX_MAC_ADDR_SIZE);
	vNX_FillMemory(gstTsnStatusMng.auchBMCACompClockIdentity, NX_ZERO, CLOCKIDENTITY_SIZE);
	gstTsnStatusMng.uchDomainStatus			= (NX_UCHAR)NX_ZERO;
	vNX_FillMemory((NX_VOID*)&gstTsnStatusMng.auchFlg_AverageProcessingLastTime[NX_ZERO], NX_C_ZERO, sizeof(NX_UCHAR)*(NX_ULONG)2);
	gstTsnStatusMng.ulOffsetStabletime			= (NX_ULONG)NX_ZERO;
	gulOutOfTimeSyncSts = NX_TIMESYNC_NOCHK;
	vNX_FillMemory(gaullSyncRcvFreeCntPre, NX_C_ZERO, sizeof(NX_ULONGLONG) * (NX_ULONGLONG)MAX_DOMAIN);
	vNX_FillMemory32(gstTsnStatusMng.aulClockRateValidPre, NX_ZERO, sizeof(NX_ULONG) * (NX_ULONG)MAX_DOMAIN / sizeof(NX_ULONG));
	

	

	for (uchIndex = 0; uchIndex < MAX_DOMAIN; uchIndex++){
		vTsn_RstAverageProcessing(uchIndex);
	}
	
	return;
}
NX_VOID vTsn_SetRegister_SnAdjCnt(NX_DOUBLE* pdbFreqRate){
	
	NX_ULONG ulSnAdjCnt_Low	 = NX_ZERO;
	NX_ULONG ulSnAdjCnt_High = NX_ZERO;
	
	NX_ULONGLONG ullCount = NX_ZERO;
	NX_ULONGLONG ullSub = NX_ZERO;
	NX_ULONGLONG ullFreqRate = NX_ZERO;
	
	if(*pdbFreqRate > NX_DB_TWO){
		ullFreqRate = (NX_ULONGLONG)(NX_DB_TWO * TENOFELVTHPOW);
	}
	else{
		ullFreqRate = (NX_ULONGLONG)(*pdbFreqRate * TENOFELVTHPOW);
	}
	if(ullFreqRate > TENOFELVTHPOW){
		ullSub = ullFreqRate - TENOFELVTHPOW;
		ullCount = (TENOFELVTHPOW / ullSub);
		
		if(ullCount < (NX_ULONGLONG)NX_ULONG_MAX){
			ulSnAdjCnt_Low 	= (NX_ULONG)ullCount;
		}
		else{
			ulSnAdjCnt_Low	= NX_ULONG_MAX;
		}
		ulSnAdjCnt_High = TIMCNT_STOP;
		
	}
	else if(ullFreqRate < TENOFELVTHPOW){
		
		ullSub = TENOFELVTHPOW - ullFreqRate;
		ullCount = (TENOFELVTHPOW / ullSub);
		
		if (ullCount < (NX_ULONGLONG)NX_ULONG_MAX){
			ulSnAdjCnt_Low 	= (NX_ULONG)ullCount;
		}
		else{
			ulSnAdjCnt_Low	= NX_ULONG_MAX;
		}
		ulSnAdjCnt_High = TIMCNT_INC2;
		
	}
	else{
		ulSnAdjCnt_Low 	= NX_ZERO;
		ulSnAdjCnt_High = TIMCNT_STOP;
	}

	NGN_SN_REG->R_SNADJCNT0 = ulSnAdjCnt_Low;
	NGN_SN_REG->R_SNADJCNT1.DATA = ulSnAdjCnt_High;	
	
	return;
}
NX_VOID vTsn_RstAverageProcessing (UCHAR uchDomainNumber)
{
	
	
	gaulST_AVE_SamplingNum_Sync[uchDomainNumber] 	=	(NX_ULONG)NX_ZERO;
	gaulST_AVE_Index_Sync[uchDomainNumber] 			=	(NX_ULONG)NX_ZERO;
	gaulST_AVE_SamplingNum_Delay[uchDomainNumber] 	=	(NX_ULONG)NX_ZERO;
	gaulST_AVE_Index_Delay[uchDomainNumber]	 		=	(NX_ULONG)NX_ZERO;
	
	gausFreqRateCnt[uchDomainNumber] 				=	(NX_USHORT)NX_ZERO;
	gaulFreqRateFullCntFlag[uchDomainNumber] 		=	(NX_ULONG)NX_ZERO;
	gadbFreqRateSum[uchDomainNumber] 				=	(NX_DOUBLE)NX_ZERO;
	gadbFreqRateAve[uchDomainNumber]	 			=	(NX_DOUBLE)NX_ZERO;
	gadbFreqRateForCalc_Oldest[uchDomainNumber]		=	(NX_DOUBLE)NX_ZERO;
	
	vNX_FillMemory32(&gastST_AveCalc[uchDomainNumber], 							NX_L_ZERO, (sizeof(ST_AVE_CALC_T)	 				  					/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastST_Rec_SyncRecv[uchDomainNumber][NX_ZERO],			NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)*(NX_ULONG)ST_SYN_AVE_SYNC_SAMPLING_MAX	/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastST_Rec_SyncRecv_Frun[uchDomainNumber][NX_ZERO], 		NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)*(NX_ULONG)ST_SYN_AVE_SYNC_SAMPLING_MAX	/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastST_Rec_SyncSend[uchDomainNumber][NX_ZERO], 			NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)*(NX_ULONG)ST_SYN_AVE_SYNC_SAMPLING_MAX	/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastST_Rec_NeighborPropDelay[uchDomainNumber][NX_ZERO], 	NX_L_ZERO, (sizeof(ST_AVE_TMSP_64T)*(NX_ULONG)ST_SYN_AVE_DELAY_SAMPLING_MAX	/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gastAveragingRslt[uchDomainNumber], 						NX_L_ZERO, (sizeof(ST_AVE_RESULT_T) 						 			/ sizeof(NX_ULONG)));
	vNX_FillMemory32(&gadbFreqRateForCalc[uchDomainNumber][NX_ZERO], 			NX_L_ZERO, (sizeof(NX_DOUBLE)	*(NX_ULONG)ST_SYN_AVE_FREQRATE_SAMPING_MAX	/ sizeof(NX_ULONG)));
	return;
}
NX_ULONG ulNX_GetOutOfTimeSyncSts ( NX_VOID )
{
	return gulOutOfTimeSyncSts;
}
/*[EOF]*/
