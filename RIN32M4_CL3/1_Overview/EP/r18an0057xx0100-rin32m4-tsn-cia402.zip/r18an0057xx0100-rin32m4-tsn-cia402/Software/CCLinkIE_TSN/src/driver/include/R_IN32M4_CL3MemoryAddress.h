/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 Driver                                                           */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3MEMORYADDRESS_H__
#define __R_IN32M4_CL3MEMORYADDRESS_H__

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/
/* Cyclic received data address																							*/
/* The offset address from the top of the cyclic reception data area must match the CSP+ configuration information		*/
/* 																														*/
/* [CSP+ configuration information]			: [cyclic received data address]											*/
/* *R_B_Address (received bit data address)	: R_IN_MEMORY_ADDRESS_RY													*/
/* *R_W_Address (received word data address)	: R_IN_MEMORY_ADDRESS_RWW												*/
/* 																														*/
/* *Make sure that the areas used in the range of 0x00000000 (0) to 0x000009FF (2559) bytes do not overlap				*/
#define R_IN_MEMORY_ADDRESS_RY			(0x00000000)		/* RY memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWW			(0x00000200)		/* RWw memory address (2byte alignment)		*/

/* Cyclic send data address																								*/
/* The offset address from the top of the cyclic send data area must match the CSP+ configuration information			*/
/* 																														*/
/* [CSP+ configuration information]					: [cyclic send data address]										*/
/* *S_B_Address (transmission bit data address)		: R_IN_MEMORY_ADDRESS_RX											*/
/* *S_W_Address (transmission word data address)		: R_IN_MEMORY_ADDRESS_RWR										*/
/* *StsW_Address (state notification device address)	: R_IN_MEMORY_ADDRESS_STSW										*/
/* 																														*/
/* *The sub-payload header information of 0x00000010 (16) bytes is added to each cyclic communication data, so set the	*/
/*  top address 16 bytes apart																							*/
/* *Make sure that the areas used in the range of 0x00000000 (0) to 0x000009FF (2559) bytes do not overlap				*/
#define R_IN_MEMORY_ADDRESS_RX			(0x00000010)		/* RX memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_RWR			(0x00000220)		/* RWr memory address (2byte alignment)		*/
#define R_IN_MEMORY_ADDRESS_STSW		(0x00000710)		/* StsW memory address (2byte alignment)	*/

#endif

/*** EOF ***/
