/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNC_errcode.h"
#include "ST_SNC_exclusion_com_l.h"
#include <Windows.h>
#include "ST_SNC_debug_com_l.h"
#else
#include <common.h>
#include <common_taskid.h>
#include <01_OS/0102_SVC/inc/svc.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_debug_com_l.h"
#include "ST_SNC_errcode.h"
#endif


#ifdef SWPS
#else
NX_ULONG	gulSNCSemCnt = 0;
#endif


NX_ULONG ulST_SNC_ExecCreate(
	ST_SNC_ExecObj*	pstObj
)
{
#ifdef SWPS
	LPCRITICAL_SECTION		pCs = NULL;
#endif

	if(NX_NULL == pstObj) {
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

#ifdef SWPS

	pCs = (LPCRITICAL_SECTION)pstObj->pvObj;
	__try {
		InitializeCriticalSection(pCs);
	}
	__except(STATUS_NO_MEMORY) {
	DBGTRACE(" CRE    (%02d) Start", pstObj->uchNumber);
		return ST_SNC_NG_INSUFFICIENT_MEM;
	}
	
#endif
	DBGTRACE(" CRE    (%02d) Start End", pstObj->uchNumber);
	return ST_SNC_OK;
}

NX_ULONG ulST_SNC_ExecFinal(
	ST_SNC_ExecObj*	pstObj
)
{
#ifdef SWPS
	LPCRITICAL_SECTION pCs = NULL;
#endif

	if(NX_NULL == pstObj){
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

#ifdef SWPS
	pCs = (LPCRITICAL_SECTION)pstObj->pvObj;
	DeleteCriticalSection(pCs);
#endif
	DBGTRACE(" FIN    (%02d) Start End", pstObj->uchNumber);
	return ST_SNC_OK;
}

NX_ULONG ulST_SNC_ExecLock(
	ST_SNC_ExecObj*	pstObj
)
{
#ifdef SWPS
	LPCRITICAL_SECTION pCs = NULL;
#endif

	if(NX_NULL == pstObj){
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}

#ifdef SWPS
	pCs = (LPCRITICAL_SECTION)pstObj->pvObj;
	EnterCriticalSection(pCs);
#else
	if( 0 == gulSNCSemCnt ){
#ifdef MASTER
		gCOM_WaiSem( NPS_SNMP_SEM_ID, 1, TMO_FEVR );
#endif
	}
	else{
		;
	}
	++(gulSNCSemCnt);
#endif
	DBGTRACE(" LOCK   (%02d) Start End", pstObj->uchNumber);
	return ST_SNC_OK;
}

NX_ULONG ulST_SNC_ExecUnlock(
	ST_SNC_ExecObj*	pstObj
)
{
#ifdef SWPS
	LPCRITICAL_SECTION pCs = NULL;
#endif

	if(NX_NULL == pstObj){
		return ST_SNC_NG_PARAM_ADDR;
	}
	else {
		;
	}
#ifdef SWPS
	pCs = (LPCRITICAL_SECTION)pstObj->pvObj;
	LeaveCriticalSection(pCs);
#else
	--(gulSNCSemCnt);
	if( 0 == gulSNCSemCnt ){
#ifdef MASTER
		gCOM_SigSem( NPS_SNMP_SEM_ID, 1 );
#endif
	}
	else{
		;
	}
#endif
	DBGTRACE(" UNLOCK (%02d) Start End", pstObj->uchNumber);
	return ST_SNC_OK;
}

