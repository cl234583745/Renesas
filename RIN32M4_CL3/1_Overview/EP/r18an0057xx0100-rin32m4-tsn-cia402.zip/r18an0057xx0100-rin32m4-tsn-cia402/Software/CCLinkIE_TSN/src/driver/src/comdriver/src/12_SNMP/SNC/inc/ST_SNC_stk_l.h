/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifndef __ST_SNC_STK_L_H_INCLUDED__
#define __ST_SNC_STK_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include "ST_SNC_oidmap.h"
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#else
#include "ST_SNC_oidmap.h"
#endif
#endif

#define ST_SNC_IDX_0                                    (0)

typedef struct ST_SNC_MibIndexes_TAG {
    NX_UCHAR                            ucType;
	NX_UCHAR                            ucPadding;
    NX_USHORT                           usIdx;
} ST_SNC_MibIndexes;

typedef struct ST_SNC_MibMng_TAG {
    NX_USHORT                           usOidmap;
	NX_USHORT                           ucPadding;
    ST_SNC_MibIndexes                stIdx;
} ST_SNC_MibMng;


#endif
