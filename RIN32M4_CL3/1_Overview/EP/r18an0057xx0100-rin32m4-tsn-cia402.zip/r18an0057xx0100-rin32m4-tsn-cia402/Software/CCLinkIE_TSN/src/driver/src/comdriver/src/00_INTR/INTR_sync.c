/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_sync.h"
#include "TOOL_api.h"
#include "INTR_api.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "INTR_common.h"

#define	SYNC_HIGH_INT	((NX_ULONG)0xFF000000)
#define	SYNC_LOW_INT	((NX_ULONG)0x00FFFFFF)



NX_STATIC INTFUNCDATA gstIntHSyncFuncList[] = {
	{TABLE_END,				NULL},
};

NX_STATIC INTFUNCDATA gstIntLSyncFuncList[] = {
	{TABLE_END,				NULL},
};



NX_VOID vINTR_IntSyncH (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	
	ulFactorInt = NGN_SN_REG->R_SNINT.DATA;
	ulFactorIntMask = NGN_SN_REG->R_SNINTM.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	ulFactorIntWork = ulFactorIntWork & SYNC_HIGH_INT;
	NGN_SN_REG->R_SNINT.DATA = ulFactorIntWork;
	
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntHSyncFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntHSyncFuncList[usCount].ulBitNo) {
			gstIntHSyncFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntHSyncFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_VOID vINTR_IntSyncL (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	
	ulFactorInt = NGN_SN_REG->R_SNINT.DATA;
	ulFactorIntMask = NGN_SN_REG->R_SNINTM.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	ulFactorIntWork = ulFactorIntWork & SYNC_LOW_INT;
	NGN_SN_REG->R_SNINT.DATA = ulFactorIntWork;
	
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntLSyncFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntLSyncFuncList[usCount].ulBitNo) {
			gstIntLSyncFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntLSyncFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_ULONG ulINTR_CheckIntLowSync (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_SN_REG->R_SNINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntLowSync (
	NX_ULONG	ulCheckTarget
)
{
	NGN_SN_REG->R_SNINT.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntLowSync (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLowSyncMask;
	vNX_vDisableDispatch();
	ulLowSyncMask = NGN_SN_REG->R_SNINTM.DATA;
	NGN_SN_REG->R_SNINTM.DATA = ulLowSyncMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntLowSync (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLowSyncMask;
	
	vNX_vDisableDispatch();
	ulLowSyncMask = NGN_SN_REG->R_SNINTM.DATA;
	NGN_SN_REG->R_SNINTM.DATA = ulLowSyncMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}
