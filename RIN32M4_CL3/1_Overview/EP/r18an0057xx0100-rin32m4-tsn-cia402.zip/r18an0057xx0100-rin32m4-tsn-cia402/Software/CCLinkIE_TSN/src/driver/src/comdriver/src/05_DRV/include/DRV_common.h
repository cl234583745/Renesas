/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __DRV_COMMON_H_INCLUDE__
#define __DRV_COMMON_H_INCLUDE__

#include "nx_common.h"

NX_VOID vDRV_InitLedDriver (NX_VOID);

#endif
/*[EOF]*/
