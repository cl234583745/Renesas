/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#ifdef MASTER
#ifdef SWPS
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNM_get_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include <snmp.h>
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#include "ST_UTI.h"
#else
#include <common.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_mibentry_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_sv_l.h>
#include <28_NPS/Include/ST_SNC_errcode.h>
#include <28_NPS/Include/ST_SNC_mib.h>
#include <28_NPS/Include/ST_SNC_oidmap.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_exclusion_com_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mmng_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_mset_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNM/Usnet/inc/ST_SNM_extmib_sv_l.h>
#include <28_NPS/03_NNW/0304_SNC/SNC/Usnet/inc/ST_SNC_debug_com_l.h>
#include <28_NPS/Include/ST_UTI.h>
#endif
#else
#include "nx_common.h"
#include "ST_SNM_mibentry_sv_l.h"
#include "ST_SNM_sv_l.h"
#include "ST_SNC_errcode.h"
#include "ST_SNC_mib.h"
#include "ST_SNC_oidmap.h"
#include "ST_SNC_exclusion_com_l.h"
#include "ST_SNC_mmng_sv_l.h"
#include "ST_SNC_mset_sv_l.h"
#include "ST_SNM_extmib_sv_l.h"
#include "ST_SNC_debug_com_l.h"
#endif


#ifdef MASTER
#else
#ifndef FALSE
#define FALSE 0
#endif

#ifndef TRUE
#define TRUE 1
#endif
#endif


#define ST_SNM_OID_ISOORG_ASN1DEC      1,3,6,1,4,1,
#define ST_SNM_OID_ENPRIS_ASN1DEC      51496,
#define ST_SNM_OID_CCIE   ST_SNM_OID_ISOORG_ASN1DEC  ST_SNM_OID_ENPRIS_ASN1DEC


#ifdef MASTER
#else
#define offsetof(type, mem) (NX_ULONG)&(((type *)0) -> mem)
#endif


#define ST_MEMBER_SIZE(type, member)       sizeof(((type *)0)->member)

#define ST_NWCFG_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibNetworkConfig,        member)
#define ST_NWCFG_MST_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibMasterStation,        member)
#define ST_NWCFG_CON_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibConnectedStation,     member)
#define ST_NWCFG_ADJ_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N3MibAdjacentStation,      member)

#define ST_DVDTL_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibDeviceDetail,         member)
#define ST_DVDTL_IDT_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibIdentifierInfo,       member)
#define ST_DVDTL_STS_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibStatusInfo,           member)
#define ST_DVDTL_STSBAS_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibStatusInfoBase,       member)
#define ST_DVDTL_STSMST_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibStatusMaster,         member)
#define ST_DVDTL_STSLED_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibLed,                  member)
#define ST_DVDTL_STSPORT_SIZE(member)      ST_MEMBER_SIZE(ST_SNC_N3MibPort,                 member)

#define ST_OTMDL_SIZE(member)              ST_MEMBER_SIZE(ST_SNC_N1MibOtherModule,          member)
#define ST_OTMDL_CNTL_SIZE(member)         ST_MEMBER_SIZE(ST_SNC_N2MibController,           member)
#define ST_OTMDL_OPT_SIZE(member)          ST_MEMBER_SIZE(ST_SNC_N2MibOptionInfo,           member)

#define ST_STAT_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibStatisticalInfo,      member)

#define ST_OVR_SIZE(member)                ST_MEMBER_SIZE(ST_SNC_N1MibIpOverlapError,       member)
#define ST_OVR_REG_SIZE(member)            ST_MEMBER_SIZE(ST_SNC_N2MibIpOverlapReg,         member)

#define ST_TOPO_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibIpTopologyError,      member)
#define ST_TOPO_REG_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibTopologyReg,          member)



#define ST_DATL_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibDatalinkError,        member)
#define ST_DATL_REG_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibDatalinkErrorReg,     member)

#define ST_COMT_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibCommTimingError,      member)

#define ST_CUER_SIZE(member)               ST_MEMBER_SIZE(ST_SNC_N1MibCurrentError,         member)
#define ST_CUER_ERR_SIZE(member)           ST_MEMBER_SIZE(ST_SNC_N2MibErrorReg,             member)
#define ST_CUER_ERR_DTL_SIZE(member)       ST_MEMBER_SIZE(ST_SNC_N3MibErrorDetailReg,       member)



#define ST_NWCFG_OFST(member)                                                     offsetof(ST_SNC_N1MibNetworkConfig,        member)
#define ST_NWCFG_MST_OFST(member)                                                 offsetof(ST_SNC_N2MibMasterStation,        member)
#define ST_NWCFG_CON_OFST(member)        (ST_NWCFG_OFST(astConnected)           + offsetof(ST_SNC_N2MibConnectedStation,     member))
#define ST_NWCFG_ADJ_OFST(member)        (ST_NWCFG_CON_OFST(astAdjacent)        + offsetof(ST_SNC_N3MibAdjacentStation,      member))

#define ST_DVDTL_OFST(member)                                                     offsetof(ST_SNC_N1MibDeviceDetail,         member)
#define ST_DVDTL_IDT_OFST(member)        (ST_DVDTL_OFST(stIdentifier)           + offsetof(ST_SNC_N2MibIdentifierInfo,       member))
#define ST_DVDTL_STS_OFST(member)        (ST_DVDTL_OFST(stStatus)               + offsetof(ST_SNC_N2MibStatusInfo,           member))
#define ST_DVDTL_STSBAS_OFST(member)     (ST_DVDTL_STS_OFST(stStatusInfoBase)   + offsetof(ST_SNC_N3MibStatusInfoBase,       member))
#define ST_DVDTL_STSMST_OFST(member)     (ST_DVDTL_STS_OFST(astMasterTable)     + offsetof(ST_SNC_N3MibStatusMaster,         member))
#define ST_DVDTL_STSLED_OFST(member)     (ST_DVDTL_STS_OFST(astLedTable)        + offsetof(ST_SNC_N3MibLed,                  member))
#define ST_DVDTL_STSPORT_OFST(member)    (ST_DVDTL_STS_OFST(astPortTable)       + offsetof(ST_SNC_N3MibPort,                 member))

#define ST_OTMDL_OFST(member)                                                     offsetof(ST_SNC_N1MibOtherModule,          member)
#define ST_OTMDL_CNTL_OFST(member)       (ST_OTMDL_OFST(stController)           + offsetof(ST_SNC_N2MibController,           member))
#define ST_OTMDL_OPT_OFST(member)        (ST_OTMDL_OFST(astOptTable)            + offsetof(ST_SNC_N2MibOptionInfo,           member))

#define ST_STAT_OFST(member)                                                      offsetof(ST_SNC_N1MibStatisticalInfo,      member)

#define ST_OVR_OFST(member)                                                       offsetof(ST_SNC_N1MibIpOverlapError,       member)
#define ST_OVR_REG_OFST(member)          (ST_OVR_OFST(astRegTable)               + offsetof(ST_SNC_N2MibIpOverlapReg,         member))

#define ST_TOPO_OFST(member)                                                      offsetof(ST_SNC_N1MibIpTopologyError,      member)
#define ST_TOPO_REG_OFST(member)         (ST_TOPO_OFST(astRegTable)              + offsetof(ST_SNC_N2MibTopologyReg,          member))


#define ST_DATL_OFST(member)                                                      offsetof(ST_SNC_N1MibDatalinkError,        member)
#define ST_DATL_REG_OFST(member)         (ST_DATL_OFST(astErrorTable)           + offsetof(ST_SNC_N2MibDatalinkErrorReg,     member))

#define ST_COMT_OFST(member)                                                      offsetof(ST_SNC_N1MibCommTimingError,      member)

#define ST_CUER_OFST(member)                                                      offsetof(ST_SNC_N1MibCurrentError,         member)
#define ST_CUER_ERR_OFST(member)         (ST_CUER_OFST(astErrorTable)            + offsetof(ST_SNC_N2MibErrorReg,             member))
#define ST_CUER_ERR_DTL_OFST(member)     (ST_CUER_ERR_OFST(astDetailTable)       + offsetof(ST_SNC_N3MibErrorDetailReg,       member))



#define ST_NO_MEMBER_OFSZ                {0, 0}
#define ST_ERR_MEMBER_OFSZ               {ST_SNM_VALUE_NONE, ST_SNM_VALUE_NONE}

#define ST_NWCFG_OFSZ(member)            {ST_NWCFG_OFST(member),            ST_NWCFG_SIZE(member)            }
#define ST_NWCFG_MST_OFSZ(member)        {ST_NWCFG_MST_OFST(member),        ST_NWCFG_MST_SIZE(member)        }
#define ST_NWCFG_CON_OFSZ(member)        {ST_NWCFG_CON_OFST(member),        ST_NWCFG_CON_SIZE(member)        }
#define ST_NWCFG_ADJ_OFSZ(member)        {ST_NWCFG_ADJ_OFST(member),        ST_NWCFG_ADJ_SIZE(member)        }

#define ST_DVDTL_OFSZ(member)            {ST_DVDTL_OFST(member),            ST_DVDTL_SIZE(member)            }
#define ST_DVDTL_IDT_OFSZ(member)        {ST_DVDTL_IDT_OFST(member),        ST_DVDTL_IDT_SIZE(member)        }
#define ST_DVDTL_STS_OFSZ(member)        {ST_DVDTL_STS_OFST(member),        ST_DVDTL_STS_SIZE(member)        }
#define ST_DVDTL_STSBAS_OFSZ(member)     {ST_DVDTL_STSBAS_OFST(member),     ST_DVDTL_STSBAS_SIZE(member)     }
#define ST_DVDTL_STSMST_OFSZ(member)     {ST_DVDTL_STSMST_OFST(member),     ST_DVDTL_STSMST_SIZE(member)     }
#define ST_DVDTL_STSLED_OFSZ(member)     {ST_DVDTL_STSLED_OFST(member),     ST_DVDTL_STSLED_SIZE(member)     }
#define ST_DVDTL_STSPORT_OFSZ(member)    {ST_DVDTL_STSPORT_OFST(member),    ST_DVDTL_STSPORT_SIZE(member)    }

#define ST_OTMDL_OFSZ(member)            {ST_OTMDL_OFST(member),            ST_OTMDL_SIZE(member)            }
#define ST_OTMDL_CNTL_OFSZ(member)       {ST_OTMDL_CNTL_OFST(member),       ST_OTMDL_CNTL_SIZE(member)       }
#define ST_OTMDL_OPT_OFSZ(member)        {ST_OTMDL_OPT_OFST(member),        ST_OTMDL_OPT_SIZE(member)        }

#define ST_STAT_OFSZ(member)             {ST_STAT_OFST(member),             ST_STAT_SIZE(member)             } 

#define ST_OVR_OFSZ(member)              {ST_OVR_OFST(member),              ST_OVR_SIZE(member)              }
#define ST_OVR_REG_OFSZ(member)          {ST_OVR_REG_OFST(member),          ST_OVR_REG_SIZE(member)          }

#define ST_TOPO_OFSZ(member)             {ST_TOPO_OFST(member),             ST_TOPO_SIZE(member)             }
#define ST_TOPO_REG_OFSZ(member)         {ST_TOPO_REG_OFST(member),         ST_TOPO_REG_SIZE(member)         }


#define ST_DATL_OFSZ(member)             {ST_DATL_OFST(member),             ST_DATL_SIZE(member)             }
#define ST_DATL_REG_OFSZ(member)         {ST_DATL_REG_OFST(member),         ST_DATL_REG_SIZE(member)         }


#define ST_COMT_OFSZ(member)             {ST_COMT_OFST(member),             ST_COMT_SIZE(member)             }

#define ST_CUER_OFSZ(member)             {ST_CUER_OFST(member),             ST_CUER_SIZE(member)             }
#define ST_CUER_ERR_OFSZ(member)         {ST_CUER_ERR_OFST(member),         ST_CUER_ERR_SIZE(member)         }
#define ST_CUER_ERR_DTL_OFSZ(member)     {ST_CUER_ERR_DTL_OFST(member),     ST_CUER_ERR_DTL_SIZE(member)     }


#define ST_SNM_NETWORKCONFIG_SFX	1
#define ST_SNM_DEVICEDETAIL_SFX		2

#define ST_SNM_USHORT_MAX			0xFFFF


#ifdef SWPS
static NX_ULONG bST_SNM_ExtMib_CheckAsnPrefix(NX_VOID*	pAsn);
#endif
static NX_ULONG ulST_SNM_ExtMib_UpdateAddr(NX_VOID);

static NX_ULONG ulST_SNM_ExtMib_GetItem(ST_SNM_GetItem* pstItem);
#ifdef SWPS
static NX_ULONG ulST_SNM_ExtMib_Oidmap2Oid(NX_USHORT usOidmap, ST_SNM_Oid* pstOid);
#endif
static NX_ULONG ulST_SNM_ExtMib_Oidmap2Mibtype(NX_USHORT usOidmap, NX_ULONG bForce, ST_SNC_Mibtype* peMibType);
static NX_ULONG ulST_SNM_ExtMib_Mibtype2Oidmap(NX_UCHAR uchMibType, ST_SNM_TblLoop* pstLoop);
static NX_ULONG ulST_SNM_ExtMib_Oidmap2MibAttr(NX_USHORT usOidmap, NX_UCHAR uchIdxAryInf, ST_SNC_MibAttr* pstAttr);
#ifdef SWPS
static NX_ULONG ulST_SNM_ExtMib_Get(NX_USHORT usOidmap, NX_USHORT usTabix, NX_UCHAR** puchPtr, NX_ULONG bIndex);
static NX_ULONG ulST_SNM_ExtMib_Index(NX_USHORT usOidmap, NX_USHORT usTabix);

static NX_ULONG ulST_SNM_ExtMib_GetIdxNum(NX_UCHAR uchType, NX_UCHAR* puchNum);
static NX_ULONG ulST_SNM_ExtMib_GetIdxNumFromEntry(NX_USHORT usOidmap, NX_UCHAR* puchNum);
static NX_ULONG ulST_SNM_ExtMib_FromIndexToOid(NX_UCHAR uchIdx, NX_ULONG	ulIndex, NX_VOID* pvOidSuffix);
static NX_ULONG ulST_SNM_ExtMib_FromOidToIndex(NX_UCHAR uchIdx, const NX_VOID* pvOidSuffix, NX_ULONG* pulIndex);
static NX_ULONG ulST_SNM_ExtMib_FromIndexToOffset(NX_UCHAR uchIdx, NX_ULONG ulIndex, NX_ULONG* pulOffset);
#endif

static NX_VOID* gpvST_SNM_Mib[ST_SNC_MIBTYPE_EXTMIB_MAX] = {
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
	NX_NULL,
};



#ifdef SWPS
static UINT gunST_SNM_OidPrefix[] = {ST_SNM_OID_CCIE};
static AsnObjectIdentifier gstOidPrefix = DEFINE_OID(gunST_SNM_OidPrefix);
#endif


static ST_SNM_MibEntry gaST_SNM_MibTbl[ST_SNC_MAP_MAX] = {
#ifdef SWPS
	{{4, {1,1,1,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNetworkNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,2,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usTotalStations)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,3,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usConfigurationPriodSeconds)                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,4,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulConfigurationPriodNanoLiw)                         },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,5,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchSyncType)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,6,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(usNumberOfConnectedStation)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,7,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usPriodSeconds)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,8,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulPriodNanoLiw)                                      },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,9,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usErrorStations)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,10,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchGrandMasterIpAddress)                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,11,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usUpdateSequenceNumber)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,12,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,13,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,14,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,15,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,16,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usNetworkType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,17,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,18,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,19,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {1,1,20,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,21,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,22,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,23,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,24,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchFunction)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,25,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,26,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortCondition)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,27,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortComSpeed)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,28,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchDiagnosisInfo)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,29,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchParameterErrorInfo)                               },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,30,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchHotLineInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,31,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStatusFlag)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,1,32,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchAlias)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,33,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchComment)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {1,1,34,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usModeStatus)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {1,2,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usNetworkType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,6    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,7    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,8    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,9    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,10   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,11   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,12   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,13   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,14   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchFunction)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,15   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,16   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortCondition)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,17   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortComSpeed)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,18   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationSpecificMode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,19   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchTransmitCycle)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,20   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchDiagnosisInfo)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,21   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchParameterErrorInfo)                               },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,22   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchHotLineInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,23   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchCyclicStatus)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,24   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStatusFlag)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,25   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfAdjacentStation)                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,26   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchAlias)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,27   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchComment)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,3,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionReceivePortNumber)                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchBeforeDetectionTransmissionPortNumber)            },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(auchBeforeNodeMacAddress)                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionResponseReceivePortNumber)               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {2,1,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchMacAddress)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchNetworkNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchIpAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchCertificationClass)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchStationType)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceVersion)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usFwVersion)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,9,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchHwVersion)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,10,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceType)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {2,1,12,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,13,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,14,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchDeviceModelName)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,15,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchVendorName)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,16,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchSerialNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,17,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchOption)                                           },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,1,18,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationSpecificMode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,1,19,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchUnitIdentifier)                                  },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfPort)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchPortCondition)                                },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchErrorFrameReceptionStatus)                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchDiagnosisInfo)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchHotLineInfo)                                  },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {2,2,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfMasterTable)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchCyclicStopInfo)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {2,2,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfLedTable)                                 },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{5, {2,2,9,1,1  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,9,1,2  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSMST_OFSZ(auchMacAddress)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,10,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedColor)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,3 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedStatus)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_LED         },
	{{4, {2,2,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchCorrespondingFunction)                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{5, {2,2,12,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,      ST_SNM_IDX_DEVDTL_PORT        },
	{{5, {2,2,12,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSPORT_OFSZ(usPortLinkDownCnt)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DEVDTL_PORT        },
	{{4, {2, 2,13,0  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchAppInfo)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,1,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchDeviceVersion)                                   },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,2,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchFwVersion)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,3,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchHwVersion)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,4,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usDeviceType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,5,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(ulDeviceModelCode)                                  },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_NONE               },
	{{4, {3,1,6,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usExpansionModelCode)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,7,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usVendorCode)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,1,8,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchDeviceModelName)                                },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,9,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchVendorName)                                     },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{4, {3,1,10,0   }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchSerialNumber)                                   },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_NONE               },
	{{3, {3,2,0      }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(usNumberOfTable)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {3,3,1,1    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,2    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(uchDeviceVersion)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,3    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(ulDeviceModelCode)                                   },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,4    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usExpansionModelCode)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,5    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usVendorCode)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,6    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchDeviceModelName)                                 },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,7    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchVendorName)                                      },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,8    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchSerialNumber)                                    },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_OTMDL_OPT          },
	{{3, {4,1,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveCounter)                                   },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,2,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveDiscardCounter)                            },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,3,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicFrameReceiveCounter)                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,4,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveCounter)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,5,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveDiscardCounter)                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,6,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfHecErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,7,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfDcsErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,8,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFcsErrorFrame)                                  },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,9,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSdcrcErrorFrame)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,10,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfShortPacketFrame)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,11,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfJumboPacketFrame)                               },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,12,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLongPacketFrame)                                },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,13,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFailedCcLinkIePduSize)                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,14,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFlagmentErrorFrame)                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,15,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfPriorityControlFrame)                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,16,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIpFrame)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,17,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIeee802or1588Frame)                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,18,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLldpFrame)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {4,19,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSyncFrame)                                      },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {5,1,0      }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_OFSZ(usNumberOfTable)                                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {5,2,1,1    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,2    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchPortIdentifier)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,3    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchStatus)                                             },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,4    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchMacAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,5    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchIpAddress)                                         },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_IPOVERLAP_REG      },
	{{3, {6,1,0      }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {6,2,1,1    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,2    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchType)                                              },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,3    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchCause)                                            },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,4    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchMacAddress)                                       },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,5    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchIpAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,6    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchStationType)                                       },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,7    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usVendorCode)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,8    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(ulDeviceModelCode)                                    },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,9    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usDeviceType)                                         },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_TOPOLOGY_REG       },
	{{3, {9,1,0      }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {9,2,1,1    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,2    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchType)                                             },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,3    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchNetworkNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,4    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchStationNumber)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,5    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchIpAddress)                                        },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_DATALINK_REG       },
	{{3, {10,1,0     }}, {ST_SNC_MIBTYPE_COMTIMING, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_COMTIMING],  ST_COMT_OFSZ(uchTimeslotNumber)                                        },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{3, {11,1,0     }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OFSZ(usNumberOfTable)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_NONE               },
	{{4, {11,2,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorCode)                                          },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,4   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ullOccurrenceTimeSeconds)                             },  SNMP_ACCESS_READ_ONLY, ASN_OCTETSTRING, ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,5   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ulOccurrenceTimeNanoLiw)                              },  SNMP_ACCESS_READ_ONLY, ASN_UNSIGNED32,  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,6   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sUtcOffset)                                           },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,7   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sSummerTimeOffset)                                    },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,8   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(uchNumberOfTable)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,3,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  SNMP_ACCESS_NONE     , ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{4, {11,3,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_DTL_OFSZ(usDetailInfo)                                     },  SNMP_ACCESS_READ_ONLY, ASN_INTEGER,     ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(stMaster)                                                 }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      {ST_NWCFG_OFST(astConnected),sizeof(ST_SNC_N2MibConnectedStation)      }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NWCFG_CONTED       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_OFSZ(stIdentifier)                                             }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(stStatusInfoBase)                                     }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astMasterTable),sizeof(ST_SNC_N3MibStatusMaster)    }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_MASTER      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astLedTable),sizeof(ST_SNC_N3MibLed)                }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_LED         },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astPortTable),sizeof(ST_SNC_N3MibPort)              }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DEVDTL_PORT        },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(stController)                                             }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      {ST_OTMDL_OFST(astOptTable),sizeof(ST_SNC_N2MibOptionInfo)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_OTMDL_OPT          },
	{{0, {0}          }, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  {ST_OVR_OFST(astRegTable),sizeof(ST_SNC_N2MibIpOverlapReg)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_IPOVERLAP_REG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   {ST_TOPO_OFST(astRegTable),sizeof(ST_SNC_N2MibTopologyReg)             }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_TOPOLOGY_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   {ST_DATL_OFST(astErrorTable),sizeof(ST_SNC_N2MibDatalinkErrorReg)      }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_DATALINK_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astErrorTable),sizeof(ST_SNC_N2MibErrorReg)              }}, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_CURERR_ERRREG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NONE,      ST_SNC_OIDMAP_NG,  NULL,                                      ST_ERR_MEMBER_OFSZ                                                      }, SNMP_ACCESS_NONE     , 0,               ST_SNM_IDX_NONE               },
#else
	{{4, {1,1,1,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNetworkNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,2,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usTotalStations)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,3,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usConfigurationPriodSeconds)                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,4,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulConfigurationPriodNanoLiw)                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,5,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchSyncType)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,6,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(usNumberOfConnectedStation)                              },  ST_SNM_IDX_NONE               },
	{{4, {1,1,7,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usPriodSeconds)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,8,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulPriodNanoLiw)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,9,0    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usErrorStations)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,10,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchGrandMasterIpAddress)                            },  ST_SNM_IDX_NONE               },
	{{4, {1,1,11,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usUpdateSequenceNumber)                              },  ST_SNM_IDX_NONE               },
	{{4, {1,1,12,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,13,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,14,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,15,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NONE               },
	{{4, {1,1,16,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usNetworkType)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,17,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NONE               },
	{{4, {1,1,18,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,19,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NONE               },
	{{4, {1,1,20,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NONE               },
	{{4, {1,1,21,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,1,22,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchOption)                                           },  ST_SNM_IDX_NONE               },
	{{4, {1,1,23,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,1,24,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchFunction)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,25,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,26,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortCondition)                                   },  ST_SNM_IDX_NONE               },
	{{4, {1,1,27,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchPortComSpeed)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,28,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchDiagnosisInfo)                                    },  ST_SNM_IDX_NONE               },
	{{4, {1,1,29,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchParameterErrorInfo)                               },  ST_SNM_IDX_NONE               },
	{{4, {1,1,30,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchHotLineInfo)                                     },  ST_SNM_IDX_NONE               },
	{{4, {1,1,31,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(uchStatusFlag)                                       },  ST_SNM_IDX_NONE               },
	{{4, {1,1,32,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchAlias)                                           },  ST_SNM_IDX_NONE               },
	{{4, {1,1,33,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(auchComment)                                         },  ST_SNM_IDX_NONE               },
	{{4, {1,1,34,0   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_MST_OFSZ(usModeStatus)                                        },  ST_SNM_IDX_NONE               },
	{{4, {1,2,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usNetworkType)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,6    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,7    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,8    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,9    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,10   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,11   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,12   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchOption)                                           },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,13   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,14   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchFunction)                                         },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,15   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,16   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortCondition)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,17   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchPortComSpeed)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,18   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(usStationSpecificMode)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,19   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchTransmitCycle)                                   },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,20   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchDiagnosisInfo)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,21   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchParameterErrorInfo)                               },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,22   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchHotLineInfo)                                     },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,23   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchCyclicStatus)                                    },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,24   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchStatusFlag)                                       },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,25   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(uchNumberOfAdjacentStation)                          },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,26   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchAlias)                                           },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,2,1,27   }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_CON_OFSZ(auchComment)                                         },  ST_SNM_IDX_NWCFG_CONTED       },
	{{4, {1,3,1,1    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,2    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionReceivePortNumber)                       },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,3    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchBeforeDetectionTransmissionPortNumber)            },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,4    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(auchBeforeNodeMacAddress)                            },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {1,3,1,5    }}, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_ADJ_OFSZ(uchDetectionResponseReceivePortNumber)               },  ST_SNM_IDX_NWCFG_ADJACENT     },
	{{4, {2,1,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchMacAddress)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationNumber)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,1,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchNetworkNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {2,1,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchIpAddress)                                       },  ST_SNM_IDX_NONE               },
	{{4, {2,1,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchCertificationClass)                               },  ST_SNM_IDX_NONE               },
	{{4, {2,1,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchStationType)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceVersion)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,1,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usFwVersion)                                         },  ST_SNM_IDX_NONE               },
	{{4, {2,1,9,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchHwVersion)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,10,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usDeviceType)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_NONE               },
	{{4, {2,1,12,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,1,13,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_NONE               },
	{{4, {2,1,14,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchDeviceModelName)                                 },  ST_SNM_IDX_NONE               },
	{{4, {2,1,15,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchVendorName)                                      },  ST_SNM_IDX_NONE               },
	{{4, {2,1,16,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchSerialNumber)                                    },  ST_SNM_IDX_NONE               },
	{{4, {2,1,17,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(uchOption)                                           },  ST_SNM_IDX_NONE               },
	{{4, {2,1,18,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(usStationSpecificMode)                               },  ST_SNM_IDX_NONE               },
	{{4, {2,1,19,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_IDT_OFSZ(auchUnitIdentifier)                                  },  ST_SNM_IDX_NONE               },
	{{4, {2,2,1,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfPort)                                     },  ST_SNM_IDX_NONE               },
	{{4, {2,2,2,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchPortCondition)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,2,3,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchErrorFrameReceptionStatus)                    },  ST_SNM_IDX_NONE               },
	{{4, {2,2,4,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchDiagnosisInfo)                                 },  ST_SNM_IDX_NONE               },
	{{4, {2,2,5,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchHotLineInfo)                                  },  ST_SNM_IDX_NONE               },
	{{4, {2,2,6,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfMasterTable)                              },  ST_SNM_IDX_NONE               },
	{{4, {2,2,7,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchCyclicStopInfo)                                },  ST_SNM_IDX_NONE               },
	{{4, {2,2,8,0    }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(uchNumberOfLedTable)                                 },  ST_SNM_IDX_NONE               },
	{{5, {2,2,9,1,1  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,9,1,2  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSMST_OFSZ(auchMacAddress)                                   },  ST_SNM_IDX_DEVDTL_MASTER      },
	{{5, {2,2,10,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedColor)                                      },  ST_SNM_IDX_DEVDTL_LED         },
	{{5, {2,2,10,1,3 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSLED_OFSZ(uchLedStatus)                                     },  ST_SNM_IDX_DEVDTL_LED         },
	{{4, {2,2,11,0   }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(auchCorrespondingFunction)                        },  ST_SNM_IDX_NONE               },
	{{5, {2,2,12,1,1 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_ERR_MEMBER_OFSZ                                                     },   ST_SNM_IDX_DEVDTL_PORT        },
	{{5, {2,2,12,1,2 }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSPORT_OFSZ(usPortLinkDownCnt)                               },  ST_SNM_IDX_DEVDTL_PORT        },
	{{4, {2, 2,13,0  }}, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STSBAS_OFSZ(uchAppInfo)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,1,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchDeviceVersion)                                   },  ST_SNM_IDX_NONE               },
	{{4, {3,1,2,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchFwVersion)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,3,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(uchHwVersion)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,4,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usDeviceType)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,5,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(ulDeviceModelCode)                                  },  ST_SNM_IDX_NONE               },
	{{4, {3,1,6,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usExpansionModelCode)                               },  ST_SNM_IDX_NONE               },
	{{4, {3,1,7,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(usVendorCode)                                       },  ST_SNM_IDX_NONE               },
	{{4, {3,1,8,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchDeviceModelName)                                },  ST_SNM_IDX_NONE               },
	{{4, {3,1,9,0    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchVendorName)                                     },  ST_SNM_IDX_NONE               },
	{{4, {3,1,10,0   }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_CNTL_OFSZ(auchSerialNumber)                                   },  ST_SNM_IDX_NONE               },
	{{3, {3,2,0      }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(usNumberOfTable)                                         },  ST_SNM_IDX_NONE               },
	{{4, {3,3,1,1    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,2    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(uchDeviceVersion)                                    },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,3    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(ulDeviceModelCode)                                   },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,4    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usExpansionModelCode)                                },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,5    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(usVendorCode)                                        },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,6    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchDeviceModelName)                                 },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,7    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchVendorName)                                      },  ST_SNM_IDX_OTMDL_OPT          },
	{{4, {3,3,1,8    }}, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OPT_OFSZ(auchSerialNumber)                                    },  ST_SNM_IDX_OTMDL_OPT          },
	{{3, {4,1,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveCounter)                                   },  ST_SNM_IDX_NONE               },
	{{3, {4,2,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicReceiveDiscardCounter)                            },  ST_SNM_IDX_NONE               },
	{{3, {4,3,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usCyclicFrameReceiveCounter)                              },  ST_SNM_IDX_NONE               },
	{{3, {4,4,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveCounter)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,5,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNonCyclicReceiveDiscardCounter)                         },  ST_SNM_IDX_NONE               },
	{{3, {4,6,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfHecErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,7,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfDcsErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,8,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFcsErrorFrame)                                  },  ST_SNM_IDX_NONE               },
	{{3, {4,9,0      }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSdcrcErrorFrame)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,10,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfShortPacketFrame)                               },  ST_SNM_IDX_NONE               },
	{{3, {4,11,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfJumboPacketFrame)                               },  ST_SNM_IDX_NONE               },
	{{3, {4,12,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLongPacketFrame)                                },  ST_SNM_IDX_NONE               },
	{{3, {4,13,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFailedCcLinkIePduSize)                          },  ST_SNM_IDX_NONE               },
	{{3, {4,14,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfFlagmentErrorFrame)                             },  ST_SNM_IDX_NONE               },
	{{3, {4,15,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfPriorityControlFrame)                           },  ST_SNM_IDX_NONE               },
	{{3, {4,16,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIpFrame)                                        },  ST_SNM_IDX_NONE               },
	{{3, {4,17,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfIeee802or1588Frame)                             },  ST_SNM_IDX_NONE               },
	{{3, {4,18,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfLldpFrame)                                      },  ST_SNM_IDX_NONE               },
	{{3, {4,19,0     }}, {ST_SNC_MIBTYPE_STATS,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_STATS],      ST_STAT_OFSZ(usNumberOfSyncFrame)                                      },  ST_SNM_IDX_NONE               },
	{{3, {5,1,0      }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_OFSZ(usNumberOfTable)                                           },  ST_SNM_IDX_NONE               },
	{{4, {5,2,1,1    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,2    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchPortIdentifier)                                     },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,3    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(uchStatus)                                             },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,4    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchMacAddress)                                        },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{4, {5,2,1,5    }}, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  ST_OVR_REG_OFSZ(auchIpAddress)                                         },  ST_SNM_IDX_IPOVERLAP_REG      },
	{{3, {6,1,0      }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {6,2,1,1    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,2    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchType)                                              },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,3    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchCause)                                            },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,4    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchMacAddress)                                       },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,5    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(auchIpAddress)                                        },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,6    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(uchStationType)                                       },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,7    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usVendorCode)                                         },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,8    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(ulDeviceModelCode)                                    },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{4, {6,2,1,9    }}, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   ST_TOPO_REG_OFSZ(usDeviceType)                                         },  ST_SNM_IDX_TOPOLOGY_REG       },
	{{3, {9,1,0      }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {9,2,1,1    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,2    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchType)                                             },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,3    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchNetworkNumber)                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,4    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(uchStationNumber)                                     },  ST_SNM_IDX_DATALINK_REG       },
	{{4, {9,2,1,5    }}, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   ST_DATL_REG_OFSZ(auchIpAddress)                                        },  ST_SNM_IDX_DATALINK_REG       },
	{{3, {10,1,0     }}, {ST_SNC_MIBTYPE_COMTIMING, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_COMTIMING],  ST_COMT_OFSZ(uchTimeslotNumber)                                        },  ST_SNM_IDX_NONE               },
	{{3, {11,1,0     }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_OFSZ(usNumberOfTable)                                          },  ST_SNM_IDX_NONE               },
	{{4, {11,2,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorCode)                                          },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,3   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(usErrorOccurrenceOrderNo)                             },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,4   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ullOccurrenceTimeSeconds)                             },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,5   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(ulOccurrenceTimeNanoLiw)                              },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,6   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sUtcOffset)                                           },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,7   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(sSummerTimeOffset)                                    },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,2,1,8   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_OFSZ(uchNumberOfTable)                                     },  ST_SNM_IDX_CURERR_ERRREG      },
	{{4, {11,3,1,1   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_NG,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_ERR_MEMBER_OFSZ                                                     },  ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{4, {11,3,1,2   }}, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     ST_CUER_ERR_DTL_OFSZ(usDetailInfo)                                     },  ST_SNM_IDX_CURERR_ERRDTLREG   },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      ST_NWCFG_OFSZ(stMaster)                                                 }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NWCFG,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_NWCFG],      {ST_NWCFG_OFST(astConnected),sizeof(ST_SNC_N2MibConnectedStation)      }}, ST_SNM_IDX_NWCFG_CONTED       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_OFSZ(stIdentifier)                                             }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     ST_DVDTL_STS_OFSZ(stStatusInfoBase)                                     }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astMasterTable),sizeof(ST_SNC_N3MibStatusMaster)    }}, ST_SNM_IDX_DEVDTL_MASTER      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astLedTable),sizeof(ST_SNC_N3MibLed)                }}, ST_SNM_IDX_DEVDTL_LED         },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DEVDTL,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DEVDTL],     {ST_DVDTL_STS_OFST(astPortTable),sizeof(ST_SNC_N3MibPort)              }}, ST_SNM_IDX_DEVDTL_PORT        },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      ST_OTMDL_OFSZ(stController)                                             }, ST_SNM_IDX_NONE               },
	{{0, {0}          }, {ST_SNC_MIBTYPE_OTMDL,     ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_OTMDL],      {ST_OTMDL_OFST(astOptTable),sizeof(ST_SNC_N2MibOptionInfo)             }}, ST_SNM_IDX_OTMDL_OPT          },
	{{0, {0}          }, {ST_SNC_MIBTYPE_IPOVERLAP, ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_IPOVERLAP],  {ST_OVR_OFST(astRegTable),sizeof(ST_SNC_N2MibIpOverlapReg)             }}, ST_SNM_IDX_IPOVERLAP_REG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_TOPOLOGY,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_TOPOLOGY],   {ST_TOPO_OFST(astRegTable),sizeof(ST_SNC_N2MibTopologyReg)             }}, ST_SNM_IDX_TOPOLOGY_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_DATALINK,  ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_DATALINK],   {ST_DATL_OFST(astErrorTable),sizeof(ST_SNC_N2MibDatalinkErrorReg)      }}, ST_SNM_IDX_DATALINK_REG       },
	{{0, {0}          }, {ST_SNC_MIBTYPE_CURERR,    ST_SNC_OIDMAP_OK,  &gpvST_SNM_Mib[ST_SNC_MIBTYPE_CURERR],     {ST_CUER_OFST(astErrorTable),sizeof(ST_SNC_N2MibErrorReg)              }}, ST_SNM_IDX_CURERR_ERRREG      },
	{{0, {0}          }, {ST_SNC_MIBTYPE_NONE,      ST_SNC_OIDMAP_NG,  NX_NULL,                                      ST_ERR_MEMBER_OFSZ                                                      }, ST_SNM_IDX_NONE               },
#endif
};


static const ST_SNM_Index gaST_SNM_IdxTbl[ST_SNM_IDX_TYPE_MAX] = {
	{ST_SNM_IDX_0,   {{0,                                      0,                                                   0,                        0                                      }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_NWCFG_CONTED_INDEX,          ST_SNC_MAP_NWCFG_MASTER_NUMBER_OF_CONNECTED_STATION, ST_SNC_NWCFG_CONSTN_MAX,  sizeof(ST_SNC_N2MibConnectedStation)   }}},
	{ST_SNM_IDX_2,   {{ST_SNC_MAP_NWCFG_CONTED_INDEX,          ST_SNC_MAP_NWCFG_MASTER_NUMBER_OF_CONNECTED_STATION, ST_SNC_NWCFG_CONSTN_MAX,  sizeof(ST_SNC_N2MibConnectedStation)   },
                      {ST_SNC_MAP_NWCFG_ADJACENT_INDEX,        ST_SNC_MAP_NWCFG_CONTED_NUMBER_OF_ADJACENT,          ST_SNC_NWCFG_ADJACENT_MAX,sizeof(ST_SNC_N3MibAdjacentStation)    }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_MASTAB_INDEX, ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_MASTAB,          ST_SNC_DEVDTL_MASTER_MAX, sizeof(ST_SNC_N3MibStatusMaster)       }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_LEDTAB_INDEX, ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_LEDTAB,          ST_SNC_DEVDTL_LED_MAX,    sizeof(ST_SNC_N3MibLed)                }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DEVDTL_STSINFO_PORTTAB_INDEX,ST_SNC_MAP_DEVDTL_STSINFO_NUMBER_OF_PORT,            ST_SNC_DEVDTL_PORT_MAX,   sizeof(ST_SNC_N3MibPort)               }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_OTMDL_OPT_INDEX,             ST_SNC_MAP_OTMDL_NUMBER_OF_OPT,                      ST_SNC_OTHER_OPT_MAX,     sizeof(ST_SNC_N2MibOptionInfo)         }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_IPOVERLAP_REG_INDEX,         ST_SNC_MAP_IPOVERLAP_NUMBER_OF_REG,                  ST_SNC_IPOVLAP_ERR_MAX,   sizeof(ST_SNC_N2MibIpOverlapReg)       }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_TOPOLOGY_REG_INDEX,          ST_SNC_MAP_TOPOLOGY_NUMBER_OF_REG,                   ST_SNC_TOPOLOGY_ERR_MAX,  sizeof(ST_SNC_N2MibTopologyReg)        }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_DATALINK_REG_INDEX,          ST_SNC_MAP_DATALINK_NUMBER_OF_REG,                   ST_SNC_DATALINK_ERR_MAX,  sizeof(ST_SNC_N2MibDatalinkErrorReg)   }}},
	{ST_SNM_IDX_1,   {{ST_SNC_MAP_CURERR_ERRREG_INDEX,         ST_SNC_MAP_CURERR_NUMBER_OF_ERRREG,                  ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N2MibErrorReg)           }}},
	{ST_SNM_IDX_2,   {{ST_SNC_MAP_CURERR_ERRREG_INDEX,         ST_SNC_MAP_CURERR_NUMBER_OF_ERRREG,                  ST_SNC_ERRREG_MAX,        sizeof(ST_SNC_N2MibErrorReg)           },
				      {ST_SNC_MAP_CURERR_ERRDTLREG_INDEX,      ST_SNC_MAP_CURERR_ERRREG_NUMBER_OF_ERRDTLREG,        ST_SNC_ERRDTLREG_MAX,     sizeof(ST_SNC_N3MibErrorDetailReg)     }}},
};


static ST_SNM_MibTblSet gST_SNM_ExtMibTbls = {
	ST_SNC_MAP_NWCFG_MASTER,
	gaST_SNM_MibTbl,
	ST_SNM_IDX_TYPE_MAX,
	gaST_SNM_IdxTbl,
#ifdef SWPS
	ST_SNM_ExtMib_GetAsnPrefix,
	bST_SNM_ExtMib_CheckAsnPrefix,
#endif
	ulST_SNM_ExtMib_UpdateAddr,
	ulST_SNM_ExtMib_GetItem,
#ifdef SWPS
	ulST_SNM_ExtMib_Get,
	ulST_SNM_ExtMib_Index,
	ulST_SNM_ExtMib_GetIdxNumFromEntry,
	ulST_SNM_ExtMib_FromIndexToOid,
	ulST_SNM_ExtMib_FromOidToIndex,
#endif
};


static ST_SNM_Suffix gastNetDev[2] = {
		{{ 1, {ST_SNM_NETWORKCONFIG_SFX} }, ST_SNC_MIBTYPE_NWCFG },
		{{ 1, {ST_SNM_DEVICEDETAIL_SFX } }, ST_SNC_MIBTYPE_DEVDTL},
};



#ifdef SWPS
NX_VOID ST_SNM_ExtMib_GetAsnPrefix(
	NX_VOID*	pAsn,
	NX_ULONG	bNotAlloc
)
{
	AsnObjectIdentifier* pAsnOid = (AsnObjectIdentifier*)pAsn;

	if(TRUE == bNotAlloc) {
		*pAsnOid = gstOidPrefix;
	} 
	else {
		SnmpUtilOidCpy(pAsnOid, &gstOidPrefix);
	}
	
}


static NX_ULONG bST_SNM_ExtMib_CheckAsnPrefix(
	NX_VOID*	pAsn
)
{
	AsnObjectIdentifier*	pAsnOid = (AsnObjectIdentifier*)pAsn;
	int						iRtn	= 0;

	iRtn = SnmpUtilOidNCmp(pAsnOid, &gstOidPrefix, gstOidPrefix.idLength);
	if(0 == iRtn) {
		return TRUE;
	}
	else {
		;
	}
	return FALSE;
}
#endif

NX_VOID ST_SNM_GetExtMibTbl(
	ST_SNM_MibTblSet**	pstTblSet
)
{
	*pstTblSet = &gST_SNM_ExtMibTbls;
}




static NX_ULONG ulST_SNM_ExtMib_UpdateAddr(NX_VOID)
{
	NX_ULONG 	ulRet = ST_SNC_OK;
	NX_UCHAR	ucCnt = 0;

	for(ucCnt=0; ucCnt<ST_SNC_MIBTYPE_EXTMIB_MAX; ucCnt++) {

		ulRet = ulST_SNC_MibGetAddr((ST_SNC_Mibtype)ucCnt, ST_SNC_MEMORY_READ, &gpvST_SNM_Mib[ucCnt]);
		if(ST_SNC_OK != ulRet) {
			break;
		}
		else {
			DBGTRACE("%s gpvST_SNM_Mib[%d]=0x%x", __FUNCTION__, ucCnt, gpvST_SNM_Mib[ucCnt] );
		}
	}

	return ulRet;
}

NX_ULONG ulST_SNM_ExtMib_UpdateAddrForMibType(NX_UCHAR uchMibType)
{
	NX_ULONG ulRet = ST_SNC_OK;

	ulRet = ulST_SNC_MibGetAddrNolock((ST_SNC_Mibtype)uchMibType, ST_SNC_MEMORY_READ, &gpvST_SNM_Mib[uchMibType]);
	if(ST_SNC_OK == ulRet){
		DBGTRACE("%s gpvST_SNM_Mib[%d]=0x%x", __FUNCTION__, uchMibType, gpvST_SNM_Mib[uchMibType] );
	}
	else {
		;
	}
	return ulRet;
}


#ifdef SWPS
static NX_ULONG ulST_SNM_ExtMib_Oidmap2Oid(
	NX_USHORT				usOidmap,
	ST_SNM_Oid*			pstOid
)
{
		*pstOid = gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stOid;
	return ST_SNC_OK;
}
#endif


static NX_ULONG ulST_SNM_ExtMib_Oidmap2Mibtype(
	NX_USHORT			usOidmap,
	NX_ULONG			bForce,
	ST_SNC_Mibtype*	peMibType
)
{
		if(TRUE == bForce) {
			*peMibType = (ST_SNC_Mibtype)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucMibType;
		}
		else {
			if(ST_SNC_OIDMAP_OK == gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucOperable) {
				*peMibType = (ST_SNC_Mibtype)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.ucMibType;
			}
			else{
				return ST_SNC_NG_PARAM_FORBID;
			}
		}
	DBGTRACE("%s END(oid=%d bForce=%d type=%d)",__FUNCTION__, usOidmap, bForce, *peMibType);
	return ST_SNC_OK;
}


#ifdef SWPS
static NX_ULONG ulST_SNM_ExtMib_Mibtype2Oidmap(
	NX_UCHAR				uchMibType,
	ST_SNM_TblLoop* 	pstLoop
)
{
	NX_ULONG 	ulRet			= ST_SNC_OK;
	NX_USHORT	usCounter		= 0;
	NX_USHORT	usCounterInit	= ST_SNM_USHORT_MAX;
	NX_USHORT	usCounterMax	= ST_SNM_USHORT_MAX;

	if (ST_SNC_MIBTYPE_NWCFG  > uchMibType ||
		ST_SNC_MIBTYPE_CURERR < uchMibType ) {
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}
	else if (NX_NULL == pstLoop) {
		ulRet = ST_SNC_NG_PARAM_ADDR;
	}
	else {

		for(usCounter = 0; usCounter< gST_SNM_ExtMibTbls.usMibTblSize; usCounter++) {

			if(uchMibType == gST_SNM_ExtMibTbls.pstMibTbl[usCounter].stMib.ucMibType){

				if(ST_SNM_USHORT_MAX == usCounterInit) {
					usCounterInit = usCounter;
				}
				else {
					;
				}
				usCounterMax  = usCounter;
			}
			else {
				
				if(ST_SNM_USHORT_MAX == usCounterInit) {
					;
				}
				else {
					break;
				}
			}
		}

		if(usCounter >= gST_SNM_ExtMibTbls.usMibTblSize){
			ulRet = ST_SNC_NG;
		}
		else {
			pstLoop->usCounterInit = usCounterInit;
			pstLoop->usCounterMax  = usCounterMax;
		}
	}

	DBGTRACE("%s END(%d type=%d min=%d max=%d)",__FUNCTION__, ulRet, uchMibType, usCounterInit, usCounterMax);
	return ulRet;
}
#endif


static NX_ULONG ulST_SNM_ExtMib_Oidmap2MibAttr(
	NX_USHORT				usOidMap,
	NX_UCHAR				uchIdxAryInf,
	ST_SNC_MibAttr*		pstAttr
)
{
	NX_ULONG				ulRet			= ST_SNC_OK;
	NX_USHORT				usArrayEntry	= 0;
	NX_UCHAR				ucIdxTblIdx		= 0;
	ST_SNC_Mibtype 		eMibType 		= ST_SNC_MIBTYPE_NONE;

		pstAttr->ulOfst = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].stMib.stAttr.ulOfst;
		pstAttr->ulSize = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].stMib.stAttr.ulSize;


		ucIdxTblIdx = gST_SNM_ExtMibTbls.pstMibTbl[usOidMap].ucIdx;

		if(ST_SNM_IDX_NONE != ucIdxTblIdx){

			usArrayEntry = gaST_SNM_IdxTbl[ ucIdxTblIdx ].astInf[uchIdxAryInf].usAryEntryOidmap;

			
			ulRet = ulST_SNM_ExtMib_Oidmap2Mibtype(usArrayEntry, TRUE, &eMibType);
			if(ST_SNC_OK == ulRet) {

				ulRet = ulST_SNC_SetMibCntAttr(
							&pstAttr->stCnt,
							eMibType,
							gST_SNM_ExtMibTbls.pstMibTbl[ usArrayEntry ].stMib.stAttr.ulOfst,
							gST_SNM_ExtMibTbls.pstMibTbl[ usArrayEntry ].stMib.stAttr.ulSize,
							gST_SNM_ExtMibTbls.pstIdxTbl[ ucIdxTblIdx  ].astInf[ uchIdxAryInf ].usAryMax
							);
			}
			else {
				;
			}
		}
		else {
			ulRet = ST_SNC_NG_MEMCNT;
		}
	return ulRet;
}


static NX_ULONG ulST_SNM_ExtMib_GetItem(ST_SNM_GetItem* pstItem)
{
#ifdef SWPS
	AsnObjectIdentifier*	pstOid;
	AsnObjectIdentifier		asnOidCopy;
#endif
	ST_SNM_Oid				stOid;
	NX_ULONG					ulRet			= ST_SNC_OK;
	NX_USHORT					usOidmapMax		= 0;

	if(	NX_NULL == pstItem			||
		NX_NULL == pstItem->pObj	) {
		ulRet = ST_SNC_NG_PARAM_ADDR;
	}
	else {
		if(TRUE == pstItem->bCallSnmpReq) {

			usOidmapMax = gST_SNM_ExtMibTbls.usMibTblSize;
		}
		else {

			usOidmapMax = (NX_USHORT)sizeof(gaST_SNM_MibTbl)/sizeof(gaST_SNM_MibTbl[0]);
		}

		if (usOidmapMax <= pstItem->usOidmap){
			ulRet = ST_SNC_NG_PARAM_RANGE;
		}
		else {

			switch(pstItem->uchItemType) {
#ifdef SWPS
			case ST_SNM_MIBENTRY_OID:
				
				ulRet = ulST_SNM_ExtMib_Oidmap2Oid(pstItem->usOidmap, &stOid);
				if(ST_SNC_OK == ulRet) {


					asnOidCopy.idLength = stOid.uiLen;
					asnOidCopy.ids = stOid.auiOid;
					pstOid = (AsnObjectIdentifier*)pstItem->pObj;
					SnmpUtilOidCpy(pstOid, &asnOidCopy);
				}
				else {
					;
				}
				break;
#endif
			case ST_SNM_MIBENTRY_TYPE:
				ulRet = ulST_SNM_ExtMib_Oidmap2Mibtype(pstItem->usOidmap, FALSE, (ST_SNC_Mibtype*)pstItem->pObj);
				break;
			case ST_SNM_MIBENTRY_ATTR:
				ulRet = ulST_SNM_ExtMib_Oidmap2MibAttr(pstItem->usOidmap, pstItem->uchIdxAryInf, (ST_SNC_MibAttr*)pstItem->pObj);
				break;
			default:
				ulRet = ST_SNC_NG_PARAM_RANGE;
			}
		}
	}

	return ulRet;
}


#ifdef SWPS
NX_ULONG ulST_SNM_ExtMib_GetForLong(
	NX_USHORT		usOidmap,
	NX_ULONG		ulTabix,
	NX_UCHAR**		puchPtr,
	NX_ULONG		bIndex
)
{
	const ST_SNM_Index*	pstIndex	=		NX_NULL;
	NX_UCHAR*			puchVal			= 		NX_NULL;
	NX_ULONG			ulRet			=		ST_SNC_OK;
	NX_ULONG 			ulIx			= 		0;
	NX_ULONG 			ulIy			= 		0;
	NX_ULONG 			ulIz			= 		0;
	NX_ULONG 			ulOfset			=		0;
	NX_UCHAR			uchCount		= 		0;


	if(TRUE == bIndex) {
		if(	(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_NONE       ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_ONLY  ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_WRITE ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_CREATE) ) {
			;
		}
		else {
			return ST_SNC_NG_MIB_ACCESS;
		}
	}
	else {
		if( (gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_ONLY  ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_WRITE ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_CREATE) ) {
			;
		}
		else {
			return ST_SNC_NG_MIB_ACCESS;
		}
	}

	pstIndex = &gaST_SNM_IdxTbl[ gaST_SNM_MibTbl[usOidmap].ucIdx ];
	for(uchCount = 0; uchCount < pstIndex->eNum; uchCount++) {

		if(usOidmap == pstIndex->astInf[uchCount].usIdxAryNum) {

			**(LONG**)puchPtr = ulTabix % pstIndex->astInf[uchCount].usAryMax;
			return ulRet;

		}
		else{
			;
		}
	}

	ulRet = ulST_SNM_ExtMib_FromIndexToOffset(gaST_SNM_MibTbl[usOidmap].ucIdx, ulTabix, &ulOfset);
	if(ST_SNC_OK == ulRet) {
		*puchPtr = *(NX_UCHAR**)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.pvAddr +
		            gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.stAttr.ulOfst   + ulOfset;
	}
	else {
		;
	}

	return ulRet;
}

static NX_ULONG ulST_SNM_ExtMib_Get(
	NX_USHORT		usOidmap,
	NX_USHORT		usTabix,
	NX_UCHAR**		puchPtr,
	NX_ULONG		bIndex
)
{
	const ST_SNM_Index*	pstIndex	=		NX_NULL;
	NX_UCHAR*			puchVal			= 		NX_NULL;
	NX_ULONG			ulRet			=		ST_SNC_OK;
	NX_ULONG 			ulIx			= 		0;
	NX_ULONG 			ulIy			= 		0;
	NX_ULONG 			ulIz			= 		0;
	NX_ULONG 			ulOfset			=		0;
	NX_UCHAR			uchCount		= 		0;


	if(TRUE == bIndex) {
		if(	(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_NONE       ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_ONLY  ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_WRITE ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_CREATE) ) {
			;
		}
		else {
			return ST_SNC_NG_MIB_ACCESS;
		}
	}
	else {
		if( (gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_ONLY  ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_WRITE ) ||
			(gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].uiAcc == SNMP_ACCESS_READ_CREATE) ) {
			;
		}
		else {
			return ST_SNC_NG_MIB_ACCESS;
		}
	}

	pstIndex = &gaST_SNM_IdxTbl[ gaST_SNM_MibTbl[usOidmap].ucIdx ];
	for(uchCount = 0; uchCount < pstIndex->eNum; uchCount++) {

		if(usOidmap == pstIndex->astInf[uchCount].usIdxAryNum) {

			**(NX_USHORT**)puchPtr = usTabix % pstIndex->astInf[uchCount].usAryMax;
			return ulRet;

		}
		else{
			;
		}
	}

	ulRet = ulST_SNM_ExtMib_FromIndexToOffset(gaST_SNM_MibTbl[usOidmap].ucIdx, usTabix, &ulOfset);
	if(ST_SNC_OK == ulRet) {
		*puchPtr = *(NX_UCHAR**)gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.pvAddr +
		            gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].stMib.stAttr.ulOfst   + ulOfset;
	}
	else {
		;
	}

	return ulRet;
}


NX_ULONG ulST_SNM_ExtMib_IndexForLong(NX_USHORT usOidmap, NX_ULONG ulTabix)
{
	ST_SNM_GetItem		stItem;
	ST_SNC_MibAttr		stAttr;
	ST_SNM_Oid			stOidSuffix;
	NX_ULONG				ulRet				=	ST_SNC_OK;
	const ST_SNM_Index*	pstIndex			=	NX_NULL;
	NX_UCHAR*				puchVal				=	NX_NULL;
	NX_USHORT				usAryEntryOidmap	=	0;
	NX_USHORT 				usAryNum			=	0;
	NX_ULONG 				ulAryMaxTotal		=	1;
	NX_UCHAR				uchCount			=	0;
	NX_USHORT				usEntryTabix		=   0;

	pstIndex = &gaST_SNM_IdxTbl[ gaST_SNM_MibTbl[usOidmap].ucIdx ];
	
	gpST_UTI_Memset(&stOidSuffix, ST_SNC_ZEROPAD, sizeof(stOidSuffix));
	ulRet = ulST_SNM_ExtMib_FromIndexToOid(gaST_SNM_MibTbl[usOidmap].ucIdx, ulTabix, &stOidSuffix);
	if(ST_SNC_OK == ulRet) {

		for(uchCount = 0; uchCount < pstIndex->eNum; uchCount++) {
			ulAryMaxTotal *= pstIndex->astInf[uchCount].usAryMax;

			ulRet = ulST_SNM_ExtMib_Get(pstIndex->astInf[uchCount].usAryEntryOidmap, usEntryTabix, &puchVal, FALSE);
			if(ST_SNC_OK == ulRet) {

				gpST_UTI_Memset(&stItem, ST_SNC_ZEROPAD, sizeof(stItem));
				gpST_UTI_Memset(&stAttr, ST_SNC_ZEROPAD, sizeof(stAttr));
				ST_SNM_SetGetItem(&stItem, ST_SNM_MIBENTRY_ATTR, pstIndex->astInf[uchCount].usAryEntryOidmap, uchCount, TRUE, &stAttr);
				
				ulRet = ulST_SNM_ExtMib_GetItem(&stItem);
				if(ST_SNC_OK == ulRet || ST_SNC_NG_MEMCNT == ulRet) {

					if(ST_SNC_NG_MEMCNT == ulRet) {
						ulRet = ST_SNC_OK;
					}
					else {
						;
					}
				}
				else {
					break;
				}

				if(sizeof(NX_UCHAR) == stAttr.ulSize){
					usAryNum = *(NX_UCHAR*)puchVal;
				}
				else if(sizeof(NX_USHORT) == stAttr.ulSize){
					usAryNum = *(NX_USHORT*)puchVal;
				}
				else {
					ulRet = ST_SNC_NG_MIB_INDEX_REGNUM;
					break;
				}
				
				if(stOidSuffix.auiOid[uchCount] <= usAryNum){
					usEntryTabix = (NX_USHORT)stOidSuffix.auiOid[uchCount] - 1;
				}
				else {
					ulRet = ST_SNC_NG_IDX_SKIP;
					break;
				}

			}
			else {
				break;
			}
		}

	}
	else {
		;
	}

	if(ST_SNC_OK == ulRet) {

		if(ulTabix < ulAryMaxTotal) {
			;
		}
		else {
			ulRet = ST_SNC_NG_IDX_EOT;
		}
	}
	else {
		if(ST_SNC_NG_IDX_SKIP == ulRet) {
			if(ulTabix < ulAryMaxTotal) {
				;
			}
			else {
				ulRet = ST_SNC_NG_IDX_EOT;
			}
		}
		else {
			;
		}
	}

	return ulRet;
}


static NX_ULONG ulST_SNM_ExtMib_Index(NX_USHORT usOidmap, NX_USHORT usTabix)
{
	return ulST_SNM_ExtMib_IndexForLong(usOidmap, usTabix);
}

static NX_ULONG ulST_SNM_ExtMib_GetIdxNum(NX_UCHAR uchType, NX_UCHAR* puchNum)
{
	NX_ULONG		ulRet		=		ST_SNC_OK;

	if(uchType < ST_SNM_IDX_TYPE_MAX){
		*puchNum = gST_SNM_ExtMibTbls.pstIdxTbl[uchType].eNum;
	}
	else {
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}

static NX_ULONG ulST_SNM_ExtMib_GetIdxNumFromEntry(NX_USHORT usOidmap, NX_UCHAR* puchNum)
{
	NX_ULONG	ulRet	=	ST_SNC_OK;

	if(usOidmap < gST_SNM_ExtMibTbls.usMibTblSize){
		ulRet = ulST_SNM_ExtMib_GetIdxNum(
			gST_SNM_ExtMibTbls.pstMibTbl[usOidmap].ucType,
			puchNum
			);
	}
	else {
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}


NX_ULONG bST_SNM_CheckStationUnitLock(
	SnmpVarBind*		pVarBind,
	DWORD 				dwRequestType
)
{
	AsnObjectIdentifier		asnOidSuffix;
	AsnObjectIdentifier		asnOidTemp;
	ST_SNM_TblLoop			stLoop;
	ST_SNM_MibTblSet*		pstTblSet		= NX_NULL;
	AsnInteger32			lErrorStatus	= SNMP_ERRORSTATUS_NOSUCHNAME;
	NX_ULONG					ulRet 			= ST_SNC_OK;
	NX_UCHAR					uchCounter		= 0;
	NX_ULONG					bRc				= FALSE;
	
	DBGTRACE("%s START",__FUNCTION__);

	pstTblSet = &gST_SNM_ExtMibTbls;
	for(uchCounter=0; uchCounter < sizeof(gastNetDev)/sizeof(gastNetDev[0]); uchCounter++) {

		ulRet = ulST_SNM_ExtMib_Mibtype2Oidmap(gastNetDev[uchCounter].ucMibType, &stLoop);
		if(ST_SNC_OK == ulRet) {

			pstTblSet->getOidPre(&asnOidTemp, FALSE);
			asnOidSuffix.idLength = gastNetDev[uchCounter].stOid.uiLen;
			asnOidSuffix.ids      = gastNetDev[uchCounter].stOid.auiOid;
			SnmpUtilOidAppend(&asnOidTemp, &asnOidSuffix);
			if(0 == SnmpUtilOidNCmp(&asnOidTemp, &pVarBind->name, asnOidTemp.idLength)) {

				if(	SNMP_EXTENSION_GET == dwRequestType){
					lErrorStatus = lST_SNM_SearchGetRequest(pVarBind, pstTblSet, &stLoop, NX_NULL);
					if( SNMP_ERRORSTATUS_NOERROR == lErrorStatus){
						bRc = TRUE;
						SnmpUtilOidFree(&asnOidTemp);
						break;
					}
					else {
						;
					}
				}
				else if(SNMP_EXTENSION_GET_NEXT == dwRequestType){
					lErrorStatus = lST_SNM_SearchGetNext(pVarBind, pstTblSet, &stLoop, FALSE, NX_NULL);
					if( SNMP_ERRORSTATUS_NOERROR == lErrorStatus){
						bRc = TRUE;
						SnmpUtilOidFree(&asnOidTemp);
						break;
					}
					else {
						;
					}
				}
				else {
					;
				}
			}
			else {
				;
			}
			SnmpUtilOidFree(&asnOidTemp);
		}
		else {
			;
		}
	}
	DBGTRACE("%s END(%d)",__FUNCTION__, bRc);
	return bRc;
}


NX_ULONG bST_SNM_CheckIndexLongRange(
	const ST_SNM_MibEntry*		pstMib,
	const ST_SNM_MibTblSet*		pstTblSet
)
{
	ST_SNM_MibTblSet*	pstBase			= NX_NULL;
	NX_ULONG				bRc				= FALSE;

	ST_SNM_GetExtMibTbl(&pstBase);
	if(pstTblSet == pstBase){

		if(ST_SNC_MIBTYPE_CURERR == pstMib->stMib.ucMibType ) {
			bRc = TRUE;
		}
		else {
			;
		}
	}
	else {
		;
	}

	return bRc;
}


static NX_ULONG ulST_SNM_ExtMib_FromIndexToOid(
	NX_UCHAR					uchIdx,
	NX_ULONG					ulIndex,
	NX_VOID*					pvOidSuffix
)
{
	const ST_SNM_Index*	pstIdxTbl		= NX_NULL;
	ST_SNM_Oid*			pstOidSuffix	= NX_NULL;
	NX_ULONG				ulRet			= ST_SNC_OK;
	NX_USHORT 				usWorkIdx		= 0;

	pstIdxTbl = &gaST_SNM_IdxTbl[ uchIdx ];
	pstOidSuffix = (ST_SNM_Oid*)pvOidSuffix;

	if( ST_SNM_INDEXLEN < (UINT)pstIdxTbl->eNum)	{
		ulRet = ST_SNC_NG_PARAM_RANGE; 
	}
	else {

		switch(pstIdxTbl->eNum) {
		case ST_SNM_IDX_0:
			break;
		case ST_SNM_IDX_1:
			pstOidSuffix->auiOid[ST_SNM_IDX_0] = ulIndex % pstIdxTbl->astInf[ST_SNM_IDX_0].usAryMax + 1;
			break;
		case ST_SNM_IDX_2:
			pstOidSuffix->auiOid[ST_SNM_IDX_0] = ulIndex / pstIdxTbl->astInf[ST_SNM_IDX_1].usAryMax + 1; 
			pstOidSuffix->auiOid[ST_SNM_IDX_1] = ulIndex % pstIdxTbl->astInf[ST_SNM_IDX_1].usAryMax + 1;
			break;
		default:
			ulRet = ST_SNC_NG_PARAM_RANGE; 
		}
	}

	if(ST_SNC_OK == ulRet) {
		pstOidSuffix->uiLen = pstIdxTbl->eNum;
	}
	else{
		;
	}

	return ulRet;
}



static NX_ULONG ulST_SNM_ExtMib_FromIndexToOffset(
	NX_UCHAR					uchIdx,
	NX_ULONG					ulIndex,
	NX_ULONG*					pulOffset
)
{
	const ST_SNM_Index*	pstIdxTbl		= NX_NULL;
	ST_SNM_Oid			stOid;
	NX_ULONG				ulRet			=	ST_SNC_OK;
	NX_ULONG 				ulIx			=	0;
	NX_ULONG 				ulIy			=	0;
	NX_ULONG 				ulOfset			=	0;

	pstIdxTbl = &gaST_SNM_IdxTbl[ uchIdx ];
	gpST_UTI_Memset(&stOid, ST_SNC_ZEROPAD, sizeof(stOid));
	
	ulRet = ulST_SNM_ExtMib_FromIndexToOid(uchIdx, ulIndex, &stOid);
	if(ST_SNC_OK == ulRet) {
		switch(stOid.uiLen){
		case ST_SNM_IDX_0:
			break;
		case ST_SNM_IDX_1:
			ulIx	= stOid.auiOid[ST_SNM_IDX_0] - 1;
			ulOfset = pstIdxTbl->astInf[ST_SNM_IDX_0].ulStructSize * ulIx;
			break;
		case ST_SNM_IDX_2:
			ulIx	= stOid.auiOid[ST_SNM_IDX_0] - 1;
			ulIy	= stOid.auiOid[ST_SNM_IDX_1] - 1;
			ulOfset = pstIdxTbl->astInf[ST_SNM_IDX_0].ulStructSize * ulIx + 
					  pstIdxTbl->astInf[ST_SNM_IDX_1].ulStructSize * ulIy;
			break;
		default:
			ulRet = ST_SNC_NG_MIB_INDEX_REGNUM;
			break;
		}
	}
	else {
		;
	}

	if(ST_SNC_OK == ulRet) {
		*pulOffset = ulOfset;
	}
	else {
		;
	}

	return ulRet;
}

static	NX_ULONG ulST_SNM_ExtMib_FromOidToIndex(
	NX_UCHAR					uchIdx,
	const NX_VOID*				pvOidSuffix,
	NX_ULONG*					pulIndex
)
{
	const ST_SNM_Index*	pstIdxTbl		= NX_NULL;
	const ST_SNM_Oid*	pstOidSuffix	= NX_NULL;
	NX_ULONG				ulRet			= ST_SNC_OK;
	NX_ULONG				ulIndex			= 0;
	NX_ULONG				ulWork			= 0;

	pstIdxTbl = &gaST_SNM_IdxTbl[ uchIdx ];
	pstOidSuffix = (ST_SNM_Oid*)pvOidSuffix;

	if( ST_SNM_INDEXLEN < (UINT)pstIdxTbl->eNum)	{
		ulRet = ST_SNC_NG_PARAM_RANGE; 
	}
	else {

		switch(pstOidSuffix->uiLen) {
		case ST_SNM_IDX_0:
			break;
		case ST_SNM_IDX_1:
			if(0 < pstOidSuffix->auiOid[ST_SNM_IDX_0]) {
				if(pstOidSuffix->auiOid[ST_SNM_IDX_0] <= pstIdxTbl->astInf[ST_SNM_IDX_0].usAryMax) {
					ulIndex = pstOidSuffix->auiOid[ST_SNM_IDX_0] - 1;
				}
				else {
					ulRet = ST_SNC_NG_PARAM_INDEX; 
				}
			}
			else {
				ulRet = ST_SNC_NG_PARAM_INDEX; 
			}
			break;
		case ST_SNM_IDX_2:
			if(0 < pstOidSuffix->auiOid[ST_SNM_IDX_0]) {
				if(pstOidSuffix->auiOid[ST_SNM_IDX_0] <= pstIdxTbl->astInf[ST_SNM_IDX_0].usAryMax) {

					if(0 < pstOidSuffix->auiOid[ST_SNM_IDX_1]) {
						if(pstOidSuffix->auiOid[ST_SNM_IDX_1] <= pstIdxTbl->astInf[ST_SNM_IDX_1].usAryMax) {
							
							ulWork  = (pstOidSuffix->auiOid[ST_SNM_IDX_0] - 1) * pstIdxTbl->astInf[ST_SNM_IDX_1].usAryMax;
							ulIndex = ulWork + pstOidSuffix->auiOid[ST_SNM_IDX_1] - 1;
						}
						else {
							ulRet = ST_SNC_NG_PARAM_INDEX; 
						}
					}
					else {
						ulRet = ST_SNC_NG_PARAM_INDEX; 
					}
				}
				else {
					ulRet = ST_SNC_NG_PARAM_INDEX; 
				}
			}
			else {
				ulRet = ST_SNC_NG_PARAM_INDEX; 
			}
			break;
		default:
			ulRet = ST_SNC_NG_PARAM_RANGE; 
		}
	}

	if(ST_SNC_OK == ulRet) {
		*pulIndex = ulIndex;
	}
	else {
		;
	}

	return ulRet;
}
#endif
