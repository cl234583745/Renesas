/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "itron.h"
#include "kernel.h"
#include "ccienx_api.h"
#include "ETH_api.h"
#include "USN_api.h"
#include "local.h"
#include "socket.h"
#include "net.h"
#include "support.h"
#include "netdrv.h"
#include "SLMP_api.h"
#include "GDN_api.h"
#include "ccienx_app_supply.h"
#include "ccienx_event.h"
#include "NMG_api.h"

#define	USN_SELECT_TIME_OUT				((NX_USHORT)1000)
#define	USN_TX_CMP						((NX_USHORT)0)
#define	USN_TX_ACT						((NX_USHORT)1)
#define	USN_INVALID						((NX_SHORT)0)
#define	USN_VALID						((NX_SHORT)1)
#define	SOCKET_ERR						((NX_SHORT)-2)

#define	IP_FRAME_NO_RCV					((NX_USHORT)0)
#define	IP_FRAME_RCV					((NX_USHORT)1)
#define	IP_FRAME_NO_SND					((NX_USHORT)0)
#define	IP_FRAME_SND					((NX_USHORT)1)

#define	SOCKET_NO_USE					((NX_USHORT)0)
#define	SOCKET_WAIT_ACCEPT				((NX_USHORT)1)
#define	SOCKET_CONNECT					((NX_USHORT)2)

#define	INITSTATE_INIT					((NX_USHORT)0)
#define	INITSTATE_INITED				((NX_USHORT)1)
#define	IPSTATE_UNIQUE					((NX_USHORT)0)
#define	IPSTATE_DUPLICATE				((NX_USHORT)1)
#define	IP_NORMAL						((NX_USHORT)0)
#define	IP_DETECTION					((NX_USHORT)1)
#define	IP_OVERLAP						((NX_USHORT)2)

typedef struct _SOCKET_CTRL_TAG {
	NX_SHORT	sSocketDesc;
	NX_USHORT	usMyPort;
	NX_ULONG	ulMyIpAddress;
	NX_ULONG	ulRxFrameAddr;
	NX_USHORT	usSocketTypeDescTxSts;
	NX_SHORT	sSocketDescServer;
	NX_USHORT	usConnectSts;
	NX_USHORT	usProtocolType;
	NX_USHORT	usReInitFlg;
	NX_USHORT	usRsv;
} SOCKET_CTRL;

typedef struct _IP_FRAME_CTRL_TAG {
	NX_USHORT		usRcvSts;
	NX_USHORT		ausSndSts[NX_PORT_SIZE];
	NX_USHORT		usRsv1;
	NX_USHORT		usRcvFrameSize;
	NX_USHORT		usPort;
	NX_USHORT		usInitFlg;
	NX_USHORT		usIPState[NX_PORT_SIZE];
	NX_USHORT		usRsv2;
	NX_ULONG		ulRcvBufferAddr;
	NX_USHORT		usSndPort;
	NX_USHORT		usRsv3;
} IP_FRAME_CTRL;


SOCKET_CTRL		gstSocket[SOCKET_CONNECT_NUM];
IP_FRAME_CTRL	gstIpFrameCtrl;

IP_OVERLAP_ERR_CTRL	gstIpOverlapErrCtrl[NX_PORT_SIZE];

NX_ULONG ulUSN_CreateSocket(NX_LONG lType, NX_USHORT usSocketPort, NX_SHORT* psSocketDesc);
NX_LONG lUSN_ConnectSocket (NX_SHORT sSocketDesc, SOCKET_INFO_USNET* pstSocketInfoUsnet);
NX_VOID vUSN_UpdateNetdata (NX_VOID);

NX_VOID vUSN_Init (NX_VOID)
{
	NX_SHORT	sResult;
	NX_USHORT	usLoop;

	vNX_FillMemory32(&gstIpFrameCtrl, NX_L_ZERO, (sizeof(IP_FRAME_CTRL) / sizeof(NX_ULONG)));
	for (usLoop = NX_ZERO; usLoop < SOCKET_CONNECT_NUM; usLoop++) {
		vNX_FillMemory32(&gstSocket[usLoop], NX_L_ZERO, sizeof(SOCKET_CTRL) / sizeof(NX_ULONG));
	}
	for (usLoop = NX_ZERO; usLoop < NX_PORT_SIZE; usLoop++) {
		vNX_FillMemory16(&gstIpOverlapErrCtrl[usLoop], NX_US_ZERO, sizeof(IP_OVERLAP_ERR_CTRL) / sizeof(NX_USHORT));
	}

	sResult = Ninit();
	if (sResult < (NX_SHORT)NX_ZERO) {
		(NX_VOID)Nterm();
		vNX_SetEvent(EVENTCODE_USNET_ERR, NX_NULL);
	}
	else {
		vUSN_UpdateNetdata();
		sResult = Portinit("*");
		if (sResult < (NX_SHORT)NX_ZERO) {
			(NX_VOID)Nterm();
			vNX_SetEvent(EVENTCODE_USNET_ERR, NX_NULL);
		}
		else {
			vNTDRV_SnmpAgentInit();
		}
	}
	gstIpFrameCtrl.usInitFlg = INITSTATE_INITED;

	return;
}

NX_ULONG ulUSN_OpenSocket (NX_USHORT usProtocolType, NX_USHORT usSocketType, SOCKET_INFO_USNET* pstSocketInfoUsnet)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_LONG				lRslt = NX_NG;
	NX_SHORT			sSocketDesc = NX_ZERO;
	SOCKET_CTRL*		pstSocketCtrl;
	NX_ULONG			ulRslt = NX_UL_NG;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		if (NX_ZERO != pstSocketInfoUsnet->usMyPort) {
			pstSocketCtrl = &gstSocket[usSocketType];
			if (SOCKET_NO_USE == pstSocketCtrl->usConnectSts) {
				if (PROTOCOL_TCP_ACTIVE == usProtocolType) {
					ulRslt = ulUSN_CreateSocket(SOCK_STREAM, pstSocketInfoUsnet->usMyPort, &sSocketDesc);

					if (NX_UL_OK == ulRslt) {

						if (SOCKET_KEEPALIVE_USE == pstSocketInfoUsnet->ulKeepAlive) {
							(NX_VOID)setsockopt(sSocketDesc, SOL_SOCKET, SO_KEEPALIVE,
											 (char *)&pstSocketInfoUsnet->ulKeepAlive,
											  sizeof(pstSocketInfoUsnet->ulKeepAlive));
						}

						lRslt = lUSN_ConnectSocket(sSocketDesc, pstSocketInfoUsnet);

						if (NX_OK == lRslt) {
							pstSocketCtrl->sSocketDesc = sSocketDesc;
							pstSocketCtrl->sSocketDescServer = pstSocketCtrl->sSocketDesc;
							pstSocketCtrl->usMyPort = pstSocketInfoUsnet->usMyPort;
							pstSocketCtrl->ulMyIpAddress = gstNET.stSelf.ulIPAddress;
							pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
							pstSocketCtrl->usConnectSts = SOCKET_CONNECT;
							pstSocketCtrl->usProtocolType = usProtocolType;

							ulRet = NX_UL_OK;
						}
						else {
							(NX_VOID)closesocket(sSocketDesc);
						}
					}
					else {
					}
				}
				else if (PROTOCOL_TCP_PASSIVE == usProtocolType) {
					ulRslt = ulUSN_CreateSocket(SOCK_STREAM, pstSocketInfoUsnet->usMyPort, &sSocketDesc);

					if (NX_UL_OK == ulRslt) {
						if (SOCKET_KEEPALIVE_USE == pstSocketInfoUsnet->ulKeepAlive) {
							(NX_VOID)setsockopt(sSocketDesc, SOL_SOCKET, SO_KEEPALIVE,
											 (char *)&pstSocketInfoUsnet->ulKeepAlive,
											 sizeof(pstSocketInfoUsnet->ulKeepAlive));
						}

						lRslt = listen(sSocketDesc, (int)pstSocketInfoUsnet->ulListenNo);

						if (lRslt >= NX_ZERO) {
							pstSocketCtrl->sSocketDesc = sSocketDesc;
							pstSocketCtrl->sSocketDescServer = pstSocketCtrl->sSocketDesc;
							pstSocketCtrl->usMyPort = pstSocketInfoUsnet->usMyPort;
							pstSocketCtrl->ulMyIpAddress = gstNET.stSelf.ulIPAddress;
							pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
							pstSocketCtrl->usConnectSts = SOCKET_WAIT_ACCEPT;
							pstSocketCtrl->usProtocolType = usProtocolType;

							ulRet = NX_UL_OK;
						}
						else {
							(NX_VOID)closesocket(sSocketDesc);
						}
					}
					else {
					}
				}
				else if (PROTOCOL_UDP == usProtocolType) {
					ulRslt = ulUSN_CreateSocket(SOCK_DGRAM, pstSocketInfoUsnet->usMyPort, &sSocketDesc);

					if (NX_UL_OK == ulRslt) {
						(NX_VOID)setsockopt(sSocketDesc, SOL_SOCKET, SO_BROADCAST, NX_NULL, NX_ZERO);

						pstSocketCtrl->sSocketDesc = sSocketDesc;
						pstSocketCtrl->sSocketDescServer = pstSocketCtrl->sSocketDesc;
						pstSocketCtrl->usMyPort = pstSocketInfoUsnet->usMyPort;
						pstSocketCtrl->ulMyIpAddress = gstNET.stSelf.ulIPAddress;
						pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
						pstSocketCtrl->usConnectSts = SOCKET_CONNECT;
						pstSocketCtrl->usProtocolType = usProtocolType;

						ulRet = NX_UL_OK;
					}
					else {
					}
				}
				else {
				}
			}
		}
	}

	return ulRet;
}

NX_ULONG ulUSN_CreateSocket(NX_LONG lType, NX_USHORT usSocketPort, NX_SHORT* psSocketDesc)
{
	NX_SHORT			sSocketDesc = NX_ZERO;
	NX_SHORT			sOptionInfo = NX_ZERO;
	NX_LONG				lRslt = NX_NG;
	NX_USHORT			usGetData = NX_ZERO;
	struct sockaddr_in	stName;
	NX_ULONG			ulIpAddress = NX_ZERO;
	NX_ULONG			ulRet = NX_UL_NG;


	sSocketDesc = (NX_SHORT)socket(AF_INET, (int)lType, NX_ZERO);

	if (sSocketDesc >= NX_ZERO){
		sOptionInfo = USN_VALID;
		(NX_VOID)setsockopt(sSocketDesc, SOL_SOCKET, SO_REUSEADDR,
							 (char *)&sOptionInfo, sizeof(sOptionInfo));

		ulIpAddress = gstNET.stSelf.ulIPAddress;

		vNX_FillMemory(&stName, NX_C_ZERO, sizeof(stName));
		stName.sin_family = AF_INET;
		stName.sin_port = htons(usSocketPort);
		stName.sin_addr.s_addr = htonl(ulIpAddress);
		lRslt = (NX_LONG)bind(sSocketDesc, (struct sockaddr *) &stName, sizeof(struct sockaddr_in));

		if (lRslt >= NX_ZERO) {
			(NX_VOID)ioctlsocket(sSocketDesc, FIONBIO, &usGetData);
			*psSocketDesc = sSocketDesc;
			ulRet = NX_UL_OK;
		}
		else {
			(NX_VOID)closesocket(sSocketDesc);
		}
	}

	return ulRet;
}

NX_LONG lUSN_ConnectSocket (NX_SHORT sSocketDesc, SOCKET_INFO_USNET* pstSocketInfoUsnet)
{
	NX_LONG		lRet = NX_NG;
	NX_LONG		lRslt = NX_NG;
	struct sockaddr_in	stName;

	vNX_FillMemory(&stName, NX_C_ZERO, sizeof(stName));
	stName.sin_port = htons(pstSocketInfoUsnet->usPeerPort);
	stName.sin_addr.s_addr = htonl(pstSocketInfoUsnet->ulPeerIpAddress);

	lRslt = (NX_LONG)connect(sSocketDesc, (struct sockaddr *)&stName,
							 sizeof(stName), pstSocketInfoUsnet->usPhysicalPort);

	if (NX_OK == lRslt) {
		lRet = NX_OK;
	}
	else {
	}

	return lRet;
}

NX_ULONG ulUSN_AcceptSocket (NX_USHORT usSocketType, SOCKET_INFO_USNET* pstSocketInfoUsnet)
{
	NX_ULONG		ulRet = NX_UL_NG;
	struct sockaddr_in	stPeerInfo;
	NX_ULONG		ulNameSize = NX_ZERO;
	NX_SHORT		sSocketDescAccept = NX_ZERO;
	SOCKET_CTRL*	pstSocketCtrl;
	NX_ULONG			ulPhysicalPort = NX_ZERO;

	vNX_FillMemory(&stPeerInfo, NX_C_ZERO, sizeof(stPeerInfo));

	ulNameSize = (NX_ULONG)sizeof(stPeerInfo);

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {
			if (SOCKET_WAIT_ACCEPT == pstSocketCtrl->usConnectSts) {
				sSocketDescAccept = (NX_SHORT)accept(pstSocketCtrl->sSocketDesc,
									(struct sockaddr *)&stPeerInfo, (int *)&ulNameSize,
									(int*)&ulPhysicalPort);

				if (sSocketDescAccept >= NX_ZERO) {
					pstSocketCtrl->sSocketDescServer = pstSocketCtrl->sSocketDesc;
					pstSocketCtrl->sSocketDesc = sSocketDescAccept;
					pstSocketCtrl->usConnectSts = SOCKET_CONNECT;

					pstSocketInfoUsnet->ulPeerIpAddress = htonl(stPeerInfo.sin_addr.s_addr);
					pstSocketInfoUsnet->usPeerPort = htons(stPeerInfo.sin_port);
					pstSocketInfoUsnet->usPhysicalPort = (NX_USHORT)ulPhysicalPort;

					ulRet = NX_UL_OK;
				}
			}
			else {
				ulRet = NX_UL_OK;
			}
		}
	}

	return ulRet;
}

NX_ULONG ulUSN_CloseSocket (NX_USHORT usSocketType)
{
	NX_ULONG			ulRet = NX_UL_NG;
	SOCKET_CTRL*		pstSocketCtrl;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			(NX_VOID)closesocket(pstSocketCtrl->sSocketDesc);

			if ((PROTOCOL_TCP_PASSIVE == pstSocketCtrl->usProtocolType)
				&& (SOCKET_CONNECT == pstSocketCtrl->usConnectSts)) {
				(NX_VOID)closesocket(pstSocketCtrl->sSocketDescServer);
			}

			pstSocketCtrl->usConnectSts = SOCKET_NO_USE;
			ulRet = NX_UL_OK;
		}
	}

	return ulRet;
}

NX_USHORT usUSN_ChkRxFrame (NX_USHORT usSocketType)
{
	NX_USHORT			usRet = USN_RX_NG;
	fd_set				stReadFds;
	NX_SHORT			sSocketNum;
	struct timeval		stTimeVal;
	SOCKET_CTRL*		pstSocketCtrl;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {
			vNX_FillMemory(&stReadFds, NX_C_ZERO, sizeof(fd_set));


			if (SOCKET_CONNECT == pstSocketCtrl->usConnectSts) {
				FD_SET( pstSocketCtrl->sSocketDesc, &stReadFds );
			}
			else {
				FD_SET( pstSocketCtrl->sSocketDescServer, &stReadFds );
			}

			stTimeVal.tv_sec  = (NX_LONG)NX_ZERO;
			stTimeVal.tv_usec = (NX_LONG)NX_ZERO;

			sSocketNum = (NX_SHORT)selectsocket(pstSocketCtrl->sSocketDesc + 1,
							 &stReadFds, NX_NULL, NX_NULL, &stTimeVal);

			if (sSocketNum > NX_ZERO) {
				usRet = USN_RX_OK;
			}
		}
	}

	return usRet;
}

NX_USHORT usUSN_ChkRxFrameTCP (NX_USHORT usSocketType)
{
	NX_USHORT			usRet = USN_RX_NG;
	fd_set				stReadFds;
	NX_SHORT			sSocketNum;
	struct timeval		stTimeVal;
	SOCKET_CTRL*		pstSocketCtrl;
	NX_ULONG			ulFinSts;
	NX_ULONG			ulErrSts;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {
			vNX_FillMemory(&stReadFds, NX_C_ZERO, sizeof(fd_set));


			if (SOCKET_CONNECT == pstSocketCtrl->usConnectSts) {
				FD_SET( pstSocketCtrl->sSocketDesc, &stReadFds );
			}
			else {
				FD_SET( pstSocketCtrl->sSocketDescServer, &stReadFds );
			}

			stTimeVal.tv_sec  = (NX_LONG)NX_ZERO;
			stTimeVal.tv_usec = (NX_LONG)NX_ZERO;

			sSocketNum = (NX_SHORT)selectsocket(pstSocketCtrl->sSocketDesc + 1,
							 &stReadFds, NX_NULL, NX_NULL, &stTimeVal);

			if (sSocketNum > NX_ZERO) {

				ulFinSts = (NX_ULONG)SOCKET_TESTFIN(pstSocketCtrl->sSocketDesc);
				ulErrSts = (NX_ULONG)SOCKET_ISFATAL(pstSocketCtrl->sSocketDesc);
				
				if ((NX_ZERO == ulFinSts) && (NX_ZERO == ulErrSts)) {
					usRet = USN_RX_OK;
				}
			}
		}
	}

	return usRet;
}


NX_USHORT usUSN_ChkTxFrame (NX_USHORT usSocketType)
{
	NX_USHORT		usRet = USN_TX_NG;
	fd_set			stWriteFds;
	NX_SHORT		sSocketNum;
	SOCKET_CTRL*	pstSocketCtrl;
	struct timeval	stTimeVal;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			vNX_vDisableDispatch();

			if (pstSocketCtrl->usSocketTypeDescTxSts == USN_TX_CMP) {
				pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_ACT;

				vNX_vEnableDispatch();

				vNX_FillMemory(&stWriteFds, NX_C_ZERO, sizeof(fd_set));
				FD_SET( pstSocketCtrl->sSocketDesc, &stWriteFds );

				stTimeVal.tv_sec  = (NX_LONG)NX_ZERO;
				stTimeVal.tv_usec = (NX_LONG)NX_ZERO;

				sSocketNum = (NX_SHORT)selectsocket(pstSocketCtrl->sSocketDesc + 1, NX_NULL, &stWriteFds, NX_NULL, &stTimeVal);
				if (sSocketNum > NX_ZERO) {
					usRet = USN_TX_OK;
				}
				else {
					pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
				}
			}
			else {
				vNX_vEnableDispatch();
			}
		}
	}

	return usRet;
}
NX_USHORT usUSN_ChkTxFrameTCP (NX_USHORT usSocketType)
{
	NX_USHORT		usRet = USN_TX_NG;
	fd_set			stWriteFds;
	NX_SHORT		sSocketNum;
	SOCKET_CTRL*	pstSocketCtrl;
	struct timeval	stTimeVal;
	NX_ULONG		ulErrSts;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			vNX_vDisableDispatch();

			if (pstSocketCtrl->usSocketTypeDescTxSts == USN_TX_CMP) {
				pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_ACT;

				vNX_vEnableDispatch();

				vNX_FillMemory(&stWriteFds, NX_C_ZERO, sizeof(fd_set));
				FD_SET( pstSocketCtrl->sSocketDesc, &stWriteFds );

				stTimeVal.tv_sec  = (NX_LONG)NX_ZERO;
				stTimeVal.tv_usec = (NX_LONG)NX_ZERO;

				sSocketNum = (NX_SHORT)selectsocket(pstSocketCtrl->sSocketDesc + 1, NX_NULL, &stWriteFds, NX_NULL, &stTimeVal);
				if (sSocketNum > NX_ZERO) {
					ulErrSts = (NX_ULONG)SOCKET_ISFATAL(pstSocketCtrl->sSocketDesc);
					if (ulErrSts == NX_ZERO) {
						usRet = USN_TX_OK;
					}
					else {
						pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
					}
				}
				else {
					pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;
				}
			}
			else {
				vNX_vEnableDispatch();
			}
		}
	}

	return usRet;
}


NX_ULONG ulUSN_SetTxFrame (NX_USHORT usSocketType, TX_INFO_USNET* pstTxInfoUsnet)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_SHORT			sRslt;
	SOCKET_CTRL*		pstSocketCtrl;
	struct sockaddr_in	stPeerInfo;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			stPeerInfo.sin_addr.s_addr = htonl(pstTxInfoUsnet->ulDstIp);
			stPeerInfo.sin_port        = htons(pstTxInfoUsnet->usDstPort);

			sRslt = (NX_SHORT)sendto(pstSocketCtrl->sSocketDesc, (char *)pstTxInfoUsnet->puchTxData, pstTxInfoUsnet->usTxDataSize, NX_ZERO,
										(struct sockaddr *)&stPeerInfo, sizeof(stPeerInfo), (int)pstTxInfoUsnet->usPhysicalPort);
			pstSocketCtrl->usSocketTypeDescTxSts = USN_TX_CMP;

			if (sRslt > NX_ZERO) {
				ulRet = NX_UL_OK;
			}
		}
	}

	return ulRet;
}

NX_ULONG ulUSN_GetRxFrame (NX_USHORT usSocketType, RX_INFO_USNET* pstReciveInfoUsnet)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_SHORT			sRcvSize = NX_ZERO;
	SOCKET_CTRL*		pstSocketCtrl;
	struct sockaddr_in	stPeerInfo;
	NX_ULONG			ulSize = NX_ZERO;
	NX_ULONG			ulPhysicalPort = NX_ZERO;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {
			vNX_FillMemory(&stPeerInfo, NX_C_ZERO, sizeof(stPeerInfo));

			sRcvSize = (NX_SHORT)recvfrom(pstSocketCtrl->sSocketDesc, (char *)pstReciveInfoUsnet->puchRxAddr, pstReciveInfoUsnet->usRxDataSize, NX_ZERO,
										(struct sockaddr *)&stPeerInfo, (int *)&ulSize, (int *)&ulPhysicalPort);
			if (sRcvSize > NX_ZERO) {
				pstReciveInfoUsnet->ulSrcIp = htonl(stPeerInfo.sin_addr.s_addr);
				pstReciveInfoUsnet->usSrcPort = htons(stPeerInfo.sin_port);
				pstReciveInfoUsnet->usPhysicalPort = (NX_USHORT)ulPhysicalPort;

				pstReciveInfoUsnet->usRxFlameSize = (NX_USHORT)sRcvSize;
				
				vNMG_UpdateTxPhysicalPort(pstReciveInfoUsnet->ulSrcIp, pstReciveInfoUsnet->usPhysicalPort);
				ulRet = NX_UL_OK;
			}
		}
	}

	return ulRet;
}


NX_VOID vUSN_IpFrameRcv (NX_VOID)
{
	NX_ULONG		ulRslt;
	NX_UCHAR*		puchRcvTopAddr;
	NX_ULONG		ulRcvBufferAddr;
	NX_USHORT		usRcvFrameSize;
	NX_USHORT		usEthRcvSts;
	NX_USHORT		usPort;

	if (IP_FRAME_NO_RCV == gstIpFrameCtrl.usRcvSts) {
		ulRslt = ulETH_ChkEtherMacFrameRcv(&usEthRcvSts, &ulRcvBufferAddr, &usRcvFrameSize, &usPort);

		if (NX_UL_OK == ulRslt) {
			if (ETH_RX_FRAME == usEthRcvSts) {
				if ((IP_OVERLAP != gstIpOverlapErrCtrl[NX_PORT1].usIpErrSts) 
					&& (IP_OVERLAP != gstIpOverlapErrCtrl[NX_PORT2].usIpErrSts)) {
				
					if (gstIpFrameCtrl.usInitFlg != INITSTATE_INITED) {

						(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBufferAddr);
					}
					else {
						gstIpFrameCtrl.usRcvSts = IP_FRAME_RCV;
						gstIpFrameCtrl.ulRcvBufferAddr = ulRcvBufferAddr;
						gstIpFrameCtrl.usRcvFrameSize = usRcvFrameSize;
						gstIpFrameCtrl.usPort = usPort;
					}
				}
				else {
					(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBufferAddr);
				}
			}
		}
		else {
		}
	}
	if (IP_FRAME_RCV == gstIpFrameCtrl.usRcvSts) {
		if (gstIpFrameCtrl.usInitFlg != INITSTATE_INITED) {
			(NX_VOID)ulETH_HwFncBuffRelease(gstIpFrameCtrl.ulRcvBufferAddr);

			gstIpFrameCtrl.usRcvSts = IP_FRAME_NO_RCV;
		}
		else {
			puchRcvTopAddr = (NX_UCHAR *)gpuchNTDRV_ReceiveGetPacket(gstIpFrameCtrl.usPort, gstIpFrameCtrl.usRcvFrameSize);

			if (NX_NULL != puchRcvTopAddr) {
				vETH_EtherMacFrameRcv(puchRcvTopAddr, gstIpFrameCtrl.usRcvFrameSize);
				gNTDRV_ReceiveComplete(gstIpFrameCtrl.usPort, puchRcvTopAddr, gstIpFrameCtrl.usRcvFrameSize);

				(NX_VOID)ulETH_HwFncBuffRelease(gstIpFrameCtrl.ulRcvBufferAddr);

				gstIpFrameCtrl.usRcvSts = IP_FRAME_NO_RCV;
			}
		}
	}

	return;
}

NX_VOID vUSN_IpFrameSnd (NX_VOID)
{
	NX_ULONG		ulTxFlameSize;
	NX_UCHAR*		puchTxTopAddr;
	NX_USHORT		usEthSndSts;
	NX_ULONG		ulRslt;
	NX_USHORT		usSndPort;
	NX_ULONG		ulTxPortChangeFlg = (NX_ULONG)NX_OFF;
	NX_ULONG ulHwFuncErrFlg = (NX_ULONG)NX_OFF;
	
	vETH_GetHwFuncErrFlg(&ulHwFuncErrFlg);


	if ((IP_OVERLAP != gstIpOverlapErrCtrl[NX_PORT1].usIpErrSts) 
		&& (IP_OVERLAP != gstIpOverlapErrCtrl[NX_PORT2].usIpErrSts)) {

		usSndPort = gstIpFrameCtrl.usSndPort;

		if (IP_FRAME_NO_SND == gstIpFrameCtrl.ausSndSts[usSndPort]) {
			if (gstIpFrameCtrl.usInitFlg == INITSTATE_INITED) {
				if ((NX_ULONG)NX_OFF == ulHwFuncErrFlg) {
						ulTxFlameSize = gulNTDRV_TransmitGetPacket(usSndPort, &puchTxTopAddr);
						
						if (ulTxFlameSize != NX_ZERO) {
							vETH_EtherMacFrameSnd(puchTxTopAddr, ulTxFlameSize, usSndPort + 1);
							gNTDRV_TransmitComplete(usSndPort, puchTxTopAddr, ulTxFlameSize);
							
							ulRslt = ulETH_HwFncMacDmaSndStart();
							
							if (NX_UL_OK == ulRslt) {
								gstIpFrameCtrl.ausSndSts[usSndPort] = IP_FRAME_SND;
							}
							else {
								ulTxPortChangeFlg = (NX_ULONG)NX_ON;
							}
						}
						else {
							ulTxPortChangeFlg = (NX_ULONG)NX_ON;
						}
				}
				else {
					ulTxFlameSize = gulNTDRV_TransmitGetPacket(usSndPort, &puchTxTopAddr);
					
					if (ulTxFlameSize != NX_ZERO) {
						gNTDRV_TransmitComplete(usSndPort, puchTxTopAddr, ulTxFlameSize);
					}
					ulTxPortChangeFlg = (NX_ULONG)NX_ON;
				}
			}
		}
	
		if (IP_FRAME_SND == gstIpFrameCtrl.ausSndSts[usSndPort]) {
			
			vETH_EtherMacChkFrameSndCmp(&usEthSndSts, usSndPort + 1);

			if (ETHER_SND_CMP == usEthSndSts) {
				gstIpFrameCtrl.ausSndSts[usSndPort] = IP_FRAME_NO_SND;
				ulTxPortChangeFlg = (NX_ULONG)NX_ON;
			}
			else if (ETHER_SND_CMP_NG == usEthSndSts) {
				gstIpFrameCtrl.ausSndSts[usSndPort] = IP_FRAME_NO_SND;
				ulTxPortChangeFlg = (NX_ULONG)NX_ON;
			}
			else {
			}
		}
		
		if ((NX_ULONG)NX_ON == ulTxPortChangeFlg) {
			if ((NX_USHORT)NX_PORT1 == usSndPort) {
				gstIpFrameCtrl.usSndPort = (NX_USHORT)NX_PORT2;
			}
			else {
				gstIpFrameCtrl.usSndPort = (NX_USHORT)NX_PORT1;
			}
		}
	}

	return;
}

NX_VOID vUSN_IpFrameComm ( NX_VOID )
{
	NX_ULONG ulHwFuncErrFlg = (NX_ULONG)NX_OFF;

	vETH_GetHwFuncErrFlg(&ulHwFuncErrFlg);


	if ((NX_ULONG)NX_OFF == ulHwFuncErrFlg) {
		vUSN_IpFrameRcv();
	}
	vUSN_IpFrameSnd();


	return;
}

NX_ULONG ulUSN_ChkRxStatusFin (NX_USHORT usSocketType, NX_ULONG* pulRxStatusFinFlg)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_ULONG			ulRslt = NX_ZERO;
	SOCKET_CTRL*		pstSocketCtrl;

	*pulRxStatusFinFlg = NX_OFF;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			ulRslt = (NX_ULONG)SOCKET_TESTFIN(pstSocketCtrl->sSocketDesc);

			if (NX_ZERO != ulRslt) {
				*pulRxStatusFinFlg = NX_ON;
			}
			ulRet = NX_UL_OK;
		}
	}
	return ulRet;
}
NX_ULONG ulUSN_ChkRxStatusErr (NX_USHORT usSocketType, NX_ULONG* pulRxStatusErrFlg)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_ULONG			ulRslt = NX_ZERO;
	SOCKET_CTRL*		pstSocketCtrl;
	
	*pulRxStatusErrFlg = NX_OFF;
	
	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {
			
			ulRslt = (NX_ULONG)SOCKET_ISFATAL(pstSocketCtrl->sSocketDesc);
			
			if (NX_ZERO != ulRslt) {
				*pulRxStatusErrFlg = NX_ON;
			}
			ulRet = NX_UL_OK;
		}
	}
	return ulRet;
}


NX_ULONG ulUSN_ChkRxData (NX_USHORT usSocketType, NX_ULONG* pulRxDataFlg)
{
	NX_ULONG			ulRet = NX_UL_NG;
	NX_ULONG			ulRslt = NX_ZERO;
	SOCKET_CTRL*		pstSocketCtrl;

	*pulRxDataFlg = NX_OFF;

	if (usSocketType < SOCKET_CONNECT_NUM) {
		pstSocketCtrl = &gstSocket[usSocketType];

		if (SOCKET_NO_USE != pstSocketCtrl->usConnectSts) {

			ulRslt = (NX_ULONG)SOCKET_HASDATA(pstSocketCtrl->sSocketDesc);

			if (NX_ZERO != ulRslt) {
				*pulRxDataFlg = NX_ON;
			}
			ulRet = NX_UL_OK;
		}
	}
	return ulRet;
}

NX_VOID vUSN_ReInit (NX_VOID)
{
	NX_USHORT			usLoop;

	gstIpFrameCtrl.usInitFlg = INITSTATE_INIT;
	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < SOCKET_CONNECT_NUM; usLoop++) {
		gstSocket[usLoop].usConnectSts = SOCKET_NO_USE;
	}
	(NX_VOID)Nterm();

	vUSN_Init();

	for (usLoop = (NX_USHORT)NX_ZERO; usLoop < SOCKET_CONNECT_NUM; usLoop++) {
		gstSocket[usLoop].usReInitFlg = USN_REINIT_ON;
	}
	return;
}

NX_VOID vUSN_UpdateNetdata (NX_VOID)
{
	NX_USHORT		usLoopCount;
	NX_SHORT		sInterFaceNo;
	struct SETIid	stIPAddr;
	struct SETIid	stSubnetMask;
	struct SETEid	stMacAddr;

	sInterFaceNo = 0;

	stIPAddr.no		= sInterFaceNo;
	stIPAddr.addr.l = htonl(gstNET.stSelf.ulIPAddress);
	Nioctl(ussSetIaddr, &stIPAddr);

	stSubnetMask.no		= sInterFaceNo;
	stSubnetMask.addr.l = htonl(gstNET.stSelf.ulSubnetMask);
	Nioctl(ussSetImask, &stSubnetMask);

	stMacAddr.no	= sInterFaceNo;
	for (usLoopCount = (NX_USHORT)NX_ZERO; usLoopCount < (NX_USHORT)NX_MAC_ADDR_SIZE; usLoopCount++) {
		stMacAddr.addr.c[usLoopCount] = gstAppInfo.stEthInfo.auchMacAddress[usLoopCount];
	}
	Nioctl(ussSetEaddr, &stMacAddr);
	return;
}

NX_VOID vUSN_UsnetPeriodic (NX_VOID)
{
	YIELD();
	return;
}

NX_USHORT usUSN_GetReInitFlg (
	NX_USHORT	usSocketType
)
{
	NX_USHORT	usResult;

	usResult = gstSocket[usSocketType].usReInitFlg;
	return usResult;
}

NX_VOID vUSN_ClearReInitFlg (
	NX_USHORT	usSocketType
)
{
	gstSocket[usSocketType].usReInitFlg = USN_REINIT_OFF;
	return;
}

NX_USHORT usUSN_DuplicatIP (NX_USHORT usPort)
{
	NX_USHORT   usResult;

	if (IP_OVERLAP == gstIpOverlapErrCtrl[usPort].usIpErrSts) {
		usResult = NX_US_NG;
	}
	else {
		usResult = NX_US_OK;
	}

	return usResult;
}

NX_VOID vUSN_SetGlbIpOverlapErrCtrl (
	NX_USHORT usPhysicalPort,
	IP_OVERLAP_ERR_CTRL* pstIpOverlapErrCtrl
)
{
	gstIpOverlapErrCtrl[usPhysicalPort] = *pstIpOverlapErrCtrl;
	return;
}

NX_VOID vUSN_GetGlbIpOverlapErrCtrl (
	NX_USHORT usPhysicalPort,
	IP_OVERLAP_ERR_CTRL* pstIpOverlapErrCtrl
)
{
	*pstIpOverlapErrCtrl = gstIpOverlapErrCtrl[usPhysicalPort];
	return;
}

