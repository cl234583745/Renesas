/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "NGN_ASIC.h"
#include "JADE.h"

#define	WDT_CTL_CNT_EN		((NX_UCHAR)0x01)
#define	WDT_CTL_CNT_DI		((NX_UCHAR)0x00)
#define	WDT_CTL_CLEAR		((NX_UCHAR)0x01)

#define	EXCPUWDT_CNT_EN		((NX_ULONG)0x00000001)
#define	EXCPUWDT_CNT_DIS	((NX_ULONG)0x00000000)
#define	EXCPUWDT_CLR		((NX_ULONG)0x00000001)
#define	WDT_BASE_CLOCK		((NX_ULONG)8)
#define	CHANGE_100MS_TO_NS	((NX_ULONG)100000000)
#define	EXCPUWDT_COUNT		((NX_ULONG)5)
#define	WDT_COUNT_MAX		((NX_ULONG)63 - EXCPUWDT_COUNT)
#define	WDT_COUNT_MIN		((NX_ULONG)1)

NX_VOID vNX_InitWdt (
	NX_ULONG ulWdtCount
)
{
	NX_ULONG	ulWdtCountTemp;
	NX_ULONG	ulWdtCountForNwIp;
	
	ulWdtCountTemp = ulWdtCount;
	
	if (ulWdtCountTemp > WDT_COUNT_MAX) {
		ulWdtCountTemp = WDT_COUNT_MAX;
	}
	if (ulWdtCountTemp == NX_ZERO) {
		ulWdtCountTemp = WDT_COUNT_MIN;
	}
	
	ulWdtCountForNwIp = (ulWdtCountTemp * CHANGE_100MS_TO_NS) / WDT_BASE_CLOCK;
	
	NGN_WDT_REG->R_RE_WDTCOUNT 	= ulWdtCountForNwIp;
	NX_JADE_SYS->R_WDTSET		= ulWdtCountTemp + EXCPUWDT_COUNT;

	return;
}

NX_VOID vNX_StartWdt (NX_VOID)
{
#ifndef FOR_DEBUG
	NGN_WDT_REG->R_RE_WDTCNT = WDT_CTL_CNT_EN;
	NX_JADE_SYS->R_WDTCNT	=	EXCPUWDT_CNT_EN;
#endif

	return;
}

NX_VOID vNX_StopWdt (NX_VOID)
{
	NGN_WDT_REG->R_RE_WDTCNT = WDT_CTL_CNT_DI;
	NX_JADE_SYS->R_WDTCNT	 = EXCPUWDT_CNT_DIS;

	return;
}

NX_VOID vNX_ClearWdt (NX_VOID)
{
	NGN_WDT_REG->R_RE_WDTRST = WDT_CTL_CLEAR;
	NX_JADE_SYS->R_WDTCLR	 = EXCPUWDT_CLR;

	return;
}
