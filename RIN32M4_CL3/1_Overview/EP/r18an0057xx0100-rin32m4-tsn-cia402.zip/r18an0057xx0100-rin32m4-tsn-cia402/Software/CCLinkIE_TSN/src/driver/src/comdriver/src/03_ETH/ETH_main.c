/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "ccienx_api.h"
#include "ETH_api.h"
#include "ETH_sw.h"
#include "INTR_api.h"
#include "ccienx_app_supply.h"
#include "ccienx_event.h"

#include "R_IN32M4_CL3.h"


#define	ETHER_CONNET_INFO_NUM		((NX_USHORT)20)

#define	ETHER_SHORT_SIZE			((NX_USHORT)128)
#define	ETHER_LONG_SIZE				((NX_USHORT)2048)

#define	RXMAC_DISABLE				((NX_ULONG)0x00000000)
#define	RXMAC_ENABLE				((NX_ULONG)0x00000001)

#define	NO_RCV_BUFFER				((NX_ULONG)0x00000000)
#define	RCV_BUFFER					((NX_ULONG)0x80000000)
#define	RCV_BUFFER_INVALID			((NX_ULONG)0x00000000)
#define	RCV_BUFFER_VALID			((NX_ULONG)0x10000000)

#define BUFID_ADDR					((NX_ULONG)0x0000FFFF)
#define BUFID_WORD					((NX_ULONG)0x0FFF0000)
#define BUFRAM_OFFSET				((NX_ULONG)0x08000000)

#define TX_TCMP						((NX_ULONG)0x00002000)
#define TX_TABT						((NX_ULONG)0x00001000)
#define TX_TFAIL					((NX_ULONG)0x00000800)

#define ETHFRM_HD_MAC_LEN			((NX_USHORT)12)
#define ETHFRM_HD_VLANTYPE_LEN		((NX_USHORT)2)
#define ETHFRM_HD_VLANID_LEN		((NX_USHORT)2)
#define ETHFRM_HD_TYPE_LEN			((NX_USHORT)2)
#define ETHFRM_HD_LEN				(ETHFRM_HD_MAC_LEN + ETHFRM_HD_TYPE_LEN)
#define ETHFRM_HD_VLANLEN			(ETHFRM_HD_MAC_LEN + ETHFRM_HD_VLANTYPE_LEN + ETHFRM_HD_VLANID_LEN + ETHFRM_HD_TYPE_LEN)
#define ETHFRM_HD_PAD				((NX_USHORT)2)
#define ETHFRM_HD_ACTLEN			(ETHFRM_HD_LEN + ETHFRM_HD_PAD)
#define ETHFRM_HD_VLANACTLEN		(ETHFRM_HD_MAC_LEN + ETHFRM_HD_VLANTYPE_LEN + ETHFRM_HD_PAD)
#define ETHFRM_FCS_LEN				((NX_USHORT)4)

#define RCV_INFO_SIZE				((NX_ULONG)2)
#define RX_FRMINFO0_CRCERR			((NX_ULONG)0x00000001)
#define RX_FRMINFO0_NBLERR			((NX_ULONG)0x00000002)
#define RX_FRMINFO0_FIFOFULL		((NX_ULONG)0x00000004)
#define RX_FRMINFO0_SHORT			((NX_ULONG)0x00000008)
#define RX_FRMINFO0_LONG			((NX_ULONG)0x00000010)
#define RX_FRMINFO0_MARNOTMT		((NX_ULONG)0x00000020)
#define RX_FRMINFO0_WORD			((NX_ULONG)0x7FFF0000)
#define RX_FRMINFO1_VTAG			((NX_ULONG)0x00000001)
#define RX_FRMINFO1_TYPEIP			((NX_ULONG)0x00000008)
#define RX_FRMINFO1_TCPNG			((NX_ULONG)0x00000040)
#define RX_FRMINFO1_IPNG			((NX_ULONG)0x00000080)
#define RX_FRMINFO_CHKSUM			(RX_FRMINFO1_TCPNG | RX_FRMINFO1_IPNG)
#define RX_FRMINFO_VALID			(RX_FRMINFO0_CRCERR | RX_FRMINFO0_NBLERR | RX_FRMINFO0_FIFOFULL | RX_FRMINFO0_SHORT | RX_FRMINFO0_MARNOTMT)

#define IPPKT_CRCT					((NX_USHORT)4)
#define VLAN_SIZE					((NX_USHORT)4)
#define IP_HD_FLGS_FO				(ETHFRM_HD_PAD + 0x14)
#define IP_HD_FLGS_MSK				((NX_USHORT)0xE000)
#define IP_HD_FLGS_DF				((NX_USHORT)0x4000)
#define IP_HD_FLSG_MF				((NX_USHORT)0x2000)
#define IP_HD_FO_MSK				((NX_USHORT)0x1FFF)

#define TX_FRMINFO0_APAD			((NX_ULONG)0x00000004)
#define TX_FRMINFO0_ITAG			((NX_ULONG)0x00000010)
#define TX_FRMINFO0_TXTIME			((NX_ULONG)0x00000080)
#define TX_FRMINFO0_FFW				((NX_ULONG)0x00000100)
#define ETH_FRMCNT_SIZE				((NX_ULONG)2)
#define ETH_FRMCNT_LEN				(ETH_FRMCNT_SIZE * sizeof(NX_ULONG))

#define TPID_VLAN_TAG				((NX_USHORT)0x8100)

#define DESC_END					((NX_ULONG)0xFFFFFFFF)

#define ETH_PORT0					((NX_USHORT)1)
#define ETH_PORT1					((NX_USHORT)2)

#define R0_SYSTEM_CALL				((NX_ULONG)0x20000000)

#define SYSCALL_OK					((NX_ULONG)0x00000000)
#define SND_ERR						((NX_ULONG)0x00000001)
#define RCV_ENA_ERR					((NX_ULONG)0x00000001)
#define RCV_DIS_ERR					((NX_ULONG)0x00000001)
#define BUFF_RELEASE_ERR			((NX_ULONG)0x00000003)
#define SHORT_BUFF_GET_ERR			((NX_ULONG)0x00000003)
#define LONG_BUFF_GET_ERR			((NX_ULONG)0x00000003)

#define SYS_MACDMA_SND_START		((NX_USHORT)0x5100)
#define SYS_BUFF_RELEASE			((NX_USHORT)0x5001)
#define SYS_MACDMA_RCV_ENA			((NX_USHORT)0x5101)
#define SYS_MACDMA_RCV_DIS			((NX_USHORT)0x5102)
#define SYS_SHORT_BUFF_GET			((NX_USHORT)0x5006)
#define SYS_LONG_BUFF_GET			((NX_USHORT)0x5000)
#define MSK_RX_FIFO					((NX_ULONG)0x00000FFF)

#define	NVIC_ON						((NX_ULONG)1)
#define	NVIC_OFF					((NX_ULONG)0)
#define MSK_MACLIST					((NX_UCHAR)0x0F)
#define	INDEX_MACLIST_LLDP			((NX_UCHAR)1)

typedef struct tagTX_DESC_BUF {
	NX_ULONG		ulTopAddr;
	NX_ULONG		ulSize;
} TX_DESC_BUF;

typedef struct tagETHER_MAC_CTRL {
	NX_UCHAR*		puchSndFramePtr;
	NX_ULONG*		pulSndInfoPtr;
	TX_DESC_BUF*	pstSndDescPtr;
	NX_ULONG		ulRcvBuffAddr;
	NX_ULONG		ulRcvBuffSize;
	NX_ULONG		ulRcvVlanFlg;
	NX_ULONG		ulSndVlanFlg;
	NX_ULONG		ulSndCmpFlg;
	NX_ULONG		ulRamEmptyPortFlg;
	NX_USHORT		usSndPort;
	NX_USHORT		usRsv;
	NX_ULONG		ulHwFuncErrFlg;
	NX_ULONG		ulFifoOverErrFlg;
} ETHER_MAC_CTRL;

typedef struct tagCONNECT_DATA {
	NX_USHORT		usPort;
	NX_UCHAR		auchMacAddr[MAC_ADDR_SIZE];
} CONNECT_DATA;

typedef struct tagETHER_FRM {
	NX_UCHAR		auchDstMac[MAC_ADDR_SIZE];
	NX_UCHAR		auchSrcMac[MAC_ADDR_SIZE];
	NX_USHORT		usType;
	NX_UCHAR		auchData[2];
} ETHER_FRM;

typedef struct tagSYSCALL_REG {
	NX_ULONG		ulR0Reg;
	NX_ULONG		ulR1Reg;
	NX_ULONG		ulR4Reg;
	NX_ULONG		ulR5Reg;
	NX_ULONG		ulR6Reg;
	NX_ULONG		ulR7Reg;
} SYSCALL_REG;

NX_STATIC ETHER_MAC_CTRL	gstEtherMacCtrl;

NX_ULONG ulETH_ChkRcvFrameInfo (NX_USHORT* pusRcvFrameSize, NX_ULONG* pulVlanTagFlg, NX_ULONG* pulErrInfo, NX_USHORT* pusPort);
NX_VOID vETH_GetRcvPort (NX_USHORT* pusPort);
NX_VOID vETH_MakeSndFrameInfo (NX_UCHAR* puchSndTopAddr, NX_ULONG ulSndSize, NX_USHORT usPort);
NX_VOID vETH_MakeSndDesc (NX_ULONG ulSndSize);
NX_VOID vETH_HwFncExeSysCall (NX_USHORT usCmd, SYSCALL_REG* pstSysCallReg);
NX_ULONG ulETH_HwFncMacDmaRcvEna (NX_VOID);
NX_ULONG ulETH_HwFncShortBufferGet (NX_ULONG* pulBufferAddr, NX_ULONG ulBufferSize);
NX_ULONG ulETH_HwFncLongBufferGet (NX_ULONG* pulBufferAddr, NX_ULONG ulBufferSize);
NX_VOID vETH_RcvFifoOverClr (NX_ULONG ulRcvAddr);

NX_VOID vETH_Init (NX_VOID)
{
	NX_ULONG	ulRslt;
	NX_ULONG	ulSndInfoAddr;
	NX_ULONG	ulSndDescAddr;
	NX_ULONG	ulSndFrameAddr;
	
	vETH_EtherSwInit();
	vNX_FillMemory32(&gstEtherMacCtrl, NX_L_ZERO, sizeof(ETHER_MAC_CTRL) / sizeof(NX_ULONG));
	
	ulRslt = ulETH_HwFncShortBufferGet(&ulSndInfoAddr, ETHER_SHORT_SIZE);
	if (NX_UL_OK == ulRslt) {
		gstEtherMacCtrl.pulSndInfoPtr = (NX_ULONG *)ulSndInfoAddr;
		
		ulRslt = ulETH_HwFncShortBufferGet(&ulSndDescAddr, ETHER_SHORT_SIZE);

		if (NX_UL_OK == ulRslt) {
			gstEtherMacCtrl.pstSndDescPtr = (TX_DESC_BUF *)ulSndDescAddr;
			
			ulRslt = ulETH_HwFncLongBufferGet(&ulSndFrameAddr, ETHER_LONG_SIZE);
			
			if (NX_UL_OK == ulRslt) {
				gstEtherMacCtrl.puchSndFramePtr = (NX_UCHAR *)ulSndFrameAddr;
			
				if ((RIN_ETH->GMAC_RXMAC_ENA & RXMAC_DISABLE) == RXMAC_DISABLE) {
					RIN_ETH->GMAC_RXMAC_ENA = RXMAC_ENABLE;
				}
				
				(NX_VOID)ulETH_HwFncMacDmaRcvEna();
			}
			else {
			}
		}
		else {
		}
	}
	else {
	}

	return;
}

NX_ULONG ulETH_ChkEtherMacFrameRcv (NX_USHORT* pusEthRcvSts, NX_ULONG* pulRcvBuffAddr, NX_USHORT* pusRcvFrameSize, NX_USHORT* pusPort)
{
	NX_ULONG	ulBuffId;
	NX_ULONG	ulRcvBuffAddr;
	NX_ULONG	ulRcvBuffSize;
	NX_ULONG	ulRslt;
	NX_ULONG	ulRet = NX_UL_NG;
	NX_ULONG	ulVlanTagFlg;
	NX_ULONG	ulErrInfo;
	NX_ULONG	ulRxBuffOverResult;
	NX_USHORT	usRcvFrameSize;
	NX_USHORT	usPort;
	
	ulBuffId = RIN_ETH->BUFID;
	ulRcvBuffAddr = (((ulBuffId & BUFID_ADDR) << NX_SHIFT11) | BUFRAM_OFFSET);
	ulRcvBuffSize = ((ulBuffId & BUFID_WORD) >> NX_SHIFT16);
	
	ulRxBuffOverResult = (NX_ULONG)NVIC_GetPendingIRQ(ETHRXFIFO_IRQn);
	if (ulRxBuffOverResult == NVIC_ON) {
		NVIC_ClearPendingIRQ(ETHRXFIFO_IRQn);
		vETH_RcvFifoOverClr(ulRcvBuffAddr);
		return ulRet;
	}
	if ((ulBuffId & RCV_BUFFER) == RCV_BUFFER) {
		if ((ulBuffId & RCV_BUFFER_VALID) == RCV_BUFFER_VALID) {
			if ((NX_ULONG)NX_OFF == gstEtherMacCtrl.ulFifoOverErrFlg) {

				gstEtherMacCtrl.ulRcvBuffAddr = ulRcvBuffAddr;
				gstEtherMacCtrl.ulRcvBuffSize = ulRcvBuffSize;
				
				ulRslt = ulETH_ChkRcvFrameInfo(&usRcvFrameSize, &ulVlanTagFlg, &ulErrInfo, &usPort);
				
				if (NX_UL_OK == ulRslt) {
					gstEtherMacCtrl.ulRcvVlanFlg = ulVlanTagFlg;
					*pulRcvBuffAddr = ulRcvBuffAddr;
					*pusRcvFrameSize = usRcvFrameSize;
					*pusEthRcvSts = ETH_RX_FRAME;
					*pusPort = usPort;
					ulRet = NX_UL_OK;
				}
				else {
					(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBuffAddr);
				}

			}
			else {
				(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBuffAddr);
				gstEtherMacCtrl.ulFifoOverErrFlg = (NX_ULONG)NX_OFF;
			}
		}
		else {
			(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBuffAddr);
		}
	}
	else {
		*pusEthRcvSts = ETH_RX_NO_FRAME;
		ulRet = NX_UL_OK;
	}

	return ulRet;
}

NX_VOID vETH_EtherMacFrameRcv (NX_UCHAR* puchRcvTopAddr, NX_USHORT usRcvFrameSize)
{
    ETHER_FRM*  pstEtherFrm;
    NX_UCHAR	uchMacListIndex;
	
	if (NX_ON == gstEtherMacCtrl.ulRcvVlanFlg) {
		vNX_CopyMemory(puchRcvTopAddr, (NX_VOID *)gstEtherMacCtrl.ulRcvBuffAddr, ETHFRM_HD_LEN);
		
		vNX_CopyMemory((NX_VOID *)(puchRcvTopAddr + ETHFRM_HD_LEN), 
						(NX_VOID *)(gstEtherMacCtrl.ulRcvBuffAddr + ETHFRM_HD_ACTLEN), 
						ETHFRM_HD_VLANID_LEN + ETHFRM_HD_TYPE_LEN);
		
		vNX_CopyMemory((NX_VOID *)(puchRcvTopAddr + ETHFRM_HD_LEN + ETHFRM_HD_VLANID_LEN + ETHFRM_HD_TYPE_LEN), 
						(NX_VOID *)(gstEtherMacCtrl.ulRcvBuffAddr + ETHFRM_HD_ACTLEN + ETHFRM_HD_VLANID_LEN + ETHFRM_HD_TYPE_LEN),
						 usRcvFrameSize - ETHFRM_HD_LEN - ETHFRM_HD_VLANID_LEN - ETHFRM_HD_TYPE_LEN);
	}
	else {
		vNX_CopyMemory(puchRcvTopAddr, (NX_VOID *)gstEtherMacCtrl.ulRcvBuffAddr, ETHFRM_HD_LEN);
		
		vNX_CopyMemory((NX_VOID *)(puchRcvTopAddr + ETHFRM_HD_LEN), 
						(NX_VOID *)(gstEtherMacCtrl.ulRcvBuffAddr + ETHFRM_HD_ACTLEN), 
						usRcvFrameSize - ETHFRM_HD_LEN);
	}
    pstEtherFrm = (ETHER_FRM *)puchRcvTopAddr;
	uchMacListIndex = pstEtherFrm->auchDstMac[4] & (NX_UCHAR)MSK_MACLIST;
	
	if (uchMacListIndex == INDEX_MACLIST_LLDP) {
		vNX_CopyMemory(pstEtherFrm->auchDstMac, (NX_VOID*)&gauchLLDPMultiMac[0], MAC_ADDR_SIZE);
	}
	return;
}

NX_VOID vETH_EtherMacFrameSnd (NX_UCHAR* puchSndTopAddr, NX_ULONG ulSndSize, NX_USHORT usPort)
{
	vNX_CopyMemory(gstEtherMacCtrl.puchSndFramePtr, puchSndTopAddr, ulSndSize);
	vETH_MakeSndFrameInfo(puchSndTopAddr, ulSndSize, usPort);
	vETH_MakeSndDesc(ulSndSize);
	
	return;
}

NX_VOID vETH_EtherMacChkFrameSndCmp (NX_USHORT* pusEthSndSts, NX_USHORT usPort)
{
	NX_ULONG	ulTxRsltReg;
	NX_ULONG	ulRlst;
	NX_ULONG	ulIntFactor;
	
	*pusEthSndSts = ETHER_SND;

	if (NX_OFF == gstEtherMacCtrl.ulSndCmpFlg) {
		ulTxRsltReg = RIN_ETH->GMAC_TXRESULT;
		
		if((ulTxRsltReg & TX_TCMP) == TX_TCMP) {
			gstEtherMacCtrl.ulSndCmpFlg = NX_ON;
		}
		else if ((ulTxRsltReg & TX_TABT) == TX_TABT) {
			*pusEthSndSts = ETHER_SND_CMP_NG;
		}
		else if ((ulTxRsltReg & TX_TFAIL) == TX_TFAIL) {
			*pusEthSndSts = ETHER_SND_CMP_NG;
		}
		else {
		}
	}

	if (ETHER_SND == *pusEthSndSts) {
		if (NX_OFF == gstEtherMacCtrl.ulRamEmptyPortFlg) {
			
			if (ETH_PORT0 == usPort) {
				ulIntFactor = INTR_LOW_GIGAMAC_PORT1;
			}
			else {
				ulIntFactor = INTR_LOW_GIGAMAC_PORT2;
			}
			
			ulRlst = ulINTR_CheckIntLow(ulIntFactor);
			if (NX_ON == ulRlst) {
				vINTR_ClearIntLow(ulIntFactor);
				gstEtherMacCtrl.ulRamEmptyPortFlg = NX_ON;
			}
		}

		if ((NX_ON == gstEtherMacCtrl.ulSndCmpFlg)
			&& (NX_ON == gstEtherMacCtrl.ulRamEmptyPortFlg)) {
			gstEtherMacCtrl.ulSndCmpFlg = NX_OFF;
			gstEtherMacCtrl.ulRamEmptyPortFlg = NX_OFF;
			*pusEthSndSts = ETHER_SND_CMP;
		}
	}

	return;
}

NX_ULONG ulETH_ChkRcvFrameInfo (NX_USHORT* pusRcvFrameSize, NX_ULONG* pulVlanTagFlg, NX_ULONG* pulErrInfo, NX_USHORT* pusPort)
{
	NX_ULONG	ulRet = NX_UL_OK;
	NX_ULONG*	pulRcvInfo;
	NX_ULONG	ulSize;
	NX_ULONG	ulVlanTagFlg;
	NX_USHORT	usVlanSize;
	NX_USHORT	usFlags;
	NX_USHORT	usIpChkSum;
	
	
	pulRcvInfo = (NX_ULONG *)gstEtherMacCtrl.ulRcvBuffAddr + gstEtherMacCtrl.ulRcvBuffSize - RCV_INFO_SIZE;

	if((pulRcvInfo[1] & RX_FRMINFO1_VTAG) == RX_FRMINFO1_VTAG) {
		ulVlanTagFlg = NX_ON;
		usVlanSize = VLAN_SIZE;
	}
	else {
		ulVlanTagFlg = NX_OFF;
		usVlanSize = 0;
	}
	
	if ((pulRcvInfo[0] & RX_FRMINFO_VALID) == 0) {
		ulSize = (((pulRcvInfo[0] & RX_FRMINFO0_WORD) >> NX_SHIFT16) - 3);
		ulSize = ulSize - ETHFRM_HD_PAD - ETHFRM_FCS_LEN;
		
		if ((ulSize & NX_BIT31) != NX_BIT31) {
			if ((pulRcvInfo[1] & RX_FRMINFO1_TYPEIP) == RX_FRMINFO1_TYPEIP) {
				ulSize = ulSize + IPPKT_CRCT;
			}
			*pusRcvFrameSize = (NX_USHORT)ulSize;
			*pulVlanTagFlg = ulVlanTagFlg;
			
			vETH_GetRcvPort(pusPort);
		}
		else {
			ulRet = NX_UL_NG;
		}
	}
	else {
		ulRet = NX_UL_NG;
		
	}
	
	*pulErrInfo = pulRcvInfo[0];
	
	return ulRet;
}

NX_VOID vETH_GetRcvPort (NX_USHORT* pusPort)
{
	ETHER_FRM*	pstEtherFrm;
	
	pstEtherFrm = (ETHER_FRM *)gstEtherMacCtrl.ulRcvBuffAddr;
	*pusPort = ((pstEtherFrm->auchDstMac[4] >> NX_SHIFT7) & 0x0001);
	
	return;
}

NX_VOID vETH_MakeSndFrameInfo (NX_UCHAR* puchSndTopAddr, NX_ULONG ulSndSize, NX_USHORT usPort)
{
	ETHER_FRM*	pstEtherFrm;
	NX_USHORT	usTpid;
	
	pstEtherFrm = (ETHER_FRM *)puchSndTopAddr;
	
	gstEtherMacCtrl.pulSndInfoPtr[0] = (ulSndSize + 3) << NX_SHIFT16;
	gstEtherMacCtrl.pulSndInfoPtr[0] |= TX_FRMINFO0_APAD;
	
	usTpid = (NX_USHORT)pstEtherFrm->auchData[0];
	
	if (TPID_VLAN_TAG == usTpid) {
		gstEtherMacCtrl.pulSndInfoPtr[0] |= TX_FRMINFO0_ITAG;
		gstEtherMacCtrl.ulSndVlanFlg = NX_ON;
	}
	else{
		gstEtherMacCtrl.ulSndVlanFlg = NX_OFF;
	}
	
	gstEtherMacCtrl.pulSndInfoPtr[0] |= TX_FRMINFO0_FFW;
	
	gstEtherMacCtrl.pulSndInfoPtr[0] |= (usPort << NX_SHIFT9);
	gstEtherMacCtrl.pulSndInfoPtr[0] |= TX_FRMINFO0_TXTIME;
	
	return;
}

NX_VOID vETH_MakeSndDesc (NX_ULONG ulSndSize)
{
	NX_USHORT		usDscCnt = 0;
	TX_DESC_BUF*	pstSndDesc;
	NX_UCHAR*		puchSndFrame;
	NX_ULONG*		pulSndInfo;
	
	pstSndDesc = (TX_DESC_BUF*)gstEtherMacCtrl.pstSndDescPtr;
	puchSndFrame = (NX_UCHAR*)gstEtherMacCtrl.puchSndFramePtr;
	pulSndInfo = (NX_ULONG*)gstEtherMacCtrl.pulSndInfoPtr;
	
	
	pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)pulSndInfo;
	pstSndDesc[usDscCnt].ulSize = (NX_ULONG)ETH_FRMCNT_LEN;
	usDscCnt++;
	
	if (NX_ON == gstEtherMacCtrl.ulSndVlanFlg) {
		pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)puchSndFrame;
		pstSndDesc[usDscCnt].ulSize = (NX_ULONG)ETHFRM_HD_VLANACTLEN;
		usDscCnt++;
		
		pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)puchSndFrame + ETHFRM_HD_MAC_LEN + ETHFRM_HD_VLANTYPE_LEN;
		pstSndDesc[usDscCnt].ulSize = (NX_ULONG)(ETHFRM_HD_VLANID_LEN + ETHFRM_HD_TYPE_LEN);
		usDscCnt++;
		
		pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)puchSndFrame + ETHFRM_HD_VLANLEN;
		pstSndDesc[usDscCnt].ulSize = (NX_ULONG)(ulSndSize - ETHFRM_HD_VLANLEN);
		usDscCnt++;
	}
	else {
		pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)puchSndFrame;
		pstSndDesc[usDscCnt].ulSize = (NX_ULONG)ETHFRM_HD_ACTLEN;
		usDscCnt++;
		
		pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)puchSndFrame + ETHFRM_HD_LEN;
		pstSndDesc[usDscCnt].ulSize = (NX_ULONG)(ulSndSize - ETHFRM_HD_LEN);
		usDscCnt++;
	}
	pstSndDesc[usDscCnt].ulTopAddr = (NX_ULONG)DESC_END;
	
	return;
}


NX_VOID vETH_HwFncExeSysCall (NX_USHORT usCmd, SYSCALL_REG* pstSysCallReg)
{
	
	vNX_vDisableInterrupt();
	
	RIN_HWOS->CPUIF.R4 = pstSysCallReg->ulR4Reg;
	RIN_HWOS->CPUIF.R5 = pstSysCallReg->ulR5Reg;
	RIN_HWOS->CPUIF.R6 = pstSysCallReg->ulR6Reg;
	RIN_HWOS->CPUIF.R7 = pstSysCallReg->ulR7Reg;
	
	RIN_HWOS->CPUIF.SYSC = usCmd;
	
    do {
		pstSysCallReg->ulR0Reg = RIN_HWOS->CPUIF.R0;
	} while ((pstSysCallReg->ulR0Reg & R0_SYSTEM_CALL) != R0_SYSTEM_CALL);
	
	pstSysCallReg->ulR1Reg = RIN_HWOS->CPUIF.R1;
	
	vNX_vEnableInterrupt();
	
	return;
}

NX_ULONG ulETH_HwFncMacDmaSndStart (NX_VOID)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	stSysCallReg.ulR4Reg = (NX_ULONG)gstEtherMacCtrl.pstSndDescPtr;
	
	vETH_HwFncExeSysCall(SYS_MACDMA_SND_START, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & SND_ERR) == SYSCALL_OK) {
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}
	
	return ulRet;
}

NX_ULONG ulETH_HwFncBuffRelease (NX_ULONG ulBuffAddr)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	stSysCallReg.ulR4Reg = ulBuffAddr;
	
	vETH_HwFncExeSysCall(SYS_BUFF_RELEASE, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & BUFF_RELEASE_ERR) == SYSCALL_OK) {
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}

	return ulRet;
}
	
NX_ULONG ulETH_HwFncMacDmaRcvEna (NX_VOID)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	
	vETH_HwFncExeSysCall(SYS_MACDMA_RCV_ENA, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & RCV_ENA_ERR) == SYSCALL_OK) {
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}

	return ulRet;
}

NX_ULONG ulETH_HwFncMacDmaRcvDis (NX_VOID)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	
	vETH_HwFncExeSysCall(SYS_MACDMA_RCV_DIS, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & RCV_DIS_ERR) == SYSCALL_OK) {
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}

	return ulRet;
}

NX_ULONG ulETH_HwFncShortBufferGet (NX_ULONG* pulBufferAddr, NX_ULONG ulBufferSize)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	stSysCallReg.ulR4Reg = ulBufferSize;
	
	vETH_HwFncExeSysCall(SYS_SHORT_BUFF_GET, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & SHORT_BUFF_GET_ERR) == SYSCALL_OK) {
		*pulBufferAddr = stSysCallReg.ulR1Reg;
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}

	return ulRet;
}

NX_ULONG ulETH_HwFncLongBufferGet (NX_ULONG* pulBufferAddr, NX_ULONG ulBufferSize)
{
	NX_ULONG	ulRet;
	SYSCALL_REG	 stSysCallReg;

	vNX_FillMemory32(&stSysCallReg, 0x00, sizeof(SYSCALL_REG) / sizeof(NX_ULONG));
	stSysCallReg.ulR4Reg = ulBufferSize;
	
	vETH_HwFncExeSysCall(SYS_LONG_BUFF_GET, &stSysCallReg);
	
	if ((stSysCallReg.ulR0Reg & LONG_BUFF_GET_ERR) == SYSCALL_OK) {
		*pulBufferAddr = stSysCallReg.ulR1Reg;
		ulRet = NX_UL_OK;
	}
	else {
		ulRet = NX_UL_NG;
		gstEtherMacCtrl.ulHwFuncErrFlg = (NX_ULONG)NX_ON;
		vNX_SetEvent(EVENTCODE_ETHERMAC_ERR, NX_NULL);
	}

	return ulRet;
}

NX_VOID vETH_RcvFifoOverClr (NX_ULONG ulRcvAddr)
{
	NX_ULONG	ulBuffId;
	NX_ULONG	ulRcvBuffAddr;
	NX_ULONG	ulRxFifoWord;
	
	
	RIN_ETH->GMAC_RXMAC_ENA = RXMAC_DISABLE;
	
	ulRxFifoWord = RIN_ETH->GMAC_RXFIFO;
	ulRxFifoWord = ((ulRxFifoWord >> NX_SHIFT17) & MSK_RX_FIFO);
	
	if ((NX_ULONG)NX_ZERO != ulRxFifoWord) {
		(NX_VOID)ulETH_HwFncBuffRelease(ulRcvAddr);
	}

	for (;;) {
		ulRxFifoWord = RIN_ETH->GMAC_RXFIFO;
		ulRxFifoWord = ((ulRxFifoWord >> NX_SHIFT17) & MSK_RX_FIFO);
		
		if ((NX_ULONG)NX_ZERO == ulRxFifoWord) {
			break;
		}
		ulBuffId = RIN_ETH->BUFID;
		ulRcvBuffAddr = (((ulBuffId & BUFID_ADDR) << NX_SHIFT11) | BUFRAM_OFFSET);

		if ((ulBuffId & RCV_BUFFER) == RCV_BUFFER) {
			(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBuffAddr);
		}
	}

	
	for (;;) {
		ulBuffId = RIN_ETH->BUFID;
		ulRcvBuffAddr = (((ulBuffId & BUFID_ADDR) << NX_SHIFT11) | BUFRAM_OFFSET);

		if ((ulBuffId & RCV_BUFFER) == RCV_BUFFER) {
			(NX_VOID)ulETH_HwFncBuffRelease(ulRcvBuffAddr);
		}
		else {
			break;
		}
	}
	
	RIN_ETH->GMAC_RXMAC_ENA = RXMAC_ENABLE;
	
	gstEtherMacCtrl.ulFifoOverErrFlg = (NX_ULONG)NX_ON;
	
	return;
}
NX_VOID vETH_GetHwFuncErrFlg (NX_ULONG* pulHwFuncErrFlg)
{
	*pulHwFuncErrFlg = gstEtherMacCtrl.ulHwFuncErrFlg;
	return;
}

