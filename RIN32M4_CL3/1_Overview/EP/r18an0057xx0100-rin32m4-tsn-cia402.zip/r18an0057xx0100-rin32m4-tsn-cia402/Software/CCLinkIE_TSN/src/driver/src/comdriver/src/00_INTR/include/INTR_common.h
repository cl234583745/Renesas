/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __INTR_COMMON_H_INCLUDE__
#define __INTR_COMMON_H_INCLUDE__

#include "nx_common.h"


typedef NX_VOID(*INT_FUNC)(NX_VOID);
typedef struct tagINTLOWFUNCDATA {
	NX_ULONG		ulBitNo;
	INT_FUNC		ppfunc;
} INTFUNCDATA;

typedef struct tagINTLOWLOGDATA {
	NX_ULONG		ulBitNo;
	NX_ULONG*		pulOccurrenceCount;
} INTLOGDATA;

#endif
/*[EOF]*/
