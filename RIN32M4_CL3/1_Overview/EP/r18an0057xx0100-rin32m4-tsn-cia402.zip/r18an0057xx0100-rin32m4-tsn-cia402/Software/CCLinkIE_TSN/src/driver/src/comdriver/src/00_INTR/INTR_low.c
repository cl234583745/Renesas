/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_low.h"
#include "INTR_txn.h"
#include "INTR_rxn.h"
#include "INTR_ts.h"
#include "INTR_sync.h"
#include "INTR_api.h"
#include "TXN_api.h"
#include "ccienx_task.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "NMG_common.h"
#include "INTR_common.h"


NX_VOID vINTR_IntLowCycleCnt (NX_VOID);
NX_VOID vINTR_IntLowCycleCnt100m (NX_VOID);
NX_VOID vINTR_IntCorrectionComp (NX_VOID);

NX_STATIC INTFUNCDATA gstIntLowFuncList[] = {
	{INTR_LOW_TX, 					vINTR_IntLowTx},
	{INTR_LOW_CYCLESWICH_PORT1, 	vINTR_IntLowCycleCnt},
	{INTR_LOW_SYNC,					vINTR_IntSyncL},
	{INTR_LOW_TS_PORT1,				vINTR_IntTs},
	{INTR_LOW_CYCLESWICH_PORT1_100,	vINTR_IntLowCycleCnt100m},
	{TABLE_END,						NULL}
};



NX_VOID vNX_Task_CciefNx_Low (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_ULONG	ulRetryFlg;
	NX_USHORT	usCount;
	
	while (NX_ONE) {
		slp_tsk();
		vNX_vDisableDispatch();
		
		ulFactorInt = NGN_CN_TS_P1_REG->R_TCPXINT.DATA;
		if (ulFactorInt & INTR_TS_START_TS2 & ~NGN_CN_TS_P1_REG->R_TCPXINTM.DATA) {
			vINTR_IntTS2Start();
			NGN_CN_TS_P1_REG->R_TCPXINT.DATA = ulFactorInt & INTR_TS_START_TS2;
		}
		ulFactorInt = NGN_CN_REG->R_RELINT.DATA;
		ulFactorIntMask = NGN_CN_REG->R_RELINTM.DATA;
		ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
		NGN_CN_REG->R_RELINT.DATA = ulFactorIntWork;
		
		vNX_vEnableDispatch();
		
		for (usCount = NX_ZERO; gstIntLowFuncList[usCount].ulBitNo != TABLE_END; usCount++) {
			if (ulFactorIntWork & gstIntLowFuncList[usCount].ulBitNo) {
				gstIntLowFuncList[usCount].ppfunc();
				ulFactorIntWork &= ~gstIntLowFuncList[usCount].ulBitNo;
			}
			if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
				break;
			}
		}
		
		vNX_vDisableDispatch();
		ulFactorInt= NGN_CN_REG->R_RELINT.DATA;
		ulRetryFlg = ulFactorInt & ~NGN_CN_REG->R_RELINTM.DATA;
		vNX_vEnableDispatch();
		if (ulRetryFlg > (NX_ULONG)NX_ZERO) {
			wup_tsk(TSKID_NX_LOW_INT);
		}
	}
	return;
}

NX_VOID vINTR_IntLowCycleCnt (NX_VOID)
{
	vNMG_ActivateTimeslot();
	(NX_VOID)ulTXN_ChangeReqTsState(TSREQ_ENCOMP);
	vINTR_MaskSetIntLow(INTR_LOW_CYCLESWICH_PORT1);
	return;
}

NX_VOID vINTR_IntLowCycleCnt100m (NX_VOID)
{
	vNMG_ActivateTimeslot();
	(NX_VOID)ulTXN_ChangeReqTsState(TSREQ_ENCOMP);
	vINTR_MaskSetIntLow(INTR_LOW_CYCLESWICH_PORT1_100);
	return;
}

NX_ULONG ulINTR_CheckIntLow (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_CN_REG->R_RELINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntLow (
	NX_ULONG	ulCheckTarget
)
{
	NGN_CN_REG->R_RELINT.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntLow (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLowMask;
	
	ulLowMask = NGN_CN_REG->R_RELINTM.DATA;
	NGN_CN_REG->R_RELINTM.DATA = ulLowMask | ulMaskTarget;
	return;
}

NX_VOID vINTR_MaskClearIntLow (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulLowMask;
	
	ulLowMask = NGN_CN_REG->R_RELINTM.DATA;
	NGN_CN_REG->R_RELINTM.DATA = ulLowMask & ~ulMaskTarget;
	return;
}
