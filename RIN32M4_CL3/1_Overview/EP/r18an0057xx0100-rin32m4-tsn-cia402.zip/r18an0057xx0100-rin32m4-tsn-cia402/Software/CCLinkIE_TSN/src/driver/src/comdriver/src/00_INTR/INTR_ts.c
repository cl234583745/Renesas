/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_ts.h"
#include "TOOL_api.h"
#include "INTR_api.h"
#include "INTR_main.h"
#include "ccienx_api.h"
#include "ccienx_app_supply.h"
#include "SYNC_api.h"
#include "NMG_api.h"
#include "INTR_common.h"
#include "NMG_common.h"
#include "LSM_api.h"
#include "ccienx_app_supply.h"



NX_STATIC INTFUNCDATA gstIntLowTsFuncList[] = {
	{INTR_TS_START_TS1,		vINTR_IntTS1Start	},
	{TABLE_END,				NULL				},
};
NX_STATIC INTLOGDATA gstIntLowTsLogList[] ={
	{TABLE_END,	NULL},
};




NX_VOID vINTR_IntTs (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_USHORT	usCount;
	
	vNX_vDisableDispatch();
	
	ulFactorInt = NGN_CN_TS_P1_REG->R_TCPXINT.DATA;
	ulFactorIntMask = NGN_CN_TS_P1_REG->R_TCPXINTM.DATA;
	ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
	NGN_CN_TS_P1_REG->R_TCPXINT.DATA = ulFactorIntWork;
	
	vNX_vEnableDispatch();
	
	for (usCount = (NX_USHORT)NX_ZERO; gstIntLowTsFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
		if (ulFactorIntWork & gstIntLowTsFuncList[usCount].ulBitNo) {
			gstIntLowTsFuncList[usCount].ppfunc();
			ulFactorIntWork &= ~gstIntLowTsFuncList[usCount].ulBitNo;
		}
		if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
			break;
		}
	}
	return;
}

NX_VOID vINTR_IntTS1Start (NX_VOID)
{
	NX_USHORT	usSyncSigSetRslt	 = NX_US_NG;
	
	usSyncSigSetRslt = usSYNC_AppSyncSigSetting();
	if ( NX_US_OK == usSyncSigSetRslt ) {
		vINTR_MaskSetIntTs(INTR_TS_START_TS1);
	}
	else {
	}
	
	return;
}

NX_VOID vINTR_IntTS2Start (NX_VOID)
{
	NX_USHORT	usWaitCnt;
	NX_ULONG	ulResult		= NX_NG;
	NX_USHORT	usLinkSpdSta	= NX_US_ZERO;
	
	usWaitCnt = usGetCycActWaitCnt();

	if (usWaitCnt == NM_CYCACTWAIT) {
		
		usLinkSpdSta	= usLSM_GetLinkSpd();
		if (usLinkSpdSta == NX_LINKSPD_STA_100M) {
			ulResult = ulNMG_ReqActivateCyclic_100M();
		}
		else {
			ulResult = ulNMG_ReqActivateCyclic();
		}
		
		if ( NX_OK == ulResult ) {
			if ((SYNCMODE_SYNC == gstNET.stApp.usSyncMode)
			) {

				usWaitCnt++;
				vSetCycActWaitCnt(usWaitCnt);
			}
			else {
				vINTR_MaskSetIntTs(INTR_TS_START_TS2);
			}
			vNX_CyclicStart();
		}
	}
	else if (usWaitCnt > NM_CYCACTWAIT) {
		vNX_SyncRcvCyc();
	}
	else {
		usWaitCnt++;
		vSetCycActWaitCnt(usWaitCnt);
	}

	return;
}

NX_ULONG ulINTR_CheckIntTs (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_CN_TS_P1_REG->R_TCPXINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntTs (
	NX_ULONG	ulCheckTarget
)
{
	NGN_CN_TS_P1_REG->R_TCPXINT.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntTs (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulTsMask;
	vNX_vDisableDispatch();
	ulTsMask = NGN_CN_TS_P1_REG->R_TCPXINTM.DATA;
	NGN_CN_TS_P1_REG->R_TCPXINTM.DATA = ulTsMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntTs (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulTsMask;
	
	vNX_vDisableDispatch();
	ulTsMask = NGN_CN_TS_P1_REG->R_TCPXINTM.DATA;
	NGN_CN_TS_P1_REG->R_TCPXINTM.DATA = ulTsMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

