/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "NGN_ASIC.h"
#include "ccienx_api.h"
#include "INIT_jade.h"
#include "ether_phy_init.h"
#include "kernel.h"
#include "ccienx_task.h"
#include "ccienx_app_supply.h"
#include "PHY_api.h"
#include "LSM_api.h"

#define	NX_PHYADDR_PORT1	((NX_ULONG)0)
#define	NX_PHYADDR_PORT2	((NX_ULONG)1)

#define	CMD_WRITE			((NX_ULONG)0x00000001)
#define	CMD_READ			((NX_ULONG)0x00000003)

#define	PM_MDC_7812MHZ	((NX_ULONG)0)
#define	PM_MDC_3906MHZ	((NX_ULONG)1)
#define	PM_MDC_2232MHZ	((NX_ULONG)2)

#define	PM_MUNUAL_ACSS_EN	((NX_ULONG)1)
#define	PM_MUNUAL_ACSS_DIS	((NX_ULONG)0)

#define	PM_MDCSRC_NGN		((NX_ULONG)0)
#define	PM_MDCSRC_EC		((NX_ULONG)1)

#define	PM_NGNMDIO_EN		((NX_ULONG)1)
#define	PM_NGNMDIO_DIS		((NX_ULONG)0)

#define	MDIO_STOP	((NX_ULONG)0)
#define	MDIO_RUN	((NX_ULONG)1)

#define	PM_STS_CMDEXEC		((NX_USHORT)0)
#define	PM_STS_CHKRESULT	((NX_USHORT)1)

#define	PHYACSSTBL_SIZE	((NX_USHORT)4)
#define	PHYACSSTBL_MODESTS_P1		((NX_USHORT)0)
#define	PHYACSSTBL_MODESTS_P2		((NX_USHORT)1)
#define	PHYACSSTBL_SUPCTRLSTS_P1	((NX_USHORT)2)
#define	PHYACSSTBL_SUPCTRLSTS_P2	((NX_USHORT)3)
#define	TMCNT_PHYACCESS		((NX_ULONG)(2000 - 1))

#define	PHYREG_ADDR_MODESTS		((NX_ULONG)0x00000001)
#define	PHYREG_ADDR_SUPCTRLSTS	((NX_ULONG)0x0000001C)
#define	PHYREG_ADDR_LEDMODESEL	((NX_ULONG)0x0000001D)
#define	PHYREG_ADDR_LEDBEHAVIOR	((NX_ULONG)0x0000001E)
#define	PHYREG_ADDR_PAGEACCESS	((NX_ULONG)0x0000001F)
#define	PHYREG_ADDR_ACTIPHYCTRL	((NX_ULONG)0x00000014)
#define	PHYREG_ADDR_AUTONEGOADV	((NX_ULONG)0x00000004)
#define	PHYREG_ADDR_1000BASETCTL	((NX_ULONG)0x00000009)

#define	PHYREG_SET_PAGEACCESS_PAGE0		((NX_ULONG)0x00000000)
#define	PHYREG_SET_PAGEACCESS_PAGE1		((NX_ULONG)0x00000001)
#define	PHYREG_SET_ACTIPHYCTRL_PINV		((NX_ULONG)0x0000A204)
#define	PHYREG_SET_LEDMODESEL			((NX_ULONG)0x00000004)
#define	PHYREG_SET_LEDBEHAVIOR			((NX_ULONG)0x00000403)
#define	PHYREG_SET_AUTONEGOADV_1G_AUTO		((NX_ULONG)0x00000001)
#define	PHYREG_SET_AUTONEGOADV_100M			((NX_ULONG)0x00000101)
#define	PHYREG_SET_1000BASETCTL_1G_AUTO			((NX_ULONG)0x00000600)
#define	PHYREG_SET_1000BASETCTL_100M			((NX_ULONG)0x00000400)

#define	BIT_PHYREG_MODESTS_LINKUP		((NX_ULONG)0x00000004)
#define	BIT_PHYREG_MODESTS_AUTONEGO		((NX_ULONG)0x00000020)
#define	BIT_PHYREG_SUPCTLSTS_AUTONEGO	((NX_ULONG)0x00008000)


typedef struct tagPM_CTRL {
	NX_USHORT	usRsv1;
	NX_USHORT	usPhyAcssTblIndex;
} PM_CTRL;

typedef struct tagPM_PHYACSS_TBL_REC {
	NX_ULONG	ulPort;
	NX_ULONG	ulPhyRegAdd;
	NX_ULONG	*pulReadDataPtr;
} PM_PHYACSS_TBL_REC;

PM_PHYACSS_TBL_REC	gastPhyAcssTbl[PHYACSSTBL_SIZE] = {
	{NX_PORT1,	PHYREG_ADDR_MODESTS,	&(gstNET.stPhyReg[NX_PORT1].ulModeSts)},
	{NX_PORT2,	PHYREG_ADDR_MODESTS,	&(gstNET.stPhyReg[NX_PORT2].ulModeSts)},
	{NX_PORT1,	PHYREG_ADDR_SUPCTRLSTS,	&(gstNET.stPhyReg[NX_PORT1].ulSupCtrl_Sts)},
	{NX_PORT2,	PHYREG_ADDR_SUPCTRLSTS,	&(gstNET.stPhyReg[NX_PORT2].ulSupCtrl_Sts)}
};

PM_CTRL	gstPM;

NX_VOID vPHY_InitPhyReg ( NX_VOID );
NX_ULONG ulPHY_ConcentrateWritePhyReg (NX_ULONG, NX_ULONG, NX_ULONG);
NX_ULONG ulPHY_ConcentrateReadPhyReg (NX_ULONG, NX_ULONG, NX_ULONG*);
NX_ULONG ulPHY_WaitMdioCmdComplete (NX_VOID);
NX_VOID vPHY_WaitPhyAccessFromResetRelease ( NX_VOID );

NX_VOID vPHY_Init ( NX_VOID )
{
	
	vNX_FillMemory16((NX_VOID*)&gstPM, 0x0000, sizeof(gstPM) / sizeof(NX_USHORT));
	
	vNX_timer_set(TMID_PHYACCESS,	TMCK_10NS,		TMCNT_PHYACCESS);
	
	if (gstNET.ulStartUpProcess == STARTUP_POWER_ON){
		ether_phy_init();
	
		vPHY_InitPhyReg();
	}
	
	return;
}


NX_VOID vPHY_InitPhyReg ( NX_VOID )
{
	if (gstAppInfo.stEthInfo.ulJadeRj45ConnectType == NX_PORTCONNECT_CROSS) {
		
		
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_PAGEACCESS,		PHYREG_SET_PAGEACCESS_PAGE1);
		
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_ACTIPHYCTRL,	PHYREG_SET_ACTIPHYCTRL_PINV);
		
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_PAGEACCESS,		PHYREG_SET_PAGEACCESS_PAGE0);
		
	}
	
	if (gstAppInfo.stEthInfo.ulLinkSpd == NX_LINKSPD_CONF_100M) {
	
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_LEDMODESEL,		PHYREG_SET_LEDMODESEL);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_LEDBEHAVIOR,	PHYREG_SET_LEDBEHAVIOR);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_AUTONEGOADV,	PHYREG_SET_AUTONEGOADV_100M);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_1000BASETCTL,	PHYREG_SET_1000BASETCTL_100M);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_LEDMODESEL,		PHYREG_SET_LEDMODESEL);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_LEDBEHAVIOR,	PHYREG_SET_LEDBEHAVIOR);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_AUTONEGOADV,	PHYREG_SET_AUTONEGOADV_100M);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_1000BASETCTL,	PHYREG_SET_1000BASETCTL_100M);
	} 
	else {
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_LEDMODESEL,		PHYREG_SET_LEDMODESEL);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_LEDBEHAVIOR,	PHYREG_SET_LEDBEHAVIOR);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_AUTONEGOADV,	PHYREG_SET_AUTONEGOADV_1G_AUTO);
		ulPHY_ConcentrateWritePhyReg(NX_PORT1,	PHYREG_ADDR_1000BASETCTL,	PHYREG_SET_1000BASETCTL_1G_AUTO);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_LEDMODESEL,		PHYREG_SET_LEDMODESEL);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_LEDBEHAVIOR,	PHYREG_SET_LEDBEHAVIOR);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_AUTONEGOADV,	PHYREG_SET_AUTONEGOADV_1G_AUTO);
		ulPHY_ConcentrateWritePhyReg(NX_PORT2,	PHYREG_ADDR_1000BASETCTL,	PHYREG_SET_1000BASETCTL_1G_AUTO);
	}
	
	return;
}

NX_ULONG ulPHY_ConcentrateWritePhyReg (
	NX_ULONG	ulPort,
	NX_ULONG	ulRegAdrs,
	NX_ULONG	ulWriteData
)
{
	NX_ULONG	ulRet;
	NX_ULONG	ulPHYadrs;
	
	if (NX_PORT1 == ulPort) {
		ulPHYadrs = NX_PHYADDR_PORT1;
	}
	else {
		ulPHYadrs = NX_PHYADDR_PORT2;
	}
	
	wai_sem(SEMID_NX_PHYACCESS);
	
	NGN_MD_REG->R_MDPHYADR.BITS.b05ZPHYAdd		=	ulPHYadrs;
	NGN_MD_REG->R_MDPHYRAD.BITS.b05ZPHYRegAdd	=	ulRegAdrs;
	NGN_MD_REG->R_MDPHYWD.BITS.b10ZWriteData	=	ulWriteData;
	
	NGN_MD_REG->R_MDCMD.DATA = CMD_WRITE;
    
	ulRet = ulPHY_WaitMdioCmdComplete();
	
	sig_sem(SEMID_NX_PHYACCESS);
	
	return (ulRet);
}

NX_ULONG ulPHY_ConcentrateReadPhyReg (
	NX_ULONG	ulPort,
	NX_ULONG	ulRegAdrs,
	NX_ULONG*	pulReadData
)
{
	NX_ULONG	ulRet = NX_UL_NG;
	NX_ULONG	ulPHYadrs;
	
	if (NX_PORT1 == ulPort) {
		ulPHYadrs = NX_PHYADDR_PORT1;
	}
	else {
		ulPHYadrs = NX_PHYADDR_PORT2;
	}
	
	wai_sem(SEMID_NX_PHYACCESS);
	
	NGN_MD_REG->R_MDPHYADR.BITS.b05ZPHYAdd		=	ulPHYadrs;
	NGN_MD_REG->R_MDPHYRAD.BITS.b05ZPHYRegAdd	=	ulRegAdrs;
	
	NGN_MD_REG->R_MDCMD.DATA	=	CMD_READ;
	
	ulRet = ulPHY_WaitMdioCmdComplete();
	
	if (ulRet == NX_UL_OK) {
		*pulReadData = NGN_MD_REG->R_MDPHYRD.BITS.b10ZReadData;
	}
	else {
		*pulReadData = NX_ZERO;
	}
	
	sig_sem(SEMID_NX_PHYACCESS);
	
	return (ulRet);
}

NX_ULONG ulPHY_WaitMdioCmdComplete (NX_VOID)
{
	NX_ULONG	ulRet = NX_UL_OK;
	NX_ULONG	ulCmdSts	=	NX_ZERO;
	NX_ULONG	ulTimeout	=	NX_UL_NG;
	
	vNX_timer_start(TMID_PHYACCESS);
	
	do {
		ulCmdSts = NGN_MD_REG->R_MDCMD.BITS.b01ZMDIOCmd;
		
		ulTimeout = ulNX_timer_check(TMID_PHYACCESS);
		if (ulTimeout == NX_UL_OK) {
			
			ulCmdSts = NGN_MD_REG->R_MDCMD.BITS.b01ZMDIOCmd;
			if (ulCmdSts == MDIO_STOP) {
			}
			else {
				ulRet = NX_UL_NG;
			}
			
			break;
		}
		else {
		}
	}
	while (ulCmdSts == MDIO_RUN);
	
	vNX_timer_stop(TMID_PHYACCESS);
	
	return (ulRet);
}

NX_VOID vPHY_UpdatePhySts ( NX_VOID )
{
	
	NX_ULONG	ulResult	=	NX_UL_OK;
	
	ulResult	=	ulPHY_ConcentrateReadPhyReg (
						gastPhyAcssTbl[gstPM.usPhyAcssTblIndex].ulPort,
						gastPhyAcssTbl[gstPM.usPhyAcssTblIndex].ulPhyRegAdd,
						gastPhyAcssTbl[gstPM.usPhyAcssTblIndex].pulReadDataPtr
						);
	
	if (ulResult == NX_UL_OK) {
		gstPM.usPhyAcssTblIndex++;
		if (gstPM.usPhyAcssTblIndex == PHYACSSTBL_SIZE) {
			gstPM.usPhyAcssTblIndex = 0;
		}
	}
	
	return;
}

NX_VOID vPHY_ForceUpdatePhyModeStsReg ( NX_VOID )
{
	
	ulPHY_ConcentrateReadPhyReg (
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P1].ulPort,
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P1].ulPhyRegAdd,
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P1].pulReadDataPtr
	);
	
	ulPHY_ConcentrateReadPhyReg (
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P2].ulPort,
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P2].ulPhyRegAdd,
					gastPhyAcssTbl[PHYACSSTBL_MODESTS_P2].pulReadDataPtr
	);
	
	return;
}

NX_VOID vPHY_ForceUpdatePhySupCtrlStsReg ( NX_VOID )
{
	ulPHY_ConcentrateReadPhyReg (
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P1].ulPort,
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P1].ulPhyRegAdd,
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P1].pulReadDataPtr
	);
	
	ulPHY_ConcentrateReadPhyReg (
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P2].ulPort,
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P2].ulPhyRegAdd,
					gastPhyAcssTbl[PHYACSSTBL_SUPCTRLSTS_P2].pulReadDataPtr
	);
	
	return;
}

NX_ULONG ulPHY_DetectLinkUp (
	NX_USHORT	usPort
)
{
	NX_ULONG	ulLinkSts	=	PHY_LINKDOWN;
	
	
	if (   ((gstNET.stPhyReg[usPort].ulModeSts & BIT_PHYREG_MODESTS_LINKUP) == BIT_PHYREG_MODESTS_LINKUP)
		&& ((gstNET.stPhyReg[usPort].ulModeSts & BIT_PHYREG_MODESTS_AUTONEGO) == BIT_PHYREG_MODESTS_AUTONEGO)
		&& ((gstNET.stPhyReg[usPort].ulSupCtrl_Sts & BIT_PHYREG_SUPCTLSTS_AUTONEGO) == BIT_PHYREG_SUPCTLSTS_AUTONEGO) ) {
		
		ulLinkSts	=	PHY_LINKUP;
		
	}
	else {
		
		ulLinkSts	=	PHY_LINKDOWN;
		
	}
	
	return ulLinkSts;
}

/*[EOF]*/
