/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef	__CCIENX_APP_SUPPLY_H_INCLUDED__
#define	__CCIENX_APP_SUPPLY_H_INCLUDED__

NX_ULONG	ulNX_SetAppMode (NX_APP_MODE*);
NX_VOID		vNX_PrepareDLink (NX_CYC_PRM*);
NX_VOID		vNX_InitRcvCycData (NX_RCV_CYC_ADDR*);
NX_VOID		vNX_InitTrnCycData (NX_TRN_CYC_ADDR*, NX_USHORT*);
NX_ULONG	vNX_CheckLifeTimerTimeout (NX_ULONG, NX_ULONG);
NX_USHORT	usNX_RecognizeSlmpCmd(NX_SLMP_TRAN_RECOG_INFO*	pstAppIFInfo);
NX_VOID		vNX_SetIPv4IPAddrForApp(NX_IPADDR_INFO*);

NX_VOID		vNX_timer_set(NX_USHORT, NX_USHORT, NX_ULONG);
NX_VOID		vNX_timer_start(NX_USHORT);
NX_VOID		vNX_timer_stop(NX_USHORT);
NX_ULONG	ulNX_timer_get_count(NX_USHORT);
NX_ULONG	ulNX_timer_check(NX_USHORT);

NX_VOID		vNX_TimeSyncComplete(NX_VOID);
NX_VOID		vNX_CyclicStart(NX_VOID);
NX_VOID		vNX_InitSeqDisconnect(NX_VOID);

#ifdef TSN_CAN_ENABLE
NX_VOID		vNX_PostMngPeriodic(NX_VOID);
NX_ULONG	ulNX_DetectDisconnect(NX_VOID);
#endif
NX_VOID		vNX_GetLedStatus (NX_ULONG, NX_LED_STATUS*);
NX_VOID 	vNX_SetEvent (NX_USHORT, NX_USHORT*);

NX_VOID		vNX_SetWdtTrnCyclic (NX_TRN_CYC_ADDR*);
NX_USHORT	usNX_GetWdtErrSts ( NX_VOID );

NX_VOID		vNX_FtpErrNotice (NX_VOID);
NX_ULONG	ulNX_ChkCycleTimeVal (NX_ULONGLONG, NX_USHORT);
NX_ULONG	ulNX_ChkSyncCycleInfoVal (NX_SYNC_COMCYC_INFO*);
NX_VOID		vNX_SyncRcvCyc (NX_VOID);
NX_USHORT 	usNX_GetAppInfoEnable (NX_VOID);
NX_UCHAR 	uchNX_GetAppInfo_SyncSts (NX_VOID);
NX_VOID		vNX_NotifyDLinkErr (NX_VOID);
NX_ULONG	ulNX_GetSndSpdNum (NX_USHORT*);
NX_ULONG	ulNX_GetRcvSpdNum (NX_USHORT*);
NX_ULONG	ulNX_GetSndSpdInfo (NX_USHORT, NX_UCHAR*, NX_USHORT*, NX_ULONG*);
NX_ULONG	ulNX_GetRcvSpdInfo (NX_USHORT, NX_UCHAR*, NX_USHORT*);

NX_VOID		vNX_PreInitTrnCycData (NX_TRN_CYC_ADDR*, NX_TRN_CYC_ADDR*);

#endif

