/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "ST_SNC.h"
#include "ST_SNC_stk_l.h"
#include "ST_SNC_prvif_stk_l.h"
#include "ST_SNC_sync_com_l.h"
#include "ST_SNP_sv_l.h"



NX_ULONG ulST_SNC_Instruction(
	NX_UCHAR 						ucType,
	const ST_SNC_ConfigSnmp*	pstConfig,
	NX_ULONG*						pulDtlErrorCode
)
{
	ST_SNC_MibMng	stMngDummy;
	NX_ULONG			ulRet = ST_SNC_OK;

	ST_SNC_MibSetMibMng(&stMngDummy, 0, 0, 0);

	switch(ucType) {
	case ST_SNC_START_INSTRUCTION:

#ifdef SWPS
		ulRet = ulST_SNC_CreateMutex(pulDtlErrorCode);
		if(ST_SNC_OK == ulRet) {
#endif

			ulRet = ulST_SNC_PipeSend(
						(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_START),
						&stMngDummy,
						NX_NULL,
						0,
						pulDtlErrorCode);
#ifdef SWPS
		}
		else {
			;
		}
#endif
		break;

	case ST_SNC_STOP_INSTRUCTION:

		ulRet = ulST_SNC_PipeSend(
					(ST_SNC_PMSG_SET_CL|ST_SNC_PMSG_TYPE_STOP),
					&stMngDummy,
					NX_NULL,
					0,
					pulDtlErrorCode);
#ifdef SWPS
		if(ST_SNC_OK == ulRet) {

			ulRet = ulST_SNC_DeleteMutex(pulDtlErrorCode);
		}
		else {
			;
		}
#endif
		break;

	case ST_SNC_CONFIG_INSTRUCTION:

		break;

	default:
		ulRet = ST_SNC_NG_PARAM_RANGE;
	}

	return ulRet;
}

NX_VOID ST_SNC_MibSetMibMng(
	ST_SNC_MibMng*	pstMng,
	NX_USHORT			usOidmap,
	NX_UCHAR			ucType,
	NX_USHORT			usIdx
)
{
	pstMng->usOidmap = usOidmap;
	pstMng->ucPadding = 0;
	pstMng->stIdx.ucType = ucType;
	pstMng->stIdx.usIdx  = usIdx;
	pstMng->stIdx.ucPadding = 0;
}

NX_ULONG ulST_SNC_MibSet(
	NX_USHORT			usOidmap,
	NX_USHORT			usMesType,
	NX_UCHAR			ucCtlType,
	NX_USHORT 			usIdx,
	const NX_VOID*		pData,
	NX_ULONG			ulDataSize,
	NX_ULONG*			pulDtlErrorCode
)
{
	ST_SNC_MibMng stMibMng;

	ST_SNC_MibSetMibMng(&stMibMng, usOidmap, ucCtlType, usIdx);

	return ulST_SNC_PipeSend(usMesType, &stMibMng, pData, ulDataSize, pulDtlErrorCode);
}


