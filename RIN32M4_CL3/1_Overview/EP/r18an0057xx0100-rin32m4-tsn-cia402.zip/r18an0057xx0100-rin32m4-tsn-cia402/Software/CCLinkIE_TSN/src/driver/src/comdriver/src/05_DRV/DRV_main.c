/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "DRV_common.h"
#include "DRV_api.h"

NX_VOID vDRV_Init (NX_VOID)
{
	
	vDRV_InitLedDriver();
	
	return;
}

