/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#include "nx_common.h"
#include "NGN_ASIC.h"
#include "kernel.h"
#include "INTR_high.h"
#include "INTR_txn.h"
#include "INTR_rxn.h"
#include "INTR_ts.h"
#include "INTR_sync.h"
#include "INTR_api.h"
#include "ccienx_task.h"
#include "ccienx_api.h"
#include "INTR_main.h"
#include "INTR_common.h"
#include "DATA_log_api.h"
#include "cyclic_address.h"
#include "CYC_common.h"
#include "TOOL_api.h"
#include "CYC_api.h"
#include "networkram.h"



NX_VOID vINTR_WDTError (NX_VOID);

NX_STATIC INTFUNCDATA gstIntHighFuncList[] ={
	{INTR_HIGH_WDT,		vINTR_WDTError},
	{INTR_HIGH_TX,		vINTR_IntHighTx},
	{INTR_HIGH_SYNC,	vINTR_IntSyncH},
	{TABLE_END,			NULL}
};

NX_ULONG gulIntHighCount = 0;



NX_VOID vNX_Task_CciefNx_High (NX_VOID)
{
	NX_ULONG	ulFactorInt;
	NX_ULONG	ulFactorIntMask;
	NX_ULONG	ulFactorIntWork;
	NX_ULONG	ulRetryFlg;
	NX_USHORT	usCount;
	
	while (NX_ONE) {
		slp_tsk();
		vNX_vDisableDispatch();

		if (NX_BIT30 == (gstAppInfo.stLibInfo.ulFreeArea & NX_BIT30)) {
			if (NX_ZERO == NGN_CN_REG->R_REHINT.BITS.b01ZWdtErr) {
				RIN_RTPORT->RP0B &= (NX_UCHAR)~NX_BIT5;
			}
			else {
			}
		}
		else {
		}

		ulFactorInt = NGN_CN_REG->R_REHINT.DATA;
		ulFactorIntMask = NGN_CN_REG->R_REHINTM.DATA;
		ulFactorIntWork = ulFactorInt & ~ulFactorIntMask;
		gulIntHighCount |= ulFactorIntWork;
		NGN_CN_REG->R_REHINT.DATA = (ulFactorIntWork & ~INTR_HIGH_WDT);
		
		vNX_vEnableDispatch();
		
		for (usCount = (NX_USHORT)NX_ZERO; gstIntHighFuncList[usCount].ulBitNo != (NX_ULONG)TABLE_END; usCount++) {
			if ((ulFactorIntWork & gstIntHighFuncList[usCount].ulBitNo) > (NX_ULONG)NX_ZERO) {
				gstIntHighFuncList[usCount].ppfunc();
				ulFactorIntWork &= ~gstIntHighFuncList[usCount].ulBitNo;
			}
			if (ulFactorIntWork == (NX_ULONG)NX_ZERO) {
				break;
			}
		}
		
		vNX_vDisableDispatch();
		ulFactorInt = NGN_CN_REG->R_REHINT.DATA;
		ulRetryFlg = ulFactorInt & ~NGN_CN_REG->R_REHINTM.DATA;
		vNX_vEnableDispatch();
		if (ulRetryFlg > (NX_ULONG)NX_ZERO) {
			wup_tsk(TSKID_NX_HIGH_INT);
		}
	}

	if (NX_BIT30 == (gstAppInfo.stLibInfo.ulFreeArea & NX_BIT30)) {
		RIN_SYS->RPTRGMD &= (NX_ULONG)~NX_BIT5;
		RIN_SYS->RPTRGMD |= (NX_ULONG)NX_BIT5;
		RIN_RTPORT->RP0B |= (NX_UCHAR)NX_BIT5;
	}
	else {
	}

	return;
}

NX_VOID vINTR_WDTError (NX_VOID)
{
	CYC_SS_HEAD		*pstHead;
	CYC_SS_HEAD		*pstHead2;
	vNX_vDisableDispatch();
	
	pstHead = (CYC_SS_HEAD*)AUTOTRNHEAD_AHBADDR_BASE;
	
	pstHead->stCcie.uchCycNum |= CYC_IGNORE_MSK_ON;
	
	pstHead2 = (CYC_SS_HEAD*)ETHRHEADAD_CYCSNDDISC_NO1;
	
	pstHead2->stCcie.uchCycNum |= CYC_IGNORE_MSK_ON;
	vCYC_WriteWdtSts();
	
	NGN_RC_REG->R_RCRLYVL.DATA				=	(NX_ULONG)0x00008303;




	
	while (NX_ONE) {
		NX_NOP();
	}
	return;
}

NX_ULONG ulINTR_CheckIntHigh (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG ulResult;
	
	ulResult = (NX_ULONG)NX_OFF;
	if ((NX_ULONG)NX_ZERO < (ulCheckTarget & NGN_CN_REG->R_REHINT.DATA)) {
		ulResult = (NX_ULONG)NX_ON;
	}
	return ulResult;
}

NX_VOID vINTR_ClearIntHigh (
	NX_ULONG	ulCheckTarget
)
{
	NX_ULONG	ulCountTarget;
	ulCountTarget = NGN_CN_REG->R_REHINT.DATA & ulCheckTarget;
	if (ulCountTarget > (NX_ULONG)NX_ZERO) {
		gulIntHighCount |= ulCountTarget;
	}
	NGN_CN_REG->R_REHINT.DATA = ulCheckTarget;
	return;
}

NX_VOID vINTR_MaskSetIntHigh (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHighMask;
	vNX_vDisableDispatch();
	ulHighMask = NGN_CN_REG->R_REHINTM.DATA;
	NGN_CN_REG->R_REHINTM.DATA = ulHighMask | ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}

NX_VOID vINTR_MaskClearIntHigh (
	NX_ULONG	ulMaskTarget
)
{
	NX_ULONG ulHighMask;
	
	vNX_vDisableDispatch();
	ulHighMask = NGN_CN_REG->R_REHINTM.DATA;
	NGN_CN_REG->R_REHINTM.DATA = ulHighMask & ~ulMaskTarget;
	vNX_vEnableDispatch();
	return;
}
