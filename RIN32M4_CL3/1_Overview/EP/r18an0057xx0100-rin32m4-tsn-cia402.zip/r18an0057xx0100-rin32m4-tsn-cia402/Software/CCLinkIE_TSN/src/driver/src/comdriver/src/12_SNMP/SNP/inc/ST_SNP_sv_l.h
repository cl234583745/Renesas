/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/
#ifndef __ST_SNP_SV_L_H_INCLUDED__
#define __ST_SNP_SV_L_H_INCLUDED__

#ifdef SWPS
#include "ST_Common.h"
#include <Windows.h>
#else
#ifdef MASTER
#include <28_NPS/Include/ST_Common.h>
#endif
#endif


#ifdef SWPS
extern NX_VOID ST_SNP_RequestExecuteThr(NX_VOID* pArg);
#endif
#ifdef SWPS
#else
extern NX_ULONG ulST_SNC_PipeSend(
	NX_USHORT usType,
	const ST_SNC_MibMng* pstMng,
	const NX_VOID* pMsg,
	NX_ULONG ulMsgSize,
	NX_ULONG* pulDtlErrorCode
	);
#endif

#endif
