/*********************************************************************************/
/* CC-Link IE TSN network                                                        */
/*                                                                               */
/* R-IN32M4-CL3 CANopen sample                                                   */
/*                                                                               */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.          */
/*********************************************************************************/
#ifndef __R_IN32M4_CL3CAN_H__
#define __R_IN32M4_CL3CAN_H__

#ifdef TSN_CAN_ENABLE

/*********************************************************************************/
/* Include files                                                                 */
/*********************************************************************************/
#include "R_IN32M4_CL3Types.h"
#include "R_IN32M4_CL3TypesSlmp.h"

/*********************************************************************************/
/* Define                                                                        */
/*********************************************************************************/

/*-------------------------------------------------------------------------------*/
/* SLMP                                                                          */
/*-------------------------------------------------------------------------------*/
/* SLMP I/F NMT State */
#define R_IN_CAN_NMT_STATE_SLMP_INIT					(1)						/* SLMP I/F NMT State Init					*/
#define R_IN_CAN_NMT_STATE_SLMP_PRE_OPERATIONAL			(2)						/* SLMP I/F NMT State Pre-Operational		*/
#define R_IN_CAN_NMT_STATE_SLMP_SAFE_OPERATIONAL		(4)						/* SLMP I/F NMT State Safe-Operational		*/
#define R_IN_CAN_NMT_STATE_SLMP_OPERATIONAL				(8)						/* SLMP I/F NMT State Operational			*/

/* SLMP I/F Object Read/Write */
#define	R_IN_SLMP_OBJECT_READ_WRITE_DATA_MAX_SIZE		(0x500)					/* Maximum data size of SLMP ObjectRead / Write	*/


/*-------------------------------------------------------------------------------*/
/* Object Dictionary                                                             */
/*-------------------------------------------------------------------------------*/
#define	R_IN_CAN_MAX_ODTABLE_NUM						(1)						/* Maximum number of Object Dictionary		*/

/* PDO */
#define	R_IN_CAN_PDO_CONFIG_OBJECT_INDEX_TOP			(0x1C00)				/* PDO Config Object Index					*/
#define R_IN_CAN_PDO_CONFIG_OBJECT_NUM					(2)						/* Number of PDO Config Object				*/

#define	R_IN_CAN_RPDO_MAPPING_OBJECT_INDEX_TOP			(0x1600)				/* RPDO Mapping Object Index				*/
#define R_IN_CAN_RPDO_MAPPING_OBJECT_NUM				(5)						/* Number of RPDO Mapping Object			*/
#define R_IN_CAN_RPDO_APPLICATION_OBJECT_NUM			(16)					/* Number of RPDO Application Object		*/

#define	R_IN_CAN_TPDO_MAPPING_OBJECT_INDEX_TOP			(0x1A00)				/* TPDO Mapping Object Index				*/
#define R_IN_CAN_TPDO_MAPPING_OBJECT_NUM				(5)						/* Number of TPDO Mapping Object			*/
#define R_IN_CAN_TPDO_APPLICATION_OBJECT_NUM			(16)					/* Number of TPDO Application Object		*/

/* Object Code */
#define	R_IN_CAN_VAR									(0x07)					/* VAR										*/
#define	R_IN_CAN_ARRAY									(0x08)					/* ARRAY									*/
#define	R_IN_CAN_RECORD									(0x09)					/* RECORD									*/

/* Data Type */
#define	R_IN_CAN_INTEGER8								(0x0002)				/* INTEGER8									*/
#define	R_IN_CAN_INTEGER16								(0x0003)				/* INTEGER16								*/
#define	R_IN_CAN_INTEGER32								(0x0004)				/* INTEGER32								*/
#define	R_IN_CAN_UNSIGNED8								(0x0005)				/* UNSIGNED8								*/
#define	R_IN_CAN_UNSIGNED16								(0x0006)				/* UNSIGNED16								*/
#define	R_IN_CAN_UNSIGNED32								(0x0007)				/* UNSIGNED32								*/
#define	R_IN_CAN_VISIBLESTRING							(0x0009)				/* VISIBLE_STRING							*/

/* Access */
#define	R_IN_CAN_READ_PREOP								(0x01)												/* Read (PreOP)						*/
#define	R_IN_CAN_READ_SAFEOP							(0x02)												/* Read (SafeOP)					*/
#define	R_IN_CAN_READ_OP								(0x04)												/* Read (OP)						*/
#define	R_IN_CAN_READ						(R_IN_CAN_READ_PREOP|R_IN_CAN_READ_SAFEOP|R_IN_CAN_READ_OP)		/* Read (Always)					*/
#define	R_IN_CAN_WRITE_PREOP							(0x10)												/* Write (PreOP)					*/
#define	R_IN_CAN_WRITE_SAFEOP							(0x20)												/* Write (SafeOP)					*/
#define	R_IN_CAN_WRITE_OP								(0x40)												/* Write (OP)						*/
#define	R_IN_CAN_WRITE						(R_IN_CAN_WRITE_PREOP|R_IN_CAN_WRITE_SAFEOP|R_IN_CAN_WRITE_OP)	/* Write (Always)					*/
#define	R_IN_CAN_READWRITEPREOP							(R_IN_CAN_READ|R_IN_CAN_WRITE_PREOP)				/* Read (Always) / Write (PreOP)	*/
#define	R_IN_CAN_READWRITE								(R_IN_CAN_READ|R_IN_CAN_WRITE)						/* Read (Always) / Write (Always)	*/

/* PDO Mapping */
#define	R_IN_CAN_NOPDOMAPPING							(0x00)												/* PDO mapping unavailable			*/
#define	R_IN_CAN_RPDOMAPPING							(0x40)												/* RPDO mapping available			*/
#define	R_IN_CAN_TPDOMAPPING							(0x80)												/* TPDO mapping available			*/

/* ValueInfo */
#define	R_IN_CAN_VALUEINFO_UNITTYPE						(0x08)												/* Unit type						*/
#define	R_IN_CAN_VALUEINFO_DEFAULTVALUE					(0x10)												/* Default value					*/
#define	R_IN_CAN_VALUEINFO_MINVALUE						(0x20)												/* Minimum value					*/
#define	R_IN_CAN_VALUEINFO_MAXVALUE						(0x40)												/* Maximum value					*/
#define	R_IN_CAN_VALUEINFO_MINMAXVALUE	(R_IN_CAN_VALUEINFO_MINVALUE|R_IN_CAN_VALUEINFO_MAXVALUE)			/* Minimum/Maximum value			*/
#define	R_IN_CAN_VALUEINFO_VALUE		(R_IN_CAN_VALUEINFO_DEFAULTVALUE|R_IN_CAN_VALUEINFO_MINMAXVALUE)	/* Default/Minimum/Maximum value	*/

/*-------------------------------------------------------------------------------*/
/* CiA402                                                                        */
/*-------------------------------------------------------------------------------*/
/*---------------------------------------------
-    CiA402 generic error option code values
        Note: Not all values are valid for each error option code.
        A detailed description of the option code values are listed in the specification IEC 61800-7-200
        0x605B    : action in state transition 8
        0x605C    : action in state transition 5
-----------------------------------------------*/
#define	DISABLE_DRIVE									0						/* Disable drive   (options: 0x605B; 0x605C; 0x605E)	*/
#define	SLOW_DOWN_RAMP									1						/* Slow down ramp  (options: 0x605B; 0x605C; 0x605E)	*/
#define	QUICKSTOP_RAMP									2						/* Quick stop ramp (options: 0x605E)					*/
#define	STOP_ON_CURRENT_LIMIT							3						/* Stop on current limit (options: 0x605E)				*/
#define	STOP_ON_VOLTAGE_LIMIT							4						/* Stop on voltage limit (options: 0x605E)				*/


/*-------------------------------------------------------------------------------*/
/* ABORTCODE                                                                     */
/*-------------------------------------------------------------------------------*/
#define	R_IN_CAN_ABORT_NOERROR														(0x00000000)	/* No error.																						*/
#define	R_IN_CAN_ABORT_TOGGLE_BIT_CANT_BE_CHANGED									(0x05030000)	/* Toggle bit not alternated.																		*/
#define	R_IN_CAN_ABORT_SDO_PROTOCOL_TIMEOUT											(0x05040000)	/* SDO protocol timed out.																			*/
#define	R_IN_CAN_ABORT_INVALID_COMMAND_SPECIFIER									(0x05040001)	/* Client/server command specifier not valid or unknown.											*/
#define	R_IN_CAN_ABORT_OUT_OF_MEMORY												(0x05040005)	/* Out of memory.																					*/
#define	R_IN_CAN_ABORT_UNSUPPORTED_ACCESS											(0x06010000)	/* Unsupported access to an object.																	*/
#define	R_IN_CAN_ABORT_READ_TO_WRITE_ONLY_OBJECT									(0x06010001)	/* Attempt to read a write only object.																*/
#define	R_IN_CAN_ABORT_WRITE_TO_READ_ONLY_OBJECT									(0x06010002)	/* Attempt to write a read only object.																*/
#define	R_IN_CAN_ABORT_OBJECT_DOESNT_EXIST											(0x06020000)	/* Object does not exist in the object dictionary.													*/
#define	R_IN_CAN_ABORT_OBJECT_CANT_BE_PDOMAPPED										(0x06040041)	/* Object cannot be mapped to the PDO.																*/
#define	R_IN_CAN_ABORT_PDO_MAPPING_OBJECTS_EXCEEDED									(0x06040042)	/* The number and length of the objects to be mapped would exceed PDO length.						*/
#define	R_IN_CAN_ABORT_PARAMETER_IS_INCOMPATIBLE									(0x06040043)	/* General parameter incompatibility reason.														*/
#define	R_IN_CAN_ABORT_GENERAL_INTERNAL_INCOMPATIBILITY_IN_DEVICE					(0x06040047)	/* General internal incompatibility in the device.													*/
#define	R_IN_CAN_ABORT_HARDWARE_ERROR												(0x06060000)	/* Access failed due to an hardware error.															*/
#define	R_IN_CAN_ABORT_DATA_LENGTH_MISMATCH											(0x06070010)	/* Data type does not match, length of service parameter does not match								*/
#define	R_IN_CAN_ABORT_DATA_LENGTH_TOO_LARGE										(0x06070012)	/* Data type does not match, length of service parameter too high									*/
#define	R_IN_CAN_ABORT_DATA_LENGTH_TOO_SMALL										(0x06070013)	/* Data type does not match, length of service parameter too low									*/
#define	R_IN_CAN_ABORT_SUBINDEX_DOESNT_EXIST										(0x06090011)	/* Sub-index does not exist.																		*/
#define	R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE											(0x06090030)	/* Invalid value for parameter (download only).														*/
#define	R_IN_CAN_ABORT_VALUE_TOO_LARGE												(0x06090031)	/* Value of parameter written too high (download only).												*/
#define	R_IN_CAN_ABORT_VALUE_TOO_SMALL												(0x06090032)	/* Value of parameter written too low (download only).												*/
#define	R_IN_CAN_ABORT_MAXIMUM_IS_LESS_THAN_MINIMUM									(0x06090036)	/* Maximum value is less than minimum value.														*/
#define	R_IN_CAN_ABORT_GENERAL_ERROR												(0x08000000)	/* General error																					*/
#define	R_IN_CAN_ABORT_DATA_CANT_BE_TRANSFERRED_OR_STORED							(0x08000020)	/* Data cannot be transferred or stored to the application.											*/
#define	R_IN_CAN_ABORT_DATA_CANT_BE_TRANSFERRED_OR_STORED_BECAUSE_OF_LOCAL_CONTROL	(0x08000021)	/* Data cannot be transferred or stored to the application because of local control.				*/
#define	R_IN_CAN_ABORT_DATA_CANT_BE_TRANSFERRED_OR_STORED_IN_THIS_STATE				(0x08000022)	/* Data cannot be transferred or stored to the application because of the present device state.		*/
#define	R_IN_CAN_ABORT_OBJECT_DICTIONARY_DOESNT_EXIST								(0x08000023)	/* Object dictionary dynamic generation fails or no object dictionary is present					*/

/* Abort code detected at Object Dictionary registration */
#define	R_IN_CAN_ABORT_INDEX_UNSORTED						(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Index Non-sort / Duplicate / 0x0000-0x0FFF														*/
#define	R_IN_CAN_ABORT_MAXSUBINDEX_VALUE_INVALID			(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid MaxSubIndex setting value																*/
#define	R_IN_CAN_ABORT_OBJECTCODE_VALUE_INVALID				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Object code setting value																*/
#define	R_IN_CAN_ABORT_OBJECTDATAPTR_IS_NULL				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Object Data address is set to NULL																*/
#define	R_IN_CAN_ABORT_NAMEPTR_IS_NULL						(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Name address is set to NULL																		*/
#define	R_IN_CAN_ABORT_DATATYPE_VALUE_INVALID				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Data type setting value																	*/
#define	R_IN_CAN_ABORT_BITLENGTH_VALUE_INVALID				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Bit length setting value																	*/
#define	R_IN_CAN_ABORT_UNITTYPE_VALUE_INVALID				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Unit type setting value																	*/
#define	R_IN_CAN_ABORT_DEFAULT_VALUE_INVALID				(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Default value setting value																*/
#define	R_IN_CAN_ABORT_MIN_VALUE_INVALID					(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Minimum value setting value																*/
#define	R_IN_CAN_ABORT_MAX_VALUE_INVALID					(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Invalid Maximum value setting value																*/
#define	R_IN_CAN_ABORT_VALUEPTR_IS_NULL						(R_IN_CAN_ABORT_VALUE_OUT_OF_RANGE)		/* Storage variable address is set to NULL															*/


/*********************************************************************************/
/* Structures                                                                    */
/*********************************************************************************/
/* Error details */
typedef struct R_IN_CAN_ERROR_DETAIL_TAG {
	ULONG		ulAbortCode;								/* Abort code					*/
	USHORT		usIndex;									/* Index						*/
	UCHAR		uchSubIndex;								/* SubIndex						*/
} R_IN_CAN_ERROR_DETAIL_T;

/* Object Dictionary */
typedef struct R_IN_OBJECT_DATA_TAG {
	USHORT		usDataType;									/* Data type					*/
	USHORT		usBitLength;								/* Bit length					*/

	UCHAR		uchAccess;									/* Access						*/
	UCHAR		uchMapping;									/* PDO Mapping					*/

	UCHAR		uchValueInfo;								/* Stored value information		*/
	ULONG		ulUnitType;									/* Unit type					*/
	ULONG		ulDefaultValue;								/* Default Value				*/
	ULONG		ulMinValue;									/* Minimum value				*/
	ULONG		ulMaxValue;									/* Maximum value				*/

	VOID		*pvValue;									/* Storage variable address		*/
} R_IN_CAN_OBJECT_DATA_T;

typedef struct R_IN_CAN_OD_TAG {
	USHORT							usIndex;				/* Index						*/
	UCHAR							uchMaxSubIndex;			/* Max SubIndex					*/
	UCHAR							uchObjectCode;			/* Object code					*/
	const R_IN_CAN_OBJECT_DATA_T	*pstObjectData;			/* Object data address			*/
	const CHAR						*pcName;				/* Name address				*/
	ULONG							(*pfulRead )(USHORT usIndex, UCHAR uchSubindex, ULONG ulSize, UCHAR *puchData);	/* Read Function	*/
	ULONG							(*pfulWrite)(USHORT usIndex, UCHAR uchSubindex, ULONG ulSize, UCHAR *puchData);	/* Write Function	*/
} R_IN_CAN_OD_T;

/* Object Dictionary Table */
typedef struct R_IN_CAN_OD_TABLE_TAG {
	const R_IN_CAN_OD_T				*pstObjectDictionary;	/* Object Dictionary address	*/
	USHORT							usObjectDictionaryNum;	/* Number of Object Dictionary	*/
} R_IN_CAN_OD_TABLE_T;


/*********************************************************************************/
/* Functions                                                                     */
/*********************************************************************************/
extern ERRCODE gerR_IN_CanInit(const R_IN_CAN_OD_TABLE_T* pstObjectDictionary, USHORT usObjectNumber, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanGetObjectHandle(USHORT usObjectDictionaryNo, USHORT usIndex, R_IN_CAN_OD_T** pstObject, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanReadObject(USHORT usObjectDictionaryNo, USHORT usIndex, UCHAR uchSubIndex, USHORT usRequestDataSize, USHORT* pusDataSize, UCHAR* puchReadData, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanWriteObject(USHORT usObjectDictionaryNo, USHORT usIndex, UCHAR uchSubIndex, USHORT usDataSize, UCHAR* puchWriteData, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanReadBlockObject(USHORT usObjectDictionaryNo, USHORT usIndex, UCHAR uchSubIndex, USHORT usDataSize, UCHAR* puchReadData, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanWriteBlockObject(USHORT usObjectDictionaryNo, USHORT usIndex, UCHAR uchSubIndex, USHORT usDataSize, UCHAR* puchWriteData, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanGetNmtState(USHORT* pusCurrentNmtState, USHORT* pusMasterRequestedNmtState, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanSetNmtState(USHORT usMasterRequestNmtState, R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanUpdateRPDO(R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);
extern ERRCODE gerR_IN_CanUpdateTPDO(R_IN_CAN_ERROR_DETAIL_T* pstErrorDetail);

#endif
#endif

/*** EOF ***/
