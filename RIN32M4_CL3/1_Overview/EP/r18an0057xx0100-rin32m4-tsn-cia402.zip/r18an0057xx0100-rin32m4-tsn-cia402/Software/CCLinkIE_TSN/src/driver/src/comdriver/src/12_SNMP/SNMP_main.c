/****************************************************************************/
/* CC-Link IE TSN network                                                   */
/*                                                                          */
/* R-IN32M4-CL3 Driver                                                      */
/*                                                                          */
/* Copyright 2019 MITSUBISHI ELECTRIC CORPORATION. All rights reserved.     */
/****************************************************************************/

#include "nx_common.h"
#include "snmpv3.h"
#include "SNMP_api.h"
#include "SNMP_mib_api.h"
#include "ccienx_api.h"

NX_VOID vSNMP_Init(NX_VOID)
{
	vSNMP_mib_Init();
	return;
}

NX_VOID vNX_SNMP_Main(NX_VOID){

	NX_LONG lRslt;

	vSNMP_UpdateStatisticsInfo();
	vSNMP_UpdateDevDtl();
	lRslt = (NX_LONG)ussSNMPAgentCheck();

	if(lRslt < NX_ZERO) {
		ussSNMPAgentShut();
	}
	
	return;
}

