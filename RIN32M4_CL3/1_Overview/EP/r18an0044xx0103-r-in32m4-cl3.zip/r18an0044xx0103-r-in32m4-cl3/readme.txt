################################################################################
 R-IN32M4-CL3 Sample Program

                                           2021 Renesas Electronics Corporation 
################################################################################

======================
 Release Notes
======================

--------------------------------------------------------------------------------
 Release V1.0.3 (2021/08/31):
--------------------------------------------------------------------------------
 - Update of TCP/IP stack

   �EFixed to discard received packets when the protocol stack is stopped and the 
     data link layer is operating.

   �EWhen there are multiple device registrations and the device status is invalid 
     when the default device (device number = 0) is selected, the device with the 
     next lowest number is selected.

   �EPublished an API for ARP that can be used by applications.

   �EAdded an option to get the link layer header when receiving an ICMP socket.

   �EDefinition of the macro that calculates the size when acquiring the network 
     buffer is divided between IPv4 and IPv6.

   �EIf the option (definition MCAST_SOC_SUP) that allows joining/leaving a multicast
     group on a socket-by-socket basis is enabled in the build, the maximum number of
     manageable multicast groups of 32 is combined with the multicast number configuration
     (CFG_NET_MGR_MAX). It has been modified so that it can be managed.

     Along with this, the management area is defined on the application side (net_cfg.c)
     as shown below, and it is set so that it can be referenced from TCP/IP stack.

       - Management area for the number of UDP sockets x the number of multicast groups 
         UW gMGR_INDEX[(CFG_NET_SOC_MAX)-(CFG_NET_TCP_MAX)][((CFG_NET_MGR_MAX)+31)/32];

       - Set the reference destination (net_inftbl [8]) from the TCP/IP stack library 
         const VP net_inftbl[] = {
             0,                  /* Socket configuration (via configurator)  */
             (VP)gNET_SOC,       /* Base pointer of Socket control block     */
             (VP)gNET_TCP,       /* Base pointer of TCP Socket control block */
             (VP)gNET_IPR,       /* Base pointer of IP Reassembly table      */
             (VP)gNET_MGR,       /* Base pointer of Multicast Group table    */
             (VP)gTCP_SND_BUF,   /* Base pointer of TCP send buffer          */
             (VP)lo_net_snd,     /* Base pointer of Loopback packet handler  */
             0,
             (VP)gMGR_INDEX,     /* Management area for the number of multicast groups */
         };

   �EDiscarding the IGMPv3 received query when the IGMP mode was v1 or v2, but fixed it 
     to send the report in my own mode.

--------------------------------------------------------------------------------
 Release V1.0.2 (2020/11/10):
--------------------------------------------------------------------------------
 - Support for new evaluation board : SBEV-RIN32M4CL3

--------------------------------------------------------------------------------
 Release V1.0.1 (2020/4/30):
--------------------------------------------------------------------------------
 - Update of sample application

--------------------------------------------------------------------------------
 Release V1.0.0 (2019/11/11):
--------------------------------------------------------------------------------
 - First release.

