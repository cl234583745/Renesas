/**
 *******************************************************************************
 * @file  kernel_cfg.c
 * @brief HW-RTOS kernel configuration file
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program.
 *  Renesas Electronics assumes no responsibility for any losses incurred.
 *
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "kernel.h"
#include "kernel_id.h"

#include "RIN32M4.h"

#include "ether_unet3/DDR_ETH.h"

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/
extern void init_task(int exinf);
extern void main_task(int exinf);
extern void idle_task(int exinf);

extern void net_tim_tsk(VP_INT exinf);
extern void phy0_link_tsk(int exinf);
extern void phy1_link_tsk(int exinf);
extern void eth_rcv_tsk(int exinf);
extern void eth_snd_tsk(int exinf);
extern void eth_ovf_tsk(int exinf);

extern void httpd_tsk(VP_INT exinf);

extern void ethsw_mac_learning_tsk(int exinf);

extern void eth_raw_rcv_tsk(int exinf);

/*============================================================================*/
/* C O N S T                                                                  */
/*============================================================================*/
//-------------------------------------
// Task information
//-------------------------------------
const TSK_TBL static_task_table[] = {
// CRE_TSK(  tskid,             {tskatr,            exinf,  task,           itskpri,    stksz,  stk});
            {ID_TASK_INIT,      {TA_HLNG | TA_ACT,  0,      (FP)init_task,      1,          0x400,  NULL}},
            {ID_TASK_MAIN,      {TA_HLNG | TA_ACT,  0,      (FP)main_task,      3,          0x400,  NULL}},

            {ID_TASK_TCP_TIM,   {TA_HLNG,           0,      (FP)net_tim_tsk,    4,          0x400,  NULL}},
            {ID_TASK_ETH_RCV,   {TA_HLNG,           0,      (FP)eth_rcv_tsk,    4,          0x400,  NULL}},
            {ID_TASK_ETH_SND,   {TA_HLNG,           0,      (FP)eth_snd_tsk,    4,          0x400,  NULL}},

            {ID_TASK_ETH_OVF,   {TA_HLNG,           0,      (FP)eth_ovf_tsk,    3,          0x400,  NULL}},

            {ID_TASK_PHY0_LINK, {TA_HLNG,           0,      (FP)phy0_link_tsk,  10,         0x200,  NULL}},
            {ID_TASK_PHY1_LINK, {TA_HLNG,           0,      (FP)phy1_link_tsk,  10,         0x200,  NULL}},

            {ID_TASK_HTTPS,     {TA_HLNG,           0,      (FP)httpd_tsk,      4,          0x400,  NULL}},

            {ID_TASK_MAC_LRN,   {TA_HLNG,           0,      (FP)ethsw_mac_learning_tsk,	10,	0x400,	NULL}},

			{ID_TASK_ETH_RAW_RCV,{TA_HLNG,	        0, 		(FP)eth_raw_rcv_tsk,	4,		0x400,	NULL}},

            {ID_TASK_IDLE,      {TA_HLNG | TA_ACT,  0,      (FP)idle_task,      15,         0x100,  NULL}},
            {TASK_TBL_END,      {0,                 0,      (FP)NULL,           0,          0,      NULL}}
};

//-------------------------------------
// Semaphore information
//-------------------------------------
const SEM_TBL static_semaphore_table[] = {
// CRE_SEM(  semid,             {sematr,    isemcnt,    maxsem});
            {ID_APL_SEM1,       {TA_TFIFO,  0,          1}},
            {ID_APL_SEM2,       {TA_TFIFO,  0,          1}},
            {ID_SEM_TCP,        {TA_TFIFO,  1,          1}},
			{ID_SEM_INTDMA,		{TA_TFIFO,	1,			1}},
            {ID_SEM_STS,        {TA_TFIFO,  1,          1}},
            {SEMAPHORE_TBL_END, {0,         0,          0}}
};

//-------------------------------------
// Eventflag information
//-------------------------------------
const FLG_TBL static_eventflag_table[] = {
// CRE_FLG(  flgid,             {flgatr,            iflgptn});
            {ID_APL_FLG1,       {TA_TFIFO | TA_CLR, 0}},
            {ID_APL_FLG2,       {TA_TFIFO | TA_CLR, 0}},

            {ID_FLG_ETH_TX_MAC, {TA_TFIFO,  0}},
            {ID_FLG_ETH_RX_MAC, {TA_TFIFO,  0}},
            {ID_FLG_PHY_STS,    {TA_TFIFO,  0}},
            {ID_FLG_SYSTEM,     {TA_TFIFO,  0}},
    
            {EVENTFLAG_TBL_END, {0,         0}} 
};

//-------------------------------------
// Mailbox information
//-------------------------------------
const MBX_TBL static_mailbox_table[] = {
// CRE_MBX(  mbxid,             {mbxatr,    maxmpri,    mprihd});
            {ID_APL_MBX1,       {TA_TFIFO,  0,          NULL}},
            {ID_APL_MBX2,       {TA_TFIFO,  0,          NULL}},

            {ID_MBX_ETH_SND,    {TA_TFIFO,  0,          NULL}},
            {ID_MBX_MEMPOL,     {TA_TFIFO,  0,          NULL}},

			{ID_MBX_ETH_RAW_RCV,{TA_TFIFO,	0,			NULL}},

            {MAILBOX_TBL_END,   {0,         0,          NULL}}
};

//-------------------------------------
// Mutex information
//-------------------------------------
const MTX_TBL static_mutex_table[] = {
// CRE_MTX(  mtxid,         {mtxatr,    ceilpri});
            {ID_APL_MTX1,   {TA_TFIFO,  0}},
            {ID_APL_MTX2,   {TA_TFIFO,  0}},
            
            {MUTEX_TBL_END, {0,         0}}
};

//-------------------------------------
// Interrupt handler information
//-------------------------------------
const INT_TBL static_interrupt_table[] = {
// DEF_INH(  inhno,         {inatr,     inthdr});
//          {INTPZ0_IRQn,   {TA_HLNG,   (FP)int_task}},
            {INT_TBL_END,   {0,         (FP)NULL}}
};

const HWISR_TBL static_hwisr_table[] = {
//          inhno,          hwisr_syscall,  id,             setptn
            {INTPZ1_IRQn,   HWISR_SET_FLG,  ID_APL_FLG1,    0x0001},
            {INTPZ2_IRQn,   HWISR_WUP_TSK,  ID_TASK_MAIN,   0},

            {ETHPHY0_IRQn,      HWISR_SET_FLG,  ID_FLG_PHY_STS,     ETH_INT_MII_PHY0},
            {ETHPHY1_IRQn,      HWISR_SET_FLG,  ID_FLG_PHY_STS,     ETH_INT_MII_PHY1},
            {ETHTXDMA_IRQn,     HWISR_SET_FLG,  ID_FLG_ETH_TX_MAC,  ETH_INT_TX_DMA_CMP},    /*!<  60 Ether MAC TX DMA complete Interrupt        */
            {ETHTXDERR_IRQn,    HWISR_SET_FLG,  ID_FLG_ETH_TX_MAC,  ETH_INT_TX_DMA_ERR},    /*!<  98 Ether MAC TX DMA error Interrupt           */
            {ETHTXCMP_IRQn,     HWISR_SET_FLG,  ID_FLG_ETH_TX_MAC,  ETH_INT_TX_MAC_CMP},    /*!<  53 Ether MAC TX complete Interrupt            */
            {ETHTXFIFO_IRQn,    HWISR_SET_FLG,  ID_FLG_ETH_TX_MAC,  ETH_INT_TX_MAC_ERR},    /*!<  58 Ether MAC TX FIFO underflow Interrupt      */
            {ETHTXFIFOERR_IRQn, HWISR_SET_FLG,  ID_FLG_ETH_TX_MAC,  ETH_INT_TX_MAC_ERR},    /*!< 106 Ether MAC TX FIFO error Interrupt          */
            {ETHRXDMA_IRQn,     HWISR_SET_FLG,  ID_FLG_ETH_RX_MAC,  ETH_INT_RX_DMA_CMP},    /*!<  59 Ether MAC RX DMA complete Interrupt        */
            {ETHRXFIFO_IRQn,    HWISR_SET_FLG,  ID_FLG_ETH_RX_MAC,  ETH_INT_RX_OVF_ERR},    /*!<  57 Ether MAC RX FIFO overflow Interrupt       */
            {ETHRXDERR_IRQn,    HWISR_SET_FLG,  ID_FLG_ETH_RX_MAC,  ETH_INT_RX_DMA_ERR},    /*!< 108 Ether MAC RX DMA error Interrupt           */

            {HWISR_TBL_END, 0,          0,          0}
};
