/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32.h                                                          */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32_H_INCLUDED_
#define __R_IN32_H_INCLUDED_

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32_ON						1		
#define R_IN32_OFF						0		

#define R_IN32_NULL			((VOID*)0)		

#define R_IN32_MACADR_SZ				6		


#define COM_DRIVER_VER				0x0003


#define COM_DSG_MNG_STNO			0x7D	
#define COM_CUR_MNG_STNO			0x7E	
#define COM_GROBAL_STNO				0xFF	


#define R_IN32D_ERR_TMO_RAMCLEAR			(ULONG)(0x0000D529)		
#define R_IN32D_ERR_TMO_MDIOCOMMAND		(ULONG)(0x0000D52A)		
#define R_IN32D_ERR_TMO_TXFIN				(ULONG)(0x0000D52B)		
#define R_IN32D_ERR_TMO_MYSTATUSCOPY		(ULONG)(0x0000D52C)		


#endif /* __R_IN32_H_INCLUDED_ */

/*** EOF ***/
