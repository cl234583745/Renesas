###########################################################################################
 R-IN32M4 OS Sample Program

                                            Renesas Electronics Corporation   Nov 01, 2019
###########################################################################################

 NOTICE 
   This software is just for reference sample software, 
   Renesas does NOT gurantee the operation.
   Please use this software, after you thoroughly check and evaluate on your enviroment.

 =============================================================================== 
  Abstract 
 =============================================================================== 
 This sample program is simple program which is to check the OS application.

 When executing this sample program on the evaluation board TS-TCS07908, 
 comment out "TS_TCS08467" in RIN32M4.h.
 The initial setting is for the evaluation board TS-TCS08467.
 
  \Device\Renesas\RIN32M4\Include\RIN32M4.h
  
 =============================================================================== 
  Operation summary 
 =============================================================================== 
 This sample software conducts the operation of timer, UART, and turning on/off LEDs
 with OS. Turning on/off LEDs is controlled by pressing the '0' to '7' key.
 Interval of time between previous system clock and current one is displyed by pressing
 the 'c' key. This application ends by pressing the ' ' key.

 =============================================================================== 
  Application sample 
 =============================================================================== 
 ====== Driver API ====== 
  - uart_init           : UART initialization 
  - clock_init          : System clock Initialization

 ====== Operation interpretation ====== 
 The operation of this sample conducts the following procedure. 
  1. Initialization 
    - LED port 
    - UART
    - System clock
  2. Opening message output
  3. Elapsed time initialization
  4. Commands input operation 
    - In case of command '0' to '7' input *1
      - Specified LED inverts
    - In case of command 'c' input
      - Get current time *2
      - Display the elapsed time since last 'c' input
    - In case of command ' ' input
      - Ending message output
      - Main routine finishes

 ====== Result of operation ====== 
 hello world
 - compiler  =ARM 4.2 (EDG gcc mode)
 - boot mode =Parallel Flash
 0                                      <- Command '0' input (LED1 turns on)
 11                                     <- Command '1' input twice (LED2 turns on and then off)
 c (interval =464369 ms)                <- Command 'c' input
 c (interval =2771 ms)
                                        <- Command ' ' input
 bye

 ====== Notes ====== 
 *1 :Each LED number correspond to the command number add 1.
     For example, if command '3' would be given the LED4 turns on/off.
 *2 :Function clock() is used to get current time. Precision of clock() is 80ns.

