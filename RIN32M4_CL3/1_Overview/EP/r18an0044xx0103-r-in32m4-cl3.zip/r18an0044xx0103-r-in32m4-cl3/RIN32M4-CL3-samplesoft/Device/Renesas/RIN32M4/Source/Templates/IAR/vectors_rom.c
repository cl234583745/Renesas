/**
 *******************************************************************************
 * @file  vectors_rom.c
 * @brief sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */
#pragma language=extended
#pragma segment="CSTACK"

typedef void( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
void NMI_Handler_rom(void);
void HardFault_Handler_rom(void);

extern void __iar_program_start( void );

/*============================================================================*/
/* Vector Table                                                               */
/*============================================================================*/
#pragma location = "vectors_rom"
__root const intvec_elem __vector_table_rom[] =
{
	{ .__ptr = __sfe( "CSTACK" ) },					// Top of Stack
	__iar_program_start,							// Reset Handler
	NMI_Handler_rom,								// NMI Handler
	HardFault_Handler_rom,							// Hard Fault Handler
};
/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
#pragma required=__vector_table_rom
void NMI_Handler_rom(void)
{
	while(1) {
	};
}

#pragma required=__vector_table_rom
void HardFault_Handler_rom(void)
{
	while(1) {
	};
}

