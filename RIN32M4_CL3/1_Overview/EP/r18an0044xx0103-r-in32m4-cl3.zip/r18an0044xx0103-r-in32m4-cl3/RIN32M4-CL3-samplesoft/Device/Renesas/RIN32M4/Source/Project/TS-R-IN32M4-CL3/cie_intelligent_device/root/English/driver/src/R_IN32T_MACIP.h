/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_MACIP.h                                                   */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_MACIP_H_INCLUDED__
#define	__R_IN32T_MACIP_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32T.h"


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID    R_IN32T_MACIP_MIBClear( VOID );
extern ERRCODE erR_IN32T_MACIP_LoopBackEnable( R_IN32T_PORT_SEL_ENUM );
extern ERRCODE erR_IN32T_MACIP_LoopBackDisable( R_IN32T_PORT_SEL_ENUM );


#endif	/* __R_IN32T_MACIP_H_INCLUDED__ */

/*** EOF ***/
