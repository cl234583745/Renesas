/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_Transient.h                                               */
/** @brief  R_IN32M4 driver user sample code                                   */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_TRANSIENT_H_INCLUDED_
#define __R_IN32M4_TRANSIENT_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define USER_TRAN1RECEIVE_NODE_MAX		256UL	/* Number of node to be handled */
												/* warning: If set to 1, only frame from master will be handled */

#define USER_DCS_FCS_SIZE				8					/* DCS size + FCS size */

#define USER_TRANRCV_BUFSIZE			1520				/* Transient frame receive buffer size */
															/* warning: Set to a number which is greater than USER_TRAN_SIZE_MAX and can be divided by 4 */
#define USER_TRANRCV_DATASIZE			1024				/* Maximum receive size of transient data frame */

#define USER_FTYPE_TRANSIENT2			(UCHAR)0x25			/* Transient2 frame type */
#define USER_FTYPE_TRANSIENTACK			(UCHAR)0x23			/* TransientAck frame type */


/* Error code */
/* TODO: Please define error code as necessary */
/* example */

#define USER_ERR_RCVTRAN2						((USHORT)0xD200)	/* Transient2 reception error */
#define USER_ERR_WRREQ_ADDRESS_OUTOFRANGE		((USHORT)0x0003)	/* Read/write address error in transient sending */
#define USER_ERR_WRREQ_COMMAND_OUTOFRANGE		((USHORT)0x0013)	/* Transient data command error */
#define USER_ERR_WRREQ_SIZE_OUTOFRANGE			((USHORT)0x0018)	/* Incorrect number of read/write transient data */
#define USER_ERR_WRREQ_ATTRIBUTE_OUTOFRANGE		((USHORT)0x0019)	/* Transient data attribute code error */
#define USER_ERR_WRREQ_ACCESSCODE_OUTOFRANGE	((USHORT)0x001A)	/* Transient data access code error */
#define USER_ERR_NOTTOONESELF					((USHORT)0x00AE)	/* Target station No. error in transient sending */

/*  Request SLMP command */
#define USER_SLMPHEADER_MEMORY_READ_DATASIZE	((USHORT)12)		/* SLMP data size(Lumping read)  */
#define USER_SLMPHEADER_MEMORY_READ_COMMAND		((USHORT)0x0613)	/* SLMP command (Lumping read) */
#define USER_SLMPHEADER_MEMORY_READ_SUBCOMMAND	((USHORT)0x0000)	/* SLMP sub command  */
#define USER_SLMP_MEMORY_READ_SIZE				((USHORT)240)		/* SLMP lumping read word size */
#define USER_SLMP_MEMORY_READ_SIZE_MAX			((USHORT)480)		/* SLMP lumping read maximum word size */


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

/*==============================================================*/
/* Transmit manage                                              */
/*==============================================================*/
/*----------------------------------------------*/
/* Transient1 divide manage */
typedef struct _USER_TRAN1_DIVIDE_MANAGE_TAG {
	BOOL	blEnableFlg;						/**< Divide enable flag */
	UCHAR	uchSequentialNumber;				/**< Sequential number */
	USHORT	usRemineByte;						/**< Remain size */
	USHORT	ulDivideByte;						/**< Divide size */
	VOID*	pvMakingBuff;						/**< Buffer address for preparing  */
	VOID*	pvTranceferBuff;					/**< Buffer address for transmit */
} USER_TRAN1_DIVIDE_MANAGE_T;
/* SLMP read memory command request data  */
typedef struct _USER_SLMP_MEMREAD_SETTING_TAG {
	ULONG	ulTopAddr;							/**< Start address  */
	USHORT	usWordSize;							/**< Word size  */
	UCHAR	uchNwNo;							/**< Target network No. */
	UCHAR	uchNode;							/**< Target Station No. */
} USER_SLMP_MEMREAD_SETTING_T;


/*==============================================================*/
/* Transient2 frame format                                      */
/*==============================================================*/

/*----------------------------------------------*/
/* Transient2 header area */
typedef struct _USER_TRANSIENT2_HEAD_TAG {
	USHORT	usL;									/**< L             */
	UCHAR	uchRsv;									/**< Reserved      */
	UCHAR	uchTP_SF;								/**< TP/SF         */
	UCHAR	uchFNO;									/**< FNO           */
	UCHAR	uchDT;									/**< DT            */
	UCHAR	uchDA;									/**< DA            */
	UCHAR	uchSA;									/**< SA            */
	UCHAR	uchDAT;									/**< DAT           */
	UCHAR	uchSAT;									/**< SAT           */
	UCHAR	uchDMF;									/**< DMF           */
	UCHAR	uchSMF;									/**< SMF           */
	UCHAR	uchDNA;									/**< DNA           */
	UCHAR	uchDS;									/**< DS            */
	USHORT	usDID;									/**< DID           */
	UCHAR	uchSNA;									/**< SNA           */
	UCHAR	uchSS;									/**< SS            */
	USHORT	usSID;									/**< SID           */
	USHORT	usL1;									/**< L1            */
	UCHAR	uchCT;									/**< CT            */
	UCHAR	uchRsv2;								/**< Reserved      */
	USHORT	usAPS;									/**< APS           */
} USER_TRANSIENT2_HEAD_T;

/*----------------------------------------------*/
/* Request frame data area */

/* Memory read request */
typedef	struct	_USER_TRANSIENT2_REQ_GETMEM_TAG {
	USHORT				usNumberOfDevices;		/**< Number of device */
	UCHAR				uchProperty;			/**< Property */
	UCHAR				uchAccessCode;			/**< Access code */
	USHORT				usAddress;				/**< Address */
	USHORT				usSize;					/**< Read size */
} USER_TRANSIENT2_REQ_GETMEM_T;

/* Memory write request */
typedef	struct	_USER_TRANSIENT2_REQ_SETMEM_TAG {
	USHORT				usNumberOfDevices;		/**< Number of device */
	UCHAR				uchProperty;			/**< Property */
	UCHAR				uchAccessCode;			/**< Access code */
	USHORT				usAddress;				/**< Address */
	USHORT				usSize;					/**< Write size */
	UCHAR				auchData[960];			/**< Write data */
} USER_TRANSIENT2_REQ_SETMEM_T;

/* General body of request frame data area body */
typedef	union _USER_TRANSIENT2_REQ_DATA_TAG {
	USER_TRANSIENT2_REQ_SETMEM_T	stSetMem;		/**< Memory write command */
	USER_TRANSIENT2_REQ_GETMEM_T	stGetMem;		/**< Memory read command */
} USER_TRANSIENT2_REQ_DATA_T;

/* Request frame data area body */
typedef	struct _USER_TRANSIENT2_REQ_TAG {
	USER_TRANSIENT2_REQ_DATA_T			uniData;	/**< DATA */
} USER_TRANSIENT2_REQ_T;

/*----------------------------------------------*/
/* Response frame data area */

/* Memory read response structure body */
typedef	struct _USER_TRANSIENT2_RES_GETMEM_TAG {
	UCHAR				auchData[960];				/**< Read data */
} USER_TRANSIENT2_RES_GETMEM_T;

/* General body of response frame data area body */
typedef	union _USER_TRANSIENT2_RES_DATA_TAG {
	USER_TRANSIENT2_RES_GETMEM_T	stGetMem;		/**< Memory read response */
} USER_TRANSIENT2_RES_DATA_T;

/* Response frame data area body */
typedef	struct _USER_TRANSIENT2_RES_TAG {
	USHORT							usRSTS;			
	USER_TRANSIENT2_RES_DATA_T		uniData;		/**< DATA */
} USER_TRANSIENT2_RES_T;

/*----------------------------------------------*/
/* General body of data area */
typedef	union _USER_TRANSIENT2_DATA_TAG {
	USER_TRANSIENT2_REQ_T			stReq;			/**< Request data area */
	USER_TRANSIENT2_RES_T			stRes;			/**< Response data area */
	UCHAR	auchTransientDataArea[R_IN32_TRAN_SIZE_MAX - sizeof(R_IN32_NONCICLIC_FRAME_T) - sizeof(USER_TRANSIENT2_HEAD_T)];
} USER_TRANSIENT2_DATA_T;

/*----------------------------------------------*/
/* Transient2 frame body */
typedef struct _USER_TRANSIENT2_FRAME_TAG {
	R_IN32_NONCICLIC_FRAME_T			stCOMMON;		/**< MAC + CCIE Header */
	USER_TRANSIENT2_HEAD_T			stHEAD;			/**< Header area */
	USER_TRANSIENT2_DATA_T			uniDATA;		/**< data area (maximum size, included DCS/FCS) */
} USER_TRANSIENT2_FRAME_T;

/*==============================================================*/
/* TransientAck frame format                                    */
/*==============================================================*/
typedef struct _USER_TRANSIENT_ACK_FRAME_TAG {
	R_IN32_NONCICLIC_FRAME_T			stCOMMON;		/**< MAC + CCIE Header */
	ULONG	ulAckNum;								/**< Number of ACK */
	USHORT	usStationNumber;						/**< Station No. */
	UCHAR	uchDummy1;								/**< Reserved */
	UCHAR	uchDistinctionNumber;					/**< Identification number (connection information (return value)) */
	USHORT	usDataSubClassification;				/**< Data sub-type */
	USHORT	usRSTS;									/**< Return status */
	ULONG	ulDCS;									/**< DCS */
	ULONG	ulFCS;									/**< FCS */
} USER_TRANSIENT_ACK_FRAME_T;



/* Transient sending result */
typedef struct _USER_TRANSIENT_SENDRESULT_TAG {
	BOOL	blFinish;			/**< Sending finish flag */
	UCHAR	uchSendBuffNo;		/**< Transient send buffer number */
	ERRCODE	erSendStatus;		/**< Transient send buffer status */
} USER_TRANSIENT_SENDRESULT_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

/* Received transient frame */
extern ULONG	gaulUserReceivedTransient[];	/* Received transient frame */
extern USHORT	gusUserReceivedTransientSize;	/* Received transient frame size (FCS not included) */

/* Send transient frame */
extern USER_TRANSIENT_SENDRESULT_T	gstUserTransientSendResult;	/* Transient sending result */

/* MAC address distribution */
extern BOOL	gblUserMACAddressTableRequest;									/* MAC address table distribution necessity flag */
extern ULONG	gaulUserSendTransient1_Response[USER_TRANRCV_BUFSIZE/4];	/* Transient1 sending frame (for responses) */

extern ULONG	gaulUserSendTransient1_Request_BigFrame[TRANSIENT_FRAME_SYNTHETIC_MAX_SIZE/4];		/* Transient1 request data storage area */
extern ULONG	gaulUserSlmpReqData[R_IN32_TRAN_SLMPALL_SIZE_MAX/4];									/* Transient1 data for SLMP */
extern ULONG	gulUserSendTransient1_Request_Size;													/* Transient1 request data size */
extern BOOL		gblUserSendTransient1_Request;														/* Transient1 request transmit request flag */


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID UserReceiveTransient( VOID );
extern VOID UserSendTransient( VOID );
extern ERRCODE erUserSetSlmpMemRead_Request ( USER_SLMP_MEMREAD_SETTING_T* );




extern BOOL blGetTransientReqSts( VOID );

extern ERRCODE erUserSetTransient1_Request( R_IN32_TRAN1_REQUEST_SETTING_T*, const VOID*, VOID*, ULONG* );

extern VOID* pvUserJudgeTransient1Divide ( ULONG, VOID*, VOID*, USER_TRAN1_DIVIDE_MANAGE_T*);

#endif	/* __R_IN32M4_TRANSIENT_H_INCLUDED_ */

/*** EOF ***/
