/***********************************************************************
                  ��Net3 Network sample program

    Copyright (c) 2013 eForce Co., Ltd. All rights reserved.
    2013-04-10: Created.
 ***********************************************************************/

#include "string.h"
#include "kernel.h"
#include "kernel_id.h"
#include "net_hdr.h"
#include "dhcp_client.h"
#include <stdio.h>

#define DHCP_ENA    0

ER net_sample(void)
{
    /* Initialize TCP/IP Stack */
    ER ercd;
#if DHCP_ENA
    int i;
    T_HOST_ADDR dhcp_addr[1];
    T_NODE host;
#endif
    printf("- uNet3 lib ver%s\n",unet3_get_version(1));

    ercd = net_ini();
    if (ercd != E_OK) {
        return ercd;
    }

    /* Initialize Ethernet Driver */
    ercd = net_dev_ini(1);
    if (ercd != E_OK) {
        return ercd;
    }

    /* Resolve IP Address */
#if DHCP_ENA
    net_memset(&dhcp_addr[0], 0, sizeof(T_HOST_ADDR));
    dhcp_addr[0].dev_num = 1;
    host.num  = dhcp_addr[0].dev_num;
    host.ipa  = INADDR_ANY;
    host.port = 68;         /*BOOTP PORT*/
    host.ver  = IP_VER4;
    dhcp_addr[0].socid = cre_soc(IP_PROTO_UDP, &host);
    if (dhcp_addr[0].socid <= 0) {
        ercd = (ER)dhcp_addr[0].socid;
        return ercd;
    }
    /* Set Timeout */
    ercd = cfg_soc(dhcp_addr[0].socid, SOC_TMO_SND, (VP)5000);
    if (ercd != E_OK) {
        cls_soc( dhcp_addr[0].socid, 0 );
        del_soc( dhcp_addr[0].socid );
        return ercd;
    }
    ercd = cfg_soc(dhcp_addr[0].socid, SOC_TMO_RCV, (VP)5000);
    if (ercd != E_OK) {
        cls_soc( dhcp_addr[0].socid, 0 );
        del_soc( dhcp_addr[0].socid );
        return ercd;
    }
    for (i = 0; i < 10; i++) {
        ercd = dhcp_client(&dhcp_addr[0]);
        if (ercd == E_OK) {
            break;
        }
        tslp_tsk(1000);
    }
    cls_soc( dhcp_addr[0].socid, 0 );
    del_soc( dhcp_addr[0].socid );
    if (ercd == E_TMOUT) {
        ercd = E_OK;
    }
    if (ercd != E_OK) {
        return ercd;
    }
#endif
    return ercd;	

}
