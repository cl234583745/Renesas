/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_6.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32M4_6_H_INCLUDED_
#define __R_IN32M4_6_H_INCLUDED_

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define	TXCNT_SND_START_TYPE_FWREGWRITE		(ULONG)0x0			
#define	TXCNT_SND_START_TYPE_TKNRCV			(ULONG)0x1			
#define	TXCNT_SND_START_TYPE_SYNCHRO		(ULONG)0x2			
#define	TXCNT_SND_START_TYPE_ENDBRK			(ULONG)0x3			
#define	TXCNT_BANK_SWITCH_MODE_MANUAL		(ULONG)0x0000		
#define	TXCNT_BANK_SWITCH_MODE_SEMIAUTO		(ULONG)0x0001		
#define	TXCNT_BANK_SWITCH_MODE_AUTO			(ULONG)0x0002		

#define	TX_TURN_DATASET					ASIC_BIT0				

#define	MST_COMMAND_MSTCTRLRUNNING			ASIC_BIT0			
#define	MST_COMMAND_DUALCPUSEPARATEMODE		ASIC_BIT1			
#define	MST_COMMAND_REQNETWORKREPLACE		ASIC_BIT2			
#define	MST_COMMAND_CYCLICOPERATION			ASIC_BIT3			
#define	MST_COMMAND_MSTUSERAPPEXECUTING		ASIC_BIT4			
#define	MST_COMMAND_MSTUSERAPPERROR			ASIC_BIT5			
#define	MST_COMMAND_OUTPUTOFSYNCRO			ASIC_BIT8			

#define	CYCLIC_STA_PARAMENDRECV				(USHORT)0x0001		
#define	CYCLIC_STA_PARAMNONRECV				(USHORT)0x0002		
#define	CYCLIC_STA_PARAMCOMM				(USHORT)0x0003		
#define	CYCLIC_STA_PARAMABNORMAL			(USHORT)0x0004		
#define	CYCLIC_STA_PARAMCHECKNOTEND			ASIC_BIT3			
#define	CYCLIC_STA_MYSTNOOUTOFRANGE			ASIC_BIT4			
#define	CYCLIC_STA_MYSTRESERVESETUP			ASIC_BIT5			
#define	CYCLIC_STA_CYCLICOPEPACKSTOP		ASIC_BIT6			
#define	CYCLIC_STA_CYCLICOPEVARISTOP		ASIC_BIT7			
#define	CYCLIC_STA_MYSTCPUABNORMAL			ASIC_BIT9			
#define	CYCLIC_STA_MYSTNODUPLICATE			ASIC_BIT10			
#define	CYCLIC_STA_MYSTMASTDUPLICATE		ASIC_BIT11			
#define	CYCLIC_STA_NETWORKNOWRONG			ASIC_BIT12			
#define	CYCLIC_STA_CPUPOWERABNORMAL			ASIC_BIT13			
#define	CYCLIC_STA_DLINKSTATE				ASIC_BIT14			
#define	CYCLIC_STA_INITORWAIT				ASIC_BIT15			

#define	SELF_STA_NONCPU						(USHORT)0x0000		
#define	SELF_STA_CPUSTOPORPAUSE				(USHORT)0x0001		
#define	SELF_STA_CPURUNORSTEPRUN			(USHORT)0x0002		
#define	SELF_STA_CPUNONERR					(USHORT)0x0000		
#define	SELF_STA_CPUERRLVLSLIGHT			(USHORT)0x0001		
#define	SELF_STA_CPUERRLVLMIDDLE			(USHORT)0x0002		
#define	SELF_STA_CPUERRLVLCRITICAL			(USHORT)0x0003		
#define	SELF_STA_SYNCHRONIZE				ASIC_BIT4			
#define	SELF_STA_OTHERNETWORKCONNECT		ASIC_BIT5			
#define	SELF_STA_TRANDIVIDESENDFUNCASSIGN	ASIC_BIT7			
#define	SELF_STA_MYSTFROMCNTLMSTRECV		ASIC_BIT8			
#define	SELF_STA_MYSTRECVCNTLMSTTIMEOUT		ASIC_BIT9			
#define	SELF_STA_CYCLICRECVPERMISSION		ASIC_BIT12			
#define	SELF_STA_CYCLICRECVEXECFLGON		ASIC_BIT13			
#define	SELF_STA_TRANRECVENABLE				ASIC_BIT14			
#define	SELF_STA_SENDFLAGNOTSET				ASIC_BIT15			

#define	SELF_STA2_NETWORKMODE_ONLINE_NORMAL	(USHORT)0x0000		
#define	SELF_STA2_NETWORKMODE_ONLINE_HIGH	(USHORT)0x0001		
#define	SELF_STA2_NETWORKMODE_LOOPTEST		(USHORT)0x0002		
#define SELF_STA2_MEASURE_DELAY_RUNNING			(USHORT)0x0000	
#define SELF_STA2_MEASURE_DELAY_FINISH			(USHORT)0x0001	
#define SELF_STA2_MEASURE_DELAY_ACTIVATE_RESULT	(USHORT)0x0002	

#define	TKN_SEQ_START_NO					1					

#define	TX_TURN_DATASET					ASIC_BIT0				

#define	INTL_NONCYCLICSNDENDINT			ASIC_BIT1			
#define	INTL_INTCLR						0xFFFFFFFF			
#define	INTLMSK_ALLINTMASK_FULL			0xFFFFFFFF			


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/
typedef struct _R_TXCNT_TAG {
	ULONG	b01ZUnder64FrmSndFlag:					1;			
	ULONG	b01ZReserved1:							1;			
	ULONG	b02ZSndStartType:						2;  		
	ULONG	b01ZCyclicReservedFrmSnd:				1; 			
	ULONG	b03ZReserved2:							3;			
	ULONG	b02ZSndDataMenChgType:					2; 			
	ULONG	b16ZReserved4:							22;			
} R_TXCNT_TAG;

typedef struct _TX_BUFFERING_TAG {
	ULONG	b06ZSecondFrmOut:						6;			
	ULONG	b02ZReserved1:							2;			
	ULONG	b06ZFirstrFrmOut:						6;			
	ULONG	b12ZReserved2:							18;			
} TX_BUFFERING_TAG;

typedef struct _TX_TURN_TAG {
	ULONG	b01SndReady:							1;			
	ULONG	b1FZReserved1:							31;			
} TX_TURN_TAG;

typedef struct _R_TXSTART_TAG {
	ULONG	b01ZSendStart:							1;			
	ULONG	b01ZSenddscpltClr:						1;			
	ULONG	b01ZSendStopFunction:					1;			
	ULONG	b1DZReserved1:							29;			
} R_TXSTART_TAG;

typedef struct _R_TXST_TAG {
	ULONG	b01ZReadRealMen:						1;			
	ULONG	b01ZSendAbend:							1;			
	ULONG	b1EZReserved1:							30;			
} R_TXST_TAG;

typedef struct _TX_COUNTER_TAG {
	ULONG	b08ZSendRemainNumDef:					8;			
	ULONG	b08ZSendRemainNum:						8;			
	ULONG	b10ZReserved1:							16;			
} TX_COUNTER_TAG;

typedef struct _SYNCHRO_FLAG_TAG {
	ULONG	b01ZSynchroTop:							1;			
	ULONG	b01ZSynchroFlag:						1;			
	ULONG	b1EZReserved1:							30;			
} SYNCHRO_FLAG_TAG;

typedef struct _MSTS_INFO_TAG {
	ULONG	b04ZProtocolClassifcation:				4;			
	ULONG	b04ZProtocolVersion:					4;			
	ULONG	b08ZFrameSubClassifcation:				8;			
	ULONG	b10ZReserved1:							16;			
} MSTS_INFO_TAG;

typedef struct _MSTS_SEQNUM_TAG {
	ULONG	b07ZSequentialNo:						7;			
	ULONG	b01ZSplitSequenceFlag:					1;			
	ULONG	b18ZReserved1:							24;			
} MSTS_SEQNUM_TAG;

typedef struct NET_NUM_TAG {
	ULONG	b08ZNetworkNumber:						8;			
	ULONG	b18ZReserved1:							24;			
} NET_NUM_T;

typedef struct _MST_COMMAND_TAG {
	ULONG	b01ZMasterActionStation:				1;			
	ULONG	b01ZDuplexCPUDistinction:				1;			
	ULONG	b01ZNetworkReplaceRequest:				1;			
	ULONG	b01ZCyclicOpeInstructPackage:			1;			
	ULONG	b01ZMasterStationUserApp:				1;			
	ULONG	b01ZMasterStationUserAppErr:			1;			
	ULONG	b01ZMovementMode:						1;			
	ULONG	b01ZSynchroOutputDirection:				1;			
	ULONG	b03ZMacDeliveryResult:					3;			
	ULONG	b01ZMacDeliveryRequest:					1;			
	ULONG	b04ZMasterID:							4;			
	ULONG	b10ZReserved1:							16;			
} MST_COMMAND_TAG;

typedef struct _CYCLIC_STA_TAG {
	union {
		USHORT ulAll;
		struct {
	ULONG	b03ZMstLocComonParamkeepCond:			3;			
	ULONG	b01ZParamCheckCond:						1;			
	ULONG	b01ZMyStationNoRangeOut:				1;			
	ULONG	b01ZMyStationReserveSetup:				1;			
	ULONG	b01ZCyclicOpeInstructPackage:			1;			
	ULONG	b01ZCyclicOpeInstructVarious:			1;			
	ULONG	b01ZApricationState:					1;			
	ULONG	b01ZMyMpuAbnomal:						1;			
	ULONG	b01ZMyStationNumberDuplicate:			1;			
	ULONG	b01ZMyStaMastStaDuplicate:				1;			
	ULONG	b01ZStationClassificationWrong:			1;			
	ULONG	b01ZCPUPowerSupplyAbnormal:				1;			
	ULONG	b01ZDLinkState:							1;			
	ULONG	b01ZWaitState:							1;			
	ULONG	b10ZReserved1:							16;			
		} stBit;
	} uniCyclicSta;
} CYCLIC_STA_T;

typedef struct _CYCLIC_STA_DEBUG_TAG {
	ULONG	b09ZReserved1:							9;			
	ULONG	b01ZMyMpuAbnomal:						1;			
	ULONG	b16ZReserved2:							22;			
} CYCLIC_STA_DEBUG_TAG;

typedef struct _SELF_STA_TAG {
	ULONG	b02ZMstLocCPURunCond:					2;			
	ULONG	b02ZMstLocCPUErrFoundCond:				2;			
	ULONG	b01ZMotionSynchronizeCond:				1;			
	ULONG	b01ZOtherNetworkConnection:				1;			
	ULONG	b01ZNonErrSetting:						1;			
	ULONG	b01ZTranDivideSendFuncAssign:			1;			
	ULONG	b01ZCyclicRevFromCntlMstSta:			1;			
	ULONG	b01ZCyclicRevCntlMstStaTmOut:			1;			
	ULONG	b01ZAsicInOutPort:						1;			
	ULONG	b01ZScoreWorng:							1;			
	ULONG	b01ZCyclicRecPermitCondition:			1;			
	ULONG	b01ZCyclicRecExec:						1;			
	ULONG	b01ZTranRecPropriety:					1;			
	ULONG	b01ZSendFlagNotSet:						1;			
	ULONG	b10ZReserved1:							16;			
} SELF_STA_TAG;

typedef struct _SELF_STA2_L_TAG {
	ULONG	b03ZMac2DeliveryResult:					3;			
	ULONG	b01ZMac2DeliveryRequest:				1;			
	ULONG	b03IpDeliveryResult:					3;			
	ULONG	b01IpDeliveryRequest:					1;			
	ULONG	b01ZRunLED:								1;			
	ULONG	b01ZReserved1:							1;			
	ULONG	b02ZErrLED:								2;			
	ULONG	b02ZDLinkLED:							2;			
	ULONG	b02ZReserved2:							2;			
	ULONG	b10ZReserved3:							16;			
} SELF_STA2_L_TAG;

typedef struct _SELF_STA2_H_TAG {
	ULONG	b02ZPropagationDelayMeasureCond1:		2;			
	ULONG	b01ZPropagationDelayMeasureCond2:		1;			
	ULONG	b01ZUnitSyncOperatCond:					1;			
	ULONG	b04ZReserved1:							4;			
	ULONG	b02ZErrInfo:							2;			
	ULONG	b01ZUnitInfo:							1;			
	ULONG	b01ZIpDeliveryCheckResult:				1;			
	ULONG	b02ZNetworkMode:						2;			
	ULONG	b01ZMultiMasterParamRecvResult:			1;			
	ULONG	b01ZReserved2:							1;			
	ULONG	b10ZReserved3:							16;			
} SELF_STA2_H_TAG;

typedef struct _SELF_STA2_TAG {
	ULONG	b03ZMac2DeliveryResult:					3;			
	ULONG	b01ZMac2DeliveryRequest:				1;			
	ULONG	b03ZIpDeliveryResult:					3;			
	ULONG	b01ZIpDeliveryRequest:					1;			
	ULONG	b01ZRunLED:								1;			
	ULONG	b01ZReserved1:							1;			
	ULONG	b02ZErrLED:								2;			
	ULONG	b02ZDLinkLED:							2;			
	ULONG	b02ZReserved2:							2;			
	ULONG	b02ZPropagationDelayMeasureCond1:		2;			
	ULONG	b01ZPropagationDelayMeasureCond2:		1;			
	ULONG	b01ZUnitSyncOperatCond:					1;			
	ULONG	b04ZReserved1:							4;			
	ULONG	b02ZErrInfo:							2;			
	ULONG	b01ZUnitInfo:							1;			
	ULONG	b01ZIpDeliveryCheckResult:				1;			
	ULONG	b02ZNetworkMode:						2;			
	ULONG	b01ZMultiMasterParamRecvResult:			1;			
 	ULONG	b01ZSelectMonitor2Support:				1;			
} SELF_STA2_TAG;

typedef struct _PORT_STATISTICS_TAG {
	ULONG	b01ZP1_ErrFlag:							1;			
	ULONG	b01ZP1_SendErrFlag:						1;			
	ULONG	b01ZP1_TokenErrFlag:					1;			
	ULONG	b01ZP1_Rsv:								1;			
	ULONG	b01ZP2_ErrFlag:							1;			
	ULONG	b01ZP3_SendErrFlag:						1;			
	ULONG	b01ZP3_TokenErrFlag:					1;			
	ULONG	b01ZP3_Rsv:								1;			
	ULONG	b18ZReserved1:							24;			
} PORT_STATISTICS_TAG;

typedef struct _PORT_HEAD_NO_TAG {
	ULONG	b08ZPortStartAddr:						8;			
	ULONG	b18ZReserved1:							24;			
} PORT_HEAD_NO_TAG;

typedef struct _COMIO_STS_TAG {
	ULONG	b01ZOutsideIOSignal0IOCond:				1;			
	ULONG	b01ZOutsideIOSignal1IOCond:				1;			
	ULONG	b01ZOutsideIOSignal2IOCond:				1;			
	ULONG	b01ZOutsideIOSignal3IOCond:				1;			
	ULONG	b01ZOutsideIOSignal4IOCond:				1;			
	ULONG	b01ZOutsideIOSignal5IOCond:				1;			
	ULONG	b01ZOutsideIOSignal6IOCond:				1;			
	ULONG	b01ZOutsideIOSignal7IOCond:				1;			
	ULONG	b18ZReserved1:							24;			
} COMIO_STS_TAG;

typedef struct _HOTLINE_TAG {
	ULONG	b01ZAlarmBreakOut:						1;			
	ULONG	b01ZGateOffRequest:						1;			
	ULONG	b01ZSystemEmergencyStop:				1;			
	ULONG	b01ZReserved1:							1;			
	ULONG	b04ZGOFSystemInformation:				4;			
	ULONG	b04ZEMGSystemInformation:				4;			
	ULONG	b14ZReservation:						20;			
} HOTLINE_TAG;

typedef struct _SELF_CONTROL_TAG {
	ULONG	b10ZSelfSafety:							16;			
	ULONG	b10ZReserved1:							16;			
} SELF_CONTROL_TAG;

typedef struct _SELF_STA_DEBUG_TAG {
	ULONG	b08ZReserved1:							8;			
	ULONG	b01ZRecvMyStatus:						1;			
	ULONG	b03ZReserved2:							3;			
	ULONG	b01ZCyclicRecPermitCond:				1;			
	ULONG	b01ZCyclicRecExecFlag:					1;			
	ULONG	b12ZReserved3:							18;			
} SELF_STA_DEBUG_TAG;

typedef struct _SLAVE_CONTROL_TAG {
	ULONG	b08SlavePeculiarEventNum:				8;			
	ULONG	b08SlaveCyclicSqNo:						8;			
	ULONG	b10ZReserved1:							16;			
} SLAVE_CONTROL_TAG;

typedef struct _TKN_NEXT_DA_TAG {
	ULONG	b10ZTknNextDA:							16;			
	ULONG	b10ZReserved1:							16;			
} TKN_NEXT_DA_TAG;

typedef struct _TKN_SEQNUM_TAG {
	ULONG	b08ZTokenSequentialNumber:				8;			
	ULONG	b18ZReserved1:							24;			
} TKN_SEQNUM_TAG;

typedef struct _REFRESH_CYCLE_TAG {
	ULONG	b08ZTokenRefreshCycleEnd:				8;			
	ULONG	b18ZReserved1:							24;			
} REFRESH_CYCLE_TAG;

typedef struct _TOKEN_ROUND_C_TAG {
	ULONG	b10ZTokenRoundCounter:					16;			
	ULONG	b10ZReserved1:							16;			
} TOKEN_ROUND_C_TAG;

typedef struct _TRAN_PERMISSION_VALUE_TAG {
	ULONG	b10ZTransientPermissionValue:			16;			
	ULONG	b10ZReserved1:							16;			
} TRAN_PERMISSION_VALUE_TAG;

typedef struct _TRAN_0_ROUND_C_TAG {
	ULONG	b10ZTransientZeroValue:					16;			
	ULONG	b10ZReserved1:							16;			
} TRAN_0_ROUND_C_TAG;

typedef struct _TRAN_COUNTER_TAG {
	ULONG	b08ZTranSendEnableRemainNum:			8;			
	ULONG	b08ZTransientTryCount:					8;			
	ULONG	b10ZReserved1:							16;			
} TRAN_COUNTER_TAG;

typedef struct _MAC_A_TAG {
	ULONG	b10ZSelfMacAddress:						16;			
	ULONG	b10ZReserved1:							16;			
} MAC_A_TAG;

typedef struct _TX_HEAD_NO_TAG {
	ULONG	b09ZHeadDiscriptNo:						9;			
	ULONG	b17ZReserved1:							23;			
} TX_HEAD_NO_TAG;

typedef struct _TX_ERMAKE_TAG {
	ULONG	b01ZSndFIFOPErrCompls:					1;			
	ULONG	b01ZTwoPortPErrCompls:					1;			
	ULONG	b1EZReserved1:							30;			
} TX_ERMAKE_TAG;

typedef struct _MAC_TYPE_TAG {
	ULONG	b10ZNetWorkType:						16;			
	ULONG	b10ZReserved1:							16;			
} MAC_TYPE_TAG ;

typedef struct _SYNC_TMS_ID_TAG	{
	ULONG	b10ZTimeMasterID:						16;			
	ULONG	b10ZReserved1:							16;			
} SYNC_TMS_ID_TAG;

typedef struct TOKEN_COUNTER_TAG {
	ULONG	b08ZTimeMasterID:						8;			
	ULONG	b18ZReserved1:							24;			
} TOKEN_COUNTER_TAG;

typedef struct _TX_INTH_TAG {
	ULONG	b01ZSndAbnormalEnd:						1;			
	ULONG	b01ZFIFOParityErr:						1;			
	ULONG	b01ZDiscriptErr:						1;			
	ULONG	b01ZAXISlaveErr:						1;			
	ULONG	b01ZSndMenChgErr:						1;			
	ULONG	b01ZFIFOUnderRun:						1;			
	ULONG	b1AZReserved1:							26;			
} TX_INTH_TAG;

typedef struct _TX_INTHMSK_TAG {
	ULONG	b01ZSndAbnormalEndMsk:					1;			
	ULONG	b01ZFIFOParityErrMsk:					1;			
	ULONG	b01ZDiscriptErrMsk:						1;			
	ULONG	b01ZAXISlaveErrMsk:						1;			
	ULONG	b01ZSndMenChgErrMsk:					1;			
	ULONG	b01ZFIFOUnderRunMsk:					1;			
	ULONG	b1AZReserved1:							26;			
} TX_INTHMSK_TAG;

typedef struct _TX_INTL_TAG {
	ULONG	b01ZSndNormalEnd:						1;			
	ULONG	b01ZNonCyclicSndEnd:					1;			
	ULONG	b01ZEasyMacSndEnd:						1;			
	ULONG	b01ZFIFODeplete:						1;			
	ULONG	b01ZDiscriptSetMiss:					1;			
	ULONG	b01ZSndChg:								1;			
	ULONG	b1AZReserved1:							26;			
} TX_INTL_TAG;

typedef struct _TX_INTLMSK_TAG {
	ULONG	b01ZSndNormalEndMsk:					1;			
	ULONG	b01ZNonCyclicSndEndMsk:					1;			
	ULONG	b01ZEasyMacSndEndMsk:					1;			
	ULONG	b01ZFIFODepleteMsk:						1;			
	ULONG	b01ZDiscriptSetMissMsk:					1;			
	ULONG	b01ZSndChgMsk:							1;			
	ULONG	b1AZReserved1:							26;			
} TX_INTLMSK_TAG;

typedef struct _HOTLINE_DEBUG_TAG {
	ULONG	b02ZReserved1:							2;			
	ULONG	b01ZEMGFlag:							1;			
	ULONG	b05ZReserved2:							5;			
	ULONG	b04ZEMGInformation:						4;			
	ULONG	b14ZReserved3:							20;			
} HOTLINE_DEBUG_TAG;

typedef struct _R_TDISS_TAG {
	ULONG	b01ZSendNormalEnd:						1;			
	ULONG	b01ZSendAbNormalEnd:					1;  		
	ULONG	b1EZReserved1:  						30;			
} R_TDISS_TAG;



typedef struct _TX_TAG {
	R_TXCNT_TAG					TXCNT;									
	TX_BUFFERING_TAG			BUFFERING;								
	ULONG						ulZReserved6108[(0x6118-0x6108)/4];		
	ULONG						ulTX_TURN;								
	R_TXSTART_TAG				R_TXSTART;								
	ULONG						ulR_TXST;								
	ULONG						ulZReserved6124[(0x6128-0x6124)/4];		
	TX_COUNTER_TAG				TX_COUNTER;								
	ULONG						ulZReserved612C[(0x6130-0x612C)/4];		
	SYNCHRO_FLAG_TAG			SYNCHRO_FLAG_M;							
	ULONG						ulZReserved6134[(0x6138-0x6134)/4];		
	MSTS_INFO_TAG				MSTS_INFO;								
	MSTS_SEQNUM_TAG 			MSTS_SEQNUM;							
	ULONG						ulNET_NUM;								
	ULONG						ulCYC_MASTER_ID_SND;					
	MST_COMMAND_TAG				MST_COMMAND;							
	CYCLIC_STA_T				CYCLIC_STA;								
	CYCLIC_STA_DEBUG_TAG		CYCLIC_STA_DEBUG;						
	SELF_STA_TAG				SELF_STA;								
	union _SELF_STA2_L {												
		ULONG					DATA;
		SELF_STA2_L_TAG			BIT;
	} SELF_STA2_L;
	union _SELF_STA2_H {												
		ULONG					DATA;
		SELF_STA2_H_TAG			BIT;
	} SELF_STA2_H;
	PORT_STATISTICS_TAG			PORT_STATISTICS;						
	PORT_HEAD_NO_TAG			PORT_HEAD_NO;							
	COMIO_STS_TAG				COMIO_STS;								
	HOTLINE_TAG					HOTLINE; 								
	SELF_CONTROL_TAG			SELF_CONTROL_1;							
	SELF_CONTROL_TAG			SELF_CONTROL_2;							
	SELF_CONTROL_TAG			SELF_CONTROL_3;							
	SELF_CONTROL_TAG			SELF_CONTROL_4;							
	SELF_STA_DEBUG_TAG			SELF_STA_DEBUG;							
	ULONG						ulMSTS_SWITCH_FLG;						
	ULONG						ulZReserved6184[(0x6190-0x6188)/4];		
	MSTS_INFO_TAG				TKN_INFO;								
	TKN_NEXT_DA_TAG				TKN_NEXT_DA1;							
	TKN_NEXT_DA_TAG				TKN_NEXT_DA2;							
	TKN_NEXT_DA_TAG				TKN_NEXT_DA3;							
	TKN_SEQNUM_TAG				TKN_SEQNUM;								
	REFRESH_CYCLE_TAG			REFRESH_CYCLE;							
	TOKEN_ROUND_C_TAG			TOKEN_ROUND_C;							
	TRAN_PERMISSION_VALUE_TAG	TRAN_PERMISSION_VALUE;					
	TRAN_0_ROUND_C_TAG			TRAN_0_ROUND_C;							
	TRAN_COUNTER_TAG			TRAN_COUNTER;							
	ULONG						ulZReserved61B8[(0x61C0-0x61B8)/4];		
	MAC_A_TAG					MAC_A1;									
	MAC_A_TAG					MAC_A2;									
	MAC_A_TAG					MAC_A3;									
	ULONG						ulZReserved61CC[(0x61D0-0x61CC)/4];		
	ULONG						ulTX_HEAD_NO;							
	ULONG						ulZReserved61D4[(0x61E0-0x61D4)/4];		
	TX_ERMAKE_TAG				TX_ERMAKE;								
	ULONG						ulZReserved61E4[(0x61E8-0x61E4)/4];		
	MAC_TYPE_TAG				MAC_TYPE;								
	MSTS_INFO_TAG				SYNC_INFO;								
	SYNC_TMS_ID_TAG				SYNC_TMS_ID;							
	ULONG						ulSYNC_ID;								
	ULONG						ulSYNC_TMSCOUNT_A1;						
	ULONG						ulSYNC_TMSCOUNT_A2;						
	ULONG						ulSYNC_TMSCOUNT_B1;						
	ULONG						ulSYNC_TMSCOUNT_B2;						
	SYNCHRO_FLAG_TAG			SYNCHRO_FLAG_S;							
	ULONG						ulZReserved620C[(0x6214-0x620C)/4];		
	TOKEN_COUNTER_TAG			TOKEN_COUNTER;							
	union _TX_INTH {													
		ULONG					DATA;
		TX_INTH_TAG				BIT;
	} TX_INTH;
	union _TX_INTHMSK {													
		ULONG					DATA;
		TX_INTHMSK_TAG			BIT;
	} TX_INTHMSK;
	union _TX_INTL {													
		ULONG					DATA;
		TX_INTL_TAG				BIT;
	} TX_INTL;
	union _TX_INTLMSK {													
		ULONG					DATA;
		TX_INTLMSK_TAG			BIT;
	} TX_INTLMSK;
	ULONG						ulZReserved6228[(0x6238-0x6228)/4];		
	HOTLINE_DEBUG_TAG			HOTLINE_DEBUG;							
	ULONG						ulZReserved623C[(0x6300-0x623C)/4];		
	ULONG						ulDummy[16];							
	ULONG						ulZReserved6340[(0x6348-0x6340)/4];		
	ULONG						ulCYC_TX_PERMISSION;					
	ULONG						ulZReserved6348[(0x6700-0x634C)/4];		
	
	ULONG						ulZReserved11[(0x7000-0x6700)/4];		
	R_TDISS_TAG					aR_TDISS[512];							
	ULONG						ulZReserved12[(0x7F00-0x7800)/4];		
} TX_T;

#endif /* __R_IN32M4_6_H_INCLUDED_ */
