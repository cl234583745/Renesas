/***********************************************************************
             TCP/IP configuration file for R-IN32M4

    Copyright (c) 2013 eForce Co., Ltd. All rights reserved.
    2016-03-29: Created.
 ***********************************************************************/
#include "kernel.h"
#include "kernel_id.h"
#include "net_hdr.h"
#include "net_sts.h"
#include "net_def.h"
#include "net_cfg.h"
#include "dmac/dmac.h"
#include "ether_unet3/DDR_ETH.h"
#include <string.h>
#include <stdlib.h>

/*******************************************
    Define Local IP Address
********************************************/
T_NET_ADR gNET_ADR[] = {
    {
        0x0,            /* Reserved */
        0x0,            /* Reserved */
        0xC0A80164,     /* IP address  "192.168.1.100" */
        0xC0A80101,     /* Gateway     "192.168.1.1"   */
        0xFFFFFF00,     /* Subnet mask "255.255.255.0" */
    }
};


/*******************************************
    Define Ethernet Driver Information
********************************************/
extern ER eth_ini(UH dev_num);
extern ER eth_snd(UH dev_num, T_NET_BUF *pkt);
extern ER eth_cls(UH dev_num);
extern ER eth_sts(UH dev_num, UH opt, VP val);
extern ER eth_ctl(UH dev_num, UH opt, VP val);

void eth_cbk(UH dev_num, UH opt, VP val)
{
#if 0
    if (opt == EV_CBK_DEV_INIT) {
    }
#endif
}

T_NET_DEV gNET_DEV[] = {
    {
        "lan0",            /* Device Name      */
        1,                 /* Device Number    */
        NET_DEV_TYPE_ETH,  /* Device Type      */
        0,                 /* Status           */
        0,                 /* Flags            */
        eth_ini,           /* Device Init      */
        eth_cls,           /* Device Close     */
        eth_ctl,           /* Device Configure */
        eth_sts,           /* Device Status    */
        eth_snd,           /* Device Transmit  */
        eth_cbk,           /* Device Callback  */
        0,
        {{{ 0x12, 0x34, 0x56, 0x78, 0x9A, 0xBC }}},  /* MAC Address */
        ETH_HDR_SZ,                                /* Link Header Size */
        CFG_NET_BUF_OFFSET                         /* Network buffer data Offset */
    }
};

/*******************************************
    uNet3 Resources
********************************************/
UW NET_SOC_MAX = CFG_NET_SOC_MAX;       /* Maximum Number of Sockets */ 
UW NET_TCP_MAX = CFG_NET_TCP_MAX;       /* Maximum Number of TCP Sockets */ 
UW NET_DEV_MAX = CFG_NET_DEV_MAX;       /* Maximum Number of Network Interface */
UW NET_ARP_MAX = CFG_NET_ARP_MAX;       /* Maximum Number of ARP Cache */
UW NET_MGR_MAX = CFG_NET_MGR_MAX;       /* Maximum Number of Multicast Table */
UW NET_IPR_MAX = CFG_NET_IPR_MAX;       /* Maximum Number of IP Reassembly Queue */
UW NET_BUF_SZ  = CFG_NET_BUF_SZ;
UW NET_STS_RES = CFG_STS_UPD_RES;       /* Update interval of status */

/*******************************************
    Define TCP Resources
********************************************/
T_NET gNET[CFG_NET_DEV_MAX];            /* Network Interface control block */
T_NET_DEV gNET_DEV[CFG_NET_DEV_MAX];    /* Network Device control block */
T_NET_ARP gNET_ARP[CFG_NET_ARP_MAX];    /* ARP Cache */
T_NET_MGR gNET_MGR[CFG_NET_MGR_MAX];    /* Multicast Group Table */
T_NET_IPR gNET_IPR[CFG_NET_IPR_MAX];    /* IP Reassembly Queue */
T_NET_SOC gNET_SOC[CFG_NET_SOC_MAX];    /* Socket control block */
T_NET_TCP gNET_TCP[CFG_NET_TCP_MAX];    /* TCP control block */
UB gTCP_SND_BUF[CFG_NET_TCP_MAX * CFG_TCP_SND_WND];     /* TCP Tx Buffer */

/*******************************************
     Define TCP/IP Kernel resource
********************************************/
ID ID_NET_TSK = ID_TASK_TCP_TIM;
ID ID_NET_SEM = ID_SEM_TCP;
ID ID_NET_SEM_STS = ID_SEM_STS;

/*******************************************
    Initialize TCP/IP Globals
********************************************/
const VP net_inftbl[] = {
    0,                  /* Reserved */
    (VP)gNET_SOC,       /* Base pointer of Socket control block */
    (VP)gNET_TCP,       /* Base pointer of TCP Socket control block */
    (VP)gNET_IPR,       /* Base pointer of IP Reassembly table */
    (VP)gNET_MGR,       /* Base pointer of Multicast Group table */
    (VP)gTCP_SND_BUF,   /* Base pointer of TCP send buffer */
    0,
    0,
};

/*******************************************
    Define TCP/IP Default Parameters
********************************************/
T_NET_CFG gNET_CFG[]  = {
    {
        TRUE,               /* 1- All Network Interfaces using Same Parameters */
        CFG_PATH_MTU,
        CFG_ARP_RET_CNT,
        CFG_ARP_RET_TMO,
        CFG_ARP_CLR_TMO,
        #ifdef ACD_SUP
        CFG_ARP_PRB_WAI,
        CFG_ARP_PRB_NUM,
        CFG_ARP_PRB_MIN,
        CFG_ARP_PRB_MAX,
        CFG_ARP_ANC_WAI,
        CFG_ARP_ANC_NUM,
        CFG_ARP_ANC_INT,
        #endif
        CFG_IP4_TTL,
        CFG_IP4_TOS,
        CFG_IP4_IPR_TMO,
        CFG_IP4_MCAST_TTL,  /* Default Multicast TTL */
        CFG_IGMP_V1_TMO,
        CFG_IGMP_REP_TMO,
        CFG_TCP_MSS,
        #ifdef IPV6_SUP
        CFG_TCP_MSS_IPV6,
        #endif
        CFG_TCP_RTO_INI,
        CFG_TCP_RTO_MIN,
        CFG_TCP_RTO_MAX,
        CFG_TCP_SND_WND,
        CFG_TCP_RCV_WND,
        CFG_TCP_DUP_CNT,
        CFG_TCP_CON_TMO,
        CFG_TCP_SND_TMO,
        CFG_TCP_CLS_TMO,
        CFG_TCP_CLW_TMO,
        CFG_TCP_ACK_TMO,
        #ifdef KEEPALIVE_SUP
        CFG_TCP_KPA_CNT,
        CFG_TCP_KPA_INT,
        CFG_TCP_KPA_TMO,
        #endif
        CFG_PKT_RCV_QUE,
        CFG_PKT_CTL_FLG,
        #ifdef IGMPv3_SUP
        CFG_IGMP_V3_ENABLE,
        #endif
        CFG_TCP_RCV_OSQ_MAX
    }
};

#ifdef STS_SUP
/*******************************************
    Status
********************************************/
/* Network device status */
static T_NET_STS_DEV net_cfg_sts_dev[CFG_NET_DEV_MAX];

/* Interface */
static T_NET_STS_IFS net_cfg_sts_ifs[CFG_NET_DEV_MAX];
static T_NET_STS_IFS net_cfg_sts_ifs_tmp[CFG_NET_DEV_MAX];

/* ARP status */
static T_NET_STS_ARP net_cfg_sts_arp[CFG_NET_ARP_MAX];

/* Socket status */
static T_NET_STS_SOC net_cfg_sts_soc[CFG_NET_SOC_MAX];

/* Status pointer */
static VP net_cfg_sts_ptr[4 + CFG_NET_DEV_MAX];
static VP net_cfg_sts_ptr_tmp[4 + CFG_NET_DEV_MAX];

/* Configuration */

T_NET_STS_CFG gNET_STS_CFG = {
    net_cfg_sts_dev,         /* Network device */
    net_cfg_sts_ifs,         /* Interface table */
    net_cfg_sts_ifs_tmp,     /* Interface table (Temporary) */
    net_cfg_sts_arp,         /* ARP status */
    net_cfg_sts_soc,         /* Socket status */
    net_cfg_sts_ptr,         /* Status table */
    net_cfg_sts_ptr_tmp,     /* Status table (Temporary) */
    0                        /* Callback function for SNMP */
};
#endif

/*******************************
     Memory function
 *******************************/
VP net_memset(VP d, int c, UINT n)
{
    return memset(d, c, n);
}

int net_memcmp(const void* d, const void* s, SIZE n)
{
    return memcmp(d, s, n);
}

/* for R-IN32M4 network memory pool */
#include "ether/eth_hwfnc.h"
#if CFG_NET_BUF_CNT > 31
#error CFG_NET_BUF_CNT must be less than 32.
#endif
#define NET_BUF_FIX_SZ         2048
UW *net_memory[CFG_NET_BUF_CNT];

ER net_memini(void)
{
    int i;
    for (i = 0; i < CFG_NET_BUF_CNT; i++) {
        net_memory[i] = (UW*)hwfnc_longbuffer_get(NET_BUF_FIX_SZ);
        if (net_memory[i] == NULL) {
            return E_NOMEM;
        }
        memset(net_memory[i], 0, sizeof(net_memory[i]));
        net_memret(net_memory[i], 0);
    }
    return E_OK;
}

ER net_memext(void)
{
    return E_OK;
}

#define NETMEM_SRC_HEAP     (0x01)
#define NETMEM_SRC_BUFRAM   (0x02)
ER net_memget(VP *adr, UINT len, TMO tmo, ID *id)
{
    ER ercd;
    if (len == 0) {
        return E_PAR;
    }
    if (len > NET_BUF_FIX_SZ) {
        *id = NETMEM_SRC_HEAP;
        dis_dsp();
        *adr = malloc(len);
        ena_dsp();
        if(*adr == NULL) {
            ercd = E_NOMEM;
        } else {
            ercd = E_OK;
        }
    } else {
        *id  = NETMEM_SRC_BUFRAM;
        *adr = NULL;
        ercd = trcv_mbx(ID_MBX_MEMPOL, (T_MSG**)adr, tmo);
    }
    return ercd;
}

ER net_memret(VP adr, ID id)
{
    if(id == NETMEM_SRC_HEAP) {
        dis_dsp();
        free(adr);
        ena_dsp();
        return E_OK;
    } else {
        return snd_mbx(ID_MBX_MEMPOL, (T_MSG*)adr);
    }
}

#define BUF_RAM_DEF           (0x08000000)
#define BUF_RAM_MASK          (0xF8000000)
#define IN_BUF_RAM(X)         (((UW)(X) & BUF_RAM_MASK) == BUF_RAM_DEF)
#define BOTH_BUF_RAM(X, Y)    ((IN_BUF_RAM(X)) && (IN_BUF_RAM(Y)))

#define INST_RAM_MIN          (0x04000000)
#define INST_RAM_MAX          (0x040BFFFF)
#define IN_INST_RAM(X)        (((UW)(X) >= INST_RAM_MIN) && ((UW)(X) <= INST_RAM_MAX))

#define EXT_RAM_DEF           (0x10000000)
#define EXT_RAM_MASK          (0xF0000000)
#define IN_EXT_RAM(X)         (((UW)(X) & EXT_RAM_MASK) == EXT_RAM_DEF)
#define EITHER_AHB_RAM(X, Y)  ((IN_INST_RAM(X)) || (IN_EXT_RAM(X)) || (IN_INST_RAM(Y)) || (IN_EXT_RAM(Y)))
VP net_memcpy(VP dst, const void* src, UINT len)
{
    ER ercd;
    if (BOTH_BUF_RAM(dst, src)) {
        eth_bufram_cpy((UINT)dst,(UINT)src,len);
    } else if (EITHER_AHB_RAM(dst, src)) {
        if (len) dmac_memcpy(dst, src, len);
    } else {
        hwfnc_dmt((UINT)src, (UINT)dst,  len, (UINT*)&ercd);
    }
    return dst;
}
