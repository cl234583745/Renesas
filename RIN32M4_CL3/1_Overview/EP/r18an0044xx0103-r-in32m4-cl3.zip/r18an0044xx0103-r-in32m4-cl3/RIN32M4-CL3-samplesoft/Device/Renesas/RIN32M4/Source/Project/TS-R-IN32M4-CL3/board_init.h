/**
 *******************************************************************************
 * @file  board_init.h
 * @brief Board setting for R-IN32M4-CL3 Evaluation Board.
 * 
 * @note 
 * Copyright 2016 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	__BOARD_INIT_H__
#define	__BOARD_INIT_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/

#include "RIN32M4.h"

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/

extern void board_init(void);
extern void cie_board_init(void);
extern void set_board_led(uint8_t output);
extern uint8_t get_board_led(void);
extern uint8_t get_board_sw(void);
extern uint8_t cie_get_nodenumber(void);
extern uint8_t cie_get_networknumber(void);


#endif // __BOARD_INIT_H__
