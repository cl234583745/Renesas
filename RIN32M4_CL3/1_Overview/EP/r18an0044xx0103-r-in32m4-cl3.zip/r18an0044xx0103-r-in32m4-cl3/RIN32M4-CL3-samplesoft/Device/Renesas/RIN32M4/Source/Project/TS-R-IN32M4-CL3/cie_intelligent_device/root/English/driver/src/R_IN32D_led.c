/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_led.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

static const ULONG gulConvLedCtrlTbl[] = {
	LEDCNT1_OFF,
	LEDCNT1_ON,
	LEDCNT1_FLASH_500MS,
	LEDCNT1_OFF
};

typedef struct USER_LED_CTRL_TAG {
	UCHAR	ucStatus;
	UCHAR	ucMaskStatus;
	ULONG	ulCtrl;
} USER_LED_CTRL_T;

static USER_LED_CTRL_T gstUserLEDCtrl[2] = {
	{ R_IN32_OFF, R_IN32_OFF, R_IN32_LED_OFF },
	{ R_IN32_OFF, R_IN32_OFF, R_IN32_LED_OFF }
};

static ERRCODE erR_IN32D_SetUserLed( UCHAR ucLedNumber, ULONG ulCtrl, UCHAR ucReset);

ERRCODE gerR_IN32D_SetLedLERR2(
	ULONG	ulCtrl		
)
{
	LED->R_LEDCNT1.stBit.b1ZLErr2LEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK1];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedLERR1(
	ULONG	ulCtrl		
)
{
	LED->R_LEDCNT1.stBit.b1ZLErr1LEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK1];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedERR(
	ULONG	ulCtrl		
)
{
	LED->R_LEDCNT1.stBit.b3ZErrLEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK2];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedDLINK(
	ULONG	ulCtrl		
)
{
	LED->R_LEDCNT1.stBit.b3ZDLinkLEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK2];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedREM(
	ULONG	ulCtrl		
)
{
	(VOID)erR_IN32D_SetUserLed(0, ulCtrl, R_IN32_TRUE);

	LED->R_LEDCNT1.stBit.b3ZRemLEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK2];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedMODE(
	ULONG	ulCtrl		
)
{
	(VOID)erR_IN32D_SetUserLed(1, ulCtrl, R_IN32_TRUE);

	LED->R_LEDCNT1.stBit.b3ZModeLEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK2];
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetLedRUN(
	ULONG	ulCtrl		
)
{
	LED->R_LEDCNT1.stBit.b3ZRunLEDLighting = gulConvLedCtrlTbl[ulCtrl & LEDCTRLMSK1];
	return( R_IN32D_OK );
}

ULONG gulR_IN32D_GetLedLERR2( VOID )
{
	ULONG	ulStat;			
	USHORT	usRegData;		
	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b1ZLErr2LEDLighting;
	if ( LEDCNT1_ON == usRegData) {		
		ulStat = R_IN32D_LED_ON;
	}
	else {									
		ulStat = R_IN32D_LED_OFF;
	}

	return( ulStat );
}

ULONG gulR_IN32D_GetLedLERR1( VOID )
{
	ULONG	ulStat;			
	USHORT	usRegData;		
	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b1ZLErr1LEDLighting;
	if ( LEDCNT1_ON == usRegData) {		
		ulStat = R_IN32D_LED_ON;
	}
	else {									
		ulStat = R_IN32D_LED_OFF;
	}

	return( ulStat );
}

ULONG gulR_IN32D_GetLedERR( VOID )
{
	ULONG	ulStat;			
	USHORT	usRegData;		
	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b3ZErrLEDLighting;
	if ( LEDCNT1_ON == usRegData) {			
		ulStat = R_IN32D_LED_ON;
	}
	else if ( LEDCNT1_FLASH_500MS == usRegData) {	
		ulStat = R_IN32D_LED_BLINK;
	}
	else {										
		ulStat = R_IN32D_LED_OFF;
	}

	return( ulStat );
}

ULONG gulR_IN32D_GetLedDLINK( VOID )
{
	ULONG	ulStat;			
	USHORT	usRegData;		
	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b3ZDLinkLEDLighting;
	if ( LEDCNT1_ON == usRegData) {			
		ulStat = R_IN32D_LED_ON;
	}
	else if ( LEDCNT1_FLASH_500MS == usRegData) {	
		ulStat = R_IN32D_LED_BLINK;
	}
	else {										
		ulStat = R_IN32D_LED_OFF;
	}

	return( ulStat );
}

ULONG gulR_IN32D_GetLedREM( VOID )
{
	ULONG	ulStat;			
#if 1
	ulStat = gstUserLEDCtrl[0].ulCtrl;
#else
	USHORT	usRegData;		

	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b3ZRemLEDLighting;
	if ( LEDCNT1_ON == usRegData) {			
		ulStat = R_IN32D_LED_ON;
	}
	else if ( LEDCNT1_FLASH_500MS == usRegData) {	
		ulStat = R_IN32D_LED_BLINK;
	}
	else {										
		ulStat = R_IN32D_LED_OFF;
	}
#endif

	return( ulStat );
}

ULONG gulR_IN32D_GetLedMODE( VOID )
{
	ULONG	ulStat;			
#if 1
	ulStat = gstUserLEDCtrl[1].ulCtrl;
#else
	USHORT	usRegData;		

	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b3ZModeLEDLighting;
	if ( LEDCNT1_ON == usRegData) {			
		ulStat = R_IN32D_LED_ON;
	}
	else if ( LEDCNT1_FLASH_500MS == usRegData) {	
		ulStat = R_IN32D_LED_BLINK;
	}
	else {										
		ulStat = R_IN32D_LED_OFF;
	}
#endif

	return( ulStat );
}

ULONG gulR_IN32D_GetLedRUN( VOID )
{
	ULONG	ulStat;			
	USHORT	usRegData;		
	usRegData = (USHORT)LED->R_LEDCNT1.stBit.b3ZRunLEDLighting;
	if ( LEDCNT1_ON == usRegData) {		
		ulStat = R_IN32D_LED_ON;
	}
	else {									
		ulStat = R_IN32D_LED_OFF;
	}

	return( ulStat );
}

ERRCODE gerR_IN32D_MaskLed(
	USHORT usMaskPattern		
)
{
	R_IN32_R_LEDMASK_T stRegData;
	
	stRegData.ulAll = 0;
	stRegData.stBit.b1ZRunLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZRunLEDLightingMask;		
	stRegData.stBit.b1ZModeLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZModeLEDLightingMask;	
	stRegData.stBit.b1ZErrLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZErrLEDLightingMask;		
	stRegData.stBit.b1ZRemLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZRemLEDLightingMask;		
	stRegData.stBit.b1ZDLinkLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZDLinkLEDLightingMask;	
	stRegData.stBit.b1ZLErr1LEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZLErr1LEDLightingMask;	
	stRegData.stBit.b1ZLErr2LEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZLErr2LEDLightingMask;	
	
	LED->R_LEDMASK.ulAll |= stRegData.ulAll;

	if (stRegData.stBit.b1ZRemLEDLightingMask == R_IN32_ON) {
		gstUserLEDCtrl[0].ucMaskStatus = R_IN32_ON;
		RIN_RTPORT->RP2B |= 0x01;
	}
	if (stRegData.stBit.b1ZModeLEDLightingMask == R_IN32_ON) {
		gstUserLEDCtrl[1].ucMaskStatus = R_IN32_ON;
		RIN_RTPORT->RP2B |= 0x02;
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_UnMaskLed(
	USHORT usMaskPattern		
)
{
	R_IN32_R_LEDMASK_T stRegData;
	
	stRegData.ulAll = 0;
	stRegData.stBit.b1ZRunLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZRunLEDLightingMask;		
	stRegData.stBit.b1ZModeLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZModeLEDLightingMask;	
	stRegData.stBit.b1ZErrLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZErrLEDLightingMask;		
	stRegData.stBit.b1ZRemLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZRemLEDLightingMask;		
	stRegData.stBit.b1ZDLinkLEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZDLinkLEDLightingMask;	
	stRegData.stBit.b1ZLErr1LEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZLErr1LEDLightingMask;	
	stRegData.stBit.b1ZLErr2LEDLightingMask	= (*(LEDMASK_T*)&usMaskPattern).uniLedMask.stBit.b1ZLErr2LEDLightingMask;	
	
	LED->R_LEDMASK.ulAll &= ~stRegData.ulAll;

	if (stRegData.stBit.b1ZRemLEDLightingMask == R_IN32_ON) {
		gstUserLEDCtrl[0].ucMaskStatus = R_IN32_OFF;
		(VOID)erR_IN32D_SetUserLed(0, gstUserLEDCtrl[0].ulCtrl, R_IN32_FALSE);
	}
	if (stRegData.stBit.b1ZModeLEDLightingMask == R_IN32_ON) {
		gstUserLEDCtrl[1].ucMaskStatus = R_IN32_OFF;
		(VOID)erR_IN32D_SetUserLed(1, gstUserLEDCtrl[1].ulCtrl, R_IN32_FALSE);
	}

	return( R_IN32D_OK );
}

static ERRCODE erR_IN32D_SetUserLed(
	UCHAR	ucLedNumber,
	ULONG	ulCtrl,
	UCHAR	ucReset
)
{
	ERRCODE				erRet		= R_IN32D_OK;
	UCHAR				ucStatus	= R_IN32_OFF;
	USER_LED_CTRL_T*	pstLEDCtrl	= &gstUserLEDCtrl[ucLedNumber];

	switch (ulCtrl) {
	case R_IN32_LED_OFF:
		ucStatus = R_IN32_OFF;
		break;
	case R_IN32_LED_ON:
		ucStatus = R_IN32_ON;
		break;
	case R_IN32_LED_BLINK:
		if (ucReset == R_IN32_TRUE) {
			ucStatus = R_IN32_ON;
		}
		else
		{
			if (pstLEDCtrl->ucStatus == R_IN32_OFF) {
				ucStatus = R_IN32_ON;
			} else {
				ucStatus = R_IN32_OFF;
			}
		}
		break;
	default:
		erRet = R_IN32D_NG;
		break;
	}

	if (erRet == R_IN32D_OK) {
		if (pstLEDCtrl->ucMaskStatus == R_IN32_OFF) {
			if (ucStatus == R_IN32_ON) {
				if (ucLedNumber == 0) {
					RIN_RTPORT->RP2B &= 0xFE;
				} else {
					RIN_RTPORT->RP2B &= 0xFD;
				}
			} else {
				if (ucLedNumber == 0) {
					RIN_RTPORT->RP2B |= 0x01;
				} else {
					RIN_RTPORT->RP2B |= 0x02;
				}
			}
		}
		pstLEDCtrl->ucStatus = ucStatus;
		if (ucReset == R_IN32_TRUE) {
			pstLEDCtrl->ulCtrl = ulCtrl;
		}
	}

	return erRet;
}

ERRCODE gerR_IN32D_BlinkLed(
	USHORT* pusBlinkMS
)
{
	USER_LED_CTRL_T*	pstLEDCtrl	= &gstUserLEDCtrl[0];
	UCHAR				ucLedNum;

	for (ucLedNum = 0; ucLedNum <= 1; ucLedNum++, pstLEDCtrl++) {
		(VOID)erR_IN32D_SetUserLed(ucLedNum, pstLEDCtrl->ulCtrl, R_IN32_FALSE);
	}

	switch(gulConvLedCtrlTbl[R_IN32_LED_BLINK]) {
	case LEDCNT1_FLASH_1S:
		*pusBlinkMS = 1000;
		break;
	case LEDCNT1_FLASH_200MS:
		*pusBlinkMS = 200;
		break;
	case LEDCNT1_FLASH_500MS:
	default:
		*pusBlinkMS = 500;
		break;
	}

	return( R_IN32D_OK );
}

/*** EOF ***/
