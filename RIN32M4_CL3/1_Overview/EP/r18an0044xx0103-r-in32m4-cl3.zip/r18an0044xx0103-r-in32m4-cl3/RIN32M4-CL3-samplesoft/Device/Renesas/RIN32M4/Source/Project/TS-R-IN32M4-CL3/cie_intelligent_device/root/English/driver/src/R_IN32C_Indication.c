/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Indication.c                                              */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Callback.h"
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


ERRCODE erR_IN32C_IndStationNumberChanged(
	UCHAR uchNetworkNumber,			
	USHORT usStationNumber			
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_NotifyRecvSetStNo(uchNetworkNumber, usStationNumber);	

	return erRet;
}

ERRCODE erR_IN32C_IndActCmdChanged(R_IN32C_PRMCMD_T stPrmCmd)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG ulNWCActCmd = 0;


	if ((R_IN32D_ACTCMD_CYCSTP_STNOUTRANGE & stPrmCmd.ulCommand) != 0){
		ulNWCActCmd |= R_IN32C_CYCSTP_OUTSTA_BIT;
	}
	else {
	}

	if ((R_IN32D_ACTCMD_CYCSTP_RSVST & stPrmCmd.ulCommand) != 0){
		ulNWCActCmd |= R_IN32C_CYCSTP_RSVST_BIT;
	}
	else {
	}

	if ((R_IN32D_ACTCMD_CYCSTP_MSTREQ & stPrmCmd.ulCommand) != 0){
		ulNWCActCmd |= R_IN32C_CYCSTP_MSTREQ_BIT;
	}
	else {
	}

	if ((R_IN32D_ACTCMD_CYCSTP_DUPLICATE & stPrmCmd.ulCommand) != 0){
		ulNWCActCmd |= R_IN32C_CYCSTP_DUP_BIT;
	}
	else {
	}

	if (R_IN32_TRUE == stPrmCmd.blTypeErr) {
		ulNWCActCmd |= R_IN32C_STATIONTYPE_VALID;
	}
	else {
	}

	if (R_IN32_TRUE == stPrmCmd.blSizeErr) {
		ulNWCActCmd |= R_IN32C_CYCSIZE_ERROR;
	}
	else {
	}

	gR_IN32S_NotifyRecvOpeCmd(ulNWCActCmd);

	return erRet;
}

ERRCODE erR_IN32C_IndRcvFrameToNCYC(
	ULONG ulSize,							
	VOID * pstRcv							
)
{
	ERRCODE erRet = R_IN32C_OK;
	NONCICLIC_FRAME_REG_T * pstTmp;


	pstTmp = pstRcv;
	if (FRAME_COM_FRMTYPE == pstTmp->usType) {

		switch (pstTmp->uchFrameClassification) {
		case (UCHAR)FTYPE_Transient1:			
		case (UCHAR)FTYPE_Transient2:			
		case (UCHAR)FTYPE_TransientAck:			
			erRet = gerR_IN32_CallbackReceivedTransient(pstRcv, (USHORT)ulSize);

			if ( R_IN32_OK == erRet ) {
				erRet = R_IN32C_OK;
			}
			else {
				erRet = R_IN32C_NG_OVERFLOW;
			}

			break;

		case (UCHAR)FTYPE_Parameter:
			erRet = gerR_IN32D_ParameterRcv((PARAMETER_FRAME_REG_TAG*)pstRcv, ulSize);
			break;

		case (UCHAR)FTYPE_ParamCheck:
			erRet = gerR_IN32D_ParamCheckRcv((PARAMCHECK_FRAME_REG_TAG*)pstRcv, ulSize);
			break;
		default:
			break;
		}
	}
	else {
	}

	return erRet;
}

ERRCODE erR_IN32C_IndSndFin(
	UCHAR uchTDISNum,		
	ULONG ulSts				
)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erSts2;

	if (R_IN32D_TDIS_TXOK == ulSts) {
		erSts2 = R_IN32_OK;
	}
	else {
		erSts2 = R_IN32_ERR;
	}

	gR_IN32S_SendFin(uchTDISNum, erSts2);

	return erRet;
}

/*** EOF ***/
