/**
 *******************************************************************************
 * @file  can.h
 * @brief CAN driver header
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	CAN_H__
#define	CAN_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

#ifdef R9A06G064SGBG_EN
#error "CAN driver cannot be used with R9A06G064SGBG."
#endif

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/*
 *		Parameter code
 */

/*----------------------------------------------------------------------------*/
/*  CAN channel                                                               */
/*----------------------------------------------------------------------------*/
/* Total number of CAN channel */
#define	CAN_CH_NUM					(2)

#define	CAN_CH0						(0)
#define	CAN_CH1						(1)

/*----------------------------------------------------------------------------*/
/*  CAN number of message buffer                                              */
/*----------------------------------------------------------------------------*/
#define	CAN_MSG_BUF_NUM				(64)

#define	CAN_Msg000					0x00	/* Tx message */
#define	CAN_Msg001					0x01	/* Tx message */
#define	CAN_Msg002					0x02	/* Tx message */
#define	CAN_Msg003					0x03	/* Tx message */
#define	CAN_Msg004					0x04	/* Tx message */
#define	CAN_Msg005					0x05	/* Tx message */
#define	CAN_Msg006					0x06	/* Tx message */
#define	CAN_Msg007					0x07	/* Tx message */
#define	CAN_Msg008					0x08	/* Tx message */
#define	CAN_Msg009					0x09	/* Tx message */
#define	CAN_Msg010					0x0A	/* Tx message */
#define	CAN_Msg011					0x0B	/* Tx message */
#define	CAN_Msg012					0x0C	/* Tx message */
#define	CAN_Msg013					0x0D	/* Tx message */
#define	CAN_Msg014					0x0E	/* Tx message */
#define	CAN_Msg015					0x0F	/* Tx message */
#define	CAN_Msg016					0x10	/* Tx message */
#define	CAN_Msg017					0x11	/* Tx message */
#define	CAN_Msg018					0x12	/* Tx message */
#define	CAN_Msg019					0x13	/* Tx message */
#define	CAN_Msg020					0x14	/* Tx message */
#define	CAN_Msg021					0x15	/* Tx message */
#define	CAN_Msg022					0x16	/* Tx message */
#define	CAN_Msg023					0x17	/* Tx message */
#define	CAN_Msg024					0x18	/* Tx message */
#define	CAN_Msg025					0x19	/* Tx message */
#define	CAN_Msg026					0x1A	/* Tx message */
#define	CAN_Msg027					0x1B	/* Tx message */
#define	CAN_Msg028					0x1C	/* Tx message */
#define	CAN_Msg029					0x1D	/* Tx message */
#define	CAN_Msg030					0x1E	/* Tx message */
#define	CAN_Msg031					0x1F	/* Tx message */
#define	CAN_Msg032					0x20	/* Rx message */
#define	CAN_Msg033					0x21	/* Rx message */
#define	CAN_Msg034					0x22	/* Rx message */
#define	CAN_Msg035					0x23	/* Rx message */
#define	CAN_Msg036					0x24	/* Rx message */
#define	CAN_Msg037					0x25	/* Rx message */
#define	CAN_Msg038					0x26	/* Rx message */
#define	CAN_Msg039					0x27	/* Rx message */
#define	CAN_Msg040					0x28	/* Rx message */
#define	CAN_Msg041					0x29	/* Rx message */
#define	CAN_Msg042					0x2A	/* Rx message */
#define	CAN_Msg043					0x2B	/* Rx message */
#define	CAN_Msg044					0x2C	/* Rx message */
#define	CAN_Msg045					0x2D	/* Rx message */
#define	CAN_Msg046					0x2E	/* Rx message */
#define	CAN_Msg047					0x2F	/* Rx message */
#define	CAN_Msg048					0x30	/* Rx message */
#define	CAN_Msg049					0x31	/* Rx message */
#define	CAN_Msg050					0x32	/* Rx message */
#define	CAN_Msg051					0x33	/* Rx message */
#define	CAN_Msg052					0x34	/* Rx message */
#define	CAN_Msg053					0x35	/* Rx message */
#define	CAN_Msg054					0x36	/* Rx message */
#define	CAN_Msg055					0x37	/* Rx message */
#define	CAN_Msg056					0x38	/* Rx message */
#define	CAN_Msg057					0x39	/* Rx message */
#define	CAN_Msg058					0x3A	/* Rx message */
#define	CAN_Msg059					0x3B	/* Rx message */
#define	CAN_Msg060					0x3C	/* Rx message */
#define	CAN_Msg061					0x3D	/* Rx message */
#define	CAN_Msg062					0x3E	/* Rx message */
#define	CAN_Msg063					0x3F	/* Rx message */


/*----------------------------------------------------------------------------*/
/*  CAN status clear macro                                                    */
/*----------------------------------------------------------------------------*/

/*----------------------------------------------------------------------------*/
/*  CAN-ID format mode                                                        */
/*----------------------------------------------------------------------------*/
#define	CAN_ID_EXT					(0x80000000)
#define	CAN_ID_STD_MSK				(0x000007ff)
#define	CAN_ID_EXT_MSK				(0x1fffffff)

/*
 *		Conversion macro
 */
#define	CAN_SET_STD_ID(id)			((id) << 18)
#define	CAN_SET_EXT_ID(id)			((id) | CAN_ID_EXT)
#define	CAN_GET_STD_ID(id)			(((id) >> 18) & CAN_ID_STD_MSK)
#define	CAN_GET_EXT_ID(id)			((id) & CAN_ID_EXT_MSK)
#define	CAN_GET_ID(id)				(((id & CAN_ID_EXT) == CAN_ID_EXT) ? CAN_GET_EXT_ID(id) : CAN_GET_STD_ID(id))

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
/*
 *		CAN device driver function
 */
ER_RET	can_enable(uint8_t);
ER_RET	can_shutdown(uint8_t);
ER_RET	can_init(uint8_t);
ER_RET	can_get_mode(uint8_t);
ER_RET	can_set_mode(uint8_t,uint16_t);
ER_RET	can_set_data(uint8_t, uint8_t, uint8_t *);
ER_RET	can_set_id_data_dlc(uint8_t, uint8_t, uint32_t, uint8_t *, uint8_t);
ER_RET	can_get_data_dlc(uint8_t, uint8_t, uint8_t *, uint8_t *);
ER_RET	can_get_id_data_dlc(uint8_t, uint8_t, uint32_t *, uint8_t *, uint8_t *);
ER_RET	can_tx_req(uint8_t, uint8_t);
ER_RET	can_get_txinfo(uint8_t , uint8_t);
ER_RET	can_get_rxinfo(uint8_t , uint8_t);
ER_RET	can_get_ch_status(uint8_t);
ER_RET	can_clr_ch_status(uint8_t, uint8_t);
ER_RET	can_get_bus_staus(uint8_t);


/*
 *		Configuration file setup information
 */
/*----------------------------------------------------------------------------*/
/*  [Channel] can_ch_info[]                                                   */
/*----------------------------------------------------------------------------*/
#define	CAN_CH_USE					(0x80)

/*----------------------------------------------------------------------------*/
/*  [Channel] can_ch_info[]                                                   */
/*----------------------------------------------------------------------------*/
#define	CAN_CMIECTL_SET_TX			(0x0100)
#define	CAN_CMIECTL_SET_RX			(0x0200)
#define	CAN_CMIECTL_SET_ERRSTS		(0x0400)
#define	CAN_CMIECTL_SET_PRTERR		(0x0800)
#define	CAN_CMIECTL_SET_ARBLST		(0x1000)
#define	CAN_CMIECTL_SET_WAKUP		(0x2000)
#define	CAN_CMIECTL_SET_TRXABT		(0x4000)
#define	CAN_CMIECTL_CLR_TX			(0x0001)
#define	CAN_CMIECTL_CLR_RX			(0x0002)
#define	CAN_CMIECTL_CLR_ERRSTS		(0x0004)
#define	CAN_CMIECTL_CLR_PRTERR		(0x0008)
#define	CAN_CMIECTL_CLR_ARBLST		(0x0010)
#define	CAN_CMIECTL_CLR_WAKUP		(0x0020)
#define	CAN_CMIECTL_CLR_TRXABT		(0x0040)

/*----------------------------------------------------------------------------*/
/*  [Message] can_msg_info                                                    */
/*----------------------------------------------------------------------------*/
#define	CAN_MSGBUF_USE					(0x01)		/* FCNnMmSTRB.FCNnMmSSMA		*/
#define	CAN_MSGBUF_MSGTYP_TX			(0x00)		/* FCNnMmSTRB.FCNnMmSSMT3-0		*/
#define	CAN_MSGBUF_MSGTYP_RX			(0x08)
#define	CAN_MSGBUF_MSGTYP_MSK1			(0x10)
#define	CAN_MSGBUF_MSGTYP_MSK2			(0x18)
#define	CAN_MSGBUF_MSGTYP_MSK3			(0x20)
#define	CAN_MSGBUF_MSGTYP_MSK4			(0x28)
#define	CAN_MSGBUF_MSGTYP_MSK5			(0x30)
#define	CAN_MSGBUF_MSGTYP_MSK6			(0x38)
#define	CAN_MSGBUF_MSGTYP_MSK7			(0x40)
#define	CAN_MSGBUF_MSGTYP_MSK8			(0x48)
#define	CAN_MSGBUF_FRMTYP_DAT			(0x00)		/* FCNnMmSTRB.FCNnMmSSRT		*/
#define	CAN_MSGBUF_FRMTYP_RMT			(0x04)
#define	CAN_MSGBUF_OVRWRT				(0x80)		/* FCNnMmSTRB.FCNnMmSSOW		*/

#define	CAN_MSGBUF_INI_TX				(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_TX | CAN_MSGBUF_FRMTYP_DAT)
#define	CAN_MSGBUF_INI_RX				(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK1 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK1			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK1 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK2			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK2 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK3			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK3 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK4			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK4 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK5			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK5 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK6			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK6 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK7			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK7 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)
#define	CAN_MSGBUF_INI_RX_MSK8			(CAN_MSGBUF_USE | CAN_MSGBUF_MSGTYP_MSK8 | CAN_MSGBUF_FRMTYP_DAT | CAN_MSGBUF_OVRWRT)


/*
 *		Structure definition
 */

/*----------------------------------------------------------------------------*/
/*  Baud rate setup information                                               */
/*----------------------------------------------------------------------------*/
typedef struct {
	uint8_t			FCNnGMCSPRE;
	uint8_t			FCNnCMBRPRS;
	uint16_t		FCNnCMBTCTL;
	uint8_t			PRMxx;
} CAN_BPSINFO_TypeDef;

/*----------------------------------------------------------------------------*/
/* CAN channel information                                                    */
/*----------------------------------------------------------------------------*/
typedef struct {
	uint8_t			use;
	uint16_t		FCNnCMIECTL;
} CAN_CHINFO_TypeDef;

/*----------------------------------------------------------------------------*/
/* CAN message buffer information                                             */
/*----------------------------------------------------------------------------*/
typedef struct {
	uint32_t		FCNnMmMID0W;
	uint8_t			FCNnMmSTRB;
	uint8_t			FCNnMmDTLGB;
} CAN_MSGINFO_TypeDef;

/*----------------------------------------------------------------------------*/
/*  Programmable I/O register for CAN macro                                   */
/*----------------------------------------------------------------------------*/
typedef struct {
	RIN_CAN_MSGB_TypeDef B;
	RIN_CAN_MSGB_TypeDef RESERVEDB[63];
	uint8_t	RESERVED1[0x09000 - 0x02000];
	RIN_CAN_MSGH_TypeDef H;
	RIN_CAN_MSGH_TypeDef RESERVEDH[63];
	uint8_t	RESERVED2[0x11000 - 0x0a000];
	RIN_CAN_MSGW_TypeDef W;
} CAN_MSG_TypeDef;

/*
 *		Configuration file setup information
 */

/*----------------------------------------------------------------------------*/
/*  [Channel] can_msg_msk_info[]                                          */
/*----------------------------------------------------------------------------*/
/*----------------------------------------------------------------------------*/
/*  [Channel] Number of mask register                                         */
/*----------------------------------------------------------------------------*/
#define	CAN_NUM_OF_MASK					(8)
#define	MSK_CAN_CMMKCTLH				(0x1fff0000)
#define	MSK_CAN_CMMKCTLL				(0x0000ffff)


/*----------------------------------------------------------------------------*/
/*  [Message]                                                                 */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_MSSMTx					(0x78)
#define	CHK_CAN_MSSMTx_TX				(0x00)
#define	MSK_CAN_DTLG					(0x000f)

/*----------------------------------------------------------------------------*/
/*  [Data] Configuration data external reference definition                   */
/*----------------------------------------------------------------------------*/
extern RIN_CAN_TypeDef* RIN_CAN[];

/* Channel information */
extern const CAN_CHINFO_TypeDef			can_ch_info[];
extern const CAN_BPSINFO_TypeDef		can_bps_info[];
extern const uint32_t					can_msg_msk_info[][CAN_NUM_OF_MASK];

/* Message information */
extern const CAN_MSGINFO_TypeDef		can_msg_info[][CAN_MSG_BUF_NUM];

/*
 *		Parameter code
 */
/*----------------------------------------------------------------------------*/
/*  CAN data length                                                           */
/*----------------------------------------------------------------------------*/
#define	LEN_CANDATA						(8)


/*
 *		CAN register macro code (for FCN)
 */
/*----------------------------------------------------------------------------*/
/*  [Register] FCNnGMCLCTL                                                    */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_GMCLPWOM				(0x0001)
#define	CLR_CAN_GMCLPWOM				(0x0001)
#define	MSK_CAN_GMCLSORF				(0x0010)
#define	MSK_CAN_GMCLECCF				(0x0020)
#define	SET_CAN_GMCLPWOM				(0x0100)
#define	SET_CAN_GMCLESDE				(0x0200)

/*----------------------------------------------------------------------------*/
/*  [Register] FCNnCMCLCTL                                                    */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_CMCLMDOF				(0x0007)
#define	MSK_CAN_CMCLMDPF				(0x0018)
#define	CHK_CAN_INIT					(0x0000)
#define	CHK_CAN_NORM					(0x0001)
#define	CHK_CAN_ABT						(0x0002)
#define	CHK_CAN_RXONLY					(0x0003)
#define	CHK_CAN_SSHT					(0x0004)
#define	CHK_CAN_SELF					(0x0005)
#define	SET_CAN_ERCF					(0x8000)
#define	CLR_CAN_ERCF					(0x0000)
#define	SET_CAN_ALBF					(0x4000)
#define	CLR_CAN_ALBF					(0x0040)
#define	SET_CAN_INIT					(0x0007)
#define	SET_CAN_NORM					(0x0100)
#define	SET_CAN_SELF					(0x0500)

/*----------------------------------------------------------------------------*/
/*  [Register] FCNnCMISCTL                                                    */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_CMISITSF0				(0x0001)
#define	MSK_CAN_CMISITSF1				(0x0002)
#define	MSK_CAN_CMISITSF2				(0x0004)
#define	MSK_CAN_CMISITSF3				(0x0008)
#define	MSK_CAN_CMISITSF4				(0x0010)
#define	MSK_CAN_CMISITSF5				(0x0020)
#define	MSK_CAN_CMISITSF6				(0x0040)
#define	CAN_STS_TXEND					(MSK_CAN_CMISITSF0)			/* CAN Tx Complete */
#define	CAN_STS_RXEND					(MSK_CAN_CMISITSF1)			/* CAN Rx Complete */
#define	CAN_STS_ERRSTS					(MSK_CAN_CMISITSF2)			/* CAN error status */
#define	CAN_STS_PRTERR					(MSK_CAN_CMISITSF3)			/* CAN protocol error */
#define	CAN_STS_ABL						(MSK_CAN_CMISITSF4)			/* Arbitration lost */
#define	CAN_STS_WAK						(MSK_CAN_CMISITSF5)			/* Wakeup */
#define	CAN_STS_TXA						(MSK_CAN_CMISITSF6)			/* Trasmittion abort */
#define	CAN_STS_ALL						( CAN_STS_TXEND \
										| CAN_STS_RXEND \
										| CAN_STS_ERRSTS \
										| CAN_STS_PRTERR \
										| CAN_STS_ABL \
										| CAN_STS_WAK \
										| CAN_STS_TXA )

/*----------------------------------------------------------------------------*/
/*  [Register] FCNnCMINSTR                                                    */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_CMINSSRE				(0x03)
#define	MSK_CAN_CMINSSTE				(0x0c)
#define	MSK_CAN_CMINBOFF				(0x10)

/*----------------------------------------------------------------------------*/
/*  [Register] FCNnCMCLCTL                                                    */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_MRDYF					(0x0001)
#define	CLR_CAN_MRDYF					(0x0001)
#define	SET_CAN_MRDYF					(0x0100)
#define	MSK_CAN_MTRQF					(0x0002)
#define	CLR_CAN_MTRQF					(0x0002)
#define	SET_CAN_MTRQF					(0x0200)
#define	MSK_CAN_MDTNF					(0x0004)
#define	CLR_CAN_MDTNF					(0x0004)
#define	SET_CAN_MDTNF					(0x0400)
#define	CLR_CAN_MIENF					(0x0008)
#define	SET_CAN_MIENF					(0x0800)
#define	CLR_CAN_MMOWF					(0x0010)
#define	MSK_CAN_MTCPF					(0x0200)
#define	MSK_CAN_MNHMF					(0x0040)
#define	CLR_CAN_MNHMF					(0x0040)
#define	SET_CAN_MNHMF					(0x4000)
#define	MSK_CAN_MMUCF					(0x2000)

/*----------------------------------------------------------------------------*/
/*  [Register] FCNnMmSTRB                                                     */
/*----------------------------------------------------------------------------*/
#define	MSK_CAN_MSSMA					(0x03)
#define	CLR_CAN_MSSMA					(0xfc)

#endif // CAN_H__
