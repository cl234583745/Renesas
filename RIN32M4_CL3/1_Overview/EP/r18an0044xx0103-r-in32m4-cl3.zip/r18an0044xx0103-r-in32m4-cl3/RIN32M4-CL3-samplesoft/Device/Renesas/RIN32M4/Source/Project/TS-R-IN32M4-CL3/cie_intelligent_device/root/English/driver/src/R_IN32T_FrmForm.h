/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_FrmForm.h                                                 */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32T_FRMFORM_H_INCLUDED__
#define __R_IN32T_FRMFORM_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define	R_IN32T_DATATYPE_UNUSED		(UCHAR)0x00				
#define	R_IN32T_DATATYPE_CTRLFRM		(UCHAR)0x01				
#define	R_IN32T_DATATYPE_PARAM			(UCHAR)0x03				
#define	R_IN32T_DATATYPE_GENDAT		(UCHAR)0x04				
#define	R_IN32T_DATATYPE_CCLINK_TRAN	(UCHAR)0x04				
/*---------*/
#define	R_IN32T_DATATYPE_TRANSIENT1_GEN	R_IN32T_DATATYPE_GENDAT	


/*------------------------------*/

#define	R_IN32T_DCS_SIZE			sizeof(ULONG)			
#define	R_IN32T_FCS_SIZE			sizeof(ULONG)			


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/


typedef struct _R_IN32T_FRM_NODE_TAG {
	USHORT usNodeID;					
	UCHAR  auchZReserved[2];			
} R_IN32T_FRM_NODE_T;

typedef struct _R_IN32T_FRM_CONNECT_TAG {
	USHORT usNodeID;					
	UCHAR  uchConnect;					
	UCHAR  uchZReserved;				
} R_IN32T_FRM_CONNECT_T;

typedef union _R_IN32T_FRM_UNION1_TAG {
	R_IN32T_FRM_NODE_T		stNode;
	R_IN32T_FRM_CONNECT_T	stConnect;
} R_IN32T_FRM_UNION1_T;

typedef struct _R_IN32T_FRMHDR_TAG {
	UCHAR	auchDesMACAddr[R_IN32_MACADR_SZ];	
	UCHAR	auchSouMACAddr[R_IN32_MACADR_SZ];	
	USHORT	usEtherType;					
	UCHAR	uchFrmType;						
	UCHAR	uchDataType;					

	R_IN32T_FRM_UNION1_T	Union1;				

	USHORT	usStNo;							
	UCHAR	uchProtocol;					
	UCHAR	uchReserved1;					
	ULONG	ulHec;							
} R_IN32T_FRMHDR_T;

typedef struct _R_IN32T_FRM_TRN1HDR_TAG {
	R_IN32T_FRMHDR_T	stFRMHDR;				
	ULONG			ulReserved1;			
	UCHAR			uchSeqNo;				
	UCHAR			uchIdentNo;				
	USHORT			usTrnDatAllSize;		
	ULONG			ulOffsetAdr;			
	USHORT			usTrnDatSize;			
	USHORT			usDataSubType;			
} R_IN32T_FRM_TRN1HDR_T;


#endif /* __R_IN32T_FRMFORM_H_INCLUDED__ */
/*** EOF ***/
