/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_Com.h                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_COM_H_INCLUDED__
#define	__R_IN32T_COM_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

typedef enum _R_IN32T_DATPTN_ENUM {
	R_IN32T_E_DATPTN_START,		
	R_IN32T_E_DATPTN_CONTINUE		
} R_IN32T_DATPTN_ENUM;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern ERRCODE erR_IN32T_Com_WaitBitOff_Word( const USHORT*, USHORT );
extern ERRCODE erR_IN32T_Com_WaitBitOff_DWord( const ULONG*, ULONG );
extern ERRCODE erR_IN32T_Com_BitCompExpect_Word( const USHORT*, USHORT, USHORT );
extern ERRCODE erR_IN32T_Com_BitCompExpect_DWord( const ULONG*, ULONG, ULONG );
extern ERRCODE erR_IN32T_Com_MemCompExpect_DWord( const ULONG*, const ULONG*, ULONG );
extern VOID    R_IN32T_Com_MemSet_BitShift_DWord( ULONG*, ULONG, R_IN32T_DATPTN_ENUM );


#endif	/* __R_IN32T_COM_H_INCLUDED__ */

/*** EOF ***/
