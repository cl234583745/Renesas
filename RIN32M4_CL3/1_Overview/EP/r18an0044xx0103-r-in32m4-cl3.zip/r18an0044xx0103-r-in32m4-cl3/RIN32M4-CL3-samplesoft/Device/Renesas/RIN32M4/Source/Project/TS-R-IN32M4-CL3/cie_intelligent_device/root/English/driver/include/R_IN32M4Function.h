/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver header                                             */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4FUNCTION_H__
#define __R_IN32M4FUNCTION_H__



/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32_BASE_ADR				0x40100000	/* R_IN32M4 top address */
#define R_IN32_WAITUS_PHYRESET_ASSERT	10000UL		/* PHY reset assert time */
#define R_IN32_WAITUS_PHYRESET_END		5000UL	/* Time until normal operation after releasing PHY reset  */
#define R_IN32_TRANSIENT_BUFFER_NUM	(64)		/* Number of transient receive buffer */

/* Port select */
#define R_IN32_PORT1					0   
#define R_IN32_PORT2					1   

/* Reset */
#define R_IN32_RESET_PWRON				1	/* Power-on reset */
#define R_IN32_RESET_SYSTEM				2	/* System reset   */

/* Communication status */
#define R_IN32_COMMSTS_DISCONNECT		0	/* Disconnected*/
#define R_IN32_COMMSTS_TOKEN_PASS		1	/* Executing token pass          */
#define R_IN32_COMMSTS_CYC_DLINK		2	/* Executing cyclic communication */

/* Port status */
#define R_IN32_LINKDOWN					0	/* link down */
#define R_IN32_LINKUP						1	/* link up   */

#define R_IN32_MYPORT_PORTALL			0x00	/* All possessed ports are effective */
#define R_IN32_MYPORT_PORT_1			0x01	/* Only port 1 is effective */
#define R_IN32_MYPORT_PORT_2			0x02	/* Only port 2 is effective */

/* Speed */
#define R_IN32_SPEED_1G					0	
#define R_IN32_SPEED_100M					1	
#define R_IN32_SPEED_10M					2	

/* Full/half duplex */
#define R_IN32_DUPLEX_FULL				0	
#define R_IN32_DUPLEX_HALF				1	

/* LED */
#define R_IN32_LED_OFF					0	/* LED off      */
#define R_IN32_LED_ON						1	/* LED on       */
#define R_IN32_LED_BLINK					2	/* LED blinking */

/* Initial value of Detailed application operation status */
#define R_IN32_RUNSTS_UNSUPPORTED		0	/* Notification of detailed application operation status not supported */
#define R_IN32_RUNSTS_STOP			1	/* Application stopped */
#define R_IN32_RUNSTS_RUN				2	/* Application running */
#define R_IN32_RUNSTS_NOTEXIST		3	/* Application entity does not exist */

/* Initial value of Detailed application error status */
#define R_IN32_ERRSTS_NONE			0	/* No error */
#define R_IN32_ERRSTS_WARNING			1	/* Minor error  */
#define R_IN32_ERRSTS_ERROR			2	/* Moderate error */
#define R_IN32_ERRSTS_FATALERROR		3	/* Major error */

/* Length of the name */
#define R_IN32_MODEL_NAME_LENGTH		20	/* Network unit model name */
#define R_IN32_VENDOR_NAME_LENGTH		32	/* Network vendor name */

/* enable/disable */
#define R_IN32_ENABLE						1	
#define R_IN32_DISABLE					0	

/* IEEE802.3ab compliance test mode */
#define R_IN32_IEEE_MODE1				0		/* MODE 1 */
#define R_IN32_IEEE_MODE2				1		/* MODE 2 */
#define R_IN32_IEEE_MODE3				2		/* MODE 3 */
#define R_IN32_IEEE_MODE4				3		/* MODE 4 */
#define R_IN32_IEEE_END				4		/* test end */


/* Interrupt source */
#define	R_IN32_EVTPRM_INTERRUPT_CONNECT		(0x00000001UL)
#define	R_IN32_EVTPRM_INTERRUPT_DISCONNECT		(0x00000002UL)
#define	R_IN32_EVTPRM_INTERRUPT_TO_DISCONNECT	(0x00000004UL)
#define	R_IN32_EVTPRM_INTERRUPT_TO_CONNECT		(0x00000008UL)
#define	R_IN32_EVTPRM_INTERRUPT_CHANGE_STNO	(0x00000010UL)
#define	R_IN32_EVTPRM_INTERRUPT_CHANGE_CMD		(0x00000020UL)
#define	R_IN32_EVTPRM_INTERRUPT_PRM_FRMRCV		(0x00000040UL)
#define	R_IN32_EVTPRM_INTERRUPT_CHKPRM_FRMRCV	(0x00000100UL)
#define	R_IN32_EVTPRM_INTERRUPT_RECV_NONCYCLIC	(0x00001000UL)
#define	R_IN32_EVTPRM_INTERRUPT_SENDFIN_NONCYCLIC		(0x00002000UL)
#define	R_IN32_EVTPRM_INTERRUPT_MST_WATCH_TIME	(0x00200000UL)



#define R_IN32_DISCONNECTFACTOR_NOFACTOR		(0x00000000UL)	
#define R_IN32_DISCONNECTFACTOR_PERSUASION		(0x00000001UL)	

#define R_IN32_MDI_AUTO					0   
#define R_IN32_MDI_FORCED_MDI				1   
#define R_IN32_MDI_FORCED_MDIX			2   

#define R_IN32_CLOCK_AUTO					0   
#define R_IN32_CLOCK_MASTER				1   
#define R_IN32_CLOCK_SLAVE				2   


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

/* Interrupt source */
typedef struct R_IN32_EVTPRM_INTERRUPT_TAG {
	union {
		ULONG ulAll;
		struct {
			ULONG b1ZCommConnect:					1; /**< b0: Communication established */
			ULONG b1ZCommDisconnect:				1; /**< b1: Communication disconnected */
			ULONG b1ZCommConnectToDisconnect:		1; /**< b2: Connected -> disconnected */
			ULONG b1ZCommDisconnectToConnect:		1; /**< b3: Disconnected -> connected */
			ULONG b1ZChangeStNoNetNo:				1; /**< b4: station/network No. change */
			ULONG b1ZChangeActCommand:				1; /**< b5: Operation command change */
			ULONG b1ZPrmFrmRcv_OK:					1; /**< b6: Parameter frame reception (setting data is valid) */
			ULONG b1ZReserve1:						1; /**< b7: Reserved */
			ULONG b1ZPrmChkFrmRcv_OK:				1; /**< b8: ParamCheck frame reception (parameter is valid) */
			ULONG b3ZReserve2:						3; /**< b9-11: Reserved */
			ULONG b1ZRecvNonCyclic:					1; /**< b12: Transient reception */
			ULONG b1ZSendFinNonCyclic:				1; /**< b13: Transient sending completion */
			ULONG b7ZReserve3:						7; /**< b14-20: Reserved */
			ULONG b1ZMasterWatchTimeout:			1; /**< b21: MasterWatchTimer time-out detection */
			ULONG bAZReserve4:						10;/**< b22-31: Reserved */
		} stBit;
	} uniFlag;
} R_IN32_EVTPRM_INTERRUPT_T;


/* Cyclic communication status */
typedef struct R_IN32_CYCLIC_STA_TAG {
	union {
		USHORT usAll;
		struct {
			USHORT b3ZComonParamkeepCond:		3; /**< b2-0: Cyclic communication parameter status */
			USHORT b1ZParamCheckCond:			1; /**< b3: Cyclic communication parameter check status */
			USHORT b1ZMyNodeNoRangeOut:			1; /**< b4: Station No. validity */
			USHORT b1ZMyNodeReserveSetup:		1; /**< b5: Reserved node setting */
			USHORT b1ZCyclicOpeInstructPackage:	1; /**< b6: Cyclic operation setting (group) */
			USHORT b1ZCyclicOpeInstructVarious:	1; /**< b7: Cyclic operation setting (individual) */
			USHORT b1ZReserved1:				1; /**< b8: Reserved */
			USHORT b1ZMyMpuAbnomal:				1; /**< b9: Cyclic communication continuation error */
			USHORT b1ZMyNodeNumberDuplicate:	1; /**< b10: Station No. duplication */
			USHORT b1ZReserved2:				1; /**< b11: Reserved */
			USHORT b1ZNodeTypeWrong:			1; /**< b12: Node type error, assigned size invalid */
			USHORT b1ZReserved3:				1; /**< b13: Reserved */
			USHORT b1ZDLinkState:				1; /**< b14: Disconnection detection status */
			USHORT b1ZCyclicState:				1; /**< b15: Other communication stop */
		} stBit;
	} uniCycSta;
} R_IN32_CYCLIC_STA_T;


/* MIB(Count) */
typedef struct R_IN32_MIBSDRD_TAG {
	ULONG			ulCyclicRecNomalFrameCnt;	
	ULONG			ulNonCyclicRecValidCnt;		
	ULONG			ulNonCyclicRecRejectCnt;	
} R_IN32_MIBSDRD_T;

/* MIB(RING) */
typedef struct R_IN32_MIBRGCNT_TAG {
	ULONG			ulHecErr;					
	ULONG			ulDcsFcsErr;				
	ULONG			ulUnderErr;					
	ULONG			ulRpt;						
	ULONG			ulUp;						
	ULONG			ulRptFullDrop;				
	ULONG			ulUpFullDrop;				
} R_IN32_MIBRGCNT_T;

/* MIB(MACIP) */
typedef struct R_IN32_MIBMACIP_TAG {
	ULONG			ulRFrm;						
	ULONG			ulTFrm;						
	ULONG			ulRUnd;						
	ULONG			ulROvr;						
	ULONG			ulRFcs;						
	ULONG			ulRFgm;						
	ULONG			ulRIFGErr;					
	ULONG			ulREps;						
	ULONG			ulRCde;						
	ULONG			ulRFce;						
	ULONG			ulRCEE;						
} R_IN32_MIBMACIP_T;

/* MIB */
typedef struct R_IN32_MIB_TAG {
	R_IN32_MIBSDRD_T	stSDRD;					
	R_IN32_MIBMACIP_T	stMACIP1;				
	R_IN32_MIBMACIP_T	stMACIP2;				
	R_IN32_MIBRGCNT_T	stRING1;				
	R_IN32_MIBRGCNT_T	stRING2;				
	ULONG	ulP1DownCounter;				
	ULONG	ulP2DownCounter;				
	ULONG	ulMasterWatchCount;				
} R_IN32_MIB_T;

/* Cyclic communication size */
typedef struct R_IN32_CYCLIC_SIZE_TAG {
	ULONG	ulRySize;							
	ULONG	ulRWwSize;							
	ULONG	ulRxSize;							
	ULONG	ulRWrSize;							
} R_IN32_CYCLIC_SIZE_T;

typedef struct R_IN32_PHY_SETTING_TAG {
	ULONG	ulMDI;							/**< MDI */
	ULONG	ulClk;							/**< Clock */
} R_IN32_PHY_SETTING_T;

/* initialization structure */
typedef struct R_IN32_UNITINFO_TAG {
	/* Maximum data size for cyclic communication */
	ULONG ulMaxRySize;									/**< RY size  (in octet unit) */
	ULONG ulMaxRWwSize;									/**< RWw size (in word unit)  */
	ULONG ulMaxRxSize;									/**< RX size  (in octet unit) */
	ULONG ulMaxRWrSize;									/**< RWr size (in word unit)  */
	/* Node information 1 */
	ULONG ulMyStationPortTotalNumber;					/**< Number of own station ports */
	ULONG ulTokenHoldTime;								/**< Token hold time */
	/* Node information 2 */
	ULONG ulIOType;										/**< Node info (I/O type) */
	/* Network card information */
	ULONG ulNetVersion;									/**< Network F/W version */
	ULONG ulNetModelType;								/**< Network model type */
	ULONG ulNetUnitModelCode;							/**< Network unit model code */
	ULONG ulNetVendorCode;								/**< Network vendor code */
	UCHAR auchNetUnitModelName[R_IN32_MODEL_NAME_LENGTH];	/**< Network unit model name */
	UCHAR auchNetVendorName[R_IN32_VENDOR_NAME_LENGTH];	/**< Network vendor name */
	USHORT usHwVersion;									/**< Network H/W version */
	USHORT usDeviceVersion;								/**< Network Device Version */
	/* Controller information */
	BOOL  blInformationFlag;							/**< Controller information status flag */
	ULONG ulCtrlVersion;								/**< Controller F/W version */
	ULONG ulCtrlModelType;								/**< Controller model type */
	ULONG ulCtrlUnitModelCode;							/**< Controller unit model code */
	ULONG ulCtrlVendorCode;								/**< Controller vendor code */
	UCHAR auchCtrlUnitModelName[R_IN32_MODEL_NAME_LENGTH];	/**< Controller unit model name */
	UCHAR auchCtrlVendorName[R_IN32_VENDOR_NAME_LENGTH];	/**< Controller vendor name */
	ULONG ulVendorInformation;							/**< Controller vendor device specific information */
} R_IN32_UNITINFO_T;

/* Initialization */
typedef struct R_IN32_UNITINIT_TAG {
	BOOL	blNMIUse;					/**< NMI interrupt use */
	BOOL	blInterruptUse;				/**< CPU Interrupt function use */
	BOOL	blFailedProcess1;			/**< Failed process setting 1 */
	BOOL	blFailedProcess2;			/**< Failed process setting 2 */
	ULONG	ulNodeType;					/**< Node type */
	BOOL	blTransientReceiveEnable;	/**< Transient reception function */
	BOOL	blMACAddressTableRequest;	/**< Request node information distribution */
	ULONG	ulRunStatus;				/**< Initial value of Detailed application operation status */
	ULONG	ulErrorStatus;				/**< Initial value of Detailed application error status */
	ULONG	ulUserInformation;			/**< Initial value for vendor specific information */
	ULONG	ulOptionSupport;			/**< Option Support Defaults */
	ULONG	ulSlmpSupport;				/**< Slmp Support Defaults */
	ULONG	ulSlmpDiagnosisSupport;		/**< CCIEF Diagnosis Support Defaults */
	R_IN32_PHY_SETTING_T	stPHYSetting[2];/**< Initial value of PHY setting */
} R_IN32_UNITINIT_T;

/* Network setting */
typedef struct R_IN32_UNITNETWORKSETTING_TAG {
	ULONG ulFrameSendCount;				/**< Setting for number of sending when holding token */
	ULONG ulFrameSendInterval;			/**< Frame sending interval setting */
	ULONG ulTokenSendCount;				/**< Setting for number of token sending */
} R_IN32_UNITNETWORKSETTING_T;

/* Time information */
typedef struct R_IN32_TIMEINFO_TAG {
	USHORT usYear;		/**< year AD (2000 - 2136) */
	USHORT usMonth;		/**< month (1 - 12) */
	USHORT usDay;		/**< day (1 - 31) */
	USHORT usHour;		/**< hour (0 - 23) */
	USHORT usMin;		/**< minute (0 - 59) */
	USHORT usSec;		/**< second (0 - 59) */
	USHORT usMsec;		/**< msec (0 - 999)*/
	USHORT usWday;		/**< weekday (0 (Sunday) - 6 (Saturday)) */
} R_IN32_TIMEINFO_T;

/* MAC address table distribution data */
typedef struct _R_IN32_MACADDRESSDATA_TAG {
	USHORT	usNodeNumber;					/**< Station No. (0-120, 0x7D for master) */
	UCHAR	uchTransientReceiveEnable;		/**< Transient reception function (R_IN32_ENABLE/R_IN32_DISABLE) */
	UCHAR	auchMacAddress[6];				/**< MAC address */
} R_IN32_MACADDRESSDATA_T;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern ULONG   gulR_IN32_GetResetStatus( VOID );
extern ERRCODE gerR_IN32_Initialize( const UCHAR*, const R_IN32_UNITINFO_T*, const R_IN32_UNITINIT_T* );
extern ERRCODE gerR_IN32_SetNodeAndNetworkNumber( UCHAR, USHORT );
extern ERRCODE gerR_IN32_Start( VOID );
extern ERRCODE gerR_IN32_ResetWDT( VOID );
extern ERRCODE gerR_IN32_DisableWDT( VOID );
extern ERRCODE gerR_IN32_EnableWDT( VOID );
extern ERRCODE gerR_IN32_SetWDT( USHORT );
extern ERRCODE gerR_IN32_GetEvent( R_IN32_EVTPRM_INTERRUPT_T* );
extern ERRCODE gerR_IN32_Main( const R_IN32_EVTPRM_INTERRUPT_T* );
extern ERRCODE gerR_IN32_RestartEvent( VOID );
extern ERRCODE gerR_IN32_UpdateMIB( VOID );
extern ERRCODE gerR_IN32_SetCyclicStop( VOID );
extern ERRCODE gerR_IN32_ClearCyclicStop( VOID );
extern ERRCODE gerR_IN32_GetReceivedCyclicData( VOID*, VOID*, BOOL );
extern ERRCODE gerR_IN32_GetMasterNodeStatus( BOOL*, BOOL*, ULONG* );
extern ERRCODE gerR_IN32_SetMyStatus( VOID );
extern ERRCODE gerR_IN32_SetSendCyclicData(const VOID*, const VOID*, BOOL );
extern ERRCODE gerR_IN32_SetNodeStatus( ULONG, ULONG, ULONG );
extern ERRCODE gerR_IN32_ForceStop( VOID );
extern ERRCODE gerR_IN32_GetNodeAndNetworkNumber( USHORT*, UCHAR* );
extern ERRCODE gerR_IN32_GetCurrentCyclicSize( R_IN32_CYCLIC_SIZE_T* );
extern ERRCODE gerR_IN32_GetCommumicationStatus( ULONG* );
extern ERRCODE gerR_IN32_GetPortStatus( ULONG, ULONG*, ULONG*, ULONG* );
extern ERRCODE gerR_IN32_GetCyclicStatus( R_IN32_CYCLIC_STA_T* );
extern ERRCODE gerR_IN32_GetMIB( R_IN32_MIB_T* );
extern ERRCODE gerR_IN32_ClearMIB( VOID );
extern ERRCODE gerR_IN32_SetERRLED( ULONG );
extern ERRCODE gerR_IN32_SetUSER1LED( ULONG );
extern ERRCODE gerR_IN32_SetUSER2LED( ULONG );
extern ERRCODE gerR_IN32_SetRUNLED( ULONG );
extern ERRCODE gerR_IN32_DisableLED( USHORT );
extern ERRCODE gerR_IN32_EnableLED( USHORT );
extern ERRCODE gerR_IN32_UpdateLedStatus( VOID );
extern ERRCODE gerR_IN32_GetNetworkTime( USHORT* );
extern ERRCODE gerR_IN32_SetNetworkTime( const USHORT* );
extern ERRCODE gerR_IN32_NetworkTimeToDate( R_IN32_TIMEINFO_T*, const USHORT* );
extern ERRCODE gerR_IN32_DateToNetworkTime( const R_IN32_TIMEINFO_T*, USHORT* );
extern ERRCODE gerR_IN32_EnableMACIPAccess( VOID );
extern ERRCODE gerR_IN32_DisableMACIPAccess( VOID );
extern ERRCODE gerR_IN32_WritePHY( ULONG, ULONG, ULONG );
extern ERRCODE gerR_IN32_ReadPHY( ULONG, ULONG, ULONG* );
extern ERRCODE gerR_IN32_InitPHY( VOID );
extern ERRCODE gerR_IN32_CheckPHY( VOID );
extern ERRCODE gerR_IN32_MainReceiveTransient1( VOID );
extern ERRCODE gerR_IN32_MainReceiveTransient2( VOID );
extern ERRCODE gerR_IN32_EnableReceiveTransient( BOOL );
extern BOOL    gblR_IN32_GetReceiveTransientStatus( VOID );
extern ERRCODE gerR_IN32_SetEtherCcieHeader ( const UCHAR*, const UCHAR*, UCHAR, UCHAR, R_IN32_NONCICLIC_FRAME_T* );
extern ERRCODE gerR_IN32_SetTransient1Header ( USHORT, USHORT, R_IN32_TRAN1_HEAD_T* );
extern ERRCODE gerR_IN32_SetRequestSlmpHeader ( R_IN32_SLMP_REQUSET_SETTING_T*, R_IN32_SLMP_REQUEST_FRAME_T*, ULONG*, USHORT* );
extern ERRCODE gerR_IN32_SetResponseSlmpHeader ( const R_IN32_SLMP_REQUEST_FRAME_T*, USHORT, R_IN32_SLMP_RESPONSE_FRAME_T* );
extern UCHAR   guchR_IN32_GetTransient1IdentificationNumber(VOID);
extern ERRCODE gerR_IN32_ReceivedMACAddressData( const VOID* , ULONG  );
extern ERRCODE gerR_IN32_ReceivedStatisticInfoRequest( VOID* , ULONG* , const VOID* , const UCHAR*  );
extern ERRCODE gerR_IN32_ReceivedUnitInfoRequest( VOID* , ULONG* , const VOID* , const UCHAR*  );
extern ERRCODE gerR_IN32_ReceivedOptionInfoRequest( VOID* , ULONG* , const VOID* , const UCHAR* , const USHORT  );
extern ERRCODE gerR_IN32_ReceivedSelectInfoRequest( VOID* , ULONG* , const VOID*  , const UCHAR* , const VOID*  );
extern ERRCODE gerR_IN32_ReceivedContactTestRequest( VOID* , ULONG* , const VOID* , const UCHAR*  );
extern ERRCODE gerR_IN32_ReceivedCableTestRequest( VOID* , ULONG* , const VOID* , const UCHAR*  );
extern ERRCODE gerR_IN32_ReceivedMemReadRequest( VOID* , ULONG* , const VOID* , const UCHAR* , const VOID*  );
extern ERRCODE gerR_IN32_ReceivedMemWriteRequest( VOID* , ULONG* , const VOID* , const UCHAR* , const VOID*  );
ERRCODE gerR_IN32_ReceiveRemoteResetRequest ( VOID*, ULONG*, const VOID*, const UCHAR* );
extern VOID    gR_IN32_SetSlmpError_Response( VOID* , ULONG* , const VOID* , const UCHAR* , USHORT  );
extern ERRCODE gerR_IN32_ErrCheckReqFieldNetworkReceived(const VOID* );
extern USHORT  gusR_IN32_ErrCheckReqSlmpReceived(const VOID* );
extern ERRCODE gerR_IN32_SetMACAddressTableData( UCHAR, R_IN32_MACADDRESSDATA_T* );
extern ERRCODE gerR_IN32_GetUnitInformation( R_IN32_UNITINFO_T*, R_IN32_UNITNETWORKSETTING_T* );
extern USHORT  gusR_IN32_GetNodeID( VOID );
extern ERRCODE gerR_IN32_GetMulticastMACAddress( UCHAR* );
extern ERRCODE gerR_IN32_GetUnicastMACAddress( USHORT, UCHAR* );
extern ERRCODE gerR_IN32_GetSendTransientBuffer( USHORT, VOID**, UCHAR*, UCHAR*  );
extern ERRCODE gerR_IN32_RequestSendingTransient( UCHAR, USHORT );
extern ERRCODE gerR_IN32_MainSendTransient( VOID );
extern ERRCODE gerR_IN32_EnableInterrupt( VOID );
extern ERRCODE gerR_IN32_DisableInterrupt( VOID );
extern ERRCODE gerR_IN32_IEEETest( USHORT );
extern ERRCODE gerR_IN32_InitializeLoopBackTest( VOID );
extern ERRCODE gerR_IN32_InternalLoopBackTest( ULONG );
extern ERRCODE gerR_IN32_ExternalLoopBackTest( ULONG );

extern ERRCODE gerR_IN32_MyStaRcvTkn( VOID );        

#endif /* __R_IN32M4FUNCTION_H__ */

/*** EOF ***/
