/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_sample.h                                                  */
/** @brief  R_IN32M4 driver user sample code                                   */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_SAMPLE_H_INCLUDED_
#define __R_IN32M4_SAMPLE_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define USER_OK		0
#define USER_ERR	(-1)

#define USER_FATALERROR_NUM			8UL		/* the capacity of the list of fatal errors */



#define USER_BUFFER_MEMORY_TAIL			((USHORT)0x0BB8)	/* Buffer memory tail */
#define USER_BUFFER_MEMORY_SIZE			((USHORT)0x0BB8)	/* Buffer memory size */
#define USER_DATA_SIZE_IN_FRAME			((USHORT)0x03C0)	/* The data size in the frame */

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

/* MAC address */
extern UCHAR	gauchUserMACAddress[];

/* User control */
extern BOOL		gblUserR_IN32M4WDT_Enable;

/* Fatal error */
extern ULONG	gulUserFatalErrorNum;						/* the number of fatal errors */
extern ULONG	gulUserFatalError[USER_FATALERROR_NUM][2];	/* list of fatal errors */
															/*  [*][0]: fatal error code */
															/*  [*][1]: fatal error information (address of the function when the error occurred) */


extern UCHAR	gauchBufferMemory[USER_BUFFER_MEMORY_SIZE];	/* Buffer memory */

extern USHORT	gusUserNodeNumber;							/* Station No. */
extern UCHAR	guchUserNetworkNumber;						/* Network number */
extern ULONG	gulCommandFromMaster;						/* Command from master */


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern INT  iUserInitialization( VOID );


#endif	/* __R_IN32M4_SAMPLE_H_INCLUDED_ */

/*** EOF ***/
