/**
 *******************************************************************************
 * @file  taud.h
 * @brief 16-bit Timer (TAUD) driver program
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	TAUD_H__
#define	TAUD_H__

/*==========================================================================*/
/* I N C L U D E															*/
/*==========================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*==========================================================================*/
/* T Y P E D E F															*/
/*==========================================================================*/

/*==========================================================================*/
/* D E F I N E																*/
/*==========================================================================*/

/*==========================================================================*/
/* P R O T O T Y P E                                                        */
/*==========================================================================*/
ER_RET taud_interval_init( uint8_t ch,uint16_t i_time );
ER_RET taud_onecount_hwtrg_init( uint8_t ch, uint16_t o_time, uint32_t trg );
ER_RET taud_start( uint8_t ch );
ER_RET taud_stop( uint8_t ch );
ER_RET taud_check_act(uint8_t ch);

#endif // TIMER_H__
