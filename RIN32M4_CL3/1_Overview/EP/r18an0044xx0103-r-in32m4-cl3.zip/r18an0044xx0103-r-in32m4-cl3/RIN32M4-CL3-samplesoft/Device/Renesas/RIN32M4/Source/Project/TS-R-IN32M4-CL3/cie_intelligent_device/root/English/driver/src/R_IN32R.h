/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32R.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32R_H_INCLUDED_
#define __R_IN32R_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define	R_IN32R_IEEE_MODE1			(USHORT)0x0001		
#define	R_IN32R_IEEE_MODE2			(USHORT)0x0002		
#define	R_IN32R_IEEE_MODE3			(USHORT)0x0003		
#define	R_IN32R_IEEE_MODE4			(USHORT)0x0004		
#define	R_IN32R_IEEE_END			(USHORT)0x0005		


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32R_STOPWATCH_TAG {
	ULONG	ulUnit;							
	ULONG	ulFirstTmr1Cnt;					
	ULONG	ulLastTmr1Cnt;					
} R_IN32R_STOPWATCH_T;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID    gR_IN32R_WaitUS(ULONG);
extern VOID    gR_IN32R_DisableInt(VOID);
extern VOID    gR_IN32R_EnableInt(VOID);
extern VOID    gR_IN32R_ExDisableInt(VOID);
extern VOID    gR_IN32R_ExEnableInt(VOID);
extern VOID    gR_IN32R_StartStopwatchTimer(R_IN32R_STOPWATCH_T *, ULONG);
extern VOID    gR_IN32R_GetElapsedTime(R_IN32R_STOPWATCH_T *, ULONG *);
extern ERRCODE gerR_IN32R_IEEETest(USHORT);
VOID gR_IN32R_StartIntervalTimer(	ULONG, ULONG);
VOID gR_IN32R_StopIntervalTimer( ULONG );
BOOL gR_IN32R_IsIntervalTimerTimeout( ULONG );
VOID gR_IN32R_UnlockSystemProtect(VOID);
VOID gR_IN32R_LockSystemProtect(VOID);
VOID gR_IN32R_WaitMS(INT iTmout);

#endif /* __R_IN32R_H_INCLUDED_ */

/*** EOF ***/
