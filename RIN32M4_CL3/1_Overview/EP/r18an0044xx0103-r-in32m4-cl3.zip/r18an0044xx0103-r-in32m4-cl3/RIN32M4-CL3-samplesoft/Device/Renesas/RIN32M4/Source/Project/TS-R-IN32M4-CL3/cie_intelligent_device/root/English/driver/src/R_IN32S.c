/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32S.c                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Callback.h"
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static VOID  R_IN32S_Memcpy_DW_B(VOID *, const VOID *, ULONG);
static VOID  R_IN32S_Memcpy_B(VOID *, const VOID *, ULONG);
static VOID  R_IN32S_Memset_DW_B(VOID *, UCHAR, ULONG);
static VOID  R_IN32S_Memset_B(VOID *, UCHAR, ULONG);
static ULONG ulR_IN32S_Memcmp_DW_B(const VOID *, const VOID *, ULONG);
static ULONG ulR_IN32S_Memcmp_B(const VOID *, const VOID *, ULONG);


VOID gR_IN32S_SysErrRet(ULONG ulErrorCode, VOID *pErrorInfo)
{

	gR_IN32_CallbackFatalError(ulErrorCode, (ULONG)pErrorInfo);

	return;
}

VOID gR_IN32S_Memcpy(VOID* pDst, const VOID* pSrc, ULONG ulSize)
{
	if ((((ULONG)pDst & 3) == ((ULONG)pSrc & 3)) && (ulSize >= 4)) {
		R_IN32S_Memcpy_DW_B(pDst,pSrc,ulSize);
	}
	else {
		R_IN32S_Memcpy_B(pDst,pSrc,ulSize);
	}

	return;
}

VOID gR_IN32S_Memset(VOID* pDst, UCHAR uchData, ULONG ulSize)
{
	if ( ulSize >= 4) {
		R_IN32S_Memset_DW_B(pDst,uchData,ulSize);
	}
	else {
		R_IN32S_Memset_B(pDst,uchData,ulSize);
	}

	return;
}

ULONG gulR_IN32S_Memcmp(const VOID* pDst, const VOID* pSrc, ULONG ulSize)
{

	ULONG ulRet;

	if ((((ULONG)pDst & 3) == ((ULONG)pSrc & 3)) && (ulSize >= 4)) {
		ulRet = ulR_IN32S_Memcmp_DW_B(pDst,pSrc,ulSize);
	}
	else {
		ulRet = ulR_IN32S_Memcmp_B(pDst,pSrc,ulSize);
	}

	return(ulRet);
}

USHORT gusR_IN32S_SwapS(USHORT usVal)
{
	USHORT	usRet;									
	
	usRet = (USHORT)( ((usVal >> 8) & 0x00ff)
					| ((usVal << 8) & 0xff00) );
	
	return(usRet);
}

ULONG gulR_IN32S_SwapL(ULONG ulVal)
{
	ULONG	ulRet;									
	
	ulRet = (ULONG)(  ((ulVal >> 24) & 0x000000ff)
					| ((ulVal >>  8) & 0x0000ff00)
					| ((ulVal <<  8) & 0x00ff0000)
					| ((ulVal << 24) & 0xff000000) );
	
	return(ulRet);
}

VOID gR_IN32S_NotifyRecvSetStNo( UCHAR uchNetNo, USHORT usStNo )
{

	return;
}

VOID gR_IN32S_NotifyRecvOpeCmd( ULONG ulOperationCmd )
{
	(VOID)gerR_IN32_CallbackCommandFromMaster(ulOperationCmd);

	return;
}

VOID gR_IN32S_SendFin(UCHAR uchTDISNo, ERRCODE erSendStatus)
{
	gerR_IN32_CallbackTransientSendingComplete(uchTDISNo, erSendStatus);

	return;
}

VOID R_IN32S_Memcpy_DW_B(VOID* pDst, const VOID* pSrc, ULONG ulSize)
{

	ULONG			ulCnt;		
	ULONG			ulOdd;		
	ULONG			ulOdd2;		
	const ULONG*	pulSrc;		
	ULONG*			pulDst;		
	const UCHAR*	puchSrc;	
	UCHAR*			puchDst;	


	ulCnt = ulSize;
	ulOdd = (ULONG)pDst & 3;
	ulOdd = (~ulOdd + 1) & 3;	
	ulCnt -= ulOdd;				
	ulOdd2 = ulCnt & 3;			
	ulCnt >>= 2;				

	puchSrc = pSrc;
	puchDst = pDst;
	for (; ulOdd != 0; ulOdd--) {
		*puchDst = *puchSrc;
		puchDst++;
		puchSrc++;
	}

	pulSrc = (const ULONG *)puchSrc;
	pulDst = (ULONG *)puchDst;
	for (; ulCnt != 0; ulCnt--) {
		*pulDst = *pulSrc;
		pulDst++;
		pulSrc++;
	}

	puchSrc = (const UCHAR *)pulSrc;
	puchDst = (UCHAR *)pulDst;
	for (; ulOdd2 != 0; ulOdd2--) {
		*puchDst = *puchSrc;
		puchDst++;
		puchSrc++;
	}

	return;
}

VOID R_IN32S_Memcpy_B(VOID* pDst, const VOID* pSrc, ULONG ulSize)
{

	ULONG			ulCnt;		
	const UCHAR*	puchSrc;	
	UCHAR*			puchDst;	

	ulCnt = ulSize;
	puchSrc = (const UCHAR *)pSrc;
	puchDst = (UCHAR *)pDst;

	for (; ulCnt != 0; ulCnt--) {
		*puchDst = *puchSrc;
		puchDst++;
		puchSrc++;
	}

	return;
}

VOID R_IN32S_Memset_DW_B(VOID* pDst, UCHAR uchData, ULONG ulSize)
{

	ULONG	ulCnt;		
	ULONG	ulOdd;		
	ULONG	ulOdd2;		
	ULONG*	pulDst;		
	UCHAR*	puchDst;	
	ULONG   ulData;


	ulCnt = ulSize;
	ulOdd = (ULONG)pDst & 3;
	ulOdd = (~ulOdd + 1) & 3;	
	ulCnt -= ulOdd;				
	ulOdd2 = ulCnt & 3;			
	ulCnt >>= 2;				
	ulData = ((ULONG)uchData<<24) | ((ULONG)uchData<<16) | ((ULONG)uchData<<8) | ((ULONG)uchData);

	puchDst = pDst;
	for (; ulOdd != 0; ulOdd--) {
		*puchDst = uchData;
		puchDst++;
	}

	pulDst = (ULONG *)puchDst;
	for (; ulCnt != 0; ulCnt--) {
		*pulDst = ulData;
		pulDst++;
	}

	puchDst = (UCHAR *)pulDst;
	for (; ulOdd2 != 0; ulOdd2--) {
		*puchDst = uchData;
		puchDst++;
	}

	return;
}

VOID R_IN32S_Memset_B(VOID* pDst, UCHAR uchData, ULONG ulSize)
{

	ULONG	ulCnt;		
	UCHAR*	puchDst;	

	ulCnt = ulSize;
	puchDst = (UCHAR *)pDst;

	for (; ulCnt != 0; ulCnt--) {
		*puchDst = uchData;
		puchDst++;
	}

	return;
}

ULONG ulR_IN32S_Memcmp_DW_B(const VOID* pDst, const VOID* pSrc, ULONG ulSize)
{

	ULONG			ulCnt;		
	ULONG			ulOdd;		
	ULONG			ulOdd2;		
	const ULONG*	pulSrc;		
	const ULONG*	pulDst;		
	const UCHAR*	puchSrc;	
	const UCHAR*	puchDst;	
	ULONG			ulPoint;	


	ulCnt = ulSize;
	ulOdd = (ULONG)pDst & 3;
	ulOdd = (~ulOdd + 1) & 3;	
	ulCnt -= ulOdd;				
	ulOdd2 = ulCnt & 3;			
	ulCnt >>= 2;				
	ulPoint = 0UL;

	puchSrc = pSrc;
	puchDst = pDst;
	for (; ulOdd != 0; ulOdd--) {
		if(*puchDst != *puchSrc){
			return (ulPoint + sizeof(UCHAR));
		}
		puchDst++;
		puchSrc++;
		ulPoint += sizeof(UCHAR);
	}

	pulSrc = (const ULONG *)puchSrc;
	pulDst = (const ULONG *)puchDst;
	for (; ulCnt != 0; ulCnt--) {
		if(*pulDst != *pulSrc){
			return (ulPoint + sizeof(ULONG));
		}
		pulDst++;
		pulSrc++;
		ulPoint += sizeof(ULONG);
	}

	puchSrc = (const UCHAR *)pulSrc;
	puchDst = (const UCHAR *)pulDst;
	for (; ulOdd2 != 0; ulOdd2--) {
		if(*puchDst != *puchSrc){
			return (ulPoint + sizeof(UCHAR));
		}
		puchDst++;
		puchSrc++;
		ulPoint += sizeof(UCHAR);
	}

	return(R_IN32_OK);
}

ULONG ulR_IN32S_Memcmp_B(const VOID* pDst, const VOID* pSrc, ULONG ulSize)
{

	ULONG			ulCnt;		
	const UCHAR*	puchSrc;	
	const UCHAR*	puchDst;	
	ULONG			ulPoint;

	ulCnt = ulSize;
	puchSrc = (const UCHAR *)pSrc;
	puchDst = (const UCHAR *)pDst;
	ulPoint	= 0;

	for (; ulCnt != 0; ulCnt--) {
		if(*puchDst != *puchSrc){
			return (ulPoint + sizeof(UCHAR));
		}
		puchDst++;
		puchSrc++;
		ulPoint += sizeof(UCHAR);
	}

	return(R_IN32_OK);
}

/*** EOF ***/
