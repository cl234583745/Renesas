/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_ASIC.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_ASIC.h"
#include "R_IN32T_RING.h"
#include "R_IN32T_MACIP.h"
#include "R_IN32T_Com.h"
#include "R_IN32T_Data.h"


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static VOID    R_IN32T_TxMacAdrsSet( const UCHAR* );
static VOID    R_IN32T_RxSwitchReset( VOID );
static VOID    R_IN32T_RxInfoClear( VOID );
static VOID    R_IN32T_ASIC_IntClear( VOID );
static VOID    R_IN32T_CntRxInvalid( VOID );


ERRCODE gerR_IN32T_CommunicationInit( VOID )
{
	ERRCODE		erRet;		
	ERRCODE		erResult;	


	erResult = R_IN32_OK;

	gerR_IN32D_SetMyMACAddr( &gauchR_IN32T_RingMACAdrs[0] );

	R_IN32T_TxMacAdrsSet( &gauchR_IN32T_TxMACAdrs[0] );

	R_IN32T_RING_Start();

	erRet = gerR_IN32D_MacIp_AccessEnable();
	if ( R_IN32D_NG == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	erRet = erR_IN32T_MACIP_LoopBackDisable( R_IN32T_E_PORT1 );
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}
	erRet = erR_IN32T_MACIP_LoopBackDisable( R_IN32T_E_PORT2 );
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	R_IN32T_MACIP_MIBClear();

	(VOID)gerR_IN32D_MacIp_AccessDisable();


	R_IN32T_RING_ModeReset();

	R_IN32T_RING_IntClear();

	(VOID)gerR_IN32D_ClearRingMIB();

	erRet = gerR_IN32T_RAMClear();
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	R_IN32T_RxSwitchReset();

	R_IN32T_RxInfoClear();

	R_IN32T_ASIC_IntClear();

	return( erResult );
}

VOID R_IN32T_TxMacAdrsSet(
	const UCHAR*	puchMacAdrs			
)
{
	USHORT			usWriteData;		


	usWriteData = (USHORT)puchMacAdrs[0] | ( (USHORT)puchMacAdrs[1] << 8 );

	OUT32(&(TX->MAC_A1), (ULONG)usWriteData);

	usWriteData = (USHORT)puchMacAdrs[2] | ( (USHORT)puchMacAdrs[3] << 8 );

	OUT32(&(TX->MAC_A2), (ULONG)usWriteData);

	usWriteData = (USHORT)puchMacAdrs[4] | ( (USHORT)puchMacAdrs[5] << 8 );

	OUT32(&(TX->MAC_A3), (ULONG)usWriteData);

	return;
}

ERRCODE gerR_IN32T_RAMClear( VOID )
{
	ERRCODE				erResult;		

	
	erResult = R_IN32_OK;
	
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicRcvRAMRY_A), 0x00, sizeof(CYCMAP->auchCyclicRcvRAMRY_A));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicRcvRAMRY_B), 0x00, sizeof(CYCMAP->auchCyclicRcvRAMRY_B));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicRcvRAMRWw_A), 0x00, sizeof(CYCMAP->auchCyclicRcvRAMRWw_A));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicRcvRAMRWw_B), 0x00, sizeof(CYCMAP->auchCyclicRcvRAMRWw_B));		
	gR_IN32S_Memset((void *)&(TRNMAP->auchTransientRcvRAM), 0x00, sizeof(TRNMAP->auchTransientRcvRAM));			
	gR_IN32S_Memset((void *)&(CTLMAP->auchControlFrmRcvRAM_A), 0x00, sizeof(CTLMAP->auchControlFrmRcvRAM_A));	
	gR_IN32S_Memset((void *)&(CTLMAP->auchControlFrmRcvRAM_B), 0x00, sizeof(CTLMAP->auchControlFrmRcvRAM_B));	

	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicSndRAMRX_A), 0x00, sizeof(CYCMAP->auchCyclicSndRAMRX_A));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicSndRAMRX_B), 0x00, sizeof(CYCMAP->auchCyclicSndRAMRX_B));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicSndRAMRWr_A), 0x00, sizeof(CYCMAP->auchCyclicSndRAMRWr_A));		
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicSndRAMRWr_B), 0x00, sizeof(CYCMAP->auchCyclicSndRAMRWr_A));		
	gR_IN32S_Memset((void *)&(TRNMAP->auchTransientSndRAM1520), 0x00, sizeof(TRNMAP->auchTransientSndRAM1520));	
	gR_IN32S_Memset((void *)&(TRNMAP->auchTransientSndRAM1152), 0x00, sizeof(TRNMAP->auchTransientSndRAM1152));	
	gR_IN32S_Memset((void *)&(CYCMAP->auchCyclicSndHeader) , 0x00, sizeof(CYCMAP->auchCyclicSndHeader));		

	gR_IN32S_Memset((void *)&(TD->aTD_TDS), 0x00, sizeof(TD->aTD_TDS));			
	gR_IN32S_Memset((void *)&(RD->astRD_NCYC), 0x00, sizeof(RD->astRD_NCYC));	
	gR_IN32S_Memset((void *)&(RD->stRD_CNTL), 0x00, sizeof(RD->stRD_CNTL));		

	return( erResult );
}

VOID R_IN32T_RxSwitchReset( VOID )
{

	(VOID)gerR_IN32D_RcvDisable();

	R_IN32T_CntRxInvalid();

	return;
}

VOID R_IN32T_RxInfoClear( VOID )
{
	volatile USHORT			usReadClr;			


	usReadClr = (USHORT)RX->ulNonCyclicRecValidCnt;

	usReadClr = (USHORT)RX->ulNonCyclicRecRejectCnt;

	RX->NSRINT.DATA = NSRINT_INTCLR;

	return;
}

VOID R_IN32T_ASIC_IntClear( VOID )
{
	INTRST->INT1.usDATA = INT1_INTCLR;

	return;
}

ERRCODE erR_IN32T_TxStart( VOID )
{
	ULONG			ulBitPtn;			
	ULONG*			pulAdr;				
	ERRCODE			erResult;			
	R_TXSTART_TAG	stTXSTART;


	gR_IN32S_Memset((void*)&stTXSTART, 0x00, sizeof(stTXSTART));

	OUT32(&stTXSTART, IN32(&(TX->R_TXSTART)));
	stTXSTART.b01ZSendStart = MACTXST_SENDSTART;
	OUT32(&(TX->R_TXSTART),*(ULONG*)&stTXSTART);

	pulAdr = (ULONG*)&TX->R_TXSTART;

	ulBitPtn = MACTXST_SENDSTART;

	erResult = erR_IN32T_Com_WaitBitOff_DWord( pulAdr, ulBitPtn );

	if ( R_IN32_OK == erResult) {

		ulBitPtn = MACTXST_SENDSTATUSABNORMALEND;

		erResult = erR_IN32T_Com_BitCompExpect_DWord( pulAdr, ulBitPtn, (ULONG)0 );
	}
	else {
	}

	return( erResult );
}


VOID R_IN32T_CntRxInvalid( VOID )
{

	RX->ulRCNTENDIS = R_IN32_OFF;

	return;
}

VOID R_IN32T_TDTran_FrmExistTypeSet(
	USHORT					usTranTDis,	
	R_IN32T_FRAME_EXIST_ENUM	eFramExist	
)
{
	return;
}

VOID R_IN32T_TDTran_StatusClear(
	USHORT			usTranTDis			
)
{



	return;
}

VOID R_IN32T_TDTran_TxSize_Set(
	USHORT			usTranTDis,			
	USHORT			usTxSize			
)
{


	return;
}

VOID R_IN32T_TDTran_LastDisSet(
	USHORT			usTranTDis			
)
{


	return;
}

VOID R_IN32T_RDTran_RDisClear(
	ULONG			ulTranRDis		
)
{

	RD->astRD_NCYC[ulTranRDis].RD_RDIS1.uniRdis1.usAll &= ~RDIS1_OWNRDISCRIPTERUSED;

	return;
}

/*** EOF ***/
