-----------------------------------------------------------------------------
R-IN32M4 driver sample code

readme

Copyright (C) 2015 Mitsubishi Electric Corporation 
-----------------------------------------------------------------------------

1. Directory
                                             ���e
root -+- Japanese -+- sample -+- include ... ���[�U�R�[�h�w�b�_�t�@�C��(���{��R�����g)
      |            |          +- src     ... ���[�U�R�[�h�ƃR�[���o�b�N(���{��R�����g)
      |            |
      |            |_ driver -+- include ... R-IN32M4�h���C�o�R�[�h�ƃw�b�_�t�@�C��(���{��R�����g)
      |                       +- src     ... R-IN32M4�h���C�o�R�[�h�t�@�C��(���{��R�����g)
      |
      |_ English  -+- sample -+- include ... ���[�U�R�[�h�w�b�_�t�@�C��(�p��R�����g)
                   |          +- src     ... ���[�U�R�[�h�ƃR�[���o�b�N(�p��R�����g)
                   |
                   |_ driver -+- include ... R-IN32M4�h���C�o�R�[�h�ƃw�b�_�t�@�C��(�p��R�����g)
                              +- src     ... R-IN32M4�h���C�o�R�[�h�t�@�C��(�p��R�����g)

2. File list
root
����version.txt  .............. �o�[�W�������



root -+  readme_j.txt .............. �w���v�t�@�C���i���{��Łj
      |  readme_e.txt .............. �w���v�t�@�C���i�p��Łj
      +- Japanese
      |   |
      |   +- driver
      |   |   |
      |   |   +- include
      |   |   |      R_IN32M4Driver.h
      |   |   |      R_IN32M4Function.h
      |   |   |      R_IN32M4Types.h
      |   |   |      
      |   |   |_  src
      |   |          R_IN32.h
      |   |          R_IN32C.h
      |   |          R_IN32C_Cyclic.c
      |   |          R_IN32C_Data.c
      |   |          R_IN32C_Indication.c
      |   |          R_IN32C_Init.c
      |   |          R_IN32C_l.h
      |   |          R_IN32C_Library.c
      |   |          R_IN32C_MainState.c
      |   |          R_IN32C_PortState.c
      |   |          R_IN32C_R_IN32DInterface.c
      |   |          R_IN32C_Time.c
      |   |          R_IN32D.h
      |   |          R_IN32D_cyc.c
      |   |          R_IN32D_cyc_l.h
      |   |          R_IN32D_ihnd.c
      |   |          R_IN32D_ini.c
      |   |          R_IN32D_intr.c
      |   |          R_IN32D_intr_l.h
      |   |          R_IN32D_led.c
      |   |          R_IN32D_phy.c
      |   |          R_IN32D_phy_l.h
      |   |          R_IN32D_RcvCnt.c
      |   |          R_IN32D_RcvCnt_l.h
      |   |          R_IN32D_RcvPrm.c
      |   |          R_IN32D_RcvPrm_l.h
      |   |          R_IN32D_reg.c
      |   |          R_IN32D_reg_l.h
      |   |          R_IN32D_sub.c
      |   |          R_IN32D_sub_l.h
      |   |          R_IN32D_tran.c
      |   |          R_IN32D_tran_l.h
      |   |          R_IN32M4_0.h
      |   |          R_IN32M4_1.h
      |   |          R_IN32M4_2.h
      |   |          R_IN32M4_3.h
      |   |          R_IN32M4_4.h
      |   |          R_IN32M4_5.h
      |   |          R_IN32M4_6.h
      |   |          R_IN32M4_in.h
      |   |          R_IN32R.c
      |   |          R_IN32R.h
      |   |          R_IN32S.c
      |   |          R_IN32S.h
      |   |          R_IN32T.h
      |   |          R_IN32T_ASIC.c
      |   |          R_IN32T_ASIC.h
      |   |          R_IN32T_Cmu.h
      |   |          R_IN32T_CmuNCycRcv.c
      |   |          R_IN32T_CmuOutLpBak.c
      |   |          R_IN32T_CmuSub.h
      |   |          R_IN32T_CmuSub3.c
      |   |          R_IN32T_Com.c
      |   |          R_IN32T_Com.h
      |   |          R_IN32T_Data.c
      |   |          R_IN32T_Data.h
      |   |          R_IN32T_FrmForm.h
      |   |          R_IN32T_MACIP.c
      |   |          R_IN32T_MACIP.h
      |   |          R_IN32T_RegChk.c
      |   |          R_IN32T_RegChk.h
      |   |          R_IN32T_RING.c
      |   |          R_IN32T_RING.h
      |   |          R_IN32T_TxFrame.c
      |   |          R_IN32T_TxFrame.h
      |   |          R_IN32U.h
      |   |          R_IN32U_Init.c
      |   |          R_IN32_Frame.h
      |   |          R_IN32_Interface.c
      |   |          
      |   |_ sample
      |       |
      |       +- include
      |       |      R_IN32M4Callback.h
      |       |      
      |       |_ src
      |              R_IN32M4_Callback.c
      |              R_IN32M4_HWTest.c
      |              R_IN32M4_HWTest.h
      |              R_IN32M4_sample.c
      |              R_IN32M4_sample.h
      |              R_IN32M4_Transient.c
      |              R_IN32M4_Transient.h
      |
      |_ English
          |
          +- driver
          |   |
          |   +- include
          |   |      R_IN32M4Driver.h
          |   |      R_IN32M4Function.h
          |   |      R_IN32M4Types.h
          |   |      
          |   |_  src
          |          R_IN32.h
          |          R_IN32C.h
          |          R_IN32C_Cyclic.c
          |          R_IN32C_Data.c
          |          R_IN32C_Indication.c
          |          R_IN32C_Init.c
          |          R_IN32C_l.h
          |          R_IN32C_Library.c
          |          R_IN32C_MainState.c
          |          R_IN32C_PortState.c
          |          R_IN32C_R_IN32DInterface.c
          |          R_IN32C_Time.c
          |          R_IN32D.h
          |          R_IN32D_cyc.c
          |          R_IN32D_cyc_l.h
          |          R_IN32D_ihnd.c
          |          R_IN32D_ini.c
          |          R_IN32D_intr.c
          |          R_IN32D_intr_l.h
          |          R_IN32D_led.c
          |          R_IN32D_phy.c
          |          R_IN32D_phy_l.h
          |          R_IN32D_RcvCnt.c
          |          R_IN32D_RcvCnt_l.h
          |          R_IN32D_RcvPrm.c
          |          R_IN32D_RcvPrm_l.h
          |          R_IN32D_reg.c
          |          R_IN32D_reg_l.h
          |          R_IN32D_sub.c
          |          R_IN32D_sub_l.h
          |          R_IN32D_tran.c
          |          R_IN32D_tran_l.h
          |          R_IN32M4_0.h
          |          R_IN32M4_1.h
          |          R_IN32M4_2.h
          |          R_IN32M4_3.h
          |          R_IN32M4_4.h
          |          R_IN32M4_5.h
          |          R_IN32M4_6.h
          |          R_IN32M4_in.h
          |          R_IN32R.c
          |          R_IN32R.h
          |          R_IN32S.c
          |          R_IN32S.h
          |          R_IN32T.h
          |          R_IN32T_ASIC.c
          |          R_IN32T_ASIC.h
          |          R_IN32T_Cmu.h
          |          R_IN32T_CmuNCycRcv.c
          |          R_IN32T_CmuOutLpBak.c
          |          R_IN32T_CmuSub.h
          |          R_IN32T_CmuSub3.c
          |          R_IN32T_Com.c
          |          R_IN32T_Com.h
          |          R_IN32T_Data.c
          |          R_IN32T_Data.h
          |          R_IN32T_FrmForm.h
          |          R_IN32T_MACIP.c
          |          R_IN32T_MACIP.h
          |          R_IN32T_RegChk.c
          |          R_IN32T_RegChk.h
          |          R_IN32T_RING.c
          |          R_IN32T_RING.h
          |          R_IN32T_TxFrame.c
          |          R_IN32T_TxFrame.h
          |          R_IN32U.h
          |          R_IN32U_Init.c
          |          R_IN32_Frame.h
          |          R_IN32_Interface.c
          |          
          |_ sample
              |
              +- include
              |      R_IN32M4Callback.h
              |      
              |_ src
                     R_IN32M4_Callback.c
                     R_IN32M4_HWTest.c
                     R_IN32M4_HWTest.h
                     R_IN32M4_sample.c
                     R_IN32M4_sample.h
                     R_IN32M4_Transient.c
                     R_IN32M4_Transient.h

�ȏ�
