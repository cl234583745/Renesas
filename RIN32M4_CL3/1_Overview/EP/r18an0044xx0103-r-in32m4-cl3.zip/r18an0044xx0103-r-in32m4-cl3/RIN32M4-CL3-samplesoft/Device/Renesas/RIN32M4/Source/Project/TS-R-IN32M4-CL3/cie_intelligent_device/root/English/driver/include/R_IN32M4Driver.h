/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver header                                             */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32M4DRIVER_H__
#define __R_IN32M4DRIVER_H__

#include "R_IN32M4Types.h"
#include "R_IN32M4Function.h"


#endif /* __R_IN32M4DRIVER_H__ */
/*** EOF ***/
