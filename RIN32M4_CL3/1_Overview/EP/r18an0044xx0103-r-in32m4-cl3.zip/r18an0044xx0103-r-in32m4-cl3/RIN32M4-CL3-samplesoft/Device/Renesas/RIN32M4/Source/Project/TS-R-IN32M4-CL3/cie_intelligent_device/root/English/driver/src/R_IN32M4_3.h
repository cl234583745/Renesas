/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_3.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32M4_3_H_INCLUDED_
#define __R_IN32M4_3_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define	BUF_CYCLIC_RXRY						512					
#define	BUF_CYCLIC_RW						2048				
#define	BUF_CYCLIC_HEADER_NUM				16					
#define	BUF_TRANSIENT_RECV					8192				
#define	BUF_TRANSIENT1_SEND					1520				
#define	BUF_TRANSIENT1_SEND_UNSND			16					
#define	BUF_TRANSIENT2_SEND					1152				
#define	BUF_CONTROL1_SIZE					64					
#define	BUF_TRANSIENT1_SEND_NUM				1					
#define	BUF_TRANSIENT2_SEND_NUM				1					


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _CYCLIC_HEAD_TAG {
	ULONG	ulInformation;		
	ULONG	ulOffsetAddress;	
	ULONG	ulReserve2_3;		
} CYCLIC_HEAD_T;

typedef struct _FRAME_COMMONINFO_TAG {
	USHORT	b4ZProtocolClassifcation:		4;			
	USHORT	b4ZProtocolVersion:				4;			
	USHORT	b8ZFrameSubClassifcation:		8;			
} FRAME_COMMONINFO_TAG;

typedef struct _HEAD_INFO_TAG {
	USHORT	usToAddress1;								
	USHORT	usToAddress2;								
	USHORT	usToAddress3;								
	USHORT	usFromAddress1;								
	USHORT	usFromAddress2;								
	USHORT	usFromAddress3;								
	USHORT	usType;										
	UCHAR	uchFrameClassification;						
	UCHAR	uchDataClassification;						
	USHORT	usNodeID;									
	UCHAR	uchConnectionInformation;					
	UCHAR	uchReserve1;								
	USHORT	usMyStationNumber;							
	FRAME_COMMONINFO_TAG		FRAME_INFO;				
	ULONG	ulHEC;										
	ULONG	ulInfomation;								
	ULONG	ulOffsetAddress;							
	ULONG	ulReserve2_3;								
	UCHAR	auchReserve2[16];							
	ULONG	ulDCS;										
	ULONG	ulFCS;										
} CYCLIC_HEAD_TAG;

typedef struct _CYCMAP_TAG {
	UCHAR			auchCyclicRcvRAMRY_A[BUF_CYCLIC_RXRY];			
	UCHAR			uchMEM_RSV01[(0x21000-0x20200)];				
	UCHAR			auchCyclicRcvRAMRY_B[BUF_CYCLIC_RXRY];			
	UCHAR			uchMEM_RSV02[(0x22000-0x21200)];				
	UCHAR			auchCyclicRcvRAMRWw_A[BUF_CYCLIC_RW];				
	UCHAR			uchMEM_RSV03[(0x23000-0x22800)];				
	UCHAR			auchCyclicRcvRAMRWw_B[BUF_CYCLIC_RW];				
	UCHAR			uchMEM_RSV04[(0x28000-0x23800)];				
	UCHAR			auchCyclicSndRAMRX_A[BUF_CYCLIC_RXRY];			
	UCHAR			uchMEM_RSV05[(0x29000-0x28200)];				
	UCHAR			auchCyclicSndRAMRX_B[BUF_CYCLIC_RXRY];			
	UCHAR			uchMEM_RSV06[(0x2A000-0x29200)];				
	UCHAR			auchCyclicSndRAMRWr_A[BUF_CYCLIC_RW];				
	UCHAR			uchMEM_RSV07[(0x2B000-0x2A800)];				
	UCHAR			auchCyclicSndRAMRWr_B[BUF_CYCLIC_RW];			
	UCHAR			uchMEM_RSV08[(0x2C000-0x2B800)];				
	CYCLIC_HEAD_TAG	auchCyclicSndHeader[BUF_CYCLIC_HEADER_NUM];			
} CYCMAP_T;

typedef struct _TRNMAP_TAG {
	UCHAR		auchTransientRcvRAM[BUF_TRANSIENT_RECV];		
	UCHAR		uchMEM_RSV01[(0x2D000-0x26000)];				
	UCHAR		auchTransientSndRAM1520[BUF_TRANSIENT1_SEND];	
	UCHAR		auchTransientSndRAM1152[BUF_TRANSIENT2_SEND];	
} TRNMAP_T;

typedef struct _CTLMAP_TAG {
	UCHAR		auchControlFrmRcvRAM_A[BUF_CONTROL1_SIZE];		
	UCHAR		uchMEM_RSV01[(0x27800-0x27040)];				
	UCHAR		auchControlFrmRcvRAM_B[BUF_CONTROL1_SIZE];		
} CTLMAP_T;


#endif	/* __R_IN32M4_3_H_INCLUDED_ */

/*** EOF ***/
