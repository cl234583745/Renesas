/**
 *******************************************************************************
 * @file  can_status.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************

  @brief  Transmission Request (Set FCNnMmTRQF bit)
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_tx_req(uint8_t ch,uint8_t bufno)
{
	CAN_MSG_TypeDef *CAN_MSG;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0){
		return ER_PARAM;
	}
#endif	/* __CHECK__ */
	/*----------------------------------------------------------------------*/
	/*	Check FCNnMmRDYF bit(When setting the TRQF, RDYF must be 1)			*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MRDYF) == 0) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set Transmission Request(FCNnMmTRQF bit)							*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->H.FCNnMmCTL = SET_CAN_MTRQF;

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Get transmission status
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @return Error condition 
  @retval ER_OK    : Normal end(Buffer empty)
  @retval ER_PARAM : Parameter error
  @retval ER_BUSY  : sending

 *******************************************************************************
 */
ER_RET can_get_txinfo(uint8_t ch,uint8_t bufno)
{
	CAN_MSG_TypeDef *CAN_MSG;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Buffer empty?(Get FCNnMmTRQF bit)									*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MTRQF) == 0) {
		return ER_OK;
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_BUSY;
}

/**
 *******************************************************************************

  @brief  Get reception buffer number
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @return Error condition 
  @retval bit7 = 0 : Normal end
                     bit6  - bit0 : the buffer number discovered first
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : No new data

 *******************************************************************************
 */
ER_RET can_get_rxinfo(uint8_t ch,uint8_t bufno)
{
	uint8_t		dnbmrx_end;
	uint8_t		dnbmrx_cnt;
	uint32_t	dnbmrx_data;
	uint8_t		bufno_offset;
	uint8_t		bufno_cnt;
	uint8_t		chk_cnt;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/
	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Check FCNnDNBMSSDN bit												*/
	/*----------------------------------------------------------------------*/
	dnbmrx_end = ((CAN_MSG_BUF_NUM >> 5) & 0x07);
	
	for (dnbmrx_cnt = ((bufno >> 5) & 0x07) ; dnbmrx_cnt < dnbmrx_end ; dnbmrx_cnt++)
	{
		switch (dnbmrx_cnt)
		{
			case 0:
				dnbmrx_data = RIN_CAN[ch]->GLB.FCNnDNBMRX0;
				bufno_offset = 0;
				break;
			case 1:
				dnbmrx_data = RIN_CAN[ch]->GLB.FCNnDNBMRX1;
				bufno_offset = 32;
				break;
			default:
				dnbmrx_data = 0;
				bufno_offset = 0;
				break;
		}
		if (dnbmrx_data != 0 )
		{
			if (bufno < bufno_offset)
			{
				chk_cnt = 0;
			}
			else
			{
				chk_cnt = (bufno & 0x1F);
			}
			
			for (bufno_cnt = chk_cnt ; bufno_cnt < 0x20 ; bufno_cnt++)
			{
				if (((dnbmrx_data >> bufno_cnt) & 0x00000001))
				{
					return ((ER_RET)(bufno_offset + bufno_cnt));
				}
			}
		}
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_INVAL;
}
