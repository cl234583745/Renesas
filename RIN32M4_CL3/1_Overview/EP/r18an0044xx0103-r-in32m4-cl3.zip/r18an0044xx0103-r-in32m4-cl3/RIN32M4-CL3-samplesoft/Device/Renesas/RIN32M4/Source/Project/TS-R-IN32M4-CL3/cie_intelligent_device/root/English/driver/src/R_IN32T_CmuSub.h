/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_CmuSub.h                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_CSUB_H_INCLUDED__
#define	__R_IN32T_CSUB_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32T.h"

#include "R_IN32T_ASIC.h"
#include "R_IN32T_Com.h"


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32T_NCYC_DATAINFO_TAB {
	R_IN32T_NCYC_TDISNO_ENUM	eTX_DIS;		
	USHORT					usTran1Size;	
	USHORT					usDmy;			
	R_IN32T_DATPTN_ENUM		eDatPtnSet;		
} R_IN32T_NCYC_DATAINFO_T;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/

extern ERRCODE erR_IN32T_Sub_RxNonCyclicCheck( const R_IN32T_NCYC_DATAINFO_T*, R_IN32T_PORT_SEL_ENUM, ULONG );


#endif	/* __R_IN32T_CSUB_H_INCLUDED__ */

/*** EOF ***/
