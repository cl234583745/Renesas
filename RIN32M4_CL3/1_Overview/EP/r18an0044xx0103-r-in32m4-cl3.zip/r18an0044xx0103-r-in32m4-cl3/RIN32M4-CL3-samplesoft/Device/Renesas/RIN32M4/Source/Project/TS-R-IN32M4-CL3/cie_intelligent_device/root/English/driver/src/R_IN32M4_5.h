/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_5.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32M4_5_H_INCLUDED_
#define __R_IN32M4_5_H_INCLUDED_

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define	TDISC_COUNT								512UL				

#define	R_TDISC1_FRM_TYPE_CYC					0UL					
#define	R_TDISC1_FRM_TYPE_TRN_FIELD				1UL					
#define	R_TDISC1_FRM_TYPE_TRN_CONTROLLER		2UL					
#define	R_TDISC1_FRM_TYPE_CTRL					2UL					
#define	R_TDISC1_FRM_TYPE_SAFETY				2UL					
#define	R_TDISC1_FRM_TYPE_MYSTAT_IEF			2UL					
#define	R_TDISC1_FRM_TYPE_SYNC					2UL					
#define	R_TDISC1_FRM_TYPE_TOKEN					2UL					
#define	R_TDISC1_FRM_TYPE_IP					3UL					

#define	R_TDISC1_DUMMY_FRM_COUNT_CYC			0UL					
#define	R_TDISC1_DUMMY_FRM_COUNT_TRN			0UL					
#define	R_TDISC1_DUMMY_FRM_COUNT_CTRL			0UL					
#define	R_TDISC1_DUMMY_FRM_COUNT_MYSTAT_IEF		0UL					
#define	R_TDISC1_DUMMY_FRM_COUNT_SYNC			0UL					
#define	R_TDISC1_DUMMY_FRM_COUNT_TOKEN			0UL					

#define	R_TDISC1_DUMMY_FRM_SIZE_CYC				0UL					
#define	R_TDISC1_DUMMY_FRM_SIZE_TRN				0UL					
#define	R_TDISC1_DUMMY_FRM_SIZE_CTRL			0UL					
#define	R_TDISC1_DUMMY_FRM_SIZE_MYSTAT_IEF		0UL					
#define	R_TDISC1_DUMMY_FRM_SIZE_SYNC			0UL					
#define	R_TDISC1_DUMMY_FRM_SIZE_TOKEN			0UL					

#define	R_TDISC2_SEND_HEADER_SIZE_CYC			40UL				
#define	R_TDISC2_SEND_HEADER_SIZE_TRN1			44UL				

#define	R_TDISC2_SEND_HEADER_SIZE_TRN2			28UL				

#define	R_TDISC2_SEND_HEADER_SIZE_IPTRN			40UL				
#define	R_TDISC2_SEND_HEADER_SIZE_TRNACK		60UL				
#define	R_TDISC2_SEND_HEADER_SIZE_CTRL			60UL				
#define	R_TDISC2_SEND_HEADER_SIZE_MYSTAT_IEF	0UL					
#define	R_TDISC2_SEND_HEADER_SIZE_SYNC			0UL					
#define	R_TDISC2_SEND_HEADER_SIZE_TOKEN			0UL					

#define	R_TDISC2_SEND_HEADER_SIZE_HEADER		60UL				


#define	R_TDISC2_SEND_SIZE_CYC					44UL				
#define	R_TDISC2_SEND_SIZE_TRNACK				60UL				
#define	R_TDISC2_SEND_SIZE_CTRL					60UL				
#define	R_TDISC2_SEND_SIZE_MYSTAT_IEF			60UL				
#define	R_TDISC2_SEND_SIZE_SYNC					60UL				
#define	R_TDISC2_SEND_SIZE_TOKEN				60UL				

#define	R_TDISC2_SEND_SIZE_HEADER				60UL				


#define	R_TDISC3_DATA_FROM_DDR2_SDRAM			0UL					
#define	R_TDISC3_DATA_FROM_MPU_RAM				1UL					

#define	R_STDISD_ELM_COUNT						14UL				

#define	TDISC_NO_CYCLIC_RWr					0UL					
#define	TDISC_NO_CYCLIC_RX					2UL					
#define	TDISC_NO_TRANSIENT					16UL				
#define	TDISC_NO_MYSTATUS					509UL				
#define	TDISC_NO_TOKEN						511UL				

#define	R_TDISC1_FRM_TYPE_CYC					0UL					
#define	R_TDISC1_FRM_TYPE_TRN_FIELD				1UL					
#define	R_TDISC1_FRM_TYPE_CTRL					2UL					

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/
typedef struct _R_TDISC1_TAG {
	ULONG	b01ZSendFrmExperienced:					1;			
	ULONG	b01ZLastDiscriptorFlag:					1;			
	ULONG   b02ZReserved1:							2;			
	ULONG	b02ZFrmType:							2;			
	ULONG   b01ZCycType:							1;			
	ULONG   b01ZAlignment:							1;			
	ULONG   b09ZNextReadDiscriptorChain:			9;			
	ULONG   b03ZReserved3:							3;			
	ULONG	b03ZDummyFlameNum:						3;			
	ULONG   b01ZReserved4:							1;			
	ULONG	b05ZDummyFlameSize:						5;			
	ULONG   b03ZReserved5:							3;			
} R_TDISC1_TAG;

typedef struct _R_TDISC2_TAG {
	ULONG	b07ZSendHeaderFrmSize:					7;			
	ULONG	b01ZReserved2:							1;			
	ULONG	b0BZSendSize:							11;			
	ULONG   b0DZReserved3:							13;			
} R_TDISC2_TAG;

typedef struct _R_TDISC3_TAG {
	ULONG	b1AZSendDataDMAFromAddress:				26;			
	ULONG	b01ZDataFromType:						1;			
	ULONG	b04ZReserved2:							5;			
} R_TDISC3_TAG;

typedef struct _R_TDS_TAG  {	
	ULONG						R_TDISC1;						
	ULONG						R_TDISC2;						
	ULONG						R_TDISC3;						
	ULONG						ulReserved;						
} R_TDS_TAG;

typedef struct _TD_TAG {
	R_TDS_TAG					aTD_TDS[TDISC_COUNT];					
} TD_T;

#endif	/* __R_IN32M4_5_H_INCLUDED_ */
