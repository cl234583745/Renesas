/***********************************************************************
    VITESSE VSC8641 10/100/Giga PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
    2014/09/03: Fixed procedure of set and get PHY mode
    2014/10/08: Changed to S/W reset from isolation at setting PHY mode
 ***********************************************************************/

#include "RIN32M4.h"
#include "ether/eth_hwfnc.h"
#include "kernel.h"
#include "ether_unet3/DDR_PHY.h"
#include "ether_unet3/DDR_PHY_VSC8641.h"


#ifdef LIB_ETHDRIVER
/* defined symbol -> external const variable */
extern   ID ID_TASK_PHY0_LINK_C;
#define  ID_TASK_PHY0_LINK  ID_TASK_PHY0_LINK_C
#else
#include "kernel_id.h"
#endif

static ID phy_flg;
static UW phy_id;
static UW phy_adr;

static UINT phy_get(UINT reg_adr)
{
    UINT sta;
    UINT i;

    loc_cpu();
    RIN_ETH->GMAC_MIIM = MII_R | MII_PHYA(phy_adr) | MII_REGA(reg_adr);

    for (i=0; i<PYH_RW_CNT; i++) {
        sta = RIN_ETH->GMAC_MIIM;
        if (sta & MII_VALID) {
            unl_cpu();
            return sta & 0xffff;
        }
    }
    unl_cpu();
    return 0xffffffff;
}

static UINT phy_put(UINT reg_adr, UINT val)
{
    UINT sta;
    UINT i;

    loc_cpu();
    RIN_ETH->GMAC_MIIM = MII_W | MII_PHYA(phy_adr) | MII_REGA(reg_adr) | val;

    for (i=0; i<PYH_RW_CNT; i++) {
        sta = RIN_ETH->GMAC_MIIM;
        if (sta & MII_VALID) {
            unl_cpu();
            return sta & 0xffff;
        }
    }
    unl_cpu();
    return 0xffffffff;
}

/* Ether Driver Interface */

ER phy_vsc_ini(ID flg, UW id, UW adr)
{
    phy_flg  = flg;
    phy_id   = id;
    phy_adr  = adr;

    phy_put(PHY_BMCR, BMCR_RESET);
    while(phy_get(PHY_BMCR) & BMCR_RESET);
    phy_put(PHY_REG_INT_MASK, VSC8641_INT_MDINT_ENA | VSC8641_INT_LINK_CHG);

    return E_OK;
}

ER phy_vsc_ext(void)
{
    ER ercd;
    ercd = ter_tsk(ID_TASK_PHY0_LINK);
    return ercd;
}

ER phy_vsc_set_mode(UW mode, UB nego)
{
    /* Auto-Negotiation*/
    if (nego) {
        /* Enable auto-negotition */
        phy_put(PHY_BMCR, BMCR_ANE);
        if (mode == PHY_10T_HD) {
            phy_put(PHY_ANAR, (ANAR_10 | ANAR_SF_802_3u));
        } else if (mode == PHY_10T_FD) {
            phy_put(PHY_ANAR, (ANAR_10_FD | ANAR_10 | ANAR_SF_802_3u));
        } else if (mode == PHY_100TX_HD) {
            phy_put(PHY_ANAR, (ANAR_TX | ANAR_SF_802_3u));
        } else if (mode == PHY_100TX_FD) {
            phy_put(PHY_ANAR, (ANAR_TX_FD | ANAR_TX | ANAR_SF_802_3u));
        } else {/* Auto select mode (10HD/10FD/100HD/100FD) */
            phy_put(PHY_ANAR, (ANAR_TX_FD | ANAR_TX | ANAR_10_FD | ANAR_10 | ANAR_SF_802_3u));
        }
        /* Restart auto-negotition */
        phy_put(PHY_BMCR, BMCR_ANE | BMCR_RS_ANP);
    } else {

        /* Disable I/F */
        phy_put(PHY_BMCR, BMCR_RESET);
        while(phy_get(PHY_BMCR) & BMCR_RESET) {
            tslp_tsk(1);
        }

        if (mode == PHY_10T_HD) {
            phy_put(PHY_BMCR, 0);
        } else if (mode == PHY_10T_FD) {
            phy_put(PHY_BMCR, BMCR_DUPLEX);
        } else if (mode == PHY_100TX_HD) {
            phy_put(PHY_BMCR, BMCR_SPD_LSB);
        } else if (mode == PHY_100TX_FD) {
            phy_put(PHY_BMCR, (BMCR_SPD_LSB | BMCR_DUPLEX));
        } else if (mode == PHY_1000T_HD) {
            phy_put(PHY_BMCR, BMCR_SPD_MSB);
        } else if (mode == PHY_1000T_FD) {
            phy_put(PHY_BMCR, (BMCR_SPD_MSB | BMCR_DUPLEX));
        } else {
            phy_put(PHY_BMCR, 0);
        }
    }
    return E_OK;
}

ER phy_vsc_get_mode(UW *mode, UB *nego, UB *link)
{
    UW sts;

    *link = (phy_get(PHY_BMSR) & BMSR_LINK_STAT) ? 1 : 0;
    if (*link == 0) {
        return E_OK;
    }

    sts = phy_get(PHY_REG_AUX_CNTSTAT); 

    /* Full Duplex */
    if (sts & VSC8641_DUPLEX_MASK) {
        if ((sts & VSC8641_SPEED_MASK) == VSC8641_SPEED_1G) {
            *mode = PHY_1000T_FD;
        } else if ((sts & VSC8641_SPEED_MASK) == VSC8641_SPEED_100M) {
            *mode = PHY_100TX_FD;
        } else {
            *mode = PHY_10T_FD;
        }
    /* Half Duplex */
    } else {
        if ((sts & VSC8641_SPEED_MASK) == VSC8641_SPEED_1G) {
            *mode = PHY_1000T_HD;
        } else if ((sts & VSC8641_SPEED_MASK) == VSC8641_SPEED_100M) {
            *mode = PHY_100TX_HD;
        } else {
            *mode = PHY_10T_HD;
        }
    }
    *nego = (phy_get(PHY_BMCR) & BMCR_ANE) ? 1 : 0;
    return E_OK;
}

/* Interrupt Handler */
/* no use H/W ISR    */
void phy_vsc_intr(void)
{
    /* link change interrupt */
    set_flg(phy_flg, (PHY_LINK_EVT | phy_id));
}

/*
If use H/W ISR following definition must add kernel_cfg.c
const HWISR_TBL static_hwisr_table[] = {
    {ETHPHY0_IRQn,  HWISR_SET_FLG,  ID_FLG_ETH_RX_MAC,  (PHY_LINK_EVT|1) },
    {ETHPHY1_IRQn,  HWISR_SET_FLG,  ID_FLG_ETH_RX_MAC,  (PHY_LINK_EVT|2) },
}
*/

