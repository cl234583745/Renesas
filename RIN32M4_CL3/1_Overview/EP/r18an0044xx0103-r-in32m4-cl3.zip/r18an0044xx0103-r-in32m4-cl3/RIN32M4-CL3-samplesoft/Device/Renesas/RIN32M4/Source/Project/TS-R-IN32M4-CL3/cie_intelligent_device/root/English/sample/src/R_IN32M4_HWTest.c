/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_HWTest.c                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Callback.h"
#include "R_IN32M4_sample.h"
#include "R_IN32M4_HWTest.h"

#include "R_IN32M4Driver.h"


/****************************************************************************/
/** @brief  H/W TEST (IEEE 802.3ab compliance tes)                          */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserIEEETest( VOID )
{
	static const USHORT ausModeTbl[] = {	/* Test mode table */
							R_IN32_IEEE_MODE1,
							R_IN32_IEEE_END,
							R_IN32_IEEE_MODE2,
							R_IN32_IEEE_END,
							R_IN32_IEEE_MODE3,
							R_IN32_IEEE_END,
							R_IN32_IEEE_MODE4,
							R_IN32_IEEE_END
						};

	ULONG	ulCount;						/* Counter */
	INT		iResult;						/* Result */
	ERRCODE	erRet;							/* Return value */
	BOOL	blNext;							/* Next test flag */
	BOOL	blOK;							/* Waveform measurement result of oscilloscope */
	/* Set the waveform measurement result of oscilloscope to normal */
	blOK = R_IN32_TRUE;

	/* Initialize R_IN32M4 */
	iResult = iUserInitialization();
	/* Return value of initial process */
	if (USER_OK != iResult) {
		return;
	}
	else {
	}


	/* Execute the test according to the test mode table */
	for ( ulCount = 0UL; ulCount < (sizeof(ausModeTbl)/sizeof(ausModeTbl[0])); ulCount++ ) {

		/* Execute IEEE802.3ab compliance test */
		erRet = gerR_IN32_IEEETest(ausModeTbl[ulCount]);

		/* Test finished erroneously */
		if (R_IN32_ERR == erRet) {

			/* example */
			/* Confirm the occurred fatal error in the gerR_IN32_IEEETest() */
			if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */
				/* Error termination */

				/* TODO: Please handle the gulUserFatalError[][] as necessary */

				/* Reset fatal error counter */
				gulUserFatalErrorNum = 0UL;
			}
			else {
			}

			iResult = USER_ERR;
			break;
		}

		/* Test finished normally */
		else {
		}

		/* Next test not available */
		blNext = R_IN32_FALSE;

		/* Measure the waveform from PHY by oscilloscope */
		while(1) {

			/* WDT reset example */
			/* When using internal WDT, please reset the WDT before time-out */
			if (R_IN32_TRUE == gblUserR_IN32M4WDT_Enable) {

				/* Reset the internal WDT */
				gerR_IN32_ResetWDT();
			}
			else {
			}

			/* If test end */
			if ( R_IN32_IEEE_END == ausModeTbl[ulCount]){
				break;
			}
			else {
			}

			/* TODO: If measurement result is not normal, code which sets blOK = R_IN32_FALSE is necessary */

			/* Is measurement result normal? */
			if (R_IN32_FALSE == blOK) {	/* Error case */
				iResult = USER_ERR;
				break;
			}
			else {
			}

			/* TODO: In case next test is to be executed, code which sets blNext = R_IN32_TRUE is necessary  */

			/* Is next test to be executed? */
			if (R_IN32_TRUE == blNext) {	/* Execute next test */
				break;
			}
			else {
			}
		}

		/* In case there is error available */
		if (USER_OK != iResult) {
			break;
		}
		else {
		}
	}

	return;
}

/****************************************************************************/
/** @brief  H/W TEST (Loop back communication test)                         */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserLoopBackTest( VOID )
{
	static const ULONG aulTestTbl[2] = 	{	R_IN32_PORT1,
											R_IN32_PORT2 };

	ULONG	ulCount;
	ULONG	ulLinkState;
	ULONG	ulSpeed;
	ULONG	ulDuplex;
	BOOL	blLinkUP;

	INT		iResult;						/* Result */
	ERRCODE	erResult;						/* Result */


	/* Initialization processing */
	iResult = iUserInitialization();
	/* Return value of initial process */
	if (USER_OK != iResult) {
		return;
	}
	else {
	}


	/* Execute test according to the test content table */
	for ( ulCount = 0UL; ulCount < (sizeof(aulTestTbl) / sizeof(aulTestTbl[0])); ulCount++ ) {

		/* WDT reset example */
		/* When using internal WDT, please reset the WDT before time-out */
		if (R_IN32_TRUE == gblUserR_IN32M4WDT_Enable) {

			/* Reset the internal WDT */
			gerR_IN32_ResetWDT();
		}
		else {
		}

		/* Initialization for loop back test */
		erResult = gerR_IN32_InitializeLoopBackTest();

		/* Initialization error */
		if (R_IN32_OK != erResult) {

			/* example */
			/* Confirm the occurred fatal error in the gerR_IN32_InitializeLoopBackTest() */
			if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */
				/* Error termination */

				/* TODO: Please handle the gulUserFatalError[][] as necessary */

				/* Reset fatal error counter */
				gulUserFatalErrorNum = 0UL;
			}
			else {
			}

			iResult = USER_ERR;
			break;
		}

		/* Initialization normal */
		else {
		}


			/* Please wait Connect to port1 and port2  */
			while(1) {

				blLinkUP = R_IN32_TRUE;

				/* Get PHY link status (PORT1) */
				(VOID)gerR_IN32_GetPortStatus( R_IN32_PORT1, &ulLinkState, &ulSpeed, &ulDuplex );

				/* Connected in 1Gbps and full duplex? */
				if ((R_IN32_LINKUP != ulLinkState) || (R_IN32_SPEED_1G != ulSpeed) || (R_IN32_DUPLEX_FULL != ulDuplex)) {
					blLinkUP = R_IN32_FALSE;
				}
				else {
				}

				/* Get PHY link status  (PORT2)*/
				(VOID)gerR_IN32_GetPortStatus( R_IN32_PORT2, &ulLinkState, &ulSpeed, &ulDuplex );

				/* Connected in 1Gbps and full duplex? */
				if ((R_IN32_LINKUP != ulLinkState) || (R_IN32_SPEED_1G != ulSpeed) || (R_IN32_DUPLEX_FULL != ulDuplex)) {
					blLinkUP = R_IN32_FALSE;
				}
				else {
				}

				/* Both port are connected in 1Gbps and full duplex */
				if ( R_IN32_TRUE == blLinkUP) {
					break;
				}
				else {
				}


				/* WDT reset example */
				/* When using internal WDT, please reset the WDT before time-out */
				if (R_IN32_TRUE == gblUserR_IN32M4WDT_Enable) {

					/* Reset the internal WDT */
					gerR_IN32_ResetWDT();
				}
				else {
				}
			}

			/* External loop back test */
		erResult = gerR_IN32_ExternalLoopBackTest( aulTestTbl[ulCount] );

			/* Test finished erroneously */
			if (R_IN32_ERR == erResult) {

				/* example */
				/* Confirm the occurred fatal error in the gerR_IN32_ExternalLoopBackTest() */
				if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */
					/* Error termination */

					/* TODO: Please handle the gulUserFatalError[][] as necessary */

					/* Reset fatal error counter */
					gulUserFatalErrorNum = 0UL;
				}
				/* Test finished normally */
				else {
				}

				iResult = USER_ERR;
				break;
			}

			/* Test finished normally */
			else {
			}

	}

	return;
}

/*** EOF ***/
