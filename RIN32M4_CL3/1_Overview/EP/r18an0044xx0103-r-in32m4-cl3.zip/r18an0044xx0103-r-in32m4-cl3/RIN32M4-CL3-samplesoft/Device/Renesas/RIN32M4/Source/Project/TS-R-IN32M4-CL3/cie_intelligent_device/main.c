/**
 *******************************************************************************
 * @file  main.c
 * @brief CC-Link IE Field sample program for R_IN32M4
 * 
 * @note 
 * Copyright 2016 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>

#include "RIN32M4.h"
#include "kernel.h"
#include "kernel_id.h"

#include "uart/uart.h"

//#include "R_IN32M4_sample.h"
//#include "R_IN32M4_HWTest.h"
#include "board_init.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/
extern ER hwos_init(void);
extern INT  iUserMainRoutine( void );
extern INT	iUserMyStaRcvTkn(void);
extern ER gerR_IN32D_BlinkLed(unsigned short*);
extern void gR_IN32R_WaitMS(INT);
/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************
  @brief  Initialize task
  @param  none
  @retval none
 *******************************************************************************
*/
void init_task(int exinf)
{
	//=========================================
	// Initialize System
	//=========================================
    // Unlock system register
    RIN_SYS->SYSPCMD = 0x00a5;
    RIN_SYS->SYSPCMD = 0x0001;
    RIN_SYS->SYSPCMD = 0xfffe;
    RIN_SYS->SYSPCMD = 0x0001;

	RIN_SYS->PHYRSTCH = 1;

	// Lock system register
    RIN_SYS->SYSPCMD = 0x0000;

	// --- Initialize Port ---
	board_init();
	cie_board_init();

	// --- Initialize CC-Link IE bridge ---
	RIN_CCI_BRG->CIEBSC = 0x0000FFFF;		// CCIBSC  (CC-LINK-IE   DATA BUS:32bit)
	RIN_CCI_BRG->CIESMC = 0x00000050;		// CCISMC  (IW0:0/WW0:0/DW0:5/AC0:0)

	// --- Initialize CC-Link IE register ---
	*((unsigned long*)0x400F1800) = 0x00000004;
	*((unsigned short*)0x40100962) = 0x0000;		// Disable watch dog timer in CC-Link IE module
	*((unsigned long*)0x400F1804) = 0x00000003;
	*((unsigned long*)0x400F1808) = 0x00000001;
	*((unsigned long*)0x400F180C) = 0x00000001;
	*((unsigned long*)0x400F1810) = 0x00030001;
	*((unsigned long*)0x400F1864) = 0x00000145;
	*((unsigned long*)0x4010C500) = 0x00000002;
	*((unsigned long*)0x40140400) = 0x00000002;
	*((unsigned long*)0x4014040C) = 0x0000000C;
	*((unsigned long*)0x4014101C) = 0x00000001;
	
	// --- Initialize HW-RTOS ---
	hwos_init();
	// --- Initialize UART ---
	uart_init(SYS_UART_CH);

    // --- Display Opening message
    rin_boot_message();

	//=========================================
	// Exit task
	//=========================================
	ext_tsk();

}

/**
 *******************************************************************************
  @brief  Main task
  @param  none
  @retval none
 *******************************************************************************
*/
void main_task(int exinf)
{
	printf("[main_tsk] Start \n");
	
	// LoopBackTest
//	UserLoopBackTest();

	// Application
	iUserMainRoutine();

	while (1) {
		printf("[main_tsk] Sleep \n");
		slp_tsk();
		
		printf("[main_tsk] Wake up \n");
		
	}

//	ext_tsk();
}

/**
 *******************************************************************************
  @brief  Software ISR task
  @param  none
  @retval none
 *******************************************************************************
*/ 
void int_task(void)
{
	set_flg(ID_APL_FLG1, 0x0001);
}

/**
 *******************************************************************************
  @brief  Idle task
  @param  none
  @retval none
 *******************************************************************************
*/
void idle_task(int exinf)
{
	while (1) {
	}
}

/**
*******************************************************************************
 @brief  int1 interrupt task
 @param  none
 @retval none
*******************************************************************************
*/
void int1_task( void )
{	
	slp_tsk();
	
	while (1) {
		
          iUserMyStaRcvTkn();
          
          slp_tsk();
	}	
}

/**
 *******************************************************************************
  @brief  LED task
  @param  none
  @retval none
 *******************************************************************************
*/
void led_task(int exinf)
{
	unsigned short  usBlinkMS;

	while (1) {
		gerR_IN32D_BlinkLed(&usBlinkMS);
		gR_IN32R_WaitMS(usBlinkMS);
	}
}
