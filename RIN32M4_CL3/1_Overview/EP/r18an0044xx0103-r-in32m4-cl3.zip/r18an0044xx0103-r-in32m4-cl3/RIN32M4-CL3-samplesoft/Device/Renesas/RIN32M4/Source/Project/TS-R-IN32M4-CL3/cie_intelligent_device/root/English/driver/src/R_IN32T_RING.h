/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_RING.h                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_RING_H_INCLUDED__
#define	__R_IN32T_RING_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32T.h"


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID R_IN32T_RING_Start( VOID );
extern VOID R_IN32T_RING_ModeReset( VOID );
extern VOID R_IN32T_RING_IntClear( VOID );
extern VOID R_IN32T_RING_RepeatDisable( VOID );
extern VOID R_IN32T_RING_DebugTxEnable( VOID );
extern VOID R_IN32T_RING_ForcedLinkUpEnable( VOID );
extern VOID R_IN32T_RING_TxPortSet( R_IN32T_PORT_SEL_ENUM );


#endif	/* __R_IN32T_RING_H_INCLUDED__ */

/*** EOF ***/
