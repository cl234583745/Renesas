/**
 *******************************************************************************
 * @file  board_init.c
 * @brief Board setting for R-IN32M4-CL3 Evaluation Board.
 * 
 * @note 
 * Copyright 2016 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */
/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/

#include "board_init.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************
  @brief  board initialize for TS-TCS08467 / TS-TCS07908.
  @param  none
  @retval none
 *******************************************************************************
*/
void board_init(void)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	RIN_SYS->DRCTLRP3L = 0x1111;

#else				// TS-TCS07908 (23mm)
	RIN_SYS->DRCTLP3H  = 0x1919;
	
	RIN_SYS->DRCTLRP2L = 0x9999;
	RIN_SYS->DRCTLRP2H = 0x9999;
	
	RIN_SYS->DRCTLRP3L = 0x1111;
	RIN_SYS->DRCTLRP3H = 0x1111;
#endif	// TS_TCS08467

	RIN_GPIO->PM0B    = 0xFF;       // P00   Input
	RIN_GPIO->PMC0B   = 0x00;       // P01   Input
	RIN_GPIO->PFC0B   = 0x00;       // P02   Input
	RIN_GPIO->PFCE0B  = 0x00;       // P03   Input
                                    // P04   Input
                                    // P05   Input
                                    // P06   none, Input
                                    // P07   none, Input
	
	RIN_GPIO->PM2B    = 0xFB;       // P20   RXD0
	RIN_GPIO->PMC2B   = 0x03;       // P21   TXD0
	RIN_GPIO->PFC2B   = 0x00;       // P22   Output
	RIN_GPIO->PFCE2B  = 0x00;       // P23   Input
	RIN_GPIO->P2B     = 0x00;       // P24   Input
                                    // P25   Input
                                    // P26   Input
                                    // P27   Input

	RIN_GPIO->PM3B    = 0xFF;       // P30   RXD1
	RIN_GPIO->PMC3B   = 0x03;       // P31   TXD1
	RIN_GPIO->PFC3B   = 0x00;       // P32   Input
	RIN_GPIO->PFCE3B  = 0x00;       // P33   Input
                                    // P34   Input
                                    // P35   Input
                                    // P36   Input
                                    // P37   Input

	RIN_GPIO->PM4B    = 0xFF;       // P40   Input
	RIN_GPIO->PMC4B   = 0x00;       // P41   Input
	RIN_GPIO->PFC4B   = 0x00;       // P42   Input
	RIN_GPIO->PFCE4B  = 0x00;       // P43   Input
                                    // P44   Input
                                    // P45   Input
                                    // P46   Input
                                    // P47   Input

	RIN_GPIO->PM6B    = 0xFF;       // P60   Input
	RIN_GPIO->PMC6B   = 0x00;       // P61   Input
	RIN_GPIO->PFC6B   = 0x00;       // P62   Input
	RIN_GPIO->PFCE6B  = 0x00;       // P63   Input
                                    // P64   Input
                                    // P65   Input
                                    // P66   Input
                                    // P67   Input

	RIN_GPIO->PM7B    = 0xFF;       // P70   Input
	RIN_GPIO->PMC7B   = 0x00;       // P71   Input
	RIN_GPIO->PFC7B   = 0x00;       // P72   Input
	RIN_GPIO->PFCE7B  = 0x00;       // P73   Input
                                    // P74   Input
                                    // P75   Input
                                    // P76   Input
                                    // P77   Input

	RIN_RTPORT->RPM0B    = 0xFF;    // RP00  Input
	RIN_RTPORT->RPMC0B   = 0x00;    // RP01  Input
	RIN_RTPORT->RPFC0B   = 0x00;    // RP02  Input
	RIN_RTPORT->RPFCE0B  = 0x00;    // RP03  Input
                                    // RP04  Input
                                    // RP05  Input
                                    // RP06  Input
                                    // RP07  Input

	RIN_RTPORT->RPM3B    = 0xFF;    // RP30  Input
	RIN_RTPORT->RPMC3B   = 0x00;    // RP31  Input
	RIN_RTPORT->RPFC3B   = 0x00;    // RP32  Input
	RIN_RTPORT->RPFCE3B  = 0x00;    // RP33  Input
                                    // RP34  Input
                                    // RP35  Input
                                    // RP36  Input
                                    // RP37  Input

	RIN_EXTPORT->EXTPM0B    = 0xFF; // EXTP0 Input
	RIN_EXTPORT->EXTPMC0B   = 0x00; // EXTP1 Input
	RIN_EXTPORT->EXTPFC0B   = 0x00; // EXTP2 Input
	RIN_EXTPORT->EXTPFCE0B  = 0x00; // EXTP3 Input
                                    // EXTP4 Input
                                    // EXTP5 Input
                                    // EXTP6 Input
                                    // EXTP7 Input

#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	RIN_GPIO->PM1B    = 0xFF;       // P10   none
	RIN_GPIO->PMC1B  &= 0xF0;       // P11   none
	RIN_GPIO->PFC1B  &= 0xF0;       // P12   none
	RIN_GPIO->PFCE1B &= 0xF0;       // P13   none
                                    // P14   ----
                                    // P15   ----
                                    // P16   ----
                                    // P17   ----

	RIN_GPIO->PM5B    = 0x87;       // P50   Input
	RIN_GPIO->PMC5B   = 0x00;       // P51   Input
	RIN_GPIO->PFC5B   = 0x00;       // P52   Input
	RIN_GPIO->PFCE5B  = 0x00;       // P53   none(Output)
                                    // P54   none(Output)
                                    // P55   none(Output)
                                    // P56   none(Output)
                                    // P57   Input

	RIN_RTPORT->RPM1B    = 0xFF;    // RP10  Input
	RIN_RTPORT->RPMC1B   = 0x22;    // RP11  LED1_PHY0
	RIN_RTPORT->RPFC1B   = 0x22;    // RP12  Input
	RIN_RTPORT->RPFCE1B  = 0x00;    // RP13  Input
                                    // RP14  Input
                                    // RP15  LED1_PHY1
                                    // RP16  Input
                                    // RP17  Input

	RIN_RTPORT->RP2B     = 0x0F;    // RP20  Output
	RIN_RTPORT->RPM2B    = 0xF0;    // RP21  Output
	RIN_RTPORT->RPMC2B   = 0x00;    // RP22  Output
	RIN_RTPORT->RPFC2B   = 0x00;    // RP23  Output
	RIN_RTPORT->RPFCE2B  = 0x00;    // RP24  Input
                                    // RP25  Input
                                    // RP26  Input
                                    // RP27  Input

	RIN_EXTPORT->EXTPM1B    = 0x7F; // EXTP8 Input
	RIN_EXTPORT->EXTPMC1B  &= 0x0C; // EXTP9 Input
	RIN_EXTPORT->EXTPFC1B  &= 0x0C; // EXTP10 ----
	RIN_EXTPORT->EXTPFCE1B &= 0x0C; // EXTP11 ----
                                    // EXTP12 Input
                                    // EXTP13 Input
                                    // EXTP14 Input

#else				// TS-TCS07908 (23mm)
	RIN_GPIO->PM1B    = 0xFF;       // P10   ----
	RIN_GPIO->PMC1B  &= 0xF3;       // P11   ----
	RIN_GPIO->PFC1B  &= 0xF3;       // P12   Input
	RIN_GPIO->PFCE1B &= 0xF3;       // P13   Input
                                    // P14   ----
                                    // P15   ----
                                    // P16   ----
                                    // P17   ----

	RIN_GPIO->PM5B    = 0x9F;       // P50   Input
	RIN_GPIO->PMC5B   = 0x00;       // P51   Input
	RIN_GPIO->PFC5B   = 0x00;       // P52   Input
	RIN_GPIO->PFCE5B  = 0x00;       // P53   Input
                                    // P54   Input
                                    // P55   Output
                                    // P56   Output
                                    // P57   Input

	RIN_RTPORT->RPM1B    = 0xFF;    // RP10  Input
	RIN_RTPORT->RPMC1B   = 0x00;    // RP11  Input
	RIN_RTPORT->RPFC1B   = 0x00;    // RP12  Input
	RIN_RTPORT->RPFCE1B  = 0x00;    // RP13  Input
                                    // RP14  Input
                                    // RP15  Input
                                    // RP16  Input
                                    // RP17  Input

	RIN_RTPORT->RP2B     = 0xFF;    // RP20  Output
	RIN_RTPORT->RPM2B    = 0x00;    // RP21  Output
	RIN_RTPORT->RPMC2B   = 0x00;    // RP22  Output
	RIN_RTPORT->RPFC2B   = 0x00;    // RP23  Output
	RIN_RTPORT->RPFCE2B  = 0x00;    // RP24  Output
                                    // RP25  Output
                                    // RP26  Output
                                    // RP27  Output

	RIN_EXTPORT->EXTPM1B    = 0x7F; // EXTP8 Input
	RIN_EXTPORT->EXTPMC1B   = 0x00; // EXTP9 Input
	RIN_EXTPORT->EXTPFC1B   = 0x00; // EXTP10 none(Input)
	RIN_EXTPORT->EXTPFCE1B  = 0x00; // EXTP11 none(Input)
                                    // EXTP12 none(Input)
                                    // EXTP13 none(Input)
                                    // EXTP14 none(Input)
#endif	// TS_TCS08467

}

/**
 *******************************************************************************
  @brief  board initialize for CC-Link IE Field
  @param  none
  @retval none
 *******************************************************************************
*/
void cie_board_init(void)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	RIN_GPIO->PMC0B  |= 0x3D;       // P00   CCI_RUNLEDZ
	RIN_GPIO->PFC0B  &=~0x3D;       // P01   ---
	RIN_GPIO->PFCE0B |= 0x3D;       // P02   CCI_DLINKLEDZ
                                    // P03   CCI_ERRLEDZ
                                    // P04   CCI_LERR1LEDZ
                                    // P05   CCI_LERR2LEDZ
                                    // P06   ---
                                    // P07   ---

	RIN_EXTPORT->EXTPMC1B  |= 0x30; // EXTP8 ---
	RIN_EXTPORT->EXTPFC1B  |= 0x30; // EXTP9 ---
	RIN_EXTPORT->EXTPFCE1B &=~0x30; // EXTP10 ----
                                    // EXTP11 ----
                                    // EXTP12 CCI_SDLEDZ
                                    // EXTP13 CCI_RDLEDZ
                                    // EXTP14 ---
	
	RIN_RTPORT->RPM1B    = 0xFF;    // RP10  Input
	RIN_RTPORT->RPMC1B   = 0x00;    // RP11  Input
	RIN_RTPORT->RPFC1B   = 0x00;    // RP12  Input
	RIN_RTPORT->RPFCE1B  = 0x00;    // RP13  Input
                                    // RP14  Input
                                    // RP15  Input
                                    // RP16  Input
                                    // RP17  Input

#else				// TS-TCS07908 (23mm)
	RIN_GPIO->PMC0B  |= 0xFD;       // P00   CCI_RUNLEDZ
	RIN_GPIO->PFC0B  &=~0xFD;       // P01   ---
	RIN_GPIO->PFCE0B |= 0xFD;       // P02   CCI_DLINKLEDZ
                                    // P03   CCI_ERRLEDZ
                                    // P04   CCI_LERR1LEDZ
                                    // P05   CCI_LERR2LEDZ
                                    // P06   CCI_SDLEDZ
                                    // P07   CCI_RDLEDZ
#endif	// TS_TCS08467
	
	RIN_SYS->INTSEL = 0x000007FF;
}


/**
 *******************************************************************************
  @brief  Set LED value
  @param  output	: LED value
  @retval none
 *******************************************************************************
*/
void set_board_led(uint8_t output)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	/* LED (LED10, LED11, LED12, LED13) */
	RIN_RTPORT->RP2B = (~output & 0x0F);	// RP20-23

#else				// TS-TCS07908 (23mm)
	/* LED (D39,D40,D42,D43,D44,D45,D46,D48) */
	RIN_RTPORT->RP2B = ~output;				// RP20-27
#endif	// TS_TCS08467
}

/**
 *******************************************************************************
  @brief  Get LED value
  @param  none
  @retval LED value
 *******************************************************************************
*/
uint8_t get_board_led(void)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	/* LED (LED10, LED11, LED12, LED13) */
	return (~RIN_RTPORT->RPIN2B & 0x0F);	// RP20-23

#else				// TS-TCS07908 (23mm)
	/* LED (D39,D40,D42,D43,D44,D45,D46,D48) */
	return ~RIN_RTPORT->RPIN2B;				// RP20-27
#endif	// TS_TCS08467
}

/**
 *******************************************************************************
  @brief  Get general sw value
  @param  none
  @retval General SW value
 *******************************************************************************
*/
uint8_t get_board_sw(void)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	/* SW12 */
	return (RIN_RTPORT->RPIN3B & 0x0F);	//  RP30-33

#else				// TS-TCS07908 (23mm)
	/* SW12 */
	return RIN_RTPORT->RPIN3B;			//  RP30-RP37
#endif	// TS_TCS08467
}

/**
 *******************************************************************************
  @brief  Get Node number for CC-Link IE field
  @param  none
  @retval Node number for CC-Link IE field
 *******************************************************************************
*/
uint8_t cie_get_nodenumber(void)
{
	/* SW3 / SW5 */
	return ~RIN_RTPORT->RPIN1B;
}


/**
 *******************************************************************************
  @brief  Get Network number for CC-Link IE field
  @param  none
  @retval Network number for CC-Link IE field
 *******************************************************************************
*/
uint8_t cie_get_networknumber(void)
{
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	return 1;		// SW none

#else				// TS-TCS07908 (23mm)
	/* SW4 / SW6 */
	return ~RIN_GPIO->PIN7B;
#endif	// TS_TCS08467
}


