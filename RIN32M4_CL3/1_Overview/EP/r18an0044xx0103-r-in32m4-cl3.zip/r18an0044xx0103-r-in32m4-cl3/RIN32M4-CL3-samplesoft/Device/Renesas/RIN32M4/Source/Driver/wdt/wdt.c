/**
 *******************************************************************************
 * @file  wdt.c
 * @brief Watchdog timer control program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "wdt/wdt.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
  @brief  Initialize
  @param  --
  @return Error condition
  @retval ER_OK -- Successful
 ******************************************************************************
 */
ER_RET wdt_init(void)
{
	//=========================================
	// System Register
	//=========================================
	RIN_SYS->SYSPCMD = 0x000000a5;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x00000001;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x0000fffe;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x00000001;			/* release protect */
	{	/* WDT count clock */
		RIN_SYS->WDTCLKCFG = 0x00000006;	/* [3:0]: frequency dividing rate -> HCLK/2048 */
	}

	RIN_SYS->SYSPCMD = 0x00000000;			/* set protect */

	//=========================================
	// WDTA Register
	//=========================================
	RIN_WDT->WDTA0MD =	  (0 << 7)			/* [7]  : reserve */
						| (7 << 4)			/* [6:4]: (WDTA0OVF2-0) Overflow interval time -> (count clk)/2^16 */
						| (1 << 2)			/* [2]  : (WDTA0ERM   ) Error mode -> Reset mode */
						| (3 << 0);			/* [1:0]: (WDTA0WS1-0 ) Window size -> 100% */

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Initialize for 75%-interrupt mode
  @param  --
  @return Error condition
  @retval ER_OK -- Successful
 ******************************************************************************
 */
ER_RET wdt_interrupt_init(void)
{
	uint32_t irq_num;

	irq_num = (uint8_t)WDTA_IRQn; 
	NVIC_EnableIRQ((IRQn_Type)irq_num);	

	//=========================================
	// System Register
	//=========================================
	RIN_SYS->SYSPCMD = 0x000000a5;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x00000001;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x0000fffe;			/* sequence to release protect */
	RIN_SYS->SYSPCMD = 0x00000001;			/* release protect */
	{	/* WDT count clock */
		RIN_SYS->WDTCLKCFG = 0x00000006;	/* [3:0]: frequency dividing rate -> HCLK/2048 */
	}

	RIN_SYS->SYSPCMD = 0x00000000;			/* set protect */

	//=========================================
	// WDTA Register
	//=========================================
	RIN_WDT->WDTA0MD =	  (0 << 7)			/* [7]  : reserve */
						| (7 << 4)			/* [6:4]: (WDTA0OVF2-0) Overflow interval time -> (count clk)/2^16 */
						| (1 << 3)			/* [3]  : (WDTA0WIE   ) 75% interrupt -> Enable */
						| (1 << 2)			/* [2]  : (WDTA0ERM   ) Error mode -> Reset mode */
						| (3 << 0);			/* [1:0]: (WDTA0WS1-0 ) Window size -> 100% */

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Start
  @param  --
  @return Error condition
  @retval ER_OK -- Successful
 ******************************************************************************
 */
ER_RET wdt_start(void)
{
	RIN_WDT->WDTA0WDTE = 0xAC;				/* [7]  : (WDTA0RUN   ) Watchdog timer start */

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Clear
  @param  --
  @return Error condition
  @retval ER_OK -- Successful
 ******************************************************************************
 */
ER_RET wdt_clear(void)
{
	RIN_WDT->WDTA0WDTE = 0xAC;				/* to clear the counter */

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Wait reset
  @param  --
  @return none
 ******************************************************************************
 */
void wdt_wait_reset(void)
{
	/* disable interrupt */
	__disable_irq();

	/* wait reset */
	while (1)
	{
		__NOP();
	}
}

/**
 ******************************************************************************
  @brief WDTA Interrupt handler
  @param  none
  @retval none
 ******************************************************************************
*/
void WDTA_IRQHandler( void )
{
	// clear WDTA count not to reset
	wdt_clear();

	__DSB();		// Errata work aruond - ID:838869
}

