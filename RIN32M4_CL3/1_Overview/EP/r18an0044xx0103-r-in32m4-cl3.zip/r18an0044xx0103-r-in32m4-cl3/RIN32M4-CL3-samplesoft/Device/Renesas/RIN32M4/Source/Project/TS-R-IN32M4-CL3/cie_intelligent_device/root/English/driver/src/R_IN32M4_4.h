/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_4.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32M4_4_H_INCLUDED_
#define __R_IN32M4_4_H_INCLUDED_

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define	RX_CTALV_ELM_COUNT					8UL					



#define	RX_FIFOSTS_RCV_FIFO_EMPTY			0UL					
#define	RX_FIFOSTS_RCV_FIFO_NOT_EMPTY		1UL					



#define	RX_STGURANTEN_CYCLICREC_ENABLE		1UL					/* C: b1, F; b0 */
#define	RX_STGURANTEN_CYCLICREC_DISABLE		0UL					/* C: b1, F; b0 */



#define	RX_STGURANTEN_C_WARRANTY_ENABLE		0UL					
#define	RX_STGURANTEN_C_WARRANTY_DISABLE	1UL					


#define	RX_BANK_SWITCH_MODE_MANUAL			(ULONG)0x0000		
#define	RX_BANK_SWITCH_MODE_SEMIAUTO		(ULONG)0x0001		
#define	RX_BANK_SWITCH_MODE_AUTO			(ULONG)0x0002		

#define	NSRINT_NONCYCLICRECVINT				ASIC_BIT0			
#define	NSRINT_TIMERFRMRECVINT				ASIC_BIT6			
#define	NSRINT_MYSTARCVTKNFRMINT			ASIC_BIT7			
#define	NSRINT_CNTLMSTTKNFRMRECVINT			ASIC_BIT8			
#define	NSRINT_CNTLFRMRECVINT				ASIC_BIT9			
#define	NSRINT_INTCLR						0xFFFFFFFF			
#define	NSRINTMS_ALLINTMASK_FULL			0xFFFFFFFF			

#define	ITRCV_NONCYCLICRECVINT				ASIC_BIT8			
#define	ITRCV_MASTERWATCHTIMERTIMEOUTINT	ASIC_BIT15			
#define	ITRCV_INTCLR						0xFFFFFFFF			
#define	ITRCV_ALLINTMASK_FULL				0xFFFFFFFF			

#define	CYCFLGCLR_CYCLICAFLGCLR				ASIC_BIT0			
#define	CYCFLGCLR_CYCLICBFLGCLR				ASIC_BIT1			
#define	CYCFLGCLR_SEQNOLATCHCLR				ASIC_BIT2			
#define	RDISENDIS_ALL_VALID					(ULONG)0x0000003F	
#define	RDISENDIS_ALL_INVALID				(ULONG)0x00000000	
#define	RDISENDIS_D1TO2_VALID				(ULONG)0x00000003	
#define	RDISENDIS_D3TO6_VALID				(ULONG)0x0000003C	

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/
typedef struct _ITMRCVE_TAG {
	ULONG	b01ZCyclicRecFIFOFullMask:				1;			
	ULONG	b01ZNonCyclicRecFIFO1FullMask:			1;			
	ULONG	b01ZNonCyclicRecFIFO2FullMask:			1;			
	ULONG	b01ZNonCyclicRecFIFO3FullMask:			1;			
	ULONG	b01ZNonCyclicRecDscpltDepleteMask:		1;			
	ULONG	b07ZReserved1:							7;			
	ULONG	b01ZCyclicRecFIFOPErrBrkMask:			1;			
	ULONG	b01ZNonCyclicRecFIFO1PErrBrkMask:		1;			
	ULONG	b01ZNonCyclicRecFIFO2PErrBrkMask:		1;			
	ULONG	b01ZNonCyclicRecFIFO3PErrBrkMask:		1;			
	ULONG	b10ZReserved2:							16;			
} ITMRCVE_TAG;

typedef struct _ITRCVE_TAG {
	ULONG	b01ZCyclicRecFIFOFull:					1;			
	ULONG	b01ZNonCyclicRecFIFO1Full:				1;			
	ULONG	b01ZNonCyclicRecFIFO2Full:				1;			
	ULONG	b01ZNonCyclicRecFIFO3Full:				1;			
	ULONG	b01ZNonCyclicRecDscpltDeplete:			1;			
	ULONG	b07ZReserved1:							7;			
	ULONG	b01ZCyclicRecFIFOPErrBrk:				1;			
	ULONG	b01ZNonCyclicRecFIFO1PErrBrk:			1;			
	ULONG	b01ZNonCyclicRecFIFO2PErrBrk:			1;			
	ULONG	b01ZNonCyclicRecFIFO3PErrBrk:			1;			
	ULONG	b10ZReserved2:							16;			
} ITRCVE_TAG;

typedef struct _ITMRCV_TAG {
	ULONG	b06ZReserved1:							6;			
	ULONG	b01ZIefCntlMstCyclRecNrmlEndMask:		1;			
	ULONG	b01ZIecCyclRecNrmlEndMask:				1;			
	ULONG	b01ZNonCyclicRecFoundMask:				1;			
	ULONG	b01ZIefCyclRecAbNrmlEndMask:			1;			
	ULONG	b01ZIecCyclRecAbNrmlEndMask:			1;			
	ULONG	b04ZReserved2:							4;			
	ULONG	b01ZMstWatchTimerTmOutBrkMask:			1;			
	ULONG	b10ZReserved3:							16;			
} ITMRCV_TAG;

typedef struct _ITRCV_TAG {
	ULONG	b06ZReserved1:							6;			
	ULONG	b01ZIefCntlMstCyclRecNrmlEnd:			1;			
	ULONG	b01ZIecCyclRecNrmlEnd:					1;			
	ULONG	b01ZNonCyclicRecFound:					1;			
	ULONG	b01ZIefCyclRecAbNrmlEnd:				1;			
	ULONG	b01ZIecCyclRecAbNrmlEnd:				1;			
	ULONG	b04ZReserved2:							4;			
	ULONG	b01ZMstWatchTimerTmOutBrk:				1;			
	ULONG	b10ZReserved3:							16;			
} ITRCV_TAG;

typedef struct ERMAKE_TAG {
	ULONG	b01ZCyclicRecFIFOPrtyErrCompls:			1;			
	ULONG	b01ZNonCyclicRecFIFO1PrtyErrCompls:		1;			
	ULONG	b01ZNonCyclicRecFIFO2PrtyErrCompls:		1;			
	ULONG	b01ZNonCyclicRecFIFO3PrtyErrCompls:		1;			
	ULONG	b1CZReserved3:							28;			
} ERMAKE_TAG;

typedef struct _FIFOSTS_TAG {
	ULONG	b01ZCyclicRecFIFOEmpty:					1;			
	ULONG	b01ZNonCyclicRecFIFO1Empty:				1;			
	ULONG	b01ZNonCyclicRecFIFO2Empty:				1;			
	ULONG	b01ZNonCyclicRecFIFO3Empty:				1;			
	ULONG	b1CZReserved3:							28;			
} FIFOSTS_TAG;

typedef struct _CYCRXFIFO_ALF_TAG {
	ULONG	b02ZCycRevFIFOAlmostFULL:				2;			
	ULONG	b1EZReserved1:							30;			
} CYCRXFIFO_ALF_TAG;

typedef struct _STGURANTEN_F_TAG {
	ULONG	b01ZCyclicRecValid:						1;			
	ULONG	b1FZReserved1:							31;			
} STGURANTEN_F_TAG;

typedef struct _CYC_MASTER_ID_F_TAG {
	ULONG	b04ZMyStationMsterID:					4;			
	ULONG	b1CZReserved1:							28;			
} CYC_MASTER_ID_F_TAG;

typedef struct _CYCSTS_F_TAG {
	ULONG	b01ZRecDataSizeAbnormal:				1;			
	ULONG	b01Z2PortAddrDeviation:					1;			
	ULONG	b1EZReserved1:							30;			
} CYCSTS_F_TAG;

typedef struct _CYCFLGCLR_F_TAG {
	ULONG	b01ZCycRecFlgAClr:						1;			
	ULONG	b01ZCycRecFlgBClr:						1;			
	ULONG	b01ZSequentialNumberClr:				1;			
	ULONG	b01ZRecSignalClr:						1;			
	ULONG	b1CZReserved1:							28;			
} CYCFLGCLR_F_TAG;

typedef struct _RX_BANK_SWITCH_MODE_TAG {
	ULONG	b02ZCycRevBufferBankSwitchMode:			2;			
	ULONG	b1EZReserved1:							30;			
} RX_BANK_SWITCH_MODE_TAG;

typedef struct _RX_BANK_STS_TAG {
	ULONG	b01ZCycRevBufferBankState:				1;			
	ULONG	b1FZReserved1:							31;			
} RX_BANK_STS_TAG;

typedef struct _RX_BANK_SWITCH_TAG {
	ULONG	b01ZCycRevBufferBankSwitch:				1;			
	ULONG	b1FZReserved1:							31;			
} RX_BANK_SWITCH_TAG;

typedef union _RY1_FMB_INFO_TAG {
	ULONG	ulDATA;										
	struct {
		ULONG	b4ZTopByteValid:			4;			
		ULONG	b4ZBtmByteValid:			4;			
		ULONG	b8ZDummy1:					8;			
		ULONG	b1FZReserved1:				16;			
	} stBIT;
} RY1_FMB_INFO_T;

typedef struct _BUFEMPINF_TAG {
	ULONG	b01ZNonCycRecDiscplit1Deplete:			1;			
	ULONG	b01ZNonCycRecDiscplit2Deplete:			1;			
	ULONG	b01ZNonCycRecDiscplit3Deplete:			1;			
	ULONG	b01ZNonCycRecDiscplit4Deplete:			1;			
	ULONG	b01ZNonCycRecDiscplit5Deplete:			1;			
	ULONG	b01ZNonCycRecDiscplit6Deplete:			1;			
	ULONG 	b1AZReserved1:							26;			
} BUFEMPINF_TAG;

typedef struct _NRXFIFO_ALF_TAG {
	ULONG	b02ZNonCycRecFIFO12AlmostFULL:			2;			
	ULONG	b02ZNonCycRecFIFO3AlmostFULL:			2;			
	ULONG	b1CZReserved1:							28;			
} NRXFIFO_ALF_TAG;

typedef struct _RDISENDIS_TAG {
	ULONG 	b01ZNonCycRecD1Valid:					1;			
	ULONG 	b01ZNonCycRecD2Valid:					1;			
	ULONG 	b01ZNonCycRecD3Valid:					1;			
	ULONG 	b01ZNonCycRecD4Valid:					1;			
	ULONG 	b01ZNonCycRecD5Valid:					1;			
	ULONG 	b01ZNonCycRecD6Valid:					1;			
	ULONG 	b1AZReserved1:							26;			
} RDISENDIS_TAG;

typedef struct _RDISENDIS_ENBL_TAG {
	ULONG 	b01ZNonCycRecD1ValidEnable:				1;			
	ULONG 	b01ZNonCycRecD2ValidEnable:				1;			
	ULONG 	b01ZNonCycRecD3ValidEnable:				1;			
	ULONG 	b01ZNonCycRecD4ValidEnable:				1;			
	ULONG 	b01ZNonCycRecD5ValidEnable:				1;			
	ULONG 	b01ZNonCycRecD6ValidEnable:				1;			
	ULONG 	b1AZReserved1:							26;			
} RDISENDIS_ENBL_TAG;

typedef struct _NSRINT_TAG {
	ULONG 	b01ZNonCycRecD1Break:					1;			
	ULONG 	b01ZNonCycRecD2Break:					1;			
	ULONG 	b01ZNonCycRecD3Break:					1;			
	ULONG 	b01ZNonCycRecD4Break:					1;			
	ULONG 	b01ZNonCycRecD5Break:					1;			
	ULONG 	b01ZNonCycRecD6Break:					1;			
	ULONG 	b01ZTimerFrmBreak:						1;			
	ULONG 	b01ZMyStaTknFrmRecBreak:				1;			
	ULONG 	b01ZCntlMstTknFrmRecBreak:				1;			
	ULONG 	b17ZReserved1:							23;			
} NSRINT_T;

typedef struct _NSRINTMS_TAG {
	ULONG 	b01ZNonCycRecD1BreakMask:				1;			
	ULONG 	b01ZNonCycRecD2BreakMask:				1;			
	ULONG 	b01ZNonCycRecD3BreakMask:				1;			
	ULONG 	b01ZNonCycRecD4BreakMask:				1;			
	ULONG 	b01ZNonCycRecD5BreakMask:				1;			
	ULONG 	b01ZNonCycRecD6BreakMask:				1;			
	ULONG 	b01ZTimerFrmBreakMask:					1;			
	ULONG 	b01ZMyStaTknFrmRecBreakMask:			1;			
	ULONG 	b01ZCntlMstTknFrmRecBreakMask:			1;			
	ULONG 	b17ZReserved1:							23;			
} NSRINTMS_TAG;

typedef struct _MST_REFRESH_CYCLE_TAG {
	ULONG 	b08ZMstRefreshCycleEnd:					8;			
	ULONG 	b18ZReserved1:							24;			
} MST_REFRESH_CYCLE_TAG;

typedef struct _TIME_CONT_TAG {
	ULONG	b01ZTimerControl:						1;			
	ULONG	b1FZReserved1:							31;			
} TIME_CONT_TAG;

typedef struct _MWT_TIM_TAG {
	ULONG	b0FZCntlMstWatchTmrTmoutSet:			15;			
	ULONG	b11ZReserved1:							17;			
} MWT_TIM_TAG;

typedef struct _MWT_ST_TAG {
	ULONG	b0FZCntlMstWatchTmrCounter:				15;			
	ULONG	b11ZReserved1:							17;			
} MWT_ST_TAG;

typedef struct _MWT_CONT_TAG {
	ULONG	b01ZCntlMstWatchTmrStart:				1;			
	ULONG	b1FZReserved1:							31;			
} MWT_CONT_TAG;

typedef struct _TIME2_CONT_TAG {
	ULONG	b01ZTimer2Control:						1;			
	ULONG	b1FZReserved1:							31;			
} TIME2_CONT_TAG;

typedef struct _CYCFLG_TAG {
	ULONG	b01Received			:			1;			
	ULONG	bFZDummy1:						31;			
} CYCFLG_T;

typedef struct _RX_TAG {
	union _ITMRCVE {													
		ULONG					DATA;
		ITMRCVE_TAG				BIT;
	} ITMRCVE;
	union _ITRCVE {														
		ULONG					DATA;
		ITRCVE_TAG				BIT;
	} ITRCVE;
	union _ITMRCV {														
		ULONG					DATA;
		ITMRCV_TAG				BIT;
	} ITMRCV;
	union _ITRCV {														
		ULONG					DATA;
		ITRCV_TAG				BIT;
	} ITRCV;
	union _ERMAKE {														
		ULONG					DATA;
		ERMAKE_TAG				BIT;
	} ERMAKE;
	FIFOSTS_TAG					FIFOSTS;								
	ULONG						ulZReserved10018[(0x015C-0x0018)/4];	
	CYCRXFIFO_ALF_TAG			CYCRXFIFO_ALF;							
	ULONG						ulZReserved10160[(0x0200-0x0160)/4];	
	ULONG						ulSTGURANTEN_F;							
	ULONG						CYC_MASTER_ID_RCV;						
	union _CYCSTS_F {													
		ULONG					DATA;
		CYCSTS_F_TAG			BIT;
	} CYCSTS_F;
	ULONG						ulCyclicRecNomalFrameCntF;				
	ULONG						ulZReserved0210[(0x0260-0x0210)/4];		
	ULONG						ulCYCFLG_A;								
	ULONG						ulZReserved0264[(0x0280-0x0264)/4];		
	ULONG						ulCYCFLG_B;								
	ULONG						ulZReserved0284[(0x02A0-0x0284)/4];		
	ULONG						ulCYCFLGCLR_F;							
	ULONG						ulZReserved0244[(0x02C0-0x02A4)/4];		
	ULONG						ulZReserved02C0[(0x02E0-0x02C0)/4];		
	RX_BANK_SWITCH_MODE_TAG		RX_BANK_SWITCH_MODE;					
	RX_BANK_STS_TAG				RX_BANK_STS;							
	ULONG						ulRX_BANK_SWITCH;						
	ULONG						ulZReserved02EC[(0x0300-0x2EC)/4];		
	ULONG						ulRY1_SQNUM_1;							
	ULONG						ulRY1_FMB_INFO;							
	ULONG						ulRY1CYC_DSIZE;							
	ULONG						ulRY1FM_OFFSET_1;						
	ULONG						ulRWw1_SQNUM_1;							
	ULONG						ulRWw1CYC_DSIZE;						
	ULONG						ulRWw1FM_OFFSET_1;						
	ULONG						ulZReserved031C[(0x0400-0x31C)/4];		
	ULONG						ulRDISENDIS;							
	ULONG						ulZReserved0404[(0x0420-0x404)/4];		
	union _NSRINT {														
		ULONG					DATA;
		NSRINT_T				BIT;
	} NSRINT;
	union _NSRINTMS {													
		ULONG					DATA;
		NSRINTMS_TAG			BIT;
	} NSRINTMS;
	BUFEMPINF_TAG				BUFEMPINF;								
	ULONG						ulZReserved042C[(0x0430-0x042C)/4];		
	NRXFIFO_ALF_TAG				NRXFIFO_ALF;							
	ULONG						ulNonCyclicRecValidCnt;					
	ULONG						ulNonCyclicRecRejectCnt;				
	ULONG						ulZReserved043C[(0x0440-0x043C)/4];		
	ULONG						ulGroupAddress;							
	ULONG						ulLastSAAddress1;						
	ULONG						ulLastSAAddress2;						
	MST_REFRESH_CYCLE_TAG		MST_REFRESH_CYCLE;						
	ULONG						ulRCNTENDIS;			
	ULONG						ulNRPRWPCLR;							
	ULONG						ulZReserved0458[(0x1004-0x0458)/4];	
	ULONG						ulTimeCountL;							
	ULONG						ulTimeCountH;							
	ULONG						ulZReserved100C[(0x1010-0x100C)/4];		
	ULONG						ulMWT_TIM;								
	MWT_ST_TAG					MWT_ST;									
	ULONG						ulMWT_CONT;								
	ULONG						ulZReserved101C[(0x1020-0x101C)/4];		
	TIME2_CONT_TAG				TIME_CONT2;								
	ULONG						ulTime2CountL;							
	ULONG						ulTime2CountH;							
	ULONG						ulZReserved102C[(0x2000-0x102C)/4];		
} RX_T;


#endif	/* __R_IN32M4_4_H_INCLUDED_ */
