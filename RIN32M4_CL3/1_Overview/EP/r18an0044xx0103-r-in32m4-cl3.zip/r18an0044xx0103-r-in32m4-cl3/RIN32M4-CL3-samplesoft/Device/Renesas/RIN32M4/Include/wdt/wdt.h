/**
 *******************************************************************************
 * @file  wdt.h
 * @brief Watchdog timer driver header
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	WDT_H__
#define	WDT_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
ER_RET wdt_init(void);									/* Initialize */
ER_RET wdt_interrupt_init(void);						/* Initialize */
ER_RET wdt_start(void);									/* WDT start */
ER_RET wdt_clear(void);									/* Counter clear */
void   wdt_wait_reset(void);							/* Wait for overflow and reset */
#endif /* WDT_H__ */
