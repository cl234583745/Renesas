/**
 *******************************************************************************
 * @file  main.c
 * @brief interval timer sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>
#include <time.h>

#include "RIN32M4.h"
#include "../board_init.h"
#include "uart/uart.h"
#include "timer/timer.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
static __IO uint8_t interval_int_flag;	/* Each bit shows interrupt of timer */

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************
  @brief  Main
  @param  -
  @return unreachable
 *******************************************************************************
*/
int main(void)
{
	uint8_t  ch;					// Channel of timer
	uint32_t i_time;				// interval time (ms)
	uint32_t elapsed_time;			// elapsed time (ms)
	uint32_t interval_count;		// count the number of interval
	
	//=========================================
	// Initialize
	//=========================================
	/* LED */
	board_init();

	/* Parameter */
	ch       = 3;					// CH of timer
	i_time   = 100;					// interval time (ms)

	/* Interval timer */
	timer_interval_init(ch,i_time);

	/* UART */
	uart_init(SYS_UART_CH);

	/* flag */
	interval_int_flag = 0;

	/* Counter & time */
	interval_count = 0;
	elapsed_time = 0;

	//=========================================
	// Opning message
	//=========================================
    rin_boot_message();
	printf("\n");
	printf("Interval timer Sample\n");

	//=========================================
	// Timer start
	//=========================================
	if (ER_OK != timer_start(ch))
	{
		printf("  timer_start(): ERROR of PARAMETER(ch)...\n");
		while (1);
	}

	//=========================================
	// Main loop
	//=========================================
	while (1)
	{
		//=========================================
		// Stop or restart timer
		//=========================================
		/* Check UART to stop timer */
		if (uart_check_receivedata(SYS_UART_CH) == 1)
		{
			uint8_t c;

			/* read UART */
			(void)uart_read(SYS_UART_CH,&c);
			if ((c == 's')||(c == 'S'))
			{
				/* Check timer activation */
				if( timer_check_act(ch) == 1 )			// count operation enable
				{
					/* Stop interval timer */
					timer_stop(ch);
					printf("\n");
					printf("Interval timer STOP. \n");
				}
				else
				{
					/* Restart interval timer */
					timer_start(ch);
					printf("\n");
					printf("Interval timer RESTART.\n");
				}
			}
			else
			{
				/* noting to do */
			}
		}
		//=========================================
		// Check timer interrupt
		//=========================================
		if(interval_int_flag)
		{
			/* Calculate elapsed time (ms) */
			interval_count++;
			elapsed_time = interval_count * i_time;

			/* output to terminal */
			printf(" %6lu [ms] \r", elapsed_time);

			/* clear interval_int_flag */
			interval_int_flag = 0;
		}
	}
}
/**
 ******************************************************************************
  @brief Interval Timer interrupt handler
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I0_IRQHandler( void )
{
	uint8_t led = get_board_led();

	/* invert LED */
	set_board_led(led ^ (1 << 0));
	/* set flag */
	interval_int_flag |= (1 << 0);

	__DSB();		// Errata work aruond - ID:838869
}
/**
 ******************************************************************************
  @brief Interval Timer interrupt handler
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I1_IRQHandler( void )
{
	uint8_t led = get_board_led();

	/* invert LED */
	set_board_led(led ^ (1 << 1));
	/* set flag */
	interval_int_flag |= (1 << 1);

	__DSB();		// Errata work aruond - ID:838869
}
/**
 ******************************************************************************
  @brief Interval Timer interrupt handler
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I2_IRQHandler( void )
{
	uint8_t led = get_board_led();
	/* invert LED */
	set_board_led(led ^ (1 << 2));
	/* set flag */
	interval_int_flag |= (1 << 2);

	__DSB();		// Errata work aruond - ID:838869
}
/**
 ******************************************************************************
  @brief Interval Timer interrupt handler
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I3_IRQHandler( void )
{
	uint8_t led = get_board_led();

	/* invert LED */
	set_board_led(led ^ (1 << 3));
	/* set flag */
	interval_int_flag |= (1 << 3);

	__DSB();		// Errata work aruond - ID:838869
}
