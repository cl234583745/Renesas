#ifndef ETH_CFG_H
#define ETH_CFG_H

/* Ether Driver Configuration */

/* uNet3 TCP/IP protocol stack */
#define USE_UNET3               1 /* 0:not use 1:use(Default) */

/* PHY Address */
#define PHY_ADR0                0
#define PHY_ADR1                1

/* PHY Ability */
#define ETH_PHY_MODE            LAN_AUTO_ABILITY

/* Address Filtering mode */
#define PROMISCUOUS_FILTER_MODE 1 /* 0:Receive all frame 1:Station only(Default) */

/* Multicast Filtering mode */
#define MULTICAST_FILTER_MODE   1 /* 0:Receive m/c 1:not receive m/c(Default) */

/* Early transmit enable */
#define ETH_EARLY_TX_ENA        1 /* 0:Disable(Detect TX Result) 1:enable(Default) */

/* Transmit blocking mode */
#define ETH_TX_ASYNC            1 /* 0:Blocking mode(call TX function) 1:tx non-blocking mode(Default)*/

/* Frame Buffer type */
#define FRAM_USE_BUFFER_RAM     1 /* 0:Use CPU DATA RAM 1:use BUFFER RAM(Default) */

/* EtherSwitch mode */
#define USE_ETHSW               0 /* 0:not use EtherSwitch 1:use EtherSwitch(Default) */
#define USE_ETHSW_MGTAG         0 /* 0:not use EtherSwitch management TAG 1:use EtherSwitch management TAG(Default) */

/* Ether statistics */
#define STATISTICS_ENA          1 /* 0:not measure 1:measure the statistics */

#endif
