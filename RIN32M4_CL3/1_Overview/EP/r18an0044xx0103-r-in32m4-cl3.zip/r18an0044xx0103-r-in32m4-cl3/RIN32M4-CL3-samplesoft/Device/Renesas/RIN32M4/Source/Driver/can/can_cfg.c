/**
 *******************************************************************************
 * @file  can_cfg.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/*
 *		Device information
 */
RIN_CAN_TypeDef* RIN_CAN[CAN_CH_NUM] = {
	(RIN_CAN_TypeDef *)RIN_CAN0_BASE,
	(RIN_CAN_TypeDef *)RIN_CAN1_BASE
};

/*
 *		CAN channel setting
 */
const CAN_CHINFO_TypeDef	can_ch_info[CAN_CH_NUM] = {
	/* Channel 0 (CAN_CH0) */
	{
		/*
		 *- Channel  use
		 *- CAN channel management number = 0
		 */
		CAN_CH_USE | 0x00,
		/* CMIECTL */
		CAN_CMIECTL_SET_TRXABT	|	\
		CAN_CMIECTL_SET_WAKUP	|	\
		CAN_CMIECTL_SET_ARBLST	|	\
		CAN_CMIECTL_SET_PRTERR	|	\
		CAN_CMIECTL_SET_ERRSTS	|	\
		CAN_CMIECTL_SET_RX		|	\
		CAN_CMIECTL_SET_TX
	},
	/* Channel 1 (CAN_CH1) */
	{
		/*
		 *- Channel  use
		 *- CAN channel management number = 0
		 */
		CAN_CH_USE | 0x01,
		/* CMIECTL */
		CAN_CMIECTL_SET_TRXABT	|	\
		CAN_CMIECTL_SET_WAKUP	|	\
		CAN_CMIECTL_SET_ARBLST	|	\
		CAN_CMIECTL_SET_PRTERR	|	\
		CAN_CMIECTL_SET_ERRSTS	|	\
		CAN_CMIECTL_SET_RX		|	\
		CAN_CMIECTL_SET_TX
	}
};

/* Information of baud rate setting */
const CAN_BPSINFO_TypeDef		can_bps_info[CAN_CH_NUM] = {
	/* Channel 0 (CAN_CH0) */
	{/* 1Mbps */
		/* FCNnGMCSPRE */
		0x01,
		/* FCNnCMBRPRS */
		0x04,
		/* FCNnCMBTCTL */
		0x0304
	},
	/* Channel 1 (CAN_CH1) */
	{/* 1Mbps */
		/* FCNnGMCSPRE */
		0x01,
		/* FCNnCMBRPRS */
		0x04,
		/* FCNnCMBTCTL */
		0x0304
	}
};

/* Information of mask setting */
const uint32_t		can_msg_msk_info[CAN_CH_NUM][CAN_NUM_OF_MASK] = {
	/* Channel 0 (CAN_CH0) */
	{
		/* Mask1 */
		0x1FFFFFFF,
		/* Mask2 */
		0x1FFFFFFF,
		/* Mask3 */
		0x1FFFFFFF,
		/* Mask4 */
		0x1FFFFFFF,
		/* Mask5 */
		0x1FFFFFFF,
		/* Mask6 */
		0x1FFFFFFF,
		/* Mask7 */
		0x1FFFFFFF,
		/* Mask8 */
		0x1FFFFFFF
	},
	/* Channel 1 (CAN_CH1) */
	{
		/* Mask1 */
		0x1FFFFFFF,
		/* Mask2 */
		0x1FFFFFFF,
		/* Mask3 */
		0x1FFFFFFF,
		/* Mask4 */
		0x1FFFFFFF,
		/* Mask5 */
		0x1FFFFFFF,
		/* Mask6 */
		0x1FFFFFFF,
		/* Mask7 */
		0x1FFFFFFF,
		/* Mask8 */
		0x1FFFFFFF
	}
};

/*
 *		CAN message buffer setting
 */
const CAN_MSGINFO_TypeDef	can_msg_info[CAN_CH_NUM][CAN_MSG_BUF_NUM] = {
		/* FCNnMmMID0W			FCNnMmSTRB			FCNnMmDTLGB		*/
	{/* Channel 0 (CAN_CH0) */
	/*- CAN message buffer management number = 0 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 1 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 2 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 3 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 4 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 5 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 6 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 7 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 8 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 9 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 10 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 11 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 12 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 13 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 14 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 15 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 16 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 17 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 18 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 19 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 20 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 21 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 22 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 23 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 24 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 25 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 26 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 27 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 28 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 29 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 30 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 31 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 32 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 33 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 34 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 35 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 36 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 37 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 38 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 39 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 40 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 41 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 42 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 43 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 44 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 45 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 46 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 47 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 48 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 49 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 50 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 51 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 52 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 53 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 54 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 55 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 56 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 57 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 58 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 59 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 60 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 61 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 62 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 63 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	},
		/* FCNnMmMID0W			FCNnMmSTRB			FCNnMmDTLGB		*/
	{/* Channel 1 (CAN_CH1) */
	/*- CAN message buffer management number = 0 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 1 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 2 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 3 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 4 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 5 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 6 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 7 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 8 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 9 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 10 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 11 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 12 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 13 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 14 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 15 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 16 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 17 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 18 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 19 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 20 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 21 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 22 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 23 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 24 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 25 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 26 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 27 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 28 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 29 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 30 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 31 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_TX,		0x08},
	/*- CAN message buffer management number = 32 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 33 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 34 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 35 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 36 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 37 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 38 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 39 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 40 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 41 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 42 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 43 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 44 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 45 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 46 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 47 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 48 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 49 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 50 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 51 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 52 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 53 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 54 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 55 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 56 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 57 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 58 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 59 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 60 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 61 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 62 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	/*- CAN message buffer management number = 63 */
		{ CAN_SET_STD_ID(0),	CAN_MSGBUF_INI_RX,		0x00},
	}
};
