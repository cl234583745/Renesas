/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_intr.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_intr_l.h"
#include "R_IN32D_phy_l.h"


ERRCODE erR_IN32D_InitIntrAfterReset( VOID )
{
	USHORT	usTemp;


	INTRST->NMIM.usDATA = NMIM_ALLINTMASK;		
	INTRST->NMI.usDATA = NMI_ALLINTCLR;			
	if ( R_IN32_TRUE == gstR_IN32U.blNMIUse ) {
		usTemp = INTRST->NMIM.usDATA;
		usTemp &= (USHORT)(~NMIM_INTERNALWDT);
		INTRST->NMIM.usDATA = usTemp;
	}
	else {
	}


	(VOID)erR_IN32D_MaskINT1_2All();
	__BUS_RELEASE();

	(VOID)erR_IN32D_MaskSYNCINTLAll();

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_ClearINT1_2All( VOID )
{

	TX->TX_INTL.DATA = INTL_INTCLR;
	RX->ITRCV.DATA = ITRCV_INTCLR;
	RX->NSRINT.DATA = NSRINT_INTCLR;


	RING->ulInt2  = INT2_INTCLR;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_ClearSYNCINTLAll( VOID )
{
	SC->R_SYNCINT.uniR_SYNCINT.ulDATA = R_SYNCINT_INTCLR;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_MaskINT1_2All( VOID )
{

	RX->NSRINTMS.DATA = NSRINTMS_ALLINTMASK_FULL;

	INTRST->INTM1.usDATA = INTM1_ALLINTMASK_FULL;


	RING->ulIntM2 = INTM2_ALLINTMASK_FULL;


	INTRST->INTM.usDATA = INTM_ALLINTMASK_FULL;
	RX->ITMRCV.DATA = ITRCV_ALLINTMASK_FULL;
	__BUS_RELEASE();
	TX->TX_INTLMSK.DATA = INTLMSK_ALLINTMASK_FULL;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_MaskSYNCINTLAll( VOID )
{
	SC->R_SYNCHINTMSK.uniR_SYNCHINTMSK.ulDATA = R_SYNCHINTMSK_ALLINTMASK_FULL;
	SC->R_SYNCSINTMSK.uniR_SYNCSINTMSK.ulDATA = R_SYNCSINTMSK_ALLINTMASK_FULL;

	INTRST->INTM.usDATA = INTM_ALLINTMASK_FULL;
	INTRST->SYNCINTLM.usDATA = SYNCINTLM_ALLINTMASK_FULL;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_UnMaskINT1_2( VOID )
{


	if ( R_IN32_TRUE == gstR_IN32U.blTransientReceiveEnable ) {	
							  
		INTRST->INTM1.usDATA = ((USHORT)~( 
											  INTM1_SNDLOWPRIINT			
											| INTM1_RCVLOWPRIINT));			
		TX->TX_INTLMSK.DATA =  ((ULONG)~( INTL_NONCYCLICSNDENDINT));		
	}
	else {
		
		INTRST->INTM1.usDATA = ((USHORT)~( INTM1_RCVLOWPRIINT ));			
		
	}
	
	RX->NSRINTMS.DATA = ((ULONG)~( NSRINTMS_MYSTARCVTKNFRMMASK ));			
	RX->ITMRCV.DATA = ((ULONG)~(
									  ITRCV_NONCYCLICRECVINT 				
									| ITRCV_MASTERWATCHTIMERTIMEOUTINT ));	
	
	
	RING->ulIntM2 = ((ULONG)~(												
						  INTM2_REG_PERSUASION_REC_MSK						
						| INTM2_REG_SETUP_REC_ACK_MSK						
						| INTM2_REG_LEAVE_TIMEOUT_MSK ));					
						
	if ( R_IN32_TRUE == gstR_IN32U.blInterruptUse ) {
		
		INTRST->INTM.usDATA = ((USHORT)~( 
											  INTM_INT2MASK					
											| INTM_INT2MASK ));				
	}
	else {
		
		INTRST->INTM.usDATA = ((USHORT)~( INTM_INT1MASK ));					
	}

	return( R_IN32D_OK );
	
}

ERRCODE erR_IN32D_UnMaskInSYNCINTL( VOID )
{

	SC->R_SYNCHINTMSK.uniR_SYNCHINTMSK.ulDATA &= (ULONG)~(
														R_SYNCHINTMSK_COMM_SWITCH_INT );

	SC->R_SYNCSINTMSK.uniR_SYNCSINTMSK.ulDATA &= (ULONG)~(
														R_SYNCSINTMSK_SYNC_SWITCH_INT );

	INTRST->INTM.usDATA &= (USHORT)~(
							 		INTM_INT3MASK );

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_UnMaskOutSYNCINTL( VOID )
{

	if ( R_IN32_TRUE == gstR_IN32U.blSynchronousInterruptUse ) {
		SC->R_SYNCSINTPC.b01ZPulseIntPulseWidth = R_SYNCSINTPC_PULSE_WIDTH_640NS;
		SC->R_SYNCSINTPC.b01ZSyncIntSigSelect = R_SYNCSINTPC_NOTICE_PULSE;

		INTRST->SYNCINTLM.usDATA = (USHORT)~(
								  			SYNCINTLM_SYNCINTMASK );	
	}

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchINT1_2(
	R_IN32D_INTR_SOURCE_T*	pstIntrSource	
)
{
	do {
	pstIntrSource->uniITRCV.ulAll		= RX->ITRCV.DATA;
	__BUS_RELEASE();
	pstIntrSource->uniTX_INTL.ulAll		= TX->TX_INTL.DATA;
		pstIntrSource->uniNSRINT.usAll		= RX->NSRINT.DATA;

}
	while((pstIntrSource->uniITRCV.ulAll  != RX->ITRCV.DATA) ||
		  (pstIntrSource->uniTX_INTL.ulAll != TX->TX_INTL.DATA)||
		  (pstIntrSource->uniNSRINT.usAll != RX->NSRINT.DATA));

	pstIntrSource->uniINT2.ulAll		= RING->ulInt2;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchSYNCINTL(
	R_IN32D_SYNCINTR_SOURCE_T*	pstSyncIntrSource
)
{
	pstSyncIntrSource->uniSYNCINT.ulAll = SC->R_SYNCINT.uniR_SYNCINT.ulDATA;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_ClearINT1_2(
	R_IN32D_INTR_SOURCE_T*	pstIntrSource		
)
{
	RX->ITRCV.DATA = pstIntrSource->uniITRCV.ulAll;
	TX->TX_INTL.DATA = pstIntrSource->uniTX_INTL.ulAll;
	RX->NSRINT.DATA = pstIntrSource->uniNSRINT.usAll;
	__BUS_RELEASE();

	RING->ulInt2 = pstIntrSource->uniINT2.ulAll;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_ClearSYNCINTL(
	R_IN32D_SYNCINTR_SOURCE_T*	pstSyncIntrSource
)
{
	SC->R_SYNCINT.uniR_SYNCINT.ulDATA = pstSyncIntrSource->uniSYNCINT.ulAll;

	return( R_IN32D_OK );
}

/*** EOF ***/
