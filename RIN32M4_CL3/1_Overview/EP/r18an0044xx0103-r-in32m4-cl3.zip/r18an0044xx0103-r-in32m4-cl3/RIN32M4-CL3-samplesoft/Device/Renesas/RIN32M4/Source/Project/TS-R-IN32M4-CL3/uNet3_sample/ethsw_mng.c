/**
 *******************************************************************************
 * @file  ethsw_mng.c
 * @brief Ethernet switch port manage driver program
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#include "RIN32M4.h"
#include "kernel.h"
#include "kernel_id.h"
#include "net_hdr.h"
#include "net_def.h"
#include "DDR_ETH_CFG.h"

#include "ether_unet3/DDR_ETH.h"
#include "ethsw/ethsw.h"


void eth_raw_rcv_cb(VP frm , UH len)
{
    T_ETH_HDR* ethh;
    T_NET_BUF* frmBuf;
    UH          ethType;

    ethh = (T_ETH_HDR *)frm;
    ethType = htons(ethh->type);

    // IEEE802.3 & LLDP-Frame only recieved
    if(!(ethType < 0x0800 || ethType == 0x88CC))
    {
        return;
    }

    if (E_OK != net_buf_get(&frmBuf, len, TMO_POL))
    {
        return;
    }
    net_memcpy(frmBuf->hdr , frm , len);
    frmBuf->hdr_len = len;

    if(E_OK != snd_mbx(ID_MBX_ETH_RAW_RCV,(T_MSG*)frmBuf))
    {
        net_buf_ret(frmBuf);
    }
} /* eht_raw_rcv_cb() */

ER eth_raw_init(UH dev_num)
{
    ER ercd;

    if (dev_num == 0) {
        return E_ID;
    }

    ercd = net_dev_ctl(1, ETH_OPT_RAW_RXFNC, (VP)eth_raw_rcv_cb);
    if(ercd != E_OK)
    {
        return ercd;
    }

    ercd = sta_tsk(ID_TASK_ETH_RAW_RCV, (VP_INT)dev_num);
    if (ercd != E_OK) {
        return ercd;
    }

    return E_OK;
} /* eth_raw_init() */


extern ER tx_frame(T_NET_BUF *pkt , UB port);

ER eth_raw_snd(T_NET_BUF *pkt , UB port)
{
    return tx_frame(pkt , port);
} /* eth_raw_snd() */

void eth_raw_rcv_tsk(int exinf)
{
    T_NET_BUF* frmBuf;
    T_NET_BUF* pkt;
    T_ETH_HDR* ethh;
    T_NET *net;
    UB  srcMacAddr[6];
    UB  srcPort;
    UH  ethType;
    UB* buf;

    net = &gNET[exinf-1];
    while(1)
    {
        if (E_OK != rcv_mbx(ID_MBX_ETH_RAW_RCV,(T_MSG**)&frmBuf)){
            ext_tsk();
        }
        ethh = (T_ETH_HDR*)frmBuf->hdr;
        ethType = htons(ethh->type);
        /* get source Mac Address & port */
        net_memcpy(srcMacAddr , ethh->sa , 6);
#if (USE_ETHSW & USE_ETHSW_MGTAG)
        srcPort = (ethh->da[4] >> 7 & 0x1);
#endif  /* USE_ETHSW & USE_ETHSW_MGTAG */

        /* Make Response Data */
        if (E_OK != net_buf_get(&pkt, 2048, TMO_POL))
        {
            net_buf_ret(frmBuf);
            continue;
        }
        pkt->hdr += net->dev->hhdrofs;
        /* Ether Header */
        ethh = (T_ETH_HDR*)pkt->hdr;
        net_memcpy(ethh->sa , net->dev->cfg.eth.mac, 6);
        net_memcpy(ethh->da , srcMacAddr, 6);
        ethh->type = htons(ethType);
        /* Frame */
        buf = (UB *)(pkt->hdr + ETH_HDR_SZ);
        net_memcpy(buf , (frmBuf->hdr + ETH_HDR_SZ) , (frmBuf->hdr_len - ETH_HDR_SZ));

        pkt->hdr_len = frmBuf->hdr_len;
        
#if (USE_ETHSW & USE_ETHSW_MGTAG)
        if(srcPort){
            srcPort = FFW_PORT1;
        }else{
            srcPort = FFW_PORT0;
        }
#else
        srcPort = FFW_NON;
#endif  /* USE_ETHSW & USE_ETHSW_MGTAG */

        eth_raw_snd(pkt , srcPort);
        net_buf_ret(frmBuf);
        net_buf_ret(pkt);
    }
} /* eth_raw_rcv_tsk() */

