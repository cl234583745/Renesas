/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Library.c                                                 */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE	erR_IN32C_ClrMACAddrTbl(VOID);


ERRCODE gerR_IN32C_GetTDIS(
	USHORT usSize,					
	VOID** ppvSendFrmAddr,			
	UCHAR* puchTDISNo,				
	UCHAR* puchNonCyclicSendCnt		
)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;

	erRet2 = erR_IN32C_GetTranTDIS_DisableInt(usSize, ppvSendFrmAddr, puchTDISNo);

	if (R_IN32D_OK != erRet2) {
		erRet = R_IN32C_NG_OTHER;
	}
	else {
		gstR_IN32C.stMain.uchNonCyclicSendCnt++;
		if (gstR_IN32C.stMain.uchNonCyclicSendCnt == 0) { 
			gstR_IN32C.stMain.uchNonCyclicSendCnt = 1;
		}
		*puchNonCyclicSendCnt = gstR_IN32C.stMain.uchNonCyclicSendCnt;
	}


	return erRet;
}

ERRCODE gerR_IN32C_EntryTDIS(
	UCHAR uchTDISNo,	
	USHORT usSize		
)
{
	ERRCODE erRet = R_IN32C_NG_OBJ;
	ERRCODE erRet2;
	R_IN32R_STOPWATCH_T stShortInform;		
	ULONG ulSpendTime;					

	gR_IN32R_StartStopwatchTimer( &stShortInform, 1UL );

	while (1) {

		erRet2 = erR_IN32C_EntryTranTDIS_DisableInt(uchTDISNo, usSize);

		if ((R_IN32D_OK == erRet2) || (R_IN32D_NG == erRet2)) {
			if (R_IN32D_OK == erRet2) {
				erRet = R_IN32C_OK;
			}
			else {
				erRet = R_IN32C_NG_OBJ;
			}
			break;
		}
		else {
		}

		gR_IN32R_GetElapsedTime( &stShortInform, &ulSpendTime );
		if (R_IN32C_TMOUT_TDISENTRY < ulSpendTime) {
			break;
		}
		else {
		}
	}

	return erRet;
}



ERRCODE gerR_IN32C_Start(
	UCHAR uchNetworkNumber,				
	USHORT usStationNumber				
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gstR_IN32C.stInf0.uchNetworkNumber = uchNetworkNumber;
	gstR_IN32C.stInf0.usStationNumber = usStationNumber;

	gR_IN32R_EnableInt();

	if (R_IN32C_STS_WAITSTART == gstR_IN32C.stMain.ulState) {
		erRet = R_IN32C_OK;
	}
	else {
		erRet = R_IN32C_NG_OBJ;
	}

	return erRet;
}


ERRCODE gerR_IN32C_GetNumber(
	USHORT* pusStationNumber,	
	UCHAR*  puchNetworkNumber	
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	*puchNetworkNumber = gstR_IN32C.stInf0.uchNetworkNumber;
	*pusStationNumber = gstR_IN32C.stInf0.usStationNumber;
	
	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_GetUnitInfo0(
	R_IN32C_UNITINF0_T* pstUnitInfo0	
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gR_IN32S_Memcpy(pstUnitInfo0, &gstR_IN32C.stInf0, sizeof(R_IN32C_UNITINF0_T));

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_GetUnitInfo1(
	R_IN32_UNITINFO_T*           pstUnitInfo,					
	R_IN32_UNITNETWORKSETTING_T* pstUnitNetworkSetting			
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	pstUnitInfo->ulMaxRySize  = gstR_IN32C.stInf1.ulMaxRySize;  
	pstUnitInfo->ulMaxRWwSize = gstR_IN32C.stInf1.ulMaxRWwSize; 
	pstUnitInfo->ulMaxRxSize  = gstR_IN32C.stInf1.ulMaxRxSize;  
	__BUS_RELEASE();
	pstUnitInfo->ulMaxRWrSize = gstR_IN32C.stInf1.ulMaxRWrSize; 

	pstUnitInfo->ulMyStationPortTotalNumber = gstR_IN32C.stInf1.ulMyStationPortTotalNumber; 
	pstUnitInfo->ulTokenHoldTime            = gstR_IN32C.stInf1.ulTokenHoldTime;            

	pstUnitInfo->ulIOType = gstR_IN32C.stInf1.ulIOType; 
	__BUS_RELEASE();

	pstUnitInfo->ulNetVersion       = gstR_IN32C.stInf1.ulNetVersion;        
	pstUnitInfo->ulNetModelType     = gstR_IN32C.stInf1.ulNetModelType;      
	pstUnitInfo->ulNetUnitModelCode = gstR_IN32C.stInf1.ulNetUnitModelCode;  
	pstUnitInfo->ulNetVendorCode    = gstR_IN32C.stInf1.ulNetVendorCode;     
	gR_IN32S_Memcpy(&pstUnitInfo->auchNetUnitModelName[0],                   
				&gstR_IN32C.stInf1.auchNetUnitModelName[0],
				R_IN32_MODEL_NAME_LENGTH
				);
	gR_IN32S_Memcpy(&pstUnitInfo->auchNetVendorName[0],                      
				&gstR_IN32C.stInf1.auchNetVendorName[0],
				R_IN32_VENDOR_NAME_LENGTH
				);

	pstUnitInfo->blInformationFlag   = (BOOL)gstR_IN32C.stInf1.ulInformationFlag;   
	pstUnitInfo->ulCtrlVersion       = gstR_IN32C.stInf1.ulCtrVersion;              
	pstUnitInfo->ulCtrlModelType     = gstR_IN32C.stInf1.ulCtrModelType;            
	pstUnitInfo->ulCtrlUnitModelCode = gstR_IN32C.stInf1.ulCtrUnitModelCode;        
	__BUS_RELEASE();
	pstUnitInfo->ulCtrlVendorCode    = gstR_IN32C.stInf1.ulCtrVendorCode;           
	gR_IN32S_Memcpy(&pstUnitInfo->auchCtrlUnitModelName[0],                         
				&gstR_IN32C.stInf1.auchCtrUnitModelName[0],
				R_IN32_MODEL_NAME_LENGTH
				);
	gR_IN32S_Memcpy(&pstUnitInfo->auchCtrlVendorName[0],                            
				&gstR_IN32C.stInf1.auchCtrVendorName[0],
				R_IN32_VENDOR_NAME_LENGTH
				);
	pstUnitInfo->ulVendorInformation = gstR_IN32C.stInf1.ulVendorInformation;       

	pstUnitNetworkSetting->ulFrameSendCount    = gstR_IN32C.stInf1.ulTknHoldFrmSendCount;   
	pstUnitNetworkSetting->ulFrameSendInterval = gstR_IN32C.stInf1.ulFramSendInterval;      
	pstUnitNetworkSetting->ulTokenSendCount    = gstR_IN32C.stInf1.ulTokenSendCount;        

	gR_IN32R_EnableInt();

	return erRet;
}


ERRCODE gerR_IN32C_GetCommState(
	ULONG* pulCommSts	
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	if (R_IN32C_STS_CONNECT == gstR_IN32C.stMain.ulState) {
		if (R_IN32C_CYC_STS_RUN == gstR_IN32C.stCyclic.ulState) {
			*pulCommSts = (ULONG)R_IN32C_COMMSTS_CYC_DLINK;
		}
		else {
			*pulCommSts = (ULONG)R_IN32C_COMMSTS_TOKEN_PASS;
		}
	}
	else {
		*pulCommSts = (ULONG)R_IN32C_COMMSTS_DISCONNECT;
	}
		
	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_GetCycStopState(
	R_IN32D_CYCLIC_STA_GET_T* pstCyclicStatus		
)
{
	ERRCODE erRet = R_IN32C_OK;

	pstCyclicStatus->uniCycSta.usAll = gstR_IN32C.stCyclic.stGetStopSts.uniCycSta.usAll;

	return erRet;
}

USHORT gusR_IN32C_GetNodeID(VOID)
{
	return gstR_IN32C.stInf0.usNodeID;
}


ERRCODE gerR_IN32C_GetMulticastMACAddress(
	UCHAR *auchAddr						
)
{
	ERRCODE erRet = R_IN32C_OK;

	if(R_IN32C_STS_CONNECT == gstR_IN32C.stMain.ulState) {
		gR_IN32R_DisableInt();

		gR_IN32S_Memcpy(auchAddr, gstR_IN32C.stInf0.auchMulticastMACAddress, R_IN32_MACADR_SZ);

		gR_IN32R_EnableInt();
	}
	else {
		erRet = R_IN32C_NG_OBJ;
	}
	return erRet;
}

ERRCODE gerR_IN32C_GetMasterUserAppStatus(
	BOOL*  pblMstUsrAppRunSts,			
	BOOL*  pblMstUsrAppErrSts,			
	ULONG* pulMstUsrAppErrCode			
)
{
	ERRCODE erRet = R_IN32C_OK;

	if (R_IN32_TRUE == gstR_IN32C.stMain.blValidMasterMyStatus) {


		gR_IN32R_DisableInt();

		*pblMstUsrAppRunSts = (BOOL)gstR_IN32C.stMain.stMasterMyStatus.ulUserAppRun;

		if (R_IN32_TRUE == gstR_IN32C.stMain.stMasterMyStatus.ulCondition) {
			*pblMstUsrAppErrSts = R_IN32_TRUE;	
		}
		else {
			*pblMstUsrAppErrSts = R_IN32_FALSE;	
		}

		*pulMstUsrAppErrCode = gstR_IN32C.stMain.stMasterMyStatus.ulErrorCode;
	
		gR_IN32R_EnableInt();
	}
	else {
		*pblMstUsrAppRunSts = R_IN32_FALSE;		
		*pblMstUsrAppErrSts = R_IN32_FALSE;		
		*pulMstUsrAppErrCode = 0;
		erRet = R_IN32C_NG_NOMYSTATUS;
	}

	return erRet;
}


ERRCODE erR_IN32C_SetMIB(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;

	if (R_IN32_FALSE == gstR_IN32C.stMain.blMACIPAccessSem) {

		gstR_IN32C.stMain.blMACIPAccessSem = R_IN32_TRUE;

		erRet2 = erR_IN32C_MacIp_AccessEnable_DisableInt();

		if (R_IN32D_OK == erRet2) {

			if (R_IN32_TRUE == gstR_IN32C.stMIB.ulClearRequest) {

				(VOID)gerR_IN32D_ClearMacIpMIB();

				(VOID)gerR_IN32D_MacIp_AccessDisable();

				(VOID)gerR_IN32D_ClearRingMIB();

				(VOID)erR_IN32C_InitLocalMIB();

				gstR_IN32C.stMIB.ulClearRequest = R_IN32_FALSE;	
			}
			else {

				(VOID)gerR_IN32D_GetMIB_MACIP(R_IN32D_PORT1,&gstR_IN32C.stMIB.stInf1.stMACIP);
				(VOID)gerR_IN32D_GetMIB_MACIP(R_IN32D_PORT2,&gstR_IN32C.stMIB.stInf2.stMACIP);

				(VOID)gerR_IN32D_MacIp_AccessDisable();

				(VOID)gerR_IN32D_GetMIB_SDRD(&gstR_IN32C.stMIB.stInf0);
				(VOID)gerR_IN32D_GetMIB_RGCNT(R_IN32D_PORT1,&gstR_IN32C.stMIB.stInf1.stRGCNT);
				(VOID)gerR_IN32D_GetMIB_RGCNT(R_IN32D_PORT2,&gstR_IN32C.stMIB.stInf2.stRGCNT);

				gstR_IN32C.stMIB.stInf0Accum.ulCyclicRecNomalFrameCnt += gstR_IN32C.stMIB.stInf0.ulCyclicRecNomalFrameCnt;
				gstR_IN32C.stMIB.stInf0Accum.ulNonCyclicRecValidCnt += gstR_IN32C.stMIB.stInf0.ulNonCyclicRecValidCnt;
				gstR_IN32C.stMIB.stInf0Accum.ulNonCyclicRecRejectCnt += gstR_IN32C.stMIB.stInf0.ulNonCyclicRecRejectCnt;
			}
		}
		else {
			(VOID)erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();

			(VOID)gerR_IN32D_MacIp_AccessDisable();

			erRet = R_IN32C_NG_OTHER;
		}

		gstR_IN32C.stMain.blMACIPAccessSem = R_IN32_FALSE;

	}
	else {
		erRet = R_IN32C_NG_OBJ;
	}

	return erRet;
}


ERRCODE gerR_IN32C_GetErrorCount(
	R_IN32C_ERRCNT_T *pstErrCnt 
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gR_IN32S_Memcpy(&pstErrCnt->stSDRD, &gstR_IN32C.stMIB.stInf0Accum, sizeof(R_IN32D_MIBSDRD_T));
	gR_IN32S_Memcpy(&pstErrCnt->stMACIP1, &gstR_IN32C.stMIB.stInf1.stMACIP, sizeof(R_IN32D_MIBMACIP_T));
	gR_IN32S_Memcpy(&pstErrCnt->stMACIP2, &gstR_IN32C.stMIB.stInf2.stMACIP, sizeof(R_IN32D_MIBMACIP_T));
	gR_IN32S_Memcpy(&pstErrCnt->stRING1, &gstR_IN32C.stMIB.stInf1.stRGCNT, sizeof(R_IN32D_MIBRGCNT_T));
	gR_IN32S_Memcpy(&pstErrCnt->stRING2, &gstR_IN32C.stMIB.stInf2.stRGCNT, sizeof(R_IN32D_MIBRGCNT_T));

	pstErrCnt->ulP1DownCounter = gstR_IN32C.stMIB.stInf1c.ulDownCounter;
	pstErrCnt->ulP2DownCounter = gstR_IN32C.stMIB.stInf2c.ulDownCounter;
	pstErrCnt->ulMasterWatchCount = gstR_IN32C.stMIB.ulMasterWatchCount;

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_ClrErrorCount(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gstR_IN32C.stMIB.ulClearRequest = R_IN32_TRUE;


	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_SetMACAddrTblDat(
	UCHAR uchSeqNumber,						
	R_IN32C_MACADDRDAT_T* pstMacAddrDat		
)
{
	ERRCODE	erRet = R_IN32C_OK;
	USHORT 				usStationNumber;
	R_IN32C_MACADDRDAT_T*	pstDst;


	usStationNumber = pstMacAddrDat->usStationNumber;

	if (R_IN32C_MAX_MACDELIVSEQNUM >= uchSeqNumber) {

		if (R_IN32C_MAX_MACADDRTBL > usStationNumber) {	

			if((0 == usStationNumber) || (COM_CUR_MNG_STNO == usStationNumber)){
				usStationNumber = COM_DSG_MNG_STNO;
			}

			if (gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivSeqNumber != uchSeqNumber) {

				(VOID)erR_IN32C_ClrMACAddrTbl();

				gR_IN32R_DisableInt();

				gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivSeqNumber = uchSeqNumber; 

				gR_IN32R_EnableInt();

			}
			else {
			}

			gR_IN32R_DisableInt();

			pstDst = &gstR_IN32C.stMACAddrTbl.astTbl[usStationNumber]; 
			gR_IN32S_Memcpy(pstDst, pstMacAddrDat, sizeof(R_IN32C_MACADDRDAT_T));

			pstDst->usStationNumber = usStationNumber;

			gR_IN32R_EnableInt();

		}
		else {
			erRet = R_IN32C_NG_OUTOFRANGE;
		}
	}
	else {
		erRet = R_IN32C_NG_OUTOFRANGE;
	}

	return erRet;
}

ERRCODE erR_IN32C_ClrMACAddrTbl(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG ulIdx;

	for (ulIdx=0 ; ulIdx<R_IN32C_MAX_MACADDRTBL ; ulIdx++) {
		gR_IN32S_Memset(&(gstR_IN32C.stMACAddrTbl.astTbl[ulIdx]), 0, sizeof(R_IN32C_MACADDRDAT_T));
	}

	return erRet;
}

ERRCODE gerR_IN32C_GetUnicastMACAddr(
	USHORT usStationNumber,				
	UCHAR * auchMACAddr					
)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32C_MACADDRDAT_T* pstTarget;

	if (R_IN32C_MAX_MACADDRTBL > usStationNumber) {

		if((0 == usStationNumber) || (COM_CUR_MNG_STNO == usStationNumber)){
			usStationNumber = COM_DSG_MNG_STNO;
		}

		pstTarget = &gstR_IN32C.stMACAddrTbl.astTbl[usStationNumber];

		if (pstTarget->usStationNumber == usStationNumber) {
			gR_IN32S_Memcpy(auchMACAddr, pstTarget->auchMacAddress, R_IN32_MACADR_SZ);
		}
		else {
			erRet = R_IN32C_NG_NOENTRY;
		}

		if ( R_IN32_OFF == pstTarget->uchTransientRecvMode ) {
			erRet = R_IN32C_NG_NOENTRY;
		}
		else {
		}
	}
	else {
		erRet = R_IN32C_NG_OUTOFRANGE;
	}

	return erRet;
}

ERRCODE gerR_IN32C_SetCPUState(
	ULONG ulRunSts,							
	ULONG ulErrSts,							
	ULONG ulErrCode,						
	ULONG ulMotSyncState,					
	ULONG ulUserInformation					
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gstR_IN32C.stInf0.stSelfStatus.ulCPURunCond      = ulRunSts;
	gstR_IN32C.stInf0.stSelfStatus.ulCPUErrFoundCond = ulErrSts;
	gstR_IN32C.stInf0.ulErrCode                      = ulErrCode;
	gstR_IN32C.stInf0.stSelfStatus.ulCPUSync         = ulMotSyncState;
	gstR_IN32C.stInf0.ulUserInformation              = ulUserInformation;

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_SetRcvEnable(
	BOOL blRcvEnable			
)
{
	ERRCODE erRet = R_IN32C_OK;

	gstR_IN32C.stMain.blRcvEnable = blRcvEnable;

	return erRet;
}

BOOL gblR_IN32C_GetRcvEnable(VOID)
{
	return gstR_IN32C.stMain.blRcvEnable;
}

ERRCODE gerR_IN32C_GetMyMACAddress(
	UCHAR*  puchMac				
)
{
	UCHAR i;
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	for ( i=0; i < 6 ; i++) {
		*(puchMac + i) = gstR_IN32C.stInf0.auchMACAddress[i];
	}
	
	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_GetMotSyncState(
	ULONG* pulSyncStatus			
)
{
	ERRCODE erRet = R_IN32C_OK;

	*pulSyncStatus = gstR_IN32C.stMotSyncCtl.ulSyncStatus;

	return erRet;
}

/*** EOF ***/
