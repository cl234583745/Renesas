/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver user sample code                                   */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include <string.h>

#include "R_IN32M4_sample.h"
#include "R_IN32M4_Transient.h"

#include "R_IN32M4Driver.h"


/****************************************************************************/
/** @brief Callback function to handle fatal error occurred in R_IN32M4        */
/** @retval VOID                                                            */
/****************************************************************************/
VOID gR_IN32_CallbackFatalError(
	ULONG	ulErrorCode,						/**< fatal error code */
	ULONG	ulErrorInfo							/**< fatal error information (address of the function when the error occurred) */
)
{

	/* TODO: add your code to handle fatal error occurred in R_IN32M4 here */

	/* example */
	/* Create a fatal error list */
	if ( USER_FATALERROR_NUM > gulUserFatalErrorNum ) {

		gulUserFatalError[gulUserFatalErrorNum][0] = ulErrorCode;	/* fatal error code */
		gulUserFatalError[gulUserFatalErrorNum][1] = ulErrorInfo;	/* fatal error information (address of the function when the error occurred) */
		gulUserFatalErrorNum ++;									/* the number of fatal errors */
	}
	else {
	}

	return;
}



/****************************************************************************/
/** @brief Callback function to handle command received from master station */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_CallbackCommandFromMaster(
	ULONG pulCommand							/**< command status from master station */
)
{

	/* TODO: add your code to handle command received from master station here */

	return R_IN32_OK;
}




/******************************************************************************/
/** @brief Callback function to handle received transient frame               */
/** @retval R_IN32_OK :Normal end (received transient frame obtained)           */
/** @retval R_IN32_ERR:Abnormal end                                             */
/**        (received transient frame obtaining failed, e.g. buffer full, etc.)*/
/******************************************************************************/
ERRCODE gerR_IN32_CallbackReceivedTransient(
	VOID*	pvRcv,								/**< Received buffer */
	USHORT	usFrameSize							/**< frame size (FCS not included) */
)
{
	ERRCODE	erResult;

	/* TODO: add your code to handle received transient frame here */

	/* example */
	/* Copy the content of receive buffer to the memory for getting transient frame */
	memcpy( &gaulUserReceivedTransient[0], pvRcv, usFrameSize );
	gusUserReceivedTransientSize = usFrameSize;			/* frame size (FCS not included) */
	erResult = R_IN32_ERR;								/* No free space in the memory for getting Transient frame  */

	return erResult;
}



/*************************************************************************************/
/** @brief Callback function to notify the complete status of transient frame sending*/
/** @retval R_IN32_OK :Normal end                                                      */
/*************************************************************************************/
ERRCODE gerR_IN32_CallbackTransientSendingComplete(
	UCHAR	uchSendBuffNo,						/**< transient send buffer number */
	ERRCODE	erSendStatus						/**< transient send buffer status */
)
{

	/* TODO: add your code to notify the complete status of transient frame sending here */

	/* example */
	gstUserTransientSendResult.blFinish = R_IN32_TRUE;			/* Sending completed */
	gstUserTransientSendResult.uchSendBuffNo = uchSendBuffNo;	/* transient send buffer number */
	gstUserTransientSendResult.erSendStatus = erSendStatus;		/* transient send buffer status */

	return R_IN32_OK;
}

/*** EOF ***/
