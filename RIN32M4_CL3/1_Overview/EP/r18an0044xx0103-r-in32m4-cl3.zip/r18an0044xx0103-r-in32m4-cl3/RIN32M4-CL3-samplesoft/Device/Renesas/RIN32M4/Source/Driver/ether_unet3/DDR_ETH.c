/*
    Update
    2013/9/12 : Modify multicast mac addres mode.
                Implement to allow change PHY mode dynamically.
    2014/2/02 : Divide PHY driver to be independent PHY.
    2014/4/21 : Remove processing of board dependent.
    2014/12/12: Changed to be able to specify the forwarding port.
    2014/12/12: Change the path of DDR_ETH_CFG.h.
    2015/01/29: Change MDC output clock rate at EC.
    2015/01/29: Change PHY settings for each port at link events.
    2015/09/11: Add IP Fragment packet check.
    2015/10/20: Add 10HD Enable setting.
    2016/03/09: Add function for statistics of mac.
    2016/03/10: Devide HW_CS flag into ICMP and TCP/UDP
    2017/10/06: Fixed port link status problem.
    2018/11/22: Fixed allocate memory size problem.
*/

#include "RIN32M4.h"
#include "system_RIN32M4.h"
#include "kernel.h"
#include "ether/eth_hwfnc.h"
#include "ether/ether_phy_init.h"


#ifdef LIB_ETHDRIVER
/* defined symbol -> external const variable */
extern ID ID_TASK_ETH_RCV_C;
extern ID ID_TASK_ETH_SND_C;
extern ID ID_FLG_ETH_TX_MAC_C;
extern ID ID_FLG_ETH_RX_MAC_C;
extern ID ID_FLG_SYSTEM_C;
extern ID ID_MBX_ETH_SND_C;
extern ID ID_SEM_INTDMA_C;

#define  ID_TASK_ETH_RCV   ID_TASK_ETH_RCV_C
#define  ID_TASK_ETH_SND   ID_TASK_ETH_SND_C
#define  ID_FLG_ETH_TX_MAC ID_FLG_ETH_TX_MAC_C
#define  ID_FLG_ETH_RX_MAC ID_FLG_ETH_RX_MAC_C
#define  ID_FLG_SYSTEM     ID_FLG_SYSTEM_C
#define  ID_MBX_ETH_SND    ID_MBX_ETH_SND_C
#define  ID_SEM_INTDMA     ID_SEM_INTDMA_C
#else
#include "kernel_id.h"
#endif

#include "DDR_ETH_CFG.h"

#if (USE_UNET3)
#include "net_hdr.h"
  #ifdef STS_SUP
    #include "net_def.h"
    #include "net_sts.h"
    #include "net_sts_id.h"
  #endif
#endif

#include "ether_unet3/DDR_PHY.h"
#include "ether_unet3/DDR_ETH.h"
#include "ethsw/ethsw.h"

#include <stdio.h>
#define ETH_TX_TMO          100

/* DMA TX descriptor */
typedef struct txdsc {
    UINT    bufadr;
    UINT    length;
} TXDSC;

#define TXDSC_NUM           4   /* FrameController, MAC+PAD, IPpayload, Termination */
#define TXDSC_LEN           (sizeof(TXDSC) * TXDSC_NUM)
#define TX_FRAME_CNT_LEN    8

#define MACSEL_ECAT				0x00000001
#define MACSEL_ETHSW			0x00000000
#define MACSEL_DIRECT			0x00000003

#define ETHSW_MODE_GIG			0x00000001	/* GIGA Ethernet */
#define ETHSW_MODE_100M			0x00000000	/* 10/100M Ethernet */
#define ETHSW_MODE_FULL_DUP		0x00000000	/* Full Duplex */
#define ETHSW_MODE_HALF_DUP		0x00000002	/* Half Duplex */

#define ETHSW_10HD_EN			0x00000001	/* 10Mbps Half Duplex Enable */
#define ETHSW_10HD_DS			0x00000000	/* 10Mbps Half Duplex Disable*/

	/* BUID bit assign */
#define BUFID_NOEMP				0x80000000	/* Recieve Buffer Empty	*/
	#define BUF_EMPTY			0
#define BUFID_VALID				0x10000000	/* Recieve Data Valid	*/
	#define DATA_INVALID		0
#define BUFID_WORD				0x0FFF0000	/* Recieve Data Length	*/
#define BUFID_ADDR				0x0000FFFF	/* Recieve Buffer Addr	*/

#define bufid_get_rxaddr(x)		(((x & BUFID_ADDR) << 11) | 0x08000000)
#define bufid_get_rxword(x)		((x & BUFID_WORD) >> 16)

/*31-----------------------------------------------------------0*/
/* |              Destination MAC Address(6Byte)               |*/
/* |----------------------------|                              |*/
/* |                            |------------------------------|*/
/* |              Source MAC Address(6Byte)                    |*/
/* |-----------------------------------------------------------|*/
/* |       Padding(2Byte)       |        Type(2Byte)           |*/
/* |-----------------------------------------------------------|*/
/* |       Payload(Max 1500Byte) & FCS(4Byte)                  |*/
/* |-----------------------------------------------------------|*/
#define ETHFRM_HD_LEN			14						/* Ethernet Header Length			*/
#define ETHFRM_HD_PAD			2						/* Ethernet Header Padding Length	*/
#define ETHFRM_HD_ACTLEN		(ETHFRM_HD_LEN + ETHFRM_HD_PAD)	/* Ethernet Header Actual Length */
#define ETHFRM_FCS_LEN			4
#define IP_HD_FLGS_FO			(ETHFRM_HD_PAD + 0x14)	/* IP Header Flags & FragmentOffset offset */
#define IP_HD_PRTCL				(ETHFRM_HD_PAD + 0x17)	/* IP Header Protocol offset	*/
#define IP_HD_CHKSUM			(ETHFRM_HD_PAD + 0x18)	/* IP Header Checksum offset	*/
#define TCP_HD_CHKSUM			(ETHFRM_HD_PAD + 0x32)	/* TCP Header Checksum offset	*/
#define UDP_HD_CHKSUM			(ETHFRM_HD_PAD + 0x28)	/* UDP Header Checksum offset	*/

#define IPPKT_CRCT				4

	/* PROTCOL No. */
#define IP_PRTCL_TCP			0x6						/* IP protcol TCP				*/
	/* Flags & Fragment Offset */
#define IP_HD_FLGS_MSK			(0xE000)				/* Flags Mask		*/
#define IP_HD_FLGS_DF			(0x4000)				/* Don't Fragment	*/
#define IP_HD_FLSG_MF			(0x2000)				/* More Fragment 	*/
#define IP_HD_FO_MSK			(0x1FFF)				/* Fragment Offset	Mask */

/* Rx Frame Information */
#define FRMINFO0_CRCERR			(0x00000001)
#define FRMINFO0_NBLERR			(0x00000002)
#define FRMINFO0_FIFOFULL		(0x00000004)
#define FRMINFO0_SHORT			(0x00000008)
#define FRMINFO0_WORD			(0x7FFF0000)
#define FRMINFO1_VTAG			(0x00000001)
#define FRMINFO1_TYPEIP			(0x00000008)
#define FRMINFO1_TCPNG			(0x00000040)
#define FRMINFO1_IPNG			(0x00000080)

#define FRMINFO_VALID			(FRMINFO0_CRCERR | FRMINFO0_NBLERR | FRMINFO0_FIFOFULL | FRMINFO0_SHORT)
#define FRMINFO_CHKSUM			(FRMINFO1_TCPNG | FRMINFO1_IPNG)

#define frminfo_get_rxword(x)	((x & FRMINFO0_WORD) >> 18)
#define frminfo_get_frmlen(x)	(((x & FRMINFO0_WORD) >> 16) - 3)

	/* wait parameter */
#define GMAC_RESET_WAIT_TIME	(2000)	/* ns */
#define CPU_CLK					(RIN32M4_SYSCLK / 1000000)
#define WAIT_LOOP_CYCLE			(7)


static UH eth_devnum;        /* Device Number*/
static UB link_status;

extern ER phy0_ini(ID flg, UW id, UW adr);
extern ER phy0_ext(void);
extern ER phy0_set_mode(UW mode, UB nego);
extern ER phy0_get_mode(UW *mode, UB *nego, UB *link);

extern ER phy1_ini(ID flg, UW id, UW adr);
extern ER phy1_ext(void);
extern ER phy1_set_mode(UW mode, UB nego);
extern ER phy1_get_mode(UW *mode, UB *nego, UB *link);

PHY_IO gPHY_IO[] = {
    {
        PHY_LINK_ID0,
        PHY_ADR0,
        phy0_ini,
        phy0_ext,
        phy0_set_mode,
        phy0_get_mode,
    },
    {
        PHY_LINK_ID1,
        PHY_ADR1,
        phy1_ini,
        phy1_ext,
        phy1_set_mode,
        phy1_get_mode,
    },
    {
        0, 0, NULL, NULL, NULL, NULL,
    },
};

static void eth_wait(UW value);
/* Raw Interface */
ETH_RAW_RCV eth_raw_rcv;
ETH_RAW_SNDDONE eth_raw_snddone;

/* Statistics */
enum {
    CNT_RX_OCTED,   CNT_RX_UNICAST, CNT_RX_BRDCAST,
    CNT_RX_DISCARD, CNT_RX_ERROR,   CNT_RX_UNKNOWN,
    CNT_TX_OCTED,   CNT_TX_UNICAST, CNT_TX_BRDCAST,
    CNT_TX_DISCARD, CNT_TX_ERROR,   CNT_TX_QUEUE,
    CNT_MAX
};

#if (STATISTICS_ENA == 1)
#define  STATS_START()         eth_pkt_cnt.flg = 1
#define  STATS_STOP()          eth_pkt_cnt.flg = 0
#define  STATS_CLEAR()         net_memset(eth_pkt_cnt.cnt, 0, sizeof(eth_pkt_cnt.cnt))
#define  STATS_UPDATE(i, c)    eth_pkt_cnt.cnt[(i)]+=(c)
#define  STATS_OF(i)           eth_pkt_cnt.cnt[(i)]
#define  STATS_CALLBK(e, s)    net_sts_cbk(eth_devnum, (e), (VP)(s))
struct {
    UW cnt[CNT_MAX];
    UB flg;
} static eth_pkt_cnt = {0};
#else
#define  STATS_START()
#define  STATS_STOP()
#define  STATS_UPDATE(i, c)
#define  STATS_OF(i)   0
#define  STATS_CALLBK(e, s)
#define  STATS_CLEAR()
#endif

/* old version */
#ifndef HW_CS_TX_TCPUDP
#define HW_CS_TX_TCPUDP  HW_CS_TX_DATA
#define HW_CS_RX_TCPUDP  HW_CS_RX_DATA
#endif

static void eth_set_mod(UINT mod)
{
    PHY_MODE mode;
    UINT ethsw_mode_shift;
    UINT temp;

    mode.ch = (UB)(mod & 0x0F);
    get_phy_mode(&mode);
    STATS_CALLBK(EV_CBK_DEV_LINK, mode.link);

    /* link up */
    if (mode.link) {
        link_status |= (UB)(mode.ch);
    } else {
        link_status &= (UB)~(mode.ch);
        goto eth_mod_end;
    }

    /* mode */

    //---------------------------------
    // Direct MAC
    //---------------------------------
    if ( RIN_SYS->MACSEL == MACSEL_DIRECT ) {
        switch ( mode.mode ) {
            case LAN_1000T_HD:     /* 1000BASE-T Half-Duplex */
                RIN_ETH->GMAC_MODE = (MODE_GIG | MODE_HALF_DUP);
                break;
            case LAN_1000T_FD:     /* 1000BASE-T Full-Duplex */
                RIN_ETH->GMAC_MODE = (MODE_GIG | MODE_FULL_DUP);
                break;
            case LAN_10T_HD:       /* 10BASE-T Half-Duplex */
            case LAN_100TX_HD:     /* 100BASE-TX Half-Duplex */
                RIN_ETH->GMAC_MODE = (MODE_100M | MODE_HALF_DUP);
                break;
            case LAN_10T_FD:       /* 10BASE-T Full-Duplex */
            case LAN_100TX_FD:     /* 100BASE-TX Full-Duplex */
                RIN_ETH->GMAC_MODE = (MODE_100M | MODE_FULL_DUP);
                break;
            default:
                RIN_ETH->GMAC_MODE = (MODE_GIG | MODE_FULL_DUP);
                break;
        }
    //---------------------------------
    // Ethernet Switch
    //---------------------------------
    } else if ( RIN_SYS->MACSEL == MACSEL_ETHSW ) {
        // --- Check port number ---
        if ( mode.ch == (UB)ETH_INT_MII_PHY0) {
            ethsw_mode_shift = 0;       // EtherSwitch Port 0
        } else {
            ethsw_mode_shift = 2;       // EtherSwitch Port 1
        }
        // Unlock system register
        RIN_SYS->SYSPCMD = 0x00a5;
        RIN_SYS->SYSPCMD = 0x0001;
        RIN_SYS->SYSPCMD = 0xfffe;
        RIN_SYS->SYSPCMD = 0x0001;

        temp = RIN_SYS->ETHSWMD & (UINT)~(0x3<<ethsw_mode_shift);
        switch ( mode.mode ) {
            case LAN_1000T_HD:     /* 1000BASE-T Half-Duplex */
                RIN_SYS->ETHSWMD = temp | ((ETHSW_MODE_GIG | ETHSW_MODE_HALF_DUP) << ethsw_mode_shift) ;
                break;
            case LAN_1000T_FD:     /* 1000BASE-T Full-Duplex */
                RIN_SYS->ETHSWMD = temp | ((ETHSW_MODE_GIG | ETHSW_MODE_FULL_DUP) << ethsw_mode_shift) ;
                break;
            case LAN_10T_HD:       /* 10BASE-T Half-Duplex */
            case LAN_100TX_HD:     /* 100BASE-TX Half-Duplex */
                RIN_SYS->ETHSWMD = temp | ((ETHSW_MODE_100M | ETHSW_MODE_HALF_DUP) << ethsw_mode_shift) ;
                break;
            case LAN_10T_FD:       /* 10BASE-T Full-Duplex */
            case LAN_100TX_FD:     /* 100BASE-TX Full-Duplex */
                RIN_SYS->ETHSWMD = temp | ((ETHSW_MODE_100M | ETHSW_MODE_FULL_DUP) << ethsw_mode_shift) ;
                break;
            default:
                RIN_SYS->ETHSWMD = temp | ((ETHSW_MODE_GIG | ETHSW_MODE_FULL_DUP) << ethsw_mode_shift) ;
                break;
        }
#if (USE_ETHSW & USE_ETHSW_MGTAG)
        RIN_SYS->ETHSWMTC |= 0x80000000;        // Management tag insertion is enabled
#endif
        // Lock system register
        RIN_SYS->SYSPCMD = 0x0000;

        RIN_ETH->GMAC_MODE = (MODE_GIG | MODE_FULL_DUP);    // CPU MAC must be 1Gbit mode
    //---------------------------------
    // Others
    //---------------------------------
    } else {
        /* Do nothing */
    }

eth_mod_end:

#if (USE_ETHSW)
    RIN_ETHSW->SWCFG.PORT_ENA = 0x00000004 | link_status;   // Enable transmit of link ports
#endif

    return;
}

ER eth_ini(UH dev_num)
{
    T_NET       *net;
    T_NET_DEV   *dev;
    PHY_IO      *phy;
    UB *mac;
    ER ercd;

    /* uNet3 network resource initialization */
    if (dev_num == 0) {
        return E_ID;
    }
    eth_devnum = dev_num;
    link_status = 0;

    net = &gNET[eth_devnum-1];
    if (net == NULL) {
        return E_PAR;
    }
    dev = net->dev;
    if (dev == NULL) {
        return E_PAR;
    }
    mac = &dev->cfg.eth.mac[0];

    eth_raw_rcv = NULL;
    eth_raw_snddone = NULL;

    if (dev->cbk) {
        /* Ether H/W init */
        dev->cbk(dev_num, EV_CBK_DEV_INIT, 0);
    }

    //=========================================
    // Setup MACSEL & PHY
    //=========================================
    // Unlock system register
    RIN_SYS->SYSPCMD = 0x00a5;
    RIN_SYS->SYSPCMD = 0x0001;
    RIN_SYS->SYSPCMD = 0xfffe;
    RIN_SYS->SYSPCMD = 0x0001;

    //---------------------------------
    // MACSEL initialization
    //---------------------------------
#if (USE_ETHSW)
    RIN_SYS->MACSEL = MACSEL_ETHSW;
#else
    RIN_SYS->MACSEL = MACSEL_DIRECT;
#endif

	// --- Setup PHY signals ---
	RIN_SYS->MDCCFG    = 0x00000003;                // MDC = 100/64 = 1.5625(MHz)
	RIN_SYS->MDIOSEL   = 0x00000000;                // Giga-bit-Ether MAC
	RIN_SYS->PHYRSTCH  = 0x00000001;
	RIN_SYS->PHYRST    = 0x00000001;

    // Lock system register
    RIN_SYS->SYSPCMD = 0x0000;

    ether_phy_init();
    //=========================================

#if (USE_ETHSW)
    /* EtherSwitch initialization */
    ethsw_init( mac );
#endif
    /* set hardware checksum flag */
    net->flag |= (HW_CS_TX_IPH4 | HW_CS_TX_TCPUDP);

    /* MAC reset */
    RIN_ETH->GMAC_RESET |= 0x80000000;
	eth_wait(GMAC_RESET_WAIT_TIME);

    RIN_ETH->GMAC_ADR1A = (((UINT)mac[3] << 24) |
                           ((UINT)mac[2] << 16) |
                           ((UINT)mac[1] <<  8) |
                           ((UINT)mac[0] <<  0));
    RIN_ETH->GMAC_ADR1B = (((UINT)mac[5] <<  8) |
                           ((UINT)mac[4] <<  0))|
                           0x00FF0000;

    /* PHY initiate */
    phy = &gPHY_IO[0];
    while (phy->phy_ini) {
        ercd = phy->phy_ini(ID_FLG_ETH_RX_MAC, phy->phy_id, phy->phy_adr);
        if (ercd != E_OK) {
            return ercd;
        }
        phy++;
    }
    RIN_SYS->PHYLINK_EN = 0x00000001;

#if (USE_ETHSW & USE_ETHSW_MGTAG)
    RIN_ETH->GMAC_TXMODE |= 0x60000000; /* Long Packet TX Enable, Store and Forward */
#else
    RIN_ETH->GMAC_TXMODE |= 0x20000000; /* Store and Forward */
#endif

#if (ETH_TX_ASYNC)
    ercd = sta_tsk(ID_TASK_ETH_SND, 0);
    if (ercd != E_OK) {
        return ercd;
    }
#endif

#if (ETH_EARLY_TX_ENA)
    RIN_ETH->GMAC_TXMODE |= 0x00000080; /* Not write TX result */
#endif

    ercd = sta_tsk(ID_TASK_ETH_OVF, 0);
    if (ercd != E_OK) {
        return ercd;
    }

    ercd = sta_tsk(ID_TASK_ETH_RCV, 0);
    if (ercd != E_OK) {
        return ercd;
    }

    STATS_START();
    STATS_CLEAR();
    return E_OK;
}


void eth_rcv_tsk(int exinf)
{
    T_NET_BUF *pkt;
    T_NET_DEV *dev;

    UINT ptn;
    UINT buffid;
    UINT rword;
    UINT rxadr;
    UINT len;
    UINT errsts;
    ER ercd;
    UH	flags;
    UB	mustSwChkSum;

    UINT *fctl;
    UINT vlan_ofst;

    dev = &gNET_DEV[eth_devnum-1];

#if (PROMISCUOUS_FILTER_MODE)
    RIN_ETH->GMAC_RXMODE |= 0x90000000;
#endif

#if (MULTICAST_FILTER_MODE)
    RIN_ETH->GMAC_RXMODE |= 0x50000000;
#endif

    hwfnc_macdma_rx_enable(0);

    while (TRUE) {

        if ((RIN_ETH->GMAC_RXMAC_ENA & 0x00000001) == 0) {
            RIN_ETH->GMAC_RXMAC_ENA |= 0x00000001;
            continue;
        }

        ercd = wai_flg(ID_FLG_ETH_RX_MAC, (ETH_INT_RX_EVT | PHY_LINK_EVT), TWF_ORW, &ptn);
        clr_flg(ID_FLG_ETH_RX_MAC, ~(ETH_INT_RX_EVT | PHY_LINK_EVT));
        if (ercd != E_OK || ptn == 0) {
            /* System Error */
            while (1) {}
        }

        if (ptn & PHY_LINK_EVT) {
            if(ptn & PHY_LINK_ID0){
                eth_set_mod(ptn & PHY_LINK_ID0);
                clr_flg(ID_FLG_ETH_RX_MAC, ~(PHY_LINK_ID0));
            }
            if(ptn & PHY_LINK_ID1){
                eth_set_mod(ptn & PHY_LINK_ID1);
                clr_flg(ID_FLG_ETH_RX_MAC, ~(PHY_LINK_ID1));
            }
            continue;
        } else if (ptn & ETH_INT_RX_DMA_ERR) {
            errsts = hwfnc_macdma_rx_errstat();
            if (errsts & 0x000000f0) { /* Hardware error */
                STATS_UPDATE(CNT_RX_DISCARD, 1);
                hwfnc_macdma_rx_disable(1);
                hwfnc_macdma_rx_enable(0);
                continue;
            }
        }

        while (TRUE) {

            buffid = RIN_HWOS->BUFID;
            rxadr = bufid_get_rxaddr(buffid);

            if ((buffid & BUFID_NOEMP) == BUF_EMPTY) {   /* bit31 RX fifo empty ?*/
                break;
            }

            if ((buffid & BUFID_VALID) == DATA_INVALID) {   /* bit28 abnormal ?*/
                STATS_UPDATE(CNT_RX_DISCARD, 1);
                hwfnc_buffer_release((UINT)rxadr);
                continue;
            }
            rword = bufid_get_rxword(buffid);
            fctl = (UINT*)rxadr + rword - 2;     /* RX frame controller [31:0] */

            /* frame validation */
            if (fctl[0] & FRMINFO_VALID) {
                // ====== CRCERR, NBLERR, FIFOFULL, TOOSHORT ===
                hwfnc_buffer_release((UINT)rxadr);
                STATS_UPDATE(CNT_RX_ERROR, 1);
                continue;
            }
            // --- Check VLAN --
            if (!(fctl[1] & FRMINFO1_VTAG)) {
                vlan_ofst = 0;                                      // None VLAN
            } else {
                vlan_ofst = 4;                                      // VLAN
            }
            /* for checksum error*/
            mustSwChkSum = 0;
            if(fctl[1] & FRMINFO_CHKSUM) {
                if ((fctl[1] & FRMINFO1_TCPNG)) {
                    /* Check IP Fragment Packet */
                    flags = ntohs(*(UH*)(rxadr + vlan_ofst + IP_HD_FLGS_FO));
                    if(!(((flags & IP_HD_FLGS_MSK) == IP_HD_FLSG_MF) ||
                         ((flags & IP_HD_FO_MSK)   != 0x0000))) {
                        if(*(UB*)(rxadr + vlan_ofst + IP_HD_PRTCL) == IP_PRTCL_TCP) {
                            // ====== TCPNG ===
                            if (!(((*(UH*)(rxadr + vlan_ofst + TCP_HD_CHKSUM) == 0xFFFF) 
                               || (*(UH*)(rxadr + vlan_ofst + TCP_HD_CHKSUM) == 0x0000))
                               &&((*(UH*)((UINT*)rxadr + frminfo_get_rxword(fctl[0]) - 1) == 0xFFFF)
                               || (*(UH*)((UINT*)rxadr + frminfo_get_rxword(fctl[0]) - 1) == 0x0000)))) {
                                hwfnc_buffer_release((UINT)rxadr);
                                STATS_UPDATE(CNT_RX_ERROR, 1);
                                continue;
                            }
                        } else {
                            // ====== UDPNG ===
                            hwfnc_buffer_release((UINT)rxadr);
                            STATS_UPDATE(CNT_RX_ERROR, 1);
                            continue;
                        }
                    }
                }
                if ((fctl[1] & FRMINFO1_IPNG)) {
                    // ====== IPNG ===
                    if (!(*(UH*)(rxadr + vlan_ofst + IP_HD_CHKSUM) == 0xFFFF) &&
                        !(*(UH*)(rxadr + vlan_ofst + IP_HD_CHKSUM) == 0x0000)) {
                        hwfnc_buffer_release((UINT)rxadr);
                        STATS_UPDATE(CNT_RX_ERROR, 1);
                        continue;
                    } else {
                        mustSwChkSum = 1;
                    }
                }
            }
            len = frminfo_get_frmlen(fctl[0]);
            len = len - ETHFRM_HD_PAD - ETHFRM_FCS_LEN;
            if(fctl[1] & FRMINFO1_TYPEIP){
                /* IP packet correction */
                len += IPPKT_CRCT;

                /* IP Fragment packet? */
                flags = ntohs(*(UH*)(rxadr + vlan_ofst + IP_HD_FLGS_FO));
                if((flags & IP_HD_FLGS_MSK) == IP_HD_FLSG_MF ||
                   (flags & IP_HD_FO_MSK)   != 0x0000) {
                    mustSwChkSum = 1;
                }
            }

            ercd = net_buf_get(&pkt, len + sizeof(T_NET_BUF) + dev->hhdrofs, TMO_POL);
            if (ercd != E_OK || pkt == NULL) {
                hwfnc_buffer_release((UINT)rxadr);
                STATS_UPDATE(CNT_RX_DISCARD, 1);
                continue;
            }
            pkt->hdr     = pkt->buf + dev->hhdrofs; /* for TX packet */
            pkt->hdr_len = ETHFRM_HD_LEN;
            pkt->dat     = pkt->hdr + pkt->hdr_len;
            pkt->dat_len = len - pkt->hdr_len;
            pkt->dev = dev;
            pkt->flg    |= (HW_CS_RX_IPH4 | HW_CS_RX_TCPUDP);
            if(mustSwChkSum){
                pkt->flg &= ~HW_CS_RX_TCPUDP;
            }
#if (FRAM_USE_BUFFER_RAM)
            eth_bufram_cpy((UINT)pkt->hdr, (UINT)rxadr, ETHFRM_HD_LEN);
            eth_bufram_cpy((UINT)(pkt->hdr + ETHFRM_HD_LEN), (UINT)(rxadr+ETHFRM_HD_ACTLEN), len-ETHFRM_HD_LEN);
#else
            hwfnc_dmt((UINT)rxadr, (UINT)pkt->hdr, ETHFRM_HD_LEN, (UINT*)&ercd);
            hwfnc_dmt((UINT)(rxadr+ETHFRM_HD_ACTLEN), (UINT)(pkt->hdr + ETHFRM_HD_LEN), len-ETHFRM_HD_LEN, (UINT*)&ercd);
#endif
            STATS_UPDATE(CNT_RX_OCTED, len);
            STATS_UPDATE((pkt->hdr[0]&0x01) ? CNT_RX_BRDCAST : CNT_RX_UNICAST, 1);
            /* raw interface */
            _eth_raw_rcv(pkt->hdr, (pkt->hdr_len + pkt->dat_len));

            net_pkt_rcv(pkt);

            if((hwfnc_buffer_release((UINT)rxadr) & 0x00000003) == 0x00000003) {
                /* wrong address or hardware error */
                while (1) {}
            }
        }
    }
}

ER tx_frame(T_NET_BUF *pkt , UB port)
{
    TXDSC *dsc;
    UINT *fcnt;
    UINT ptn;
    T_NET_BUF *pktbuf;
    ER ercd;

#if (!ETH_EARLY_TX_ENA)
    volatile UINT txid;
    volatile UINT txres;
#endif

    if (link_status == 0) {
        STATS_UPDATE(CNT_TX_DISCARD, 1);
        return E_TMOUT;
    }

    ercd = E_OK;

#if (FRAM_USE_BUFFER_RAM)
    pktbuf = pkt;
#else
    pktbuf = (T_NET_BUF*)hwfnc_longbuffer_get(2048);
    if (pktbuf == NULL) {
        STATS_UPDATE(CNT_TX_DISCARD, 1);
        return E_NOMEM;
    }
    hwfnc_dmt((UINT)pkt, (UINT)pktbuf,  2048, (UINT*)&ercd);
    pktbuf->hdr = pktbuf->buf + (pkt->hdr - pkt->buf); /* hdr - buf = offset */
#endif
    pkt->dat = (UB*)pktbuf;

    dsc = (TXDSC*)pktbuf->buf;
    fcnt = (UINT*)&dsc[TXDSC_NUM];

    /* Descriptor[0] Frame controller */
    dsc[0].bufadr = (UINT)(fcnt);
    dsc[0].length = (UINT)TX_FRAME_CNT_LEN;

    /* Descriptor[1] MAC header and padding */
    dsc[1].bufadr = (UINT)pktbuf->hdr;
    dsc[1].length = (UINT)(ETHFRM_HD_ACTLEN);

    /* Descriptor[2] IP packet */
    dsc[2].bufadr = (UINT)(pktbuf->hdr + ETHFRM_HD_LEN);
    dsc[2].length = (UINT)(pktbuf->hdr_len - ETHFRM_HD_LEN);

    /* Descriptor[3] Termination */
    dsc[3].bufadr = 0xffffffff;

    /* Set Frame controller */
    fcnt[0] = (pktbuf->hdr_len + 3) << 16 | 0x04;
    fcnt[0] |= ( port <<  8 );          // Forced Forwarding
#if (USE_ETHSW & USE_ETHSW_MGTAG)
    fcnt[0] |= ( 1 <<  7 ) |            // Transmit Timestamp
               ( 0 <<  6 ) ;            // One Step Proc
#endif
    fcnt[1] = (UINT)pktbuf; /* for unique ID */

    /* Start TX */
    hwfnc_macdma_tx_start((UINT)dsc, 0);

    wai_flg(ID_FLG_ETH_TX_MAC, (ETH_INT_TX_DMA_CMP | ETH_INT_TX_DMA_ERR), TWF_ORW, &ptn);
    clr_flg(ID_FLG_ETH_TX_MAC, ~(ETH_INT_TX_DMA_CMP | ETH_INT_TX_DMA_ERR));
    if (ptn & ETH_INT_TX_DMA_ERR) {
        return E_SYS;
    }
    STATS_UPDATE(CNT_TX_OCTED, pkt->hdr_len);
    STATS_UPDATE((pkt->hdr[0]&0x01) ? CNT_TX_BRDCAST : CNT_TX_UNICAST, 1);

#if (!ETH_EARLY_TX_ENA)
    ptn = 0;
    wai_flg(ID_FLG_ETH_TX_MAC, (ETH_INT_TX_MAC_CMP | ETH_INT_TX_MAC_ERR), TWF_ORW, &ptn);
    clr_flg(ID_FLG_ETH_TX_MAC, ~(ETH_INT_TX_MAC_CMP | ETH_INT_TX_MAC_ERR));

    txid = RIN_ETH->GMAC_TXID;
    txres = RIN_ETH->GMAC_TXRESULT;

    if ((ptn & ETH_INT_TX_MAC_ERR) || ((txres & 0x00002000) == 0)) {
        return E_SYS;
    }
#endif
    return ercd;
}

void eth_snd_tsk(int exinf)
{
    T_NET_BUF *pkt;
    ER ercd;
#if (USE_ETHSW)
    FLGPTN p_flgptn;
#endif

    while (TRUE) {
        /* Wait for packet from Protocol stack */

        ercd = rcv_mbx(ID_MBX_ETH_SND, (T_MSG**)&pkt);
        if (ercd != E_OK) {
            break;
        }
#if (USE_ETHSW)
        /* Check the EtherSwitch status before transmit */
        if ( RIN_ETHSW->SWCFG.OQMGR_STATUS & 0x00000004 ) {
            ercd = twai_flg(ID_FLG_SYSTEM, 0x0001, TWF_ORW, &p_flgptn, 1);      // used as dly_tsk()
        }
#endif
        ercd = tx_frame(pkt,FFW_NON);
        if (ercd < E_OK) {
            pkt->ercd = ercd;
        }
#if (!FRAM_USE_BUFFER_RAM)
        hwfnc_buffer_release((UINT)pkt->dat);
#endif
        _eth_raw_snddone(pkt);

        loc_tcp();
        net_buf_ret(pkt);
        ulc_tcp();
    }
    /* System Error */
    ext_tsk();
}

ER eth_snd(UH dev_num, T_NET_BUF *pkt)
{
#if (ETH_TX_ASYNC)
    /* Add to Device send queue */
    snd_mbx(ID_MBX_ETH_SND, (T_MSG*)pkt);
    return E_WBLK;
#else
    ER ercd;

    ercd = tx_frame(pkt,FFW_NON);
    if (ercd < E_OK) {
        pkt->ercd = ercd;
    }
#if (!FRAM_USE_BUFFER_RAM)
    hwfnc_buffer_release((UINT)pkt->dat);
#endif
    return ercd;
#endif
}

ER eth_cls(UH dev_num)
{
    PHY_IO  *phy;

    phy = &gPHY_IO[0];
    while (phy->phy_ext) {
        phy->phy_ext();
        phy++;
    }
    STATS_STOP();
    return E_OK;
}

ER eth_sts(UH dev_num, UH opt, VP val)
{
    ER ercd;
#ifdef STS_SUP
    T_NET_STS_IFS* ifs;
#endif

    switch(opt) {
        case ETH_OPT_PHY_MODE :
            ercd = get_phy_mode((PHY_MODE*)val);
            break;
#ifdef STS_SUP
        case REF_ETH_UPD_STS :
            ifs = (T_NET_STS_IFS*)val;
            ifs->in_octet = STATS_OF( CNT_RX_OCTED );
            ifs->in_ucast_pkt = STATS_OF( CNT_RX_UNICAST );
            ifs->in_nucast_pkt = STATS_OF( CNT_RX_BRDCAST );
            ifs->in_discard = STATS_OF( CNT_RX_DISCARD );
            ifs->in_err = STATS_OF( CNT_RX_ERROR );
            ifs->in_unknown_proto = STATS_OF( CNT_RX_UNKNOWN );
            ifs->out_octet = STATS_OF( CNT_TX_OCTED );
            ifs->out_ucast_pkt = STATS_OF( CNT_TX_UNICAST );
            ifs->out_nucast_pkt = STATS_OF( CNT_TX_BRDCAST );
            ifs->out_discard = STATS_OF( CNT_TX_DISCARD );
            ifs->out_err = STATS_OF( CNT_TX_ERROR );
            ercd = E_OK;
            break;
#endif
        default:
            ercd = E_PAR;
            break;
    }
    return ercd;
}

ER eth_ctl(UH dev_num, UH opt, VP val)
{
    ER ercd;

    switch(opt) {
        case ETH_OPT_PHY_MODE :
            ercd = set_phy_mode((PHY_MODE*)val);
            break;
        case ETH_OPT_MCRX_MODE :
            ercd = set_mcast_filter_mode(*(UINT*)val);
            break;
        case ETH_OPT_MCRX_ADR :
            ercd = add_mcast_filter((MAC_FILTER*)val);
            break;
        case ETH_OPT_RAW_RXFNC :
            eth_raw_rcv = (ETH_RAW_RCV)val;
            ercd = E_OK;
            break;
        case ETH_OPT_RAW_SNDDONE :
            eth_raw_snddone = (ETH_RAW_SNDDONE)val;
            ercd = E_OK;
            break;
        default:
            ercd = E_PAR;
            break;
    }
    return ercd;
}

static UW lan_to_phy_mode(UW lan_mode)
{
    UW phy_mode;
    if (lan_mode == LAN_10T_HD) {
        phy_mode = PHY_10T_HD;
    } else if (lan_mode == LAN_10T_FD) {
        phy_mode = PHY_10T_FD;
    } else if (lan_mode == LAN_100TX_HD) {
        phy_mode = PHY_100TX_HD;
    } else if (lan_mode == LAN_100TX_FD) {
        phy_mode = PHY_100TX_FD;
    } else if (lan_mode == LAN_1000T_HD) {
        phy_mode = PHY_1000T_HD;
    } else if (lan_mode == LAN_1000T_FD) {
        phy_mode = PHY_1000T_FD;
    } else {
        phy_mode = PHY_AUTO_ABILITY;
    }
    return phy_mode;
}

static UW phy_to_lan_mode(UW phy_mode)
{
    UW lan_mode;
    if (phy_mode == PHY_10T_HD) {
        lan_mode = LAN_10T_HD;
    } else if (phy_mode == PHY_10T_FD) {
        lan_mode = LAN_10T_FD;
    } else if (phy_mode == PHY_100TX_HD) {
        lan_mode = LAN_100TX_HD;
    } else if (phy_mode == PHY_100TX_FD) {
        lan_mode = LAN_100TX_FD;
    } else if (phy_mode == PHY_1000T_HD) {
        lan_mode = LAN_1000T_HD;
    } else if (phy_mode == PHY_1000T_FD) {
        lan_mode = LAN_1000T_FD;
    } else {
        lan_mode = LAN_AUTO_ABILITY;
    }
    return lan_mode;
}

ER set_phy_mode(PHY_MODE *mode)
{
    ER      ercd;
    PHY_IO  *phy;

    ercd = E_PAR;
    phy = &gPHY_IO[0];

    while (phy->phy_set_mode) {
        if (phy->phy_id == mode->ch) {
            ercd = phy->phy_set_mode(lan_to_phy_mode(mode->mode), mode->nego);
            if (ercd != E_OK) {
                break;
            }
        }
        link_status &= (UB)~(mode->ch);
        phy++;
    }
    return ercd;
}

ER get_phy_mode(PHY_MODE *mode)
{
    ER      ercd;
    PHY_IO  *phy;

    ercd = E_PAR;
    phy = &gPHY_IO[0];

    while (phy->phy_get_mode) {
        if (phy->phy_id == mode->ch) {
            ercd = phy->phy_get_mode(&mode->mode, &mode->nego, &mode->link);
            if (ercd != E_OK) {
                break;
            }
            mode->mode = phy_to_lan_mode(mode->mode);
        }
        phy++;
    }
    return ercd;
}

ER set_mcast_filter_mode(UINT mode)
{
    UINT *mac, i;

    if (mode == MCRX_MODE_ALLOW) {
        RIN_ETH->GMAC_RXMODE &= ~0x40000000;
    } else if (mode == MCRX_MODE_DENY) {
        RIN_ETH->GMAC_RXMODE |= 0x40000000;
    } else if (mode == MCRX_MODE_FILTER) {
        RIN_ETH->GMAC_RXMODE |= 0x40000000;
    } else {
        return E_PAR;
    }

    if (mode == MCRX_MODE_DENY) {
        mac = (UINT*)&RIN_ETH->GMAC_ADR1A;
        for (i = 1; i <= 16; i++, mac+=2) {
            /* delte multicast address */
            if ((*mac & 0x80FFFFFF) == 0x005E0001) {
                *mac     = 0x00000000; /* ADDRESS_xA*/
                *(mac+1) = 0x00FF0000; /* ADDERSS_xB*/
            }
        }
    }
    return E_OK;
}

ER add_mcast_filter(MAC_FILTER *adr)
{
    UINT *mac, i;
    UB bitnum;

    bitnum = adr->bitnum;
    if (bitnum == 0) {
        bitnum = 48;
    }

    /* bitnum must be 48 or less and more than 40 */
    if (bitnum < 40 || 48 < bitnum) {
        return E_PAR;
    }
    bitnum -= 40;

    mac = (UINT*)&RIN_ETH->GMAC_ADR1A;
    for (i = 1; i <= 16; i++, mac+=2) {
        if (*mac == 0x00000000) {
            *mac = (((UINT)adr->mac[3] << 24) |
                    ((UINT)adr->mac[2] << 16) |
                    ((UINT)adr->mac[1] <<  8) |
                    ((UINT)adr->mac[0] <<  0));
            *(mac+1) = (((0xFF000000 >> bitnum) & 0x00FF0000) |
                        ((UINT)adr->mac[5] <<  8) |
                        ((UINT)adr->mac[4] <<  0));
            break;
        }
    }
    return E_OK;
}

ER eth_bufram_cpy(UINT dst, UINT src, UINT len)
{
    ER ercd;

    ercd = wai_sem(ID_SEM_INTDMA);
    if (ercd != E_OK) {
        return ercd;
    }

    ercd = hwfnc_intbuff_dma_start1(dst, src, len, 0);
    if ((ercd & 0x1) != 0) {
        sig_sem(ID_SEM_INTDMA);
        return E_SYS;
    }
    // --- Wait for transfer finish ---
    while (NVIC_GetPendingIRQ(BUFDMA_IRQn) != 1 && NVIC_GetPendingIRQ(BUFDMAERR_IRQn) != 1)
    {
        __NOP();
    }
    if (NVIC_GetPendingIRQ(BUFDMAERR_IRQn)) {
        NVIC_ClearPendingIRQ(BUFDMAERR_IRQn);
        ercd = E_SYS;
    } else {
        NVIC_ClearPendingIRQ(BUFDMA_IRQn);
        ercd = E_OK;
    }
    sig_sem(ID_SEM_INTDMA);

    return ercd;
}

/*******************************************************************************
* Function Name: eth_wait
* Description  : wait function
* Arguments    : uint32_t value : wait time(us)
* Return Value : None
*******************************************************************************/
#if defined ( __ICCARM__ )
#pragma inline=never
#else	/* __CC_ARM__ || __GNUC__ */
__attribute__((noinline))
#endif
static void eth_wait(UW value)
{
    UW wait;

    wait = (value * 10) / (10000 / CPU_CLK) / WAIT_LOOP_CYCLE + 1;

#if defined ( __CC_ARM )
	__asm("mov   r0,wait   \n"
		  "eth_wait_loop:  \n"
		  "nop             \n"
		  "nop             \n"
		  "nop             \n"
		  "subs  r0,r0,#1  \n"
		  "bne   eth_wait_loop");
#else	/* __ICCARM__ || __GNUC__ */
	__asm("mov   r0,%0     \n"
		  "eth_wait_loop:  \n"
		  "nop             \n"
		  "nop             \n"
		  "nop             \n"
		  "subs  r0,r0,#1  \n"
		  "bne   eth_wait_loop"
		  : : "r"(wait));
#endif
} /* eth_wait() */

/*******************************************************************************
* Function Name:
* Description  :
* Arguments    : None
* Return Value : None
*******************************************************************************/
void eth_ovf_tsk(int exinf)
{
    ER ercd;
    FLGPTN ptn;

    UINT buffid;
    UINT rxadr;
    UINT rfwd;

    for (;;)
    {
        //-----------------------------------
        // Wait for Rx FIFO Overflow
        //-----------------------------------
        ercd = wai_flg(ID_FLG_ETH_RX_MAC, ETH_INT_RX_OVF_ERR, TWF_ORW, &ptn);
        clr_flg(ID_FLG_ETH_RX_MAC, ~(ETH_INT_RX_OVF_ERR));
        if (ercd != E_OK) {
            /* System Error */
            while (1) {}
        }

        //-----------------------------------
        // Stop recieving and clear Rx FIFO
        //-----------------------------------
        // 1.Disable MAC
        RIN_ETH->GMAC_RXMAC_ENA = 0x00000000;

        // 2.Discard all FIFO data
        for (;;)
        {
            rfwd = RIN_ETH->GMAC_RXFIFO;
            rfwd = (rfwd>>17) & 0xfff;
            if ( rfwd == 0)
            {
                break;
            }

            buffid = RIN_HWOS->BUFID;
            if ((buffid & BUFID_NOEMP) == BUF_EMPTY) {   /* bit31 RX fifo empty ?*/
                continue;
            }
            rxadr = bufid_get_rxaddr(buffid);
            hwfnc_buffer_release((UINT)rxadr);
        }

        // 3.Discard all buffer data
        for (;;)
        {
            buffid = RIN_HWOS->BUFID;
            if ((buffid & BUFID_NOEMP) == BUF_EMPTY) {   /* bit31 RX fifo empty ?*/
                break;
            }
            rxadr = bufid_get_rxaddr(buffid);
            hwfnc_buffer_release((UINT)rxadr);
        }
        clr_flg(ID_FLG_ETH_RX_MAC, ~(ETH_INT_RX_DMA_CMP));

        // 4.Enable MAC
        RIN_ETH->GMAC_RXMAC_ENA = 0x00000001;

        // 5.Discard frames and back to normal state
        while (TRUE) {
            ercd = wai_flg(ID_FLG_ETH_RX_MAC, ETH_INT_RX_DMA_CMP | ETH_INT_RX_OVF_ERR, TWF_ORW, &ptn);
            if (ercd != E_OK) {
                /* System Error */
                while (1) {}
            }
            if(ptn & ETH_INT_RX_OVF_ERR){
                break;
            }

            buffid = RIN_HWOS->BUFID;
            if ((buffid & BUFID_NOEMP) == BUF_EMPTY) {
                clr_flg(ID_FLG_ETH_RX_MAC, ~(ETH_INT_RX_DMA_CMP));
                continue;
            }

            rxadr = bufid_get_rxaddr(buffid);
            hwfnc_buffer_release((UINT)rxadr);
            if (buffid & BUFID_VALID) {
                break;
            }
        }
    }
}
