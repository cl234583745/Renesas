/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_MainState.c                                               */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


ERRCODE erR_IN32C_SeqMain(
	const R_IN32_EVTPRM_INTERRUPT_T* pstEvent			
)
{
	ULONG ulEvtID;		
	ULONG ulData;		
	ERRCODE erRet  = R_IN32C_OK;

	ulEvtID = R_IN32C_EVT_INTERRUPT;
	ulData = *(const ULONG *)pstEvent;

	switch (gstR_IN32C.stMain.ulState) {

	case R_IN32C_STS_DISCONNECT:			
	case R_IN32C_STS_DISCONNECT_SYSTEM:	
	case R_IN32C_STS_CONNECT:				
		erRet = erR_IN32C_SeqMainCommon(ulEvtID, ulData);
		break;

	default:
		erRet = R_IN32C_NG_OBJ;
		break;
	}

	return erRet;
}


ERRCODE erR_IN32C_SeqMainWaitStart(
	ULONG ulEvtID	
)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;

	switch (ulEvtID) {

	case R_IN32C_EVT_START:

		(VOID)gerR_IN32D_SetNetworkNumber(gstR_IN32C.stInf0.uchNetworkNumber);
		(VOID)gerR_IN32D_SetStationNumber(gstR_IN32C.stInf0.usStationNumber);

		erRet2 = erR_IN32C_StartRing_DisableInt();	

		if (R_IN32D_OK == erRet2) {
			gstR_IN32C.stMain.ulState = R_IN32C_STS_DISCONNECT_SYSTEM;	
		}
		else {
			(VOID)erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
		}
		break;

	default:
		break;
	}

	return erRet;
}

ERRCODE erR_IN32C_SeqMainCommon(
	ULONG ulEvtID,	
	ULONG ulData	
)
{
	ERRCODE erRet = R_IN32C_OK;


	switch (ulEvtID) {

	case R_IN32C_EVT_INTERRUPT:
		erRet = erR_IN32C_SeqMain_Intr(ulData);
		break;

	default:
		break;
	}

	return erRet;
}



ERRCODE erR_IN32C_SeqMain_Intr(
	ULONG ulIntrBitmap			
)
{
	ERRCODE	erRet = R_IN32C_OK;
	ULONG	ulMask;

	ulMask = 0x1;


	while (ulIntrBitmap != 0) {
		if ((ulIntrBitmap & ulMask) != 0) {

			switch (ulMask) {

			case R_IN32C_EVTPRM_COMMCONNECT:
				if(	(R_IN32C_STS_DISCONNECT == gstR_IN32C.stMain.ulState) || 
					(R_IN32C_STS_DISCONNECT_SYSTEM == gstR_IN32C.stMain.ulState)){
					erRet = erR_IN32C_SeqMain_Connect();
				}
				else {
				}
				break;

			case R_IN32C_EVTPRM_COMMDISCONNECTTOCONNECT:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = erR_IN32C_SeqMain_Disconnect();		
				}
				else {
				}
				erRet = erR_IN32C_SeqMain_Connect();		
				break;

			case R_IN32C_EVTPRM_DISCONNECT:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = erR_IN32C_SeqMain_Disconnect();
				}
				else {
				}
				break;

			case R_IN32C_EVTPRM_COMMCONNECTTODISCONNECT:
				if(	(R_IN32C_STS_DISCONNECT == gstR_IN32C.stMain.ulState) || 
					(R_IN32C_STS_DISCONNECT_SYSTEM == gstR_IN32C.stMain.ulState)){
					erRet = erR_IN32C_SeqMain_Connect();		
				}
				else {
				}
				erRet = erR_IN32C_SeqMain_Disconnect();		
				break;

			case R_IN32C_EVTPRM_CHANGESTNONETNO:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = gerR_IN32C_SeqMain_ChangeStationNetworkNumber();
				}
				else {
				}
				break;

			case R_IN32C_EVTPRM_CHANGEACTCOMMAND:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = gerR_IN32C_SeqMain_ChangeActCommand();
				}
				else {
				}
				break;

			case R_IN32C_EVTPRM_PRMFRMRCV_OK:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = gerR_IN32C_SeqMain_ChangeCommonParamStart();
				}
				else {
				}
				break;

			case R_IN32C_EVTPRM_PRMCHKFRMRCV_OK:
				if(gstR_IN32C.stMain.ulState == R_IN32C_STS_CONNECT){
					erRet = gerR_IN32C_SeqMain_ChangeCommonParamFin();
				}
				else {
				}
				break;


			case R_IN32C_EVTPRM_MASTERWATCHTIMEOUT:
				if(R_IN32C_STS_DISCONNECT == gstR_IN32C.stMain.ulState){
					erRet = erR_IN32C_SeqMain_MasterWatchTimeout();
				}
				else if( R_IN32C_STS_CONNECT == gstR_IN32C.stMain.ulState ){
					gerR_IN32D_StartMstWatchTmr();
				}
				else {
				}
				break;

			default:
				break;

			}

			ulIntrBitmap &= (~ulMask); 

		}
		else {
		}

		ulMask <<= 1;

	} 

	return erRet;
}


ERRCODE erR_IN32C_SeqMain_Connect(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32D_NETMOTION_T stNetmotion;

	(VOID)gerR_IN32D_GetMultiCastAddr(gstR_IN32C.stInf0.auchMulticastMACAddress);

	gstR_IN32C.stInf0.usNodeID = (USHORT)gulR_IN32D_GetNodeID();

	gerR_IN32D_GetNetMotion(&stNetmotion);
	gstR_IN32C.stInf1.ulTknHoldFrmSendCount = stNetmotion.ulTknHoldFrmSendCount;
	gstR_IN32C.stInf1.ulFramSendInterval = stNetmotion.ulFramSendInterval;
	gstR_IN32C.stInf1.ulTokenSendCount = stNetmotion.ulTokenSendCount;

	(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_INIT);

	gstR_IN32C.stMain.ulState = R_IN32C_STS_CONNECT;

	gerR_IN32D_SetDisconnectFactor(R_IN32_DISCONNECTFACTOR_NOFACTOR);
	return erRet;
}

ERRCODE erR_IN32C_SeqMain_Disconnect(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	(VOID)erR_IN32C_SeqMain_SndFinish();

	(VOID)gerR_IN32C_SetCyclicSndStopRequest(R_IN32C_CYCSTOP_LEAVE);

	gR_IN32R_DisableInt();

	gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivSeqNumber = 0;	

	gR_IN32R_EnableInt();

	gstR_IN32C.stMain.ulState = R_IN32C_STS_DISCONNECT;


	return erRet;
}


ERRCODE gerR_IN32C_SeqMain_ChangeStationNetworkNumber(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32D_PRMFRM_INF0_T	stWork0;

	(VOID)gerR_IN32D_GetParamStnNetNumber(&stWork0);


	gstR_IN32C.stInf0.uchNetworkNumber = (UCHAR)stWork0.ulNetworkNumber;
	gstR_IN32C.stInf0.usStationNumber = (USHORT)stWork0.ulStationNumber;

	(VOID)erR_IN32C_IndStationNumberChanged(gstR_IN32C.stInf0.uchNetworkNumber, gstR_IN32C.stInf0.usStationNumber);

	return erRet;
}

ERRCODE gerR_IN32C_SeqMain_ChangeActCommand(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32D_PRMFRM_INF1_T stWork1;

	(VOID)gerR_IN32D_GetParamActCmdStnType(&stWork1);
	gstR_IN32C.stMain.stPrmCmd.ulCommand = stWork1.ulCommand;


	if ((R_IN32D_ACTCMD_STATIONTYPE_VALID & gstR_IN32C.stMain.stPrmCmd.ulCommand) != 0){
		if (gstR_IN32C.stInf0.uchStationType == (UCHAR)stWork1.ulStationType) {
			(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_TYPE);	
			gstR_IN32C.stMain.stPrmCmd.blTypeErr = R_IN32_FALSE; 	
		}
		else {
			(VOID)gerR_IN32C_SetCyclicSndStopRequest(R_IN32C_CYCSTOP_TYPE);	
			gstR_IN32C.stMain.stPrmCmd.blTypeErr = R_IN32_TRUE; 	
		}
	}
	else {
	}

	(VOID)erR_IN32C_IndActCmdChanged(gstR_IN32C.stMain.stPrmCmd);

	return erRet;
}


ERRCODE gerR_IN32C_SeqMain_ChangeCommonParamStart(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	(VOID)gerR_IN32C_SetCyclicSndStopRequest(R_IN32C_CYCSTOP_PARAM);

	(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_LEAVE);	

	return erRet;
}

ERRCODE gerR_IN32C_SeqMain_ChangeCommonParamFin(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32D_PRMFRM_INF2_T stWork2;

	(VOID)gerR_IN32D_GetParamComParameter(&stWork2);


	if( (R_IN32D_OK != M_RANGECHK(gulR_IN32U_MIN_RX_SIZE,	stWork2.ulRxByteSize,	gulR_IN32U_MAX_RX_SIZE))	||
		(R_IN32D_OK != M_RANGECHK(gulR_IN32U_MIN_RY_SIZE,	stWork2.ulRyByteSize,	gulR_IN32U_MAX_RY_SIZE))	||
		(R_IN32D_OK != M_RANGECHK(gulR_IN32U_MIN_RWR_SIZE,	stWork2.ulRWwByteSize,	gulR_IN32U_MAX_RWR_SIZE))	||
		(R_IN32D_OK != M_RANGECHK(gulR_IN32U_MIN_RWW_SIZE,	stWork2.ulRWrByteSize,	gulR_IN32U_MAX_RWW_SIZE))){
		gstR_IN32C.stInf0.ulCurrRxSize = 0;
		gstR_IN32C.stInf0.ulCurrRySize = 0;
		gstR_IN32C.stInf0.ulCurrRWwSize = 0;
		gstR_IN32C.stInf0.ulCurrRWrSize = 0;
		(VOID)gerR_IN32C_SetCyclicSndStopRequest(R_IN32C_CYCSTOP_CYCSIZE);	
		gstR_IN32C.stMain.stPrmCmd.blSizeErr = R_IN32_TRUE;		
	}
	else {
		gstR_IN32C.stInf0.ulCurrRxSize = stWork2.ulRxByteSize;
		gstR_IN32C.stInf0.ulCurrRySize = stWork2.ulRyByteSize;
		gstR_IN32C.stInf0.ulCurrRWwSize = stWork2.ulRWwByteSize;
		gstR_IN32C.stInf0.ulCurrRWrSize = stWork2.ulRWrByteSize;
		(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_CYCSIZE);	
		gstR_IN32C.stMain.stPrmCmd.blSizeErr = R_IN32_FALSE;		
	}

	(VOID)erR_IN32C_IndActCmdChanged(gstR_IN32C.stMain.stPrmCmd);

	if (((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_PARAM) != 0) ||
		((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_LEAVE) != 0)) {
		(VOID)gerR_IN32C_SetCyclicSndStopRequest(R_IN32C_CYCSTOP_FIRSTSND);
	}
	else {
	}

	(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_PARAM);



	return erRet;
}

ERRCODE erR_IN32C_SeqMain_RcvFinish(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	VOID *pRcv;
	ULONG ulLen;
	ERRCODE erRet2;
	ERRCODE erRet3;


	while (1) {

		if (R_IN32_TRUE == gstR_IN32C.stMain.blRcvEnable) {

			erRet2 = erR_IN32C_GetRcvTran2(&ulLen,&pRcv);	

			if (R_IN32C_OK != erRet2) {
				break; 
			}
			else {
			}

			erRet3 = erR_IN32C_IndRcvFrameToNCYC(ulLen, pRcv);

			if (R_IN32C_NG_OVERFLOW == erRet3) {
				gstR_IN32C.stMain.blRcvEnable = R_IN32_FALSE;
			}
			else if (R_IN32C_NG_TRAN_SIZE == erRet3) {
				erRet = R_IN32C_NG_TRAN_SIZE;
			}
			else {
			}

			(VOID)erR_IN32C_SetRcvTranFin2();		


		}
		else {

			break;	
	} 
	} 

	return erRet;
}


ERRCODE erR_IN32C_SeqMain_SndFinish(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32C_TDIS_RES_T astTDIS[TD_TRAN_NUM];
	ULONG ulIdx;

	for (ulIdx=0; ulIdx<TD_TRAN_NUM; ulIdx++) {
		astTDIS[ulIdx].blValid = R_IN32_FALSE;
		astTDIS[ulIdx].uchNum  = 0;
		astTDIS[ulIdx].ulSts   = 0;
	}

	erR_IN32C_GetTranSndSts_DisableInt(astTDIS);

	for (ulIdx=0; ulIdx<TD_TRAN_NUM; ulIdx++) {
		if(R_IN32_TRUE == astTDIS[ulIdx].blValid) {
			(VOID)erR_IN32C_IndSndFin(astTDIS[ulIdx].uchNum, astTDIS[ulIdx].ulSts);
		}
		else {
		}
	}

	return erRet;
}

ERRCODE erR_IN32C_SeqMain_TimeInterval(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;


	gR_IN32R_DisableInt();

	erRet2 = gerR_IN32D_SetMyStatus(	
						&gstR_IN32C.stCyclic.stSetStopReq,		
						&gstR_IN32C.stInf0.stSelfStatus,		
						&gstR_IN32C.stSlvEvt.stSetSlvEvt,		
						&gstR_IN32C.stMACAddrTbl.stInf,			
						gstR_IN32C.stInf0.ulErrCode,			
						gstR_IN32C.stInf0.ulUserInformation);	
	if (R_IN32D_OK == erRet2) {
		gstR_IN32C.stMain.blReqSlvEvt = R_IN32_FALSE;		
	}
	else {
	}

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_SeqMain_MasterWatchTimeout(VOID)
{
	ERRCODE erRet = R_IN32C_OK;


	gstR_IN32C.stMIB.ulMasterWatchCount++;


	gstR_IN32C.stMain.ulState = R_IN32C_STS_DISCONNECT_SYSTEM;	

	gstR_IN32C.stMain.blValidMasterMyStatus = R_IN32_FALSE;

	gR_IN32R_DisableInt();

	gstR_IN32C.stCyclic.stGetStopSts.uniCycSta.usAll |= CYCLIC_STA_PARAMCHECKNOTEND;
	gstR_IN32C.stCyclic.ulState = R_IN32C_CYC_STS_STOP;

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	R_IN32D_FATALERROR_T stFatalError;

	while (1) {
		erRet = gerR_IN32D_GetFatalError(&stFatalError);
		if (R_IN32D_OK == erRet) {

			gR_IN32S_SysErrRet(stFatalError.ulErrorCode, (VOID *)stFatalError.ulErrorInfo);
		}
		else {
			break; 
	} 
	} 

	return erRet;
}

ERRCODE erR_IN32C_RcvBuf(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;
	ULONG ulLen;
	UCHAR *pBuf;

	while (1) {

		if ( R_IN32_FALSE == gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufWIdx].blValid ) {

			erRet2 = gerR_IN32D_GetRcvTran(&ulLen, (VOID**)&pBuf);	

			if (R_IN32D_OK != erRet2) {
				break; 
			}
			else {
			}

			gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufWIdx].ulLen = ulLen;
			gR_IN32S_Memcpy(gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufWIdx].auchData, pBuf, ulLen); 
			gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufWIdx].blValid = R_IN32_TRUE;

			gulR_IN32C_RcvBufWIdx++;
			if (R_IN32C_2ND_BUFFER_NUM <= gulR_IN32C_RcvBufWIdx) {
				gulR_IN32C_RcvBufWIdx = 0;
			}
			else {
			}

			(VOID)gerR_IN32D_SetRcvTranFin();

		}
		else {
			(VOID)gerR_IN32D_RcvDisable();
			
			break;	

		}

	} 

	return erRet;
}


ERRCODE erR_IN32C_GetRcvTran2(
	ULONG*	pulSize,		
	VOID**	ppRcvbuf		
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	if (R_IN32_TRUE == gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufRIdx].blValid) {
	
		*pulSize = gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufRIdx].ulLen;
		*ppRcvbuf = gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufRIdx].auchData;
	
	}
	else {
		erRet = R_IN32C_NG_NODATA;

		(VOID)gerR_IN32D_RcvEnable();

	}

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_SetRcvTranFin2(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gastR_IN32C_RcvBuf[gulR_IN32C_RcvBufRIdx].blValid = R_IN32_FALSE;

	gulR_IN32C_RcvBufRIdx++;
	if (R_IN32C_2ND_BUFFER_NUM <= gulR_IN32C_RcvBufRIdx) {
		gulR_IN32C_RcvBufRIdx = 0;
	}
	else {
	}

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_ChangeSyncStatusToReady(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gstR_IN32C.stMotSyncCtl.ulSyncStatus = R_IN32C_MOTSYNC_READY;

	return erRet;
}

ERRCODE erR_IN32C_CheckSyncFrmTmgErr(
	R_IN32D_MSTMYSTATUS_INFO_T*	pstMyStatus
)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG   ulSyncFlgCheckData;

	if ( (R_IN32C_MOTSYNC_START == gstR_IN32C.stMotSyncCtl.ulSyncStatus) ||
	     (R_IN32C_MOTSYNC_FINISH == gstR_IN32C.stMotSyncCtl.ulSyncStatus) ) {
		if( 1 == gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckStart ) {

			ulSyncFlgCheckData = FRAME_COM_SYNCFLG;

			if( 1 == gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest ) {

				if( ulSyncFlgCheckData != pstMyStatus->ulSyncFlg ) {
					gstR_IN32C.stMotSyncCtl.ulSyncFrameErr = 1;
				}

				gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest = 0;
			}
			else {

				if( ulSyncFlgCheckData == pstMyStatus->ulSyncFlg ) {
					gstR_IN32C.stMotSyncCtl.ulSyncFrameErr = 1;
				}
			}
		}
	}
	else {
	}

	return erRet;
}

ERRCODE erR_IN32C_SeqMain_SyncCommExec(VOID)
{
	ERRCODE erRet = R_IN32C_NG_OTHER;

	if ( R_IN32C_MOTSYNC_START == gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
	}
	else if ( R_IN32C_MOTSYNC_READY == gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
		gstR_IN32C.stMotSyncCtl.ulSyncCounter = 0;
		gstR_IN32C.stMotSyncCtl.ulSyncStatus = R_IN32C_MOTSYNC_START;
	}
	else {
		return erRet;
	}

	switch( gstR_IN32C.stMotSyncCtl.ulSyncCounter ) {
	case 1:
	case 2:
	case 3:
	case 4:
		break;

	case 5:
		gstR_IN32C.stMotSyncCtl.ulSyncStatus = R_IN32C_MOTSYNC_FINISH;
		erRet = R_IN32C_OK;
		break;

	case 0:
	default:
		break;
	}

	return erRet;
}

ERRCODE erR_IN32C_RequestSyncOffCheck(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckStart = 1;
	gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest = 1;

	return erRet;
}

ERRCODE erR_IN32C_CancelSyncOffCheck(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if( 1 == gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest ) {
		gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest = 0;
	}

	return erRet;
}

ERRCODE erR_IN32C_CancelSyncOffCheckForNonRecv(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if( 1 == gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest ) {
		gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest = 0;
	}

	return erRet;
}

ERRCODE erR_IN32C_CheckSyncFrameErr(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if( 1 == gstR_IN32C.stMotSyncCtl.ulSyncFrameErr ) {
		erRet = R_IN32C_NG_NODATA;
		gstR_IN32C.stMotSyncCtl.ulSyncFrameErr = 0;
	}

	return erRet;
}

ERRCODE erR_IN32C_CountSyncOn(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if( R_IN32C_MOTSYNC_FINISH == gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
	}
	else {
		gstR_IN32C.stMotSyncCtl.ulSyncCounter += 1;
	}

	return erRet;
}

ERRCODE erR_IN32C_CountSyncOff(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if( R_IN32C_MOTSYNC_FINISH == gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
		if( 0xffffffff != gstR_IN32C.stMotSyncCtl.ulSyncWinOffCounterAcml ) {
			gstR_IN32C.stMotSyncCtl.ulSyncWinOffCounterAcml += 1;
		}
	}
	else {
		gstR_IN32C.stMotSyncCtl.ulSyncCounter = 0;
	}

	return erRet;
}

/*** EOF ***/
