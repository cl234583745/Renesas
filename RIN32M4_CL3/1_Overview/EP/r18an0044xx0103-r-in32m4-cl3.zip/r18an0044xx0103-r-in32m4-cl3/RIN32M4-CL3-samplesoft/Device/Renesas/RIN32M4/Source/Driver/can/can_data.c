/**
 *******************************************************************************
 * @file  can_status.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************

  @brief  Get receive message buffer data(ID,Data,DLC)
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @param  [out] canid : CAN ID buffer address
  @param  [out] data  : Receive data buffer address
  @param  [out] dlc   : Data length code buffer address
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_get_id_data_dlc(uint8_t ch,uint8_t bufno,uint32_t *canid,uint8_t *data,uint8_t *dlc)
{
	CAN_MSG_TypeDef *CAN_MSG;
	uint8_t		data_cnt;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/
	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Is a new frame?														*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MDTNF) == 0) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Clear FCNnMmDTNF bit												*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->H.FCNnMmCTL = CLR_CAN_MDTNF;

	/*----------------------------------------------------------------------*/
	/*	Get CAN id															*/
	/*----------------------------------------------------------------------*/
	*canid = CAN_GET_ID(CAN_MSG->W.FCNnMmMID0W);

	/*----------------------------------------------------------------------*/
	/*	Get dlc																*/
	/*----------------------------------------------------------------------*/
	*dlc = (CAN_MSG->B.FCNnMmDTLGB & MSK_CAN_DTLG);

	/*----------------------------------------------------------------------*/
	/*	Get message data													*/
	/*----------------------------------------------------------------------*/
	for (data_cnt = 0 ; ((data_cnt < *dlc) && (data_cnt < LEN_CANDATA)) ; data_cnt++) {
		data[data_cnt] = (uint8_t)CAN_MSG->B.FCNnMmDATB[data_cnt];
	}

	/*----------------------------------------------------------------------*/
	/*	Check FCNnMmDTNF and FCNnMmMUCF bit									*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & (MSK_CAN_MDTNF | MSK_CAN_MMUCF)) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Get receive message buffer data(Data,DLC)
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @param  [out] data  : Receive data buffer address
  @param  [out] dlc   : Data length code buffer address
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_get_data_dlc(uint8_t ch,uint8_t bufno,uint8_t *data,uint8_t *dlc)
{
	CAN_MSG_TypeDef *CAN_MSG;
	uint8_t			data_cnt;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0){
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Is a new frame?														*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MDTNF) == 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Clear FCNnMmDTNF bit												*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->H.FCNnMmCTL = CLR_CAN_MDTNF;

	/*----------------------------------------------------------------------*/
	/*	Get dlc																*/
	/*----------------------------------------------------------------------*/
	*dlc = (uint8_t)(CAN_MSG->B.FCNnMmDTLGB & MSK_CAN_DTLG);

	/*----------------------------------------------------------------------*/
	/*	Get message data													*/
	/*----------------------------------------------------------------------*/
	for (data_cnt = 0 ; ((data_cnt < *dlc) && (data_cnt < LEN_CANDATA)) ; data_cnt++) {
		data[data_cnt] = (uint8_t)CAN_MSG->B.FCNnMmDATB[data_cnt];
	}

	/*----------------------------------------------------------------------*/
	/*	Check FCNnMmDTNF and FCNnMmMUCF bit									*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & (MSK_CAN_MDTNF | MSK_CAN_MMUCF)) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/

	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Setup of buffer data(ID,Data,DLC)
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @param  [in] canid : CAN ID
                     : Standard  ID = CAN_SET_STD_ID(canid)
                     : Extension ID = CAN_SET_EXT_ID(canid)
  @param  [in] data  : Transmit data buffer address
  @param  [in] dlc   : Data length code
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_set_id_data_dlc(uint8_t ch,uint8_t bufno,uint32_t canid,uint8_t *data,uint8_t dlc)
{
	CAN_MSG_TypeDef *CAN_MSG;
	uint8_t			dlc_msk;
	uint8_t			data_cnt;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/

	/*
	the state of sending? * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0){
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	state of sending?													*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MTRQF) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Check FCNnMmRDYF bit												*/
	/*----------------------------------------------------------------------*/
	/*
	 * Clear FCNnMmRDYF bit
	 */
	CAN_MSG->H.FCNnMmCTL = CLR_CAN_MRDYF;
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MRDYF) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set CAN id															*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->W.FCNnMmMID0W = canid;

	/*----------------------------------------------------------------------*/
	/*	Set dlc																*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->B.FCNnMmDTLGB = (dlc_msk = (uint8_t)(dlc & MSK_CAN_DTLG));

	/*----------------------------------------------------------------------*/
	/*	Set message data													*/
	/*----------------------------------------------------------------------*/
	for (data_cnt = 0 ; ((data_cnt < dlc_msk) && (data_cnt < LEN_CANDATA)) ; data_cnt++) {
		CAN_MSG->B.FCNnMmDATB[data_cnt] = data[data_cnt];
	}

	/*----------------------------------------------------------------------*/
	/*	Message ready(Set FCNnMmRDYF bit)									*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->H.FCNnMmCTL = SET_CAN_MRDYF;

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Setup of buffer data(Data)
  @param  [in] ch     : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] bufno  : Message buffer number
  @param  [in] data  : Transmit data buffer address
  @param  [in] dlc   : Data length code
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_set_data(uint8_t ch,uint8_t bufno,uint8_t *data)
{
	CAN_MSG_TypeDef *CAN_MSG;
	uint8_t		dlc_msk;
	uint8_t		data_cnt;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Channel No, CAN Buffer No Max)						*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}

	/*
	 * CAN Buffer No Max/Min
	 */
	if (CAN_MSG_BUF_NUM <= bufno) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter (Use CAN Buffer No) 								*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMA) == 0){
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	state of sending?													*/
	/*----------------------------------------------------------------------*/
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MTRQF) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Check FCNnMmRDYF bit												*/
	/*----------------------------------------------------------------------*/
	/*
	 * Clear FCNnMmRDYF bit
	 */
	CAN_MSG->H.FCNnMmCTL = CLR_CAN_MRDYF;
	if((CAN_MSG->H.FCNnMmCTL & MSK_CAN_MRDYF) != 0){
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Get dlc																*/
	/*----------------------------------------------------------------------*/
	dlc_msk = (uint8_t)(CAN_MSG->B.FCNnMmDTLGB & MSK_CAN_DTLG);

	/*----------------------------------------------------------------------*/
	/*	Set message data													*/
	/*----------------------------------------------------------------------*/
	for (data_cnt = 0 ; ((data_cnt < dlc_msk) && (data_cnt < LEN_CANDATA)) ; data_cnt++) {
		CAN_MSG->B.FCNnMmDATB[data_cnt] = data[data_cnt];
	}

	/*----------------------------------------------------------------------*/
	/*	Message ready(Set FCNnMmRDYF bit)									*/
	/*----------------------------------------------------------------------*/
	CAN_MSG->H.FCNnMmCTL = SET_CAN_MRDYF;

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

