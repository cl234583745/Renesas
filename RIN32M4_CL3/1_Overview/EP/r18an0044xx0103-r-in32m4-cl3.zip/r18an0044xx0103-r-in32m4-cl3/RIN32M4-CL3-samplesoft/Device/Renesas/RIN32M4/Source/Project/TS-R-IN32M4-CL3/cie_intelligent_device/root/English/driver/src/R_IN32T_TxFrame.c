/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_TxFrame.c                                                 */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_ASIC.h"
#include "R_IN32T_FrmForm.h"
#include "R_IN32T_TxFrame.h"
#include "R_IN32T_Data.h"

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
static USHORT	usSlmpRequestSerialNoManage = 0x0000;			
static UCHAR	uchID = (UCHAR)0;								

VOID R_IN32T_TxFrame_Tran1Head_Make(
	const R_IN32T_TRAN1_FRM_MAKE_T*	pstTran1Make,
	USHORT							usTranTDis
)
{
	R_IN32T_FRM_TRN1HDR_T*		pstTran1;		
	ULONG					ulTemp;			
	USHORT					usTemp;			
	const UCHAR*			puchTemp;		

	pstTran1 = (R_IN32T_FRM_TRN1HDR_T*)gaulR_IN32T_NCycTxBufAdr[ usTranTDis - TDISC_NO_TRANSIENT ];
	puchTemp = pstTran1Make->puchDesMACAddr;
	pstTran1->stFRMHDR.auchDesMACAddr[0] = *puchTemp;
	pstTran1->stFRMHDR.auchDesMACAddr[1] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchDesMACAddr[2] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchDesMACAddr[3] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchDesMACAddr[4] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchDesMACAddr[5] = *(++ puchTemp);

	puchTemp = pstTran1Make->puchSouMACAddr;
	pstTran1->stFRMHDR.auchSouMACAddr[0] = *puchTemp;
	pstTran1->stFRMHDR.auchSouMACAddr[1] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchSouMACAddr[2] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchSouMACAddr[3] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchSouMACAddr[4] = *(++ puchTemp);
	pstTran1->stFRMHDR.auchSouMACAddr[5] = *(++ puchTemp);

	pstTran1->stFRMHDR.usEtherType = FRAME_COM_FRMTYPE;

	pstTran1->stFRMHDR.uchFrmType = (UCHAR)FTYPE_Transient1;

	pstTran1->stFRMHDR.uchDataType = pstTran1Make->uchDataType;

	usTemp = gusR_IN32S_SwapS( pstTran1Make->usNodeID );
	pstTran1->stFRMHDR.Union1.stNode.usNodeID = usTemp;

	pstTran1->stFRMHDR.Union1.stConnect.uchConnect = pstTran1Make->uchConnect;

	pstTran1->stFRMHDR.Union1.stConnect.uchZReserved = (UCHAR)0;

	usTemp = gusR_IN32S_SwapS( pstTran1Make->usStNo );
	pstTran1->stFRMHDR.usStNo = usTemp;

	pstTran1->stFRMHDR.uchProtocol = (UCHAR)((R_IN32U_PROTOCOL_VER << 4) | R_IN32U_PROTOCOL_CLASS);

	pstTran1->stFRMHDR.uchReserved1 = (UCHAR)0;

	pstTran1->stFRMHDR.ulHec = 0UL;

	pstTran1->ulReserved1 = 0UL;

	pstTran1->uchSeqNo = pstTran1Make->uchSeqNo;

	pstTran1->uchIdentNo = pstTran1Make->uchIdentNo;

	usTemp = gusR_IN32S_SwapS( pstTran1Make->usTrnDatAllSize );
	pstTran1->usTrnDatAllSize = usTemp;

	ulTemp = gulR_IN32S_SwapL( pstTran1Make->ulOffsetAdr );
	pstTran1->ulOffsetAdr = ulTemp;

	usTemp = gusR_IN32S_SwapS( pstTran1Make->usTrnDatSize );
	pstTran1->usTrnDatSize = usTemp;

	usTemp = gusR_IN32S_SwapS( pstTran1Make->usDataSubType );
	pstTran1->usDataSubType = usTemp;

	return;
}

ERRCODE erR_IN32T_TxFrame_TxTran_1Frame(
	USHORT		usTranTDis,
	USHORT		usDatSize,
	USHORT		usOffset
)
{
	USHORT	usCycTxPerm;	
	ERRCODE	erResult;		

	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;
	TRAN_COUNTER_TAG	stTRAN_COUNTER;

	usCycTxPerm  = TX->ulCYC_TX_PERMISSION;

	/*----------------------------------*/	
	TX->ulCYC_TX_PERMISSION &= ~(ASIC_BIT0 | ASIC_BIT1);
	TX->TXCNT.b02ZSndStartType = TXCNT_SND_START_TYPE_FWREGWRITE;
	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));
	gR_IN32S_Memset(&stTRAN_COUNTER, 0x00, sizeof(TRAN_COUNTER_TAG));
	stTRAN_COUNTER.b08ZTranSendEnableRemainNum = 0x01;
	OUT32(&TX->TRAN_COUNTER, *((ULONG*)&stTRAN_COUNTER));
	stTmpTDISC1.b09ZNextReadDiscriptorChain = TDISC_NO_TOKEN;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_TRN_FIELD;
	stTmpTDISC1.b01ZSendFrmExperienced = (ULONG)R_IN32_ON;
	stTmpTDISC1.b01ZLastDiscriptorFlag = R_IN32_ON;
	stTmpTDISC2.b0BZSendSize = (ULONG)usDatSize;
	stTmpTDISC3.b1AZSendDataDMAFromAddress = usOffset;
	OUT32(&TD->aTD_TDS[usTranTDis].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[usTranTDis].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[usTranTDis].R_TDISC3, *((ULONG*)&stTmpTDISC3));
	TX->ulTX_HEAD_NO = (ULONG)usTranTDis;

	erResult = erR_IN32T_TxStart();



	TX->ulCYC_TX_PERMISSION = usCycTxPerm;

	return( erResult );
}


ERRCODE gerR_IN32T_TxFrame_CreateEtherCcieHeader (
	const UCHAR* puchSndMac,					
	const UCHAR* puchMyMac,						
	UCHAR uchFrameClassification,				
	UCHAR uchDataClassification,				
	R_IN32_NONCICLIC_FRAME_T* pstCOMMON			
)
{
	ERRCODE		erRet;
	USHORT		usTemp;
	USHORT		usNodeNumber;									
	UCHAR		uchNetworkNumber;								
	UCHAR		auchMACAddress[6];								
	UCHAR		auchMyMACAddress[6];							
	UCHAR		i;
	
	
	erRet = R_IN32_OK;
	
	(VOID)gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
	
	for (i=0 ; i < R_IN32_MACADR_SZ ; i++) {
		auchMACAddress[i] = *(puchSndMac+i);
		auchMyMACAddress[i] = *(puchMyMac+i);
	}
	

	usTemp = (USHORT)auchMACAddress[0];
	usTemp |= ((USHORT)auchMACAddress[1] << 8 );
	pstCOMMON->usToAddress1 = usTemp;
	usTemp = (USHORT)auchMACAddress[2];
	usTemp |= ((USHORT)auchMACAddress[3] << 8 );
	pstCOMMON->usToAddress2 = usTemp;
	usTemp = (USHORT)auchMACAddress[4];
	usTemp |= ((USHORT)auchMACAddress[5] << 8 );
	pstCOMMON->usToAddress3 = usTemp;

	usTemp = (USHORT)auchMyMACAddress[0];
	usTemp |= ((USHORT)auchMyMACAddress[1] << 8 );
	pstCOMMON->usFromAddress1 = usTemp;
	usTemp = (USHORT)auchMyMACAddress[2];
	usTemp |= ((USHORT)auchMyMACAddress[3] << 8 );
	pstCOMMON->usFromAddress2 = usTemp;
	usTemp = (USHORT)auchMyMACAddress[4];
	usTemp |= ((USHORT)auchMyMACAddress[5] << 8 );
	pstCOMMON->usFromAddress3 = usTemp;

	pstCOMMON->usType = R_IN32_FRAMETYPE;



	pstCOMMON->uchFrameClassification = uchFrameClassification;

	pstCOMMON->uchDataClassification = uchDataClassification;

	usTemp = gusR_IN32_GetNodeID();
	pstCOMMON->usNodeID = gusR_IN32S_SwapS( usTemp );

	pstCOMMON->uchConnectionInformation = (UCHAR)0;

	pstCOMMON->uchReserved = (UCHAR)0;

	pstCOMMON->usMyStationNumber = gusR_IN32S_SwapS( usNodeNumber );

	pstCOMMON->stFRAME_INFO.uniFrameInfo.usAll = (USHORT)0;

	pstCOMMON->stFRAME_INFO.uniFrameInfo.usAll |= (R_IN32_FRAME_INFO_PROTOCOL_VER_MASK & (R_IN32_PROTOCOL_VER << R_IN32_FRAME_INFO_PROTOCOL_VER_SHIFT) );

	pstCOMMON->stFRAME_INFO.uniFrameInfo.usAll |= (R_IN32_FRAME_INFO_PROTOCOL_TYPE_MASK & R_IN32_PROTOCOL_CLASS);

	pstCOMMON->stFRAME_INFO.uniFrameInfo.usAll |= (R_IN32_FRAME_INFO_RESERVED & (R_IN32_FRAME_INFO_RSV1 << R_IN32_FRAME_INFO_RESERVED_SHIFT));
	
	return erRet;

}
ERRCODE gerR_IN32T_TxFrame_CreateTransient1Header (
	USHORT				usDataSubClassification, 			
	USHORT				usTransientDataSize,				
	R_IN32_TRAN1_HEAD_T*	pstHEAD								
)
{
	ERRCODE		erRet;
	ULONG		ulDataSize;
	
	
	erRet = R_IN32_OK;
	
	if( TRANSIENT_DATA_SYNTHETIC_MAX_SIZE < usTransientDataSize ){
		erRet = R_IN32_ERR;
	}
	else {
		
		ulDataSize = usTransientDataSize;
		
		pstHEAD->ulReserved1 = 0UL;

		pstHEAD->uchSequentialNumber = TRNHEAD_SERIALNO_INIT;

		pstHEAD->uchIdentificationNumber = guchR_IN32T_TxFrame_GetTransient1IdentificationNumber();

		pstHEAD->usTransientDataAllSize = gusR_IN32S_SwapS( (USHORT)ulDataSize );

		pstHEAD->ulOffsetAddress = 0UL;

		pstHEAD->usTransientDataDivisionSize = gusR_IN32S_SwapS( (USHORT)ulDataSize );

		pstHEAD->usDataSubClassification = gusR_IN32S_SwapS( usDataSubClassification );
	}
	return erRet;
}

ERRCODE gerR_IN32T_TxFrame_CreateRequestSlmpHeader (
	R_IN32_SLMP_REQUSET_SETTING_T*	pstSlmpReqSetting,		
	R_IN32_SLMP_REQUEST_FRAME_T*		pstSlmpExHead,			
	ULONG*							pulAllDataSize,			
	USHORT*							pusReqSerialNo			
)
{
	ERRCODE		erRet;											
	ULONG		ulDataSize;										
	ULONG		ulTrnSize;										
	USHORT		usNodeNumber;									
	UCHAR		uchNetworkNumber;								
	
	erRet = R_IN32_OK;
	
	ulTrnSize = pstSlmpReqSetting->usL + sizeof(R_IN32_SLMP_HEAD_T)						
									   + sizeof(R_IN32_CCLINK_HEAD_T);
	
	if ( ( R_IN32_NETWORK_NUMBER_MIN > pstSlmpReqSetting->usNwNo ) 
	||   ( R_IN32_NETWORK_NUMBER_MAX < pstSlmpReqSetting->usNwNo ) 						
	||   ( ( R_IN32_NODE_NUMBER_MAX < pstSlmpReqSetting->uchNode ) 
		&& ( COM_DSG_MNG_STNO != pstSlmpReqSetting->uchNode )
		&& ( COM_CUR_MNG_STNO != pstSlmpReqSetting->uchNode ) 
		&& ( COM_GROBAL_STNO  != pstSlmpReqSetting->uchNode ) )							
	||   ( TRANSIENT_DATA_SYNTHETIC_MAX_SIZE < ulTrnSize ) ) {							
		erRet = R_IN32_ERR;
	}
	else {
		usSlmpRequestSerialNoManage++;
		
		if( 0 == usSlmpRequestSerialNoManage){
			usSlmpRequestSerialNoManage = 1;
		}
		
		*pusReqSerialNo = usSlmpRequestSerialNoManage;
		
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		
		ulDataSize = ulTrnSize - 2;												
		
		pstSlmpExHead->stCCLinkHead.usL = ulDataSize;
		
		pstSlmpExHead->stCCLinkHead.uchGcnt = R_IN32_GCNT_INITIAL;
		
		pstSlmpExHead->stCCLinkHead.uchTP = (UCHAR)0x00;
		
		pstSlmpExHead->stCCLinkHead.uchFNO = (UCHAR)0x00;
		
		pstSlmpExHead->stCCLinkHead.uchDT = (UCHAR)0x00;
		
		pstSlmpExHead->stCCLinkHead.uchDA = pstSlmpReqSetting->uchNode;
		
		pstSlmpExHead->stCCLinkHead.uchSA = (UCHAR)usNodeNumber;
		
		pstSlmpExHead->stCCLinkHead.uchDAT = (UCHAR)0x22;
		
		pstSlmpExHead->stCCLinkHead.uchSAT = (UCHAR)0x22;
		
		pstSlmpExHead->stCCLinkHead.uchDMF = (UCHAR)0x03;
		
		pstSlmpExHead->stCCLinkHead.uchSMF = (UCHAR)0x04;
		
		pstSlmpExHead->stCCLinkHead.uchDNA = (UCHAR)pstSlmpReqSetting->usNwNo;
		
		pstSlmpExHead->stCCLinkHead.uchDS = pstSlmpReqSetting->uchNode;
		
		pstSlmpExHead->stCCLinkHead.usDID = pstSlmpReqSetting->usConectInfo;
		
		pstSlmpExHead->stCCLinkHead.uchSNA = uchNetworkNumber;
		
		pstSlmpExHead->stCCLinkHead.uchSS = usNodeNumber;
		
		pstSlmpExHead->stCCLinkHead.usSID = pstSlmpReqSetting->usConectInfo;
		
		ulDataSize = ulDataSize - (USHORT)(sizeof(UCHAR)						
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(USHORT)						
										+ sizeof(UCHAR)							
										+ sizeof(UCHAR)							
										+ sizeof(USHORT)						
										+ sizeof(USHORT));						
		
		pstSlmpExHead->stCCLinkHead.usL1 = ulDataSize;
		
		pstSlmpExHead->stCCLinkHead.stCT.uchCt = 0x30;
		pstSlmpExHead->stCCLinkHead.stCT.stCtDtl.b1ZFrameType = 0x00;		
		
		pstSlmpExHead->stCCLinkHead.uchDno = (UCHAR)0x00;
		
		pstSlmpExHead->stCCLinkHead.usAPS = gusR_IN32S_SwapS(usSlmpRequestSerialNoManage);
		
		
		
		pstSlmpExHead->stSlmpHead.usFType = R_IN32_FTYPE_REQUEST;
		
		pstSlmpExHead->stSlmpHead.usSerialNo = usSlmpRequestSerialNoManage;
		
		pstSlmpExHead->stSlmpHead.usRsv = (USHORT)0x0000;
		
		pstSlmpExHead->stSlmpHead.uchNetworkNo = (UCHAR)pstSlmpReqSetting->usNwNo;
		
		pstSlmpExHead->stSlmpHead.uchStationNo = (UCHAR)pstSlmpReqSetting->uchNode;
		
		pstSlmpExHead->stSlmpHead.usModuleIONo = pstSlmpReqSetting->usConectInfo;
		
		pstSlmpExHead->stSlmpHead.uchRequStNo = (UCHAR)0x00;
		
		pstSlmpExHead->stSlmpHead.usL = pstSlmpReqSetting->usL;
		
		pstSlmpExHead->usTimer = 0x0000;
		
		pstSlmpExHead->usCommand = pstSlmpReqSetting->usCommand;
		
		pstSlmpExHead->usSubCommand = pstSlmpReqSetting->usSubCommand;
		
		
		*pulAllDataSize = ulTrnSize;
		
		
		erRet = R_IN32_OK;
		
	}
	
	return erRet;
	
}

ERRCODE gerR_IN32T_TxFrame_CreateResponseSlmpHeader (
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstReqSlmpExHead,	
	USHORT								usSlmpDataSize,		
	R_IN32_SLMP_RESPONSE_FRAME_T*			pstSlmpExHead		
)
{
	ERRCODE		erRet;											
	USHORT		usSizeL;										
	USHORT		usSizeL1;										
	USHORT		usSizeSlmpL;									
	
	
	erRet = R_IN32_OK;
	
	usSizeL  = ((USHORT)(sizeof(R_IN32_SLMP_RESPONSE_FRAME_T)		
						   + usSlmpDataSize
						   - sizeof(USHORT)));					
	
	usSizeL1 = ((USHORT)(sizeof(UCHAR)							
						   + sizeof(UCHAR)						
						   + sizeof(USHORT)						
						   + sizeof(USHORT)						
						   + sizeof(R_IN32_SLMP_HEAD_T)			
						   + sizeof(USHORT)						
						   + usSlmpDataSize));					
	
	usSizeSlmpL = ((USHORT)(sizeof(USHORT)						
						  + usSlmpDataSize));					
	
	pstSlmpExHead->stCCLinkHead.usL = usSizeL;

	pstSlmpExHead->stCCLinkHead.uchGcnt = R_IN32_GCNT_INITIAL;

	pstSlmpExHead->stCCLinkHead.uchTP = (UCHAR)0x00;

	pstSlmpExHead->stCCLinkHead.uchFNO = (UCHAR)0x00;

	pstSlmpExHead->stCCLinkHead.uchDT = (UCHAR)0x00;

	pstSlmpExHead->stCCLinkHead.uchDA = pstReqSlmpExHead->stCCLinkHead.uchSA;

	pstSlmpExHead->stCCLinkHead.uchSA = pstReqSlmpExHead->stCCLinkHead.uchDA;

	pstSlmpExHead->stCCLinkHead.uchDAT = pstReqSlmpExHead->stCCLinkHead.uchSAT;

	pstSlmpExHead->stCCLinkHead.uchSAT = pstReqSlmpExHead->stCCLinkHead.uchDAT;

	pstSlmpExHead->stCCLinkHead.uchDMF = pstReqSlmpExHead->stCCLinkHead.uchSMF;

	pstSlmpExHead->stCCLinkHead.uchSMF = pstReqSlmpExHead->stCCLinkHead.uchDMF;

	pstSlmpExHead->stCCLinkHead.uchDNA = pstReqSlmpExHead->stCCLinkHead.uchSNA;

	pstSlmpExHead->stCCLinkHead.uchDS = pstReqSlmpExHead->stCCLinkHead.uchSS;

	pstSlmpExHead->stCCLinkHead.usDID = pstReqSlmpExHead->stCCLinkHead.usSID;

	pstSlmpExHead->stCCLinkHead.uchSNA = pstReqSlmpExHead->stCCLinkHead.uchDNA;

	pstSlmpExHead->stCCLinkHead.uchSS = pstReqSlmpExHead->stCCLinkHead.uchDS;

	pstSlmpExHead->stCCLinkHead.usSID = pstReqSlmpExHead->stCCLinkHead.usDID;

	pstSlmpExHead->stCCLinkHead.usL1 = usSizeL1;

	pstSlmpExHead->stCCLinkHead.stCT.uchCt = pstReqSlmpExHead->stCCLinkHead.stCT.uchCt;
	pstSlmpExHead->stCCLinkHead.stCT.stCtDtl.b1ZFrameType = 0x01;

	pstSlmpExHead->stCCLinkHead.uchDno = (UCHAR)0x00;

	pstSlmpExHead->stCCLinkHead.usAPS = pstReqSlmpExHead->stCCLinkHead.usAPS;

	pstSlmpExHead->usRSTS = (USHORT)0x0000;



	pstSlmpExHead->stSlmpHead.usFType = R_IN32_FTYPE_RESPONSE;

	pstSlmpExHead->stSlmpHead.usSerialNo = pstReqSlmpExHead->stSlmpHead.usSerialNo;

	pstSlmpExHead->stSlmpHead.usRsv = (USHORT)0x0000;

	pstSlmpExHead->stSlmpHead.uchNetworkNo = pstReqSlmpExHead->stSlmpHead.uchNetworkNo;

	pstSlmpExHead->stSlmpHead.uchStationNo = pstReqSlmpExHead->stSlmpHead.uchStationNo;

	pstSlmpExHead->stSlmpHead.usModuleIONo = pstReqSlmpExHead->stSlmpHead.usModuleIONo;

	pstSlmpExHead->stSlmpHead.uchRequStNo = pstReqSlmpExHead->stSlmpHead.uchRequStNo;

	pstSlmpExHead->stSlmpHead.usL = usSizeSlmpL;

	pstSlmpExHead->usFinCode = (USHORT)0x0000;
	
	
	return erRet;
	
}

UCHAR guchR_IN32T_TxFrame_GetTransient1IdentificationNumber(VOID)
{
	uchID++;

	return uchID;
}

/*** EOF ***/
