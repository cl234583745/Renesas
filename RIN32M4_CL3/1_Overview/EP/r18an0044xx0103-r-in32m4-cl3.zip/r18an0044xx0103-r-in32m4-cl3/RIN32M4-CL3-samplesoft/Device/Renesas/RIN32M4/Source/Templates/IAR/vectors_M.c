/**
 *******************************************************************************
 * @file  vectors_M.c
 * @brief sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#pragma language=extended
#pragma segment="CSTACK"

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>
#include <time.h>
#include "RIN32M4.h"
#include "kernel.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/
extern void __iar_program_start( void );

typedef void( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
extern void NMI_Handler( void );
extern void HardFault_Handler( void );
extern void MemManage_Handler( void );
extern void BusFault_Handler( void );
extern void UsageFault_Handler( void );
extern void SVC_Handler( void );
extern void DebugMon_Handler( void );
extern void PendSV_Handler( void );
extern void SysTick_Handler( void );

extern void TAUJ2I0_IRQHandler( void );
extern void TAUJ2I1_IRQHandler( void );
extern void TAUJ2I2_IRQHandler( void );
extern void TAUJ2I3_IRQHandler( void );
extern void UAJ0TIT_IRQHandler( void );
extern void UAJ0TIR_IRQHandler( void );
extern void UAJ1TIT_IRQHandler( void );
extern void UAJ1TIR_IRQHandler( void );
extern void CSIH0IC_IRQHandler( void );
extern void CSIH0IR_IRQHandler( void );
extern void CSIH0IJC_IRQHandler( void );
extern void CSIH1IC_IRQHandler( void );
extern void CSIH1IR_IRQHandler( void );
extern void CSIH1IJC_IRQHandler( void );
extern void IICB0TIA_IRQHandler( void );
extern void IICB1TIA_IRQHandler( void );
extern void FCN0REC_IRQHandler( void );
extern void FCN0TRX_IRQHandler( void );
extern void FCN0WUP_IRQHandler( void );
extern void FCN1REC_IRQHandler( void );
extern void FCN1TRX_IRQHandler( void );
extern void FCN1WUP_IRQHandler( void );
extern void DMA00_IRQHandler( void );
extern void DMA01_IRQHandler( void );
extern void DMA02_IRQHandler( void );
extern void DMA03_IRQHandler( void );
extern void RTDMA_IRQHandler( void );
extern void TAUDI0_IRQHandler( void );
extern void TAUDI1_IRQHandler( void );
extern void TAUDI2_IRQHandler( void );
extern void TAUDI3_IRQHandler( void );
extern void TAUDI4_IRQHandler( void );
extern void BUFDMA_IRQHandler( void );
extern void ETHPHY0_IRQHandler( void );
extern void ETHPHY1_IRQHandler( void );
extern void ETHMIICMP_IRQHandler( void );
extern void ETHPAUSECMP_IRQHandler( void );
extern void ETHTXCMP_IRQHandler( void );
extern void ETHSW_IRQHandler( void );
extern void ETHSWDLR_IRQHandler( void );
extern void ETHSWSYNC_IRQHandler( void );
extern void ETHRXFIFO_IRQHandler( void );
extern void ETHTXFIFO_IRQHandler( void );
extern void ETHRXDMA_IRQHandler( void );
extern void ETHTXDMA_IRQHandler( void );
extern void MACDMARXFRM_IRQHandler( void );
extern void INTPZ0_IRQHandler( void );
extern void INTPZ1_IRQHandler( void );
extern void INTPZ2_IRQHandler( void );
extern void INTPZ3_IRQHandler( void );
extern void INTPZ4_IRQHandler( void );
extern void INTPZ5_IRQHandler( void );
extern void INTPZ6_IRQHandler( void );
extern void INTPZ7_IRQHandler( void );
extern void INTPZ8_IRQHandler( void );
extern void INTPZ9_IRQHandler( void );
extern void INTPZ10_IRQHandler( void );
extern void INTPZ11_IRQHandler( void );
extern void INTPZ12_IRQHandler( void );
extern void INTPZ13_IRQHandler( void );
extern void INTPZ14_IRQHandler( void );
extern void INTPZ15_IRQHandler( void );
extern void INTPZ16_IRQHandler( void );
extern void INTPZ17_IRQHandler( void );
extern void INTPZ18_IRQHandler( void );
extern void INTPZ19_IRQHandler( void );
extern void INTPZ20_IRQHandler( void );
extern void INTPZ21_IRQHandler( void );
extern void INTPZ22_IRQHandler( void );
extern void INTPZ23_IRQHandler( void );
extern void INTPZ24_IRQHandler( void );
extern void INTPZ25_IRQHandler( void );
extern void INTPZ26_IRQHandler( void );
extern void INTPZ27_IRQHandler( void );
extern void INTPZ28_IRQHandler( void );
extern void HWRTOS_IRQHandler( void );
extern void BRAMERR_IRQHandler( void );
extern void IICB0TIS_IRQHandler( void );
extern void IICB1TIS_IRQHandler( void );
extern void WDTA_IRQHandler( void );
extern void SFLASH_IRQHandler( void );
extern void UAJ0TIS_IRQHandler( void );
extern void UAJ1TIS_IRQHandler( void );
extern void CSIH0IRE_IRQHandler( void );
extern void CSIH1IRE_IRQHandler( void );
extern void FCN0ERR_IRQHandler( void );
extern void FCN1ERR_IRQHandler( void );
extern void DERR0_IRQHandler( void );
extern void DERR1_IRQHandler( void );
extern void ETHTXFIFOERR_IRQHandler( void );
extern void ETHRXERR_IRQHandler( void );
extern void ETHRXDERR_IRQHandler( void );
extern void ETHTXDERR_IRQHandler( void );
extern void BUFDMAERR_IRQHandler( void );
extern void LED0PHY0_IRQHandler( void );
extern void LED0PHY1_IRQHandler( void );
extern void IRAMECCSEC_IRQHandler( void );
extern void DRAMECCSEC_IRQHandler( void );
extern void BRAMECCSEC_IRQHandler( void );
extern void IRAMECCDED_IRQHandler( void );
extern void DRAMECCDED_IRQHandler( void );
extern void BRAMECCDED_IRQHandler( void );
extern void CCINMIZ_IRQHandler( void );
extern void CCIWDTZ_IRQHandler( void );
extern void CCIINTZ_IRQHandler( void );
extern void CCICLKLOSSZ_IRQHandler( void );
extern void NCHINT_IRQHandler( void );
extern void NCLINT_IRQHandler( void );
extern void GBEPHYFLF_IRQHandler( void );
extern void LED1PHY0_IRQHandler( void );
extern void LED1PHY1_IRQHandler( void );
extern void LED2PHY0_IRQHandler( void );
extern void LED2PHY1_IRQHandler( void );
extern void FPU_IRQHandler( void );
extern void INTPZ29_IRQHandler( void );
extern void NRAMECCSEC_IRQHandler( void );
extern void NRAMECCDED_IRQHandler( void );
extern void INTHSNGNREGBE_IRQHandler( void );
extern void INTHSNGNBE_IRQHandler( void );
extern void INTXSNGNBE_IRQHandler( void );
extern void MCINTWDTERR_IRQHandler( void );
extern void INTROK_IRQHandler( void );

/*============================================================================*/
/* Vector Table                                                               */
/*============================================================================*/

// The vector table is normally located at address 0.
// When debugging in RAM, it can be located in RAM, aligned to at least 2^6.
// If you need to define interrupt service routines,
// make a copy of this file and include it in your project.
// The name "__vector_table" has special meaning for C-SPY:
// it is where the SP start value is found, and the NVIC vector
// table register (VTOR) is initialized to this address if != 0.

#pragma location = "vectors"
intvec_elem __vector_table[] =
{
  { .__ptr = __sfe( "CSTACK" ) },
  __iar_program_start,
  NMI_Handler,
  HardFault_Handler,
  MemManage_Handler,
  BusFault_Handler,
  UsageFault_Handler,
  0,
  0,
  0,
  0,
  SVC_Handler,
  DebugMon_Handler,
  0,
  PendSV_Handler,
  SysTick_Handler,

  // External Interrupts 1 - 240
  // These are essentially unused, so will all
  // take the same default handler if invoked.
	TAUJ2I0_IRQHandler,
	TAUJ2I1_IRQHandler,
	TAUJ2I2_IRQHandler,
	TAUJ2I3_IRQHandler,
	UAJ0TIT_IRQHandler,
	UAJ0TIR_IRQHandler,
	UAJ1TIT_IRQHandler,
	UAJ1TIR_IRQHandler,
	CSIH0IC_IRQHandler,
	CSIH0IR_IRQHandler,
	CSIH0IJC_IRQHandler,
	CSIH1IC_IRQHandler,
	CSIH1IR_IRQHandler,
	CSIH1IJC_IRQHandler,
	IICB0TIA_IRQHandler,
	IICB1TIA_IRQHandler,
	FCN0REC_IRQHandler,
	FCN0TRX_IRQHandler,
	FCN0WUP_IRQHandler,
	FCN1REC_IRQHandler,
	FCN1TRX_IRQHandler,
	FCN1WUP_IRQHandler,
	DMA00_IRQHandler,
	DMA01_IRQHandler,
	DMA02_IRQHandler,
	DMA03_IRQHandler,
	RTDMA_IRQHandler,
	TAUDI0_IRQHandler,
	TAUDI1_IRQHandler,
	TAUDI2_IRQHandler,
	TAUDI3_IRQHandler,
	TAUDI4_IRQHandler,
	BUFDMA_IRQHandler,
	ETHPHY0_IRQHandler,
	ETHPHY1_IRQHandler,
	ETHMIICMP_IRQHandler,
	ETHPAUSECMP_IRQHandler,
	ETHTXCMP_IRQHandler,
	ETHSW_IRQHandler,
	ETHSWDLR_IRQHandler,
	ETHSWSYNC_IRQHandler,
	ETHRXFIFO_IRQHandler,
	ETHTXFIFO_IRQHandler,
	ETHRXDMA_IRQHandler,
	ETHTXDMA_IRQHandler,
	MACDMARXFRM_IRQHandler,
	0,												// Reserved 62
	INTPZ0_IRQHandler,
	INTPZ1_IRQHandler,
	INTPZ2_IRQHandler,
	INTPZ3_IRQHandler,
	INTPZ4_IRQHandler,
	INTPZ5_IRQHandler,
	INTPZ6_IRQHandler,
	INTPZ7_IRQHandler,
	INTPZ8_IRQHandler,
	INTPZ9_IRQHandler,
	INTPZ10_IRQHandler,
	INTPZ11_IRQHandler,
	INTPZ12_IRQHandler,
	INTPZ13_IRQHandler,
	INTPZ14_IRQHandler,
	INTPZ15_IRQHandler,
	INTPZ16_IRQHandler,
	INTPZ17_IRQHandler,
	INTPZ18_IRQHandler,
	INTPZ19_IRQHandler,
	INTPZ20_IRQHandler,
	INTPZ21_IRQHandler,
	INTPZ22_IRQHandler,
	INTPZ23_IRQHandler,
	INTPZ24_IRQHandler,
	INTPZ25_IRQHandler,
	INTPZ26_IRQHandler,
	INTPZ27_IRQHandler,
	INTPZ28_IRQHandler,
	HWRTOS_IRQHandler,
	BRAMERR_IRQHandler,
	IICB0TIS_IRQHandler,
	IICB1TIS_IRQHandler,
	WDTA_IRQHandler,
	SFLASH_IRQHandler,
	UAJ0TIS_IRQHandler,
	UAJ1TIS_IRQHandler,
	CSIH0IRE_IRQHandler,
	CSIH1IRE_IRQHandler,
	FCN0ERR_IRQHandler,
	FCN1ERR_IRQHandler,
	DERR0_IRQHandler,
	DERR1_IRQHandler,
	ETHTXFIFOERR_IRQHandler,
	ETHRXERR_IRQHandler,
	ETHRXDERR_IRQHandler,
	ETHTXDERR_IRQHandler,
	BUFDMAERR_IRQHandler,
	LED0PHY0_IRQHandler,
	LED0PHY1_IRQHandler,
	0,												// Reserved 113
	0,												// Reserved 114
	IRAMECCSEC_IRQHandler,
	DRAMECCSEC_IRQHandler,
	BRAMECCSEC_IRQHandler,
	IRAMECCDED_IRQHandler,
	DRAMECCDED_IRQHandler,
	BRAMECCDED_IRQHandler,
	0,												// Reserved 121
	0,												// Reserved 122
	CCINMIZ_IRQHandler,
	CCIWDTZ_IRQHandler,
	CCIINTZ_IRQHandler,
	CCICLKLOSSZ_IRQHandler,
	NCHINT_IRQHandler,
	NCLINT_IRQHandler,
	0,												// Reserved 129
	0,												// Reserved 130
	0,												// Reserved 131
	0,												// Reserved 132
	0,												// Reserved 133
	0,												// Reserved 134
	0,												// Reserved 135
	0,												// Reserved 136
	GBEPHYFLF_IRQHandler,
	LED1PHY0_IRQHandler,
	LED1PHY1_IRQHandler,
	LED2PHY0_IRQHandler,
	LED2PHY1_IRQHandler,
	FPU_IRQHandler,
	INTPZ29_IRQHandler,
	0,												// Reserved 144
	NRAMECCSEC_IRQHandler,
	NRAMECCDED_IRQHandler,
	0,												// Reserved 147
	INTHSNGNREGBE_IRQHandler,
	INTHSNGNBE_IRQHandler,
	INTXSNGNBE_IRQHandler,
	0,												// Reserved 151
	MCINTWDTERR_IRQHandler,
	0,												// Reserved 153
	0,												// Reserved 154
	0,												// Reserved 155
	0,												// Reserved 156
	0,												// Reserved 157
	0,												// Reserved 158
	0,												// Reserved 159
	0,												// Reserved 160
	0,												// Reserved 161
	0,												// Reserved 162
	0,												// Reserved 163
	0,												// Reserved 164
	0,												// Reserved 165
	0,												// Reserved 166
	0,												// Reserved 167
	INTROK_IRQHandler
};

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
#pragma call_graph_root = "interrupt"
__weak void NMI_Handler( void )          { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void HardFault_Handler( void )    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void MemManage_Handler( void )    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BusFault_Handler( void )     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UsageFault_Handler( void )   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void SVC_Handler( void )          { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DebugMon_Handler( void )     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void PendSV_Handler( void )       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void SysTick_Handler( void )      { while (1) {} }

#pragma call_graph_root = "interrupt"
__weak void TAUJ2I0_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUJ2I1_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUJ2I2_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUJ2I3_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ0TIT_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ0TIR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ1TIT_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ1TIR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH0IC_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH0IR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH0IJC_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH1IC_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH1IR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH1IJC_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IICB0TIA_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IICB1TIA_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN0REC_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN0TRX_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN0WUP_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN1REC_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN1TRX_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN1WUP_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DMA00_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DMA01_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DMA02_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DMA03_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void RTDMA_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUDI0_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUDI1_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUDI2_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUDI3_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void TAUDI4_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BUFDMA_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHPHY0_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHPHY1_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHMIICMP_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHPAUSECMP_IRQHandler(void) { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHTXCMP_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHSW_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHSWDLR_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHSWSYNC_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHRXFIFO_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHTXFIFO_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHRXDMA_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHTXDMA_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void MACDMARXFRM_IRQHandler(void) { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ0_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ1_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ2_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ3_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ4_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ5_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ6_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ7_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ8_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ9_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ10_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ11_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ12_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ13_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ14_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ15_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ16_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ17_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ18_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ19_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ20_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ21_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ22_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ23_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ24_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ25_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ26_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ27_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ28_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void HWRTOS_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BRAMERR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IICB0TIS_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IICB1TIS_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void WDTA_IRQHandler(void)        { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void SFLASH_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ0TIS_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void UAJ1TIS_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH0IRE_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CSIH1IRE_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN0ERR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FCN1ERR_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DERR0_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DERR1_IRQHandler(void)       { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHTXFIFOERR_IRQHandler(void){ while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHRXERR_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHRXDERR_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void ETHTXDERR_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BUFDMAERR_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED0PHY0_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED0PHY1_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IRAMECCSEC_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DRAMECCSEC_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BRAMECCSEC_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void IRAMECCDED_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void DRAMECCDED_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void BRAMECCDED_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CCINMIZ_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CCIWDTZ_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CCIINTZ_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void CCICLKLOSSZ_IRQHandler(void) { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void NCHINT_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void NCLINT_IRQHandler(void)      { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void GBEPHYFLF_IRQHandler(void)   { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED1PHY0_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED1PHY1_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED2PHY0_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void LED2PHY1_IRQHandler(void)    { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void FPU_IRQHandler(void)         { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTPZ29_IRQHandler(void)     { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void NRAMECCSEC_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void NRAMECCDED_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTHSNGNREGBE_IRQHandler(void) { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTHSNGNBE_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTXSNGNBE_IRQHandler(void)  { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void MCINTWDTERR_IRQHandler(void) { while (1) {} }
#pragma call_graph_root = "interrupt"
__weak void INTROK_IRQHandler(void)      { while (1) {} }
