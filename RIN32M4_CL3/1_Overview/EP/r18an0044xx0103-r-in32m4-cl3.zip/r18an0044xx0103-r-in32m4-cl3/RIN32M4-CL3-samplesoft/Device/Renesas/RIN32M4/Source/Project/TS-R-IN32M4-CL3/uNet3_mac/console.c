
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <stdlib.h>

#include "kernel.h"
#include "net_hdr.h"
#include "ether_unet3/DDR_ETH.h"


#if defined (NET_C_OS) || defined (NET_S_OS)
#define _STAND_ON_UC3
#include "DDR_COM.h"
#define  DBG_PORTID     1   /* ? */
#define  GET_CHAR(c)    getc_com(DBG_PORTID, (c), NULL, TMO_FEVR)
#define  PUT_CHAR(c)    putc_com(DBG_PORTID, (c), TMO_FEVR)
#else

#define _STAND_ON_HWOS
#include "uart/uart.h"
#define  DBG_PORTID     SYS_UART_CH
#define  GET_CHAR(c)    *c='\n'; uart_read(DBG_PORTID, (unsigned char*)(c))
#define  PUT_CHAR(c)    uart_write(DBG_PORTID, (c))
#endif


#define MAX_CMD_LEN     512  /* Max Command Length */
char CmdBuf[MAX_CMD_LEN];    /* Command Buffer */
void dbg_console_puts(const char *format, ...);
void dbg_console_gets(char *buf, int size);

typedef int (*COMMAND_API)(void*);

typedef struct command_api_info {
    COMMAND_API  func;
    const char *command_name;
    const char *command_note;
}COMMAND_API_INFO;

int do_ip(void*);
int do_phy(void*);
int do_view(void*);
int do_mac(void*);
int do_rx(void*);
int do_tx(void*);
int do_test(void*);
int do_help(void*);

COMMAND_API_INFO command_api_list[] = {
    { do_ip,    "ip", "view host address"},
    { do_phy,   "phy", "change phy ability"},
    { do_mac,   "mac", "change multicast address filter"},
    { do_view,  "view", "view phy ability"},
    { do_rx,    "rx", "enable raw receive"},
    { do_tx,    "tx", "raw transmit"},
    { do_help,  "?", "this command"},
    { NULL,     "end"},
};

RIN_ETH_TypeDef *gETH_REG;

unsigned char mac[][6] = {
    {0x01, 0x00, 0x5e, 0x00, 0x01, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x02, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x03, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x04, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x05, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x06, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x07, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x08, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x09, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0A, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0B, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0C, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0D, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0E, 0xFF},
    {0x01, 0x00, 0x5e, 0x00, 0x0F, 0xFF},
};

int do_test(void* p)
{
    MAC_FILTER adr;
    int i;
    for (i = 0; i < 15; i++) {
        memcpy(adr.mac, mac[i], 6);
        adr.bitnum = 40 + i%9;   /* 40-48*/
        add_mcast_filter(&adr);
    }
    return 0;
}

int do_ip(void* p)
{
    T_NET_ADR adr;
	char inbuf[32];
    ER ercd;

    ercd = net_ref(0, NET_IP4_CFG, (VP)&adr);
    if (ercd != E_OK) {
        return ercd;
    }

    dbg_console_puts("\r\n IP Address  : ");
    ip_ntoa(inbuf, adr.ipaddr);
    dbg_console_puts(inbuf);

    dbg_console_puts("\r\n Subnet Mask : ");
    ip_ntoa(inbuf, adr.mask);
    dbg_console_puts(inbuf);

    dbg_console_puts("\r\n Gateway     : ");
    ip_ntoa(inbuf, adr.gateway);
    dbg_console_puts(inbuf);

    return 1;
}

int do_phy(void* p)
{
    PHY_MODE phy;
    char inbuf[16];
    int duplex, speed, nego;

    dbg_console_puts("\r\nDuplex? HALF(0)/FULL(1)  : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    duplex = atoi(inbuf);
    dbg_console_puts("\r\nSpeed?  10M(0)/100M(1)/1000M(2)   : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    speed = atoi(inbuf);
    dbg_console_puts("\r\nAuto nego?  NO(0)/YES(1) : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    nego = atoi(inbuf);
    dbg_console_puts("\r\nPHY channel? 1/2         : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    phy.ch = atoi(inbuf);

    if (duplex) {
        if (speed == 0)  {
            phy.mode = LAN_10T_FD;
        } else if (speed == 1) {
            phy.mode = LAN_100TX_FD;
        } else {
            phy.mode = LAN_1000T_FD;
        }
    } else {
        if (speed == 0)  {
            phy.mode = LAN_10T_HD;
        } else if (speed == 1) {
            phy.mode = LAN_100TX_HD;
        } else {
            phy.mode = LAN_1000T_HD;
        }
    }

    if (nego) {
        phy.nego = 1; 
    } else {
        phy.nego = 0; 
    }

    net_dev_ctl(1, ETH_OPT_PHY_MODE, (VP)&phy);
    return 0;
}

int do_view(void* p)
{
    PHY_MODE phy;
    char inbuf[32];

    dbg_console_puts("\r\nPHY channel? 1/2 : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    phy.ch = atoi(inbuf);

    net_dev_sts(1, ETH_OPT_PHY_MODE, (VP)&phy);

    dbg_console_puts("\r\n Speed  : %s", (phy.mode==LAN_1000T_FD || phy.mode==LAN_1000T_HD) ? "1000" : (phy.mode==LAN_100TX_FD || phy.mode==LAN_100TX_HD) ? "100" : "10");
    dbg_console_puts("\r\n Duplex : %s", (phy.mode==LAN_1000T_FD || phy.mode==LAN_100TX_FD || phy.mode==LAN_10T_FD) ? "Full" : "Half");
    dbg_console_puts("\r\n Link   : %s", (phy.link) ? "up" : "down");
    dbg_console_puts("\r\n Nego   : %s", (phy.nego) ? "on" : "off");

    return 0;
}

#define hex2ascii(x) ((x) < 0xA) ? ((x)+'0') : ((x)+0x37)

void hex_dump(VB b)
{
    VB c;

    PUT_CHAR(' ');
    c = hex2ascii(((b >> 4) & 0x0F));
    PUT_CHAR(c);
    c = hex2ascii((b & 0x0F));
    PUT_CHAR(c);
}

void dbg_console_dmp(VP chr, UH len)
{
    UB *c = (UB*)chr;

    dbg_console_puts("\r\n");
    while (len-- != 0) {
        hex_dump(*(c++));
    }
}

int do_rx(void* p)
{
    char inbuf[16];

    dbg_console_puts("\r\nEnable raw frame reception?  NO(0)/YES(1) : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    if (atoi(inbuf)) {
        net_dev_ctl(1, ETH_OPT_RAW_RXFNC, (VP)dbg_console_dmp);
    } else {
        net_dev_ctl(1, ETH_OPT_RAW_RXFNC, NULL);
    }
    return 0;
}

extern ER eth_snd(UH dev_num, T_NET_BUF *pkt);
extern T_NET_ADR gNET_ADR[];

int do_tx(void* p)
{
    int i;
    char inbuf[16];
    UB dstmac[6];
    UW dstip;
    UH port;
    T_NET_BUF *buf;

    buf = NULL;
    net_buf_get(&buf, 1500, -1);
    if (buf == NULL) {
        return -1;
    }

    for (i = 0; i < 6; i++) {
        dbg_console_puts("\r\nInput destination MAC address[%d] in hex : ", i);
        dbg_console_gets(inbuf, sizeof(inbuf));
        dstmac[i] = strtol(inbuf, NULL, 16);
    }
    dbg_console_puts("\r\nDestination MAC address : %02x.%02x.%02x.%02x.%02x.%02x",
                      dstmac[0], dstmac[1], dstmac[2], dstmac[3], dstmac[4], dstmac[5]);

    dbg_console_puts("\r\nInput destination IP address : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    dstip = ip_aton(inbuf);

    dbg_console_puts("\r\nInput UDP port(Local/Remote)  : ");
    dbg_console_gets(inbuf, sizeof(inbuf));
    port = atoi(inbuf);

    buf->hdr = &buf->buf[0] + 42; /* offset*/
    buf->hdr_len = 1514;

    /* MAC header */
    net_memcpy(buf->hdr, dstmac, 6);
    net_memcpy(buf->hdr+6, "\x12\x34\x56\x78\x9A\xBC", 6);
    buf->hdr[12] = 0x08;  /* ether type : IP */
    buf->hdr[13] = 0x00;

    /* IP header */
    buf->hdr[14] = 0x45;
    buf->hdr[15] = 0x00;
    buf->hdr[16] = 0x05;
    buf->hdr[17] = 0xDC; /* 1500 */
    buf->hdr[18] = 0x00;
    buf->hdr[19] = 0x01; /* id */
    buf->hdr[20] = 0x00;
    buf->hdr[21] = 0x00;
    buf->hdr[22] = 0x05;
    buf->hdr[23] = 0x11; /* protocol : udp */
    buf->hdr[24] = 0x00;
    buf->hdr[25] = 0x00;

    ip_n2byte((char*)(buf->hdr+26), gNET_ADR[0].ipaddr);
    ip_n2byte((char*)(buf->hdr+30), dstip);

    /* UDP header */
    buf->hdr[34] = port >> 8;
    buf->hdr[35] = port & 0xFF;
    buf->hdr[36] = port >> 8;
    buf->hdr[37] = port & 0xFF;
    buf->hdr[38] = 0x05;
    buf->hdr[39] = 0xC0; /* 1472 */
    buf->hdr[40] = 0x00;
    buf->hdr[41] = 0x00;

    /* payload */

    /* use checksum offload engine */
    buf->flg |= (HW_CS_TX_IPH4 | HW_CS_TX_DATA);

    eth_snd(0, buf);
    return 0;
}

char* get_hex(char *p, UB *h)
{
    int i;
    UB hex;

    *h = 0;
    for (i = 0; i < 2; i++, p++) {
        hex = 0;
        if ('0'<=(*p)&&(*p)<='9') {
            hex = (*p)-'0';
        } else if (('a'<=(*p)&&(*p)<='f')) {
            hex = (*p)-'a' + 10;
        } else if (('A'<=(*p)&&(*p)<='F')) {
            hex = (*p)-'A' + 10;
        } else {
            if (i == 0) {
                p = NULL;
            }
            break;
        }
        *h <<= i*4;
        *h += hex;
    }
    return p;
}

int do_mac(void* p)
{
    MAC_FILTER adr;
    char inbuf[32], *x;
    int mode, i;

    dbg_console_puts("\r\nFiltering mode?  All receive(1)/Block(2)/Address filter(3) :");
    dbg_console_gets(inbuf, sizeof(inbuf));
    mode = atoi(inbuf);

    net_dev_ctl(1, ETH_OPT_MCRX_MODE, (VP)&mode);

    if (mode == 3) { /* MCRX_MODE_FILTER */
        dbg_console_puts("\r\nInput MAC address e.g 01.00.5e.12.3... :");
        dbg_console_gets(inbuf, sizeof(inbuf));

        x = &inbuf[0];
        for (i = 0; i < 6; i++, x++) {
            x = get_hex(x, &adr.mac[i]);
            if (x == NULL) {
                dbg_console_puts("\r\nWrong mac address %s", inbuf);
                return 0;
            }
        }
        dbg_console_puts("\r\nBit length of address filter? 40 or 48 :");
        dbg_console_gets(inbuf, sizeof(inbuf));
        adr.bitnum = atoi(inbuf);

        net_dev_ctl(1, ETH_OPT_MCRX_ADR, (VP)&adr);
    }
    return 0;
}

int do_help(void *p)
{
    COMMAND_API_INFO  *menu = &command_api_list[0];

    while (menu->func) {
        dbg_console_puts("\r\n%-4s : %s", menu->command_name, menu->command_note);
        menu++;
    }
    return 0;
}

char tempbuf[64];
void dbg_console_puts(const char *format, ...)
{
    va_list argp;
    char *msg;

    memset(tempbuf, 0, sizeof(tempbuf));
    msg = &tempbuf[0];

    va_start(argp, format);
    vsnprintf(msg, MAX_CMD_LEN-1, format, argp );
    va_end(argp);

#ifdef _STAND_ALONE
    printf(msg);
#else
    unsigned int cnt;
    cnt = strlen(msg);

#ifdef _STAND_ON_UC3
    puts_com(DBG_PORTID, msg, &cnt, TMO_FEVR);
#else
    while (cnt) {
        uart_write(DBG_PORTID, *msg);
        msg++;cnt--;
    }
#endif
#endif
}

void dbg_console_gets(char *buf, int size)
{
#ifdef _STAND_ALONE
    scanf("%s", buf);
#else

    int i, s;
    char c;

    for (i = s = 0;;) {
        GET_CHAR(&c);

        if (i == 0 && c == '\n')
            continue;

        if (s) {
            s--;
            continue;
        }
    
        if (c == '\r') {
            buf[i] = '\0';
            return;
        }

        if (c == '\b') {
            if (i > 0) {
                i--;
                PUT_CHAR('\b');
                PUT_CHAR(' ');
                PUT_CHAR('\b');
            }
            continue;
        }

        if (c == 0x1b) {
            s = 2;
            continue;
        }

        if (c < 0x20 || c > 0x7e)
            continue;

        if (i >= size - 1)
            continue;

        buf[i++] = c;

        PUT_CHAR(c);
    }
#endif
}

/* command */
void command(char *cmd)
{
    COMMAND_API_INFO  *menu = &command_api_list[0];

    while (menu->func) {
        if (strcmp(menu->command_name, cmd) == 0) {
            menu->func(NULL);
            break;
        }
        menu++;
    }
}

/* standard I/O */
void console(void)
{
    while (1) {
        dbg_console_puts("\r\nR-IN32>");
        dbg_console_gets(CmdBuf, MAX_CMD_LEN);

        if (strcmp(CmdBuf, "") != 0) {
            command((char *)CmdBuf);
        }
    }
}

/* entry */
#ifdef _STAND_ALONE
int main(void)
{
    console();

    return 0;
}

#else

void command_task(VP_INT exinf)
{
#ifdef _STAND_ON_UC3

    /* main.c */
    /* 
    ini_com(DBG_PORTID, &com_ini);
    dly_tsk(1);
    ctr_com(DBG_PORTID, STA_COM, 0);
    */

#endif

#ifdef _STAND_ON_HWOS
    /* main.c */
    /*
    uart_init(SYS_UART_CH);
    */

    //debug
    gETH_REG = (RIN_ETH_TypeDef*)(RIN_ETH_BASE);
#endif
    console();
}
#endif
