/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_ini.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_intr_l.h"
#include "R_IN32D_reg_l.h"
#include "R_IN32D_sub_l.h"
#include "R_IN32D_tran_l.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_TMOUTUS_MYSTATUSCOPY		9000UL	


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ULONG   ulR_IN32D_Reset( VOID );
static ERRCODE erR_IN32D_InitCommuDriverAfterReset( VOID );
static ERRCODE erR_IN32D_InitAsic( VOID );
static ERRCODE erR_IN32D_InitFrameInf( VOID );
static ERRCODE erR_IN32D_InitTestDataAck( VOID );
static ERRCODE erR_IN32D_InitSetupAck( VOID );
static ERRCODE erR_IN32D_InitMyStatusFrame( VOID );
static ERRCODE erR_IN32D_InitTokenFrame( VOID );
static ERRCODE erR_IN32D_InitCyclicRXFrame( VOID );
static ERRCODE erR_IN32D_InitCyclicRWrFrame( VOID );
static ERRCODE erR_IN32D_InitTransientFrame(VOID);
static ERRCODE erR_IN32D_InitFrameType( VOID );
static ERRCODE erR_IN32D_InitSETUPACK_FRAME_6_2( VOID );


ERRCODE gerR_IN32D_Init(
	const UCHAR*	puchMACAddr,		
	ULONG*			pulResetLevel		
)
{

	(VOID)erR_IN32D_InitFatalErrorFIFO();

	*pulResetLevel = ulR_IN32D_Reset();

	(VOID)gerR_IN32D_StopWdt();

	(VOID)gerR_IN32D_InitPHYLinkSetting( );

	(VOID)erR_IN32D_InitSETUPACK_FRAME_6_2();

	(VOID)erR_IN32D_InitCommuDriverAfterReset();

	RX->ulRCNTENDIS = RCNTENDIS_CNTLFRMRECVVALID;

	RX->ulRDISENDIS &= ~RDISENDIS_NONCYCLICRECVVALID;
	RX->ulRDISENDIS |= (gulR_IN32U_NCYCRCV_VALID & gulR_IN32U_NCYCRCV_VALID);	

	(VOID)gerR_IN32D_SetMyMACAddr( puchMACAddr );

	(VOID)gerR_IN32D_SetSndMyMACAddr( puchMACAddr );

	(VOID)erR_IN32D_InitIntrAfterReset();

	return( R_IN32D_OK );
}

ULONG ulR_IN32D_Reset( VOID )
{
	ULONG	ulResetLevel;		
	ULONG	ulMACAddress0Temp;	
	ULONG	ulMACAddress1Temp;	


	ulMACAddress0Temp = RING->ulMACAddress0;
	ulMACAddress1Temp = RING->ulMACAddress1;
	if (( 0UL == ulMACAddress0Temp ) && ( 0UL == ulMACAddress1Temp)) {
		ulResetLevel = R_IN32D_RESET_PWRON;		
	}
	else {
		ulResetLevel = R_IN32D_RESET_SYSTEM;	
	}

	(VOID)erR_IN32D_ResetMAC();

	(VOID)erR_IN32D_ResetPHY( );

	if ( R_IN32D_RESET_SYSTEM == ulResetLevel ) {
	}
	else {

	}

	return( ulResetLevel );
}

ERRCODE erR_IN32D_InitCommuDriverAfterReset( VOID )
{

	(VOID)erR_IN32D_InitTranSndInf();		
	(VOID)erR_IN32D_InitTranRcvInf();		


	(VOID)gerR_IN32D_ClearTxRxRAM();

	(VOID)erR_IN32D_InitAsic();

	(VOID)erR_IN32D_InitFrameInf();

	(VOID)gerR_IN32D_ClearRingMIB();


	(VOID)gerR_IN32D_MacIp_AccessEnable();

	(VOID)gerR_IN32D_ClearMacIpMIB();

	(VOID)gerR_IN32D_MacIp_AccessDisable();

	(VOID)gerR_IN32D_InitSyncCommunication();

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_StartRing( VOID )
{
	R_IN32D_FATALERROR_T	stFatalErr;			
	R_IN32R_STOPWATCH_T	stShortInform;		
	ULONG				ulSpendTime;		
	ERRCODE				erResult;			


	gR_IN32R_StartStopwatchTimer( &stShortInform, 1UL );

	while (1) {

		gR_IN32R_GetElapsedTime( &stShortInform, &ulSpendTime );

		erResult = gerR_IN32D_SetMyStatus(
					(R_IN32D_CYCLIC_STA_SET_T*)R_IN32_NULL,
					(R_IN32D_SELF_STA_SET_T*)R_IN32_NULL,
					(R_IN32D_SLVEVENT_SET_T*)R_IN32_NULL,
					(R_IN32D_MACDELIV_RESULT_SET_T*)R_IN32_NULL,
					gulR_IN32U_ERRCODE,					
					gulR_IN32U_USER_INFORMATION			
				);

		if ( R_IN32D_OK == erResult ) {	
			break;
		}
		else {
		}

		if ( R_IN32D_TMOUTUS_MYSTATUSCOPY < ulSpendTime ) {		

			stFatalErr.ulErrorCode = R_IN32D_ERR_TMO_MYSTATUSCOPY;
			stFatalErr.ulErrorInfo = (ULONG)&gerR_IN32D_StartRing;
			(VOID)gerR_IN32D_SetFatalError( &stFatalErr );

			erResult = R_IN32D_NG;
			break;
		}
		else {
		}

	}

	(VOID)erR_IN32D_ClearINT1_2All();		
	(VOID)erR_IN32D_UnMaskINT1_2();		
	(VOID)erR_IN32D_ClearSYNCINTLAll();

	RING->ulStart = START_REG_START;

	return( erResult );
}

ERRCODE erR_IN32D_InitAsic( VOID )
{
	RING->ulMode = MODE_CLR;


	EMGDBG->stSELF_WDT.uniSelfWdt.usAll &= ~(SELF_WDT_SELFWDTSET);

	EMGDBG->stFAIL_MD_SET.uniMdSet.usAll &= ~(FAIL_MD_SET_WDTLLBYPASSMODE | FAIL_MD_SET_SELFWDTBYPASSMODE);
	EMGDBG->stFAIL_MD_SET.uniMdSet.usAll |= (FAIL_MD_SET_PASSMODE_MASK & (USHORT)(gulR_IN32U_FAILEDPROCESS1 | (gulR_IN32U_FAILEDPROCESS2 << FAIL_MD_SET_SELFWDTBYPASSMODE_SHIFT)));

	gerR_IN32D_SetStationNumber( (ULONG)R_IN32U_STATION_NUMBER );

	gerR_IN32D_SetNetworkNumber( (ULONG)R_IN32U_NETWORK_NUMBER );

        
    TX->TXCNT.b02ZSndStartType = TXCNT_SND_START_TYPE_FWREGWRITE;
	TX->ulTX_HEAD_NO = TDISC_NO_MYSTATUS;

	OUT32(&(TX->MAC_TYPE), (ULONG)0x890F);

	TX->ulMSTS_SWITCH_FLG = R_IN32_ON;
	gerR_IN32D_SetMasterID(0x01);

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitFrameInf( VOID )
{
	(VOID)erR_IN32D_InitTestDataAck();

	(VOID)erR_IN32D_InitSetupAck();

	(VOID)erR_IN32D_InitMyStatusFrame();

	(VOID)erR_IN32D_InitTokenFrame();

	(VOID)erR_IN32D_InitCyclicRXFrame();

	(VOID)erR_IN32D_InitCyclicRWrFrame();

	(VOID)erR_IN32D_InitTransientFrame();

	(VOID)erR_IN32D_InitFrameType();

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitTestDataAck( VOID )
{
	ULONG	ul32bitReg;								

	ul32bitReg  = 0UL;
	ul32bitReg |= ((TESTDATAACK_FRAME_REG0_UNIT_TYPE_MASK & (UCHAR)gulR_IN32U_STATION_CLASS_UNIT )
				| ( TESTDATAACK_FRAME_REG0_UNIT_EQUIPMENT_MASK & (ULONG)((UCHAR)gulR_IN32U_STATION_CLASS_EQUIPMENT << TESTDATAACK_FRAME_REG0_UNIT_EQUIPMENT_SHIFT) )
				| ( TESTDATAACK_FRAME_REG0_MSTMEDIATION_MASK & ((ULONG)R_IN32U_MST_ARBIT_PRI << TESTDATAACK_FRAME_REG0_MSTMEDIATION_SHIFT ) ));
	RING->ulTestDataAck_Frame0 = ul32bitReg;

	ul32bitReg = 0UL;
	ul32bitReg |= ((TESTDATAACK_FRAME_REG1_PROTOCOLCLASSIFICATION_MASK & ((ULONG)R_IN32U_PROTOCOL_CLASS << TESTDATAACK_FRAME_REG1_PROTOCOLCLASSIFICATION_SHIFT))
				 | (TESTDATAACK_FRAME_REG1_PROTOCOLVERSION_MASK & ((ULONG)R_IN32U_PROTOCOL_VER << TESTDATAACK_FRAME_REG1_PROTOCOLVERSION_SHIFT)));
	RING->ulTestDataAck_Frame1 = ul32bitReg;

	ul32bitReg = 0UL;
	ul32bitReg |= ( (TESTDATAACK_FRAME_REG2_TOKENHOLDTIME_MASK & gulR_IN32U_TOKEN_HOLD_TIME)
				 | ( TESTDATAACK_FRAME_REG2_MYSTATIONPORTNUM_MASK & (gulR_IN32U_MAX_PORT_NUMBER << TESTDATAACK_FRAME_REG2_MYSTATIONPORTNUM_SHIFT)) );
	RING->ulTestDataAck_Frame2 = ul32bitReg;
	
	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitSetupAck( VOID )
{
	ULONG	ul32bitReg;								

	ul32bitReg = 0UL;
	ul32bitReg |= ( (SETUPACK_FRAME_REG0_PROTOCOLCLASSIFICATION_MASK & ((ULONG)R_IN32U_PROTOCOL_CLASS << SETUPACK_FRAME_REG0_PROTOCOLCLASSIFICATION_SHIFT))
					| (SETUPACK_FRAME_REG0_PROTOCOLVERSION_MASK & ((ULONG)R_IN32U_PROTOCOL_VER << SETUPACK_FRAME_REG0_PROTOCOLVERSION_SHIFT)) );
	RING->ulSetupAck_Frame0 = ul32bitReg;

	ul32bitReg  = 0UL;
	ul32bitReg |= ((SETUPACK_FRAME_REG1_MODELTYPE_MASK & gulR_IN32U_UNIT_MODEL_TYPE)
				| (SETUPACK_FRAME_REG1_VERSION_MASK & (gulR_IN32U_UNIT_VERSION << SETUPACK_FRAME_REG1_VERSION_SHIFT))
				| (SETUPACK_FRAME_REG1_STATIONINFO_MASK & (gulR_IN32U_STINF_IOTYPE << SETUPACK_FRAME_REG1_STATIONINFO_SHIFT)));
	RING->ulSetupAck_Frame1 = ul32bitReg;

	ul32bitReg = 0UL;
	ul32bitReg |= (SETUPACK_FRAME_REG2_VENDOR_CODE_MASK & gulR_IN32U_UNIT_VENDOR_CODE);
	RING->ulSetupAck_Frame2 = ul32bitReg;

	RING->ulSetupAck_Frame3 = gulR_IN32U_UNIT_MODEL_CODE;

	ul32bitReg = 0UL;
	ul32bitReg = ( (SETUPACK_FRAME_REG4_RWW_SIZE_MASK & gulR_IN32U_MAX_RWW_WSIZE)
				 | (SETUPACK_FRAME_REG4_RY_SIZE_MASK & (gulR_IN32U_MAX_RY_SIZE << SETUPACK_FRAME_REG4_RY_SIZE_SHIFT )));
	RING->ulSetupAck_Frame4 = ul32bitReg;

	ul32bitReg = 0UL;
	ul32bitReg = ( (SETUPACK_FRAME_REG5_RWR_SIZE_MASK & gulR_IN32U_MAX_RWR_WSIZE)
				 | (SETUPACK_FRAME_REG5_RX_SIZE_MASK & (gulR_IN32U_MAX_RX_SIZE << SETUPACK_FRAME_REG5_RX_SIZE_SHIFT )));
	RING->ulSetupAck_Frame5 = ul32bitReg;

	ul32bitReg  = 0UL;
	ul32bitReg |= ((SETUPACK_FRAME_REG6_TRANSIENTRECV_MODE & (gulR_IN32U_TRANRCV_MODE << SETUPACK_FRAME_REG6_TRANSIENTRECV_MODE_SHIFT))
				| ( SETUPACK_FRAME_REG6_STATION_MODE   & (gulR_IN32U_STATION_MODE   << SETUPACK_FRAME_REG6_STATION_MODE_SHIFT) )
				| ( SETUPACK_FRAME_REG6_OPTION_SUPPORT & (gulR_IN32U_OPTION_SUPPORT << SETUPACK_FRAME_REG6_OPTION_SUPPORT_SHIFT) )
				| ( SETUPACK_FRAME_REG6_SYNC_SUPPORT & (gulR_IN32U_SYNC_FUNCTION1 << SETUPACK_FRAME_REG6_SYNC_SUPPORT_SHIFT) )
				| ( SETUPACK_FRAME_REG6_DEVICE_SET & (gulR_IN32U_DEVICE_SET_STATUS << SETUPACK_FRAME_REG6_DEVICE_SET_SHIFT) )
				| ( SETUPACK_FRAME_REG6_DEVICE_INIT & (gulR_IN32U_DEVICE_INIT << SETUPACK_FRAME_REG6_DEVICE_INIT_SHIFT) )
				| ( SETUPACK_FRAME_REG6_SYNC2_SUPPORT & (gulR_IN32U_SYNC_FUNCTION2 << SETUPACK_FRAME_REG6_SYNC2_SUPPORT_SHIFT) )
				| ( SETUPACK_FRAME_REG6_SLMP_SUPPORT   & (gulR_IN32U_SLMP_SUPPORT   << SETUPACK_FRAME_REG6_SLMP_SUPPORT_SHIFT) ));
	RING->ulSetupAck_Frame6 = ul32bitReg;

	ul32bitReg  = 0UL;
	ul32bitReg |= ( (SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT & (gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT << SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT_SHIFT))
				  | (SETUPACK_FRAME_REG7_SYNC_SET_FOLLOWUP & (gulR_IN32U_SYNC_SET_FOLLOWUP << SETUPACK_FRAME_REG7_SYNC_SET_FOLLOWUP_SHIFT))
				  | (SETUPACK_FRAME_REG7_SYNC3_SUPPORT & (gulR_IN32U_SYNC_FUNCTION3 << SETUPACK_FRAME_REG7_SYNC3_SUPPORT_SHIFT))
				  );
	ul32bitReg |=  (SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT & (gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT << SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT_SHIFT));

	RING->ulSetupAck_Frame7 = ul32bitReg;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitMyStatusFrame( VOID )
{

	ULONG *dummy;
	R_TDISC1_TAG		stTmpTDISC1;
	R_TDISC2_TAG		stTmpTDISC2;
	R_TDISC3_TAG		stTmpTDISC3;
	MSTS_INFO_TAG		stMstsInfo;
	CYCLIC_STA_T		stCycSta;
	SELF_CONTROL_TAG	stSelfCtl;

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));
	gR_IN32S_Memset(&stMstsInfo, 0x00, sizeof(stMstsInfo));
	gR_IN32S_Memset(&stCycSta, 0x00, sizeof(stCycSta));
	gR_IN32S_Memset(&stSelfCtl, 0x00, sizeof(stSelfCtl));

	stMstsInfo.b04ZProtocolVersion       = (USHORT)R_IN32U_PROTOCOL_VER;
	stMstsInfo.b04ZProtocolClassifcation = (USHORT)R_IN32U_PROTOCOL_CLASS;
	stMstsInfo.b08ZFrameSubClassifcation = R_IN32U_FRAME_SUBTYPE;
	OUT32(&(TX->MSTS_INFO), *((ULONG*)&stMstsInfo));

	stCycSta.uniCyclicSta.ulAll |= ((ULONG)R_IN32D_CYCLICSTA_STATIONWRONG	|
									(ULONG)R_IN32D_CYCLICSTA_DISCONNECT		|
									(ULONG)R_IN32D_CYCLICSTA_CYCSTOP);
	stCycSta.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond = CYCLIC_STA_PARAMNONRECV;
	OUT32(&(TX->CYCLIC_STA), *((ULONG*)&stCycSta));
	dummy = (ULONG *)&TX->SELF_STA;
	*dummy = (*dummy & 0xFFFFBFF0);
	*dummy = (*dummy | gulR_IN32U_SELFSTA_CPURUN
					 | (gulR_IN32U_SELFSTA_CPUERRFOUND <<  2)
					 | (gulR_IN32U_SELFSTA_TRANRCV     << 14));

	stSelfCtl.b10ZSelfSafety = (USHORT)0;
	OUT32(&(TX->SELF_CONTROL_1), *((ULONG*)&stSelfCtl));
	OUT32(&(TX->SELF_CONTROL_2), *((ULONG*)&stSelfCtl));

	stSelfCtl.b10ZSelfSafety = (gulR_IN32U_USER_INFORMATION & 0x0000FFFF);
	__BUS_RELEASE();
	OUT32(&(TX->SELF_CONTROL_3), *((ULONG*)&stSelfCtl));

	stSelfCtl.b10ZSelfSafety = ((gulR_IN32U_USER_INFORMATION & 0xFFFF0000) >> 16);
	OUT32(&(TX->SELF_CONTROL_4), *((ULONG*)&stSelfCtl));

	TX->SELF_STA2_L.DATA = (gulR_IN32U_ERRCODE & 0x0000FFFF);
	TX->SELF_STA2_H.DATA = (gulR_IN32U_ERRCODE & 0xFFFF0000) >> 16;

	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_ON;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_CTRL;
	stTmpTDISC1.b09ZNextReadDiscriptorChain = TDISC_NO_CYCLIC_RWr;
	stTmpTDISC2.b0BZSendSize = 60;

	OUT32(&TD->aTD_TDS[TDISC_NO_MYSTATUS].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_MYSTATUS].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_MYSTATUS].R_TDISC3, *((ULONG*)&stTmpTDISC3));

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitTokenFrame(VOID)
{
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));

	TX->TKN_INFO.b04ZProtocolVersion       = (USHORT)R_IN32U_PROTOCOL_VER;		
	TX->TKN_INFO.b04ZProtocolClassifcation = (USHORT)R_IN32U_PROTOCOL_CLASS;		
	
	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_ON;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_CTRL;
	stTmpTDISC1.b01ZLastDiscriptorFlag = R_IN32_ON;
	stTmpTDISC2.b0BZSendSize = 60;

	OUT32(&TD->aTD_TDS[TDISC_NO_TOKEN].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_TOKEN].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_TOKEN].R_TDISC3, *((ULONG*)&stTmpTDISC3));

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitCyclicRXFrame(VOID)
{
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));

	stTmpTDISC1.b01ZCycType = R_IN32_OFF;
	stTmpTDISC1.b01ZAlignment = R_IN32_OFF;
	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_CYC;
	stTmpTDISC1.b09ZNextReadDiscriptorChain = TDISC_NO_TRANSIENT;
	stTmpTDISC2.b07ZSendHeaderFrmSize = 0x28;
	stTmpTDISC2.b0BZSendSize = 56;

	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC3, *((ULONG*)&stTmpTDISC3));


	
	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitCyclicRWrFrame(VOID)
{
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));

	stTmpTDISC1.b01ZCycType = R_IN32_ON;
	stTmpTDISC1.b01ZAlignment = R_IN32_OFF;
	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_CYC;
	stTmpTDISC1.b09ZNextReadDiscriptorChain = (TDISC_NO_CYCLIC_RWr + 1);
	stTmpTDISC2.b07ZSendHeaderFrmSize = 0x28;
	stTmpTDISC2.b0BZSendSize = 0x5E4;

	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC3, *((ULONG*)&stTmpTDISC3));

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));

	stTmpTDISC1.b01ZCycType = R_IN32_ON;
	stTmpTDISC1.b01ZAlignment = R_IN32_OFF;
	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_CYC;
	stTmpTDISC1.b09ZNextReadDiscriptorChain = TDISC_NO_CYCLIC_RX;
	stTmpTDISC2.b07ZSendHeaderFrmSize = 0x28;
	stTmpTDISC2.b0BZSendSize = 0x26C;
	stTmpTDISC3.b1AZSendDataDMAFromAddress = 0x5BC;

	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC3, *((ULONG*)&stTmpTDISC3));
	
	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitTransientFrame(VOID)
{
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));

	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
	stTmpTDISC1.b02ZFrmType = R_TDISC1_FRM_TYPE_TRN_FIELD;
	stTmpTDISC1.b09ZNextReadDiscriptorChain = TDISC_NO_TOKEN;
	stTmpTDISC1.b01ZLastDiscriptorFlag = R_IN32_ON;

	OUT32(&TD->aTD_TDS[TDISC_NO_TRANSIENT].R_TDISC1, *((ULONG*)&stTmpTDISC1));
	OUT32(&TD->aTD_TDS[TDISC_NO_TRANSIENT].R_TDISC2, *((ULONG*)&stTmpTDISC2));
	OUT32(&TD->aTD_TDS[TDISC_NO_TRANSIENT].R_TDISC3, *((ULONG*)&stTmpTDISC3));

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitFrameType( VOID )
{
	RING->ulFType1  = ((ULONG)FTYPE_Persuasion         )	
					| ((ULONG)FTYPE_TestData      << 8 )	
					| ((ULONG)FTYPE_TestDataAck   << 16)	
					| ((ULONG)FTYPE_Setup         << 24);	

	RING->ulFType2  = ((ULONG)FTYPE_SetupAck           )	
					| ((ULONG)FTYPE_Token         << 8 )	
					| ((ULONG)FTYPE_MyStatus      << 16)	
					| ((ULONG)FTYPE_CyclicRWw     << 24);	

	RING->ulFType3  = ((ULONG)FTYPE_CyclicRY           )	
					| ((ULONG)FTYPE_CyclicRWr     << 8 )	
					| ((ULONG)FTYPE_CyclicRX      << 16)	
					| ((ULONG)FTYPE_Transient2    << 24);	

	RING->ulFType4  = ((ULONG)FTYPE_Transient1          )	
					| ((ULONG)FTYPE_ParamCheck     << 8 )	
					| ((ULONG)FTYPE_REG4_Reserved1 << 16)	
					| ((ULONG)FTYPE_REG4_Reserved2 << 24);	

	RING->ulFType5  = ((ULONG)FTYPE_Parameter           )	
					| ((ULONG)FTYPE_Timer          << 8 )	
					| ((ULONG)FTYPE_REG5_Reserved1 << 16)	
					| ((ULONG)FTYPE_REG5_Reserved2 << 20);	

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitSETUPACK_FRAME_6_2( VOID )
{


	return( R_IN32D_OK );
}

/*** EOF ***/
