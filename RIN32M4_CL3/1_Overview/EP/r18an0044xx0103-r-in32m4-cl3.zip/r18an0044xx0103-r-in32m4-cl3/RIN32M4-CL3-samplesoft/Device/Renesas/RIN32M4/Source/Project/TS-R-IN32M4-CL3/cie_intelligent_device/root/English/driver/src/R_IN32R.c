/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32R.c                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Callback.h"
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"
#include "timer/timer.h"
#include <time.h>

#define CLOCKS_PER_USEC		(CLOCKS_PER_SEC/1000000)
extern void clock_init(void);

extern INT tslp_tsk(INT tmout);
extern INT dis_dsp(void);
extern INT ena_dsp(void);
/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32R_IEEETEST_PHY_CNT			(USHORT)2				
#define R_IN32R_IEEETEST_1MS_DELAY			(USHORT)0xFFFF			
#define R_IN32R_IEEETEST_WAIT				1000UL					


VOID gR_IN32R_WaitUS(
	ULONG				ulWaitTime			
)
{
	R_IN32R_STOPWATCH_T	stStopWatch;		
	ULONG				ulSpendTime;		

	gR_IN32R_StartStopwatchTimer( &stStopWatch, 1UL );

	while (1) {
		gR_IN32R_GetElapsedTime( &stStopWatch, &ulSpendTime );

		if ( ulWaitTime < ulSpendTime ) {
			break;
		}
		else {
		}
	}

	return;
}

VOID gR_IN32R_DisableInt(VOID)
{
//	dis_dsp();

	return;
}

VOID gR_IN32R_EnableInt(VOID)
{
//	ena_dsp();

	return;
}
VOID gR_IN32R_ExDisableInt(VOID)
{
	dis_dsp();

	return;
}

VOID gR_IN32R_ExEnableInt(VOID)
{
	ena_dsp();

	return;
}

VOID gR_IN32R_StartStopwatchTimer(
	R_IN32R_STOPWATCH_T*	pstStopWatch,	
	ULONG				ulUnit			
)
{
	pstStopWatch->ulUnit = ulUnit;

	clock_init();
	pstStopWatch->ulFirstTmr1Cnt = (ULONG)clock();
	return;
}

VOID gR_IN32R_GetElapsedTime(
	R_IN32R_STOPWATCH_T* 	pstStopWatch,	
	ULONG*				pulElapsedTime	
)
{
	clock_t clk_tmp;

	clk_tmp = clock();
	pstStopWatch->ulLastTmr1Cnt = (ULONG)clk_tmp;
	
	if ( 0 != pstStopWatch->ulUnit ) {
		clk_tmp = (clk_tmp - (clock_t)pstStopWatch->ulFirstTmr1Cnt) / (clock_t)(CLOCKS_PER_USEC * pstStopWatch->ulUnit);
	}
	*pulElapsedTime = (ULONG)clk_tmp;
	return;
}

ERRCODE gerR_IN32R_IEEETest(
	USHORT	usIEEETestMode	
)
{
	static const USHORT ausPhyTbl[R_IN32R_IEEETEST_PHY_CNT][5] = {	

		{R_IN32D_PHYREG_CTRL,          0x9140, 0x9140, 0x9140, 0x9140},
		{R_IN32D_PHYREG_1000CTRL,      0x3F00, 0x5F00, 0x7700, 0x9F00}
	};

	static ULONG 	ulIEEETestRegSaveFlg = (ULONG)R_IN32_OFF;	

	static ULONG	ulPhy1_CtrlReg_Data;		
	static ULONG	ulPhy1_1000CtrlReg_Data;	
	static ULONG	ulPhy2_CtrlReg_Data;		
	static ULONG	ulPhy2_1000CtrlReg_Data;	
	int				i;
	ERRCODE			erResult;					
	ERRCODE			erCallRet;					


	erResult = R_IN32_OK;

	switch (usIEEETestMode) {
	case R_IN32R_IEEE_MODE1:
	case R_IN32R_IEEE_MODE2:
	case R_IN32R_IEEE_MODE3:
	case R_IN32R_IEEE_MODE4:

		erCallRet = gerR_IN32D_MacIp_AccessEnable();
		if (R_IN32D_NG == erCallRet) {
			erResult = R_IN32_ERR;
		}
		else {
		}

		if ((ULONG)R_IN32_ON == ulIEEETestRegSaveFlg) {
			ulIEEETestRegSaveFlg = (ULONG)R_IN32_OFF;


			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, R_IN32D_PHYREG_1000CTRL, ulPhy1_1000CtrlReg_Data);
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}

			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, R_IN32D_PHYREG_CTRL, (ulPhy1_CtrlReg_Data | R_IN32D_MDIO_CTRL_SWRESET));
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}


			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, R_IN32D_PHYREG_1000CTRL, ulPhy2_1000CtrlReg_Data);
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}

			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, R_IN32D_PHYREG_CTRL, (ulPhy2_CtrlReg_Data | R_IN32D_MDIO_CTRL_SWRESET));
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}
		}
		else {
		}


		ulIEEETestRegSaveFlg = (ULONG)R_IN32_ON;


		erCallRet = gerR_IN32D_MACIP_PHYRead(R_IN32D_PORT1, R_IN32D_PHYREG_1000CTRL, &ulPhy1_1000CtrlReg_Data);
		if (R_IN32D_NG == erCallRet) {
			erResult = R_IN32_ERR;
		}
		else {
		}

		erCallRet = gerR_IN32D_MACIP_PHYRead(R_IN32D_PORT1, R_IN32D_PHYREG_CTRL, &ulPhy1_CtrlReg_Data);
		if (R_IN32D_NG == erCallRet) {
			erResult = R_IN32_ERR;
		}
		else {
		}


		erCallRet = gerR_IN32D_MACIP_PHYRead(R_IN32D_PORT2, R_IN32D_PHYREG_1000CTRL, &ulPhy2_1000CtrlReg_Data);
		if (R_IN32D_NG == erCallRet) {
			erResult = R_IN32_ERR;
		}
		else {
		}

		erCallRet = gerR_IN32D_MACIP_PHYRead(R_IN32D_PORT2, R_IN32D_PHYREG_CTRL, &ulPhy2_CtrlReg_Data);
		if (R_IN32D_NG == erCallRet) {
			erResult = R_IN32_ERR;
		}
		else {
		}


		for (i = 0; i < R_IN32R_IEEETEST_PHY_CNT; i++) {

			if (R_IN32R_IEEETEST_1MS_DELAY != ausPhyTbl[i][0]) {

				erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, (ULONG)ausPhyTbl[i][0], (ULONG)ausPhyTbl[i][usIEEETestMode]);
				if (R_IN32D_NG == erCallRet) {
					erResult = R_IN32_ERR;
				}
				else {
				}
			}
			else {
				gR_IN32R_WaitUS(R_IN32R_IEEETEST_WAIT);
			}
		}

		for (i = 0; i < R_IN32R_IEEETEST_PHY_CNT; i++) {

			if (R_IN32R_IEEETEST_1MS_DELAY != ausPhyTbl[i][0]) {

				erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, (ULONG)ausPhyTbl[i][0], (ULONG)ausPhyTbl[i][usIEEETestMode]);
				if (R_IN32D_NG == erCallRet) {
					erResult = R_IN32_ERR;
				}
				else {
				}
			}
			else {
				gR_IN32R_WaitUS(R_IN32R_IEEETEST_WAIT);
			}
		}


		erCallRet = gerR_IN32D_MacIp_AccessDisable();
		if ( R_IN32D_NG == erCallRet ) {
			erResult = R_IN32_ERR;
		}
		else {
		}

		break ;

	case R_IN32R_IEEE_END:

		if ((ULONG)R_IN32_ON == ulIEEETestRegSaveFlg) {

			ulIEEETestRegSaveFlg = (ULONG)R_IN32_OFF;

			erCallRet = gerR_IN32D_MacIp_AccessEnable();
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}


			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, R_IN32D_PHYREG_1000CTRL, ulPhy1_1000CtrlReg_Data);
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}

			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, R_IN32D_PHYREG_CTRL, (ulPhy1_CtrlReg_Data | R_IN32D_MDIO_CTRL_SWRESET));
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}


			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, R_IN32D_PHYREG_1000CTRL, ulPhy2_1000CtrlReg_Data);
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}

			erCallRet = gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, R_IN32D_PHYREG_CTRL, (ulPhy2_CtrlReg_Data | R_IN32D_MDIO_CTRL_SWRESET));
			if (R_IN32D_NG == erCallRet) {
				erResult = R_IN32_ERR;
			}
			else {
			}


			erCallRet = gerR_IN32D_MacIp_AccessDisable();
			if ( R_IN32D_NG == erCallRet ) {
				erResult = R_IN32_ERR;
			}
			else {
			}
		}
		else {
		}

		break;

	default:								

		erResult = R_IN32_ERR;
		break;
	}

	return(erResult);
}
VOID gR_IN32R_StartIntervalTimer(
	ULONG				ulChnl,			
	ULONG				ulTime			
)
{
	NVIC_ClearPendingIRQ((IRQn_Type)(TAUJ2I0_IRQn + ulChnl));
	timer_interval_init((uint8_t)ulChnl, (uint32_t)ulTime);
	NVIC_DisableIRQ((IRQn_Type)(TAUJ2I0_IRQn + ulChnl));
	timer_start( (uint8_t)ulChnl );
}
VOID gR_IN32R_StopIntervalTimer(
		ULONG				ulChnl			
)
{
	timer_stop((uint8_t)ulChnl);
	NVIC_ClearPendingIRQ((IRQn_Type)(TAUJ2I0_IRQn + ulChnl));
}
BOOL gR_IN32R_IsIntervalTimerTimeout(
		ULONG				ulChnl			
)
{
	ULONG	ulInterrupt;
	BOOL	blTimeout;

	ulInterrupt = NVIC_GetPendingIRQ((IRQn_Type)(TAUJ2I0_IRQn + ulChnl));

	if (1 == ulInterrupt){
		blTimeout = R_IN32_TRUE;
	}
	else{
		blTimeout = R_IN32_FALSE;
	}
	return blTimeout;
}
VOID gR_IN32R_UnlockSystemProtect(VOID)
{
	RIN_SYS->SYSPCMD	= 0x000000A5;
	RIN_SYS->SYSPCMD	= 0x00000001;
	RIN_SYS->SYSPCMD	= 0x0000FFFE;
	RIN_SYS->SYSPCMD	= 0x00000001;
	return;
}
VOID gR_IN32R_LockSystemProtect(VOID)
{
	RIN_SYS->SYSPCMD	= 0x00000000;
}
VOID gR_IN32R_WaitMS(INT iTmout)
{
	tslp_tsk(iTmout);
}
/*** EOF ***/
