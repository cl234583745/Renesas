/***********************************************************************
    Renesas uPD602x Industrial Ether PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
 ***********************************************************************/

#ifndef _DDR_PHY_UPD602x_H_
#define _DDR_PHY_UPD602x_H_

#include "COMMONDEF.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PHY_REG_INT_MASK        ( 0x001d )  /*!< Register 29: Interrupt source                                */
#define PHY_REG_INT_ENA         ( 0x001e )  /*!< Register 30: Interrupt enable                                */
#define PHY_REG_SPEC_CNTSTAT    ( 0x001f )  /*!< Register 31: Special control and status                      */

// Register 31: Special control and status
#define UPD602x_DUPLEX_MASK     (0x0010)            /*!< Duplex type mask   */
#define UPD602x_DUPLEX_HALF     (0x0000)            /*!< Harf duplex        */
#define UPD602x_DUPLEX_FULL     (0x0010)            /*!< Full duplex        */
#define UPD602x_SPEED_MASK      (0x000C)            /*!< Speed status mask  */
#define UPD602x_SPEED_10M       (0x0004)            /*!<   10BASE-T         */
#define UPD602x_SPEED_100M      (0x0008)            /*!<  100BASE-T         */

// Register 29: Interrupt mask
// Register 30: Interrupt status
#define UPD602x_INT_CLIPPING    (BIT12)    /*!< [12] Clipping interrupt    */
#define UPD602x_INT_MAXLEVEL    (BIT11)    /*!< [11] Maxlvl interrupt      */
#define UPD602x_INT_BERCOUNT    (BIT10)    /*!< [10] BER counter trigger   */
#define UPD602x_INT_FEQ         (BIT9)     /*!< [ 9] FEQ trigger           */
#define UPD602x_INT_ENERGYON    (BIT7)     /*!< [ 7] ENERGYON generated    */
#define UPD602x_INT_NEGOCOMP    (BIT6)     /*!< [ 6] auto-negotiation complete */
#define UPD602x_INT_REMOTEFAULT (BIT5)     /*!< [ 5] remote fault detected */
#define UPD602x_INT_LINK_DWN    (BIT4)     /*!< [ 4] link down             */
#define UPD602x_INT_NEGOLAST    (BIT3)     /*!< [ 3] auto-negotiation Last Page acknowledge */
#define UPD602x_INT_PARALLEL    (BIT2)     /*!< [ 2] parallel detection fault*/
#define UPD602x_INT_NEGOPAGE    (BIT1)     /*!< [ 1] auto-negotiation page  received*/


#ifdef __cplusplus
}
#endif
#endif /* _DDR_PHY_UPD602x_H_ */

