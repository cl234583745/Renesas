/**
 *******************************************************************************
 * @file  main.c
 * @brief Version get sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>
#include <time.h>

#include "uart/uart.h"
#include "timer/timer.h"
#include "kernel.h"
#include "net_hdr.h"
#include "snmp.h"
#include "snmp_lib.h"
#include "board_init.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************
  @brief  Main
  @param  --
  @return always 0
 *******************************************************************************
*/
int main(void)
{
	uint8_t c;
	clock_t prev_time;
	clock_t curr_time;
	uint8_t led;
	
	/* Initialize LED */
	board_init();
	
	/* Initialize driver */
	uart_init(SYS_UART_CH);				/* UART */
	clock_init();						/* Timer */
	
	/* Opening message */
    rin_boot_message();

	/* main loop */
	prev_time = clock();
	curr_time = prev_time;
	while (1)
	{
		/* check input key */
		c = (uint8_t)getchar();
		if (c == ' ')
		{
			break;
		}
		else if ((c >= '0') && (c <= '7'))
		{
			led = get_board_led();
			set_board_led(led ^ (1 << (c - '0')));
		}
		else if (c == 'c')
		{
			curr_time = clock();
		}
		else if (c == 'v')
		{
			printf("\nR-IN32M4 Package ver%s\n",rin_package_get_version(0));
			printf("R-IN32M4 Package ver%s\n",rin_package_get_version(1));
			printf("R-IN32M4 Driver ver%s\n",rin_driver_get_version(0));
			printf("R-IN32M4 Driver ver%s\n",rin_driver_get_version(1));
			printf("R-IN32M4 HWOS lib ver%s\n",rin_hwos_get_version(0));
			printf("R-IN32M4 HWOS lib ver%s\n",rin_hwos_get_version(1));
			printf("R-IN32M4 uNet3 lib ver%s\n",unet3_get_version(0));
			printf("R-IN32M4 uNet3 lib ver%s\n",unet3_get_version(1));
			printf("R-IN32M4 uNet3 snmp lib ver%s\n",unet3snmp_get_version(0));
			printf("R-IN32M4 uNet3 snmp lib ver%s\n",unet3snmp_get_version(1));
		}

		/* check interval */
		if (prev_time != curr_time)
		{
			printf(" (interval =%lu ms)\n", ((curr_time - prev_time) / (CLOCKS_PER_SEC / 1000)));
			prev_time = curr_time;
		}
	}
	
	/* Ending message */
	printf("\n");
	printf("bye\n");

	return 0;
}


