/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_H_INCLUDED__
#define	__R_IN32T_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

typedef enum _R_IN32T_PORT_SEL_ENUM {
	R_IN32T_E_PORT1,				
	R_IN32T_E_PORT2,				
	R_IN32T_E_PORT_SEL_NUM			
} R_IN32T_PORT_SEL_ENUM;
#define	R_IN32T_PORT_SEL_NUM	(ULONG)R_IN32T_E_PORT_SEL_NUM


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern ERRCODE gerR_IN32T_CommunicationInit( VOID );
extern ERRCODE gerR_IN32T_RAMClear( VOID );

extern ERRCODE gerR_IN32T_NonCyclicRcvTest( R_IN32T_PORT_SEL_ENUM );

extern ERRCODE gerR_IN32T_OutsideLoopBackTest( R_IN32T_PORT_SEL_ENUM );

ERRCODE gerR_IN32T_TxFrame_CreateEtherCcieHeader (const UCHAR*,const UCHAR*, UCHAR, UCHAR, R_IN32_NONCICLIC_FRAME_T*);
ERRCODE gerR_IN32T_TxFrame_CreateTransient1Header (USHORT,USHORT,R_IN32_TRAN1_HEAD_T*);
ERRCODE gerR_IN32T_TxFrame_CreateRequestSlmpHeader (R_IN32_SLMP_REQUSET_SETTING_T*,R_IN32_SLMP_REQUEST_FRAME_T*,ULONG*,USHORT*);
ERRCODE gerR_IN32T_TxFrame_CreateResponseSlmpHeader (const R_IN32_SLMP_REQUEST_FRAME_T*,USHORT,R_IN32_SLMP_RESPONSE_FRAME_T*);
UCHAR guchR_IN32T_TxFrame_GetTransient1IdentificationNumber(VOID);

#endif	/* __R_IN32T_H_INCLUDED__ */

/*** EOF ***/
