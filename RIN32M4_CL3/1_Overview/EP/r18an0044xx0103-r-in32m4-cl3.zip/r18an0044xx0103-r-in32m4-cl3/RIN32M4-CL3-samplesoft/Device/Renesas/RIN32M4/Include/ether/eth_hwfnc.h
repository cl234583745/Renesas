/**
 *******************************************************************************
 * @file  eth_hwfnc.h
 * @brief Ether Hardware function header
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef ETH_HWFNC_H__
#define ETH_HWFNC_H__

/******************************************************************************
Includes   <System Includes> , "Project Includes"
******************************************************************************/

/*******************************************************************************
Macro definitions
*******************************************************************************/
#define UINT unsigned int
//#define NULL -1

/*******************************************************************************
Typedef definitions
*******************************************************************************/

/*******************************************************************************
Exported global variables and functions (to be accessed by other files)
*******************************************************************************/
/* ==== struct ==== */
typedef struct {
	UINT    r0;                         /*!< R0             */
	UINT    r1;                         /*!< R1             */
}SYSCALL_RETURN;

/* ==== function ==== */

// ====== Buffer allocator ======
UINT hwfnc_longbuffer_get(UINT par);
UINT hwfnc_shortbuffer_get(UINT len);
UINT hwfnc_buffer_release(UINT top);
UINT hwfnc_buffer_return(UINT top, UINT addr);
UINT hwfnc_longbuffer_link(UINT src, UINT *p_sta);

// ====== HeaderEnDec ======
UINT hwfnc_gbe_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_gbe_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_snap_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_ip4_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_ip4_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_ip6_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_ip6_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_tcp_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_tcp_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_udp_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_udp_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_arp_enc(UINT src, UINT dst, UINT *excp);
UINT hwfnc_arp_dec(UINT src, UINT dst, UINT *excp);
UINT hwfnc_dsc_trns(UINT src, UINT dst, UINT *excp);
UINT hwfnc_dmt(UINT src, UINT dst, UINT bytes, UINT *excp);
UINT hwfnc_dmr(UINT src, UINT dst, UINT bytes, UINT *excp);

// ====== DMAC ======
// --- MACDMA ---
UINT hwfnc_macdma_tx_start(UINT dsc, UINT llsn);
UINT hwfnc_macdma_rx_enable(UINT llsn);
UINT hwfnc_macdma_rx_disable(UINT flg);
UINT hwfnc_macdma_rx_control(UINT msk);
UINT hwfnc_macdma_tx_errstat(void);
UINT hwfnc_macdma_rx_errstat(void);

// --- INTBUFF DMA ---
/* Internal Buffer */
UINT hwfnc_intbuff_dma_start1(UINT dst, UINT src, UINT bytes, UINT llsn);
UINT hwfnc_intbuff_dma_start2(UINT ddsc, UINT sdsc, UINT llsn);

#endif	// ETH_HWFNC_H__

/* End of File */
