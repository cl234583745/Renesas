/**
 *******************************************************************************
 * @file  kernel_id.h
 * @brief HW-RTOS kernel configuration file
 * 
 * @note 
 * Copyright 2016 Renesas Electronics Corporation
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	KERNEL_ID_H__
#define	KERNEL_ID_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "kernel.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
// --- Task ID ---
#define ID_TASK_INIT	 1
#define ID_TASK_MAIN	 2
#define ID_TASK_INT1	 3
#define ID_TASK_LED      4
#define ID_TASK_IDLE	63

// --- Semaphore/Mutex ID ---
#define ID_APL_SEM1		 1
#define ID_APL_SEM2		 2
#define ID_APL_MTX1		 3
#define ID_APL_MTX2		 4

// --- Eventflag ID ---
#define ID_APL_FLG1		 1
#define ID_APL_FLG2		 2

// --- Mailbox ID ---
#define ID_APL_MBX1		 1
#define ID_APL_MBX2		 2

#endif // KERNEL_ID_H__
