/**
 *******************************************************************************
 * @file  uart.c
 * @brief UART control program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "uart/uart.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define RX_FIFO_EMPTY			(1 << 0)
#define RX_FIFO_FULL			(1 << 1)
#define TX_FIFO_EMPTY			(1 << 2)
#define TX_FIFO_FULL			(1 << 3)

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
  @brief  Initialize UART driver and controller
  @param  ch       -- UART channel
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
 ******************************************************************************
*/
ER_RET uart_init(uint8_t ch)
{
	RIN_UART_TypeDef *RIN_UART;
	uint8_t irq_num;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Port setting
	//=========================================
	switch (ch)
	{
		// -- UART ch 0 --
		case 0:
			RIN_GPIO->PFCE2B &= ~0x03;			// P20 -> RXD0
			RIN_GPIO->PFC2B  &= ~0x03;			// P21 -> TXD0
			RIN_GPIO->PMC2B  |=  0x03;
			break;
		// -- UART ch 1 --
		case 1:
			RIN_GPIO->PFCE3B &= ~0x03;			// P30 -> RXD1
			RIN_GPIO->PFC3B  &= ~0x03;			// P31 -> TXD1
			RIN_GPIO->PMC3B  |=  0x03;
			break;
		default:
			break;
	}
	//=========================================
	// Initialize UART
	//=========================================
	// --- Baud rate setting (115200bps@PCLK=100MHz) ---
	RIN_UART->URTJnCTL2 = (   1 << 13 ) |		// PRSCLK    = PCLK/2^n
	                      ( 217       ) ;		// Baud rate = PRSCLK/(2*n)

	// --- Data format setting ---
	RIN_UART->URTJnCTL1 = (  0 << 15 ) |		// [15]    BF recieve    : non-detect
	                      (  5 << 12 ) |		// [14:12] BF bit length : 13
	                      (  1 <<  8 ) |		// [ 8]    bit length    : 8
	                      (  0 <<  6 ) |		// [ 7: 6] parity        : none
	                      (  0 <<  5 ) |		// [ 5]    tx level      : normal
	                      (  0 <<  4 ) |		// [ 4]    rx level      : normal
	                      (  0 <<  3 ) |		// [ 3]    loop back     : none
	                      (  0 <<  2 ) |		// [ 2]    stop bit      : 1
	                      (  1 <<  1 ) |		// [ 1]    MSB or LSB    : LSB first
	                      (  1 <<  0 ) ;		// [ 0]    TIT output    : when tx complete

	// -- Data consistency error setting ---
	RIN_UART->URTJnCTL0 = 0x00000000;			// [ 0] Disable consistency check

	// --- Timeout detection setting ---
	RIN_UART->URTJnFCTL1 = 0x00000000;			// [ 5: 0] disable to detect timeout

	// --- Communication enable setting ---
	RIN_UART->URTJnCTL0 |= ((1 << 7) |			// [ 7] Enable UARTJn operation
							(1 << 6) |			// [ 6] Enable transmission
							(1 << 5));			// [ 5] Enable reception

	// --- Specify a FIFO pointer ---
	RIN_UART->URTJnFCTL0 = (( 15 << 8 ) |		// [11: 8] Rx pointer for interrupt request
							(  0 << 0 ));		// [ 3: 0] Tx pointer for interrupt request

	// --- Enable interrupt ---
	irq_num = (uint8_t)UAJ0TIT_IRQn + (ch<<1);	// Tx Interrupt (UAJnTIT_IRQn)
//	NVIC_SetPriority((IRQn_Type)irq_num, 10);
//	NVIC_EnableIRQ((IRQn_Type)irq_num);

	irq_num++;									// Rx Interrupt (UAJnTIR_IRQn)
//	NVIC_SetPriority((IRQn_Type)irq_num, 10);
//	NVIC_EnableIRQ((IRQn_Type)irq_num);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Send 1byte charactor code
  @param  ch         -- UART channel
  @param  data       -- 1byte charactor code
  @retval ER_OK      -- Successful
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_write(uint8_t ch,uint8_t data)
{
	RIN_UART_TypeDef *RIN_UART;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Wait until TX FIFO is not full
	//=========================================
	while ( (RIN_UART->URTJnFSTR1 & TX_FIFO_FULL) == TX_FIFO_FULL ) {
	}

	// Set transmit data
	RIN_UART->URTJnFTX = (uint32_t)data;

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Recieve 1byte charactor code
  @param  ch         -- UART channel
  @param  *data      -- 1byte charactor code
  @retval 1          -- Get data
  @retval 0          -- Not get data
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_read(uint8_t ch,uint8_t* data)
{
	RIN_UART_TypeDef *RIN_UART;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Read data
	//=========================================
	if ((RIN_UART->URTJnFSTR1 & RX_FIFO_EMPTY) != RX_FIFO_EMPTY) {
		*data = RIN_UART->URTJnFRX;
		return 1;		/* Get data */
	} else {
		return 0;		/* Not get data */
	}
}

/**
 ******************************************************************************
  @brief  Check recieved code
  @param  ch         -- UART channel
  @retval 1          -- Get data
  @retval 0          -- Not get data
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_check_receivedata(uint8_t ch)
{
	RIN_UART_TypeDef *RIN_UART;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Check RX_FIFO
	//=========================================
	if ((RIN_UART->URTJnFSTR1 & RX_FIFO_EMPTY) != RX_FIFO_EMPTY) {
		return 1;		/* Get data */
	} else {
		return 0;		/* Not get data */
	}
}

/**
 *******************************************************************************
  @brief  UART tx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ0TIT_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************
  @brief  UART rx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ0TIR_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838869
}

/**
 *******************************************************************************
  @brief  UART tx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ1TIT_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************
  @brief  UART rx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ1TIR_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838869
}

