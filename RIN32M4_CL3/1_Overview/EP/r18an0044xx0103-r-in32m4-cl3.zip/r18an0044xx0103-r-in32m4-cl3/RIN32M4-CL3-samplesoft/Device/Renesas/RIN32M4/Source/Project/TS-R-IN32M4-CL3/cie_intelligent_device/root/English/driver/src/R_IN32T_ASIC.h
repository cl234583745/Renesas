/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_ASIC.h                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_ASIC_H_INCLUDED__
#define	__R_IN32T_ASIC_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

typedef enum _R_IN32T_NCYC_TDISNO_ENUM {
	R_IN32T_E_TD_TRAN1_5K_01,	
	R_IN32T_E_TD_TRAN1K_01,	
	R_IN32T_E_TD_NCYC_NUM		
} R_IN32T_NCYC_TDISNO_ENUM;
#define	R_IN32T_TD_NCYC_NUM		(ULONG)R_IN32T_E_TD_NCYC_NUM

typedef enum _R_IN32T_FRAME_EXIST_ENUM {
	R_IN32T_E_FRAME_NOFRAME,	
	R_IN32T_E_FRAME_EXIST		
} R_IN32T_FRAME_EXIST_ENUM;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/

extern ERRCODE erR_IN32T_TxStart( VOID );
extern VOID    R_IN32T_MyStatTxDisable( VOID );
extern VOID    R_IN32T_CyclicTxDisable( VOID );
extern VOID    R_IN32T_NonCyclicTxEnable( VOID );
extern VOID    R_IN32T_NonCyclicTxDisable( VOID );
extern VOID    R_IN32T_TokenTxDisable( VOID );
extern VOID    R_IN32T_TDTran_FrmExistTypeSet( USHORT, R_IN32T_FRAME_EXIST_ENUM );
extern VOID    R_IN32T_TDTran_StatusClear( USHORT );
extern VOID    R_IN32T_TDTran_TxSize_Set( USHORT, USHORT );
extern VOID    R_IN32T_TDTran_LastDisSet( USHORT );
extern VOID    R_IN32T_RDTran_RDisClear( ULONG );

#endif	/* __R_IN32T_ASIC_H_INCLUDED__ */

/*** EOF ***/
