/**
 *******************************************************************************
 * @file  sromc.c
 * @brief Serial Flash ROM Controller control program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "sromc/sromc.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/* SFMSMD register : Read mode */
#define SFMSMD_SLOWREAD			(0 <<  0)	/**< SFMSMD[1:0](SFMRM):0x0=normal read */
#define SFMSMD_FASTREAD			(1 <<  0)	/**< SFMSMD[1:0](SFMRM):0x1=fast read */
#define SFMSMD_FASTREAD2O		(2 <<  0)	/**< SFMSMD[1:0](SFMRM):0x2=fast read dual output */
#define SFMSMD_FASTREAD2IO		(3 <<  0)	/**< SFMSMD[1:0](SFMRM):0x3=fast read dual I/O */
#define SFMSMD_FASTREAD4O		(4 <<  0)	/**< SFMSMD[1:0](SFMRM):0x4=fast read quad output */
#define SFMSMD_FASTREAD4IO		(5 <<  0)	/**< SFMSMD[1:0](SFMRM):0x5=fast read quad I/O */
/* SFMSMD register : SSB expand */
#define SFMSMD_SPIEXT0			(0 <<  4)	/**< SFMSMD[5:4](SFMSE):0x00=non expand */
#define SFMSMD_SPIEXT1			(1 <<  4)	/**< SFMSMD[5:4](SFMSE):0x01=33*SCK expand */
#define SFMSMD_SPIEXT2			(2 <<  4)	/**< SFMSMD[5:4](SFMSE):0x10=129*SCK expand */
#define SFMSMD_SPIEXT3			(3 <<  4)	/**< SFMSMD[5:4](SFMSE):0x11=unlimit expand */
/* SFMSMD register : prefetch */
#define SFMSMD_NO_PREFETCH		(0 <<  6)	/**< SFMSMD[6](SFMPFE):0=prefetch disable */
#define SFMSMD_PREFETCH			(1 <<  6)	/**< SFMSMD[6](SFMPFE):1=prefetch enable */
/* SFMSMD register : prefetch abort */
#define SFMSMD_ABORT_DISABLE	(0 <<  7)	/**< SFMSMD[7](SFMPAE):0=prefetch abort disable */
#define SFMSMD_ABORT_ENABLE		(1 <<  7)	/**< SFMSMD[7](SFMPAE):1=prefetch abort enable */
/* SFMSMD register : SPI mode */
#define SFMSMD_SPIMODE0			(0 <<  8)	/**< SFMSMD[8](SFMMD3):0=SPI mode0 */
#define SFMSMD_SPIMODE3			(1 <<  8)	/**< SFMSMD[8](SFMMD3):1=SPI mode3 */
/* SFMSMD register : output enable expand */
#define SFMSMD_OEEXT0			(0 <<  9)	/**< SFMSMD[9](SFMOEX):0=non expand */
#define SFMSMD_OEEXT1			(1 <<  9)	/**< SFMSMD[9](SFMOEX):1=1*SCK expand */
/* SFMSMD register : output hold */
#define SFMSMD_MOSUPWAIT0		(0 << 10)	/**< SFMSD[10](SFMOHW):0=non expand */
#define SFMSMD_MOSUPWAIT1		(1 << 10)	/**< SFMSD[10](SFMOHW):1=1*HCLK expand (SCK low width)*/
/* SFMSMD register : output setup */
#define SFMSMD_MOHLDWAIT0		(0 << 11)	/**< SFMSD[11](SFMOSW):0=non expand */
#define SFMSMD_MOHLDWAIT1		(1 << 11)	/**< SFMSD[11](SFMOSW):1=1*HCLK expand (SCK high width) */

/* SFMSSC register : SSB release timing */
#define SFMSSC_SSB_H_DELAY0		(0 <<  4)	/**< SFMSSC[4](SFMSHD):0=0.5*SCK before */
#define SFMSSC_SSB_H_DELAY1		(1 <<  4)	/**< SFMSSC[4](SFMSHD):1=1.5*SCK before */
/* SFMSSC register : SSB output timing */
#define SFMSSC_SSB_L_DELAY0		(0 <<  5)	/**< SFMSSC[5](SFMSLD):0=0.5*SCK before */
#define SFMSSC_SSB_L_DELAY1		(1 <<  5)	/**< SFMSSC[5](SFMSLD):1=1.5*SCK before */

/* SFMSKC register : SCK duty adjust */
#define SFMSKC_DUTYXX			(0 <<  5)	/**< SFMSKC[5](SFMDTY):0=non adjust */
#define SFMSKC_DUTY50			(1 <<  5)	/**< SFMSKC[5](SFMDTY):1=0.5*HCLK delayed */

/* SFMCMD register : access mode */
#define SFMCMD_DCOM_DISABLE		(0 <<  0)	/**< SFMCMD[0](DCOM):0=ROM access mode */
#define SFMCMD_DCOM_ENABLE		(1 <<  0)	/**< SFMCMD[0](DCOM):1=Direct access mode */


/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static void sromc_init_port(void);

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 *******************************************************************************
  @brief  Initialize Normal Mode
  @param  -
  @return none
 *******************************************************************************
 */
void sromc_init(void)
{
	/* init controller */
	RIN_SROM->SFMSMD	= (	SFMSMD_MOHLDWAIT0
						|	SFMSMD_MOSUPWAIT0
						|	SFMSMD_OEEXT0
						|	SFMSMD_SPIMODE3
						|	SFMSMD_ABORT_DISABLE
						|	SFMSMD_NO_PREFETCH
						|	SFMSMD_SPIEXT0
						|	SFMSMD_SLOWREAD
						);
	RIN_SROM->SFMSSC	= (	SFMSSC_SSB_L_DELAY1 
						|	SFMSSC_SSB_H_DELAY1
						|	0x07					/* SSB min. width=8*SCK */
						);

	/* PLCK = 100MHz -> SCK = 25MHz */
	RIN_SROM->SFMSKC	= (	SFMSKC_DUTY50
						|	0x02					/* SCK freq.=HCLK/4 */
						);
	
	/* init port */
	sromc_init_port();
	
	return;
}

/**
 *******************************************************************************
  @brief  Initialize Dual I/O  Mode
  @param  -
  @return none
 *******************************************************************************
 */
void sromc_dual_init(void)
{
	/* init controller */
	RIN_SROM->SFMSMD	= (	SFMSMD_MOHLDWAIT0
						|	SFMSMD_MOSUPWAIT0
						|	SFMSMD_OEEXT0
						|	SFMSMD_SPIMODE3
						|	SFMSMD_ABORT_DISABLE
						|	SFMSMD_NO_PREFETCH
						|	SFMSMD_SPIEXT0
						|	SFMSMD_FASTREAD2IO
						);
	RIN_SROM->SFMSSC	= (	SFMSSC_SSB_L_DELAY1 
						|	SFMSSC_SSB_H_DELAY1
						|	0x07					/* SSB min. width=8*SCK */
						);

	/* PLCK = 100MHz -> SCK = 25MHz */
	RIN_SROM->SFMSKC	= (	SFMSKC_DUTY50
						|	0x00					/* SCK freq.=HCLK/2 */
						);
	
	/* init port */
	sromc_init_port();
	
	return;
}

/**
 *******************************************************************************
  @brief  Initialize Quad I/O Mode
  @param  -
  @return none
 *******************************************************************************
 */
void sromc_quad_init(void)
{
	/* init controller */
	RIN_SROM->SFMSMD	= (	SFMSMD_MOHLDWAIT0
						|	SFMSMD_MOSUPWAIT0
						|	SFMSMD_OEEXT0
						|	SFMSMD_SPIMODE3
						|	SFMSMD_ABORT_DISABLE
						|	SFMSMD_NO_PREFETCH
						|	SFMSMD_SPIEXT0
						|	SFMSMD_FASTREAD4IO
						);
	RIN_SROM->SFMSSC	= (	SFMSSC_SSB_L_DELAY1 
						|	SFMSSC_SSB_H_DELAY1
						|	0x07					/* SSB min. width=8*SCK */
						);

	/* PLCK = 100MHz -> SCK = 25MHz */
	RIN_SROM->SFMSKC	= (	SFMSKC_DUTY50
						|	0x00					/* SCK freq.=HCLK/2 */
						);
	
	/* init port */
	sromc_init_port();
	
	return;
}

/**
 *******************************************************************************
  @brief  Write SPI
  @param  [in] data  -- write data 
  @param  [in] first -- flag for first SPI access cycle (0=NOT first, others=first) 
  @param  [in] last  -- flag for last SPI access cycle (0=NOT last, others=last) 
  @return none
 *******************************************************************************
 */
void sromc_write(uint8_t data, uint32_t first, uint32_t last)
{
	if (first != 0) RIN_SROM->SFMCMD = SFMCMD_DCOM_ENABLE;		/* direct access mode */
	                RIN_SROM->SFMCOM = (uint32_t)data;			/* data write on SPI bus */
	if (last  != 0) RIN_SROM->SFMCMD = SFMCMD_DCOM_DISABLE;		/* ROM access mode */
	
	return;
}

/**
 *******************************************************************************
  @brief  Read SPI
  @param  [out] *data -- read data pointer 
  @param  [in]  first -- flag for first SPI access cycle (0=NOT first, others=first) 
  @param  [in]  last  -- flag for last SPI access cycle (0=NOT last, others=last)
  @return none
 *******************************************************************************
 */
void sromc_read(uint8_t* data, uint32_t first, uint32_t last)
{
	if (first != 0) RIN_SROM->SFMCMD = SFMCMD_DCOM_ENABLE;		/* direct access mode */
	                *data = (uint8_t)RIN_SROM->SFMCOM;			/* data read from SPI bus */
	if (last  != 0) RIN_SROM->SFMCMD = SFMCMD_DCOM_DISABLE;		/* ROM access mode */
	
	return;
}

/**
 *******************************************************************************
  @brief  Initialize Port
  @param  none
  @return none
 *******************************************************************************
 */
static void sromc_init_port(void)
{
	
	
#ifdef TS_TCS08467	// TS-TCS08467 (17mm)
	/* EXTP10(SMIO2),EXTP11(SMIO3) */
	/* P14(SMSCK),P15(SMSO),P16(SMSI),P17(SMCSZ) */
	RIN_GPIO->PFCE1B	&= ~0xf0;
	RIN_GPIO->PFC1B		&= ~0xf0;
	RIN_GPIO->PMC1B		|=  0xf0;
	
	RIN_EXTPORT->EXTPFCE1B &= ~0x0C;
	RIN_EXTPORT->EXTPFC1B  &= ~0x0C;
	RIN_EXTPORT->EXTPMC1B  |=  0x0C;

#else				// TS-TCS07908 (23mm)
	/* P10(SMIO2),P11(SMIO3) */
	/* P14(SMSCK),P15(SMSO),P16(SMSI),P17(SMCSZ) */
	RIN_GPIO->PFCE1B	&= ~0xf3;
	RIN_GPIO->PFC1B		&= ~0xf3;
	RIN_GPIO->PMC1B		|=  0xf3;
#endif	// TS_TCS08467

	return;
}
