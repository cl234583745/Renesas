/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_RING.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_RING.h"


VOID R_IN32T_RING_Start( VOID )
{

	RING->ulStart = START_REG_START;

	return;
}

VOID R_IN32T_RING_ModeReset( VOID )
{

	RING->ulMode = MODE_CLR;

	return;
}

VOID R_IN32T_RING_IntClear( VOID )
{

	RING->ulInt2  = INT2_INTCLR;

	return;
}

VOID R_IN32T_RING_RepeatDisable( VOID )
{
	ULONG			ulWriteData;		


	ulWriteData = RING->ulMode;

	ulWriteData |= MODE_REG_RSTOP_REPEATSTOP;

	RING->ulMode = ulWriteData;

	return;
}

VOID R_IN32T_RING_DebugTxEnable( VOID )
{
	ULONG			ulWriteData;		


	ulWriteData = RING->ulMode;

	ulWriteData |= MODE_REG_TX_FRMSNDMODE;

	RING->ulMode = ulWriteData;

	return;
}

VOID R_IN32T_RING_ForcedLinkUpEnable( VOID )
{
	ULONG			ulWriteData;		


	ulWriteData = RING->ulMode;

	ulWriteData |= MODE_REG_FLINKUP_FORCELINKUP;

	RING->ulMode = ulWriteData;

	return;
}

VOID R_IN32T_RING_TxPortSet(
	R_IN32T_PORT_SEL_ENUM	eTxPort		
)
{
	const ULONG		aulTxPort[ R_IN32T_PORT_SEL_NUM ] = {
							DATATXPORT_REG_TX_PORT1,	
							DATATXPORT_REG_TX_PORT2		
						};

	ULONG			ulWriteData;		


	ulWriteData = aulTxPort[(ULONG)eTxPort];

	RING->ulDataTxPort = ulWriteData;

	return;
}

/*** EOF ***/
