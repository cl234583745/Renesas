/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_H_INCLUDED__
#define __R_IN32D_H_INCLUDED__

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_0.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32D_PORT1							0UL
#define R_IN32D_PORT2							1UL

#define R_IN32D_LINKDOWN						0UL
#define R_IN32D_LINKUP							1UL

#define R_IN32D_SPEED_1G						0UL
#define R_IN32D_SPEED_100M						1UL
#define R_IN32D_SPEED_10M						2UL

#define R_IN32D_DUPLEX_FULL					0UL
#define R_IN32D_DUPLEX_HALF					1UL

#define R_IN32D_OK								0				
#define R_IN32D_NG								-1				
#define R_IN32D_NODATA							1				
#define R_IN32D_NODIS							2				
#define R_IN32D_BUSY							3				

#define R_IN32D_RESET_PWRON					1UL		
#define R_IN32D_RESET_SYSTEM					2UL		

#define R_IN32D_NG_OVERFLOW					-1		
#define R_IN32D_NG_EMPTY						-2		


#define R_IN32D_PORTVLD_ALL				0UL		
#define R_IN32D_PORTVLD_1					1UL		
#define R_IN32D_PORTVLD_2					2UL		

#define R_IN32D_TDIS_TXOK					0UL		
#define R_IN32D_TDIS_TXERR					1UL		
#define R_IN32D_TDIS_NG					2UL		


#define R_IN32D_LED_OFF					0UL		
#define R_IN32D_LED_ON						1UL		
#define R_IN32D_LED_BLINK					2UL		


#define R_IN32D_ACTCMD_CYCSTP_STNOUTRANGE		ASIC_BIT0		
#define R_IN32D_ACTCMD_CYCSTP_RSVST			ASIC_BIT1		
#define R_IN32D_ACTCMD_CYCSTP_MSTREQ			ASIC_BIT2		
#define R_IN32D_ACTCMD_CYCSTP_DUPLICATE		ASIC_BIT3		
#define R_IN32D_ACTCMD_STATIONTYPE_VALID		ASIC_BIT6		

#define R_IN32D_CYCLICSTA_STATIONWRONG		(R_IN32_OFF)				
#define R_IN32D_CYCLICSTA_DISCONNECT		(USHORT)(ASIC_BIT14)	
#define R_IN32D_CYCLICSTA_CYCSTOP			(USHORT)(ASIC_BIT15)	

#define	R_IN32D_PHYREG_CTRL			0UL		
#define	R_IN32D_PHYREG_1000CTRL		9UL		
#define	R_IN32D_PHYREG_EXT_ADDRESS		29UL	
#define	R_IN32D_PHYREG_EXT_REGIST		30UL	

#define	R_IN32D_MDIO_CTRL_LOOPBACK_EN	0x4000UL	
#define	R_IN32D_MDIO_CTRL_SWRESET		0x8000UL	

#define	R_IN32D_CYCSTATUS_STATION_MISSMATCH		(USHORT)ASIC_BIT13	
#define	R_IN32D_CYCSTATUS_DLINKSTATE			(USHORT)ASIC_BIT14		
#define	R_IN32D_CYCSTATUS_CYCLICSTATE			(USHORT)ASIC_BIT15		

#define	R_IN32D_CYCSTATUS_GET_ENABLE_MASK			(USHORT)0xD6FF		
#define	R_IN32D_CYCSTATUS_GET_PARAM_MASK			(USHORT)0x000F		
#define	R_IN32D_CYCSTATUS_SET_ENABLE_MASK			(USHORT)0xE000		

#define R_IN32D_PORT1_TMRCHNL						1UL
#define R_IN32D_PORT2_TMRCHNL						2UL

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32D_PRMFRM_INF0_TAG {
	ULONG 		ulNetworkNumber;				
	ULONG 		ulStationNumber;				
} R_IN32D_PRMFRM_INF0_T;

typedef struct _R_IN32D_PRMFRM_INF1_TAG {
	ULONG		ulCommand;						
	ULONG		ulStationType;					
} R_IN32D_PRMFRM_INF1_T;

typedef struct _R_IN32D_PRMFRM_INF2_TAG {
	UCHAR		auchPARAMID[12];				
	ULONG		ulRxByteSize;					
	ULONG		ulRWrByteSize;					
	ULONG		ulRyByteSize;					
	ULONG		ulRWwByteSize;					
} R_IN32D_PRMFRM_INF2_T;


typedef struct _R_IN32D_MACDELIV_RESULT_SET_TAG {
	ULONG		ulMacDelivType;					
	ULONG		ulMacDelivSeqNumber;			
} R_IN32D_MACDELIV_RESULT_SET_T;

typedef struct _R_IN32D_SLVEVENT_SET_TAG {
	ULONG		ulSlaveEventNumber;				
	ULONG		ulSlaveEventInformation;		
} R_IN32D_SLVEVENT_SET_T;

typedef struct _R_IN32D_SELF_STA_SET_TAG {
	ULONG		ulCPURunCond;					
	ULONG		ulCPUErrFoundCond;				
	ULONG		ulCPUSync;						
} R_IN32D_SELF_STA_SET_T;

typedef struct _R_IN32D_CYCLIC_STA_SET_TAG {
	union {
		USHORT	usAll;
		struct {
	USHORT		bDZReserve1:					13;			
	USHORT		b1ZStationClassificationWrong:	1;			
	USHORT		b1ZDLinkState:					1;			
	USHORT		b1ZCyclicState:					1;			
		} stBit;
	} uniCycStaSet;
} R_IN32D_CYCLIC_STA_SET_T;


typedef struct _R_IN32D_CYCLIC_STA_GET_TAG {
	union {
		USHORT	usAll;
		struct {
			USHORT	b3ZComonParamkeepCond:			3;	
			USHORT	b1ZParamCheckCond:				1;	
			USHORT	b1ZMyStationNoRangeOut:			1;	
			USHORT	b1ZMyStationReserveSetup:		1;	
			USHORT	b1ZCyclicOpeInstructPackage:	1;	
			USHORT	b1ZCyclicOpeInstructVarious:	1;	
			USHORT	b1ZReserve1:					1;	
			USHORT	b1ZMyMpuAbnomal:				1;	
			USHORT	b1ZMyStationNumberDuplicate:	1;	
			USHORT	b1ZReserve2:					1;	
			USHORT	b1ZStationClassificationWrong:	1;	
			USHORT	b1ZReserve3:					1;	
			USHORT	b1ZDLinkState:					1;	
			USHORT	b1ZCyclicState:					1;	
		} stBit;
	} uniCycSta;
} R_IN32D_CYCLIC_STA_GET_T;


typedef struct _R_IN32D_NETMOTION_TAG {
	ULONG	ulTknHoldFrmSendCount;				
	ULONG	ulFramSendInterval;					
	ULONG	ulTokenSendCount;					
} R_IN32D_NETMOTION_T;


typedef struct _R_IN32D_MSTMYSTATUS_INFO_TAG {
	ULONG	ulUserAppRun;						
	ULONG	ulCondition;						
	ULONG	ulErrorCode;						
	ULONG	ulTranRcvPropriety;	 				
	ULONG	ulSlaveEventRcvCond;				
	ULONG	ulSlaveEventRcvCondCount;			
	ULONG	ulSyncFlg;							
} R_IN32D_MSTMYSTATUS_INFO_T;


typedef struct _R_IN32D_MIBSDRD_TAG {
	ULONG			ulCyclicRecNomalFrameCnt;	
	ULONG			ulNonCyclicRecValidCnt;		
	ULONG			ulNonCyclicRecRejectCnt;	
} R_IN32D_MIBSDRD_T;

typedef struct _R_IN32D_MIBRGCNT_TAG {
	ULONG			ulHecErr;					
	ULONG			ulDcsFcsErr;				
	ULONG			ulUnderErr;					
	ULONG			ulRpt;						
	ULONG			ulUp;						
	ULONG			ulRptFullDrop;				
	ULONG			ulUpFullDrop;				
} R_IN32D_MIBRGCNT_T;

typedef struct _R_IN32D_MIBMACIP_TAG {
	ULONG			ulRFrm;						
	ULONG			ulTFrm;						
	ULONG			ulRUnd;						
	ULONG			ulROvr;						
	ULONG			ulRFcs;						
	ULONG			ulRFgm;						
	ULONG			ulRIFGErr;					
	ULONG			ulREps;						
	ULONG			ulRCde;						
	ULONG			ulRFce;						
	ULONG			ulRCEE;						
} R_IN32D_MIBMACIP_T;

typedef struct _R_IN32D_FATALERROR_TAG {
	ULONG	ulErrorCode;
	ULONG	ulErrorInfo;
} R_IN32D_FATALERROR_T;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/

extern ERRCODE gerR_IN32D_Init( const UCHAR*, ULONG* );
extern ERRCODE gerR_IN32D_StartRing( VOID );

extern ERRCODE gerR_IN32D_IntrINT1_2( R_IN32_EVTPRM_INTERRUPT_T* );

extern ERRCODE gerR_IN32D_ReleaseLoopIntMask( VOID );
extern ERRCODE gerR_IN32D_SetDisconnectFactor( ULONG ulDisconnectfactor );
extern ULONG gerR_IN32D_GetDisconnectFactor( ULONG* pulDisconnectfactor );


extern ERRCODE gerR_IN32D_SetMyMACAddr( const UCHAR* );
extern ERRCODE gerR_IN32D_SetSndMyMACAddr( const UCHAR* );
extern ERRCODE gerR_IN32D_SetNetworkNumber( ULONG );
extern ERRCODE gerR_IN32D_SetStationNumber( ULONG );
extern ERRCODE gerR_IN32D_GetMIB_SDRD( R_IN32D_MIBSDRD_T* );
extern ERRCODE gerR_IN32D_GetMIB_RGCNT( ULONG, R_IN32D_MIBRGCNT_T* );
extern ERRCODE gerR_IN32D_GetMIB_MACIP( ULONG, R_IN32D_MIBMACIP_T* );
extern ERRCODE gerR_IN32D_ClearRingMIB( VOID );
extern ERRCODE gerR_IN32D_ClearMacIpMIB( VOID );
extern ERRCODE gerR_IN32D_ClearTxRxRAM( VOID );
extern ERRCODE gerR_IN32D_GetNetworkTime( USHORT*, USHORT*, USHORT* );
extern ERRCODE gerR_IN32D_SetNetworkTime( USHORT, USHORT, USHORT );
extern ERRCODE gerR_IN32D_StopWdt( VOID );
extern ERRCODE gerR_IN32D_MacIp_AccessEnable( VOID );
extern ERRCODE gerR_IN32D_MacIp_AccessDisable( VOID );
extern ERRCODE gerR_IN32D_SetMyPort_PortAll( VOID );
extern ERRCODE gerR_IN32D_RcvEnable( VOID );
extern ERRCODE gerR_IN32D_RcvDisable( VOID );
extern ERRCODE gerR_IN32D_StartMstWatchTmr( VOID );
extern ERRCODE gerR_IN32D_SetMasterID( ULONG );
extern ERRCODE gerR_IN32D_UpdateCyclicPermission( VOID );
extern ERRCODE gerR_IN32D_InitPHYLinkSetting( VOID );
extern ERRCODE gerR_IN32D_ResetPHYPower( ULONG );
extern ERRCODE gerR_IN32D_StartIntervalTimer( ULONG, ULONG );
extern ERRCODE gerR_IN32D_StopIntervalTimer( ULONG );
extern ERRCODE gblR_IN32D_IsIntervalTimerTimeout( ULONG );
extern ERRCODE gerR_IN32D_InitSyncCommunication( VOID );
extern ERRCODE gerR_IN32D_SetSyncCommunication( ULONG, ULONG );
extern ERRCODE gerR_IN32D_CheckSyncReceived( VOID );
extern ERRCODE gerR_IN32D_StartInSyncInterrupt( VOID );
extern ERRCODE gerR_IN32D_StartOutSyncInterrupt( VOID );
extern ERRCODE gerR_IN32D_CheckSyncWindowError( VOID );
extern ERRCODE gerR_IN32D_ResetSyncCommunication( VOID );

extern ULONG   gulR_IN32D_GetPortValidInf( VOID );
extern ERRCODE gerR_IN32D_GetMultiCastAddr( UCHAR* );
extern ULONG   gulR_IN32D_GetNodeID( VOID );
extern ERRCODE gerR_IN32D_GetNetMotion( R_IN32D_NETMOTION_T* );
extern ERRCODE gerR_IN32D_GetMasterMyStatus( R_IN32D_MSTMYSTATUS_INFO_T* );
extern ERRCODE gerR_IN32D_FinGetMasterMyStatus( VOID );

extern ERRCODE gerR_IN32D_GetParamStnNetNumber( R_IN32D_PRMFRM_INF0_T* );
extern ERRCODE gerR_IN32D_GetParamActCmdStnType( R_IN32D_PRMFRM_INF1_T* );
extern ERRCODE gerR_IN32D_GetParamComParameter( R_IN32D_PRMFRM_INF2_T* );
extern ERRCODE gerR_IN32D_FetchStationNetworkNumber( VOID );
extern ERRCODE gerR_IN32D_ParameterRcv( PARAMETER_FRAME_REG_TAG* , ULONG );
extern ERRCODE gerR_IN32D_ParamCheckRcv( PARAMCHECK_FRAME_REG_TAG* , ULONG );

extern ERRCODE gerR_IN32D_SetMyStatus( R_IN32D_CYCLIC_STA_SET_T*, R_IN32D_SELF_STA_SET_T*, R_IN32D_SLVEVENT_SET_T*, R_IN32D_MACDELIV_RESULT_SET_T*, ULONG, ULONG );
extern ERRCODE gerR_IN32D_GetCyclicStopFactor( R_IN32D_CYCLIC_STA_GET_T* );
extern ERRCODE gerR_IN32D_GetRcvCyclic( VOID*, VOID*, R_IN32D_CYCLIC_STA_GET_T*, BOOL);
extern ERRCODE gerR_IN32D_SetSndCyclic(const VOID*, const VOID* );
extern ERRCODE gerR_IN32D_MyStaRcvTkn(VOID);

extern ERRCODE gerR_IN32D_GetTranTDIS( USHORT, VOID**, UCHAR* );
extern ERRCODE gerR_IN32D_EntryTranTDIS( UCHAR, USHORT );
extern ERRCODE gerR_IN32D_GetTranSndSts( UCHAR*, ULONG* );
extern ERRCODE gerR_IN32D_GetRcvTran( ULONG*, VOID** );
extern ERRCODE gerR_IN32D_SetRcvTranFin( VOID );

extern ERRCODE gerR_IN32D_PhyGetState( ULONG, ULONG*, ULONG*, ULONG* );
extern ERRCODE gerR_IN32D_MACIP_PHYWrite( ULONG, ULONG, ULONG );
extern ERRCODE gerR_IN32D_MACIP_PHYRead( ULONG, ULONG, ULONG* );

extern ERRCODE gerR_IN32D_SetLedLERR2( ULONG );
extern ERRCODE gerR_IN32D_SetLedLERR1( ULONG );
extern ERRCODE gerR_IN32D_SetLedERR( ULONG );
extern ERRCODE gerR_IN32D_SetLedDLINK( ULONG );
extern ERRCODE gerR_IN32D_SetLedREM( ULONG );
extern ERRCODE gerR_IN32D_SetLedMODE( ULONG );
extern ERRCODE gerR_IN32D_SetLedRUN( ULONG );

extern ULONG   gulR_IN32D_GetLedLERR2( VOID );
extern ULONG   gulR_IN32D_GetLedLERR1( VOID );
extern ULONG   gulR_IN32D_GetLedERR( VOID );
extern ULONG   gulR_IN32D_GetLedDLINK( VOID );
extern ULONG   gulR_IN32D_GetLedREM( VOID );
extern ULONG   gulR_IN32D_GetLedMODE( VOID );
extern ULONG   gulR_IN32D_GetLedRUN( VOID );

extern ERRCODE gerR_IN32D_MaskLed( USHORT );
extern ERRCODE gerR_IN32D_UnMaskLed( USHORT );


extern ERRCODE gerR_IN32D_SetFatalError( R_IN32D_FATALERROR_T* );
extern ERRCODE gerR_IN32D_GetFatalError( R_IN32D_FATALERROR_T* );

/****************************************************************************/
/* Macros                                                         */
/****************************************************************************/
#define	M_RANGECHK(min, value, max)	(((min <= value) && (value <= max)) ? R_IN32D_OK : R_IN32D_NG)

#endif /* __R_IN32D_H_INCLUDED__ */

/*** EOF ***/
