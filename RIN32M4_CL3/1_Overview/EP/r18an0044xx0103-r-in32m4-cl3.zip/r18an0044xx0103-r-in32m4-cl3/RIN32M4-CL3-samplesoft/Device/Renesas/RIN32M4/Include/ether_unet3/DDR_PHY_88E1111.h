/***********************************************************************
    Marvell 88E1111 10/100/Giga PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
 ***********************************************************************/

#ifndef _DDR_PHY_88E1111_H_
#define _DDR_PHY_88E1111_H_

#include "COMMONDEF.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PHY_REG_INT_ENA         ( 0x0012 )  /*!< Register 18: Interrupt enable                                */
#define PHY_REG_INT_STS         ( 0x0013 )  /*!< Register 19: Interrupt status                                */
#define PHY_REG_SPEC_CNTSTAT    ( 0x0011 )  /*!< Register 17: Special control and status                      */

// Register 17: Special control and status
#define MVL_88E1111_DUPLEX_MASK     (BIT13)             /*!< Duplex type mask   */
#define MVL_88E1111_DUPLEX_HALF     (0x0000)            /*!< Harf duplex        */
#define MVL_88E1111_DUPLEX_FULL     (BIT13)             /*!< Full duplex        */
#define MVL_88E1111_SPEED_MASK      (BIT15|BIT14)       /*!< Speed status mask  */
#define MVL_88E1111_SPEED_10M       (0x0000)            /*!<   10BASE-T         */
#define MVL_88E1111_SPEED_100M      (BIT14)             /*!<  100BASE-T         */
#define MVL_88E1111_SPEED_1G        (BIT15)             /*!<  100BASE-T         */

// Register 18: Interrupt mask
// Register 19: Interrupt status
#define MVL_88E1111_INT_NEGOERROR   (BIT15)    /*!< [15] Auto-negotiation error*/
#define MVL_88E1111_INT_SPDCHANGE   (BIT14)    /*!< [14] Speed changed         */
#define MVL_88E1111_INT_DPXCHANGE   (BIT13)    /*!< [13] Duplex changed        */
#define MVL_88E1111_INT_PAGERECV    (BIT12)    /*!< [12] Page received         */
#define MVL_88E1111_INT_NEGOCOMP    (BIT11)    /*!< [11] Auto-negotiation complete*/
#define MVL_88E1111_INT_LNKCHANGE   (BIT10)    /*!< [10] Link status changed   */
#define MVL_88E1111_INT_SMBLERROR   (BIT9)     /*!< [ 9] Symbol error          */
#define MVL_88E1111_INT_FALSECAR    (BIT8)     /*!< [ 8] False carrier         */
#define MVL_88E1111_INT_FIFOFLOW    (BIT7)     /*!< [ 7] FIFO over/underflow   */
#define MVL_88E1111_INT_MDICHANGE   (BIT6)     /*!< [ 6] MDI corssover changed */
#define MVL_88E1111_INT_DOWNSHIFT   (BIT5)     /*!< [ 5] Downshift interrupt   */
#define MVL_88E1111_INT_ENERGY      (BIT4)     /*!< [ 4] Energy detect changed */
#define MVL_88E1111_INT_DTEPOWER    (BIT2)     /*!< [ 2] DTE power detecton changed*/
#define MVL_88E1111_INT_POLARITY    (BIT1)     /*!< [ 1] Polarity changed      */
#define MVL_88E1111_INT_JABBER      (BIT0)     /*!< [ 0] Jabber                */


#ifdef __cplusplus
}
#endif
#endif /* _DDR_PHY_88E1111_H_ */

