/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_Data.h                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__R_IN32T_DATA_H_INCLUDED__
#define	__R_IN32T_DATA_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

extern const UCHAR	gauchR_IN32T_RingMACAdrs[];

extern const UCHAR	gauchR_IN32T_TxMACAdrs[];

extern const ULONG	gaulR_IN32T_NCycTxBufAdr[];


#endif	/* __R_IN32T_DATA_H_INCLUDED__ */

/*** EOF ***/
