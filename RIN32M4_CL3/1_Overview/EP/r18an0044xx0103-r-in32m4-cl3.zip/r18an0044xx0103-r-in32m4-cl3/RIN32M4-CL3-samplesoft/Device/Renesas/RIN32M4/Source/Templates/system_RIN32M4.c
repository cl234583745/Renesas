/**
 *******************************************************************************
 * @file  system_RIN32M4.c
 * @brief sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>

#include "RIN32M4.h"
#include "system_RIN32M4.h"

#include "kernel.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/* CC-Link IE WDT */
#define CCIWDT							(*((volatile uint16_t *) (0x40100962)))

#ifdef __CC_ARM
#define COMPILER_VERSION "ARM "__VERSION__
#elif __GNUC__
#define COMPILER_VERSION "GCC "__VERSION__
#elif __ICCARM__
#define COMPILER_VERSION __VERSION__
#else
#define COMPILER_VERSION "Please put compiler version here (e.g. gcc 4.1)"
#endif

#define BOOT_MODE(b) \
    ((b==0)?"Parallel Flash":(b==1)?"Serial Flash":(b==2)?"External Micon":"Instruction RAM")


/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
uint32_t SystemCoreClock = RIN32M4_SYSCLK ;

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  System initialize
  @param  none
  @retval none
 ******************************************************************************
*/
#ifndef __ICCARM__									// if not use IAR compiler
__attribute__ ((section("handlers_rom"))) 
#endif
void SystemInit(void)
{

	// --- Setup Cortex-M4 core ---
	SCB->SHCSR = 0x00070000;						// Bus,Usage,Mem Fault Handler Enable
	CCIWDT = 0x0000;								// Disable watch dog timer in CC-Link IE module

	// --- Setup memory controller ---
	// ToDo: Please modify wait setting according to user board. Default setting is slowest.
	RIN_MEMC->SMC0 = 0x0000ffff;					// Access wait setting for CS0
//	RIN_MEMC->PRC  = 0x20010001;					// Page ROM control for CS0
	RIN_MEMC->SMC1 = 0x0000ffff;					// Access wait setting for CS1
	RIN_MEMC->SMC2 = 0x0000ffff;					// Access wait setting for CS2
	RIN_MEMC->SMC3 = 0x0000ffff;					// Access wait setting for CS3
}

/**
 ******************************************************************************
  @brief  System core clock update
  @param  none
  @retval none
 ******************************************************************************
*/
#ifndef __ICCARM__									// if not use IAR compiler
__attribute__ ((section("handlers_rom"))) 
#endif
void SystemCoreClockUpdate(void)
{

}

/**
 ******************************************************************************
  @brief  display R-IN boot message
  @param  none
  @retval none
 ******************************************************************************
*/
void rin_boot_message(void)
{
	uint32_t boot_mode;

    boot_mode = ((RIN_SYS->MDMNT >> 7) & 0x3);
    printf("\n");
    printf("Renesas %s\n",RIN_TYPE);
    printf("- compiler  =%s\n", COMPILER_VERSION);
    printf("- boot mode =%s\n", BOOT_MODE(boot_mode));
    printf("- Package   ver%s\n",rin_package_get_version(1));
    printf("- Driver    ver%s\n",rin_driver_get_version(1));
#ifndef OSLESS
    printf("- HWOS lib  ver%s\n",rin_hwos_get_version(1));
#endif
}

/**
 ******************************************************************************
  @brief  get driver version
  @param  [in] mode -- 0 : version , 1 : version + compile date
  @retval none
 ******************************************************************************
*/
char *rin_package_get_version(uint8_t mode)
{
	if(mode)
	{
		return RIN_PACKAGE_VERSION" (build:"__DATE__" "__TIME__")";
	}
	else
	{
		return RIN_PACKAGE_VERSION;
	}
}

/**
 ******************************************************************************
  @brief  get driver version
  @param  [in] mode -- 0 : version , 1 : version + compile date
  @retval none
 ******************************************************************************
*/
char *rin_driver_get_version(uint8_t mode)
{
	if(mode)
	{
		return RIN_DRIVER_VERSION" (build:"__DATE__" "__TIME__")";
	}
	else
	{
		return RIN_DRIVER_VERSION;
	}
}
