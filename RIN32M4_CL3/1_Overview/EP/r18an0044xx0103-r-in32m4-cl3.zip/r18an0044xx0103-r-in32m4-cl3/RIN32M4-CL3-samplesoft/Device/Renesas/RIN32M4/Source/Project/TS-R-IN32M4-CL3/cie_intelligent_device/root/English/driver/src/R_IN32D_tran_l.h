/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_tran_l.h                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_TRAN_L_H_INCLUDED__
#define __R_IN32D_TRAN_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_0.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_FRAME_TYPE_TRAN1		(UCHAR)0x22
#define R_IN32D_FRAME_TYPE_TRAN_ACK	(UCHAR)0x23
#define R_IN32D_FRAME_TYPE_TRAN2		(UCHAR)0x25
#define R_IN32D_FRAME_CMD_REQ_TYPE		(UCHAR)0x80

/****************************************************************************/
/* Functions (for R_IN32D)                                                     */
/****************************************************************************/
extern ERRCODE erR_IN32D_InitTranSndInf( VOID );
extern ERRCODE erR_IN32D_InitTranRcvInf( VOID );

#endif	/* __R_IN32D_TRAN_L_H_INCLUDED__ */

/*** EOF ***/
