###########################################################################################
 R-IN32M4 CAN controler Sample Program
  
                                            Renesas Electronics Corporation   Nov 01, 2019
###########################################################################################
  
 NOTICE 
   This software is just for reference sample software, 
   Renesas does NOT gurantee the operation.
   Please use this software, after you thoroughly check and evaluate on your enviroment.
 
  
  
 =============================================================================== 
  Abstract 
 =============================================================================== 
 This sample program is simple program which is to check the operation of CAN 
 controler.
 
 The operation of the CAN controller is limited to R9A06G064MGBG.
 Cannot be used with R9A06G064SGBG.
 When executing this sample program on the evaluation board TS-TCS07908, 
 comment out "TS_TCS08467" in RIN32M4.h.
 The initial setting is for the evaluation board TS-TCS08467.
 
  \Device\Renesas\RIN32M4\Include\RIN32M4.h
  
 =============================================================================== 
  Operation summary 
 =============================================================================== 
 This sample program conducts the CAN controler initializetion and to send and
 receive data by the loopback mode .

 =============================================================================== 
  Application sample 
 =============================================================================== 
 ====== Driver API ====== 
  - uart_init
  - can_enable
  - can_init
  - can_set_mode
  - can_get_txinfo
  - can_set_data
  - can_tx_req
  - can_get_txinfo
  - can_get_rxinfo
  - can_get_data_dlc
  - can_get_ch_status
  - can_clr_ch_status
 
 ====== Operation interpretation ====== 
 The operation of this sample conducts the following procedure. 

  1. Initialization 
    - UART 
    - LED port 
  2. CAN controler operation sample
    - CAN controler initialize
      - CAN controler Enable
      - CAN controler initialize
      - CAN set operation mode        *1
   - CAN transmit message
   - CAN reception message
   - CAN check the status
  
 ====== Result of operation ====== 

CAN contoler Initialized!
CAN transmit buffer empty
CAN create transmit data
--- CAN ch1: Tx data[ 0 ] = 0x00 ----
--- CAN ch1: Tx data[ 1 ] = 0x11 ----
--- CAN ch1: Tx data[ 2 ] = 0x22 ----
--- CAN ch1: Tx data[ 3 ] = 0x33 ----
--- CAN ch1: Tx data[ 4 ] = 0x44 ----
--- CAN ch1: Tx data[ 5 ] = 0x55 ----
--- CAN ch1: Tx data[ 6 ] = 0x66 ----
--- CAN ch1: Tx data[ 7 ] = 0x77 ----
CAN transmit start..
CAN transmit complete
CAN reception data wait..
CAN reception interrupt
CAN reception message buffer number = 32
--- CAN ch1: Rx data[ 0 ] = 0x00 ----
--- CAN ch1: Rx data[ 1 ] = 0x11 ----
--- CAN ch1: Rx data[ 2 ] = 0x22 ----
--- CAN ch1: Rx data[ 3 ] = 0x33 ----
--- CAN ch1: Rx data[ 4 ] = 0x44 ----
--- CAN ch1: Rx data[ 5 ] = 0x55 ----
--- CAN ch1: Rx data[ 6 ] = 0x66 ----
--- CAN ch1: Rx data[ 7 ] = 0x77 ----
CAN check status
- CAN transmit success!
- CAN reception success!
- CAN no error!

 ====== Notes ====== 
 *1 : Please refer to the "SET_CAN_SELF" to "SET_CAN_NORM" If you do the normal operation

