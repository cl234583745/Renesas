/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_Com.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_Com.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define	R_IN32T_WAITUS_REGSENCE		1000UL			
#define	R_IN32T_TIMES_REGSENCE			500UL			

/*----------------------------------------------*/
#define	R_IN32T_BITOFF_EXP				0x0				
#define	R_IN32T_BITSFT32_STA			0x00000001UL	
#define	R_IN32T_BITSFT32_END			0x00000000UL	


ERRCODE erR_IN32T_Com_WaitBitOff_Word(
	const USHORT*	pusAdrs,		
	USHORT			usBitOFF		
)
{
	R_IN32D_FATALERROR_T	stErrInfo;	
	ULONG				ulCount;	
	USHORT				usReadData;	
	ERRCODE				erResult;	


	erResult = R_IN32_ERR;	

	for ( ulCount = (ULONG)0; R_IN32T_TIMES_REGSENCE > ulCount; ulCount++) {

		usReadData = IN16( pusAdrs );

		if ( (usReadData & usBitOFF) == (USHORT)R_IN32T_BITOFF_EXP ) {
			erResult = R_IN32_OK;	
			break;
		}
		else {
		}

		gR_IN32R_WaitUS( R_IN32T_WAITUS_REGSENCE );
	}

	if ( R_IN32_ERR == erResult ) {

		stErrInfo.ulErrorCode = (ULONG)&erR_IN32T_Com_WaitBitOff_Word;	
		stErrInfo.ulErrorInfo = (ULONG)pusAdrs;						

		(VOID)gerR_IN32D_SetFatalError( &stErrInfo );
	}
	else {
	}

	return( erResult );
}

ERRCODE erR_IN32T_Com_WaitBitOff_DWord(
	const ULONG*	pulAdrs,		
	ULONG			ulBitOFF		
)
{
	R_IN32D_FATALERROR_T	stErrInfo;	
	ULONG				ulCount;	
	USHORT				ulReadData;	
	ERRCODE				erResult;	

	erResult = R_IN32_ERR;	

	for ( ulCount = (ULONG)0; R_IN32T_TIMES_REGSENCE > ulCount; ulCount++) {

		ulReadData = IN32( pulAdrs );

		if ( (ulReadData & ulBitOFF) == (ULONG)R_IN32T_BITOFF_EXP ) {
			erResult = R_IN32_OK;	
			break;
		}
		else {
		}

		gR_IN32R_WaitUS( R_IN32T_WAITUS_REGSENCE );
	}

	if ( R_IN32_ERR == erResult ) {

		stErrInfo.ulErrorCode = (ULONG)&erR_IN32T_Com_WaitBitOff_DWord;	
		stErrInfo.ulErrorInfo = (ULONG)pulAdrs;						

		(VOID)gerR_IN32D_SetFatalError( &stErrInfo );
	}
	else {
	}

	return( erResult );
}

ERRCODE erR_IN32T_Com_BitCompExpect_Word(
	const USHORT*	pusAdrs,		
	USHORT			usBitPtn,		
	USHORT			usExpect		
)
{
	R_IN32D_FATALERROR_T	stErrInfo;		
	USHORT				usReadData;		
	ERRCODE				erResult;		


	erResult = R_IN32_OK;	

	usReadData = IN16( pusAdrs );

	if ( (usReadData & usBitPtn) != (usExpect & usBitPtn) ) {

		erResult = R_IN32_ERR;	

		stErrInfo.ulErrorCode = (ULONG)&erR_IN32T_Com_BitCompExpect_Word;	
		stErrInfo.ulErrorInfo = (ULONG)pusAdrs;							

		(VOID)gerR_IN32D_SetFatalError( &stErrInfo );
	}
	else {
	}

	return( erResult );
}

ERRCODE erR_IN32T_Com_BitCompExpect_DWord(
	const ULONG*	pulAdrs,		
	ULONG			ulBitPtn,		
	ULONG			ulExpect		
)
{
	R_IN32D_FATALERROR_T	stErrInfo;		
	ULONG				ulReadData;		
	ERRCODE				erResult;		


	erResult = R_IN32_OK;	

	ulReadData = IN32( pulAdrs );

	if ( (ulReadData & ulBitPtn) != (ulExpect & ulBitPtn) ) {

		erResult = R_IN32_ERR;	

		stErrInfo.ulErrorCode = (ULONG)&erR_IN32T_Com_BitCompExpect_DWord;	
		stErrInfo.ulErrorInfo = (ULONG)pulAdrs;							

		(VOID)gerR_IN32D_SetFatalError( &stErrInfo );
	}
	else {
	}

	return( erResult );
}

ERRCODE erR_IN32T_Com_MemCompExpect_DWord(
	const ULONG*	pulSubject,		
	const ULONG*	pulExpect,		
	ULONG			ulSize			
)
{
	R_IN32D_FATALERROR_T	stErrInfo;	
	ULONG				ulCount;	
	ULONG				ulReadData;	
	ERRCODE				erResult;	


	ulSize >>= 2;

	erResult = R_IN32_OK;	

	for ( ulCount = (ULONG)0; ulCount < ulSize; ulCount++ ) {

		ulReadData = IN32( pulSubject );
		if ( ulReadData != *pulExpect ) {

			erResult = R_IN32_ERR;	

			stErrInfo.ulErrorCode = (ULONG)&erR_IN32T_Com_MemCompExpect_DWord;	
			stErrInfo.ulErrorInfo = (ULONG)pulSubject;						

			(VOID)gerR_IN32D_SetFatalError( &stErrInfo );

			break;
		}
		else {
		}

		pulSubject++;
		pulExpect++;
	}

	return( erResult );
}

VOID R_IN32T_Com_MemSet_BitShift_DWord(
	ULONG*				pulMem,		
	ULONG				ulSize,		
	R_IN32T_DATPTN_ENUM	eDatPtnSet	
)
{
	ULONG				ulCount;	
	static ULONG		ulData;		


	ulSize >>= 2;

	if ( R_IN32T_E_DATPTN_START == eDatPtnSet ) {
		ulData = R_IN32T_BITSFT32_STA;
	}
	else {
	}

	for ( ulCount = (ULONG)0; ulCount < ulSize; ulCount++ ) {

		OUT32( pulMem, ulData );

		ulData <<= 1;

		if ( R_IN32T_BITSFT32_END == ulData) {
			ulData = R_IN32T_BITSFT32_STA;
		}
		else {
		}

		pulMem++;
	}

	return;
}

/*** EOF ***/
