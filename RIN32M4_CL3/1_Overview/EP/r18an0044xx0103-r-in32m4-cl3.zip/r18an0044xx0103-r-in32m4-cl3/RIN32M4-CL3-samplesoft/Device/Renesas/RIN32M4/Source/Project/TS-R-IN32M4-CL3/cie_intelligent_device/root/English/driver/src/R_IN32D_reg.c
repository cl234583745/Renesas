/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_reg.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"
#include "R_IN32T.h"

#include "R_IN32D_phy_l.h"

#include "R_IN32D_reg_l.h"
#include "R_IN32D_tran_l.h"

#include "R_IN32D_intr_l.h"
#include "ether/ether_phy_init.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_TMOUTUS_TXFIN			9000UL		

#define R_IN32D_WAITUS_SWTXFIN			15UL		

#define R_IN32D_WAITUS_LINKSTAT		250UL		

#define R_IN32D_WAITUS_PHYRESET_ASSERT	R_IN32_WAITUS_PHYRESET_ASSERT	
#define R_IN32D_WAITUS_PHYRESET_END	R_IN32_WAITUS_PHYRESET_END		
#define R_IN32D_WAITUS_RING_POLLING	210UL		

#define R_IN32D_TMOUTUS_RAMCLEAR		80UL		


ERRCODE erR_IN32D_ResetMAC( VOID )
{
	R_IN32D_FATALERROR_T	stFatalErr;			
	R_IN32R_STOPWATCH_T	stShortInform;		
	ULONG				ulSpendTime;		
	ERRCODE				erResult;			

	erResult = R_IN32D_OK;

	gR_IN32R_StartStopwatchTimer( &stShortInform, 1UL );

	while (1) {

		gR_IN32R_GetElapsedTime( &stShortInform, &ulSpendTime );

		if (R_IN32_OFF == TX->R_TXSTART.b01ZSendStart) {	
			erResult = R_IN32D_OK;
			break;
		}
		else {
		}

		if ( R_IN32D_TMOUTUS_TXFIN < ulSpendTime ) {		

			stFatalErr.ulErrorCode = R_IN32D_ERR_TMO_TXFIN;
			stFatalErr.ulErrorInfo = (ULONG)&erR_IN32D_ResetMAC;
			(VOID)gerR_IN32D_SetFatalError( &stFatalErr );

			erResult = R_IN32D_NG;
			break;
		}
		else {
		}
	}

	RING->ulMode |= MODE_REG_RSTOP_REPEATSTOP;

	RX->ulSTGURANTEN_F = R_IN32_OFF;	
	RX->ulRDISENDIS = R_IN32_OFF;	

	gR_IN32R_WaitUS( R_IN32D_WAITUS_SWTXFIN );

	INTRST->usMACRST |= MACRST_RESETMAC;

	gR_IN32R_UnlockSystemProtect();

	RIN_SYS->MACSEL = 0x00000004;
	
	gR_IN32R_LockSystemProtect();

	INTRST->usMACRST &= ~MACRST_RESETMAC;

	gR_IN32R_WaitUS( R_IN32D_WAITUS_LINKSTAT );

	return( erResult );
}


ERRCODE erR_IN32D_ResetPHY( VOID )
{
	ERRCODE erRet = R_IN32_OK;
	ULONG ulRegData;

	gR_IN32R_UnlockSystemProtect();

	RIN_SYS->PHYRSTCH = 1;


	gR_IN32R_LockSystemProtect();

	GMAC->ulMacIpAccess &= ~(MACIP_P1_PHAY_ADDRESS_MASK | MACIP_P2_PHAY_ADDRESS_MASK);

	if(0x00000000 == ( RIN_SYS->MDMNT & 0x00000200 )){
		GMAC->ulMacIpAccess |= (  (MACIP_P1_PHAY_ADDRESS_MASK & (MACIP_P1_PHAY_ADDRESS << MACIP_P1_PHAY_ADDRESS_SHIFT))
								| (MACIP_P2_PHAY_ADDRESS_MASK & (MACIP_P2_PHAY_ADDRESS << MACIP_P2_PHAY_ADDRESS_SHIFT)));
	}
	else{
		GMAC->ulMacIpAccess |= (  (MACIP_P1_PHAY_ADDRESS_MASK & (MACIP_P2_PHAY_ADDRESS << MACIP_P1_PHAY_ADDRESS_SHIFT))
								| (MACIP_P2_PHAY_ADDRESS_MASK & (MACIP_P1_PHAY_ADDRESS << MACIP_P2_PHAY_ADDRESS_SHIFT)));
	}

	gR_IN32R_UnlockSystemProtect();
	RIN_SYS->PHYRST = 0x00000000;
	RIN_SYS->PHYRST = 0x00000001;
	gR_IN32R_LockSystemProtect();

	gR_IN32R_WaitMS(105);

	erRet = gerR_IN32D_MacIp_AccessEnable();

	gR_IN32R_UnlockSystemProtect();

	RIN_SYS->MACSEL  = 0x00000000;	

	gR_IN32R_LockSystemProtect();

	ether_phy_init();
//	ether_phy_init(0);
//	ether_phy_init();

	gR_IN32R_UnlockSystemProtect();

	RIN_SYS->MACSEL = 0x00000004;	


	gR_IN32R_LockSystemProtect();

	ulRegData = 0x00001111;
	gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, 29UL, ulRegData);
	gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, 29UL, ulRegData);

	ulRegData = 0x000081EF;
	gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT1, 30UL, ulRegData);
	gerR_IN32D_MACIP_PHYWrite(R_IN32D_PORT2, 30UL, ulRegData);

	(VOID)gerR_IN32D_MacIp_AccessDisable();

	RIN_SYS->PHYLINK_EN = 0x00000001;
	gerR_IN32D_StopWdt();

	INTRST->usMACRST &= ~MACRST_RESETMAC;

	gR_IN32R_WaitUS( R_IN32D_WAITUS_LINKSTAT );

	return( erRet );
}

ERRCODE gerR_IN32D_SetMyMACAddr(
	const UCHAR*	puchMACAddr		
)
{
	ULONG	ulTemp;			

	ulTemp = (ULONG)puchMACAddr[0];
	ulTemp |= ( ( (ULONG)puchMACAddr[1] << 8 ) & (ULONG)0x0000FF00);
	ulTemp |= ( ( (ULONG)puchMACAddr[2] << 16 ) & (ULONG)0x00FF0000);
	ulTemp |= ( ( (ULONG)puchMACAddr[3] << 24 ) & (ULONG)0xFF000000);
	RING->ulMACAddress0 = ulTemp;

	ulTemp = (ULONG)puchMACAddr[4];
	ulTemp |= ( ( (ULONG)puchMACAddr[5] << 8 ) & (ULONG)0x0000FF00);
	RING->ulMACAddress1 = ulTemp;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetSndMyMACAddr(
	const UCHAR*	puchMACAddr		
)
{
	USHORT	usTemp;			

	usTemp = (USHORT)puchMACAddr[0];
	usTemp |= ((USHORT)puchMACAddr[1] << 8 );
	OUT32(&(TX->MAC_A1), (ULONG)usTemp);

	usTemp = (USHORT)puchMACAddr[2];
	usTemp |= ((USHORT)puchMACAddr[3] << 8 );
	OUT32(&(TX->MAC_A2), (ULONG)usTemp);

	usTemp = (USHORT)puchMACAddr[4];
	usTemp |= ((USHORT)puchMACAddr[5] << 8 );
	OUT32(&(TX->MAC_A3), (ULONG)usTemp);

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetNetworkNumber(
	ULONG	ulNumber		
)
{
	TX->ulNET_NUM = ulNumber;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetStationNumber(
	ULONG	ulNumber		
)
{
	GMAC->ulNum = ulNumber;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetMIB_SDRD(
	R_IN32D_MIBSDRD_T*	pstSdRd		
)
{
	pstSdRd->ulCyclicRecNomalFrameCnt = RX->ulCyclicRecNomalFrameCntF;
	pstSdRd->ulNonCyclicRecValidCnt   = RX->ulNonCyclicRecValidCnt;
	pstSdRd->ulNonCyclicRecRejectCnt  = RX->ulNonCyclicRecRejectCnt;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetMIB_RGCNT(
	ULONG				ulPort,			
	R_IN32D_MIBRGCNT_T*	pstMIB_RING		
)
{
	volatile ULONG*	pulMib;


	if ( R_IN32D_PORT1 == ulPort ) {
		pulMib = &RING->aulMib1Reg[0];
	}
	else {
		pulMib = &RING->aulMib2Reg[0];
	}

	pstMIB_RING->ulHecErr      = *pulMib;
	pstMIB_RING->ulDcsFcsErr   = *(pulMib+1);
	pstMIB_RING->ulUnderErr    = *(pulMib+2);
	__BUS_RELEASE();
	pstMIB_RING->ulRpt         = *(pulMib+3);
	pstMIB_RING->ulUp          = *(pulMib+4);
	pstMIB_RING->ulRptFullDrop = *(pulMib+5);
	pstMIB_RING->ulUpFullDrop  = *(pulMib+6);

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetMIB_MACIP(
	ULONG				ulPort,			
	R_IN32D_MIBMACIP_T*	pstMIB_MACIP	
)
{
	volatile MAC_IP_T*	pstMib;


	if ( R_IN32D_PORT1 == ulPort ) {
		pstMib = &(GMAC->MAC_IP1);
	}
	else {
		pstMib = &(GMAC->MAC_IP2);
	}

	pstMIB_MACIP->ulRFrm    = pstMib->ulRFrm;
	pstMIB_MACIP->ulTFrm    = pstMib->ulTFrm;
	pstMIB_MACIP->ulRUnd    = pstMib->ulRUnd;
	__BUS_RELEASE();
	pstMIB_MACIP->ulROvr    = pstMib->ulROvr;
	pstMIB_MACIP->ulRFcs    = pstMib->ulRFcs;
	pstMIB_MACIP->ulRFgm    = pstMib->ulRFgm;
	pstMIB_MACIP->ulRIFGErr = pstMib->ulRIFGErr;
	__BUS_RELEASE();
	pstMIB_MACIP->ulREps    = pstMib->ulREps;
	pstMIB_MACIP->ulRCde    = pstMib->ulRCde;
	pstMIB_MACIP->ulRFce    = pstMib->ulRFce;
	pstMIB_MACIP->ulRCEE    = pstMib->ulRCEE;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ClearRingMIB( VOID )
{
	RING->ulMib_Clr = MIB_CLR_REG_CNT_CLR;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ClearMacIpMIB( VOID )
{
	GMAC->MAC_IP1.ulMib_Ip_Clr = MIB_CLR_REG_MIB_CLR;
	GMAC->MAC_IP2.ulMib_Ip_Clr = MIB_CLR_REG_MIB_CLR;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ClearTxRxRAM( VOID )
{
	R_IN32R_STOPWATCH_T	stShortInform;		
	ERRCODE				erResult;			

	erResult = R_IN32D_OK;

	gerR_IN32T_RAMClear();

	gR_IN32R_StartStopwatchTimer( &stShortInform, 1UL );

	(VOID)erR_IN32D_InitTranSndInf();		
	(VOID)erR_IN32D_InitTranRcvInf();		


	return( erResult );
}

ERRCODE gerR_IN32D_GetNetworkTime(
	USHORT*	pusTimeHi,	
	USHORT*	pusTimeMid,	
	USHORT*	pusTimeLo	
)
{
	volatile USHORT*	pusTemp;

	pusTemp = (volatile USHORT*)&RX->ulTimeCountL;
	*pusTimeLo = *pusTemp;
	*pusTimeMid = *(pusTemp + 1);
	*pusTimeHi = *(volatile USHORT*)&RX->ulTimeCountH;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetNetworkTime(
	USHORT	usTimeHi,	
	USHORT	usTimeMid,	
	USHORT	usTimeLo	
)
{
	RX->ulTimeCountL = ((((ULONG)usTimeMid)<<16) | (ULONG)usTimeLo);
	RX->ulTimeCountH = (ULONG)usTimeHi;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_StopWdt( VOID )
{
	EMGDBG->stWDTCNT.uniWdtCnt.usAll &= ~WDTCNT_WDT_CNTL;	

	INTRST->NMI.stBIT.uniNmi.usAll |= NMI_INTERNALWDT;			

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_MacIp_AccessEnable( VOID )
{
	ERRCODE				erResult;			
	ULONG				ulTemp;

	ulTemp = GMAC->ulMacIpAccess;
	ulTemp |= MACIP_ACCESS_ENABLE;
	GMAC->ulMacIpAccess = ulTemp;

	erResult = erR_IN32D_MDIO_WaitCommandComplete();

	return( erResult );
}

ERRCODE gerR_IN32D_MacIp_AccessDisable( VOID )
{
	ULONG				ulTemp;

	ulTemp = GMAC->ulMacIpAccess;
	ulTemp &= MACIP_ACCESS_DISABLE;
	GMAC->ulMacIpAccess = ulTemp;

	gR_IN32R_WaitUS( R_IN32D_WAITUS_RING_POLLING );

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetMyPort_PortAll( VOID )
{
	ULONG	ul32bitReg;								

	ul32bitReg = RING->ulSetup_Inf3;
	ul32bitReg &= ~SU_INF_SETUP_FRAME_PORT_ENABLE_MASK;
	ul32bitReg |= (SU_INF_SETUP_FRAME_PORT_ENABLE_MASK & (R_IN32D_MYPORT_PORTALL << SU_INF_SETUP_FRAME_PORT_ENABLE_SHIFT));
	RING->ulSetup_Inf3 = ul32bitReg;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_RcvEnable( VOID )
{

	RX->ulRDISENDIS = R_IN32_ON;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_RcvDisable( VOID )
{

	RX->ulRDISENDIS = R_IN32_OFF;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_StartMstWatchTmr( VOID )
{

	RX->ulMWT_CONT = R_IN32_ON;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetMasterID( ULONG ulMstID )
{
	RX->CYC_MASTER_ID_RCV = ulMstID;
	TX->ulCYC_MASTER_ID_SND = ulMstID;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_UpdateCyclicPermission( VOID )
{
	if( (0x00000001 == IN32(&(TX->CYCLIC_STA)))	&&
		(R_IN32_OFF == TX->SELF_STA.b01ZSendFlagNotSet)){

		TX->ulCYC_TX_PERMISSION |= (ASIC_BIT0 | ASIC_BIT1);
	}
	else{
		TX->ulCYC_TX_PERMISSION &= ~(ASIC_BIT0 | ASIC_BIT1);
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_InitPHYLinkSetting( VOID )
{
	if(R_IN32_CLOCK_SLAVE    == gstPHYSetting[R_IN32_PORT1].ulClk){
		erR_IN32D_InitPHYFastLinkUpSetting(R_IN32D_PORT1, gstPHYSetting[R_IN32_PORT1].ulClk,gstPHYSetting[R_IN32_PORT1].ulMDI);
	}
	if(R_IN32_CLOCK_SLAVE    == gstPHYSetting[R_IN32_PORT2].ulClk){
		erR_IN32D_InitPHYFastLinkUpSetting(R_IN32D_PORT2, gstPHYSetting[R_IN32_PORT2].ulClk,gstPHYSetting[R_IN32_PORT2].ulMDI);
	}

	if( (R_IN32_CLOCK_MASTER    == gstPHYSetting[R_IN32_PORT1].ulClk) ||
		(R_IN32_CLOCK_MASTER    == gstPHYSetting[R_IN32_PORT2].ulClk)){

		gR_IN32R_WaitMS(150);

		if(R_IN32_CLOCK_MASTER    == gstPHYSetting[R_IN32_PORT1].ulClk){
			erR_IN32D_InitPHYFastLinkUpSetting(R_IN32D_PORT1, gstPHYSetting[R_IN32_PORT1].ulClk,gstPHYSetting[R_IN32_PORT1].ulMDI);
			gerR_IN32D_StartIntervalTimer(R_IN32D_PORT1, 500);
		}

		if(R_IN32_CLOCK_MASTER    == gstPHYSetting[R_IN32_PORT2].ulClk){
			erR_IN32D_InitPHYFastLinkUpSetting(R_IN32D_PORT2, gstPHYSetting[R_IN32_PORT2].ulClk,gstPHYSetting[R_IN32_PORT2].ulMDI);
			gerR_IN32D_StartIntervalTimer(R_IN32D_PORT2, 500);
		}

	}

	return( R_IN32D_OK );
}


ERRCODE erR_IN32D_InitPHYFastLinkUpSetting(
	ULONG		ulPort,	
	ULONG		ulClk,	
	ULONG		ulMDI	
)
{
	ULONG		ulPhyReg;

	gerR_IN32D_MacIp_AccessEnable();

	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, 0x8140);
	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, 0x0140);

	(void)gerR_IN32D_MACIP_PHYRead(ulPort, 0, &ulPhyReg);

	while (0x8000 == (ulPhyReg & 0x8000))
	{
		(void)gerR_IN32D_MACIP_PHYRead(ulPort, 0, &ulPhyReg);
	}

	if (R_IN32_CLOCK_SLAVE == ulClk)
	{
		(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 9, 0x1700);
	}
	else
	{
		(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 9, 0x1F00);
	}

	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 31, 0x0001);

	if (R_IN32_MDI_FORCED_MDI == ulMDI)
	{
		(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 19, 0x0008);
	}
	else
	{
		(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 19, 0x000C);
	}

	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 31, 0x0000);

	(void)gerR_IN32D_MACIP_PHYRead(ulPort, 0, &ulPhyReg);
	ulPhyReg |= 0x0800;
	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, ulPhyReg);

	ulPhyReg &= ~0x0800;
	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, ulPhyReg);

	gerR_IN32D_MacIp_AccessDisable();

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ResetPHYPower(
	ULONG		ulPort	
)
{
	ULONG	ulPhyReg;

	gerR_IN32D_MacIp_AccessEnable();

	/* [ Power-down(b11) ] */
	(void)gerR_IN32D_MACIP_PHYRead(ulPort, 0, &ulPhyReg);
	ulPhyReg |= 0x0800;
	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, ulPhyReg);

	/* [ Power-up(b11) ] */
	ulPhyReg &= ~0x0800;
	(void)gerR_IN32D_MACIP_PHYWrite(ulPort, 0, ulPhyReg);

	gerR_IN32D_MacIp_AccessDisable();

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_StartIntervalTimer(
	ULONG				ulPort,			
	ULONG				ulTime			
)
{
	ULONG	ulChnl;

	erR_IN32D_GetPortTmrChnl(ulPort, &ulChnl);

	gR_IN32R_StartIntervalTimer(ulChnl, ulTime);

	return R_IN32_OK;
}
ERRCODE gerR_IN32D_StopIntervalTimer(
		ULONG				ulPort			
)
{
	ULONG	ulChnl;

	erR_IN32D_GetPortTmrChnl(ulPort, &ulChnl);

	gR_IN32R_StopIntervalTimer(ulChnl);

	return R_IN32_OK;
}
BOOL gblR_IN32D_IsIntervalTimerTimeout(
		ULONG				ulPort			
)
{
	ULONG	ulChnl;
	BOOL	blTimeout;

	erR_IN32D_GetPortTmrChnl(ulPort, &ulChnl);

	blTimeout = gR_IN32R_IsIntervalTimerTimeout(ulChnl);

	return blTimeout;
}


ERRCODE erR_IN32D_GetPortTmrChnl(
		ULONG				ulPort,			
		ULONG*				ulChnl			
)
{

	if ( R_IN32D_PORT1 == ulPort ) {
		*ulChnl = R_IN32D_PORT1_TMRCHNL;
	}
	else {
		*ulChnl = R_IN32D_PORT2_TMRCHNL;
	}

	return R_IN32_OK;
}

ERRCODE gerR_IN32D_InitSyncCommunication( VOID )
{
	SC->R_USYNC_EN_DN.b1ZSyncSigInOutPermit = R_USYNC_EN_REG_INOUT_STOP;

	SC->R_USYNC_IOCNT_SEL.b03ZSyncSrcSelect = R_USYNC_SEL_NONUSE;
	SC->R_SYNCCSET.b01ZCommCycCntMode = R_SYNCCSET_REG_COMCTL1;
	SC->R_SYNC_SEL.b01ZSyncFrameSelect  = R_SYNC_SEL_SYNCFRM_MYSTATUS;
	SC->R_SYNC_SEL.b01ZSyncSignalSelect = R_SYNC_SEL_SYNCSIG_USER;

	SC->R_USYNC_CNTCLR_WINSET.b1ZControlChange = R_USYNC_WIN_SET_REG_AUTOSET;
	SC->R_USYNC_CNTCLR_WINSET.b1ZWindowFunc    = R_USYNC_WIN_SET_REG_INVALID;
	SC->R_SETUPCHACNT.b01ZCommCyc = 0;
	SC->R_SETUPCHACNT.b01ZWindCloseTmg = 0;
	SC->R_SETUPCHACNT.b01ZWindOpenTmg = 0;
	SC->R_WINOPENTMG.b1CZWindOpenTmg = 0;
	SC->R_WINCLOSETMG.b1CZWindCloseTmg = 0;
	SC->R_WINOPEN_INT.b10ZWindOpenPermitCycSet = 0;

	SC->R_COMSET.b1CZCommCycSet = 0;
	SC->R_SYNCSET.b10ZSyncCycSet = 0;

	SC->ulR_WINCOUNT1_COMPSET0 = 0;
	SC->ulR_WINCOUNT1_COMPSET1 = 0;
	SC->ulR_WINCOUNT2_COMPSET0 = 0;
	SC->ulR_WINCOUNT2_COMPSET1 = 0;
	__BUS_RELEASE();
	SC->ulR_P1DELYTIMESET0 = 0;
	SC->ulR_P1DELYTIMESET1 = 0;
	SC->ulR_P2DELYTIMESET0 = 0;
	SC->ulR_P2DELYTIMESET1 = 0;

	RX->RX_BANK_SWITCH_MODE.b02ZCycRevBufferBankSwitchMode = RX_BANK_SWITCH_MODE_MANUAL;
	TX->TXCNT.b02ZSndDataMenChgType = TXCNT_BANK_SWITCH_MODE_MANUAL;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetSyncCommunication(
	ULONG		ulCommCycle,		
	ULONG		ulSyncCycle			
)
{
	ULONG		ulSetupRecvPortInf;
	ULONG		ulSyncCycleInf;

	if( 0 == ulCommCycle ) {
		ulSyncCycleInf = 0;		
	}
	else {
		ulSyncCycleInf = ((((ulSyncCycle << 8) / ulCommCycle) + 128) >> 8) - 1;	
	}

	SC->R_COMSET.b1CZCommCycSet = ulCommCycle;
	SC->R_SYNCSET.b10ZSyncCycSet = ulSyncCycleInf;

	ulSetupRecvPortInf = RING->ulSetup_RxP & 0x00000003;
	if( 1 == ulSetupRecvPortInf ) {
		SC->R_WINSET.b01ZWindSetting = R_WINSET_REG_WIN1;
	}
	else if( 2 == ulSetupRecvPortInf ) {
		SC->R_WINSET.b01ZWindSetting = R_WINSET_REG_WIN2;
	}
	else {
	}

	SC->R_WINOPENTMG.b1CZWindOpenTmg = ulCommCycle - R_WINCLOSETMG_REG_2US;
	SC->R_WINCLOSETMG.b1CZWindCloseTmg = R_WINCLOSETMG_REG_2US;
	SC->R_WINOPEN_INT.b10ZWindOpenPermitCycSet = 0;
	SC->R_USYNC_CNTCLR_WINSET.b1ZWindowFunc = R_USYNC_WIN_SET_REG_VALID;


	SC->R_RXBUFFTMG.b1CZRcvStartTmg = ulCommCycle - R_WINCLOSETMG_REG_2US - 1;
	RX->RX_BANK_SWITCH_MODE.b02ZCycRevBufferBankSwitchMode = RX_BANK_SWITCH_MODE_SEMIAUTO;

	SC->R_TXBUFFTMG.b1CZSndStartTmg = 0;
	TX->TXCNT.b02ZSndDataMenChgType = TXCNT_BANK_SWITCH_MODE_SEMIAUTO;

	SC->R_USYNC_IOCNT_SEL.b1ZSyncSigInOutSetting = R_USYNC_IOCNT_REG_IN;
	SC->R_USYNC_IOCNT_SEL.b03ZSyncSrcSelect = R_USYNC_SEL_SYNCFRM;
	SC->R_USYNC_EN_DN.b1ZSyncSigInOutPermit = R_USYNC_EN_REG_INOUT_START;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_CheckSyncReceived( VOID )
{
	ERRCODE		erResult;

	erResult = R_IN32D_OK;

	if( R_USYNC_DN_REG_NORMAL_COMP != SC->R_USYNC_EN_DN.b2ZSyncProcCompStat ) {
		erResult = R_IN32D_NG;
	}

	return( erResult );
}

ERRCODE gerR_IN32D_StartInSyncInterrupt( VOID )
{
	(VOID)erR_IN32D_UnMaskInSYNCINTL();

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_StartOutSyncInterrupt( VOID )
{
	(VOID)erR_IN32D_UnMaskOutSYNCINTL();

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_CheckSyncWindowError( VOID )
{
	ERRCODE		erResult = R_IN32D_OK;

	if ( 0 < SC->R_UAOFFCOUNT.b10ZUserSetOutOfSyncErrTotalCnt ) {
		erResult = R_IN32D_NG;
	}

	SC->R_UAOFFCOUNT.b10ZUserSetOutOfSyncErrTotalCnt = 0;

	return( erResult );
}

ERRCODE gerR_IN32D_ResetSyncCommunication( VOID )
{
	(VOID)erR_IN32D_MaskSYNCINTLAll();
	(VOID)erR_IN32D_ClearSYNCINTLAll();

	(VOID)gerR_IN32D_InitSyncCommunication();

	return( R_IN32D_OK );
}

/*** EOF ***/
