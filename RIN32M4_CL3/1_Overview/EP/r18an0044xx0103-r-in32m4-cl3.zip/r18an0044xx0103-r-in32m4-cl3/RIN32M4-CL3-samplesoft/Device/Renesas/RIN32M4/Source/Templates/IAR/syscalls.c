/**
 *******************************************************************************
 * @file  syscall.c
 * @brief Retarget program
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */


/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <time.h>
#include <yfuns.h>
#include "uart/uart.h"
#include "system_RIN32M4.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define OVERRIDE_LOW_LEVEL_IO		(1)		// 0: Not override, 1: Override

/*===========================================================================*/
/* S T R U C T                                                               */
/*===========================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
int const __aeabi_CLOCKS_PER_SEC = RIN32M4_SYSCLK / 8;

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
 * @brief     Reentrant write
 * @param     handle  -- file descriptor
 * @param     *buffer -- file pointer
 * @param     size    -- length
 * @return    write length
 ******************************************************************************
 */
#if (OVERRIDE_LOW_LEVEL_IO == 1)
size_t __write(int handle, const unsigned char * buffer, size_t size)
{
  size_t nChars = 0;

  if (buffer == 0)
  {
    /*
     * This means that we should flush internal buffers.  Since we
     * don't we just return.  (Remember, "handle" == -1 means that all
     * handles should be flushed.)
     */
    return 0;
  }

  /* This template only writes to "standard out" and "standard err",
   * for all other file handles it returns failure. */
  if (handle != _LLIO_STDOUT && handle != _LLIO_STDERR)
  {
    return _LLIO_ERROR;
  }

  for (/* Empty */; size != 0; --size)
  {
	if (*buffer == '\n') {
		(void)uart_write(SYS_UART_CH,'\r');							/* UART 1byte transmit */
	}
	uart_write(SYS_UART_CH,*buffer++);								/* UART 1byte transmit */
    ++nChars;
  }

  return nChars;
}

/**
 ******************************************************************************
 * @brief     Reentrant read
 * @param     handle  -- file descriptor
 * @param     *buffer -- file pointer
 * @param     size    -- length
 * @return    read length
 ******************************************************************************
 */
size_t __read(int handle, unsigned char * buffer, size_t size)
{
  int nChars = 0;

  /* This template only reads from "standard in", for all other file
   * handles it returns failure. */
  if (handle != _LLIO_STDIN)
  {
    return _LLIO_ERROR;
  }

  for (/* Empty */; size > 0; --size)
  {
	unsigned char c;
	while (uart_read(SYS_UART_CH,&c) == 0);					/* UART 1byte recieve */
	(void)uart_write(SYS_UART_CH,c);						/* echo back */

    *buffer++ = c;
    ++nChars;
  }

  return nChars;
}
#endif
/**
 ******************************************************************************
 * @brief     Reentrant sytem clock
 * @param     none
 * @return    Timing information
 ******************************************************************************
 */
clock_t clock(void)
{
	return (clock_t)(RIN_TMR->TAUJ2CNT0);
}

