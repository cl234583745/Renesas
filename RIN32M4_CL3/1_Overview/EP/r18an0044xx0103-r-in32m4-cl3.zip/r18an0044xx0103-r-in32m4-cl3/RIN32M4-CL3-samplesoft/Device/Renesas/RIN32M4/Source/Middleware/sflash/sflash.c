/**
 *******************************************************************************
 * @file  sflash.c
 * @brief Serial Flash ROM control program for R-IN32M4 @ MX25L6533F
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/

#include "sromc/sromc.h"
#include "sflash.h"


/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/* commands */
#define SFLASH_COMMAND_PAGE_PROGRAM		(0x02)				/**< page program command */
#define SFLASH_COMMAND_READ_DATA		(0x03)				/**< read data command */
#define SFLASH_COMMAND_WRITE_DISABLE	(0x04)				/**< write disable command */
#define SFLASH_COMMAND_READ_STATUS		(0x05)				/**< read status register command */
#define SFLASH_COMMAND_WRITE_ENABLE		(0x06)				/**< write enable command */
#define SFLASH_COMMAND_ERASE_4K			(0x20)				/**< sector erase (4Kbyte) command */
#define SFLASH_COMMAND_ERASE_64K		(0xd8)				/**< sector erase (64Kbyte) command */
#define SFLASH_COMMAND_ERASE_CHIP		(0xc7)				/**< chip erase command */

/* status register */
#define SFLASH_STATUS_BUSY				(1 << 0)			/**< erase/program in progress status */
#define SFLASH_STATUS_WEL				(1 << 1)			/**< write enable latch status */

/** channel info structure for serial flash */
typedef struct
{
	/* system info */
	uint32_t system_read_mapped_memory;						/**< read memory mapped flag (0=unmapped, others=mapped) */
	uint32_t system_base_address;							/**< read memory mapped address */
	/* device info */
	uint32_t device_total_size;								/**< device size */
	uint32_t device_erase_size;								/**< erase size */
	uint32_t device_program_size;							/**< program size */
} sflash_into_t;


/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/** channel information for serial flash */
const sflash_into_t sflash_info[SFLASH_CHANNEL_MAX] =
{
	/* ch 0 */
	(1)						/* read memory mapped flag */
,	(SFLASH_BASE_ADDRESS)	/* read memory mapped address */
,	(SFLASH_DEVICE_SIZE)	/* device size */
,	(SFLASH_ERASE_SIZE)		/* erase size */
,	(SFLASH_PROGRAM_SIZE)	/* program size */
};


/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/


/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

static ER_RET sflash_init_spi(void);
static ER_RET sflash_dual_init_spi(void);
static ER_RET sflash_quad_init_spi(void);
static ER_RET sflash_rd_spi(uint8_t* data, uint32_t first, uint32_t last);
static ER_RET sflash_wr_spi(uint8_t data, uint32_t first, uint32_t last);


/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
 
  @brief  Initialize
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_NG    -- Failed
 
 ******************************************************************************
 */
ER_RET sflash_init(void)
{
	ER_RET retval;
	static uint8_t data[1];
	
	retval = sflash_init_spi();
	
	/* Set "Quad Enable" to 0 */

	//WREN
	sromc_write(0x06, 1, 1);
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);
		if((data[0] & 0x2) == 0x2)break;
	}
	//WRSR
	sromc_write(0x01, 1, 0);
	sromc_write(0x00, 0, 0); // Status
	sromc_write(0x00, 0, 1); // Config
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);
		if((data[0] & 0x1) == 0x0)break;
	}
	//RDSR
	sromc_write(0x05, 1, 0);
	sromc_read(data, 0, 1);
	if(data[0] & 0x40 == 0x40){return ER_NG;}
	/* End "Quad Enable" to 0 */
	
	/* Init */
	return retval;
}

/**
 ******************************************************************************
 
  @brief  Initialize
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_NG    -- Failed
 
 ******************************************************************************
 */
ER_RET sflash_dual_init(void)
{
	ER_RET retval;
	static uint8_t data[1];
	
	retval = sflash_dual_init_spi();
	
	/* Set "Quad Enable" to 0 */

	//WREN
	sromc_write(0x06, 1, 1);
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);
		if((data[0] & 0x2) == 0x2)break;
	}
	//WRSR
	sromc_write(0x01, 1, 0);
	sromc_write(0x00, 0, 0); // Status
	sromc_write(0x00, 0, 1); // Config
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);
		if((data[0] & 0x1) == 0x0)break;
	}
	//RDSR
	sromc_write(0x05, 1, 0);
	sromc_read(data, 0, 1);
	if(data[0] & 0x40 == 0x40){return ER_NG;}
	/* End "Quad Enable" to 0 */
	
	/* Init */
	return retval;
}

/**
 ******************************************************************************
 
  @brief  Initialize
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_NG    -- Failed
 
 ******************************************************************************
 */
ER_RET sflash_quad_init(void)
{
	ER_RET retval;
	static uint8_t data[1];
	
	retval = sflash_quad_init_spi();
	
	/* Set "Quad Enable" to 1 */

	//WREN
	sromc_write(0x06, 1, 1);
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);	
		if((data[0] & 0x2) == 0x2)break;
	}
	//WRSR
	sromc_write(0x01, 1, 0);
	sromc_write(0x40, 0, 0); // Status
	sromc_write(0x00, 0, 1); // Config
	//RDSR
	while(1){
		sromc_write(0x05, 1, 0);
		sromc_read(data, 0, 1);
		if((data[0] & 0x1) == 0x0)break;
	}
	//RDSR
	sromc_write(0x05, 1, 0);
	sromc_read(data, 0, 1);
	if(data[0] & 0x40 != 0x40){return ER_NG;}
	/* End "Quad Enable" to 1 */
	
	/* Init */
	return retval;
}

/**
 ******************************************************************************
 
  @brief  Read Data
  @param  [out] *buf -- Buffer address
  @param  [in]  addr -- Read address
  @param  [in]  size -- Read size (byte)
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET sflash_read(uint8_t* buf, uint32_t addr, uint32_t size)
{
	sflash_into_t* info_p;
	uint32_t i;
	
	/* Get channel info */
	info_p = (sflash_into_t*)(&sflash_info[0]);
	
	/* Check address range */
	if ((addr + size) > info_p->device_total_size)
	{
		return ER_PARAM;
	}
	
	/* Read */
	if (info_p->system_read_mapped_memory != 0)		/* Memory mapped */
	{
		addr += info_p->system_base_address;
		for (i = 0; i < size; i++)
		{
			*buf++ = *(__IO uint8_t*)(addr + i);
		}
	}
	else											/* IO mapped */
	{
		/*
		 *---------------------------------------------------------------------
		 * 
		 *  read sequence 
		 * 
		 *---------------------------------------------------------------------
		 */
		/* normal read */
		sflash_wr_spi(SFLASH_COMMAND_READ_DATA, 1, 0);
		sflash_wr_spi((addr >> 16) & 0xff     , 0, 0);
		sflash_wr_spi((addr >>  8) & 0xff     , 0, 0);
		sflash_wr_spi((addr >>  0) & 0xff     , 0, 0);
		for (i = 0; i < (size - 1); i++)
		{
			sflash_rd_spi(buf++, 0, 0);
		}
		sflash_rd_spi(buf++, 0, 1);
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Program
  @param  [in] *buf -- buffer address
  @param  [in] addr -- Program base address
  @param  [in] size -- Program size
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET sflash_program(uint8_t* buf, uint32_t addr, uint32_t size)
{
	sflash_into_t* info_p;
	uint8_t        status;
	uint32_t       i;
	
	/* Get channel info */
	info_p = (sflash_into_t*)(&sflash_info[0]);
	
	/* Check address range */
	if ((addr + size) > info_p->device_total_size)
	{
		return ER_PARAM;
	}
	
	/* Erase and Program */
	while (size > 0)
	{
		uint32_t erase_offset;
		uint32_t erase_size;
		uint32_t program_size;
		uint32_t program_addr;
		
		/* get offset and size */
		erase_offset = (addr & (info_p->device_erase_size - 1));
		if (size > (info_p->device_erase_size - erase_offset))
		{
			erase_size = (info_p->device_erase_size - erase_offset);
		}
		else
		{
			erase_size = size;
		}
#if 0
		/*
		 *---------------------------------------------------------------------
		 * 
		 *  sector erase sequence 
		 * 
		 *---------------------------------------------------------------------
		 */
		/* write enable */
		sflash_wr_spi(SFLASH_COMMAND_WRITE_ENABLE, 1, 1);
		/* sector erase */
		sflash_wr_spi(SFLASH_COMMAND_ERASE_64K   , 1, 0);
		sflash_wr_spi((addr >> 16) & 0xff        , 0, 0);
		sflash_wr_spi((addr >>  8) & 0xff        , 0, 0);
		sflash_wr_spi((addr >>  0) & 0xff        , 0, 1);
		/* read status */
		do
		{
			sflash_wr_spi(SFLASH_COMMAND_READ_STATUS, 1, 0);
			sflash_rd_spi(&status                   , 0, 1);
		} while (status & SFLASH_STATUS_BUSY);
#endif		
		program_addr = addr;
		program_size = erase_size;
		while (program_size > 0)
		{
			uint32_t programing_offset;
			uint32_t programing_size;
			
			/* get offset and size */
			programing_offset = (program_addr & (info_p->device_program_size - 1));
			if (program_size > (info_p->device_program_size - programing_offset))
			{
				programing_size = (info_p->device_program_size - programing_offset);
			}
			else
			{
				programing_size = program_size;
			}
			
			/*
			 *---------------------------------------------------------------------
			 * 
			 *  page program sequence 
			 * 
			 *---------------------------------------------------------------------
			 */
			/* write enable */
			sflash_wr_spi(SFLASH_COMMAND_WRITE_ENABLE, 1, 1);
			/* page program */
			sflash_wr_spi(SFLASH_COMMAND_PAGE_PROGRAM, 1, 0);
			sflash_wr_spi((program_addr >> 16) & 0xff        , 0, 0);
			sflash_wr_spi((program_addr >>  8) & 0xff        , 0, 0);
			sflash_wr_spi((program_addr >>  0) & 0xff        , 0, 0);
			for (i = 0; i < (programing_size - 1); i++)
			{
				sflash_wr_spi(*buf++, 0, 0);
			}
			sflash_wr_spi(*buf++, 0, 1);
			/* read status */
			do
			{
				sflash_wr_spi(SFLASH_COMMAND_READ_STATUS, 1, 0);
				sflash_rd_spi(&status                   , 0, 1);
			} while (status & SFLASH_STATUS_BUSY);
			
			/* update address and size */
			program_addr += programing_size;
			program_size -= programing_size;
		}
		
		/* update address and size */
		addr += erase_size;
		size -= erase_size;
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Erase
  @param  [in] addr -- Erase base address
  @param  [in] size -- Erase size
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET sflash_erase(uint32_t addr, uint32_t size)
{
	sflash_into_t* info_p;
	uint8_t        status;
	
	/* Get channel info */
	info_p = (sflash_into_t*)(&sflash_info[0]);
	
	/* Check address range */
	if ((addr + size) > info_p->device_total_size)
	{
		return ER_PARAM;
	}
	
	/* Erase */
	if (((addr       ) < (                            info_p->device_erase_size))
	&&  ((addr + size) > (info_p->device_total_size - info_p->device_erase_size)))
	{	/* chip erase */
		/*
		 *---------------------------------------------------------------------
		 * 
		 *  chip erase sequence 
		 * 
		 *---------------------------------------------------------------------
		 */
		/* write enable */
		sflash_wr_spi(SFLASH_COMMAND_WRITE_ENABLE, 1, 1);
		/* chip erase */
		sflash_wr_spi(SFLASH_COMMAND_ERASE_CHIP  , 1, 1);
		/* read status */
		do
		{
			sflash_wr_spi(SFLASH_COMMAND_READ_STATUS, 1, 0);
			sflash_rd_spi(&status                   , 0, 1);
		} while (status & SFLASH_STATUS_BUSY);
	}
	else
	{	/* sector erase */
		uint32_t erase_offset;
		uint32_t erase_size;
		
		while (size > 0)
		{
			/* get offset and size */
			erase_offset = (addr & (info_p->device_erase_size - 1));
			if (size > (info_p->device_erase_size - erase_offset))
			{
				erase_size = (info_p->device_erase_size - erase_offset);
			}
			else
			{
				erase_size = size;
			}
			
			/*
			 *-----------------------------------------------------------------
			 * 
			 *  sector erase sequence 
			 * 
			 *-----------------------------------------------------------------
			 */
			/* write enable */
			sflash_wr_spi(SFLASH_COMMAND_WRITE_ENABLE, 1, 1);
			/* sector erase */
			sflash_wr_spi(SFLASH_COMMAND_ERASE_64K   , 1, 0);
			sflash_wr_spi((addr >> 16) & 0xff        , 0, 0);
			sflash_wr_spi((addr >>  8) & 0xff        , 0, 0);
			sflash_wr_spi((addr >>  0) & 0xff        , 0, 1);
			/* read status */
			do
			{
				sflash_wr_spi(SFLASH_COMMAND_READ_STATUS, 1, 0);
				sflash_rd_spi(&status                   , 0, 1);
			} while (status & SFLASH_STATUS_BUSY);
			
			/* update address and size */
			addr += erase_size;
			size -= erase_size;
		}
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Initialize SPI
  @return Error condition
  @retval ER_OK    -- Successful
 ******************************************************************************
 */
static ER_RET sflash_init_spi(void)
{
	ER_RET retval;
	
	sromc_init();
	retval = ER_OK;
	
	return retval;
}

/**
 ******************************************************************************
  @brief  Initialize SPI (Dual I/O mode)
  @return Error condition
  @retval ER_OK    -- Successful
 ******************************************************************************
 */
static ER_RET sflash_dual_init_spi(void)
{
	ER_RET retval;
	
	sromc_dual_init();
	retval = ER_OK;
	
	return retval;
}

/**
 ******************************************************************************
  @brief  Initialize SPI (Quad I/O Mode)
  @return Error condition
  @retval ER_OK    -- Successful
 ******************************************************************************
 */
static ER_RET sflash_quad_init_spi(void)
{
	ER_RET retval;
	
	sromc_quad_init();
	retval = ER_OK;
	
	return retval;
}

/**
 ******************************************************************************
  @brief  Write SPI
  @param  [in] data  -- Write data
  @param  [in] first -- flag for first SPI access cycle (0=NOT first, others=first)
  @param  [in] last  -- flag for last SPI access cycle (0=NOT last, others=last)
  @return Error condition
  @retval ER_OK    -- Successful
 ******************************************************************************
 */
static ER_RET sflash_wr_spi(uint8_t data, uint32_t first, uint32_t last)
{
	ER_RET retval;
	
	retval = ER_PARAM;
	
	sromc_write(data, first, last);
	retval = ER_OK;
	
	return retval;
}

/**
 ******************************************************************************
  @brief  Read SPI
  @param  [out] *data -- Read data pointer
  @param  [in]  first -- Flag for first SPI access cycle (0=NOT first, others=first)
  @param  [in]  last  -- Flag for last SPI access cycle (0=NOT last, others=last)
  @return Error condition
  @retval ER_OK    -- Successful
 ******************************************************************************
 */
static ER_RET sflash_rd_spi(uint8_t* data, uint32_t first, uint32_t last)
{
	ER_RET retval;
	
	sromc_read(data, first, last);
	retval = ER_OK;
	
	return retval;
}

