/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Time.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/


#define UNTP_ZERO					0			

#define UNTP_DAY1Y		365		
#define UNTP_DAY4Y		1461	
#define UNTP_DAY100Y	36524	
#define UNTP_DAY400Y	146097	

#define UNTP_4Y			4		
#define UNTP_100Y		100		
#define UNTP_400Y		400		

#define UNTP_DAY5M		153		
#define UNTP_DAY2M		61		
#define UNTP_DAY1M		31		

#define UNTP_2M			2		
#define UNTP_5M			5		
#define UNTP_12M		12		

#define UNTP_SECOND_86400		86400		
#define UNTP_SECOND_3600		3600		
#define UNTP_SECOND_60			60			

#define UNTP_WDAYOFFSET			3			
#define UNTP_DAY1W				7			

#define UNTP_DNSTDMON			3			
#define UNTP_DNSTDDAY			1			

#define R_IN32C_TM_DNSTDDAY2000Y	730425		
#define R_IN32C_TM_DNSTDTIME2000Y	0			

#define	R_IN32C_TM_YEAR_DATE_CNT	365			
#define R_IN32C_TM_4Y				4			
#define R_IN32C_TM_100Y			100			
#define R_IN32C_TM_400Y			400			
#define	R_IN32C_TM_MONTH_DEF		1			
#define	R_IN32C_TM_DATE_DEF		1			
#define	R_IN32C_TM_YEAR			100			
#define	R_IN32C_TM_DAY				24*60*60	
#define	R_IN32C_TM_HOUR			60*60		
#define	R_IN32C_TM_MINUTES			60			

#define	R_IN32C_TM_START_YEAR		2000		
#define	R_IN32C_TM_END_YEAR		2136		


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
const USHORT gausR_IN32C_MonthDateCnt[12] = 
{
	31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
};


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static VOID erR_IN32C_GetTimeInfoFromDays(R_IN32_TIMEINFO_T*, LONG, LONG);
static ULONG ulR_IN32C_GetTimeSerialFromDate(USHORT, USHORT, USHORT);
static USHORT usR_IN32C_GetLeapYear(USHORT);



ERRCODE gerR_IN32C_TimeInfoToSerial(
	const R_IN32_TIMEINFO_T* pstTimeInfo,		
	USHORT*               pusSerial			
)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG ulDays;
	ULONG ulSecs;

	if ((R_IN32C_TM_START_YEAR <= pstTimeInfo->usYear) && (R_IN32C_TM_END_YEAR >= pstTimeInfo->usYear)) {

		ulDays = ulR_IN32C_GetTimeSerialFromDate(pstTimeInfo->usYear, pstTimeInfo->usMonth, pstTimeInfo->usDay);

		ulSecs = 	 ((ulDays                   * R_IN32C_TM_DAY) 
					+ ((ULONG)pstTimeInfo->usHour * R_IN32C_TM_HOUR)
					+ ((ULONG)pstTimeInfo->usMin  * R_IN32C_TM_MINUTES)
					+ ((ULONG)pstTimeInfo->usSec));
	}
	else {
		erRet  = R_IN32C_NG_OUTOFRANGE;
		ulSecs = 0;					
	}

	pusSerial[2] = (USHORT)(ulSecs >> 16);
	pusSerial[1] = (USHORT)(ulSecs & 0xffff);
	pusSerial[0] = 0; 

	return erRet;
}



ERRCODE gerR_IN32C_TimeSerialToInfo(
	R_IN32_TIMEINFO_T* pstTimeInfo,		
	const USHORT*   pusSerial 			
)
{
	ULONG ulSerial;						
	ERRCODE erRet = R_IN32C_OK;
	LONG lPassageDay;					
	LONG lPassageTime;					


	ulSerial = (ULONG)(((ULONG)pusSerial[2] << 16) | pusSerial[1]);

	lPassageDay = R_IN32C_TM_DNSTDDAY2000Y;			
	lPassageTime = R_IN32C_TM_DNSTDTIME2000Y;			

	lPassageDay += (LONG)(ulSerial / UNTP_SECOND_86400);	
	
	lPassageTime += (LONG)(ulSerial % UNTP_SECOND_86400);	
	
	if ( lPassageTime >= (LONG)UNTP_SECOND_86400 ) {
		lPassageDay++;
		lPassageTime -= (LONG)UNTP_SECOND_86400;
	}
	erR_IN32C_GetTimeInfoFromDays(pstTimeInfo, lPassageDay, lPassageTime);
	__BUS_RELEASE();

	return erRet;
}

VOID erR_IN32C_GetTimeInfoFromDays(
	R_IN32_TIMEINFO_T* pstTimeInfo, 		
	LONG lDayNumber, 					
	LONG lDNTime						
)
{
	LONG lY400, lY100, lY4, lY1;	
	SHORT sM5, sM2, sM1;			
	SHORT sYear  = (SHORT)UNTP_ZERO;		
	CHAR  chMonth = (CHAR)UNTP_DNSTDMON;	
	CHAR  chDay   = (CHAR)UNTP_DNSTDDAY;	
	CHAR  chHour;		
	CHAR  chMin;		
	CHAR  chSec;		
	CHAR  chWday;		
	
	chWday = (CHAR)((lDayNumber + (LONG)UNTP_WDAYOFFSET) % (LONG)UNTP_DAY1W);
	
	lY400 = lDayNumber / (LONG)UNTP_DAY400Y;
	lDayNumber %= (LONG)UNTP_DAY400Y;
	
	lY100 = lDayNumber / (LONG)UNTP_DAY100Y;
	lDayNumber %= (LONG)UNTP_DAY100Y;
	
	if ( lY100 == (LONG)UNTP_4Y ) {
		lY100--;
		lDayNumber += (LONG)UNTP_DAY100Y;
	}
	
	lY4  = lDayNumber / (LONG)UNTP_DAY4Y;
	lDayNumber %= (LONG)UNTP_DAY4Y;

	lY1  = lDayNumber / (LONG)UNTP_DAY1Y;
	lDayNumber %= (LONG)UNTP_DAY1Y;
	if ( lY1 == (LONG)UNTP_4Y ) {
		lY1--;
		lDayNumber += (LONG)UNTP_DAY1Y;
	}
	sYear = (SHORT)((lY400 * (LONG)UNTP_400Y) + (lY100 * (LONG)UNTP_100Y) + (lY4 * (LONG)UNTP_4Y) + lY1);
	
	sM5  = (SHORT)(lDayNumber / (LONG)UNTP_DAY5M);
	lDayNumber %= (LONG)UNTP_DAY5M;
	sM2  = (SHORT)(lDayNumber / (LONG)UNTP_DAY2M);
	lDayNumber %= (LONG)UNTP_DAY2M;
	sM1  = (SHORT)(lDayNumber / (LONG)UNTP_DAY1M);
	lDayNumber %= (LONG)UNTP_DAY1M;
	chMonth = chMonth + (CHAR)((sM5 * (LONG)UNTP_5M) + (sM2 * (LONG)UNTP_2M) + sM1);
	
	chDay += (CHAR)lDayNumber;
	
	if ( chMonth > (CHAR)UNTP_12M ) {
		chMonth -= (CHAR)UNTP_12M;
		sYear++;
	}
	
	chHour = (CHAR)(lDNTime / (LONG)UNTP_SECOND_3600);								
	chMin = (CHAR)((lDNTime % (LONG)UNTP_SECOND_3600) / (LONG)UNTP_SECOND_60);		
	chSec = (CHAR)(lDNTime % (LONG)UNTP_SECOND_60);									
	
	pstTimeInfo->usYear  = (USHORT)sYear;			
	pstTimeInfo->usMonth = (USHORT)chMonth;			
	pstTimeInfo->usDay   = (USHORT)chDay;			
	pstTimeInfo->usHour  = (USHORT)chHour;			
	pstTimeInfo->usMin   = (USHORT)chMin;			
	pstTimeInfo->usSec   = (USHORT)chSec;			
	pstTimeInfo->usMsec  = (USHORT)0;				
	pstTimeInfo->usWday  = (USHORT)chWday;			
}



ULONG ulR_IN32C_GetTimeSerialFromDate(
	USHORT usInYear, 					
	USHORT usInMonth, 					
	USHORT usInDay						
)
{
	ULONG		ulAddDate;				
	USHORT		usLeapYearCnt;			
	USHORT		usYeardateCnt;			
	USHORT		usAddMonth;				
	int			i;						
	
	ulAddDate = 0;
	usAddMonth = 0;

	usYeardateCnt = 0;
	for (i = R_IN32C_TM_START_YEAR; i < usInYear; i++) {
		usLeapYearCnt = usR_IN32C_GetLeapYear((USHORT)i);	
		usYeardateCnt += R_IN32C_TM_YEAR_DATE_CNT + usLeapYearCnt;	
	}
	if (usInMonth > 2) {
		usLeapYearCnt = usR_IN32C_GetLeapYear(usInYear);	
	}
	else {
		usLeapYearCnt = 0;
	}
	for (i = 0; i < usInMonth-1; i++) {
		usAddMonth += gausR_IN32C_MonthDateCnt[i];
	}

	ulAddDate = usYeardateCnt + (usAddMonth + usLeapYearCnt) + (usInDay -1); 

	return ulAddDate;
}



USHORT usR_IN32C_GetLeapYear(
	USHORT usTargetYear				
)
{
	USHORT		usRetVal;			
	
	usRetVal = 0;
	
	if(((usTargetYear % R_IN32C_TM_4Y == 0)&&(usTargetYear % R_IN32C_TM_100Y != 0)) || (usTargetYear % R_IN32C_TM_400Y == 0)){
		usRetVal = 1;
	}
	else{
		usRetVal = 0;
	}

	return usRetVal;
}

/*** EOF ***/
