/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Cyclic.c                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


VOID R_IN32C_SeqCyclic(
	R_IN32D_CYCLIC_STA_GET_T usCyclicStatus		
)
{
	gR_IN32R_DisableInt();

	gstR_IN32C.stCyclic.stGetStopSts.uniCycSta.usAll = usCyclicStatus.uniCycSta.usAll;

	if( usCyclicStatus.uniCycSta.usAll == CYCLIC_STA_PARAMENDRECV ){
		gstR_IN32C.stCyclic.ulState = R_IN32C_CYC_STS_RUN;
	}
	else {
		gstR_IN32C.stCyclic.ulState = R_IN32C_CYC_STS_STOP;
	}

	gR_IN32R_EnableInt();

	return;
}

ERRCODE gerR_IN32C_CyclicRcvMain(
	VOID* pRyDst,			
	VOID* pRWwDst,			
	BOOL blEnable			
)
{
	ERRCODE erRet;
	ERRCODE erRet2;
	ERRCODE erRet3;
	ERRCODE erRet4;
	R_IN32D_CYCLIC_STA_GET_T stSts;
	R_IN32D_MSTMYSTATUS_INFO_T stWork;
	BOOL blCopyEnable;
	ULONG ulRcvMystatus;
	ULONG ulRcvCyclic;
	ULONG ulClearReg;

	erRet2 = R_IN32D_NODATA;

	blCopyEnable = blEnable;

	if(R_IN32_OFF != RX->RX_BANK_STS.b01ZCycRevBufferBankState) {
		if ( R_IN32C_MOTSYNC_WAIT != gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
			ulRcvMystatus = RD->stRD_CNTL.b1ZOWNBit_B;
			ulRcvCyclic = RX->ulCYCFLG_B;
			ulClearReg = RDIS_CNT_RECVA;

			RX->ulRX_BANK_SWITCH = R_IN32_ON;
		}
		else {
			ulRcvMystatus = RD->stRD_CNTL.b1ZOWNBit_A;
			ulRcvCyclic = RX->ulCYCFLG_A;
			ulClearReg = ~RDIS_CNT_RECVA;
		}
	}
	else {
		if ( R_IN32C_MOTSYNC_WAIT != gstR_IN32C.stMotSyncCtl.ulSyncStatus ) {
			ulRcvMystatus = RD->stRD_CNTL.b1ZOWNBit_A;
			ulRcvCyclic = RX->ulCYCFLG_A;
			ulClearReg = RDIS_CNT_RECVB;

			RX->ulRX_BANK_SWITCH = R_IN32_ON;
		}
		else {
			ulRcvMystatus = RD->stRD_CNTL.b1ZOWNBit_B;
			ulRcvCyclic = RX->ulCYCFLG_B;
			ulClearReg = ~RDIS_CNT_RECVB;
		}
	}
	

		
	if( R_IN32C_MOTSYNC_WAIT != gstR_IN32C.stMotSyncCtl.ulSyncStatus ){
	if((R_IN32_ON == ulRcvCyclic) && (R_IN32_ON == ulRcvMystatus)) {
			if(R_IN32_ON == ulRcvMystatus){
				erRet2 = gerR_IN32D_GetMasterMyStatus(&stWork);
			}
			else {
			}

			OUT32(&(RD->stRD_CNTL), ulClearReg);


			if (R_IN32D_OK == erRet2) {
				(VOID)erR_IN32C_CheckSyncFrmTmgErr( &stWork );

				gR_IN32S_Memcpy(&gstR_IN32C.stMain.stMasterMyStatus,&stWork,sizeof(R_IN32D_MSTMYSTATUS_INFO_T));
				gstR_IN32C.stMain.blValidMasterMyStatus = R_IN32_TRUE;

				if (R_IN32_TRUE == gstR_IN32C.stMain.stMasterMyStatus.ulCondition) {
					blCopyEnable = R_IN32_FALSE;	
				}
				else {
				}

				erRet3 = gerR_IN32D_GetRcvCyclic(pRyDst, pRWwDst, &stSts, blCopyEnable);

				if (R_IN32D_OK == erRet3) {
					erRet = R_IN32C_OK;
				}
				else {
					erRet = R_IN32C_NG_NODATA;
				}

				R_IN32C_SeqCyclic(stSts);

			}
			else {
				(VOID)erR_IN32C_CancelSyncOffCheck();

				(VOID)gerR_IN32D_GetCyclicStopFactor( &stSts );
				
				R_IN32C_SeqCyclic(stSts);		
				
				erRet = R_IN32C_NG_NODATA;
			}

			(VOID)gerR_IN32D_FinGetMasterMyStatus();
		}
	else {

		if(R_IN32_ON == ulRcvMystatus){
			erRet2 = gerR_IN32D_GetMasterMyStatus(&stWork);

			OUT32(&(RD->stRD_CNTL), ulClearReg);

			if (R_IN32D_OK == erRet2) {
				(VOID)erR_IN32C_CheckSyncFrmTmgErr( &stWork );
			}
			else {
				(VOID)erR_IN32C_CancelSyncOffCheck();
			}

			(VOID)gerR_IN32D_FinGetMasterMyStatus();
		}
		else {
			(VOID)erR_IN32C_CancelSyncOffCheckForNonRecv();
		}

		(VOID)gerR_IN32D_GetCyclicStopFactor( &stSts );
		
		R_IN32C_SeqCyclic(stSts);		
		
		erRet = R_IN32C_NG_NODATA;
	}
	}
	else{
		if(R_IN32_ON == ulRcvCyclic) {
			if(R_IN32_ON == ulRcvMystatus){
				erRet2 = gerR_IN32D_GetMasterMyStatus(&stWork);
				OUT32(&(RD->stRD_CNTL), ulClearReg);
			}
			else {
			}
			if (R_IN32D_OK == erRet2) {
	
				gR_IN32S_Memcpy(&gstR_IN32C.stMain.stMasterMyStatus,&stWork,sizeof(R_IN32D_MSTMYSTATUS_INFO_T));
				gstR_IN32C.stMain.blValidMasterMyStatus = R_IN32_TRUE;

				if (R_IN32_TRUE == gstR_IN32C.stMain.stMasterMyStatus.ulCondition) {
					blCopyEnable = R_IN32_FALSE;	
				}
				else {
				}

			}

			erRet3 = gerR_IN32D_GetRcvCyclic(pRyDst, pRWwDst, &stSts, blCopyEnable);

			if (R_IN32D_OK == erRet3) {
				erRet = R_IN32C_OK;
			}
			else {
				erRet = R_IN32C_NG_NODATA;
			}

			R_IN32C_SeqCyclic(stSts);


			(VOID)gerR_IN32D_FinGetMasterMyStatus();
		}
		else{
			if(R_IN32_ON == ulRcvMystatus){
				erRet2 = gerR_IN32D_GetMasterMyStatus(&stWork);
				OUT32(&(RD->stRD_CNTL), ulClearReg);

				if (R_IN32D_OK == erRet2) {
					(VOID)erR_IN32C_CheckSyncFrmTmgErr( &stWork );

					gR_IN32S_Memcpy(&gstR_IN32C.stMain.stMasterMyStatus, &stWork, sizeof(R_IN32D_MSTMYSTATUS_INFO_T));
					gstR_IN32C.stMain.blValidMasterMyStatus = R_IN32_TRUE;
				}
				else {
					(VOID)erR_IN32C_CancelSyncOffCheck();
				}

				(VOID)gerR_IN32D_FinGetMasterMyStatus();
			}
			else {
				(VOID)erR_IN32C_CancelSyncOffCheckForNonRecv();
			}

			(VOID)gerR_IN32D_GetCyclicStopFactor( &stSts );
		
			R_IN32C_SeqCyclic(stSts);
		
			erRet = R_IN32C_NG_NODATA;
		}
	}

	gR_IN32R_DisableInt();

	erRet4 = gerR_IN32D_SetMyStatus(
						&gstR_IN32C.stCyclic.stSetStopReq,		
						&gstR_IN32C.stInf0.stSelfStatus,		
						&gstR_IN32C.stSlvEvt.stSetSlvEvt,		
						&gstR_IN32C.stMACAddrTbl.stInf,		
						gstR_IN32C.stInf0.ulErrCode,			
						gstR_IN32C.stInf0.ulUserInformation);	
	if (R_IN32D_OK == erRet4) {
		gstR_IN32C.stMain.blReqSlvEvt = R_IN32_FALSE;		
	}
	else {
	}

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_CyclicSndMain(
	const VOID *pRxSrc,		
	const VOID *pRWrSrc,	
	BOOL blEnable			
)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;

	if (R_IN32_TRUE == blEnable) {
		erRet2 = gerR_IN32D_SetSndCyclic(pRxSrc, pRWrSrc);
	}
	else {
		erRet2 = R_IN32D_OK;
	}

	if (R_IN32D_OK == erRet2) {
		if ((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_FIRSTSND) != 0) {
			(VOID)gerR_IN32C_ClrCyclicSndStopRequest(R_IN32C_CYCSTOP_FIRSTSND);
		}
		else {
		}
	}
	else {
	}

	return erRet;
}

ERRCODE gerR_IN32C_SetCyclicSndStopRequest(
	ULONG ulSrc				
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gstR_IN32C.stCyclic.ulStopRequst |= ulSrc;		
	(VOID)erR_IN32C_ReqCyclicSndStop();

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE gerR_IN32C_ClrCyclicSndStopRequest(
	ULONG ulSrc				
)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32R_DisableInt();

	gstR_IN32C.stCyclic.ulStopRequst &= (~ulSrc);	
	(VOID)erR_IN32C_ReqCyclicSndStop();

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_ReqCyclicSndStop(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	if (((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_INIT) != 0) ||
		((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_PARAM) != 0) ||
		((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_FIRSTSND) != 0) ||
		((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_APP2) != 0)) {
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll |= R_IN32D_CYCSTATUS_CYCLICSTATE;
	}
	else {
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll &= ~R_IN32D_CYCSTATUS_CYCLICSTATE;
	}

	if((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_LEAVE) != 0){
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll |= R_IN32D_CYCSTATUS_DLINKSTATE;
	}
	else {
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll &= ~R_IN32D_CYCSTATUS_DLINKSTATE;
	}

	if (((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_TYPE) != 0) || 
	    ((gstR_IN32C.stCyclic.ulStopRequst & R_IN32C_CYCSTOP_CYCSIZE) != 0)) {
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll |= R_IN32D_CYCSTATUS_STATION_MISSMATCH;
	}
	else {
		gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll &= ~R_IN32D_CYCSTATUS_STATION_MISSMATCH;
	}

	return erRet;
}

/*** EOF ***/
