/**
 *******************************************************************************
 * @file  sflash.h
 * @brief Serial Flash ROM control header for R-IN32M4 @ MX25L6533F
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	SFLASH_H__
#define	SFLASH_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/* base address */
#define SFLASH_BASE_ADDRESS (0x02000000)	/**< Mapped base address of Serial Flash memory */

/* flash configuration */
/* MX25L6433F */
/* channel information */
#define SFLASH_CHANNEL_MAX  (1)				/**< Serial Flash ROM Channel count */
/* device information (ch 0) */
#define SFLASH_DEVICE_SIZE  (1 << 23)		/**< Serial Flash ROM Device size */
#define SFLASH_ERASE_SIZE   (1 << 16)		/**< Serial Flash ROM Erase size */
#define SFLASH_PROGRAM_SIZE (1 <<  8)		/**< Serial Flash ROM Program size */

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
ER_RET sflash_init(void);
ER_RET sflash_dual_init(void);
ER_RET sflash_quad_init(void);
ER_RET sflash_read(uint8_t* buf, uint32_t addr, uint32_t size);
ER_RET sflash_program(uint8_t* buf, uint32_t addr, uint32_t size);
ER_RET sflash_erase(uint32_t addr, uint32_t size);

#endif // SFLASH_H__
