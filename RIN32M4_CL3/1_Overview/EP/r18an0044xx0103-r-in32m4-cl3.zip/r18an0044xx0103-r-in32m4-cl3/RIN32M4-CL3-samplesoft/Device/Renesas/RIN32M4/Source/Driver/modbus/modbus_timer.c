/**
 *******************************************************************************
 * @file  modbus_timer.c
 * @brief Timer driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2014,2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "modbus/modbus_timer.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T R U C T                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
  @brief  timer initialise
          This function initializes the timer 
  @param  init_time -- Time in microsecond
  @param  ch        -- Timer channel
  @retval ER_OK     -- for success
  @retval ER_PARAM  -- for invalid timer parameter
 ******************************************************************************
*/
ER_RET timer_init_modbus(uint32_t init_time,
                         uint8_t ch)
{
	uint32_t	u32_i_count;								/* counter value */
	uint8_t		u8_irq_num;

	/** Check parameters */ 
	if (ch > MAX_TIMER_CHANNEL)
	{
		return ER_PARAM;
	}

	/* Set count clock */ 
	/* Set Prescaler */
	RIN_TMR->TAUJ2TPS &= ~(0xf << (4 * ch));				/* [4*m+3:4*m] clear bits (CKm: PCLK/2^0 = 100MHz) */
	/* Set Baud rate (CK3 only) */

	//=========================================
	// Set count value
	//=========================================
	{
		uint32_t *cdr_reg;

		/* set base pointer */
		cdr_reg = (uint32_t*)&RIN_TMR->TAUJ2CDR0;

		/* count value = ( interval time(ns) / count clock cycle(ns) - 1 ) */
		u32_i_count = ( init_time*(1000 / 10) - 1 );		/** microseconds */
		*(cdr_reg + ch) = u32_i_count;						/** [31:0] countdown start value */
	}
	/** Set Interval timer mode */
	{
		uint32_t *cmor_reg;
		uint32_t *cmur_reg;

		/* set base pointer */
		cmor_reg = (uint32_t*)&RIN_TMR->TAUJ2CMOR0;
		cmur_reg = (uint32_t*)&RIN_TMR->TAUJ2CMUR0;

		*(cmor_reg + ch) = ((ch << 14) |					/** [15:14] Prescaler output      : Select CKm */
							( 0 << 12) |					/** [13:12] Count clock           : Prescaler */ 
							( 0 << 11) |					/** [11]    Synchronous operation : (Not used) */
							( 0 <<  8) |					/** [10:8]  Start trigger         : Software trigger */
							( 0 <<  6) |					/** [7:6]   Capture overflow      : (Not used) */
							( 0 <<  1) |					/** [4:1]   Mode                  : Interval timer */
							( 0 <<  0));					/** [0]     Aux                   : Does not output INTn when count starts */
		*(cmur_reg + ch) = (( 0 <<  0));					/** [1:0]   Detect TINm edge      : (Not used) */
	}
	/** set timer output signal */
	RIN_TMR->TAUJ2TOE  |=  ( 1 << ch );						/** [m] TOEm (channel output enable)  : Enable */
	RIN_TMR->TAUJ2TO   &= ~( 1 << ch );						/** [m]  TOm (TOUTm pin output level) : Low level */
	RIN_TMR->TAUJ2TOM  &= ~( 1 << ch );						/** [m] TOMm (channel output mode)    : Independent */
	RIN_TMR->TAUJ2TOC  &= ~( 1 << ch );						/** [m] TOCm (channel output config)  : Performs toggle operation */
	RIN_TMR->TAUJ2TOL  &= ~( 1 << ch );						/** [m] TOLm (channel output level)   : Active high */

	//=========================================
	// Set reload data control
	//=========================================
	RIN_TMR->TAUJ2RDE  &= ~( 1 << ch );						/** [m] RDEm (reload data enable) : disable */
	RIN_TMR->TAUJ2RDM  &= ~( 1 << ch );						/** [m] RDMm (reload data mode)   : disable for simultaneous rewriting */

	/** Enable interrupt */
	u8_irq_num = (uint8_t)TAUJ2I0_IRQn + ch;
	NVIC_EnableIRQ((IRQn_Type)u8_irq_num);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Timer update 
          This function reloads the timer with a new interval value
  @param  update_time  -- Updates time in microsecond
  @param  ch           -- Timer channel
  @retval none
 ******************************************************************************
*/
void timer_update_modbus(uint32_t update_time,
                         uint8_t ch)
{
	uint32_t u32_count;									/** counter value */
	uint32_t *cdr_reg;

	/* set base pointer */
	cdr_reg   = (uint32_t*)&RIN_TMR->TAUJ2CDR0;
	u32_count = (update_time * (1000 / 10) - 1);

	*(cdr_reg + ch) = u32_count;						/** [31:0] countdown start value */
}

/**
 ******************************************************************************
  @brief  Timer count start
  @param  ch        -- channel number
  @retval ER_OK     -- No error
  @retval ER_PARAM  -- Parameter error
 ******************************************************************************
*/
ER_RET timer_start( uint8_t ch )
{
	/* Check parameter */
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	/* Timer count start */
	RIN_TMR->TAUJ2TS = (1 << ch);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Timer count stop
  @param  ch        -- channel number
  @retval ER_OK     -- No error
  @retval ER_PARAM  -- Parameter error
 ******************************************************************************
*/
ER_RET timer_stop( uint8_t ch )
{
	/* Check parameter */
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	/* Timer count stop */
	RIN_TMR->TAUJ2TT = (1 << ch);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Timer interrupt handler 
          This function is replaced default function.
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I0_IRQHandler(void)
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838469
}

/**
 ******************************************************************************
  @brief  Timer interrupt handler 
          This function is replaced default function.
  @param  none
  @retval none
 ******************************************************************************
*/
void TAUJ2I1_IRQHandler(void)
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838469
}


/* *************************** End of File ********************************** */

