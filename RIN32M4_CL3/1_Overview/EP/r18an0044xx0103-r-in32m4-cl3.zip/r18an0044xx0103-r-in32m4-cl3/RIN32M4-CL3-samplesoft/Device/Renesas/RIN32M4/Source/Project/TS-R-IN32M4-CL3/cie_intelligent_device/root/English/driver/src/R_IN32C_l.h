/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_l.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32C_L_H_INCLUDED__
#define __R_IN32C_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32U.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32C_2ND_BUFFER_NUM				R_IN32_TRANSIENT_BUFFER_NUM		
#define R_IN32C_2ND_BUFFER_SIZE			(1520)		

#define R_IN32C_INTERVAL_TIME				(50UL)							
#define R_IN32C_TMOUT_TDISENTRY			(R_IN32U_LINKSCANTIME_CONST * 3)	
#define R_IN32C_TIMEINFO_1S1000MSEC		(1000UL)						

#define	R_IN32C_EVT_START					4	
#define	R_IN32C_EVT_INTERRUPT				6	
#define	R_IN32C_EVT_SNDENTRYERR			7	

#define R_IN32C_SLVEVT_EVT_TICK			1	
#define R_IN32C_SLVEVT_EVT_MSTWDTTIMEOUT	2	

#define	R_IN32C_SLVEVT_STS_IDLE			0	
#define	R_IN32C_SLVEVT_STS_WAITSND			1	

#define R_IN32C_PORT_EVT_TICK		1

#define R_IN32C_PORT_STS_LINKDOWN			1	
#define R_IN32C_PORT_STS_LINKUP			2	

#define R_IN32C_EMGDBG_SELF_WDT		(USHORT)ASIC_BIT0	
#define R_IN32C_EMGDBG_WDTCNT			(USHORT)ASIC_BIT0	
#define R_IN32C_EMGDBG_WDTRST			(USHORT)ASIC_BIT0	

#define R_IN32C_CYCLIC_SETSTA_ENABLE_MASK		(USHORT)0xD6FF		

#define R_IN32C_CYCLIC_GETSTA_PARAMCOND_MASK	(USHORT)0x000F		

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32C_TDIS_RES_TAG {
	BOOL  blValid;
	UCHAR uchNum;
	ULONG ulSts;
} R_IN32C_TDIS_RES_T;

typedef struct _R_IN32C_2ND_BUFFER_TAG {
	BOOL blValid;
	ULONG    ulLen;
	UCHAR    auchData[R_IN32C_2ND_BUFFER_SIZE];
} R_IN32C_2ND_BUFFER_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
extern R_IN32C_T				gstR_IN32C;
extern R_IN32C_2ND_BUFFER_T	gastR_IN32C_RcvBuf[R_IN32C_2ND_BUFFER_NUM];
extern ULONG				gulR_IN32C_RcvBufWIdx;
extern ULONG				gulR_IN32C_RcvBufRIdx;


/****************************************************************************/
/* Functions (for R_IN32C)                                                     */
/****************************************************************************/

extern ERRCODE erR_IN32C_InitLocal(VOID);
extern ERRCODE erR_IN32C_InitLocalMain(VOID);
extern ERRCODE erR_IN32C_InitLocalInf0(VOID);
extern ERRCODE erR_IN32C_InitLocalInf1(VOID);
extern ERRCODE erR_IN32C_InitLocalCyclic(VOID);
extern ERRCODE erR_IN32C_InitLocalSlvEvt(VOID);
extern ERRCODE erR_IN32C_InitLocalPort(VOID);
extern ERRCODE erR_IN32C_InitLocalMIB(VOID);
extern ERRCODE erR_IN32C_InitLocalMACAddrTbl(VOID);
extern ERRCODE erR_IN32C_InitLocal2ndBuf(VOID);
extern ERRCODE erR_IN32C_InitLocalMotSyncCtl(VOID);
extern ERRCODE erR_IN32C_UpdateLocal(const R_IN32_UNITINFO_T *, const R_IN32_UNITINIT_T *);

extern ERRCODE erR_IN32C_SeqMain(const R_IN32_EVTPRM_INTERRUPT_T*);
extern ERRCODE erR_IN32C_SeqMainWaitStart(ULONG);
extern ERRCODE erR_IN32C_SeqMainCommon(ULONG, ULONG);
extern ERRCODE erR_IN32C_SeqMain_Intr(ULONG);
extern ERRCODE erR_IN32C_SeqMain_Connect(VOID);
extern ERRCODE erR_IN32C_SeqMain_Disconnect(VOID);
extern ERRCODE erR_IN32C_SeqMain_RcvFinish(VOID);
extern ERRCODE erR_IN32C_SeqMain_SndFinish(VOID);
extern ERRCODE erR_IN32C_SeqMain_TimeInterval(VOID);
extern ERRCODE erR_IN32C_SeqMain_MasterWatchTimeout(VOID);
extern ERRCODE erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU(VOID);
extern ERRCODE erR_IN32C_RcvBuf(VOID);
extern ERRCODE erR_IN32C_GetRcvTran2(ULONG*,VOID**);
extern ERRCODE erR_IN32C_SetRcvTranFin2(VOID);
extern ERRCODE erR_IN32C_ChangeSyncStatusToReady(VOID);
extern ERRCODE erR_IN32C_CheckSyncFrmTmgErr(R_IN32D_MSTMYSTATUS_INFO_T*);
extern ERRCODE erR_IN32C_SeqMain_SyncCommExec(VOID);
extern ERRCODE erR_IN32C_RequestSyncOffCheck(VOID);
extern ERRCODE erR_IN32C_CancelSyncOffCheck(VOID);
extern ERRCODE erR_IN32C_CancelSyncOffCheckForNonRecv(VOID);
extern ERRCODE erR_IN32C_CheckSyncFrameErr(VOID);
extern ERRCODE erR_IN32C_CountSyncOn(VOID);
extern ERRCODE erR_IN32C_CountSyncOff(VOID);

extern ERRCODE erR_IN32C_R_IN32DInit_DisableInt(const UCHAR *, ULONG *);
extern ERRCODE erR_IN32C_MacIp_AccessEnable_DisableInt(VOID);
extern ERRCODE erR_IN32C_GetTranTDIS_DisableInt(USHORT, VOID **,UCHAR *);
extern ERRCODE erR_IN32C_EntryTranTDIS_DisableInt(UCHAR, USHORT);
extern ERRCODE erR_IN32C_GetTranSndSts_DisableInt(R_IN32C_TDIS_RES_T *);
extern ERRCODE erR_IN32C_StartRing_DisableInt(VOID);
extern ERRCODE erR_IN32C_GetNetworkTime_DisableInt(USHORT *, USHORT *, USHORT *);
extern ERRCODE erR_IN32C_SetNetworkTime_DisableInt(USHORT,USHORT,USHORT);
extern ERRCODE erR_IN32C_GetRcvTran_DisableInt(ULONG*,VOID**);
extern ERRCODE erR_IN32C_SetRcvTranFin_DisableInt(VOID);


extern ERRCODE erR_IN32C_SetMIB(VOID);

extern ERRCODE erR_IN32C_IndStationNumberChanged(UCHAR, USHORT);
extern ERRCODE erR_IN32C_IndActCmdChanged(R_IN32C_PRMCMD_T);
extern ERRCODE erR_IN32C_IndRcvFrameToNCYC(ULONG, VOID *);
extern ERRCODE erR_IN32C_IndSndFin(UCHAR, ULONG);

extern VOID    R_IN32C_SeqCyclic(R_IN32D_CYCLIC_STA_GET_T);
extern ERRCODE erR_IN32C_ReqCyclicSndStop(VOID);

extern VOID    R_IN32C_SeqPort(ULONG, ULONG);
extern ERRCODE erR_IN32C_SeqPort_Update(R_IN32C_PORT_T *);
extern ERRCODE erR_IN32C_CheckPHY(VOID);
extern ERRCODE erR_IN32C_WritePHY(	ULONG, ULONG, ULONG );
extern ERRCODE erR_IN32C_ReadPHY(ULONG, ULONG, ULONG* );



#endif /*__R_IN32C_H_L_INCLUDED__ */

/*** EOF ***/
