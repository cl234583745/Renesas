/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32U_Init.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

ULONG	gulR_IN32U_MAX_RX_SIZE;		
ULONG	gulR_IN32U_MAX_RY_SIZE;		
ULONG	gulR_IN32U_MAX_RWW_WSIZE;		
ULONG	gulR_IN32U_MAX_RWR_WSIZE;		
ULONG	gulR_IN32U_MAX_RWW_SIZE;		
ULONG	gulR_IN32U_MAX_RWR_SIZE;		
ULONG	gulR_IN32U_MIN_RX_SIZE;		
ULONG	gulR_IN32U_MIN_RY_SIZE;		
ULONG	gulR_IN32U_MIN_RWW_WSIZE;	
ULONG	gulR_IN32U_MIN_RWR_WSIZE;	
ULONG	gulR_IN32U_MIN_RWW_SIZE;	
ULONG	gulR_IN32U_MIN_RWR_SIZE;	

ULONG	gulR_IN32U_STATION_CLASS;				
ULONG	gulR_IN32U_STATION_CLASS_UNIT;			
ULONG	gulR_IN32U_STATION_CLASS_EQUIPMENT;	

ULONG	gulR_IN32U_MAX_PORT_NUMBER;
ULONG	gulR_IN32U_TOKEN_HOLD_TIME;

ULONG	gulR_IN32U_STINF_IOTYPE;

ULONG	gulR_IN32U_STATION_MODE;

ULONG	gulR_IN32U_UNIT_VERSION;
ULONG	gulR_IN32U_UNIT_MODEL_TYPE;
ULONG	gulR_IN32U_UNIT_MODEL_CODE;
ULONG	gulR_IN32U_UNIT_VENDOR_CODE;
USHORT	gusR_IN32U_UNIT_HW_VERSION;
USHORT	gusR_IN32U_UNIT_DEVICE_VERSION;

ULONG	gulR_IN32U_MACDELIV_TYPE;

ULONG	gulR_IN32U_NCYCRCV_VALID;
ULONG	gulR_IN32U_TRANRCV_MODE;
ULONG	gulR_IN32U_SELFSTA_TRANRCV;

ULONG	gulR_IN32U_SYNC_FUNCTION1;		
ULONG	gulR_IN32U_DEVICE_SET_STATUS;	
ULONG	gulR_IN32U_DEVICE_INIT;			
ULONG	gulR_IN32U_SYNC_FUNCTION2;		
ULONG	gulR_IN32U_SYNC_SET_FOLLOWUP;	
ULONG	gulR_IN32U_SYNC_FUNCTION3;		
ULONG	gulR_IN32U_SYNC_SUPPORTED_MODE;	

ULONG	gulR_IN32U_FAILEDPROCESS1;		
ULONG	gulR_IN32U_FAILEDPROCESS2;		

ULONG	gulR_IN32U_SELFSTA_CPURUN;			
ULONG	gulR_IN32U_SELFSTA_CPUERRFOUND;	
ULONG	gulR_IN32U_ERRCODE;				
ULONG	gulR_IN32U_USER_INFORMATION;		

ULONG	gulR_IN32U_OPTION_SUPPORT;

ULONG	gulR_IN32U_SLMP_SUPPORT;

ULONG	gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT;

R_IN32_PHY_SETTING_T	gstPHYSetting[2];

R_IN32U_T	gstR_IN32U;

ERRCODE gerR_IN32U_Init( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gulR_IN32U_MAX_RX_SIZE   = (ULONG)R_IN32U_MAX_RX_SIZE;		
	gulR_IN32U_MAX_RY_SIZE   = (ULONG)R_IN32U_MAX_RY_SIZE;		
	gulR_IN32U_MAX_RWW_WSIZE = (ULONG)R_IN32U_MAX_RWW_WSIZE;		
	gulR_IN32U_MAX_RWR_WSIZE = (ULONG)R_IN32U_MAX_RWR_WSIZE;		
	gulR_IN32U_MAX_RWW_SIZE  = (gulR_IN32U_MAX_RWW_WSIZE << 1);	
	gulR_IN32U_MAX_RWR_SIZE  = (gulR_IN32U_MAX_RWR_WSIZE << 1);	
	gulR_IN32U_MIN_RX_SIZE   = (ULONG)R_IN32U_MIN_RX_SIZE;		
	gulR_IN32U_MIN_RY_SIZE   = (ULONG)R_IN32U_MIN_RY_SIZE;		
	gulR_IN32U_MIN_RWW_WSIZE = (ULONG)R_IN32U_MIN_RWW_WSIZE;		
	gulR_IN32U_MIN_RWR_WSIZE = (ULONG)R_IN32U_MIN_RWR_WSIZE;		
	gulR_IN32U_MIN_RWW_SIZE  = (gulR_IN32U_MIN_RWW_WSIZE << 1);	
	gulR_IN32U_MIN_RWR_SIZE  = (gulR_IN32U_MIN_RWR_WSIZE << 1);	

	gulR_IN32U_STATION_CLASS           = (ULONG)R_IN32U_STATION_CLASS;
	gulR_IN32U_STATION_CLASS_UNIT      = (ULONG)R_IN32U_STATION_CLASS_UNIT;
	gulR_IN32U_STATION_CLASS_EQUIPMENT = (ULONG)R_IN32U_STATION_CLASS_EQUIPMENT;

	gulR_IN32U_MAX_PORT_NUMBER = (ULONG)R_IN32U_MAX_PORT_NUMBER;
	gulR_IN32U_TOKEN_HOLD_TIME = (ULONG)R_IN32U_TOKEN_HOLD_TIME;

	gulR_IN32U_STINF_IOTYPE = (ULONG)R_IN32U_STINF_IOTYPE;

	gulR_IN32U_STATION_MODE = (ULONG)R_IN32_OFF;

	gulR_IN32U_UNIT_VERSION     = (ULONG)R_IN32U_UNIT_VERSION;
	gulR_IN32U_UNIT_MODEL_TYPE  = (ULONG)R_IN32U_UNIT_MODEL_TYPE;
	gulR_IN32U_UNIT_MODEL_CODE  = (ULONG)R_IN32U_UNIT_MODEL_CODE;
	gulR_IN32U_UNIT_VENDOR_CODE = (ULONG)R_IN32U_UNIT_VENDOR_CODE;
	gusR_IN32U_UNIT_HW_VERSION  = (ULONG)R_IN32U_UNIT_HW_VERSION;
	gusR_IN32U_UNIT_DEVICE_VERSION = (ULONG)R_IN32U_UNIT_DEVICE_VERSION;
	__BUS_RELEASE();

	gulR_IN32U_MACDELIV_TYPE = (ULONG)R_IN32U_MACDELIV_TYPE;

	gulR_IN32U_FAILEDPROCESS1 = (ULONG)R_IN32_ON;
	gulR_IN32U_FAILEDPROCESS2 = (ULONG)R_IN32_ON;

	gstR_IN32U.blNMIUse = R_IN32_FALSE;

	gstR_IN32U.blInterruptUse = R_IN32_FALSE;
	__BUS_RELEASE();

	gstR_IN32U.blTransientReceiveEnable = R_IN32_TRUE;
	gulR_IN32U_NCYCRCV_VALID   = (ULONG)R_IN32_ON;
	gulR_IN32U_TRANRCV_MODE    = (ULONG)R_IN32_ON;
	gulR_IN32U_SELFSTA_TRANRCV = (ULONG)R_IN32_ON;

	gulR_IN32U_SELFSTA_CPURUN      = (ULONG)R_IN32U_SELFSTA_CPURUN;
	gulR_IN32U_SELFSTA_CPUERRFOUND = (ULONG)R_IN32U_SELFSTA_CPUERRFOUND;
	__BUS_RELEASE();
	gulR_IN32U_ERRCODE             = (ULONG)R_IN32U_ERRCODE;
	gulR_IN32U_USER_INFORMATION    = (ULONG)R_IN32U_USER_INFORMATION;

	gulR_IN32U_OPTION_SUPPORT		= (ULONG)R_IN32U_OPTION_SUPPORT;

	gulR_IN32U_SLMP_SUPPORT		= (ULONG)R_IN32U_SLMP_SUPPORT;

	gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT	= (ULONG)R_IN32U_SLMP_DIAGNOSIS_SUPPORT;

	gstR_IN32U.blSynchronousInterruptUse = R_IN32_FALSE;
	__BUS_RELEASE();

	gulR_IN32U_SYNC_FUNCTION1    = (ULONG)R_IN32_OFF;
	gulR_IN32U_DEVICE_SET_STATUS = (ULONG)R_IN32_OFF;
	gulR_IN32U_DEVICE_INIT       = (ULONG)R_IN32_OFF;
	gulR_IN32U_SYNC_FUNCTION2    = (ULONG)R_IN32_OFF;
	gulR_IN32U_SYNC_SET_FOLLOWUP = (ULONG)R_IN32_OFF;
	gulR_IN32U_SYNC_FUNCTION3    = (ULONG)R_IN32_OFF;
	gulR_IN32U_SYNC_SUPPORTED_MODE = (ULONG)R_IN32U_SYNC_SUPPORTED_MODE;

	return erRet;
}

ERRCODE gerR_IN32U_Update(
	const R_IN32_UNITINFO_T* pstUnitInfo, 		
	const R_IN32_UNITINIT_T* pstUnitInit		
)
{
	ERRCODE erRet = R_IN32_OK;

	gulR_IN32U_MAX_RX_SIZE   = pstUnitInfo->ulMaxRxSize;		
	gulR_IN32U_MAX_RY_SIZE   = pstUnitInfo->ulMaxRySize;		
	gulR_IN32U_MAX_RWW_WSIZE = pstUnitInfo->ulMaxRWwSize;		
	gulR_IN32U_MAX_RWR_WSIZE = pstUnitInfo->ulMaxRWrSize;		
	gulR_IN32U_MAX_RWW_SIZE  = (gulR_IN32U_MAX_RWW_WSIZE << 1);	
	gulR_IN32U_MAX_RWR_SIZE  = (gulR_IN32U_MAX_RWR_WSIZE << 1);	

	gulR_IN32U_STATION_CLASS = (pstUnitInit->ulNodeType & 0xFFUL);	
	gulR_IN32U_STATION_CLASS_UNIT      = (gulR_IN32U_STATION_CLASS & 0x0FUL);		
	gulR_IN32U_STATION_CLASS_EQUIPMENT = (gulR_IN32U_STATION_CLASS >> 4);			

	gulR_IN32U_MAX_PORT_NUMBER = pstUnitInfo->ulMyStationPortTotalNumber;	
	gulR_IN32U_TOKEN_HOLD_TIME = pstUnitInfo->ulTokenHoldTime;				

	gulR_IN32U_STINF_IOTYPE = pstUnitInfo->ulIOType;	
	__BUS_RELEASE();


	gulR_IN32U_UNIT_VERSION     = pstUnitInfo->ulNetVersion;		
	gulR_IN32U_UNIT_MODEL_TYPE  = pstUnitInfo->ulNetModelType;		
	gulR_IN32U_UNIT_MODEL_CODE  = pstUnitInfo->ulNetUnitModelCode;	
	gulR_IN32U_UNIT_VENDOR_CODE = pstUnitInfo->ulNetVendorCode;	
	__BUS_RELEASE();
	gusR_IN32U_UNIT_HW_VERSION  = pstUnitInfo->usHwVersion;		
	gusR_IN32U_UNIT_DEVICE_VERSION = pstUnitInfo->usDeviceVersion;	
	if ( R_IN32_TRUE == pstUnitInit->blMACAddressTableRequest ) {
		gulR_IN32U_MACDELIV_TYPE = (ULONG)R_IN32_ON;
	}
	else {
		gulR_IN32U_MACDELIV_TYPE = (ULONG)R_IN32_OFF;
	}

	if ( R_IN32_TRUE == pstUnitInit->blFailedProcess1 ) {
		gulR_IN32U_FAILEDPROCESS1 = (ULONG)R_IN32_ON;
	}
	else {
		gulR_IN32U_FAILEDPROCESS1 = (ULONG)R_IN32_OFF;
	}

	if ( R_IN32_TRUE == pstUnitInit->blFailedProcess2 ) {
		gulR_IN32U_FAILEDPROCESS2 = (ULONG)R_IN32_ON;
	}
	else {
		gulR_IN32U_FAILEDPROCESS2 = (ULONG)R_IN32_OFF;
	}


	gstR_IN32U.blNMIUse = pstUnitInit->blNMIUse;

	gstR_IN32U.blInterruptUse = pstUnitInit->blInterruptUse;
	__BUS_RELEASE();

	gstR_IN32U.blTransientReceiveEnable = pstUnitInit->blTransientReceiveEnable;
	if ( R_IN32_TRUE == pstUnitInit->blTransientReceiveEnable ) {

		gulR_IN32U_NCYCRCV_VALID   = (ULONG)R_IN32_ON;
		gulR_IN32U_TRANRCV_MODE    = (ULONG)R_IN32_ON;
		gulR_IN32U_SELFSTA_TRANRCV = (ULONG)R_IN32_ON;
	}
	else {
		gulR_IN32U_NCYCRCV_VALID   = (ULONG)R_IN32_OFF;
		gulR_IN32U_TRANRCV_MODE    = (ULONG)R_IN32_OFF;
		gulR_IN32U_SELFSTA_TRANRCV = (ULONG)R_IN32_OFF;
	}

	gulR_IN32U_SELFSTA_CPURUN      = pstUnitInit->ulRunStatus;
	gulR_IN32U_SELFSTA_CPUERRFOUND = pstUnitInit->ulErrorStatus;
	__BUS_RELEASE();
	gulR_IN32U_USER_INFORMATION    = pstUnitInit->ulUserInformation;

	gulR_IN32U_OPTION_SUPPORT		= pstUnitInit->ulOptionSupport;

	gulR_IN32U_SLMP_SUPPORT		= pstUnitInit->ulSlmpSupport;
	__BUS_RELEASE();

	gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT	= pstUnitInit->ulSlmpDiagnosisSupport;

	gstPHYSetting[R_IN32_PORT1].ulMDI = pstUnitInit->stPHYSetting[R_IN32_PORT1].ulMDI;
	gstPHYSetting[R_IN32_PORT1].ulClk = pstUnitInit->stPHYSetting[R_IN32_PORT1].ulClk;
	gstPHYSetting[R_IN32_PORT2].ulMDI = pstUnitInit->stPHYSetting[R_IN32_PORT2].ulMDI;
	gstPHYSetting[R_IN32_PORT2].ulClk = pstUnitInit->stPHYSetting[R_IN32_PORT2].ulClk;


	return erRet;
}

/*** EOF ***/
