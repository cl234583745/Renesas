/***************************************************************************
    MICRO C CUBE / COMPACT, NETWORK
    Protocol headers, internal structure & macro definitions
    Copyright (c)  2008-2020, eForce Co., Ltd. All rights reserved.

    Version Information  2016.4.28: Created
                         2017.02.01: Support 64bit processor
                         2017.10.06: Added ARP_API_SUP definition
                         2021.06.01: Added TTS_DMT and ref_tst()
 **************************************************************************/

#ifndef NETHWOS_H
#define NETHWOS_H
#ifdef __cplusplus
extern "C" {
#endif

#ifndef NET_HW_OS
#define NET_HW_OS       /* Using H/W RTOS */
#endif

#ifndef EXT_ALOC_SUP
#define EXT_ALOC_SUP
#endif

#ifndef ARP_API_SUP
#define ARP_API_SUP
#endif

typedef unsigned long ADDR;

extern char *unet3_get_version(unsigned char mode);
extern char *unet3bsd_get_version(unsigned char mode);

#ifdef POSIX_API_SUP
   #define unet3_get_version unet3bsd_get_version
   #define UNET3_VERSION  "3.2.7"
#else
   #define UNET3_VERSION  "3.2.7"
#endif

typedef struct t_rcfg {
    UH          tick;
    UH          tskpri_max;
    UH          id_max;
} T_RCFG;

typedef struct t_cmpf {
    UINT        blkcnt;
    UINT        blksz;
    VP          mpf;
} T_CMPF;

extern ER net_act_tsk(ID tskid);
extern ER net_ref_cfg(T_RCFG *pk_rcfg);
extern ER net_get_mpf(ID mpfid, VP *p_blk);
extern ER net_tget_mpf(ID mpfid, VP *p_blk, TMO tmout);
extern ER net_rel_mpf(ID mpfid, VP p_blk);
#define dly_tsk(x) tslp_tsk((x)+1)
#define act_tsk(a) net_act_tsk((a))
#define ref_cfg(a) net_ref_cfg((a))
#define get_mpf(a,b) net_get_mpf((a),(b))
#define tget_mpf(a,b,c) net_tget_mpf((a),(b),(c))
#define rel_mpf(a,b) net_rel_mpf((a),(b))
#define TTS_DMT  0
#define ref_tst(a, b) ((b)->tskstat = !(TTS_DMT))   /* never be dormant */
#define T_RTST struct {UB tskstat;}

#ifdef __cplusplus
}
#endif
#endif /* NETHWOS_H */
