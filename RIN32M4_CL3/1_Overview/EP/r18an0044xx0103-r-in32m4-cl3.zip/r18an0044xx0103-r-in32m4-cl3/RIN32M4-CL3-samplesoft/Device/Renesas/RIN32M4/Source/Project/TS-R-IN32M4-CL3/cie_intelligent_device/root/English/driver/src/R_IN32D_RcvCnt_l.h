/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	 */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_RcvCnt_l.h                                                */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_RCVCNT_L_H_INCLUDED__
#define __R_IN32D_RCVCNT_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32D_SETUP_RCV_TAG {
	ULONG					aulMultiCastAdrs[2];	
	union _SETUP_INF_REG0 {
		ULONG			ulData;
	SETUP_INF_REG0_T		stSetup_Inf0;			
	} SETUP_INF_REG0;
	SETUP_INF_REG3_T		stSetup_Inf3;			
	union _SETUP_INF_REG4 {
		ULONG			ulData;
	SETUP_INF_REG4_T		stSetup_Inf4;			
	} SETUP_INF_REG4;
} R_IN32D_SETUP_RCV_T;


/****************************************************************************/
/* Functions (for R_IN32D)                                                     */
/****************************************************************************/
extern ERRCODE erR_IN32D_FetchSetupRcv( VOID );

#endif	/* __R_IN32D_RCVCNT_L_H_INCLUDED__ */

/*** EOF ***/
