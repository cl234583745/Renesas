/**
 *******************************************************************************
 * @file  timer.c
 * @brief 32-bit Timer (TAUJ2) driver program
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "timer/timer.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define MAX_TIMER_CHANNEL	(3)				/* Max timer channel number */

#define SYS_TIMER_CHANNEL	(0)				/* System timer channel */
#define SYS_TIMER_DIVIDE	(3)				/* System timer freqency divided by 2^n */

#define MAX_INTERVAL_TIME	(42949UL)		/* Max interval time (ms) */
#define MIN_INTERVAL_TIME	(1UL)			/* Min interval time (ms) */

#define MAX_ONECNT_HW_TIME	(42949672UL)	/* Max one count time (us) */
#define MIN_ONECNT_HW_TIME	(1UL)			/* Min one count time (us) */

/*===========================================================================*/
/* S T R U C T                                                               */
/*===========================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static ER_RET timer_cntcap_init( uint8_t ch );
//static ER_RET set_port_tout( uint8_t ch );
//static ER_RET set_port_tin( uint8_t ch );

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  Initialize clock
  @param  none
  @retval none
 ******************************************************************************
*/
void clock_init( void )
{
	// --- Setup system timer ---
	timer_cntcap_init( SYS_TIMER_CHANNEL );
	timer_start( SYS_TIMER_CHANNEL );
}

/**
 ******************************************************************************
  @brief  Initialize interval timer
  @param  ch		: channel number
  @param  i_time	: interval time (ms)
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
ER_RET timer_interval_init( uint8_t ch,uint32_t i_time )
{
	uint32_t i_count;						// counter value
	uint8_t irq_num;

	//=========================================
	// Check parameter s
	//=========================================
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	if ((i_time < MIN_INTERVAL_TIME) || (MAX_INTERVAL_TIME < i_time)) {
		return ER_PARAM;
	}

	//=========================================
	// Set count clock
	//=========================================
	/* Set Prescaler */
	RIN_TMR->TAUJ2TPS &= ~(0xf << (4*ch));		// [4*m+3:4*m] clear bits (CKm: PCLK/2^0 = 100MHz)
	/* Set Baud rate (CK3 only) */
//	RIN_TMR->TAUJ2BRS = 0x00000000;				// [7:0] Baud rate for CK3

	//=========================================
	// Set count value
	//=========================================
	{
		uint32_t *cdr_reg;

		/* set base pointer */
		cdr_reg = (uint32_t*)&RIN_TMR->TAUJ2CDR0;

		// count value = ( interval time(ns) / count clock cycle(ns) - 1 )
		i_count = ( i_time*(1000000 / 10) - 1 );
		*(cdr_reg + ch) = i_count;				// [31:0] countdown start value
	}
	//=========================================
	// Set Interval timer mode
	//=========================================
	{
		uint32_t *cmor_reg;
		uint32_t *cmur_reg;

		/* set base pointer */
		cmor_reg = (uint32_t*)&RIN_TMR->TAUJ2CMOR0;
		cmur_reg = (uint32_t*)&RIN_TMR->TAUJ2CMUR0;

		*(cmor_reg + ch) = ((ch << 14) |		// [15:14] Prescaler output      : Select CKm
						    ( 0 << 12) |		// [13:12] Count clock           : Prescaler
						    ( 0 << 11) |		// [11]    Synchronous operation : (Not used)
						    ( 0 <<  8) |		// [10:8]  Start trigger         : Software trigger
						    ( 0 <<  6) |		// [7:6]   Capture overflow      : (Not used)
						    ( 0 <<  1) |		// [4:1]   Mode                  : Interval timer
						    ( 0 <<  0));		// [0]     Aux                   : Does not output INTn when count starts
		*(cmur_reg + ch) = (( 0 <<  0));		// [1:0]   Detect TINm edge      : (Not used)
	}
	//=========================================
	// Set timer output signal
	//=========================================
	RIN_TMR->TAUJ2TOE  |=  ( 1 << ch );			// [m] TOEm (channel output enable)  : Enable
	RIN_TMR->TAUJ2TO   &= ~( 1 << ch );			// [m]  TOm (TOUTm pin output level) : Low level
	RIN_TMR->TAUJ2TOM  &= ~( 1 << ch );			// [m] TOMm (channel output mode)    : Independent
	RIN_TMR->TAUJ2TOC  &= ~( 1 << ch );			// [m] TOCm (channel output config)  : Performs toggle operation
	RIN_TMR->TAUJ2TOL  &= ~( 1 << ch );			// [m] TOLm (channel output level)   : Active high

	//=========================================
	// Set reload data control
	//=========================================
	RIN_TMR->TAUJ2RDE  &= ~( 1 << ch );			// [m] RDEm (reload data enable) : disable
	RIN_TMR->TAUJ2RDM  &= ~( 1 << ch );			// [m] RDMm (reload data mode)   : disable for simultaneous rewriting

	//=========================================
	// Enable interrupt
	//=========================================
	irq_num = (uint8_t)TAUJ2I0_IRQn + ch;
//	NVIC_SetPriority((IRQn_Type)irq_num, 1);
	NVIC_EnableIRQ((IRQn_Type)irq_num);

	//=========================================
	// Set TOUTn port (if you use)
	//=========================================
//	set_port_tout(ch);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Initialize one count timer( delay count function controlled by hardware)
  @param  ch		: channel number
  @param  o_time	: one count time (ns)
  @param  trg		: timer count start trigger
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
ER_RET timer_onecount_hwtrg_init( uint8_t ch, uint32_t o_time, uint32_t trg )
{
	uint32_t o_count;			// one_count time
	uint8_t irq_num;

	//=========================================
	// Check parameter 
	//=========================================
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	// a permissible range of one count time : 1us~42949672us
	if ((o_time < MIN_ONECNT_HW_TIME) || (MAX_ONECNT_HW_TIME < o_time)) {
		return ER_PARAM;
	}

	//=========================================
	// Set count clock
	//=========================================
	/* Set Prescaler */
	RIN_TMR->TAUJ2TPS &= ~( 0xf << (4*ch)) | ( 0x0 << (4*ch));
	/* Set Baud rate (CK3 only) */
//	RIN_TMR->TAUJ2BRS = 0x00000000;				// [7:0] Baud rate for CK3

	/* Set CNTn loaded value */
	// count value = ((one_count time(ns))/(count clock cycle(ns)) - 1)
	// min                10ns       ,   100MHz(10ns)   ->   count value : 0x00000001
	// Max count value : 0xFFFFFFFF(4,294,967,295)      ->   42,949,672.95us
	// Max 42949672us = 42,949,672,000ns, 100MHz(10ns)  ->   count value : 0xFFFFFFA0
	o_count = ((o_time*(1000/10)) - 1);

	switch(ch)
	{
		case 0:
			RIN_TMR->TAUJ2CDR0 = o_count;		// ch0 countdown start value
			break;
		case 1:
			RIN_TMR->TAUJ2CDR1 = o_count;		// ch1 countdown start value
			break;
		case 2:
			RIN_TMR->TAUJ2CDR2 = o_count;		// ch2 countdown start value
			break;
		case 3:
			RIN_TMR->TAUJ2CDR3 = o_count;		// ch3 countdown start value
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Set One count timer mode
	//=========================================
	{
		uint32_t *cmor_reg;
		uint32_t *cmur_reg;

		/* set base pointer */
		cmor_reg = (uint32_t*)&RIN_TMR->TAUJ2CMOR0;
		cmur_reg = (uint32_t*)&RIN_TMR->TAUJ2CMUR0;

		*(cmor_reg + ch) = ((ch << 14) |		// [15:14] Prescaler output      : Select CKm
							( 0 << 12) |		// [13:12] Count clock           : Prescaler
							( 0 << 11) |		// [11]    Synchronous operation : Slave
							( 1 <<  8) |		// [10:8]  Start trigger         : Software & TINn
							( 0 <<  6) |		// [7:6]   Capture overflow      : Not used,so set to 00B
							( 4 <<  1) |		// [4:1]   Mode                  : One count
							( 0 <<  0));		// [0]     Aux                   : Disable start trigger during count douwn
		*(cmur_reg + ch) = (( 1 <<  0));		// [1:0]   Detect TINm edge      : Rise edge
	}

	//=========================================
	// Set timer output signal
	//=========================================
	RIN_TMR->TAUJ2TOE  &= ~( 1 << ch );			// [m] TOEm (channel output enable)  : Disable
	RIN_TMR->TAUJ2TO   &= ~( 1 << ch );			// [m]  TOm (TOUTm pin output level) : Low level
	RIN_TMR->TAUJ2TOM  &= ~( 1 << ch );			// [m] TOMm (channel output mode)    : Independent
	RIN_TMR->TAUJ2TOC  &= ~( 1 << ch );			// [m] TOCm (channel output config)  : Performs toggle operation
	RIN_TMR->TAUJ2TOL  &= ~( 1 << ch );			// [m] TOLm (channel output level)   : Active high

	//=========================================
	// Set reload data control
	//=========================================
	// Not used in this mode
	RIN_TMR->TAUJ2RDE  &= ~( 1 << ch );			// [m] RDEm (reload data enable) : (Must be 0)
	RIN_TMR->TAUJ2RDM  &= ~( 1 << ch );			// [m] RDMm (reload data mode)   : (Must be 0)

	//=========================================
	// Enable interrupt
	//=========================================
	irq_num = (uint8_t)TAUJ2I0_IRQn + ch;
//	NVIC_SetPriority((IRQn_Type)irq_num, 1);
	NVIC_EnableIRQ((IRQn_Type)irq_num);

	//=========================================
	// Set TINm port (if you use)
	//=========================================
//	set_port_tin(ch);

	// Unlock system register
	RIN_SYS->SYSPCMD = 0x00a5;
	RIN_SYS->SYSPCMD = 0x0001;
	RIN_SYS->SYSPCMD = 0xfffe;
	RIN_SYS->SYSPCMD = 0x0001;

	// Use interrupt signal for timer trigger
	RIN_SYS->SELCNT |= (1 << (ch*2));
	switch(ch)
	{
		case 0:
			RIN_SYS->TMTFR0  = trg;
			break;
		case 1:
			RIN_SYS->TMTFR1  = trg;
			break;
		case 2:
			RIN_SYS->TMTFR2  = trg;
			break;
		case 3:
			RIN_SYS->TMTFR3  = trg;
			break;
		default:
			return ER_PARAM;
	}
	// Lock system register
	RIN_SYS->SYSPCMD = 0x0000;

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Timer count start
  @param  ch		: channel number
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
ER_RET timer_start( uint8_t ch )
{
	/* Check parameter */
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	/* Timer count start */
	RIN_TMR->TAUJ2TS = (1 << ch);
	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Timer count stop
  @param  ch		: channel number
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
ER_RET timer_stop( uint8_t ch )
{
	/* Check parameter */
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	/* Timer count stop */
	RIN_TMR->TAUJ2TT = (1 << ch);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Check timer activation
  @param  ch		: channel number
  @retval 0			: Not active
  @retval 1			: Active
 ******************************************************************************
*/

ER_RET timer_check_act(uint8_t ch)
{
	/* Check parameter */
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	/* Read count operation status */
	if((RIN_TMR->TAUJ2TE & (1 <<  ch)) == (1 << ch))
	{
		/* count operation is enabled */
		return 1;
	}
	else
	{
		/* count operation is disabled */
		return 0;
	}
}

/**
 ******************************************************************************
  @brief  Initialize count capture timer (used as free-run timer)
  @param  ch		: Channel number
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
static ER_RET timer_cntcap_init( uint8_t ch )
{
	//=========================================
	// Check parameter 
	//=========================================
	if (ch > MAX_TIMER_CHANNEL) {
		return ER_PARAM;
	}

	//=========================================
	// Set count clock
	//=========================================
	/* Set Prescaler */
	RIN_TMR->TAUJ2TPS &= ~(             0xf << (4*ch));		// [4*m+3:4*m] clear bits (CKm: PCLK/2^0)
	RIN_TMR->TAUJ2TPS |=  (SYS_TIMER_DIVIDE << (4*ch));		// [4*m+3:4*m] set bits   (CKm: PCLK/2^3)
	/* Set Baud rate (CK3 only) */
//	RIN_TMR->TAUJ2BRS = 0x00000000;				// [7:0] Baud rate for CK3

	//=========================================
	// Set timer mode
	//=========================================
	{
		uint32_t *cmor_reg;
		uint32_t *cmur_reg;

		/* set base pointer */
		cmor_reg = (uint32_t*)&RIN_TMR->TAUJ2CMOR0;
		cmur_reg = (uint32_t*)&RIN_TMR->TAUJ2CMUR0;

		*(cmor_reg + ch) = ((ch << 14) |		// [15:14] Prescaler output      : Select CKm
						    ( 0 << 12) |		// [13:12] Count clock           : Prescaler
						    ( 0 << 11) |		// [11]    Synchronous operation : (Not used)
						    ( 1 <<  8) |		// [10:8]  Start trigger         : TINm(Capture)
						    ( 1 <<  6) |		// [7:6]   Capture overflow      : TAUJ2CDRm is updated by TINm edge
						                        //                                 TAUJ2OVF bit is cleared by TAUJ2CLOV bit
						    (11 <<  1) |		// [4:1]   Mode                  : Count capture
						    ( 0 <<  0));		// [0]     Aux                   : Does not output interrupt when count starts

		*(cmur_reg + ch) = (( 1 <<  0));		// [1:0]   Detect TINm edge      : Rise edge
	}
	//=========================================
	// Set reload data control
	//=========================================
	RIN_TMR->TAUJ2RDE  &= ~( 1 << ch );			// [m] RDEm (reload data enable) : disable
	RIN_TMR->TAUJ2RDM  &= ~( 1 << ch );			// [m] RDMm (reload data mode)   : disable for simultaneous rewriting

	//=========================================
	// Set TINm port (if you use)
	//=========================================
//	set_port_tin(ch);

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Selcet TOUTm function port
  @param  ch		: channel number
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
#if 0
static ER_RET set_port_tout( uint8_t ch )
{
	switch(ch)
	{
		case 0:
			RIN_GPIO->PFCE2B &= ~0x80;				// P27 -> TOUT0
			RIN_GPIO->PFC2B  |=  0x80;
			RIN_GPIO->PMC2B  |=  0x80;
			break;
		case 1:
			RIN_GPIO->PFCE2B &= ~0x40;				// P26 -> TOUT1
			RIN_GPIO->PFC2B  |=  0x40;
			RIN_GPIO->PMC2B  |=  0x40;
			break;
		case 2:
			RIN_GPIO->PFCE5B &= ~0x80;				// P57 -> TOUT2
			RIN_GPIO->PFC5B  |=  0x80;
			RIN_GPIO->PMC5B  |=  0x80;
			break;
		case 3:
			RIN_GPIO->PFCE5B &= ~0x04;				// P52 -> TOUT3
			RIN_GPIO->PFC5B  |=  0x04;
			RIN_GPIO->PMC5B  |=  0x04;
			break;
		default:
			return ER_PARAM;
			break;
	}
	return ER_OK;
}
#endif
/**
 ******************************************************************************
  @brief  Selcet TINm function port
  @param  ch		: channel number
  @retval ER_OK		: No error
  @retval ER_PARAM	: Parameter error
 ******************************************************************************
*/
#if 0
static ER_RET set_port_tin( uint8_t ch )
{
	switch(ch)
	{
		case 0:
			RIN_GPIO->PFCE2B &= ~0x80;				// P27 -> TIN0
			RIN_GPIO->PFC2B  &= ~0x80;
			RIN_GPIO->PMC2B  |=  0x80;
			break;
		case 1:
			RIN_GPIO->PFCE2B &= ~0x40;				// P26 -> TIN1
			RIN_GPIO->PFC2B  &= ~0x40;
			RIN_GPIO->PMC2B  |=  0x40;
			break;
		case 2:
			RIN_GPIO->PFCE5B &= ~0x80;				// P57 -> TIN2
			RIN_GPIO->PFC5B  &= ~0x80;
			RIN_GPIO->PMC5B  |=  0x80;
			break;
		case 3:
			RIN_GPIO->PFCE5B &= ~0x04;				// P52 -> TIN3
			RIN_GPIO->PFC5B  &= ~0x04;
			RIN_GPIO->PMC5B  |=  0x04;
			break;
		default:
			return ER_PARAM;
			break;
	}
	return ER_OK;
}
#endif

