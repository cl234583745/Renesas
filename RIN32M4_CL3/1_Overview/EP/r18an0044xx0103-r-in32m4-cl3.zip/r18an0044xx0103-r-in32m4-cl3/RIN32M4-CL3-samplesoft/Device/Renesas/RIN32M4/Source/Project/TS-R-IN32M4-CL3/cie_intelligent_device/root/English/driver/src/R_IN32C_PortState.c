/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_PortState.c                                               */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"
#include "ether/ether_phy_init.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define PHY_0					( 0 )		/*!<  */
#define PHY_1					( 1 )		/*!<  */
#define	ARMPF_REG_WRITE( reg, data )	(*(volatile unsigned long*)(reg) = (data))
#define	ARMPF_REG_READ( reg )			(*(volatile unsigned long*)(reg))


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
static ERRCODE erR_IN32C_ChangePHYSetting( ULONG );

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

ULONG	gulR_IN32C_LastLinkStat[2];				

VOID R_IN32C_SeqPort(
	ULONG ulPortNumber,					
	ULONG ulEvt							
)
{
	R_IN32C_PORT_T *pstPort;		

	if (R_IN32C_PORT1 == ulPortNumber) {
		pstPort = &gstR_IN32C.stP1;
	}
	else {
		pstPort = &gstR_IN32C.stP2;
	}

	switch (pstPort->ulState) {

	case R_IN32C_PORT_STS_LINKDOWN:		
	case R_IN32C_PORT_STS_LINKUP:			

		switch (ulEvt) {
		case R_IN32C_PORT_EVT_TICK:

			(VOID)erR_IN32C_SeqPort_Update(pstPort);
			break;
		default:
			break;
		}
		break;

	default:
		break;
	}

	return;
}


ERRCODE erR_IN32C_SeqPort_Update(
	R_IN32C_PORT_T *pstPort		
)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG	ulPortNo;
	BOOL	blTimeout;
	(VOID)gerR_IN32D_PhyGetState(pstPort->ulNumber, &pstPort->ulCurrState, &pstPort->ulCurrSpeed, &pstPort->ulCurrDuplex);

	if ( R_IN32C_PORT1 == pstPort->ulNumber ) {
		ulPortNo = R_IN32D_PORT1;
	}
	else {
		ulPortNo = R_IN32D_PORT2;
	}

	switch (pstPort->ulState) {
	case R_IN32C_PORT_STS_LINKDOWN:
		if ((R_IN32D_LINKUP == pstPort->ulCurrState) &&
		    (R_IN32D_SPEED_1G == pstPort->ulCurrSpeed) &&
		    (R_IN32D_DUPLEX_FULL == pstPort->ulCurrDuplex)) {
			pstPort->ulState = R_IN32C_PORT_STS_LINKUP;
			if (R_IN32C_PORT1 == pstPort->ulNumber) {
				gstR_IN32C.stMIB.stInf1c.ulUpCounter++;
			}
			else {
				gstR_IN32C.stMIB.stInf2c.ulUpCounter++;
			}
		
			if(R_IN32_CLOCK_MASTER == gstPHYSetting[pstPort->ulNumber].ulClk){

				gerR_IN32D_StopIntervalTimer(ulPortNo);
			}
		}
		else {
			if(R_IN32_CLOCK_MASTER == gstPHYSetting[pstPort->ulNumber].ulClk){

				blTimeout = gblR_IN32D_IsIntervalTimerTimeout(ulPortNo);

				if(R_IN32_TRUE == blTimeout){
					gerR_IN32D_StopIntervalTimer(ulPortNo);

					gerR_IN32D_ResetPHYPower(ulPortNo);

					gerR_IN32D_StartIntervalTimer(ulPortNo, 500);
				}
			}
		}
		break;
	case R_IN32C_PORT_STS_LINKUP:
		if (R_IN32D_LINKDOWN == pstPort->ulCurrState) {
			pstPort->ulState = R_IN32C_PORT_STS_LINKDOWN;
			if (R_IN32C_PORT1 == pstPort->ulNumber) {
				gstR_IN32C.stMIB.stInf1c.ulDownCounter++;
			}
			else {
				gstR_IN32C.stMIB.stInf2c.ulDownCounter++;
			}
			if(R_IN32_CLOCK_SLAVE == gstPHYSetting[pstPort->ulNumber].ulClk){
				gerR_IN32D_ResetPHYPower(ulPortNo);
			}
			else if(R_IN32_CLOCK_MASTER == gstPHYSetting[pstPort->ulNumber].ulClk){
				gerR_IN32D_StartIntervalTimer(ulPortNo, 500);
			}
		}
		else {
		}
		break;
	default:
		break;
	}

	return erRet;
}


ERRCODE erR_IN32C_CheckPHY(VOID)
{
	ULONG ulPort;
	ULONG ulLinkState;
	ULONG ulSpeed;
	ULONG ulDuplex;
	ULONG ulCount;
	ERRCODE erRet;

	erRet = R_IN32_OK;


	for (ulCount = 0UL; ulCount < 2UL; ulCount++) {

		if ( 0UL == ulCount) {
			ulPort = R_IN32D_PORT1;
		}
		else {
			ulPort = R_IN32D_PORT2;
		}

		(VOID)gerR_IN32D_PhyGetState( ulPort, &ulLinkState, &ulSpeed, &ulDuplex );

		if ((R_IN32_LINKUP == ulLinkState) && ((R_IN32_SPEED_1G != ulSpeed) || (R_IN32_DUPLEX_FULL != ulDuplex))) {

			if(R_IN32_CLOCK_AUTO == gstPHYSetting[ulPort].ulClk){
				erR_IN32C_ChangePHYSetting( ulPort );
			}
		}
		else{
		}
	}

	return erRet;
}


ERRCODE erR_IN32C_ChangePHYSetting(
	ULONG ulPort					
)
{
	ULONG ulRegData;
	ERRCODE erRet;

	erRet = R_IN32_OK;


	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_MacIp_AccessEnable();
	if ( R_IN32D_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
		erRet = R_IN32_ERR;
	}


	(VOID)erR_IN32C_ReadPHY( ulPort, 4UL, &ulRegData );
	ulRegData &= 0xFFFFFC1FUL;
	(VOID)erR_IN32C_WritePHY( ulPort, 4UL, ulRegData );

	(VOID)erR_IN32C_ReadPHY( ulPort, 9UL, &ulRegData );
	ulRegData &= 0xFFFFEEFFUL;
	ulRegData |= 0x00000E00UL;
	(VOID)erR_IN32C_WritePHY( ulPort, 9UL, ulRegData );

	(VOID)erR_IN32C_ReadPHY( ulPort, 0UL, &ulRegData );
	ulRegData |= 0x00000200UL;
	(VOID)erR_IN32C_WritePHY( ulPort, 0UL, ulRegData );

	(VOID)gerR_IN32D_MacIp_AccessDisable();

	(VOID)gR_IN32R_EnableInt();

	return erRet;
}




ERRCODE erR_IN32C_WritePHY(
	ULONG ulPort,							
	ULONG ulAddr,							
	ULONG ulData							
)
{
	ERRCODE erRet;

	if ( R_IN32_PORT1 == ulPort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erRet = gerR_IN32D_MACIP_PHYWrite(ulPort, ulAddr, ulData);

	if ( R_IN32D_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
		erRet = R_IN32_ERR;
	}

	return erRet;
}



ERRCODE erR_IN32C_ReadPHY(
	ULONG  ulPort,							
	ULONG  ulAddr,							
	ULONG* ulData							
)
{
	ERRCODE erRet;

	if ( R_IN32_PORT1 == ulPort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erRet = gerR_IN32D_MACIP_PHYRead(ulPort, ulAddr, ulData);

	if ( R_IN32D_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/*** EOF ***/
