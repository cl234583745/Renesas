/**
 *******************************************************************************
 * @file  timer.h
 * @brief 32-bit Timer (TAUJ2) driver program
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	TIMER_H__
#define	TIMER_H__

/*==========================================================================*/
/* I N C L U D E															*/
/*==========================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*==========================================================================*/
/* T Y P E D E F															*/
/*==========================================================================*/

/*==========================================================================*/
/* D E F I N E																*/
/*==========================================================================*/

/*==========================================================================*/
/* P R O T O T Y P E                                                        */
/*==========================================================================*/
void clock_init( void );

ER_RET timer_interval_init( uint8_t ch,uint32_t i_time );
ER_RET timer_onecount_hwtrg_init( uint8_t ch,uint32_t o_time, uint32_t trg );
ER_RET timer_start( uint8_t ch );
ER_RET timer_stop( uint8_t ch );
ER_RET timer_check_act(uint8_t ch);

#endif // TIMER_H__
