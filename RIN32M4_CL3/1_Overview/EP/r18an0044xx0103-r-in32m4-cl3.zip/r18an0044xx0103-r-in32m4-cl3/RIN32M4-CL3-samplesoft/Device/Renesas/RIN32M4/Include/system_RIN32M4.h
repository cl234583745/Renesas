/**
 *******************************************************************************
 * @file  system_RIN32M4.h
 * @brief sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */
#ifndef __SYSTEM_RIN32M4_H
#define __SYSTEM_RIN32M4_H

#ifdef __cplusplus
extern "C" {
#endif

/*==========================================================================*/
/* I N C L U D E															*/
/*==========================================================================*/
#if defined ( __ICCARM__ )
#include <arm_itm.h>
#endif

/*==========================================================================*/
/* T Y P E D E F															*/
/*==========================================================================*/

/*==========================================================================*/
/* D E F I N E																*/
/*==========================================================================*/
#define RIN32M4_SYSCLK	100000000			/* System clock freq.(Hz) */
#define SYS_UART_CH		1					/* UART channel           */

#define RIN_TYPE                "R-IN32M4-CL3"
#define RIN_PACKAGE_VERSION		"1.0.0"
#define RIN_DRIVER_VERSION		"2.6.1"
#define RIN_HWOS_VERSION		"2.0.3"

/*==========================================================================*/
/* E X T E R N																*/
/*==========================================================================*/
extern uint32_t SystemCoreClock;

extern void SystemInit(void);

extern void SystemCoreClockUpdate(void);

extern void rin_boot_message(void);
extern char *rin_package_get_version(uint8_t mode);
extern char *rin_driver_get_version(uint8_t mode);

#ifdef __cplusplus
}
#endif

#else
#endif
