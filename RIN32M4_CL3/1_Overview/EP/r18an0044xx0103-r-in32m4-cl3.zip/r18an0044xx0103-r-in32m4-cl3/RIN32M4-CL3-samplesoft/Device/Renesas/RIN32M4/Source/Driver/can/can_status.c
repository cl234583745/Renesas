/**
 *******************************************************************************
 * @file  can_status.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************

  @brief  Get CAN channel status
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval bit7 = 0  : Normal end
                     bit0            : Tx complete
                     bit1            : Rx complete
                     bit2            : CAN error status
                     bit3            : CAN protocol error
                     bit4            : Arbitration lost
                     bit5            : Wake up status from CAN sleep mode
                     bit6            : Trasmittion abort
                     bit7            : 0
  @retval ER_PARAM : Parameter error
 *******************************************************************************
 */
ER_RET can_get_ch_status(uint8_t ch)
{

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Get CAN status (Set return value)									*/
	/*----------------------------------------------------------------------*/
	return ((ER_RET)(RIN_CAN[ch]->MDL.FCNnCMISCTL & (MSK_CAN_CMISITSF0 | MSK_CAN_CMISITSF1 |MSK_CAN_CMISITSF2 | MSK_CAN_CMISITSF3 | MSK_CAN_CMISITSF4 | MSK_CAN_CMISITSF5 | MSK_CAN_CMISITSF6)));
}

/**
 *******************************************************************************

  @brief  CAN channel status clear
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] clrdat: Clear data
    @arg  bit0       : Tx complete
          bit1       : Rx complete
          bit2       : CAN error status
          bit3       : CAN protocol error
          bit4       : Arbitration lost
          bit5       : Wake up status from CAN sleep mode
          bit6       : Trasmittion abort
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
 *******************************************************************************
 */
ER_RET can_clr_ch_status(uint8_t ch,uint8_t clrdat)
{

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Clear CAN status													*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->MDL.FCNnCMISCTL = (uint32_t)(clrdat & (MSK_CAN_CMISITSF0 | MSK_CAN_CMISITSF1 | MSK_CAN_CMISITSF2 | MSK_CAN_CMISITSF3 | MSK_CAN_CMISITSF4 | MSK_CAN_CMISITSF5 | MSK_CAN_CMISITSF6));

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Get CAN bus status
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval bit7 = 0  : Normal end
                     bit1 - bit0    : Reception error counter status bit
                     bit3 - bit2    : Transmission error counter status bit
                     bit4           : Busoff status bit
                     bit7 - bit5    : 0
  @retval ER_PARAM : Parameter error
 *******************************************************************************
 */
ER_RET can_get_bus_staus(uint8_t ch)
{
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Get CAN bus status (Set return value)								*/
	/*----------------------------------------------------------------------*/
	return ((ER_RET)(RIN_CAN[ch]->MDL.FCNnCMINSTR & (MSK_CAN_CMINBOFF | MSK_CAN_CMINSSTE | MSK_CAN_CMINSSRE)));
}
