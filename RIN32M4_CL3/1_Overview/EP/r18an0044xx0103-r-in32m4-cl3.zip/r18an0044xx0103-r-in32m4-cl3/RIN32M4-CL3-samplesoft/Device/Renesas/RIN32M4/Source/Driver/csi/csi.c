/**
 *******************************************************************************
 * @file  csi.c
 * @brief CSI driver program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "csi/csi.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/* CSI ring-buffer */
#define CSI_RING_SIZE ((uint32_t)1 << 8)								/**< ring-buffer size for CSI driver */
struct CSI_RING
{
	__IO uint32_t head;													/**< head pointer */
	__IO uint32_t tail;													/**< tail pointer */
	__IO uint8_t  data[CSI_RING_SIZE];									/**< buffer */
};																		/**< ring-buffer structure for CSI driver */
typedef struct CSI_RING tCSI_RING;										/**< type define for ring-buffer structure for CSI driver */
#define CSI_RING_NOT_EMPTY(r)  ( (r)->head > 0 )												/**< Check whether ring-buffer is not empty */
#define CSI_RING_EMPTY(r)      ( (r)->head == 0 )												/**< Check whether ring-buffer is empty */
#define CSI_RING_NOT_FULL(r)   ( (r)->head < CSI_RING_SIZE )									/**< Check whether ring-buffer is not full */
#define CSI_RING_GETCHAR(r)    ( (r)->head--, (r)->data[((r)->tail++)  % CSI_RING_SIZE])		/**< Get character from ring-buffer */
#define CSI_RING_PUTCHAR(r, c) ( (r)->data[((r)->tail + ((r)->head++)) % CSI_RING_SIZE] = (c))	/**< Put character to ring-buffer */
#define CSI_RING_TAIL(r)       (((r)->tail) % CSI_RING_SIZE)									/**< return ring-buffer tail */

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
static __IO tCSI_RING csi_tx_ring[2];		/**< CSI reception buffer */
static __IO tCSI_RING csi_rx_ring[2];		/**< CSI transmission buffer */
static __IO int32_t   csi_mode_ms[2];		/**< CSI Master/Slave mode */
static __IO int32_t   csi_mode_rt[2];		/**< CSI Reception/Transmit mode */
static __IO int32_t   csi_flag_ic[2];		/**< CSI Interrupt Comunication Flag for master */
static __IO int32_t   csi_flag_ir[2];		/**< CSI Interrupt Reception Flag for master */

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static void   csi_master_init(uint32_t ch);
static void   csi_master_change_mode(uint32_t ch, uint32_t mode);
static ER_RET csi_master_write(uint32_t ch, uint8_t data);
static ER_RET csi_master_read(uint32_t ch, uint8_t* data);
static void   csi_slave_init(uint32_t ch);
static void   csi_slave_change_mode(uint32_t ch, uint32_t mode);
static ER_RET csi_slave_write(uint32_t ch, uint8_t data);
static ER_RET csi_slave_read(uint32_t ch, uint8_t* data);

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 *******************************************************************************

  @brief  Initialize CSI driver and controller
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] mode : Master/Slave mode 
    @arg 0 =master(CSI_MSMODE_MASTER) 
    @arg 1 =slave(CSI_MSMODE_SLAVE) 
  @return Error condition 
  @retval ER_OK    : No error
  @retval ER_PARAM : Parameter error

 *******************************************************************************
 */
ER_RET csi_init(uint32_t ch, uint32_t mode)
{
	/* Check parameter */
	if (ch   >= 2) { return ER_PARAM; }
	if (mode >= 2) { return ER_PARAM; }
	
	/* Set mode */
	csi_mode_ms[ch] = mode;						/* master or slave */
	csi_mode_rt[ch] = CSI_RTMODE_INITIAL;		/* initial mode */
	csi_flag_ic[ch] = 0;						/* clear */
	csi_flag_ic[ch] = 0;						/* clear */
	
	/* Initialize ( csi controller ) */
	if (csi_mode_ms[ch] == 0)
	{
		csi_master_init(ch);
	}
	else
	{
		csi_slave_init(ch);
	}
	
	/* initialize ( interrupt, port ) */
	if (ch == 0)
	{
		/* Interrupt */
//		NVIC_SetPriority(CSIH0IC_IRQn , 10);
//		NVIC_SetPriority(CSIH0IR_IRQn , 10);
//		NVIC_SetPriority(CSIH0IJC_IRQn, 10);
//		NVIC_SetPriority(CSIH0IRE_IRQn, 10);
		NVIC_EnableIRQ(CSIH0IC_IRQn );
		NVIC_EnableIRQ(CSIH0IR_IRQn );
		NVIC_EnableIRQ(CSIH0IJC_IRQn);
		NVIC_EnableIRQ(CSIH0IRE_IRQn);
		/* Port */
		RIN_GPIO->PFCE4B &= ~0xe0;	/* P47(CSISO0),P46(CSISI0),P45(CSISCK0) */
		RIN_GPIO->PFC4B  &= ~0xe0;
		RIN_GPIO->PMC4B  |=  0xe0;
	}
	else
	{
		/* Interrupt */
//		NVIC_SetPriority(CSIH1IC_IRQn , 10);
//		NVIC_SetPriority(CSIH1IR_IRQn , 10);
//		NVIC_SetPriority(CSIH1IJC_IRQn, 10);
//		NVIC_SetPriority(CSIH1IRE_IRQn, 10);
		NVIC_EnableIRQ(CSIH1IC_IRQn );
		NVIC_EnableIRQ(CSIH1IR_IRQn );
		NVIC_EnableIRQ(CSIH1IJC_IRQn);
		NVIC_EnableIRQ(CSIH1IRE_IRQn);
		/* Port */
		RIN_GPIO->PFCE3B &= ~0xe0;	/* P37(CSISO1),P36(CSISI1),P35(CSISCK1) */
		RIN_GPIO->PFC3B  &= ~0xe0;
		RIN_GPIO->PMC3B  |=  0xe0;
	}
	
	/* Return */
	return ER_OK;
}


/**
 *******************************************************************************

  @brief   Change CSI transfer mode 
  @param   [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param   [in] mode : Transter mode 
    @arg 0 =reception mode(CSI_RTMODE_RECEPTION) 
    @arg 1 =transmission mode(CSI_RTMODE_TRANSMISSION) 
  @return  Error condition 
  @retval  ER_OK    : No error 
  @retval  ER_PARAM : Parameter error 
  
  @note    In MASTER mode, the transfer mode is changed to TRANSMISSION mode, even in csi_write().
  @note    In MASTER mode, the transfer mode is changed to RECEPTION mode, even in csi_read().

 *******************************************************************************
 */
ER_RET csi_change_mode(uint32_t ch, uint32_t mode)
{
	/* Check parameter */
	if (ch   >= 2) { return ER_PARAM; }
	if (mode >= 2) { return ER_PARAM; }
	
	/* Change transfer mode */
	if (csi_mode_ms[ch] == 0)
	{
		csi_master_change_mode(ch, mode);
	}
	else
	{
		csi_slave_change_mode(ch, mode);
	}
	csi_mode_rt[ch] = mode;
	
	/* Return */
	return ER_OK;
}


/**
 *******************************************************************************

  @brief   Write CSI data 
  @param   [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param   [in] data : Write data 
  @return  Error condition 
  @retval  ER_OK     : No error 
  @retval  ER_PARAM  : Parameter error 
  @retval  ER_INVAL  : Mode error 
  @retval  ER_NOTYET : Write is not complete 
  
  @note    In MASTER mode, the transfer mode is changed to TRANSMISSION mode.

 *******************************************************************************
 */
ER_RET csi_write(uint32_t ch, uint8_t data)
{
	ER_RET retval;			/* return value */
	
	/* Check parameter */
	if (ch >= 2) { return ER_PARAM; }
	
	/* Write */
	if (csi_mode_ms[ch] == CSI_MSMODE_MASTER)
	{
		/* Check transfer mode */
		if (csi_mode_rt[ch] != CSI_RTMODE_TRANSMISSION)
		{
			csi_master_change_mode(ch, CSI_RTMODE_TRANSMISSION);
			csi_mode_rt[ch] = CSI_RTMODE_TRANSMISSION;
		}
		retval = csi_master_write(ch, data);
	}
	else
	{
		/* Check transfer mode */
		if (csi_mode_rt[ch] != CSI_RTMODE_TRANSMISSION)
		{
			return ER_INVAL;
		}
		retval = csi_slave_write(ch, data);
	}
	
	/* Return */
	return retval;
}


/**
 *******************************************************************************

  @brief   Read CSI data 
  @param   [in]  ch    : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param   [out] *data : Read data pointer 
  @return  Error condition 
  @retval  ER_OK     : No error 
  @retval  ER_PARAM  : Parameter error 
  @retval  ER_INVAL  : Mode error 
  @retval  ER_NOTYET : Read is not complete 
  
  @note    In MASTER mode, the transfer mode is changed to RECEPTION mode.

 *******************************************************************************
 */
ER_RET csi_read(uint32_t ch, uint8_t* data)
{
	ER_RET retval;			/* return value */
	
	/* Check parameter */
	if (ch >= 2) { return ER_PARAM; }
	
	/* Read */
	if (csi_mode_ms[ch] == CSI_MSMODE_MASTER)
	{
		/* Check transfer mode */
		if (csi_mode_rt[ch] != CSI_RTMODE_RECEPTION)
		{
			csi_master_change_mode(ch, CSI_RTMODE_RECEPTION);
			csi_mode_rt[ch] = CSI_RTMODE_RECEPTION;
		}
		retval = csi_master_read(ch, data);
	}
	else
	{
		/* Check transfer mode */
		if (csi_mode_rt[ch] != CSI_RTMODE_RECEPTION)
		{
			return ER_INVAL;
		}
		retval = csi_slave_read(ch, data);
	}
	
	/* Return */
	return retval;
}


/**
 *******************************************************************************

  @brief   Check CSI write data 
  @param   [in] ch : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return  Checked condition 
  @retval  ER_OK     : Not exist transmission data 
  @retval  ER_NOTYET : Exist transmission data 
  @retval  ER_INVAL  : Mode error 
  @retval  ER_PARAM  : Parameter error 
  
  @note    Because MASTER mode does not use the buffer(csi_tx_ring), the return value is always ER_OK.

 *******************************************************************************
 */
ER_RET csi_check_tx(uint32_t ch)
{
	/* Check parameter */
	if (ch >= 2)
	{
		return ER_PARAM;
	}
	
	/* Check Master/Slave mode */
	if (csi_mode_ms[ch] == CSI_MSMODE_MASTER)
	{
		/* Master mode f use buffer */
		return ER_OK;
	}
	
	/* Check Reception/Transmission mode */
	if (csi_mode_rt[ch] != CSI_RTMODE_TRANSMISSION)
	{
		return ER_INVAL;
	}
	
	/* Check ring-buffer */
	if (CSI_RING_NOT_EMPTY(&csi_tx_ring[ch]))
	{
		return ER_NOTYET;
	}
	
	/* Return */
	return ER_OK;
}


/**
 *******************************************************************************

  @brief   Check CSI read data 
  @param   [in] ch : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return  Checked condition 
  @retval  ER_OK     : Exist reception data 
  @retval  ER_NOTYET : Not exist reception data 
  @retval  ER_INVAL  : Mode error 
  @retval  ER_PARAM  : Parameter error 
  
  @note    Because MASTER mode does not use the buffer(csi_rx_ring), the return value is always ER_NOTYET.

 *******************************************************************************
 */
ER_RET csi_check_rx(uint32_t ch)
{
	/* Check parameter */
	if (ch >= 2)
	{
		return ER_PARAM;
	}
	
	/* Check Master/Slave mode */
	if (csi_mode_ms[ch] == CSI_MSMODE_MASTER)
	{
		/* Master mode doesn't use buffer */
		return ER_NOTYET;
	}
	
	/* Check Reception/Transmission mode */
	if (csi_mode_rt[ch] != CSI_RTMODE_RECEPTION)
	{
		return ER_INVAL;
	}
	
	/* Check ring-buffer */
	if (CSI_RING_EMPTY(&csi_rx_ring[ch]))
	{
		return ER_NOTYET;
	}
	
	return ER_OK;
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Communication handler (channel 0)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH0IC_IRQHandler(void)
{
	if (csi_mode_ms[0] == CSI_MSMODE_MASTER)
	{
		/* Master */
		csi_flag_ic[0] = 1;
	}
	else
	{
		/* Slave */
		if (CSI_RING_NOT_EMPTY(&csi_tx_ring[0]))
		{
			RIN_CSI0->CSIHnTX0W = (uint32_t)(CSI_RING_GETCHAR(&csi_tx_ring[0]));
		}
	}

	__DSB();		// Errata work aruond - ID:838869
	return;
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Reception handler (channel 0)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH0IR_IRQHandler(void)
{
	if (csi_mode_ms[0] == CSI_MSMODE_MASTER)
	{
		/* Master */
		csi_flag_ir[0] = 1;
	}
	else
	{
		/* Slave */
		if (CSI_RING_NOT_FULL(&csi_rx_ring[0]))
		{
			CSI_RING_PUTCHAR(&csi_rx_ring[0], ((uint8_t)(RIN_CSI0->CSIHnRX0W & 0xff)));
		}
	}

	__DSB();		// Errata work aruond - ID:838869
	return;
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Reception Error handler (channel 0)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH0IRE_IRQHandler(void)
{
	/* Implemented by user */
	while(1);

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt for JOB Completion handler (channel 0)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH0IJC_IRQHandler(void)
{
	/* Implemented by user */
	while(1);

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Communication handler (channel 1)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH1IC_IRQHandler(void)
{
	if (csi_mode_ms[1] == CSI_MSMODE_MASTER)
	{
		/* Master */
		csi_flag_ic[1] = 1;
	}
	else
	{
		/* Slave */
		if (CSI_RING_NOT_EMPTY(&csi_tx_ring[1]))
		{
			RIN_CSI1->CSIHnTX0W = (uint32_t)(CSI_RING_GETCHAR(&csi_tx_ring[1]));
		}
	}

	__DSB();		// Errata work aruond - ID:838869
	return;
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Reception handler (channel 1)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH1IR_IRQHandler(void)
{
	if (csi_mode_ms[1] == CSI_MSMODE_MASTER)
	{
		/* Master */
		csi_flag_ir[1] = 1;
	}
	else
	{
		/* Slave */
		if (CSI_RING_NOT_FULL(&csi_rx_ring[1]))
		{
			CSI_RING_PUTCHAR(&csi_rx_ring[1], ((uint8_t)(RIN_CSI1->CSIHnRX0W & 0xff)));
		}
	}

	__DSB();		// Errata work aruond - ID:838869
	return;
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt Reception Error handler (channel 1)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH1IRE_IRQHandler(void)
{
	/* Implemented by user */
	while(1);

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************

  @brief  CSI Transmission Interrupt for JOB Completion handler (channel 1)
  @param  -
  @return none

 *******************************************************************************
 */
void CSIH1IJC_IRQHandler(void)
{
	/* Implemented by user */
	while(1);

	__DSB();		// Errata work aruond - ID:838869
}


/**
 *******************************************************************************
  @brief  init CSI (master) 
  @param  [in] ch : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @return none 
 *******************************************************************************
 */
static void csi_master_init(uint32_t ch)
{
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Initialize */
	RIN_CSI->CSIHnCTL1  = (0    << 17)	/* bit17   (CSIHnCKR     )=0   :default level of CSIHTSCO is High */
	                    | (1    << 16)	/* bit16   (CSIHnSLIT    )=1   :CSIHTIC is generated as soon as new data is transferred to the shift register. */
	                    | (0x00 <<  8)	/* bit15-08(CSIHnCSL7-0  )=0x00:Chip Select0 is active low */
	                    | (0    <<  7)	/* bit07   (CSIHnEDLE    )=0   :Extend data length Mode disabled */
	                    | (0    <<  6)	/* bit06   (CSIHnJE      )=0   :Job Mode disable */
	                    | (0    <<  5)	/* bit05   (CSIHnDCS     )=0   :Data Consistency Check disabled */
	                    | (0    <<  4)	/* bit04   (CSIHnCSRI    )=0   :CS holds active level of last data after the data transfer of the final data. */
	                    | (0    <<  3)	/* bit03   (CSIHnLBM     )=0   :Loop-Back Mode deactivated */
	                    | (0    <<  2)	/* bit02   (CSIHnSIT     )=0   :No delay */
	                    | (0    <<  1)	/* bit01   (CSIHnHSE     )=0   :Hand-shake function disabled */
	                    | (0    <<  0);	/* bit00   (CSIHnSSE     )=0   :CSIHTSSI operation is disabled in slave mode. */

	RIN_CSI->CSIHnCTL2  = (0x0  << 13)	/* bit15-13(CSIHnPRS2-0  )=0x1 :PRS = PCLK / 2 ( Master mode ) */
	                    | (0x3  <<  0);	/* bit11-00(CSIHnBRS11-0 )=0x3 :Baud rate = PCLK / (2^m�~3�~2) */

	RIN_CSI->CSIHnCFG1  = (0x0  << 30)	/* bit31-30(CSIHnPSCLm1-0)=0x0 :( CSIH0CTL2 Configuration CLK ) / 1 */
	                    | (0x0  << 28)	/* bit29-28(CSIHnPSm1-0  )=0x0 :No parity transmitted/ No parity expected */
	                    | (0x8  << 24)	/* bit27-24(CSIHnDLSm3-0 )=0x8 :Data Length for chip select m is 8 */
	                    | (0    << 19)	/* bit19   (CSIHnRCBm    )=0   :Configuration of chip select m is dominant (higher priority) */
	                    | (0    << 18)	/* bit18   (CSIHnDIRm    )=0   :Data is sent/received with MSB first */
	                    | (0    << 17)	/* bit17   (CSIHnCKPm    )=0   :Clock phase selection bit */
	                    | (0    << 16)	/* bit16   (CSIHnDAPm    )=0   :Data phase selecton bit */
	                    | (0    << 15)	/* bit15   (CSIHnIDLm    )=0   :Idle Enforcement Configuration */
	                    | (0x0  << 12)	/* bit14-12(CSIHnIDm2-0  )=0x0 :Idle Time ( CS_IDLE ) = 0.5 */
	                    | (0x0  <<  8)	/* bit11-08(CSIHnHDm3-0  )=0x0 :Hold Time ( CS_HOLD ) = 0.5 */
	                    | (0x0  <<  4)	/* bit07-04(CSIHnINm3-0  )=0x0 :Inter-Data Time ( CSINTER ) = 0.0 */
	                    | (0x0  <<  0);	/* bit03-00(CSIHnSPm3-0  )=0x0 :Setup Time ( CSSETUP ) = 0.5 */
	
	RIN_CSI->CSIHnCTL0  = (0    <<  7)	/* bit07   (CSIHnPWR     )=0   :Stop macro operation clock */
	                    | (0    <<  6)	/* bit06   (CSIHnTXE     )=0   :Transmission disabled */
	                    | (0    <<  5)	/* bit05   (CSIHnRXE     )=0   :Reception disabled */
	                    | (0    <<  1)	/* bit01   (CSIHnJOBE    )=0   :Communication stop is not required */
	                    | (1    <<  0);	/* bit00   (CSIHnMBS     )=1   :Direct Access mode (Memory part is by-passed) */
	
	/* Return */
	return;
}

/**
 *******************************************************************************
  @brief  Change CSI mode (master) 
  @param  [in] ch   : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [in] mode : Transter mode 
    @arg 0      =reception mode(CSI_RTMODE_RECEPTION) 
    @arg others =transmission mode(CSI_RTMODE_TRANSMISSION) 
  @return none 
 *******************************************************************************
 */
static void csi_master_change_mode(uint32_t ch, uint32_t mode)
{
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	uint32_t ctl0;				/* temporary value */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Stop */
	ctl0 = RIN_CSI->CSIHnCTL0;
	ctl0 &= ~(1 << 7);			/* bit07(CSIHnPWR)=0:Stop macro operation clock */
	
	/* Change mode */
	if (mode == CSI_RTMODE_RECEPTION)
	{
		ctl0 &= ~(1 << 6);		/* bit06(CSIHnTXE)=0:Transmission disabled */
		ctl0 |=  (1 << 5);		/* bit05(CSIHnRXE)=1:Reception enabled */
	}
	else
	{
		ctl0 |=  (1 << 6);		/* bit06(CSIHnTXE)=1:Transmission enabled */
		ctl0 &= ~(1 << 5);		/* bit05(CSIHnRXE)=0:Reception disabled */
	}
	RIN_CSI->CSIHnCTL0 = ctl0;
	
	/* Start */
	ctl0 |=  (1 << 7);			/* bit07(CSIHnPWR)=1:Start macro operation clock */
	RIN_CSI->CSIHnCTL0 = ctl0;
	
	/* Return */
	return;
}

/**
 *******************************************************************************
  @brief  Write CSI data (master) 
  @param  [in] ch   : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [in] data : Write data 
  @return Error condition 
  @retval ER_OK : no error 
 *******************************************************************************
 */
static ER_RET csi_master_write(uint32_t ch, uint8_t data)
{
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Write */
	csi_flag_ic[ch] = 0;				/* clear */
	csi_flag_ir[ch] = 0;				/* clear */
	RIN_CSI->CSIHnTX0W = (0    << 31)	/* bit31   (CSIHnCIRE  )=0   :No Communication Interrupt requested */
	                   | (0    << 30)	/* bit30   (CSIHnEOJ   )=0   :No end-of-job data */
	                   | (0    << 29)	/* bit29   (CSIHnEDL   )=0   :Normal operation */
	                   | (0xfd << 16)	/* bit23-16(CSIHnCS1-0 )=0xfd:Chip Select 1 is activated for the associated transmission */
	                   | (data <<  0);	/* bit15-00(CSIHnTX15-0)=data:Data to be transmitted */
	
	/* Wait write complete */
	while (csi_flag_ic[ch] == 0);
	
	return ER_OK;
}

/**
 *******************************************************************************
  @brief  Read CSI data (master) 
  @param  [in]  ch    : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [out] *data : Read data pointer 
  @return Error condition 
  @retval ER_OK : No error 
  @retval ER_NG : fifo error (underrun or overflow) 
 *******************************************************************************
 */
static ER_RET csi_master_read(uint32_t ch, uint8_t* data)
{
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Read */
	csi_flag_ic[ch] = 0;					/* clear */
	csi_flag_ir[ch] = 0;					/* clear */
	RIN_CSI->CSIHnTX0W = (0      << 31)		/* bit31   (CSIHnCIRE  )=0   :No Communication Interrupt requested */
	                   | (0      << 30)		/* bit30   (CSIHnEOJ   )=0   :No end-of-job data */
	                   | (0      << 29)		/* bit29   (CSIHnEDL   )=0   :Normal operation */
	                   | (0xfd   << 16)		/* bit23-16(CSIHnCS1-0 )=0xfd:Chip Select 1 is activated for the associated transmission */
	                   | (0x0000 <<  0);	/* bit15-00(CSIHnTX15-0)=data:(Tx data is not used, but CS is enabled.) */
	
	/* Wait read complete */
	while (csi_flag_ic[ch] == 0);
	while (csi_flag_ir[ch] == 0);
	
	/* Return */
	*data = (uint8_t)(RIN_CSI->CSIHnRX0W & 0xff);
	return ER_OK;
}


/**
 *******************************************************************************
  @brief  CSI init (slave) 
  @param  [in] ch : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @return none 
 *******************************************************************************
 */
static void csi_slave_init(uint32_t ch)
{
	RIN_CSI_TypeDef *RIN_CSI;
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Initialize */
	RIN_CSI->CSIHnCTL1  = (0    << 17)	/* bit17   (CSIHnCKR     )=0   :default level of CSIHTSCO is High */
	                    | (1    << 16)	/* bit16   (CSIHnSLIT    )=1   :CSIHTIC is generated as soon as new data is transferred to the shift register. */
	                    | (0xff <<  8)	/* bit15-08(CSIHnCSL7-0  )=0xff:Chip Select m is active high */
	                    | (0    <<  7)	/* bit07   (CSIHnEDLE    )=0   :Extend data length Mode disabled */
	                    | (0    <<  6)	/* bit06   (CSIHnJE      )=0   :Job Mode disable */
	                    | (0    <<  5)	/* bit05   (CSIHnDCS     )=0   :Data Consistency Check disabled */
	                    | (0    <<  4)	/* bit04   (CSIHnCSRI    )=0   :CS holds active level of last data after the data transfer of the final data. */
	                    | (0    <<  3)	/* bit03   (CSIHnLBM     )=0   :Loop-Back Mode deactivated */
	                    | (0    <<  2)	/* bit02   (CSIHnSIT     )=0   :No delay */
	                    | (0    <<  1)	/* bit01   (CSIHnHSE     )=0   :Hand-shake function disabled */
	                    | (0    <<  0);	/* bit00   (CSIHnSSE     )=0   :CSIHTSSI operation is disabled in slave mode. */
	RIN_CSI->CSIHnCTL2  = (0x7  << 13)	/* bit15-13(CSIHnPRS2-0  )=0x7 :PRS = CSIHTSCI ( slave mode ) */
	                    | (0x0  <<  0);	/* bit11-00(CSIHnBRS11-0 )=0x0 :Baud rate = stopped */
	RIN_CSI->CSIHnCFG0  = (0x0  << 30)	/* bit31-30(CSIHnPSCLm1-0)=0x0 :( CSIH0CTL2 Configuration CLK ) / 1 */
	                    | (0x0  << 28)	/* bit29-28(CSIHnPSm1-0  )=0x0 :No parity transmitted/ No parity expected */
	                    | (0x8  << 24)	/* bit27-24(CSIHnDLSm3-0 )=0x8 :Data Length for chip select m is 8 */
	                    | (0    << 19)	/* bit19   (CSIHnRCBm    )=0   :Configuration of chip select m is dominant (higher priority) */
	                    | (0    << 18)	/* bit18   (CSIHnDIRm    )=0   :Data is sent/received with MSB first */
	                    | (0    << 17)	/* bit17   (CSIHnCKPm    )=0   :Clock phase selection bit */
	                    | (0    << 16)	/* bit16   (CSIHnDAPm    )=0   :Data phase selecton bit */
	                    | (0    << 15)	/* bit15   (CSIHnIDLm    )=0   :Idle Enforcement Configuration */
	                    | (0x0  << 12)	/* bit14-12(CSIHnIDm2-0  )=0x0 :Idle Time ( CS_IDLE ) = 0.5 */
	                    | (0x0  <<  8)	/* bit11-08(CSIHnHDm3-0  )=0x0 :Hold Time ( CS_HOLD ) = 0.5 */
	                    | (0x0  <<  4)	/* bit07-04(CSIHnINm3-0  )=0x0 :Inter-Data Time ( CSINTER ) = 0.0 */
	                    | (0x0  <<  0);	/* bit03-00(CSIHnSPm3-0  )=0x0 :Setup Time ( CSSETUP ) = 0.5 */
	
	RIN_CSI->CSIHnCTL0  = (0    <<  7)	/* bit07   (CSIHnPWR     )=0   :Stop macro operation clock */
	                    | (0    <<  6)	/* bit06   (CSIHnTXE     )=0   :Transmission disabled */
	                    | (0    <<  5)	/* bit05   (CSIHnRXE     )=0   :Reception disabled */
	                    | (0    <<  1)	/* bit01   (CSIHnJOBE    )=0   :Communication stop is not required */
	                    | (1    <<  0);	/* bit00   (CSIHnMBS     )=1   :Direct Access mode (Memory part is by-passed) */
	
	/* Return */
	return;
}

/**
 *******************************************************************************
  @brief  Change CSI mode (slave) 
  @param  [in] ch   : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [in] mode : Transter mode 
    @arg 0      =reception mode(CSI_RTMODE_RECEPTION) 
    @arg others =transmission mode(CSI_RTMODE_TRANSMISSION) 
  @return none 
 *******************************************************************************
 */
static void csi_slave_change_mode(uint32_t ch, uint32_t mode)
{
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	uint32_t ctl0;				/* temporary value */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Stop */
	ctl0 = RIN_CSI->CSIHnCTL0;
	ctl0 &= ~(1 << 7);			/* bit07(CSIHnPWR)=0:Stop macro operation clock */
	
	/* Change mode */
	if (mode == CSI_RTMODE_RECEPTION)
	{
		ctl0 &= ~(1 << 6);		/* bit06(CSIHnTXE)=0:Transmission disabled */
		ctl0 |=  (1 << 5);		/* bit05(CSIHnRXE)=1:Reception enabled */
	}
	else
	{
		ctl0 |=  (1 << 6);		/* bit06(CSIHnTXE)=1:Transmission enabled */
		ctl0 &= ~(1 << 5);		/* bit05(CSIHnRXE)=0:Reception disabled */
	}
	RIN_CSI->CSIHnCTL0 = ctl0;
	
	/* Start */
	ctl0 |=  (1 << 7);			/* bit07(CSIHnPWR)=1:Start macro operation clock */
	RIN_CSI->CSIHnCTL0 = ctl0;
	
	/* Return */
	return;
}

/**
 *******************************************************************************
  @brief  Write CSI data (slave) 
  @param  [in] ch   : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [in] data : Write data 
  @return Error condition 
  @retval ER_OK     : Write complete 
  @retval ER_NOTYET : Write is not complete 
 *******************************************************************************
 */
static ER_RET csi_slave_write(uint32_t ch, uint8_t data)
{
	ER_RET retval;				/* return value */
	RIN_CSI_TypeDef* RIN_CSI;	/* register pointer */
	
	/* Select channel */
	if (ch == 0)
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI0_BASE;
	}
	else
	{
		RIN_CSI = (RIN_CSI_TypeDef *)RIN_CSI1_BASE;
	}
	
	/* Write */
	if (CSI_RING_EMPTY(&csi_tx_ring[ch]) && ((RIN_CSI->CSIHnSTR0 & 0x00000080) == 0))
	{
		/* idle, and ring-buffer is empty, then put data to OFIFO */
		RIN_CSI->CSIHnTX0W = (0    << 31)	/* bit31   (CSIHnCIRE     )=0   :No Communication Interrupt requested */
		                   | (0    << 30)	/* bit30   (CSIHnEOJ      )=0   :No end-of-job data */
		                   | (0    << 29)	/* bit29   (CSIHnEDL      )=0   :Normal operation */
		                   | (0x00 << 16)	/* bit23-16(CSIHnCS1-0    )=0x00:Chip Select m is disactivated for the associated transmission */
		                   | (data <<  0);	/* bit15-00(CSIHnTX15-0   )=data:Data to be transmitted */
		retval = ER_OK;
	}
	else if (CSI_RING_NOT_FULL(&csi_tx_ring[ch]))
	{
		/* during transmitting, and ring-buffer is not full, then put character to ring-buffer */
		CSI_RING_PUTCHAR(&csi_tx_ring[ch], data);
		retval = ER_OK;
	}
	else
	{
		/* during transmitting, and ring-buffer is full, then do nothing */
		retval = ER_NOTYET;
	}
	
	/* Return */
	return retval;
}

/**
 **************************************************************************************************
  @brief  Read CSI data (slave) 
  @param  [in]  ch    : Channel number 
    @arg 0      =channel0 
    @arg others =channel1 
  @param  [out] *data : Read data pointer 
  @return Error condition 
  @retval ER_OK     : Read complete 
  @retval ER_NOTYET : Read is not complete 
 **************************************************************************************************
 */
static ER_RET csi_slave_read(uint32_t ch, uint8_t* data)
{
	ER_RET retval;				/* return value */
	
	/* Read */
	if (CSI_RING_NOT_EMPTY(&csi_rx_ring[ch]))
	{
		/* ring-buffer is not empty, then read data */
		*data = CSI_RING_GETCHAR(&csi_rx_ring[ch]);
		retval = ER_OK;
	}
	else
	{
		/* data is not recieved (ring-buffer is empty) */
		retval = ER_NOTYET;
	}
	
	/* Return */
	return retval;
}

