/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_2.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_2_H_INCLUDED_
#define __R_IN32M4_2_H_INCLUDED_

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/



	#define	START_REG_START					(ULONG)0x00000001	
	#define	START_REG_STOP					(ULONG)0x00000000	

#define	MODE_REG_MYSTA_TXFRM_TIMING			ASIC_BIT1			
#define	MODE_REG_TX_FRMSNDMODE				ASIC_BIT8			
#define	MODE_REG_RSTOP_REPEATSTOP			ASIC_BIT9			
#define	MODE_REG_HEC_CHKDIS_NOTHECCHK		ASIC_BIT10			
#define	MODE_REG_DCS_CHKDIS_NOTDCSCHK		ASIC_BIT11			
#define	MODE_REG_SA_CHKDIS_NOTSACHK			ASIC_BIT12			
#define	MODE_REG_HEC_ADDDIS_NOTHECADD		ASIC_BIT13			
#define	MODE_REG_DCS_ADDDIS_NOTDCSADD		ASIC_BIT14			
#define	MODE_REG_FCS_ADDDIS_NOTFCSADD		ASIC_BIT15			
#define	MODE_REG_FLINKUP_FORCELINKUP		ASIC_BIT16			
#define	MODE_CLR							(ULONG)0x00000000
	#define	RING_TXFRM_0TIMING				0					
	#define	RING_TXFRM_1TIMING				1					
	#define	RING_TX_FRMSNDMODE_DI			0					
	#define	RING_TX_FRMSNDMODE_EI			1					
	#define	RING_REP_STOPMODE_EI			0					
	#define	RING_REP_STOPMODE_DI			1					
	#define	RING_HEC_CHK					0					
	#define	RING_HEC_NONCHK					1					
	#define	RING_DCS_CHK					0					
	#define	RING_DCS_NONCHK					1					
	#define	RING_SA_CHK						0					
	#define	RING_SA_NONCHK					1					
	#define	RING_HEC_ADD_EI					0					
	#define	RING_HEC_ADD_DI					1					
	#define	RING_DCS_ADD_EI					0					
	#define	RING_DCS_ADD_DI					1					
	#define	RING_FCS_ADD_EI					0					
	#define	RING_FCS_ADD_DI					1					
	#define	RING_LINKUP_NOMAL				0					
	#define	RING_LINKUP_FORCE				1					

#define	INT2_REG_PERSUASION_REC				ASIC_BIT1			
#define	INT2_REG_SETUP_REC_ACK				ASIC_BIT6			
#define	INT2_REG_LEAVE_TIMEOUT				ASIC_BIT17			
#define	INT2_INTCLR							(ULONG)(			 \
												  INT2_REG_PERSUASION_REC \
												| INT2_REG_SETUP_REC_ACK \
												| INT2_REG_LEAVE_TIMEOUT \
											)

#define	INTM2_REG_PERSUASION_REC_MSK		ASIC_BIT1			
#define	INTM2_REG_SETUP_REC_ACK_MSK			ASIC_BIT6			
#define	INTM2_REG_LEAVE_TIMEOUT_MSK			ASIC_BIT17			
#define	INTM2_ALLINTMASK_FULL				(ULONG)0xFFFFFFFF	


	#define	DATATXPORT_REG_TX_PORTALL			0				
	#define	DATATXPORT_REG_TX_PORT1				1				
	#define	DATATXPORT_REG_TX_PORT2				2				

#define	TESTDATAACK_FRAME_REG0_UNIT_TYPE_MASK		(ULONG)0x0000000F
#define	TESTDATAACK_FRAME_REG0_UNIT_EQUIPMENT_MASK	(ULONG)0x00000070
#define	TESTDATAACK_FRAME_REG0_MSTMEDIATION_MASK	(ULONG)0xFFFFFF00
#define	TESTDATAACK_FRAME_REG0_UNIT_EQUIPMENT_SHIFT	4
#define	TESTDATAACK_FRAME_REG0_MSTMEDIATION_SHIFT	8

#define	TESTDATAACK_FRAME_REG1_PROTOCOLCLASSIFICATION_MASK	(ULONG)0x00000F00
#define	TESTDATAACK_FRAME_REG1_PROTOCOLVERSION_MASK			(ULONG)0x0000F000
#define	TESTDATAACK_FRAME_REG1_PROTOCOLCLASSIFICATION_SHIFT	8
#define	TESTDATAACK_FRAME_REG1_PROTOCOLVERSION_SHIFT		12

#define	TESTDATAACK_FRAME_REG2_TOKENHOLDTIME_MASK		(ULONG)0x00007FFF
#define	TESTDATAACK_FRAME_REG2_MYSTATIONPORTNUM_MASK	(ULONG)0x00FF0000
#define	TESTDATAACK_FRAME_REG2_MYSTATIONPORTNUM_SHIFT	16

#define	SETUPACK_FRAME_REG0_PROTOCOLCLASSIFICATION_MASK		(ULONG)0x00000F00
#define	SETUPACK_FRAME_REG0_PROTOCOLVERSION_MASK			(ULONG)0x0000F000
#define	SETUPACK_FRAME_REG0_PROTOCOLCLASSIFICATION_SHIFT	8
#define	SETUPACK_FRAME_REG0_PROTOCOLVERSION_SHIFT			12

#define	SETUPACK_FRAME_REG1_MODELTYPE_MASK		(ULONG)0x0000FFFF
#define	SETUPACK_FRAME_REG1_VERSION_MASK		(ULONG)0x00FF0000
#define	SETUPACK_FRAME_REG1_STATIONINFO_MASK	(ULONG)0x03000000
#define	SETUPACK_FRAME_REG1_VERSION_SHIFT		16
#define	SETUPACK_FRAME_REG1_STATIONINFO_SHIFT	24

#define	SETUPACK_FRAME_REG2_VENDOR_CODE_MASK	(ULONG)0x0000FFFF

#define	SETUPACK_FRAME_REG4_RWW_SIZE_MASK		(ULONG)0x0000FFFF
#define	SETUPACK_FRAME_REG4_RY_SIZE_MASK		(ULONG)0xFFFF0000
#define	SETUPACK_FRAME_REG4_RY_SIZE_SHIFT		16

#define	SETUPACK_FRAME_REG5_RWR_SIZE_MASK		(ULONG)0x0000FFFF
#define	SETUPACK_FRAME_REG5_RX_SIZE_MASK		(ULONG)0xFFFF0000
#define	SETUPACK_FRAME_REG5_RX_SIZE_SHIFT		16

#define	SETUPACK_FRAME_REG6_TRANSIENTRECV_MODE		ASIC_BIT8
#define	SETUPACK_FRAME_REG6_STATION_MODE			ASIC_BIT9
#define	SETUPACK_FRAME_REG6_TRANRECFUNCTION_MASK	(ULONG)0x0000FF00
#define	SETUPACK_FRAME_REG6_TRANSIENTRECV_MODE_SHIFT	8
#define	SETUPACK_FRAME_REG6_STATION_MODE_SHIFT		9
#define	SETUPACK_FRAME_REG6_OPTION_SUPPORT			ASIC_BIT7
#define	SETUPACK_FRAME_REG6_SLMP_SUPPORT			ASIC_BIT14
#define	SETUPACK_FRAME_REG6_OPTION_SUPPORT_SHIFT	7
#define	SETUPACK_FRAME_REG6_SLMP_SUPPORT_SHIFT		14
#define	SETUPACK_FRAME_REG6_SYNC_SUPPORT			ASIC_BIT0
#define	SETUPACK_FRAME_REG6_SYNC_SUPPORT_SHIFT		0
#define	SETUPACK_FRAME_REG6_DEVICE_SET				ASIC_BIT1
#define	SETUPACK_FRAME_REG6_DEVICE_SET_SHIFT		1
#define	SETUPACK_FRAME_REG6_DEVICE_INIT				ASIC_BIT2
#define	SETUPACK_FRAME_REG6_DEVICE_INIT_SHIFT		2
#define	SETUPACK_FRAME_REG6_SYNC2_SUPPORT			ASIC_BIT5
#define	SETUPACK_FRAME_REG6_SYNC2_SUPPORT_SHIFT		5

#define	SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT			ASIC_BIT25
#define	SETUPACK_FRAME_REG7_SLMP_DIAGNOSIS_SUPPORT_SHIFT	25
#define	SETUPACK_FRAME_REG7_SYNC_SET_FOLLOWUP				ASIC_BIT24
#define	SETUPACK_FRAME_REG7_SYNC_SET_FOLLOWUP_SHIFT			24
#define	SETUPACK_FRAME_REG7_SYNC3_SUPPORT					ASIC_BIT26
#define	SETUPACK_FRAME_REG7_SYNC3_SUPPORT_SHIFT				26

#define	SU_INF_SETUP_FRAME_NODE_ID_MASK			(ULONG)0xFFFF0000
#define	SU_INF_SETUP_FRAME_NODE_ID_SHIFT		16

#define	SU_INF_SETUP_FRAME_MAC_ADR_MASK			(ULONG)0x0000FFFF

#define	SU_INF_SETUP_FRAME_PORT_ENABLE_MASK		(ULONG)0x0000FF00
#define	SU_INF_SETUP_FRAME_LEAVE_TIMER_MASK		(ULONG)0xFFFF0000
#define	SU_INF_SETUP_FRAME_PORT_ENABLE_SHIFT	8
#define	SU_INF_SETUP_FRAME_LEAVE_TIMER_SHIFT	16

#define	SU_INF_SETUP_FRAME_TOKEN_TRANS_MASK		(ULONG)0x000000FF
#define	SU_INF_SETUP_FRAME_SEND_TRANS_MASK		(ULONG)0x00FF0000
#define	SU_INF_SETUP_FRAME_TOKEN_HOLDING_MASK	(ULONG)0xFF000000
#define	SU_INF_SETUP_FRAME_SEND_TRANS_SHIFT		16
#define	SU_INF_SETUP_FRAME_TOKEN_HOLDING_SHIFT	24

	#define	SU_INF_DEFAULT_TKNSEND_COUNT		2
	#define	SU_INF_DEFAULT_FRAME_INTERVAL		1
	#define	SU_INF_DEFAULT_FRESEND_COUNT		2

	#define	SU_INF_DEFAULT_LEAVETIMER			2000

#define	RINGPHASE_REG_PHASE_INITIAL			(ULONG)0x00000001	
#define	RINGPHASE_REG_PHASE_LISTEN			(ULONG)0x00000002	
#define	RINGPHASE_REG_PHASE_WAITTD			(ULONG)0x00000003	
#define	RINGPHASE_REG_PHASE_WAITSETUP		(ULONG)0x00000004	
#define	RINGPHASE_REG_PHASE_SOLISITTOKEN	(ULONG)0x00000005	
#define	RINGPHASE_REG_PHASE_HOLDTOKEN		(ULONG)0x00000006	
#define	RINGPHASE_REG_PHASE_MASTER			(ULONG)0x00000007	

#define	MIB_CLR_REG_MIB_CLR					ASIC_BIT0			

#define	LINKSTAT_REG_P1_0_LINKUP			ASIC_BIT0			
#define	LINKSTAT_REG_P1_1_10MBPSLINK		ASIC_BIT1			
#define	LINKSTAT_REG_P1_2_100MBPSLINK		ASIC_BIT2			
#define	LINKSTAT_REG_P1_3_1000MBPSLINK		ASIC_BIT3			
#define	LINKSTAT_REG_P1_4_FULLLINK			ASIC_BIT4			
#define	LINKSTAT_REG_P2_0_LINKUP			ASIC_BIT16			
#define	LINKSTAT_REG_P2_1_10MBPSLINK		ASIC_BIT17			
#define	LINKSTAT_REG_P2_2_100MBPSLINK		ASIC_BIT18			
#define	LINKSTAT_REG_P2_3_1000MBPSLINK		ASIC_BIT19			
#define	LINKSTAT_REG_P2_4_FULLLINK			ASIC_BIT20			

#define	MACIP_ACCESS_ENABLE					ASIC_BIT0			
#define	MACIP_ACCESS_DISABLE				~ASIC_BIT0			
#define	MACIP_POLLING_CNT					0x000000F0			
#define	MACIP_P1_PHAY_ADDRESS				0					
#define	MACIP_P1_PHAY_ADDRESS_SHIFT			8
#define	MACIP_P1_PHAY_ADDRESS_MASK			(ULONG)0x00001F00
#define	MACIP_POLLING_TIME					0x000F0000			
#define	MACIP_P2_PHAY_ADDRESS				1					
#define	MACIP_P2_PHAY_ADDRESS_SHIFT			24
#define	MACIP_P2_PHAY_ADDRESS_MASK			(ULONG)0x1F000000


#define	FTYPE_Persuasion					0x10				
#define	FTYPE_TestData						0x11				
#define	FTYPE_TestDataAck					0x12				
#define	FTYPE_Setup							0x13				
#define	FTYPE_SetupAck						0x14				
#define	FTYPE_Token							0x15				
#define	FTYPE_MyStatus						0x20				
#define	FTYPE_CyclicRWw						0x82				
#define	FTYPE_CyclicRY						0x83				
#define	FTYPE_CyclicRWr						0x84				
#define	FTYPE_CyclicRX						0x85				
#define	FTYPE_Transient2					0x25				
#define	FTYPE_Transient1					0x22				
#define	FTYPE_ParamCheck					0x28				
#define	FTYPE_REG4_Reserved1				0x2B				
#define	FTYPE_REG4_Reserved2				0x2A				
#define	FTYPE_Parameter						0x29				
#define	FTYPE_Timer							0x1C				
#define	FTYPE_REG5_Reserved1				0x4					
#define	FTYPE_REG5_Reserved2				0xC					

#define	FTYPE_TransientAck					0x23				
#define	FTYPE_Dummy							0x24				



#define	MCMD_REG_MDIO_ON					ASIC_BIT0			
#define	MCMD_REG_RW_READ					ASIC_BIT1			
#define	MCMD_INTCLR							(ULONG)0x00000000

#define	MDCK_REG_CLOCK_7812					(ULONG)0x00000001	
#define	MDCK_REG_CLOCK_3906					(ULONG)0x00000002	
#define	MDCK_REG_CLOCK_2604					(ULONG)0x00000003	
#define	MDCLKSET_INTCLR						(ULONG)0x00000000

#define	MIB_CLR_REG_CNT_CLR					ASIC_BIT0			
#define	MIB_IP_CLR_INTCLR					(ULONG)0x00000001


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/


typedef struct _START_REG_TAG {
	ULONG	b01ZStart:						1;			
	ULONG	b1FZReserve1:					31;			
} START_REG_T;

typedef struct _MODE_REG_TAG {
	ULONG	b01ZReserve1:					1;			
	ULONG	b01Zdtx_tim:					1;			
	ULONG	b06ZReserve1:					6;			
	ULONG	b01ZTx:							1;			
	ULONG	b01ZRStop:						1;			
	ULONG	b01ZHec_Chkdis:					1;			
	ULONG	b01ZDcs_Chkdis:					1;			
	ULONG	b01ZSa_Chkdis:					1;			
	ULONG	b01ZHec_Adddis:					1;			
	ULONG	b01ZDcs_Adddis:					1;			
	ULONG	b01ZFcs_Adddis:					1;			
	ULONG	b01ZFlinkUp:					1;			
	ULONG	b0FZReserve2:					15;			
} MODE_REG_T;

typedef struct _INT2_TAG {
	ULONG	b01ZReserve1:					1;			
	ULONG	b01ZPer_Rcv:					1;			
	ULONG	b04ZReserve2:					4;			
	ULONG	b01ZSu_At_Rcv:					1;			
	ULONG	b0AZReserve3:					10;			
	ULONG	b01ZLeave_To:					1;			
	ULONG	b0EZReserve4:					14;			
} INT2_T;

typedef struct _INTM2_TAG {
	ULONG	b01ZReserve1:					1;			
	ULONG	b01ZPer_Msk:					1;			
	ULONG	b04ZReserve2:					4;			
	ULONG	b01ZSu_At_Msk:					1;			
	ULONG	b0AZReserve3:					10;			
	ULONG	b01ZLeave_Msk:					1;			
	ULONG	b0EZReserve4:					14;			
} INTM2_T;

typedef struct _DATATXPORT_REG_TAG {
	ULONG	b02ZTx_Port:					2;			
	ULONG	b1EZReserve1:					30;			
} DATATXPORT_REG_T;


typedef struct _TESTDATAACK_FRAME_REG0_TAG {
	ULONG	b08ZStationUnitInformation:		8;			
	ULONG	b18ZMstMediationPriority:		24;			
} TESTDATAACK_FRAME_REG0_T;

typedef struct _TESTDATAACK_FRAME_REG1_TAG {
	ULONG	b08ZReserve1:					8;			
	ULONG	b04ZProtocolClassification:		4;			
	ULONG	b04ZProtocolVersion:			4;			
	ULONG	b10ZReserve1:					16;			
} TESTDATAACK_FRAME_REG1_T;

typedef struct _TESTDATAACK_FRAME_REG2_TAG {
	ULONG	b0FZTokenHoldTime:				15;			
	ULONG	b01ZReserve1:					1;			
	ULONG	b08ZMyStationPortNum:			8;			
	ULONG	b08ZReserve2:					8;			
} TESTDATAACK_FRAME_REG2_T;

typedef struct _TESTDATAACK_FRAME_REG3_TAG {
	ULONG	ulReserve1:						32;			
} TESTDATAACK_FRAME_REG3_T;

typedef struct _SETUPACK_FRAME_REG0_TAG {
	ULONG	b08ZReserve0:					8;			
	ULONG	b04ZProtocolClassification:		4;			
	ULONG	b04ZProtocolVersion:			4;			
	ULONG	b10ZReserve1:					16;			
} SETUPACK_FRAME_REG0_T;

typedef struct _SETUPACK_FRAME_REG1_TAG {
	ULONG	b10ZModelType:					16;			
	ULONG	b08ZVersion:					8;			
	ULONG	b02ZStationInformation:			2;			
	ULONG	b06ZReserve1:					6;			
} SETUPACK_FRAME_REG1_T;

typedef struct _SETUPACK_FRAME_REG2_TAG {
	ULONG	b10ZVendorCode:					16;			
	ULONG	b10ZReserve1:					16;			
} SETUPACK_FRAME_REG2_T;

typedef struct _SETUPACK_FRAME_REG3_TAG {
	ULONG	ulUnitModelCode:				32;			
} SETUPACK_FRAME_REG3_T;

typedef struct _SETUPACK_FRAME_REG4_TAG {
	ULONG	b10ZRWwSize:					16;			
	ULONG	b10ZRySize:						16;			
} SETUPACK_FRAME_REG4_T;

typedef struct _SETUPACK_FRAME_REG5_TAG {
	ULONG	b10ZRWrSize:					16;			
	ULONG	b10ZRxSize:						16;			
} SETUPACK_FRAME_REG5_T;

typedef struct _SETUPACK_FRAME_REG6_TAG {
	ULONG	b01ZSync:						1;			
	ULONG	b01ZDeviceSet:					1;			
	ULONG	b01ZDEviceInit:					1;			
	ULONG	b1OptionSupp:					1;			
	ULONG	b1TranRecvMode:					1;			
	ULONG	b1PrmChgStNo:					1;			
	ULONG	b4ZReserve2:					4;			
	ULONG	b1SlmpSupp:						1;			
	ULONG	b17ZReserve3:					17;			
} SETUPACK_FRAME_REG6_T;

typedef struct _SETUPACK_FRAME_REG7_TAG {
	ULONG	ulReserve1:						24;			
	ULONG	b01ZSyncSetFollowup:			1;			
	ULONG	b1SlmpDiagnosisSupp:			1;			
	ULONG	b01ZSync3:						1;			
	ULONG	ulReserve2:						5;			
} SETUPACK_FRAME_REG7_T;

typedef struct _SETUP_INF_REG0_TAG {
	ULONG	b10ZReserve1:					16;			
	ULONG	b10ZSu_Inf2:					16;			
} SETUP_INF_REG0_T;

typedef struct _SETUP_INF_REG1_TAG {
	ULONG	ulSu_Inf3:						32;			
} SETUP_INF_REG1_T;

typedef struct _SETUP_INF_REG2_TAG {
	ULONG	usSu_Inf4:						16;			
	ULONG	b10ZReserve1:					16;			
} SETUP_INF_REG2_T;

typedef struct _SETUP_INF_REG3_TAG {
	ULONG	b08ZReserve1:					8;			
	ULONG	b08ZSu_Inf6:					8;			
	ULONG	b10ZSu_Inf7:					16;			
} SETUP_INF_REG3_T;

typedef struct _SETUP_INF_REG4_TAG {
	ULONG	b08ZSu_Inf13:					8;			
	ULONG	b08ZReserve0:					8;			
	ULONG	b08ZSu_Inf9:					8;			
	ULONG	b08ZSu_Inf8:					8;			
} SETUP_INF_REG4_T;

typedef struct _RINGPHASE_REG_TAG {
	ULONG	b03ZPhase:						3;			
	ULONG	b1DZReserve1:					29;			
} RINGPHASE_REG_T;

typedef struct _MIB_CLR_REG_TAG {
	ULONG	b01ZMib_Clr:					1;			
	ULONG	b1FZReserve1:					31;			
} MIB_CLR_REG_T;

typedef struct _LINKSTAT_REG_TAG {
	ULONG	b01ZP1_0:						1;			
	ULONG	b01ZP1_1:						1;			
	ULONG	b01ZP1_2:						1;			
	ULONG	b01ZP1_3:						1;			
	ULONG	b01ZP1_4:						1;			
	ULONG	b0BZReserve1:					11;			
	ULONG	b01ZP2_0:						1;			
	ULONG	b01ZP2_1:						1;			
	ULONG	b01ZP2_2:						1;			
	ULONG	b01ZP2_3:						1;			
	ULONG	b01ZP2_4:						1;			
	ULONG	b0BZReserve2:					11;			
} LINKSTAT_REG_T;

typedef struct _MACIPACCESS_REG_TAG {
	ULONG	b01ZAcc_En:						1;			
	ULONG	b03ZReserve1:					3;			
	ULONG	b04ZPolling_cnt:				4;			
	ULONG	b05ZP1_Phyadd:					5;			
	ULONG	b03ZReserve2:					3;			
	ULONG	b08ZPolling_Time:				8;			
	ULONG	b05ZP2_Phyadd:					5;			
	ULONG	b03ZReserve3:					3;			
} MACIPACCESS_REG_T;

typedef struct _FTYPE_REG1_TAG {
	ULONG	b08ZFType_Persuasion:			8;			
	ULONG	b08ZFType_TestData:				8;			
	ULONG	b08ZFType_TestDataAck:			8;			
	ULONG	b08ZFType_Setup:				8;			
} FTYPE_REG1_T;

typedef struct _FTYPE_REG2_TAG {
	ULONG	b08ZFType_SetupAck:				8;			
	ULONG	b08ZFType_Token:				8;			
	ULONG	b08ZFType_MyStatus:				8;			
	ULONG	b08ZFType_CyclicRWw:			8;			
} FTYPE_REG2_T;

typedef struct _FTYPE_REG3_TAG {
	ULONG	b08ZFType_CyclicRY:				8;			
	ULONG	b08ZFType_CyclicRWr:			8;			
	ULONG	b08ZFType_CyclicRX:				8;			
	ULONG	b08ZFType_Transient2:			8;			
} FTYPE_REG3_T;

typedef struct _FTYPE_REG4_TAG {
	ULONG	b08ZFType_Transient1:			8;			
	ULONG	b08ZFType_ParamCheck:			8;			
	ULONG	b08ZFType_REG4_Reserved1:		8;			
	ULONG	b08ZFType_REG4_Reserved2:		8;			
} FTYPE_REG4_T;

typedef struct _FTYPE_REG5_TAG {
	ULONG	b08ZFType_Parameter:			8;			
	ULONG	b08ZFType_Timer:				8;			
	ULONG	b04ZFType_REG5_Reserved1:		4;			
	ULONG	b04ZFType_REG5_Reserved2:		4;			
	ULONG	b08ZReserve0:					8;			
} FTYPE_REG5_T;


typedef struct _MCMD_REG_TAG {
	ULONG	b01ZON_OFF:						1;			
	ULONG	b01ZR_W:						1;			
	ULONG	b1EZReserve1:					30;			
} MCMD_REG_T;

typedef struct _MPHYADR_REG_TAG {
	ULONG	b05ZPHY_ADR:					5;			
	ULONG	b1AZReserve1:					27;			
} MPHYADR_REG_T;

typedef struct _MPHYRADR_REG_TAG {
	ULONG	b05ZREG_ADR:					5;			
	ULONG	b1AZReserve1:					27;			
} MPHYRADR_REG_T;

typedef struct _MPHYWD_REG_TAG {
	ULONG	b10ZWr_DATA:					16;			
	ULONG	b10ZReserve1:					16;			
} MPHYWD_REG_T;

typedef struct _MPHYRD_REG_TAG {
	ULONG	b10ZRD_DATA:					16;			
	ULONG	b10ZReserve1:					16;			
} MPHYRD_REG_T;

typedef struct _MDCLKSET_REG_TAG {
	ULONG	b02ZMDCK:						2;			
	ULONG	b1CZReserve1:					30;			
} MDCLKSET_REG_T;

typedef struct _MIB_IP_CLR_REG_TAG {
	ULONG	b01ZMIB_CLR:					1;			
	ULONG	b1FZReserve1:					31;			
} MIB_IP_CLR_REG_T;


typedef struct _RING_TAG {
	ULONG		ulStart;								
	ULONG		ulMode;									
	ULONG		ulMACAddress0;							
	ULONG		ulMACAddress1;							
	ULONG		ulReserved0010[(0x0014-0x0010)/4];		
	ULONG		ulInt2;									
	ULONG		ulIntM2;								
	ULONG		ulReserved001C[(0x0024-0x001C)/4];		
	ULONG		ulMultiAddReg0;							
	ULONG		ulMultiAddReg1;							
	ULONG		ulDataTxPort;							
	ULONG		ulReserved0030[(0x0070-0x0030)/4];		
	ULONG		ulTestDataAck_Frame0;					
	ULONG		ulTestDataAck_Frame1;					
	ULONG		ulTestDataAck_Frame2;					
	ULONG		ulTestDataAck_Frame3;					
	ULONG		ulSetupAck_Frame0;						
	ULONG		ulSetupAck_Frame1;						
	ULONG		ulSetupAck_Frame2;						
	ULONG		ulSetupAck_Frame3;						
	ULONG		ulSetupAck_Frame4;						
	ULONG		ulSetupAck_Frame5;						
	ULONG		ulSetupAck_Frame6;						
	ULONG		ulSetupAck_Frame7;						
	ULONG		ulReserved00A0[(0x0100-0x00A0)/4];		
	ULONG		ulSetup_Inf0;							
	ULONG		ulSetup_Inf1;							
	ULONG		ulSetup_Inf2;							
	ULONG		ulSetup_Inf3;							
	ULONG		ulSetup_Inf4;							
	ULONG		ulSetup_RxP;							
	ULONG		ulReserved0118[(0x0120-0x0118)/4];		
	ULONG		ulRingPhase;							
	ULONG		ulReserved0124[(0x0200-0x0124)/4];		
	ULONG		aulMib1Reg[7];							
	ULONG		ulReserved021C[(0x0280-0x021C)/4];		
	ULONG		aulMib2Reg[7];							
	ULONG		ulReserved029C[(0x02CC-0x029C)/4];		
	ULONG		ulMib_Clr;								
	ULONG		ulReserved02D0[(0x0300-0x02D0)/4];		
	ULONG		ulLinkStat;								
	ULONG		ulMacIpAccess;							
	ULONG		ulReserved0308[(0x0400-0x0308)/4];		
	ULONG		ulFType1;								
	ULONG		ulFType2;								
	ULONG		ulFType3;								
	ULONG		ulFType4;								
	ULONG		ulFType5;								
	ULONG		ulReserved0414[(0x0600-0x0414)/4];		
} RING_T;


typedef struct _MAC_IP_TAG {
	ULONG		ulReserved0000[(0x0040-0x0000)/4];		
	ULONG		ulMcmd;									
	ULONG		ulMPhyAdr;								
	ULONG		ulMPhyRAdr;								
	ULONG		ulMPhyWD;								
	ULONG		ulMPhyRD;								
	ULONG		ulMDClkSet;								
	ULONG		ulReserved0058[(0x0070-0x0058)/4];		
	ULONG		ulMib_Ip_Clr;							
	ULONG		ulReserved0074[(0x0080-0x0074)/4];		
	ULONG		ulRFrm;									
	ULONG		ulTFrm;									
	ULONG		ulRUnd;									
	ULONG		ulROvr;									
	ULONG		ulRFcs;									
	ULONG		ulRFgm;									
	ULONG		ulRIFGErr;								
	ULONG		ulREps;									
	ULONG		ulRCde;									
	ULONG		ulRFce;									
	ULONG		ulRCEE;									
	ULONG		ulReserved00AC[(0x0100-0x00AC)/4];		
} MAC_IP_T;

typedef struct _GIGAMAC_TAG {
	MAC_IP_T					MAC_IP1;								
	MAC_IP_T					MAC_IP2;								
	ULONG						ulMacIpAccess;							
	ULONG						ulNum;									
} GIGAMAC_T;

#endif	/* __R_IN32M4_2_H_INCLUDED_ */

/*** EOF ***/
