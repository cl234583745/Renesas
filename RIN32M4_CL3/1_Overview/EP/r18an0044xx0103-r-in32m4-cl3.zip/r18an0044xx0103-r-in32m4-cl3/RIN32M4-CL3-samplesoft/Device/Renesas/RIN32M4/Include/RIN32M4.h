/**
 *******************************************************************************
 * @file  RIN32M4.h
 * @brief 
 *
 * @note
 * Copyright (C) 2015 Renesas Electronics Corporation
 *
 * @par
 *  This is a sample program.
 *  Renesas Electronics assumes no responsibility for any losses incurred.
 *
 *******************************************************************************
 */
#ifndef	__RIN32M4_H
#define __RIN32M4_H

#ifdef __cplusplus
extern "C" {
#endif 

#include "RIN32M4_CL3.h"

// Comment out "TS_TCS08467" when using TS-TCS07908.
#define TS_TCS08467			// SBEV-RIN32M4CL3, TS-TCS08467
#ifdef  TS_TCS08467
#define R9A06G064SGBG_EN	// 17mm PKG
#endif


#ifdef __cplusplus
}
#endif 

#endif	/* __RIN32M4_H */
