/**
 *******************************************************************************
 * @file  main.c
 * @brief CAN sample program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <stdio.h>

#include "RIN32M4.h"

#include "uart/uart.h"
#include "can/can.h"
#include "board_init.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/* Buffer number */
#define	TxData_00	CAN_Msg000
#define	RxData_00	CAN_Msg032



/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
volatile uint8_t	rx_flg[CAN_CH_NUM];

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static void can_sample( void );

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************
  @brief  Main program
  @param  none
  @retval none
 *******************************************************************************
*/
int main( void )
{
	//=========================================
	// Initialize System
	//=========================================
	board_init();

	// --- Initialize UART ---
	uart_init(SYS_UART_CH);

	// --- Display Opening message
	rin_boot_message();

	//=========================================
	// Execute application program
	//=========================================
	can_sample();						/* CAN sample application */

	return 0;
}

/**
 *******************************************************************************
  @brief  CAN communication sample
  @param  none
  @retval none
 *******************************************************************************
*/
static void can_sample( void )
{
	uint8_t	ch = CAN_CH0;
	ER_RET	ercd;
	uint8_t	txDatabuf[ 8 ];
	uint8_t	rxDatabuf[ 8 ];
	uint8_t	index;
	uint8_t	bufno;
	uint8_t	rxDlc;	/* reception data length */

	/**********************************************/
	/* CAN Initialize                             */
	/**********************************************/
	/* Enable CAN controler */
	if(  can_enable( ch ) != ER_OK ) {
		printf("CAN controler Enable error!!\n");
		return;
	}

	/* Initialize CAN controler */
	if( can_init( ch ) != ER_OK ) {
		printf("CAN controler Initialize error!!\n");
		return;
	}

	/* Set CAN operation mode(Loop back mode) */
//	if( can_set_mode(ch , SET_CAN_SELF) != ER_OK ) {
	if( can_set_mode(ch , SET_CAN_NORM) != ER_OK ) {
		printf("CAN operation mode setting error!!\n");
		return;
	}

	/* Enable interrupt */
	rx_flg[ch] = 0;
	if(ch == CAN_CH0){
		NVIC_EnableIRQ(FCN0REC_IRQn);
	}else{
		NVIC_EnableIRQ(FCN1REC_IRQn);
	}
	printf("CAN contoler Initialized!\n");

	/**********************************************/
	/* CAN Transmit                               */
	/**********************************************/
	/* Get transmit info */
	ercd = can_get_txinfo( ch, TxData_00 );
	if( ercd == ER_BUSY ) {
		printf("CAN transmit busy\n");
		return;
	} else if( ercd != ER_OK ){
		printf("CAN paramter error\n");
		return;
	}
	printf("CAN transmit buffer empty\n");

	/* create transmit data */
	printf("CAN create transmit data\n");
	for(index = 0; index < 8; index++){
		txDatabuf[ index ] = index * 0x11;
		printf("--- CAN ch%d: Tx data[ %d ] = 0x%02X ----\n", ch, index, txDatabuf[index] );
	}

	/* Set transmit data to message buffer */
	if( can_set_data( ch, TxData_00, &txDatabuf[0] ) != ER_OK ){
		printf("CAN transmit data setting error!!\n");
		return;
	}

	/* Transmit request */
	printf("CAN transmit start..\n");
	if( can_tx_req( ch, TxData_00) != ER_OK ){
		printf("CAN transmit request error!!\n");
		return;
	}

	/* Wait for transmit complete */
	while(can_get_txinfo( ch, TxData_00 ) == ER_BUSY){
	};
	printf("CAN transmit complete\n");

	/**********************************************/
	/* CAN Reception                              */
	/**********************************************/
	// --- Wait for reception data ---
	printf("CAN reception data wait..\n");
	while (rx_flg[ch] != 1)
	{
		__NOP();
	}
	rx_flg[ch] = 0;
	printf("CAN reception interrupt\n");

	/* Search reception message */
	ercd = can_get_rxinfo( ch, RxData_00 );
	if(ercd < 0){
		printf("CAN none reception data\n");
		return;
	}
	bufno = ercd;
	printf("CAN reception message buffer number = %d\n",bufno);

	/* Get reception data */
	if( can_get_data_dlc( ch, bufno, &rxDatabuf[0], &rxDlc ) != ER_OK ){
		printf("CAN reception data get error!!\n");
		return;
	}

	/* Display reception data */
	for ( index = 0; index < rxDlc; index++ ) {
		printf("--- CAN ch%d: Rx data[ %d ] = 0x%02X ----\n", ch, index, rxDatabuf[index] );
	}

	/**********************************************/
	/* CAN check status                           */
	/**********************************************/
	printf("CAN check status\n");
	ercd =  can_get_ch_status(ch);
	if( ercd < 0 ) {
		printf("CAN status get error!!\n");
		return;
	}
	if( ercd & CAN_STS_TXEND){
		printf("- CAN transmit success!\n");
	}
	if( ercd & CAN_STS_RXEND){
		printf("- CAN reception success!\n");
	}
	if( (ercd & (CAN_STS_ERRSTS | CAN_STS_PRTERR | CAN_STS_ABL | CAN_STS_WAK | CAN_STS_TXA)) == 0) {
		printf("- CAN no error!\n");
	}
	if( can_clr_ch_status(ch , CAN_STS_ALL) != ER_OK ) {
		printf("CAN status clear error!!\n");
		return;
	}
}

/**
 *******************************************************************************
 
  @brief  CAN recieve interrupt handler (chnnel 0)
  @param  none
  @retval none
 
 *******************************************************************************
*/
void FCN0REC_IRQHandler( void )
{
	rx_flg[CAN_CH0] = 1;
}

/**
 *******************************************************************************
 
  @brief  CAN recieve interrupt handler (channel 1)
  @param  none
  @retval none
 
 *******************************************************************************
*/
void FCN1REC_IRQHandler( void )
{
	rx_flg[CAN_CH1] = 1;
}

