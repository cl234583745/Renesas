/***********************************************************************
                  ��Net3 Network sample program

    Copyright (c) 2013 eForce Co., Ltd. All rights reserved.
    2013-11-20: Created.
    2015-09-18: Callback function does not use printf().
 ***********************************************************************/

#include "string.h"
#include "kernel.h"
#include "kernel_id.h"
#include "net_hdr.h"
#include "http_server.h"
#include "html.h"
#include "dhcp_client.h"
#include "snmp.h"
#include "snmp_lib.h"
#include <stdio.h>


/*******************************
        CGI Script definition
 *******************************/
extern void sample_fnc(T_HTTP_SERVER *http);

/*******************************
    HTTP Content List
 *******************************/
T_HTTP_FILE const content_list[] =
{
    {"/", "text/html", index_html1, sizeof(index_html1), NULL},
    {"/sample.cgi", "", NULL, 0, sample_fnc},
    {"", "", NULL, 0, NULL}
};

/*******************************
  HTTP Server Task
 *******************************/
static T_HTTP_SERVER http_server1;

void httpd_tsk(VP_INT exinf)
{ 
    T_NODE host;

    gHTTP_FILE = (T_HTTP_FILE*)content_list;
    net_memset((char* )&http_server1, 0, sizeof(http_server1));

    /* Listen from IPv4 address */
    http_server1.ver = IP_VER4;

    host.num  = 1;
    host.ver  = http_server1.ver;
#ifdef IPV6_SUP
    if(host.ver == IP_VER6)
        net_memset(host.ip6a, 0, 16);
    else
#endif
    host.ipa  = INADDR_ANY;
    host.port = 80;
    http_server1.SocketID = cre_soc(IP_PROTO_TCP, &host);
    if (http_server1.SocketID <= 0) {
        return;
    }

    /* Set Timeout's */
    cfg_soc(http_server1.SocketID, SOC_TMO_SND, (VP)25000);
    cfg_soc(http_server1.SocketID, SOC_TMO_RCV, (VP)25000);
    cfg_soc(http_server1.SocketID, SOC_TMO_CLS, (VP)25000);

    http_server(&http_server1);
    
    cls_soc( http_server1.SocketID, 0 );
    del_soc( http_server1.SocketID );
}

/*******************************
  SNMP Callback Function
 *******************************/
extern T_SNMP_MIB_TBL snmp_mib_ven[];         /* Vendor MIB */

ER snmp_usr_cbk(T_SNMP_CFG_CBK_DAT* cbk_dat)
{
    UW* dat;

    /* Print callback data */

    printf("  Request type: ");
    if (cbk_dat->req == SNMP_REQ_GET) {
        printf("SNMP_REQ_GET\r\n");
    } else if (cbk_dat->req == SNMP_REQ_SET) {
        printf("SNMP_REQ_SET\r\n");
    }

    printf("  OID: ");
    printf(snmp_mib_ven[cbk_dat->mib_id].pre);
    printf(snmp_mib_ven[cbk_dat->mib_id].mib[cbk_dat->obj_id].str);
    printf("\r\n");

    printf("  Vendor MIB ID: %d : %d\r\n", cbk_dat->mib_id, cbk_dat->obj_id);

    printf("  Data: ");
    dat = (UW*)cbk_dat->buf;
    if (snmp_mib_ven[cbk_dat->mib_id].mib[cbk_dat->obj_id].typ == TYP_OCT_STR) {
        printf("%s\r\n", (char *)dat);
    } else {
        printf("%d\r\n", *dat);
    }

    printf("  Size: %d  (Buffer size: %d)\r\n", cbk_dat->dat_len, cbk_dat->buf_len);
    return E_OK;
}

#define DHCP_ENA    1

ER net_sample(void)
{
    /* Initialize TCP/IP Stack */
    ER ercd;
#if DHCP_ENA
    int i;
    T_HOST_ADDR dhcp_addr[1];
    T_NODE host;
#endif
    T_NET_ADR adr;
    UW str_buf[32];
    VB* buf;

    printf("- uNet3 lib ver%s\n",unet3_get_version(1));
    printf("- uNet3 snmp lib ver%s\n",unet3snmp_get_version(1));
    printf("---- Sample Program ----\r\n");

    ercd = net_ini();
    if (ercd != E_OK) {
        return ercd;
    }

    /* SNMP */
    ercd = snmp_ini(0x00);
    if (ercd != E_OK) {
        return ercd;
    }

    /* Initialize Ethernet Driver */
    ercd = net_dev_ini(1);
    if (ercd != E_OK) {
        return ercd;
    }

    /* Resolve IP Address */
#if DHCP_ENA
    net_memset(&dhcp_addr[0], 0, sizeof(T_HOST_ADDR));
    dhcp_addr[0].dev_num = 1;
    host.num  = dhcp_addr[0].dev_num;
    host.ipa  = INADDR_ANY;
    host.port = 68;         /*BOOTP PORT*/
    host.ver  = IP_VER4;
    dhcp_addr[0].socid = cre_soc(IP_PROTO_UDP, &host);
    if (dhcp_addr[0].socid <= 0) {
        ercd = (ER)dhcp_addr[0].socid;
        return ercd;
    }
    /* Set Timeout */
    ercd = cfg_soc(dhcp_addr[0].socid, SOC_TMO_SND, (VP)5000);
    if (ercd != E_OK) {
        cls_soc( dhcp_addr[0].socid, 0 );
        del_soc( dhcp_addr[0].socid );
        return ercd;
    }
    ercd = cfg_soc(dhcp_addr[0].socid, SOC_TMO_RCV, (VP)5000);
    if (ercd != E_OK) {
        cls_soc( dhcp_addr[0].socid, 0 );
        del_soc( dhcp_addr[0].socid );
        return ercd;
    }
    for (i = 0; i < 10; i++) {
        ercd = dhcp_client(&dhcp_addr[0]);
        if (ercd == E_OK) {
            break;
        }
        tslp_tsk(1000);
    }
    cls_soc( dhcp_addr[0].socid, 0 );
    del_soc( dhcp_addr[0].socid );
    if (ercd == E_TMOUT) {
        ercd = E_OK;
    }
    if (ercd != E_OK) {
        return ercd;
    }
#endif

    ercd = snmp_ena();
    if (ercd != E_OK) {
        return ercd;
    }

    /* My IP address */
    ercd = net_ref(1, NET_IP4_CFG, &adr);
    if (ercd != E_OK) {
        return ercd;
    }
    buf = (VB*)str_buf;
    ip_ntoa(buf, adr.ipaddr);
    printf("  [IP Address ]: %s\r\n", buf);

    /* start WEB server*/
    ercd = sta_tsk(ID_TASK_HTTPS, 0);
    return ercd;	

}
