/***********************************************************************
    Standard 10/100baseT PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
    2014/09/03: Fixed procedure of set and get PHY mode
    2015/01/29: Modified to wait for release of reset.
 ***********************************************************************/

#include "RIN32M4.h"
#include "kernel.h"
#include "ether/eth_hwfnc.h"
#include "ether_unet3/DDR_PHY.h"


#ifdef LIB_ETHDRIVER
/* defined symbol -> external const variable */
extern   ID ID_TASK_PHY0_LINK_C;
#define  ID_TASK_PHY0_LINK  ID_TASK_PHY0_LINK_C
#else
#include "kernel_id.h"
#endif

static ID phy_flg;
static UW phy_id;
static UW phy_adr;
static UB phy_link;

static UINT phy_get(UINT reg_adr)
{
    volatile UINT sta;
    UINT i;

    loc_cpu();
    RIN_ETH->GMAC_MIIM = MII_R | MII_PHYA(phy_adr) | MII_REGA(reg_adr);

    for (i=0; i<PYH_RW_CNT; i++) {
        sta = RIN_ETH->GMAC_MIIM;
        if (sta & MII_VALID) {
            unl_cpu();
            return sta & 0xffff;
        }
    }
    unl_cpu();
    return 0xffffffff;
}

static UINT phy_put(UINT reg_adr, UINT val)
{
    UINT sta;
    UINT i;

    loc_cpu();
    RIN_ETH->GMAC_MIIM = MII_W | MII_PHYA(phy_adr) | MII_REGA(reg_adr) | val;

    for (i=0; i<PYH_RW_CNT; i++) {
        sta = RIN_ETH->GMAC_MIIM;
        if (sta & MII_VALID) {
            unl_cpu();
            return sta & 0xffff;
        }
    }
    unl_cpu();
    return 0xffffffff;
}

/* Ether Driver Interface */

ER phy0_ini(ID flg, UW id, UW adr)
{
    ER ercd;

    phy_flg  = flg;
    phy_id   = id;
    phy_adr  = adr;
    phy_link = 0;

    phy_put(PHY_BMCR, BMCR_RESET);
	while(phy_get(PHY_BMCR) & BMCR_RESET);
    phy_put(PHY_BMCR, BMCR_ANE);            // Enable auto negotiation
    // select PHY LED Mode
      // PHY-LED0 : Link
      // PHY-LED1 : Activity
    phy_put(PHY_LEDMDSEL , 0x00A0);
    phy_put(PHY_LEDBHVR  , 0x0403);

    ercd = sta_tsk(ID_TASK_PHY0_LINK, 0);
    return ercd;
}

ER phy0_ext(void)
{
    ER ercd;
    ercd = ter_tsk(ID_TASK_PHY0_LINK);
    return ercd;
}

ER phy0_set_mode(UW mode, UB nego)
{
    /* Auto-Negotiation*/
    if (nego) {
        /* Enable auto-negotition */
        phy_put(PHY_BMCR, BMCR_ANE);

        phy_put(PHY_1000BCR, 0);

        if (mode == PHY_10T_HD) {
            phy_put(PHY_ANAR, (ANAR_10 | ANAR_SF_802_3u));
        } else if (mode == PHY_10T_FD) {
            phy_put(PHY_ANAR, (ANAR_10_FD | ANAR_10 | ANAR_SF_802_3u));
        } else if (mode == PHY_100TX_HD) {
            phy_put(PHY_ANAR, (ANAR_TX | ANAR_SF_802_3u));
        } else if (mode == PHY_100TX_FD) {
            phy_put(PHY_ANAR, (ANAR_TX_FD | ANAR_TX | ANAR_SF_802_3u));
        } else if (mode == PHY_1000T_HD) {
            phy_put(PHY_1000BCR, GIGABASET_CTRL_HD);
        } else if (mode == PHY_1000T_FD) {
            phy_put(PHY_1000BCR, GIGABASET_CTRL_FD);
        } else {/* Auto select mode (10HD/10FD/100HD/100FD) */
            phy_put(PHY_ANAR, (ANAR_TX_FD | ANAR_TX | ANAR_10_FD | ANAR_10 | ANAR_SF_802_3u));
        }
        /* Restart auto-negotition */
        phy_put(PHY_BMCR, BMCR_ANE | BMCR_RS_ANP);
    } else {

        phy_put(PHY_1000BCR, 0);

        /* Disable I/F */
        phy_put(PHY_BMCR, BMCR_RESET);
        while(phy_get(PHY_BMCR) & BMCR_RESET) {
            tslp_tsk(1);
        }

        if (mode == PHY_10T_HD) {
            phy_put(PHY_BMCR, 0);
        } else if (mode == PHY_10T_FD) {
            phy_put(PHY_BMCR, BMCR_DUPLEX);
        } else if (mode == PHY_100TX_HD) {
            phy_put(PHY_BMCR, BMCR_SPD_LSB);
        } else if (mode == PHY_100TX_FD) {
            phy_put(PHY_BMCR, (BMCR_SPD_LSB | BMCR_DUPLEX));
        } else if (mode == PHY_1000T_HD) {
            phy_put(PHY_BMCR, BMCR_SPD_MSB);
            phy_put(PHY_1000BCR, GIGABASET_CTRL_HD);
        } else if (mode == PHY_1000T_FD) {
            phy_put(PHY_BMCR, (BMCR_SPD_MSB | BMCR_DUPLEX));
            phy_put(PHY_1000BCR, GIGABASET_CTRL_FD);
        } else {
            phy_put(PHY_BMCR, 0);
        }
    }
    return E_OK;
}

ER phy0_get_mode(UW *mode, UB *nego, UB *link)
{
    UW sts, bmcr;

    /* released latched status (Dummy read) */
    phy_get(PHY_BMSR);

    *link = (phy_get(PHY_BMSR) & BMSR_LINK_STAT) ? 1 : 0;
    if (*link == 0) {
        *mode = *nego = 0;
        return E_OK;
    }

    sts = phy_get(PHY_1000BSR);
    if (sts & GIGABASET_STAT_FD) {
        /* 1000Base-T Full Duplex */
        *mode = PHY_1000T_FD;
        return E_OK;
    }
    else if (sts & GIGABASET_STAT_HD) {
        /* 1000Base-T Half Duplex */
        *mode = PHY_1000T_HD;
        return E_OK;
    }

    bmcr = phy_get(PHY_BMCR);
    /* fix mode */
    if ((bmcr & BMCR_ANE) == 0) {
        *nego = 0;
        if (bmcr & BMCR_SPD_LSB) {
            if (bmcr & BMCR_DUPLEX) {
                *mode = PHY_100TX_FD;
            } else {
                *mode = PHY_100TX_HD;
            }
        } else {
            if (bmcr & BMCR_DUPLEX) {
                *mode = PHY_10T_FD;
            } else {
                *mode = PHY_10T_HD;
            }
        }
        return E_OK;
    }

    /* In Basic register set, there is no bit avaialble to read the 
       Link details. So, here we use the common capabilities of remote
       and local stations as Link details.
    */
    *nego = 1;
    sts = phy_get(PHY_ANLPAR);  /* Link partner abilities */
    sts &= phy_get(PHY_ANAR);   /* Local station abilities */

    if (sts & ANLPAR_B_TX_FD) {
        /* 100Base-TX Full Duplex */
        *mode = PHY_100TX_FD;
    }
    else if (sts & ANLPAR_B_TX) {
        /* 100Base-Tx Half Duplex */
        *mode = PHY_100TX_HD;
    }
    else if (sts & ANLPAR_B_10_FD) {
        /* 10Base-T Full Duplex */
        *mode = PHY_10T_FD;
    } else {
        /* 10Base-T */
        *mode = PHY_10T_HD;
    }

    return E_OK;
}

void phy0_link_tsk(int exinf)
{
    UB bmsr_link;

    while (TRUE) {

        tslp_tsk(100);

        /* released latched status (Dummy read) */
        phy_get(PHY_BMSR);

        /* BMSR link status */
        if (phy_get(PHY_BMSR) & BMSR_LINK_STAT) {
            bmsr_link = 1;
        } else {
            bmsr_link = 0;
        }

        if (bmsr_link == phy_link) {
            continue;
        }

        /* link status change */
        phy_link = bmsr_link;

        /* link up */
        if (phy_link) {
            /* negotition ? */
            if (phy_get(PHY_BMCR) & BMCR_ANE) {
                /* wait complete */
                while ((phy_get(PHY_BMSR) & BMSR_ANEG_COMP) == 0) {
                    tslp_tsk(1);
                }
            }
        }
        set_flg(phy_flg, (PHY_LINK_EVT | phy_id));
    }
}
