/**
 *******************************************************************************
 * @file  kernel_cfg.c
 * @brief HW-RTOS kernel configuration file
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "kernel.h"
#include "kernel_id.h"

#include "RIN32M4.h"

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/
extern void init_task(int exinf);
extern void main_task(int exinf);
extern void idle_task(int exinf);
//extern void int_task(void);

/*============================================================================*/
/* C O N S T                                                                  */
/*============================================================================*/
//-------------------------------------
// Task information
//-------------------------------------
const TSK_TBL static_task_table[] = {
// CRE_TSK(	 tskid, 			{tskatr,			exinf,	task,			itskpri,	stksz,	stk});
			{ID_TASK_INIT, 		{TA_HLNG | TA_ACT,	0, 		(FP)init_task,		1, 			0x400,	NULL}},
			{ID_TASK_MAIN, 		{TA_HLNG | TA_ACT,	0, 		(FP)main_task,		3, 			0x400,	NULL}},
            {ID_TASK_IDLE,		{TA_HLNG | TA_ACT,  0,      (FP)idle_task,		15,         0x100,  NULL}},			
			{TASK_TBL_END,		{0,					0,		(FP)NULL,			0,			0,		NULL}}
};

//-------------------------------------
// Semaphore information
//-------------------------------------
const SEM_TBL static_semaphore_table[] = {
// CRE_SEM(	 semid,				{sematr,	isemcnt,	maxsem});
			{ID_APL_SEM1,	 	{TA_TFIFO,	0, 			1}},
			{ID_APL_SEM2,	 	{TA_TFIFO,	0, 			1}},
			
			{SEMAPHORE_TBL_END,	{0,			0,			0}}
};

//-------------------------------------
// Eventflag information
//-------------------------------------
const FLG_TBL static_eventflag_table[] = {
// CRE_FLG(	 flgid,				{flgatr,			iflgptn});
			{ID_APL_FLG1,		{TA_TFIFO | TA_CLR,	0}},
			{ID_APL_FLG2,		{TA_TFIFO | TA_CLR,	0}},
		
			{EVENTFLAG_TBL_END,	{0,			0}}	
};

//-------------------------------------
// Mailbox information
//-------------------------------------
const MBX_TBL static_mailbox_table[] = {
// CRE_MBX(  mbxid,             {mbxatr,    maxmpri,	mprihd});
            {ID_APL_MBX1,       {TA_TFIFO,  0,			NULL}},			     
			{ID_APL_MBX2,       {TA_TFIFO,  0,			NULL}},

			{MAILBOX_TBL_END,	{0,			0,			NULL}}
};

//-------------------------------------
// Mutex information
//-------------------------------------
const MTX_TBL static_mutex_table[] = {
// CRE_MTX(	 mtxid, 		{mtxatr,	ceilpri});
			{ID_APL_MTX1, 	{TA_TFIFO,	0}},
			{ID_APL_MTX2, 	{TA_TFIFO,	0}},
			
			{MUTEX_TBL_END,	{0,			0}}
};

//-------------------------------------
// Interrupt handler information
//-------------------------------------
const INT_TBL static_interrupt_table[] = {
// DEF_INH(  inhno,			{inatr,		inthdr});
//			{INTPZ0_IRQn,	{TA_HLNG,	(FP)int_task}},
			{INT_TBL_END,	{0,			(FP)NULL}}
};

const HWISR_TBL static_hwisr_table[] = {
//			inhno,			hwisr_syscall,	id,				setptn
			{INTPZ1_IRQn,	HWISR_SET_FLG,	ID_APL_FLG1,	0x0001},
			{INTPZ2_IRQn,	HWISR_WUP_TSK,	ID_TASK_MAIN,	0},
			
			{HWISR_TBL_END,	0,			0,			0}
};
