/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Init.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


ERRCODE gerR_IN32C_Init(
	const UCHAR*          puchMACAddr,		
	const R_IN32_UNITINFO_T* pstUnitInfo, 		
	const R_IN32_UNITINIT_T* pstUnitInit		
)
{
	ERRCODE erRet = R_IN32C_OK;


	gerR_IN32U_Init();

	erR_IN32C_InitLocal();

	gerR_IN32U_Update(pstUnitInfo, pstUnitInit);

	erR_IN32C_UpdateLocal(pstUnitInfo, pstUnitInit);

	gR_IN32S_Memcpy(gstR_IN32C.stInf0.auchMACAddress, puchMACAddr, R_IN32_MACADR_SZ);

	erR_IN32C_R_IN32DInit_DisableInt(gstR_IN32C.stInf0.auchMACAddress, &gstR_IN32C.stMain.ulLastResetLevel);

	return erRet;
}

ERRCODE erR_IN32C_InitLocal(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	(VOID)erR_IN32C_InitLocalMain();
	(VOID)erR_IN32C_InitLocalInf0();
	(VOID)erR_IN32C_InitLocalInf1();
	(VOID)erR_IN32C_InitLocalCyclic();
	(VOID)erR_IN32C_InitLocalSlvEvt();
	(VOID)erR_IN32C_InitLocalPort();
	(VOID)erR_IN32C_InitLocalMIB();
	(VOID)erR_IN32C_InitLocalMACAddrTbl();
	(VOID)erR_IN32C_InitLocal2ndBuf();
	(VOID)erR_IN32C_InitLocalMotSyncCtl();

	return erRet;
}

ERRCODE erR_IN32C_InitLocalMain(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stMain, 0, sizeof(R_IN32C_MAIN_T));

	gstR_IN32C.stMain.ulState = R_IN32C_STS_WAITSTART;
	gstR_IN32C.stMain.ulLastResetLevel = R_IN32D_RESET_PWRON;	
	gstR_IN32C.stMain.blValidMasterMyStatus = R_IN32_FALSE;	
	gstR_IN32C.stMain.blReqSlvEvt           = R_IN32_FALSE;	
	gstR_IN32C.stMain.blMACIPAccessSem      = R_IN32_FALSE;	
	gstR_IN32C.stMain.blRcvEnable           = R_IN32_TRUE;		

	return erRet;
}

ERRCODE erR_IN32C_InitLocalInf0(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stInf0, 0, sizeof(R_IN32C_UNITINF0_T));

	gstR_IN32C.stInf0.uchNetworkNumber = R_IN32U_NETWORK_NUMBER;
	gstR_IN32C.stInf0.usStationNumber  = R_IN32U_STATION_NUMBER;
	gstR_IN32C.stInf0.uchStationType   = (UCHAR)gulR_IN32U_STATION_CLASS;

	gstR_IN32C.stInf0.stSelfStatus.ulCPURunCond      = gulR_IN32U_SELFSTA_CPURUN;
	__BUS_RELEASE();
	gstR_IN32C.stInf0.stSelfStatus.ulCPUErrFoundCond = gulR_IN32U_SELFSTA_CPUERRFOUND;

	gstR_IN32C.stInf0.ulErrCode                      = gulR_IN32U_ERRCODE;
	gstR_IN32C.stInf0.ulUserInformation              = gulR_IN32U_USER_INFORMATION;

	return erRet;
}

ERRCODE erR_IN32C_InitLocalInf1(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stInf1, 0, sizeof(R_IN32C_UNITINF1_T));

	gstR_IN32C.stInf1.ulMaxRySize  = gulR_IN32U_MAX_RY_SIZE;   
	gstR_IN32C.stInf1.ulMaxRWwSize = gulR_IN32U_MAX_RWW_WSIZE; 
	gstR_IN32C.stInf1.ulMaxRxSize  = gulR_IN32U_MAX_RX_SIZE;   
	__BUS_RELEASE();
	gstR_IN32C.stInf1.ulMaxRWrSize = gulR_IN32U_MAX_RWR_WSIZE; 
	gstR_IN32C.stInf1.ulMinRySize  = gulR_IN32U_MIN_RY_SIZE;   
	gstR_IN32C.stInf1.ulMinRWwSize = gulR_IN32U_MIN_RWW_WSIZE; 
	__BUS_RELEASE();
	gstR_IN32C.stInf1.ulMinRxSize  = gulR_IN32U_MIN_RX_SIZE;   
	gstR_IN32C.stInf1.ulMinRWrSize = gulR_IN32U_MIN_RWR_WSIZE; 

	gstR_IN32C.stInf1.ulMyStationPortTotalNumber = gulR_IN32U_MAX_PORT_NUMBER;
	__BUS_RELEASE();
	gstR_IN32C.stInf1.ulTokenHoldTime            = gulR_IN32U_TOKEN_HOLD_TIME;

	gstR_IN32C.stInf1.ulIOType        = gulR_IN32U_STINF_IOTYPE;

	gstR_IN32C.stInf1.ulNetVersion       = gulR_IN32U_UNIT_VERSION;
	__BUS_RELEASE();
	
	gstR_IN32C.stInf1.ulNetModelType     = gulR_IN32U_UNIT_MODEL_TYPE;
	__BUS_RELEASE();
	gstR_IN32C.stInf1.ulNetUnitModelCode = gulR_IN32U_UNIT_MODEL_CODE;
	gstR_IN32C.stInf1.ulNetVendorCode    = gulR_IN32U_UNIT_VENDOR_CODE;
	gR_IN32S_Memcpy(gstR_IN32C.stInf1.auchNetUnitModelName, R_IN32U_UNIT_MODEL_NAME, R_IN32_MODEL_NAME_LENGTH);
	gR_IN32S_Memcpy(gstR_IN32C.stInf1.auchNetVendorName   , R_IN32U_UNIT_VENDOR_NAME, R_IN32_VENDOR_NAME_LENGTH);
	gstR_IN32C.stInf1.usHwVersion        = gusR_IN32U_UNIT_HW_VERSION;
	gstR_IN32C.stInf1.usDeviceVersion    = gusR_IN32U_UNIT_DEVICE_VERSION;

	gstR_IN32C.stInf1.ulInformationFlag  = R_IN32U_CTRL_INFOFLG;
	gstR_IN32C.stInf1.ulCtrVersion       = R_IN32U_CTRL_VERSION;
	gstR_IN32C.stInf1.ulCtrModelType     = R_IN32U_CTRL_MODEL_TYPE;
	gstR_IN32C.stInf1.ulCtrUnitModelCode = R_IN32U_CTRL_MODEL_CODE;
	gstR_IN32C.stInf1.ulCtrVendorCode    = R_IN32U_CTRL_VENDOR_CODE;
	gR_IN32S_Memcpy(gstR_IN32C.stInf1.auchCtrUnitModelName, R_IN32U_CTRL_MODEL_NAME, R_IN32_MODEL_NAME_LENGTH);
	gR_IN32S_Memcpy(gstR_IN32C.stInf1.auchCtrVendorName   , R_IN32U_CTRL_VENDOR_NAME, R_IN32_VENDOR_NAME_LENGTH);
	gstR_IN32C.stInf1.ulVendorInformation = R_IN32U_CTRL_VENDOR_UNIT_INFO;

	return erRet;
}

ERRCODE erR_IN32C_InitLocalCyclic(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stCyclic, 0, sizeof(R_IN32C_CYCLIC_T));

	gstR_IN32C.stCyclic.ulState = R_IN32C_CYC_STS_STOP; 

	if (R_IN32_OFF != R_IN32D_CYCLICSTA_STATIONWRONG) {
		gstR_IN32C.stCyclic.ulStopRequst |= R_IN32C_CYCSTOP_TYPE;
	}
	else {
	}
	if (R_IN32_OFF != R_IN32D_CYCLICSTA_DISCONNECT) {
		gstR_IN32C.stCyclic.ulStopRequst |= R_IN32C_CYCSTOP_LEAVE;
	}
	else {
	}
	if (R_IN32_OFF != R_IN32D_CYCLICSTA_CYCSTOP) {
		gstR_IN32C.stCyclic.ulStopRequst |= R_IN32C_CYCSTOP_INIT;
	}
	else {
	}
	gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll &= ~R_IN32D_CYCLICSTA_STATIONWRONG;
	gstR_IN32C.stCyclic.stSetStopReq.uniCycStaSet.usAll |= ( R_IN32D_CYCLICSTA_DISCONNECT
														| R_IN32D_CYCLICSTA_CYCSTOP);


	gstR_IN32C.stCyclic.stGetStopSts.uniCycSta.usAll &= ~R_IN32D_CYCSTATUS_GET_ENABLE_MASK;
	gstR_IN32C.stCyclic.stGetStopSts.uniCycSta.usAll |= (CYCLIC_STA_PARAMNONRECV
													| CYCLIC_STA_PARAMCHECKNOTEND
													| CYCLIC_STA_DLINKSTATE
													| CYCLIC_STA_INITORWAIT);

	return erRet;
}

ERRCODE erR_IN32C_InitLocalSlvEvt(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stSlvEvt, 0, sizeof(R_IN32C_SLVEVT_T));

	gstR_IN32C.stSlvEvt.ulState = R_IN32C_SLVEVT_STS_IDLE;
	gstR_IN32C.stSlvEvt.uchNextNumber = 1; 

	return erRet;
}

ERRCODE erR_IN32C_InitLocalPort(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stP1, 0, sizeof(R_IN32C_PORT_T));
	gR_IN32S_Memset(&gstR_IN32C.stP2, 0, sizeof(R_IN32C_PORT_T));

	gstR_IN32C.stP1.ulNumber = R_IN32C_PORT1;
	gstR_IN32C.stP1.ulState  = R_IN32C_PORT_STS_LINKDOWN;
	gstR_IN32C.stP2.ulNumber = R_IN32C_PORT2;
	gstR_IN32C.stP2.ulState  = R_IN32C_PORT_STS_LINKDOWN;

	return erRet;
}

ERRCODE erR_IN32C_InitLocalMIB(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stMIB, 0, sizeof(R_IN32C_MIB_T));

	return erRet;
}

ERRCODE erR_IN32C_InitLocalMACAddrTbl(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gR_IN32S_Memset(&gstR_IN32C.stMACAddrTbl, 0, sizeof(R_IN32C_MACADDRTBL_T));

	gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivType      = gulR_IN32U_MACDELIV_TYPE;				
	gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivSeqNumber = (ULONG)R_IN32U_MACDELIV_SEQNUMBER;	

	return erRet;
}

ERRCODE erR_IN32C_InitLocal2ndBuf(VOID)
{
	ERRCODE erRet = R_IN32C_OK;
	ULONG ulIdx;

	gulR_IN32C_RcvBufWIdx = 0;
	gulR_IN32C_RcvBufRIdx = 0;
	__BUS_RELEASE();

	for (ulIdx=0; ulIdx<R_IN32C_2ND_BUFFER_NUM; ulIdx++) {
		gastR_IN32C_RcvBuf[ulIdx].blValid = R_IN32_FALSE;
	}

	return erRet;
}

ERRCODE erR_IN32C_InitLocalMotSyncCtl(VOID)
{
	ERRCODE erRet = R_IN32C_OK;

	gstR_IN32C.stMotSyncCtl.ulSyncStatus = R_IN32C_MOTSYNC_WAIT;
	gstR_IN32C.stMotSyncCtl.ulSyncCounter = 0;
	gstR_IN32C.stMotSyncCtl.ulSyncCounterLast = 0;
	__BUS_RELEASE();
	gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckStart = 0;
	gstR_IN32C.stMotSyncCtl.ulSyncFrameCheckRequest = 0;
	gstR_IN32C.stMotSyncCtl.ulSyncFrameErr = 0;
	gstR_IN32C.stMotSyncCtl.ulSyncWinOffCounterAcml = 0;

	return erRet;
}

ERRCODE erR_IN32C_UpdateLocal(
	const R_IN32_UNITINFO_T* pstUnitInfo, 		
	const R_IN32_UNITINIT_T* pstUnitInit		
)
{
	ERRCODE erRet = R_IN32C_OK;

	gstR_IN32C.stInf1.ulMaxRySize  = pstUnitInfo->ulMaxRySize;  
	gstR_IN32C.stInf1.ulMaxRWwSize = pstUnitInfo->ulMaxRWwSize; 
	gstR_IN32C.stInf1.ulMaxRxSize  = pstUnitInfo->ulMaxRxSize;  
	gstR_IN32C.stInf1.ulMaxRWrSize = pstUnitInfo->ulMaxRWrSize; 
	__BUS_RELEASE();
	
	__BUS_RELEASE();
	
	gstR_IN32C.stInf0.uchStationType = (UCHAR)pstUnitInit->ulNodeType;	
	gstR_IN32C.stInf1.ulMyStationPortTotalNumber = pstUnitInfo->ulMyStationPortTotalNumber;	
	gstR_IN32C.stInf1.ulTokenHoldTime            = pstUnitInfo->ulTokenHoldTime;				

	gstR_IN32C.stInf1.ulIOType = pstUnitInfo->ulIOType; 
	__BUS_RELEASE();

	gstR_IN32C.stInf1.ulNetVersion       = pstUnitInfo->ulNetVersion;			
	gstR_IN32C.stInf1.ulNetModelType     = pstUnitInfo->ulNetModelType;		
	gstR_IN32C.stInf1.ulNetUnitModelCode = pstUnitInfo->ulNetUnitModelCode;	
	gstR_IN32C.stInf1.ulNetVendorCode    = pstUnitInfo->ulNetVendorCode;		
	gR_IN32S_Memcpy(&gstR_IN32C.stInf1.auchNetUnitModelName[0],					
				&pstUnitInfo->auchNetUnitModelName[0],
				R_IN32_MODEL_NAME_LENGTH
				);
	gR_IN32S_Memcpy(&gstR_IN32C.stInf1.auchNetVendorName[0],					
				&pstUnitInfo->auchNetVendorName[0],
				R_IN32_VENDOR_NAME_LENGTH
				);
	gstR_IN32C.stInf1.usHwVersion       = pstUnitInfo->usHwVersion;			
	gstR_IN32C.stInf1.usDeviceVersion   = pstUnitInfo->usDeviceVersion;		

	gstR_IN32C.stInf1.ulInformationFlag  = (ULONG)pstUnitInfo->blInformationFlag;	
	gstR_IN32C.stInf1.ulCtrVersion       = pstUnitInfo->ulCtrlVersion;				
	__BUS_RELEASE();
	gstR_IN32C.stInf1.ulCtrModelType     = pstUnitInfo->ulCtrlModelType;			
	gstR_IN32C.stInf1.ulCtrUnitModelCode = pstUnitInfo->ulCtrlUnitModelCode;		
	gstR_IN32C.stInf1.ulCtrVendorCode    = pstUnitInfo->ulCtrlVendorCode;			
	gR_IN32S_Memcpy(&gstR_IN32C.stInf1.auchCtrUnitModelName[0],						
				&pstUnitInfo->auchCtrlUnitModelName[0],
				R_IN32_MODEL_NAME_LENGTH
				);
	gR_IN32S_Memcpy(&gstR_IN32C.stInf1.auchCtrVendorName[0],							
				&pstUnitInfo->auchCtrlVendorName[0],
				R_IN32_VENDOR_NAME_LENGTH
				);
	gstR_IN32C.stInf1.ulVendorInformation = pstUnitInfo->ulVendorInformation;		

	if ( R_IN32_TRUE == pstUnitInit->blMACAddressTableRequest ) {					
		gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivType = (ULONG)R_IN32_ON;
	}
	else {
		gstR_IN32C.stMACAddrTbl.stInf.ulMacDelivType = (ULONG)R_IN32_OFF;
	}

	gstR_IN32C.stInf0.stSelfStatus.ulCPURunCond      = pstUnitInit->ulRunStatus;		
	gstR_IN32C.stInf0.stSelfStatus.ulCPUErrFoundCond = pstUnitInit->ulErrorStatus;		
	__BUS_RELEASE();
	gstR_IN32C.stInf0.ulErrCode                      = gulR_IN32U_ERRCODE;		
	gstR_IN32C.stInf0.ulUserInformation              = pstUnitInit->ulUserInformation;	

	if ( R_IN32_TRUE == pstUnitInit->blTransientReceiveEnable ) {
		gstR_IN32C.stMain.blRcvEnable = R_IN32_TRUE;
	}
	else {
		gstR_IN32C.stMain.blRcvEnable = R_IN32_FALSE;
	}

	return erRet;
}

/*** EOF ***/
