/**
 *******************************************************************************
 * @file  csi.h
 * @brief CSI driver header
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	CSI_H__
#define	CSI_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/* Master/Slave mode define for csi_mode_ms[] */
#define CSI_MSMODE_MASTER (0)				/**< CSI Master mode */
#define CSI_MSMODE_SLAVE  (1)				/**< CSI Slave mode */

/* Reception/Transmission mode define for csi_mode_rt[] */
#define CSI_RTMODE_RECEPTION    (0)			/**< CSI Reception mode */
#define CSI_RTMODE_TRANSMISSION (1)			/**< CSI Transmission mode */
#define CSI_RTMODE_INITIAL      (0xFF)		/**< CSI Initial mode */
/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
ER_RET csi_init(uint32_t ch, uint32_t mode);				/* Initialize */
ER_RET csi_change_mode(uint32_t ch, uint32_t mode);			/* Change mode */
ER_RET csi_read(uint32_t ch, uint8_t* data);				/* Read */
ER_RET csi_write(uint32_t ch, uint8_t data);				/* Write */
ER_RET csi_check_rx(uint32_t ch);							/* Check recieve status */
ER_RET csi_check_tx(uint32_t ch);							/* Check transmit status */

#endif // CSI_H__
