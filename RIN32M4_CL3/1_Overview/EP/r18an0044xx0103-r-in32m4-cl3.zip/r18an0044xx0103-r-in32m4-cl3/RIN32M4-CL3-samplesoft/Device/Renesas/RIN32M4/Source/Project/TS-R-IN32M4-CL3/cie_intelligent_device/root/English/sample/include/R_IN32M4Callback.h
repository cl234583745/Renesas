/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver user callback code                                 */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4CALLBACK_H_INCLUDED__
#define __R_IN32M4CALLBACK_H_INCLUDED__

#include "R_IN32M4Types.h"

extern VOID gR_IN32_CallbackFatalError( ULONG, ULONG );
extern ERRCODE gerR_IN32_CallbackCommandFromMaster( ULONG );
extern ERRCODE gerR_IN32_CallbackReceivedTransient( VOID*, USHORT );
extern ERRCODE gerR_IN32_CallbackTransientSendingComplete( UCHAR, ERRCODE );

#endif /*__R_IN32M4CALLBACK_H_INCLUDED__*/

/*** EOF ***/
