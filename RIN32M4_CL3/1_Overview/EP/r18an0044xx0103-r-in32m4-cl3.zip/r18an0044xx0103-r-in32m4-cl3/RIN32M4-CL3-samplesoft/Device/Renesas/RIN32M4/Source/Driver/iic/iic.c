/**
 *******************************************************************************
 * @file  iic.c
 * @brief I2C control program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "iic/iic.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
  @brief  Initialize I2C driver and controller
  @param  [in] ch -- IIC channel
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
 ******************************************************************************
*/
ER_RET iic_init(uint8_t ch)
{
	RIN_IIC_TypeDef *RIN_IIC;
	
	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC0_BASE;
			break;
		case 1:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	
	//=========================================
	// Initialize I2C
	//=========================================
	// --- Set the high/low level width of SCLn ---
		// Transfer clock                     : 400 [kHz]
		// SDAn and SCLn signal falling times :  20 [ ns]
		// SDAn and SCLn signal rising times  :  20 [ ns]
		// (PCLK:100MHz))

	RIN_IIC->IICBnWL = 130;	// (0.52 / 400k[Hz] ) * 100M[Hz]
	RIN_IIC->IICBnWH = 116;	// (0.48 / 400k[Hz] - 20n[s] -20n[s]) * 100M[Hz]

	// --- Slave address ---
//	RIN_IIC->IICBnSVA = 0x00;
	
	// --- Mode control 0 ---
	RIN_IIC->IICBnCTL0 = (0 << 7)			// [7] IIC operation            : Disable
	                   | (0 << 4)			// [4] Transfer mode(Slave)     : Single
	                   | (0 << 3)			// [3] Transfer mode(Master)    : Single
	                   | (1 << 2)			// [2] INTIICBTISn              : Enable
	                   | (1 << 1)			// [1] Interrupt request timing : 9th clock
	                   | (1 << 0);			// [0] Acknowledge              : Enable

	// --- Mode control 1 ---
	RIN_IIC->IICBnCTL1 = (1 << 7)			// [7]   Operation mode                 : Fast (400kHz)
	                   | (0 << 4)			// [6:4] Digital filter                 : Not use
	                   | (0 << 3)			// [3]   Loop-back mode                 : Not use
	                   | (1 << 1)			// [1]   Start condition output         : Enable
	                   | (0 << 0);			// [0]   Communication reserve function : Enable
	
	// --- Enable interrupt & Set port mode ---
	switch (ch)
	{
		case 0:
			// --- Interrupt ---
//			NVIC_SetPriority(IICB0TIA_IRQn, 10);
//			NVIC_SetPriority(IICB0TIS_IRQn, 10);
			// --- Port ---
			RIN_GPIO->PFCE6B &= ~0x03;	/* P60(SCL0),P61(SDA0) */
			RIN_GPIO->PFC6B  &= ~0x03;
			RIN_GPIO->PMC6B  |=  0x03;
		
			break;
		case 1:
			// --- Interrupt ---
//			NVIC_SetPriority(IICB1TIA_IRQn, 10);
//			NVIC_SetPriority(IICB1TIS_IRQn, 10);
			// --- Port ---
			RIN_RTPORT->RPFCE0B &= ~0x03;	/* RP00(SCL1),RP01(SDA1) */
			RIN_RTPORT->RPFC0B  |=  0x03;
			RIN_RTPORT->RPMC0B  |=  0x03;
			break;
		default:
			break;
	}
	
	// --- IIC Enable ---
	RIN_IIC->IICBnCTL0 |= (1 << 7);			// [7] IIC operation            : Enable
	
	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Create start condition
  @param  [in] ch -- IIC channel
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
 ******************************************************************************
*/
ER_RET iic_start_condition(uint8_t ch)
{
	RIN_IIC_TypeDef *RIN_IIC;
	
	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC0_BASE;
			break;
		case 1:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	
	//=========================================
	// Create start condition
	//=========================================
	RIN_IIC->IICBnTRG = 0x02;					// Create Start condition
	
	// --- Confirm start condition ---
	while ((RIN_IIC->IICBnSTR0 & 0x0020) != 0x0020)
	{
		__NOP();
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Create stop condition
  @param  [in] ch -- IIC channel
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
 ******************************************************************************
*/
ER_RET iic_stop_condition(uint8_t ch)
{
	RIN_IIC_TypeDef *RIN_IIC;
	
	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC0_BASE;
			break;
		case 1:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	
	//=========================================
	// Create stop condition
	//=========================================
	RIN_IIC->IICBnTRG = 0x01;					// Create stop condition
	
	// --- Confirm stop condition ---
	while ((RIN_IIC->IICBnSTR0 & 0x0010) != 0x0010)
	{
		__NOP();
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Write data
  @param  [in] ch   -- IIC channel
  @param  [in] data -- Write data
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
  @retval ER_NG    -- Error
 ******************************************************************************
*/
ER_RET iic_write(uint8_t ch, uint8_t data)
{
	RIN_IIC_TypeDef *RIN_IIC;
	
	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC0_BASE;
			break;
		case 1:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	
	//=========================================
	// Write data
	//=========================================
	RIN_IIC->IICBnDAT = data;						// Write data
	
	// --- Wait for transfer finish ---
	while (NVIC_GetPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch)) != 1)
	{
		__NOP();
	}
	NVIC_ClearPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch));
	
	// --- Confirm ACK ---
	if ((RIN_IIC->IICBnSTR0 & 0x0100) != 0x0100)
	{
		return ER_NG;
	}
	
	return ER_OK;
}


/**
 ******************************************************************************
  @brief  Read data
  @param  [in]  ch    -- IIC channel
  @param  [out] *data -- Read data
  @param  [in]  last  -- last
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter error
 ******************************************************************************
*/
ER_RET iic_read(uint8_t ch, uint8_t *data, uint32_t last)
{
	RIN_IIC_TypeDef *RIN_IIC;
	
	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC0_BASE;
			break;
		case 1:
			RIN_IIC = (RIN_IIC_TypeDef *)RIN_IIC1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	
	//=========================================
	// Read data
	//=========================================
	RIN_IIC->IICBnCTL0 &= ~(1 << 1);				// [1] Interrupt request timing : 8th clock
	RIN_IIC->IICBnTRG   = 0x04;						// Exit the wait state
	
	// --- Wait for transfer finish ---
	while (NVIC_GetPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch)) != 1)
	{
		__NOP();
	}
	NVIC_ClearPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch));	// Clear PendingIRQ
	
	if (last == 0)
	{
		// ====== Usually ======
		
		// --- Read data ---
		*data = RIN_IIC->IICBnDAT;					// Read data
	}
	else
	{
		// ====== Last ======
		
		// --- Disable ACK ---
		RIN_IIC->IICBnCTL0 &= ~(1 << 0);			// [0] Acknowledge              : Disable
		// --- Read data ---
		*data = RIN_IIC->IICBnDAT;					// Read data
		// ---  ---
		RIN_IIC->IICBnCTL0 |= (1 << 1);				// [1] Interrupt request timing : 9th clock
		RIN_IIC->IICBnTRG = 0x04;					// Exit the wait state
		// --- Wait for transfer finish ---
		while (NVIC_GetPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch)) != 1)
		{
			__NOP();
		}
		NVIC_ClearPendingIRQ((IRQn_Type)(IICB0TIA_IRQn + ch));	// Clear PendingIRQ
		
		// --- Enable ACK ---
		RIN_IIC->IICBnCTL0 |= (1 << 0);				// [0] Acknowledge              : Enable
	}
	
	return ER_OK;
}
