/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. */
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32C_H_INCLUDED__
#define __R_IN32C_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32D.h"
#include "R_IN32U.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32C_PORT1			0
#define R_IN32C_PORT2			1

#define R_IN32C_OK				0			
#define R_IN32C_NG_OBJ			-1			
#define R_IN32C_NG_OTHER		-2			
#define R_IN32C_NG_OUTOFRANGE	-3			
#define R_IN32C_NG_EMPTY		-4			
#define R_IN32C_NG_OVERFLOW	-5			
#define R_IN32C_NG_NOENTRY		-6			
#define R_IN32C_NG_NOPERMIT	-7			
#define R_IN32C_NG_NODATA		-8			
#define R_IN32C_NG_NOMYSTATUS	-9			
#define R_IN32C_NG_DISCONNECT	-10			
#define R_IN32C_NG_TEST		-11			
#define R_IN32C_NG_TRAN_SIZE	-12			



#define	R_IN32C_STS_WAITSTART				2	
#define	R_IN32C_STS_DISCONNECT				3	
#define	R_IN32C_STS_CONNECT				4	
#define	R_IN32C_STS_DISCONNECT_SYSTEM		6	

#define R_IN32C_CYC_STS_RUN				1	
#define R_IN32C_CYC_STS_STOP				2	

#define	R_IN32C_COMMSTS_DISCONNECT			0	
#define	R_IN32C_COMMSTS_TOKEN_PASS			1	
#define	R_IN32C_COMMSTS_CYC_DLINK			2	

#define R_IN32C_PORTSTS_LINKDOWN			0	
#define R_IN32C_PORTSTS_LINKUP				1	

#define	R_IN32C_CYCSTOP_INIT							0x00000001UL	
#define	R_IN32C_CYCSTOP_APP2							0x00000004UL	
#define R_IN32C_CYCSTOP_FIRSTSND						0x00000008UL	
#define	R_IN32C_CYCSTOP_PARAM							0x00000010UL	
#define	R_IN32C_CYCSTOP_LEAVE							0x00000020UL	
#define	R_IN32C_CYCSTOP_TYPE							0x00000040UL	
#define	R_IN32C_CYCSTOP_CYCSIZE						0x00000080UL	

#define R_IN32C_EVTPRM_COMMCONNECT						0x00000001UL	
#define R_IN32C_EVTPRM_DISCONNECT						0x00000002UL	
#define R_IN32C_EVTPRM_COMMCONNECTTODISCONNECT			0x00000004UL	
#define R_IN32C_EVTPRM_COMMDISCONNECTTOCONNECT			0x00000008UL	
#define R_IN32C_EVTPRM_CHANGESTNONETNO					0x00000010UL	
#define R_IN32C_EVTPRM_CHANGEACTCOMMAND				0x00000020UL	
#define R_IN32C_EVTPRM_PRMFRMRCV_OK					0x00000040UL	
#define R_IN32C_EVTPRM_PRMCHKFRMRCV_OK					0x00000100UL	
#define R_IN32C_EVTPRM_RECVNONCYCLIC					0x00001000UL	
#define R_IN32C_EVTPRM_SENDFINNONCYCLIC				0x00002000UL	
#define R_IN32C_EVTPRM_MASTERWATCHTIMEOUT				0x00200000UL	



#define R_IN32C_MAX_MACDELIVSEQNUM			7	
#define R_IN32C_RETRY_TDISENTRY			7	

#define R_IN32C_MAX_MACADDRTBL				128 

#define R_IN32C_CYCSTP_OUTSTA_BIT		0x00000001UL	
#define R_IN32C_CYCSTP_RSVST_BIT		0x00000002UL	
#define R_IN32C_CYCSTP_MSTREQ_BIT		0x00000004UL	
#define R_IN32C_CYCSTP_DUP_BIT			0x00000008UL	
#define R_IN32C_STATIONTYPE_VALID		0x00010000UL	
#define R_IN32C_CYCSIZE_ERROR			0x00020000UL	

#define R_IN32C_MOTSYNC_WAIT			0				
#define R_IN32C_MOTSYNC_READY			1				
#define R_IN32C_MOTSYNC_START			2				
#define R_IN32C_MOTSYNC_FINISH			3				


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32C_MIBINF0_TAG {
	R_IN32D_MIBMACIP_T		stMACIP;			
	R_IN32D_MIBRGCNT_T		stRGCNT;			
} R_IN32C_MIBINF0_T;

typedef struct _R_IN32C_MIBINF1_TAG {
	ULONG				ulUpCounter;		
	ULONG				ulDownCounter;		
} R_IN32C_MIBINF1_T;

typedef struct _R_IN32C_ERRCNT_TAG {
	R_IN32D_MIBSDRD_T	stSDRD;					
	R_IN32D_MIBMACIP_T	stMACIP1;				
	R_IN32D_MIBMACIP_T	stMACIP2;				
	R_IN32D_MIBRGCNT_T	stRING1;				
	R_IN32D_MIBRGCNT_T	stRING2;				
	ULONG	ulP1DownCounter;				
	ULONG	ulP2DownCounter;				
	ULONG	ulMasterWatchCount;				
} R_IN32C_ERRCNT_T;

typedef struct _R_IN32C_UNITINF0_TAG {
	UCHAR	auchMACAddress[R_IN32_MACADR_SZ];	
	UCHAR	uchNetworkNumber;				
	USHORT	usStationNumber;				

	UCHAR	auchMulticastMACAddress[R_IN32_MACADR_SZ];	
	USHORT	usNodeID;						
	UCHAR	uchReserve1;
	UCHAR	uchStationType;					

	ULONG	ulCurrRySize;					
	ULONG	ulCurrRWwSize;					
	ULONG	ulCurrRxSize;					
	ULONG	ulCurrRWrSize;					

	R_IN32D_SELF_STA_SET_T stSelfStatus;		

	ULONG	ulErrCode;						
	ULONG	ulUserInformation;				

} R_IN32C_UNITINF0_T;

typedef struct _R_IN32C_UNITINF1_TAG {
	ULONG	ulMaxRySize;					
	ULONG	ulMaxRWwSize;					
	ULONG	ulMaxRxSize;					
	ULONG	ulMaxRWrSize;					

	ULONG	ulMyStationPortTotalNumber;		
	ULONG	ulTokenHoldTime;				

	ULONG	ulIOType;						

	ULONG	ulTknHoldFrmSendCount;			
	ULONG	ulFramSendInterval;				
	ULONG	ulTokenSendCount;				

	ULONG	ulNetVersion;					
	ULONG	ulNetModelType;					
	ULONG	ulNetUnitModelCode;				
	ULONG	ulNetVendorCode;				
	UCHAR	auchNetUnitModelName[R_IN32_MODEL_NAME_LENGTH];	
	UCHAR	auchNetVendorName[R_IN32_VENDOR_NAME_LENGTH];		
	USHORT	usHwVersion;					
	USHORT	usDeviceVersion;				

	ULONG	ulInformationFlag;				
	ULONG	ulCtrVersion;					
	ULONG	ulCtrModelType;					
	ULONG	ulCtrUnitModelCode;				
	ULONG	ulCtrVendorCode;				
	UCHAR	auchCtrUnitModelName[R_IN32_MODEL_NAME_LENGTH];	
	UCHAR	auchCtrVendorName[R_IN32_VENDOR_NAME_LENGTH];		
	ULONG	ulVendorInformation;			
	ULONG	ulMinRySize;					
	ULONG	ulMinRWwSize;					
	ULONG	ulMinRxSize;					
	ULONG	ulMinRWrSize;					
} R_IN32C_UNITINF1_T;


typedef struct _R_IN32C_MACADDRDAT_TAG {
	USHORT	usStationNumber;				
	UCHAR	uchTransientRecvMode;			
	UCHAR	auchMacAddress[R_IN32_MACADR_SZ];	
} R_IN32C_MACADDRDAT_T;




typedef struct _R_IN32C_PRMCMD_TAG {
	ULONG ulCommand;			
	BOOL  blTypeErr;			
	BOOL  blSizeErr;			
} R_IN32C_PRMCMD_T;


typedef struct _R_IN32C_MAIN_TAG {
	ULONG ulState;					
	ULONG ulRegTimerID;				
	ULONG ulLastResetLevel;			
	BOOL  blValidMasterMyStatus;	
	BOOL  blReqSlvEvt;				
	BOOL  blMACIPAccessSem;			
	BOOL  blRcvEnable;				
	R_IN32D_MSTMYSTATUS_INFO_T stMasterMyStatus;	
	R_IN32C_PRMCMD_T			 stPrmCmd;			
	UCHAR uchNonCyclicSendCnt;		
} R_IN32C_MAIN_T;

typedef struct _R_IN32C_CYCLIC_TAG {
	ULONG ulState;							
	ULONG ulStopRequst;						
	R_IN32D_CYCLIC_STA_GET_T stGetStopSts;		
	R_IN32D_CYCLIC_STA_SET_T stSetStopReq;		
} R_IN32C_CYCLIC_T;

typedef struct _R_IN32C_PORT_TAG {
	ULONG ulNumber;					
	ULONG ulState;					
	ULONG ulCurrState;				
	ULONG ulCurrSpeed;				
	ULONG ulCurrDuplex;				
} R_IN32C_PORT_T;

typedef struct _R_IN32C_SLVEVTINFO_TAG {
	UCHAR		uchNumber;			
	USHORT		usInformation;		
} R_IN32C_SLVEVTINFO_T;


typedef struct _R_IN32C_SLVEVT_TAG {
	ULONG				ulState;				
	R_IN32C_SLVEVTINFO_T	stSndSlaveEvent;		
	R_IN32D_SLVEVENT_SET_T	stSetSlvEvt;			
	ULONG				ulWtIdx;				
	ULONG				ulRdIdx;				
	ULONG				ulLastSlvEvtRcvCnt;		
	UCHAR				uchNextNumber;			
} R_IN32C_SLVEVT_T;


typedef struct _R_IN32C_MIB_TAG {

	R_IN32D_MIBSDRD_T		stInf0;			
	R_IN32D_MIBSDRD_T		stInf0Accum;	

	R_IN32C_MIBINF0_T		stInf1;			
	R_IN32C_MIBINF1_T		stInf1c;		
	R_IN32C_MIBINF0_T		stInf2;			
	R_IN32C_MIBINF1_T		stInf2c;		

	ULONG ulMasterWatchCount;			

	ULONG ulClearRequest;				

} R_IN32C_MIB_T;

typedef struct _R_IN32C_MACADDRTBL_TAG {
	R_IN32C_MACADDRDAT_T	astTbl[R_IN32C_MAX_MACADDRTBL];	
	R_IN32D_MACDELIV_RESULT_SET_T stInf;	
} R_IN32C_MACADDRTBL_T;

typedef struct _R_IN32C_MOTION_SYNCCTL_TAG {
	ULONG	ulSyncStatus;				
	ULONG	ulSyncCounter;				
	ULONG	ulSyncCounterLast;			
	ULONG	ulSyncFrameCheckStart;		
	ULONG	ulSyncFrameCheckRequest;	
	ULONG	ulSyncFrameErr;				
	ULONG	ulSyncWinOffCounterAcml;	
} R_IN32C_MOTION_SYNCCTL_T;


typedef struct _R_IN32C_TAG {
	R_IN32C_MAIN_T				stMain;			
	R_IN32C_UNITINF0_T			stInf0;			
	R_IN32C_UNITINF1_T			stInf1;			
	R_IN32C_CYCLIC_T			stCyclic;		
	R_IN32C_SLVEVT_T			stSlvEvt;		
	R_IN32C_PORT_T				stP1;			
	R_IN32C_PORT_T				stP2;			
	R_IN32C_MIB_T				stMIB;			
	R_IN32C_MACADDRTBL_T		stMACAddrTbl;	
	R_IN32C_MOTION_SYNCCTL_T	stMotSyncCtl;	
} R_IN32C_T;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/

extern ERRCODE gerR_IN32C_Init(const UCHAR*, const R_IN32_UNITINFO_T*, const R_IN32_UNITINIT_T*);

extern ERRCODE gerR_IN32C_GetTDIS(USHORT,VOID **, UCHAR *,UCHAR *);
extern ERRCODE gerR_IN32C_EntryTDIS(UCHAR ,USHORT);
extern ERRCODE gerR_IN32C_Start(UCHAR ,USHORT);
extern ERRCODE gerR_IN32C_GetNumber(USHORT *,UCHAR *);
extern ERRCODE gerR_IN32C_GetUnitInfo0(R_IN32C_UNITINF0_T *);
extern ERRCODE gerR_IN32C_GetUnitInfo1(R_IN32_UNITINFO_T *, R_IN32_UNITNETWORKSETTING_T *);
extern ERRCODE gerR_IN32C_GetCommState(ULONG *);
extern ERRCODE gerR_IN32C_GetCycStopState(R_IN32D_CYCLIC_STA_GET_T *);
extern USHORT  gusR_IN32C_GetNodeID(VOID);
extern ERRCODE gerR_IN32C_GetMulticastMACAddress(UCHAR *);
extern ERRCODE gerR_IN32C_GetMasterUserAppStatus(BOOL *,BOOL *,ULONG *);
extern ERRCODE gerR_IN32C_GetErrorCount(R_IN32C_ERRCNT_T *);
extern ERRCODE gerR_IN32C_ClrErrorCount(VOID);
extern ERRCODE gerR_IN32C_SetMACAddrTblDat(UCHAR, R_IN32C_MACADDRDAT_T *);
extern ERRCODE gerR_IN32C_GetUnicastMACAddr(USHORT, UCHAR *);
extern ERRCODE gerR_IN32C_SetCPUState(ULONG,ULONG,ULONG,ULONG,ULONG);
extern ERRCODE gerR_IN32C_SetRcvEnable(BOOL);
extern BOOL    gblR_IN32C_GetRcvEnable(VOID);
extern ERRCODE gerR_IN32C_GetMyMACAddress( UCHAR* );
extern ERRCODE gerR_IN32C_GetMotSyncState(ULONG*);

extern ERRCODE gerR_IN32C_CyclicRcvMain(VOID *,VOID *, BOOL);
extern ERRCODE gerR_IN32C_CyclicSndMain(const VOID *, const VOID *, BOOL);
extern ERRCODE gerR_IN32C_SetCyclicSndStopRequest(ULONG);
extern ERRCODE gerR_IN32C_ClrCyclicSndStopRequest(ULONG);

extern ERRCODE gerR_IN32C_TimeSerialToInfo(R_IN32_TIMEINFO_T *, const USHORT *);
extern ERRCODE gerR_IN32C_TimeInfoToSerial(const R_IN32_TIMEINFO_T *, USHORT *);

extern ERRCODE gerR_IN32C_SeqMain_ChangeStationNetworkNumber(VOID);
extern ERRCODE gerR_IN32C_SeqMain_ChangeActCommand(VOID);
extern ERRCODE gerR_IN32C_SeqMain_ChangeCommonParamStart(VOID);
extern ERRCODE gerR_IN32C_SeqMain_ChangeCommonParamFin(VOID);

#endif /*__R_IN32C_H_INCLUDED__*/

/*** EOF ***/
