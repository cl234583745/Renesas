/*
    SNMP
    TCP/IP network
    Copyright (c) 2014, eForce Co., Ltd. All rights reserved.
    
    2014-03-06 Created
*/

#ifndef SNMP_NET_H
#define SNMP_NET_H

/* Macro definitions */
#define SNMP_BCAST_ADR        0xffffffff    /* Broadcast address */ 
#define SNMP_REASM_MAX_LEN    65535         /* Reassembly size */

#endif

