/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_CmuOutLpBak.c                                             */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_Cmu.h"
#include "R_IN32T_ASIC.h"
#include "R_IN32T_RING.h"
#include "R_IN32T_FrmForm.h"
#include "R_IN32T_TxFrame.h"
#include "R_IN32T_RegChk.h"
#include "R_IN32T_Com.h"
#include "R_IN32T_CmuSub.h"
#include "R_IN32T_Data.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

const R_IN32T_NCYC_DATAINFO_T	gastR_IN32T_NCycDataInfo_OLB[] = {	


		{ (R_IN32T_NCYC_TDISNO_ENUM)(TDISC_NO_TRANSIENT),		(USHORT)1464,		(USHORT)0,	(R_IN32T_DATPTN_ENUM)R_IN32T_E_DATPTN_START		},
		{ (R_IN32T_NCYC_TDISNO_ENUM)(TDISC_NO_TRANSIENT + 1),	(USHORT)1108,		(USHORT)0,	(R_IN32T_DATPTN_ENUM)R_IN32T_E_DATPTN_CONTINUE	}
	};
#define R_IN32T_NCYC_DATAINFO_NUM	(ULONG)(sizeof(gastR_IN32T_NCycDataInfo_OLB)/sizeof(R_IN32T_NCYC_DATAINFO_T))


ERRCODE gerR_IN32T_OutsideLoopBackTest(
	R_IN32T_PORT_SEL_ENUM	eTestPort		
)
{
	R_IN32T_TRAN1_FRM_MAKE_T			stTran1Make;		
	R_IN32T_NCYC_TDISNO_ENUM			eTX_DIS;			
	R_IN32T_DATPTN_ENUM				eDatPtnSet;			
	R_IN32T_PORT_SEL_ENUM				eRxPort;			
	ULONG							ulRxDis;			
	ULONG							ulCount;			
	ULONG*							pulTxBufAdr;		
	USHORT							usTran1Size;		
	USHORT							usTemp;				
	ERRCODE							erRet;				
	ERRCODE							erResult;			
	USHORT							usOffset;
	R_TXSTART_TAG					stTXSTART;

	*(ULONG*)&stTXSTART = 	IN32(&(TX->R_TXSTART));

	erResult = R_IN32_OK;	

	ulRxDis = 0UL;

	if ( R_IN32T_E_PORT1 == eTestPort ) {
		eRxPort = R_IN32T_E_PORT2;
	}
	else {
		eRxPort = R_IN32T_E_PORT1;
	}

	R_IN32T_RING_DebugTxEnable();

	R_IN32T_RING_RepeatDisable();

	R_IN32T_RING_TxPortSet( eTestPort );
	
	(VOID)gerR_IN32D_RcvDisable();
	
	RX->ulNRPRWPCLR = 0x01;

	(VOID)gerR_IN32D_RcvEnable();

	stTran1Make.puchDesMACAddr = &gauchR_IN32T_RingMACAdrs[0];	
	stTran1Make.puchSouMACAddr = &gauchR_IN32T_TxMACAdrs[0];	
	stTran1Make.uchDataType = R_IN32T_DATATYPE_TRANSIENT1_GEN;	
	stTran1Make.usNodeID = R_IN32T_PMST_NODEID;				
	stTran1Make.usStNo = R_IN32T_PMST_STNO;					
	stTran1Make.ulOffsetAdr = 0UL;							
	stTran1Make.usDataSubType = (USHORT)0;					

	for ( ulCount = (ULONG)0; R_IN32T_NCYC_DATAINFO_NUM > ulCount; ulCount++ ) {

		if ( R_IN32_ERR == erResult ) {
			break;
		}
		else {
		}

		eTX_DIS = gastR_IN32T_NCycDataInfo_OLB[ulCount].eTX_DIS;

		usTran1Size = gastR_IN32T_NCycDataInfo_OLB[ulCount].usTran1Size;

		eDatPtnSet = gastR_IN32T_NCycDataInfo_OLB[ulCount].eDatPtnSet;

		stTran1Make.uchConnect = (UCHAR)(ulCount + 1UL);	
		stTran1Make.uchSeqNo = R_IN32T_TXF_TRAN_DIVLAST;		
		stTran1Make.uchIdentNo = (UCHAR)0;					
		stTran1Make.usTrnDatAllSize = usTran1Size;			
		stTran1Make.usTrnDatSize = usTran1Size;				

		R_IN32T_TxFrame_Tran1Head_Make( &stTran1Make, (USHORT)eTX_DIS );



		pulTxBufAdr = (ULONG*)(gaulR_IN32T_NCycTxBufAdr[(ULONG)eTX_DIS - TDISC_NO_TRANSIENT] + sizeof(R_IN32T_FRM_TRN1HDR_T));
		R_IN32T_Com_MemSet_BitShift_DWord( pulTxBufAdr, (ULONG)usTran1Size, eDatPtnSet );


		usTemp = usTran1Size + (USHORT)(sizeof(R_IN32T_FRM_TRN1HDR_T) + R_IN32T_DCS_SIZE);

		usOffset = (USHORT)gaulR_IN32T_NCycTxBufAdr[(ULONG)eTX_DIS - TDISC_NO_TRANSIENT] - gaulR_IN32T_NCycTxBufAdr[0];

		erRet = erR_IN32T_TxFrame_TxTran_1Frame( (USHORT)eTX_DIS, usTemp, usOffset );
		if ( R_IN32_ERR == erRet ) {
			erResult = R_IN32_ERR;
		}
		else {
		}

		gR_IN32R_WaitUS( R_IN32T_WAITUS_RX1FRM );

		if ( R_IN32_OK == erResult) {
			erRet = erR_IN32T_Sub_RxNonCyclicCheck( &gastR_IN32T_NCycDataInfo_OLB[ulCount], eRxPort, ulRxDis );
			if ( R_IN32_ERR == erRet ) {
				erResult = R_IN32_ERR;
			}
			else {
			}
		}
		else {
		}

		R_IN32T_RDTran_RDisClear( ulRxDis );

		ulRxDis++;
		if ( RD_NCYC_MAXNUM <= ulRxDis ) {
			ulRxDis = 0UL;
		}
		else {
		}
	}

	erRet = erR_IN32T_AsicRegCheck_NonCyclic( R_IN32T_NCYC_DATAINFO_NUM );
	if (R_IN32_ERR == erRet) {
		erResult = R_IN32_ERR;
	}
	else {
	}
	
	stTXSTART.b01ZSendStart = R_IN32_OFF;
	stTXSTART.b01ZSenddscpltClr = R_IN32_ON;
	stTXSTART.b01ZSendStopFunction = R_IN32_OFF;
	
	OUT32(&(TX->R_TXSTART),*(ULONG*)&stTXSTART);

	return( erResult );
}

/*** EOF ***/
