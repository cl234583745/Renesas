/**
 *******************************************************************************
 * @file  uart.c
 * @brief UART control program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2014,2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "modbus/modbus_uart.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define RX_FIFO_EMPTY			(1 << 0)
#define RX_FIFO_FULL			(1 << 1)
#define TX_FIFO_EMPTY			(1 << 2)
#define TX_FIFO_FULL			(1 << 3)


/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 *******************************************************************************
 * @brief Initialize UART driver and controller
 *
 * This function initializes the UART channel specified.
 * This function is modified from the RENESAS Driver implementation 
 * Allows setting specified baud rate, stop bit, parity and bit length
 *  
 *  @param ch           -- UART channel
 *  @param bit_length   -- Length of the data to be transmitted
 *  @param baud_rate    -- Baud rate
 *  @param parity_bit   -- Parity mode
 *  @param stop_bit     -- Stop bit
 *
 *  @retval ER_OK       -- if UART configured as per user settings successfully
 *  @retval ER_PARAM    -- if parameter is invalid
 *******************************************************************************
 */
ER_RET uart_init_modbus(uint8_t ch,
                        uint8_t bit_length,
                        uint32_t baud_rate,
                        uint32_t parity_bit,
                        uint32_t stop_bit)
{
	RIN_UART_TypeDef *RIN_UART;
	ER_RET ret_status = ER_OK;

	do
	{
		/** Select channel */
		switch (ch)
		{
		case UART_CHANNEL_0:
			{
				RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
				break;
			}
		case UART_CHANNEL_1:
			{
				RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
				break;
			}
		default:
			{
				ret_status = ER_PARAM;
				break;
			}
		}
		if (ER_OK != ret_status)
		{
			break;
		}

		/** Port setting */
		switch (ch)
		{
		case UART_CHANNEL_0: /** UART channel 0 */
			{
				RIN_GPIO->PFCE2B &= ~0x03;					/** P20 -> RXD0, P21 -> TXD0 */
				RIN_GPIO->PFC2B  &= ~0x03;
				RIN_GPIO->PMC2B  |=  0x03;
				break;
			}
		case UART_CHANNEL_1: /** UART channel 1 */
			{
				RIN_GPIO->PFCE3B &= ~0x03;					/** P30 -> RXD1, P31 -> TXD1 */
				RIN_GPIO->PFC3B  &= ~0x03;
				RIN_GPIO->PMC3B  |=  0x03;
				break;
			}
		default:
			{
				ret_status = ER_PARAM;
				break;
			}
		}
		if (ER_OK != ret_status)
		{
			break;
		}

		/** Initialize UART */
		/** Baud rate setting (baud at PCLK=100MHz) */

		switch (baud_rate)
		{
		case UART_BAUD_9600:
			{
				RIN_UART->URTJnCTL2 = (   1 << 13 ) |		/** prescalor */
									  ( 2604       ) ;		/** baud rate */
				break;
			}
		case UART_BAUD_19200:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 2604       ) ;
				break;
			}
		case UART_BAUD_31250:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 1600       ) ;
				break;
			}
		case UART_BAUD_38400:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 1302       );
				break;
			}
		case UART_BAUD_76800:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 651       );
				break;
			}
		case UART_BAUD_115200:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 434       );
				break;
			}
		case UART_BAUD_153600:
			{
				RIN_UART->URTJnCTL2 = (   0 << 13 ) |
									  ( 326       );
				break;
			}
		default:
			{
				ret_status = ER_PARAM;
				break;
			}
		}
		if (ER_OK != ret_status)
		{
			break;
		}

		/** Data format setting */ 
		RIN_UART->URTJnCTL1 = (  0 << 15 ) |				/** [15]    BF recieve    : non-detect */
							  (  5 << 12 ) |				/** [14:12] BF bit length : 13 */
							  (  0 <<  8 ) |				/** [ 8]    bit length    : 7 */
							  (  0 <<  7 ) |				/** [ 7: 6] parity        : none */
							  (  0 <<  6 ) |				/** [ 7: 6] parity        : none */
							  (  0 <<  5 ) |				/** [ 5]    tx level      : normal */
							  (  0 <<  4 ) |				/** [ 4]    rx level      : normal */
							  (  0 <<  3 ) |				/** [ 3]    loop back     : none */
							  (  0 <<  2 ) |				/** [ 2]    stop bit      : 1 */ 
							  (  1 <<  1 ) |				/** [ 1]    MSB or LSB    : LSB first */
							  (  1 <<  0 ) ;				/** [ 0]    TIT output    : when tx complete */

		/** Only 8 bit is handled because, 7 bit setting is initialized before */
		if (UART_LEN_8BIT == bit_length)
		{
			RIN_UART->URTJnCTL1 |= ( 1 <<  8 );
		}

		/** UART Parity */  
		switch (parity_bit)
		{
		case UART_PARITY_NONE:
			{
				/** Handled above */
				break;
			}
		case UART_PARITY_ODD:
			{
				RIN_UART->URTJnCTL1 |= ( 1 <<  7 ) ;
				break;
			}
		case UART_PARITY_EVEN:
			{
				RIN_UART->URTJnCTL1 = RIN_UART->URTJnCTL1 |
									  ( 1 <<  6 ) |
									  ( 1 <<  7 ) ;
				break;
			}
		default:
			{
				ret_status = ER_PARAM;
				break;
			}
		}
		if (ER_OK != ret_status)
		{
			break;
		}

		/** UART Stop Parity */  
		switch (stop_bit)
		{
		case UART_STOPBIT_1:
			{
				/** Handled above */
				break;
			}
		case UART_STOPBIT_2:
			{
				RIN_UART->URTJnCTL1 |= (  1 <<  2 );
				break;
			}
		default:
			{
				ret_status = ER_PARAM;
				break;
			}
		}
		if (ER_OK != ret_status)
		{
			break;
		}
		/** Data consistency error setting */
		RIN_UART->URTJnCTL0 = 0x00000000;					/** [ 0] Disable consistency check */

		/** Time out detection setting */
		RIN_UART->URTJnFCTL1 = 0x00000000;					/** [ 5: 0] disable to detect timeout */

		/** Communication enable setting */
		RIN_UART->URTJnCTL0 |= ((1 << 7) |					/** [ 7] Enable UARTJn operation */
								(1 << 6) |					/** [ 6] Enable transmission */
								(1 << 5));					/** [ 5] Enable reception */

		/** Specify a FIFO pointer */
		RIN_UART->URTJnFCTL0 = (( 15 << 8 ) |				/** [11: 8] Rx pointer for interrupt request */
								(  0 << 0 ));				/** [ 3: 0] Tx pointer for interrupt request */ 
	}
	while(0);

	return ret_status;
}

/**
 ******************************************************************************
  @brief  Send 1byte charactor code
  @param  ch         -- UART channel
  @param  data       -- 1byte charactor code
  @retval ER_OK      -- Successful
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_write(uint8_t ch, uint8_t data)
{
	RIN_UART_TypeDef *RIN_UART;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Wait until TX FIFO is not full
	//=========================================
	while ( (RIN_UART->URTJnFSTR1 & TX_FIFO_FULL) == TX_FIFO_FULL ) {
	}

	// Set transmit data
	RIN_UART->URTJnFTX = (uint32_t)data;

	return ER_OK;
}

/**
 ******************************************************************************
  @brief  Recieve 1byte charactor code
  @param  ch         -- UART channel
  @param  *data      -- 1byte charactor code
  @retval 1          -- Get data
  @retval 0          -- Not get data
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_read(uint8_t ch, uint8_t* data)
{
	RIN_UART_TypeDef *RIN_UART;

	//=========================================
	// Select channel
	//=========================================
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}
	//=========================================
	// Read data
	//=========================================
	if ((RIN_UART->URTJnFSTR1 & RX_FIFO_EMPTY) != RX_FIFO_EMPTY) {
		*data = RIN_UART->URTJnFRX;
		return 1;			/* Get data */
	} else {
		return 0;			/* Not get data */
	}
}

/**
 ******************************************************************************
  @brief  Recieve 1byte charactor code
  @param  ch         -- UART channel
  @retval ER_OK      -- 
  @retval ER_PARAM   -- Parameter error
 ******************************************************************************
*/
ER_RET uart_rxdata_ready(uint8_t ch)
{
	RIN_UART_TypeDef *RIN_UART;

	/* Select channel */
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}

	/* waiting for txdata empty */
	while (((RIN_UART->URTJnSTR0) & (1 << 0)) != 0) {
	}

	/* clear RX FIFO */
	RIN_UART->URTJnFSTC |= 0x21;							/** Clears the RX FIFO Overrun empty and RX FIFO empty */

	return ER_OK;
}


/**
 *******************************************************************************
  @brief  UART status event handler 
          This function clears all the errors in the UART
  @param  ch    -- UART channel
  @retval none
 *******************************************************************************
*/
ER_RET UAJ0TIS_IRQn_EventHandler(uint8_t ch)
{
	volatile uint32_t data;
	volatile uint32_t fifo_stat;
	volatile uint32_t i;
	uint32_t remain_recv;

	RIN_UART_TypeDef *RIN_UART;

	/** Select channel */
	switch (ch)
	{
		case 0:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART0_BASE;
			break;
		case 1:
			RIN_UART = (RIN_UART_TypeDef *)RIN_UART1_BASE;
			break;
		default:
			return ER_PARAM;
	}

	fifo_stat = 0;  
	fifo_stat = RIN_UART->URTJnSTR1;
	fifo_stat = 0;
	fifo_stat = RIN_UART->URTJnSTR1;
	fifo_stat = 0;  
	fifo_stat = RIN_UART->URTJnSTR0;

	/* Get the count of data in the FIFO */
	remain_recv = RIN_UART->URTJnFSTR0 >> 8;

	for(i=0;i<remain_recv;i++)
	{
		data = RIN_UART->URTJnFRX;
	}

	RIN_UART->URTJnSTC = 0x1E;
	RIN_UART->URTJnFSTC = 0x20;

	RIN_UART->URTJnCTL0 &= (~0x40);

	for(i=0;i<10;i++)
	{
	}

	RIN_UART->URTJnCTL0 |= 0x40;

	return ER_OK;
}


/**
 *******************************************************************************
  @brief  UART tx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ0TIT_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838469
}


/**
 *******************************************************************************
  @brief  UART rx interrupt
  @param  none
  @retval none
 *******************************************************************************
*/
void UAJ0TIR_IRQHandler( void )
{
	/* Do nothing */

	__DSB();		// Errata work aruond - ID:838469
}


/* *************************** End of File ********************************** */
