/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32U.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32U_H__
#define __R_IN32U_H__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32_Frame.h"
#include "R_IN32M4_0.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32U_NODE_NUMBER_MIN			1									
#define R_IN32U_NODE_NUMBER_MAX			120									

#define R_IN32U_NETWORK_NUMBER_MIN			1									
#define R_IN32U_NETWORK_NUMBER_MAX			239									


#define R_IN32U_PROTOCOL_VER				(FRAME_COM_PROTCOLVERSION1)			
#define R_IN32U_PROTOCOL_CLASS				(FRAME_COM_PRTCLCLASSFEILDNW)		
#define R_IN32U_MST_ARBIT_PRI				(FRAME_COM_NONMASTERPRIORITY)		
#define R_IN32U_FRAME_SUBTYPE				(FRAME_COM_FRMSUBCLASSTYPE1_1)		

#define R_IN32U_NETWORK_NUMBER				(UCHAR)0x01							
#define R_IN32U_STATION_NUMBER				(ULONG)0xffff						
#define R_IN32U_STATION_CLASS_UNIT			(FRAME_COM_STCLASSIO_RD)			
#define R_IN32U_STATION_CLASS_EQUIPMENT	(FRAME_COM_STCLASSFIELD)			
#define R_IN32U_STATION_CLASS				(R_IN32U_STATION_CLASS_UNIT | (R_IN32U_STATION_CLASS_EQUIPMENT << 4))	

#define R_IN32U_MAX_RX_POINT				(128)						
#define R_IN32U_MAX_RY_POINT				(128)						
#define R_IN32U_MAX_RWW_POINT				(64)						
#define R_IN32U_MAX_RWR_POINT				(64)						
#define R_IN32U_MAX_RX_SIZE				(R_IN32U_MAX_RX_POINT/8)		
#define R_IN32U_MAX_RY_SIZE				(R_IN32U_MAX_RY_POINT/8)		
#define R_IN32U_MAX_RWW_SIZE				(R_IN32U_MAX_RWW_POINT*2)		
#define R_IN32U_MAX_RWR_SIZE				(R_IN32U_MAX_RWR_POINT*2)		
#define R_IN32U_MAX_RWW_WSIZE				(R_IN32U_MAX_RWW_POINT)		
#define R_IN32U_MAX_RWR_WSIZE				(R_IN32U_MAX_RWR_POINT)		
#define R_IN32U_MIN_RX_SIZE					(0)		
#define R_IN32U_MIN_RY_SIZE					(0)		
#define R_IN32U_MIN_RWW_SIZE				(0)		
#define R_IN32U_MIN_RWR_SIZE				(0)		
#define R_IN32U_MIN_RWW_WSIZE				(0)		
#define R_IN32U_MIN_RWR_WSIZE				(0)		

#define R_IN32U_MAX_PORT_NUMBER			(2)
#define R_IN32U_TOKEN_HOLD_TIME			(23)
#define	R_IN32U_MIN_PORT_NUMBER			(1)

#define R_IN32U_STINF_IOTYPE				(FRAME_COM_STINF_IOTYPE_EXMIX)			

#define R_IN32U_UNIT_VERSION				(FRAME_COM_UNIT_VER)
#define R_IN32U_UNIT_MODEL_TYPE				(FRAME_COM_MACHINETYPE_PROTOCOLCONV)
#define R_IN32U_UNIT_MODEL_CODE				(0x00000002UL)							
#define R_IN32U_UNIT_VENDOR_CODE			(FRAME_COM_VENDORCODE)
#define R_IN32U_UNIT_MODEL_NAME				"LJ72GF15-T2         "					
#define R_IN32U_UNIT_VENDOR_NAME			"MITSUBISHI ELECTRIC CORP.       "		
/*                                          01234567890123456789012345678901 */
#define R_IN32U_UNIT_HW_VERSION			(USHORT)0x0001							
#define R_IN32U_UNIT_DEVICE_VERSION		(USHORT)0x0001							

#define R_IN32U_CTRL_INFOFLG				(R_IN32_OFF)								
#define R_IN32U_CTRL_VERSION				(0)
#define R_IN32U_CTRL_MODEL_TYPE			(0)
#define R_IN32U_CTRL_MODEL_CODE			(0)
#define R_IN32U_CTRL_VENDOR_CODE			(0)
#define R_IN32U_CTRL_MODEL_NAME			"                    "					
#define R_IN32U_CTRL_VENDOR_NAME			"                                "		
#define R_IN32U_CTRL_VENDOR_UNIT_INFO		(0)										

#define R_IN32U_SELFSTA_CPURUN				(SELF_STA_CPUSTOPORPAUSE)	
#define R_IN32U_SELFSTA_CPUERRFOUND		(SELF_STA_CPUNONERR)		

#define R_IN32U_LINKSCANTIME_CONST			(200UL*1000UL)	
#define R_IN32U_LINKSCANTIME_MIN			(200UL)			

#define R_IN32U_MACDELIV_TYPE				(R_IN32_OFF)		
#define R_IN32U_MACDELIV_SEQNUMBER			0				

#define R_IN32U_USER_INFORMATION			0UL

#define R_IN32U_ERRCODE					0

#define R_IN32U_OPTION_SUPPORT				(R_IN32_TRUE)		
#define R_IN32U_SLMP_SUPPORT				(R_IN32_TRUE)		
#define R_IN32U_SLMP_DIAGNOSIS_SUPPORT		(R_IN32_TRUE)		

#define R_IN32U_SYNC_SUPPORTED_MODE			(1)					

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32U_TAG {
	BOOL	blNMIUse;					
	BOOL	blInterruptUse;				
	BOOL	blTransientReceiveEnable;	
	BOOL	blSynchronousInterruptUse;	
} R_IN32U_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

extern ULONG	gulR_IN32U_MAX_RX_SIZE;		
extern ULONG	gulR_IN32U_MAX_RY_SIZE;		
extern ULONG	gulR_IN32U_MAX_RWW_WSIZE;		
extern ULONG	gulR_IN32U_MAX_RWR_WSIZE;		
extern ULONG	gulR_IN32U_MAX_RWW_SIZE;		
extern ULONG	gulR_IN32U_MAX_RWR_SIZE;		
extern ULONG	gulR_IN32U_MIN_RX_SIZE;		
extern ULONG	gulR_IN32U_MIN_RY_SIZE;		
extern ULONG	gulR_IN32U_MIN_RWW_WSIZE;		
extern ULONG	gulR_IN32U_MIN_RWR_WSIZE;		
extern ULONG	gulR_IN32U_MIN_RWW_SIZE;		
extern ULONG	gulR_IN32U_MIN_RWR_SIZE;		

extern ULONG	gulR_IN32U_STATION_CLASS;				
extern ULONG	gulR_IN32U_STATION_CLASS_UNIT;			
extern ULONG	gulR_IN32U_STATION_CLASS_EQUIPMENT;	

extern ULONG	gulR_IN32U_MAX_PORT_NUMBER;
extern ULONG	gulR_IN32U_TOKEN_HOLD_TIME;

extern ULONG	gulR_IN32U_STINF_IOTYPE;

extern ULONG	gulR_IN32U_STATION_MODE;

extern ULONG	gulR_IN32U_UNIT_VERSION;
extern ULONG	gulR_IN32U_UNIT_MODEL_TYPE;
extern ULONG	gulR_IN32U_UNIT_MODEL_CODE;
extern ULONG	gulR_IN32U_UNIT_VENDOR_CODE;
extern USHORT	gusR_IN32U_UNIT_HW_VERSION;
extern USHORT	gusR_IN32U_UNIT_DEVICE_VERSION;

extern ULONG	gulR_IN32U_MACDELIV_TYPE;

extern ULONG	gulR_IN32U_NCYCRCV_VALID;		
extern ULONG	gulR_IN32U_TRANRCV_MODE;		
extern ULONG	gulR_IN32U_SELFSTA_TRANRCV;	
extern ULONG	gulR_IN32U_OPTION_SUPPORT;		
extern ULONG	gulR_IN32U_SLMP_SUPPORT;		
extern ULONG	gulR_IN32U_SLMP_DIAGNOSIS_SUPPORT;	

extern R_IN32_PHY_SETTING_T	gstPHYSetting[2];

extern ULONG	gulR_IN32U_SYNC_FUNCTION1;		
extern ULONG	gulR_IN32U_DEVICE_SET_STATUS;	
extern ULONG	gulR_IN32U_DEVICE_INIT;			
extern ULONG	gulR_IN32U_SYNC_FUNCTION2;		
extern ULONG	gulR_IN32U_SYNC_SET_FOLLOWUP;	
extern ULONG	gulR_IN32U_SYNC_FUNCTION3;		
extern ULONG	gulR_IN32U_SYNC_SUPPORTED_MODE;	

extern ULONG	gulR_IN32U_FAILEDPROCESS1;		
extern ULONG	gulR_IN32U_FAILEDPROCESS2;		

extern ULONG	gulR_IN32U_SELFSTA_CPURUN;			
extern ULONG	gulR_IN32U_SELFSTA_CPUERRFOUND;	
extern ULONG	gulR_IN32U_ERRCODE;				
extern ULONG	gulR_IN32U_USER_INFORMATION;		

extern R_IN32U_T	gstR_IN32U;


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern ERRCODE gerR_IN32U_Init( VOID );
extern ERRCODE gerR_IN32U_Update( const R_IN32_UNITINFO_T*, const R_IN32_UNITINIT_T* );


#endif /* __R_IN32U_H__ */

/*** EOF ***/
