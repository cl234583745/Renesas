/***********************************************************************
    VITESSE VSC8641 10/100/Giga PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
 ***********************************************************************/

#ifndef _DDR_PHY_VSC8641_H_
#define _DDR_PHY_VSC8641_H_

#include "COMMONDEF.h"

#ifdef __cplusplus
extern "C" {
#endif

#define PHY_REG_INT_MASK        ( 0x0019 )  /*!< Register 25: Interrupt mask                                    */
#define PHY_REG_INT_STATUS      ( 0x001a )  /*!< Register 26: Interrupt status                                  */
#define PHY_REG_AUX_CNTSTAT     ( 0x001c )  /*!< Register 28: Auxiliary control and status                      */

// Register 28: Auxiliary control and status
#define VSC8641_DUPLEX_MASK     (0x0020)            /*!< Duplex type mask   */
#define VSC8641_DUPLEX_HALF     (0x0000)            /*!< Harf duplex        */
#define VSC8641_DUPLEX_FULL     (0x0020)            /*!< Full duplex        */
#define VSC8641_SPEED_MASK      (0x0018)            /*!< Speed status mask  */
#define VSC8641_SPEED_10M       (0x0000)            /*!<   10BASE-T         */
#define VSC8641_SPEED_100M      (0x0008)            /*!<  100BASE-T         */
#define VSC8641_SPEED_1G        (0x0010)            /*!< 1000BASE-T         */

// Register 25: Interrupt mask
// Register 26: Interrupt status
#define VSC8641_INT_MDINT_ENA   (0x8000)    /*!< [15] MDINT interrupt status enable */
#define VSC8641_INT_SPEED_CHG   (0x4000)    /*!< [14] Speed state change            */
#define VSC8641_INT_LINK_CHG    (0x2000)    /*!< [13] Link  state change            */
#define VSC8641_INT_FDX_CHG     (0x1000)    /*!< [12] FDX   state change            */
#define VSC8641_INT_NEGO_ERR    (0x0800)    /*!< [11] Auto-negotiation error        */
#define VSC8641_INT_NEGO_CMP    (0x0400)    /*!< [10] Auto-negotiation complete     */
#define VSC8641_INT_PWR_DET     (0x0200)    /*!< [ 9] Inline powered device detect  */
#define VSC8641_INT_LINK_DWN    (0x0004)    /*!< [ 2] Link speed downshift detect   */
#define VSC8641_INT_MS_ERR      (0x0002)    /*!< [ 1] Master/Slave resolution error */


#ifdef __cplusplus
}
#endif
#endif /* _DDR_PHY_VSC8641_H_ */

