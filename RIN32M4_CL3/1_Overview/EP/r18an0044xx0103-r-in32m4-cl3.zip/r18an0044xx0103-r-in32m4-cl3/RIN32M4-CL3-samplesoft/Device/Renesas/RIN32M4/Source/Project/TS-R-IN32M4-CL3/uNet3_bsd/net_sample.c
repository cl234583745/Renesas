/***********************************************************************
                  ��Net3 Network sample program

    Copyright (c) 2021 eForce Co., Ltd. All rights reserved.
    2013-04-10: Created.
    2021-05-31: Deleted unnecessary included files.
 ***********************************************************************/

#include "sys/socket.h"
#include <stdio.h>

ER net_sample(void)
{
    /* Initialize TCP/IP Stack */
    ER ercd;

    printf("- uNet3 lib ver%s\n",unet3bsd_get_version(1));

    ercd = net_ini();
    if (ercd != E_OK) {
        return ercd;
    }

    /* Initialize Ethernet Driver */
    ercd = net_dev_ini(1);
    if (ercd != E_OK) {
        return ercd;
    }

    /* BSD wrapper */
    ercd = unet3_bsd_init();

    return ercd;

}
