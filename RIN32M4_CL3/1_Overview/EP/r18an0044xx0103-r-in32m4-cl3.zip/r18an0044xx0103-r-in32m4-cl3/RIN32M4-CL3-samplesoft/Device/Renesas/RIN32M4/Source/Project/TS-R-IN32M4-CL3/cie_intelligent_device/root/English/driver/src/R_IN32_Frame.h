/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32_Frame.h                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32_FRAME_H_INCLUDED_
#define __R_IN32_FRAME_H_INCLUDED_

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_0.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/


#define	FRAME_COM_TOADDRFORBROADCAST		(USHORT)0xFFFF			
#define	FRAME_COM_FRMTYPE					(USHORT)0x0F89			
#define	FRAME_COM_STCLASSPRIMAST			 (UCHAR)0x00			
#define	FRAME_COM_STCLASSCTRLMAST			 (UCHAR)0x01			
#define	FRAME_COM_STCLASSLOCAL				 (UCHAR)0x02			
#define	FRAME_COM_STCLASSIO_ID				 (UCHAR)0x03			
#define	FRAME_COM_STCLASSIO_RD				 (UCHAR)0x04			
#define	FRAME_COM_STCLASSIO_IO				 (UCHAR)0x05			
#define	FRAME_COM_STCLASSMOTIONCTRL			 (UCHAR)0x00			
#define	FRAME_COM_STCLASSMOTIONDRVR			 (UCHAR)0x01			
#define	FRAME_COM_STCLASSHUB				 (UCHAR)0x00			
#define	FRAME_COM_STCLASSCCLINKGW			 (UCHAR)0x01			
#define	FRAME_COM_STCLASSIPCOMMGW			 (UCHAR)0x02			
#define	FRAME_COM_STCLASSFIELD				 (UCHAR)0x03			
#define	FRAME_COM_STCLASSMOTION				 (UCHAR)0x04			
#define	FRAME_COM_STCLASSGW_HUB				 (UCHAR)0x05			
#define	FRAME_COM_NOTSETSTNO				(USHORT)0xFFFF			
#define	FRAME_COM_PROTCOLVERSION1			 (UCHAR)0x00			
#define	FRAME_COM_PROTCOLVERSION2			 (UCHAR)0x01			
#define	FRAME_COM_PRTCLCLASSCTRLNW			 (UCHAR)0x00			
#define	FRAME_COM_PRTCLCLASSFEILDNW			 (UCHAR)0x01			
#define	FRAME_COM_PRTCLCLASSMOTIONNW		 (UCHAR)0x02			
#define	FRAME_COM_FRMSUBCLASSTYPE1_0		 (UCHAR)0x00			
#define	FRAME_COM_FRMSUBCLASSTYPE1_1		 (UCHAR)0x01			











#define	FRAME_COM_VENDORCODE				(USHORT)0x0000			
#define	FRAME_COM_UNITCODE					 (ULONG)0x00000000		

#define	FRAME_COM_NONMASTERPRIORITY			 (UCHAR)0x00			
#define	FRAME_COM_TOKEN_HOLDTIME			(USHORT)0x0000			
#define	FRAME_COM_PORT_DISCONNECT			 (UCHAR)0x0				
#define	FRAME_COM_PORT_LINKUP1G				 (UCHAR)0x1				
#define	FRAME_COM_PORT_LINKUP100M			 (UCHAR)0x2				
#define	FRAME_COM_PORT_LINKUP10M			 (UCHAR)0x3				
#define	FRAME_COM_PORT_FULL					 (UCHAR)0x0				
#define	FRAME_COM_PORT_HALF					 (UCHAR)0x4				
#define	FRAME_COM_TOKENHOLDTIME				(USHORT)10				

#define	FRAME_COM_STINF_IOTYPE_EXMIX		 (UCHAR)0x00			
#define	FRAME_COM_STINF_IOTYPE_INPUT		 (UCHAR)0x01			
#define	FRAME_COM_STINF_IOTYPE_OUTPUT		 (UCHAR)0x02			
#define	FRAME_COM_STINF_IOTYPE_MIX			 (UCHAR)0x03			
#define	FRAME_COM_UNIT_VER					 (UCHAR)COM_DRIVER_VER	
#define	FRAME_COM_MACHINETYPE_PLC			(USHORT)0x0001			
#define	FRAME_COM_MACHINETYPE_PC			(USHORT)0x0002			
#define	FRAME_COM_MACHINETYPE_REMOTEIO		(USHORT)0x0003			
#define	FRAME_COM_MACHINETYPE_NC			(USHORT)0x0004			
#define	FRAME_COM_MACHINETYPE_ROBOT			(USHORT)0x0005			
#define	FRAME_COM_MACHINETYPE_MOTION		(USHORT)0x0006			
#define	FRAME_COM_MACHINETYPE_THUB			(USHORT)0x0007			
#define	FRAME_COM_MACHINETYPE_PROTOCOLCONV	(USHORT)0x001F			
#define	FRAME_COM_EXFUNC_NONTRANSIENTRECV	 (UCHAR)0x00			
#define	FRAME_COM_EXFUNC_TRANSIENTRECV		 (UCHAR)0x01			
#define	FRAME_COM_EXFUNC_NONPRMSTSET		 (UCHAR)0x00			
#define	FRAME_COM_EXFUNC_PRMSTSET		 	 (UCHAR)0x01			

#define	MYSTATUS_COMMAND_MSTACTIONSTAT		(USHORT)0x0001		
#define	MYSTATUS_COMMAND_CYC_OPE_PACK		(USHORT)0x0004		
#define	MYSTATUS_COMMAND_MSTSTAT_USERAPP	(USHORT)0x0008		
#define	MYSTATUS_COMMAND_MSTSTAT_USERAPPERR	(USHORT)0x0010		
#define	MYSTATUS_COMMAND_MACADR_RETVAL_MASK	(USHORT)0x0F00		
#define	MYSTATUS_COMMAND_MSTSTAT_USERAPP_SHIFT		4
#define	MYSTATUS_COMMAND_MSTSTAT_USERAPPERR_SHIFT	5
#define	MYSTATUS_COMMAND_MACADR_RETVAL_SHIFT		8

#define	MYSTATUS_SELF_CPURUNCOND_MASK		(USHORT)0x0003		
#define	MYSTATUS_SELF_CPUERRFOUNDCOND		(USHORT)0x000C		
#define	MYSTATUS_SELF_SCOREERROR			(USHORT)0x0800		
#define	MYSTATUS_SELF_TRANRECPPROP			(USHORT)0x4000		
#define	MYSTATUS_SELF_TRANRECPPROP_SHIFT			14

#define	FRAME_COM_SYNCFLG					(UCHAR)0x03		

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _FRAME_UNIT_INFO_TAG {
	UCHAR	b4ZUnitType:				4;			
	UCHAR	b3ZEquipmentType:			3;			
	UCHAR	b1Reserved1:				1;			
} FRAME_UNIT_INFO_T;

typedef struct _FRAME_INFO_TAG {
	USHORT	b4ZProtocolClassifcation:		4;		
	USHORT	b4ZProtocolVersion:				4;		
	USHORT	b8Reserved1:					8;		
} FRAME_INFO_T;

typedef struct _SETUPACK_STATION_INFO_TAG {
	UCHAR	b2ZIOTyep:					2;			
	UCHAR	b6Reserved1:				6;			
} SETUPACK_STATION_INFO_T;

typedef struct _SETUPACK_ETC_INFO_TAG {
	UCHAR	b1ZTransientRecvMode:		1;			
	UCHAR	b1ZStationMode:				1;			
	UCHAR	b6ZReserved1:				6;			
} SETUPACK_ETC_INFO_T;

typedef struct _SETUPACK_ETC_INFO2_TAG {
	UCHAR	b1ZSync:					1;			
	UCHAR	b1ZDeviceSet:				1;			
	UCHAR	b1ZDeviceInit:				1;			
	UCHAR	b4ZReserved1:				5;			
} SETUPACK_ETC_INFO2_T;

typedef struct _SETUPACK_ETC_INFO3_TAG {
	UCHAR	b2ZReserved1:				2;			
	UCHAR	b1ZSync3:					1;			
	UCHAR	b4ZReserved2:				5;			
} SETUPACK_ETC_INFO3_T;

typedef struct _MYSTATUS_COMMAND_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZMasterActionStation:			1;		
	USHORT	b2ZReserved1:					2;		
	USHORT	b1ZCyclicOpeInstructPackage:	1;		
	USHORT	b1ZMasterStationUserApp:		1;		
	USHORT	b1ZMasterStationUserAppErr:		1;		
	USHORT	b2ZReserved2:					2;		
	USHORT	b4ZMacAdrDistributeRetVal:		4;		
	USHORT	b4ZReserved3:					4;		
		} stBit;
	} uniMyStaCmd;
} MYSTATUS_COMMAND_T;

typedef struct _MYSTATUS_SELF_STA_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b2ZMstLocCPURunCond:			2;		
	USHORT	b2ZMstLocCPUErrFoundCond:		2;		
	USHORT	b7ZReserve1:					7;		
	USHORT	b2ZScoreError:					1;		
	USHORT	b2ZReserve2:					2;		
	USHORT	b1ZTranRecPropriety:			1;		
	USHORT	b1ZReserve3:					1;		
		} stBit;
	} uniMyStaSelf;
} MYSTATUS_SELF_STA_T;

typedef struct _MYSTATUS_FRAME_REG_TAG {
	USHORT	usToAddress1;							
	USHORT	usToAddress2;							
	USHORT	usToAddress3;							
	USHORT	usFromAddress1;							
	USHORT	usFromAddress2;							
	USHORT	usFromAddress3;							
	USHORT	usType;									
	UCHAR	uchFrameClassification;					
	UCHAR	uchDataClassification;					
	USHORT	usNodeID;								
	UCHAR	uchSyncFlag;							
	UCHAR	uchStationClassification;				
	USHORT	usMyStationNumber;						
	FRAME_INFO_T			stFRAME_INFO;			
	ULONG	ulHEC;									
	UCHAR	uchSequentialNumber;					
	UCHAR	uchTemporaryNetworkNumber;				
	USHORT	usStationCommand;						
	USHORT	usCyclicState;							
	USHORT	usMyStationUnitState;					
	ULONG	ulMyStationErrorCode;					
	USHORT	usPortConnectState;						
	USHORT	usPortStatisticsInformation;			
	UCHAR	uchPortHeadNumber;						
	UCHAR	uchReserved2;							
	USHORT	usReserved3;							
	UCHAR	uchReserved4;							
	UCHAR	uchSlaveEventRcvCond;					
	USHORT	usSlaveEventRcvCondCount;				
	UCHAR	auchMyStationCnrlInfo[4];				
	ULONG	ulDCS;									
	ULONG	ulFCS;									
} MYSTATUS_FRAME_REG_T;

typedef struct _NONCICLIC_FRAME_REG_TAG {
	USHORT	usToAddress1;							
	USHORT	usToAddress2;							
	USHORT	usToAddress3;							
	USHORT	usFromAddress1;							
	USHORT	usFromAddress2;							
	USHORT	usFromAddress3;							
	USHORT	usType;									
	UCHAR	uchFrameClassification;					
	UCHAR	uchDataClassification;					
	USHORT	usNodeID;								
	UCHAR	uchConnectionInformation;				
	UCHAR	uchReserve;								
	USHORT	usMyStationNumber;						
	FRAME_INFO_T			stFRAME_INFO;			
	ULONG	ulHEC;									
} NONCICLIC_FRAME_REG_T;

typedef struct _PARAMETER_SETTING_INFO_TAG {
	UCHAR	b1ZSwitchInfo:					1;			
	UCHAR	b1ZModeInfo:					1;			
	UCHAR	b1ZParamInfo:					1;			
	UCHAR	b5ZDummy:						5;			
} PARAMETER_SETTING_INFO_TAG;
typedef struct _PARAMETER_MODE_COMMAND_TAG {
	UCHAR	b1ZCyclicStop_Reseve:			1;			
	UCHAR	b1ZCyclicStop_Repeat:			1;			
	UCHAR	b1ZCyclicStop_StOver:			1;			
	UCHAR	b1ZCyclicStop_Master:			1;			
	UCHAR	b1ZCyclicDuplicate_Master:		1;			
	UCHAR	b3ZDummy1:						3;			
} PARAMETER_MODE_COMMAND_TAG;
typedef struct _PARAMETER_OUT_COMMAND_TAG {
	UCHAR	b1ZOutside0:					1;			
	UCHAR	b1ZOutside1:					1;			
	UCHAR	b1ZOutside2:					1;			
	UCHAR	b1ZOutside3:					1;			
	UCHAR	b1ZOutside4:					1;			
	UCHAR	b1ZOutside5:					1;			
	UCHAR	b1ZOutside6:					1;			
	UCHAR	b1ZOutside7:					1;			
} PARAMETER_OUT_COMMAND_TAG;
typedef struct _PARAMETER_SET_COMMAND_TAG {
	UCHAR	b1ZCyclicStop_Invalid:			1;			
	UCHAR	b1ZErrOutputMode:				1;			
	UCHAR	b1ZSyncOutput:					1;			
	UCHAR	b1ZCyclicRun:					1;			
	UCHAR	b1ZClassification:				1;			
	UCHAR	b1ZSyncSetAbnormal:				1;			
	UCHAR	b2ZDummy1:						2;			
} PARAMETER_SET_COMMAND_TAG;
typedef struct _PARAMETER_STATION_INFO_TAG {
	USHORT	b1ZStUnitInfo:					1;			
	USHORT	b1ZCyclicInfo:					1;			
	USHORT	b1ZDivideInfo:					1;			
	USHORT	b1ZSyncInfo:					1;			
	USHORT	b4ZDummy1:						4;			
	USHORT	b4ZDummy2:						4;			
	USHORT	b4ZMasterID:					4;			
} PARAMETER_STATION_INFO_TAG;
typedef struct _PARAMETER_COMMONID_TAG {
	USHORT	usYear;										
	UCHAR	uchMonth;									
	UCHAR	uchDay;										
	UCHAR	uchHour;									
	UCHAR	uchMin;										
	UCHAR	uchSec;										
	UCHAR	uchStationNo;								
	ULONG	ulSumcheckCode;								
} PARAMETER_COMMONID_TAG;
typedef struct _PARAMETER_DATA_TAG {
	UCHAR	uchReserve2;								
	UCHAR	uchCyclicSendMasterID;						
	USHORT	usMasterIDActionSet;						
	UCHAR	uchRYFrameSequentialNumber;					
	UCHAR	uchRYFrameByteEnableInfo;					
	USHORT	usRYFrameCyclicDataSize;					
	USHORT	usRYFrameAreaOffsetAddress;					
	USHORT	usReserve3;									
	UCHAR	uchRWwFrameSequentialNumber;				
	UCHAR	uchReserve4;								
	USHORT	usRWwFrameCyclicDataSize;					
	USHORT	usRWwFrameAreaOffsetAddress;				
	USHORT	usReserve5;									
	UCHAR	uchRXFrameSequentialNumber;					
	UCHAR	uchRXFrameByteEnableInfo;					
	USHORT	usRXFrameCyclicDataSize;					
	ULONG	ulRXOffsetAddress;							
	UCHAR	uchRWrFrameSequentialNumber;				
	UCHAR	uchReserve6;								
	USHORT	usRWrFrameCyclicDataSize;					
	ULONG	ulRWrOffsetAddress;							
	ULONG	ulGroupReservation;							
	USHORT	usMasterWatchTimerSetNumber;				
	USHORT	usReserve7;									
	UCHAR	uchReserve8;								
	UCHAR	uchMasterRYByteEnableInfo;					
	USHORT	usMasterRYDataSize;							
	ULONG	ulMasterRYOffsetAddress;					
	USHORT	usReserve9;									
	USHORT	usMasterRWwDataSize;						
	ULONG	ulMasterRWwOffsetAddress;					
	UCHAR	uchReserve10;								
	UCHAR	uchMasterRXByteEnableInfo;					
	USHORT	usMasterRXDataSize;							
	ULONG	ulMasterRXOffsetAddress;					
	USHORT	usReserve11;								
	USHORT	usMasterRWrDataSize;						
	ULONG	ulMasterRWrOffsetAddress;					
} PARAMETER_DATA_TAG;

typedef struct _PARAMCHECK_FRAME_REG_TAG {
	NONCICLIC_FRAME_REG_T		COMMON;					
	USHORT	usReserve2;									
	USHORT	usMasterIDActionSet;						
	PARAMETER_COMMONID_TAG		PRAMID;					
	UCHAR	auchDummy1[12];								
	ULONG	ulDCS;										
	ULONG	ulFCS;										
} PARAMCHECK_FRAME_REG_TAG;

typedef struct _PARAMETER_FRAME_REG_TAG {
	NONCICLIC_FRAME_REG_T		COMMON;					
	PARAMETER_SETTING_INFO_TAG	SETCONTENT;				
	UCHAR	uchNetworkNumberSet;						
	USHORT	usStationNumberSet;							
	PARAMETER_MODE_COMMAND_TAG	MODECOMMAND;			
	PARAMETER_OUT_COMMAND_TAG	OUTCOMMAND;				
	PARAMETER_SET_COMMAND_TAG	SETCOMMAND;				
	UCHAR	uchStationClassification;					
	PARAMETER_COMMONID_TAG		PRAMID;					
	PARAMETER_DATA_TAG			PRAMDATA;				
	ULONG	ulDCS;										
	ULONG	ulFCS;										
} PARAMETER_FRAME_REG_TAG;

typedef struct _PARAMCOMD_FRAME_REG_TAG {
	NONCICLIC_FRAME_REG_T		COMMON;					
	PARAMETER_SETTING_INFO_TAG	SETCONTENT;				
	UCHAR	uchNetworkNumberSet;						
	USHORT	usStationNumberSet;							
	PARAMETER_MODE_COMMAND_TAG	MODECOMMAND;			
	PARAMETER_OUT_COMMAND_TAG	OUTCOMMAND;				
	PARAMETER_SET_COMMAND_TAG	SETCOMMAND;				
	UCHAR	uchReserve;									
	UCHAR	auchDummy1[20];								
	ULONG	ulDCS;										
	ULONG	ulFCS;										
} PARAMCOMD_FRAME_REG_TAG;

#endif	/* __R_IN32_FRAME_H_INCLUDED_ */

/*** EOF ***/
