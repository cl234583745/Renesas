/**
 *******************************************************************************
 * @file  flash.c
 * @brief Flash ROM control program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "flash.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static void flash_cmd_word_program(uint32_t addr, uint16_t data);
static void flash_cmd_sector_erase(uint32_t addr);
static void flash_cmd_chip_erase(void);
#if FLASH_SUPPORT_CFI!=0
static void flash_cmd_cfi_entry(void);
static void flash_cmd_cfi_exit(void);
#endif

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/

/**
 ******************************************************************************
 
  @brief  Initialize
  @param  -
  @return Error condition
  @retval ER_OK -- Successful
 
 ******************************************************************************
 */
ER_RET flash_init(void)
{
#if 0
	/* port */
	RIN_RTPORT->RPMC2B |= 0xff;			/* RP20 : BCYSTZ */
										/* RP21 : A21    */
										/* RP22 : A22    */
										/* RP23 : A23    */
										/* RP24 : A24    */
										/* RP25 : A25    */
										/* RP26 : A26    */
										/* RP27 : A27    */
#endif
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Read Data
  @param  [out] *buf -- Buffer address
  @param  [in]  addr -- Read address
  @param  [in]  size -- Read size (byte)
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET flash_read_data(uint16_t* buf, uint32_t addr, uint32_t size)
{
	uint32_t i;
	
	/* Parameter Check */
	if (((addr & 0x01) != 0)
	||  ((size & 0x01) != 0)
	||  ((addr + size) > FLASH_DEVICE_SIZE))
	{
		return ER_PARAM;
	}
	
	/* Read Data */
	addr += FLASH_BASE_ADDRESS;
	for (i = 0; i < size; i += 2)
	{
		*buf++ = *(__IO uint16_t*)(addr + i);
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Program
  @param  [in] *buf -- buffer address
  @param  [in] addr -- Program base address
  @param  [in] size -- Program size
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET flash_program(uint16_t* buf, uint32_t addr, uint32_t size)
{
	uint32_t program_offset;
	uint32_t program_size;
	uint32_t i;
	
	/* Parameter Check */
	if (((addr & 0x01) != 0)
	||  ((size & 0x01) != 0)
	||  ((addr + size) > FLASH_DEVICE_SIZE))
	{
		return ER_PARAM;
	}
	
	/* Erase and Program */
	while (size > 0)
	{
		/* get offset and size */
		program_offset = (addr & FLASH_BYTE_INDEX_BIT);
		if (size > (FLASH_SECTOR_SIZE - program_offset))
		{
			program_size = (FLASH_SECTOR_SIZE - program_offset);
		}
		else
		{
			program_size = size;
		}
#if 0
		/* Erase */
		flash_cmd_sector_erase(addr);
#endif
		/* Program */
		for (i = 0; i < program_size; i += 2)
		{
			flash_cmd_word_program((addr + i), *buf++);
		}
		
		/* update address and size */
		addr += program_size;
		size -= program_size;
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Erase
  @param  [in] addr -- Erase base address
  @param  [in] size -- Erase size
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_PARAM -- Parameter Error
 
 ******************************************************************************
 */
ER_RET flash_erase(uint32_t addr, uint32_t size)
{
	uint32_t erase_offset;
	uint32_t erase_size;
	
	/* Parameter Check */
	if ((addr + size) > FLASH_DEVICE_SIZE)
	{
		return ER_PARAM;
	}
	
	/* Erase */
	if (((addr       ) < (                    FLASH_SECTOR_SIZE))
	&&  ((addr + size) > (FLASH_DEVICE_SIZE - FLASH_SECTOR_SIZE)))
	{
		/* chip erase */
		flash_cmd_chip_erase();
	}
	else
	{
		/* sector erase */
		while (size > 0)
		{
			/* get offset and size */
			erase_offset = (addr & FLASH_BYTE_INDEX_BIT);
			if (size > (FLASH_SECTOR_SIZE - erase_offset))
			{
				erase_size = (FLASH_SECTOR_SIZE - erase_offset);
			}
			else
			{
				erase_size = size;
			}
			
			/* sector erase */
			flash_cmd_sector_erase(addr);
			
			/* update address and size */
			addr += erase_size;
			size -= erase_size;
		}
	}
	
	return ER_OK;
}

/**
 ******************************************************************************
 
  @brief  Read CFI Table
  @param  [out] *buf -- buffer address 
  @param  [in]  addr -- read address 
  @return Error condition
  @retval ER_OK    -- Successful
  @retval ER_INVAL -- CFI configuration is disabled
 
 ******************************************************************************
 */
ER_RET flash_read_cfi(uint16_t* buf, uint32_t addr)
{
#if FLASH_SUPPORT_CFI!=0
	/* Parameter Check */
	if (((addr & 0x01) != 0)
	||  ((addr       ) >= FLASH_DEVICE_SIZE))
	{
		return ER_PARAM;
	}
	
	/* CFI mode on */
	flash_cmd_cfi_entry();
	
	/* Read */
	addr += FLASH_BASE_ADDRESS;
	*buf = *(__IO uint16_t*)(addr);
	
	/* CFI mode off */
	flash_cmd_cfi_exit();
	
	return ER_OK;
#else	/* FLASH_SUPPORT_CFI==0 */
	return ER_INVAL;
#endif	/* FLASH_SUPPORT_CFI!=0 */
}

/**
 ******************************************************************************
  @brief  Word program command 
  @param  [in] addr -- program address (byte address)
  @param  [in] data -- program data
  @return none
 ******************************************************************************
 */
static void flash_cmd_word_program(uint32_t addr, uint16_t data)
{
	/* Write Unlock Cycles */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x0555 << 1)) = 0x00aa;
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x02AA << 1)) = 0x0055;
	
	/* Write Program Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x0555 << 1)) = 0x00a0;
	
	/* Program Data to Address */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (addr)) = data;
	
	/* Data# Polling */
	while (*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (addr)) != data)
	{
		__NOP();
	}
	
	return;
}

/**
 ******************************************************************************
  @brief  Sector erase command 
  @param  [in] addr  -- erase address (byte address)
  @return none
 ******************************************************************************
 */
static void flash_cmd_sector_erase(uint32_t addr)
{
	/* Write Unlock Cycles */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0xaa;
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x2AA << 1)) = 0x55;
	
	/* Setup Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0x80;
	
	/* Write Unlock Cycles */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0xaa;
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x2AA << 1)) = 0x55;
	
	/* Sector Erase Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (addr & FLASH_SECTOR_INDEX_BIT)) = 0x30;
	
	/* Data# Polling */
	while (*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (addr & FLASH_SECTOR_INDEX_BIT)) != 0xffff)
	{
		__NOP();
	}
	
	return;
}

/**
 ******************************************************************************
  @brief  Chip erase command 
  @param  -
  @return none
 ******************************************************************************
 */
static void flash_cmd_chip_erase(void)
{
	/* Write Unlock Cycles */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0xaa;
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x2AA << 1)) = 0x55;
	
	/* Setup Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0x80;
	
	/* Write Unlock Cycles */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0xaa;
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x2AA << 1)) = 0x55;
	
	/* Chip Erase Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x555 << 1)) = 0x10;
	
	/* Data# Polling */
	while (*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x000 << 1)) != 0xffff)
	{
		__NOP();
	}
	
	return;
}

#if FLASH_SUPPORT_CFI!=0
/**
 ******************************************************************************
  @brief  CFI entry command 
  @param  - 
  @return none 
 ******************************************************************************
 */
static void flash_cmd_cfi_entry(void)
{
	/* CFI Entry Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x055 << 1)) = 0x98;
}

/**
 ******************************************************************************
  @brief  CFI exit command 
  @param  - 
  @return none 
 ******************************************************************************
 */
static void flash_cmd_cfi_exit(void)
{
	/* CFI Exit Command */
	*(__IO uint16_t*)(FLASH_BASE_ADDRESS + (0x000 << 1)) = 0xf0;
}
#endif	/* FLASH_SUPPORT_CFI!=0 */

