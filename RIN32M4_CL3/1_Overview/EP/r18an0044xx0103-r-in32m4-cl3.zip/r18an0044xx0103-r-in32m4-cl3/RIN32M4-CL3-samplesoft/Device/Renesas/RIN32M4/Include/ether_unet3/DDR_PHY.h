/***********************************************************************
    Standard 10/100baseT PHY driver for R-IN32M4 Ethernet
    2014/02/08: First release
 ***********************************************************************/

#ifndef _DDR_PHY_H_
#define _DDR_PHY_H_

#include "COMMONDEF.h"

#ifdef __cplusplus
extern "C" {
#endif


#define PHY_BMCR        0x00    /* Basic mode Control */
#define PHY_BMSR        0x01    /* Basic mode Status */
#define PHY_IDR1        0x02    /* PHY Identifier */
#define PHY_IDR2        0x03    /* PHY Identifier */
#define PHY_ANAR        0x04    /* Auto-Negotiation Advertisement */
#define PHY_ANLPAR      0x05    /* Auto-Negotiation Link Partner Ability */
#define PHY_ANER        0x06    /* Auto-Negotiation Expansion */
#define PHY_ANNPTR      0x07    /* Auto-Negotiation Next Page Transmit */

#define PHY_1000BCR     0x09    /* 1000Base-T Control Register */
#define PHY_1000BSR     0x0A    /* 1000Base-T Control Staus  */

#define PHY_LEDMDSEL    0x1D    /* LED Mode Select Register */
#define PHY_LEDBHVR     0x1E    /* LED Behavior Register */

/* (Register 0) Basic mode Control Register */
#define BMCR_RESET          BIT15
#define BMCR_LOOPBACK       BIT14
#define BMCR_SPD_LSB        BIT13
#define BMCR_ANE            BIT12
#define BMCR_PDOWN          BIT11
#define BMCR_ISOL           BIT10
#define BMCR_RS_ANP         BIT9
#define BMCR_DUPLEX         BIT8
#define BMCR_COL_TEST       BIT7
#define BMCR_SPD_MSB        BIT6

/* (Register 1) Status Register */
#define BMSR_100_T4         BIT15
#define BMSR_100_X_FD       BIT14
#define BMSR_100_X_HD       BIT13
#define BMSR_10_FD          BIT12
#define BMSR_10_HD          BIT11
#define BMSR_PREAMBLE       BIT6
#define BMSR_ANEG_COMP      BIT5
#define BMSR_RM_FAULT       BIT4
#define BMSR_AN_ABLE        BIT3
#define BMSR_LINK_STAT      BIT2
#define BMSR_JABBER         BIT1
#define BMSR_EXT_CAP        BIT0

/* (Register 4) Auto-Negotiation Advertisement Register */
#define ANAR_NP             BIT15
#define ANAR_RF             BIT13
#define ANAR_ASM_DIR        BIT11
#define ANAR_PAUSE          BIT10
#define ANAR_T4             BIT9
#define ANAR_TX_FD          BIT8
#define ANAR_TX             BIT7
#define ANAR_10_FD          BIT6
#define ANAR_10             BIT5
#define ANAR_SF_802_3u      0x0001

/* (Register 5) Auto-Negotiation Link Partner Abilty Register (Base Page) */
#define ANLPAR_B_NP         BIT15
#define ANLPAR_B_ACK        BIT14
#define ANLPAR_B_R_FAULT    BIT13
#define ANLPAR_B_ASM_DIR    BIT11
#define ANLPAR_B_PAUSE      BIT10
#define ANLPAR_B_T4         BIT9
#define ANLPAR_B_TX_FD      BIT8
#define ANLPAR_B_TX         BIT7
#define ANLPAR_B_10_FD      BIT6
#define ANLPAR_B_10         BIT5
#define ANLPAR_B_SF_802_3u  0x0001

/* (Register 5) Auto-Negotiation Link Partner Abilty Register (Next Page) */
#define ANLPAR_N_NP         BIT15
#define ANLPAR_N_ACK        BIT14
#define ANLPAR_N_MP         BIT13
#define ANLPAR_N_ACK2       BIT12
#define ANLPAR_N_TOGGLE     BIT11

/* (Register 6) Auto-Negotiation Expansion */
#define ANER_PDF            BIT4
#define ANER_LP_NP_ABLE     BIT3
#define ANER_NP_ABLE        BIT2
#define ANER_PAGE_RX        BIT1
#define ANER_LP_AN_ABLE     BIT0

/* (Register 7) Auto-Negotiation Next Page Transmit Register */
#define ANNPTR_NP           BIT15
#define ANNPTR_MP           BIT13
#define ANNPTR_ACK2         BIT12
#define ANNPTR_TOG_TX       BIT11
#define ANNPTR_CODE_802_3u  0x0001

/* (Register 9) 1000Base-T Control Register */
#define GIGABASET_CTRL_TEST  (BIT15|BIT14|BIT13)
#define GIGABASET_CTRL_MSC    BIT12
#define GIGABASET_CTRL_MSV    BIT11
#define GIGABASET_CTRL_PORT   BIT10
#define GIGABASET_CTRL_FD     BIT9
#define GIGABASET_CTRL_HD     BIT8

/* (Register 10) 1000Base-T Status Register */
#define GIGABASET_STAT_MSF    BIT15
#define GIGABASET_STAT_MSR    BIT14
#define GIGABASET_STAT_LOCAL  BIT13
#define GIGABASET_STAT_REMOTE BIT12
#define GIGABASET_STAT_FD     BIT11
#define GIGABASET_STAT_HD     BIT10
#define GIGABASET_STAT_ERROR  (0x000000FF)

/* (Register 29) LED Mode Select Register */
#define LEDMDSEL_LED3         (BIT15|BIT14|BIT13|BIT12)
#define LEDMDSEL_LED2         (BIT11|BIT10|BIT9|BIT8)
#define LEDMDSEL_LED1         (BIT7|BIT6|BIT5|BIT4)
#define LEDMDSEL_LED0         (BIT3|BIT2|BIT1|BIT0)

/* (Register 30) LED Behavior Register */
#define LEDBHVR_PULS_EN       (BIT15|BIT14|BIT13|BIT12)
#define LEDBHVR_PULS_RATE     (BIT11|BIT10)
#define LEDBHVR_LED3_SEL      BIT8
#define LEDBHVR_LED2_SEL      BIT7
#define LEDBHVR_LED1_SEL      BIT6
#define LEDBHVR_LED0_SEL      BIT5



#define PHY_10T_HD          1
#define PHY_10T_FD          2
#define PHY_100TX_HD        3
#define PHY_100TX_FD        4
#define PHY_1000T_HD        5
#define PHY_1000T_FD        6
#define PHY_AUTO_ABILITY    7








/* for R-IN32M4 MAC Controller */

#define PYH_RW_CNT          1000 /* Maximum access time for PHY */ 

/* Macros */
/* PHY */
#define NEGOTIATION(x)      (((x)==LAN_10T_FD) || ((x)==LAN_100TX_FD) || ((x)==LAN_1000T_FD) || ((x)==LAN_AUTO_ABILITY))
#define MII_W               0x04000000
#define MII_R               0x00000000
#define MII_VALID           0x04000000
#define MII_PHYA(x)         ((x & 0x1f) << 21)
#define MII_REGA(x)         ((x & 0x1f) << 16)

#define PHY_LINK_UP         0x00000010
#define PHY_LINK_DOWN       0x00000020
#define PHY_LINK_EVT        (PHY_LINK_UP  | PHY_LINK_DOWN)

#ifdef __cplusplus
}
#endif
#endif /* _DDR_PHY_H_ */

