/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32S.h                                                         */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

#ifndef __R_IN32S_H_INCLUDED_
#define __R_IN32S_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define		IN8(p)					(*(volatile unsigned char  *)((int)(p)))
#define		OUT8(p,d)				(*(volatile unsigned char  *)((int)(p)) = (d))
#define		IN16(p)					(*(volatile unsigned short  *)((int)(p)))
#define		OUT16(p,d)				(*(volatile unsigned short  *)((int)(p)) = (d))
#define		IN32(p)					(((*(volatile unsigned int  *)((int)(p)))))
#define		OUT32(p,d)				(*(volatile unsigned int  *)((int)(p)) = ((d)))


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID   gR_IN32S_SysErrRet(ULONG, VOID*);
extern VOID   gR_IN32S_Memcpy(VOID*, const VOID*, ULONG);
extern VOID   gR_IN32S_Memset(VOID*, UCHAR, ULONG);
extern ULONG  gulR_IN32S_Memcmp(const VOID*, const VOID*, ULONG);
extern USHORT gusR_IN32S_SwapS(USHORT);
extern ULONG  gulR_IN32S_SwapL(ULONG);
extern VOID   gR_IN32S_NotifyRecvSetStNo(UCHAR, USHORT);
extern VOID   gR_IN32S_NotifyRecvOpeCmd(ULONG);
extern VOID   gR_IN32S_SendFin(UCHAR, ERRCODE);

#endif /* __R_IN32S_H_INCLUDED_ */

/*** EOF ***/
