/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved.     */
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_Transient.c                                               */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include <string.h>

#include "R_IN32M4Driver.h"
#include "R_IN32M4Callback.h"
#include "R_IN32M4_sample.h"
#include "R_IN32M4_Transient.h"

#include "RIN32M4.h"
#include "R_IN32.h"
#include "R_IN32S.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

/* Transient1 frame reception */
#define USER_TRAN1RECEIVE_NODE		1UL			/* Number of node to be handled */
												/* warning: If set to 1, only frame from master will be handled */

#define USER_SUPPORT_FUNCTION		0x0001		/* Option support */

/* Select Info LED Color */
#define USER_SELECTINFO_LED_UNUSED	0x00		/* LED, unused. */
#define USER_SELECTINFO_LED_GREEN	0x01		/* Green */
#define USER_SELECTINFO_LED_RED		0x02		/* Red */
#define USER_SELECTINFO_LED_ORANGE	0x03		/* Orange */

/* Select Info LED State */
#define USER_SELECTINFO_LED_OFF		0x01		/* OFF */
#define USER_SELECTINFO_LED_ON		0x02		/* ON */
#define USER_SELECTINFO_LED_BLINK	0x03		/* Blink */

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

/* Transient1 received data reconstruction information */
typedef struct _USER_TRAN1MAKE_TAG {
	BOOL	blMaking;							/**< Now reconstructing */
	UCHAR	uchIdentificationNumber;			/**< Identification number */
	USHORT	usTransientDataAllSize;				/**< Total data size */
	USHORT	usConnectedSize;					/**< Concatenated data size */
} USER_TRAN1MAKE_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

/* Received transient frame */
ULONG	gaulUserReceivedTransient[USER_TRANRCV_BUFSIZE/4];			/* Received transient frame */
USHORT	gusUserReceivedTransientSize = (USHORT)0;					/* Received transient frame size (FCS not included) */

ULONG	gaulUserReceivedTransient1[USER_TRAN1RECEIVE_NODE][3000/4];	/* Storage area for Transient1 received data */
																	/* warning: Please set the buffer size greater than the former size of partitioned sent Transient1 frame */

USER_TRAN1MAKE_T	gastUserTransient1Make[USER_TRAN1RECEIVE_NODE];	/* Transient1 received data reconstruction information table */


/* Send transient frame */

BOOL	gblUserTransientSending = R_IN32_FALSE;			/* "Now sending transient frame"-flag */
BOOL	gblUserSendTransientAck = R_IN32_FALSE;			/* TransientAck frame send start flag */
BOOL	gblUserSendTransient1_Response = R_IN32_FALSE;	/* Transient1 response frame send start flag */
BOOL	gblUserSendTransient1_Request = R_IN32_FALSE;		/* Transient1 send start flag */
BOOL	gblUserSendTransient2_Response = R_IN32_FALSE;	/* Transient2 response frame send start flag */
BOOL	gblUserSendTransient2_Request = R_IN32_FALSE;		/* Transient2 request frame send start flag */

ULONG	gulUserSendTransientAck_Size;					/* frame send size (DCS/FCS not included) */
ULONG	gulUserSendTransient1_Response_Size;			/* Transient1 response frame send size (DCS/FCS not included) */
ULONG	gulUserSendTransient1_Request_Size;				/* Transient1 request data size */
ULONG	gulUserSendTransient2_Response_Size;			/* Transient2 response frame send size (DCS/FCS not included) */
ULONG	gulUserSendTransient2_Request_Size;				/* Transient2 request frame send size (DCS/FCS not included) */

ULONG	gaulUserSendTransientAck[(sizeof(USER_TRANSIENT_ACK_FRAME_T) - USER_DCS_FCS_SIZE)/4];	/* TransientAck send frame */

ULONG	gaulUserSendTransient1_Response[USER_TRANRCV_BUFSIZE/4];	/* Transient1 send frame (for response) */
ULONG	gaulUserSendTransient1_Request_BigFrame[TRANSIENT_FRAME_SYNTHETIC_MAX_SIZE/4];		/* Transient1 request data storage area */
ULONG	gaulUserSendTransient1_Request[USER_TRANRCV_BUFSIZE/4];		/* Transient1 request data storage area for sending */
ULONG	gaulUserSlmpReqData[R_IN32_TRAN_SLMPALL_SIZE_MAX/4];			/* Transient1 data for SLMP */
ULONG	gaulUserSendTransient2_Response[USER_TRANRCV_BUFSIZE/4];	/* Transient2 send frame (for response) */
ULONG	gaulUserSendTransient2_Request[USER_TRANRCV_BUFSIZE/4];		/* Transient2 send frame (for request) */
USER_TRANSIENT_SENDRESULT_T	gstUserTransientSendResult = {	/* Transient sending result */
								R_IN32_FALSE,		/* .blFinish */
								(UCHAR)0,		/* .uchSendBuffNo */
								R_IN32_OK,		/* .erSendStatus */
							};
/* MAC address distribution */
BOOL	gblUserMACAddressTableRequest;				/* MAC address table distribution necessity flag */
/* Divide manage */
USER_TRAN1_DIVIDE_MANAGE_T	gstReqFrameDivManage;				/* For request traesient */
USHORT	gusTxSerialNo = 0x0000;									/* Sending serial no(Check for Response) */
UCHAR	guchReadBuffReceive[USER_SLMP_MEMORY_READ_SIZE_MAX*2];	/*  buffer memory read */



/****************************************************************************/
/* Static Functions                                                         */
/****************************************************************************/
static VOID		UserHandleReceivedTransient1(const VOID*, USHORT);
static VOID		UserHandleReceivedTransient2(const VOID*, USHORT);
static VOID		UserHandleReceivedTransientAck(const VOID*, USHORT);

static ERRCODE	erUserHandleReceivedMemReadRequest(const VOID*, const UCHAR*, const VOID*, VOID*, ULONG*);
static ERRCODE	erUserHandleReceivedMemWriteRequest(const VOID*, const UCHAR*, const VOID*, VOID*, ULONG*);

static ERRCODE	erUserHandleReceivedMemReadResponse ( USHORT, const VOID*, UCHAR*);

static VOID		UserStartMakingReceivedTransient1(const VOID*, USER_TRAN1MAKE_T*);
static BOOL		blUserMakeReceivedTransient1(const VOID*, ULONG, VOID*, USER_TRAN1MAKE_T*);

static ERRCODE	erUserCheckReceivedTransient2(const VOID*);
static ERRCODE	erUserHandleReceivedTransient2_RequestSetMemory(const USER_TRANSIENT2_REQ_SETMEM_T*);
static ERRCODE	erUserHandleReceivedTransient2_ResponseGetMemory(const USER_TRANSIENT2_RES_T*);

static ULONG	ulUserSetTransient2_Response(VOID*, const VOID*, USHORT);
static BOOL		blUserSetTransientAck(VOID*, const VOID*, USHORT);
static ULONG	ulUserSetTransient2_RequestGetMemory(VOID*);
static USHORT	usUserSwapS(USHORT);
static ULONG	ulUserSwapL(ULONG);


/****************************************************************************/
/** @brief  Receive Transient1, Transient2, and TransientAck processing     */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserReceiveTransient( VOID )
{
	USHORT	usReceiveResult;				/* Receive result */
	BOOL	blRcvTran;						/* Transient receive enable/disable */
	static	BOOL blCanReceive = R_IN32_TRUE;	/* Transient receive function flag */
	R_IN32_NONCICLIC_FRAME_T*	pstHeader;		/* MAC + CCIE Header */
	BOOL	blRet;							/* Return value */


	pstHeader = (R_IN32_NONCICLIC_FRAME_T*)&gaulUserReceivedTransient[0];

	/* Receive transient main handling 1 */
	gerR_IN32_MainReceiveTransient1();
	
	/* Only when the transient sending stops, the presence of a reception frame is confirmed */
	if( R_IN32_FALSE == gblUserTransientSending ) {
		/* Receive transient main handling 2 */
		gerR_IN32_MainReceiveTransient2();
	}

	/* Is TransientAck data received? */
	if ( (USHORT)0 < gusUserReceivedTransientSize ) {

		/* Handle according to frame type */
		switch (pstHeader->uchFrameClassification) {

		case R_IN32_FTYPE_TRANSIENT1:				/* Receive Transient1 */

			/* Disable receive function */
			blCanReceive = R_IN32_FALSE;

			/* TODO: Please set error code as necessary */
			usReceiveResult = (USHORT)0;		/* Example: no error */

			/* Prepare TransientAck frame */
			/* (If preparation not necessary, return value is R_IN32_FALSE) */
			blRet = blUserSetTransientAck(
						&gaulUserSendTransientAck[0],	/* Send frame */
						&gaulUserReceivedTransient[0],	/* Received frame */
						usReceiveResult					/* Receive result */
					);

			/* Is it necessary to send TransientAck? */
			if ( R_IN32_TRUE == blRet ) {

				/* Set TransientAck frame send data size */
				gulUserSendTransientAck_Size = sizeof(USER_TRANSIENT_ACK_FRAME_T) - USER_DCS_FCS_SIZE;	/* DCS/FCS not included */

				/* TransientAck frame send start flag <- ON */
				gblUserSendTransientAck = R_IN32_TRUE;
			}
			else {
			}

			/* Transient1 received data handling */
			UserHandleReceivedTransient1(
					&gaulUserReceivedTransient[0],	/* Received frame */
					gusUserReceivedTransientSize	/* Size (FCS not included) */
				);

			/* Set no reception */
			gusUserReceivedTransientSize = (USHORT)0;

			break;

		case USER_FTYPE_TRANSIENT2:				/* Receive Transient2 */

			/* Disable receive function */
			blCanReceive = R_IN32_FALSE;

			/* TODO: Please set error code as necessary */
			usReceiveResult = (USHORT)0;		/* Example: no error */

			/* Prepare TransientAck frame */
			/* (If preparation not necessary, return value is R_IN32_FALSE) */
			blRet = blUserSetTransientAck(
						&gaulUserSendTransientAck[0],	/* Send frame */
						&gaulUserReceivedTransient[0],	/* Received frame */
						usReceiveResult					/* Receive result */
					);

			/* Is it necessary to send TransientAck? */
			if ( R_IN32_TRUE == blRet ) {

				/* Set TransientAck frame send data size */
				gulUserSendTransientAck_Size = sizeof(USER_TRANSIENT_ACK_FRAME_T) - USER_DCS_FCS_SIZE;	/* DCS/FCS not included */

				/* TransientAck frame send start flag <- ON */
				gblUserSendTransientAck = R_IN32_TRUE;
			}
			else {
			}

			/* Transient2 receive data handling */
			UserHandleReceivedTransient2(
					&gaulUserReceivedTransient[0],	/* Received frame */
					gusUserReceivedTransientSize	/* Size (FCS not included) */
				);

			/* Set no reception */
			gusUserReceivedTransientSize = (USHORT)0;

			break;

		case USER_FTYPE_TRANSIENTACK:			/* Receive TransientAck */

			/* Disable receive function */
			blCanReceive = R_IN32_FALSE;

			/* TransientAck receive data handling */
			UserHandleReceivedTransientAck(
					&gaulUserReceivedTransient[0],	/* Received frame */
					gusUserReceivedTransientSize	/* Size (FCS not included) */
				);

			/* Set no reception */
			gusUserReceivedTransientSize = (USHORT)0;

			break;

		default:								/* Other reception */

			/* This situation is not possible */

			break;
		}
	}
	else {
	}

	/* Enable reception all of the following condition */
	/*   - Received data obtaining is completed */
	/*   - No TransientAck frame send request */
	/*   - No Transient response frame send request */
	if (( 0UL == gusUserReceivedTransientSize )
	  && ( R_IN32_FALSE == gblUserSendTransientAck )
	  && ( R_IN32_FALSE == gblUserSendTransient1_Response )
	  && ( R_IN32_FALSE == gblUserSendTransient2_Response )) {

		/* Enable reception */
		blCanReceive = R_IN32_TRUE;
	}
	else {
	}

	/* Get the status of the transient frame reception function */
	blRcvTran = gblR_IN32_GetReceiveTransientStatus();

	/* Transient frame reception disabled? */
	if ( R_IN32_TRUE != blRcvTran ) {

		/* Can receive transient frame again? */
		if ( R_IN32_TRUE == blCanReceive ) {

			/* Enable the transient frame reception function */
			gerR_IN32_EnableReceiveTransient( R_IN32_TRUE );
		}
		else {
		}
	}
	else {
	}

	return;
}

/****************************************************************************/
/** @brief  Received Transient1 data processing                             */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserHandleReceivedTransient1(
	const VOID*	pvReceivedFrame,	/**< Received frame */
	USHORT		usReceivedSize		/**< Size (FCS not included) */
)
{
	const R_IN32_TRAN1_FRAME_T*			pstReceivedFrame;		/* Received frame */
	R_IN32_EXTENSION_HEAD_DATA_T*			pstData;				/* Transient1 Reconstruction data */
	USER_TRAN1MAKE_T*					pstMake;				/* Reconstruction information */
	R_IN32_SLMP_REQUEST_FRAME_T*			pstSlmpReqData;			/* SLMP Request Frame Format */
	R_IN32_SLMP_RESPONSE_DATA_T*			pstSlmpResData;			/* SLMP Response Frame Format */
	USHORT								usNodeID;				/* Sender's node ID */
	USHORT								usTemp;					/* Temporary */
	USHORT								usTemp2;				/* Temporary */
	BOOL								blComplete;				/* Reconstruction finish flag */
	ULONG								ulResponseDataSize;		/* Response Data size */
	R_IN32_SELECTINFO_LED_INFO_T			stLedInfo;				/* LED information */
	ERRCODE								erRetErrCode;			/* Retrun value */



	pstReceivedFrame = (const R_IN32_TRAN1_FRAME_T*)pvReceivedFrame;

	/* Get sender's node ID */
	usNodeID = usUserSwapS(pstReceivedFrame->stCOMMON.usNodeID);

	/* If received sender's node ID is out of range */
	if( USER_TRAN1RECEIVE_NODE_MAX < usNodeID ) { 
		return;
	}
	else {
	}
	
	/* If received sender's node ID is out of range */
	if (USER_TRAN1RECEIVE_NODE <= usNodeID) {
		/* Splitting assembly for reception other than the master is not performed */
		if(pstReceivedFrame->stHEAD.usTransientDataAllSize == pstReceivedFrame->stHEAD.usTransientDataDivisionSize){
		pstData = (R_IN32_EXTENSION_HEAD_DATA_T*)(&pstReceivedFrame->uniDATA.auchTransientDataArea[0]);
		blComplete = R_IN32_TRUE;
	}
		else{
			blComplete = R_IN32_FALSE;
		}
	}
	else {
		/* Get reconstruction information according to sender's node ID */
		pstMake = &gastUserTransient1Make[usNodeID];

		/* Get Transient1 received data storage source according to sender's node ID */
		pstData = (R_IN32_EXTENSION_HEAD_DATA_T*)&gaulUserReceivedTransient1[usNodeID][0];
		
		/* Now reconstructing? */
		if ( R_IN32_TRUE == pstMake->blMaking ) {

			/* Is identification number changed? */
			if ( pstMake->uchIdentificationNumber != pstReceivedFrame->stHEAD.uchIdentificationNumber ) {

				/* Start reconstruction Transient1 received data */
				UserStartMakingReceivedTransient1(
						pstReceivedFrame,	/* Received frame */
						pstMake				/* Reconstruction information */
					);
			}
			else {
			}
		}
		/* Now not reconstructing */
		else {
			/* Start reconstruction Transient1 received data */
			UserStartMakingReceivedTransient1(
					pstReceivedFrame,	/* Received frame */
					pstMake				/* Reconstruction information */
				);

		}

		/* Reconstruct Transient1 received data */
		blComplete = blUserMakeReceivedTransient1(
						pstReceivedFrame,						/* Received frame */
						sizeof(gaulUserReceivedTransient1[0]),	/* Transient1 received data storage area size */
						pstData,								/* Reconstruction data */
						pstMake									/* Reconstruction information */
					);
	}
	
	/* Is reconstruction finished? */
	if ( R_IN32_TRUE == blComplete ) {

		/* Handling according to the data type */
		switch( pstReceivedFrame->stCOMMON.uchDataClassification ) {
		case R_IN32_DTYPE_NETWORK_COMMON:	/* Network Common */

			/* Handling for data sub-type */
			usTemp = usUserSwapS( pstReceivedFrame->stHEAD.usDataSubClassification );
			switch( usTemp ) {

			case R_IN32_DSTYPE_SLMP:	/* SLMP */

				/* Cast Transient2 Head */
				pstSlmpReqData = (R_IN32_SLMP_REQUEST_FRAME_T*)pstData;
				pstSlmpResData = (R_IN32_SLMP_RESPONSE_DATA_T*)pstData;
				
				/* Check CT, Is reeceived frame request or responce? */
				if( 0 != pstSlmpResData->stExHead.stCCLinkHead.stCT.stCtDtl.b1ZFrameType ) {
					/* Receiving response frame */
					/* When  serial number of response frame match with serial number of request frame, get value from responce frame.  */
					if( pstSlmpResData->stExHead.stSlmpHead.usSerialNo == gusTxSerialNo ) {
						if( 0x0000 != pstSlmpResData->stExHead.usFinCode ) {
							/* TODO: Please implement error case as necessary */
						}
						else {
							usTemp2 = (pstSlmpResData->stExHead.stSlmpHead.usL-2) / 2;		/* Maintained word size */
							erUserHandleReceivedMemReadResponse( usTemp2, &pstSlmpResData->auchDataArea[0] , guchReadBuffReceive );

						}
					}
					
					break;	
							/* Because  responce frame, receiving request frame will not be handled */
				}
				
				
				/* Handling for the command */
				switch( pstSlmpReqData->usCommand ) {

				case 0x3119:	/* Get Select Info */

					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						/* LED information */
						stLedInfo.uchRow    = 4;						/* Row */
						stLedInfo.uchColumn = 2;						/* Column */

						/* PW */
						stLedInfo.stLedInf[0].uchColor = USER_SELECTINFO_LED_GREEN;		/* LED Color */
						stLedInfo.stLedInf[0].uchState = USER_SELECTINFO_LED_ON;		/* LED State */

						/* RUN */
						stLedInfo.stLedInf[1].uchColor = USER_SELECTINFO_LED_GREEN;		/* LED Color */
						stLedInfo.stLedInf[1].uchState = USER_SELECTINFO_LED_ON;		/* LED State */

						/* SD */
						stLedInfo.stLedInf[2].uchColor = USER_SELECTINFO_LED_GREEN;		/* LED Color */
						stLedInfo.stLedInf[2].uchState = USER_SELECTINFO_LED_ON;		/* LED State */

						/* ERR. */
						stLedInfo.stLedInf[3].uchColor = USER_SELECTINFO_LED_RED;		/* LED Color */
						stLedInfo.stLedInf[3].uchState = USER_SELECTINFO_LED_OFF;		/* LED State */

						/* MST */
						stLedInfo.stLedInf[4].uchColor = USER_SELECTINFO_LED_UNUSED;	/* LED Color */
						stLedInfo.stLedInf[4].uchState = USER_SELECTINFO_LED_UNUSED;	/* LED State */

						/* D.LINK */
						stLedInfo.stLedInf[5].uchColor = USER_SELECTINFO_LED_GREEN;		/* LED Color */
						stLedInfo.stLedInf[5].uchState = USER_SELECTINFO_LED_ON;		/* LED State */

						/* RD */
						stLedInfo.stLedInf[6].uchColor = USER_SELECTINFO_LED_GREEN;		/* LED Color */
						stLedInfo.stLedInf[6].uchState = USER_SELECTINFO_LED_ON;		/* LED State */

						/* L ERR. */
						stLedInfo.stLedInf[7].uchColor = USER_SELECTINFO_LED_RED;		/* LED Color */
						stLedInfo.stLedInf[7].uchState = USER_SELECTINFO_LED_OFF;		/* LED State */

						/* Handling for the received Select information request */
						erRetErrCode = gerR_IN32_ReceivedSelectInfoRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1),
							&stLedInfo
						);
						
						/* Set Transient1 response frame send data size */
						gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

						/* Transient1 response frame send start flag <- ON */
						gblUserSendTransient1_Response = R_IN32_TRUE;
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;

				case 0x3040:	/* Communication Test */

					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						/* Handling for the received Communication Test request */
						erRetErrCode = gerR_IN32_ReceivedContactTestRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1)
						);
						
						/* Set Transient1 response frame send data size */
						gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

						/* Transient1 response frame send start flag <- ON */
						gblUserSendTransient1_Response = R_IN32_TRUE;
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;

				case 0x3050:	/* Cable Test */

					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						/* Handling for the received Cable Test request */
						erRetErrCode = gerR_IN32_ReceivedCableTestRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1)
						);
						
						/* Set Transient1 response frame send data size */	
						gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

						/* Transient1 response frame send start flag <- ON */
						gblUserSendTransient1_Response = R_IN32_TRUE;
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;
				case 0x0613:	/* SLMP read memory */

					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						erRetErrCode = erUserHandleReceivedMemReadRequest (
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1),
							(void*)&gauchBufferMemory[0],
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize
						);
						
						/* Set Transient1 response frame send data size */
						gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

						/* Transient1 response frame send start flag <- ON */
						gblUserSendTransient1_Response = R_IN32_TRUE;
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}

					}
					else {
					}

					break;

				case 0x1613:	/* SLMP Write Memory */

					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						/* Handling for the received SLMP Write Memory request */
						erRetErrCode = erUserHandleReceivedMemWriteRequest (
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1),
							(void*)&gauchBufferMemory[0],
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize
						);
						
						/* Set Transient1 response frame send data size */
						gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

						/* Transient1 response frame send start flag <- ON */
						gblUserSendTransient1_Response = R_IN32_TRUE;
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;
					
				case 0x1006:	/* SLMP Remote Reset */
					/* Handling for the sub-command */
					if ( 0UL == (ULONG)pstSlmpReqData->usSubCommand ) {
						/* Handling for the received SLMP Remote Reset request */
						erRetErrCode = gerR_IN32_ReceiveRemoteResetRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1)
						);
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						
							/* Set Transient1 response frame send data size */
							gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

							/* Transient1 response frame send start flag <- ON */
							gblUserSendTransient1_Response = R_IN32_TRUE;
						}
						else{
							/* TODO: add your code here */
							RIN_RTPORT->RP2B ^= 0x02;
							
						}
					}
					else {
					}
					break;
				/* TODO: Please implement the command handling */

				default:
					break;
				}

				break;

			/* TODO: Please implement the handling for data sub-type */

			default:
				break;
			}

			break;

		case R_IN32_DTYPE_FIELD:				/* CC-Link IE Field specific */

			/* Handling for data sub-type */
			usTemp = usUserSwapS( pstReceivedFrame->stHEAD.usDataSubClassification );
			switch( usTemp ) {

			case R_IN32_DSTYPE_FIELD_SYSTEM:	/* System specific */

				/* Handling for the command */
				switch( pstData->stOPHEAD.uchCommandType ) {

				case 0x01:	/* MAC address distribution */
					/* Is MAC address table necessary? */
					if ( R_IN32_TRUE == gblUserMACAddressTableRequest) {

						/* Handling for the received MAC address distribution frame */
						erRetErrCode = gerR_IN32_ReceivedMACAddressData( pstData, pstMake->usTransientDataAllSize );
						
						if( R_IN32_ERR == erRetErrCode ) {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}
					break;

				case 0x03:	/* Get statistic information */

					/* Is it request frame? */
					/* (in case bit7 of sub-command is OFF) */
					if ( 0UL == (0x80UL & (ULONG)pstData->stOPHEAD.uchSubCommandType) ) {
						/* Handling for the received statistic information request */
						erRetErrCode = gerR_IN32_ReceivedStatisticInfoRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1)
						);
						
						if( R_IN32_OK == erRetErrCode ) {
							/* Set Transient1 response frame send data size */
							gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

							/* Transient1 response frame send start flag <- ON */
							gblUserSendTransient1_Response = R_IN32_TRUE;
						}
						else {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;

				case 0x04:	/* Get unit information */

					/* Is it request frame? */
					/* (in case bit7 of sub-command is OFF) */
					if ( 0UL == (0x80UL & (ULONG)pstData->stOPHEAD.uchSubCommandType) ) {
						/* Handling for the received unit information request */
						erRetErrCode = gerR_IN32_ReceivedUnitInfoRequest(
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1)
						);
						
						if( R_IN32_OK == erRetErrCode ) {
							/* Set Transient1 response frame send data size */
							gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

							/* Transient1 response frame send start flag <- ON */
							gblUserSendTransient1_Response = R_IN32_TRUE;
						}
						else {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;

				case 0x0A:	/* Get Option information */

					/* Is it request frame? */
					/* (in case bit7 of sub-command is OFF) */
					if ( 0UL == (0x80UL & (ULONG)pstData->stOPHEAD.uchSubCommandType) ) {
						/* Handling for the received Option information request */
						erRetErrCode = gerR_IN32_ReceivedOptionInfoRequest (
							&gaulUserSendTransient1_Response[0],
							&ulResponseDataSize,
							pstData,
							(const UCHAR*)&(pstReceivedFrame->stCOMMON.usFromAddress1),
							USER_SUPPORT_FUNCTION
						);
						
						if( R_IN32_OK == erRetErrCode ) {
							/* Set Transient1 response frame send data size */
							gulUserSendTransient1_Response_Size = ulResponseDataSize;		/* DCS/FCS not included */

							/* Transient1 response frame send start flag <- ON */
							gblUserSendTransient1_Response = R_IN32_TRUE;
						}
						else {
							/* TODO: Please implement the received value error occer */
						}
					}
					else {
					}

					break;

				/* TODO: Please implement the command handling */

				default:
					break;
				}

				break;

			/* TODO: Please implement the handling for data sub-type */

			default:
				break;
			}

			break;

		/* TODO: Please implement the handling for data type */

		default:
			break;
		}
	}
	else {
	}

	return;
}

/****************************************************************************/
/** @brief  Received Transient2 Data processing                             */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserHandleReceivedTransient2(
	const VOID*	pvReceivedFrame,	/* Received frame */
	USHORT		usReceivedSize		/**< Size (FCS not included) */
)
{
	const USER_TRANSIENT2_FRAME_T*	pstRcvFrame;		/* Received frame */
	const USER_TRANSIENT2_HEAD_T*	pstHeader;			/* CC-Link header of Transient2 frame */
	ULONG							ulCommand;			/* Command */
	ULONG							ulTemp;				/* Temporary */
	USHORT							usErrorCode;		/* Error code, to be set to response frame */
	ERRCODE							erResult;			/* Result */


	pstRcvFrame = (const USER_TRANSIENT2_FRAME_T*)pvReceivedFrame;
	pstHeader = &pstRcvFrame->stHEAD;

	/* Check Transient2 received data */
	erResult = erUserCheckReceivedTransient2(
					pvReceivedFrame		/* Received frame */
				);

	/* Is result normal? */
	if ( R_IN32_OK == erResult ) {

		/*[ Check bit7 of CT ]*/
		/* If OFF, then it's a request frame */
		if ( 0UL == (0x80UL & (ULONG)pstHeader->uchCT) ) {

			/* Get command (bit0-6 of CT) */
			ulCommand = (0x7FUL & (ULONG)pstHeader->uchCT);

			/* Handling according to command */
			switch ( ulCommand ) {

			case 0x12UL:	/*[ Memory write request ]*/

				/* Handling for received Transient2 memory write request */
				erResult = erUserHandleReceivedTransient2_RequestSetMemory(
								&pstRcvFrame->uniDATA.stReq.uniData.stSetMem	/* Memory write request data part of the received frame */
							);

				/* Error case */
				if ( R_IN32_OK != erResult ) {

					/* TODO: Please implement error handling as necessary */

					/* Set error code */
					/* TODO: Set the result of erUserHandleReceivedTransient2_RequestSetMemory() */
					/* example */
					usErrorCode = (USHORT)erResult;
					usErrorCode |= USER_ERR_RCVTRAN2;
				}
				else {
					usErrorCode = (USHORT)0;
				}

				/*[ Check bit7 of DT]*/
				/* If OFF, then response frame is necessary */
				if ( 0UL == (0x80UL & (ULONG)pstHeader->uchCT) ) {

					/* Prepare Transient2 response frame */
					ulTemp = ulUserSetTransient2_Response(
								&gaulUserSendTransient2_Response[0],	/* Send frame */
								pvReceivedFrame,						/* Received frame */
								usErrorCode								/* Error code */
							);

					/* Set Transient2 response frame send data size */
					gulUserSendTransient2_Response_Size = ulTemp;	/* DCS/FCS not included */

					/* Transient2 response frame send start flag <- ON */
					gblUserSendTransient2_Response = R_IN32_TRUE;
				}
				else {
				}

				break;

			/* TODO: Please add handling for each request */

			default:		/* Other */

				break;
			}
		}
		/* If ON, then it's response frame */
		else {


		/* TODO: Please confirm the response requested by this node */

		/* Get command (bit0-6 of CT) */
		ulCommand = (0x7FUL & (ULONG)pstHeader->uchCT);

		/* Handling according to command */
		switch ( ulCommand ) {

		case 0x10UL:	/*[ Memory read response ]*/

			/* Handling for received Transient2 memory read response */
			erResult = erUserHandleReceivedTransient2_ResponseGetMemory(
							&pstRcvFrame->uniDATA.stRes		/* Response data part of the received frame */
							);

			/* If error */
			if ( R_IN32_OK != erResult ) {
				/* TODO: Please implement error handling as necessary */
				}
				else {
				}

			break;

		case 0xFFUL:

			break;

		/* TODO: Please add handling for each request */

		default:		/* Other */

			break;
		}
	/* Discard received data */
	/* TODO: Please implement error handling as necessary */

		}

	}
	/* Frame is not addressed to this node */
	else {
		/*[ Check bit7 of CT ]*/
		/* If OFF, then it's a request frame */
		if ( 0UL == (0x80UL & (ULONG)pstHeader->uchCT) ) {

			/*[ Check bit7 of DT]*/
			/* If OFF, then response frame is necessary */
			if ( 0UL == (0x80UL & (ULONG)pstHeader->uchDT) ) {

				/* Set error code */
				/* TODO: Set the result of erUserCheckReceivedTransient2() */
				/* example */
				usErrorCode = (USHORT)erResult;
				usErrorCode |= USER_ERR_RCVTRAN2;

				/* Prepare Transient2 response frame */
				ulTemp = ulUserSetTransient2_Response(
							&gaulUserSendTransient2_Response[0],	/* Send frame */
							pvReceivedFrame,						/* Received frame */
							usErrorCode								/* Error code */
						);

				/* Set Transient2 response frame send data size */
				gulUserSendTransient2_Response_Size = ulTemp;	/* DCS/FCS not included */

				/* Transient2 response frame send start flag <- ON */
				gblUserSendTransient2_Response = R_IN32_TRUE;
			}
			else {
			}
		}
		/* If ON, then it's response frame */
		else {
			/* Discard received data */
			/* TODO: Please implement error handling as necessary */
		}
	}

	return;
}


/****************************************************************************/
/** @brief  Received TransientAck Data processing                           */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserHandleReceivedTransientAck(
	const VOID*	pvReceivedFrame,	/**< Received frame */
	USHORT		usReceivedSize		/**< Size (FCS not included) */
)
{

	/* TODO: Please implement the following checks as necessary: */
	/* - whether or not the TransientAck is for the transient frame sent by this node */
	/* - whether or not the result is normal */

	return;
}



/****************************************************************************/
/** @brief  Create Transient1 request frame processing                      */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end (Argument error)                          */
/****************************************************************************/
ERRCODE erUserSetTransient1_Request(
	R_IN32_TRAN1_REQUEST_SETTING_T*	pstRequestSetting,			/**< Transient1 request frame settings */
	const VOID*	pvTransientData,								/**< Transient senging data */
	VOID*	pvSendFrame,										/**< [out] Sengin frame Address */
	ULONG*	pulFrameSize										/**< [out] Sengin frame size */
)
{
	USHORT						usNodeNumber;					/* Station No. */
	UCHAR						uchNetworkNumber;				/* Network No. */
	R_IN32_TRAN1_FRAME_T*			pstSndFrame;					/* Transient1 sending frame */
	UCHAR						auchMACAddress[R_IN32_MACADR_SZ];	/* MAC address */
	
	
	ERRCODE						erRet;							/* Return value  */
	
	
	erRet = R_IN32_OK;
	
	/* Abnormal setting judgment processing of the set value of the argument */
	/* Check maximum transient data size */
	if( TRANSIENT_DATA_SYNTHETIC_MAX_SIZE < pstRequestSetting->usDataAllSize ){
		erRet = R_IN32_ERR;
	}
	
	
	if( R_IN32_OK == erRet ) {
		
		pstSndFrame = (R_IN32_TRAN1_FRAME_T*)pvSendFrame;
		
		(VOID)gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/* Unicast MAC address acquisition */
		if ( uchNetworkNumber == pstRequestSetting->usDstNwNo ) {
			erRet = gerR_IN32_GetUnicastMACAddress( (UCHAR)pstRequestSetting->uchDstNode, &auchMACAddress[0]);
		}
		else {
			erRet = gerR_IN32_GetUnicastMACAddress( 0x7D, &auchMACAddress[0]);
		}
		
		if( R_IN32_OK == erRet ) {
			/* Create MAC + CCIE Header */
			gerR_IN32_SetEtherCcieHeader (
				auchMACAddress,										/**< Sending MAC address */
				gauchUserMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,								/**< Frame classification */
				pstRequestSetting->uchDataClass,					/**< Data classification */
				(VOID*)&pstSndFrame->stCOMMON						/**< [out] MAC + CCIE Header Address */
			);
			
			
			/* Create Transient1 Header */
			gerR_IN32_SetTransient1Header (
				pstRequestSetting->usDataSubClass, 					/**< data sub-type */
				pstRequestSetting->usDataAllSize,					/**< Transient1 data size */
				(VOID*)&(pstSndFrame->stHEAD)						/**< [out] Create Transient1 Header */
			);
			
			
			/* Copy transient data to send transient frame buffer */
			memcpy( (VOID*)&(pstSndFrame->uniDATA), pvTransientData, pstRequestSetting->usDataAllSize );
			
			
			/* Calculate all frame size */
			*pulFrameSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + pstRequestSetting->usDataAllSize;
		}
		
	}
	
	return erRet;
}


/*************************************************************************************/
/** @brief  Transient1 request sending data division judgment processing             */
/** @retval Other than 0(NULL):Buffer address for preparing frame                    */
/**                    0(NULL):Prohibited preparing frame for wrong argument         */
/*************************************************************************************/
VOID* pvUserJudgeTransient1Divide( 
	ULONG ulTrn1DataSize,						/**< Ttansient1 data size  */
	VOID* pvDivideFramebuf,						/**<  division buffer */
	VOID* pvTransmitFrameBuf,					/**< Send buffer */
	USER_TRAN1_DIVIDE_MANAGE_T* pstDivManageData/**< Divide sending Management data */
)
{
	VOID* pvRet = 0;
	
	
	if( TRANSIENT_DATA_SYNTHETIC_MAX_SIZE < ulTrn1DataSize )
	{
		pvRet = 0;
		
		pstDivManageData->blEnableFlg = R_IN32_FALSE;
		
		pstDivManageData->uchSequentialNumber = 0x00;
		pstDivManageData->usRemineByte        = 0;
		pstDivManageData->ulDivideByte        = 0;
		pstDivManageData->pvMakingBuff        = 0;
		pstDivManageData->pvTranceferBuff     = 0;
	}
	else { 
		if( TRANSIENT_DATA_MAX_SIZE > ulTrn1DataSize )			/*  Division necessity condition of transient1 frame*/
		{
			/* Divide sending will not be handled */
			pvRet = pvTransmitFrameBuf;
			
			pstDivManageData->blEnableFlg = R_IN32_FALSE;
			
			pstDivManageData->uchSequentialNumber = 0x00;
			pstDivManageData->usRemineByte        = 0;
			pstDivManageData->ulDivideByte        = 0;
			pstDivManageData->pvMakingBuff        = 0;
			pstDivManageData->pvTranceferBuff     = 0;
		}
		else{
			/* Divide sending will be handled */
			pvRet = pvDivideFramebuf;
			
			pstDivManageData->blEnableFlg         = R_IN32_TRUE;
			
			pstDivManageData->uchSequentialNumber = 0x00;
			pstDivManageData->usRemineByte        = ulTrn1DataSize;
			pstDivManageData->ulDivideByte        = TRANSIENT_DATA_MAX_SIZE;
			pstDivManageData->pvMakingBuff        = pvDivideFramebuf;
			pstDivManageData->pvTranceferBuff     = pvTransmitFrameBuf;
		}
	}
	
	return pvRet;
}


/****************************************************************************/
/** @brief  Received SLMP read memory request processing                    */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end (Argument error)                          */
/****************************************************************************/
ERRCODE erUserHandleReceivedMemReadRequest(
	const VOID* pvReceivedData,					/**< Received data storage area */
	const UCHAR* puchSA,						/**< Sender's MAC address */
	const VOID* pvBufferMemory,					/**< Buffer Memory */
	VOID* pvSendFrame, 							/**< [out] Transmit Address */
	ULONG* pulDataSize							/**< [out] Send Data Size */
)
{
	const R_IN32_MEMREAD_REQUEST_FRAME_T*		pstMemRead;			/* SLMP Read Memory(Request) Frame format */
	const R_IN32_SLMP_REQUEST_DATA_T*			pstRcvData;			/* Request Data All */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*			pstSndFrame;		/* Entire response Frame */
	R_IN32_MEMREAD_RESPONSE_FRAME_T*			pstRespData;		/* SLMP Read memory(Response) Frame format */
	ULONG									ulReadOffset;		/* Reading offset */
	UCHAR*									puchOffsetBuffer;	/* Offset add buffer memory */
	ULONG									ulReadTail;			/* Reading tail */
	USHORT									usNodeNumber;		/* Station No. */
	UCHAR									uchNetworkNumber;	/* network No. */
	ULONG									ulDataSize;			/* Transient data size */
	USHORT									usReadByteSize;		/* Reading byte size */
	USHORT									usCheckResult;		/* result */
	ERRCODE									erRet;				/* Return value */
	
	
	erRet = R_IN32_OK;
	
	/*[ Check destination network No. and destination station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);
	pstRcvData = (const R_IN32_SLMP_REQUEST_DATA_T*)pvReceivedData;

	/* Cast SLMP Read Buffer Memory(Request) Frame format */
	pstMemRead = (const R_IN32_MEMREAD_REQUEST_FRAME_T *)&pstRcvData->auchDataArea[0];

	/*[ Check Start address ]*/
	ulReadOffset = (ULONG)(pstMemRead->ulTopAddress << R_IN32_SHIFT1);

	if (R_IN32_BUFFER_MEMORY_TAIL > ulReadOffset) {
		/*[ Memory tail > Start address ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check request size ]*/
	usReadByteSize = (USHORT)(pstMemRead->usWordSize << R_IN32_SHIFT1);

	if (R_IN32_BUFFER_MEMORY_SIZE >= usReadByteSize) {
		/*[ Memory size >= Request size ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check termination address ]*/
	ulReadTail = ulReadOffset + usReadByteSize;

	if (R_IN32_BUFFER_MEMORY_TAIL >= ulReadTail) {
		/*[ Memory tail >= Tail address ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check data size in the frame ]*/

	if (R_IN32_DATA_SIZE_IN_FRAME >= usReadByteSize) {
		/*[ The data size in the frame >= Request size ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}


	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;

	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		pstRespData = (R_IN32_MEMREAD_RESPONSE_FRAME_T*)&pstSndFrame->auchDataArea[0];
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
			
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32_SetEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				gauchUserMACAddress,							/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_NETWORK_COMMON,						/**< Data classification */
				(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame			/**< [out] prepare MAC+CCIE header address */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_SLMP_RESPONSE_FRAME_T) + (ULONG)(pstMemRead->usWordSize << R_IN32_SHIFT1);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32_SetTransient1Header(
				R_IN32_DSTYPE_SLMP,								/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
						sizeof(R_IN32_NONCICLIC_FRAME_T))			/**< [out] prepare MAC+CCIE header address  */
				);
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ SLMP Hedder information ]*/
		gerR_IN32_SetResponseSlmpHeader(
				&(pstRcvData->stExHead),							/**< Received request Transient2 + SLMP header */
				(USHORT)((pstMemRead->usWordSize << R_IN32_SHIFT1)),	/**< SLMP data size */
				&(pstSndFrame->stExHead)							/**< [out] Response SLMP Header*/
				);
		
		
		/*[ SLMP Response data information ]*/
		
		/*[ Buffer memories reading processing ]*/
		puchOffsetBuffer = (UCHAR*)pvBufferMemory + ulReadOffset;
		
		memcpy((void*)&pstRespData->auchData[0],
					 (const void*)puchOffsetBuffer,
					 (ULONG)usReadByteSize);
		
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pstSndFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Received data storage area */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
	}
	
	return erRet;
}



/****************************************************************************/
/** @brief  Received SLMP write memory request processing                   */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end (Argument error)                          */
/****************************************************************************/
ERRCODE erUserHandleReceivedMemWriteRequest(
	const VOID* pvReceivedData,					/**< Received data storage area */
	const UCHAR* puchSA,						/**< Sender's MAC address */
	const VOID* pvBufferMemory,					/**< Buffer Memory */
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize							/**< [out] Send Data Size */
)
{
	ULONG									ulWriteOffset;		/* Writing offset */
	ULONG									ulWriteTail;		/* Writing tail */
	USHORT									usWriteByteSize;	/* Reading byte size */
	const R_IN32_SLMP_REQUEST_DATA_T*			pstRcvData;			/* Request Data All */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*			pstSndFrame;		/* Entire response Frame */
	const R_IN32_MEMWRITE_REQUEST_FRAME_T*	pstMemWrite;		/* SLMP Write Memory(Request) Frame format */
	ULONG									ulDataSize;			/* Transient data size */
	USHORT									usNodeNumber;		/* Station No. */
	UCHAR									uchNetworkNumber;	/* Network No. */
	USHORT									usCheckResult;		/* result */
	ERRCODE									erRet;				/* Return value */
	
	
	erRet = R_IN32_OK;
	
	/*[ Check destination network No. and destination station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);
	pstRcvData = (const R_IN32_SLMP_REQUEST_DATA_T*)pvReceivedData;

	/* Cast SLMP Write Buffer Memory(Request) Frame format */
	pstMemWrite = (const R_IN32_MEMWRITE_REQUEST_FRAME_T *)&pstRcvData->auchDataArea[0];

	/*[ Check Start address ]*/
	ulWriteOffset = (ULONG)(pstMemWrite->ulTopAddress << R_IN32_SHIFT1);

	if (R_IN32_BUFFER_MEMORY_TAIL > ulWriteOffset) {
		/*[ Memory tail > Start address ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check request size ]*/
	usWriteByteSize = (USHORT)(pstMemWrite->usWordSize << R_IN32_SHIFT1);

	if (R_IN32_BUFFER_MEMORY_SIZE >= usWriteByteSize) {
		/*[ Memory size >= Request size ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check termination address ]*/
	ulWriteTail = ulWriteOffset + usWriteByteSize;

	if (R_IN32_BUFFER_MEMORY_TAIL >= ulWriteTail) {
		/*[ Memory tail >= Tail address ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}

	/*[ Check data size in the frame ]*/

	if (R_IN32_DATA_SIZE_IN_FRAME >= usWriteByteSize) {
		/*[ The data size in the frame >= Request size ]*/
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_BUFFER_ACCESS;
	}


	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;

	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		
		/*[ SLMP write buffer memory processing ]*/
		memcpy((void*)((UCHAR*)pvBufferMemory+ulWriteOffset),
					 (const void*)&pstMemWrite->auchData[0],
					 (ULONG)usWriteByteSize);
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Create MAV and CCIE Header ]*/
		gerR_IN32_SetEtherCcieHeader(
				puchSA,											/**< Sending MAC address */
				gauchUserMACAddress,							/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_NETWORK_COMMON,						/**< Data classification */
				(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame			/**< [out] prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_SLMP_RESPONSE_FRAME_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32_SetTransient1Header(
				R_IN32_DSTYPE_SLMP,								/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
						sizeof(R_IN32_NONCICLIC_FRAME_T))			/**< [out]  prepare MAC+CCIE header address  */
				);
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ SLMP Hedder information ]*/
		gerR_IN32_SetResponseSlmpHeader(
				&(pstRcvData->stExHead),						/**< Received request Transient2+SLMP header  */
				0,												/**< SLMP data size */
				&(pstSndFrame->stExHead)						/**< [out] ResponseSLMP Header*/
				);
		
		
		/*[ SLMP Response data information ]*/
		
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pstSndFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Received data storage area  */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
	
	}
	
	return erRet;
}



/****************************************************************************/
/** @brief  Create SLMP Read Memory Request Frame processing                */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end (Argument error)                          */
/****************************************************************************/
ERRCODE erUserSetSlmpMemRead_Request( USER_SLMP_MEMREAD_SETTING_T* pstMemReadSetting )			/** Read memory command request data  */
{
	R_IN32_SLMP_REQUEST_DATA_T*			pstSlmpRequestData;		/**< SLMP DATA pointer */
	R_IN32_SLMP_REQUSET_SETTING_T			stSlmpTargetSetting;	/**< SLMP target setting */
	R_IN32_TRAN1_REQUEST_SETTING_T		stTrn1ReqSetting;		/**< Transient1 Request setting */
	ULONG								ulSlmpDataAllSize;		/**< SLMP data all size */
	ULONG								ulTranFrameSize;		/**< Transient1 Frame size */
	VOID*								pvTranFrame;			/**< Transient1 Frame */

	ERRCODE								erRet;					/**< Return value */
	UCHAR								uchTemp;				/**< temp */
	
	
	erRet = R_IN32_OK;
	pstSlmpRequestData = (R_IN32_SLMP_REQUEST_DATA_T*)gaulUserSlmpReqData;
	
	if( USER_SLMP_MEMORY_READ_SIZE_MAX < pstMemReadSetting->usWordSize )		/* Check word size  */
	{
		erRet = R_IN32_ERR;
	}
	else
	{
		stSlmpTargetSetting.usConectInfo	= 0x03FF;							/* Destination Connect Info */
		stSlmpTargetSetting.usNwNo			= pstMemReadSetting->uchNwNo;		/* Destination Network No. */
		stSlmpTargetSetting.uchNode			= pstMemReadSetting->uchNode;		/* Destination Node */
		stSlmpTargetSetting.usL				= USER_SLMPHEADER_MEMORY_READ_DATASIZE;		/* SLMP data length */
		stSlmpTargetSetting.usCommand		= USER_SLMPHEADER_MEMORY_READ_COMMAND;		/* SLMP Command */
		stSlmpTargetSetting.usSubCommand	= USER_SLMPHEADER_MEMORY_READ_SUBCOMMAND;	/* SLMP Sub-command */
		
		uchTemp = (UCHAR)(pstMemReadSetting->ulTopAddr);
		pstSlmpRequestData->auchDataArea[0]	= uchTemp;							/* SLMP data : Start address(LSByte)  */
		uchTemp = (UCHAR)(pstMemReadSetting->ulTopAddr >> 8);
		pstSlmpRequestData->auchDataArea[1]	= uchTemp;							/* SLMP data : Start address  */
		uchTemp = (UCHAR)(pstMemReadSetting->ulTopAddr >> 16);
		pstSlmpRequestData->auchDataArea[2]	= uchTemp;							/* SLMP data : Start address  */
		uchTemp = (UCHAR)(pstMemReadSetting->ulTopAddr >> 24);
		pstSlmpRequestData->auchDataArea[3]	= uchTemp;							/* SLMP data : Start address(MSByte)  */
		uchTemp = (UCHAR)(pstMemReadSetting->usWordSize);
		pstSlmpRequestData->auchDataArea[4]	= uchTemp;							/* Device size(LSByte)  */
		uchTemp = (UCHAR)(pstMemReadSetting->usWordSize >> 8);
		pstSlmpRequestData->auchDataArea[5]	= uchTemp;							/* Device size(MSByte)  */
		
		/* Prepare SLMP+Transient2 header  */
		if( R_IN32_OK == gerR_IN32_SetRequestSlmpHeader
				( &stSlmpTargetSetting,											/* SLMP target setting */
				  &( pstSlmpRequestData->stExHead ),							/* Request Data */
				  &ulSlmpDataAllSize,											/* Request Data Size(byte, Expect for "DCS"4byte) */
				  &gusTxSerialNo)												/**< Request Sending serial number(Check for Response) */
		) {
			stTrn1ReqSetting.uchDataClass = R_IN32_DTYPE_NETWORK_COMMON;			/* Network Common */
			stTrn1ReqSetting.usDataSubClass = R_IN32_DSTYPE_SLMP;					/* SLMP */
			stTrn1ReqSetting.usDataAllSize = ulSlmpDataAllSize;
			stTrn1ReqSetting.usDstNwNo = stSlmpTargetSetting.usNwNo;
			stTrn1ReqSetting.uchDstNode = stSlmpTargetSetting.uchNode;
			
			
			pvTranFrame = pvUserJudgeTransient1Divide (
				stTrn1ReqSetting.usDataAllSize,									/**< Transient1 data size  */
				(VOID*)gaulUserSendTransient1_Request_BigFrame,					/**< Designated plitting buffer */
				(VOID*)gaulUserSendTransient1_Request,							/**< Designated send buffer  */
				&gstReqFrameDivManage);											/**< partitioned sent Management data  */
			

			if( 0 != pvTranFrame){
			if( R_IN32_OK == erUserSetTransient1_Request(
				&stTrn1ReqSetting,								/* Transient1 request frame settings */
				(const VOID*)pstSlmpRequestData,				/* Transient senging data  */
					pvTranFrame,								/* [out] Sending frame Address */
				&ulTranFrameSize								/* [out] Sending frame size */
			) ) {
				gulUserSendTransient1_Request_Size = ulTranFrameSize;
				gblUserSendTransient1_Request = R_IN32_TRUE;
				
			}
			else {
					/* If return value of division necessity judge is 0(NULL pointer),it is out of range so it don't send.*/
				erRet = R_IN32_ERR;
			}
				
			}
			else{
				erRet = R_IN32_ERR;

			}

		}
		else {
			erRet = R_IN32_ERR;
		}
	}
	
	
	return erRet;
	
}



/****************************************************************************/
/** @brief  Received SLMP Read Memory Response processing                   */
/** @retval VOID                                                            */
/****************************************************************************/
ERRCODE erUserHandleReceivedMemReadResponse(
	USHORT		usDeviceSize,									/**< Designated */
	const VOID*	pvTransient1Data,								/**< Received data storage area  */
	UCHAR*		puchReadBuffer									/**< Address of read result storage buffer  */
)
{
	ERRCODE erRet;
	USHORT  usByteSize;
	
	
	erRet = R_IN32_OK;
	if( USER_SLMP_MEMORY_READ_SIZE_MAX < usDeviceSize ) {		/* Check wrong argument  */
		erRet = R_IN32_ERR;
	}
	else {
		usByteSize = usDeviceSize * 2;
		memcpy( puchReadBuffer, pvTransient1Data, usByteSize );
	}
	
	return erRet;
	
}



/****************************************************************************/
/** @brief  Start Making Received Transient1 Data processing                */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserStartMakingReceivedTransient1(
	const VOID*			pvReceivedFrame,	/**< Transient1 received frame */
	USER_TRAN1MAKE_T*	pstMake				/**< [out] Reconstruction information */
)
{
	const R_IN32_TRAN1_FRAME_T*	pstReceivedFrame;		/* Received frame */

	pstReceivedFrame = (const R_IN32_TRAN1_FRAME_T*)pvReceivedFrame;

	/* Set to "Now reconstructing" */
	pstMake->blMaking = R_IN32_TRUE;

	/* Store the identification information of the received data */
	pstMake->uchIdentificationNumber = pstReceivedFrame->stHEAD.uchIdentificationNumber;

	/* Store the total size of the received data */
	pstMake->usTransientDataAllSize = usUserSwapS( pstReceivedFrame->stHEAD.usTransientDataAllSize );

	/* Initialize the concatenated size */
	pstMake->usConnectedSize = (USHORT)0;

	return;
}

/****************************************************************************/
/** @brief  Make Received Transient1 Data processing                        */
/** @retval R_IN32_TRUE :Reconstruction finished                              */
/** @retval R_IN32_FALSE:Reconstruction not finished                          */
/****************************************************************************/
BOOL blUserMakeReceivedTransient1(
	const VOID*			pvReceivedFrame,	/**< Transient1 received frame */
	ULONG				ulStorageSize,		/**< Storage area size of the reconstruction data */
	VOID*				pvMadeData,			/**< [out] Reconstruction data */
	USER_TRAN1MAKE_T*	pstMake				/**< [out] Reconstruction information */
)
{
	const R_IN32_TRAN1_FRAME_T*	pstReceivedFrame;		/* Received frame */
	UCHAR*							puchConnectAddress;	/* Start address of the prior concatenated data */
	ULONG							ulOffset;			/* Offset address */
	USHORT							usConnectSize;		/* Data size after concatenation */
	USHORT							usSize;				/* Data size to be concatenated */
	BOOL							blCheckOK;			/* Check result of the received frame */
	BOOL							blComplete;			/* Reconstruction finish flag */


	pstReceivedFrame = (const R_IN32_TRAN1_FRAME_T*)pvReceivedFrame;

	/* Reconstruction not finished */
	blComplete = R_IN32_FALSE;

	/* Initial value of received frame check result */
	blCheckOK = R_IN32_TRUE;

	/* Get offset address */
	ulOffset = ulUserSwapL( pstReceivedFrame->stHEAD.ulOffsetAddress );

	/* Calculate data size after concatenation */
	usSize = usUserSwapS( pstReceivedFrame->stHEAD.usTransientDataDivisionSize );
	usConnectSize = pstMake->usConnectedSize + usSize;

	/*[ Check whether there is error in the received frame ]*/

	/* When offset address doesn't match with concatenated data size */
	/* (in this example, the check is executed under the condition that frames are received in sequential number order) */
	if ( ulOffset != (ULONG)pstMake->usConnectedSize ) {
		blCheckOK = R_IN32_FALSE;
	}
	else {
	}

	/* If reconstruction data doesn't fit to the storage area */
	if ( ulStorageSize < (ULONG)usConnectSize ) {
		blCheckOK = R_IN32_FALSE;
	}
	else {
	}
	/*[ If the check result of the received data is normal, then execute the reconstruction of the received frame]*/
	if ( R_IN32_TRUE == blCheckOK ) {

		/* Copy the data part of the received frame */
		puchConnectAddress = (UCHAR*)pvMadeData;
		puchConnectAddress += pstMake->usConnectedSize;
		memcpy( puchConnectAddress, &pstReceivedFrame->uniDATA, usSize );

		/* Store the concatenated data size */
		pstMake->usConnectedSize = usConnectSize;

		/* All data is present? */
		if ( usConnectSize == pstMake->usTransientDataAllSize ) {

			/* Set "Now reconstructing"-flag to false */
			pstMake->blMaking = R_IN32_FALSE;

			/* Reconstruction finished */
			blComplete = R_IN32_TRUE;
		}
		else {
			/* Reconstruction not finished */
			blComplete = R_IN32_FALSE;
		}
	}
	else {
		/* Reconstruction not finished */
		blComplete = R_IN32_FALSE;
	}

	return blComplete;
}

/********************************************************************************/
/** @brief  Check Received Transient2 Data processing                           */
/** @retval R_IN32_OK              :Normal end                                    */
/** @retval USER_ERR_NOTTOONESELF:Target station No. error in transient sending */
/********************************************************************************/
ERRCODE erUserCheckReceivedTransient2(
	const VOID*	pvReceivedFrame		/**< Received frame */
)
{
	const USER_TRANSIENT2_FRAME_T*	pstReceivedFrame;	/* Received frame */
	const USER_TRANSIENT2_HEAD_T*	pstHeader;			/* Transient frame general header */
	UCHAR							uchNetworkNumber;	/* network No. */
	USHORT							usNodeNumber;		/* Station No. */
	ERRCODE							erResult;			/* Result */

	pstReceivedFrame = (const USER_TRANSIENT2_FRAME_T*)pvReceivedFrame;
	pstHeader = &pstReceivedFrame->stHEAD;

	/*[ Get station and network No. ]*/
	gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );

	/*[ Check whether it's addressed to this node ]*/
	if ( ((UCHAR)usNodeNumber == pstHeader->uchDA)			/* DA  = This node's Station No. */
		&& (uchNetworkNumber == pstHeader->uchDNA)			/* DNA = This node's network No. */
		&& ((UCHAR)usNodeNumber == pstHeader->uchDS) ) {	/* DS  = This node's Station No. */

		/* success */
		erResult = R_IN32_OK;
	}
	else {
		/* Received frame is not addressed to this node */
		erResult = (ERRCODE)USER_ERR_NOTTOONESELF;
	}

	return erResult;
}

/****************************************************************************/
/** @brief  Received Transient2 Read Memory Request processing              */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:USER_ERR_WRREQ_***                                     */
/****************************************************************************/
ERRCODE	erUserHandleReceivedTransient2_RequestSetMemory(
	const USER_TRANSIENT2_REQ_SETMEM_T*	pstData		/**< Memory write request data part of the received frame */
)
{
	/* Warning */
	/* Following sample code for memory write request is implemented based on the following conditions: */
	/* - Memory batch write */
	/* - Access code     = 0x04 (data register) */
	/* - Property        = 0x05 (word access, external information) */
	/* - Address         = 0-63 */
	/* - Write data size = 1-(64 addresses) */

	ERRCODE	erResult;

	switch ( pstData->uchAccessCode ) {

	case 0x04:	/* Data register */

		/* If not batch writing */
		if ( 0x0001UL != (ULONG)pstData->usNumberOfDevices ) {
			erResult = (ERRCODE)USER_ERR_WRREQ_COMMAND_OUTOFRANGE;
		}

		/* If not word access and external information */
		else if ( 0x05UL != (ULONG)pstData->uchProperty ) {
			erResult = (ERRCODE)USER_ERR_WRREQ_ATTRIBUTE_OUTOFRANGE;
		}

		/* If address is out of range */
		else if ( 64UL <= (ULONG)pstData->usAddress ) {

			erResult = (ERRCODE)USER_ERR_WRREQ_ADDRESS_OUTOFRANGE;
		}

		/* If write data size is out of range */
		else if ( (1UL > (ULONG)pstData->usSize) || ((64UL - (ULONG)pstData->usAddress) < (ULONG)pstData->usSize) ){
			erResult = (ERRCODE)USER_ERR_WRREQ_SIZE_OUTOFRANGE;
		}

		/* Normal */
		else {
			/* TODO: Please take the write data according to the write data size */
			/* size = pstData->usSize * 2; */
			/* memcpy( (VOID *)destination, &pstData->auchData[0], size ); */

			erResult = R_IN32_OK;
		}

		break;

	/* TODO: Please implement the handling according to the access code */

	default:		/* Other case */
		/* Because of the unsupported access code on this sample code, erResult<-error */
		erResult = (ERRCODE)USER_ERR_WRREQ_ACCESSCODE_OUTOFRANGE;
		break;
	}

	return erResult;
}

/****************************************************************************/
/** @brief  Received Transient2 read memory response processing             */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE	erUserHandleReceivedTransient2_ResponseGetMemory(
	const USER_TRANSIENT2_RES_T*	pstData			/**< Response data part of the received frame */
)
{
	/* warning */
	/* Following sample code for received response for memory read request is implemented based on the following conditions: */
	/* - Destination node = master (0x7D) */
	/* - Access code      = 0x04 (data register) */
	/* - Property         = 0x05 (word access, external information) */
	/* - Address          = 0 */
	/* - Read data size   = 64 */

	ERRCODE	erResult;
	/* If normal response */
	if ( 0UL == (ULONG)pstData->usRSTS ) {

		/* TODO: Please take the read data according to the read data size */
		/* size = 64 * 2; */
		/* memcpy( (VOID *)destination, &pstData->uniData.stGetMem.auchData[0], size ); */


		erResult = R_IN32_OK;
	}
	/* If error response */
	else {
		erResult = R_IN32_ERR;
	}

	return erResult;
}

/****************************************************************************/
/** @brief  Send Transient1, Transient2, and TransientAck processing        */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserSendTransient(VOID)
{
	R_IN32_NONCICLIC_FRAME_T*	pstHeader;			/**< MAC + CCIE Header */
	ULONG		ulSendBuffAddr;					/**< transient send buffer address */
	ULONG*		pulData;						/**< Send data */
	USHORT		usDataSize;						/**< Size (FCS not included) */
	UCHAR		uchSendBuffNo;					/**< transient send buffer number */
	UCHAR		uchConnection;					/**< connection information */
	ERRCODE		erResult;						/* Result */

	R_IN32_TRAN1_FRAME_T*	pstSndFrame;			/**< Transient frame */
	R_IN32_TRAN1_FRAME_T*	pstMakeSndFrame;		/**< Transient1 Make frame(for divide Sending) */
	UCHAR		uchSequentialNumber;			/**< Sequential number */
	ULONG		ulOffsetAddress;				/**< Offset address */
	USHORT		usTransientDataDivisionSize;	/**< Transient data size in the frame */
	
	
	/* Transient sending has completed? */
	if ( R_IN32_TRUE == gstUserTransientSendResult.blFinish ) {

		/* Transient sending completion status */

		/* Is transient sending normal? */
		if ( R_IN32_OK == gstUserTransientSendResult.erSendStatus ) {
			/* TODO: Please add handling as necessary */
		}

		/* Transient sending is erroneous */
		else {
			/* TODO: Please add handling as necessary */
		}

		/* Set the transient sending result to "sending not finished" */
		gstUserTransientSendResult.blFinish = R_IN32_FALSE;

		/* "Sending transient frame" flag <- OFF */
		gblUserTransientSending = R_IN32_FALSE;
	}
	else {
	}


	/* Is transient sending finished? */
	if ( R_IN32_FALSE == gblUserTransientSending) {

		/* Transient sending necessary? */

		/* If there is TransientAck frame send request */
		if ( R_IN32_TRUE == gblUserSendTransientAck ) {

			/* Set send data and send data size */
			pulData = &gaulUserSendTransientAck[0];
			usDataSize = (USHORT)gulUserSendTransientAck_Size;

			/* TransientAck frame send start flag <- OFF */
			gblUserSendTransientAck = R_IN32_FALSE;
		}
		/* If there is Transient1 response frame send request */
		else if ( R_IN32_TRUE == gblUserSendTransient1_Response ) {

			/* Set send data and send data size */
			pulData = &gaulUserSendTransient1_Response[0];
			usDataSize = (USHORT)gulUserSendTransient1_Response_Size;

			/* Transient1 response frame send start flag <- OFF */
			gblUserSendTransient1_Response = R_IN32_FALSE;
		}
		
		/* If there is Transient1 response frame send request */
		else if ( R_IN32_TRUE == gblUserSendTransient1_Request ) {
			/* Judge divide Sending */
			
			if ( R_IN32_TRUE == gstReqFrameDivManage.blEnableFlg ) {
				pstSndFrame = (R_IN32_TRAN1_FRAME_T*)gstReqFrameDivManage.pvMakingBuff;
				pstMakeSndFrame = (R_IN32_TRAN1_FRAME_T*)gstReqFrameDivManage.pvTranceferBuff;
				
				/*[ Create Sending buffer ]*/
				
				/* Copy MAC + CCIE,Transient1 Header */
				memcpy( &(pstMakeSndFrame->stCOMMON), &(pstSndFrame->stCOMMON), sizeof(pstMakeSndFrame->stCOMMON) );
				memcpy( &(pstMakeSndFrame->stHEAD), &(pstSndFrame->stHEAD), sizeof(pstMakeSndFrame->stHEAD) );
				
				/* Change send frame */
				if( gstReqFrameDivManage.usRemineByte > gstReqFrameDivManage.ulDivideByte ) {
					
					uchSequentialNumber = gstReqFrameDivManage.uchSequentialNumber;
					usTransientDataDivisionSize = gstReqFrameDivManage.ulDivideByte;
					
					/* Calculate offset address */
					ulOffsetAddress  = (ULONG)usUserSwapS(pstSndFrame->stHEAD.usTransientDataAllSize);
					ulOffsetAddress -= gstReqFrameDivManage.usRemineByte;
					
					/* Copy Sending data */
					memcpy( &(pstMakeSndFrame->uniDATA.auchTransientDataArea[0]),
								   &(pstSndFrame->uniDATA.auchTransientDataArea[ulOffsetAddress]),
								   usTransientDataDivisionSize );
					
					/* === Edit transient1 header === */
					/* Offset address */
					pstMakeSndFrame->stHEAD.ulOffsetAddress = ulUserSwapL(ulOffsetAddress);
					
					/* Sequential number */
					pstMakeSndFrame->stHEAD.uchSequentialNumber = uchSequentialNumber;
					
					/* Transient size in frame */
					pstMakeSndFrame->stHEAD.usTransientDataDivisionSize = usUserSwapS(usTransientDataDivisionSize);
					
					
					/* === Edit partitioned Managemen t=== */
					/* Sequential number */
					gstReqFrameDivManage.uchSequentialNumber++;
					
					/* Remaining bytes size */
					gstReqFrameDivManage.usRemineByte -= gstReqFrameDivManage.ulDivideByte;
					
					
				}
				else {
					uchSequentialNumber = gstReqFrameDivManage.uchSequentialNumber;
					uchSequentialNumber |= TRNHEAD_SERIALNO_INIT;
					usTransientDataDivisionSize = gstReqFrameDivManage.usRemineByte;	
					
					/* Calculate offset address */
					ulOffsetAddress  = (ULONG)usUserSwapS(pstSndFrame->stHEAD.usTransientDataAllSize);
					ulOffsetAddress -= gstReqFrameDivManage.usRemineByte;
					
					/* Copy Sending data */
					memcpy( &(pstMakeSndFrame->uniDATA.auchTransientDataArea[0]),
								   &(pstSndFrame->uniDATA.auchTransientDataArea[ulOffsetAddress]),
								   usTransientDataDivisionSize );
					
					/* === Edit transient1 header === */
					/* Offset address */
					pstMakeSndFrame->stHEAD.ulOffsetAddress = ulUserSwapL(ulOffsetAddress);
					
					/* Sequential number */
					pstMakeSndFrame->stHEAD.uchSequentialNumber = uchSequentialNumber;
					
					/* Transient size in frame */
					pstMakeSndFrame->stHEAD.usTransientDataDivisionSize = usUserSwapS(usTransientDataDivisionSize);
					
					gstReqFrameDivManage.blEnableFlg = R_IN32_FALSE;						
					gblUserSendTransient1_Request    = R_IN32_FALSE;
					
				}
				/* divide sending*/
				pulData = (ULONG*)pstMakeSndFrame;
				usDataSize = (USHORT)(usTransientDataDivisionSize + sizeof( pstMakeSndFrame->stHEAD ) + sizeof(pstMakeSndFrame->stCOMMON));
			}
			else {
				/* No divide sending */
				pulData = gaulUserSendTransient1_Request;
				usDataSize = (USHORT)gulUserSendTransient1_Request_Size;
				
				/* Transient1 response frame sending start flag <- OFF */
				gblUserSendTransient1_Request = R_IN32_FALSE;
			}
			
			
		}
		
		/* If there is Transient2 response frame send request */
		else if ( R_IN32_TRUE == gblUserSendTransient2_Response ) {

			/* Set send data and send data size */
			pulData = &gaulUserSendTransient2_Response[0];
			usDataSize = (USHORT)gulUserSendTransient2_Response_Size;

			/* Transient2 response frame send start flag <- OFF */
			gblUserSendTransient2_Response = R_IN32_FALSE;
		}

		/* If there is Transient2 request frame send request */
		else if ( R_IN32_TRUE == gblUserSendTransient2_Request ) {

		/* Set send data and send data size */
		pulData = &gaulUserSendTransient2_Request[0];
		usDataSize = (USHORT)gulUserSendTransient2_Request_Size;

		/* Transient2 request frame send start flag <- OFF */
		gblUserSendTransient2_Request = R_IN32_FALSE;
		}

		/* No transient send request */
		else {
			return;
		}

		/* Get transient send buffer */
		erResult = gerR_IN32_GetSendTransientBuffer(
						usDataSize,					/* send data size (DCS/FCS not included) */
						(VOID**)&ulSendBuffAddr,	/* transient send buffer address   */
						&uchSendBuffNo,				/* transient send buffer number    */
						&uchConnection				/* connection information          */
					);

		/* Transient send buffer obtaining process finished abnormally? */
		if ( R_IN32_ERR == erResult ) {

			/* TODO: Please add error handling as necessary */

			return;
		}
		else {
		}

		/* Set connection information to send data */
		pstHeader = (R_IN32_NONCICLIC_FRAME_T*)pulData;
		pstHeader->uchConnectionInformation = uchConnection;

		/* Storing transmission data to the obtained transient send buffer */
		memcpy( (VOID*)ulSendBuffAddr, pulData, usDataSize );

		/* Request to send the transient frame */
		erResult = gerR_IN32_RequestSendingTransient( uchSendBuffNo, usDataSize );

		/* Is request sending finished normally? */
		if ( R_IN32_OK == erResult) {

			/* "Sending transient frame" flagON */
			gblUserTransientSending = R_IN32_TRUE;
		}
		else {
			/* TODO: Please add error handling as necessary */

			return;
		}
	}
	else {
	}


	return;
}

/****************************************************************************/
/** @brief  Get Transient1 send frame identification number                 */
/** @retval UCHAR Identification number                                     */
/****************************************************************************/
UCHAR uchUserGetTransient1IdentificationNumber(VOID)
{
	static UCHAR	uchID = (UCHAR)0;	/* Identification number */

	uchID++;

	return uchID;
}

/****************************************************************************/
/** @brief  Create Transient2 Response Frame processing                     */
/** @retval ULONG send data size (DCS/FCS not included)                     */
/****************************************************************************/
ULONG ulUserSetTransient2_Response(
	VOID*			pvSendFrame,		/**< [out] Send frame */
	const VOID*		pvReceivedFrame,	/**< Received frame */
	USHORT			usErrorCode			/**< Error code */
)
{
	const USER_TRANSIENT2_FRAME_T*	pstRcvFrame;		/* Received frame */
	USER_TRANSIENT2_FRAME_T*		pstSendFrame;		/* Send frame */
	UCHAR							uchNetworkNumber;	/* network No. */
	ULONG							ulSize;				/* send data size (DCS/FCS not included) */
	USHORT							usNodeNumber;		/* Station No. */
	USHORT							usTemp;				/* Temporary */
	UCHAR							auchMACAddress[R_IN32_MACADR_SZ];			/* MAC address */

	pstRcvFrame = (const USER_TRANSIENT2_FRAME_T*)pvReceivedFrame;
	pstSendFrame = (USER_TRANSIENT2_FRAME_T*)pvSendFrame;

	/*[ Get station and network No. ]*/
	gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );

	/* Destination address */
	usTemp = pstRcvFrame->stCOMMON.usFromAddress1;
	auchMACAddress[0] = (UCHAR)(usTemp);
	auchMACAddress[1] = (UCHAR)(usTemp >> 8);

	usTemp = pstRcvFrame->stCOMMON.usFromAddress2;
	auchMACAddress[2] = (UCHAR)(usTemp);
	auchMACAddress[3] = (UCHAR)(usTemp >> 8);

	usTemp = pstRcvFrame->stCOMMON.usFromAddress3;
	auchMACAddress[4] = (UCHAR)(usTemp);
	auchMACAddress[5] = (UCHAR)(usTemp >> 8);


	/*[ Prepare MAC header part ]*/

	/* Create MAC and CCIE Header */
	gerR_IN32_SetEtherCcieHeader (
		auchMACAddress,										/**< sending MAC address */
		gauchUserMACAddress,								/**< My MAC address */
		USER_FTYPE_TRANSIENT2,								/**< Frame classification */
		R_IN32_DTYPE_CCLINKTRANSIENT,							/**< Data classification */
		&(pstSendFrame->stCOMMON)							/**< [out] prepare MAC+CCIE header address  */
	);


	/*[ Prepare data area ]*/

	/* L     */
	/* Set FNO-RSTS size (for frame with no data after RSTS) */
	pstSendFrame->stHEAD.usL = (USHORT)( (ULONG)&pstSendFrame->uniDATA.stRes.usRSTS - (ULONG)&pstSendFrame->stHEAD.uchFNO
								+ sizeof(pstSendFrame->uniDATA.stRes.usRSTS) );

	/* RSV <- 0x00 */
	pstSendFrame->stHEAD.uchRsv		= (UCHAR)0;

	/* TP/SF */
	pstSendFrame->stHEAD.uchTP_SF	= pstRcvFrame->stHEAD.uchTP_SF;

	/* FNO   */
	pstSendFrame->stHEAD.uchFNO		= pstRcvFrame->stHEAD.uchFNO;

	/* DT    */
	pstSendFrame->stHEAD.uchDT		= pstRcvFrame->stHEAD.uchDT;

	/* DA <- SA */
	pstSendFrame->stHEAD.uchDA		= pstRcvFrame->stHEAD.uchSA;

	/* SA    */
	pstSendFrame->stHEAD.uchSA		= (UCHAR)usNodeNumber;

	/* DAT <- SAT */
	pstSendFrame->stHEAD.uchDAT		= pstRcvFrame->stHEAD.uchSAT;

	/* SAT <- DAT */
	pstSendFrame->stHEAD.uchSAT		= pstRcvFrame->stHEAD.uchDAT;

	/* DMF <- SMF */
	pstSendFrame->stHEAD.uchDMF		= pstRcvFrame->stHEAD.uchSMF;

	/* SMF <- DMF */
	pstSendFrame->stHEAD.uchSMF		= pstRcvFrame->stHEAD.uchDMF;

	/* DNA <- SNA */
	pstSendFrame->stHEAD.uchDNA		= pstRcvFrame->stHEAD.uchSNA;

	/* DS <- SS */
	pstSendFrame->stHEAD.uchDS		= pstRcvFrame->stHEAD.uchSS;

	/* DID <- SID */
	pstSendFrame->stHEAD.usDID		= pstRcvFrame->stHEAD.usSID;

	/* SNA   */
	pstSendFrame->stHEAD.uchSNA		= uchNetworkNumber;

	/* SS    */
	pstSendFrame->stHEAD.uchSS		= (UCHAR)usNodeNumber;

	/* SID   */
	pstSendFrame->stHEAD.usSID		= (USHORT)0x03FF;

	/* L1 */
	/* Set CT-RSTS size (for frame with no data after RSTS) */
	pstSendFrame->stHEAD.usL1 = (USHORT)( (ULONG)&pstSendFrame->uniDATA.stRes.usRSTS - (ULONG)&pstSendFrame->stHEAD.uchCT
								+ sizeof(pstSendFrame->uniDATA.stRes.usRSTS) );

	/* CT */
	/* Set the value which turned ON the bit7 of CT of received frame */
	pstSendFrame->stHEAD.uchCT		= (UCHAR)(0x80UL | (ULONG)pstRcvFrame->stHEAD.uchCT);

	/* RSV <- 0x00 */
	pstSendFrame->stHEAD.uchRsv2	= (UCHAR)0;

	/* APS */
	pstSendFrame->stHEAD.usAPS		= pstRcvFrame->stHEAD.usAPS;

	/* RSTS */
	pstSendFrame->uniDATA.stRes.usRSTS = usErrorCode;

	/*[ Calculate send data size ]*/
	ulSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(USER_TRANSIENT2_HEAD_T) + sizeof(pstSendFrame->uniDATA.stRes.usRSTS);

	return ulSize;
}

/****************************************************************************/
/** @brief  Create TransientAck Frame processing                             */
/** @retval R_IN32_TRUE :TransientAck sending necessary                        */
/** @retval R_IN32_FALSE:TransientAck sending not necessary                    */
/****************************************************************************/
BOOL blUserSetTransientAck(
	VOID*			pvSendFrame,		/**< [out] Send frame */
	const VOID*		pvReceivedFrame,	/**< Received frame */
	USHORT			usReceiveResult		/**< Receive result */
)
{
	const USER_TRANSIENT2_FRAME_T*	pstRcvFrame;		/* Received frame */
	const R_IN32_NONCICLIC_FRAME_T*	pstRcvFrmHead;		/* MAC + CCIE Header */
	USER_TRANSIENT_ACK_FRAME_T*		pstSendFrame;		/* Send frame */
	UCHAR							auchMACAddress[6];	/* MAC address */
	USHORT							usTemp;
	BOOL							blResult;


	pstRcvFrame = (const USER_TRANSIENT2_FRAME_T*)pvReceivedFrame;
	pstRcvFrmHead = &pstRcvFrame->stCOMMON;

	pstSendFrame = (USER_TRANSIENT_ACK_FRAME_T*)pvSendFrame;

	blResult = R_IN32_FALSE;	/* Ack sending not necessary */


	/* Unicast frame? */
	/* (If the bit0 of the 1st octet of the destination MAC address is not 1, then it's unicast frame) */

	if ( 0x0001UL != ( 0x0001UL & (ULONG)pstRcvFrmHead->usToAddress1) ) {

		/*[ Prepare TransientAck frame ]*/

		/*[ Prepare TransientAck frame(MAC header)  ]*/

		/* Destination address */
		usTemp = pstRcvFrame->stCOMMON.usFromAddress1;
		auchMACAddress[0] = (UCHAR)(usTemp);
		auchMACAddress[1] = (UCHAR)(usTemp >> 8);

		usTemp = pstRcvFrame->stCOMMON.usFromAddress2;
		auchMACAddress[2] = (UCHAR)(usTemp);
		auchMACAddress[3] = (UCHAR)(usTemp >> 8);

		usTemp = pstRcvFrame->stCOMMON.usFromAddress3;
		auchMACAddress[4] = (UCHAR)(usTemp);
		auchMACAddress[5] = (UCHAR)(usTemp >> 8);


		/*[ Prepare MAC header part ]*/

		/* Create Ether and CCIE Header */
		gerR_IN32_SetEtherCcieHeader (
			auchMACAddress,										/**< sending MAC address */
			gauchUserMACAddress,								/**< My MAC address */
			USER_FTYPE_TRANSIENTACK,							/**< Frame classification */
			pstRcvFrmHead->uchDataClassification,				/**< Data classification */
			&(pstSendFrame->stCOMMON)							/**< [out] prepare MAC+CCIE header address  */
		);

		/*[ Prepare  TransientAck frame(data)  ]*/

		/* Number of ACK */
		pstSendFrame->ulAckNum = ulUserSwapL( 1UL );

		/* Station No. (exchange the received Station No.) */

		if (pstRcvFrmHead->usMyStationNumber == 0) { 

		/* If Station No.[0x00](target/destination master), then Station No. [0x7D] */
			pstSendFrame->usStationNumber = (USHORT)0x7D;
		}
		/* If Station No. other than[0x00](target/destination master), then not change */
		else{
			pstSendFrame->usStationNumber = pstRcvFrmHead->usMyStationNumber;
		}
		/* Identification number (exchange the received connection information) */
		pstSendFrame->uchDistinctionNumber = pstRcvFrmHead->uchConnectionInformation;

		/* Data sub-type */
		/* If Transient1 frame */
		if ( R_IN32_FTYPE_TRANSIENT1 == pstRcvFrmHead->uchFrameClassification ) {
			/* Data sub-type <- Data sub-type in recieved frame */
			pstSendFrame->usDataSubClassification = ((const R_IN32_TRAN1_FRAME_T*)pvReceivedFrame)->stHEAD.usDataSubClassification;
		}
		/* Other frame */
		else {
			/* Data sub-type <- 0x0000 */
			pstSendFrame->usDataSubClassification = (USHORT)0;
		}

		/* Receive result (big endian) */
		pstSendFrame->usRSTS = usUserSwapS( usReceiveResult );

		blResult = R_IN32_TRUE;	/* Ack sending is necessary */
	}
	else {
		blResult = R_IN32_FALSE;	/* Ack sending not necessary */
	}

	return blResult;
}

/****************************************************************************/
/** @brief  Create Transient2 Request Frame processing                      */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserSetTransient2_Request( VOID )
{
	ULONG		ulSize;			/* Send size (DCS/FCS not included) */


	/* TODO: Following is an example for "Transient2 memory read request" */
	/*       Please implement other necessary handling */


	/* No send request for transient2 request frame */
	if ( R_IN32_FALSE == gblUserSendTransient2_Request ) {

		/* Prepare Transient2 memory read request frame */
		ulSize = ulUserSetTransient2_RequestGetMemory(
					&gaulUserSendTransient2_Request[0]		/* Send frame */
				);

		/* If send data is available */
		if ( 0UL != ulSize ) {

			/* Set Transient2 request frame send data size */
			gulUserSendTransient2_Request_Size = ulSize;

			/* Transient2 request frame send start flag <- OFF */
			gblUserSendTransient2_Request = R_IN32_TRUE;
		}
		else {
		}
	}
	else {
	}

	return;
}
/****************************************************************************/
/** @brief  Create Transient2 read memory request frame                     */
/** @retval ULONG send data size (DCS/FCS not included)                     */
/****************************************************************************/
ULONG ulUserSetTransient2_RequestGetMemory(
	VOID*			pvSendFrame		/**< [out] Send frame */
)
{
	/* warning */
	/* The sample code is implemented based on the following conditions: */
	/* - Destination address = master (0x7D) */
	/* - Access code    = 0x04 (data register) */
	/* - Property       = 0x05 (word access, external information) */
	/* - Address        = 0 */
	/* - Read data size = 64 */

	USER_TRANSIENT2_FRAME_T*	pstSendFrame;		/* Send frame */
	UCHAR						uchDstNodeNmber;	/* destination Station No. */
	UCHAR						uchNetworkNumber;	/* network No. */
	ULONG						ulSize;				/* send data size (DCS/FCS not included) */
	USHORT						usNodeNumber;		/* Station No. */
	ERRCODE						erRet;				/* Return value */
	UCHAR						auchMACAddress[6];	/* MAC address */


	/* Destination Station No. */
	uchDstNodeNmber = (UCHAR)0x7D;	/* Master station */

	/* Get MAC address */
	erRet = gerR_IN32_GetUnicastMACAddress( uchDstNodeNmber, &auchMACAddress[0]);

	/* MAC address could be obtained */
	if ( R_IN32_OK == erRet ) {

		pstSendFrame = (USER_TRANSIENT2_FRAME_T*)pvSendFrame;

		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );

		/*[ Prepare MAC header part ]*/

		/* Create MAC and CCIE Header */
		gerR_IN32_SetEtherCcieHeader (
			auchMACAddress,										/**< sending MAC address */
			gauchUserMACAddress,								/**< My MAC address */
			USER_FTYPE_TRANSIENT2,								/**< Frame classification */
			R_IN32_DTYPE_CCLINKTRANSIENT,							/**< Data classification */
			&(pstSendFrame->stCOMMON)							/**< [out] prepare MAC+CCIE header address  */
		);

		/*[ Prepare data area ]*/

		/* L     */
		/* Set size of FNO-read data size */
		pstSendFrame->stHEAD.usL = (USHORT)( (ULONG)&pstSendFrame->uniDATA - (ULONG)&pstSendFrame->stHEAD.uchFNO
									+ sizeof(USER_TRANSIENT2_REQ_GETMEM_T) );

		/* RSV <- 0 */
		pstSendFrame->stHEAD.uchRsv		= (UCHAR)0;

		/* TP/SF <- 0 */
		pstSendFrame->stHEAD.uchTP_SF	= (UCHAR)0;

		/* FNO <- 0 */
		pstSendFrame->stHEAD.uchFNO		= (UCHAR)0;

		/* DT <- 0 */
		pstSendFrame->stHEAD.uchDT		= (UCHAR)0;

		/* DA    */
		pstSendFrame->stHEAD.uchDA		= uchDstNodeNmber;

		/* SA    */
		pstSendFrame->stHEAD.uchSA		= (UCHAR)usNodeNumber;

		/* DAT */
		pstSendFrame->stHEAD.uchDAT		= (UCHAR)0x22;	/* CC-Link convertible Transient */

		/* SAT */
		pstSendFrame->stHEAD.uchSAT		= (UCHAR)0x22;	/* CC-Link convertible Transient */

		/* DMF <- 0 */
		pstSendFrame->stHEAD.uchDMF		= (UCHAR)0;

		/* SMF <- 0 */
		pstSendFrame->stHEAD.uchSMF		= (UCHAR)0;

		/* DNA   */
		pstSendFrame->stHEAD.uchDNA		= uchNetworkNumber;

		/* DS    */
		pstSendFrame->stHEAD.uchDS		= uchDstNodeNmber;

		/* DID <- 0x03FF */
		pstSendFrame->stHEAD.usDID		= (USHORT)0x03FF;

		/* SNA   */
		pstSendFrame->stHEAD.uchSNA		= uchNetworkNumber;

		/* SS    */
		pstSendFrame->stHEAD.uchSS		= (UCHAR)usNodeNumber;

		/* SID <- 0x03FF */
		pstSendFrame->stHEAD.usSID		= (USHORT)0x03FF;

		/* L1 */
		/* Set size of CT-read data size */
		pstSendFrame->stHEAD.usL1 = (USHORT)( (ULONG)&pstSendFrame->uniDATA - (ULONG)&pstSendFrame->stHEAD.uchCT
									+ sizeof(USER_TRANSIENT2_REQ_GETMEM_T) );

		/* CT */
		pstSendFrame->stHEAD.uchCT		= (UCHAR)0x10;	/* Memory read */

		/* RSV <- 0 */
		pstSendFrame->stHEAD.uchRsv2	= (UCHAR)0;

		/* APS */
		/* Value is not specified */
		pstSendFrame->stHEAD.usAPS		= (UCHAR)1;

		/* Number of device */
		pstSendFrame->uniDATA.stReq.uniData.stGetMem.usNumberOfDevices = (USHORT)1;

		/* Property */
		pstSendFrame->uniDATA.stReq.uniData.stGetMem.uchProperty = (UCHAR)0x05;	/* Word access, external information */

		/* Access code */
		pstSendFrame->uniDATA.stReq.uniData.stGetMem.uchAccessCode = (UCHAR)0x04;	/* Data register */

		/* Address */
		pstSendFrame->uniDATA.stReq.uniData.stGetMem.usAddress = (USHORT)0;

		/* Read size */
		pstSendFrame->uniDATA.stReq.uniData.stGetMem.usSize = (USHORT)64;

		/*[ Calculate send data size ]*/
		ulSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(USER_TRANSIENT2_HEAD_T) + sizeof(USER_TRANSIENT2_REQ_GETMEM_T);
	}
	/* MAC address couldn't be obtained */
	else {
		/*[ No send data ]*/
		ulSize = 0UL;
	}

	return ulSize;
}

/****************************************************************************/
/** @brief  Endian conversion (USHORT)                                      */
/** @retval USHORT Data after endian conversion                             */
/****************************************************************************/
USHORT usUserSwapS(
	USHORT	usVal
)
{
	USHORT	usRet;		/* Return value after endian conversion */
	
	/*[ USHORT type endian conversion ]*/
	usRet = (USHORT)( ((usVal >> 8) & 0x00ff)
					| ((usVal << 8) & 0xff00) );
	
	return(usRet);
}

/****************************************************************************/
/** @brief  Endian conversion (ULONG)                                       */
/** @retval ULONG Data after endian conversion                              */
/****************************************************************************/
ULONG ulUserSwapL(
	ULONG	ulVal
)
{
	ULONG	ulRet;		/* Return value after endian conversion */
	
	/*[ ULONG type endian conversion ]*/
	ulRet = (ULONG)(  ((ulVal >> 24) & 0x000000ff)
					| ((ulVal >>  8) & 0x0000ff00)
					| ((ulVal <<  8) & 0x00ff0000)
					| ((ulVal << 24) & 0xff000000) );
	
	return(ulRet);
}

/*** EOF ***/
