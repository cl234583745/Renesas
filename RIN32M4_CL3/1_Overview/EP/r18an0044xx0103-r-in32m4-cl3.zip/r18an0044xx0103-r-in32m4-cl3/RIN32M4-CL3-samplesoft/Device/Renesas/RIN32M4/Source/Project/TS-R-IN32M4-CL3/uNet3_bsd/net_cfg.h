/***************************************************************************
    MICRO C CUBE / COMPACT, NETWORK
    Default configuration parameters
    Copyright (c)  2008-2021, eForce Co., Ltd. All rights reserved.

    Version Information  2016.03.29: Created
                         2019.12.05: Update CFG_TASK_MAX value to max (64)
                         2021.05.31: Deleted unnecessary macros.
 ***************************************************************************/

#ifndef NETCFG_H
#define NETCFG_H
#ifdef __cplusplus
extern "C" {
#endif

/**************************************************************************/
/* TCP/IP Default Configuration Values                                    */
/**************************************************************************/

#define CFG_NET_DEV_MAX     1           /* Maximum Interface            */
#define CFG_NET_SOC_MAX     10          /* Maximum Sockets (TCP&UDP)    */
#define CFG_NET_TCP_MAX     5           /* Maximum TCP Control blocks   */
#define CFG_NET_ARP_MAX     8           /* ARP Cache                    */
#define CFG_NET_MGR_MAX     8           /* Multicast Group              */
#define CFG_NET_IPR_MAX     2           /* IP Reassembly                */
#define CFG_NET_BUF_SZ      8192
#define CFG_NET_BUF_CNT     16
#define CFG_NET_BUF_OFFSET  42
#define CFG_PATH_MTU        1500        /* IP Path MTU                  */
#define CFG_ARP_RET_CNT     3           /* 3 Times  */
#define CFG_ARP_RET_TMO     1000        /* 1 sec    */
#define CFG_ARP_CLR_TMO     20*60*1000  /* 20 min   */
#define CFG_ARP_PRB_WAI     1*1000
#define CFG_ARP_PRB_NUM     3
#define CFG_ARP_PRB_MIN     1*1000
#define CFG_ARP_PRB_MAX     2*1000
#define CFG_ARP_ANC_WAI     2*1000
#define CFG_ARP_ANC_NUM     2
#define CFG_ARP_ANC_INT     2*1000
#define CFG_IP4_TTL         64
#define CFG_IP4_TOS         0
#define CFG_IP4_IPR_TMO     10*1000     /* 10 sec   */
#define CFG_IP4_MCAST_TTL   1
#define CFG_IGMP_V1_TMO     400*1000
#define CFG_IGMP_REP_TMO    10*1000
#define CFG_TCP_MSS         (CFG_PATH_MTU-40)   /* TCP MSS */
#define CFG_TCP_RTO_INI     3*1000
#define CFG_TCP_RTO_MIN     500
#define CFG_TCP_RTO_MAX     60*1000
#define CFG_TCP_SND_WND     1024
#define CFG_TCP_RCV_WND     1024
#define CFG_TCP_DUP_CNT     4
#define CFG_TCP_CON_TMO     75*1000     /* 75 secs */
#define CFG_TCP_SND_TMO     64*1000     /* 64 secs */
#define CFG_TCP_CLS_TMO     75*1000     /* 75 secs */
#define CFG_TCP_CLW_TMO     20*1000
#define CFG_TCP_ACK_TMO     200
#define CFG_TCP_KPA_CNT     0
#define CFG_TCP_KPA_INT     1*1000
#define CFG_TCP_KPA_TMO     7200*1000
#define CFG_PKT_RCV_QUE     1
#define CFG_TCP_RCV_OSQ_MAX 6
#define CFG_PKT_CTL_FLG     0x0000
#define CFG_NET_TSK_PRI     4
#define CFG_NET_TSK_SIZ     1024
#define CFG_STS_UPD_RES     2000

/* uNet3/BSD wrapper settings */
#define CFG_BSD_TCP_MAX     4
#define CFG_BSD_TCP_TOP     1
#define CFG_BSD_TCP_SBUFSZ  1024
#define CFG_BSD_TCP_RBUFSZ  1024
#define CFG_BSD_UDP_MAX     4
#define CFG_BSD_UDP_TOP     5
#define CFG_TASK_MAX        64


#ifdef __cplusplus
}
#endif
#endif /* NETCFG_H */
