/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_CmuSub3.c                                                 */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_ASIC.h"
#include "R_IN32T_FrmForm.h"
#include "R_IN32T_CmuSub.h"
#include "R_IN32T_Com.h"
#include "R_IN32T_Data.h"


ERRCODE erR_IN32T_Sub_RxNonCyclicCheck(
	const R_IN32T_NCYC_DATAINFO_T	*	pstDataInfo,	
	R_IN32T_PORT_SEL_ENUM				eRxPort,		
	ULONG							ulRxDis			
)
{
	R_IN32T_FRM_TRN1HDR_T*		pstSndHead;		
	R_IN32T_FRM_TRN1HDR_T*		pstRcvHead;		
	R_IN32T_NCYC_TDISNO_ENUM	eTX_DIS;		
	ULONG					ulTemp;			
	USHORT					usFrmSize;		
	USHORT					usExpect;		
	USHORT*					pusAdr;			
	ERRCODE					erResult;		


	usFrmSize = pstDataInfo->usTran1Size;
	usFrmSize += (USHORT)(sizeof(R_IN32T_FRM_TRN1HDR_T) + R_IN32T_DCS_SIZE);

	if ( R_IN32T_E_PORT1 == eRxPort ) {
		usExpect = (USHORT)0;					
	}
	else {
		usExpect = RDIS1_RECVPORT2;				
	}
	usExpect |= RDIS1_OWNRDISCRIPTERUSED;		

	usExpect |= usFrmSize;			

	pusAdr = (USHORT*)&RD->astRD_NCYC[ulRxDis].RD_RDIS1;

	erResult = erR_IN32T_Com_BitCompExpect_Word( pusAdr, (USHORT)0xFFFF, usExpect );

	if ( R_IN32_OK == erResult ){


		ulTemp = (ULONG)(RDIS2_BUF_ADDR_MASK & RD->astRD_NCYC[ulRxDis].RD_RDIS2.uniRdis2.usAll);
		ulTemp += (ULONG)&TRNMAP->auchTransientRcvRAM[0];
		pstRcvHead = (R_IN32T_FRM_TRN1HDR_T*)ulTemp;

		eTX_DIS = pstDataInfo->eTX_DIS;
		pstSndHead = (R_IN32T_FRM_TRN1HDR_T*)gaulR_IN32T_NCycTxBufAdr[(ULONG)eTX_DIS - TDISC_NO_TRANSIENT];
		pstSndHead->stFRMHDR.ulHec = pstRcvHead->stFRMHDR.ulHec;

		ulTemp = (ULONG)usFrmSize - R_IN32T_DCS_SIZE;	
		erResult = erR_IN32T_Com_MemCompExpect_DWord( (ULONG*)pstRcvHead, (ULONG*)pstSndHead, ulTemp );
	}
	else {
	}

	return( erResult );
}

/*** EOF ***/
