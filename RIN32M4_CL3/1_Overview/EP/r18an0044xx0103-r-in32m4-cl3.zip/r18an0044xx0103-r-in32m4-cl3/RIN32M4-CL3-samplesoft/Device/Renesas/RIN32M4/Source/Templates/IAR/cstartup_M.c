/**
 *******************************************************************************
 * @file  cstartup_M.c
 * @brief sample program for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#pragma language=extended
#pragma segment="CSTACK"

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "kernel.h"

#ifdef SFLASH_QUAD_BOOT
#include <stdint.h>
#include "sflash.h"
#endif	/* SFLASH_QUAD_BOOT */

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
typedef void( *intfunc )( void );
typedef union { intfunc __fun; void * __ptr; } intvec_elem;

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/
extern void __iar_program_start( void );
extern void __iar_data_init3(void);
extern void __iar_init_vfp(void);

extern int main(void);
extern void exit(void);
extern ER hwos_setup(void);

extern const intvec_elem __vector_table[];

#ifdef SFLASH_QUAD_BOOT
void pre_init(void);
void memcpy_pre(uint32_t dst, uint32_t src, uint32_t size);
#endif	/* SFLASH_QUAD_BOOT */

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  Reset Handler
  @param  none
  @retval none
 ******************************************************************************
*/
#pragma required=__vector_table
void __iar_program_start( void )
{

	SystemInit();

#ifdef SFLASH_QUAD_BOOT
	pre_init();
#endif	/* SFLASH_QUAD_BOOT */

	__iar_data_init3();
	__iar_init_vfp();			// FPU enable

	//--------------------------
	// Replace vectors address
	//--------------------------
	SCB->VTOR = (uint32_t)__vector_table;

	main();

	exit();
}

/**
 ******************************************************************************
  @brief  Main program (when HW-RTOS is used)
  @param  none
  @retval 0
 ******************************************************************************
*/
#ifndef OSLESS
int main(void)
{
	//--------------------------
	// Setup HWRTOS
	//--------------------------
	hwos_setup();

	return 0;
}
#endif	// OSLESS

#ifdef SFLASH_QUAD_BOOT
#ifdef __ICCARM__
#pragma section="PRE_PRG_RDBLK"
#pragma section="PRE_PRG_WRBLK"
#endif  // __ICCARM__

/**
 ******************************************************************************
  @brief  pre init function
  @param  none
  @retval none
 ******************************************************************************
*/
void pre_init(void)
{
	volatile uint8_t	*src;
	volatile uint8_t	*dst;
	volatile uint32_t	size;

	src		= __section_begin("PRE_PRG_RDBLK");
	size	= __section_size("PRE_PRG_RDBLK");
	//IRAM is only 32bit access
	if(size & 0x3){
		size = (size & ~0x3UL) + 0x4;
	}
	dst		= __section_begin("PRE_PRG_WRBLK");
	memcpy_pre((uint32_t)dst ,(uint32_t)src ,size);

	sflash_quad_init();
}

/**
 ******************************************************************************
  @brief  memory copy function
  @param  uint32_t dst  : destination address
  @param  uint32_t src  : source address
  @param  uint32_t size : copy size
  @retval none
 ******************************************************************************
*/
void memcpy_pre(uint32_t dst, uint32_t src, uint32_t size)
{
	uint32_t *src4, *dst4, size4;
	uint8_t  *src1, *dst1, size1;
	
	src4 = (uint32_t *)src;
	dst4 = (uint32_t *)dst;
	
	size4 = size >> 2;
	if (size4 > 0) {
		while (size4 > 0) {
			*dst4++ = *src4++;
			size4--;
		}
	}
	
	size1 = size & 0x03;
	src1 = (uint8_t *)src4;
	dst1 = (uint8_t *)dst4;
	while (size1 > 0) {
		*dst1++ = *src1++;
		size1--;
	}
}
#endif	/* SFLASH_QUAD_BOOT */
