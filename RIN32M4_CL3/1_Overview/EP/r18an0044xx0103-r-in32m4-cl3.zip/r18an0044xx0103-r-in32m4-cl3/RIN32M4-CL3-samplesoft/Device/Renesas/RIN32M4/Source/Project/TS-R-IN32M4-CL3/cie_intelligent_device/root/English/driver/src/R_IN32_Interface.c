/****************************************************************************/
/** @file                                                                   */
/** @brief  Interface                                                       */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"
#include "R_IN32T_TxFrame.h"

#include "R_IN32C_l.h"

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

R_IN32_STP_CAUSE_TAG	gstStopCause;				/* Data Link Stop Cause */

/****************************************************************************/
/** @brief  Get reset status                                                */
/** @retval R_IN32_RESET_PWRON  Power-ON reset (cold start)                   */
/** @retval R_IN32_RESET_SYSTEM System reset   (hot start)                    */
/****************************************************************************/
ULONG   gulR_IN32_GetResetStatus( VOID )
{
	ULONG ulResetLevel;
	ULONG ulMACAddress0Temp;
	ULONG ulMACAddress1Temp;

	ulMACAddress0Temp = RING->ulMACAddress0;
	ulMACAddress1Temp = RING->ulMACAddress1;
	if (( 0UL == ulMACAddress0Temp ) && ( 0UL == ulMACAddress1Temp)) {
		ulResetLevel = R_IN32_RESET_PWRON;
	} else {
		ulResetLevel = R_IN32_RESET_SYSTEM;
	}

	return ulResetLevel;
}



/****************************************************************************/
/** @brief  Initialize R_IN32M4                                                */
/** @retval R_IN32_OK:Normal end                                              */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm*/
/**          whether or not fatal error is occurred after calling this      */
/**          function                                                       */
/****************************************************************************/
ERRCODE gerR_IN32_Initialize(
	const UCHAR*          puchMACAddr,			/**< MAC address      */
	const R_IN32_UNITINFO_T* pstUnitInfo, 		/**< Unit information */
	const R_IN32_UNITINIT_T* pstUnitInit			/**< Initial setting  */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_Init(puchMACAddr, pstUnitInfo, pstUnitInit);

	erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();

	/*[ Data Link Time Up  ]*/
	gstStopCause.StpDtl.b1ZStpLostMaster = R_IN32_ON;

	return erRet;
}



/****************************************************************************/
/** @brief  Set station and network No.                                     */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abormal end (error status in the library)              */
/** @retval R_IN32_ERR_OUTOFRANGE (node or network No. is out of range)       */
/****************************************************************************/
ERRCODE gerR_IN32_SetNodeAndNetworkNumber(
	UCHAR  uchNetworkNumber, 					/**< network No. */
	USHORT usNodeNumber							/**< node number    */
)
{
	ERRCODE erRet;

	if ((R_IN32U_NETWORK_NUMBER_MIN > uchNetworkNumber) || (R_IN32U_NETWORK_NUMBER_MAX < uchNetworkNumber)) {
		return R_IN32_ERR_OUTOFRANGE;
	}
	else {
	}

	if (( R_IN32U_NODE_NUMBER_MIN > usNodeNumber ) || ( R_IN32U_NODE_NUMBER_MAX < usNodeNumber )) {
		return R_IN32_ERR_OUTOFRANGE;
	}
	else {
	}

	erRet = gerR_IN32C_Start(uchNetworkNumber, usNodeNumber);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Start R_IN32M4 communication                                       */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm*/
/**          whether or not fatal error is occurred after calling this      */
/**          function                                                       */
/****************************************************************************/
ERRCODE gerR_IN32_Start( VOID )
{
	ERRCODE erRet;

	erRet = erR_IN32C_SeqMainWaitStart( R_IN32C_EVT_START );

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Reset R_IN32M4 internal WDT                                         */
/** @retval R_IN32_OK:Normal end                                               */
/****************************************************************************/
ERRCODE gerR_IN32_ResetWDT( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	EMGDBG->stWDTRST.uniWdtRst.stBit.b1ZWDTReset = (USHORT)R_IN32_ON;

	return erRet;
}



/*****************************************************************************/
/** @brief  Disable R_IN32M4 internal WDT                                       */
/** @retval R_IN32_OK :Normal end                                              */
/*****************************************************************************/
ERRCODE gerR_IN32_DisableWDT( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_StopWdt();

	return erRet;
}



/****************************************************************************/
/** @brief  Enable R_IN32M4 internal WDT                                        */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_EnableWDT( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	EMGDBG->stWDTCNT.uniWdtCnt.stBit.b1ZWDTCntl = (USHORT)R_IN32_ON;

	return erRet;
}



/****************************************************************************/
/** @brief  Set R_IN32M4 internal WDT time limit                               */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetWDT(
	USHORT usWDTCOUNT							/**< WDT time out value */
)
{
	ERRCODE erRet = R_IN32_OK;

	EMGDBG->usWDTCOUNT = (WDT_COUNT_BIT & usWDTCOUNT);

	return erRet;
}



/****************************************************************************/
/** @brief  Detects R_IN32M4 events                                            */
/** @retval R_IN32_OK:Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetEvent(
	R_IN32_EVTPRM_INTERRUPT_T* pstEvent				/**< [out] Interrupt cause */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_IntrINT1_2( pstEvent );

	return erRet;
}



/****************************************************************************/
/** @brief  Main R_IN32M4 event detection processing                           */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm*/
/**          whether or not fatal error is occurred after calling this      */
/**          function                                                       */
/****************************************************************************/
ERRCODE gerR_IN32_Main(
	const R_IN32_EVTPRM_INTERRUPT_T* pstEvent			/**< Interrupt cause */
)
{
	ERRCODE erRet;

	erRet = erR_IN32C_SeqMain( pstEvent );

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	R_IN32C_SeqPort(R_IN32C_PORT1, R_IN32C_PORT_EVT_TICK);
	R_IN32C_SeqPort(R_IN32C_PORT2, R_IN32C_PORT_EVT_TICK);
	return erRet;
}



/****************************************************************************/
/** @brief  Restart detection R_IN32M4 events                                   */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_RestartEvent( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_ReleaseLoopIntMask();

	return erRet;
}






/*************************************************************************************/
/** @brief  Update MIB information.                                                  */
/** @retval R_IN32_OK :Normal end                                                      */
/** @retval R_IN32_ERR:Abnormal end (status error in library / mismatch)               */
/** @retval R_IN32_ERR_OTHER (Error occurred in library internal driver)               */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm         */
/**          whether or not fatal error is occurred after calling this function      */
/*************************************************************************************/
ERRCODE gerR_IN32_UpdateMIB( VOID )
{
	ERRCODE erRet;

	erRet = erR_IN32C_SetMIB();

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else if ( R_IN32C_NG_OBJ == erRet ) {
		erRet = R_IN32_ERR;
	}
	else {
		erRet = R_IN32_ERR_OTHER;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Stop cyclic for user application-side reasons                    */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_SetCyclicStop( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_SetCyclicSndStopRequest( R_IN32C_CYCSTOP_APP2 );

	return erRet;
}



/******************************************************************************/
/** @brief  Clears cyclic communication stop for user application-side reasons*/
/** @retval R_IN32_OK :Normal end                                               */
/******************************************************************************/
ERRCODE gerR_IN32_ClearCyclicStop( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_ClrCyclicSndStopRequest( R_IN32C_CYCSTOP_APP2 );

	return erRet;
}



/****************************************************************************/
/** @brief  Get received cyclic data                                         */
/** @retval R_IN32_OK :Normal end (received data present)                      */
/** @retval R_IN32_ERR:Abnormal end (no received data)                         */
/****************************************************************************/
ERRCODE gerR_IN32_GetReceivedCyclicData(
	VOID* pRyDst,							/**< [out] start address in RY area (4byte alignment)  */
	VOID* pRWwDst,							/**< [out] start address in RWw area (4byte alignment) */
	BOOL  blEnable							/**< Copy enable/disable */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_CyclicRcvMain(pRyDst, pRWwDst, blEnable);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Get the master node status                                       */
/** @retval R_IN32_OK :Normal end                                              */
/** @retval R_IN32_ERR:Abnormal end                                            */
/****************************************************************************/
ERRCODE gerR_IN32_GetMasterNodeStatus(
	BOOL*  pblRunSts,						/**< [out] application status       */
	BOOL*  pblErrSts,						/**< [out] application error status */
	ULONG* pulErrCode						/**< [out] error code               */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_GetMasterUserAppStatus(pblRunSts, pblErrSts, pulErrCode);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Sets MyStatus data to send                                       */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_SetMyStatus( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_SeqMain_TimeInterval();

	return erRet;
}



/****************************************************************************/
/** @brief  Set cyclic sending data                                          */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_SetSendCyclicData(
	const VOID* pRxSrc,						/**< start address in RX area  */
	const VOID* pRWwSrc,					/**< start address in RWw area */
	BOOL  blEnable							/**< Copy enable/disable */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_CyclicSndMain(pRxSrc, pRWwSrc, blEnable);

	return erRet;
}



/****************************************************************************/
/** @brief  Sets its host station status.                                    */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_SetNodeStatus(
	ULONG ulRunSts,							/**< Application detail operation status */
	ULONG ulErrSts,							/**< Application error status */
	ULONG ulUserInformation					/**< Vendor specific node information */
)
{
	ERRCODE erRet = R_IN32_OK;
	ULONG ulErrCode;
	ULONG ulMotSyncState;
	
	ulErrCode = 0;
	ulMotSyncState = 0;

	gerR_IN32C_SetCPUState(ulRunSts, ulErrSts, ulErrCode, ulMotSyncState, ulUserInformation);

	return erRet;
}



/****************************************************************************/
/** @brief  Sets a forced stop                                               */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_ForceStop( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	EMGDBG->stSELF_WDT.uniSelfWdt.stBit.b1ZMyStationCriticalTrouble = (USHORT)R_IN32_ON;

	return erRet;
}



/****************************************************************************/
/** @brief  Get station and network No.                                      */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetNodeAndNetworkNumber(
	USHORT* pusNodeNumber,					/**< [out] Node number    */
	UCHAR*  puchNetworkNumber				/**< [out] network No. */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetNumber(pusNodeNumber, puchNetworkNumber);

	return erRet;
}



/****************************************************************************/
/** @brief  Gets specified cyclic communication size from master station     */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetCurrentCyclicSize(
	R_IN32_CYCLIC_SIZE_T* pstCyclicSize		/**< [out] current cyclic size */
)
{
	R_IN32C_UNITINF0_T stInfo;
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetUnitInfo0( &stInfo );

	pstCyclicSize->ulRySize = stInfo.ulCurrRySize;
	pstCyclicSize->ulRxSize = stInfo.ulCurrRxSize;
	pstCyclicSize->ulRWwSize = stInfo.ulCurrRWwSize;
	pstCyclicSize->ulRWrSize = stInfo.ulCurrRWrSize;

	return erRet;
}



/****************************************************************************/
/** @brief  Get data linkn status                                            */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetCommumicationStatus(
	ULONG* pulCommSts						/**< [out] communication status */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetCommState( pulCommSts );

	return erRet;
}



/****************************************************************************/
/** @brief  Get the PHY link status                                          */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetPortStatus(
	ULONG  ulPort,							/**< port number to be read */
	ULONG* pulLinkStatus,					/**< [out] status           */
	ULONG* pulSpeed,						/**< [out] transfer rate    */
	ULONG* pulDuplex						/**< [out] Full/half duplex */
)                                           
{
	ERRCODE erRet = R_IN32_OK;

	if (R_IN32_PORT1 == ulPort) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	gerR_IN32D_PhyGetState(ulPort, pulLinkStatus, pulSpeed, pulDuplex);

	return erRet;
}



/****************************************************************************/
/** @brief  Get cyclic communication status                                  */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetCyclicStatus(
	R_IN32_CYCLIC_STA_T* pstCyclicStatus		/**< cyclic communication status */
)
{
	R_IN32D_CYCLIC_STA_GET_T stCyclicSTA;
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetCycStopState( &stCyclicSTA );

	pstCyclicStatus->uniCycSta.stBit.b3ZComonParamkeepCond       = stCyclicSTA.uniCycSta.stBit.b3ZComonParamkeepCond;
	pstCyclicStatus->uniCycSta.stBit.b1ZParamCheckCond           = stCyclicSTA.uniCycSta.stBit.b1ZParamCheckCond;
	pstCyclicStatus->uniCycSta.stBit.b1ZMyNodeNoRangeOut         = stCyclicSTA.uniCycSta.stBit.b1ZMyStationNoRangeOut;
	pstCyclicStatus->uniCycSta.stBit.b1ZMyNodeReserveSetup       = stCyclicSTA.uniCycSta.stBit.b1ZMyStationReserveSetup;
	pstCyclicStatus->uniCycSta.stBit.b1ZCyclicOpeInstructPackage = stCyclicSTA.uniCycSta.stBit.b1ZCyclicOpeInstructPackage;
	pstCyclicStatus->uniCycSta.stBit.b1ZCyclicOpeInstructVarious = stCyclicSTA.uniCycSta.stBit.b1ZCyclicOpeInstructVarious;
	pstCyclicStatus->uniCycSta.stBit.b1ZReserved1                = (USHORT)0;
	pstCyclicStatus->uniCycSta.stBit.b1ZMyMpuAbnomal             = stCyclicSTA.uniCycSta.stBit.b1ZMyMpuAbnomal;
	pstCyclicStatus->uniCycSta.stBit.b1ZMyNodeNumberDuplicate    = stCyclicSTA.uniCycSta.stBit.b1ZMyStationNumberDuplicate;
	pstCyclicStatus->uniCycSta.stBit.b1ZReserved2                = (USHORT)0;
	pstCyclicStatus->uniCycSta.stBit.b1ZNodeTypeWrong            = stCyclicSTA.uniCycSta.stBit.b1ZStationClassificationWrong;
	pstCyclicStatus->uniCycSta.stBit.b1ZReserved3                = (USHORT)0;
	pstCyclicStatus->uniCycSta.stBit.b1ZDLinkState               = stCyclicSTA.uniCycSta.stBit.b1ZDLinkState;
	pstCyclicStatus->uniCycSta.stBit.b1ZCyclicState              = stCyclicSTA.uniCycSta.stBit.b1ZCyclicState;

	return erRet;
}



/****************************************************************************/
/** @brief  Get the MIB information of R_IN32M4                                 */
/** @retval R_IN32_OK :Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_GetMIB(
	R_IN32_MIB_T* pstMIB						/**< R_IN32M4 MIB information */
)
{
	R_IN32C_ERRCNT_T stErrCount;
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetErrorCount( &stErrCount );

	pstMIB->stSDRD.ulCyclicRecNomalFrameCnt = stErrCount.stSDRD.ulCyclicRecNomalFrameCnt;
	pstMIB->stSDRD.ulNonCyclicRecValidCnt   = stErrCount.stSDRD.ulNonCyclicRecValidCnt;
	pstMIB->stSDRD.ulNonCyclicRecRejectCnt  = stErrCount.stSDRD.ulNonCyclicRecRejectCnt;

	pstMIB->stMACIP1.ulRFrm    = stErrCount.stMACIP1.ulRFrm;
	
	pstMIB->stMACIP1.ulTFrm    = stErrCount.stMACIP1.ulTFrm;
	pstMIB->stMACIP1.ulRUnd    = stErrCount.stMACIP1.ulRUnd;
	pstMIB->stMACIP1.ulROvr    = stErrCount.stMACIP1.ulROvr;
	pstMIB->stMACIP1.ulRFcs    = stErrCount.stMACIP1.ulRFcs;
	
	pstMIB->stMACIP1.ulRFgm    = stErrCount.stMACIP1.ulRFgm;
	pstMIB->stMACIP1.ulRIFGErr = stErrCount.stMACIP1.ulRIFGErr;
	pstMIB->stMACIP1.ulREps    = stErrCount.stMACIP1.ulREps;
	pstMIB->stMACIP1.ulRCde    = stErrCount.stMACIP1.ulRCde;
	
	pstMIB->stMACIP1.ulRFce    = stErrCount.stMACIP1.ulRFce;
	pstMIB->stMACIP1.ulRCEE    = stErrCount.stMACIP1.ulRCEE;

	pstMIB->stMACIP2.ulRFrm    = stErrCount.stMACIP2.ulRFrm;
	pstMIB->stMACIP2.ulTFrm    = stErrCount.stMACIP2.ulTFrm;
	
	pstMIB->stMACIP2.ulRUnd    = stErrCount.stMACIP2.ulRUnd;
	pstMIB->stMACIP2.ulROvr    = stErrCount.stMACIP2.ulROvr;
	pstMIB->stMACIP2.ulRFcs    = stErrCount.stMACIP2.ulRFcs;
	pstMIB->stMACIP2.ulRFgm    = stErrCount.stMACIP2.ulRFgm;
	
	pstMIB->stMACIP2.ulRIFGErr = stErrCount.stMACIP2.ulRIFGErr;
	pstMIB->stMACIP2.ulREps    = stErrCount.stMACIP2.ulREps;
	pstMIB->stMACIP2.ulRCde    = stErrCount.stMACIP2.ulRCde;
	pstMIB->stMACIP2.ulRFce    = stErrCount.stMACIP2.ulRFce;
	
	pstMIB->stMACIP2.ulRCEE    = stErrCount.stMACIP2.ulRCEE;

	pstMIB->stRING1.ulHecErr      = stErrCount.stRING1.ulHecErr;
	pstMIB->stRING1.ulDcsFcsErr   = stErrCount.stRING1.ulDcsFcsErr;
	pstMIB->stRING1.ulUnderErr    = stErrCount.stRING1.ulUnderErr;
	
	pstMIB->stRING1.ulRpt         = stErrCount.stRING1.ulRpt;
	pstMIB->stRING1.ulUp          = stErrCount.stRING1.ulUp;
	pstMIB->stRING1.ulRptFullDrop = stErrCount.stRING1.ulRptFullDrop;
	pstMIB->stRING1.ulUpFullDrop  = stErrCount.stRING1.ulUpFullDrop;
	
	pstMIB->stRING2.ulHecErr      = stErrCount.stRING2.ulHecErr;
	pstMIB->stRING2.ulDcsFcsErr   = stErrCount.stRING2.ulDcsFcsErr;
	pstMIB->stRING2.ulUnderErr    = stErrCount.stRING2.ulUnderErr;
	
	pstMIB->stRING2.ulRpt         = stErrCount.stRING2.ulRpt;
	pstMIB->stRING2.ulUp          = stErrCount.stRING2.ulUp;
	pstMIB->stRING2.ulRptFullDrop = stErrCount.stRING2.ulRptFullDrop;
	pstMIB->stRING2.ulUpFullDrop  = stErrCount.stRING2.ulUpFullDrop;
	
	pstMIB->ulP1DownCounter    = stErrCount.ulP1DownCounter;
	pstMIB->ulP2DownCounter    = stErrCount.ulP2DownCounter;
	pstMIB->ulMasterWatchCount = stErrCount.ulMasterWatchCount;

	return erRet;
}



/****************************************************************************/
/** @brief  Clear the MIB information of R_IN32M4                              */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_ClearMIB( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_ClrErrorCount();

	return erRet;
}





/****************************************************************************/
/** @brief  LED control (ERR)                                               */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetERRLED( 
	ULONG ulCtrl							/**< LED lighting control */
 )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_SetLedERR( ulCtrl );

	return erRet;
}






/****************************************************************************/
/** @brief  LED control (User LED1)                                         */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetUSER1LED( 
	ULONG ulCtrl							/**< LED lighting control */
 )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_SetLedREM( ulCtrl );

	return erRet;
}



/****************************************************************************/
/** @brief  LED control (User LED2)                                         */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetUSER2LED( 
	ULONG ulCtrl							/**< LED lighting control */
 )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_SetLedMODE( ulCtrl );

	return erRet;
}



/****************************************************************************/
/** @brief  LED control (RUN LED)                                           */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetRUNLED( 
	ULONG ulCtrl							/**< LED lighting control */
 )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_SetLedRUN( ulCtrl );

	return erRet;
}



/****************************************************************************/
/** @brief  Disable LED control of each LED.                                */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_DisableLED(
	USHORT usBitPattern						/**< disable the LED control of each LED */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_MaskLed( usBitPattern );

	return erRet;
}



/****************************************************************************/
/** @brief  Enable LED control of each LED.                                 */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_EnableLED(
	USHORT usBitPattern						/**< enable the LED control of each LED */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_UnMaskLed( usBitPattern );

	return erRet;
}



/****************************************************************************/
/** @brief  Update communication status LED                                 */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_UpdateLedStatus( VOID )
{
	ERRCODE erRet = R_IN32_OK;
	ULONG ulCommSts;
	
	
	const ULONG	ulRingPhase = RING->ulRingPhase;
	ULONG ulReadRingReg;
	ULONG ulPortStatus;
	ULONG ulDlinkCtrl = R_IN32_LED_OFF;


	/* Get the communication status */
	(VOID)gerR_IN32_GetCommumicationStatus( &ulCommSts );

	/* User program execution according to communication status */
	switch ((INT)ulCommSts) {
	case R_IN32_COMMSTS_CYC_DLINK:
		/* Data Link */
		ulDlinkCtrl = R_IN32_LED_ON;
		/* TODO: add your code here */
		break;

	case R_IN32_COMMSTS_TOKEN_PASS:
		/* Data Link(Cyclic stop) */
		ulDlinkCtrl = R_IN32_LED_BLINK;
		/* TODO: Add your code about Hold/Clear processing */
		/* TODO: add your code here */
		break;

	case R_IN32_COMMSTS_DISCONNECT:
		/* In the parallel off */	
		ulDlinkCtrl = R_IN32_LED_OFF;
		/* TODO: Add your code about Hold/Clear processing */
		/* TODO: add your code here */
		break;

	default:
		break;
	}

	/* Check tokun */
	if ((RINGPHASE_REG_PHASE_SOLISITTOKEN == ulRingPhase) || (RINGPHASE_REG_PHASE_HOLDTOKEN == ulRingPhase)) {
		/* SolicitToken or HoldToken */

		/* Get port, effectively/invalidly */
		ulReadRingReg = RING->ulSetup_Inf3;
		ulPortStatus  = ((SETUP_INF_REG3_T*)&ulReadRingReg)->b08ZSu_Inf6;

		/* Setting in a port is checked */
		switch (ulPortStatus) {
		case R_IN32_MYPORT_PORTALL:
			/* All ports are effective */

			/* Two ports are turned off */
			(void)gerR_IN32D_SetLedLERR1((ULONG)R_IN32_LED_OFF);
			(void)gerR_IN32D_SetLedLERR2((ULONG)R_IN32_LED_OFF);
			break;
			
		case R_IN32_MYPORT_PORT_1:
			/* Only port 1 is effective (With loop back setting) */
			(void)gerR_IN32D_SetLedLERR1((ULONG)R_IN32_LED_OFF);
			(void)gerR_IN32D_SetLedLERR2((ULONG)R_IN32_LED_ON);
			break;
			
		case R_IN32_MYPORT_PORT_2:
			/* Only port 2 is effective (With loop back setting) */
			(void)gerR_IN32D_SetLedLERR1((ULONG)R_IN32_LED_ON);
			(void)gerR_IN32D_SetLedLERR2((ULONG)R_IN32_LED_OFF);
			break;
			
		default :
			break;
		}
	}
	else {
		/* In the parallel off */

		/* Two ports are turned off */
		(void)gerR_IN32D_SetLedLERR1((ULONG)R_IN32_LED_OFF);
		(void)gerR_IN32D_SetLedLERR2((ULONG)R_IN32_LED_OFF);
	}

	/* Update D_LINK LED */
	(VOID)gerR_IN32D_SetLedDLINK( ulDlinkCtrl );

	return erRet;
}



/****************************************************************************/
/** @brief  Get the network time (serial value)                             */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_GetNetworkTime(
	USHORT* pusSerial						/**< [out] Network time 48bit */
)
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_GetNetworkTime_DisableInt( &pusSerial[2], &pusSerial[1], &pusSerial[0] );

	return erRet;
}



/****************************************************************************/
/** @brief  Set the network time (serial value)                             */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetNetworkTime(
	const USHORT* pusSerial					/**< Network time 48bit */
)
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_SetNetworkTime_DisableInt(pusSerial[2], pusSerial[1], pusSerial[0]);

	return erRet;
}



/****************************************************************************/
/** @brief  Convert network time to Clock information                       */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_NetworkTimeToDate(
	R_IN32_TIMEINFO_T* pstTimeinfo,			/**< [out] Clock information   */
	const USHORT*   pusSerial 				/**< Network time 48bit */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_TimeSerialToInfo(pstTimeinfo, pusSerial);

	return erRet;
}



/****************************************************************************/
/** @brief  Convert Clock information to network time                       */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE gerR_IN32_DateToNetworkTime(
	const R_IN32_TIMEINFO_T* pstTimeinfo,		/**< Clock information               */
	USHORT*               pusSerial			/**< [out] Network time 48bit */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_TimeInfoToSerial(pstTimeinfo, pusSerial);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Enable MAC IP access                                             */
/** @retval R_IN32_OK :Normal end                                              */
/** @retval R_IN32_ERR:Abnormal end (MDI command completion waiting error)     */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm */
/**          whether or not fatal error is occurred after calling this       */
/**          function                                                        */
/****************************************************************************/
ERRCODE gerR_IN32_EnableMACIPAccess( VOID )
{
	ERRCODE erRet;

	erRet = erR_IN32C_MacIp_AccessEnable_DisableInt();

	if ( R_IN32D_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Disable MAC IP access                                           */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_DisableMACIPAccess( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_MacIp_AccessDisable();

	return erRet;
}


/****************************************************************************/
/** @brief  Check PHY                                                       */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_CheckPHY( VOID )
{
	ERRCODE erRet;

	erRet = erR_IN32C_CheckPHY();

	return erRet;
}

/****************************************************************************/
/** @brief  Write to PHY internal register                                  */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end (MDIO command end wait error)             */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm*/
/**          whether or not fatal error is occurred after calling this      */
/**          function                                                       */
/****************************************************************************/
ERRCODE gerR_IN32_WritePHY(
	ULONG ulPort,							/**< port number */
	ULONG ulAddr,							/**< address     */
	ULONG ulData							/**< data        */
)                                           
{
	ERRCODE erRet;

	if ( R_IN32_PORT1 == ulPort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erRet = erR_IN32C_WritePHY(ulPort, ulAddr, ulData);

	return erRet;
}



/****************************************************************************/
/** @brief  Read  PHY internal register                                      */
/** @retval R_IN32_OK :Normal end                                              */
/** @retval R_IN32_ERR:Abnormal end (MDIO command end wait error)              */
/** @warning:The result of gR_IN32_CallbackFatalError() can be used to confirm */
/**          whether or not fatal error is occurred after calling this       */
/**          function                                                        */
/****************************************************************************/
ERRCODE gerR_IN32_ReadPHY(
	ULONG  ulPort,							/**< port number */
	ULONG  ulAddr,							/**< address     */
	ULONG* ulData							/**< [out] data  */
)
{
	ERRCODE erRet;

	if ( R_IN32_PORT1 == ulPort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erRet = erR_IN32C_ReadPHY(ulPort, ulAddr, ulData);


	return erRet;
}



/****************************************************************************/
/** @brief  Main transient reception processing 1                           */
/** @retval R_IN32_OK:Normal end                                              */
/****************************************************************************/
ERRCODE gerR_IN32_MainReceiveTransient1( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_RcvBuf();

	return erRet;
}



/****************************************************************************/
/** @brief  Main transient reception processing 2                           */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_MainReceiveTransient2( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_SeqMain_RcvFinish();

	return erRet;
}



/****************************************************************************/
/** @brief  Enables transient reception for vendor reasons.                 */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_EnableReceiveTransient(
	BOOL blEnable							/**< enable/disable reception */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_SetRcvEnable( blEnable );

	return erRet;
}



/****************************************************************************/
/** @brief  Gets status of transient reception for vendor reasons.          */
/** @retval R_IN32_TRUE :enabled                                              */
/** @retval R_IN32_FALSE:disabled                                             */
/****************************************************************************/
BOOL    gblR_IN32_GetReceiveTransientStatus( VOID )
{
	return gblR_IN32C_GetRcvEnable();
}




/****************************************************************************/
/** @brief  Create MAC and CCIE Header                                      */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_SetEtherCcieHeader(
	const UCHAR* puchSndMac,					/**< Destination MAC address */
	const UCHAR* puchMyMac,						/**< My MAC address */
	UCHAR uchFrameClassification,				/**< Frame Type */
	UCHAR uchDataClassification,				/**< Data Type */
	R_IN32_NONCICLIC_FRAME_T* pstCOMMON			/**< [out] Address of creating MAC+CCIE header */
)
{
	ERRCODE erRet;
	
	
	erRet = gerR_IN32T_TxFrame_CreateEtherCcieHeader( puchSndMac, puchMyMac, uchFrameClassification, uchDataClassification, pstCOMMON);
	
	return erRet;
}



/****************************************************************************/
/** @brief  Create Transient1 Header                                        */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_SetTransient1Header(
	USHORT				usDataSubClassification, 			/**< Data sub-type */
	USHORT				usTransientDataSize,				/**< Transient1 data size */
	R_IN32_TRAN1_HEAD_T*	pstHEAD								/**< [out] Create Transient1 Header */
)
{
	ERRCODE erRet;
	
	
	erRet = gerR_IN32T_TxFrame_CreateTransient1Header( usDataSubClassification, usTransientDataSize, pstHEAD );
	
	return erRet;
}



/****************************************************************************/
/** @brief  Create RequestSlmp Header                                       */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_SetRequestSlmpHeader(
	R_IN32_SLMP_REQUSET_SETTING_T*	pstSlmpReqSetting,		/**< SLMP Request Frame Setting */
	R_IN32_SLMP_REQUEST_FRAME_T*		pstSlmpExHead,			/**< [out] RequestSLMP Header*/
	ULONG*							pulAllDataSize,			/**< [out] RequestSLMP all data size */
	USHORT*							pusReqSerialNo			/**< [out] Request send serial No. for responce check  */
)
{
	ERRCODE erRet;
	
	
	erRet = gerR_IN32T_TxFrame_CreateRequestSlmpHeader( pstSlmpReqSetting, pstSlmpExHead, pulAllDataSize, pusReqSerialNo );
	
	return erRet;
}



/****************************************************************************/
/** @brief  Create ResponseSlmp Header                                      */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_SetResponseSlmpHeader(
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstReqSlmpExHead,	/**< Recieved request frame header  */
	USHORT								usSlmpDataSize,		/**< SLMP data size */
	R_IN32_SLMP_RESPONSE_FRAME_T*			pstSlmpExHead		/**< [out] SLMP Response Header */
)
{
	ERRCODE erRet;
	
	
	erRet = gerR_IN32T_TxFrame_CreateResponseSlmpHeader( pstReqSlmpExHead, usSlmpDataSize, pstSlmpExHead );
	
	return erRet;
}



/****************************************************************************/
/** @brief  Get Transient1 send frame identification number                 */
/** @retval UCHAR Identification number                                     */
/****************************************************************************/
UCHAR guchR_IN32_GetTransient1IdentificationNumber(VOID)
{
	UCHAR uchRet;
	
	
	uchRet = guchR_IN32T_TxFrame_GetTransient1IdentificationNumber();
	
	return uchRet;
}



/****************************************************************************/
/** @brief  Received Node Information Distribution Frame processing         */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedMACAddressData(
	const VOID*	pvReceivedData,					/**< Received Transient1 data */
	ULONG		ulDataSize						/**< Received Transient1 data size */
)
{
	const R_IN32_EXTENSION_HEAD_DATA_T*	pstData;			/* Received Transient1 data */
	const R_IN32_NODEINFO_DIST_T*			pstNodeData;		/* MAC address distribution data (received data) */
	const R_IN32_NODEINFO_T*				pstNodeInfo;		/* node information */
	R_IN32_MACADDRESSDATA_T				stNodeInfoData;		/* MAC address table distribution data */
	ULONG								ulCount;			/* counter */
	ULONG								ulDataNum;			/* the number of distribution */
	USHORT								usDestNodeNumber;	/* destination node number */
	USHORT								usMyNodeNumber;		/* host station No. */
	UCHAR								uchDestNetNumber;	/* destination network No. */
	UCHAR								uchMyNetNumber;		/* host network No. */
	UCHAR								uchSeqNumber;		/* distribution sequential number */
	ERRCODE								erCheckResult;		/* result */
	ERRCODE								erRet;				/* result value */


	pstData = (const R_IN32_EXTENSION_HEAD_DATA_T*)pvReceivedData;
	pstNodeData = (const R_IN32_NODEINFO_DIST_T*)&pstData->auchDataArea[0];


	/*[ Check MAC address distribution data ]*/

	/* Set check result to normal */
	erCheckResult = R_IN32_OK;

	/*[ Get number of distribution data ]*/
	ulDataNum = gulR_IN32S_SwapL( pstNodeData->ulDataNum );

	/*[ Check distribution sequential number ]*/
	if( ( R_IN32_NODEINFO_SEQNUMBER_MIN <= pstNodeData->uchSeqNumber )
			&& ( R_IN32_NODEINFO_SEQNUMBER_MAX >= pstNodeData->uchSeqNumber ) ){
	}
	else {
		/* Set check result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Check master's network No. ]*/
	if( ( R_IN32_NETWORK_NUMBER_MIN <= pstNodeData->uchMasterNetNumber )
			&& ( R_IN32_NETWORK_NUMBER_MAX >= pstNodeData->uchMasterNetNumber ) ){
	}
	else {
		/* Set check result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Check number of distribution data ]*/
	if( ( 0UL < ulDataNum )
			&& ( R_IN32_NODEINFO_NUMMAX >= ulDataNum ) ){
	}
	else {
		/* Set check result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Check Transient1 received data size ]*/
	if( ( sizeof(R_IN32_EXTENSION_HEAD_T) + sizeof(R_IN32_NODEINFO_DIST_T)
			 - ( (R_IN32_NODEINFO_NUMMAX - ulDataNum) * sizeof(R_IN32_NODEINFO_T) ) ) == ulDataSize ){
	}
	else {
		/* Set check result to error */
		erCheckResult = R_IN32_ERR;
	}


	/*[ Get station and network No. of this node ]*/
	gerR_IN32_GetNodeAndNetworkNumber( &usMyNodeNumber, &uchMyNetNumber );

	/*[ Check destination network No. ]*/
	uchDestNetNumber = pstData->stOPHEAD.uchDestNetNumber;
	if ( (uchDestNetNumber == uchMyNetNumber) || (uchDestNetNumber == R_IN32_NETWORK_NUMBER_BROADCAST) ) {
	}
	else {
		/* Set result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Check destination node number ]*/
	usDestNodeNumber = gusR_IN32S_SwapS( pstData->stOPHEAD.usDestNodeNumber );
	if ( (usDestNodeNumber == usMyNodeNumber) || (usDestNodeNumber == R_IN32_NODE_NUM_ALL) ) {
	}
	else {
		/* Set result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Is check result normal? ]*/
	if (R_IN32_OK == erCheckResult) {

		/* Get distribution sequential number */
		uchSeqNumber = pstNodeData->uchSeqNumber;

		/*[ Set master station information ]*/

		/* Station No. */
		stNodeInfoData.usNodeNumber = (USHORT)0x7D;

		/* Transient reception function availability */
		stNodeInfoData.uchTransientReceiveEnable = (UCHAR)R_IN32_ENABLE;

		/* MAC address */
		gR_IN32S_Memcpy(&stNodeInfoData.auchMacAddress[0], &pstNodeData->auchMasterMACAddress[0], R_IN32_MACADR_SZ);

		/*[ Update MAC address table ]*/
		gerR_IN32_SetMACAddressTableData( uchSeqNumber, &stNodeInfoData );


		/* Get number of distribution data */
		ulDataNum = gulR_IN32S_SwapL( pstNodeData->ulDataNum );

		/*[ Update MAC address table according to the number of data ]*/
		for(ulCount = 0UL; ulCount < ulDataNum; ulCount++){

			/*[ Set slave information ]*/

			pstNodeInfo = &pstNodeData->astNodeInfo[ulCount];

			/* Station No. */
			stNodeInfoData.usNodeNumber = gusR_IN32S_SwapS( pstNodeInfo->usNodeNumber );

			/* Transient reception function availability */
			if ( 0 != ( R_IN32_AVAILABLEFUNCS_TRANRCV & pstNodeInfo->uchAvailableFuncs ) ) {
				/* Transient receive function available */
				stNodeInfoData.uchTransientReceiveEnable = (UCHAR)R_IN32_ENABLE;
			}
			else {
				/* Transient receive function not available */
				stNodeInfoData.uchTransientReceiveEnable = (UCHAR)R_IN32_DISABLE;
			}

			/* MAC address */
			gR_IN32S_Memcpy(&stNodeInfoData.auchMacAddress[0], &pstNodeInfo->auchMACAddress[0], R_IN32_MACADR_SZ);

			/*[ Check node and network No. ]*/
			if( (pstNodeInfo->uchNetNumber == uchMyNetNumber)
					&& (stNodeInfoData.usNodeNumber <= R_IN32_NODE_NUMBER_MAX) ){
				/*[ Update MAC address table ]*/
				gerR_IN32_SetMACAddressTableData( uchSeqNumber, &stNodeInfoData );
			}
			else{
			}
		}
		
		erRet = R_IN32_OK;
	}
	else{
		
		erRet = R_IN32_ERR;
		
		/* TODO: Please implement error handling as necessary */
	}

	return erRet;
}


/****************************************************************************/
/** @brief  Received Statistical Information Request Frame processing       */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedStatisticInfoRequest (
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**<  Received Transient1 data */
	const UCHAR* puchSA							/**< Sender's MAC address */
)
{
	const R_IN32_EXTENSION_HEAD_DATA_T*	pstRcvData;			/* Received Transient1 data */
	R_IN32_TRAN1_FRAME_T*					pstSndFrame;		/* Sending Transient1 */
	R_IN32_EXTENSION_HEAD_T*				pstOPHead;			/* Extension header */
	R_IN32_TRAN1_STAINF_DATA_T*			pstRespData;		/* Response data */
	R_IN32_MIB_T							stMIB;				/* R_IN32M4 MIB information */
	ULONG								ulDataSize;			/* Transient data size */
	USHORT								usNodeNumber;		/* Station No. */
	UCHAR								uchNetworkNumber;	/* network No. */
	ERRCODE								erCheckResult;		/* result */
	ERRCODE								erRet;				/* result value */
	UCHAR								auchMyMACAddress[6];/* My MAC address */

	/*[ Check destination network and Station No. ]*/
	erCheckResult = gerR_IN32_ErrCheckReqFieldNetworkReceived(pvReceivedData);

	/*[ Is check result normal? ]*/
	if (R_IN32_OK == erCheckResult) {
		
		pstRcvData = (const R_IN32_EXTENSION_HEAD_DATA_T*)pvReceivedData;
		pstSndFrame = (R_IN32_TRAN1_FRAME_T*)pvSendFrame;
		pstOPHead = (R_IN32_EXTENSION_HEAD_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.stOPHEAD;
		pstRespData = (R_IN32_TRAN1_STAINF_DATA_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.auchDataArea[0];
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_FIELD,								/**< Data classification */
				&(pstSndFrame->stCOMMON)						/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_EXTENSION_HEAD_T) + sizeof(R_IN32_TRAN1_STAINF_DATA_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header(
				R_IN32_DSTYPE_FIELD_SYSTEM,						/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				&(pstSndFrame->stHEAD)							/**< [out] prepare MAC+CCIE header address  */
				);
				
		/*[ Create Transient1 Data ]*/
		
		/* Field specific command type */
		pstOPHead->uchCommandType = pstRcvData->stOPHEAD.uchCommandType;

		/* Sub-command type */
		pstOPHead->uchSubCommandType = (UCHAR)((UCHAR)0x80 | pstRcvData->stOPHEAD.uchSubCommandType);

		/* Return value (big endian) */
		pstOPHead->usReturn = (USHORT)0;

		/* Reserved */
		pstOPHead->uchReserved1 = (UCHAR)0;

		/* Destination network No. */
		pstOPHead->uchDestNetNumber = pstRcvData->stOPHEAD.uchSrcNetNumber;

		/* Destination Station No. (big endian) */
		pstOPHead->usDestNodeNumber = pstRcvData->stOPHEAD.usSrcNodeNumber;

		/* Reserved */
		pstOPHead->usReserved2 = (USHORT)0;
		pstOPHead->usReserved3 = (USHORT)0;
		pstOPHead->uchReserved4 = (UCHAR)0;

		/* sending source network No. */
		pstOPHead->uchSrcNetNumber = uchNetworkNumber;

		/* sending source Station No. (big endian) */
		pstOPHead->usSrcNodeNumber = gusR_IN32S_SwapS( usNodeNumber );

		/* Reserved */
		pstOPHead->usReserved5 = (USHORT)0;
		pstOPHead->usReserved6 = (USHORT)0;


		/*[ Prepare data or the data area ]*/

		/* Get statistic information */
		(VOID)gerR_IN32_GetMIB( &stMIB );

		/* Set the statistic information after converting to big-endian */
		pstRespData->ulP1Mib1 = gulR_IN32S_SwapL(stMIB.stRING1.ulHecErr);			/* PORT1 HEC error counter */
		pstRespData->ulP1Mib2 = gulR_IN32S_SwapL(stMIB.stRING1.ulDcsFcsErr);		/* PORT1 DCS/FCS error counter */
		pstRespData->ulP1Mib3 = gulR_IN32S_SwapL(stMIB.stRING1.ulUnderErr);		/* PORT1 Under size error counter */
		pstRespData->ulP1Mib4 = gulR_IN32S_SwapL(stMIB.stRING1.ulRpt);			/* PORT1 Forward frame counter */
		pstRespData->ulP1Mib5 = gulR_IN32S_SwapL(stMIB.stRING1.ulUp);				/* PORT1 Upward frame counter */
		pstRespData->ulP1Mib6 = gulR_IN32S_SwapL(stMIB.stRING1.ulRptFullDrop);	/* PORT1 Forward overflow error counter */
		pstRespData->ulP1Mib7 = gulR_IN32S_SwapL(stMIB.stRING1.ulUpFullDrop);		/* PORT1 Upward overflow error counter */
		pstRespData->ulP2Mib1 = gulR_IN32S_SwapL(stMIB.stRING2.ulHecErr);			/* PORT2 HEC error counter */
		pstRespData->ulP2Mib2 = gulR_IN32S_SwapL(stMIB.stRING2.ulDcsFcsErr);		/* PORT2 DCS/FCS error counter */
		pstRespData->ulP2Mib3 = gulR_IN32S_SwapL(stMIB.stRING2.ulUnderErr);		/* PORT2 Under size error counter */
		pstRespData->ulP2Mib4 = gulR_IN32S_SwapL(stMIB.stRING2.ulRpt);			/* PORT2 Forward frame counter */
		pstRespData->ulP2Mib5 = gulR_IN32S_SwapL(stMIB.stRING2.ulUp);				/* PORT2 Upward frame counter */
		pstRespData->ulP2Mib6 = gulR_IN32S_SwapL(stMIB.stRING2.ulRptFullDrop);	/* PORT2 Forward overflow error counter */
		pstRespData->ulP2Mib7 = gulR_IN32S_SwapL(stMIB.stRING2.ulUpFullDrop);		/* PORT2 Upward overflow error counter */
		
		/* Reserved */
		pstRespData->ulReserved1 = 0UL;
		
		/* Health status data number (big-endian) */
		pstRespData->ulStsDataNum = 0UL;
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
		
	}
	else{
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}

/****************************************************************************/
/** @brief  Received Detailed Node Information Request Frame processing     */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedUnitInfoRequest(
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**<  Received Transient1 data */
	const UCHAR* puchSA							/**< Sender's MAC address */
)
{
	const R_IN32_EXTENSION_HEAD_DATA_T*	pstRcvData;				/* Received Transient1 data */
	R_IN32_TRAN1_FRAME_T*					pstSndFrame;			/* Send frame */
	R_IN32_EXTENSION_HEAD_T*				pstOPHead;				/* Extension header */
	R_IN32_TRAN1_UNITINF_DATA_T*			pstRespData;			/* Response data */
	R_IN32_UNITINFO_T						stUnitInfo;				/* unit information */
	R_IN32_UNITNETWORKSETTING_T			stUnitNetSetting;		/* network setting */
	
	ULONG								ulDataSize;				/* Transient data size */
	USHORT								usNodeNumber;			/* Station No. */
	UCHAR								uchNetworkNumber;		/* network No. */
	ERRCODE								erCheckResult;			/* result */
	ERRCODE								erRet;					/* result value */
	UCHAR								auchMyMACAddress[6];	/* My MAC address */
	
	
	
	/*[ Check destination network and Station No. ]*/
	erCheckResult = gerR_IN32_ErrCheckReqFieldNetworkReceived(pvReceivedData);
	
	
	/*[ Is check result normal? ]*/
	if (R_IN32_OK == erCheckResult) {
		pstSndFrame = (R_IN32_TRAN1_FRAME_T*)pvSendFrame;
		pstRcvData = (const R_IN32_EXTENSION_HEAD_DATA_T*)pvReceivedData;
		pstOPHead = (R_IN32_EXTENSION_HEAD_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.stOPHEAD;
		pstRespData = (R_IN32_TRAN1_UNITINF_DATA_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.auchDataArea[0];
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_FIELD,								/**< Data classification */
				&(pstSndFrame->stCOMMON)						/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_EXTENSION_HEAD_T) + sizeof(R_IN32_TRAN1_UNITINF_DATA_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header (
				R_IN32_DSTYPE_FIELD_SYSTEM,						/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				&(pstSndFrame->stHEAD)							/**< [out] Prepare Transient1 header address */
				);
		
		
		/*[ Prepare the extension header of the data area ]*/

		/* Field specific command type */
		pstOPHead->uchCommandType = pstRcvData->stOPHEAD.uchCommandType;

		/* Sub-command type */
		pstOPHead->uchSubCommandType = (UCHAR)((UCHAR)0x80 | pstRcvData->stOPHEAD.uchSubCommandType);

		/* Return value (big endian) */
		pstOPHead->usReturn = (USHORT)0;

		/* Reserved */
		pstOPHead->uchReserved1 = (UCHAR)0;

		/* Destination network No. */
		pstOPHead->uchDestNetNumber = pstRcvData->stOPHEAD.uchSrcNetNumber;

		/* Destination Station No. (big endian) */
		pstOPHead->usDestNodeNumber = pstRcvData->stOPHEAD.usSrcNodeNumber;

		/* Reserved */
		pstOPHead->usReserved2 = (USHORT)0;
		pstOPHead->usReserved3 = (USHORT)0;
		pstOPHead->uchReserved4 = (UCHAR)0;

		/* sending source network No. */
		pstOPHead->uchSrcNetNumber = uchNetworkNumber;

		/* sending source Station No. (big endian) */
		pstOPHead->usSrcNodeNumber = gusR_IN32S_SwapS( usNodeNumber );

		/* Reserved */
		pstOPHead->usReserved5 = (USHORT)0;
		pstOPHead->usReserved6 = (USHORT)0;


		/*[ Prepare data or the data area ]*/

		/* Get unit information */
		(VOID)gerR_IN32_GetUnitInformation( &stUnitInfo, &stUnitNetSetting );

		/* RY size  (in octet unit)(big endian) */
		pstRespData->usRySize = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulMaxRySize );

		/* RWw size (in word unit)(big endian) */
		pstRespData->usRWwSize = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulMaxRWwSize );

		/* RX size  (in octet unit)(big endian) */
		pstRespData->usRxSize = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulMaxRxSize );

		/* RWr size (in word unit)(big endian) */
		pstRespData->usRWrSize = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulMaxRWrSize );

		/* Reserved */
		pstRespData->uchReserved1 = (UCHAR)0;

		/* Number of ports */
		pstRespData->uchPortTotalNumber = (UCHAR)stUnitInfo.ulMyStationPortTotalNumber;

		/* Token holding time (big endian) */
		pstRespData->usTokenHoldTime = gusR_IN32S_SwapS((USHORT)stUnitInfo.ulTokenHoldTime);

		/* Network behaviour setting (setting for number of sending when holding token) */
		pstRespData->uchTknHoldFrmSendCount = (UCHAR)stUnitNetSetting.ulFrameSendCount;

		/* Network behaviour setting (frame sending interval setting) */
		pstRespData->uchFramSendInterval = (UCHAR)stUnitNetSetting.ulFrameSendInterval;

		/* Reserved */
		pstRespData->uchReserved2 = (UCHAR)0;

		/* Network behaviour setting (setting for number of token sending) */
		pstRespData->uchTokenSendCount = (UCHAR)stUnitNetSetting.ulTokenSendCount;

		/* Node information */
		pstRespData->uchNodeInformation = (UCHAR)stUnitInfo.ulIOType;

		/* Network firmware version */
		pstRespData->uchNetVersion = (UCHAR)stUnitInfo.ulNetVersion;

		/* Network model type (big endian) */
		pstRespData->usNetModelType = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulNetModelType );

		/* Network unit model code (big endian) */
		pstRespData->ulNetUnitModelCode = gulR_IN32S_SwapL( stUnitInfo.ulNetUnitModelCode );

		/* Network vendor code (big endian) */
		pstRespData->usNetVendorCode = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulNetVendorCode );

		/* Reserved */
		pstRespData->usReserved3 = (USHORT)0;

		/* Network unit model name */
		gR_IN32S_Memcpy( &(pstRespData->auchNetUnitModelName[0]), &(stUnitInfo.auchNetUnitModelName[0]),
				sizeof(pstRespData->auchNetUnitModelName) );

		/* Network vendor name */
		gR_IN32S_Memcpy( &(pstRespData->auchNetVendorName[0]), &(stUnitInfo.auchNetVendorName[0]),
				sizeof(pstRespData->auchNetVendorName) );

		/* Controller information flag */
		pstRespData->uchInformationFlag = (UCHAR)stUnitInfo.blInformationFlag;

		/* Controller firmware version */
		pstRespData->uchCtrlVersion = (UCHAR)stUnitInfo.ulCtrlVersion;

		/* Controller model type (big endian) */
		pstRespData->usCtrlModelType = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulCtrlModelType );

		/* Controller unit model code (big endian) */
		pstRespData->ulCtrlUnitModelCode = gulR_IN32S_SwapL( stUnitInfo.ulCtrlUnitModelCode );

		/* Controller vendor code (big endian) */
		pstRespData->usCtrlVendorCode = gusR_IN32S_SwapS( (USHORT)stUnitInfo.ulCtrlVendorCode );

		/* Reserved */
		pstRespData->usReserved4 = (USHORT)0;

		/* Controller unit model name */
		gR_IN32S_Memcpy( &(pstRespData->auchCtrlUnitModelName[0]), &(stUnitInfo.auchCtrlUnitModelName[0]),
				sizeof(pstRespData->auchCtrlUnitModelName) );

		/* Controller vendor name */
		gR_IN32S_Memcpy( &(pstRespData->auchCtrlVendorName[0]), &(stUnitInfo.auchCtrlVendorName[0]),
				sizeof(pstRespData->auchCtrlVendorName) );

		/* Controller vendor device specific information */
		pstRespData->ulVendorInformation = gulR_IN32S_SwapL( stUnitInfo.ulVendorInformation );
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
		
	}
	else{
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}

/****************************************************************************/
/** @brief  Received Option information request frame processing            */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedOptionInfoRequest(
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**<  Received Transient1 data */
	const UCHAR* puchSA,						/**< Sender's MAC address */
	const USHORT usSupportFunction	 			/**< Option support */
)
{
	const R_IN32_EXTENSION_HEAD_DATA_T*	pstRcvData;			/* Received Transient1 data */
	R_IN32_TRAN1_FRAME_T*					pstSndFrame;		/* Send frame */
	R_IN32_EXTENSION_HEAD_T*				pstOPHead;			/* Extension header */
	R_IN32_TRAN1_OPTINF_DATA_T*			pstRespData;		/* Response data */
	ULONG								ulDataSize;			/* Transient data size */
	USHORT								usNodeNumber;		/* Station No. */
	UCHAR								uchNetworkNumber;	/* network No. */
	ERRCODE								erCheckResult;		/* result */
	ERRCODE								erRet;				/* result value */
	UCHAR								auchMyMACAddress[6];/* My MAC address */

	/*[ Check destination network and Station No. ]*/
	erCheckResult = gerR_IN32_ErrCheckReqFieldNetworkReceived(pvReceivedData);

	/*[ Is check result normal? ]*/
	if (R_IN32_OK == erCheckResult) {
		pstRcvData = (const R_IN32_EXTENSION_HEAD_DATA_T*)pvReceivedData;
		pstSndFrame = (R_IN32_TRAN1_FRAME_T*)pvSendFrame;
		pstOPHead = (R_IN32_EXTENSION_HEAD_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.stOPHEAD;
		pstRespData = (R_IN32_TRAN1_OPTINF_DATA_T*)&pstSndFrame->uniDATA.stOPHEAD_DATA.auchDataArea[0];
		
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_FIELD,								/**< Data classification */
				&(pstSndFrame->stCOMMON)						/**< [out] Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_EXTENSION_HEAD_T) + sizeof(R_IN32_TRAN1_OPTINF_DATA_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header(
				R_IN32_DSTYPE_FIELD_SYSTEM,						/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				&(pstSndFrame->stHEAD)							/**< [out] Prepare Transient1 header address */
				);                                               
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ Prepare the extension header of the data area ]*/

		/* Field specific command type */
		pstOPHead->uchCommandType = pstRcvData->stOPHEAD.uchCommandType;

		/* Sub-command type */
		pstOPHead->uchSubCommandType = (UCHAR)((UCHAR)0x80 | pstRcvData->stOPHEAD.uchSubCommandType);

		/* Return value (big endian) */
		pstOPHead->usReturn = (USHORT)0;

		/* Reserved */
		pstOPHead->uchReserved1 = (UCHAR)0;

		/* Destination network No. */
		pstOPHead->uchDestNetNumber = pstRcvData->stOPHEAD.uchSrcNetNumber;

		/* Destination Station No. (big endian) */
		pstOPHead->usDestNodeNumber = pstRcvData->stOPHEAD.usSrcNodeNumber;
		__BUS_RELEASE();

		/* Reserved */
		pstOPHead->usReserved2 = (USHORT)0;
		pstOPHead->usReserved3 = (USHORT)0;
		pstOPHead->uchReserved4 = (UCHAR)0;

		/* sending source network No. */
		pstOPHead->uchSrcNetNumber = uchNetworkNumber;

		/* sending source Station No. (big endian) */
		pstOPHead->usSrcNodeNumber = gusR_IN32S_SwapS( usNodeNumber );

		/* Reserved */
		pstOPHead->usReserved5 = (USHORT)0;
		pstOPHead->usReserved6 = (USHORT)0;


		/*[ Prepare data or the data area ]*/

		/*[ Set option information response frame ]*/
		pstRespData->usFWVer		= gusR_IN32S_SwapS((USHORT)gulR_IN32U_UNIT_VERSION);/* Unit F/W.ver */
		pstRespData->usHWVer		= gusR_IN32S_SwapS(gusR_IN32U_UNIT_HW_VERSION);		/* Unit H/W.ver */
		pstRespData->usFuncVer		= gusR_IN32S_SwapS(gusR_IN32U_UNIT_DEVICE_VERSION);	/* Device.ver */
		pstRespData->usRsv1			= 0x0000;										/* Reserved */
		pstRespData->usSuppFunc		= usSupportFunction;							/* Option support */
		pstRespData->usOptSize		= 0x0000;										/* Option size */

		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;

		erRet = R_IN32_OK;
		
	}
	else{
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}

/****************************************************************************/
/** @brief  Received Select information request frame processing            */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedSelectInfoRequest(
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**<  Received Transient1 data */
	const UCHAR* puchSA,						/**< Sender's MAC address */
	const VOID* pvR_IN32TLedInfo					/**< My LED Info */
)
{
	volatile LINKSTAT_REG_T*			pstLinkStat;			/* Operation PHY Link Register */
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstRcvData;				/* SLMP request frame format */
	CYCLIC_STA_T*						pstCycLicSta;			/* Cyclic state */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*	pstSndFrame;				/* SLMP response frame  */
	R_IN32_SELECTINFO_RESPONSE_FRAME_T*	pstRespData;			/* SLMP select information response frame */
	ULONG								ulDataSize;				/* Transient data size */
	ULONG								ul32bitReg;				/* Register Value */
	ULONG								ulLnkStatus_POne;		/* PORT1 Link Status */
	ULONG								ulLnkStatus_PTwo;		/* PORT2 Link Status */
	ULONG 								ulPortStatus;			/* PORT Status */
	USHORT								usTemp;					/* Temporary */
	USHORT								usNodeNumber;			/* Station No. */
	ULONG								ul32bitReg2;			/* Register Value */
	UCHAR								uchNetworkNumber;		/* network No. */
	USHORT								usCheckResult;			/* result */
	ERRCODE								erRet;					/* result value */
	UCHAR								auchMyMACAddress[6];	/* My MAC address */
	
	
	
	pstRcvData = (const R_IN32_SLMP_REQUEST_FRAME_T*)pvReceivedData;
	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;
	pstRespData = (R_IN32_SELECTINFO_RESPONSE_FRAME_T*)&pstSndFrame->auchDataArea[0];
	
	/*[ Check destination network and Station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);

	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_NETWORK_COMMON,						/**< Data classification */
				(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame			/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_SLMP_RESPONSE_FRAME_T) + sizeof(R_IN32_SELECTINFO_RESPONSE_FRAME_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header(
				R_IN32_DSTYPE_SLMP,								/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
						sizeof(R_IN32_NONCICLIC_FRAME_T))			/**< [out] Prepare MAC+CCIE header address  */
				);
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ SLMP Hedder information ]*/
		gerR_IN32T_TxFrame_CreateResponseSlmpHeader(
				pstRcvData,										/**< Recieved request Transient2+SLMP header  */
				sizeof(R_IN32_SELECTINFO_RESPONSE_FRAME_T),		/**< SLMP data size */
				&(pstSndFrame->stExHead)						/**< [out] ResponseSLMP Header*/
				);
		
		
		/*[ Prepare SLMP frame data ]*/
		/*[ SB0040~009F  ]*/
		/*[ Lumping initializes whole SB (SB0040-SB009F)  ]*/
		gR_IN32S_Memset((void*)&(pstRespData->stSB), (UCHAR)0x00, (ULONG)(sizeof(R_IN32_SELECTINFO_SB_T)));

		/*[ SW0040~009F  ]*/
		/*[ Lumping initializes whole SW (SW0040-SW009F)  ]*/
		gR_IN32S_Memset((void*)&(pstRespData->stSW), (UCHAR)0x00, (ULONG)(sizeof(R_IN32_SELECTINFO_SW_T)));

		/*[ Check setting of Station No. ]*/
		if (R_IN32U_STATION_NUMBER == usNodeNumber) {
			/*[ No Station No. ]*/
			usNodeNumber = (USHORT)0x00;

			/*[ No Station No. ]*/
			gstStopCause.StpDtl.b1ZStpNoStNo = R_IN32_ON ;
		}
		else {
			/*[ established node No. ]*/
		}
		
		/*[ SW0042 <- node No. ]*/
		pstRespData->stSW.usSW0042 = usNodeNumber;

		/*[ Set Data Link Stop Cause(SW0049) ]*/

		/*[ CPU Error  ]*/

		/*[ Because CPU unit doesn't exist, fix no error ] */
		gstStopCause.StpDtl.b1ZStpCpuErr = R_IN32_OFF;

		/*[ Out Station No. ]*/

		/* us16bitReg   = MAC->stCYCLIC_STA.uniCyclicSta.usAll; */
		ul32bitReg2   = TX->CYCLIC_STA.uniCyclicSta.ulAll;
		pstCycLicSta = (CYCLIC_STA_T*)&ul32bitReg2;

		gstStopCause.StpDtl.b1ZStpOutRangeSta = pstCycLicSta->uniCyclicSta.stBit.b01ZMyStationNoRangeOut;

		/*[ Station Type Wrong ]*/
		gstStopCause.StpDtl.b1ZStpStaClass = pstCycLicSta->uniCyclicSta.stBit.b01ZStationClassificationWrong;

		/*[ Duplicate Station ]*/
		gstStopCause.StpDtl.b1ZStpDupSta = pstCycLicSta->uniCyclicSta.stBit.b01ZMyStationNumberDuplicate;

		/*[ Reserved Station  ]*/
		gstStopCause.StpDtl.b1ZStpResvSta = pstCycLicSta->uniCyclicSta.stBit.b01ZMyStationReserveSetup;

		/*[ Parameter Error ]*/
		gstStopCause.StpDtl.b1ZStpCParNg = pstCycLicSta->uniCyclicSta.stBit.b01ZParamCheckCond;

		/*[  Parameter Change ]*/
		if (R_IN32_CYCLIC_STA_PRM_RECV_NOW == pstCycLicSta->uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond){
			gstStopCause.StpDtl.b1ZStpCParCom = R_IN32_ON;
		}
		else {
			gstStopCause.StpDtl.b1ZStpCParCom = R_IN32_OFF;
		}

		/*[ Not Receive Parameter ]*/
		if (R_IN32_CYCLIC_STA_PRM_NO_RECV == pstCycLicSta->uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond){
			gstStopCause.StpDtl.b1ZStpCParNon = R_IN32_ON;
		}
		else {
			gstStopCause.StpDtl.b1ZStpCParNon = R_IN32_OFF;
		}

		/*[ Cyclic implementation directions(Lumping) /Cyclic implementation directions(Different)]*/
		if ((R_IN32_ON == pstCycLicSta->uniCyclicSta.stBit.b01ZCyclicOpeInstructPackage)
		 ||  (R_IN32_ON == pstCycLicSta->uniCyclicSta.stBit.b01ZCyclicOpeInstructVarious)
		 || (R_IN32_ON == pstCycLicSta->uniCyclicSta.stBit.b01ZApricationState)
		 || (R_IN32_ON == pstCycLicSta->uniCyclicSta.stBit.b01ZWaitState)) {
			gstStopCause.StpDtl.b1ZStpCycStp = R_IN32_ON;
		}
		else {
			gstStopCause.StpDtl.b1ZStpCycStp = R_IN32_OFF;
		}

		/* Priority1 */
		/* [No Station No.?] */
		if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpNoStNo) {
			/*  No Station No.(0x0016) */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_NO_STNO ;
		}
		/* Priority2 */
		/* No CPU error state is serious error or the degree of inside error ? */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpCpuErr) {
			/* [CPU Error(0x0020)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_CPU_ERR ;
		}
		/* Priority3 */
		/* [Station No. is out of range total station?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpOutRangeSta) {
			/* [Out Station No.(0x0011)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_PRM_OUT_STNO ;
		}
		/* Priority4 */
		/* [Station Type is agreement?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpStaClass) {
			/* [Station Type Wrong(0x001A)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_STTYPE_WRONG ;
		}
		/* Priority6 */
		/* Duplicate Station? */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpDupSta) {
			/* [Duplicate Station(0x0013)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_DUP_MYSTNO ;
		}
		/* Priority7 */
		/* [Reserved Station?]*/
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpResvSta) {
			/* [Reserved Station(0x0012)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_PRM_RSVST ;
		}
		/* Priority8 */
		/* [Parameter Error?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpCParNg) {
			/* [Parameter Error(0x0018)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_PRM_ERR ;
		}
		/* Priority9 */
		/* [Control master loss?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpLostMaster) {
			/* [Data Link Time Up(0x0002)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_DLINK_TIMUP ;
		}
		/* Priority10 */
		/* [Parameter Change?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpCParCom) {
			/* [Parameter Change(0x0019)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_PRM_CHG ;
		}
		/* Priority11 */
		/* [Not Receive Parameter?] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpCParNon) {
			/* [Not Receive Parameter(0x0010)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_NOT_RCV_PAR ;
		}
		/* Priority12 */
		/* [Stop Data Link?] */
		/* [Cyclic implementation directions(Different) -> Stop Data Link] */
		/* [Data Link Stop -> Stop Data Link] */
		else if(R_IN32_ON == gstStopCause.StpDtl.b1ZStpCycStp) {
			/* [Stop Data Link(0x0001)] */
			pstRespData->stSW.usSW0049 = R_IN32_SW49_STOP_DLNK ;
		}
		/* [Otherwise] */
		else {
			/* [No handling] */ 
		}

		/*[ Set Link status(SW0064) ]*/

		/*[ Get Link Status ]*/
		ul32bitReg  = RING->ulLinkStat;
		pstLinkStat = (LINKSTAT_REG_T*)&ul32bitReg;

	    ulLnkStatus_POne = pstLinkStat->b01ZP1_0;
	    ulLnkStatus_PTwo = pstLinkStat->b01ZP2_0;

		/*[ Get Port Status ]*/
		ul32bitReg   = RING->ulSetup_Inf3;
		ulPortStatus = ((SETUP_INF_REG3_T*)&ul32bitReg)->b08ZSu_Inf6;

		pstRespData->stSW.usSW0064 = R_IN32_PORT1_NG_PORT2_NG;

		/*[ Check Port Number ]*/
		if (R_IN32U_MIN_PORT_NUMBER == gulR_IN32U_MAX_PORT_NUMBER) {
			/* [ Check Loop Back setting]*/
			if (R_IN32_MYPORT_PORTALL == ulPortStatus) {
				/* ALL Effectively*/
				
				/* [ PORT1 Effectively ]*/
				if ((R_IN32_PORT_LINK_UP == ulLnkStatus_POne)
				 && (R_IN32_PORT_LINK_UP == ulLnkStatus_PTwo)) {
					/* OK(PORT1 OK, PORT2 OK) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_OK_PORT2_OK;
				}
				else if ((R_IN32_PORT_LINK_UP   == ulLnkStatus_POne)
					  && (R_IN32_PORT_LINK_DOWN == ulLnkStatus_PTwo)) {
					/* OK(PORT1 OK, PORT2 NG) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_OK_PORT2_OK;
				}
				else if ((R_IN32_PORT_LINK_DOWN == ulLnkStatus_POne)
					  && (R_IN32_PORT_LINK_UP   == ulLnkStatus_PTwo)) {
					/* OK(PORT1 NG, PORT2 OK) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_NG_PORT2_NG;
				}
				else {
					/* NG(PORT1 NG, PORT2 NG) */
				}
			}
			else if (R_IN32_MYPORT_PORT_1 == ulPortStatus){
				/* OK(PORT1 Loop back, PORT2 NG) */
				pstRespData->stSW.usSW0064 = R_IN32_PORT1_OK_PORT2_OK;
			}
			else if (R_IN32_MYPORT_PORT_2 == ulPortStatus){
				/* OK(PORT1 NG, PORT2 Loop back) */
				pstRespData->stSW.usSW0064 = R_IN32_PORT1_NG_PORT2_NG;
			}
			else {
				/* [No handling] */ 
			}
		}
		else {
			/* [ Check Loop Back setting]*/
			if (R_IN32_MYPORT_PORTALL == ulPortStatus) {
				/* ALL Effectively*/
				
				/* [ PORT1 Effectively ]*/
				if ((R_IN32_PORT_LINK_UP == ulLnkStatus_POne)
				 && (R_IN32_PORT_LINK_UP == ulLnkStatus_PTwo)) {
					/* OK(PORT1 OK, PORT2 OK) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_OK_PORT2_OK;
				}
				else if ((R_IN32_PORT_LINK_UP   == ulLnkStatus_POne)
					  && (R_IN32_PORT_LINK_DOWN == ulLnkStatus_PTwo)) {
					/* OK(PORT1 OK, PORT2 NG) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_OK_PORT2_NG;
				}
				else if ((R_IN32_PORT_LINK_DOWN == ulLnkStatus_POne)
					  && (R_IN32_PORT_LINK_UP   == ulLnkStatus_PTwo)) {
					/* OK(PORT1 NG, PORT2 OK) */
					pstRespData->stSW.usSW0064 = R_IN32_PORT1_NG_PORT2_OK;
				}
				else {
					/* NG(PORT1 NG, PORT2 NG) */
				}
			}
			else if (R_IN32_MYPORT_PORT_1 == ulPortStatus){
				/* OK(PORT1 Loop back, PORT2 NG) */
				pstRespData->stSW.usSW0064 = R_IN32_PORT1_LB_PORT2_NG;
			}
			else if (R_IN32_MYPORT_PORT_2 == ulPortStatus){
				/* OK(PORT1 NG, PORT2 Loop back) */
				pstRespData->stSW.usSW0064 = R_IN32_PORT1_NG_PORT2_LB;
			}
			else {
				/* [No handling] */
			}
		}

		/*[ MyLED information ]*/
		gR_IN32S_Memcpy((void*)&pstRespData->stLED,
					 (const void*)pvR_IN32TLedInfo,
					 (ULONG)(sizeof(R_IN32_SELECTINFO_LED_INFO_T)));

		/* Sender address */
		/* 1st, 2nd octet */
		usTemp = (USHORT)auchMyMACAddress[1];
		usTemp |= ((USHORT)auchMyMACAddress[0] << 8 );
		pstRespData->usFromAddress1 = usTemp;
		/* 3rd, 4th octet */
		usTemp = (USHORT)auchMyMACAddress[3];
		usTemp |= ((USHORT)auchMyMACAddress[2] << 8 );
		pstRespData->usFromAddress2 = usTemp;
		/* 5th, 6th octet */
		usTemp = (USHORT)auchMyMACAddress[5];
		usTemp |= ((USHORT)auchMyMACAddress[4] << 8 );
		pstRespData->usFromAddress3 = usTemp;

		/* Reserved */
		pstRespData->usRsv1 = (USHORT)0x0000;

		/*[ Vendor code ]*/
		pstRespData->usMakerCode = (USHORT)gulR_IN32U_UNIT_VENDOR_CODE;

		/*[ Unit model code ]*/
		pstRespData->ulModelCode = (USHORT)gulR_IN32U_UNIT_MODEL_CODE;

		/* Reserved */
		pstRespData->usRsv2 = (USHORT)0x0000;

		/* Reserved */
		pstRespData->auchRsv[0] = (UCHAR)0x00;
		pstRespData->auchRsv[1] = (UCHAR)0x00;
		pstRespData->auchRsv[2] = (UCHAR)0x00;
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		
		erRet = R_IN32_OK;
		
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pstSndFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Sender's MAC address */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}

/****************************************************************************/
/** @brief  Received Communication Test request frame processing            */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedContactTestRequest(
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**<  Received Transient1 data */
	const UCHAR* puchSA							/**< Sender's MAC address */
)
{
	const R_IN32_SLMP_REQUEST_DATA_T*		pstRcvData;				/* Request Data All */
	const R_IN32_CONTACTTEST_REQUEST_FRAME_T*	pstReqData;			/* SLMP Contact Test(Request) Frame format */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*		pstSndFrame;			/* Entire response Frame */
	R_IN32_CONTACTTEST_RESPONSE_FRAME_T*		pstRespData;		/* SLMP Cable Test(Response) Frame format */
	ULONG									ulDataSize;			/* Transient data size */
	USHORT									usNodeNumber;		/* Station No. */
	UCHAR									uchNetworkNumber;	/* network No. */
	USHORT									usCheckResult;		/* result */
	UCHAR									auchMyMACAddress[6];/* My MAC address */
	ERRCODE									erRet;				/* result value */
	
	
	
	pstRcvData = (const R_IN32_SLMP_REQUEST_DATA_T*)pvReceivedData;
	pstReqData = (const R_IN32_CONTACTTEST_REQUEST_FRAME_T*)&pstRcvData->auchDataArea[0];
	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;
	pstRespData = (R_IN32_CONTACTTEST_RESPONSE_FRAME_T*)&pstSndFrame->auchDataArea[0];

	/*[ Check destination network and Station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);

	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_NETWORK_COMMON,						/**< Data classification */
				(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame			/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = (ULONG)(sizeof(R_IN32_SLMP_RESPONSE_FRAME_T)	/* SLMP Response frame format */
					+ sizeof(USHORT)							/* Number of contact data */
					+ pstReqData->usContactNum);				/* Data size of Contact data */
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header(
				R_IN32_DSTYPE_SLMP,								/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
						sizeof(R_IN32_NONCICLIC_FRAME_T))			/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ SLMP Hedder information ]*/
		gerR_IN32T_TxFrame_CreateResponseSlmpHeader(
				&(pstRcvData->stExHead),									/**< Recieved request Transient2+SLMP header  */
				(USHORT)(ulDataSize-(sizeof(R_IN32_SLMP_RESPONSE_FRAME_T))),	/**< SLMP data size */
				&(pstSndFrame->stExHead)									/**< [out] ResponseSLMP Header*/
				);
		
		
		/*[ SLMP Response data information ]*/
		
		/*[ Number of contact data <- Number of contact data ]*/
		pstRespData->usContactNum = pstReqData->usContactNum;

		/*[ Set contact data(ALL 0) ]*/
		gR_IN32S_Memset((void*)&pstRespData->auchData[0],
					 (UCHAR)0x00,
					 (ULONG)(pstReqData->usContactNum));
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
		
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pstSndFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Sender's MAC address */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}

/****************************************************************************/
/** @brief  Received Cable Test request frame processing                    */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceivedCableTestRequest(
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**< Received Transient1 data */
	const UCHAR* puchSA							/**< Sender's MAC address */
)
{
	volatile LINKSTAT_REG_T*			pstLinkStat;			/* Operation PHY Link Register */
	R_IN32_CABLETEST_RESULT_T			stTestResult;				/* Test result */
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstRcvData;				/* Request Frame format */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*	pstSndFrame;				/* Entire response Frame */
	R_IN32_CABLETEST_RESPONSE_FRAME_T*	pstRespData;			/* SLMP Cable Test(Response) Frame format */
	ULONG								ulDataSize;				/* Transient data size */
	USHORT								usNodeNumber;			/* Station No. */
	UCHAR								uchNetworkNumber;		/* network No. */
	ULONG								ul32bitReg;				/* Register Value */
	USHORT								usCheckResult;			/* result */
	UCHAR								auchMyMACAddress[6];	/* My MAC address */
	ERRCODE								erRet;					/* result value */
	
	
	
	pstRcvData = (const R_IN32_SLMP_REQUEST_FRAME_T*)pvReceivedData;
	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;
	pstRespData = (R_IN32_CABLETEST_RESPONSE_FRAME_T*)&pstSndFrame->auchDataArea[0];
	
	/*[ Check destination network and Station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);
	
	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		
		/*[ Get station and network No. ]*/
		gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
		/*[ Get my MAC address ]*/
		gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
		
		/*[ CableTest execute ]*/
		
		/*[ Initialize Test result ]*/
		(VOID)gR_IN32S_Memset((void*)&stTestResult, (UCHAR)0x00, sizeof(stTestResult));
		
		/*[ Number of ports <- Number of ports in host station ]*/
		stTestResult.usPortNum = gulR_IN32U_MAX_PORT_NUMBER;

		/*[ Get PHY link inforamation register ]*/
		ul32bitReg  = RING->ulLinkStat;
		pstLinkStat = (LINKSTAT_REG_T*)&ul32bitReg;

		/*[ Check PORT1 Link Status ]*/
		if (R_IN32_PORT_LINK_DOWN == pstLinkStat->b01ZP1_0) {
			/*[ Port1 Test result <- Disconnect or No Connection ]*/
			stTestResult.ausPortResult[0] = R_IN32_CABLE_TEST_NG;
		}
		else {
			/*[ Port1 Test result <- Cable normal ]*/
			stTestResult.ausPortResult[0] = R_IN32_CABLE_TEST_OK;
		}

		if (R_IN32U_MIN_PORT_NUMBER < gulR_IN32U_MAX_PORT_NUMBER) {

			/*[ Check PORT2 Link Status ]*/
			if (R_IN32_PORT_LINK_DOWN == pstLinkStat->b01ZP2_0) {
				/*[ Port2 Test result <- Disconnect or No Connection ]*/
				stTestResult.ausPortResult[1] = R_IN32_CABLE_TEST_NG;
			}
			else {
				/*[ Port2 Test result <- Cable normal ]*/
				stTestResult.ausPortResult[1] = R_IN32_CABLE_TEST_OK;
			}
		}
		else {

			/*[ Initialize Port2 test result ]*/
			stTestResult.ausPortResult[1] = (UCHAR)0x00;
		}
		
		
		/*[ Create MAC and CCIE Header ]*/
		gerR_IN32T_TxFrame_CreateEtherCcieHeader (
				puchSA,											/**< Sending MAC address */
				auchMyMACAddress,								/**< My MAC address */
				R_IN32_FTYPE_TRANSIENT1,							/**< FrameClassification */
				R_IN32_DTYPE_NETWORK_COMMON,						/**< Data classification */
				(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame			/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		/* Create Transient data size (In transient1 Header */
		ulDataSize = sizeof(R_IN32_SLMP_RESPONSE_FRAME_T) + sizeof(R_IN32_CABLETEST_RESPONSE_FRAME_T);
		
		/*[ Create Transient1 Header ]*/
		gerR_IN32T_TxFrame_CreateTransient1Header(
				R_IN32_DSTYPE_SLMP,								/**< Sub data classification */
				ulDataSize,										/**< Transient1 data size */
				(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
						sizeof(R_IN32_NONCICLIC_FRAME_T))			/**< [out]  Prepare MAC+CCIE header address  */
				);
		
		
		/*[ Create Transient1 Data ]*/
		
		/*[ SLMP Hedder information ]*/
		gerR_IN32T_TxFrame_CreateResponseSlmpHeader(
				pstRcvData,										/**< Recieved request Transient2+SLMP header  */
				sizeof(R_IN32_CABLETEST_RESPONSE_FRAME_T),		/**< SLMP data size */
				&(pstSndFrame->stExHead)						/**< [out] ResponseSLMP Header*/
				);
		
		
		/*[ SLMP Response data information ]*/
		
		
		/*[ Port Result ]*/
		gR_IN32S_Memcpy((void*)&pstRespData->stResult,
					 (const void*)&stTestResult,
					 (ULONG)(sizeof(R_IN32_CABLETEST_RESULT_T)));
		
		/*[ Calculate send data size ]*/
		*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;
		
		erRet = R_IN32_OK;
		
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pstSndFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Sender's MAC address */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}



/****************************************************************************/
/** @brief  Received SLMP remote reset request frame processing             */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ReceiveRemoteResetRequest(
	VOID* pvSendFrame,					/**< [out] Sending Address */
	ULONG* pulDataSize,					/**< [out] Send Data Size */
	const VOID* pvReceivedData,			/**< Received Transient1 data */
	const UCHAR* puchSA					/**< Sender's MAC address */
)
{
	USHORT		usCheckResult;			/* result */
	ERRCODE		erRet;					/* result value */


	/*[ Check destination network and Station No. ]*/
	usCheckResult = gusR_IN32_ErrCheckReqSlmpReceived(pvReceivedData);

	/*[ Is check result normal? ]*/
	if (R_IN32_SLMP_FINCODE_OK == usCheckResult) {
		
		erRet = R_IN32_OK;
		
	}
	else{
		gR_IN32_SetSlmpError_Response ( 
			pvSendFrame,										/**< [out] Sending Address */
			pulDataSize,										/**< [out] Send Data Size */
			pvReceivedData,										/**< Sender's MAC address */
			puchSA,												/**< Sender's MAC address */
			usCheckResult										/**< End Code */
		);
		
		erRet = R_IN32_ERR;
		
	}
	
	return erRet;
}


/****************************************************************************/
/** @brief  Create SLMP error response frame processing                     */
/** @retval VOID                                                            */
/****************************************************************************/
VOID gR_IN32_SetSlmpError_Response( 
	VOID* pvSendFrame,							/**< [out] Sending Address */
	ULONG* pulDataSize,							/**< [out] Send Data Size */
	const VOID* pvReceivedData,					/**< Received Transient1 data */
	const UCHAR* puchSA,						/**< Sender's MAC address */
	USHORT usFinCode							/**< End Code */
)
{
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstRcvData;			/* ### data */
	R_IN32_SLMP_RESPONSE_FRAME_ALL_T*	pstSndFrame;			/* ### */
	R_IN32_SLMP_ERROR_RESPONSE_FRAME_T*	pstRespData;		/* ### */
	ULONG								ulDataSize;			/* Transient data size */
	USHORT								usNodeNumber;		/* Station No. */
	UCHAR								uchNetworkNumber;	/* network No. */
	UCHAR								auchMyMACAddress[6];/* My MAC address */


	pstRcvData = (const R_IN32_SLMP_REQUEST_FRAME_T*)pvReceivedData;
	pstSndFrame = (R_IN32_SLMP_RESPONSE_FRAME_ALL_T*)pvSendFrame;
	pstRespData = (R_IN32_SLMP_ERROR_RESPONSE_FRAME_T*)&pstSndFrame->auchDataArea[0];


	/*[ Get station and network No. ]*/
	gerR_IN32_GetNodeAndNetworkNumber( &usNodeNumber, &uchNetworkNumber );
		
	/*[ Get my MAC address ]*/
	gerR_IN32C_GetMyMACAddress( auchMyMACAddress );
	
	/*[ Create MAC and CCIE Header ]*/
	gerR_IN32T_TxFrame_CreateEtherCcieHeader (
			puchSA,												/**< Sending MAC address */
			auchMyMACAddress,									/**< My MAC address */
			R_IN32_FTYPE_TRANSIENT1,								/**< FrameClassification */
			R_IN32_DTYPE_NETWORK_COMMON,							/**< Data classification */
			(R_IN32_NONCICLIC_FRAME_T*)pstSndFrame				/**< [out]  Prepare MAC+CCIE header address  */
			);
	
	
	/* Create Transient data size (In transient1 Header */
	ulDataSize = sizeof(R_IN32_SLMP_RESPONSE_FRAME_T) + sizeof(R_IN32_SLMP_ERROR_RESPONSE_FRAME_T);
	
	/*[ Create Transient1 Header ]*/
	gerR_IN32T_TxFrame_CreateTransient1Header(
			R_IN32_DSTYPE_SLMP,									/**< Sub data classification */
			ulDataSize,											/**< Transient1 data size */
			(R_IN32_TRAN1_HEAD_T*)((UCHAR*)pstSndFrame +
					sizeof(R_IN32_NONCICLIC_FRAME_T))				/**< [out]  Prepare MAC+CCIE header address  */
			);
	
	/*[ Create Transient1 Data ]*/
	
	/*[ SLMP Hedder information ]*/
	gerR_IN32T_TxFrame_CreateResponseSlmpHeader(
			pstRcvData,											/**< Recieved request Transient2+SLMP header  */
			sizeof(R_IN32_SLMP_ERROR_RESPONSE_FRAME_T),			/**< SLMP data size */
			&(pstSndFrame->stExHead)							/**< [out] ResponseSLMP Header*/
			);
	
	/*[ Set End code from argument ]*/
	pstSndFrame->stExHead.usFinCode = usFinCode;
	
	
	/*[ Prepare SLMP frame data ]*/

	/*[ Request destination network No. <- network No. ]*/
	pstRespData->uchNetWorkNo = uchNetworkNumber;

	/*[ Request destination station number <- station number ]*/
	pstRespData->uchPcNo = usNodeNumber;

	/*[ Request destination module I/O number <- SLMP unit I/O number ]*/
	pstRespData->usRespUtIONo = R_IN32_DEFAULT_UNIT_IO_NO;

	/*[ Request destination multi drop number <- for 0]*/
	pstRespData->uchRequStNo = (USHORT)0x0000;

	/*[ Field specific command type ]*/
	pstRespData->usCmd = pstRcvData->usCommand;

	/*[ Sub-command type]*/
	pstRespData->usSubCmd = pstRcvData->usSubCommand;

	/*[ Calculate send data size ]*/
	*pulDataSize = sizeof(R_IN32_NONCICLIC_FRAME_T) + sizeof(R_IN32_TRAN1_HEAD_T) + ulDataSize;

}

/****************************************************************************/
/** @brief  Check error in received CC-Link IE Field transient request frame*/
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
ERRCODE gerR_IN32_ErrCheckReqFieldNetworkReceived(const VOID* pvReceivedData)		/**< Received Transient1 data */
{
	ERRCODE								erCheckResult;			/* result */
	const R_IN32_EXTENSION_HEAD_DATA_T*	pstData;				/* Received Transient1 data */
	USHORT								usDestNodeNumber;		/* destination Station No. */
	USHORT								usMyNodeNumber;			/* host Station No. */
	UCHAR								uchDestNetNumber;		/* destination network No. */
	UCHAR								uchMyNetNumber;			/* host network No. */
	
	
	
	erCheckResult = R_IN32_OK;

	pstData = (const R_IN32_EXTENSION_HEAD_DATA_T*)pvReceivedData;

	/*[ Get station and network No. of this node ]*/
	gerR_IN32_GetNodeAndNetworkNumber( &usMyNodeNumber, &uchMyNetNumber );

	/*[ Check destination network No. ]*/
	uchDestNetNumber = pstData->stOPHEAD.uchDestNetNumber;
	if (uchDestNetNumber == uchMyNetNumber) {
	}
	else {
		/* Set result to error */
		erCheckResult = R_IN32_ERR;
	}

	/*[ Check destination Station No. ]*/
	usDestNodeNumber = gusR_IN32S_SwapS( pstData->stOPHEAD.usDestNodeNumber );
	if (usDestNodeNumber == usMyNodeNumber) {
	}
	else {
		/* Set result to error */
		erCheckResult = R_IN32_ERR;
	}
	
	return erCheckResult;
}


/****************************************************************************/
/** @brief  Check error in received SLMP request frame                      */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end(Argument error)                           */
/****************************************************************************/
USHORT gusR_IN32_ErrCheckReqSlmpReceived(const VOID* pvReceivedData)		/**< Received Transient1 data */
{
	const R_IN32_SLMP_REQUEST_FRAME_T*	pstData;				/* Received Transient2 header and SLMP header information */
	USHORT								usDestNodeNumber;		/* destination Station No. */
	USHORT								usMyNodeNumber;			/* host Station No. */
	USHORT								usCheckResult;			/* result */
	UCHAR								uchDestNetNumber;		/* destination network No. */
	UCHAR								uchMyNetNumber;			/* host network No. */
	
	
	usCheckResult = R_IN32_SLMP_FINCODE_OK;

	pstData = (const R_IN32_SLMP_REQUEST_FRAME_T*)pvReceivedData;

	/*[ Get Station No. and network No. of this node ]*/
	(VOID)gerR_IN32_GetNodeAndNetworkNumber( &usMyNodeNumber, &uchMyNetNumber );

	/*[ Check destination network No. ]*/
	uchDestNetNumber = pstData->stCCLinkHead.uchDNA;
	if (uchDestNetNumber == uchMyNetNumber) {
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_NETWORK_NO_NG;
	}

	/*[ Check destination Station No. ]*/
	usDestNodeNumber = (USHORT)(pstData->stCCLinkHead.uchDS);
	if (usDestNodeNumber == usMyNodeNumber) {
	}
	else {
		/* Set result to error */
		usCheckResult |= R_IN32_SLMP_FINCODE_NODE_NO_NG;
	}

	
	return usCheckResult;
}


/************************************************************************************/
/** @brief  Sets node information distribution data (MAC address table)             */
/** @retval R_IN32_OK            :Normal end                                          */
/** @retval R_IN32_ERR_OUTOFRANGE:Abnormal end (station/sequential No.is out of range)*/
/************************************************************************************/
ERRCODE gerR_IN32_SetMACAddressTableData(
	UCHAR uchSeqNumber,						/**< Distribution sequential number */
	R_IN32_MACADDRESSDATA_T* pstMacAddrDat	/**< MAC address table distribution data */
)
{
	R_IN32C_MACADDRDAT_T stMacAddrDat;		/**< MAC address, etc. information */
	ERRCODE erRet;

	stMacAddrDat.usStationNumber = pstMacAddrDat->usNodeNumber;

	if ( R_IN32_ENABLE == pstMacAddrDat->uchTransientReceiveEnable ) {
		stMacAddrDat.uchTransientRecvMode = (UCHAR)R_IN32_ON;
	}
	else {
		stMacAddrDat.uchTransientRecvMode = (UCHAR)R_IN32_OFF;
	}

	gR_IN32S_Memcpy(&stMacAddrDat.auchMacAddress[0], &pstMacAddrDat->auchMacAddress[0], R_IN32_MACADR_SZ);

	erRet = gerR_IN32C_SetMACAddrTblDat(uchSeqNumber, &stMacAddrDat);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR_OUTOFRANGE;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Get the unit information                                        */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_GetUnitInformation(
	R_IN32_UNITINFO_T*           pstUnitInfo,					/**< [out] unit information */
	R_IN32_UNITNETWORKSETTING_T* pstUnitNetworkSetting		/**< [out] network setting  */
)
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32C_GetUnitInfo1(pstUnitInfo, pstUnitNetworkSetting);

	return erRet;
}



/****************************************************************************/
/** @brief  Get node ID                                                     */
/** @retval Node ID                                                         */
/****************************************************************************/
USHORT  gusR_IN32_GetNodeID( VOID )
{
	return gusR_IN32C_GetNodeID();
}



/***************************************************************************************/
/** @brief  Get multicast MAC address                                                  */
/** @retval R_IN32_OK :Normal end                                                        */
/** @retval R_IN32_ERR:Abnormal end                                                      */
/**                  (due to disconnection, multicast MAC address couldn't be obtained)*/
/***************************************************************************************/
ERRCODE gerR_IN32_GetMulticastMACAddress(
	UCHAR* puchMACAddr						/**< [out] Multicast MAC address */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_GetMulticastMACAddress( puchMACAddr );

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Get unicast MAC address                                         */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR_NOENTRY:No entry                                       */
/** @retval R_IN32_ERR_OUTOFRANGE:Station No. is out of range                 */
/****************************************************************************/
ERRCODE gerR_IN32_GetUnicastMACAddress(
	USHORT usNodeNumber,					/**< Station No. */
	UCHAR* puchMACAddr						/**< [out] Unicast MAC address */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_GetUnicastMACAddr(usNodeNumber, puchMACAddr);

	if ( R_IN32C_NG_NOENTRY == erRet ){
		erRet = R_IN32_ERR_NOENTRY;
	}
	else if ( R_IN32C_NG_OUTOFRANGE == erRet ){
		erRet = R_IN32_ERR_OUTOFRANGE;
	}
	else {
		erRet = R_IN32_OK;
	}

	return erRet;
}



/*******************************************************************************/
/** @brief  Get buffer for sending transient frame                             */
/** @retval R_IN32_OK :Normal end                                                */
/** @retval R_IN32_ERR:Abnormal end (transient send buffer could not be obtained)*/
/*******************************************************************************/
ERRCODE gerR_IN32_GetSendTransientBuffer(
	USHORT usSize,							/**< Send data size (DCS/FCS not included) */
	VOID** ppvSendBuffAddr,					/**< [out] Transient send buffer address   */
	UCHAR* puchSendBuffNo,					/**< [out] Transient send buffer number    */
	UCHAR* puchConnectionInfo				/**< [out] Connection information          */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_GetTDIS(usSize, ppvSendBuffAddr, puchSendBuffNo, puchConnectionInfo);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}


/****************************************************************************/
/** @brief  Request to send the transient frame                             */
/** @retval R_IN32_OK:Normal end                                              */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE gerR_IN32_RequestSendingTransient(
	UCHAR  uchSendBuffNo,					/**< transient send buffer number          */
	USHORT usSize							/**< send data size (DCS/FCS not included) */
)
{
	ERRCODE erRet;

	erRet = gerR_IN32C_EntryTDIS(uchSendBuffNo, usSize);

	if ( R_IN32C_OK == erRet ) {
		erRet = R_IN32_OK;
	}
	else {
		erRet = R_IN32_ERR;
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Main handling for sending transient frame                       */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_MainSendTransient( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	erR_IN32C_SeqMain_SndFinish();

	return erRet;
}

/****************************************************************************/
/** @brief  Enable interrupt                                                */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_EnableInterrupt( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gR_IN32R_ExEnableInt();

	return erRet;
}



/****************************************************************************/
/** @brief  Disable interrupt                                               */
/** @retval R_IN32_OK :Normal end                                             */
/****************************************************************************/
ERRCODE gerR_IN32_DisableInterrupt( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gR_IN32R_ExDisableInt();

	return erRet;
}



/****************************************************************************/
/** @brief  IEEE 802.3ab compliance test                                    */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE gerR_IN32_IEEETest(
	USHORT usMode							/**< IEEE802.3ab compliance test mode */
											/**<  R_IN32_IEEE_MODE1(1) :MODE1 */
											/**<  R_IN32_IEEE_MODE2(2) :MODE2 */
											/**<  R_IN32_IEEE_MODE3(3) :MODE3 */
											/**<  R_IN32_IEEE_MODE4(4) :MODE4 */
)
{
	static const USHORT ausModeTbl[] = {
							R_IN32R_IEEE_MODE1,
							R_IN32R_IEEE_MODE2,
							R_IN32R_IEEE_MODE3,
							R_IN32R_IEEE_MODE4,
							R_IN32R_IEEE_END
						};

	ERRCODE erRet;

	erRet = gerR_IN32R_IEEETest(ausModeTbl[usMode]);

	if ( R_IN32_OK != erRet ) {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
	}
	else {
	}

	return erRet;
}



/****************************************************************************/
/** @brief  Initialization for loop back test                               */
/** @retval R_IN32_OK :Normal end                                             */
/** @retval R_IN32_ERR:Abnormal end                                           */
/****************************************************************************/
ERRCODE gerR_IN32_InitializeLoopBackTest( VOID )
{
	ERRCODE erRet;

	erRet = gerR_IN32T_CommunicationInit();

	if ( R_IN32_OK != erRet ) {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
	}
	else {
	}

	return erRet;
}





/****************************************************************************/
/** @brief  Loop back test                                                   */
/** @retval R_IN32_OK :Normal end                                              */
/** @retval R_IN32_ERR:Abnormal end                                            */
/****************************************************************************/
ERRCODE gerR_IN32_ExternalLoopBackTest(
	ULONG ulPort							/**< port number */
)
{
	R_IN32T_PORT_SEL_ENUM eTestPort;
	ERRCODE erRet;


	if (R_IN32_PORT1 == ulPort) {
		eTestPort = R_IN32T_E_PORT1;
	}
	else {
		eTestPort = R_IN32T_E_PORT2;
	}

	erRet = gerR_IN32T_OutsideLoopBackTest(eTestPort);

	if ( R_IN32_OK != erRet ) {
		erR_IN32C_SeqMain_R_IN32DFatalErrorToCPU();
	}
	else {
	}

	return erRet;
}




/****************************************************************************/
/** @brief  Process when My station receives Token frame                    */
/** @retval R_IN32_OK                                                         */
/****************************************************************************/
ERRCODE gerR_IN32_MyStaRcvTkn( VOID )
{
	ERRCODE erRet = R_IN32_OK;

	gerR_IN32D_MyStaRcvTkn();

	return erRet;
}

/*** EOF ***/
