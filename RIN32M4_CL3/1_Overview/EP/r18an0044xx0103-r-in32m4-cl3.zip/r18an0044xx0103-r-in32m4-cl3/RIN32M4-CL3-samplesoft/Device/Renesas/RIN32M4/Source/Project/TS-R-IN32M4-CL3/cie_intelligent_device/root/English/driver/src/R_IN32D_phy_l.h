/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_phy_l.h                                                   */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_PHY_L_H_INCLUDED__
#define __R_IN32D_PHY_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define	R_IN32D_PHYADRS_PORT1			0x1UL	
#define	R_IN32D_PHYADRS_PORT2			0x0UL	


#define	R_IN32D_BIT_MACIP1_MCMD_ON		MCMD_REG_MDIO_ON						
#define	R_IN32D_BIT_MACIP1_MCMD_WRITE	MCMD_REG_MDIO_ON						
#define	R_IN32D_BIT_MACIP1_MCMD_READ	(MCMD_REG_RW_READ|MCMD_REG_MDIO_ON)		


/****************************************************************************/
/* Functions (for R_IN32D)                                                     */
/****************************************************************************/
extern ERRCODE erR_IN32D_MDIO_WaitCommandComplete( VOID );

#endif	/* __R_IN32D_PHY_L_H_INCLUDED__ */

/*** EOF ***/
