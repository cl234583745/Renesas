/**
 *******************************************************************************
 * @file  sromc.h
 * @brief Serial Flash ROM Controller control header for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef SROMC_H__
#define SROMC_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/

#include "RIN32M4.h"


/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/


/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/

void sromc_init(void);
void sromc_dual_init(void);
void sromc_quad_init(void);
void sromc_write(uint8_t data, uint32_t first, uint32_t last);
void sromc_read(uint8_t* data, uint32_t first, uint32_t last);


#endif // SROMC_H__
