/**
 *******************************************************************************
 * @file  ethsw.h
 * @brief Ethernet swtich driver program
 * 
 * @note 
 * Copyright (C) 2012 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	ETHSW_H__
#define	ETHSW_H__

/*==========================================================================*/
/* I N C L U D E															*/
/*==========================================================================*/
#include "RIN32M4.h"

/*==========================================================================*/
/* T Y P E D E F															*/
/*==========================================================================*/

/*==========================================================================*/
/* D E F I N E																*/
/*==========================================================================*/
#define LRN_TSK_SLP				100			//Sleep time of the learning task(ms)
#define LRN_CHK_CNT				10			//Continuous learning count

#define FFW_ENA					0x1			//Forced Forwarding function Enable
#define FFW_PORT0_ENA			0x2			//Forced Forwarding port0 Enable
#define FFW_PORT1_ENA			0x4			//Forced Forwarding port1 Enable
#define FFW_NON					0x0			//Forced Forwarding Disable
#define FFW_PORT0				(FFW_ENA | FFW_PORT0_ENA)
#define FFW_PORT1				(FFW_ENA | FFW_PORT1_ENA)
#define FFW_ALL					(FFW_ENA | FFW_PORT0_ENA | FFW_PORT1_ENA)

/*==========================================================================*/
/* P R O T O T Y P E                                                        */
/*==========================================================================*/
void ethsw_init( uint8_t *mac );
void ethsw_mac_learning_tsk(int exinf);
void ethsw_add_maclut(uint8_t *mac , uint8_t port);
void ethsw_add_maclut_static(uint8_t *mac , uint8_t port);

#endif // ETHSW_H__
