/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_TxFrame.h                                                 */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef	__TXFRAME_H_INCLUDED__
#define	__TXFRAME_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"
#include "R_IN32M4Types.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define	R_IN32T_TXF_TRAN_DIVLAST				(UCHAR)0x80			


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/
typedef struct _R_IN32T_TRAN1_FRM_MAKE_TAG {
	const UCHAR*	puchDesMACAddr;								
	const UCHAR*	puchSouMACAddr;								
	UCHAR			uchDataType;								
	UCHAR			uchReserved0;
	USHORT			usNodeID;									
	UCHAR			uchConnect;									
	UCHAR			uchReserved1;
	USHORT			usStNo;										
	UCHAR			uchSeqNo;									
	UCHAR			uchIdentNo;									
	USHORT			usTrnDatAllSize;							
	ULONG			ulOffsetAdr;								
	USHORT			usTrnDatSize;								
	USHORT			usDataSubType;								
} R_IN32T_TRAN1_FRM_MAKE_T;

/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern VOID    R_IN32T_TxFrame_Tran1Head_Make( const R_IN32T_TRAN1_FRM_MAKE_T*, USHORT );
extern ERRCODE erR_IN32T_TxFrame_TxTran_1Frame( USHORT, USHORT, USHORT );

#endif	/* __TXFRAME_H_INCLUDED__ */

/*** EOF ***/
