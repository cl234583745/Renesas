/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_cyc.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32C_l.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_RcvPrm_l.h"
#include "R_IN32D_cyc_l.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_CYCLIC_STA_CYCLIC_ENABLE				CYCLIC_STA_PARAMENDRECV		


ERRCODE gerR_IN32D_SetMyStatus(
	R_IN32D_CYCLIC_STA_SET_T*			pstCycilcDisable,	
	R_IN32D_SELF_STA_SET_T*			pstSelfSta,			
	R_IN32D_SLVEVENT_SET_T*			pstSlaveEvent,		
	R_IN32D_MACDELIV_RESULT_SET_T*		pstMacDelivResult,	
	ULONG							ulErrCode,			
	ULONG							ulUserInformation	
)
{
	ERRCODE		erResult;		
	ULONG		ulRegData;		

	if ( R_IN32_OFF == TX->ulMSTS_SWITCH_FLG ) {

		gR_IN32R_ExDisableInt();

		OUT32(&(TX->SELF_CONTROL_3), (ulUserInformation & 0x0000FFFF));
		OUT32(&(TX->SELF_CONTROL_4), ((ulUserInformation & 0xFFFF0000) >> 16));

		TX->SELF_STA2_L.DATA = (ulErrCode & 0x0000FFFF);
		TX->SELF_STA2_H.DATA = (ulErrCode & 0xFFFF0000) >> 16;

		if ( R_IN32_NULL != (VOID*)pstCycilcDisable ) {

			ulRegData = IN32(&TX->CYCLIC_STA);

			if ( R_IN32D_CYCSTATUS_STATION_MISSMATCH == ( R_IN32D_CYCSTATUS_STATION_MISSMATCH & pstCycilcDisable->uniCycStaSet.usAll )) {
				ulRegData |= CYCLIC_STA_NETWORKNOWRONG;
			}
			else {
				ulRegData &= ~((ULONG)CYCLIC_STA_NETWORKNOWRONG);
			}

			if ( R_IN32D_CYCSTATUS_DLINKSTATE == ( R_IN32D_CYCSTATUS_DLINKSTATE & pstCycilcDisable->uniCycStaSet.usAll )) {
				ulRegData |= CYCLIC_STA_DLINKSTATE;
			}
			else {
				ulRegData &= ~((ULONG)CYCLIC_STA_DLINKSTATE);
			}

			if ( R_IN32D_CYCSTATUS_CYCLICSTATE == ( R_IN32D_CYCSTATUS_CYCLICSTATE & pstCycilcDisable->uniCycStaSet.usAll )) {
				ulRegData |= CYCLIC_STA_INITORWAIT;
			}
			else {
				ulRegData &= ~((ULONG)CYCLIC_STA_INITORWAIT);
			}


			OUT32( &TX->CYCLIC_STA, ulRegData );
			gerR_IN32D_UpdateCyclicPermission();
		}
		else {
		}

		if ( R_IN32_NULL != (VOID*)pstSelfSta ) {

				ULONG *dummy;

				dummy = (ULONG *)&TX->SELF_STA;

				*dummy = (*dummy & 0xFFFFFFFC);
				*dummy |= pstSelfSta->ulCPURunCond;

				*dummy = (*dummy & 0xFFFFFFF3);
				*dummy |= (pstSelfSta->ulCPUErrFoundCond << 2);

				*dummy = (*dummy & 0xFFFFFFEF);
				*dummy |= (pstSelfSta->ulCPUSync << 4);

		}
		else {
		}

		if ( R_IN32_NULL != (VOID*)pstSlaveEvent ) {

			OUT32(&(TX->SELF_CONTROL_1), pstSlaveEvent->ulSlaveEventInformation);
			OUT32(&(TX->SELF_CONTROL_2), pstSlaveEvent->ulSlaveEventNumber);
		}
		else {
		}


		{
				ULONG *dummy;

				dummy = (ULONG *)&TX->SELF_STA;

				*dummy = (*dummy & 0xFFFFBFFF);

				if ( R_IN32_ON == RX->ulRDISENDIS ) {	
					*dummy = (*dummy | (R_IN32_ON << 14));
				}
				else {														
					*dummy = (*dummy | (R_IN32_OFF << 14));
				}
		}
                gR_IN32R_ExEnableInt();
		

		erResult = R_IN32D_OK;					
	}

	else {
		erResult = R_IN32D_BUSY;				
	}

	return( erResult );
}

ERRCODE gerR_IN32D_GetCyclicStopFactor(
	R_IN32D_CYCLIC_STA_GET_T*		pstDisableFact		
)
{
	CYCLIC_STA_T		stCycSta;
	volatile ULONG*		pulTemp;

	pulTemp = (ULONG*)&stCycSta;
	*pulTemp = IN32(&(TX->CYCLIC_STA));

	pstDisableFact->uniCycSta.usAll	= *pulTemp;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetRcvCyclic(
	VOID*					pRyDst,				
	VOID*					pRWwDst,			
	R_IN32D_CYCLIC_STA_GET_T*	pstDisableFact,		
	BOOL					blEnable			
)
{
	ERRCODE		erResult;


	erResult = R_IN32D_NODATA;

	(VOID)gerR_IN32D_GetCyclicStopFactor( pstDisableFact );

	if ( (R_IN32D_CYCLIC_STA_CYCLIC_ENABLE != pstDisableFact->uniCycSta.usAll) || (R_IN32_FALSE == blEnable) ) {
		RX->ulCYCFLG_A = R_IN32_ON;
		RX->ulCYCFLG_B = R_IN32_ON;

		return( R_IN32D_NODATA );		
	}
	else {
	}

	if(R_IN32C_MOTSYNC_WAIT != gstR_IN32C.stMotSyncCtl.ulSyncStatus){
	if( R_IN32_OFF == RX->RX_BANK_STS.b01ZCycRevBufferBankState ){
		if(R_IN32_ON == RX->ulCYCFLG_A) {
			gR_IN32S_Memcpy(pRyDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRY_A[0], gstR_IN32D_RefreshSize.ulRyByteSize );

			gR_IN32S_Memcpy(pRWwDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRWw_A[0], gstR_IN32D_RefreshSize.ulRWwByteSize );

			RX->ulCYCFLGCLR_F = CYCFLGCLR_CYCLICAFLGCLR;

			erResult = R_IN32D_OK;					
		}
	}
	else {
		if(R_IN32_ON == RX->ulCYCFLG_B) {
			gR_IN32S_Memcpy(pRyDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRY_B[0], gstR_IN32D_RefreshSize.ulRyByteSize );

			gR_IN32S_Memcpy(pRWwDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRWw_B[0], gstR_IN32D_RefreshSize.ulRWwByteSize );

			RX->ulCYCFLGCLR_F = CYCFLGCLR_CYCLICBFLGCLR;

			erResult = R_IN32D_OK;					
			}
		}
	}
	else{
		if( R_IN32_OFF != RX->RX_BANK_STS.b01ZCycRevBufferBankState ){
			if(R_IN32_ON == RX->ulCYCFLG_A) {
				gR_IN32S_Memcpy(pRyDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRY_A[0], gstR_IN32D_RefreshSize.ulRyByteSize );

				gR_IN32S_Memcpy(pRWwDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRWw_A[0], gstR_IN32D_RefreshSize.ulRWwByteSize );

				RX->ulCYCFLGCLR_F = CYCFLGCLR_CYCLICAFLGCLR;

				erResult = R_IN32D_OK;
			}
		}
		else{
			if(R_IN32_ON == RX->ulCYCFLG_B) {
				gR_IN32S_Memcpy(pRyDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRY_B[0], gstR_IN32D_RefreshSize.ulRyByteSize );

				gR_IN32S_Memcpy(pRWwDst, (VOID*)&CYCMAP->auchCyclicRcvRAMRWw_B[0], gstR_IN32D_RefreshSize.ulRWwByteSize );

				RX->ulCYCFLGCLR_F = CYCFLGCLR_CYCLICBFLGCLR;

				erResult = R_IN32D_OK;
			}
		}
	}


	return( erResult );
}

ERRCODE gerR_IN32D_SetSndCyclic(
	const VOID*		pRxSrc,		
	const VOID*		pRWrSrc		
)
{
	ERRCODE		erResult;

	if(0 == (TX->ulTX_TURN & TX_TURN_DATASET)) {
		if(0 != (TX->ulR_TXST & TX_TURN_DATASET)) {

			gR_IN32S_Memcpy((VOID*)&CYCMAP->auchCyclicSndRAMRX_A[0], pRxSrc, gstR_IN32D_RefreshSize.ulRxByteSize);

			gR_IN32S_Memcpy((VOID*)&CYCMAP->auchCyclicSndRAMRWr_A[0], pRWrSrc, gstR_IN32D_RefreshSize.ulRWrByteSize);
		}
		else {

			gR_IN32S_Memcpy((VOID*)&CYCMAP->auchCyclicSndRAMRX_B[0], pRxSrc, gstR_IN32D_RefreshSize.ulRxByteSize);

			gR_IN32S_Memcpy((VOID*)&CYCMAP->auchCyclicSndRAMRWr_B[0], pRWrSrc, gstR_IN32D_RefreshSize.ulRWrByteSize);
		}
		TX->ulTX_TURN = TX_TURN_DATASET;

		erResult = R_IN32D_OK;					
	}
	else {
		erResult = R_IN32D_BUSY;				
	}

	return( erResult );

}

ERRCODE gerR_IN32D_MyStaRcvTkn( VOID)
{
	ERRCODE erRet;
	
	ULONG		ulTemp;							
	R_TXSTART_TAG	stTXSTART;					
	
	erRet = R_IN32_OK;
	
	ulTemp = RX->NSRINT.DATA;
	ulTemp &= (ULONG)( NSRINT_MYSTARCVTKNFRMINT ); 
	
	if( NSRINT_MYSTARCVTKNFRMINT  == ulTemp ){
		TX->ulMSTS_SWITCH_FLG = (ULONG) R_IN32_ON;
		
		RX->NSRINT.DATA = ulTemp;
		
		if( TXCNT_SND_START_TYPE_FWREGWRITE == TX->TXCNT.b02ZSndStartType ){
			
			gR_IN32S_Memset((void*)&stTXSTART, 0x00, sizeof(stTXSTART));
			
			OUT32(&stTXSTART, IN32(&(TX->R_TXSTART)));
			stTXSTART.b01ZSendStart = MACTXST_SENDSTART;
			OUT32(&(TX->R_TXSTART),*(ULONG*)&stTXSTART); 
		}
		else {
		}
	}
	else {
	}
	
	return erRet;
}

/*** EOF ***/
