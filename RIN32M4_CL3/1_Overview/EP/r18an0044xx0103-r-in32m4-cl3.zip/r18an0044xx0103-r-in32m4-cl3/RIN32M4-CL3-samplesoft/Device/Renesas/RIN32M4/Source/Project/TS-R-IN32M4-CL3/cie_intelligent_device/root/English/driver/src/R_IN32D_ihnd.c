/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_ihnd.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_intr_l.h"
#include "R_IN32D_RcvCnt_l.h"
#include "R_IN32D_RcvPrm_l.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
ULONG	gulR_IN32D_HealthCheckCount = 0UL;				
ULONG	gulR_IN32D_DisconnectFactor = R_IN32_DISCONNECTFACTOR_NOFACTOR;


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE erR_IN32D_IntrINT1( R_IN32D_INTR_SOURCE_T* );
static ERRCODE erR_IN32D_IntrINT2( R_IN32D_INTR_SOURCE_T* );
static ERRCODE erR_IN32D_SetLoopIntMask( R_IN32D_INTR_SOURCE_T* );


ERRCODE	gerR_IN32D_IntrINT1_2(
	R_IN32_EVTPRM_INTERRUPT_T* pstEvent				
)
{
	R_IN32D_INTR_SOURCE_T			stIntrSource;	
	ULONG						ulRingPhase;	
	ULONG						ulCount;


	static const ULONG	aulITRCV[][2] = {			
				{ITRCV_NONCYCLICRECVINT,			R_IN32C_EVTPRM_RECVNONCYCLIC},		
				{ITRCV_MASTERWATCHTIMERTIMEOUTINT,	R_IN32C_EVTPRM_MASTERWATCHTIMEOUT}		
			};
	static const ULONG	aulTX_INTL[][2] = {			
				{INTL_NONCYCLICSNDENDINT,			R_IN32C_EVTPRM_SENDFINNONCYCLIC},		
			};

	static const ULONG	aulINT2[][2] = {			
				{INT2_REG_PERSUASION_REC,			R_IN32C_EVTPRM_DISCONNECT},			
				{INT2_REG_SETUP_REC_ACK,			R_IN32C_EVTPRM_COMMCONNECT},			
				{INT2_REG_LEAVE_TIMEOUT,			R_IN32C_EVTPRM_DISCONNECT}				
			};


	pstEvent->uniFlag.ulAll = 0UL;

	(VOID)erR_IN32D_FetchINT1_2(&stIntrSource);						
	(VOID)erR_IN32D_ClearINT1_2(&stIntrSource);						

	if ( R_IN32_FALSE == gstR_IN32U.blTransientReceiveEnable ) {

	}
	else {
	}

	(VOID)erR_IN32D_SetLoopIntMask( &stIntrSource );

	(VOID)erR_IN32D_IntrINT1( &stIntrSource );

	(VOID)erR_IN32D_IntrINT2( &stIntrSource );


	for ( ulCount = 0UL; ulCount < (sizeof(aulITRCV) / sizeof(aulITRCV[0])); ulCount++) {
		if ( ((ULONG)stIntrSource.uniITRCV.ulAll & aulITRCV[ulCount][0]) == aulITRCV[ulCount][0] ) {
			pstEvent->uniFlag.ulAll |= aulITRCV[ulCount][1];
		}
		else {
		}
	}

	for ( ulCount = 0UL; ulCount < (sizeof(aulTX_INTL) / sizeof(aulTX_INTL[0])); ulCount++) {
		if ( ((ULONG)stIntrSource.uniTX_INTL.ulAll & aulTX_INTL[ulCount][0]) == aulTX_INTL[ulCount][0] ) {
			pstEvent->uniFlag.ulAll |= aulTX_INTL[ulCount][1];
		}
		else {
		}
	}

	for ( ulCount = 0UL; ulCount < (sizeof(aulINT2) / sizeof(aulINT2[0])); ulCount++) {
		if ( ((ULONG)stIntrSource.uniINT2.ulAll & aulINT2[ulCount][0]) == aulINT2[ulCount][0] ) {
			pstEvent->uniFlag.ulAll |= aulINT2[ulCount][1];

			if(INT2_REG_PERSUASION_REC == aulINT2[ulCount][0] ) {
				gerR_IN32D_SetDisconnectFactor(R_IN32_DISCONNECTFACTOR_PERSUASION);
			}
		}
		else {
		}
	}

	if ( (R_IN32C_EVTPRM_COMMCONNECT | R_IN32C_EVTPRM_DISCONNECT) ==
			(pstEvent->uniFlag.ulAll & (R_IN32C_EVTPRM_COMMCONNECT | R_IN32C_EVTPRM_DISCONNECT)) ) {

		pstEvent->uniFlag.ulAll &= ~(R_IN32C_EVTPRM_COMMCONNECT | R_IN32C_EVTPRM_DISCONNECT);

		ulRingPhase = RING->ulRingPhase;
		if ( (ulRingPhase == RINGPHASE_REG_PHASE_SOLISITTOKEN)
				|| (ulRingPhase == RINGPHASE_REG_PHASE_HOLDTOKEN)) {	

			pstEvent->uniFlag.ulAll |= R_IN32C_EVTPRM_COMMDISCONNECTTOCONNECT;
		}
		else {															
			pstEvent->uniFlag.ulAll |= R_IN32C_EVTPRM_COMMCONNECTTODISCONNECT;
		}
	}

	if ( R_IN32C_EVTPRM_COMMCONNECT == (pstEvent->uniFlag.ulAll & R_IN32C_EVTPRM_COMMCONNECT) ) {

		ulRingPhase = RING->ulRingPhase;
		if ( (ulRingPhase != RINGPHASE_REG_PHASE_SOLISITTOKEN)
				&& (ulRingPhase != RINGPHASE_REG_PHASE_HOLDTOKEN)) {	

			pstEvent->uniFlag.ulAll &= ~R_IN32C_EVTPRM_COMMCONNECT;

			pstEvent->uniFlag.ulAll |= R_IN32C_EVTPRM_COMMCONNECTTODISCONNECT;
		}
		else {															
		}
	}
	else {
	}

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_IntrINT1(
	R_IN32D_INTR_SOURCE_T*	pstIntrSource		
)
{
	CYCLIC_STA_T	stCyc;

	if(R_IN32_ON == pstIntrSource->uniITRCV.stBit.b01ZMstWatchTimerTmOutBrk) {
		if(CYCLIC_STA_PARAMENDRECV == TX->CYCLIC_STA.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond) {
            gR_IN32R_ExDisableInt();

			*((ULONG*)&stCyc) = IN32( &TX->CYCLIC_STA );
			stCyc.uniCyclicSta.stBit.b01ZParamCheckCond = R_IN32_ON;
			OUT32(&TX->CYCLIC_STA, *((ULONG*)&stCyc));

           gR_IN32R_ExEnableInt();                 
                        
			RX->ulSTGURANTEN_F = R_IN32_OFF;
			
		}
	}

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_IntrINT2(
	R_IN32D_INTR_SOURCE_T*	pstIntrSource		
)
{
	ULONG		ulIntMask;		


		if ( INT2_REG_SETUP_REC_ACK == (INT2_REG_SETUP_REC_ACK & pstIntrSource->uniINT2.ulAll) ) {
			(VOID)erR_IN32D_FetchSetupRcv();

			ulIntMask = RING->ulIntM2;
			if (  0UL != (INTM2_REG_PERSUASION_REC_MSK & ulIntMask) ) {		

				RING->ulIntM2 = (ulIntMask & ~(ULONG)INTM2_REG_PERSUASION_REC_MSK);

				pstIntrSource->uniINT2.ulAll &= ~INT2_REG_PERSUASION_REC;
			}
			else {															
			}
		}
		else {
		}

		if ( INT2_REG_PERSUASION_REC == (INT2_REG_PERSUASION_REC & pstIntrSource->uniINT2.ulAll) ) {

			gstStopCause.StpDtl.b1ZStpLostMaster = R_IN32_ON;

			ulIntMask = RING->ulIntM2;
			if (  0UL != (INTM2_REG_PERSUASION_REC_MSK & ulIntMask) ) {		

				pstIntrSource->uniINT2.ulAll &= ~INT2_REG_PERSUASION_REC;
			}
			else {															
				RING->ulIntM2 = (ulIntMask | (ULONG)INTM2_REG_PERSUASION_REC_MSK);

				gerR_IN32D_SetMyPort_PortAll();
			}
		}
		else {
		}


		if ( INT2_REG_LEAVE_TIMEOUT == (INT2_REG_LEAVE_TIMEOUT & pstIntrSource->uniINT2.ulAll)) {

			gstStopCause.StpDtl.b1ZStpLostMaster = R_IN32_ON;

			gerR_IN32D_SetMyPort_PortAll();
		}
		else {
		}

	return( R_IN32D_OK );
}


ERRCODE erR_IN32D_SetLoopIntMask(
	R_IN32D_INTR_SOURCE_T*	pstIntrSource		
)
{
//	static ULONG	ulPramCheckOKCount = 0UL;		
	static ULONG	ulHealthCheckCountPre = 0UL;	
	ULONG			ulHealthCheckCountTemp;			
	ULONG			ulSetMask;						
	ULONG			ulTemp;							


	ulSetMask = 0UL;

	ulHealthCheckCountTemp = gulR_IN32D_HealthCheckCount;
	if ( ulHealthCheckCountPre != ulHealthCheckCountTemp ) {
//		ulPramCheckOKCount = 0UL;		
	}
	else {
	}


	if ( 1UL == ulSetMask ) {

		ulTemp = RING->ulMode;
		ulTemp |= (ULONG)MODE_REG_RSTOP_REPEATSTOP;
		RING->ulMode = ulTemp;
	}
	else {
	}
	
	ulHealthCheckCountPre = ulHealthCheckCountTemp;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ReleaseLoopIntMask( VOID )
{
	ULONG		ulReleaseMask;		
	ULONG		ulTemp;				


	ulReleaseMask = 0UL;

	gulR_IN32D_HealthCheckCount++;


	if ( 1UL == ulReleaseMask ) {

		ulTemp = RING->ulMode;
		ulTemp &= (ULONG)~MODE_REG_RSTOP_REPEATSTOP;
		RING->ulMode = ulTemp;
	}
	else {
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetDisconnectFactor( ULONG ulDisconnectfactor )
{
	gulR_IN32D_DisconnectFactor = ulDisconnectfactor;

	return( R_IN32D_OK );
}
ULONG gerR_IN32D_GetDisconnectFactor( ULONG* pulDisconnectfactor )
{
	*pulDisconnectfactor = gulR_IN32D_DisconnectFactor;
	return( R_IN32D_OK );
}

/*** EOF ***/
