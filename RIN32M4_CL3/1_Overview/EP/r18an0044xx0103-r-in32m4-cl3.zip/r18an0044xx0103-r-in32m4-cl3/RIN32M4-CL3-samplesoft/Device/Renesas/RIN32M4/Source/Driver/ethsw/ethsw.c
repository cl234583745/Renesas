/**
 *******************************************************************************
 * @file  ethsw.c
 * @brief Ethernet switch driver program
 * 
 * @note 
 * Copyright (C) 2012,2013 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include <string.h>
#include <time.h>
#include "RIN32M4.h"
#include "kernel.h"
#include "ether/eth_hwfnc.h"
#include "ethsw/ethsw.h"
#include "kernel_id.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
#define ETHSW_LUT_BLK_ENTRIES	8													//Number of entries in one block of the EtherSW LUT
#define ETHSW_LUT_TBL_ENTRIES	256													//Number of blocks of the EtherSW LUT
#define ETHSW_LUT_SIZE			2048												//Size of the EtherSW LUT

#define LRN_TMR_TICK			0x2FAF080											//Tick of 4sec(1count = 80ns)

#define LRN_TMSTP_WIDTH			10													//LUT time stamp width
#define LRN_TIMEDELTA(n, o)		((n - o) & ((1 << LRN_TMSTP_WIDTH)-1 ))				//Time stamp for time calculation macro
#define LRN_TIMEINCREMENT(x)	((x) = ((x)+1) & ((1 << LRN_TMSTP_WIDTH)-1) )		//Timestamp for time increment macro

#define LUT_RECTYPE_DYNAMIC		0
#define LUT_RECTYPE_STATIC		1
#define LUT_REC_INVALID			0
#define LUT_REC_VALID			1

typedef uint8_t crc;

/*===========================================================================*/
/* S T R U C T                                                               */
/*===========================================================================*/
typedef union
{
	struct {
		uint32_t maclo;
		struct{
			uint16_t machi;
			union{
				struct {
					uint16_t rec_valid: 1;
					uint16_t rec_type : 1;
					uint16_t tmstp : 10;
					uint16_t port : 4;
				} dymc;
				struct {
					uint16_t rec_valid: 1;
					uint16_t rec_type : 1;
					uint16_t priority : 3;
					uint16_t port0msk : 1;
					uint16_t port1msk : 1;
					uint16_t port2msk : 1;
					uint16_t reserved : 8;
				} stc;
			}type;
		}hi;
	}record;
	uint32_t all[2];
} RIN_ETHSW_LUT_ADR_Typedef;

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/
uint16_t lrn_crr_timer = 0;
RIN_ETHSW_LUT_ADR_Typedef macinfo_g = {0};
uint8_t lldp_mac[6] = {0x01,0x80,0xC2,0x00,0x00,0x0E};

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/
static void ethsw_mac_learning(void);
static uint8_t ethsw_update_maclut(RIN_ETHSW_LUT_ADR_Typedef *macinfo,uint8_t hash);
static crc ethsw_getCRC8( uint8_t *buff , uint16_t size);

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 ******************************************************************************
  @brief  Initialize ether switch
  @param  none
  @retval none
 ******************************************************************************
*/
void ethsw_init( uint8_t *mac )
{
	uint32_t p;
	
    //=========================================
	// Initialize MAC
    //=========================================
	for (p = 0; p < 2; p++) {
		RIN_ETHSW->MAC[p].FRM_LENGTH       = 1522;			// Maximum Frame Length

#if 1 // << Sample program setting >>
		RIN_ETHSW->MAC[p].RX_SECTION_EMPTY =  0;			// Set 0, empty flag is never asserted. (=Disable pause frame)
		RIN_ETHSW->MAC[p].RX_SECTION_FULL  =  0;			// Set 0, full flag is never asserted. (must be 0 always)
		RIN_ETHSW->MAC[p].TX_SECTION_EMPTY = 80;			// TX ready (septy) to the switch. Controls discard when Outputqueue gets too full.
		RIN_ETHSW->MAC[p].TX_SECTION_FULL  = 40;			// TX cut-through operation

		RIN_ETHSW->MAC[p].RX_ALMOST_FULL  =  8;				// 
		RIN_ETHSW->MAC[p].RX_ALMOST_EMPTY =  8;				// 
		RIN_ETHSW->MAC[p].TX_ALMOST_FULL  =  8;				// 
		RIN_ETHSW->MAC[p].TX_ALMOST_EMPTY =  5;				// must be less than TX_SECTION_FULL
#else // << Reference Guide setteing >>
		RIN_ETHSW->MAC[p].RX_SECTION_EMPTY =  0;			// Set 0, empty flag is never asserted. (=Disable pause frame)
		RIN_ETHSW->MAC[p].RX_SECTION_FULL  =  0;			// Set 0, full flag is never asserted. (must be 0 always)
		RIN_ETHSW->MAC[p].TX_SECTION_EMPTY = 72;			// TX ready (septy) to the switch. Controls discard when Outputqueue gets too full.
		RIN_ETHSW->MAC[p].TX_SECTION_FULL  = 16;			// TX cut-through operation

		RIN_ETHSW->MAC[p].RX_ALMOST_FULL  =  8;				// 
		RIN_ETHSW->MAC[p].RX_ALMOST_EMPTY =  9;				// 
		RIN_ETHSW->MAC[p].TX_ALMOST_FULL  =  4;				// 
		RIN_ETHSW->MAC[p].TX_ALMOST_EMPTY = 10;				// must be less than TX_SECTION_FULL
#endif
	}

    //=========================================
	// Initialize Switch
    //=========================================
    // --- Init. port ---
	RIN_ETHSW->SWCFG.BCAST_DEFAULT_MASK = 0x00000007;		// Allow broadcast to all ports(0-2)
	RIN_ETHSW->SWCFG.MCAST_DEFAULT_MASK = 0x00000007;		// Allow multicast to all ports(0-2)
	RIN_ETHSW->SWCFG.UCAST_DEFAULT_MASK = 0x00000007;		// Allow unknown unicast to flood to all ports
	RIN_ETHSW->SWCFG.MGMT_CONFIG        = 0;

    // --- Init. VLAN ---
	for (p = 0; p < 2; p++) {
		RIN_ETHSW->SWCFG.VLAN_PRIORITY[p] = ((0 <<  0) |	// priority 0 maps to priority 0
											 (1 <<  3) |	// priority 1 map to 1
											 (2 <<  6) |	// 2 to 2
											 (3 <<  9) |	// 3 to 3 (highest)
											 (3 << 12) |	// 4 to 3
											 (3 << 15) |	// 5 to 3
											 (3 << 18) |	// 6 to 3
											 (3 << 21) );	// 7 to 3
											 
		RIN_ETHSW->SWCFG.PRIORITY_CFG[p] = 1;				// Enable VLAN
	}

	// --- Init. LUT ---
	{
		uint32_t *addr;

		addr = (uint32_t *)&RIN_ETHSW->LUT.ADR_TABLE[0];
		for(p = 0 ; p < ETHSW_LUT_SIZE/4 ; p++){
			addr[p]	= 0;
		}
	}
	ethsw_add_maclut(mac,2);
	ethsw_add_maclut_static(lldp_mac,4);

    // --- Enable Switch ---
	RIN_ETHSW->SWCFG.PORT_ENA = 0x00000004;					// Enable port 2

	//=========================================
	// Initialize Hub
	//=========================================
    // --- Init. typical HUB MAC Filter () ---
	//----------------------------------------------------------------
    // Local node unicast address           : UU-VV-WW-XX-YY-ZZ
	//----------------------------------------------------------------
	RIN_ETHSW->SWCFG.HUB_FLT_MAC4lo = (((uint32_t)mac[3] << 24) |
									   ((uint32_t)mac[2] << 16) |
									   ((uint32_t)mac[1] <<  8) |
									   ((uint32_t)mac[0] <<  0));
	RIN_ETHSW->SWCFG.HUB_FLT_MAC4hi = ((               0 << 24) |		// Force forward
									   (            0xff << 16) |		// Mask value
									   ((uint32_t)mac[5] <<  8) |
									   ((uint32_t)mac[4] <<  0));

	//----------------------------------------------------------------
    // Management Frame Domains             : 01-80-c2-00-00-{00..3F}
	//----------------------------------------------------------------
    //  - Spanning Tree, IEEE 802.1d        : 01-80-c2-00-00-{00..0F}
    //  - Bridge Management Address, 802.1d : 01-80-c2-00-00-10
    //  - GARP                              : 01-80-c2-00-00-{20..2F}
    //  - MAC Layer Control Frames (Pause)  : 01-80-c2-00-00-01
	RIN_ETHSW->SWCFG.HUB_FLT_MAC0lo = 0x00c28001;			// 01-80-c2-00-
	RIN_ETHSW->SWCFG.HUB_FLT_MAC0hi = 0x00c00000;			// 00-00 [last byte mask = 0xC0] => {00..3F}

	//----------------------------------------------------------------
    // PTPv2                                : 01-1b-19-00-00-00
	//----------------------------------------------------------------
	RIN_ETHSW->SWCFG.HUB_FLT_MAC1lo = 0x00191b01;			// 01-1b-19-00-
	RIN_ETHSW->SWCFG.HUB_FLT_MAC1hi = 0x00ff0000;			// 00-00 [last byte mask = 0xFF] => 00

	//----------------------------------------------------------------
	// PTP UDP/IP Multicast Domains         : 01-00-5e-00-01-{80..87}
	//----------------------------------------------------------------
	//  - DefaultPTPdomain                  : 01-00-5e-00-01-81 (IP address : 224.0.1.129)
	//  - AlternatePTPdomain1               : 01-00-5e-00-01-82 (IP address : 224.0.1.130)
	//  - AlternatePTPdomain2               : 01-00-5e-00-01-83 (IP address : 224.0.1.131)
	//  - AlternatePTPdomain3               : 01-00-5e-00-01-84 (IP address : 224.0.1.132)
	RIN_ETHSW->SWCFG.HUB_FLT_MAC2lo = 0x005e0001;			// 01-00-5e-00-
	RIN_ETHSW->SWCFG.HUB_FLT_MAC2hi = 0x00f88001;			// 01-80 [last byte mask = 0xF8] => {80..87}

	//----------------------------------------------------------------
    // Management Frame Domains             : 01-00-5e-00-00-{00..03}
	//----------------------------------------------------------------
    //  - Generic Switch Management         : 01-00-5e-00-00-00 (IP address : 224.0.0.0)
    //  - IGMP                              : 01-00-5e-00-00-01 (IP address : 224.0.0.1)
	RIN_ETHSW->SWCFG.HUB_FLT_MAC3lo = 0x005e0001;			// 01-00-5e-00-
	RIN_ETHSW->SWCFG.HUB_FLT_MAC3hi = 0x00fc0000;			// 00-00 [last byte mask = 0xFC] => {00..03}

	//----------------------------------------------------------------
    // DLR Multicast Domains                : 01-21-6C-00-00-{00, 02..FF}
	//----------------------------------------------------------------
    //  * Beacon Frame (Through)            : 01-80-c2-00-00-01
	RIN_ETHSW->SWCFG.HUB_FLT_MAC5lo = 0x006c2101;			// 01-21-6C-00-
	RIN_ETHSW->SWCFG.HUB_FLT_MAC5hi = 0x01ff0100;			// 00-01 [last byte not mask = 0xFF] => {00, 02..FF}

	//----------------------------------------------------------------
    // Reserved
    //----------------------------------------------------------------
	RIN_ETHSW->SWCFG.HUB_FLT_MAC6lo = 0x00000000;
	RIN_ETHSW->SWCFG.HUB_FLT_MAC6hi = 0x00ff0000;

    // --- Enable Hub ---
	RIN_ETHSW->SWCFG.HUB_CONTROL = 0x000000af;				// Enable HUB direction port 0 <-> port 1

    //=========================================
	// Output Queue manager
    //=========================================
    while ( (RIN_ETHSW->SWCFG.OQMGR_STATUS & 0x1) != 0x00000000 ) {
	}
#if 1 // << Sample program setting >>
	RIN_ETHSW->SWCFG.QMGR_MINCELLS    = 0x00000008;			// Set threshold
#else
	RIN_ETHSW->SWCFG.QMGR_MINCELLS    = 0x00000006;			// Set threshold
#endif
	RIN_ETHSW->SWCFG.OQMGR_STATUS     = 0x00000000;			// clear bits
	RIN_ETHSW->SWCFG.QMGR_ST_MINCELLS = 0x00000000;			// clear history
	RIN_ETHSW->SWCFG.QMGR_WEIGHTS     = (					// << Queue weights >>
									   (8 << 24) |			//  - Queue 3
									   (4 << 16) |			//  - Queue 2
									   (2 <<  8) |			//  - Queue 1
									   (1 <<  0));			//  - Queue 0

    //=========================================
	// Initialize timer
    //=========================================
    // --- Init. interrupt ---
	RIN_ETHSW->TSM.TSM_CONFIG       = 0x0000300b;			// Enable all interrupts except for IRQ_EVT_PERIOD
	RIN_ETHSW->TSM.TSM_IRQ_STAT_ACK = 0x0000301f;			// Clear all interrupts

    // --- Init. coutnter ---
	RIN_ETHSW->TSM.ATIME_SEC        = 0x00000000;			// Initialize counter (    seconds time value)
	RIN_ETHSW->TSM.ATIME            = 0x00000000;			// Initialize counter (nanoseconds time value)

    // --- Init. period ---
	RIN_ETHSW->TSM.ATIME_EVT_PERIOD = 1000000000;			// 1 (sec) = 1,000,000,000 (ns)
	RIN_ETHSW->TSM.ATIME_INC        = (						// << Set increment value >>
									   (0 << 16) |			//  - Offset correction increment
									   (8 <<  8) |			//  - Correction increment (When it reaches the value configured in ATIME_CORR)
									   (8 <<  0));			//  - Normal increment (because of 125MHz)
	RIN_ETHSW->TSM.ATIME_CORR       = 0x00000000;			// Clear correction counter

    // --- Init. control ---
	RIN_ETHSW->TSM.ATIME_CTRL       = (						// << Timer control >>
									   (1 <<  7) |			//  - Enable external pin
									   (1 <<  5) |			//  - Reset timer on periodical event
									   (1 <<  4) |			//  - Enable periodical event
									   (1 <<  2) |			//  - Enable offset event
									   (1 <<  1) |			//  - Avoid timer wrap around
									   (1 <<  0));			//  - Start increment

    // --- Init. port status ---
	RIN_ETHSW->TSM.PORT0_CTRL       = 0x00000000;			// Clear port status
	RIN_ETHSW->TSM.PORT1_CTRL       = 0x00000000;			// Clear port status

    //=========================================
	// Enable MAC
    //=========================================
	for (p = 0; p < 2; p++) {
		RIN_ETHSW->MAC[p].COMMAND_CONFIG = ( (1 << 26) |	// Errored frame discard	: Enabled 
										     (0 << 25) |	// 10Mbps Interface			: Disabled
										     (1 << 24) |	// Payload length check		: Enabled 
										     (1 << 23) |	// MAC control frame		: Enabled 
										     (0 << 15) |	// Loopback					: Disabled
										     (0 <<  9) |	// Modify MAC address		: Disabled
										     (0 <<  8) |	// Ignore pause frame		: Disabled
										     (0 <<  7) |	// Forward pause frame		: Disabled
										     (0 <<  6) |	// Forward Received CRC		: Disabled
										     (0 <<  5) |	// Remove frame padding		: Disabled
										     (1 <<  4) |	// Promiscuous operation	: Enabled  (Receive all frames)
										     (0 <<  3) |	// Gigabit Ethernet			: Disabled (10/100M)
										     (1 <<  1) |	// Recieve function			: Enabled 
										     (1 <<  0) );	// Transmit function		: Enabled 
	}

	// clear the timer for time stamp
	lrn_crr_timer = 0;
	sta_tsk(ID_TASK_MAC_LRN, 0);
}

/**
 ******************************************************************************
  @brief  MAC address learning task(Layer 2 Switch)
  @param  none
  @retval none
 ******************************************************************************
*/
void ethsw_mac_learning_tsk(int exinf)
{
	clock_t		timer;

	timer = clock();
	while(1)
	{
		tslp_tsk(LRN_TSK_SLP);
		ethsw_mac_learning();
		if((clock() - timer) > LRN_TMR_TICK)
		{
			 timer = clock();
			 LRN_TIMEINCREMENT(lrn_crr_timer);
		}
	}
} /* ethsw_mac_learning_tsk() */

/**
 ******************************************************************************
  @brief  Add the MAC address and Port to the LUT (dynamic entry)
  @param  mac  -- mac address
  @param  port -- EtherSW port No.
                     0 : Port 0
                     1 : Port 1
                     2 : Port 2(CPU Port)
  @retval none
 ******************************************************************************
*/
void ethsw_add_maclut(uint8_t *mac , uint8_t port)
{
	uint8_t hash = 0;

	memset (&macinfo_g, 0, sizeof (macinfo_g));
	macinfo_g.record.maclo		=	(((uint32_t)mac[3] << 24) |
									 ((uint32_t)mac[2] << 16) |
									 ((uint32_t)mac[1] <<  8) |
									 ((uint32_t)mac[0] <<  0));
	macinfo_g.record.hi.machi	=	(((uint16_t)mac[5] <<  8) |
									 ((uint16_t)mac[4] <<  0));
	macinfo_g.record.hi.type.dymc.port		= port;
	macinfo_g.record.hi.type.dymc.tmstp		= lrn_crr_timer;
	macinfo_g.record.hi.type.dymc.rec_type	= LUT_RECTYPE_DYNAMIC;
	macinfo_g.record.hi.type.dymc.rec_valid	= LUT_REC_VALID;
	hash = ethsw_getCRC8(mac,6);

	ethsw_update_maclut(&macinfo_g , hash);
} /* ethsw_add_maclut() */

/**
 ******************************************************************************
  @brief  Add the MAC address and Port to the LUT (static entry)
  @param  mac  -- mac address
  @param  port -- EtherSW port No.
                     1 : Port 0
                     2 : Port 1
                     3 : Port 0 & Port 1
                     4 : Port 2
                     7 : Port ALL
  @retval none
 ******************************************************************************
*/
void ethsw_add_maclut_static(uint8_t *mac , uint8_t port)
{
	uint8_t hash = 0;

	memset (&macinfo_g, 0, sizeof (macinfo_g));
	macinfo_g.record.maclo		=	(((uint32_t)mac[3] << 24) |
									 ((uint32_t)mac[2] << 16) |
									 ((uint32_t)mac[1] <<  8) |
									 ((uint32_t)mac[0] <<  0));
	macinfo_g.record.hi.machi	=	(((uint16_t)mac[5] <<  8) |
									 ((uint16_t)mac[4] <<  0));
	if(port & 0x1)
	{
		macinfo_g.record.hi.type.stc.port0msk = 1;
	}
	if(port & 0x2)
	{
		macinfo_g.record.hi.type.stc.port1msk = 1;
	}
	if(port & 0x4)
	{
		macinfo_g.record.hi.type.stc.port2msk = 1;
	}
	macinfo_g.record.hi.type.stc.priority	= 0;
	macinfo_g.record.hi.type.stc.rec_type	= LUT_RECTYPE_STATIC;
	macinfo_g.record.hi.type.stc.rec_valid	= LUT_REC_VALID;
	hash = ethsw_getCRC8(mac,6);

	ethsw_update_maclut(&macinfo_g , hash);
} /* ethsw_add_maclut() */

/**
 ******************************************************************************
  @brief  Learning the MAC address and Port
          Add to the LUT (dynamic entry)
  @param  none
  @retval none
 ******************************************************************************
*/
static void ethsw_mac_learning(void)
{
	uint8_t i;
	uint8_t hash = 0;
	uint32_t lrn_temp;

	for(i = 0 ; i < LRN_CHK_CNT ; i++)
	{
		if(RIN_ETHSW->FIFO.LRN_STATUS & 0x01){
			macinfo_g.record.maclo		= RIN_ETHSW->FIFO.LRN_REC_A;
			lrn_temp = RIN_ETHSW->FIFO.LRN_REC_B;
			macinfo_g.record.hi.machi	=  lrn_temp & 0xFFFF;
			macinfo_g.record.hi.type.dymc.port		= (lrn_temp >> 24) & 0xf;
			macinfo_g.record.hi.type.dymc.tmstp		= lrn_crr_timer;
			macinfo_g.record.hi.type.dymc.rec_type	= LUT_RECTYPE_DYNAMIC;
			macinfo_g.record.hi.type.dymc.rec_valid	= LUT_REC_VALID;
			hash = (lrn_temp >> 16) & 0xff;
			ethsw_update_maclut(&macinfo_g , hash);
		}
		else
		{
			return;
		}
	}
} /* ethsw_mac_learning() */

/**
 ******************************************************************************
  @brief  Update or insert the LUT entry.
  @param  macinfo -- mac information(LUT entry information)
  @param  hash    -- hach code(LUT index)
  @retval 0 : LUT entry is update
  @retval 1 : LUT entry is inserted or overwrite
 ******************************************************************************
*/
static uint8_t ethsw_update_maclut(RIN_ETHSW_LUT_ADR_Typedef *macinfo,uint8_t hash)
{
	uint16_t i;
	uint16_t iend;
	uint16_t iold;
	int16_t  iunused;
	uint16_t time;
	uint16_t timeold;
	uint8_t  found_flg;
	RIN_ETHSW_LUT_ADR_Typedef *macinfo_t;
	RIN_ETHSW_LUT_ADR_Typedef macinfo_l;

	if(macinfo->record.hi.type.dymc.rec_type == LUT_RECTYPE_DYNAMIC){
		macinfo->record.hi.type.dymc.tmstp = lrn_crr_timer;
	}
	// linear search through all slot entries and update if found
	iend = hash + ETHSW_LUT_BLK_ENTRIES;
	iunused = -1;
	macinfo_t = (RIN_ETHSW_LUT_ADR_Typedef *)&RIN_ETHSW->LUT.ADR_TABLE[0];
	for( i=hash; i < iend; i++ ) {
		macinfo_l = macinfo_t[i];
		if(macinfo_l.record.maclo == macinfo->record.maclo
		&& macinfo_l.record.hi.machi == macinfo->record.hi.machi)
		{
			//match a MAC address
			if(macinfo_l.record.hi.type.dymc.rec_type == LUT_RECTYPE_DYNAMIC){
				macinfo_t[i] = *macinfo;
			}
			return 0;	//LUT update
		}
		else if(macinfo_l.record.hi.type.dymc.rec_valid == LUT_REC_INVALID)
		{
			//found empty entry
			if( iunused < 0 ){
				iunused = i;
			}
		}
	}

	// new entry inserted. add it to first unused entry.
	if(iunused >= 0) {
		macinfo_t[iunused] = *macinfo;
		return 1;  // newly inserted
	}

	// no more entry available in block... overwrite oldest
	timeold = 0;
	iold = 0;
	found_flg = 0;
	for(i=hash; i < iend; i++)
	{
		macinfo_l = macinfo_t[i];
		if(macinfo_l.record.hi.type.dymc.rec_type == LUT_RECTYPE_DYNAMIC){
			time = LRN_TIMEDELTA(lrn_crr_timer, macinfo_l.record.hi.type.dymc.tmstp);
			if( time > timeold ) {	// is it older ?
				timeold = time;
				iold = i;
			}
			found_flg = 1; // remember that there was at least one dynamic entry we can overwrite
		}
	}
	if(found_flg)
	{
		//overwrite the oldest entry
		macinfo_t[iold] = *macinfo;
	}

	return 1;  // newly overwrite
} /* ethsw_update_maclut() */

/**
 *******************************************************************************
  @brief   Calculation of CRC8.
  @param   [in] *buff : buff is a CRC calculation data.
  @param   [in] size  : size is the length of  buff.
  @return  crc value
 *******************************************************************************
 */
static crc ethsw_getCRC8( uint8_t *buff , uint16_t size)
{
	uint8_t byte;
	uint8_t bit;
	uint16_t inval;
	uint16_t t_crc;
	
	t_crc   = 0x12;         // preset is 0xff after 8 shifts

	for(byte=0; byte < size; byte++) {
		inval = ((uint16_t)(buff[byte])) << 8;
		t_crc |= inval;
		for(bit=0; bit < 8; bit++) {
			if( t_crc & 0x01 ) {
				t_crc ^= 0x1c0;
			}
			t_crc >>= 1;
		}
	}
    
	return (crc)t_crc;
} /* ethsw_getCRC8() */
