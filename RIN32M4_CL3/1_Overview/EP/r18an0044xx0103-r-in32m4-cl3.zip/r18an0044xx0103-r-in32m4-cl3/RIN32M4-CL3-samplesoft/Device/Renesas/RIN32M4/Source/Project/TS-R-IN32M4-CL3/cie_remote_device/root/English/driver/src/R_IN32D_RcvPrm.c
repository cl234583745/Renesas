/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_RcvPrm.c                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_RcvPrm_l.h"

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

R_IN32D_PRAMETER_NUMBER_RCV_T	gstR_IN32D_ParamNumberRcv;	
R_IN32D_PRAMETER_ACTION_RCV_T	gstR_IN32D_ParamActionRcv;	
R_IN32D_PRAMETER_COMMON_RCV_T	gstR_IN32D_ParamCommonRcv;	

R_IN32D_REFRESH_SIZE_T			gstR_IN32D_RefreshSize = { 0UL, 0UL, 0UL, 0UL };		

PARAMID_T						gstTempPARAMID = {{{0UL}}};

/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE erR_IN32D_FetchStationNetworkNumber( R_IN32D_PRAMETER_NUMBER_RCV_T* );
static ERRCODE erR_IN32D_FetchActionCommmand( R_IN32D_PRAMETER_ACTION_RCV_T*, PARAMETER_FRAME_REG_TAG* );
static ERRCODE erR_IN32D_FetchCommonParameter( R_IN32D_PRAMETER_COMMON_RCV_T*, PARAMCHECK_FRAME_REG_TAG* );
static ULONG   ulR_IN32D_GetRxRyDataValidSize( ULONG, ULONG, ULONG );
ERRCODE erR_IN32D_SetCyclicTD(  PARAMETER_FRAME_REG_TAG* p_frame, ULONG ulSize );

/****************************************************************************/
/* Macros                                                         */
/****************************************************************************/
#define	M_RANGECHK(min, value, max)	(((min <= value) && (value <= max)) ? R_IN32D_OK : R_IN32D_NG)

ERRCODE gerR_IN32D_GetParamStnNetNumber(
	R_IN32D_PRMFRM_INF0_T*	pstStationNetworkNumber		
)
{
	pstStationNetworkNumber->ulStationNumber = (ULONG)gstR_IN32D_ParamNumberRcv.usSelfNumber;

	pstStationNetworkNumber->ulNetworkNumber = (ULONG)gstR_IN32D_ParamNumberRcv.stNetNum.b08ZNetworkNumber;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetParamActCmdStnType(
	R_IN32D_PRMFRM_INF1_T*	pstActCommand				
)
{
	pstActCommand->ulCommand = 0UL;

	if ( (USHORT)0 != (gstR_IN32D_ParamActionRcv.usActCmd & PARA_ACT_COMMAND_STATIONTYPE_VALID) ) {
		pstActCommand->ulCommand |= R_IN32D_ACTCMD_STATIONTYPE_VALID;
	}
	else {
	}

	if ( CYCLIC_STA_MYSTNOOUTOFRANGE == (CYCLIC_STA_MYSTNOOUTOFRANGE & gstR_IN32D_ParamActionRcv.stCyclicSta.uniCyclicSta.ulAll) ) {
		pstActCommand->ulCommand |= R_IN32D_ACTCMD_CYCSTP_STNOUTRANGE;
	}
	else {
	}

	if ( CYCLIC_STA_MYSTRESERVESETUP == (CYCLIC_STA_MYSTRESERVESETUP & gstR_IN32D_ParamActionRcv.stCyclicSta.uniCyclicSta.ulAll) ) {
		pstActCommand->ulCommand |= R_IN32D_ACTCMD_CYCSTP_RSVST;
	}
	else {
	}

	if ( CYCLIC_STA_CYCLICOPEVARISTOP == (CYCLIC_STA_CYCLICOPEVARISTOP & gstR_IN32D_ParamActionRcv.stCyclicSta.uniCyclicSta.ulAll) ) {
		pstActCommand->ulCommand |= R_IN32D_ACTCMD_CYCSTP_MSTREQ;
	}
	else {
	}

	if ( CYCLIC_STA_MYSTNODUPLICATE == (CYCLIC_STA_MYSTNODUPLICATE & gstR_IN32D_ParamActionRcv.stCyclicSta.uniCyclicSta.ulAll) ) {
		pstActCommand->ulCommand |= R_IN32D_ACTCMD_CYCSTP_DUPLICATE;
	}
	else {
	}

	pstActCommand->ulStationType = (ULONG)(gstR_IN32D_ParamActionRcv.usActCmd >> 8);

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetParamComParameter(
	R_IN32D_PRMFRM_INF2_T*	pstCommonParam				
)
{
	pstCommonParam->auchPARAMID[0]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[0];	
	pstCommonParam->auchPARAMID[1]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[1];	
	pstCommonParam->auchPARAMID[2]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[2];	
	pstCommonParam->auchPARAMID[3]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[3];	
	pstCommonParam->auchPARAMID[4]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[4];	
	pstCommonParam->auchPARAMID[5]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[5];	
	pstCommonParam->auchPARAMID[6]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[6];	
	pstCommonParam->auchPARAMID[7]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[7];	
	pstCommonParam->auchPARAMID[8]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[8];	
	pstCommonParam->auchPARAMID[9]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[9];	
	pstCommonParam->auchPARAMID[10]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[10];	
	pstCommonParam->auchPARAMID[11]	= (UCHAR)gstR_IN32D_ParamCommonRcv.stPARAMID.uniParamId.auchData[11];	

	pstCommonParam->ulRxByteSize	= gstR_IN32D_RefreshSize.ulRxByteSize;		
	__BUS_RELEASE();
	pstCommonParam->ulRWrByteSize	= gstR_IN32D_RefreshSize.ulRWrByteSize;		
	pstCommonParam->ulRyByteSize	= gstR_IN32D_RefreshSize.ulRyByteSize;		
	pstCommonParam->ulRWwByteSize	= gstR_IN32D_RefreshSize.ulRWwByteSize;		

	return( R_IN32D_OK );
}


ERRCODE gerR_IN32D_FetchStationNetworkNumber( VOID ){
	(VOID)erR_IN32D_FetchStationNetworkNumber( &gstR_IN32D_ParamNumberRcv );
	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchStationNetworkNumber(
	R_IN32D_PRAMETER_NUMBER_RCV_T*	pstNumber		
)
{
	USHORT*		pusTemp;

	pstNumber->usSelfNumber = GMAC->ulNum;

	pusTemp = (USHORT*)&pstNumber->stNetNum;
	*pusTemp = (USHORT)TX->ulNET_NUM;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchActionCommmand(
	R_IN32D_PRAMETER_ACTION_RCV_T*	pstActCmd,
	PARAMETER_FRAME_REG_TAG* p_frame
)
{

	volatile USHORT*		pusDst;
	volatile ULONG*			pulSrc;
	pulSrc = (volatile ULONG*)&TX->CYCLIC_STA;
	pusDst = (volatile USHORT*)&pstActCmd->stCyclicSta;
	*pusDst = (USHORT)IN32( pulSrc );

	gR_IN32S_Memcpy(&(pstActCmd->usActCmd), &(p_frame->SETCOMMAND), (sizeof(p_frame->SETCOMMAND) + sizeof(p_frame->uchStationClassification)));

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchCommonParameter(
	R_IN32D_PRAMETER_COMMON_RCV_T*	pstComPrm,
	PARAMCHECK_FRAME_REG_TAG*	p_frame
)
{

	gR_IN32S_Memcpy(&pstComPrm->stPARAMID, &(p_frame->PRAMID), sizeof(p_frame->PRAMID));

	pstComPrm->stRY1_FMB_INFO.ulDATA = RX->ulRY1_FMB_INFO;

	pstComPrm->usRY1CYC_DSIZE  = RX->ulRY1CYC_DSIZE;

	pstComPrm->usRWw1CYC_DSIZE = RX->ulRWw1CYC_DSIZE;


	return( R_IN32D_OK );
}


ULONG ulR_IN32D_GetRxRyDataValidSize(
	ULONG	ulDataLWord,			
	ULONG	ulTopByteValidInf,		
	ULONG	ulBtmByteValidInf		
)
{
	static const ULONG	aulTopInvalidByteSize_1LW[16] = {
								4, 
								3, 
								3, 
								2, 
								3, 
								1, 
								2, 
								0, 
								3, 
								0, 
								1, 
								0, 
								2, 
								0, 
								1, 
								0  
							};
	
	static const ULONG	aulTopInvalidByteSize_2LW[16] = {
								4, 
								0, 
								1, 
								0, 
								2, 
								0, 
								1, 
								0, 
								3, 
								0, 
								1, 
								0, 
								2, 
								0, 
								1, 
								0  
							};
	
	static const ULONG	aulBtmInvalidByteSize[16] = {
								4, 
								3, 
								2, 
								2, 
								1, 
								1, 
								1, 
								1, 
								0, 
								0, 
								0, 
								0, 
								0, 
								0, 
								0, 
								0  
							};

	ULONG	ulValidByteSize;				


	ulValidByteSize = (ulDataLWord << 2);

	if (0 == ulDataLWord) {						
	}
	else if (1UL == ulDataLWord) {					
		ulValidByteSize -= aulTopInvalidByteSize_1LW[ ulTopByteValidInf ];
	}
	else {											
		ulValidByteSize -= aulTopInvalidByteSize_2LW[ ulTopByteValidInf ];

		ulValidByteSize -= aulBtmInvalidByteSize[ ulBtmByteValidInf ];
	}

	return( ulValidByteSize );
}


ERRCODE erR_IN32D_TransParameter( PARAMETER_COMMONID_TAG* pstSrcParamID, PARAMID_T* pstDstParamID )
{

	pstDstParamID->uniParamId.stBit.b8ZYear_h	= ((pstSrcParamID->usYear) & 0x00FF);
	pstDstParamID->uniParamId.stBit.b8ZYear_l	= ((pstSrcParamID->usYear) & 0xFF00) >> 8;
	pstDstParamID->uniParamId.stBit.b8ZMonth		= pstSrcParamID->uchMonth;
	pstDstParamID->uniParamId.stBit.b8ZDay		= pstSrcParamID->uchDay;
	pstDstParamID->uniParamId.stBit.b8ZHour		= pstSrcParamID->uchHour;
	__BUS_RELEASE();
	pstDstParamID->uniParamId.stBit.b8ZMinute	= pstSrcParamID->uchMin;
	pstDstParamID->uniParamId.stBit.b8ZSecond	= pstSrcParamID->uchSec;
	pstDstParamID->uniParamId.stBit.b8ZStationNo	= pstSrcParamID->uchStationNo;;
	__BUS_RELEASE();
	pstDstParamID->uniParamId.stBit.b8ZSum1		= ((pstSrcParamID->ulSumcheckCode) & 0x000000FF);
	pstDstParamID->uniParamId.stBit.b8ZSum2		= ((pstSrcParamID->ulSumcheckCode) & 0x0000FF00) >> 8;
	pstDstParamID->uniParamId.stBit.b8ZSum3		= ((pstSrcParamID->ulSumcheckCode) & 0x00FF0000) >> 16;
	pstDstParamID->uniParamId.stBit.b8ZSum4		= ((pstSrcParamID->ulSumcheckCode) & 0xFF000000) >> 24;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ParameterRcv( PARAMETER_FRAME_REG_TAG* p_frame, ULONG ulSize)
{
	ULONG	ulRet;
	CYCLIC_STA_T	stCyc;
	SELF_STA_TAG	stSelf;
	USHORT usStationInfo;
	PARAMETER_STATION_INFO_TAG* stStationInfo = (PARAMETER_STATION_INFO_TAG*)&usStationInfo;
	BOOL		blSync;
	PARAMID_T	stBlankParamID;
	PARAMID_T	stRcvParamID;
	ULONG	ulRXSize;
	ULONG	ulRYSize;
	ULONG	ulRWrSize;
	ULONG	ulRWwSize;
	__BUS_RELEASE();
	
	gR_IN32R_ExDisableInt();


	*((ULONG*)&stCyc) = IN32( &TX->CYCLIC_STA );
	*((ULONG*)&stSelf)= IN32( &TX->SELF_STA );

	gR_IN32S_Memset(&stBlankParamID, 0x00, sizeof(stBlankParamID));
	
	erR_IN32D_TransParameter(&(p_frame->PRAMID), &stRcvParamID);

	gstStopCause.StpDtl.b1ZStpLostMaster = R_IN32_OFF;

	if(R_IN32_ON == p_frame->SETCONTENT.b1ZSwitchInfo){
		gerR_IN32D_SetNetworkNumber(p_frame->uchNetworkNumberSet);

		gerR_IN32D_SetStationNumber((ULONG)gusR_IN32S_SwapS(p_frame->usStationNumberSet));

		(VOID)erR_IN32D_FetchStationNetworkNumber( &gstR_IN32D_ParamNumberRcv );
		gerR_IN32C_SeqMain_ChangeStationNetworkNumber();
	}

	if(R_IN32_ON == p_frame->SETCONTENT.b1ZParamInfo){
		
		stCyc.uniCyclicSta.stBit.b01ZParamCheckCond = R_IN32_ON;
		

		ulRet = gulR_IN32S_Memcmp(&stBlankParamID, &stRcvParamID, sizeof(PARAMID_T));
		
		if(R_IN32_OK == ulRet) {

			gstR_IN32D_ParamCommonRcv.stPARAMID = stBlankParamID;

			gstTempPARAMID = stBlankParamID;
			
			stCyc.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond = CYCLIC_STA_PARAMNONRECV;
		}
		else {

			gR_IN32S_Memcpy(&gstTempPARAMID, &(p_frame->PRAMID), sizeof(p_frame->PRAMID));

			if( (0 == p_frame->PRAMDATA.usRXFrameCyclicDataSize) &&
				(0 == p_frame->PRAMDATA.usRWrFrameCyclicDataSize))
			{
				stSelf.b01ZSendFlagNotSet = R_IN32_ON;
			}
			else {
				stSelf.b01ZSendFlagNotSet = R_IN32_OFF;
			}

			usStationInfo = gusR_IN32S_SwapS(p_frame->PRAMDATA.usMasterIDActionSet);
			blSync = R_IN32_TRUE;
			if ((gulR_IN32U_SYNC_SUPPORTED_MODE & (1 << stStationInfo->b1ZSyncInfo)) == 0) {
				blSync = R_IN32_FALSE;
			}

			ulRXSize =	ulR_IN32D_GetRxRyDataValidSize(	gusR_IN32S_SwapS(p_frame->PRAMDATA.usRXFrameCyclicDataSize),
														(0x0F & (p_frame->PRAMDATA.uchRXFrameByteEnableInfo)),
														((0xF0 & (p_frame->PRAMDATA.uchRXFrameByteEnableInfo)) >> 4));
			ulRYSize =	ulR_IN32D_GetRxRyDataValidSize(	gusR_IN32S_SwapS(p_frame->PRAMDATA.usRYFrameCyclicDataSize),
														(0x0F & (p_frame->PRAMDATA.uchRYFrameByteEnableInfo)),
														((0xF0 & (p_frame->PRAMDATA.uchRYFrameByteEnableInfo)) >> 4));
			ulRWrSize = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWrFrameCyclicDataSize)) * 4;
			ulRWwSize = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWwFrameCyclicDataSize)) * 4;

			if(
				(R_IN32D_OK == M_RANGECHK(gulR_IN32U_MIN_RX_SIZE,	ulRXSize,	gulR_IN32U_MAX_RX_SIZE))	&&
				(R_IN32D_OK == M_RANGECHK(gulR_IN32U_MIN_RY_SIZE,	ulRYSize,	gulR_IN32U_MAX_RY_SIZE))	&&
				(R_IN32D_OK == M_RANGECHK(gulR_IN32U_MIN_RWR_SIZE,	ulRWrSize,	gulR_IN32U_MAX_RWR_SIZE))	&&
				(R_IN32D_OK == M_RANGECHK(gulR_IN32U_MIN_RWW_SIZE,	ulRWwSize,	gulR_IN32U_MAX_RWW_SIZE))	&&
				(blSync == R_IN32_TRUE)
			){


				gerR_IN32D_SetMasterID((ULONG)((gusR_IN32S_SwapS(p_frame->PRAMDATA.usMasterIDActionSet)) & 0xF000) >> 12);

				stCyc.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond = CYCLIC_STA_PARAMENDRECV;
				

			}
			else {
				TX->ulCYC_MASTER_ID_SND = 0x00;

				stCyc.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond = CYCLIC_STA_PARAMABNORMAL;
			}
			
			RX->ulRY1_SQNUM_1 = p_frame->PRAMDATA.uchRYFrameSequentialNumber;
			RX->ulRWw1_SQNUM_1 = p_frame->PRAMDATA.uchRWwFrameSequentialNumber;

			RX->ulRY1FM_OFFSET_1 = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRYFrameAreaOffsetAddress));
			RX->ulRWw1FM_OFFSET_1 = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWwFrameAreaOffsetAddress));

			RX->ulRY1_FMB_INFO = p_frame->PRAMDATA.uchRYFrameByteEnableInfo;

			RX->ulRY1CYC_DSIZE = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRYFrameCyclicDataSize));
			RX->ulRWw1CYC_DSIZE = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWwFrameCyclicDataSize));

			RX->ulMWT_TIM = (ULONG)(gusR_IN32S_SwapS(p_frame->PRAMDATA.usMasterWatchTimerSetNumber));

			RX->ulGroupAddress = p_frame->PRAMDATA.ulGroupReservation;

			erR_IN32D_SetCyclicTD(p_frame, ulSize);
		}

		gerR_IN32C_SeqMain_ChangeCommonParamStart();
	}

	if(R_IN32_ON == p_frame->SETCONTENT.b1ZModeInfo){


		if(R_IN32_ON == p_frame->MODECOMMAND.b1ZCyclicStop_Reseve) {
			stCyc.uniCyclicSta.stBit.b01ZMyStationReserveSetup = R_IN32_ON;
		}
		else {
			stCyc.uniCyclicSta.stBit.b01ZMyStationReserveSetup = R_IN32_OFF;
		}
		if(R_IN32_ON == p_frame->MODECOMMAND.b1ZCyclicStop_Repeat) {
			stCyc.uniCyclicSta.stBit.b01ZMyStationNumberDuplicate = R_IN32_ON;
		}
		else {
			stCyc.uniCyclicSta.stBit.b01ZMyStationNumberDuplicate = R_IN32_OFF;
		}
		if(R_IN32_ON == p_frame->MODECOMMAND.b1ZCyclicStop_StOver) {
			stCyc.uniCyclicSta.stBit.b01ZMyStationNoRangeOut = R_IN32_ON;
		}
		else {
			stCyc.uniCyclicSta.stBit.b01ZMyStationNoRangeOut = R_IN32_OFF;
		}
		if(R_IN32_ON == p_frame->MODECOMMAND.b1ZCyclicStop_Master) {
			stCyc.uniCyclicSta.stBit.b01ZCyclicOpeInstructVarious = R_IN32_ON;
		}
		else {
			stCyc.uniCyclicSta.stBit.b01ZCyclicOpeInstructVarious = R_IN32_OFF;
		}
		if(R_IN32_ON == p_frame->SETCOMMAND.b1ZCyclicStop_Invalid) {
			stSelf.b01ZNonErrSetting = R_IN32_ON;
		}
		else {
			stSelf.b01ZNonErrSetting = R_IN32_OFF;
		}



		(VOID)erR_IN32D_FetchActionCommmand( &gstR_IN32D_ParamActionRcv, p_frame );
		gerR_IN32C_SeqMain_ChangeActCommand();
	}
	
	if( (R_IN32_ON == p_frame->SETCONTENT.b1ZParamInfo) &&
		(R_IN32_ON == p_frame->SETCONTENT.b1ZModeInfo)){
		
		if(gulR_IN32U_STATION_CLASS != p_frame->uchStationClassification){
			stCyc.uniCyclicSta.stBit.b01ZStationClassificationWrong = R_IN32_ON;
		}
		else {
		}

	}
	
	OUT32(&TX->CYCLIC_STA, *((ULONG*)&stCyc));
	OUT32(&TX->SELF_STA, *((ULONG*)&stSelf));
	
	gR_IN32R_ExEnableInt();

	gerR_IN32D_UpdateCyclicPermission();


	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_ParamCheckRcv( PARAMCHECK_FRAME_REG_TAG* p_frame, ULONG ulSize)
{
	ULONG	ulRet1;
	ULONG	ulRet2;
	ULONG	ulMstID;
	CYCLIC_STA_T	stCyc;
	SELF_STA_TAG	stSelf;
	PARAMID_T	stBlankParamID;
	PARAMID_T	stRcvParamID;

	gR_IN32R_ExDisableInt();

	*((ULONG*)&stCyc) = IN32( &TX->CYCLIC_STA );
	*((ULONG*)&stSelf)= IN32( &TX->SELF_STA );

	gR_IN32S_Memset(&stBlankParamID, 0x00, sizeof(stBlankParamID));

	erR_IN32D_TransParameter(&(p_frame->PRAMID), &stRcvParamID);

	ulMstID = (ULONG)((gusR_IN32S_SwapS(p_frame->usMasterIDActionSet)) & 0xF000) >> 12;

	ulRet1 = gulR_IN32S_Memcmp(&stBlankParamID, &stRcvParamID, sizeof(PARAMID_T));

	ulRet2 = gulR_IN32S_Memcmp(&(gstTempPARAMID), &stRcvParamID, sizeof(PARAMID_T));

	if(RX->CYC_MASTER_ID_RCV == ulMstID){

		if((R_IN32_OK != ulRet1) && (R_IN32_OK == ulRet2)){

			if(CYCLIC_STA_PARAMENDRECV == stCyc.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond){


				stCyc.uniCyclicSta.stBit.b01ZParamCheckCond = R_IN32_OFF;



			}
			else{
			}
		}
		else{
			stCyc.uniCyclicSta.stBit.b01ZParamCheckCond = R_IN32_ON;

			gstTempPARAMID = stBlankParamID;

			stCyc.uniCyclicSta.stBit.b03ZMstLocComonParamkeepCond = CYCLIC_STA_PARAMNONRECV;
		}

		RX->ulMWT_CONT = R_IN32_ON;

		(VOID)erR_IN32D_FetchCommonParameter( &gstR_IN32D_ParamCommonRcv, p_frame );
		gerR_IN32C_SeqMain_ChangeCommonParamFin();
	}
	else{
	}
	
	OUT32(&TX->CYCLIC_STA, *((ULONG*)&stCyc));
	OUT32(&TX->SELF_STA, *((ULONG*)&stSelf));
	
	gR_IN32R_ExEnableInt();

	gerR_IN32D_UpdateCyclicPermission();



	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_SetCyclicTD(  PARAMETER_FRAME_REG_TAG* p_frame, ULONG ulSize )
{
	ULONG			ulAdr0;
	ULONG			ulAdr1;
	ULONG			ulAdr2;
	ULONG			ulLastDiscNo;
	ULONG			ulSeqNo;
	ULONG			ulRWrSize;
	ULONG			ulRWr1Size;
	ULONG			ulRWr2Size;
	ULONG			ulRXSize;
	ULONG			ulMACAddress0;
	ULONG			ulMACAddress1;
	ULONG			ulMultiCastAddress0;
	ULONG			ulMultiCastAddress1;
	CYCLIC_HEAD_TAG	stheadRWr1;
	CYCLIC_HEAD_TAG	stheadRWr2;
	CYCLIC_HEAD_TAG	stheadRX;

	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;

	ulLastDiscNo = 0x00;
	ulSeqNo		 = 0x01;
	ulMACAddress0 = RING->ulMACAddress0;
	ulMACAddress1 = RING->ulMACAddress1;
	ulMultiCastAddress0 = RING->ulMultiAddReg0;
	ulMultiCastAddress1 = RING->ulMultiAddReg1;

	ulAdr0 = ulMultiCastAddress0;
	ulAdr1 = ((ulMultiCastAddress1 & 0x0000FFFF) |
			  (ulMACAddress0  & 0x0000FFFF) << 16 );
	ulAdr2 = (((ulMACAddress0 & 0xFFFF0000) >> 16) |
			  ((ulMACAddress1 & 0x0000FFFF) << 16));

	gR_IN32S_Memset(&stheadRWr1, 0x00, sizeof(stheadRWr1));
	gR_IN32S_Memset(&stheadRWr2, 0x00, sizeof(stheadRWr2));
	gR_IN32S_Memset(&stheadRX, 0x00, sizeof(stheadRX));
	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));
	

	ulRWrSize = (ULONG)gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWrFrameCyclicDataSize);
	
	if( 0x16F < ulRWrSize) {
		ulRWr1Size = 0x16F;
		ulRWr2Size =ulRWrSize - 0x16F;
	}
	else {
		ulRWr1Size = ulRWrSize;
		ulRWr2Size = 0;
	}
	
	ulRXSize = (ULONG)gusR_IN32S_SwapS(p_frame->PRAMDATA.usRXFrameCyclicDataSize);

	gstR_IN32D_RefreshSize.ulRxByteSize =	ulR_IN32D_GetRxRyDataValidSize(	gusR_IN32S_SwapS(p_frame->PRAMDATA.usRXFrameCyclicDataSize),
												(0x0F & (p_frame->PRAMDATA.uchRXFrameByteEnableInfo)),
												((0xF0 & (p_frame->PRAMDATA.uchRXFrameByteEnableInfo)) >> 4));
	gstR_IN32D_RefreshSize.ulRyByteSize =	ulR_IN32D_GetRxRyDataValidSize(	gusR_IN32S_SwapS(p_frame->PRAMDATA.usRYFrameCyclicDataSize),
												(0x0F & (p_frame->PRAMDATA.uchRYFrameByteEnableInfo)),
												((0xF0 & (p_frame->PRAMDATA.uchRYFrameByteEnableInfo)) >> 4));
	gstR_IN32D_RefreshSize.ulRWrByteSize = (ULONG)gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWrFrameCyclicDataSize) * 4;
	gstR_IN32D_RefreshSize.ulRWwByteSize = (ULONG)gusR_IN32S_SwapS(p_frame->PRAMDATA.usRWwFrameCyclicDataSize) * 4;

	if(0 == ulRXSize) {
		if(0 >= ulRWr2Size) {
			ulLastDiscNo = TDISC_NO_CYCLIC_RWr;
		}
		else {
			ulLastDiscNo = TDISC_NO_CYCLIC_RWr + 1;
		}
	}
	else {
		ulLastDiscNo = TDISC_NO_CYCLIC_RX;
	}

	if(0 != ulRWr1Size) {

		*(ULONG*)&stheadRWr1 = ulAdr0;
		*((ULONG*)(&stheadRWr1) + 1) = ulAdr1;
		*((ULONG*)(&stheadRWr1) + 2) = ulAdr2;

		stheadRWr1.usType = FRAME_COM_FRMTYPE;
		stheadRWr1.FRAME_INFO.b4ZProtocolClassifcation = R_IN32U_PROTOCOL_CLASS;
		stheadRWr1.FRAME_INFO.b4ZProtocolVersion = R_IN32U_PROTOCOL_VER;

		stheadRWr1.usMyStationNumber = gusR_IN32S_SwapS((USHORT)(GMAC->ulNum));
		stheadRWr1.usNodeID = gusR_IN32S_SwapS((USHORT)gulR_IN32D_GetNodeID());

		stheadRWr1.uchFrameClassification = FTYPE_CyclicRWr;

		stheadRWr1.ulInfomation = 0;
		stheadRWr1.ulInfomation |= ulSeqNo;
		ulSeqNo++;
		
		if(TDISC_NO_CYCLIC_RWr == ulLastDiscNo) {
			stheadRWr1.ulInfomation |= 0x00000080;
		}
		
		stheadRWr1.ulInfomation |= 0x0000FF00;
		stheadRWr1.ulInfomation |= (0x00FF0000 & (RX->CYC_MASTER_ID_RCV << 20));
		stheadRWr1.ulInfomation |= (ULONG)(gusR_IN32S_SwapS((USHORT)ulRWr1Size)) << 16;

		stheadRWr1.ulOffsetAddress = p_frame->PRAMDATA.ulRWrOffsetAddress;

		gR_IN32S_Memcpy( (void *)&(CYCMAP->auchCyclicSndHeader[TDISC_NO_CYCLIC_RWr]), (void *)&stheadRWr1, sizeof(stheadRWr1));

		*(ULONG*)&stTmpTDISC2 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC2));
		stTmpTDISC2.b0BZSendSize = (ulRWr1Size * 4) + 40 + 4;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC2),*(ULONG*)&stTmpTDISC2);

		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_ON;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}
	else {
		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}
	

	if(0 != ulRWr2Size) {
		*(ULONG*)&stheadRWr2 = ulAdr0;
		*((ULONG*)(&stheadRWr2) + 1) = ulAdr1;
		*((ULONG*)(&stheadRWr2) + 2) = ulAdr2;

		stheadRWr2.usType = FRAME_COM_FRMTYPE;
		stheadRWr2.FRAME_INFO.b4ZProtocolClassifcation = R_IN32U_PROTOCOL_CLASS;
		stheadRWr2.FRAME_INFO.b4ZProtocolVersion = R_IN32U_PROTOCOL_VER;

		stheadRWr2.usMyStationNumber = gusR_IN32S_SwapS((USHORT)(GMAC->ulNum));
		stheadRWr2.usNodeID = gusR_IN32S_SwapS((USHORT)gulR_IN32D_GetNodeID());

		stheadRWr2.uchFrameClassification = FTYPE_CyclicRWr;
		stheadRWr2.ulInfomation = 0;
		stheadRWr2.ulInfomation |= ulSeqNo;
		ulSeqNo++;
		if((TDISC_NO_CYCLIC_RWr + 1) == ulLastDiscNo) {
			stheadRWr2.ulInfomation |= 0x00000080;
		}
		stheadRWr2.ulInfomation |= 0x0000FF00;
		stheadRWr2.ulInfomation |= (0x00FF0000 & (RX->CYC_MASTER_ID_RCV << 20));
		stheadRWr2.ulInfomation |= (ULONG)(gusR_IN32S_SwapS((USHORT)ulRWr2Size)) << 16;
		stheadRWr2.ulOffsetAddress = p_frame->PRAMDATA.ulRWrOffsetAddress + gulR_IN32S_SwapL((ULONG)(0x16F * 4));

		gR_IN32S_Memcpy( (void *)&(CYCMAP->auchCyclicSndHeader[TDISC_NO_CYCLIC_RWr + 1]), (void *)&stheadRWr2, sizeof(stheadRWr2));

		*(ULONG*)&stTmpTDISC2 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC2));
		stTmpTDISC2.b0BZSendSize = (ulRWr2Size * 4) + 40 + 4;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC2),*(ULONG*)&stTmpTDISC2);

		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_ON;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}
	else {
		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RWr + 1].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}

	if(0 != ulRXSize) {
		*(ULONG*)&stheadRX = ulAdr0;
		*((ULONG*)(&stheadRX) + 1) = ulAdr1;
		*((ULONG*)(&stheadRX) + 2) = ulAdr2;

		stheadRX.usType = FRAME_COM_FRMTYPE;
		stheadRX.FRAME_INFO.b4ZProtocolClassifcation = R_IN32U_PROTOCOL_CLASS;
		stheadRX.FRAME_INFO.b4ZProtocolVersion = R_IN32U_PROTOCOL_VER;

		stheadRX.usMyStationNumber = gusR_IN32S_SwapS((USHORT)(GMAC->ulNum));
		stheadRX.usNodeID = gusR_IN32S_SwapS((USHORT)gulR_IN32D_GetNodeID());

		stheadRX.uchFrameClassification = FTYPE_CyclicRX;
		stheadRX.ulOffsetAddress = p_frame->PRAMDATA.ulRXOffsetAddress;
		stheadRX.ulInfomation |= ulSeqNo;
		if(TDISC_NO_CYCLIC_RX == ulLastDiscNo) {
			stheadRX.ulInfomation |= 0x00000080;
		}
		ulSeqNo++;
		stheadRX.ulInfomation |= ((ULONG)p_frame->PRAMDATA.uchRXFrameByteEnableInfo << 8);
		stheadRX.ulInfomation |= (0x00FF0000 & (RX->CYC_MASTER_ID_RCV << 20));
		stheadRX.ulInfomation |= (ULONG)(gusR_IN32S_SwapS((USHORT)ulRXSize)) << 16;

		gR_IN32S_Memcpy( (void *)&(CYCMAP->auchCyclicSndHeader[TDISC_NO_CYCLIC_RX]), (void *)&stheadRX, sizeof(stheadRX));

		*(ULONG*)&stTmpTDISC2 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC2));
		stTmpTDISC2.b0BZSendSize = gstR_IN32D_RefreshSize.ulRxByteSize+ 40 + 4;
				
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC2),*(ULONG*)&stTmpTDISC2);

		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_ON;

		if(0x00 == (0x03 & p_frame->PRAMDATA.uchRXFrameByteEnableInfo)){
			stTmpTDISC1.b01ZAlignment = R_IN32_ON;
		}
		else{
			stTmpTDISC1.b01ZAlignment = R_IN32_OFF;
		}

		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}
	else {
		*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC1));
		stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
		OUT32(&(TD->aTD_TDS[TDISC_NO_CYCLIC_RX].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	}

	return( R_IN32D_OK );
}


/*** EOF ***/
