/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_MACIP.c                                                   */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_MACIP.h"


VOID R_IN32T_MACIP_MIBClear( VOID )
{


	GMAC->MAC_IP1.ulMib_Ip_Clr = MIB_CLR_REG_MIB_CLR;


	GMAC->MAC_IP2.ulMib_Ip_Clr = MIB_CLR_REG_MIB_CLR;


	return;
}

ERRCODE erR_IN32T_MACIP_LoopBackEnable(
	R_IN32T_PORT_SEL_ENUM	ePort	
)
{
	ULONG			ulWriteData;		
	ULONG			ulPort;				
	ERRCODE			erResult;			


	if ( R_IN32T_E_PORT1 == ePort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erResult = gerR_IN32D_MACIP_PHYRead( ulPort, R_IN32D_PHYREG_CTRL, &ulWriteData );

	if ( R_IN32D_OK == erResult ) {

		ulWriteData |= R_IN32D_MDIO_CTRL_LOOPBACK_EN;

		erResult = gerR_IN32D_MACIP_PHYWrite( ulPort, R_IN32D_PHYREG_CTRL, ulWriteData );
	}
	else {
	}

	if ( R_IN32D_OK == erResult ) {
		erResult = R_IN32_OK;
	}
	else {
		erResult = R_IN32_ERR;
	}

	return( erResult );
}

ERRCODE erR_IN32T_MACIP_LoopBackDisable(
	R_IN32T_PORT_SEL_ENUM	ePort	
)
{
	ULONG			ulWriteData;		
	ULONG			ulPort;				
	ERRCODE			erResult;			


	if ( R_IN32T_E_PORT1 == ePort ) {
		ulPort = R_IN32D_PORT1;
	}
	else {
		ulPort = R_IN32D_PORT2;
	}

	erResult = gerR_IN32D_MACIP_PHYRead( ulPort, R_IN32D_PHYREG_CTRL, &ulWriteData );

	if ( R_IN32D_OK == erResult ) {

		ulWriteData &= (~R_IN32D_MDIO_CTRL_LOOPBACK_EN);

		erResult = gerR_IN32D_MACIP_PHYWrite( ulPort, R_IN32D_PHYREG_CTRL, ulWriteData );	
	}
	else {
	}

	if ( R_IN32D_OK == erResult ) {
		erResult = R_IN32_OK;
	}
	else {
		erResult = R_IN32_ERR;
	}

	return( erResult );
}

/*** EOF ***/
