###########################################################################################
  R-IN32M4 Interval timer Sample Program

                                            Renesas Electronics Corporation   Nov 01, 2019
###########################################################################################

 NOTICE 
   This software is just for reference sample software, 
   Renesas does NOT gurantee the operation.
   Please use this software, after you thoroughly check and evaluate on your enviroment.

 =============================================================================== 
  Abstract 
 =============================================================================== 
 This sample program is simple program which is to check the interval timer operation.
 
 When executing this sample program on the evaluation board TS-TCS07908, 
 comment out "TS_TCS08467" in RIN32M4.h.
 The initial setting is for the evaluation board TS-TCS08467.
 
  \Device\Renesas\RIN32M4\Include\RIN32M4.h
  
 =============================================================================== 
  Operation summary 
 =============================================================================== 
 This sample software conducts the operation of timer, and turning on/off LEDs when timer
 interrupt occurs. The operation of timer starts/stops when the 's' or 'S' key is pressed.
 First key input triggers to stop timer, because timer has already started.

 In this sample program, timer 3rd channel is used and interval of time is 100ms.

 =============================================================================== 
  Application sample 
 =============================================================================== 
 ====== Driver API ====== 
  - uart_init           : UART initialization 
  - timer_interval_init : Interval timer mode initialization
  - timer_start         : Start timer
  - timer_stop          : Stop timer
  - timer_check_act     : Check the operating status of timer

 ====== Operation interpretation ====== 
 The operation of this sample conducts the following procedure. 
  1. Initialization *1
    - LED port 
    - Interval timer
    - UART
  2. Opening message output
  3. Interval timer starts
  4. Commands input operation, or interrupt operation
    - In case of command 's' or 'S' input
      - Odd number of times input  : Stop timer
      - Even number of times input : Start timer
    - In case the timer interrupt (TAUJ0I3_IRQHandler()) occurs
      - Specified LED inverts
      - Count the interrupt, and elapsed time outputs.

====== Result of operation ======

Interval timer Sample       <- Opening message
 --------[ms] *2
Interval timer STOP.        <- 1st input command

Interval timer RESTART.     <- 2nd input command
 --------[ms] *2
Interval timer STOP.        <- 3rd input command

====== Notes ======
 *1 : Specify "ch" (the timer channel number), "i_timer" (interval of time).
      "ch" is able to set channel 0 to channel 3.
      "i_timer" is able to have 1 to 42949(ms).
 *2 : "--------[ms]" output has the time taken from system clock.
      This output and LED are updated every interrupt.

