/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_sub.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_sub_l.h"


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/
typedef struct _R_IN32D_FATALERROR_FIFO_TAG {
	R_IN32D_FATALERROR_T	astBuffer[R_IN32D_FATALERROR_LOGNUM];
	ULONG				ulWriteIndex;		
	ULONG				ulReadIndex;		
} R_IN32D_FATALERROR_FIFO_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
R_IN32D_FATALERROR_FIFO_T		gstR_IN32D_FatalErrorFIFO;	


ERRCODE erR_IN32D_InitFatalErrorFIFO( VOID )
{
	ULONG i;

	for(i=0; R_IN32D_FATALERROR_LOGNUM > i; i++){
		gstR_IN32D_FatalErrorFIFO.astBuffer[i].ulErrorCode = 0UL;
		gstR_IN32D_FatalErrorFIFO.astBuffer[i].ulErrorInfo = 0UL;
	}
	gstR_IN32D_FatalErrorFIFO.ulWriteIndex = 1UL;
	gstR_IN32D_FatalErrorFIFO.ulReadIndex = 0UL;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_SetFatalError(
	R_IN32D_FATALERROR_T*	pstSrc	
)
{
	ERRCODE	erResult = R_IN32D_OK;

	gR_IN32R_DisableInt();

	if (gstR_IN32D_FatalErrorFIFO.ulWriteIndex != gstR_IN32D_FatalErrorFIFO.ulReadIndex) {

		gstR_IN32D_FatalErrorFIFO.astBuffer[gstR_IN32D_FatalErrorFIFO.ulWriteIndex].ulErrorCode = pstSrc->ulErrorCode;
		gstR_IN32D_FatalErrorFIFO.astBuffer[gstR_IN32D_FatalErrorFIFO.ulWriteIndex].ulErrorInfo = pstSrc->ulErrorInfo;


		gstR_IN32D_FatalErrorFIFO.ulWriteIndex++;

		if (R_IN32D_FATALERROR_LOGNUM == gstR_IN32D_FatalErrorFIFO.ulWriteIndex) {
			gstR_IN32D_FatalErrorFIFO.ulWriteIndex = 0UL;
		}
		else {
		}
	}
	else {
		erResult = R_IN32D_NG_OVERFLOW;
	}

	gR_IN32R_EnableInt();

	return( erResult );
}

ERRCODE gerR_IN32D_GetFatalError(
	R_IN32D_FATALERROR_T*	pstDst	
)
{
	ULONG	ulReadIndex;
	ERRCODE	erResult = R_IN32D_OK;

	gR_IN32R_DisableInt();

	ulReadIndex = gstR_IN32D_FatalErrorFIFO.ulReadIndex;
	ulReadIndex++;
	if (R_IN32D_FATALERROR_LOGNUM == ulReadIndex) {
		ulReadIndex = 0UL;
	}
	else {
	}

	if (gstR_IN32D_FatalErrorFIFO.ulWriteIndex != ulReadIndex) {

		pstDst->ulErrorCode = gstR_IN32D_FatalErrorFIFO.astBuffer[ulReadIndex].ulErrorCode;
		pstDst->ulErrorInfo = gstR_IN32D_FatalErrorFIFO.astBuffer[ulReadIndex].ulErrorInfo;

		gstR_IN32D_FatalErrorFIFO.ulReadIndex = ulReadIndex;
	}
	else {
		erResult = R_IN32D_NG_EMPTY;
	}

	gR_IN32R_EnableInt();

	return( erResult );
}

/*** EOF ***/
