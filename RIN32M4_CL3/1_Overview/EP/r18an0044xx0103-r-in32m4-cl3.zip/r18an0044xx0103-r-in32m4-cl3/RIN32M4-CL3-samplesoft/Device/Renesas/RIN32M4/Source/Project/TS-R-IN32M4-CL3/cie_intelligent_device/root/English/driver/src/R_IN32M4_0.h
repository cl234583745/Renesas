/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_0.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_0_H_INCLUDED_
#define __R_IN32M4_0_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_1.h"
#include "R_IN32M4_3.h"
#include "R_IN32M4_2.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define	ASIC_BIT0							(0x00000001UL)		
#define	ASIC_BIT1							(0x00000002UL)		
#define	ASIC_BIT2							(0x00000004UL)		
#define	ASIC_BIT3							(0x00000008UL)		
#define	ASIC_BIT4							(0x00000010UL)		
#define	ASIC_BIT5							(0x00000020UL)		
#define	ASIC_BIT6							(0x00000040UL)		
#define	ASIC_BIT7							(0x00000080UL)		
#define	ASIC_BIT8							(0x00000100UL)		
#define	ASIC_BIT9							(0x00000200UL)		
#define	ASIC_BIT10							(0x00000400UL)		
#define	ASIC_BIT11							(0x00000800UL)		
#define	ASIC_BIT12							(0x00001000UL)		
#define	ASIC_BIT13							(0x00002000UL)		
#define	ASIC_BIT14							(0x00004000UL)		
#define	ASIC_BIT15							(0x00008000UL)		
#define	ASIC_BIT16							(0x00010000UL)		
#define	ASIC_BIT17							(0x00020000UL)		
#define	ASIC_BIT18							(0x00040000UL)		
#define	ASIC_BIT19							(0x00080000UL)		
#define	ASIC_BIT20							(0x00100000UL)		
#define	ASIC_BIT21							(0x00200000UL)		
#define	ASIC_BIT22							(0x00400000UL)		
#define	ASIC_BIT23							(0x00800000UL)		
#define	ASIC_BIT24							(0x01000000UL)		
#define	ASIC_BIT25							(0x02000000UL)		
#define	ASIC_BIT26							(0x04000000UL)		
#define	ASIC_BIT27							(0x08000000UL)		
#define	ASIC_BIT28							(0x10000000UL)		
#define	ASIC_BIT29							(0x20000000UL)		
#define	ASIC_BIT30							(0x40000000UL)		
#define	ASIC_BIT31							(0x80000000UL)		



#define	R_IN32M4_BASE_ADR	R_IN32_BASE_ADR			

#define	INTRST		((volatile INTRST_T		*)(R_IN32M4_BASE_ADR + 0x00700))	
#define	EMGDBG		((volatile EMGDBG_T		*)(R_IN32M4_BASE_ADR + 0x00900))	
#define	TD			((volatile TD_T			*)(R_IN32M4_BASE_ADR + 0x04000))	
#define	TX			((volatile TX_T			*)(R_IN32M4_BASE_ADR + 0x06100))	
#define	RX			((volatile RX_T			*)(R_IN32M4_BASE_ADR + 0x08000))	
#define	RD			((volatile RD_T			*)(R_IN32M4_BASE_ADR + 0x0A000))	
#define	RING		((volatile RING_T		*)(R_IN32M4_BASE_ADR + 0x0C000))	
#define	GMAC		((volatile GIGAMAC_T	*)(R_IN32M4_BASE_ADR + 0x10000))	
#define	SC			((volatile SC_T			*)(R_IN32M4_BASE_ADR + 0x14000))	
#define	CYCMAP		((volatile CYCMAP_T		*)(R_IN32M4_BASE_ADR + 0x20000))	
#define	TRNMAP		((volatile TRNMAP_T		*)(R_IN32M4_BASE_ADR + 0x24000))	
#define	CTLMAP		((volatile CTLMAP_T		*)(R_IN32M4_BASE_ADR + 0x27000))	
#define	LED			((volatile LED_T		*)(0x400F1860))	


#endif	/* __R_IN32M4_0_H_INCLUDED_ */

/*** EOF ***/
