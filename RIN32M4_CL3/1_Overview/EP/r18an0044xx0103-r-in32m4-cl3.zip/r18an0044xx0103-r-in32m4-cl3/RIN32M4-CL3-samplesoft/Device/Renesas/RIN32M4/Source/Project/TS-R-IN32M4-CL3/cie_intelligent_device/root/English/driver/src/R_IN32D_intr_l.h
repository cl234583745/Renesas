/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_intr_l.h                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_INTR_L_H_INCLUDED__
#define __R_IN32D_INTR_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_0.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32D_LOOPMAX_COUNT   (75UL)


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/


typedef union _R_IN32D_INT_TAG {								
	USHORT				usAll;
	INT_T				stBit;
} R_IN32D_INT_T;

typedef union _R_IN32D_INT1_TAG {								
	USHORT				usAll;
	INT1_T				stBit;
} R_IN32D_INT1_T;

typedef union _R_IN32D_NSRINT_TAG {							
	USHORT				usAll;
	NSRINT_T			stBit;
} R_IN32D_NSRINT_T;

typedef union _R_IN32D_INT2_TAG {								
	ULONG				ulAll;
	INT2_T				stBit;
} R_IN32D_INT2_T;

typedef union _R_IN32D_ITRCV_TAG {								
	ULONG				ulAll;
	ITRCV_TAG				stBit;
} R_IN32D_ITRCV_T;
typedef union _R_IN32D_TX_INTL_TAG {								
	ULONG				ulAll;
	TX_INTL_TAG			stBit;
} R_IN32D_TX_INTL_T;

typedef struct _R_IN32D_INTR_SOURCE_TAG {											
	R_IN32D_ITRCV_T			uniITRCV;
	R_IN32D_TX_INTL_T		uniTX_INTL;
	R_IN32D_NSRINT_T		uniNSRINT;							

	R_IN32D_INT2_T			uniINT2;							

} R_IN32D_INTR_SOURCE_T;


typedef union _R_IN32D_SYNCINT_TAG {
	ULONG						ulAll;
	R_SYNCINT_T					stBit;
} R_IN32D_SYNCINT_T;

typedef struct _R_IN32D_SYNCINTR_SOURCE_TAG {
	R_IN32D_SYNCINT_T			uniSYNCINT;
} R_IN32D_SYNCINTR_SOURCE_T;


/****************************************************************************/
/* Functions (for R_IN32D)                                                     */
/****************************************************************************/
extern ERRCODE erR_IN32D_InitIntrAfterReset( VOID );
extern ERRCODE erR_IN32D_ClearINT1_2All( VOID );
extern ERRCODE erR_IN32D_MaskINT1_2All( VOID );
extern ERRCODE erR_IN32D_UnMaskINT1_2( VOID );
extern ERRCODE erR_IN32D_FetchINT1_2( R_IN32D_INTR_SOURCE_T* );
extern ERRCODE erR_IN32D_ClearINT1_2( R_IN32D_INTR_SOURCE_T* );
extern ERRCODE erR_IN32D_ClearSYNCINTLAll( VOID );
extern ERRCODE erR_IN32D_MaskSYNCINTLAll( VOID );
extern ERRCODE erR_IN32D_UnMaskInSYNCINTL( VOID );
extern ERRCODE erR_IN32D_UnMaskOutSYNCINTL( VOID );
extern ERRCODE erR_IN32D_FetchSYNCINTL( R_IN32D_SYNCINTR_SOURCE_T* );
extern ERRCODE erR_IN32D_ClearSYNCINTL( R_IN32D_SYNCINTR_SOURCE_T* );

#endif /* __R_IN32D_INTR_L_H_INCLUDED__ */

/*** EOF ***/
