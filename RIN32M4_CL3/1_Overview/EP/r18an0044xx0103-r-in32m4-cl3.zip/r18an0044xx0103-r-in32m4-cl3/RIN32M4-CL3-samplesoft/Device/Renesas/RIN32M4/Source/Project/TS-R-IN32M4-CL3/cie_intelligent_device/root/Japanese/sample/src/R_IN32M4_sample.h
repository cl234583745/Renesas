/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_sample.h                                                  */
/** @brief  R_IN32M4 driver user sample code                                   */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_SAMPLE_H_INCLUDED_
#define __R_IN32M4_SAMPLE_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define USER_OK		0
#define USER_ERR	(-1)

#define USER_FATALERROR_NUM			8UL		/* Fatal�G���[�̃��X�g�e�� */



#define USER_BUFFER_MEMORY_TAIL			((USHORT)0x0BB8)	/* �o�b�t�@�������[�I�[ */
#define USER_BUFFER_MEMORY_SIZE			((USHORT)0x0BB8)	/* �o�b�t�@�������[�T�C�Y */
#define USER_DATA_SIZE_IN_FRAME			((USHORT)0x03C0)	/* �t���[�����f�[�^�T�C�Y */

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

/* MAC �A�h���X */
extern UCHAR	gauchUserMACAddress[];

/* ����t���O */
extern BOOL		gblUserR_IN32M4WDT_Enable;

/* Fatal�G���[ */
extern ULONG	gulUserFatalErrorNum;						/* Fatal�G���[�̔����� */
extern ULONG	gulUserFatalError[USER_FATALERROR_NUM][2];	/* Fatal�G���[�̃��X�g */
															/*  [*][0]: Fatal�G���[�R�[�h */
															/*  [*][1]: Fatal�G���[���(�G���[�������֐��̃A�h���X) */


extern UCHAR	gauchBufferMemory[USER_BUFFER_MEMORY_SIZE];	/* �o�b�t�@������ */

extern USHORT	gusUserNodeNumber;							/* �ǔ� */
extern UCHAR	guchUserNetworkNumber;						/* NW No.*/
extern ULONG	gulCommandFromMaster;						/* �}�X�^�ǂ���̃R�}���h*/


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
extern INT  iUserInitialization( VOID );


#endif	/* __R_IN32M4_SAMPLE_H_INCLUDED_ */

/*** EOF ***/
