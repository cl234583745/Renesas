/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_tran.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_FrmForm.h"
#include "R_IN32D_tran_l.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_MAXIMUMFRMSIZE_CCIE		1510	

#define R_IN32D_NOPRETDIS			(UCHAR)255		
#define R_IN32D_TDISCHECKEND		0xFFFFFFFFUL	
#define R_IN32D_STSCHK_INI			0xFFFFFFFFUL	


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
UCHAR	guchR_IN32D_PreTDIS;						
ULONG	gulR_IN32D_StsTDIS;						

ULONG	gaulR_IN32D_CheckStartTDIS_Ring[TD_TRAN_NUM];	
ULONG	gulR_IN32D_CheckStartTDIS_SetPoint;			
ULONG	gulR_IN32D_CheckStartTDIS_ChkPoint;			

ULONG	gulR_IN32D_ReadRDIS;						
ULONG	gulR_IN32D_ClearRDIS;						
ULONG	gulR_IN32D_GetRDISNum;						


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE erR_IN32D_SearchUnusedTranTDIS( USHORT, VOID**, UCHAR* );	


ERRCODE erR_IN32D_InitTranSndInf( VOID )
{
	ULONG					ulCount;

	guchR_IN32D_PreTDIS = R_IN32D_NOPRETDIS;	
	gulR_IN32D_StsTDIS = R_IN32D_STSCHK_INI;	

	gulR_IN32D_CheckStartTDIS_SetPoint = 0UL;	
	gulR_IN32D_CheckStartTDIS_ChkPoint = 0UL;	

	for ( ulCount = 0UL; ulCount < (ULONG)TD_TRAN_NUM; ulCount++ ) {
		gaulR_IN32D_CheckStartTDIS_Ring[ulCount] = R_IN32D_TDISCHECKEND;	
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetTranTDIS(
	USHORT	usSize,					
	VOID**	ppvSendFrmAdr,			
	UCHAR*	puchTDISNo				
)
{
	ULONG	ulRingPhase;	
	ERRCODE	erResult;		
	VOID*	pSendFrm;		
	UCHAR	uchTDISNo;		


	ulRingPhase = RING->ulRingPhase;
	if ( (ulRingPhase != RINGPHASE_REG_PHASE_SOLISITTOKEN)
			&& (ulRingPhase != RINGPHASE_REG_PHASE_HOLDTOKEN)) {
		return( R_IN32D_NG );
	}
	else {
	}

	erResult = erR_IN32D_SearchUnusedTranTDIS(usSize, &pSendFrm, &uchTDISNo);

	if (erResult == R_IN32D_OK) {		
		*ppvSendFrmAdr = pSendFrm;
		*puchTDISNo    = uchTDISNo;
	}
	else {							
	}

	return( erResult );
}

ERRCODE erR_IN32D_SearchUnusedTranTDIS(
	USHORT	usSize,				
	VOID**	ppSendFrmAdr,		
	UCHAR*	puchTDIS			
)
{
	ERRCODE	erResult;

	erResult = R_IN32D_NODIS;


	

	*ppSendFrmAdr = (VOID *)&TRNMAP->auchTransientSndRAM1520[0];
	*puchTDIS = TDISC_NO_TRANSIENT;

	erResult = R_IN32D_OK;



	return( erResult );
}

ERRCODE gerR_IN32D_EntryTranTDIS(
	UCHAR	uchTDISNo,		
	USHORT	usSize			
)
{
	ULONG				ulRingPhase;
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TDISC3_TAG	stTmpTDISC3;
	R_TXCNT_TAG		stTXCNT;


	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));
	gR_IN32S_Memset(&stTmpTDISC3, 0x00, sizeof(R_TDISC3_TAG));
	gR_IN32S_Memset(&stTXCNT, 0x00, sizeof(R_TXCNT_TAG));

	*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[uchTDISNo].R_TDISC1));
	*(ULONG*)&stTmpTDISC2 = IN32(&(TD->aTD_TDS[uchTDISNo].R_TDISC2));
	*(ULONG*)&stTmpTDISC3 = IN32(&(TD->aTD_TDS[uchTDISNo].R_TDISC3));
	__BUS_RELEASE();
	*(ULONG*)&stTXCNT = 	IN32(&(TX->TXCNT));

	ulRingPhase = RING->ulRingPhase;
	if ( (ulRingPhase != RINGPHASE_REG_PHASE_SOLISITTOKEN)
			&& (ulRingPhase != RINGPHASE_REG_PHASE_HOLDTOKEN) ) {
		return( R_IN32D_NG );
	}
	else {
	}
	
	if (( R_IN32_ON == TX->aR_TDISS[uchTDISNo].b01ZSendNormalEnd )	||
		( R_IN32_ON == TX->aR_TDISS[uchTDISNo].b01ZSendAbNormalEnd ))	{	
		return( R_IN32D_BUSY );
	}
	
	
	while (TX->R_TXSTART.b01ZSendStart == R_IN32_ON){
	}

	stTmpTDISC1.b02ZFrmType = 0x01;
	stTmpTDISC1.b01ZSendFrmExperienced = (ULONG)R_IN32_ON;
	stTmpTDISC1.b01ZLastDiscriptorFlag = R_IN32_ON;
	stTmpTDISC2.b0BZSendSize = (ULONG)usSize + 4;
	
	
	OUT32(&(TD->aTD_TDS[uchTDISNo].R_TDISC2),*(ULONG*)&stTmpTDISC2);
	OUT32(&(TD->aTD_TDS[uchTDISNo].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	
	

	gaulR_IN32D_CheckStartTDIS_Ring[gulR_IN32D_CheckStartTDIS_SetPoint] = (ULONG)uchTDISNo;
	gulR_IN32D_CheckStartTDIS_SetPoint++;
	if ( (ULONG)TD_TRAN_NUM <= gulR_IN32D_CheckStartTDIS_SetPoint ) {
		gulR_IN32D_CheckStartTDIS_SetPoint = 0UL;
	}
	else {
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetTranSndSts(
	UCHAR*	puchTDISNo,			
	ULONG*	pulSts				
)
{
	ULONG			ulClearTDIS;
	R_TDISC1_TAG	stTmpTDISC1;
	R_TDISC2_TAG	stTmpTDISC2;
	R_TXCNT_TAG		stTXCNT;
	R_TXSTART_TAG	stTXSTART;

	gR_IN32S_Memset(&stTXCNT, 0x00, sizeof(R_TXCNT_TAG));

	*(ULONG*)&stTXCNT = 	IN32(&(TX->TXCNT));
	*(ULONG*)&stTXSTART = 	IN32(&(TX->R_TXSTART));

	gR_IN32S_Memset(&stTmpTDISC1, 0x00, sizeof(R_TDISC1_TAG));
	gR_IN32S_Memset(&stTmpTDISC2, 0x00, sizeof(R_TDISC2_TAG));

	ulClearTDIS = gaulR_IN32D_CheckStartTDIS_Ring[gulR_IN32D_CheckStartTDIS_ChkPoint];

	if ( R_IN32D_TDISCHECKEND == ulClearTDIS ) {	
		return( R_IN32D_NODATA );
	}


	gaulR_IN32D_CheckStartTDIS_Ring[gulR_IN32D_CheckStartTDIS_ChkPoint] = R_IN32D_TDISCHECKEND;

	gulR_IN32D_CheckStartTDIS_ChkPoint++;
	if ( (ULONG)TD_TRAN_NUM <= gulR_IN32D_CheckStartTDIS_ChkPoint ) {
		gulR_IN32D_CheckStartTDIS_ChkPoint = 0UL;
	}
	else {
	}
	
	*(ULONG*)&stTmpTDISC1 = IN32(&(TD->aTD_TDS[ulClearTDIS].R_TDISC1));

	*puchTDISNo = (UCHAR)ulClearTDIS;

	if ( R_IN32_ON == TX->aR_TDISS[ulClearTDIS].b01ZSendNormalEnd ) {			
		*pulSts = R_IN32D_TDIS_TXOK;
	}
	else if ( R_IN32_ON == TX->aR_TDISS[ulClearTDIS].b01ZSendAbNormalEnd ) {	
		*pulSts = R_IN32D_TDIS_TXERR;
	}
	else {												
		*pulSts = R_IN32D_TDIS_NG;
	}

	stTmpTDISC1.b01ZSendFrmExperienced = R_IN32_OFF;
	
	stTXSTART.b01ZSendStart = R_IN32_OFF;
	stTXSTART.b01ZSenddscpltClr = R_IN32_ON;
	stTXSTART.b01ZSendStopFunction = R_IN32_OFF;

	
	OUT32(&(TD->aTD_TDS[ulClearTDIS].R_TDISC1),*(ULONG*)&stTmpTDISC1);
	OUT32(&(TD->aTD_TDS[ulClearTDIS].R_TDISC2),*(ULONG*)&stTmpTDISC2);

	stTXSTART.b01ZSendStart = R_IN32_OFF;
	stTXSTART.b01ZSenddscpltClr = R_IN32_ON;
	stTXSTART.b01ZSendStopFunction = R_IN32_OFF;

	OUT32(&(TX->R_TXSTART),*(ULONG*)&stTXSTART);

	stTXSTART.b01ZSenddscpltClr = R_IN32_OFF;

	OUT32(&(TX->R_TXSTART),*(ULONG*)&stTXSTART);


	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_InitTranRcvInf( VOID )
{
	gulR_IN32D_ReadRDIS = 0UL;		
	gulR_IN32D_ClearRDIS = 0UL;	
	gulR_IN32D_GetRDISNum = 0UL;	

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetRcvTran(
	ULONG*	pulSize,		
	VOID**	ppRcvbuf		
)
{
	ERRCODE		erResult;		
	UCHAR*		pBufPointer;	

	if ( RDIS1_OWNRDISCRIPTERUSED == (RDIS1_OWNRDISCRIPTERUSED & RD->astRD_NCYC[ gulR_IN32D_ReadRDIS ].RD_RDIS1.uniRdis1.usAll) ) {	

		pBufPointer = (UCHAR*)&TRNMAP->auchTransientRcvRAM[0];
		pBufPointer += (RDIS2_BUF_ADDR_MASK & RD->astRD_NCYC[ gulR_IN32D_ReadRDIS ].RD_RDIS2.uniRdis2.usAll);

		*pulSize = (RDIS1_REC_DATA_SIZE_MASK & RD->astRD_NCYC[ gulR_IN32D_ReadRDIS ].RD_RDIS1.uniRdis1.usAll);
		*ppRcvbuf = pBufPointer;

		gulR_IN32D_ReadRDIS++;
		if ( RD_NCYC_MAXNUM <= gulR_IN32D_ReadRDIS ) {
			gulR_IN32D_ReadRDIS = 0UL;
		}
		else {
		}

		gulR_IN32D_GetRDISNum++;

		erResult = R_IN32D_OK;
	}
	else {																	
		erResult = R_IN32D_NODATA;
	}

	return( erResult );
}

ERRCODE gerR_IN32D_SetRcvTranFin( VOID )
{
	ERRCODE		erResult;		
	RD_RDS_T	stRegData;

	if ( 0UL < gulR_IN32D_GetRDISNum ) {

		*((ULONG*)&stRegData) = IN32( &(RD->astRD_NCYC[ gulR_IN32D_ClearRDIS ]) );
		stRegData.RD_RDIS1.uniRdis1.stBit.b1ZOWNBit = (USHORT)R_IN32_OFF;
		OUT32(&(RD->astRD_NCYC[ gulR_IN32D_ClearRDIS ]), *((ULONG*)&stRegData));

		gulR_IN32D_ClearRDIS++;
		if ( RD_NCYC_MAXNUM <= gulR_IN32D_ClearRDIS ) {
			gulR_IN32D_ClearRDIS = 0UL;
		}
		else {
		}


		gulR_IN32D_GetRDISNum--;
		erResult = R_IN32D_OK;
	}
	else {
		erResult = R_IN32D_NODATA;
	}

	return( erResult );
}

/*** EOF ***/
