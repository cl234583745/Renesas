/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_RcvCnt.c                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32C_l.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_RcvCnt_l.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
ULONG					gulR_IN32D_RcvMyStatus = 0UL;	

R_IN32D_SETUP_RCV_T		gstR_IN32D_SetupRcv;			


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE erR_IN32D_FetchMultiCastAddr( ULONG* );
static ERRCODE erR_IN32D_FetchNodeID( SETUP_INF_REG0_T* );
static ERRCODE erR_IN32D_FetchSetupInf3( SETUP_INF_REG3_T* );
static ERRCODE erR_IN32D_FetchNetMotion( SETUP_INF_REG4_T* );


ULONG gulR_IN32D_GetPortValidInf( VOID )
{
	ULONG				ulPortValid;		

	ulPortValid = gstR_IN32D_SetupRcv.stSetup_Inf3.b08ZSu_Inf6;


	return( ulPortValid );
}

ERRCODE gerR_IN32D_GetMultiCastAddr(
	UCHAR*	puchAdr		
)
{
	UCHAR*		puchTemp;


	puchTemp = (UCHAR*)&gstR_IN32D_SetupRcv.aulMultiCastAdrs[0];
	puchAdr[0] = puchTemp[0];
	puchAdr[1] = puchTemp[1];
	puchAdr[2] = puchTemp[2];
	__BUS_RELEASE();
	puchAdr[3] = puchTemp[3];

	puchTemp = (UCHAR*)&gstR_IN32D_SetupRcv.aulMultiCastAdrs[1];
	puchAdr[4] = puchTemp[0];
	puchAdr[5] = puchTemp[1];

	return( R_IN32D_OK );
}

ULONG gulR_IN32D_GetNodeID( VOID )
{
	ULONG				ulNodeID;		

	ulNodeID = ((SU_INF_SETUP_FRAME_NODE_ID_MASK & gstR_IN32D_SetupRcv.SETUP_INF_REG0.ulData) >> SU_INF_SETUP_FRAME_NODE_ID_SHIFT);

	return( ulNodeID );
}

ERRCODE gerR_IN32D_GetNetMotion(
	R_IN32D_NETMOTION_T*	pstNetMotion		
)
{
	pstNetMotion->ulTknHoldFrmSendCount = ((SU_INF_SETUP_FRAME_TOKEN_HOLDING_MASK & gstR_IN32D_SetupRcv.SETUP_INF_REG4.ulData) >> SU_INF_SETUP_FRAME_TOKEN_HOLDING_SHIFT );
	pstNetMotion->ulFramSendInterval    = ((SU_INF_SETUP_FRAME_SEND_TRANS_MASK & gstR_IN32D_SetupRcv.SETUP_INF_REG4.ulData) >> SU_INF_SETUP_FRAME_SEND_TRANS_SHIFT );
	pstNetMotion->ulTokenSendCount      = ( SU_INF_SETUP_FRAME_TOKEN_TRANS_MASK & gstR_IN32D_SetupRcv.SETUP_INF_REG4.ulData );

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchSetupRcv( VOID )
{
	(VOID)erR_IN32D_FetchMultiCastAddr( &gstR_IN32D_SetupRcv.aulMultiCastAdrs[0] );
	(VOID)erR_IN32D_FetchNodeID( &gstR_IN32D_SetupRcv.SETUP_INF_REG0.stSetup_Inf0 );
	__BUS_RELEASE();
	(VOID)erR_IN32D_FetchSetupInf3( &gstR_IN32D_SetupRcv.stSetup_Inf3 );
	(VOID)erR_IN32D_FetchNetMotion( &gstR_IN32D_SetupRcv.SETUP_INF_REG4.stSetup_Inf4 );

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchMultiCastAddr(
	ULONG*	pulMultiCastAdrs		
)
{
	pulMultiCastAdrs[0] = RING->ulMultiAddReg0;
	pulMultiCastAdrs[1] = RING->ulMultiAddReg1;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchNodeID(
	SETUP_INF_REG0_T*	pstNodeID	
)
{
	ULONG*		pulNodeID;

	pulNodeID = (ULONG*)pstNodeID;
	*pulNodeID = RING->ulSetup_Inf0;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchSetupInf3(
	SETUP_INF_REG3_T*	pstSetupInf3	
)
{
	ULONG*		pulSetupInf3;

	pulSetupInf3 = (ULONG*)pstSetupInf3;
	*pulSetupInf3 = RING->ulSetup_Inf3;

	return( R_IN32D_OK );
}

ERRCODE erR_IN32D_FetchNetMotion(
	SETUP_INF_REG4_T*	pstNetMotion	
)
{
	ULONG*		pulNetMotion;

	pulNetMotion = (ULONG*)pstNetMotion;
	*pulNetMotion = RING->ulSetup_Inf4;

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_GetMasterMyStatus(
	R_IN32D_MSTMYSTATUS_INFO_T*	pstMyStatus		
)
{
	volatile MYSTATUS_FRAME_REG_T*	pstMyStatusFrame;	
	volatile MYSTATUS_COMMAND_T*	pstCommand;			
	volatile MYSTATUS_SELF_STA_T*		pstSelfSTA;		
	ULONG								ulTemp;
	USHORT								usTemp;

	if(R_IN32C_MOTSYNC_WAIT != gstR_IN32C.stMotSyncCtl.ulSyncStatus){
	if( R_IN32_OFF == RX->RX_BANK_STS.b01ZCycRevBufferBankState ){
		pstMyStatusFrame = (volatile MYSTATUS_FRAME_REG_T*)&CTLMAP->auchControlFrmRcvRAM_A[0];
	}
	else {
		pstMyStatusFrame = (volatile MYSTATUS_FRAME_REG_T*)&CTLMAP->auchControlFrmRcvRAM_B[0];
	}
	}
	else{
		if( R_IN32_OFF != RX->RX_BANK_STS.b01ZCycRevBufferBankState ){
			pstMyStatusFrame = (volatile MYSTATUS_FRAME_REG_T*)&CTLMAP->auchControlFrmRcvRAM_A[0];
		}
		else {
			pstMyStatusFrame = (volatile MYSTATUS_FRAME_REG_T*)&CTLMAP->auchControlFrmRcvRAM_B[0];
		}
	}

	pstMyStatus->ulSyncFlg = (ULONG)pstMyStatusFrame->uchSyncFlag;

	usTemp = pstMyStatusFrame->usStationCommand;
	usTemp = gusR_IN32S_SwapS( usTemp );
	pstCommand = (volatile MYSTATUS_COMMAND_T*)&usTemp;
	pstMyStatus->ulUserAppRun = (ULONG)pstCommand->uniMyStaCmd.stBit.b1ZMasterStationUserApp;
	pstMyStatus->ulCondition  = (ULONG)pstCommand->uniMyStaCmd.stBit.b1ZMasterStationUserAppErr; 

	usTemp = pstMyStatusFrame->usMyStationUnitState;
	pstSelfSTA = (volatile MYSTATUS_SELF_STA_T*)&usTemp;
	pstMyStatus->ulTranRcvPropriety = (ULONG)pstSelfSTA->uniMyStaSelf.stBit.b1ZTranRecPropriety;	

	ulTemp = pstMyStatusFrame->ulMyStationErrorCode;
	ulTemp = gulR_IN32S_SwapL( ulTemp );
	pstMyStatus->ulErrorCode = ulTemp;

	pstMyStatus->ulSlaveEventRcvCond = (ULONG)pstMyStatusFrame->uchSlaveEventRcvCond;

	usTemp = pstMyStatusFrame->usSlaveEventRcvCondCount;
	usTemp = gusR_IN32S_SwapS( usTemp );
	pstMyStatus->ulSlaveEventRcvCondCount = (ULONG)usTemp;

	if(0 == TX->ulNET_NUM){

		gerR_IN32D_SetNetworkNumber(pstMyStatusFrame->uchTemporaryNetworkNumber);

		(VOID)gerR_IN32D_FetchStationNetworkNumber();
		gerR_IN32C_SeqMain_ChangeStationNetworkNumber();
	}
	gulR_IN32D_RcvMyStatus = 1UL;		
	
	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_FinGetMasterMyStatus( VOID )
{
	if ( 1UL == gulR_IN32D_RcvMyStatus ) {

		gulR_IN32D_RcvMyStatus = 0UL;		
	}
	else {
	}

	return( R_IN32D_OK );
}

/*** EOF ***/
