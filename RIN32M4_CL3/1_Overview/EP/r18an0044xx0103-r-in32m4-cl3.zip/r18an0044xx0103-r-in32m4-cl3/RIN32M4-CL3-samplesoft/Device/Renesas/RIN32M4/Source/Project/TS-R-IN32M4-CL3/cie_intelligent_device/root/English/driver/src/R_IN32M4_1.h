/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_1.h                                                       */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_1_H_INCLUDED_
#define __R_IN32M4_1_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_2.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/



#define	MACTXST_SENDSTART					(USHORT)ASIC_BIT0	
#define	MACTXST_SENDSTATUSABNORMALEND		(USHORT)ASIC_BIT1	

#define	TRAN_COUNTER_SEND_ENABLE_REMAIN		(USHORT)0x00FF		
#define	TRAN_COUNTER_REMAIN_NUM_SEND_RETRY	(USHORT)0xFF00		




#define	PORT_STATISTICS_PORTNABNORMAL		(USHORT)ASIC_BIT0	
#define	PORT_STATISTICS_PORTNDUALSNDRIGHT	(USHORT)ASIC_BIT1	
#define	PORT_STATISTICS_PORTNTOKENINJUST	(USHORT)ASIC_BIT2	
#define	PORT_STATISTICS_PORTNP1ABNORMAL		(USHORT)ASIC_BIT4	
#define	PORT_STATISTICS_PORTNP1DUALSNDRIGHT	(USHORT)ASIC_BIT5	
#define	PORT_STATISTICS_PORTNP1TOKENINJUST	(USHORT)ASIC_BIT6	

#define	SELF_CONTROL_4_SHIFT				16

#define	MSTS_TX_PERMISSION_SEND				(USHORT)ASIC_BIT0	

#define	CYC_TX_PERMISSION_SEND				(USHORT)ASIC_BIT0	

#define	TRAN_TX_PERMISSION_SEND				(USHORT)ASIC_BIT0	

#define	TKN_TX_PERMISSION_SEND				(USHORT)ASIC_BIT0	

#define	TRAN_HEAD_NO_HEAD_DISCRIPT_NO		(USHORT)ASIC_BIT0	

#define	FRAME_COMMONINFO_ENABLE_MASK			(USHORT)0x00FF
#define	FRAME_COMMONINFO_PROTOCOLCLASSIFCATION_MASK	(USHORT)0x000F
#define	FRAME_COMMONINFO_PROTOCOLVERSION_MASK		(USHORT)0x00F0
#define	FRAME_COMMONINFO_PROTOCOLVERSION_SHIFT		4

#define	MSTS_SWITCH_FLAG_COPY				(USHORT)ASIC_BIT0	

#define	CYC_SWITCH_FLAG_WRITTEN				(USHORT)ASIC_BIT0	

#define	MST_COMMAND_ZERO					(USHORT)0x0000		
#define	MST_COMMAND_MASTERCOMMAND_MASK				(USHORT)0x00FF
#define	MST_COMMAND_SEQ_NO_ENABLE_MASK				(USHORT)0x0700
#define	MST_COMMAND_DEVTYPE_BIT					(USHORT)0x0800
#define	MST_COMMAND_SEQ_NO_INDEX_SHIFT				8
#define	MST_COMMAND_DEVTYPE_INDEX_SHIFT				11
#define	MST_COMMAND_ENABLE_MASK					(USHORT)0x0FFF

#define	NET_NUM_NETWORKNUMBER_MASK				(USHORT)0x00FF		

#define	SETUPACK_FRAME_RESERVED1				(USHORT)0x00FF
#define	SETUPACK_FRAME_RESERVED2				(USHORT)0x0100

#define	SETUPACK_MYSTA_RESERVED1				(USHORT)0x00FF



#define	STGURANTEN_CYCLICRECVVALID			(USHORT)ASIC_BIT0	

#define	RY1_FMB_INFO_BIT_TOPBYTE07_00VALID	(USHORT)ASIC_BIT0	
#define	RY1_FMB_INFO_BIT_TOPBYTE0F_08VALID	(USHORT)ASIC_BIT1	
#define	RY1_FMB_INFO_BIT_TOPBYTE17_10VALID	(USHORT)ASIC_BIT2	
#define	RY1_FMB_INFO_BIT_TOPBYTE1F_18VALID	(USHORT)ASIC_BIT3	
#define	RY1_FMB_INFO_BIT_BTMBYTE07_00VALID	(USHORT)ASIC_BIT4	
#define	RY1_FMB_INFO_BIT_BTMBYTE0F_08VALID	(USHORT)ASIC_BIT5	
#define	RY1_FMB_INFO_BIT_BTMBYTE17_10VALID	(USHORT)ASIC_BIT6	
#define	RY1_FMB_INFO_BIT_BTMBYTE1F_18VALID	(USHORT)ASIC_BIT7	
#define	RY1_FMB_INFO_ALLBIT					(USHORT)0x00FF		

#define	RY1_FMB_INFO_TOPBYTEVALID_MASK			(USHORT)0x000F			
#define	RY1_FMB_INFO_BTMBYTEVALID_MASK			(USHORT)0x00F0			
#define	RY1_FMB_INFO_BTMBYTEVALID_SHIFT			4

#define	PARAMID_COMMON_PARAMETER_NUM		6
#define	PARAMID_COMMON_PARAMETER_BYTE_SIZE	2

#define	CYCFLG_NOTREAD						(USHORT)0			

#define	CYCFLG_RECVDATAEXIST				(USHORT)ASIC_BIT0		


#define	RDISENDIS_NONCYCLICRECVVALID		(USHORT)ASIC_BIT0	


#define	NSRINTMS_NONCYCLICRECVINTMASK		(USHORT)ASIC_BIT0	

#define	NSRINTMS_MYSTARCVTKNFRMMASK			(USHORT)ASIC_BIT7	

#define	RCNTENDIS_CNTLFRMRECVVALID			(USHORT)ASIC_BIT0	

#define	NRRWPCLR_NONCYCRECVRPWPCLR			(USHORT)ASIC_BIT0	

#define	PARA_ACT_COMMAND_STATIONTYPE_VALID	(USHORT)ASIC_BIT4	


#define MACRST_RESETMAC						(USHORT)ASIC_BIT0	
#define MACRST_RESETPHY1					(USHORT)ASIC_BIT1	
#define MACRST_RESETPHY2					(USHORT)ASIC_BIT2	
#define MACRST_RESETPHY12					(USHORT)ASIC_BIT3	

#define	RAMCLR_CLEARSENDRECVRAM				(USHORT)ASIC_BIT0	

#define LEDCTRLMSK1							(ULONG)0x00000001	
#define LEDCTRLMSK2							(ULONG)0x00000003	
#define	LEDCNT1_OFF							(USHORT)0			
#define	LEDCNT1_ON							(USHORT)1			
#define	LEDCNT1_FLASH_1S					(USHORT)2			
#define	LEDCNT1_FLASH_500MS					(USHORT)3			
#define	LEDCNT1_FLASH_200MS					(USHORT)4			

#define	NMI_INTERNALWDT						(USHORT)ASIC_BIT0	
#define	NMI_ALLINTCLR						(USHORT)0x0001		

#define	NMIM_INTERNALWDT					(USHORT)ASIC_BIT0	
#define	NMIM_ALLINTMASK						(USHORT)0x0001		
#define	NMIM_ALLINTMASK_FULL				(USHORT)0xFFFF		

#define INT_INT1INTERRUPT					(USHORT)ASIC_BIT1	
#define INT_INT2INTERRUPT					(USHORT)ASIC_BIT2	
#define	INT_ALLINT							(USHORT)0x0006		

#define INTM_INT1MASK						(USHORT)ASIC_BIT1	
#define INTM_INT2MASK						(USHORT)ASIC_BIT2	
#define INTM_INT3MASK						(USHORT)ASIC_BIT3	

#define INTM_ALLINTMASK_FULL				(USHORT)0xFFFF		

#define	INT1_MACSENDNORMALEND				(USHORT)ASIC_BIT0	
#define	INT1_MACSENDERR						(USHORT)ASIC_BIT1	
#define	INT1_NONCYCSENDOKINT				(USHORT)ASIC_BIT2	
#define	INT1_NONCYCORCTRLFRMRECV			(USHORT)ASIC_BIT8	
#define	INT1_MASTERWATCHTIMERTIMEOUTINT		(USHORT)ASIC_BIT15	
#define	INT1_INTCLR							(USHORT)(			 \
												  INT1_MACSENDNORMALEND \
												| INT1_MACSENDERR \
												| INT1_NONCYCSENDOKINT \
												| INT1_MASTERWATCHTIMERTIMEOUTINT \
											)

#define INTM1_RCVLOWPRIINT					(USHORT)ASIC_BIT0	
#define INTM1_SNDLOWPRIINT					(USHORT)ASIC_BIT1	

#define	INTM1_ALLINTMASK_FULL				(USHORT)0xFFFF		

#define SYNCINTLM_SYNCINTMASK				(USHORT)ASIC_BIT0	
#define SYNCINTLM_ALLINTMASK_FULL			(USHORT)0xFFFF		



#define	TIME_CONT_TIMERSTART				(USHORT)ASIC_BIT0	
#define	MWT_CONT_MASTERWATCHTIMERSTART		(USHORT)ASIC_BIT0	

#define	FAIL_MD_SET_WDTLLBYPASSMODE			(USHORT)ASIC_BIT0	
#define	FAIL_MD_SET_SELFWDTBYPASSMODE		(USHORT)ASIC_BIT1	
#define	FAIL_MD_SET_PASSMODE_MASK			(USHORT)0x0003
#define	FAIL_MD_SET_SELFWDTBYPASSMODE_SHIFT	1

#define	SELF_WDT_SELFWDTSET					(USHORT)ASIC_BIT0	

#define	WDT_COUNT_BIT						(USHORT)0x001F		

#define	WDTCNT_WDT_CNTL			(USHORT)ASIC_BIT0

#define	TDIS_DISCRIPTNO_1					0					
#define	TDIS_DISCRIPTNO_2					1					

#define	TDIS1_SFRAMEPOSSIBLE				(USHORT)ASIC_BIT0	
#define	TDIS1_FRAMETYPENOT0x890F			(USHORT)ASIC_BIT1	
#define	TDIS1_DATASIZEDIFFCHKMASK			(USHORT)0x0001		

#define	TDIS2_SDISCRIPTERSENDOK				(USHORT)ASIC_BIT0	
#define	TDIS2_SDISCRIPTERSENDNG				(USHORT)ASIC_BIT1	
#define	TDIS2_CLR							(USHORT)0x0003		

#define	TDIS3_CYCNCYC_HDRBYTESIZE			40					
#define	TDIS3_CYCNCYC_CYCMAXBYTESIZE		1468				
#define	TDIS3_DATASIZEDIFFCHKMASK			(USHORT)0x003F		
#define	TDIS3_SENDDATA_SIZE_ENABLE_BIT		(USHORT)0x07FF


#define	TDIS4_LASTDISCRIPTERCHAIN			(USHORT)0x7FFF		
#define	TDIS4_LASTDISCRIPTER				(USHORT)ASIC_BIT15	

#define	TDIS6_DATASIZEDIFFCHKMASK			(USHORT)0xFF00		
#define	TDIS6_TOPBYTEVALID_RX_MASK			(USHORT)0x0F00			
#define	TDIS6_TOPBYTEVALID_RX_SHIFT			8
#define	TDIS6_BTMBYTEVALID_RX_MASK			(USHORT)0xF000			
#define	TDIS6_BTMBYTEVALID_RX_SHIFT			12


#define	RDIS1_REC_DATA_SIZE_MASK			(USHORT)0x07FF		
#define	RDIS1_RECVPORT2						(USHORT)ASIC_BIT12	
#define	RDIS1_OWNRDISCRIPTERUSED			(USHORT)ASIC_BIT15	

#define	RDIS1_CNT_RECVPORT2					(USHORT)ASIC_BIT0	
#define	RDIS1_CNT_OWNRDISCRIPTERUSED		(USHORT)ASIC_BIT1	

#define	RDIS2_BUF_ADDR_MASK					(USHORT)0x3FFF		

#define	RDIS_CNT_RECVA						(ASIC_BIT1)
#define	RDIS_CNT_RECVB						(ASIC_BIT17)

/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/




typedef struct _PARAMID_TAG {
	union {
	CHAR					auchData[PARAMID_COMMON_PARAMETER_NUM*PARAMID_COMMON_PARAMETER_BYTE_SIZE];
		struct {
	USHORT	b8ZYear_h:						8;			
	USHORT	b8ZYear_l:						8;			
	USHORT	b8ZMonth:						8;			
	USHORT	b8ZDay:							8;			
	USHORT	b8ZHour:						8;			
	USHORT	b8ZMinute:						8;			
	USHORT	b8ZSecond:						8;			
	USHORT	b8ZStationNo:					8;			
	USHORT	b8ZSum1:						8;			
	USHORT	b8ZSum2:						8;			
	USHORT	b8ZSum3:						8;			
	USHORT	b8ZSum4:						8;			
		} stBit;
	} uniParamId;
} PARAMID_T;



typedef struct _MACRST_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZMACReset:					1;			
	USHORT	b1ZPHY1Reset:					1;			
	USHORT	b1ZPHY2Reset:					1;			
	USHORT	b1ZPHY12Reset:					1;			
	USHORT	bDZDummy1:						12;			
		} stBit;
	} uniMacRst;
} MACRST_T;

typedef struct _RAMCLR_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZSndRecRAMClr:				1;			
			USHORT	bFDummy1:						15;			
		} stBit;
	} uniRamClr;
} RAMCLR_T;

typedef struct _LEDCNT1_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZRunLEDLighting:				1;			
	USHORT	b1ZDummy1:						1;			
	USHORT	b2ZModeLEDLighting:				2;			
	USHORT	b2ZRemLEDLighting:				2;			
	USHORT	b2ZDLinkLEDLighting:			2;			
	USHORT	b2ZErrLEDLighting:				2;			
	USHORT	b1ZLErr1LEDLighting:			1;			
	USHORT	b1ZLErr2LEDLighting:			1;			
	USHORT	b4ZDummy2:						4;			
		} stBit;
	} uniLedCnt1;
} LEDCNT1_T;

typedef struct _LEDMASK_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZRunLEDLightingMask:			1;			
	USHORT	b1ZDummy1:						1;			
	USHORT	b1ZModeLEDLightingMask:			1;			
	USHORT	b1ZDummy2:						1;			
	USHORT	b1ZRemLEDLightingMask:			1;			
	USHORT	b1ZDummy3:						1;			
	USHORT	b1ZDLinkLEDLightingMask:		1;			
	USHORT	b1ZDummy4:						1;			
	USHORT	b1ZErrLEDLightingMask:			1;			
	USHORT	b1ZDummy5:						1;			
	USHORT	b1ZLErr1LEDLightingMask:		1;			
	USHORT	b1ZLErr2LEDLightingMask:		1;			
	USHORT	b4ZDummy6:						4;			
		} stBit;
	} uniLedMask;
} LEDMASK_T;

typedef struct _NMI_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZWDTError:					1;			
	USHORT	bFZDummy1:						15;			
		} stBit;
	} uniNmi;
} NMI_T;

typedef struct _NMIM_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZWDTErrorMask:				1;			
	USHORT	bFZDummy1:						15;			
		} stBit;
	} uniNmiM;
} NMIM_T;

typedef struct _INT_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZReserved0:					1;			
	USHORT	b1ZINT1Break:					1;			
	USHORT	b1ZINT2Break:					1;			
	USHORT	bDZReserved3:					13;			
		} stBit;
	} uniInt;
} INT_T;

typedef struct _INTM_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZReserved0:					1;			
	USHORT	b1ZINT1BreakMask:				1;			
	USHORT	b1ZINT2BreakMask:				1;			
	USHORT	bDZReserved3:					13;			
		} stBit;
	} uniIntM;
} INTM_T;

typedef struct _INT1_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZRcvLPriInt:					1;			
	USHORT	b1ZSndLPriInt:					1;			
	USHORT	b14ZReserved2:					14;			
		} stBit;
	} uniInt1;
} INT1_T;

typedef struct _INTM1_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZRcvLPriIntMask:				1;			
	USHORT	b1ZSndLPriIntMask:				1;			
	USHORT	b14ZReserved2:					14;			
		} stBit;
	} uniIntM1;
} INTM1_T;


typedef struct _SYNCINTL_TAG {
	USHORT	b1ZSyncInt:						1;			
	USHORT	bFZReserved1:					15;			
} SYNCINTL_T;

typedef struct _SYNCINTLM_TAG {
	USHORT	b1ZSyncIntMask:					1;			
	USHORT	bFZReserved1:					15;			
} SYNCINTLM_T;




typedef struct _FAIL_MD_SET_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZTroubleProcessWDTLLSet:		1;			
	USHORT	b1ZTroubleProcessCritical:		1;			
	USHORT	bEZDummy1:						14;			
		} stBit;
	} uniMdSet;
} FAIL_MD_SET_T;

typedef struct _SELF_WDT_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZMyStationCriticalTrouble:	1;			
	USHORT	bFZDummy1:						15;			
		} stBit;
	} uniSelfWdt;
} SELF_WDT_T;

typedef struct _WDTCNT_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZWDTCntl:						1;			
	USHORT	bFZDummy1:						15;			
		} stBit;
	} uniWdtCnt;
} WDTCNT_T;

typedef struct _WDTRST_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZWDTReset:					1;			
	USHORT	bFZDummy1:						15;			
		} stBit;
	} uniWdtRst;
} WDTRST_T;



typedef struct _TDIS1_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZSendFrmExperienced:			1;			
	USHORT	bFZReserve:						15;			
		} stBit;
	} uniTdis1;
} TDIS1_T;

typedef struct _TDIS2_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b1ZSendNormalEnd:				1;			
	USHORT	b1ZSendAbNormalEnd:				1;			
	USHORT	bEZDummy1:						14;			
		} stBit;
	} uniTdis2;
} TDIS2_T;

typedef struct _TDIS3_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	bBZSendDataSize:				11;			
	USHORT	b5ZReserve1:					5;			
		} stBit;
	} uniTdis3;
} TDIS3_T;

typedef struct _TDIS4_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	bFZNextReadDiscripterChain:		15;			
	USHORT	b1ZLastDiscripterFlag:			1;			
		} stBit;
	} uniTdis4;
} TDIS4_T;

typedef struct _TDIS5_TAG {
	USHORT	usMemoryCyclicHeadAddress;			
} TDIS5_T;

typedef struct _TDIS6_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b8ZSequentialNo:				8;			
	USHORT	b4ZTopByteValid:				4;			
	USHORT	b4ZBtmByteValid:				4;			
		} stBit;
	} uniTdis6;
} TDIS6_T;

typedef struct _TDIS7_TAG {
	USHORT	usOffsetAddress_h;			
} TDIS7_T;

typedef struct _TDIS8_TAG {
	USHORT	usOffsetAddress_l;			
} TDIS8_T;

typedef struct _TDIS9_TAG {
	USHORT	usZReserved2;			
} TDIS9_T;

typedef struct _TDIS10_TAG {
	USHORT	usZReserved3;			
} TDIS10_T;

typedef struct _TD_TDS_TAG {
	TDIS1_T						TD_TDIS1;				
	TDIS2_T						TD_TDIS2;				
	TDIS3_T						TD_TDIS3;				
	TDIS4_T						TD_TDIS4;				
	USHORT		usZReserved[(0x10-0x08)/2];				
} TD_TDS_T;

typedef struct _TD_TDS_CYC_TAG {
	TDIS1_T						TD_TDIS1;				
	TDIS2_T						TD_TDIS2;				
	TDIS3_T						TD_TDIS3;				
	TDIS4_T						TD_TDIS4;				
	TDIS5_T						TD_TDIS5;				
	TDIS6_T						TD_TDIS6;				
	TDIS7_T						TD_TDIS7;				
	TDIS8_T						TD_TDIS8;				
	TDIS9_T						TD_TDIS9;				
	TDIS10_T					TD_TDIS10;				
	USHORT		usZReserved[(0x20-0x14)/2];				
} TD_TDS_CYC_T;


typedef struct _RDIS_TAG {
	USHORT	b1ZRecPortIndicator_A:			1;			
	USHORT	b1ZOWNBit_A:					1;			
	USHORT	bEZDummy1:						14;			
	USHORT	b1ZRecPortIndicator_B:			1;			
	USHORT	b1ZOWNBit_B:					1;			
	USHORT	bEZDummy2:						14;			
} RDIS_T;

typedef struct _RDIS1_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	bBZRecDataSize:					11;			
	USHORT	b1ZDummy1:						1;			
	USHORT	b1ZRecPortIndicator:			1;			
	USHORT	b2ZDummy2:						2;			
	USHORT	b1ZOWNBit:						1;			
		} stBit;
	} uniRdis1;
} RDIS1_T;

typedef struct _RDIS2_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	bEZRecBuffAddr:					14;			
	USHORT	b2ZDummy1:						2;			
		} stBit;
	} uniRdis2;
} RDIS2_T;

typedef struct _RD_RDS_TAG {
	RDIS1_T					RD_RDIS1;					
	RDIS2_T					RD_RDIS2;					
} RD_RDS_T;





typedef struct _INTRST_TAG {
	USHORT						usMACRST;				
	USHORT		usZReserved0702[(0x0708-0x0702)/2];		
	union	_LEDCNT1 {									
		USHORT					usDATA;
		LEDCNT1_T				stBIT;
	} LEDCNT1;
	union	_LEDMASK {									
		USHORT					usDATA;
		LEDMASK_T				stBIT;
	} LEDMASK;
	USHORT		usZReserved070C[(0x0710-0x070C)/2];		
	union _NMI {										
		USHORT					usDATA;
		NMI_T					stBIT;
	} NMI;
	union _NMIM {										
		USHORT					usDATA;
		NMIM_T					stBIT;
	} NMIM;
	union _INTR {										
		USHORT					usDATA;
		INT_T					stBIT;
	} INTR;
	union _INTM {										
		USHORT					usDATA;
		INTM_T					stBIT;
	} INTM;
	USHORT		usZReserved0718[(0x0724-0x0718)/2];		
	union _INT1 {										
		USHORT					usDATA;
		INT1_T					stBIT;
	} INT1;
	union _INTM1 {										
		USHORT					usDATA;
		INTM1_T					stBIT;
	} INTM1;
	USHORT		usZReserved0728[(0x0730-0x0728)/2];		
	union _SYNCINTL {									
		USHORT					usDATA;
		SYNCINTL_T				stBIT;
	} SYNCINTL;
	union _SYNCINTLM {									
		USHORT					usDATA;
		SYNCINTLM_T				stBIT;
	} SYNCINTLM;
	USHORT		usZReserved0734[(0x0800-0x0734)/2];		
} INTRST_T;

typedef struct _EMGDBG_TAG {
	USHORT		usZReserved0900[(0x0950-0x0900)/2];		
	FAIL_MD_SET_T				stFAIL_MD_SET;			
	USHORT		usZReserved0952[(0x0954-0x0952)/2];		
	SELF_WDT_T					stSELF_WDT;				
	USHORT		usZReserved0956[(0x0960-0x0956)/2];		
	USHORT						usWDTCOUNT;				
	WDTCNT_T					stWDTCNT;				
	WDTRST_T					stWDTRST;				
	USHORT		usZReserved0966[(0x0A00-0x0966)/2];		
} EMGDBG_T;


#define TD_RWR_NUM						2				
#define	TD_TRAN_NUM						2				



#define	RD_NCYC_MAXNUM					20				

typedef struct _RD_TAG {
	RD_RDS_T		astRD_NCYC[RD_NCYC_MAXNUM];			
	ULONG		ulZReserved2050[(0x2800-0x2050)/4];		
	RDIS_T			stRD_CNTL;							
} RD_T;



#define	R_USYNC_IOCNT_REG_IN						0		
#define	R_USYNC_IOCNT_REG_OUT						1		

#define R_USYNC_SEL_NONUSE							0		
#define R_USYNC_SEL_SYNCFRM							4		

typedef struct _R_USYNC_IOCNT_SEL_TAG {						
	ULONG		b1ZSyncSigInOutSetting:				1;		
	ULONG		bFZReserved1:						15;
	ULONG		b03ZSyncSrcSelect:					3;		
	ULONG		bDZReserved1:						13;
} R_USYNC_IOCNT_SEL_T;

#define R_USYNC_EN_REG_INOUT_STOP					0		
#define R_USYNC_EN_REG_INOUT_START					1		

#define R_USYNC_DN_REG_NORMAL_COMP					3		

typedef struct _R_USYNC_EN_DN_TAG {							
	ULONG		b1ZSyncSigInOutPermit:				1;		
	ULONG		bFZReserved1:						15;
	ULONG		b2ZSyncProcCompStat:				2;		
	ULONG		bEZReserve1:						14;
} R_USYNC_EN_DN_T;

#define R_USYNC_WIN_SET_REG_AUTOSET					0		
#define R_USYNC_WIN_SET_REG_MANSET					1		

#define R_USYNC_WIN_SET_REG_INVALID					0		
#define R_USYNC_WIN_SET_REG_VALID					1		

typedef struct _R_USYNC_CNTCLR_WINSET_TAG {					
	ULONG		b1ZCycCountClr:						1;		
	ULONG		bFZReserved1:						15;
	/* 0292 */
	ULONG		b1ZControlChange:					1;		
	ULONG		b1ZWindowFunc:						1;		
	ULONG		bEZReserved2:						14;
} R_USYNC_CNTCLR_WINSET_T;

typedef struct _R_WINOPENTMG_TAG {							
	ULONG		b1CZWindOpenTmg:					28;		
	ULONG		b4ZReserved1:						4;
} R_WINOPENTMG_T;

#define R_WINCLOSETMG_REG_2US						0x000000FA	

typedef struct _R_WINCLOSETMG_TAG {							
	ULONG		b1CZWindCloseTmg:					28;		
	ULONG		b4ZReserved1:						4;
} R_WINCLOSETMG_T;

typedef struct _R_WINOPEN_INT_TAG {							
	ULONG		b10ZWindOpenPermitCycSet:			16;		
	ULONG		b10ZReserved1:						16;
} R_WINOPEN_INT_T;

typedef struct _R_SYNCSET_TAG {								
	ULONG		b10ZSyncCycSet:						16;		
	ULONG		b10ZReserved1:						16;
} R_SYNCSET_T;

typedef struct _R_COMSET_TAG {								
	ULONG		b1CZCommCycSet:						28;		
	ULONG		b4ZReserved1:						4;
} R_COMSET_T;

#define	R_SYNCCSET_REG_COMCTL1						0		
#define	R_SYNCCSET_REG_CONCTL2						1		

typedef struct _R_SYNCCSET_TAG {							
	ULONG	b01ZReserved1:							1;
	ULONG	b01ZCommCycCntMode:						1;		
	ULONG	b01ZQuartzCorrectMode:					1;		
	ULONG	b1DZReserved2:							29;
} R_SYNCCSET_T;

typedef struct _R_TXBUFFTMG_TAG {							
	ULONG		b1CZSndStartTmg:					28;		
	ULONG		b04ZReserved1:						4;
} R_TXBUFFTMG_T;

typedef struct _R_RXBUFFTMG_TAG {							
	ULONG		b1CZRcvStartTmg:					28;		
	ULONG		b04ZReserved1:						4;
} R_RXBUFFTMG_T;

typedef struct _R_UAOFFCOUNT_TAG {							
	ULONG		b10ZUserSetOutOfSyncErrTotalCnt:	16;		
	ULONG		b10ZReserved1:						16;
} R_UAOFFCOUNT_T;

#define R_SYNCINT_INTCLR							0xFFFFFFFF	

typedef struct _R_SYNCINT_TAG {								
	union {
		ULONG		ulDATA;
		struct {
			ULONG	b01ZCommCycChgInt:				1;		
			ULONG	b01ZSyncCycChgInt:				1;		
			ULONG	b1FZReserved1:					30;
		} stBIT;
	} uniR_SYNCINT;
} R_SYNCINT_T;

#define R_SYNCHINTMSK_COMM_SWITCH_INT				ASIC_BIT0	
#define R_SYNCHINTMSK_ALLINTMASK_FULL				0xFFFFFFFF	

typedef struct _R_SYNCHINTMSK_TAG {							
	union {
		ULONG		ulDATA;
		struct {
			ULONG	b01ZCommCycChgIntMsk:			1;		
			ULONG	b01ZReserved1:					1;
			ULONG	b1FZReserved2:					30;
		} stBIT;
	} uniR_SYNCHINTMSK;
} R_SYNCHINTMSK_T;

#define R_SYNCSINTMSK_SYNC_SWITCH_INT				ASIC_BIT1	
#define R_SYNCSINTMSK_ALLINTMASK_FULL				0xFFFFFFFF	

typedef struct _R_SYNCSINTMSK_TAG {							
	union {
		ULONG		ulDATA;
		struct {
			ULONG	b01ZReserved1:					1;
			ULONG	b01ZSyncCycChgIntMsk:			1;		
			ULONG	b1FZReserved2:					30;
		} stBIT;
	} uniR_SYNCSINTMSK;
} R_SYNCSINTMSK_T;

#define R_SYNCSINTPC_NOTICE_LEVEL					0		
#define R_SYNCSINTPC_NOTICE_PULSE					1		

#define R_SYNCSINTPC_PULSE_WIDTH_80NS				0		
#define R_SYNCSINTPC_PULSE_WIDTH_160NS				1		
#define R_SYNCSINTPC_PULSE_WIDTH_320NS				2		
#define R_SYNCSINTPC_PULSE_WIDTH_640NS				3		

typedef struct _R_SYNCSINTPC_TAG {							
	ULONG		b01ZSyncIntSigSelect:				1;		
	ULONG		b01ZPulseIntPulseWidth:				2;		
	ULONG		b1DZReserved1:						29;
} R_SYNCSINTPC_T;

typedef struct _R_SETUPCHACNT_TAG {							
	ULONG		b01ZCommCyc:						1;		
	ULONG		b01ZWindCloseTmg:					1;		
	ULONG		b01ZWindOpenTmg:					1;		
	ULONG		b1DZReserved1:						29;
} R_SETUPCHACNT_T;

#define R_WINSET_REG_WIN1							0		
#define R_WINSET_REG_WIN2							1		

typedef struct _R_WINSET_TAG {								
	ULONG		b01ZWindSetting:					1;		
	ULONG		b01FZReserved1:						31;
} R_WINSET_T;

#define R_SYNC_SEL_SYNCFRM_MYSTATUS					0		
#define R_SYNC_SEL_SYNCFRM_SYNC						1		

#define R_SYNC_SEL_SYNCSIG_BUS						0		
#define R_SYNC_SEL_SYNCSIG_USER						1		

typedef struct _R_SYNC_SEL_TAG {							
	ULONG		b01ZSyncFrameSelect:				1;		
	ULONG		b01ZSyncSignalSelect:				1;		
	ULONG		b1DZReserved1:						30;
} R_SYNC_SEL_T;


typedef struct _SC_TAG {
	ULONG					usZReserved0000[(0x0200-0x0000)/4];		
	ULONG					ulR_SYNC_OUT_SEL_SYNCERR;				
	ULONG					ulR_SYNCERR1_RSV;						
	ULONG					ulZReserved0206[(0x0240-0x0208)/4];		
	ULONG					ulR_FSYNC_IOCNT_SEL;					
	ULONG					ulR_FSYNC_EN_DN;						
	ULONG					ulR_FSYNC_PRD_LO_HI;					
	ULONG					ulZReserved024C[(0x0250-0x024C)/4];		
	ULONG					ulR_FSYNC_CNTCLR_WINSET;				
	ULONG					ulR_FSYNC_WIN_OPEN_LO_HI;				
	ULONG					ulR_FSYNC_WIN_CLS_LO_HI;				
	ULONG					ulR_FXSYNC_CERR_TERR_TH;				
	ULONG					ulR_FXSYNC_CERRCNT_TERRCNT;				
	ULONG					ulZReserved0264[(0x0280-0x0264)/4];		
	R_USYNC_IOCNT_SEL_T		R_USYNC_IOCNT_SEL;						
	R_USYNC_EN_DN_T			R_USYNC_EN_DN;							
	ULONG					ulR_USYNC_PRD_LO_HI;					
	ULONG					ulZReserved028C[(0x0290-0x028C)/4];		
	R_USYNC_CNTCLR_WINSET_T	R_USYNC_CNTCLR_WINSET;					
	ULONG					ulR_USYNC_WIN_OPEN_LO_HI;				
	ULONG					ulR_USYNC_WIN_CLS_LO_HI;				
	ULONG					ulR_USYNC_CERR_TERR_TH;					
	ULONG					ulR_USYNC_CERRCNT_TERRCNT;				
	ULONG					ulZReserved02A4[(0x3000-0x02A4)/4];		
	ULONG					ulR_SYNCNUM;							
	ULONG					ulR_COMNUM;								
	ULONG					ulR_COMCOUNT1;							
	ULONG					ulZReserved300C[(0x3010-0x300C)/4];		
	ULONG					ulR_COMCOUNT2L;							
	ULONG					ulR_COMCOUNT2U;							
	ULONG					ulR_COMNUM_LATCH;						
	ULONG					ulR_COMCOUNT1_LATCH;					
	ULONG					ulR_COMCOUNT2L_LATCH;					
	ULONG					ulR_COMCOUNT2U_LATCH;					
	ULONG					ulR_FREECOUNTL;							
	ULONG					ulR_FREECOUNTU;							
	ULONG					ulR_FREECOUNTL_LATCH;					
	ULONG					ulR_FREECOUNTU_LATCH;					
	ULONG					ulR_WINCOUNT1_LATCH;					
	ULONG					ulR_WINCOUNT2_LATCH;					
	ULONG					ulR_WINCOUNT1;							
	ULONG					ulR_WINCOUNT2;							
	ULONG					ulR_WINCOUNT1NUM;						
	ULONG					ulR_WINCOUNT2NUM;						
	ULONG					ulR_WINCOUNT1NUM_LATCH;					
	ULONG					ulR_WINCOUNT2NUM_LATCH;					
	ULONG					ulR_WINCOMCOUNT;						
	ULONG					ulR_WINCOMCOUNT_LATCH;					
	R_WINOPENTMG_T			R_WINOPENTMG;							
	R_WINCLOSETMG_T			R_WINCLOSETMG;							
	R_WINOPEN_INT_T			R_WINOPEN_INT;							
	ULONG					ulR_WINCOUNT1_COMPSET0;					
	ULONG					ulR_WINCOUNT1_COMPSET1;					
	ULONG					ulR_WINCOUNT2_COMPSET0;					
	ULONG					ulR_WINCOUNT2_COMPSET1;					
	ULONG					ulR_SYNCNUMCLR;							
	R_SYNCSET_T				R_SYNCSET;								
	R_COMSET_T				R_COMSET;								
	R_SYNCCSET_T			R_SYNCCSET;								
	ULONG					ulR_SFLAGCNT;							
	ULONG					ulR_SFLAGCOMCOUNT;						
	ULONG					ulR_SFLAGCOMCOUNT_LATCH;				
	ULONG					ulR_SHFLAGCNT;							
	ULONG					ulR_FSYNC_OW;							
	ULONG					ulR_SYNCOUTTMG;							
	ULONG					ulR_SYNCOUT_INT;						
	ULONG					ulR_SYNCOUTCOMCOUNT;					
	ULONG					ulR_SYNCOUTCOMCOUNT_LATCH;				
	ULONG					ulR_TXTMG;								
	R_TXBUFFTMG_T			R_TXBUFFTMG;							
	R_RXBUFFTMG_T			R_RXBUFFTMG;							
	ULONG					ulR_REVICE;								
	ULONG					ulR_REVICE_BPSEL;						
	ULONG					ulR_REVICE_RST;							
	ULONG					ulR_SCDFLT;								
	ULONG					ulR_RXDATA_BUFFSET;						
	ULONG					ulR_SYNC_P1CAL_CML;						
	ULONG					ulR_SYNC_P1CAL_CMU;						
	ULONG					ulR_SYNC_P1CAL_CSL;						
	ULONG					ulR_SYNC_P1CAL_CSU;						
	ULONG					ulR_SYNC_P2CAL_CML;						
	ULONG					ulR_SYNC_P2CAL_CMU;						
	ULONG					ulR_SYNC_P2CAL_CSL;						
	ULONG					ulR_SYNC_P2CAL_CSU;						
	ULONG					ulR_SETUPDATA;							
	ULONG					ulR_TMID_SET;							
	ULONG					ulR_MEASURE_FTYPE;						
	ULONG					ulR_MEASURE_ACK_FTYPE;					
	ULONG					ulR_OFFSET_FTYPE;						
	ULONG					ulR_UPDATE_FTYPE;						
	ULONG					ulR_SYNC_FTYPE;							
	ULONG					ulR_MEASURE_ACK_INFO;					
	ULONG					ulR_RXSYNCID;							
	ULONG					ulR_SYNCID_SET0;						
	ULONG					ulR_SYNCID_SET1;						
	ULONG					ulZReserved311C[(0x3120-0x311C)/4];		
	ULONG					ulR_TSRXTMCAL;							
	ULONG					ulR_TSRXTMCAU;							
	ULONG					ulR_QXSYNCCOMPSET;						
	ULONG					ulR_P1DELYTIMESET0;						
	ULONG					ulR_P1DELYTIMESET1;						
	ULONG					ulR_P2DELYTIMESET0;						
	ULONG					ulR_P2DELYTIMESET1;						
	ULONG					ulR_TMTXRTIM;							
	ULONG					ulR_TMP1MMID;							
	ULONG					ulR_TMP1CMID;							
	ULONG					ulR_TMP1MTIM;							
	ULONG					ulR_TMP1OFCDATA;						
	ULONG					ulR_TSP1MMID;							
	ULONG					ulR_TSP1CMID;							
	ULONG					ulR_TSP1MTIM;							
	ULONG					ulZReserved315C[(0x3160-0x315C)/4];		
	ULONG					ulR_TSP1OFAL;							
	ULONG					ulR_TSP1OFAU;							
	ULONG					ulR_TSP1MRE;							
	ULONG					ulR_TMP2MMID;							
	ULONG					ulR_TMP2CMID;							
	ULONG					ulR_TMP2MTIM;							
	ULONG					ulR_TMP2OFCDATA;						
	ULONG					ulR_TSP2MMID;							
	ULONG					ulR_TSP2CMID;							
	ULONG					ulR_TSP2MTIM;							
	ULONG					ulR_TSP2OFAL;							
	ULONG					ulR_TSP2OFAU;							
	ULONG					ulR_TSP2MRE;							
	ULONG					ulZReserved3194[(0x3198-0x3194)/4];		
	ULONG					ulR_TSOFBL;								
	ULONG					ulR_TSOFBU;								
	ULONG					ulR_REFPOINTL;							
	ULONG					ulR_REFPOINTU;							
	ULONG					ulR_TMCCL;								
	ULONG					ulR_TMCCU;								
	ULONG					ulR_CCINTTIM1SET0;						
	ULONG					ulR_CCINTTIM1SET1;						
	ULONG					ulR_CCINTTIM2SET0;						
	ULONG					ulR_CCINTTIM2SET1;						
	ULONG					ulR_CCINTTIM3SET0;						
	ULONG					ulR_CCINTTIM3SET1;						
	ULONG					ulR_CCINTTIM4SET0;						
	ULONG					ulR_CCINTTIM4SET1;						
	ULONG					ulR_CCINTTIM1SET0_INT;					
	ULONG					ulR_CCINTTIM1SET1_INT;					
	ULONG					ulR_CCINTTIM2SET0_INT;					
	ULONG					ulR_CCINTTIM2SET1_INT;					
	ULONG					ulR_CCINTTIM3SET0_INT;					
	ULONG					ulR_CCINTTIM3SET1_INT;					
	ULONG					ulR_CCINTTTIM4SET0_INT;					
	ULONG					ulR_CCINTTTIM4SET1_INT;					
	ULONG					ulR_FSYNCOERRSET;						
	ULONG					ulR_FCOFFCOUNT;							
	ULONG					ulR_FAOFFCOUNT;							
	ULONG					ulR_USYNCOERRSET;						
	ULONG					ulR_UCOFFCOUNT;							
	R_UAOFFCOUNT_T			R_UAOFFCOUNT;							
	ULONG					ulR_EMGSTS;								
	ULONG					ulR_P1EMGSTS;							
	ULONG					ulR_P2EMGSTS;							
	ULONG					ulR_EMGCONF;							
	ULONG					ulR_EMGSET;								
	ULONG					ulR_TXRXEMGGRP;							
	ULONG					ulR_EMGFIL;								
	R_SYNCINT_T				R_SYNCINT;								
	R_SYNCHINTMSK_T			R_SYNCHINTMSK;							
	R_SYNCSINTMSK_T			R_SYNCSINTMSK;							
	R_SYNCSINTPC_T			R_SYNCSINTPC;							
	R_SETUPCHACNT_T			R_SETUPCHACNT;							
	ULONG					ulR_P1SFLAGMYRXTMGL;					
	ULONG					ulR_P1SFLAGMYRXTMGU;					
	ULONG					ulR_P2SFLAGMYRXTMGL;					
	ULONG					ulR_P2SFLAGMYRXTMGU;					
	ULONG					ulR_SYNCINTMGL;							
	ULONG					ulR_SYNCINTMGU;							
	R_WINSET_T				R_WINSET;								
	R_SYNC_SEL_T			R_SYNC_SEL;								
} SC_T;

typedef union _R_IN32_R_LEDCNT1_TAG {
	ULONG ulAll;
	struct {
		ULONG	b3ZRunLEDLighting:				3;					
		ULONG	b3ZModeLEDLighting:				3;					
		ULONG	b3ZDummy1:						3;					
		ULONG	b3ZErrLEDLighting:				3;					
		ULONG	b3ZDummy2:						3;					
		ULONG	b3ZRemLEDLighting:				3;					
		ULONG	b3ZDLinkLEDLighting:			3;					
		ULONG	b4ZDummy3:						4;					
		ULONG	b1ZLErr1LEDLighting:			1;					
		ULONG	b1ZLErr2LEDLighting:			1;					
		ULONG	b3ZDummy4:						3;					
		ULONG	b2ZLIeTypeLEDLighting:			2;					
	} stBit;
} R_IN32_R_LEDCNT1_T;

typedef union _R_IN32_R_LEDCNT2_TAG {
	ULONG ulAll;
	struct {
		ULONG	b2ZSdSdRd1LEDLightingTime:		2;					
		ULONG	b2ZRdSdRd2LEDLightingTime:		2;					
		ULONG	b2ZDummy1:						2;					
		ULONG	b2ZLErr1LEDLightingTime:		2;					
		ULONG	b2ZLErr2LEDLightingTime:		2;					
		ULONG	b22ZDummy2:						22;					
	} stBit;
} R_IN32_R_LEDCNT2_T;

typedef union _R_IN32_R_LEDMASK_TAG {
	ULONG ulAll;
	struct {
		ULONG	b1ZRunLEDLightingMask:			1;					
		ULONG	b1ZModeLEDLightingMask:			1;					
		ULONG	b1ZDummy1:						1;					
		ULONG	b1ZErrLEDLightingMask:			1;					
		ULONG	b1ZDummy2:						1;					
		ULONG	b1ZRemLEDLightingMask:			1;					
		ULONG	b1ZDLinkLEDLightingMask:		1;					
		ULONG	b2ZDummy3:						2;					
		ULONG	b1ZLErr1LEDLightingMask:		1;					
		ULONG	b1ZLErr2LEDLightingMask:		1;					
		ULONG	b1ZDummy4:						1;					
		ULONG	b1ZLIeTypeLEDLightingMask:		1;					
		ULONG	b19ZDummy5:						19;					
	} stBit;
} R_IN32_R_LEDMASK_T;

typedef struct _LED_TAG {
	R_IN32_R_LEDCNT1_T R_LEDCNT1;									
	R_IN32_R_LEDCNT2_T R_LEDCNT2;									
	R_IN32_R_LEDMASK_T R_LEDMASK;									
} LED_T;
#endif	/* __R_IN32M4_1_H_INCLUDED_ */

/*** EOF ***/
