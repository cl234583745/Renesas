/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_Data.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
R_IN32C_T          gstR_IN32C;

R_IN32C_2ND_BUFFER_T gastR_IN32C_RcvBuf[R_IN32C_2ND_BUFFER_NUM];
ULONG gulR_IN32C_RcvBufWIdx;
ULONG gulR_IN32C_RcvBufRIdx;


/*** EOF ***/
