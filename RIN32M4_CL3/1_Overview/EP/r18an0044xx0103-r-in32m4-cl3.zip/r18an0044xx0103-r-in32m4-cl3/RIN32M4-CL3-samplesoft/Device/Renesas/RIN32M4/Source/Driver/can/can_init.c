/**
 *******************************************************************************
 * @file  can_init.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************

  @brief  Enable the CAN-controller
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state
  @retval ER_BUSY  : Soft reset is running

 *******************************************************************************
 */
ER_RET can_enable(uint8_t ch)
{
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	During soft reset?(Check FCNnGMCLSORF bit)							*/
	/*----------------------------------------------------------------------*/
	if((RIN_CAN[ch]->GLB.FCNnGMCLCTL & MSK_CAN_GMCLSORF) != 0) {
		return ER_BUSY;
	}

	/*----------------------------------------------------------------------*/
	/*	Message buffer read error?(Check FCNnGMCLECCF bit)					*/
	/*----------------------------------------------------------------------*/
	if((RIN_CAN[ch]->GLB.FCNnGMCLCTL & MSK_CAN_GMCLECCF) != 0) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	CAN module is already enabled?(Check FCNnGMCLPWOM bit)				*/
	/*----------------------------------------------------------------------*/
	if((RIN_CAN[ch]->GLB.FCNnGMCLCTL & MSK_CAN_GMCLPWOM) != 0) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set CAN clock														*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->GLB.FCNnGMCSPRE = can_bps_info[ch].FCNnGMCSPRE;

	/*----------------------------------------------------------------------*/
	/*	Start CAN controller												*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->GLB.FCNnGMCLCTL = SET_CAN_GMCLPWOM;

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  Shutdown the CAN-controller(forced shutdown)
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_shutdown(uint8_t ch)
{
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Set FCNnGMCLESDE bit												*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->GLB.FCNnGMCLCTL = SET_CAN_GMCLESDE;

	/*----------------------------------------------------------------------*/
	/*	Clear FCNnGMCLPWOM bit												*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->GLB.FCNnGMCLCTL = CLR_CAN_GMCLPWOM;

	/*----------------------------------------------------------------------*/
	/*	Check FCNnGMCLPWOM bit												*/
	/*----------------------------------------------------------------------*/
	if((RIN_CAN[ch]->GLB.FCNnGMCLCTL & MSK_CAN_GMCLPWOM) != 0) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

/**
 *******************************************************************************

  @brief  CAN channel initialization (Re-initialization)
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval ER_OK    : Normal end
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_init(uint8_t ch)
{
	uint32_t		*msgbuf_mask;
	uint8_t			bufno;
	CAN_MSG_TypeDef *CAN_MSG;

#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	/*----------------------------------------------------------------------*/
	/*	Check init mode														*/
	/*----------------------------------------------------------------------*/
	if((RIN_CAN[ch]->MDL.FCNnCMCLCTL & MSK_CAN_CMCLMDOF) != CHK_CAN_INIT) {
		return ER_INVAL;
	}

	/*----------------------------------------------------------------------*/
	/*	Port setting														*/
	/*----------------------------------------------------------------------*/
	switch(ch){
		case CAN_CH0:
			// --- Initialize Port(CAN0) ---
			RIN_GPIO->PFC5B  &= ~0x18;	//  P53:CRXD0
			RIN_GPIO->PFCE5B &= ~0x18;	//  P54:CTXD0
			RIN_GPIO->PMC5B  |=  0x18;
			break;
		case CAN_CH1:
			// --- Initialize Port(CAN1) ---
			RIN_GPIO->PFC5B  &= ~0x60;	//  P55:CRXD1
			RIN_GPIO->PFCE5B &= ~0x60;	//  P56:CTXD1
			RIN_GPIO->PMC5B  |=  0x60;
			break;
		default:
			return ER_PARAM;
	}

	/*----------------------------------------------------------------------*/
	/*	Set baudrate														*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->MDL.FCNnCMBRPRS = can_bps_info[ch].FCNnCMBRPRS;
	RIN_CAN[ch]->MDL.FCNnCMBTCTL = can_bps_info[ch].FCNnCMBTCTL;

	/*----------------------------------------------------------------------*/
	/*	Set channel interrupt												*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->MDL.FCNnCMIECTL = can_ch_info[ch].FCNnCMIECTL;

	/*----------------------------------------------------------------------*/
	/*	Set mask resister													*/
	/*----------------------------------------------------------------------*/
	msgbuf_mask = (uint32_t *)&can_msg_msk_info[ch][0];

	RIN_CAN[ch]->MDL.FCNnCMMKCTL01W = msgbuf_mask[0];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL03W = msgbuf_mask[1];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL05W = msgbuf_mask[2];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL07W = msgbuf_mask[3];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL09W = msgbuf_mask[4];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL11W = msgbuf_mask[5];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL13W = msgbuf_mask[6];
	RIN_CAN[ch]->MDL.FCNnCMMKCTL15W = msgbuf_mask[7];

	/*----------------------------------------------------------------------*/
	/*	Set error counter clear bit and the action of arbitration lost		*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->MDL.FCNnCMCLCTL = (CLR_CAN_ERCF | CLR_CAN_ALBF);

	/*----------------------------------------------------------------------*/
	/*	Set ABT delay														*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->GLB.FCNnGMADCTL = 0x00;

	/*----------------------------------------------------------------------*/
	/*	CAN message buffer initialization									*/
	/*----------------------------------------------------------------------*/
	/*
	 * Init message buffer nouse
	 */
	/*
	 * Loop all message buffer
	 */
	for (bufno = 0 ; bufno < CAN_MSG_BUF_NUM ; bufno++) {
		/*
		 * Clear FCNnMmRDYF bit
		 */
		RIN_CAN[ch]->MSG.H[bufno].FCNnMmCTL = CLR_CAN_MRDYF;

		/*
		 * Clear FCNnMmSSMA bit
		 */
		RIN_CAN[ch]->MSG.B[bufno].FCNnMmSTRB &= CLR_CAN_MSSMA;

		/*
		 * Clear FCNnMmTRQF, FCNnMmDTNF bit
		 */
		RIN_CAN[ch]->MSG.H[bufno].FCNnMmCTL = (uint16_t)(CLR_CAN_MTRQF | CLR_CAN_MDTNF);
	}

	/*
	 * Init message buffer initial value
	 */
	/*
	 * Loop use message buffer
	 */
	for (bufno = 0 ; bufno < CAN_MSG_BUF_NUM ; bufno++)
	{
		CAN_MSG = (CAN_MSG_TypeDef *)&RIN_CAN[ch]->MSG.B[bufno];
		/*
		 * Set FCNnMmSTRB resister
		 */
		CAN_MSG->B.FCNnMmSTRB = can_msg_info[ch][bufno].FCNnMmSTRB;

		/*
		 * Set FCNnMmMID1H, FCNnMmMID0H resister
		 */
		CAN_MSG->W.FCNnMmMID0W = can_msg_info[ch][bufno].FCNnMmMID0W;

		/*
		 * Tx message buffer ?
		 */
		if((CAN_MSG->B.FCNnMmSTRB & MSK_CAN_MSSMTx) == CHK_CAN_MSSMTx_TX) {
			/*
			 * Set FCNnMmDTLGB resister
			 */
			CAN_MSG->B.FCNnMmDTLGB = can_msg_info[ch][bufno].FCNnMmDTLGB;

			/*
			 * Set FCNnMmDAT resister
			 */
			CAN_MSG->H.FCNnMmDAT0H = 0;
			CAN_MSG->H.FCNnMmDAT2H = 0;
			CAN_MSG->H.FCNnMmDAT4H = 0;
			CAN_MSG->H.FCNnMmDAT6H = 0;
		}

		/*
		 * Set FCNnMmCTL resister
		 */
		CAN_MSG->H.FCNnMmCTL = (uint16_t)(SET_CAN_MIENF | CLR_CAN_MNHMF | CLR_CAN_MMOWF | CLR_CAN_MDTNF | CLR_CAN_MTRQF);

		/*
		 * Set FCNnMmRDYF bit
		 */
		CAN_MSG->H.FCNnMmCTL = SET_CAN_MRDYF;
	}

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

