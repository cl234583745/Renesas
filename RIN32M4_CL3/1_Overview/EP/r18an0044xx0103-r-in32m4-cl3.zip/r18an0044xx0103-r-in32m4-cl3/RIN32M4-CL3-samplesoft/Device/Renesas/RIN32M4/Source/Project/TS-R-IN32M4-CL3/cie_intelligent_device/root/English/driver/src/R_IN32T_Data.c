/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_Data.c                                                    */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_ASIC.h"


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

const UCHAR	gauchR_IN32T_RingMACAdrs[R_IN32_MACADR_SZ] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0x00 };

const UCHAR	gauchR_IN32T_TxMACAdrs[R_IN32_MACADR_SZ] = { 0x00, 0x11, 0x22, 0x33, 0x44, 0xFF };

const ULONG gaulR_IN32T_NCycTxBufAdr[R_IN32T_TD_NCYC_NUM] = {
	(ULONG)&TRNMAP->auchTransientSndRAM1520[0],		
	(ULONG)&TRNMAP->auchTransientSndRAM1152[0]  	
};


/*** EOF ***/
