/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32T_RegChk.c                                                  */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32.h"
#include "R_IN32T.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32T_RegChk.h"
#include "R_IN32T_Com.h"


/****************************************************************************/
/* Static functions                                                         */
/****************************************************************************/
static ERRCODE erR_IN32T_AsicRegCheck_INT1( VOID );
static ERRCODE erR_IN32T_AsicRegCheck_NRRXCTR( ULONG );
static ERRCODE erR_IN32T_AsicRegCheck_NRRXERR( ULONG );
static ERRCODE erR_IN32T_AsicRegCheck_HecDcsERR( VOID );


ERRCODE erR_IN32T_AsicRegCheck_NonCyclic(
	ULONG	ulRxNCycNum		
)
{
	ERRCODE		erResult;		
	ERRCODE		erRet;			


	erResult = R_IN32_OK;		

	erRet = erR_IN32T_AsicRegCheck_INT1();
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	erRet = erR_IN32T_AsicRegCheck_NRRXCTR( ulRxNCycNum );
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	erRet = erR_IN32T_AsicRegCheck_NRRXERR( 0UL );
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	erRet = erR_IN32T_AsicRegCheck_HecDcsERR();
	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	return( erResult );
}

ERRCODE erR_IN32T_AsicRegCheck_INT1( VOID )
{
	USHORT					usBitPtn;		
	USHORT					usExpect;		
	USHORT*					pusAdr;			
	ERRCODE					erResult;		


	pusAdr = (USHORT*)&INTRST->INT1.usDATA;

	usBitPtn = INT1_MACSENDERR;

	usExpect = (USHORT)0x0000;


	erResult = erR_IN32T_Com_BitCompExpect_Word( pusAdr, usBitPtn, usExpect );

	return( erResult );
}

ERRCODE erR_IN32T_AsicRegCheck_NRRXCTR(
	ULONG	ulRxNCycNum		
)
{
	USHORT					usBitPtn;		
	USHORT					usExpect;		
	USHORT*					pusAdr;			
	ERRCODE					erResult;		


	pusAdr = (USHORT*)&RX->ulNonCyclicRecValidCnt;

	usBitPtn = (USHORT)0xFFFF;

	if ( 0x0000FFFFUL >= ulRxNCycNum ) {	
		usExpect = (USHORT)ulRxNCycNum;
	}
	else {									
		usExpect = (USHORT)0xFFFF;
	}


	erResult = erR_IN32T_Com_BitCompExpect_Word( pusAdr, usBitPtn, usExpect );

	return( erResult );
}

ERRCODE erR_IN32T_AsicRegCheck_NRRXERR( 
	ULONG	ulRxNCycErrNum	
)
{
	USHORT					usBitPtn;		
	USHORT					usExpect;		
	USHORT*					pusAdr;			
	ERRCODE					erResult;		


	pusAdr = (USHORT*)&RX->ulNonCyclicRecRejectCnt;

	usBitPtn = (USHORT)0xFFFF;

	if ( 0x0000FFFFUL >= ulRxNCycErrNum ) {	
		usExpect = (USHORT)ulRxNCycErrNum;
	}
	else {									
		usExpect = (USHORT)0xFFFF;
	}


	erResult = erR_IN32T_Com_BitCompExpect_Word( pusAdr, usBitPtn, usExpect );

	return( erResult );
}

ERRCODE erR_IN32T_AsicRegCheck_HecDcsERR( VOID )
{
	ULONG					ulBitPtn;		
	ULONG					ulExpect;		
	ULONG*					pulAdr;			
	ERRCODE					erRet;			
	ERRCODE					erResult;		


	erResult = R_IN32_OK;


	pulAdr = (ULONG*)&RING->aulMib1Reg[0];

	ulBitPtn = 0xFFFFFFFFUL;

	ulExpect = 0x00000000UL;

	erRet = erR_IN32T_Com_BitCompExpect_DWord( pulAdr, ulBitPtn, ulExpect );

	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}


	pulAdr = (ULONG*)&RING->aulMib1Reg[1];

	ulBitPtn = 0xFFFFFFFFUL;

	ulExpect = 0x00000000UL;

	erRet = erR_IN32T_Com_BitCompExpect_DWord( pulAdr, ulBitPtn, ulExpect );

	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}


	pulAdr = (ULONG*)&RING->aulMib2Reg[0];

	ulBitPtn = 0xFFFFFFFFUL;

	ulExpect = 0x00000000UL;

	erRet = erR_IN32T_Com_BitCompExpect_DWord( pulAdr, ulBitPtn, ulExpect );

	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}


	pulAdr = (ULONG*)&RING->aulMib2Reg[1];

	ulBitPtn = 0xFFFFFFFFUL;

	ulExpect = 0x00000000UL;

	erRet = erR_IN32T_Com_BitCompExpect_DWord( pulAdr, ulBitPtn, ulExpect );

	if ( R_IN32_ERR == erRet ) {
		erResult = R_IN32_ERR;
	}
	else {
	}

	return( erResult );
}

/*** EOF ***/
