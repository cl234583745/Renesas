/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32C_R_IN32DInterface.c                                          */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32C_l.h"


ERRCODE erR_IN32C_R_IN32DInit_DisableInt(
	const UCHAR* puchMACAddr,		
	ULONG*       pulResetLevel		
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_Init(puchMACAddr,pulResetLevel);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_MacIp_AccessEnable_DisableInt(VOID)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_MacIp_AccessEnable();

	gR_IN32R_EnableInt();

	return erRet;
}


ERRCODE erR_IN32C_GetTranTDIS_DisableInt(
	USHORT usSize,					
	VOID** ppvSendFrmAddr,			
	UCHAR* puchTDISNo				
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_GetTranTDIS(usSize, ppvSendFrmAddr, puchTDISNo);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_EntryTranTDIS_DisableInt(
	UCHAR uchTDISNo,	
	USHORT usSize		
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_EntryTranTDIS(uchTDISNo, usSize);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_GetTranSndSts_DisableInt(
	R_IN32C_TDIS_RES_T *astTDIS	
)
{
	ERRCODE erRet = R_IN32C_OK;
	ERRCODE erRet2;
	ULONG ulIdx;
	UCHAR uchTDISNo;
	ULONG ulSts;

	gR_IN32R_DisableInt();

	for (ulIdx=0; ulIdx<TD_TRAN_NUM; ulIdx++) {

		while (1) {
			erRet2 = gerR_IN32D_GetTranSndSts(&uchTDISNo, &ulSts);
			if (R_IN32D_BUSY != erRet2) {
				break;
			}
			else {
			}
		}

		if(R_IN32D_OK == erRet2){
			astTDIS[ulIdx].blValid = R_IN32_TRUE;
			astTDIS[ulIdx].uchNum  = uchTDISNo;
			astTDIS[ulIdx].ulSts   = ulSts;
		}
		else {
			break;
		}
	}

	gR_IN32R_EnableInt();

	return erRet;
}


ERRCODE erR_IN32C_StartRing_DisableInt(VOID)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_StartRing();

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_GetNetworkTime_DisableInt(
	USHORT*	pusTimeHi,	
	USHORT*	pusTimeMid,	
	USHORT*	pusTimeLo	
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_GetNetworkTime(pusTimeHi, pusTimeMid, pusTimeLo);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_SetNetworkTime_DisableInt(
	USHORT	usTimeHi,	
	USHORT	usTimeMid,	
	USHORT	usTimeLo	
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_SetNetworkTime(usTimeHi, usTimeMid, usTimeLo);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_GetRcvTran_DisableInt(
	ULONG*	pulSize,		
	VOID**	ppRcvbuf		
)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_GetRcvTran(pulSize, ppRcvbuf);

	gR_IN32R_EnableInt();

	return erRet;
}

ERRCODE erR_IN32C_SetRcvTranFin_DisableInt(VOID)
{
	ERRCODE erRet;

	gR_IN32R_DisableInt();

	erRet = gerR_IN32D_SetRcvTranFin();

	gR_IN32R_EnableInt();

	return erRet;
}

/*** EOF ***/
