/**
 *******************************************************************************
 * @file  kernel_id.h
 * @brief HW-RTOS kernel configuration file
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program.
 *  Renesas Electronics assumes no responsibility for any losses incurred.
 *
 *******************************************************************************
 */

#ifndef	KERNEL_ID_H__
#define	KERNEL_ID_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "kernel.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
// --- Task ID ---
#define ID_TASK_INIT	 1
#define ID_TASK_MAIN	 2
//uNet3
#define ID_TASK_TCP_TIM  3
#define ID_TASK_ETH_SND  5
#define ID_TASK_ETH_RCV  6
#define ID_TASK_ETH_OVF 20
//HTTP server sample
#define ID_TASK_HTTPS    7
//PHY
#define ID_TASK_PHY0_LINK 8
#define ID_TASK_PHY1_LINK 9
//SNMP
#define ID_TASK_SNMP_RCV 10
#define ID_TASK_SNMP_TIM 11
#define ID_TASK_SNMP_TRP 12
//EtherSW
#define ID_TASK_MAC_LRN  13

#define ID_TASK_IDLE	63

// --- Semaphore/Mutex ID ---
#define ID_APL_SEM1		 1
#define ID_APL_SEM2		 2
#define ID_APL_MTX1		 3
#define ID_APL_MTX2		 4
//uNet3
#define ID_SEM_TCP		 5
#define ID_SEM_INTDMA	 6
#define ID_SEM_STS		 7
//SNMP
#define ID_SEM_SNMP_MIB  8
#define ID_SEM_SNMP_TRP  9

// --- Eventflag ID ---
#define ID_APL_FLG1		 1
#define ID_APL_FLG2		 2
//uNet3
#define ID_FLG_PHY_STS	 3
#define ID_FLG_ETH_TX_MAC 4
#define ID_FLG_ETH_RX_MAC 5
#define ID_FLG_SYSTEM    6
//SNMP
#define ID_FLG_SNMP_STS  7
#define ID_FLG_SNMP_TRP  8

// --- Mailbox ID ---
#define ID_APL_MBX1		 1
#define ID_APL_MBX2		 2
//uNet3
#define ID_MBX_MEMPOL	 3
#define ID_MBX_ETH_SND	 4
//SNMP
#define ID_MBX_SNMP_TRP  5

#endif // KERNEL_ID_H__
