/**
 *******************************************************************************
 * @file  flash.h
 * @brief Flash ROM control header for R-IN32M4
 * 
 * @note 
 * Copyright (C) 2015 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

#ifndef	FLASH_H__
#define	FLASH_H__

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "RIN32M4.h"
#include "errcodes.h"

/*============================================================================*/
/* T Y P E D E F                                                              */
/*============================================================================*/

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/
/* base address */
#define FLASH_BASE_ADDRESS ((uint32_t)(0x10000000))							/**< Mapped base address of Flash memory */

/* flash configuration */
/* for exsample :  S29GL128S (8M * 16bit) */
/* CIF configuration */
#define FLASH_SUPPORT_CFI (1)												/**< CFI configuration (0=disable, others=enable) */
/* device information */
#define FLASH_BYTE_INDEX_WIDTH   (17)														/**< byte number width in sector (2^17=128 kbyte) */
#define FLASH_SECTOR_INDEX_WIDTH ( 7)														/**< sector number width (2^7=128 sector) : full size */
#define FLASH_BYTE_INDEX_LSB     ( 0)														/**< byte position in sector (LSB) */
#define FLASH_SECTOR_INDEX_LSB   (FLASH_BYTE_INDEX_LSB + FLASH_BYTE_INDEX_WIDTH)			/**< sector position (LSB) */
#define FLASH_SECTOR_SIZE        (1 << (FLASH_BYTE_INDEX_WIDTH                           ))	/**< byte size in sector */
#define FLASH_SECTOR_COUNT       (1 << (FLASH_SECTOR_INDEX_WIDTH                         ))	/**< sector size */
#define FLASH_DEVICE_SIZE        (1 << (FLASH_BYTE_INDEX_WIDTH + FLASH_SECTOR_INDEX_WIDTH))	/**< device size */
#define FLASH_BYTE_INDEX_BIT     ((FLASH_SECTOR_SIZE  - 1) << FLASH_BYTE_INDEX_LSB  )		/**< byte bit in sector */
#define FLASH_SECTOR_INDEX_BIT   ((FLASH_SECTOR_COUNT - 1) << FLASH_SECTOR_INDEX_LSB)		/**< sector bit */

/*============================================================================*/
/* P R O T O T Y P E                                                          */
/*============================================================================*/
ER_RET flash_init(void);
ER_RET flash_read_data(uint16_t* buf, uint32_t addr, uint32_t size);
ER_RET flash_program(uint16_t* buf, uint32_t addr, uint32_t size);
ER_RET flash_erase(uint32_t addr, uint32_t size);
ER_RET flash_read_cfi(uint16_t* buf, uint32_t addr);

#endif // FLASH_H__
