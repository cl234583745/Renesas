/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                         	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver header (common defines)                            */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4TYPES_H__
#define __R_IN32M4TYPES_H__

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define VOID				void
typedef char				CHAR;
typedef unsigned char		UCHAR;
typedef short				SHORT;
typedef unsigned short		USHORT;
typedef int					INT;
typedef unsigned int		UINT;
typedef long				LONG;
typedef unsigned long		ULONG;
typedef int					ERRCODE;
typedef int					BOOL;

#define R_IN32_TRUE				1
#define R_IN32_FALSE			0

#define R_IN32_OK				0			/* Normal end */
#define R_IN32_ERR			(-1)		/* Abnormal end (error condition/inconsistency) */
#define R_IN32_ERR_OTHER		(-2)		/* Abnormal end (error occurred in internal library) */
#define R_IN32_ERR_OUTOFRANGE	(-3)		/* Out of range */
#define R_IN32_ERR_EMPTY		(-4)		/* Empty */
#define R_IN32_ERR_OVERFLOW	(-5)		/* Overflow */
#define R_IN32_ERR_NOENTRY	(-6)		/* No entry */
#define R_IN32_ERR_NOPERMIT	(-7)		/* No permitted */
#define R_IN32_ERR_NODATA		(-8)		/* No data */
#define R_IN32_ERR_NOMYSTATUS	(-9)		/* Valid MyStatus non-existent */

#define R_IN32_SHIFT0			(0)
#define R_IN32_SHIFT1			(1)
#define R_IN32_SHIFT2			(2)
#define R_IN32_SHIFT3			(3)
#define R_IN32_SHIFT4			(4)
#define R_IN32_SHIFT5			(5)
#define R_IN32_SHIFT6			(6)
#define R_IN32_SHIFT7			(7)
#define R_IN32_SHIFT8			(8)
#define R_IN32_SHIFT9			(9)
#define R_IN32_SHIFT10			(10)
#define R_IN32_SHIFT11			(11)
#define R_IN32_SHIFT12			(12)
#define R_IN32_SHIFT13			(13)
#define R_IN32_SHIFT14			(14)
#define R_IN32_SHIFT15			(15)
#define R_IN32_SHIFT16			(16)
#define R_IN32_SHIFT17			(17)
#define R_IN32_SHIFT18			(18)
#define R_IN32_SHIFT19			(19)
#define R_IN32_SHIFT20			(20)
#define R_IN32_SHIFT21			(21)
#define R_IN32_SHIFT22			(22)
#define R_IN32_SHIFT23			(23)
#define R_IN32_SHIFT24			(24)
#define R_IN32_SHIFT25			(25)
#define R_IN32_SHIFT26			(26)
#define R_IN32_SHIFT27			(27)
#define R_IN32_SHIFT28			(28)
#define R_IN32_SHIFT29			(29)
#define R_IN32_SHIFT30			(30)
#define R_IN32_SHIFT31			(31)
#define R_IN32_SHIFT32			(32)

#define	__BUS_RELEASE()



#define R_IN32_MACADR_SZ						6					/* MAC address size */

#define R_IN32_TRAN_SIZE_MAX					1518				/* Transient frame size (maximum) */

#define R_IN32_TRAN_SLMPALL_SIZE_MAX			(1000 + R_IN32_TRAN_SIZE_MAX				\
												- sizeof(R_IN32_NONCICLIC_FRAME_T)	\
												- sizeof(R_IN32_TRAN1_HEAD_T))

#define TRNHEAD_SERIALNO_INIT				(0x80)				/* sequential NO. */
#define TRANSIENT_DATA_MAX_SIZE				(1466)				/*  Transient Data(1frame) Max Size */
#define TRANSIENT_DATA_MIN_SIZE				(12)				/*  Transient Data(1frame) Min Size */
#define TRANSIENT_DATA_SYNTHETIC_MAX_SIZE	(2048)				/* Transient Data Max Size */
#define TRANSIENT_FRAME_SYNTHETIC_MAX_SIZE	(3000)				/* Transient buffer Max Size */


/* Frame type */
#define R_IN32_FTYPE_TRANSIENT1				(UCHAR)0x22			/* Transient1 frame type */

/* Data type */
#define R_IN32_DTYPE_CCLINKTRANSIENT			(UCHAR)0x04			/* CC-Link compatible transient */
#define R_IN32_DTYPE_FIELD					(UCHAR)0x07			/* CC-Link IE Field specific */
#define R_IN32_DTYPE_NETWORK_COMMON			(UCHAR)0x05			/* Network Common */

/* Data sub-type */
	/* Data sub-type in case that data type is Field specific */
#define R_IN32_DSTYPE_FIELD_SYSTEM			(USHORT)0x0002		/* System specific */

	/* Data sub-type in case that data type is Network Common */
#define R_IN32_DSTYPE_SLMP					(USHORT)0x0002		/* SLMP */

/* Type */
#define R_IN32_FRAMETYPE						(USHORT)0x0F89		/* Type (defined in big-endian) */

/* Protocol */
#define R_IN32_PROTOCOL_VER					(UCHAR)0x00			/* Protocol version */

#define R_IN32_PROTOCOL_CLASS					(UCHAR)0x01			/* CC-Link IE Field network  */

/* Frame information */
#define R_IN32_FRAME_INFO_RSV1				(UCHAR)0x00			/* Reserved */

#define R_IN32_FRAME_INFO_PROTOCOL_TYPE_MASK	(USHORT)0x000F		/**< Protocol type */
#define R_IN32_FRAME_INFO_PROTOCOL_VER_MASK	(USHORT)0x00F0		/**< Protocol version */
#define R_IN32_FRAME_INFO_RESERVED			(USHORT)0xFF00		/**< Reserved */
#define R_IN32_FRAME_INFO_PROTOCOL_VER_SHIFT	4
#define R_IN32_FRAME_INFO_RESERVED_SHIFT		8

/* Station No. */
#define R_IN32_NODE_NUMBER_MAX				120					/* Station No. (maximum) */

/* Network No. */
#define R_IN32_NETWORK_NUMBER_MIN				1					/* Network No. (minimum) */
#define R_IN32_NETWORK_NUMBER_MAX				239					/* Network No. (maximum) */

/* Destination Station No. */
#define R_IN32_NODE_NUM_ALL					0xFFFF				/* Broadcast */

/* Destination network No. */
#define R_IN32_NETWORK_NUMBER_BROADCAST		0x00				/* Broadcast */

/* MAC address distribution */
#define R_IN32_NODEINFO_NUMMAX				120					/* Number of distribution (maximum) */
#define R_IN32_NODEINFO_SEQNUMBER_MIN			1					/* Distribution sequential number (minimum) */
#define R_IN32_NODEINFO_SEQNUMBER_MAX			7					/* Distribution sequential number (maximum) */

/* Availability of other functions (MAC address distribution) */
#define R_IN32_AVAILABLEFUNCS_TRANRCV			(UCHAR)0x01			/* bit for Transient reception function availability */

/* PHY Link State */
#define 	R_IN32_PORT_LINK_DOWN				((ULONG)0)			/* Link Down */
#define 	R_IN32_PORT_LINK_UP				((ULONG)1)			/* Link Up */

/* SLMP END CODE */
#define R_IN32_SLMP_FINCODE_OK				(USHORT)0x0000		/* SLMP No Error */
#define R_IN32_SLMP_FINCODE_NETWORK_NO_NG		(USHORT)0x0001		/* SLMP network No. Error available */
#define R_IN32_SLMP_FINCODE_NODE_NO_NG		(USHORT)0x0002		/* SLMP Station No.Error available */
#define R_IN32_SLMP_FINCODE_BUFFER_ACCESS		(USHORT)0x0004		/* SLMP Buffer access Error available */

/* GCNT */
#define R_IN32_GCNT_INITIAL					(UCHAR)0xFF			/* GCNT */

/* fixed pattern */
#define R_IN32_FTYPE_REQUEST					(USHORT)0x0054		/* Request frame */
#define R_IN32_FTYPE_RESPONSE					(USHORT)0x00D4		/* Response frame */

/* SLMP unit I/O number */
#define R_IN32_DEFAULT_UNIT_IO_NO				(USHORT)0x03FF		/* Default */

/* Contact Test Data Size */
#define R_IN32_CONTACT_TEST_LIMIT_BYTESIZE	900					/* Max Data Size */

/* Cable Test Data Size */
#define R_IN32_CABLE_TEST_RESULT_MAX			32					/* Max Result Num */

/* Cable Test Response frame Data area */
#define R_IN32_CABLE_TEST_OK					((USHORT)0x0000)	/* Test result OK */
#define R_IN32_CABLE_TEST_NG					((USHORT)0x0002)	/* Test result NG */

/* Buffer memory detail */
#define R_IN32_BUFFER_MEMORY_TAIL				((USHORT)0x0BB8)	/* Buffer memory tail */
#define R_IN32_BUFFER_MEMORY_SIZE				((USHORT)0x0BB8)	/* Buffer memory size */
#define R_IN32_DATA_SIZE_IN_FRAME				((USHORT)0x03C0)	/* The data size in the frame */


/* PHY Link State */
#define R_IN32_PORT_LINK_DOWN		((ULONG)0)			/* Link Down */
#define R_IN32_PORT_LINK_UP		((ULONG)1)			/* Link Up */


/* Select Information (SW0064) */
#define R_IN32_PORT1_OK_PORT2_OK	((USHORT)0x00)		/* OK(PORT1 OK, PORT2 OK) */
#define R_IN32_PORT1_OK_PORT2_NG	((USHORT)0x01)		/* OK(PORT1 OK, PORT2 NG) */
#define R_IN32_PORT1_NG_PORT2_OK	((USHORT)0x10)		/* OK(PORT1 NG, PORT2 OK) */
#define R_IN32_PORT1_NG_PORT2_NG	((USHORT)0x11)		/* NG(PORT1 NG, PORT2 NG) */
#define R_IN32_PORT1_LB_PORT2_NG	((USHORT)0x04)		/* OK(PORT1 LOOP BAK, PORT2 NG) */
#define R_IN32_PORT1_NG_PORT2_LB	((USHORT)0x40)		/* OK(PORT1 NG, PORT2 LOOP BAK) */

#define R_IN32_CYCLIC_STA_PRM_NO_RECV		(2)			/* No Parameter */
#define R_IN32_CYCLIC_STA_PRM_RECV_NOW	(3)			/* Parameter check */

/* Data Link Stop Cause(SW0049) */
#define R_IN32_SW49_NML					0x0000		/* Normal */
#define R_IN32_SW49_STOP_DLNK				0x0001		/* Stop Data Link */
#define R_IN32_SW49_DLINK_TIMUP			0x0002		/* Data Link Time Up */
#define R_IN32_SW49_NON_SLAVE				0x0005		/* Non Slave */
#define R_IN32_SW49_NOT_RCV_PAR			0x0010		/* Not Receive Parameter */
#define R_IN32_SW49_PRM_OUT_STNO			0x0011		/* Out Station No. */
#define R_IN32_SW49_PRM_RSVST				0x0012		/* Reserved Station */
#define R_IN32_SW49_DUP_MYSTNO			0x0013		/* Duplicate Station */
#define R_IN32_SW49_DUP_CNTST				0x0014		/* Duplicate Master */
#define R_IN32_SW49_NO_STNO				0x0016		/* No Station No. */
#define R_IN32_SW49_PRM_ERR				0x0018		/* Parameter Error */
#define R_IN32_SW49_PRM_CHG				0x0019		/* Parameter Change */
#define R_IN32_SW49_STTYPE_WRONG			0x001A		/* Station Type Wrong */
#define R_IN32_SW49_CPU_ERR				0x0020		/* CPU Error */
#define R_IN32_SW49_LOOP_ERR				0x0060		/* Loop Back Error */


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

/* Protocol version and type */
typedef struct _R_IN32_FRAME_INFO_TAG {
	union {
		USHORT usAll;
		struct {
	USHORT	b4ZProtocolClassifcation:		4;		/**< Protocol type */
	USHORT	b4ZProtocolVersion:				4;		/**< Protocol version */
	USHORT	b8Reserved1:					8;		/**< Reserved */
		} stBit;
	} uniFrameInfo;
} R_IN32_FRAME_INFO_T;

/*----------------------------------------------*/
/* SLMP Request Frame Setting */
typedef struct _R_IN32_SLMP_REQUSET_SETTING_TAG {
	USHORT	usConectInfo;										/**< Destination Connect Info */
	USHORT	usNwNo;												/**< Destination Network No. */
	UCHAR	uchNode;											/**< Destination Node */
	USHORT	usL;												/**< Data size */
	USHORT	usCommand;											/**< Command */
	USHORT	usSubCommand;										/**< Sub Command */
} R_IN32_SLMP_REQUSET_SETTING_T;

/*----------------------------------------------*/
/* Transient1 Frame Setting */
typedef struct _R_IN32_TRAN1_REQUEST_SETTING_TAG {
	UCHAR	uchDataClass;										/**< Data class */
	USHORT	usDataSubClass;										/**< Data sub class */
	USHORT	usDataAllSize;										/**< Transient data all size */
	USHORT	usDstNwNo;											/**< Des Network No. */
	USHORT	uchDstNode;											/**< Dst node */
} R_IN32_TRAN1_REQUEST_SETTING_T;


/* MAC + CCIE Header */
typedef struct _R_IN32_NONCICLIC_FRAME_TAG {
	USHORT	usToAddress1;										/**< Destination address (1st, 2nd octet) */
	USHORT	usToAddress2;										/**< Destination address (3rd, 4th octet) */
	USHORT	usToAddress3;										/**< Destination address (5th, 6th octet) */
	USHORT	usFromAddress1;										/**< Sender address (1st, 2nd octet) */
	USHORT	usFromAddress2;										/**< Sender address (3rd, 4th octet) */
	USHORT	usFromAddress3;										/**< Sender address (5th, 6th octet) */
	USHORT	usType;												/**< Type */
	UCHAR	uchFrameClassification;								/**< Frame type */
	UCHAR	uchDataClassification;								/**< Data type */
	USHORT	usNodeID;											/**< Node ID */
	UCHAR	uchConnectionInformation;							/**< Connection information */
	UCHAR	uchReserved;										/**< Reserved */
	USHORT	usMyStationNumber;									/**< Station No. */
	R_IN32_FRAME_INFO_T		stFRAME_INFO;						/**< Protocol version and type */
	ULONG	ulHEC;												/**< HEC */
} R_IN32_NONCICLIC_FRAME_T;


/*==============================================================*/
/* Transient1 frame format                                      */
/*==============================================================*/

/*----------------------------------------------*/
/* Transient Header */
typedef struct _R_IN32_TRAN1_HEAD_TAG {
	ULONG	ulReserved1;										/**< Reserved */
	UCHAR	uchSequentialNumber;								/**< Sequential number */
	UCHAR	uchIdentificationNumber;							/**< Identification number */
	USHORT	usTransientDataAllSize;								/**< Total size of transient data  */
	ULONG	ulOffsetAddress;									/**< Offset address */
	USHORT	usTransientDataDivisionSize;						/**< Transient data size in the frame */
	USHORT	usDataSubClassification;							/**< Data sub-type */
} R_IN32_TRAN1_HEAD_T;

/*----------------------------------------------*/
/* Data area */

/* Extension Header */
typedef struct _R_IN32_EXTENSION_HEAD_TAG {
	UCHAR	uchCommandType;										/**< Field specific command type */
	UCHAR	uchSubCommandType;									/**< Sub-command type */
	USHORT	usReturn;											/**< Return value */
	UCHAR	uchReserved1;										/**< Reserved */
	UCHAR	uchDestNetNumber;									/**< Destination network No. */
	USHORT	usDestNodeNumber;									/**< Destination Station No. */
	USHORT	usReserved2;										/**< Reserved */
	USHORT	usReserved3;										/**< Reserved */
	UCHAR	uchReserved4;										/**< Reserved */
	UCHAR	uchSrcNetNumber;									/**< Transmission source network No. */
	USHORT	usSrcNodeNumber;									/**< Transmission source Station No. */
	USHORT	usReserved5;										/**< Reserved */
	USHORT	usReserved6;										/**< Reserved */
} R_IN32_EXTENSION_HEAD_T;

/*----------------------------------------------*/
/* Extension Header, Data area */
typedef struct _R_IN32_EXTENSION_HEAD_DATA_TAG {
	R_IN32_EXTENSION_HEAD_T			stOPHEAD;					/**< Extension header */
	UCHAR	auchDataArea[R_IN32_TRAN_SIZE_MAX - sizeof(R_IN32_NONCICLIC_FRAME_T) - sizeof(R_IN32_TRAN1_HEAD_T)-sizeof(R_IN32_EXTENSION_HEAD_T)];
} R_IN32_EXTENSION_HEAD_DATA_T;

/*----------------------------------------------*/
/* General body of Transient1 data area */
typedef union _R_IN32_TRAN1_DATA_TAG {
	R_IN32_EXTENSION_HEAD_DATA_T		stOPHEAD_DATA;				/**< Extension header/data */
	UCHAR	auchTransientDataArea[R_IN32_TRAN_SIZE_MAX - sizeof(R_IN32_NONCICLIC_FRAME_T) - sizeof(R_IN32_TRAN1_HEAD_T)];
} R_IN32_TRAN1_DATA_T;

/*----------------------------------------------*/
/* Transient1 frame body */
typedef struct _R_IN32_TRAN1_FRAME_TAG {
	R_IN32_NONCICLIC_FRAME_T		stCOMMON;						/**< MAC + CCIE Header */
	R_IN32_TRAN1_HEAD_T			stHEAD;							/**< Header area */
	R_IN32_TRAN1_DATA_T			uniDATA;						/**< Data area */
} R_IN32_TRAN1_FRAME_T;

/*----------------------------------------------*/
/* Statistic information response data */
typedef struct _R_IN32_TRAN1_STAINF_DATA_TAG {
	ULONG		ulP1Mib1;										/**< PORT1 HEC error counter */
	ULONG		ulP1Mib2;										/**< PORT1 DCS/FCS error counter */
	ULONG		ulP1Mib3;										/**< PORT1 Under size error counter */
	ULONG		ulP1Mib4;										/**< PORT1 Forward frame counter */
	ULONG		ulP1Mib5;										/**< PORT1 Upward frame counter */
	ULONG		ulP1Mib6;										/**< PORT1 Forward overflow error counter */
	ULONG		ulP1Mib7;										/**< PORT1 Upward overflow error counter */
	ULONG		ulReserved1;									/**< Reserved */
	ULONG		ulP2Mib1;										/**< PORT2 HEC error counter */
	ULONG		ulP2Mib2;										/**< PORT2 DCS/FCS error counter */
	ULONG		ulP2Mib3;										/**< PORT2 Under size error counter */
	ULONG		ulP2Mib4;										/**< PORT2 Forward frame counter */
	ULONG		ulP2Mib5;										/**< PORT2 Upward frame counter */
	ULONG		ulP2Mib6;										/**< PORT2 Forward overflow error counter */
	ULONG		ulP2Mib7;										/**< PORT2 Upward overflow error counter */
	ULONG		ulStsDataNum;									/**< Health status data number */
} R_IN32_TRAN1_STAINF_DATA_T;

/*----------------------------------------------*/
/* Unit information response frame */
typedef struct _R_IN32_TRAN1_UNITINF_DATA_TAG {
	USHORT		usRySize;										/**< RY size  (in octet unit) */
	USHORT		usRWwSize;										/**< RWw size (in word unit) */
	USHORT		usRxSize;										/**< RX size  (in octet unit) */
	USHORT		usRWrSize;										/**< RWr size (in word unit) */
	UCHAR		uchReserved1;									/**< Reserved */
	UCHAR		uchPortTotalNumber;								/**< Number of ports */
	USHORT		usTokenHoldTime;								/**< Token holding time */
	UCHAR		uchTknHoldFrmSendCount;							/**< Network behaviour setting (setting for number of transmission when holding token) */
	UCHAR		uchFramSendInterval;							/**< Network behaviour setting (frame transmission interval setting) */
	UCHAR		uchReserved2;									/**< Reserved */
	UCHAR		uchTokenSendCount;								/**< Network behaviour setting (setting for number of token transmission) */
	UCHAR		uchNodeInformation;								/**< Node information */
	UCHAR		uchNetVersion;									/**< Network firmware version */
	USHORT		usNetModelType;									/**< Network model type */
	ULONG		ulNetUnitModelCode;								/**< Network unit model code */
	USHORT		usNetVendorCode;								/**< Network vendor code */
	USHORT		usReserved3;									/**< Reserved */
	UCHAR		auchNetUnitModelName[20];						/**< Network unit model name */
	UCHAR		auchNetVendorName[32];							/**< Network vendor name */
	UCHAR		uchInformationFlag;								/**< Controller information flag */
	UCHAR		uchCtrlVersion;									/**< Controller firmware version */
	USHORT		usCtrlModelType;								/**< Controller model type */
	ULONG		ulCtrlUnitModelCode;							/**< Controller unit model code */
	USHORT		usCtrlVendorCode;								/**< Controller vendor code */
	USHORT		usReserved4;									/**< Reserved */
	UCHAR		auchCtrlUnitModelName[20];						/**< Controller unit model name */
	UCHAR		auchCtrlVendorName[32];							/**< Controller vendor name */
	ULONG		ulVendorInformation;							/**< Controller vendor device specific information */
} R_IN32_TRAN1_UNITINF_DATA_T;

/*----------------------------------------------*/
/* Option information response Data */
typedef struct _R_IN32_TRAN1_OPTINF_DATA_TAG {
	USHORT							usFWVer;					/**< basic unit F/W version */
	USHORT							usHWVer;					/**< basic unit H/W version */
	USHORT							usFuncVer;					/**< equipment version */
	USHORT							usRsv1;						/**< Reserved */
	USHORT							usSuppFunc;					/**< Option support */
	USHORT							usOptSize;					/**< Option Size */
} R_IN32_TRAN1_OPTINF_DATA_T;

/*----------------------------------------------*/
/* Structure CT */
typedef	struct	_R_IN32_CT_DTL {
	UCHAR							b7ZCommand:7;				/**< command */
	UCHAR							b1ZFrameType:1;				/**< Frame classification */
}	R_IN32_CT_DTL;

/*----------------------------------------------*/
/* Union CT */
typedef	union	_R_IN32_CT_TAG {
	UCHAR							uchCt;
	R_IN32_CT_DTL						stCtDtl;
}	R_IN32_CT_TAG;

/*-------------------------------------------------*/
/* Transient2 Header information(L ~ APS) (Postulation/reply commonness) */
typedef	struct	_R_IN32_CCLINK_HEAD_TAG {
	USHORT							usL;						/**< L    Frame size(Length)            */
	UCHAR							uchGcnt;					/**< GCNT Relay counter                 */
	UCHAR							uchTP;						/**< TP   Unused(Type/SequenceFlag)     */
	UCHAR							uchFNO;						/**< FNO  Division frameNo.(FrameNo)    */
	UCHAR							uchDT;						/**< DT   DataFrameType                 */
	UCHAR							uchDA;						/**< DA   DestinationAddress            */
	UCHAR							uchSA;						/**< SA   SourceAddress                 */
	UCHAR							uchDAT;						/**< DAT  Destination Application Type  */
	UCHAR							uchSAT;						/**< SAT  Source Application Type       */
	UCHAR							uchDMF;						/**< DMF  Destination Module Flag       */
	UCHAR							uchSMF;						/**< SMF  Source Module Flag            */
	UCHAR							uchDNA;						/**< DNA  Destination network No.       */
	UCHAR							uchDS;						/**< DS   Destination station No.       */
	USHORT							usDID;						/**< DID  Destination ID(ID Number)     */
	UCHAR							uchSNA;						/**< SNA  Source network No.            */
	UCHAR							uchSS;						/**< SS   Source station No.            */
	USHORT							usSID;						/**< SID  Source ID                     */
	USHORT							usL1;						/**< L1   Frame size(Length1)           */
	R_IN32_CT_TAG					stCT;							/**< CT   Command Type                  */
	UCHAR							uchDno;						/**< DNO  Division distinction(Data No) */
	USHORT							usAPS;						/**< APS  Application sequence No.      */
} R_IN32_CCLINK_HEAD_T;

/*---------------------------------------------------------------*/
/* SLMP Header information(Sub header - Data size(L1)) (Postulation/reply commonness) */
#pragma pack(1)
typedef	struct	_R_IN32_SLMP_HEAD_TAG {
	USHORT							usFType;					/**< Frame classification */
	USHORT							usSerialNo;					/**< serial No. */
	USHORT							usRsv;						/**< fixed value */
	UCHAR							uchNetworkNo;				/**< Destination network No. */
	UCHAR							uchStationNo;				/**< Destination station No. */
	USHORT							usModuleIONo;				/**< Destination unit I/O number */
	UCHAR							uchRequStNo;				/**< Destination multi-drop number */
	USHORT							usL;						/**< Data size */
} R_IN32_SLMP_HEAD_T;

/*------------------------------------*/
/* SLMP Request frame format */

typedef struct _R_IN32_SLMP_REQUEST_FRAME_TAG {
	R_IN32_CCLINK_HEAD_T				stCCLinkHead;				/**< Transient2 Header information */
	R_IN32_SLMP_HEAD_T				stSlmpHead;					/**< SLMP Header information */
	USHORT							usTimer;					/**< Watch timer */
	USHORT							usCommand;					/**< Command */
	USHORT							usSubCommand;				/**< Sub Command */
} R_IN32_SLMP_REQUEST_FRAME_T;


/*------------------------------------*/
/* SLMP Response frame format */
typedef struct _R_IN32_SLMP_RESPONSE_FRAME_TAG {
	R_IN32_CCLINK_HEAD_T				stCCLinkHead;				/**< Transient2 Header information */
	USHORT							usRSTS;						/**< Return status */
	R_IN32_SLMP_HEAD_T				stSlmpHead;					/**< SLMP Header information */
	USHORT							usFinCode;					/**< End Code */
} R_IN32_SLMP_RESPONSE_FRAME_T;

/*----------------------------------------------*/
/* SLMP Response frame All */
typedef struct _R_IN32_SLMP_REQUEST_FRAME_ALL_TAG {
	R_IN32_NONCICLIC_FRAME_T			stCOMMON;					/**< MAC + CCIE Header */
	R_IN32_TRAN1_HEAD_T				stHEAD;						/**< Header area */
	R_IN32_SLMP_REQUEST_FRAME_T		stExHead;					/**< SLMP Response frame format */
	UCHAR							auchDataArea[R_IN32_TRAN_SIZE_MAX
													- sizeof(R_IN32_NONCICLIC_FRAME_T)
													- sizeof(R_IN32_TRAN1_HEAD_T)
													- sizeof(R_IN32_SLMP_REQUEST_FRAME_T)];
} R_IN32_SLMP_REQUEST_FRAME_ALL_T;


/*------------------------------------*/
/* SLMP Request data format */
typedef struct _R_IN32_SLMP_REQUEST_DATA_TAG {
	R_IN32_SLMP_REQUEST_FRAME_T		stExHead;					/**< SLMP Response frame format */
	UCHAR							auchDataArea[R_IN32_TRAN_SLMPALL_SIZE_MAX];	/**< Data area */
} R_IN32_SLMP_REQUEST_DATA_T;

/*----------------------------------------------*/
/* SLMP Response frame All */
typedef struct _R_IN32_SLMP_RESPONSE_FRAME_ALL_TAG {
	R_IN32_NONCICLIC_FRAME_T			stCOMMON;					/**< MAC + CCIE Header */
	R_IN32_TRAN1_HEAD_T				stHEAD;						/**< Header area */
	R_IN32_SLMP_RESPONSE_FRAME_T		stExHead;					/**< SLMP Response frame format */
	UCHAR							auchDataArea[R_IN32_TRAN_SIZE_MAX
													- sizeof(R_IN32_NONCICLIC_FRAME_T)
													- sizeof(R_IN32_TRAN1_HEAD_T)
													- sizeof(R_IN32_SLMP_RESPONSE_FRAME_T)];
} R_IN32_SLMP_RESPONSE_FRAME_ALL_T;

/*------------------------------------*/
/* SLMP Request data format */
typedef struct _R_IN32_SLMP_RESPONSE_DATA_TAG {
	R_IN32_SLMP_RESPONSE_FRAME_T		stExHead;					/**< SLMP Response frame format */
	UCHAR							auchDataArea[R_IN32_TRAN_SLMPALL_SIZE_MAX];	/**< Data area */
} R_IN32_SLMP_RESPONSE_DATA_T;

/*----------------------------------------------*/
/* Select information Data area(Response) */

/* SB0040-SB009F */
typedef struct _R_IN32_SELECTINFO_SB_TAG {
	USHORT							usSB0040;					/**< SB0040~004F */
	USHORT							usSB0050;					/**< SB0050~005F */
	USHORT							usSB0060;					/**< SB0060~006F */
	USHORT							usSB0070;					/**< SB0070~007F */
	USHORT							usSB0080;					/**< SB0080~008F */
	USHORT							usSB0090;					/**< SB0090~009F */
} R_IN32_SELECTINFO_SB_T;

/* SW0040-SW009F */
typedef struct _R_IN32_SELECTINFO_SW_TAG {
	USHORT							usSW0040;					/**< SW0040 */
	USHORT							usSW0041;					/**< SW0041 */
	USHORT							usSW0042;					/**< SW0042 */
	USHORT							usSW0043;					/**< SW0043 */
	USHORT							usSW0044;					/**< SW0044 */
	USHORT							usSW0045;					/**< SW0045 */
	USHORT							usSW0046;					/**< SW0046 */
	USHORT							usSW0047;					/**< SW0047 */
	USHORT							usSW0048;					/**< SW0048 */
	USHORT							usSW0049;					/**< SW0049 */
	USHORT							usSW004A;					/**< SW004A */
	USHORT							usSW004B;					/**< SW004B */
	USHORT							usSW004C;					/**< SW004C */
	USHORT							usSW004D;					/**< SW004D */
	USHORT							usSW004E;					/**< SW004E */
	USHORT							usSW004F;					/**< SW004F */
	USHORT							usSW0050;					/**< SW0050 */
	USHORT							usSW0051;					/**< SW0051 */
	USHORT							usSW0052;					/**< SW0052 */
	USHORT							usSW0053;					/**< SW0053 */
	USHORT							usSW0054;					/**< SW0054 */
	USHORT							usSW0055;					/**< SW0055 */
	USHORT							usSW0056;					/**< SW0056 */
	USHORT							usSW0057;					/**< SW0057 */
	USHORT							usSW0058;					/**< SW0058 */
	USHORT							usSW0059;					/**< SW0059 */
	USHORT							usSW005A;					/**< SW005A */
	USHORT							usSW005B;					/**< SW005B */
	USHORT							usSW005C;					/**< SW005C */
	USHORT							usSW005D;					/**< SW005D */
	USHORT							usSW005E;					/**< SW005E */
	USHORT							usSW005F;					/**< SW005F */
	USHORT							usSW0060;					/**< SW0060 */
	USHORT							usSW0061;					/**< SW0061 */
	USHORT							usSW0062;					/**< SW0062 */
	USHORT							usSW0063;					/**< SW0063 */
	USHORT							usSW0064;					/**< SW0064 */
	USHORT							usSW0065;					/**< SW0065 */
	USHORT							usSW0066;					/**< SW0066 */
	USHORT							usSW0067;					/**< SW0067 */
	USHORT							usSW0068;					/**< SW0068 */
	USHORT							usSW0069;					/**< SW0069 */
	USHORT							usSW006A;					/**< SW006A */
	USHORT							usSW006B;					/**< SW006B */
	USHORT							usSW006C;					/**< SW006C */
	USHORT							usSW006D;					/**< SW006D */
	USHORT							usSW006E;					/**< SW006E */
	USHORT							usSW006F;					/**< SW006F */
	USHORT							usSW0070;					/**< SW0070 */
	USHORT							usSW0071;					/**< SW0071 */
	USHORT							usSW0072;					/**< SW0072 */
	USHORT							usSW0073;					/**< SW0073 */
	USHORT							usSW0074;					/**< SW0074 */
	USHORT							usSW0075;					/**< SW0075 */
	USHORT							usSW0076;					/**< SW0076 */
	USHORT							usSW0077;					/**< SW0077 */
	USHORT							usSW0078;					/**< SW0078 */
	USHORT							usSW0079;					/**< SW0079 */
	USHORT							usSW007A;					/**< SW007A */
	USHORT							usSW007B;					/**< SW007B */
	USHORT							usSW007C;					/**< SW007C */
	USHORT							usSW007D;					/**< SW007D */
	USHORT							usSW007E;					/**< SW007E */
	USHORT							usSW007F;					/**< SW007F */
	USHORT							usSW0080;					/**< SW0080 */
	USHORT							usSW0081;					/**< SW0081 */
	USHORT							usSW0082;					/**< SW0082 */
	USHORT							usSW0083;					/**< SW0083 */
	USHORT							usSW0084;					/**< SW0084 */
	USHORT							usSW0085;					/**< SW0085 */
	USHORT							usSW0086;					/**< SW0086 */
	USHORT							usSW0087;					/**< SW0087 */
	USHORT							usSW0088;					/**< SW0088 */
	USHORT							usSW0089;					/**< SW0089 */
	USHORT							usSW008A;					/**< SW008A */
	USHORT							usSW008B;					/**< SW008B */
	USHORT							usSW008C;					/**< SW008C */
	USHORT							usSW008D;					/**< SW008D */
	USHORT							usSW008E;					/**< SW008E */
	USHORT							usSW008F;					/**< SW008F */
	USHORT							usSW0090;					/**< SW0090 */
	USHORT							usSW0091;					/**< SW0091 */
	USHORT							usSW0092;					/**< SW0092 */
	USHORT							usSW0093;					/**< SW0093 */
	USHORT							usSW0094;					/**< SW0094 */
	USHORT							usSW0095;					/**< SW0095 */
	USHORT							usSW0096;					/**< SW0096 */
	USHORT							usSW0097;					/**< SW0097 */
	USHORT							usSW0098;					/**< SW0098 */
	USHORT							usSW0099;					/**< SW0099 */
	USHORT							usSW009A;					/**< SW009A */
	USHORT							usSW009B;					/**< SW009B */
	USHORT							usSW009C;					/**< SW009C */
	USHORT							usSW009D;					/**< SW009D */
	USHORT							usSW009E;					/**< SW009E */
	USHORT							usSW009F;					/**< SW009F */
} R_IN32_SELECTINFO_SW_T;

/* LED information */
typedef	struct	_R_IN32_LED_INFO_TAG {
	UCHAR							uchColor;					/**< LED Color */
	UCHAR							uchState;					/**< LED State */
} R_IN32_LED_INFO_T;

/* My LED information */
typedef	struct	_R_IN32_SELECTINFO_LED_INFO_TAG {
	UCHAR							uchRow;						/**< LED Row */
	UCHAR							uchColumn;					/**< LED Column */
	R_IN32_LED_INFO_T				stLedInf[8];					/**< LED information 1 - 8 */
} R_IN32_SELECTINFO_LED_INFO_T;

/*---------------------------------------------------*/
/* SLMP Select Information(Response) Frame format */
typedef struct _R_IN32_SELECTINFO_RESPONSE_FRAME_TAG {
	R_IN32_SELECTINFO_SB_T			stSB;						/**< SB0040-SB009F */
	R_IN32_SELECTINFO_SW_T			stSW;						/**< SW0040-SW009F */
	R_IN32_SELECTINFO_LED_INFO_T		stLED;						/**< My LED information */
	USHORT							usFromAddress1;				/**< Sender address (1st, 2nd octet) */
	USHORT							usFromAddress2;				/**< Sender address (3rd, 4th octet) */
	USHORT							usFromAddress3;				/**< Sender address (5th, 6th octet) */
	USHORT							usRsv1;						/**< Reserved1 */
	USHORT							usMakerCode;				/**< Maker Code */
	ULONG							ulModelCode;				/**< Model Code */
	USHORT							usRsv2;						/**< Reserved2*/
	UCHAR							auchRsv[3];					/**< Reserved3 */
} R_IN32_SELECTINFO_RESPONSE_FRAME_T;

/* MAC address distribution data part (each node information) */
typedef struct _R_IN32_NODEINFO_TAG {
	USHORT			usNodeNumber;						/**< Station No. */
	UCHAR			uchReserved1;						/**< Reserved */
	UCHAR			uchAvailableFuncs;					/**< Available functions */
	UCHAR			uchReserved2;						/**< Reserved */
	UCHAR			uchNetNumber;						/**< network No. */
	USHORT			usDeviceType;						/**< Device type */
	ULONG			ulModelCode;						/**< Model code */
	USHORT			usVendorCode;						/**< Vendor code */
	UCHAR			uchNodeType;						/**< Node type */
	UCHAR			uchReserved3;						/**< Reserved */
	UCHAR			auchMACAddress[6];					/**< MAC address */
	USHORT			usReserved4;						/**< Reserved */
} R_IN32_NODEINFO_T;

/* MAC address distribution data area body */
typedef struct _R_IN32_NODEINFO_DIST_TAG {
	UCHAR			uchSeqNumber;						/**< Distribution sequential number */
	UCHAR			uchMasterNetNumber;					/**< Master station network No. */
	USHORT			usMasterDeviceType;					/**< Master station device type */
	ULONG			ulMasterModelCode;					/**< Master station model code */
	USHORT			usMasterVendorCode;					/**< Master station vendor code */
	UCHAR			uchMasterNodeType;					/**< Master station node type */
	UCHAR			uchReserved1;						/**< Reserved */
	UCHAR			auchMasterMACAddress[6];			/**< Master station MAC address */
	USHORT			usReserved2;						/**< Reserved */
	ULONG			ulDataNum;							/**< Number of distribution */
	R_IN32_NODEINFO_T	astNodeInfo[R_IN32_NODEINFO_NUMMAX];	/**< Node Information */
} R_IN32_NODEINFO_DIST_T;

/*--------------------------------------*/
/* SLMP Error Response Frame format */
typedef struct _R_IN32_SLMP_ERROR_RESPONSE_FRAME_TAG {
	UCHAR							uchNetWorkNo;				/**< Destination network No. */
	UCHAR							uchPcNo;					/**< Destination station No. */
	USHORT							usRespUtIONo;				/**< Destination unit I/O number */
	UCHAR							uchRequStNo;				/**< Destination multi-drop number */
	USHORT							usCmd;						/**< Command */
	USHORT							usSubCmd;					/**< Sub Command */
} R_IN32_SLMP_ERROR_RESPONSE_FRAME_T;
#pragma pack()

/*--------------------------------------*/
/* Data Link Stop Cause */
typedef	struct	_R_IN32_STP_CAUSE_DTL_TAG {
	USHORT		b1ZStpNoStNo:			1;						/**< b0     : No Station No.              */
	USHORT		b1ZStpCpuErr:			1;						/**< b1     : Cpu Error                   */
	USHORT		b1ZStpOutRangeSta:		1;						/**< b2     : Out Range Station No.       */
	USHORT		b1ZStpStaClass:			1;						/**< b3     : node type mismatch          */
	USHORT		b1ZStpMstDupSta:		1;						/**< b4     : Master Duplicate            */
	USHORT		b1ZStpDupSta:			1;						/**< b5     : Duplicate Local station No. */
	USHORT		b1ZStpResvSta:			1;						/**< b6     : Response Station            */
	USHORT		b1ZStpLostMaster:		1;						/**< b7     : Lost Master                 */
	USHORT		b1ZStpCParNg:			1;						/**< b8     : Common parameter NG         */
	USHORT		b1ZStpCParCom:			1;						/**< b9     : Common parameter contacting */
	USHORT		b1ZStpCParNon:			1;						/**< b10    : Common parameter Receiving  */
	USHORT		b1ZStpCycStp:			1;						/**< b11    : Stop Cyclic                 */
	USHORT		b4ZRsv:					4;						/**< b12-15 : Reserved                    */
}	R_IN32_STP_CAUSE_DTL_TAG ;

typedef union _R_IN32_STP_CAUSE_TAG
{
	USHORT					usStpCause ;						/**< Data link stop cause  */
	R_IN32_STP_CAUSE_DTL_TAG	StpDtl ;							/**< Data link stop cause Detailed */
} R_IN32_STP_CAUSE_TAG ;
/*---------------------------------------------------*/
/* SLMP Contact Test(Request) Frame format        */
#pragma pack(1)
typedef struct _R_IN32_CONTACTTEST_REQUEST_FRAME_TAG {
	USHORT							usContactNum;				/**< Number of contact data */
	UCHAR							auchData[R_IN32_CONTACT_TEST_LIMIT_BYTESIZE];
} R_IN32_CONTACTTEST_REQUEST_FRAME_T;

/*---------------------------------------------------*/
/* SLMP Contact Test(Response) Frame format       */
typedef struct _R_IN32_CONTACTTEST_RESPONSE_FRAME_TAG {
	USHORT							usContactNum;				/**< Number of contact data */
	UCHAR							auchData[R_IN32_CONTACT_TEST_LIMIT_BYTESIZE];
} R_IN32_CONTACTTEST_RESPONSE_FRAME_T;

/*---------------------------------------------------*/
/* SLMP Cable Test(Response) Frame format         */
typedef struct _R_IN32_CABLETEST_RESULT_TAG {
	USHORT							usPortNum;					/**< Port Num */
	USHORT							ausPortResult[R_IN32_CABLE_TEST_RESULT_MAX];
} R_IN32_CABLETEST_RESULT_T;

typedef struct _R_IN32_CABLETEST_RESPONSE_FRAME_TAG {
	R_IN32_CABLETEST_RESULT_T			stResult;					/**< Port Result */
} R_IN32_CABLETEST_RESPONSE_FRAME_T;


/*----------------------------------------------------------*/
/* SLMP Read Memory (request) frame format         */
typedef struct _R_IN32_MEMREAD_REQUEST_FRAME_TAG {
	ULONG							ulTopAddress;				/**< Start address of a buffer memory */
	USHORT							usWordSize;					/**< Read size(Word Size) */
} R_IN32_MEMREAD_REQUEST_FRAME_T;

/*----------------------------------------------------------*/
/* SLMP Read Memory (Response) Frame format        */
typedef struct _R_IN32_MEMREAD_RESPONSE_FRAME_TAG {
	UCHAR							auchData[R_IN32_DATA_SIZE_IN_FRAME];	/**< Data in a request area */
} R_IN32_MEMREAD_RESPONSE_FRAME_T;

/*----------------------------------------------------------*/
/* SLMP Write Memory(request) frame format         */
typedef struct _R_IN32_MEMWRITE_REQUEST_FRAME_TAG {
	ULONG							ulTopAddress;				/**< Start address of a buffer memory */
	USHORT							usWordSize;					/**< Write size(Word Size) */
	UCHAR							auchData[R_IN32_DATA_SIZE_IN_FRAME];	/**< Write data */
} R_IN32_MEMWRITE_REQUEST_FRAME_T;
#pragma pack()

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
extern	R_IN32_STP_CAUSE_TAG	gstStopCause;				/* Data Link Stop Cause */


#endif /* __R_IN32M4TYPES_H__ */

/*** EOF ***/
