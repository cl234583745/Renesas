/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                             */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_phy.c                                                     */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"

#include "R_IN32M4_in.h"
#include "R_IN32_Frame.h"
#include "R_IN32.h"
#include "R_IN32C.h"
#include "R_IN32D.h"
#include "R_IN32U.h"
#include "R_IN32S.h"
#include "R_IN32R.h"

#include "R_IN32D_phy_l.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
#define R_IN32D_TMOUTUS_MDIO_CMDFIN		32UL		


ERRCODE gerR_IN32D_PhyGetState(
	ULONG ulPort,			
	ULONG *ulLinkState,		
	ULONG *ulSpeed,			
	ULONG *ulDuplex			
)
{
	ULONG	ulReg;		

	ulReg = RING->ulLinkStat;

	if(ulPort == R_IN32D_PORT1){


		if (LINKSTAT_REG_P1_0_LINKUP == (LINKSTAT_REG_P1_0_LINKUP & ulReg)) {
			*ulLinkState = R_IN32D_LINKUP;
		}
		else {
			*ulLinkState = R_IN32D_LINKDOWN;
		}

		if (LINKSTAT_REG_P1_3_1000MBPSLINK == (LINKSTAT_REG_P1_3_1000MBPSLINK & ulReg)) {
			*ulSpeed = R_IN32D_SPEED_1G;
		}
		else {
			if (LINKSTAT_REG_P1_2_100MBPSLINK == (LINKSTAT_REG_P1_2_100MBPSLINK & ulReg)) {
				*ulSpeed = R_IN32D_SPEED_100M;
			}
			else {
				if (LINKSTAT_REG_P1_1_10MBPSLINK == (LINKSTAT_REG_P1_1_10MBPSLINK & ulReg)) {
					*ulSpeed = R_IN32D_SPEED_10M;
				}
			}
		}

		if (LINKSTAT_REG_P1_4_FULLLINK == (LINKSTAT_REG_P1_4_FULLLINK & ulReg)) {
			*ulDuplex = R_IN32D_DUPLEX_FULL;
		}
		else {
			*ulDuplex = R_IN32D_DUPLEX_HALF;
		}
	}
	else{


		if (LINKSTAT_REG_P2_0_LINKUP == (LINKSTAT_REG_P2_0_LINKUP & ulReg)) {
			*ulLinkState = R_IN32D_LINKUP;
		}
		else {
			*ulLinkState = R_IN32D_LINKDOWN;
		}

		if (LINKSTAT_REG_P2_3_1000MBPSLINK == (LINKSTAT_REG_P2_3_1000MBPSLINK & ulReg)) {
			*ulSpeed = R_IN32D_SPEED_1G;
		}
		else {
			if (LINKSTAT_REG_P2_2_100MBPSLINK == (LINKSTAT_REG_P2_2_100MBPSLINK & ulReg)) {
				*ulSpeed = R_IN32D_SPEED_100M;
			}
			else {
				if (LINKSTAT_REG_P2_1_10MBPSLINK == (LINKSTAT_REG_P2_1_10MBPSLINK & ulReg)) {
					*ulSpeed = R_IN32D_SPEED_10M;
				}
			}
		}

		if (LINKSTAT_REG_P2_4_FULLLINK == (LINKSTAT_REG_P2_4_FULLLINK & ulReg)) {
			*ulDuplex = R_IN32D_DUPLEX_FULL;
		}
		else {
			*ulDuplex = R_IN32D_DUPLEX_HALF;
		}
	}

	return( R_IN32D_OK );
}

ERRCODE gerR_IN32D_MACIP_PHYWrite(
	ULONG	ulPort,			
	ULONG	ulRegAdrs,		
	ULONG	ulWriteData		
	)
{
	ULONG			ulPHYadrs;			
	ERRCODE			erResult;			


	if ( R_IN32D_PORT1 == ulPort ) {
		ulPHYadrs = (GMAC->ulMacIpAccess & 0x00001F00) >> 8;
	}
	else {
		ulPHYadrs = (GMAC->ulMacIpAccess & 0x1F000000) >> 24;
	}

	GMAC->MAC_IP1.ulMPhyAdr = ulPHYadrs;

	GMAC->MAC_IP1.ulMPhyRAdr = ulRegAdrs;

	GMAC->MAC_IP1.ulMPhyWD = ulWriteData;

	GMAC->MAC_IP1.ulMcmd = R_IN32D_BIT_MACIP1_MCMD_WRITE;

	erResult = erR_IN32D_MDIO_WaitCommandComplete();

	return( erResult );
}

ERRCODE gerR_IN32D_MACIP_PHYRead(
	ULONG	ulPort,			
	ULONG	ulRegAdrs,		
	ULONG*	pulReadData		
	)
{
	ULONG			ulPHYadrs;			
	ERRCODE			erResult;			



	if ( R_IN32D_PORT1 == ulPort ) {
		ulPHYadrs = (GMAC->ulMacIpAccess & 0x00001F00) >> 8;
	}
	else {
		ulPHYadrs = (GMAC->ulMacIpAccess & 0x1F000000) >> 24;
	}

	GMAC->MAC_IP1.ulMPhyAdr = ulPHYadrs;

	GMAC->MAC_IP1.ulMPhyRAdr = ulRegAdrs;

	GMAC->MAC_IP1.ulMcmd = R_IN32D_BIT_MACIP1_MCMD_READ;

	erResult = erR_IN32D_MDIO_WaitCommandComplete();


	*pulReadData = GMAC->MAC_IP1.ulMPhyRD;

	return( erResult );
}

ERRCODE erR_IN32D_MDIO_WaitCommandComplete( VOID )
{
	R_IN32D_FATALERROR_T	stFatalErr;			
	R_IN32R_STOPWATCH_T	stShortInform;		
	ULONG				ulSpendTime;		
	ULONG				ulTemp;				
	ERRCODE				erResult;			


	erResult = R_IN32D_OK;

	gR_IN32R_StartStopwatchTimer( &stShortInform, 1UL );

	while (1) {

		gR_IN32R_GetElapsedTime( &stShortInform, &ulSpendTime );

		ulTemp = GMAC->MAC_IP1.ulMcmd;
		ulTemp &= R_IN32D_BIT_MACIP1_MCMD_ON;
		if (R_IN32D_BIT_MACIP1_MCMD_ON != ulTemp) {	
			erResult = R_IN32D_OK;
			break;
		}
		else {
		}

		if ( R_IN32D_TMOUTUS_MDIO_CMDFIN < ulSpendTime ) {		

			stFatalErr.ulErrorCode = R_IN32D_ERR_TMO_MDIOCOMMAND;
			stFatalErr.ulErrorInfo = (ULONG)&erR_IN32D_MDIO_WaitCommandComplete;
			(VOID)gerR_IN32D_SetFatalError( &stFatalErr );

			erResult = R_IN32D_NG;
			break;
		}
		else {
		}
	}

	return( erResult );
}

/*** EOF ***/
