#ifndef ETH_H
#define ETH_H

/* Definitions */
/* Event flag pattern */
#define ETH_INT_MII_PHY0    0x0001
#define ETH_INT_MII_PHY1    0x0002

#define ETH_INT_TX_DMA_CMP  0x00000001
#define ETH_INT_TX_MAC_CMP  0x00000002
#define ETH_INT_TX_DMA_ERR  0x00000010
#define ETH_INT_TX_MAC_ERR  0x00000020
#define ETH_INT_RX_DMA_CMP  0x00000100
#define ETH_INT_RX_DMA_ERR  0x00001000
#define ETH_INT_RX_MAC_ERR  0x00002000
#define ETH_INT_RX_OVF_ERR  0x00004000

#define ETH_INT_TX_EVT      (ETH_INT_TX_DMA_CMP | ETH_INT_TX_DMA_ERR | ETH_INT_TX_MAC_CMP | ETH_INT_TX_MAC_ERR)
#define ETH_INT_TX_ERR      (ETH_INT_TX_DMA_ERR | ETH_INT_TX_MAC_ERR)
#define ETH_INT_RX_EVT      (ETH_INT_RX_DMA_CMP | ETH_INT_RX_DMA_ERR | ETH_INT_RX_MAC_ERR)
#define ETH_INT_RX_ERR      (ETH_INT_RX_DMA_ERR | ETH_INT_RX_MAC_ERR)

/*
#define PHY_LINK_EVT        0x00000010
*/
#define PHY_LINK_ID0        0x00000001    /* use also event pattern with RX event*/
#define PHY_LINK_ID1        0x00000002


/* Register */
/* MAC_MODE */
#define MODE_GIG            0x80000000   /* GIGA Ethernet */
#define MODE_100M           0x00000000   /* 10/100M Ethernet */
#define MODE_FULL_DUP       0x40000000   /* Full Duplex */
#define MODE_HALF_DUP       0x00000000   /* Half Duplex */

/* PHY ability mode */
typedef struct phy_mode {
    UW mode;    /* 10/100/1000, HD/FD*/
    UB nego;    /* Fixed, Auto-Negotiation */
    UB link;
    UB ch;
}PHY_MODE;

typedef struct phy_io {
    UW phy_id;
    UW phy_adr;
    ER (*phy_ini)(ID flg, UW id, UW adr);
    ER (*phy_ext)(void);
    ER (*phy_set_mode)(UW mode, UB nego);
    ER (*phy_get_mode)(UW *mode, UB *nego, UB *link);
}PHY_IO;

typedef struct mac_filter {
    UB mac[6];
    UB bitnum;  /* effective number of bit(40-48) */
}MAC_FILTER;

ER set_phy_mode(PHY_MODE *mode);
ER get_phy_mode(PHY_MODE *mode);
ER set_mcast_filter_mode(UINT mode);
ER add_mcast_filter(MAC_FILTER *adr);
ER eth_bufram_cpy(UINT dst, UINT src, UINT len);


#ifdef STS_SUP
    /* EtherDriver Set/Get Option Code */
    #define  ETH_OPT_PHY_MODE       CFG_PHY_MODE
    #define  ETH_OPT_MCRX_MODE      CFG_MCRX_MODE
    #define  ETH_OPT_MCRX_ADR       CFG_MAC_FIL_SET
    #define  ETH_OPT_RAW_RXFNC      CFG_RX_FRAME_CBK
    #define  ETH_OPT_RAW_SNDDONE    CFG_TX_FRAME_CBK

    /* Multicast frame reception mode */
    #define  MCRX_MODE_ALLOW        MC_RX_ALLOW
    #define  MCRX_MODE_DENY         MC_RX_DENY
    #define  MCRX_MODE_FILTER       MC_RX_FILTER

    /* PHY Ability */
    #define LAN_10T_HD              PHY_STS_10HD
    #define LAN_10T_FD              PHY_STS_10FD
    #define LAN_100TX_HD            PHY_STS_100HD
    #define LAN_100TX_FD            PHY_STS_100FD
    #define LAN_1000T_HD            PHY_STS_1000HD
    #define LAN_1000T_FD            PHY_STS_1000FD
    #define LAN_AUTO_ABILITY        7   /* Auto */
#else
    /* PHY Ability */
    #define LAN_10T_HD              1   /* 10BASE-T Half-Duplex   */
    #define LAN_10T_FD              5   /* 10BASE-T Full-Duplex   */
    #define LAN_100TX_HD            2   /* 100BASE-TX Half-Duplex */
    #define LAN_100TX_FD            6   /* 100BASE-TX Full-Duplex */
    #define LAN_1000T_HD            8   /* 1000BASE-T Half-Duplex */
    #define LAN_1000T_FD            9   /* 1000BASE-T Full-Duplex */
    #define LAN_AUTO_ABILITY        7   /* Auto */

    /* EtherDriver Set/Get Option Code */
    #define  ETH_OPT_PHY_MODE       1
    #define  ETH_OPT_MCRX_MODE      2
    #define  ETH_OPT_MCRX_ADR       3
    #define  ETH_OPT_RAW_RXFNC      4
    #define  ETH_OPT_RAW_SNDDONE    5

    /* Multicast frame reception mode */
    #define  MCRX_MODE_ALLOW        1
    #define  MCRX_MODE_DENY         2
    #define  MCRX_MODE_FILTER       3
#endif

/* Raw Interface */
typedef void(*ETH_RAW_RCV)(VP fram, UH len);
typedef void(*ETH_RAW_SNDDONE)(VP pkt);

extern ETH_RAW_RCV eth_raw_rcv;
extern ETH_RAW_SNDDONE eth_raw_snddone;

#define _eth_raw_rcv(a,b) \
if (eth_raw_rcv != NULL) \
    eth_raw_rcv(a,b);

#define _eth_raw_snddone(a) \
if (eth_raw_snddone != NULL) \
    eth_raw_snddone(a);

#endif
