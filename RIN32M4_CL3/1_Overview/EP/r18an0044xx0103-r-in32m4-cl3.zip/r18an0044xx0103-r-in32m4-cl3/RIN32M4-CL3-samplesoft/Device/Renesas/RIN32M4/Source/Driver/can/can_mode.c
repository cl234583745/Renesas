/**
 *******************************************************************************
 * @file  can_status.c
 * @brief CAN driver program for R-IN32M4-CL3
 * 
 * @note 
 * Copyright (C) 2019 Renesas Electronics Corporation 
 * 
 * @par
 *  This is a sample program. 
 *  Renesas Electronics assumes no responsibility for any losses incurred. 
 * 
 *******************************************************************************
 */

/*============================================================================*/
/* I N C L U D E                                                              */
/*============================================================================*/
#include "can/can.h"

/*============================================================================*/
/* D E F I N E                                                                */
/*============================================================================*/

/*============================================================================*/
/* V A R I A B L E                                                            */
/*============================================================================*/

/*============================================================================*/
/* E X T E R N                                                                */
/*============================================================================*/

/*============================================================================*/
/* S T A T I C   F U N C T I O N   P R O T O T Y P E                          */
/*============================================================================*/

/*============================================================================*/
/* P R O G R A M                                                              */
/*============================================================================*/
/**
 *******************************************************************************

  @brief  get status of operation mode and power save mode
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @return Error condition 
  @retval bit7 = 0  : Normal end
                      bit2 - bit0   : operation mode
                                    : 000b - Initial mode
                                    : 001b - Normal mode
                                    : 101b - Self test mode
                      bit4 - bit3   : power save mode
                                    :  00b - Not poer save mode
                                    :  01b - CAN sleep mode
                                    :  11b - CAN stop mode
                      bit7 - bit5   : 0
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_get_mode(uint8_t ch)
{
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	return (ER_RET)(RIN_CAN[ch]->MDL.FCNnCMCLCTL & (MSK_CAN_CMCLMDOF | MSK_CAN_CMCLMDPF));
}

/**
 *******************************************************************************

  @brief  set can mode
  @param  [in] ch   : Channel number 
    @arg 0 =channel0 
    @arg 1 =channel1 
  @param  [in] mode : can operating mode
    @arg SET_CAN_INIT = initial mode
    @arg SET_CAN_NORM = normal mode
    @arg SET_CAN_SELF = self test mode
  @return Error condition 
  @retval ER_OK    : No error
  @retval ER_PARAM : Parameter error
  @retval ER_INVAL : Invalid state

 *******************************************************************************
 */
ER_RET can_set_mode(uint8_t ch,uint16_t mode)
{
#if		defined(__CHECK__)
	/*----------------------------------------------------------------------*/
	/*	Check parameter 													*/
	/*----------------------------------------------------------------------*/

	/*
	 * Channel No Max/Min
	 */
	if (CAN_CH_NUM <= ch) {
		return ER_PARAM;
	}

	/*
	 * Use Channel No
	 */
	if ((can_ch_info[ch].use & CAN_CH_USE) == 0) {
		return ER_PARAM;
	}
#endif	/* __CHECK__ */

	if(mode == SET_CAN_INIT){
		/*----------------------------------------------------------------------*/
		/*	Check not init mode													*/
		/*----------------------------------------------------------------------*/
		if((RIN_CAN[ch]->MDL.FCNnCMCLCTL & MSK_CAN_CMCLMDOF) == CHK_CAN_INIT) {
			return ER_INVAL;
		}
	}else{
		/*----------------------------------------------------------------------*/
		/*	Check init mode														*/
		/*----------------------------------------------------------------------*/
		if((RIN_CAN[ch]->MDL.FCNnCMCLCTL & MSK_CAN_CMCLMDOF) != CHK_CAN_INIT) {
			return ER_INVAL;
		}
	}
	/*----------------------------------------------------------------------*/
	/*	Set mode															*/
	/*----------------------------------------------------------------------*/
	RIN_CAN[ch]->MDL.FCNnCMCLCTL = mode;

	/*----------------------------------------------------------------------*/
	/*	Set return value													*/
	/*----------------------------------------------------------------------*/
	return ER_OK;
}

