/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4(Communication LSI for intelligent device station) Driver        */
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved.     */
/****************************************************************************/

/****************************************************************************/
/** @file                                                                   */
/** @brief  R_IN32M4 driver user sample code                                */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/

/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include <string.h>

#include "R_IN32M4Driver.h"
#include "R_IN32M4_sample.h"
#include "R_IN32M4_Transient.h"
#include "R_IN32M4Function.h"
//#include "RIN32M4.h"
#include "R_IN32R.h"
#include "R_IN32S.h"
#include "board_init.h"

/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/
/* Maximum data size for cyclic communication */
#define	USER_MAX_RX_POINT				(2048)						/* RY size (point) */
#define	USER_MAX_RY_POINT				(2048)						/* RY size (point) */
#define	USER_MAX_RWW_POINT				(1024)						/* RWw size (point) */
#define	USER_MAX_RWR_POINT				(1024)						/* RWr size (point) */
#define	USER_MAX_RX_SIZE				(USER_MAX_RX_POINT/8)		/* RX size (in octet unit) */
#define	USER_MAX_RY_SIZE				(USER_MAX_RY_POINT/8)		/* RY size (in octet unit) */
#define	USER_MAX_RWW_SIZE				(USER_MAX_RWW_POINT)		/* RWw size (in word unit) */
#define	USER_MAX_RWR_SIZE				(USER_MAX_RWR_POINT)		/* RWr size (in word unit) */

/* Node information 1 */
#define	USER_MAX_PORT_NUMBER			(2)							/**< Number of host station ports */
#define	USER_TOKEN_HOLD_TIME			(23)						/**< Token holding time */
#define	USER_MIN_PORT_NUMBER			(1)							/* Min number of ports */

/* Node information 2 */
#define	USER_STINF_IOTYPE				(UCHAR)0x00					/**< Node info (I/O type) */

/* Network card information */
#define	USER_UNIT_VERSION				(0x00000001UL)							/* Network F/W version */
#define	USER_UNIT_MODEL_TYPE			(0x0000001FUL)							/* Network model type */
#define	USER_UNIT_MODEL_CODE			(0x00000002UL)							/* Network unit model code */
#define	USER_UNIT_VENDOR_CODE			(0x00000100UL)							/* Network vendor code */
#define	USER_UNIT_MODEL_NAME			"12345678901234567890"					/* Network unit model name */
#define	USER_UNIT_VENDOR_NAME			"09876543210987654321098765432109"		/* Network vendor name */
#define	USER_UNIT_MODEL_NAME_SIZE		(20)									/* 20 byte */
#define	USER_UNIT_VENDOR_NAME_SIZE		(32)									/* 32 byte */
#define USER_UNIT_HW_VERSION			(USHORT)0x0001							/* Network hardware version */
#define USER_UNIT_DEVICE_VERSION		(USHORT)0x0001							/* Network Equipment version */

/* Controller information */
#define	USER_CTRL_INFOFLG				(R_IN32_TRUE)								/* Controller information status flag */
#define	USER_CTRL_VERSION				(0x00000002UL)							/* Controller F/W version */
#define	USER_CTRL_MODEL_TYPE			(0x00000001UL)							/* Controller model type */
#define	USER_CTRL_MODEL_CODE			(0x00001234UL)							/* Controller unit model code */
#define	USER_CTRL_VENDOR_CODE			(0x00000002UL)							/* Controller vendor code */
#define	USER_CTRL_MODEL_NAME			"ABCDEFGHIJKLMNOPQRST"					/* Controller unit model name */
#define	USER_CTRL_VENDOR_NAME			"1234567890ABCDEFGHIJKLMNOPQRSTUV"		/* Controller vendor name */
#define	USER_CTRL_MODEL_NAME_SIZE		(20)									/* 20 byte */
#define	USER_CTRL_VENDOR_NAME_SIZE		(32)									/* 32 byte */
#define	USER_CTRL_VENDOR_UNIT_INFO		(0x12345678UL)							/**< Controller vendor device specific information */

#define USER_INIT_NMIUSE				(R_IN32_FALSE)							/* NMI interrupt use */
#define USER_INIT_INTERRUPTUSE			(R_IN32_FALSE)							/* CPU Interrupt function use */
#define USER_INIT_FAILEDPROCESS1		(R_IN32_TRUE)								/* Failed process setting 1 */
#define USER_INIT_FAILEDPROCESS2		(R_IN32_TRUE)								/* Failed process setting 2 */
#define USER_INIT_NODETYPE				(0x33)									/* Node type -Intelligent Device Station- */
#define USER_INIT_TRANSIENTRECEIVEENABLE	(R_IN32_TRUE)							/* Transient reception function */
#define USER_INIT_MACADDRESSTABLEREQUEST	(R_IN32_TRUE)							/* If you equip a client function of Transient to an apparatus to develop, please set it in "R_IN32_TRUE".*/
#define USER_INIT_RUNSTATUS					(R_IN32_RUNSTS_STOP)					/* Initial value of Detailed application operation status */
#define USER_INIT_ERRORSTATUS				(R_IN32_ERRSTS_NONE)					/* Initial value of Detailed application error status */
#define USER_INIT_USERINFORMATION			0									/* Initial value for vendor specific information */
#define USER_INIT_OPTION_SUPPORT			(R_IN32_TRUE)							/* Option Support Defaults */
#define USER_INIT_SLMP_SUPPORT				(R_IN32_TRUE)							/* Slmp Support Defaults */
#define USER_INIT_SLMP_DIAGNOSIS_SUPPORT	(R_IN32_TRUE)							/* CCIEF Diagnosis Support Defaults */



#define PHY_0					( 0 )		/*!<  */
#define PHY_1					( 1 )		/*!<  */
#define	ARMPF_REG_WRITE( reg, data )	(*(volatile unsigned long*)(reg) = (data))
#define	ARMPF_REG_READ( reg )			(*(volatile unsigned long*)(reg))

#ifdef FAST_LINKUP_MODE
/* Bit location of FastLinkUp switch */
#define F_LINK_P1_BIT	(0x00000001UL)
#define F_LINK_P2_BIT	(0x00000002UL)
#endif

//#define LOOPBACK_FUNCTION					/* Enable loop-back function */

/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/

/* Status of Reset */
ULONG	gulUserResetStatus;

/* MAC address */
UCHAR	gauchUserMACAddress[6] = { 0xF0, 0x2E, 0x15, 0x6C, 0x77, 0x9B };

/* Station No. */
USHORT	gusUserNodeNumber     = 1;
UCHAR	guchUserNetworkNumber = 1;

/* Cyclic data */
/* CAUTION: the follwing data must be assigned in 4byte alignment. */
ULONG	gaulUserCycRy [USER_MAX_RY_SIZE/sizeof(ULONG)] = {0};
ULONG	gaulUserCycRWw[USER_MAX_RWW_SIZE*2/sizeof(ULONG)] = {0};
ULONG	gaulUserCycRx [USER_MAX_RX_SIZE/sizeof(ULONG)] = {0};
ULONG	gaulUserCycRWr[USER_MAX_RWR_SIZE*2/sizeof(ULONG)] = {0};

/* User control */
BOOL	gblUserClearMIBRequest     = R_IN32_FALSE;				
BOOL	gblUserCyclicStopRequest   = R_IN32_FALSE;				
BOOL	gblUserForceStopRequest    = R_IN32_FALSE;				
BOOL	gblUserSendCyclicEnable    = R_IN32_TRUE;					
BOOL	gblUserReceiveCyclicEnable = R_IN32_TRUE;					
BOOL	gblUserR_IN32M4WDT_Enable     = R_IN32_FALSE;				

/* MyStatus */
ULONG	gulUserRunState = USER_INIT_RUNSTATUS;					
ULONG	gulUserErrState = USER_INIT_ERRORSTATUS;				
ULONG	gulUserVendorSpfNodeInfo = USER_INIT_USERINFORMATION;	

/* Fatal error */
ULONG	gulUserFatalErrorNum = 0UL;					/* the number of fatal errors */
ULONG	gulUserFatalError[USER_FATALERROR_NUM][2];	/* list of fatal errors */
													/*  [*][0]: fatal error code */
													/*  [*][1]: fatal error information (address of the function when the error occurred) */

BOOL	gblUserSendRequestTransient = R_IN32_FALSE;	/* Sending request of transient request frame */

UCHAR	gauchBufferMemory[USER_BUFFER_MEMORY_SIZE] = {0};		/* Buffer memory */

BOOL							gblSlmpClientRequestFlg = R_IN32_FALSE;			/* Request of SLMP read memory */
USER_SLMP_MEMREAD_SETTING_T		stMemReadSetting;

ULONG gulErrCtrl = R_IN32_LED_OFF;					/* ERR LED control flag */


/****************************************************************************/
/* Functions                                                                */
/****************************************************************************/
INT  iUserMainRoutine( VOID );
INT  iUserInitialization( VOID );
INT  iUserStart( VOID );
INT  iUserExecuteMain( VOID );
VOID UserForceStop( VOID );
VOID UserStopCyclic( VOID );
VOID UserUpdateStatus( VOID );
VOID UserUpdateLed( VOID );
VOID UserReceiveCyclic( VOID );
VOID UserSendCyclic( VOID );
VOID UserSendMyStatus( VOID );
VOID UserGetCyclicStatus( VOID );
VOID UserGetMIB( VOID );
INT iUserMyStaRcvTkn( VOID );

/****************************************************************************/
/** @brief  Main Routine                                                    */
/** @retval USER_OK :Normal end                                             */
/** @retval USER_ERR:Abnormal end                                           */
/****************************************************************************/
INT iUserMainRoutine(VOID)
{
	INT iReturn = USER_OK;
	INT iResult;
	

	
	/* Initialization processing */
	iResult = iUserInitialization();
	if (USER_OK != iResult) {
		iReturn = USER_ERR;
		return iReturn;
	}
	else {
	}

	/* Start communication processing */
	iResult = iUserStart();
	if (USER_OK != iResult) {
		iReturn = USER_ERR;
		return iReturn;
	}
	else {
	}

	/* Main loop */
	while (1) {


		/* Force Stop processing */
		UserForceStop();

		/* Stop Cyclic Communication processing */
		UserStopCyclic();

		/* Event processing */
		iResult = iUserExecuteMain();
		if (USER_OK != iResult) {
			iReturn = USER_ERR;
			break;
		}
		else {
		}

		/* Receive MyStatus from Master Station and Cyclic Data processing */
		UserReceiveCyclic();

		/* TODO: add your device main processing code here */

		/* Sending MyStatus processing */
		UserSendMyStatus();

		/* Send Cyclic Data processing */
		UserSendCyclic();

		/* Update Communication Status processing */
		UserUpdateStatus();

		/* Update LED processing */
		UserUpdateLed();

		/* Update Cyclic Communication Status processing */
		UserGetCyclicStatus();

		/* Get MIB Information processing */
		UserGetMIB();
		
		/* Receive Transient1, Transient2, and TransientAck */
		UserReceiveTransient();

	/* Create Transient2 Request Frame processing */
	if ( R_IN32_TRUE == gblUserSendRequestTransient ) {
		UserSetTransient2_Request();
		gblUserSendRequestTransient = R_IN32_FALSE;
		}
	else {
		}

	if( R_IN32_TRUE == gblSlmpClientRequestFlg) {
		stMemReadSetting.ulTopAddr = 0x00000000;						/* Start address */
		stMemReadSetting.usWordSize = USER_SLMP_MEMORY_READ_SIZE;		/* Word size  */
		stMemReadSetting.uchNwNo = 1;									/* Destination Network No. */
		stMemReadSetting.uchNode = 0x7D;								/* Destination Node */
		
		erUserSetSlmpMemRead_Request(&stMemReadSetting);
		
		gblSlmpClientRequestFlg = R_IN32_FALSE;
		
	}
		
		
		/* Send Transient1, Transient2, and TransientAck processing */
		UserSendTransient();
		

	} /* while */

	/* TODO: add your code here */

	return iReturn;
}



/****************************************************************************/
/** @brief  Initialization processing                                       */
/** @retval USER_OK :Normal end                                             */
/** @retval USER_ERR:Abnormal end                                           */
/****************************************************************************/
INT iUserInitialization( VOID )
{
	INT            iReturn = USER_OK;
	R_IN32_UNITINFO_T stUnitInfo;
	R_IN32_UNITINIT_T stUnitInit;
	USHORT	usNodeNumber10, usNodeNumber1;
	UCHAR	uNetworkNumber10, uNetworkNumber1;
#ifdef FAST_LINKUP_MODE
	UCHAR uchBordSW;
#endif

	/* Get reset status */
	gulUserResetStatus = gulR_IN32_GetResetStatus();

	/* Maximum data size for cyclic communication */
	stUnitInfo.ulMaxRySize  = USER_MAX_RY_SIZE;			/* RY size (in octet unit) */
	stUnitInfo.ulMaxRWwSize = USER_MAX_RWW_SIZE;		/* RWw size (in word unit) */
	stUnitInfo.ulMaxRxSize  = USER_MAX_RX_SIZE;			/* RX size (in octet unit) */	
	stUnitInfo.ulMaxRWrSize = USER_MAX_RWR_SIZE;		/* RWr size (in word unit) */

	/* Node information 1 */
	stUnitInfo.ulMyStationPortTotalNumber = USER_MAX_PORT_NUMBER;	/* Number of ports */
	stUnitInfo.ulTokenHoldTime = USER_TOKEN_HOLD_TIME;				/* Token hold time */

	/* Node information 2 */
	stUnitInfo.ulIOType = USER_STINF_IOTYPE;				/* Node I/O type */

	/* Network information */
	stUnitInfo.ulNetVersion = USER_UNIT_VERSION;			/* Network firmware version */
	stUnitInfo.ulNetModelType = USER_UNIT_MODEL_TYPE;		/* Network model type */
	stUnitInfo.ulNetUnitModelCode = USER_UNIT_MODEL_CODE;	/* Network unit model code */
	stUnitInfo.ulNetVendorCode = USER_UNIT_VENDOR_CODE;		/* Network vendor code */
	memcpy(stUnitInfo.auchNetUnitModelName, USER_UNIT_MODEL_NAME, USER_UNIT_MODEL_NAME_SIZE);	/* Network unit model name */
	memcpy(stUnitInfo.auchNetVendorName, USER_UNIT_VENDOR_NAME, USER_UNIT_VENDOR_NAME_SIZE);	/* Network vendor name */
	stUnitInfo.usHwVersion = USER_UNIT_HW_VERSION;			/* Network hardware version */
	stUnitInfo.usDeviceVersion = USER_UNIT_DEVICE_VERSION;	/* Network Equipment version */
	
	/* Controller information */
	stUnitInfo.blInformationFlag = USER_CTRL_INFOFLG;		/* Controller information flag */
	stUnitInfo.ulCtrlVersion = USER_CTRL_VERSION;			/* Controller firmware version */
	stUnitInfo.ulCtrlModelType = USER_CTRL_MODEL_TYPE;		/* Controller model type */
	stUnitInfo.ulCtrlUnitModelCode = USER_CTRL_MODEL_CODE;	/* Controller unit model code */
	stUnitInfo.ulCtrlVendorCode = USER_CTRL_VENDOR_CODE;	/* Controller vendor code */
	memcpy(stUnitInfo.auchCtrlUnitModelName, USER_CTRL_MODEL_NAME, USER_CTRL_MODEL_NAME_SIZE);	/* Controller unit model name */
	memcpy(stUnitInfo.auchCtrlVendorName, USER_CTRL_VENDOR_NAME, USER_CTRL_VENDOR_NAME_SIZE);	/* Controller vendor name */
	stUnitInfo.ulVendorInformation = USER_CTRL_VENDOR_UNIT_INFO;	/* Controller vendor device specific information */

	stUnitInit.blNMIUse = USER_INIT_NMIUSE;						/* NMI interrupt use */
	stUnitInit.blInterruptUse = USER_INIT_INTERRUPTUSE;			/* Interrupt function use */
	stUnitInit.blFailedProcess1 = USER_INIT_FAILEDPROCESS1;		/* Failed process 1 */
	stUnitInit.blFailedProcess2 = USER_INIT_FAILEDPROCESS2;		/* Failed process 2 */
	stUnitInit.ulNodeType = USER_INIT_NODETYPE;					/* Node type */
	stUnitInit.blTransientReceiveEnable = USER_INIT_TRANSIENTRECEIVEENABLE;	/* Transient receive function availability */
	stUnitInit.blMACAddressTableRequest = USER_INIT_MACADDRESSTABLEREQUEST;	/* Initial value of MAC address table necessity */
	stUnitInit.ulRunStatus = USER_INIT_RUNSTATUS;				/* Initial value of application operating status */
	stUnitInit.ulErrorStatus = USER_INIT_ERRORSTATUS;			/* Initial value of error status */
	stUnitInit.ulUserInformation = USER_INIT_USERINFORMATION;	/* Initial value for vendor specific information */
	stUnitInit.ulOptionSupport = USER_INIT_OPTION_SUPPORT;		/* Option presence */
	stUnitInit.ulSlmpSupport = USER_INIT_SLMP_SUPPORT;			/* SLMP Support bit */
	stUnitInit.ulSlmpDiagnosisSupport = USER_INIT_SLMP_DIAGNOSIS_SUPPORT;	/* SLMP Diagnosis Support bit */	

#ifdef FAST_LINKUP_MODE
	/* Initial value of PHY settings dependent on fast link up mode */
	uchBordSW = get_board_sw();
	if (F_LINK_P1_BIT == (F_LINK_P1_BIT & uchBordSW))
	{
		stUnitInit.stPHYSetting[R_IN32_PORT1].ulMDI = R_IN32_MDI_FORCED_MDI;
		stUnitInit.stPHYSetting[R_IN32_PORT1].ulClk = R_IN32_CLOCK_MASTER;
	}
	else
	{
		stUnitInit.stPHYSetting[R_IN32_PORT1].ulMDI = R_IN32_MDI_AUTO;
		stUnitInit.stPHYSetting[R_IN32_PORT1].ulClk = R_IN32_CLOCK_AUTO;
	}

	if (F_LINK_P2_BIT == (F_LINK_P2_BIT & uchBordSW))
	{
		stUnitInit.stPHYSetting[R_IN32_PORT2].ulMDI = R_IN32_MDI_FORCED_MDIX;
		stUnitInit.stPHYSetting[R_IN32_PORT2].ulClk = R_IN32_CLOCK_SLAVE;
	}
	else
	{
		stUnitInit.stPHYSetting[R_IN32_PORT2].ulMDI = R_IN32_MDI_AUTO;
		stUnitInit.stPHYSetting[R_IN32_PORT2].ulClk = R_IN32_CLOCK_AUTO;
	}
#else
	stUnitInit.stPHYSetting[R_IN32_PORT1].ulMDI = R_IN32_MDI_AUTO;
	stUnitInit.stPHYSetting[R_IN32_PORT1].ulClk = R_IN32_CLOCK_AUTO;
	stUnitInit.stPHYSetting[R_IN32_PORT2].ulMDI = R_IN32_MDI_AUTO;
	stUnitInit.stPHYSetting[R_IN32_PORT2].ulClk = R_IN32_CLOCK_AUTO;
#endif

	/* For transient handling */
	gblUserMACAddressTableRequest = USER_INIT_MACADDRESSTABLEREQUEST;	/* MAC address table necessity flag */

	/* Initialize R_IN32M4 */
	gerR_IN32_Initialize( gauchUserMACAddress, &stUnitInfo, &stUnitInit );

	/* example */
	/* Confirm the occurred fatal error in the gerR_IN32_Initialize() */
	if ( 0UL != gulUserFatalErrorNum) {								/* Fatal error occurred */
		/* Error termination */

		/* TODO: Please handle the gulUserFatalError[][] as necessary */

		/* Reset fatal error counter */
		gulUserFatalErrorNum = 0UL;

		iReturn = USER_ERR;
		return iReturn;
	}
	else {
	}

	/* Set R_IN32M4 when using internal WDT */
	if (R_IN32_TRUE == gblUserR_IN32M4WDT_Enable) {	/* When using internal WDT */

		/* Set R_IN32M4 internal WDT time */
		/* TODO: Please set the time according to the system */
		gerR_IN32_SetWDT( (USHORT)0x001F );

		/* Enable R_IN32M4 internal WDT */
		gerR_IN32_EnableWDT();

		/* Reset R_IN32M4 internal WDT */
		gerR_IN32_ResetWDT();

		/* Warning: Hereafter, please call gerR_IN32_ResetWDT() before WDT time-out occured */
	}
	else {										/* When not using internal WDT */

		/* Disable R_IN32M4 internal WDT */
		gerR_IN32_DisableWDT();
	}

	/* Set station/network No. */
	uNetworkNumber10 = ((cie_get_networknumber() & 0xF0) >> 4);
	uNetworkNumber1  =  (cie_get_networknumber() & 0x0F);
	if(uNetworkNumber1  > 0x09) uNetworkNumber1  = 0x09;
	guchUserNetworkNumber = uNetworkNumber10 * 10 + uNetworkNumber1;
	if(guchUserNetworkNumber == 0) guchUserNetworkNumber = 1;
	
	usNodeNumber10 = ((cie_get_nodenumber() & 0xF0) >> 4);
	usNodeNumber1  =  (cie_get_nodenumber() & 0x0F);
	if(usNodeNumber10 > 0x0C) usNodeNumber10 = 0x0C;
	if(usNodeNumber1  > 0x09) usNodeNumber1  = 0x09;
	gusUserNodeNumber = usNodeNumber10 * 10 + usNodeNumber1;
	if(gusUserNodeNumber == 0)  gusUserNodeNumber = 1;
	if(gusUserNodeNumber > 120) gusUserNodeNumber = 120;
	
	(VOID)gerR_IN32_SetNodeAndNetworkNumber( guchUserNetworkNumber, gusUserNodeNumber );

	return iReturn;
}



/****************************************************************************/
/** @brief  Start R_IN32M4 communication                                       */
/** @retval USER_OK :Normal end                                             */
/** @retval USER_ERR:Abnormal end                                           */
/****************************************************************************/
INT iUserStart( VOID )
{
	INT     iReturn = USER_OK;

	/* Start communication of R_IN32M4 */
	gerR_IN32_Start();

	/* example */
	/* Confirm the occurred fatal error in the gerR_IN32_Start() */
	if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */
		/* Error termination */

		/* TODO: Please handle the gulUserFatalError[][] as necessary */

		/* Reset fatal error counter */
		gulUserFatalErrorNum = 0UL;

		iReturn = USER_ERR;
		return iReturn;
	}
	else {
	}

	/* Set RUN LED */
	(VOID)gerR_IN32_SetRUNLED( R_IN32_LED_ON );

	/* Set application operating status(MyStatus data) */
	gulUserRunState = R_IN32_RUNSTS_RUN;

	return iReturn;
}



/****************************************************************************/
/** @brief  Executing main routine                                          */
/** @retval USER_OK :Normal end                                             */
/** @retval USER_ERR:Abnormal end                                           */
/****************************************************************************/
INT iUserExecuteMain( VOID )
{
	INT                     iReturn = USER_OK;
	R_IN32_EVTPRM_INTERRUPT_T  stEvent;

	/* Get R_IN32M4 event */
	(VOID)gerR_IN32_GetEvent( &stEvent );

	/* Transient frame sending finished? */
	if ( R_IN32_EVTPRM_INTERRUPT_SENDFIN_NONCYCLIC == (R_IN32_EVTPRM_INTERRUPT_SENDFIN_NONCYCLIC & stEvent.uniFlag.ulAll)) {
		/* Main transient senging processing */ 
		gerR_IN32_MainSendTransient();
	}
	else {
	}

	/* Main handling */
	gerR_IN32_Main( &stEvent );

	/* Restart R_IN32M4 event */
	(VOID)gerR_IN32_RestartEvent();

	/* Check PHY */
	(VOID)gerR_IN32_CheckPHY();
	/* example */
	/* Confirm the occurred fatal error in the UserChangePHYSetting() */
	if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */

		/* TODO: Please handle the gulUserFatalError[][] as necessary */

		/* Reset fatal error counter */
		gulUserFatalErrorNum = 0UL;
	}
	else {
	}


	/* Update MIB (of R_IN32M4) */
	gerR_IN32_UpdateMIB();

	/* example */
	/* Confirm the occurred fatal error in the gerR_IN32_UpdateMIB() */
	if ( 0UL != gulUserFatalErrorNum) {	/* Fatal error occurred */
		/* Error termination */

		/* TODO: Please handle the gulUserFatalError[][] as necessary */

		/* Reset fatal error counter */
		gulUserFatalErrorNum = 0UL;

		iReturn = USER_ERR;
		return iReturn;
	}
	else {
	}
	
	return iReturn;
}



/****************************************************************************/
/** @brief  Force Stop processing                                           */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserForceStop( VOID )
{
	/* Force Stopping the communication of R_IN32M4 */
	if (R_IN32_TRUE == gblUserForceStopRequest) {
		(VOID)gerR_IN32_ForceStop();
	}
	else {
	}

	return;
}



/****************************************************************************/
/** @brief  Stop cyclic communication processing                            */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserStopCyclic( VOID )
{
	if (R_IN32_TRUE == gblUserCyclicStopRequest) {
		/* Stop the cyclic communication  */
		(VOID)gerR_IN32_SetCyclicStop();
	}
	else {
		/* Restart the cyclic communication */
		(VOID)gerR_IN32_ClearCyclicStop();
	}

	return;
}



/****************************************************************************/
/** @brief  Update communication status processing                          */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserUpdateStatus( VOID )
{
	ULONG ulCommSts;
	static BOOL blConnectFlag = R_IN32_FALSE;

	/* Get the communication status */
	(VOID)gerR_IN32_GetCommumicationStatus( &ulCommSts );

	/* User program execution according to communication status */
	switch ((INT)ulCommSts) {
	case R_IN32_COMMSTS_CYC_DLINK:
		/* Data Link */
		gulErrCtrl = R_IN32_LED_OFF;
		blConnectFlag = R_IN32_TRUE;
		/* TODO: add your code here */
		break;

	case R_IN32_COMMSTS_TOKEN_PASS:
		/* Executing token pass */

		gulErrCtrl = R_IN32_LED_OFF;
		/* TODO: Add your code about Hold/Clear processing, if this device is not "Executing cyclic communication" certain period of time. */
		/* TODO: add your code here */
		break;

	case R_IN32_COMMSTS_DISCONNECT:
		/* Disconnected */
		/* After start-up, did it become "Cyclic communication execution" one time or more? */
		if (blConnectFlag == R_IN32_TRUE) {
			gulErrCtrl = R_IN32_LED_ON;
		}
		else {
			gulErrCtrl = R_IN32_LED_OFF;
		}
		
		/* TODO: Add your code about Hold/Clear processing */
		/* TODO: add your code here */
		break;

	default:
		break;
	}
	
	return;
}



/****************************************************************************/
/** @brief  LED Update processing.                                          */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserUpdateLed( VOID )
{
	/* Updata L ERR1, L ERR2, D LINK LED */
	gerR_IN32_UpdateLedStatus();
	
	
	/* TODO: add your code here */
	
	/* Update ERR LED */
	(VOID)gerR_IN32_SetERRLED( gulErrCtrl );
}



/****************************************************************************/
/** @brief  Receive MyStatus from Master Station and Cyclic Data processing */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserReceiveCyclic( VOID )
{
	BOOL    blMasterApplicationRunSts;
	BOOL    blMasterApplicationErrSts;
	ULONG   ulMasterApplicationErrCode;
	ERRCODE erResult;
	/* Receive MyStatus and cyclic frame */
	(VOID)gerR_IN32_GetReceivedCyclicData( &gaulUserCycRy[0], &gaulUserCycRWw[0], gblUserReceiveCyclicEnable );


	/* Read master station status */
	erResult = gerR_IN32_GetMasterNodeStatus( &blMasterApplicationRunSts, &blMasterApplicationErrSts, &ulMasterApplicationErrCode );
	if (R_IN32_OK == erResult) {

		/* Application operating status */
		if (R_IN32_TRUE == blMasterApplicationRunSts) {
			/* TODO: add your code here */

			/*===============================================================*/
			/* Output cyclic reception data to LED                           */
			/*===============================================================*/
			set_board_led(gaulUserCycRy[0]);
		}
		else {
			/* TODO: Add your code about Hold/Clear processing */
			/* TODO: add your code here */
		}

		/* Application error status */
		if (R_IN32_TRUE == blMasterApplicationErrSts) {
			/* TODO: add your code here */
		}
		else {
			/* TODO: Add your code about Hold/Clear processing */
			/* TODO: add your code here */
		}

	}
	else {
	}

	return;
}



/****************************************************************************/
/** @brief  Send Cyclic Data processing                                     */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserSendCyclic( VOID )
{
	static USHORT delay_cnt = 0;
	static UCHAR signal;

#ifdef LOOPBACK_FUNCTION
	memcpy(gaulUserCycRx, gaulUserCycRy, USER_MAX_RY_SIZE);
	memcpy(gaulUserCycRWr, gaulUserCycRWw, USER_MAX_RWR_SIZE);
#else	// LOOPBACK_FUNCTION
	delay_cnt++;
	if (delay_cnt > 1000){
		signal = signal << 1;
		if (signal == 0)
			signal = 0x01;
		delay_cnt = 0;
	}
	gaulUserCycRx[0] = (ULONG)signal;
#endif	// LOOPBACK_FUNCTION

	/* Set cyclic send data */
	(VOID)gerR_IN32_SetSendCyclicData( gaulUserCycRx, gaulUserCycRWr, gblUserSendCyclicEnable );

	return;
}



/****************************************************************************/
/** @brief  Send MyStauts processing                                        */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserSendMyStatus( VOID )
{
	/* Set node status (MyStatus data) */
	
	(VOID)gerR_IN32_SetNodeStatus(gulUserRunState, gulUserErrState, gulUserVendorSpfNodeInfo );

	/* Set MyStatus send data */
	(VOID)gerR_IN32_SetMyStatus();

	return;
}



/****************************************************************************/
/** @brief  Update Cyclic Communication Status processing                   */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserGetCyclicStatus( VOID )
{
	static R_IN32_CYCLIC_SIZE_T stCurrCyclicSize;
	static R_IN32_CYCLIC_STA_T  stPortConnectState;

	/* Get cyclic communication size assigned by master station */
	(VOID)gerR_IN32_GetCurrentCyclicSize( &stCurrCyclicSize );

	/* Get cyclic communication status */
	(VOID)gerR_IN32_GetCyclicStatus( &stPortConnectState );

	/* TODO: add your code here */

	return;
}



/****************************************************************************/
/** @brief  Get MIB Information processing                                  */
/** @retval VOID                                                            */
/****************************************************************************/
VOID UserGetMIB( VOID )
{
	static R_IN32_MIB_T stMIB;

	/* Get MIB information of R_IN32M4? */
	(VOID)gerR_IN32_GetMIB( &stMIB );

	/* Clear MIB information of R_IN32M4? */
	if (R_IN32_TRUE == gblUserClearMIBRequest) {
		/* Clear MIB information */
		(VOID)gerR_IN32_ClearMIB();

		gblUserClearMIBRequest = R_IN32_FALSE;
	}
	else {
	}

	/* TODO: add your code here */

	return;
}



/****************************************************************************/
/** @brief  Process when My station receives Token frame                    */
/** @retval USER_OK                                                         */
/****************************************************************************/
INT iUserMyStaRcvTkn( VOID )
{
	INT	iReturn = USER_OK;
	
	(VOID)gerR_IN32_MyStaRcvTkn();

	return iReturn;	
}




/*** EOF ***/
