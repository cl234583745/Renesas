/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32M4_in.h                                                      */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32M4_H_INCLUDED_
#define __R_IN32M4_H_INCLUDED_


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32_Frame.h"
#include "RIN32M4.h"
#include "R_IN32M4_0.h"
#include "R_IN32M4_1.h"
#include "R_IN32M4_2.h"
#include "R_IN32M4_3.h"
#include "R_IN32M4_4.h"
#include "R_IN32M4_5.h"
#include "R_IN32M4_6.h"

#endif /* __R_IN32M4_H_INCLUDED_ */

/*** EOF ***/
