/****************************************************************************/
/* CC-Link IE Field network                                                 */
/*                                                                          */
/* R_IN32M4 Driver                                                          	*/
/*                                                                          */
/* Copyright 2016 Renesas Electronics Corporation. All rights reserved. 	*/
/****************************************************************************/

/****************************************************************************/
/** @file   R_IN32D_RcvPrm_l.h                                                */
/** @brief  R_IN32M4 driver                                                    */
/** @author Renesas Electronics Corporation                                 */
/** @date   2016/01/15                                                      */
/** @file                                                                   */
/****************************************************************************/
#ifndef __R_IN32D_RCVPRM_L_H_INCLUDED__
#define __R_IN32D_RCVPRM_L_H_INCLUDED__


/****************************************************************************/
/* Include files                                                            */
/****************************************************************************/
#include "R_IN32M4Driver.h"


/****************************************************************************/
/* Define                                                                   */
/****************************************************************************/

#define R_IN32D_PARAM_NUMBER	0x01UL		
#define R_IN32D_PARAM_ACTION	0x02UL		
#define R_IN32D_PARAM_COMMON	0x04UL		


/****************************************************************************/
/* Structures                                                               */
/****************************************************************************/

typedef struct _R_IN32D_REFRESH_SIZE_TAG {
	ULONG				ulRyByteSize;			
	ULONG				ulRxByteSize;			
	ULONG				ulRWrByteSize;			
	ULONG				ulRWwByteSize;			
} R_IN32D_REFRESH_SIZE_T;

typedef struct _R_IN32D_PRAMETER_NUMBER_RCV_TAG {
	USHORT				usSelfNumber;			
	NET_NUM_T			stNetNum;				
} R_IN32D_PRAMETER_NUMBER_RCV_T;

typedef struct _R_IN32D_PRAMETER_ACTION_RCV_TAG {
	CYCLIC_STA_T		stCyclicSta;			
	USHORT				usActCmd;				
} R_IN32D_PRAMETER_ACTION_RCV_T;

typedef struct _R_IN32D_PRAMETER_COMMON_RCV_TAG {
	PARAMID_T		stPARAMID;					
	USHORT			usMASTER_STATUS;			

	RY1_FMB_INFO_T	stRY1_FMB_INFO;				
	USHORT			usRY1CYC_DSIZE;				

	USHORT			usRWw1CYC_DSIZE;			

	TDIS1_T			stTD_RX0_TDIS1;				
	TDIS3_T			stTD_RX0_TDIS3;				
	TDIS6_T			stTD_RX0_TDIS6;				

	TDIS1_T			stTD_RWR0_TDIS1;			
	TDIS3_T			stTD_RWR0_TDIS3;			

	TDIS1_T			stTD_RWR1_TDIS1;			
	TDIS3_T			stTD_RWR1_TDIS3;			

} R_IN32D_PRAMETER_COMMON_RCV_T;


/****************************************************************************/
/* Variables                                                                */
/****************************************************************************/
extern R_IN32D_REFRESH_SIZE_T		gstR_IN32D_RefreshSize;		


/****************************************************************************/
/* Functions (for R_IN32D)                                                     */
/****************************************************************************/
extern ERRCODE erR_IN32D_FetchParameterRcv( ULONG );

#endif /* __R_IN32D_RCVPRM_L_H_INCLUDED__ */

/*** EOF ***/
