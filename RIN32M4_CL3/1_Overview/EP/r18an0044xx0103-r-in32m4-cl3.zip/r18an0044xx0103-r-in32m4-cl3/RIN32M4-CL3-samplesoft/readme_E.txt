###########################################################################################
  R-IN32M4-CL3 Sample Program 
  
                                            Renesas Electronics Corporation   Nov 10, 2020
###########################################################################################
  
 NOTICE 
   This software is just for reference sample software, 
   Renesas does NOT gurantee the operation.
   Please use this software, after you thoroughly check and evaluate on your enviroment.
  
  
 =============================================================================== 
  Abstract 
 =============================================================================== 
 This sample program is simple program to check R-IN32M4-CL3 operation.
 
 When executing this sample program on the evaluation board TS-TCS07908, 
 comment out "TS_TCS08467" in RIN32M4.h.
 The initial setting is for the evaluation board SBEV-RIN32M4CL3 and TS-TCS08467.
 
  \Device\Renesas\RIN32M4\Include\RIN32M4.h
  
 =============================================================================== 
  Development Environment
 =============================================================================== 
 Development environment is as below.

  << IAR Embedded Workbench for Arm + I-jet / I-jet Trace for Arm Cortex-M >>
   Compiler    : IAR Embedded Workbench for Arm 8.42.1
   Debugger    : IAR Embedded Workbench for Arm 8.42.1
   ICE         : I-jet / I-jet Trace for Arm Cortex-M (IAR)

 =============================================================================== 
  Directory Structure
 =============================================================================== 

 +-- CMSIS << Cortex Microcontroller Software Interface Standard  >>
 |     |
 |     +-- include
 |
 +-- Device << Device dependent files >>
       |
       +-- Renesas
             |
             +-- RIN32M4 << R-IN32M4 dependent files >>
                  |
                  +-- Include << Include directory >>
                  |
                  +-- Library << Library directory >>
                  |
                  +-- Source  << Source directory >>
                       |
                       +-- Driver     << Driver directory >>
                       |
                       +-- Middleware << Middleware directory >>
                       |
                       +-- Project    << Project directory >>
                       |    |
                       |    +-- [Board type]
                       |          +-- can_sample
                       |          +-- cie_intelligent_device
                       |          +-- cie_remote_device
                       |          +-- interval_timer
                       |          +-- os_sample
                       |          +-- osless_sample
                       |          +-- uNet3_bsd
                       |          +-- uNet3_mac
                       |          +-- uNet3_nonblock
                       |          +-- uNet3_sample
                       |          +-- uNet3_snmp
                       |          +-- version_get_sample
                       |
                       +-- Templates  << Startup file and others >>
                            |
                            +-- IAR     << IAR compiler dependent files >>

 =============================================================================== 
  Function Structure
 =============================================================================== 
 ====== Driver ======
  - CAN
  - CSI
  - DMAC
  - Ether Switch
  - IIC
  - Serial Flash MEMC
  - TAUD  (16bit timer TAUD)
  - Timer (32bit timer TAUJ2)
  - UART
  - WDT

 ====== Middleware ======
  - Parallel flash ROM control
  - Serial   flash ROM control
  - TCP/IP stack control

 ====== Library ======
  - HW-RTOS library
  - EtherPHY library
  - TCP/IP stack library

 ====== Application ======
  - CAN sample
  - CC-Link IE Field (intelligent device)
  - CC-Link IE Field (remote device)
  - Interval timer sample
  - OS sample
  - OS-less sample
  - TCP/IP BSD Socket API sample
  - TCP/IP MAC Control sample
  - TCP/IP nonblock API sample
  - TCP/IP Network App sample
  - TCP/IP SNMP sample
  - Version get sample

