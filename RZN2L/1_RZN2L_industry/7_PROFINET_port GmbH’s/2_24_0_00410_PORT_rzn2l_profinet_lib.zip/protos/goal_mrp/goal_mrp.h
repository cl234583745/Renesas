/** @file
 *
 * @brief
 * Media Redundancy Protocol
 *
 * @details
 * Implementation of the Media Redundancy Protocol
 *
 * @copyright
 * Copyright 2010-2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_MRP_H
#define GOAL_MRP_H

#include <goal_includes.h>
#include <pn_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/

/**< MRP test packet MAC address */
#define GOAL_MRP_TEST_MAC_ADDR { 0x01, 0x15, 0x4E, 0x00, 0x00, 0x01}

/**< MRP topology/link change MAC address */
#define GOAL_MRP_LINK_CHANGE_MAC_ADDR { 0x01, 0x15, 0x4E, 0x00, 0x00, 0x02}

/**< MRP default domain UUID */
#define GOAL_MRP_DEFAULT_UUID { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}

#define GOAL_MRP_RING_PORT_ID_1 0               /**< Ring port 1 ID */
#define GOAL_MRP_RING_PORT_ID_2 1               /**< Ring port 2 ID */

/* MRP Roles */
#define GOAL_MRP_ROLE_DISABLED                  0x0000 /**< MRP Role MRP disabled */
#define GOAL_MRP_ROLE_CLIENT                    0x0001 /**< MRP Role MRP client */

/* MRP Timer Default Settings */
#define GOAL_MRP_LINK_CHANGE_TIMER_VAL          20 /**< MRP default Link Change Timer Interval */
#define GOAL_MRP_LINK_CHANGE_NUMBER             3  /**< MRP default Number of Link Changes */

/* MRP block types */
#define GOAL_MRP_BLOCK_TYPE_END                 0x00 /**< MRP Type End */
#define GOAL_MRP_BLOCK_TYPE_COMMON              0x01 /**< MRP Type Common */
#define GOAL_MRP_BLOCK_TYPE_TEST                0x02 /**< MRP Type Test */
#define GOAL_MRP_BLOCK_TYPE_TOPOLOGY_CHANGE     0x03 /**< MRP Type Topologie Change */
#define GOAL_MRP_BLOCK_TYPE_LINK_DOWN           0x04 /**< MRP Type LinkDown */
#define GOAL_MRP_BLOCK_TYPE_LINK_UP             0x05 /**< MRP Type LinkUp */
#define GOAL_MRP_BLOCK_TYPE_IN_TEST             0x06 /**< MRP Type Test */
#define GOAL_MRP_BLOCK_TYPE_IN_TOPOLOGY_CHANGE  0x07 /**< MRP Type Topologie Change */
#define GOAL_MRP_BLOCK_TYPE_IN_LINK_DOWN        0x08 /**< MRP Type LinkDown */
#define GOAL_MRP_BLOCK_TYPE_IN_LINK_UP          0x09 /**< MRP Type LinkUp */
#define GOAL_MRP_BLOCK_TYPE_IN_LINK_STAT_POLL   0x0A /**< MRP Type LinkUp */
#define GOAL_MRP_BLOCK_TYPE_OPTION              0x7F /**< MRP Type Option */

/* MRP Domain UIID Size */
#define MRP_DOMAIN_UUID_SIZE    16              /**< MRP Domain UUID Size */
#define MRP_DOMAIN_NAME_SIZE    240             /**< MRP Domain name size */

/* MRP Ring State */
#define GOAL_MRP_RING_STATE_OPEN                0x00 /**< MRP Ring State Ring Open */
#define GOAL_MRP_RING_STATE_CLOSED              0x01 /**< MRP Ring State Ring Closed */

/* MRP Port Role */
#define GOAL_MRP_PORT_ROLE_PRIMARY              0x00 /**< MRP Primary ring port */
#define GOAL_MRP_PORT_ROLE_SECONDARY            0x01 /**< MRP Secondary ring port */
#define GOAL_MRP_PORT_ROLE_IN                   0x02 /**< MRP interconnection port */

/* MRP Block Lengths */
#define GOAL_MRP_BLOCK_LEN_LINK                 0x0e /**< MRP link change block length */
#define GOAL_MRP_BLOCK_LEN_COMMON               0x12 /**< MRP common block length */
#define GOAL_MRP_BLOCK_LEN_END                  0x00 /**< MRP end block length */

#define GOAL_MRP_LINK_CHANGE_START              0x00 /**< Start Value MRP Link Change */

/* MRP Read Res Block Version */
#define GOAL_MRP_READ_RES_BLOCK_VER_HIGH_1      0x01 /**< MRP Read Response Block Version High 1 */
#define GOAL_MRP_READ_RES_BLOCK_VER_LOW_0       0x00 /**< MRP Read Response Block Version Low 0 */
#define GOAL_MRP_READ_RES_BLOCK_VER_LOW_1       0x01 /**< MRP Read Response Block Version Low 1 */

/* Record Related Types */
#define GOAL_MRP_CLIENTPARAMS_BLOCK_LEN         0x08 /**< MRP lient Parameters Block Length */

/* MRP Version */
#define GOAL_MRP_VERSION                        0x0001 /**< MRP Version */

/* Padding */
#define GOAL_MRP_PADDING_16_ZERO                0x0000 /**< Padding 16bit Zeros */


/****************************************************************************/
/* Datatypes */
/****************************************************************************/


/** MRP State Enum */
typedef enum {
    MRP_STATE_POWER_ON = 0,                     /**< MRP State Power on */
    MRP_STATE_AC_STAT1,                         /**< MRP State Awaiting Conection State 1 */
    MRP_STATE_DE_IDLE,                          /**< MRP State Data Exchange Idle State */
    MRP_STATE_PT,                               /**< MRP State Pass Through */
    MRP_STATE_DE,                               /**< MRP State Data Exchange */
    MRP_STATE_PT_IDLE,                          /**< MRP State Pass Through Idle State */
} GOAL_MRP_STATE_T;

/** MRP link state */
typedef enum {
    MRP_LINK_STATE_DEFAULT = 0,                 /**< MRP Port State Default */
    MRP_LINK_STATE_UNKNOWN,                     /**< MRP Port State Unknown */
    MRP_LINK_STATE_DOWN,                        /**< MRP Port State  */
    MRP_LINK_STATE_UP,                          /**< MRP Port Status Init */
} GOAL_MRP_LINK_STATE_T;

/**< MRP common field type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t mrpBlockType;                       /**< MRP Block type */
    uint8_t blockLen;                           /**< MRP block Length */
    uint16_t seqId;                             /**< MRP sequence ID */
    uint8_t mrpDomainUuid[MRP_DOMAIN_UUID_SIZE]; /*! MRP Domain UUID */
} GOAL_TARGET_PACKED GOAL_MRP_BLOCK_COMMON_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< MRP test field type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t mrpBlockType;                       /**< MRP Block type */
    uint8_t blockLen;                           /**< MRP block Length */
    uint16_t mrpPrio;                           /**< MRP priority */
    GOAL_ETH_MAC_ADDR_T mrpSa;                  /**< MRP SA */
    uint16_t mrpPortRole;                       /**< MRP port role */
    uint16_t mrpRingState;                      /**< MRP ring State */
    uint16_t mrpTransition;                     /**< MRP Transition */
    uint32_t mrpTimestamp;                      /**< MRP Timestamp */
} GOAL_TARGET_PACKED GOAL_MRP_BLOCK_TEST_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< MRP link change field type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t mrpBlockType;                       /**< MRP Block type */
    uint8_t blockLen;                           /**< MRP block Length */
    GOAL_ETH_MAC_ADDR_T mrpSa;                  /**< MRP SA */
    uint16_t mrpPortRole;                       /**< MRP port role */
    uint16_t mrpInterval;                       /**< MRP Interval for next topology change in ms */
    uint16_t mrpBlocked;                        /**< MRP Blocked */
    uint16_t padding;                           /**< padding */
} GOAL_TARGET_PACKED GOAL_MRP_BLOCK_LINK_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< MRP end field type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t mrpBlockType;                       /**< MRP Block type */
    uint8_t blockLen;                           /**< MRP block Length */
} GOAL_TARGET_PACKED GOAL_MRP_BLOCK_END_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< Ethernet header frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t macDst[MAC_ADDR_LEN];               /**< destination MAC address */
    uint8_t macSrc[MAC_ADDR_LEN];               /**< source MAC address */
    uint16_t typeEth_be16;                      /**< EtherType */
} GOAL_TARGET_PACKED GOAL_MRP_ETH_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< MRP Frame type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t mrpVersion;                        /**< MRP Version */
    union {
        GOAL_MRP_BLOCK_TEST_T mrpTest;          /**< MRP Block Test */
        GOAL_MRP_BLOCK_LINK_T mrpLink;          /**< MRP Block Link Up */
    } firstblock;
    GOAL_MRP_BLOCK_COMMON_T mrpCommon;          /**< MRP Block Common */
    GOAL_MRP_BLOCK_END_T mrpEnd;                /**< MRP Block End */
} GOAL_TARGET_PACKED GOAL_MRP_FRAME_T;
GOAL_TARGET_PACKED_STRUCT_POST

/**< MRP Link Change Frame type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t mrpVersion;                        /**< MRP Version */
    GOAL_MRP_BLOCK_LINK_T mrpLink;          /**< MRP Block Link Up */
    GOAL_MRP_BLOCK_COMMON_T mrpCommon;          /**< MRP Block Common */
    GOAL_MRP_BLOCK_END_T mrpEnd;                /**< MRP Block End */
} GOAL_TARGET_PACKED GOAL_MRP_LINK_CHANGE_FRAME_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP link change timer */
typedef struct {
    GOAL_TIMER_T *pMrpLinkTimer;                /**< MRP Link Change Send Timer */
    uint8_t linkChangeCnt;                      /**< MRP Link Change Count */
    uint32_t changedPortId;                     /**< Id of changed port */
    uint8_t changeType;                         /**< Link change type */
} GOAL_MRP_LINK_CHANGE_TIMER_T;

/**< MRP ASE type */
typedef struct {
    GOAL_PNIO_T *pPnio;
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
    uint8_t domainNameLen;                      /**< MRP Domain Name Length */
    uint8_t domainName[MRP_DOMAIN_NAME_SIZE];   /**< MRP Domain Name */
    uint16_t ringPort1Id;                       /**< Port ID of primary ring port */
    GOAL_MRP_LINK_STATE_T ringPort1State;       /**< Ring port state */
    uint16_t ringPort2Id;                       /**< Port ID of secundary ring port */
    GOAL_MRP_LINK_STATE_T ringPort2State;       /**< Ring port state */
    uint16_t vlanId;                            /**< VLAN identifier */
    uint16_t expectedRole;                      /**< MRP Expected Role */
    uint16_t mrpVersion;                        /**< MRP Version */
    uint16_t linkDownInt;                       /**< Link down interval */
    uint16_t linkUpInt;                         /**< Link up interval */
    uint16_t linkChangeNmb;                     /**< Link change interval */
    GOAL_BOOL_T blockedSupported;               /**< Blocked state Supportet */
    uint8_t macMrpSa[MAC_ADDR_LEN];             /**< MRP MRM nac address */
    uint16_t seqID;                             /**< MRP send sequence ID */
    GOAL_BOOL_T port1initflg;                   /**< Ring Port 1 Init Flag */
    GOAL_BOOL_T port2initflg;                   /**< Ring Port 2 Init Flag */
    GOAL_MRP_LINK_CHANGE_TIMER_T *changeTimer;  /**< MRP link change timer */
    GOAL_BOOL_T mrpInitFlg;                     /**< init flag */
    uint16_t mrpLinkChangeTimerVal;             /**< MRP default Link Change Timer Interval */
    uint16_t mrpLinkChangeNmb;                  /**< MRP default Number of Link Changes */
    GOAL_BOOL_T mrpCfgFlg;                      /**< MRP configuration flag */
} GOAL_MRP_ASE_T;

/* MRP Client Parameter Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t linkDownInt;                       /**< Link down interval */
    uint16_t linkUpInt;                         /**< Link up interval */
    uint16_t linkChangeNmb;                     /**< Link change interval */
} GOAL_TARGET_PACKED GOAL_MRP_CL_PARAM_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP PDInterfaceMrpDataAdjust Record Read Response Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t padding1;                          /**< Padding */
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
    uint16_t mrpRole;                           /**< MRP Role */
    uint16_t padding2;                          /**< Padding */
    uint8_t mrpDomainNameLen;                   /**< MRP Domain Name Length */
    uint8_t domainName[MRP_DOMAIN_NAME_SIZE];   /**< MRP Domain Name */
} GOAL_TARGET_PACKED GOAL_MRP_IF_DATA_ADJ_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP PDInterfaceMrpDataReal Record Read Response Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t padding1;                          /**< Padding */
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
    uint16_t mrpRole;                           /**< MRP Role */
    uint16_t mrpVersion;                        /**< Mrp Version */
    uint8_t mrpDomainNameLen;                   /**< MRP Domain Name Length */
    uint8_t domainName[MRP_DOMAIN_NAME_SIZE];   /**< MRP Domain Name */
} GOAL_TARGET_PACKED GOAL_MRP_IF_DATA_REAL_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP PDInterfaceMrpDataCheck Record Read Response Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t padding;                           /**< Padding */
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
    uint32_t mrpCheck;                          /**< MRP Check */
} GOAL_TARGET_PACKED GOAL_MRP_IF_DATA_CHECK_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP PDPortMrpDataAdjust Record Read Response Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t padding;                           /**< Padding */
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
} GOAL_TARGET_PACKED GOAL_MRP_PORT_DATA_ADJ_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST

/* MRP PDPortMrpDataAdjust Record Read Response Type */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHead;                     /**< Block Header */
    uint16_t padding;                           /**< Padding */
    uint8_t domainUuid[MRP_DOMAIN_UUID_SIZE];   /**< MRP Domain UUID */
} GOAL_TARGET_PACKED GOAL_MRP_PORT_DATA_REAL_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
void goal_mrpCfgReset(
    void
);

void goal_mrpUuidGet(
    uint8_t *pMrpUUID                           /**< pointer to fill */
);

uint16_t goal_mrpExpectedRoleGet(
    void
);

GOAL_BOOL_T goal_mrpConfigFlagGet(
    void
);

GOAL_STATUS_T goal_mrpNew(
    GOAL_PNIO_T *pInst                          /**< GOAL PROFINET Instance */
);

GOAL_STATUS_T goal_mrpSetDomainName(
    char *pDomainName,                          /**< MRP Domain Name */
    uint8_t domainNameLen                       /**< MRP Domain Name length */
);

PN_STATUS_T goal_mrpReadPDIfaceDataReal(
    IOD_READ_RES_T *pReadRes,                   /**< Read Response */
    uint16_t *pOutDataLen,                      /**< output data length */
    uint16_t offset                             /**< offset for multiple read */
);

PN_STATUS_T goal_mrpAddDataPDIfaceDataReal(
    uint8_t *ptr,                               /**< Read Response Data Pointer */
    uint16_t *pLen                              /**< Read Response Data Length */
);

PN_STATUS_T goal_mrpReadPDIfaceDataAdj(
    IOD_READ_RES_T *pReadRes,                   /**< Read Response */
    uint16_t *pOutDataLen                       /**< output data length */
);

PN_STATUS_T goal_mrpAddDataPDIfaceDataAdj(
    uint8_t *ptr,                               /**< Read Response Data Pointer */
    uint16_t *pLen                              /**< Read Response Data Length */
);

PN_STATUS_T goal_mrpReadPDIfaceDataCheck(
    IOD_READ_RES_T *pReadRes,                   /**< Read Response */
    uint16_t *pOutDataLen                       /**< output data length */
);

PN_STATUS_T goal_mrpAddDataPDIfaceDataCheck(
    uint8_t *ptr,                               /**< Read Response Data Pointer */
    uint16_t *pLen                              /**< Read Response Data Length */
);

PN_STATUS_T goal_mrpReadPDPortDataAdj(
    IOD_READ_RES_T *pReadRes,                   /**< Read Response */
    uint16_t *pOutDataLen                       /**< output data length */
);

PN_STATUS_T goal_mrpReadPDPortDataReal(
    IOD_READ_RES_T *pReadRes,                   /**< Read Response */
    uint16_t *pOutDataLen,                      /**< output data length */
    uint16_t offset                             /**< offset for multiple read */
);

PN_STATUS_T goal_mrpWritePDIfaceDataAdjust(
    const void *pRequest                        /**< PE Write Request Data */
);

PN_STATUS_T goal_mrpWritePDIfaceDataCheck(
    const void *pRequest                        /**< PE Write Request Data */
);

PN_STATUS_T goal_mrpWritePDPortDataAdjust(
    const void *pRequest                        /**< PE Write Request Data */
);

#endif /* GOAL_MRP_H */
