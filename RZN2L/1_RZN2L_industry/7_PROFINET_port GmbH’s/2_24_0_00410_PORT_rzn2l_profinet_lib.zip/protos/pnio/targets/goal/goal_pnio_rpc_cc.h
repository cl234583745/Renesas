/** @file
 *
 * @brief
 * GOAL PROFINET CC Adapter
 *
 * @details
 * Provides the GOAL PROFINET API over CTC RPC.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_PNIO_RPC_CC_H
#define GOAL_PNIO_RPC_CC_H

#include <goal_pnio_rpc.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_pnioInitCc(
    void
);


#endif /* GOAL_PNIO_RPC_CC_H */
