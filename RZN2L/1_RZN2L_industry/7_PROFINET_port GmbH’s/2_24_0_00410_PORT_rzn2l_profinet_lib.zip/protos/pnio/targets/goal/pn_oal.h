/** @file
 *
 * @brief
 * PROFINET Operating system abstraction layer module stack internal definitions
 *
 * @details
 * This header defines function prototypes and module specific constants for
 * Operating system abstraction layer module.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_OAL_H
#define PN_OAL_H

#include <goal_includes.h>


/****************************************************************************/
/* Macros */
/****************************************************************************/
#define OAL_MEMCPY              GOAL_MEMCPY
#define OAL_MEMSET              GOAL_MEMSET
#define OAL_MEMCMP              GOAL_MEMCMP
#define OAL_STRLEN              GOAL_STRLEN
#define OAL_STRNLEN             GOAL_STRNLEN
#define OAL_STRNCPY             GOAL_STRNCPY
#define OAL_STRSTR              GOAL_STRSTR
#define OAL_ASSERT(x)           { if (!(x)) { PN_logErr("Assert: %s", #x); OAL_halt(); } }
#define OAL_SNPRINTF            GOAL_SNPRINTF
#define OAL_VSNPRINTF           GOAL_VSNPRINTF
#define OAL_ISALNUM             GOAL_ISALNUM
#define OAL_ISDIGIT             GOAL_ISDIGIT

/* Memory flag wrappers */
#define PN_MEM_FLAG_NONE            GOAL_QUEUE_FLG_NONE
#define PN_MEM_FLAG_TX              GOAL_QUEUE_FLG_TX
#define PN_MEM_FLAG_NO_RELEASE      GOAL_QUEUE_FLG_NO_RELEASE
#define PN_MEM_FLAG_VLAN            GOAL_QUEUE_FLG_VLAN
#define PN_MEM_FLAG_KEEP_CONTENT    GOAL_QUEUE_FLG_KEEP_CONTENT
#define PN_MEM_FLAG_USED            GOAL_QUEUE_FLG_USED

/* Buffer wrappers */
#define OAL_BUFFER_T                GOAL_BUFFER_T
#define QUEUE_T                     GOAL_QUEUE_T
#define MM_releaseCb                goal_queueReleaseCb

/* Queue ID wrappers */
#define MM_QID_SMALL                0
#define MM_QID_NET                  1
#define MM_QID_MAX                  2
#define MM_QID_NONE                 3

/* Timer wrappers */
#define PN_TIMER_T                  GOAL_TIMER_T
#define PN_TIMER_STATE_T            GOAL_TIMER_STATE_T
#define PN_TIMER_STATE_FREE         GOAL_TIMER_STATE_FREE
#define PN_TIMER_STATE_USED         GOAL_TIMER_STATE_USED
#define PN_TIMER_STATE_SETUP        GOAL_TIMER_STATE_SETUP
#define PN_TIMER_STATE_ACTIVE       GOAL_TIMER_STATE_ACTIVE
#define PN_TIMER_STATE_RUN          GOAL_TIMER_STATE_RUN
#define PN_TIMER_MSEC               GOAL_TIMER_MSEC
#define PN_TIMER_SEC                GOAL_TIMER_SEC

/* Logging wrappers */
#define PN_LOG_SET_ID               GOAL_LOG_SET_ID


/****************************************************************************/
/* Prototypes/Wrappers */
/****************************************************************************/
#define PN_lockCreate(lT, pL, vI, vM, u) PN_statusGoalToIod(goal_lockCreate(lT, pL, vI, vM, (GOAL_ID_T) u))
#define PN_lockGet(...) PN_statusGoalToIod(goal_lockGet(__VA_ARGS__))
#define PN_lockPut goal_lockPut
#define PN_lockDelete goal_lockDelete
#define PN_lockGetIfTrue(...) PN_statusGoalToIod(goal_lockGetIfTrue(__VA_ARGS__))
#define PN_lockGetIfFalse(...) PN_statusGoalToIod(goal_lockGetIfFalse(__VA_ARGS__))

#define MM_init() IOD_OK
#define OAL_memInitQueue(...) PN_statusGoalToIod(goal_queueInit(__VA_ARGS__))
#define OAL_getBuffer(pBuf, ...) PN_statusGoalToIod(goal_ethGetNetBuf(pBuf))
#define OAL_getBufferById(pBuf, ...) PN_statusGoalToIod(goal_ethGetNetBuf(pBuf))
#define OAL_getBufferFromQueue(pB, pQ, u) PN_statusGoalToIod(goal_queueGetNewBuf(pB, pQ, (GOAL_ID_T) u))
#define MM_isQueueFull goal_queueIsFull
#define MM_isQueueEmpty goal_queueIsEmpty
#define OAL_setBufferReleaseCallback goal_queueSetReleaseCallback
#define PN_memFlagsClear(pBuf, flags) goal_queueFlagsClr(pBuf, flags)
#define PN_memFlagsSet(pBuf, flag) goal_queueFlagsSet(pBuf, flag)
#define PN_memFlagsGet(pBuf, flags) goal_queueFlagsGet(pBuf, flags)
#define OAL_setBufferTraceId(x, y)

#define PN_memInit() IOD_OK
#define PN_memAlloc(...) PN_statusGoalToIod(goal_memAllocAlign(__VA_ARGS__))
#define PN_memAllocAlign(...) PN_statusGoalToIod(goal_memAllocAlign(__VA_ARGS__, GOAL_TARGET_MEM_ALIGN_NET))
#define PN_memCalloc(...) PN_statusGoalToIod(goal_memCalloc(__VA_ARGS__))
#define PN_memCallocAlign(...) PN_statusGoalToIod(goal_memCallocAlign(__VA_ARGS__, GOAL_TARGET_MEM_ALIGN_NET))

#define PN_timerInit() IOD_OK
#define PN_timerCreate(pId, prio) PN_statusGoalToIod(goal_timerCreate(pId, (GOAL_TIMER_PRIO_T) prio))
#define PN_timerSetup(id, ty, pe, pF, pA, sF) PN_statusGoalToIod(goal_timerSetup(id, (GOAL_TIMER_TYPE_T) ty, pe, pF, pA, sF))
#define PN_timerStart(...) PN_statusGoalToIod(goal_timerStart(__VA_ARGS__))
#define PN_timerStop(...) PN_statusGoalToIod(goal_timerStop(__VA_ARGS__))
#define PN_timerRun()

IOD_STATUS_T PN_logInit(
    PN_BOOL_T sysFlag                           /**< system run flag */
);

#define PN_logErr goal_logErr
#define PN_logWarn goal_logWarn
#define PN_logInfo goal_logInfo
#define PN_logDbg goal_logDbg

const char * uuidToString(
    const Unsigned8 *uuid                       /**< UUID ptr */
);

IOD_STATUS_T PN_statusGoalToIod(
    GOAL_STATUS_T status                        /**< GOAL_STATUS_T value */
);

GOAL_STATUS_T PN_statusIodToGoal(
    IOD_STATUS_T status                         /**< IOD_STATUS_T value */
);

GOAL_STATUS_T PN_netChanGoalToPnio(
    GOAL_NET_CHAN_T *pChanGoal,                 /**< GOAL net channel */
    int *pChanPnio                              /**< PNIO net channel */
);

GOAL_STATUS_T PN_netChanPnioToGoal(
    int chanPnio,                               /**< PNIO net channel */
    GOAL_NET_CHAN_T **ppChanGoal                /**< GOAL net channel */
);

GOAL_STATUS_T PN_netChanCreateEntry(
    GOAL_NET_CHAN_T *pChanGoal,                 /**< GOAL net channel */
    int *pChanPnio                              /**< PNIO net channel */
);


#define OAL_getTimestamp() goal_timerTsGet()


#endif /* PN_OAL_H */
