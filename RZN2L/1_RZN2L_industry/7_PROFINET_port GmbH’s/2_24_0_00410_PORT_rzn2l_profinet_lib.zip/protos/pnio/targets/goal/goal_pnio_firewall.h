/** @file
 *
 * @brief
 * GOAL PROFINET Firewall
 *
 * @details
 * GOAL PROFINET specific firewall that filters DCP Ident Requests that aren't
 * matching the devices name.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_PNIO_FIREWALL_H
#define GOAL_PNIO_FIREWALL_H


/****************************************************************************/
/* Datatypes */
/****************************************************************************/
/**< simplified PROFINET DCP frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t idService;                          /**< service id */
    uint8_t typeService;                        /**< service type */
    uint32_t idXid_be32;                        /**< Xid */
    uint16_t lenRespDelay_be16;                 /**< response delay */
    uint16_t lenDcpData_be16;                   /**< DCP data length */
    uint8_t idOpt;                              /**< option */
    uint8_t idSubopt;                           /**< suboption */
    uint16_t lenBlock_be16;                     /**< DCP block length */
} GOAL_TARGET_PACKED GOAL_PNIO_FW_DCP_T;
GOAL_TARGET_PACKED_STRUCT_POST


#define GOAL_PNIO_FW_DCP_SERVICE_TYPE_REQ 0x00  /**< default service type */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_pnioFwInit(
    void
);

GOAL_STATUS_T goal_pnioFw(
    uint8_t *pData,                             /**< [in] data */
    unsigned int lenData,                       /**< data length */
    uint16_t idPnio                             /**< PROFINET frame ID */
);


#endif /* GOAL_PNIO_FIREWALL_H */
