/** @file
 *
 * @brief
 * PROFINET Operating system abstraction layer - data type definitions
 *
 * @details
 * This header contains data type definitions which are used by OAL and
 * external OS-dependend modules.
 *
 * It is currently an extra file, because pnio_types.h can't include pn_oal.h
 * as it is refereing to pnio_types.h.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_OAL_TYPES_H
#define PN_OAL_TYPES_H

#include <goal_includes.h>
#include <ctype.h>
#include <limits.h>


/****************************************************************************/
/* GOAL compiler mappings */
/****************************************************************************/
/* Network and Frame Handling Defines
 *
 * CONFIG_TARGET_ETH_BUF_RX - number of RX buffers
 * CONFIG_TARGET_ETH_BUF_TX - number of TX buffers
 */
#define CONFIG_TARGET_ETH_BUF_RX 2
#define CONFIG_TARGET_ETH_BUF_TX 2


/* portable data type definitions */
typedef int8_t    Integer8;     /**< signed integer 8 bit */
typedef int16_t   Integer16;    /**< signed integer 16 bit */
typedef int32_t   Integer32;    /**< signed integer 32 bit */
typedef int64_t   Integer64;    /**< signed integer 64 bit */
typedef uint8_t   Unsigned8;    /**< unsigned integer 8 bit */
typedef uint16_t  Unsigned16;   /**< unsigned integer 16 bit */
typedef uint32_t  Unsigned32;   /**< unsigned integer 32 bit */
typedef uint64_t  Unsigned64;   /**< unsigned integer 64 bit */

typedef int OAL_UDPCHAN_T;      /**< UDP socket descriptor */
typedef GOAL_LOCK_T OAL_LOCK_BIN_T; /**< binary lock handle */
typedef GOAL_LOCK_T OAL_LOCK_CNT_T; /**< counting lock handle */
typedef int OAL_THREAD_T;       /**< thread/level handle */


#endif /* PN_OAL_TYPES_H */
