/** @file
 *
 * @brief
 * PROFINET Global Independent Type Definitions
 *
 * @details
 * This file contains definitions that are generic and independend from othe
 * definitions.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_TYPES_INDEP_H
#define PN_TYPES_INDEP_H

/* configuration */
#include <pn_conf_def.h>

/* include portable type definitions */
#include <pn_oal_types.h>


/**< timer specific defines */
#define PN_TIMER_INVALID                0
#define PN_TIMER_FUNC(f, p)             void f(void *p)
typedef void (* PN_TIMER_CB_T)(void *);

typedef enum {
    PN_TIMER_SINGLE = 0,                        /**< single shot timer */
    PN_TIMER_PERIODIC = 1                       /**< periodic timer */
} PN_TIMER_TYPE_T;


typedef enum {                                  /**< timer priorities */
    PN_TIMER_LOW = 0,
    PN_TIMER_HIGH = 1
} PN_TIMER_PRIO_T;


/**< 64 bit timestamp */
typedef Unsigned64 PN_TIMESTAMP_T;              /**< timestamp */


typedef enum {
    PN_NET_TX_LOW = 0,                          /**< low priority */
    PN_NET_TX_LLDP,                             /**< LLDP */
    PN_NET_TX_RT,                               /**< real-time data */
} PN_NET_TX_TYPE_T;


/**< boolean definition */
#define PN_FALSE        GOAL_FALSE
#define PN_TRUE         GOAL_TRUE
#define PN_BOOL_T       GOAL_BOOL_T


/**< byte specific UUID definition */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 data1[4];
    Unsigned8 data2[2];
    Unsigned8 data3[2];
    Unsigned8 data4[8];
} GOAL_TARGET_PACKED UUID_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< type specific UUID definition */
typedef struct
{
    Unsigned32 data1;
    Unsigned16 data2;
    Unsigned16 data3;
    Unsigned8  data4[8];
}
UUID_TYPE_T;


/**< endian type */
#define PN_ENDIAN_T GOAL_ENDIAN_T
#define PN_ENDIAN_LITTLE GOAL_ENDIAN_LITTLE
#define PN_ENDIAN_BIG GOAL_ENDIAN_BIG


/**< usage types (see goal/goal_id.h) */
#define PN_USAGE_ALARM_ACK              GOAL_ID_PNIO_ALARM_ACK
#define PN_USAGE_ALARM_DATA             GOAL_ID_PNIO_ALARM_DATA
#define PN_USAGE_ALARM_ERR              GOAL_ID_PNIO_ALARM_ERR
#define PN_USAGE_AR                     GOAL_ID_PNIO_AR
#define PN_USAGE_CRT_EP                 GOAL_ID_PNIO_CRT_EP
#define PN_USAGE_CRT_EP_INPUT           GOAL_ID_PNIO_CRT_EP_INPUT
#define PN_USAGE_CRT_EP_OUTPUT          GOAL_ID_PNIO_CRT_EP_OUTPUT
#define PN_USAGE_CRT_EP_CLEANUP         GOAL_ID_PNIO_CRT_EP_CLEANUP
#define PN_USAGE_CTX_APP_READY          GOAL_ID_PNIO_CTX_APP_READY
#define PN_USAGE_DCP_IDENTIFY_RESPONSE  GOAL_ID_PNIO_DCP_IDENT_RESP
#define PN_USAGE_DCP_GET_RESPONSE       GOAL_ID_PNIO_DCP_GET_RESPONSE
#define PN_USAGE_DCP_SET_RESPONSE       GOAL_ID_PNIO_DCP_SET_RESPONSE
#define PN_USAGE_LLDP                   GOAL_ID_PNIO_LLDP
#define PN_USAGE_RPC_LOCK               GOAL_ID_PNIO_RPC_LOCK
#define PN_USAGE_RPC_EPM_LOCK           GOAL_ID_PNIO_RPC_EPM_LOCK
#define PN_USAGE_OAL_ETH_RECV           GOAL_ID_PNIO_OAL_ETH_RECV
#define PN_USAGE_OAL_ETH_SEND           GOAL_ID_PNIO_OAL_ETH_SEND
#define PN_USAGE_LOG_SYSLOG             GOAL_ID_PNIO_LOG_SYSLOG
#define PN_USAGE_CTX                    GOAL_ID_PNIO_CTX


/* generic lock handle defines */
#define PN_LOCK_INFINITE                 0

#define PN_LOCK_BINARY  GOAL_LOCK_BINARY
#define PN_LOCK_COUNT   GOAL_LOCK_COUNT
#define PN_LOCK_TYPE_T  GOAL_LOCK_TYPE_T
#define PN_LOCK_T       GOAL_LOCK_T


/**< PROFINET Status */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 errorCode;                        /**< ErrorCode */
    Unsigned8 errorDecode;                      /**< ErrorDecode */
    Unsigned8 errorCode1;                       /**< ErrorCode1 */
    Unsigned8 errorCode2;                       /**< ErrorCode2 */
} GOAL_TARGET_PACKED ERROR_STATUS_T;
GOAL_TARGET_PACKED_STRUCT_POST


#define PN_htole16                  GOAL_htole16
#define PN_htole16_p                GOAL_htole16_p
#define PN_htole32                  GOAL_htole32
#define PN_htole32_p                GOAL_htole32_p
#define PN_htole64                  GOAL_htole64
#define PN_htole64_p                GOAL_htole64_p

#define PN_htobe16                  GOAL_htobe16
#define PN_htobe16_p                GOAL_htobe16_p
#define PN_htobe32                  GOAL_htobe32
#define PN_htobe32_p                GOAL_htobe32_p
#define PN_htobe64                  GOAL_htobe64
#define PN_htobe64_p                GOAL_htobe64_p

#define PN_le16toh                  GOAL_le16toh
#define PN_le16toh_p                GOAL_le16toh_p
#define PN_le32toh                  GOAL_le32toh
#define PN_le32toh_p                GOAL_le32toh_p
#define PN_le64toh                  GOAL_le64toh
#define PN_le64toh_p                GOAL_le64toh_p

#define PN_be16toh                  GOAL_be16toh
#define PN_be16toh_p                GOAL_be16toh_p
#define PN_be24toh_p                GOAL_be24toh_p
#define PN_be32toh                  GOAL_be32toh
#define PN_be32toh_p                GOAL_be32toh_p
#define PN_be64toh                  GOAL_be64toh
#define PN_be64toh_p                GOAL_be64toh_p

#define PN_en16toh_p                GOAL_en16toh_p
#define PN_en32toh_p                GOAL_en32toh_p
#define PN_en64toh_p                GOAL_en64toh_p

#define PN_htoen16_p                GOAL_htoen16_p
#define PN_htoen32_p                GOAL_htoen32_p
#define PN_htoen64_p                GOAL_htoen64_p

#define PN_align32                  GOAL_align32

/* logic to align memory pointer at OAL_MEM_ALIGN defines */
#if (GOAL_TARGET_MEM_ALIGN_CPU > GOAL_TARGET_MEM_ALIGN_NET)
#  define PN_ALIGN_PAD GOAL_TARGET_MEM_ALIGN_CPU
#else
#  define PN_ALIGN_PAD GOAL_TARGET_MEM_ALIGN_NET
#endif

#if (PN_ALIGN_PAD < GOAL_TARGET_MEM_ALIGN_CPU) || (PN_ALIGN_PAD < GOAL_TARGET_MEM_ALIGN_NET)
#  error "PN_ALIGN_PAD < OAL_MEM_ALIGN_*"
#endif


#if ((2 != GOAL_TARGET_MEM_ALIGN_CPU) && (4 != GOAL_TARGET_MEM_ALIGN_CPU) && (8 != GOAL_TARGET_MEM_ALIGN_CPU) &&\
    (16 != GOAL_TARGET_MEM_ALIGN_CPU)) ||                                                       \
    ((2 != GOAL_TARGET_MEM_ALIGN_NET) && (4 != GOAL_TARGET_MEM_ALIGN_NET) && (8 != GOAL_TARGET_MEM_ALIGN_NET) &&\
    (16 != GOAL_TARGET_MEM_ALIGN_NET))
#  error "GOAL_TARGET_MEM_ALIGN_CPU or GOAL_TARGET_MEM_ALIGN_NET: only 2, 4, 8 and 16 bit alignment supported"
#endif


#define PN_align_2(ptr, ptrcast)                                                        \
    ((3 == (ptrcast ptr & 3)) ? 3 : (2 - (ptrcast ptr & 3)))

#define PN_align_4(ptr, ptrcast)                                                        \
    ((ptrcast ptr & 3) ? (4 - (ptrcast ptr & 3)) : 0)

#define PN_align_8(ptr, ptrcast)                                                        \
    ((ptrcast ptr & 7) ? (8 - (ptrcast ptr & 7)) : 0)

#define PN_align_16(ptr, ptrcast)                                                       \
    ((ptrcast ptr & 15) ? (16 - (ptrcast ptr & 15)) : 0)

#define PN_alignPtr(align, ptr)                                                         \
    (void *) ((PtrCast) ptr + (                                                         \
        (2 == align) ? PN_align_2(ptr, (PtrCast)) : (                                   \
        (4 == align) ? PN_align_4(ptr, (PtrCast)) : (                                   \
        (8 == align) ? PN_align_8(ptr, (PtrCast)) :                                     \
                       PN_align_16(ptr, (PtrCast))))))

#define PN_alignInt(align, val)                                                         \
    (val + ((2 == align) ? PN_align_2(val, ) : (                                        \
            (4 == align) ? PN_align_4(val, ) : (                                        \
            (8 == align) ? PN_align_8(val, ) :                                          \
                           PN_align_16(val, )))))


/* define maximum values */
#define PN_MAX_I16 0x7fff
#define PN_MAX_U16 0xffff
#define PN_MAX_U32 0xffffffff


/* sane convert functions for larger to smaller widths */
#define PN_INT2U16(x)   (((0 < (x)) && (PN_MAX_I16 >= (x))) ? (Unsigned16) (x) : 0)
#define PN_UINT2I16(x)  (((0 < (x)) && (PN_MAX_I16 >= (x))) ? (Integer16)  (x) : 0)
#define PN_UINT2U16(x)  (((0 < (x)) && (PN_MAX_U16 >= (x))) ? (Unsigned16) (x) : 0)
#define PN_UINT2U32(x)  (((0 < (x)) && (PN_MAX_U32 >= (x))) ? (Unsigned32) (x) : 0)


/* set and clear bit macros
 * explanation: the C standard converts unsigned char operands to integers,
 * thats why the casting is necessary - otherwise for example IAR will give you
 * the warning:
 *     Remark[Pa091]: operator operates on value promoted to int (with possibly
 *     unexpected result)
 */
#define PN_bitSet(x, y)     x |= (1 << y)
#define PN_bitClear(x, y)   x &= ~(unsigned int) (1 << y)
#define PN_bitToggle(x, y)  x ^= (1 << x)
#define PN_maskSet(x, y)    x |= y
#define PN_maskClear(x, y)  x &= ~(unsigned int) y
#define PN_maskToggle(x, y) x ^= y


/* verify type widths at compile time */
GOAL_CASSERT(1 == sizeof(Integer8));
GOAL_CASSERT(1 == sizeof(Unsigned8));
GOAL_CASSERT(2 == sizeof(Integer16));
GOAL_CASSERT(2 == sizeof(Unsigned16));
GOAL_CASSERT(4 == sizeof(Integer32));
GOAL_CASSERT(4 == sizeof(Unsigned32));
GOAL_CASSERT(8 == sizeof(Integer64));
GOAL_CASSERT(8 == sizeof(Unsigned64));


#endif /* PN_TYPES_INDEP_H */
