/** @file
 *
 * @brief
 * PROFINET User API for PROFINET IO Device Stack
 *
 * @details
 * This file contains function declarations for all stack functions which are
 * usable by the user. All functions start with IOD_. The function defintions
 * are located in the corresponding stack module.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_USER_H_
#define PN_USER_H_

#include <pn_frames.h>


/** Get Cyclic Output Data
 *
 * This function reads cyclic output data of IO Data Object identified by API
 * \c api, Slot \c slotNr and SubSlot \c subSlotNr.  \c length number of bytes
 * is read from cyclic data buffer and written to the buffer \c pValue. For
 * this the buffer \c pValue should have a minimum size of \c length.
 * Additionally the IO Provider Status is returned in \c pIoPS.
 *
 * Reading of Output data is only allowed if an IO Data Object was created
 * before for this API/Slot/SubSlot. This is usually done by the PROFINET IO
 * Stack when receiving Connect frame from IO Controller.This function can
 * only be used to read IO Data Objects which are configured inside an Output
 * Communication Relationship (IOCR type).
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_GetOutputData(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< Application process number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr,                       /**< SubSlot number */
    Unsigned8 *pValue,                          /**< buffer to return IO data */
    Unsigned16 length,                          /**< number of bytes to read */
    Unsigned8 *pIoPS                            /**< pointer to return IOPS */
);


/** Set Cyclic Input Data
 *
 * This function sets cyclic input data of IO Data Object identified by API \c
 * api, Slot \c slotNr and SubSlot \c subSlotNr. The data to be set is given in
 * \c pValue buffer with length \c length. Additionally the IO Provider Status
 * has to be set in \c ioPS.
 *
 * Setting of Input data is only allowed if an IO Data Object was created
 * before for this API/Slot/SubSlot. This is usually done by the PROFINET IO
 * Stack when receiving Connect frame from IO Controller. This function can
 * only be used to set IO Data Objects which are configured inside an Input
 * Communication Relationship (IOCR type).
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_SetInputData(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< Application process number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr,                       /**< SubSlot number */
    const Unsigned8 *pValue,                    /**< pointer to data to set */
    Unsigned16 length,                          /**< size of data to set */
    Unsigned8 ioPS                              /**< IOPS to set */
);


/** Get Cyclic Input Data (Debug-Function)
 *
 * This function reads cyclic input data of IO Data Object identified by API \c
 * api, Slot \c slotNr and SubSlot \c subSlotNr. The data to be read is written
 * to \c pValue buffer with length \c length. If the buffer size is smaller
 * than the input data, an error is returned. The IO Provider Status is written
 * to \c pioPS.
 *
 * Reading of Input data is only allowed if an IO Data Object was created
 * before for this API/Slot/SubSlot. This is usually done by the PROFINET IO
 * Stack when receiving Connect frame from IO Controller. This function can
 * only be used to read IO Data Objects which are configured inside an Input
 * Communication Relationship (IOCR type).
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_GetInputData(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< Application process number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr,                       /**< SubSlot number */
    Unsigned8 *pValue,                          /**< pointer of data buffer */
    Unsigned16 length,                          /**< size of data buffer */
    Unsigned8 *pIoPS                            /**< IOPS store pointer */
);


/** Pull Module (with Submodules) from a given Slot
 *
 * Pull module with all attached submodules out of a given slot and send an
 * alarm to the controller if a connection is established.
 *
 * @retval PN_OK successful
 * @retval other failed
 */
RET_T IOD_pullModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slotNr                           /**< Slot number */
);


/** Pull a Submodule from a given Subslot
 *
 * Pull a single submodule out of a given slot/subslot combination and send an
 * alarm to the controller if a connection is established.
 *
 * @retval PN_OK successful
 * @retval other failed
 */
RET_T IOD_pullSubModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr                        /**< Subslot number */
);


/** Plug a Module into a given Slot
 *
 * Plug a module into a given slot, but don't send an alarm.
 *
 * @retval PN_OK successful
 * @retval other failed
 */
RET_T IOD_plugModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned32 moduleIdentNr                    /**< Module ident number */
);


/** Plug a Submodule into a given Subslot
 *
 * Plug a submodule into a given slot/subslot combination and send an alarm if
 * a connection is established.
 *
 * @retval PN_OK successful
 * @retval other failed
 */
RET_T IOD_plugSubModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr,                       /**< Subslot number */
    Unsigned32 moduleIdentNr,                   /**< Module ident nr */
    Unsigned32 subModuleIdentNr,                /**< Submodule ident nr */
    Unsigned16 *pSubModulePlugHandle            /**< Submodule plug handle */
);


/** PROFINET IO Stack Shutdown
 *
 * Shutdown the components of the Profinet stack.
 */
void IOD_shutdown(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);


/** PROFINET IO Stack Init Check
 *
 * Returns if the stack has been started.
 *
 * @retval PN_TRUE  stack has been started
 * @retval PN_FALSE stack was not started yet
 */
PN_BOOL_T IOD_isStackInitialized(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);


/** Send Application Ready
 *
 * This function sends an application ready frame to IO Controller. The frame
 * is send as control service via RPC.
 *
 * The user has to provide the application relationship reference to identify
 * the application relationship the application relationship command belongs
 * to. Application relationship reference is provided in parameter end
 * callback.
 *
 * Info: Normally there is no need to call this function because the stack
 * automatically sends the application ready message.
 *
 * @retval PN_OK successful
 * @retval other failed
 */
RET_T IOD_sendApplReady(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< Application relationship reference */
    Unsigned16 type,                            /**< type of message (0 = normal, 1 = plug) */
    Unsigned16 plugHandle                       /**< handle from plug request */
);


/** Set Input IOPS to Subslot Path
 *
 * Set input IOPS to subslot path.
 *
 * @retval IOD_OK ok
 * @retval other fail
 */
IOD_STATUS_T PN_ioSetIops(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned8 value                             /**< value */
);


/** Get Output IOPS from Subslot Path
 *
 * Set output IOPS from subslot path.
 *
 * @retval IOD_OK ok
 * @retval other fail
 */
IOD_STATUS_T PN_ioGetIops(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned8 *pValue                           /**< value ref */
);


/** Set Output IOCS to Subslot Path
 *
 * Set output IOCS to subslot path.
 *
 * @retval IOD_OK ok
 * @retval other fail
 */
IOD_STATUS_T PN_ioSetIocs(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned8 value                             /**< value */
);


/** Get Input IOCS from Subslot Path
 *
 * Set input IOCS from subslot path.
 *
 * @retval IOD_OK ok
 * @retval other fail
 */
IOD_STATUS_T PN_ioGetIocs(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned8 *pValue                           /**< value ref */
);


/****************************************************************************/
/** LLDP Set System Description
 *
 * Set the LLDP system description.
 */
GOAL_STATUS_T PN_lldpLocSystemDescSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *pSysDesc,                       /**< system description */
    uint32_t len                                /**< description length */
);


/****************************************************************************/
/** LLDP Set System Name
 *
 * Set the LLDP system name - IEE 802.1AB ASE - system name.
 */
PN_STATUS_T PN_lldpSetSystemName(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *strSysName,                     /**< system name */
    unsigned int len                            /**< system name length */
);


/** LLDP Set Port Description
 *
 * Set the LLDP port description.
 */
GOAL_STATUS_T PN_lldpLocPortDescSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *portDesc,                       /**< port description */
    uint32_t len                                /**< descriptor length */
);


/** Create a new application process.
 *
 * Creates the first access level to the devices structures, the application
 * process (AP).
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_devNewAP(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 apNr                             /**< API number */
);


/** Create a slot in an AP.
 *
 * Creates a slot which is assigned to the APs slot list. If the genFlag is set
 * to AUTO_GEN and the AP apNr doesn't exist, is is created automatically.
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_devNewSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 apNr,                            /**< AP number */
    Unsigned16 slotNr,                          /**< Slot number */
    DEV_GEN_FLAG_T genFlag                      /**< auto-gen flag */
);


/** Create a subslot in a slot.
 *
 * Creates a subslot which is assigned to the slots subslot list. If the
 * genFlag is set to AUTO_GEN and the slot slotNr doesn't exist, it is created
 * automatically.
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_devNewSubSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 apNr,                            /**< AP number */
    Unsigned16 slotNr,                          /**< slot number */
    Unsigned16 subSlotNr,                       /**< subslot number */
    DEV_GEN_FLAG_T genFlag                      /**< auto-gen flag */
);


/** Create a module in the module list.
 *
 * Creates a module in the global module list.
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_devNewModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 id                               /**< module id */
);


/** Create a submodule in a submodulelist.
 *
 * Creates a submodule which is assigned to the modules submodule list. If the
 * genFlag is set to AUTO_GET and the module modId doesn't exist, it is created
 * automatically.
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
IOD_STATUS_T IOD_devNewSubModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 modId,                           /**< module id */
    Unsigned32 subModId,                        /**< submodule id */
    DATA_DIR_T dataDir,                         /**< data direction */
    Unsigned16 inLen,                           /**< input length */
    Unsigned16 outLen,                          /**< output length */
    DEV_GEN_FLAG_T genFlag                      /**< auto-gen flag */
);


/** Set Vendor ID
 *
 * Set the vendor ID.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetVendorId(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 vendorId                         /**< vendor ID */
);


/** Set Device ID
 *
 * Set the device ID.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetDeviceId(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 deviceId                         /**< device ID */
);


/** Set Hardware Revision
 *
 * Set the hardware revision.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetHwRev(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 hwRev                            /**< hardware revision */
);


/** Set Software Revision
 *
 * Set the software revision.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetSwRev(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    char prefix,                                /**< prefix */
    Unsigned8 funcEnh,                          /**< functional enhancement */
    Unsigned8 bugfix,                           /**< bugfix */
    Unsigned8 intChange,                        /**< internal change */
    Unsigned16 revCnt                           /**< revision counter */
);


/** Set Profile ID
 *
 * Set the profile ID.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetProfileId(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 profileId,                       /**< profile ID */
    Unsigned16 specType                         /**< profile specific type */
);


/** Set Order ID
 *
 * Set the order ID.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetOrderId(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *pOrderId,                       /**< order ID */
    unsigned int len                            /**< order ID len */
);


/** Set Serial Nr
 *
 * Set the serial nr.
 *
 * @retval IOD_STATUS_T status
 */
IOD_STATUS_T PN_devSetSerialNr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *pSerialNr,                      /**< serial nr */
    unsigned int len                            /**< serial nr len */
);


/****************************************************************************/
/** LLDP Set Message TX Interval
 *
 * @returns PN_STATUS_T result
 */
PN_STATUS_T PN_lldpSetTxInterval(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 valTxInterval                    /**< LLDP TX Interval */
);


/****************************************************************************/
/** LLDP Set Message TX Hold Multiplier
 *
 * @returns PN_STATUS_T result
 */
PN_STATUS_T PN_lldpSetTxHoldMult(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 valTxHoldMult                    /**< LLDP TX Hold Multiplier */
);


#endif /* PN_USER_H_ */
