/** @file
 *
 * @brief
 * PROFINET Unified OAL API
 *
 * @details
 * This header defines function prototypes for the OAL module.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_OAL_API_H
#define PN_OAL_API_H

#include <pn_oal.h>


/* types */
typedef struct {
    uint32_t      localIp;                      /**< local IP address */
    uint16_t      localPort;                    /**< local port number */
    uint32_t      remoteIp;                     /**< remote IP address */
    uint16_t      remotePort;                   /**< remote port number */
} OAL_UDP_ADDR_T;

typedef void (*OAL_UDP_RECV_CB_T)(
    int             chan,                       /**< channel descriptor */
    OAL_UDP_ADDR_T  *pAddr,                     /**< connection data */
    void            *buf,                       /**< buffer */
    unsigned int    bufLen                      /**< buffer length */
);


/** OAL Initialization - Init Stage
 *
 * This function initializes the OAL and provides unified interfaces to the
 * PROFINET stack.
 *
 * @retval IOD_OK - success
 * @retval other - failed
 */
IOD_STATUS_T OAL_init(
    void
);


/** Global Stack Halt Function
 *
 * This functions makes it easier to focus on one breakpoint while debugging.
 * See the stack for details of the caller.
 */
GOAL_TARGET_NORETURN_PRE void OAL_halt(
    void
) GOAL_TARGET_NORETURN;


/** Shutdown the OAL module
 *
 * Should do all necessary steps to shutdown the OAL - on some architectures,
 * this halts the device.
 */
void OAL_shutdown(
    void
);


/** Read MAC address from Interface
 *
 * The MAC address buffer macAddr needs to have at least MAC_ADDR_LEN bytes.
 *
 * @retval IOD_OK - successful
 * @retval other - failed
 */
IOD_STATUS_T OAL_getMacAddr(
    unsigned int portIdx,                       /**< port index */
    char *pMacAddr                              /**< buffer to store MAC addr */
);


/** Open an UDP Channel
 *
 * Open an UDP channel on the specified port.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_udpOpen(
    int *pSockIdx,                              /**< pointer to store socket index */
    Unsigned16 port,                            /**< UDP port number */
    GOAL_NET_CB_T callback                      /**< receive callback */
);


/** Close an UDP Channel
 *
 * Close the specified UDP channel handle.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_udpClose(
    int *pConn                                  /**< UDP channel handle */
);


/** Reopen an UDP Channel
 *
 * Reopen an UDP channel on the specified port.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_udpReopen(
    void
);


/** Send Data over UDP Channel
 *
 * Send data in pBuf with bufLen size over the UDP channel to the destination
 * address given in pDA.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_udpSend(
    int                 chan,                   /**< connection handle */
    OAL_UDP_ADDR_T     *pAddr,                  /**< UDP address */
    Unsigned8          *pBuf,                   /**< send buffer */
    Unsigned16          bufLen                  /**< send buffer size */
);


/** Generic Ethernet Send Function for PROFINET Buffers
 *
 * This function is called when an Ethernet frame that is embedded in a
 * PROFINET buffer is ready to send.
 */
IOD_STATUS_T OAL_ethSendAndRelease(
    void **ppOAL,                               /**< pointer to PROFINET buffer */
    PN_NET_TX_TYPE_T type                       /**< frame channel type */
);


/** Read the Ethernet Medium Attachment Unit Status
 *
 * Returns the set or detected MAU type like 100BASETXFD.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_ethMAUType(
    unsigned int portIdx,                       /**< interface index */
    Unsigned16 *pMAUType                        /**< pointer to store MAU type */
);


/** Read the Ethernet Port State
 *
 * Returns if the interface is up or down.
 *
 * See specification 6.2.12.16 Coding of the field LinkState.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_ethPortState(
    unsigned int portIdx,                       /**< interface index */
    Unsigned16 *pPortState                      /**< pointer to store port state */
);


/** Set the Ethernet Port State
 *
 * Set the given Ethernet port to a given link state.
 * If setFlag isn't set to PN_TRUE the default state must be resetted.
 *
 * @returns IOD_OK - success
 * @returns IOD_NOT_SUPPORTED - unsupported or failed
 */
IOD_STATUS_T OAL_ethPortStateSet(
    unsigned int portIdx,                       /**< interface index */
    Unsigned16 portState,                       /**< port state */
    PN_BOOL_T setFlag                           /**< set flag */
);


/** Set the Ethernet Medium Attachment Unit Status
 *
 * Sets the MAU type like 100BASETXFD.
 * If setFlag isn't set to PN_TRUE the default state must be resetted.
 *
 * @returns IOD_OK - success
 * @returns IOD_NOT_SUPPORTED - unsupported or failed
 */
IOD_STATUS_T OAL_ethMAUTypeSet(
    unsigned int portIdx,                       /**< interface index */
    Unsigned16 mauType,                         /**< MAU type */
    PN_BOOL_T setFlag                           /**< set flag */
);


/** Init Timer
 *
 * Initializes the OAL timer management.
 *
 * @returns IOD_OK - success
 * @returns IOD_TIMER_INIT_FAILED - error initializing timers
 */
IOD_STATUS_T OAL_timerInit(
    void
);


/** Create Timer
 *
 * Creates a timer with the given priority.
 *
 * @returns IOD_OK - success
 * @returns IOD_TIMER_CREATE_FAILED - error creating timer
 */
IOD_STATUS_T OAL_timerCreate(
    PN_TIMER_T **ppTmr,                         /**< timer */
    PN_TIMER_PRIO_T prio                        /**< PN_TIMER_PRIO_LOW, PN_TIMER_PRIO_HIGH */
);


/** Setup Timer
 *
 * Setup a timer.
 *
 * @returns IOD_OK - success
 * @returns IOD_TIMER_SETUP_FAILED - error setting up timer
 */
IOD_STATUS_T OAL_timerSetup(
    PN_TIMER_T *pTmr,                           /**< timer */
    PN_TIMER_TYPE_T type,                       /**< timer type: single or periodic */
    Unsigned32 period                           /**< period in ms after which timer is triggered */
);


/** Start Timer
 *
 * Start a timer.
 *
 * @returns IOD_OK - success
 * @returns IOD_TIMER_START_FAILED - error starting timer
 */
IOD_STATUS_T OAL_timerStart(
    PN_TIMER_T *pTmr                            /**< timer */
);


/** Stop Timer
 *
 * Stop a timer.
 *
 * @returns IOD_OK - success
 * @returns other - fail
 */
IOD_STATUS_T OAL_timerStop(
    PN_TIMER_T *pTmr                            /**< timer */
);


/** Add multicast address to device
 *
 * Configure the forwarding of a specific multicast address. If extFlag is set,
 * Multicast is configured to be forwarded on all external ports and to the
 * internal port, otherwise only the internal port sees the frames.
 */
IOD_STATUS_T OAL_ethMulticastAdd(
    PN_BOOL_T extFlag,                          /**< external ports flag */
    char *pMcAddr                               /**< multicast address */
);


/** Remove multicast address from device
 *
 * Remove a configured multicast address.
 */
IOD_STATUS_T OAL_ethMulticastDel(
    char *pMcAddr                               /**< multicast address */
);


#endif /* PN_OAL_API_H */
