/** @file
 *
 * @brief
 * PROFINET Version Header
 *
 * @details
 * Defines the current version information of the PROFINET stack.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_VERSION_H
#define PN_VERSION_H

/* Stack version: PN_STACK_VERSION.PN_STACK_SUBVERSION.PN_STACK_PATCH */

#define PN_STACK_VERSION    GOAL_VER_MAJ        /**< version */
#define PN_STACK_SUBVERSION GOAL_VER_MIN        /**< subversion */
#define PN_STACK_PATCH      GOAL_VER_SUB        /**< patch level */
#define PN_STACK_SPECIAL    ""                  /**< special tag (obsolete) */
#define PN_STACK_REV        ""                  /**< revision tag (obsolete) */

#define PN_CT_PNIO_STD  "V2.4"                  /**< PROFINET Standard */
#define PN_CT_TEST_SPEC "V2.43 February 2022"   /**< PROFINET Test Specification */
#define PN_CT_TESTCASES "Bundle July 2022"      /**< PROFINET Testcases */
#define PN_CT_ART       "V2.43.1.2"             /**< PROFINET ART includes TED Check */
#define PN_CT_SL1_TEST  "V2.43.0.0 V1.0"        /**< PROFINET SL1 Test */
#define PN_CT_PNIO      "2.4"                   /**< PROFINET Version */
#define PN_CT_GSD       "2.43"                  /**< PROFINET GSDML Version */

#endif /* PN_VERSION_H */
