/** @file
 *
 * @brief
 * PROFINET Global Type Definitions
 *
 * @details
 * This file defines types that are used by all Profinet IO Stack modules and
 * by the object dictionary. It defines basic datatypes, endpoint structures
 * and the object dictionary structures (Modules, Slots, API etc.).
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_TYPES_H
#define PN_TYPES_H

#include <pn_includes.h>
#include <pn_rpc_types.h>
#if GOAL_CONFIG_MEDIA_MI_DM == 1
#  include <goal_media/goal_mi_dm.h>
#endif


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define PN_IPV4_ADDR_LEN                  4
#define MAC_ADDR_LEN                      6
#define IFACE_NAME_LEN                    16
#define NVS_NAME_LEN                      255

#define IOD_EPIO_IN                       1
#define IOD_EPIO_OUT                      2
#define IOD_EPALARM                       3

#define IOD_PNIO_PROTO                    1
#define IOD_IP_PROTO                      1

#define PN_LEN_STRTERM                    1

#define PN_LEN_HWREV                      sizeof(Unsigned16)
#define PN_LEN_SWREV_PREFIX               sizeof(Unsigned8)
#define PN_LEN_SWREV_ENH                  sizeof(Unsigned8)
#define PN_LEN_SWREV_BUGFIX               sizeof(Unsigned8)
#define PN_LEN_SWREV_INTCHG               sizeof(Unsigned8)
#define PN_LEN_SWREV_REVCNT               sizeof(Unsigned16)
#define PN_LEN_PROFILE_ID                 sizeof(Unsigned16)
#define PN_LEN_PROFILE_TYPE               sizeof(Unsigned16)
#define PN_LEN_ORDER_ID                   20
#define PN_LEN_SERIAL_NR                  16

#define PN_LEN_IM2                        16
#define PN_LEN_IM2_DASH                   1
#define PN_LEN_IM2_BLANK                  1
#define PN_LEN_IM2_COLON                  1
#define PN_LEN_IM2_YEAR                   4
#define PN_LEN_IM2_MONTH                  2
#define PN_LEN_IM2_DAY                    2
#define PN_LEN_IM2_HOUR                   2
#define PN_LEN_IM2_MINUTE                 2


/* Block types */
#define IOD_BLOCK_ALARM_HIGH              0x0001
#define IOD_BLOCK_ALARM_LOW               0x0002
#define IOD_BLOCK_ACK_HIGH                0x8001
#define IOD_BLOCK_ACK_LOW                 0x8002

#define IOD_MAX_IO_DATA_LEN               1440

#ifndef NULL
#  define NULL                            ((void *) 0)
#endif

#define ARRAY_ELEMENTS(x)                 (sizeof(x) / sizeof(x[0]))

/**! Ethernet Frame Types */
#define ETH_P_PNIO                        0x8892
#define ETH_P_LLDP                        0x88CC
#define ETH_P_VLAN                        0x8100
#define ETH_P_IP                          0x0800
#define ETH_P_ARP                         0x0806


/** Max Callback Data Elements
 *
 * Highest value is used in pn_recdata:RD_processRecWrite
 */
#define IOD_CALLBACK_DATA_MAX             11


/* APDU_Status Defines */
#define PN_APDU_DS_STATE_PRIMARY                (1 << 0)
#define PN_APDU_DS_REDUNDANCY_BCK_NONE_PRIM     (1 << 1)
#define PN_APDU_DS_REDUNDANCY_PRIM_IS_BCK       (1 << 1)
#define PN_APDU_DS_DATAVALID_VALID              (1 << 2)
#define PN_APDU_DS_PROVIDERSTATE_RUN            (1 << 4)
#define PN_APDU_DS_STATION_PROBLEM_INDICATOR    (1 << 5)
#define PN_APDU_DS_IGNORE_DATASTATUS            (1 << 7)


/****************************************************************************/
/* Data Types */
/****************************************************************************/
struct AR_T;                                    /**< AR_T typedef prototype */
struct PN_ALARM_EP_T;                           /**< alarm endpoint */
struct PN_ALARM_NOTIFY_T;                       /**< alarm notification */

typedef Integer16 PN_DIAG_HANDLE_T;             /**< diagnosis handle */
typedef Unsigned8 MACADDR_T[MAC_ADDR_LEN];      /**< MAC address */


/**< Ethernet Header */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    MACADDR_T destMac;                          /**< destination MAC */
    MACADDR_T srcMac;                           /**< source MAC */
    Unsigned16 type_be16;                       /**< EtherType / VLAN TPID */
} GOAL_TARGET_PACKED PN_NET_ETH_HDR_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< VLAN Header */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 tci_be16;                        /**< TCI (PCP, DEI, VID) */
    Unsigned16 type_be16;                       /**< EtherType */
} GOAL_TARGET_PACKED PN_NET_VLAN_HDR_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PROFINET Header */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 frameId_be16;                    /**< PROFINET FrameID */
} GOAL_TARGET_PACKED PN_NET_PNIO_HDR_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< CREP */
typedef struct {
    Unsigned16 crep;                            /**< CREP */
    MACADDR_T remoteMac;                        /**< remote MAC */
    Unsigned32 remoteIP;                        /**< remote IP */
    Unsigned16 vlanID;                          /**< VLAN ID */
    Unsigned16 frameID;                         /**< frame ID */
    Unsigned8 type;                             /**< type */
    Unsigned8 state;                            /**< state */
} IOD_CREP_T;


/*! IO Data Object type */
typedef enum {
    IO_CR_TYPE_NONE,                            /**< No IO CR active */
    IO_CR_TYPE_INPUT,                           /**< IO Data Object */
    IO_CR_TYPE_OUTPUT,                          /**< IO consumer status */
    IO_CR_TYPE_END                              /**< -enum end marker- */
} IO_CR_TYPE_T;


/**< APDU_Status */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 cycleCounter_be16;               /**< CycleCounter */
    Unsigned8 dataStatus;                       /**< DataStatus */
    Unsigned8 transferStatus;                   /**< TransferStatus */
} GOAL_TARGET_PACKED PN_APDU_STATUS_T;
GOAL_TARGET_PACKED_STRUCT_POST


typedef struct
{
    struct AR_T     *pAR;                       /**< pointer to AR_T structure */
    PN_TIMER_T      *pTmr;                      /**< timer */
    PN_LOCK_T       *pMutex;                    /**< lock */

    PN_APDU_STATUS_T apduStatus;                /**< APDUStatus */
    unsigned int    apduStatusOfs;              /**< APDUStatus offset */
    Unsigned16      cycleCounter;               /**< CycleCounter */
    GOAL_BOOL_T     flgCycleRemValid;           /**< remove CycleCounter valid flag */
    uint16_t        valCycleRem;                /**< remote CycleCounter */

    IOD_CREP_T      base;                       /**< communication relation */
    Unsigned32      frameSendOff;               /**< frame send offset */
    Unsigned16      dataLen;                    /**< data length */
    Unsigned16      redRatio;                   /**< reduction ratio */
    Unsigned16      phase;                      /**< phase */
    Unsigned16      sendClkFactor;              /**< send clock factor */
    Unsigned16      dataHoldFactor;             /**< data hold factor */
    Unsigned32      timerVal;                   /**< timer value */

    OAL_BUFFER_T    *pBuf;                      /**< pointer to memory buffer */
    OAL_BUFFER_T    *pBufSubst;                 /**< SubstitutionValue buffer */
    QUEUE_T         *pQueue;                    /**< CRT specific memory queue */
} IO_EP_T;


typedef enum {
    IOD_EP_CLOSED = 0,
    IOD_EP_OPEN,
    IOD_EP_WACK1,
    IOD_EP_WACK2,
    IOD_EP_READY,
    IOD_EP_ACTIVE,
    IOD_EP_TIMEOUT
} IOD_EP_STATE_T;


typedef enum {
    RESP_FILLED,
    RESP_EMPTY,
    RESP_ERROR
} RESP_RET_T;

/*! Data directions */
typedef enum {
    PN_NO_IO,       /*! no direction */
    PN_INPUT,       /*! input */
    PN_OUTPUT,      /*! output */
    PN_IO,          /*! input & output */
    PN_DATA_DIR_END /*! -enum end marker- */
} DATA_DIR_T;

/*! Frame transmit notification events */
typedef enum {
    PN_FRAME_TX,        /*! PNIO frame was submitted for the transmission */
    PN_FRAME_RX         /*! PNIO frame was received */
} FRAME_TX_EVENT_T;

/*! AR state machine states */
typedef enum {
    CMDEV_W_CIND = 0,   /*! initial state (free), waiting for connect request */
    CMDEV_W_PIND,       /*! ConnectReq received, processing WriteReq, waiting for ControlReq ParamEnd */
    CMDEV_W_PIND_IOACT, /*! ConnectReq and 1st WriteReq received -> IOEP active processing WriteReq, waiting for ParamEnd */
    CMDEV_W_ARDY,       /*! ParamEnd received, waiting for ApplReady */
    CMDEV_W_RDYC,       /*! ApplReady sent, waiting for Response */
    CMDEV_DATA,         /*! ApplReadyRes received, New Cyclic Data Indicated */
    CMDEV_ABORT,        /*! AR shall be deleted in main loop */
} CMDEV_STATE_T;

/*! Communication Relationship type */
typedef enum {
    IO_CR,      /*! IO Communication relationship */
    ALARM_CR    /*! Alarm Communication relationship */
} CR_TYPE_T;

/*! Application relationship state */
typedef enum  {
    CR_UNUSED,          /*! CR free to use */
    CR_CONNECTED        /*! CR used */
} CR_STATE_T;

/*! Application Relationship search key */
typedef enum {
    AR_UUID,    /*! UUID of application relationship */
    AR_EPPTR    /*! pointer to the AR endpoint */
} AR_KEY_T;

/*! Application Relationship */
typedef struct AR_T {
    struct PN_INSTANCE_T *pPnio;                            /**< PROFINET instance */

    Integer32       id;                                     /*! internal AR id */
    CMDEV_STATE_T   state;                                  /*! CMDEV state machine state */
    Unsigned16      type;                                   /*! normal/supervisor */
    Unsigned8       arUUID[AR_UUID_SIZE];                   /*! AR identifier from IO Controller */
    Unsigned16      sessionKey;                             /*! session key from IO Controller */
    Unsigned8       cmInitiatorMAC[MAC_ADDR_LEN];           /*! MAC from IO Controller */
    UUID_T          cmInitObjUUID;                          /*! CM Initiator Object UUID */
    Unsigned16      cmInitActToutFact;                      /*! Timeout factor (100ms base) */
    Unsigned16      initiatorUDPport;                       /*! UDP port from IO Controller */
    char            cmInitiatorName[AR_INIT_NAME_SIZE];     /*! name of IO Controller */
    Unsigned16      nameLength;                             /*! length of initiator name */
    struct PN_ALARM_EP_T *pAlarmEP;                         /*! AR related Alarm Endpoint */
    PN_BOOL_T       flgIsRpc;                               /*! AR handles a RPC connection */
    void            *pRemoteSession;                        /*! RPC or RSI session */
    Unsigned16      ioEPCount;                              /*! count of IO endpoints */
    IO_EP_T         **ppIoEP;                               /*! List of communication relationships */
    PN_TIMER_T      *pTmr;                                  /*! timeout timer */
    Unsigned32      properties;                             /*! AR properties */
    PN_BOOL_T       flgAppReady;                            /*! application ready confirmed flag */
    PN_BOOL_T       flgAlarmFreeze;                         /*! freeze alarms state flag */
    Unsigned8       errCode2;                               /*! errCode2 (reason) for alarm */
    int             noAlarm;                                /*! flag to signal if an alarm should be send */
    PN_TIMER_T      *pTmrAppReady;                          /*! application ready sending start timer */
    Unsigned16      appReadyType;                           /*! type of message (0 = normal, 1 = plug) */
    Unsigned16      appReadyPlugHandle;                     /*! handle from plug request */
    PN_BOOL_T       paramEndSync;                           /*! request physical port synchronization after ParamEnd */
} AR_T;

/*! submodule definition */
typedef struct SUBMOD_T {
    struct SUBMOD_T *pNext;                     /**< next submodule */

    uint32_t id;                                /**< submodule id */
    DATA_DIR_T      dataDirection;          /*! data direction (in, out, in/out) */
    Unsigned16      inDataLength;           /*! in data length */
    Unsigned16      outDataLength;          /*! out data length */
} SUBMOD_T;

/**< module definition */
typedef struct MODULE_T {
    struct MODULE_T *pNext;                     /**< next module */

    Unsigned32 id;                              /**< module id */
    unsigned int cntSubmod;                     /**< submodule count */
    SUBMOD_T *pSubmod;                          /**< submodule list */
} MODULE_T;

/*! state of slot */
typedef enum {
     SLOT_NO_MODULE = 0x00,                     /**< module state: no module */
     SLOT_WRONG_MODULE = 0x01,                  /**< module state: wrong module */
     SLOT_PROPER_MODULE = 0x02,                 /**< module state: proper module */
     SLOT_SUBSTITUTE = 0x03,                    /**< module state: substitute */
     SLOT_GOOD,                                 /**< (internal) correct module */

     SLOT_STATE_END                             /**< -enum end marker- */
} SLOT_STATE_T;

/*! state of subSlot */
typedef enum {
     SUB_GOOD = 0x00,                           /**< submodule state: OK */
     SUB_SUBSTITUTE = 0x01,                     /**< submodule state: substitute (SU) */
     SUB_WRONG_SUBMODULE = 0x02,                /**< submodule state: wrong (WR) */
     SUB_NO_SUBMODULE = 0x03,                   /**< submodule state: no submodule (NO) */

     SUB_STATE_END                              /**< -enum end marker- */
} SUBSLOT_STATE_T;

/*! Expected Module/Submodule Indicator */
typedef enum {
    IND_MOD,                            /*! indicator was called for module */
    IND_SUBMOD                          /*! indicator was called for submodule */
} IND_EXPMOD_T;

/*! IO Data Object */
typedef struct {
    IO_CR_TYPE_T        ioCrType;       /*! Type of IO CR (None/Input/Output) */
    IO_EP_T             *pIOEP;         /*! Cyclic data endpoint */
    Unsigned16          frameOffset;    /*! frame offset in cycle data buffer */
} IO_DATA_OBJ_T;


/*! IO CS/PS */
typedef struct {
    Unsigned8           val;                    /**< value */
    Unsigned16          ofs;                    /**< offset */
    IO_EP_T             *pEpIo;                 /**< IO endpoint */
} PN_IO_XS_T;


/**< Subslot */
typedef struct SUBSLOT_T {
    struct SUBSLOT_T *pNext;                    /**< next subslot */

    Unsigned16          number;                 /**< Subslot number */
    SUBMOD_T            *pSubMod;               /**< Pointer to plugged SubModule */
    SUBSLOT_STATE_T     state;                  /**< submod match state */
    SUBSLOT_STATE_T     stateAppl;              /**< application submod match state */
    AR_T                *pAR;                   /**< pointer to AR which uses subSlot */
    IO_DATA_OBJ_T       outDataObj;             /**< IO Data Object */
    IO_DATA_OBJ_T       inDataObj;              /**< IO Data Object */

    PN_IO_XS_T          inIocs;                 /**< input IOCS */
    PN_IO_XS_T          inIops;                 /**< input IOPS */
    PN_IO_XS_T          outIocs;                /**< output IOCS */
    PN_IO_XS_T          outIops;                /**< output IOPS */

    GOAL_LOCK_T *pLock;                         /**< subslot lock */
    uint16_t modeSubst;                         /**< substitution mode */
    uint8_t valSubstIocs;                       /**< substitution IOCS */

#if GOAL_CONFIG_MEDIA_MI_DM == 1
    GOAL_MI_DM_PART_T dmIn;                     /**< input data */
    GOAL_MI_DM_PART_T dmOut;                    /**< output data */
    GOAL_MI_DM_PART_T dmInIocs;                 /**< input IOCS */
    GOAL_MI_DM_PART_T dmOutIocs;                /**< output IOCS */
    GOAL_MI_DM_PART_T dmInIops;                 /**< input IOPS */
    GOAL_MI_DM_PART_T dmOutIops;                /**< output IOPS */
#endif /* GOAL_CONFIG_MEDIA_MI_DM == 1 */
} SUBSLOT_T;


/**< Slot */
typedef struct SLOT_T {
    struct SLOT_T *pNext;                       /**< next slot */

    Unsigned16          number;                 /**< slot number */
    MODULE_T            *pModule;               /**< pointer to plugged module */
    SLOT_STATE_T        state;                  /**< slot state used/unused */
    AR_T                *pAR;                   /**< pointer to AR which uses slot */

    unsigned int cntSubslots;                   /**< subslot count */
    SUBSLOT_T *pSubslots;                       /**< subslot list */
} SLOT_T;


/**< Application process */
typedef struct AP_T {
    struct AP_T *pNext;                         /**< next API */

    Unsigned32 number;                          /**< API number */
    unsigned int cntSlots;                      /**< slot count */
    SLOT_T *pSlots;                             /**< slot list */
} AP_T;


/*! Profinet Stack Version Information */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32 verid1;      /*! id to find version in binary */
    Unsigned32 verid2;      /*! id to find version in binary */
    Unsigned16 version;     /*! major version */
    Unsigned16 subver;      /*! minor version */
    Unsigned16 patch;       /*! patch set */
    char special[32];       /*! special tag */
    char rev[32];           /*! VCS revision */
} GOAL_TARGET_PACKED PNIO_VERSION_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**! Device Configuration Generation Flag */
typedef enum {
    MANU_GEN = 0,           /*! manual generation of device tree */
    AUTO_GEN = 1            /*! create needed structure elements automatically */
} DEV_GEN_FLAG_T;

/**! DCP signal blink states */
typedef enum {
    PN_DCP_BLINK_START,                         /*! start signal */
    PN_DCP_BLINK_TOGGLE,                        /*! toggle signal */
    PN_DCP_BLINK_FINISH                         /*! stop signal */
} PN_DCP_BLINK_STATE_T;


/**! DCP signal light state */
typedef enum {
    PN_DCP_BLINK_OFF = 0,                       /*! light off */
    PN_DCP_BLINK_ON,                            /*! light on */
} PN_DCP_BLINK_LIGHT_T;

/**< internal write information used by different stack modules */
typedef struct {
    PN_BOOL_T      flgLastIndex;                /**< last MultipleWrite index is or was processed */
    Unsigned16     cntMultiWrite;               /**< index counter for MultipleWrite */
    Unsigned16     lenResponse;                 /**< total length of response */
    ERROR_STATUS_T *pFirstResponseStatus;       /**< error status of first write response in response frame */
} PN_WRITE_INFO_T;

/**! Callback Data Content Structure */
typedef union {
    Integer32 i32;          /*! 32-bit signed */

    Unsigned8 *pu8;         /*! 8-bit unsigned pointer */
    Unsigned16 *pu16;       /*! 16-bit unsigned pointer */
    Unsigned32 *pu32;       /*! 32-bit unsigned pointer */
    const Unsigned8 *pcu8;  /*! const 8-bit unsigned pointer */
    const Unsigned16 *pcu16; /*! const 16-bit unsigned pointer */
    const Unsigned32 *pcu32; /*! const 32-bit unsigned pointer */
    const Unsigned64 *pcu64; /*! const 64-bit unsigned pointer */

    Unsigned16 u16;         /*! 16-bit unsigned */
    Unsigned32 u32;         /*! 32-bit unsigned */

    PN_BOOL_T boolVal;      /*! true or false */

    AR_T *pAR;              /*! application relation pointer */
    IO_CR_TYPE_T ioCrType;  /*! IO CR type */
    const IO_EP_T *pIoEp;   /*! IO endpoint pointer */
    const IOD_CREP_T *pIoCrEp;  /*! IO CR endpoint pointer */
    IND_EXPMOD_T expMod;    /*! expected module selection */
    FRAME_TX_EVENT_T frTxEv;/*! frame TX event */
    ERROR_STATUS_T *pErrStat;   /*! error status pointer */
    struct PN_ALARM_NOTIFY_T *pAlarmNotify;     /*! alarm notification */
    struct PN_ALARM_NOTIFY_ACK_T *pAlarmNotifyAck; /*! alarm notification */
    PN_DCP_BLINK_STATE_T dcpBlinkState;         /*! DCP blink state */
    PN_DCP_BLINK_LIGHT_T dcpBlinkLight;         /*! DCP light on/off */
} IOD_CALLBACK_DATA_T;


/**! Callback Data Structure */
typedef struct {
    IOD_CALLBACK_DATA_T data[IOD_CALLBACK_DATA_MAX];    /*! callback data */
} IOD_CALLBACK_T;


/**< Callback IDs */
typedef enum {
    IOD_CB_ALARM_ACK_TIMEOUT = 0,               /**< alarm ACK timeout (APMS) */
    IOD_CB_ALARM_NOTIFY_ACK = 1,                /**< alarm notification ACK (ALPMI) */
    IOD_CB_ALARM_NOTIFY = 2,                    /**< alarm notification (ALPMR) */
    IOD_CB_APPL_READY = 3,                      /**< application ready indication */
    IOD_CB_BLINK = 4,                           /**< blink indication */
    IOD_CB_CONNECT_FINISH = 5,                  /**< connect finish indicator */
    IOD_CB_CONNECT_REQUEST = 6,                 /**< connect request indicator */
    IOD_CB_CONNECT_REQUEST_EXP_START = 7,       /**< expected submodule block start indicator */
    IOD_CB_END_OF_PARAM = 8,                    /**< end of param indication */
    IOD_CB_END_OF_PARAM_PLUG = 9,               /**< plug end of param indication */
    IOD_CB_EXP_SUBMOD = 10,                     /**< expected module/submodule indication */
    IOD_CB_FACTORY_RESET = 11,                  /**< factory reset indication */
    IOD_CB_FRAME_TRANSMIT = 12,                 /**< frame transmission indicator */
    IOD_CB_IO_DATA_TIMEOUT = 13,                /**< IO data timeout indication */
    IOD_CB_NET_IP_SET = 14,                     /**< IP configuration update */
    IOD_CB_NEW_AR = 15,                         /**< new AR indication */
    IOD_CB_NEW_IO_CR = 16,                      /**< new IO CR indication */
    IOD_CB_NEW_IO_DATA = 17,                    /**< new IO data indication */
    IOD_CB_NEW_IO_DATA_OBJ = 18,                /**< new IO data object indication */
    IOD_CB_PLUG_READY = 19,                     /**< plug ready indication */
    IOD_CB_READ_RECORD = 20,                    /**< read record indication */
    IOD_CB_RELEASE_AR = 21,                     /**< release AR indication */
    IOD_CB_RESET_TO_FACTORY = 22,               /**< reset to factory indication */
    IOD_CB_STATION_NAME = 23,                   /**< name of station changed */
    IOD_CB_WRITE_RECORD = 24,                   /**< write record indication */
    IOD_CB_INIT = 25,                           /**< PROFINET stack initialized */
    IOD_CB_LLDP_UPDATE = 26,                    /**< Received new LLDP data */
    IOD_CB_CONNECT_REQUEST_EXP_FINISH = 27,     /**< ExpectedSubmoduleBlock processed indicator */
    IOD_CB_STATION_NAME_VERIFY = 28,            /**< DCP Station Name Verification */
    IOD_CB_NET_IP_SET_VERIFY = 29,              /**< DCP Net IP Set Verification */

    IOD_CB_ID_MAX,                              /**< maximum callback ID number */
} IOD_CALLBACK_ID_T;

/**! Callback Structure */
typedef struct {
    PN_BOOL_T cbFlg;                                    /*! callback flg */
    IOD_CALLBACK_DATA_T data[IOD_CALLBACK_DATA_MAX];    /*! callback data */
    IOD_CALLBACK_ID_T cbId;                             /*! callback ID */
} IOD_USER_CALLBACK_T;

/**! Callback Function Define */
typedef IOD_STATUS_T (* PNA_CALLBACK_FUNC)(struct PN_INSTANCE_T *, IOD_CALLBACK_ID_T, IOD_CALLBACK_T *);

/**! LED events */
#define PN_LED_SIGNAL   (1 << 0)                /**< signal/blink */
#define PN_LED_CONN     (1 << 1)                /**< cyclic connection running */


/****************************************************************************/
/* External Variables */
/****************************************************************************/
extern UUID_T            null_id;               /**< UUID with all elements set to zero */


/* Priority defines for PROFINET stack threads
 * (If not defined in OAL.)
 *
 * These defines need to be adapted to the target platform. When using a
 * platform which doesn't support priorities or threads, just leave them
 * defined as they are or set them to one.
 *
 * Please set the priority as the threads are listed here. First listed thread
 * should have the highest priority in the system.
 *
 * OAL_THREAD_PRIO_TIMER   - timer thread (also sends out RT frames)
 * OAL_THREAD_PRIO_RT_RX   - LMPM realtime frame receive thread
 * OAL_THREAD_PRIO_RPC_RX  - RPC server thread
 * OAL_THREAD_PRIO_RPC_TX  - RPC responder thread
 * OAL_THREAD_PRIO_LLDP_RX - LLDP receive thread for neighborhood detection
 * OAL_THREAD_PRIO_MAIN    - main thread (main loop, user application)
 *
 * We only compare one priority and assume that if this is not set, all aren't
 * set.
 */
#ifndef OAL_THREAD_PRIO_TIMER
#  define OAL_THREAD_PRIO_TIMER   1
#  define OAL_THREAD_PRIO_RT_RX   1
#  define OAL_THREAD_PRIO_RPC_RX  1
#  define OAL_THREAD_PRIO_RPC_TX  1
#  define OAL_THREAD_PRIO_LLDP_RX 1
#  define OAL_THREAD_PRIO_MAIN    1
#endif


#endif
