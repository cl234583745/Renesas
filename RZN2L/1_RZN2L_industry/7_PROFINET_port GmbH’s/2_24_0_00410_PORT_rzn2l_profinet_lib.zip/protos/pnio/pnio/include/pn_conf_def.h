/** @file
 *
 * @brief
 * PROFINET Default Define Settings
 *
 * @details
 * Default values for undefined defines.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_CONF_DEF_H
#define PN_CONF_DEF_H


/****************************************************************************/
/* GOAL */
/****************************************************************************/
/* check global PROFINET define */
#ifndef PORT_GMBH_PROFINET_DEVICE_STACK
#  error "PORT_GMBH_PROFINET_DEVICE_STACK define not set"
#endif


/****************************************************************************/
/* Configuration */
/****************************************************************************/
#ifndef CONFIG_DEBUG_SOFTSCOPE
#  define CONFIG_DEBUG_SOFTSCOPE 0
#endif


/****************************************************************************/
/* Logging */
/****************************************************************************/
#ifndef CONFIG_LOGGING_TARGET_RAW
#  define CONFIG_LOGGING_TARGET_RAW 0
#endif

#ifndef CONFIG_LOGGING_DETAIL_MODULES
#  define CONFIG_LOGGING_DETAIL_MODULES 0
#endif

#ifndef CONFIG_LOGGING_DETAIL_SYSINFO
#  define CONFIG_LOGGING_DETAIL_SYSINFO 0
#endif

#if GOAL_CONFIG_LOGGING == 1
#  define CONFIG_LOGGING 1
#endif

#ifndef CONFIG_LOGGING
#  define CONFIG_LOGGING 0
#endif

#ifndef CONFIG_LOGGING_NAME_RESOLVER
#  define CONFIG_LOGGING_NAME_RESOLVER 1
#endif

#ifndef CONFIG_LOGGING_DETAIL_DCP_OPT
#  define CONFIG_LOGGING_DETAIL_DCP_OPT 0
#endif


#endif /* PN_CONF_DEF_H */
