/** @file
 *
 * @brief
 * PROFINET Common Include File
 *
 * @details
 * This file collects all necessary header files for the stack.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_INCLUDES_H
#define PN_INCLUDES_H

/* enable calling from cpp */
#ifdef __cplusplus
extern "C" {
#endif


/****************************************************************************/
/* Configuration */
/****************************************************************************/
#ifndef GOAL_CONFIG_MRP
#  define GOAL_CONFIG_MRP 0
#endif


/****************************************************************************/
/* Global Instance */
/****************************************************************************/
struct PN_INSTANCE_T;                           /**< PROFINET instance */


/* standard libraries */
#include <string.h>

/* GOAL includes */
#include <goal_includes.h>

/* configuration and default define values */
#include <pn_conf_def.h>

/* independent types */
#include <pn_types_indep.h>
#include <pn_status.h>


/* softscope includes */
#if CONFIG_DEBUG_SOFTSCOPE == 1
#  include "ssc.h"
#else
#  define TRACE(x, v)
#  define TRACE_IMP(x)
#  define TRACE_INC(x)
#  define TRACE_DEC(x)
#endif

/* LLDP includes */
#include <goal_lldp.h>

/* SNMP includes */
#if GOAL_CONFIG_SNMP == 1
#  include <goal_lldp_snmp.h>
#  include <goal_snmp.h>
#endif

/* stack includes */
#include <pn_def.h>
#include <pn_oal.h>
#include <goal_pnio_firewall.h>
#include <pn_oal_api.h>
#include <pn_types.h>
#include <pn_version.h>
#include <pn_frames.h>
#include <pn_fsu.h>
#include <pn_pdev.h>
#include <pn_goal_cm.h>
#include <pn_context.h>
#include <pn_lmpm.h>
#include <pn_lldp.h>
#include <pn_snmp.h>
#include <pn_alarm.h>
#include <pn_crtdata.h>
#include <pn_dcp.h>
#include <pn_ar.h>
#include <pn_utils.h>
#include <pn_user.h>
#include <pn_diag.h>
#include <pn_recdata.h>
#include <pn_recdata_diag.h>
#include <pn_recdata_log.h>
#include <pn_rpc.h>
#include <pn_rpc_types.h>
#include <pn_iodata.h>
#include <pn_user.h>
#include <pn_log_resolv.h>
#include <pn_log_sysinfo.h>
#include <pn_log_stack.h>
#include <pn_device.h>
#include <pn_net.h>
#include <pn_stat.h>
#include <pn_goal.h>
#include <goal_pnio.h>

/* PROFIenergy includes */
#if GOAL_CONFIG_MRP == 1
#  include <protos/goal_mrp/goal_mrp.h>
#endif


/****************************************************************************/
/* Instance defines */
/****************************************************************************/
#define PN_LEN_VENDOR 255                       /**< Vendor name length */
#define PN_LEN_PORT LLDP_PORT_DESC_LEN          /**< Port description length */
#define PN_LEN_SYSDESC LLDP_SYS_NAME_LEN        /**< System description name */
#define PN_LEN_ORDERID (20 + 1)                 /**< Order Id length */
#define PN_LEN_SERIAL (16 + 1)                  /**< Serial length */
#define PN_LEN_IM1TAG (32 + 1)                  /**< IM1 Tag function length */
#define PN_LEN_IM1LOC (22 + 1)                  /**< IM1 Location length */
#define PN_LEN_IM2DATE (16 + 1)                 /**< IM2 Date length */
#define PN_LEN_IM3DESC (54 + 1)                 /**< IM3 Description length */
#define PN_LEN_IM4SIG (54 + 1)                  /**< IM4 Signature length */


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
/**< instance configuration */
typedef struct PN_INSTANCE_CFG_T {
    PN_BOOL_T flgDcpFactoryResetDisable;        /**< CONFIG_DCP_DISABLE_FACTORY_RESET */
    PN_BOOL_T flgDcpAcceptMixcaseStation;       /**< CONFIG_DCP_ACCEPT_MIXCASE_STATION */
    uint16_t idVendor;                          /**< DEVICE_VENDORID */
    uint16_t idDevice;                          /**< DEVICE_DEVICEID */
    char strVendor[PN_LEN_VENDOR];              /**< DEVICE_VENDOR_NAME */
    char strDescPort[PN_LEN_PORT];              /**< DEVICE_PORT_DESC */
    char strSystem[PN_LEN_SYSDESC];             /**< DEVICE_SYSTEM_DESC */
    char strIdOrder[PN_LEN_ORDERID];            /**< DEVICE_ORDERID */
    char strNumSerial[PN_LEN_SERIAL];           /**< DEVICE_SERIALNUM */
    uint16_t idRevHw;                           /**< DEVICE_HWREV */
    char chrRevSwPrefix;                        /**< DEVICE_SWREV_PREFIX */
    uint8_t idRevSwFuncEnh;                     /**< DEVICE_SWREV_FUNCENH */
    uint8_t idRevSwBugfix;                      /**< DEVICE_SWREV_BUGFIX */
    uint8_t idRevSwIntChg;                      /**< DEVICE_SWREV_INTCHG */
    uint16_t idRevSwRevCnt;                     /**< DEVICE_SWREV_REVCNT */
    char strIm1TagFunc[PN_LEN_IM1TAG];          /**< DEVICE_IM1_TAG_FUNC */
    char strIm1TagLoc[PN_LEN_IM1LOC];           /**< DEVICE_IM1_TAG_LOC */
    char strIm2Date[PN_LEN_IM2DATE];            /**< DEVICE_IM2_DATE */
    char strIm3Desc[PN_LEN_IM3DESC];            /**< DEVICE_IM3_DESCRIPTOR */
    char strIm4Sig[PN_LEN_IM4SIG];              /**< DEVICE_IM4_SIGNATURE */
    PN_BOOL_T flgDevDapSimple;                  /**< DEVICE_DAP_SIMPLE */
    uint32_t idDevDapApi;                       /**< DEVICE_DAP_API */
    uint16_t idDevDapSlot;                      /**< DEVICE_DAP_SLOT */
    uint16_t idDevDapSubslot;                   /**< DEVICE_DAP_SUBSLOT */
    uint32_t idDevDapMod;                       /**< DEVICE_DAP_MOD */
    uint32_t idDevDapSubmod;                    /**< DEVICE_DAP_SUBMOD */
    PN_BOOL_T flgNetLinkSafety;                 /**< CONFIG_NET_LINK_SAFETY */
    PN_BOOL_T flgCbNewIoData;                   /**< CONFIG_NEW_IODATA_CB */
    PN_BOOL_T flgLldpOrgExt;                    /**< LLDP_ORG_EXT */
    PN_BOOL_T flgLldpOptTlv;                    /**< LLDP_OPT_TLV */
    PN_BOOL_T flgLldpGenMac;                    /**< CONFIG_LLDP_GENERATE_MAC */
    PN_BOOL_T flgIm14Support;                   /**< CONFIG_IM_1_4_SUPPORT */
    PN_BOOL_T flgIm14Cb;                        /**< CONFIG_IM_1_4_CALLBACK */
    PN_BOOL_T flgIm0Cb;                         /**< CONFIG_IM_0_CALLBACK */
    PN_BOOL_T flgIm0FilterCb;                   /**< CONFIG_IM_0_FILTER_CALLBACK */
    PN_BOOL_T flgIm4WriteSupport;               /**< CONFIG_IM_4_WRITE_SUPPORT */
    unsigned int cntRecDataBusyBufsize;         /**< CONFIG_RECORD_DATA_BUSY_BUFSIZE */
    unsigned int sizeRpcFragMaxReqLen;          /**< RPC_FRAG_MAX_REQ_LEN */
    PN_BOOL_T flgRpcFragSupport;                /**< RPC_FRAG_SUPPORT */
    unsigned int numRpcSessions;                /**< CONFIG_RPC_NUM_SESSIONS */
    unsigned int numDiagBufMax;                 /**< CONFIG_MAX_DIAGBUFFER_COUNT */
    unsigned int numDiagDataSizeMax;            /**< CONFIG_MAX_DIAG_DATA_SIZE */
    unsigned int numIocrBlocksMax;              /**< CONFIG_MAX_IOCR_BLOCKS_COUNT */
    unsigned int numCrMax;                      /**< CONFIG_MAX_CR_COUNT */
    unsigned int numArMax;                      /**< CONFIG_MAX_AR_COUNT */
    unsigned int numApiMax;                     /**< CONFIG_MAX_AP_COUNT */
    unsigned int numSlotMax;                    /**< CONFIG_MAX_SLOT_COUNT */
    unsigned int numSubslotMax;                 /**< CONFIG_MAX_SUBSLOT_COUNT */
    uint16_t idSubslotIf;                       /**< PDEV_SUBSLOT_IF */
    uint16_t idSubslotPort;                     /**< PDEV_SUBSLOT_PORT */
    uint8_t numProcAlBuf;                       /**< GOAL_PNIO_CFG_NUM_PROC_AL_BUF */
    uint32_t idSnmp;                            /**< SNMP ID */
    PN_BOOL_T flgMrpCfg;                        /**< MRP Config Flag */
} PN_INSTANCE_CFG_T;


/**< instance data */
typedef struct PN_INSTANCE_T {
    GOAL_INSTANCE_HEADER(PN_INSTANCE_T);        /**< instance header */

    PN_INSTANCE_ALARM_T alarm;                  /**< alarm data */
    PN_INSTANCE_AR_T ar;                        /**< AR data */
    PN_INSTANCE_CRT_T crt;                      /**< CRT data */
    PN_INSTANCE_CTX_T ctx;                      /**< context data */
    PN_INSTANCE_DCP_T dcp;                      /**< DCP data */
    PN_INSTANCE_DEVICE_T dev;                   /**< device data */
    PN_INSTANCE_DIAG_T diag;                    /**< Diagnosis data */
    PN_INSTANCE_GOAL_T goal;                    /**< GOAL data */
    PN_INSTANCE_LLDP_T lldp;                    /**< LLDP data */
    PN_INSTANCE_LMPM_T lmpm;                    /**< LMPM data */

#if CONFIG_LOGGING == 1
#  if CONFIG_LOGGING_NAME_RESOLVER == 1
    PN_INSTANCE_LOG_RESOLV_T logRes;            /**< Log resolver */
#  endif
#endif

    PN_INSTANCE_PDEV_T pdev;                    /**< PDEV data */
    PN_INSTANCE_RECDATA_T rec;                  /**< record data */
    PN_INSTANCE_RECDATA_LOG_T recLog;           /**< record logbook data */
    PN_INSTANCE_RPC_T rpc;                      /**< RPC data */
    PN_INSTANCE_RPC_EPM_T rpcEpm;               /**< RPC EPM data */
    PN_INSTANCE_STATS_T stats;                  /**< statistics data */
    PN_INSTANCE_UTIL_T util;                    /**< util data */
    PN_INSTANCE_CFG_T *pCfg;                    /**< instance configuration */
    uint32_t idSnmp;                            /**< SNMP instance id */
    PN_INSTANCE_FSU_T fsu;                      /**< Fast Start Up data */
    IOD_USER_CALLBACK_T userCbData;             /**< Callback Data */
} PN_INSTANCE_T;


#ifdef __cplusplus
}
#endif


#endif /* PN_INCLUDES_H */
