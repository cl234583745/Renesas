/** @file
 *
 * @brief
 * PROFINET Error Code Definitions
 *
 * @details
 * This file contains all available OK and Error codes that can be returned by
 * Profinet stack components.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_STATUS_H
#define PN_STATUS_H


/**< IOD_STATUS_T values (same as PN_STATUS_T) */
typedef uint32_t IOD_STATUS_T;

#define IOD_OK                              0 /**< successful */
#define IOD_DCP_IDENT_OTHER_DEVICE_OK       1 /**< DCP identity request was for an other device */
#define IOD_INDEX_SUPPORTED_OK              2 /**< index supported */
#define IOD_OK_FRAME_TYPE_NOT_PNIO          3 /**< frame doesn't contain PROFINET data */
#define IOD_OK_OAL_SHUTDOWN                 4 /**< OAL: shutdown stack */
#define IOD_OK_APPL_HANDLED                 5 /**< handled in application, not in stack */
#define IOD_OK_ALARM_DROPPED                6 /**< alarm dropped as no AR established or AppReady state missing */
#define IOD_OK_ALARM_ENQUEUED               7 /**< alarm enqueued */
#define IOD_OK_MOD_ALREADY_PULLED           8 /**< module already pulled */
#define IOD_OK_MOD_ALREADY_PLUGGED          9 /**< module already plugged */
#define IOD_OK_SUBMODULE_ALREADY_PULLED     10 /**< submodule already pulled */
#define IOD_OK_SUBMODULE_ALREADY_PLUGGED    11 /**< submodule already plugged */

#define IOD_OK_END_MARKER                   12 /**< OK Status End Marker */

#define IOD_GEN_ERR                         100 /**< generic error */
#define IOD_INIT_ERR                        101 /**< initialization failed */
#define IOD_FULL_ERR                        102 /**< no internal resources */
#define IOD_ALLOC_ERR                       103 /**< allocation failed */
#define IOD_IO_ERR                          104 /**< input/output error */
#define IOD_OVERFLOW_ERR                    105 /**< overflow error */
#define IOD_MISMATCH_ERR                    106 /**< mismatch error */
#define IOD_OAL_MUTEX_ERR                   107 /**< OAL mutex error */
#define IOD_OAL_TIMER_ERR                   108 /**< OAL: timer setup error */
#define IOD_OAL_ETH_INIT_FAILED             109 /**< OAL: Ethernet init failed */
#define IOD_OAL_ETH_OPEN_FAILED             110 /**< OAL: Ethernet open failed */
#define IOD_EPWRONGTYPE_ERR                 111 /**< endpoint has wrong type */
#define IOD_EPWRONGSTATE_ERR                112 /**< endpoint has wrong state */
#define IOD_DCP_INIT_ERR                    113 /**< DCP module not initialized */
#define IOD_DCP_SERVTYPE_INVAL_ERR          114 /**< invalid DCP ServiceType */
#define IOD_DCP_RESP_TIMER_ERR              115 /**< could not create DCP response timer */
#define IOD_DCP_UNKNOWN_SERVICEID_ERR       116 /**< unknown DCP ServiceID received */
#define IOD_DCP_IDENT_HANDLER_ERR           117 /**< error in DCP identity request handler */
#define IOD_DCP_GET_HANDLER_ERR             118 /**< error in DCP get request handler */
#define IOD_DCP_SET_HANDLER_ERR             119 /**< error in DCP set request handler */
#define IOD_DCP_PARAMETER_MISMATCH_ERR      120 /**< DCP parameter mismatch error */
#define IOD_DCP_INVALID_DEVICE_NAME         121 /**< DCP: invalid device name */
#define IOD_DCP_INVALID_DEVICE_NAME_LEN     122 /**< DCP: invalid device name length */
#define IOD_PARAM_ERR                       123 /**< parameter error */
#define IOD_RPCREQ_ERR                      124 /**< RPC request error */
#define IOD_ARGSLEN_INVALID                 125 /**< invalid argument length */
#define IOD_NOT_SUPPORTED                   126 /**< unsupported error */
#define IOD_FRAME_ERR                       127 /**< frame parsing error */
#define IOD_AR_ERR                          128 /**< AR not found */
#define IOD_API_ERR                         129 /**< wrong API */
#define IOD_SLOT_ERR                        130 /**< slot not supported */
#define IOD_SUBSLOT_ERR                     131 /**< subslot not supported */
#define IOD_PADDING_ERR                     132 /**< padding error */
#define IOD_INDEX_ERR                       133 /**< index not supported */
#define IOD_ERROR_SET                       134 /**< error status was set */
#define IOD_SEQNUM_ERR                      135 /**< incorrect sequence number */
#define IOD_NO_RESOURCES                    136 /**< no resource available */
#define IOD_ALTYPE_ERR                      137 /**< alarm type error */
#define IOD_ALFRAMETYPE_ERR                 138 /**< alarm frame type error */
#define IOD_ALTIMEOUT_ERR                   139 /**< alarm timeout error */
#define IOD_ALRETRY_ERR                     140 /**< alarm retry error */
#define IOD_ALDATALEN_ERR                   141 /**< alarm data length error */
#define IOD_ALVLANID_ERR                    142 /**< alarm VLAN ID error */
#define IOD_AR_UUID_NOT_FOUND               143 /**< AR UUID not found */
#define IOD_INTERNAL_ERR                    144 /**< internal error */
#define IOD_ALPRIO_ERR                      145 /**< alarm priority error */
#define IOD_NULLPTR_ERR                     146 /**< null pointer error */
#define IOD_BLOCKTYPE_ERR                   147 /**< block type error */
#define IOD_BLOCKLEN_ERR                    148 /**< block length error */
#define IOD_BLOCKVERH_ERR                   149 /**< block version high error */
#define IOD_BLOCKVERL_ERR                   150 /**< block version low error */
#define IOD_WRONG_SERVICE                   151 /**< wrong service error */
#define IOD_WRONG_STATE                     152 /**< wrong state error */
#define IOD_STATE_CONFLICT_ERR              153 /**< state conflict error */
#define IOD_EP_NOT_EXIST                    154 /**< endpoint does not exist error */
#define IOD_MODULE_NOT_FOUND                155 /**< module not found error */
#define IOD_SUBMODULE_NOT_FOUND             156 /**< submodule not found error */
#define IOD_AL_EP_NOT_EXIST                 157 /**< alarm endpoint does not exist error */
#define IOD_SLOT_NOT_EXIST                  158 /**< slot does not exist error */
#define IOD_SUBSLOT_NOT_EXIST               159 /**< subslot does not exist error */
#define IOD_SLOT_ALREADY_EXIST              160 /**< slot already exist error */
#define IOD_SUBSLOT_ALREADY_EXIST           161 /**< subslot already exist error */
#define IOD_EXP_NO_FREE_AR                  162 /**< no unused AR location found in expected list */
#define IOD_EXP_NO_FREE_API                 163 /**< no unused API location found in expected list */
#define IOD_EXP_NO_FREE_SLOT                164 /**< no unused Slot location found in expected list */
#define IOD_EXP_NO_FREE_SUBSLOT             165 /**< no unused SubSlot location found in expected list */
#define IOD_EXP_AR_NOT_FOUND                166 /**< AR not found in expected list */
#define IOD_FRAME_IGNORED                   167 /**< frame didn't match specific criterias and was ignored */
#define IOD_MM_ALLOC_OOM                    168 /**< MM: out of memory */
#define IOD_MM_QUEUE_NOT_FOUND              169 /**< MM: queue ID not found */
#define IOD_MM_QUEUE_EMPTY                  170 /**< MM: empty queue */
#define IOD_MM_QUEUE_FULL                   171 /**< MM: full queue */
#define IOD_MM_MEM_ERROR                    172 /**< MM: error in memory management */
#define IOD_FULL_AP_LIST                    173 /**< no free entry in AP list found */
#define IOD_FULL_SLOT_LIST                  174 /**< no free entry in slot list found */
#define IOD_FULL_SUBSLOT_LIST               175 /**< no free entry in subslot list found */
#define IOD_FULL_MODULE_LIST                176 /**< no free entry in module list found */
#define IOD_FULL_SUBMOD_LIST                177 /**< no free entry in submodule list found */
#define IOD_API_NOT_FOUND                   178 /**< API not found */
#define IOD_SLOT_NOT_FOUND                  179 /**< slot not found */
#define IOD_SUBSLOT_NOT_FOUND               180 /**< subslot not found */
#define IOD_INDEX_NOT_FOUND                 181 /**< index not found */
#define IOD_GET_MAC_ADDR_FAILED             182 /**< could not read MAC address */
#define IOD_CFG_INIT_FAILED                 183 /**< configuration init failed */
#define IOD_CFG_MISSING_INIT                184 /**< Config: unitialized module */
#define IOD_ELEMENT_NOT_FOUND               185 /**< element not found */
#define IOD_NVS_READ_FAILED                 186 /**< NVS read failed */
#define IOD_NVS_WRITE_FAILED                187 /**< NVS write failed */
#define IOD_UDP_OPEN_FAILED                 188 /**< UDP: channel open failed */
#define IOD_UDP_REOPEN_FAILED               189 /**< UDP: channel reopen failed */
#define IOD_UDP_RECV_FAILED                 190 /**< UDP: channel receive failed */
#define IOD_UDP_SEND_FAILED                 191 /**< UDP: channel send failed */
#define IOD_UDP_CLOSE_FAILED                192 /**< UDP: channel close failed */
#define IOD_RAW_OPEN_FAILED                 193 /**< RAW channel open failed */
#define IOD_RAW_CLOSE_FAILED                194 /**< RAW channel close failed */
#define IOD_DCP_IN_PROGRESS                 195 /**< DCP: already processing a frame (delay not expired) */
#define IOD_LOCK_CREATE_FAILED              196 /**< Lock: creating lock failed */
#define IOD_LOCK_GET_TIMEOUT_FAIL           197 /**< Lock: get timeout reached without aquiring lock */
#define IOD_TIMER_ALREADY_STARTED           198 /**< Timer: timer already started */
#define IOD_TIMER_NOT_USED                  199 /**< Timer: handle not assigned */
#define IOD_TIMER_NOT_SET                   200 /**< Timer: unconfigured timer */
#define IOD_TIMER_OUT_OF_TIMERS             201 /**< Timer: out of timers */
#define IOD_TIMER_CREATE_FAILED             202 /**< Timer: failed to create timer */
#define IOD_TIMER_START_FAILED              203 /**< Timer: failed to start timer */
#define IOD_TIMER_STOP_FAILED               204 /**< Timer: failed to stop timer */
#define IOD_IP_SET_FAILED                   205 /**< TCP/IP: could not update IP address configuration */
#define IOD_NET_IP_INVALID                  206 /**< Net: IP address invalid */
#define IOD_NET_GATEWAY_INVALID             207 /**< Net: gateway address invalid */
#define IOD_NET_NETMASK_INVALID             208 /**< Net: netmask invalid */
#define IOD_NET_UDP_OPEN_FAILED             209 /**< Net: opening UDP channel failed */
#define IOD_NET_UDP_CLOSE_FAILED            210 /**< Net: closing UDP channel failed */
#define IOD_NET_UDP_REOPEN_FAILED           211 /**< Net: reopening UDP channels failed */
#define IOD_NET_UDP_SEND_FAILED             212 /**< Net: sending UDP data failed */
#define IOD_NET_UDP_RECV_FAILED             213 /**< Net: reading UDP data failed */
#define IOD_NET_FRAME_SEND_FAILED           214 /**< Net: sending frame failed */
#define IOD_THREAD_CREATE_FAILED            215 /**< OAL: creating thread failed */
#define IOD_THREAD_CLOSE_FAILED             216 /**< OAL: closing thread failed */
#define IOD_PDEV_PLUG_FAILED                217 /**< PDEV: plugging (sub) module failed */
#define IOD_SNMP_INIT_FAILED                218 /**< SNMP: init failed */
#define IOD_MULTICAST_ADD_FAILED            219 /**< Net: failed to add multicast address */
#define IOD_MULTICAST_DEL_FAILED            220 /**< Net: failed to del multicast address */
#define IOD_EP_OFFSET_OVERFLOW              221 /**< CRT: endpoint offset length overflow */
#define IOD_RPC_SESSION_NOT_AVAIL           222 /**< RPC: no free session available */
#define IOD_RPC_SESSION_NOT_FOUND           223 /**< RPC: session not found */
#define IOD_RPC_SESSION_INVALID             224 /**< RPC: invalid session */
#define IOD_RPC_SESSION_LOCK_FAILED         225 /**< RPC: failed to lock session */
#define IOD_RPC_SESSION_UNLOCK_FAILED       226 /**< RPC: failed to unlock session */
#define IOD_RPC_ERR                         227 /**< RPC: generic error */
#define IOD_DIAG_AVAIL                      228 /**< diagnosis available */
#define IOD_NOT_FOUND                       229 /**< generic: not found */
#define IOD_SUBSLOT_TYPE_NOT_INPUT          230 /**< subslot hasn't type input */
#define IOD_SUBSLOT_TYPE_NOT_OUTPUT         231 /**< subslot hasn't type output */
#define IOD_SIZE_OVERFLOW                   232 /**< data size too large */
#define IOD_WRONG_TYPE_ERR                  233 /**< wrong type */
#define IOD_MODULE_IDENT_MISMATCH_ERR       234 /**< module ident nr mismatch */
#define IOD_SUBMODULE_IDENT_MISMATCH_ERR    235 /**< submodule ident nr mismatch */
#define IOD_OAL_INIT_ERR                    236 /**< OAL init error */
#define IOD_MM_INIT_ERR                     237 /**< memory management init error */
#define IOD_CFG_INIT_ERR                    238 /**< config init error */
#define IOD_TIMER_INIT_ERR                  239 /**< timer init error */
#define IOD_NET_INIT_ERR                    240 /**< network init error */
#define IOD_DEV_INIT_ERR                    241 /**< device config init error */
#define IOD_LMPM_INIT_ERR                   242 /**< LMPM init error */
#define IOD_ALARM_INIT_ERR                  243 /**< alarm init error */
#define IOD_CRT_INIT_ERR                    244 /**< CRT init error */
#define IOD_AR_INIT_ERR                     245 /**< AR init error */
#define IOD_CD_INIT_ERR                     246 /**< CD init error */
#define IOD_DIAG_INIT_ERR                   247 /**< diagnosis init error */
#define IOD_LLDP_INIT_ERR                   248 /**< LLDP init error */
#define IOD_SNMP_INIT_ERR                   249 /**< SNMP init error */
#define IOD_LOG_INIT_ERR                    250 /**< Logging init error */
#define IOD_READ_IMPL_AR_NOT_ZERO_ERR       251 /**< read implicit with AR not zero */
#define IOD_RECORD_BUSY_ERR                 252 /**< error handling busy record data */


/* native PN_STATUS_T status codes */
#define PN_OK_DELAYED                       253 /**< ok: postpone current processing */


/**< PROFINET status type (same as IOD_STATUS_T) */
typedef IOD_STATUS_T PN_STATUS_T;


/* IOD_STATUS_T to PN_STATUS_T mappings */
#define PN_OK                               IOD_OK
#define PN_OK_DCP_IDENT_OTHER_DEVICE        IOD_DCP_IDENT_OTHER_DEVICE_OK
#define PN_OK_INDEX_SUPPORTED               IOD_INDEX_SUPPORTED_OK
#define PN_OK_FRAME_TYPE_NOT_PNIO           IOD_OK_FRAME_TYPE_NOT_PNIO
#define PN_OK_OAL_SHUTDOWN                  IOD_OK_OAL_SHUTDOWN
#define PN_OK_APPL_HANDLED                  IOD_OK_APPL_HANDLED
#define PN_OK_ALARM_DROPPED                 IOD_OK_ALARM_DROPPED
#define PN_OK_ALARM_ENQUEUED                IOD_OK_ALARM_ENQUEUED
#define PN_OK_MOD_ALREADY_PULLED            IOD_OK_MOD_ALREADY_PULLED
#define PN_OK_MOD_ALREADY_PLUGGED           IOD_OK_MOD_ALREADY_PLUGGED
#define PN_OK_SUBMOD_ALREADY_PULLED         IOD_OK_SUBMODULE_ALREADY_PULLED
#define PN_OK_SUBMOD_ALREADY_PLUGGED        IOD_OK_SUBMODULE_ALREADY_PLUGGED
#define PN_OK_END_MARKER                    IOD_OK_END_MARKER
#define PN_ERROR                            IOD_GEN_ERR
#define PN_ERR_INIT                         IOD INIT_ERR
#define PN_ERR_FULL                         IOD_FULL_ERR
#define PN_ERR_ALLOC                        IOD_ALLOC_ERR
#define PN_ERR_IO                           IOD_IO_ERR
#define PN_ERR_OVERFLOW                     IOD_OVERFLOW_ERR
#define PN_ERR_MISMATCH                     IOD_MISMATCH_ERR
#define PN_ERR_OAL_MUTEX                    IOD_OAL_MUTEX_ERR
#define PN_ERR_OAL_TIMER                    IOD_OAL_TIMER_ERR
#define PN_ERR_OAL_ETH_INIT_FAILED          IOD_OAL_ETH_INIT_FAILED
#define PN_ERR_OAL_ETH_OPEN_FAILED          IOD_OAL_ETH_OPEN_FAILED
#define PN_ERR_EPWRONGTYPE                  IOD_EPWRONGTYPE_ERR
#define PN_ERR_EPWRONGSTATE                 IOD_EPWRONGSTATE_ERR
#define PN_ERR_DCP_INIT                     IOD_DCP_INIT_ERR
#define PN_ERR_DCP_SERVTYPE_INVAL           IOD_DCP_SERVTYPE_INVAL_ERR
#define PN_ERR_DCP_RESP_TIMER               IOD_DCP_RESP_TIMER_ERR
#define PN_ERR_DCP_UNKNOWN_SERVICEID        IOD_DCP_UNKNOWN_SERVICEID_ERR
#define PN_ERR_DCP_IDENT_HANDLER            IOD_DCP_IDENT_HANDLER_ERR
#define PN_ERR_DCP_GET_HANDLER              IOD_DCP_GET_HANDLER_ERR
#define PN_ERR_DCP_SET_HANDLER              IOD_DCP_SET_HANDLER_ERR
#define PN_ERR_DCP_PARAMETER_MISMATCH       IOD_DCP_PARAMETER_MISMATCH_ERR
#define PN_ERR_DCP_INVALID_DEVICE_NAME      IOD_DCP_INVALID_DEVICE_NAME
#define PN_ERR_DCP_INVALID_DEVICE_NAME_LEN  IOD_DCP_INVALID_DEVICE_NAME_LEN
#define PN_ERR_PARAM                        IOD_PARAM_ERR
#define PN_ERR_RPCREQ                       IOD_RPCREQ_ERR
#define PN_ERR_ARGSLEN_INVALID              IOD_ARGSLEN_INVALID
#define PN_ERR_NOT_SUPPORTED                IOD_NOT_SUPPORTED
#define PN_ERR_FRAME                        IOD_FRAME_ERR
#define PN_ERR_AR                           IOD_AR_ERR
#define PN_ERR_API                          IOD_API_ERR
#define PN_ERR_SLOT                         IOD_SLOT_ERR
#define PN_ERR_SUBSLOT                      IOD_SUBSLOT_ERR
#define PN_ERR_PADDING                      IOD_PADDING_ERR
#define PN_ERR_INDEX                        IOD_INDEX_ERR
#define PN_ERR_ERROR_SET                    IOD_ERROR_SET
#define PN_ERR_SEQNUM                       IOD_SEQNUM_ERR
#define PN_ERR_NO_RESOURCES                 IOD_NO_RESOURCES
#define PN_ERR_ALTYPE                       IOD_ALTYPE_ERR
#define PN_ERR_ALFRAMETYPE                  IOD_ALFRAMETYPE_ERR
#define PN_ERR_ALTIMEOUT                    IOD_ALTIMEOUT_ERR
#define PN_ERR_ALRETRY                      IOD_ALRETRY_ERR
#define PN_ERR_ALDATALEN                    IOD_ALDATALEN_ERR
#define PN_ERR_ALVLANID                     IOD_ALVLANID_ERR
#define PN_ERR_AR_UUID_NOT_FOUND            IOD_AR_UUID_NOT_FOUND
#define PN_ERR_INTERNAL                     IOD_INTERNAL_ERR
#define PN_ERR_ALPRIO                       IOD_ALPRIO_ERR
#define PN_ERR_NULLPTR                      IOD_NULLPTR_ERR
#define PN_ERR_BLOCKTYPE                    IOD_BLOCKTYPE_ERR
#define PN_ERR_BLOCKLEN                     IOD_BLOCKLEN_ERR
#define PN_ERR_BLOCKVERH                    IOD_BLOCKVERH_ERR
#define PN_ERR_BLOCKVERL                    IOD_BLOCKVERL_ERR
#define PN_ERR_WRONG_SERVICE                IOD_WRONG_SERVICE
#define PN_ERR_WRONG_STATE                  IOD_WRONG_STATE
#define PN_ERR_STATE_CONFLICT               IOD_STATE_CONFLICT_ERR
#define PN_ERR_EP_NOT_EXIST                 IOD_EP_NOT_EXIST
#define PN_ERR_MODULE_NOT_FOUND             IOD_MODULE_NOT_FOUND
#define PN_ERR_SUBMODULE_NOT_FOUND          IOD_SUBMODULE_NOT_FOUND
#define PN_ERR_AL_EP_NOT_EXIST              IOD_AL_EP_NOT_EXIST
#define PN_ERR_SLOT_NOT_EXIST               IOD_SLOT_NOT_EXIST
#define PN_ERR_SUBSLOT_NOT_EXIST            IOD_SUBSLOT_NOT_EXIST
#define PN_ERR_SLOT_ALREADY_EXIST           IOD_SLOT_ALREADY_EXIST
#define PN_ERR_SUBSLOT_ALREADY_EXIST        IOD_SUBSLOT_ALREADY_EXIST
#define PN_ERR_EXP_NO_FREE_AR               IOD_EXP_NO_FREE_AR
#define PN_ERR_EXP_NO_FREE_API              IOD_EXP_NO_FREE_API
#define PN_ERR_EXP_NO_FREE_SLOT             IOD_EXP_NO_FREE_SLOT
#define PN_ERR_EXP_NO_FREE_SUBSLOT          IOD_EXP_NO_FREE_SUBSLOT
#define PN_ERR_EXP_AR_NOT_FOUND             IOD_EXP_AR_NOT_FOUND
#define PN_ERR_FRAME_IGNORED                IOD_FRAME_IGNORED
#define PN_ERR_MM_ALLOC_OOM                 IOD_MM_ALLOC_OOM
#define PN_ERR_MM_QUEUE_NOT_FOUND           IOD_MM_QUEUE_NOT_FOUND
#define PN_ERR_MM_QUEUE_EMPTY               IOD_MM_QUEUE_EMPTY
#define PN_ERR_MM_QUEUE_FULL                IOD_MM_QUEUE_FULL
#define PN_ERR_MM_MEM                       IOD_MM_MEM_ERROR
#define PN_ERR_FULL_AP_LIST                 IOD_FULL_AP_LIST
#define PN_ERR_FULL_SLOT_LIST               IOD_FULL_SLOT_LIST
#define PN_ERR_FULL_SUBSLOT_LIST            IOD_FULL_SUBSLOT_LIST
#define PN_ERR_FULL_MODULE_LIST             IOD_FULL_MODULE_LIST
#define PN_ERR_FULL_SUBMOD_LIST             IOD_FULL_SUBMOD_LIST
#define PN_ERR_API_NOT_FOUND                IOD_API_NOT_FOUND
#define PN_ERR_SLOT_NOT_FOUND               IOD_SLOT_NOT_FOUND
#define PN_ERR_SUBSLOT_NOT_FOUND            IOD_SUBSLOT_NOT_FOUND
#define PN_ERR_INDEX_NOT_FOUND              IOD_INDEX_NOT_FOUND
#define PN_ERR_GET_MAC_ADDR_FAILED          IOD_GET_MAC_ADDR_FAILED
#define PN_ERR_CFG_INIT_FAILED              IOD_CFG_INIT_FAILED
#define PN_ERR_CFG_MISSING_INIT             IOD_CFG_MISSING_INIT
#define PN_ERR_ELEMENT_NOT_FOUND            IOD_ELEMENT_NOT_FOUND
#define PN_ERR_NVS_READ_FAILED              IOD_NVS_READ_FAILED
#define PN_ERR_NVS_WRITE_FAILED             IOD_NVS_WRITE_FAILED
#define PN_ERR_UDP_OPEN_FAILED              IOD_UDP_OPEN_FAILED
#define PN_ERR_UDP_REOPEN_FAILED            IOD_UDP_REOPEN_FAILED
#define PN_ERR_UDP_RECV_FAILED              IOD_UDP_RECV_FAILED
#define PN_ERR_UDP_SEND_FAILED              IOD_UDP_SEND_FAILED
#define PN_ERR_UDP_CLOSE_FAILED             IOD_UDP_CLOSE_FAILED
#define PN_ERR_RAW_OPEN_FAILED              IOD_RAW_OPEN_FAILED
#define PN_ERR_RAW_CLOSE_FAILED             IOD_RAW_CLOSE_FAILED
#define PN_ERR_DCP_IN_PROGRESS              IOD_DCP_IN_PROGRESS
#define PN_ERR_LOCK_CREATE_FAILED           IOD_LOCK_CREATE_FAILED
#define PN_ERR_LOCK_GET_TIMEOUT_FAIL        IOD_LOCK_GET_TIMEOUT_FAIL
#define PN_ERR_TIMER_ALREADY_STARTED        IOD_TIMER_ALREADY_STARTED
#define PN_ERR_TIMER_NOT_USED               IOD_TIMER_NOT_USED
#define PN_ERR_TIMER_NOT_SET                IOD_TIMER_NOT_SET
#define PN_ERR_TIMER_OUT_OF_TIMERS          IOD_TIMER_OUT_OF_TIMERS
#define PN_ERR_TIMER_CREATE_FAILED          IOD_TIMER_CREATE_FAILED
#define PN_ERR_TIMER_START_FAILED           IOD_TIMER_START_FAILED
#define PN_ERR_TIMER_STOP_FAILED            IOD_TIMER_STOP_FAILED
#define PN_ERR_IP_SET_FAILED                IOD_IP_SET_FAILED
#define PN_ERR_NET_IP_INVALID               IOD_NET_IP_INVALID
#define PN_ERR_NET_GATEWAY_INVALID          IOD_NET_GATEWAY_INVALID
#define PN_ERR_NET_NETMASK_INVALID          IOD_NET_NETMASK_INVALID
#define PN_ERR_NET_UDP_OPEN_FAILED          IOD_NET_UDP_OPEN_FAILED
#define PN_ERR_NET_UDP_CLOSE_FAILED         IOD_NET_UDP_CLOSE_FAILED
#define PN_ERR_NET_UDP_REOPEN_FAILED        IOD_NET_UDP_REOPEN_FAILED
#define PN_ERR_NET_UDP_SEND_FAILED          IOD_NET_UDP_SEND_FAILED
#define PN_ERR_NET_UDP_RECV_FAILED          IOD_NET_UDP_RECV_FAILED
#define PN_ERR_NET_FRAME_SEND_FAILED        IOD_NET_FRAME_SEND_FAILED
#define PN_ERR_THREAD_CREATE_FAILED         IOD_THREAD_CREATE_FAILED
#define PN_ERR_THREAD_CLOSE_FAILED          IOD_THREAD_CLOSE_FAILED
#define PN_ERR_PDEV_PLUG_FAILED             IOD_PDEV_PLUG_FAILED
#define PN_ERR_SNMP_INIT_FAILED             IOD_SNMP_INIT_FAILED
#define PN_ERR_MULTICAST_ADD_FAILED         IOD_MULTICAST_ADD_FAILED
#define PN_ERR_MULTICAST_DEL_FAILED         IOD_MULTICAST_DEL_FAILED
#define PN_ERR_EP_OFFSET_OVERFLOW           IOD_EP_OFFSET_OVERFLOW
#define PN_ERR_RPC_SESSION_NOT_AVAIL        IOD_RPC_SESSION_NOT_AVAIL
#define PN_ERR_RPC_SESSION_NOT_FOUND        IOD_RPC_SESSION_NOT_FOUND
#define PN_ERR_RPC_SESSION_INVALID          IOD_RPC_SESSION_INVALID
#define PN_ERR_RPC_SESSION_LOCK_FAILED      IOD_RPC_SESSION_LOCK_FAILED
#define PN_ERR_RPC_SESSION_UNLOCK_FAILED    IOD_RPC_SESSION_UNLOCK_FAILED
#define PN_ERR_RPC_GENERIC                  IOD_RPC_ERR
#define PN_ERR_DIAG_AVAIL                   IOD_DIAG_AVAIL
#define PN_ERR_NOT_FOUND                    IOD_NOT_FOUND
#define PN_ERR_SUBSLOT_TYPE_NOT_INPUT       IOD_SUBSLOT_TYPE_NOT_INPUT
#define PN_ERR_SUBSLOT_TYPE_NOT_OUTPUT      IOD_SUBSLOT_TYPE_NOT_OUTPUT
#define PN_ERR_SIZE_OVERFLOW                IOD_SIZE_OVERFLOW
#define PN_ERR_WRONG_TYPE                   IOD_WRONG_TYPE_ERR
#define PN_ERR_MOD_IDENT_MISMATCH           IOD_MODULE_IDENT_MISMATCH_ERR
#define PN_ERR_SUBMOD_IDENT_MISMATCH        IOD_SUBMODULE_IDENT_MISMATCH_ERR
#define PN_ERR_OAL_INIT                     IOD_OAL_INIT_ERR
#define PN_ERR_MM_INIT                      IOD_MM_INIT_ERR
#define PN_ERR_CFG_INIT                     IOD_CFG_INIT_ERR
#define PN_ERR_TIMER_INIT                   IOD_TIMER_INIT_ERR
#define PN_ERR_NET_INIT                     IOD_NET_INIT_ERR
#define PN_ERR_DEV_INIT                     IOD_DEV_INIT_ERR
#define PN_ERR_LMPM_INIT                    IOD_LMPM_INIT_ERR
#define PN_ERR_ALARM_INIT                   IOD_ALARM_INIT_ERR
#define PN_ERR_CRT_INIT                     IOD_CRT_INIT_ERR
#define PN_ERR_AR_INIT                      IOD_AR_INIT_ERR
#define PN_ERR_CD_INIT                      IOD_CD_INIT_ERR
#define PN_ERR_DIAG_INIT                    IOD_DIAG_INIT_ERR
#define PN_ERR_LLDP_INIT                    IOD_LLDP_INIT_ERR
#define PN_ERR_SNMP_INIT                    IOD_SNMP_INIT_ERR
#define PN_ERR_LOG_INIT                     IOD_LOG_INIT_ERR
#define PN_ERR_READ_IMPL_AR_NOT_ZERO        IOD_READ_IMPL_AR_NOT_ZERO_ERR
#define PN_ERR_RECORD_BUSY                  IOD_RECORD_BUSY_ERR


/**< PROFINET RET_T status type (same as PN_STATUS_T) */
typedef PN_STATUS_T RET_T;


/* RET_T to PN_STATUS_T mappings */
#define PN_OK_MODULE_ALREADY_PULLED         PN_OK_MOD_ALREADY_PULLED
#define PN_OK_MODULE_ALREADY_PLUGGED        PN_OK_MOD_ALREADY_PLUGGED
#define PN_OK_SUBMODULE_ALREADY_PULLED      PN_OK_SUBMOD_ALREADY_PULLED
#define PN_OK_SUBMODULE_ALREADY_PLUGGED     PN_OK_SUBMOD_ALREADY_PLUGGED
#define PN_E_ALLOC_ERROR                    PN_ERR_ALLOC
#define PN_E_RPC_ERROR                      PN_ERR_RPC_GENERIC
#define PN_E_STATE_CONFLICT                 PN_ERR_STATE_CONFLICT
#define PN_E_AR_NOT_FOUND                   PN_ERR_AR_UUID_NOT_FOUND
#define PN_E_API_NOT_EXIST                  PN_ERR_API_NOT_FOUND
#define PN_E_SLOT_NOT_EXIST                 PN_ERR_SLOT_NOT_FOUND
#define PN_E_SUBSLOT_NOT_EXIST              PN_ERR_SUBSLOT_NOT_FOUND
#define PN_E_INDEX_NOT_EXIST                PN_ERR_INDEX_NOT_FOUND
#define PN_E_WRONG_TYPE                     PN_ERR_WRONG_TYPE
#define PN_E_MODULE_IDENT_NOT_MATCH         PN_ERR_MOD_IDENT_MISMATCH
#define PN_E_SUBMODULE_IDENT_NOT_MATCH      PN_ERR_SUBMOD_IDENT_MISMATCH
#define PN_E_MODULE_NOT_FOUND               PN_ERR_MODULE_NOT_FOUND
#define PN_E_SUBMODULE_NOT_FOUND            PN_ERR_SUBMODULE_NOT_FOUND
#define PN_E_OAL_INIT_ERROR                 PN_ERR_OAL_INIT
#define PN_E_MM_INIT_ERROR                  PN_ERR_MM_INIT
#define PN_E_CFG_INIT_ERROR                 PN_ERR_CFG_INIT
#define PN_E_TIMER_INIT_ERROR               PN_ERR_TIMER_INIT
#define PN_E_NET_INIT_ERROR                 PN_ERR_NET_INIT
#define PN_E_DEV_INIT_ERROR                 PN_ERR_DEV_INIT
#define PN_E_LMPM_INIT_ERROR                PN_ERR_LMPM_INIT
#define PN_E_DCP_INIT_ERROR                 PN_ERR_DCP_INIT
#define PN_E_ALARM_INIT_ERROR               PN_ERR_ALARM_INIT
#define PN_E_CRT_INIT_ERROR                 PN_ERR_CRT_INIT
#define PN_E_AR_INIT_ERROR                  PN_ERR_AR_INIT
#define PN_E_CD_INIT_ERROR                  PN_ERR_CD_INIT
#define PN_E_DIAG_INIT_ERROR                PN_ERR_DIAG_INIT
#define PN_E_LLDP_INIT_ERROR                PN_ERR_LLDP_INIT
#define PN_E_SNMP_INIT_ERROR                PN_ERR_SNMP_INIT
#define PN_E_LOG_INIT_ERROR                 PN_ERR_LOG_INIT
#define PN_E_READ_IMPLICIT_WITH_AR_NOT_NIL  PN_ERR_READ_IMPL_AR_NOT_ZERO
#define PN_E_INTERNAL                       PN_ERROR
#define PN_E_RECORD_DATA_BUSY_ERR           PN_ERR_RECORD_BUSY


/* PROFINET status macros */
#define PN_RES_OK(x) (PN_OK_END_MARKER > x)     /**< positive result verification */
#define PN_RES_ERR(x) (PN_OK_END_MARKER <= x)   /**< negative result verification */
#define PN_RET_RES_OK(x) PN_RES_OK(x)           /**< positive result verification */
#define PN_RET_RES_ERR(x) PN_RES_ERR(x)         /**< negative result verification */


#endif /* PN_STATUS_H */
