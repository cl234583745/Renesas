/** @file
 *
 * @brief
 * PROFINET Diagnosis Specific Record Data Handling
 *
 * @details
 * This module implements the diagnostic data specific functionality for record
 * data access.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_RECDATA_DIAG_H
#define PN_RECDATA_DIAG_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define PN_DIAG_DIAGDATA_DIAG_CHAN_SUBSLOT          0x800a
#define PN_DIAG_DIAGDATA_DIAG_ALL_SUBSLOT           0x800b
#define PN_DIAG_DIAGDATA_ALL_SUBSLOT                0x800c

#define PN_DIAG_DIAGDATA_MAINT_REQ_CHAN_SUBSLOT     0x8010
#define PN_DIAG_DIAGDATA_MAINT_DEM_CHAN_SUBSLOT     0x8011
#define PN_DIAG_DIAGDATA_MAINT_REQ_ALL_SUBSLOT      0x8012
#define PN_DIAG_DIAGDATA_MAINT_DEM_ALL_SUBSLOT      0x8013

#define PN_DIAG_DIAGDATA_DIAG_CHAN_SLOT             0xc00a
#define PN_DIAG_DIAGDATA_DIAG_ALL_SLOT              0xc00b
#define PN_DIAG_DIAGDATA_ALL_SLOT                   0xc00c

#define PN_DIAG_DIAGDATA_MAINT_REQ_CHAN_SLOT        0xc010
#define PN_DIAG_DIAGDATA_MAINT_DEM_CHAN_SLOT        0xc011
#define PN_DIAG_DIAGDATA_MAINT_REQ_ALL_SLOT         0xc012
#define PN_DIAG_DIAGDATA_MAINT_DEM_ALL_SLOT         0xc013

#define PN_DIAG_DIAGDATA_DIAG_CHAN_AR               0xe00a
#define PN_DIAG_DIAGDATA_DIAG_ALL_AR                0xe00b
#define PN_DIAG_DIAGDATA_ALL_AR                     0xe00c

#define PN_DIAG_DIAGDATA_MAINT_REQ_CHAN_AR          0xe010
#define PN_DIAG_DIAGDATA_MAINT_DEM_CHAN_AR          0xe011
#define PN_DIAG_DIAGDATA_MAINT_REQ_ALL_AR           0xe012
#define PN_DIAG_DIAGDATA_MAINT_DEM_ALL_AR           0xe013

#define PN_DIAG_DIAGDATA_DIAG_CHAN_API              0xf00a
#define PN_DIAG_DIAGDATA_DIAG_ALL_API               0xf00b
#define PN_DIAG_DIAGDATA_ALL_API                    0xf00c

#define PN_DIAG_DIAGDATA_MAINT_REQ_CHAN_API         0xf010
#define PN_DIAG_DIAGDATA_MAINT_DEM_CHAN_API         0xf011
#define PN_DIAG_DIAGDATA_MAINT_REQ_ALL_API          0xf012
#define PN_DIAG_DIAGDATA_MAINT_DEM_ALL_API          0xf013

#define PN_DIAG_DIAGDATA_ALL_DEVICE                 0xf80c


/****************************************************************************/
/* Data Types */
/****************************************************************************/
/**< Diagnosis Filter */
typedef enum {
    PN_DIAG_FILTER_DEVICE,                      /**< whole device */
    PN_DIAG_FILTER_AR,                          /**< specific AR */
    PN_DIAG_FILTER_API,                         /**< specific API */
    PN_DIAG_FILTER_SLOT,                        /**< specific API:Slot */
    PN_DIAG_FILTER_SUBSLOT,                     /**< specific API:Slot:Subslot */
} PN_DIAG_FILTER_DEPTH_T;


/**< DiagnosisData with BlockVersionLow = 1 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T hdrBlock;                    /**< BlockHeader */
    Unsigned32 api_be32;                        /**< API */
    /* ChannelDiagnosis */
    /* ManufacturerSpecificDiagnosis */
    /* ExtChannelDiagnosis */
    /* QualifiedChannelDiagnosis */
} GOAL_TARGET_PACKED PN_DIAG_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< ChannelDiagnosis */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 slotNr_be16;                     /**< slot */
    Unsigned16 subSlotNr_be16;                  /**< subslot */
    Unsigned16 chanNr_be16;                     /**< channel number */
    Unsigned16 chanProp_be16;                   /**< channel properties */
    Unsigned16 usi_be16;                        /**< user structure identifier */
    /* *DiagnosisData */
} GOAL_TARGET_PACKED PN_DIAG_CHAN_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< ChannelDiagnosisData */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 chanNr_be16;                     /**< ChannelNumber */
    Unsigned16 chanProp_be16;                   /**< ChannelProperties */
    Unsigned16 chanErrType_be16;                /**< ChannelErrorType */
} GOAL_TARGET_PACKED PN_DIAG_CHAN_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< ExtChannelDiagnosisData */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 extChanErrType_be16;             /**< ExtChannelErrorType */
    Unsigned32 extChanAddVal_be32;              /**< ExtChannelAddValue */
} GOAL_TARGET_PACKED PN_DIAG_CHAN_EXT_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
RET_T PN_recGenReadRespDiagMaintQualStatus(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const IOD_HEADER_T *pReadReqHdr,            /**< read request hdr */
    const UUID_T *pArUuid,                      /**< AR UUID */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    IOD_READ_RES_T *pReadRes,                   /**< target frame */
    Unsigned16 *pOutDataLen                     /**< output data len ptr */
);

PN_BOOL_T PN_recDiagFilterDepth(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_DIAG_FILTER_DEPTH_T filterDepth,         /**< depth filter */
    PN_DIAG_TYPE_T *pDiag,                      /**< diagnosis buffer */
    const UUID_T *pArUuid,                      /**< AR UUID */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subslot                          /**< subslot */
);


#endif /* PN_RECDATA_DIAG_H */
