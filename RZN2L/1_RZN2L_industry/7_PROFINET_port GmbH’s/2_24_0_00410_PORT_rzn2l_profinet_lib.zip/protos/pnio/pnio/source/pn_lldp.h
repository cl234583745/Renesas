/** @file
 *
 * @brief
 * PROFINET Link Layer Discovery Protocol Module
 *
 * @details
 * This module implements Link Layer Discovery Protocol which is used in
 * PROFINET to deliever information about network device properties e.g.
 * chassis id, port id, system name, system description.
 *
 * @copyright
 * Copyright 2023 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_LLDP_H
#define PN_LLDP_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* string lengths */
#define PN_LLDP_NOS_LEN_MAX 255                 /**< maximum Name of Station length in bytes */

/* CM variable string lengths */
#define LLDP_PORT_DESC_LEN  GOAL_LLDP_TLV_LEN_PORTDESC_STRING_MAX
#define LLDP_SYS_DESC_LEN   GOAL_LLDP_TLV_LEN_SYSDESC_STRING_MAX
#define LLDP_SYS_NAME_LEN   GOAL_LLDP_TLV_LEN_SYSNAME_STRING_MAX

/* PROFINET organization OUI and subtypes */
#define PN_LLDP_ORGEXT_PNIO_OUID                     0x000ECFu
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_DELAY                   1u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_PORT_STATUS             2u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_ALIAS                   3u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_MRP_PORT_STATUS         4u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_MAC_ADDRESS             5u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_PTCP_STATUS             6u
#define PN_LLDP_ORGEXT_PNIO_SUBTYPE_MAU_TYPE_EXTENSION      7u

/* IEEE Std 802.3. organization OUI and subtypes */
#define PN_LLDP_ORGEXT_8023_OUID                     0x00120Fu
#define PN_LLDP_ORGEXT_8023_SUBTYPE_PHY_STATUS              1u
#define PN_LLDP_ORGEXT_8023_SUBTYPE_PWR_VIA_MDI             2u
#define PN_LLDP_ORGEXT_8023_SUBTYPE_LINK_AGG                3u
#define PN_LLDP_ORGEXT_8023_SUBTYPE_MAX_FRAME_SIZE          4u

/* IEEE Std 802.1Q organization OUI and subtypes */
#define PN_LLDP_ORGEXT_8021_OUID                     0x0080C2u
#define PN_LLDP_ORGEXT_8021_SUBTYPE_PORT_VLAN               1u
#define PN_LLDP_ORGEXT_8021_SUBTYPE_PP_VLAN                 2u
#define PN_LLDP_ORGEXT_8021_SUBTYPE_VLAN_NAME               3u
#define PN_LLDP_ORGEXT_8021_SUBTYPE_PROTOCOL                4u

/* autoneg flags in PHY Interface */
#define PN_LLDP_PHY_IF_AUTONEG_SUPPORT_FLAG (1 << 0)
#define PN_LLDP_PHY_IF_AUTONEG_ENABLE_FLAG (1 << 1)

#define PN_LLDP_IPV4_SIZE 4

#define PN_LLDP_MAC_ADDR_STR_FORMAT "%02X-%02X-%02X-%02X-%02X-%02X"
#define PN_LLDP_MAC_ADDR_LEN  18
#define PN_LLDP_MAC_ADDR_LEN_WITHOUT_NULL_TERM (PN_LLDP_MAC_ADDR_LEN - 1)


/****************************************************************************/
/* Types */
/****************************************************************************/
typedef struct PN_LLDP_PHY_IF_T {
    uint8_t autoNegState;                       /**< auto-negotiation state */
    uint16_t advertisedCap;                     /**< advertised capabilities for auto negotiation */
    uint16_t mauType;                           /**< MAU Type */
} PN_LLDP_PHY_IF_T;

typedef struct PN_INSTANCE_LLDP_T {
    /* instance */
    GOAL_LLDP_HANDLE_T *pLldp;                  /**< GOAL LLDP handle */

    /* generic data */
    GOAL_BOOL_T flgInitalized;                  /**< PNIO LLDP is initialized */
    PN_BOOL_T multipleInterFaceMode;            /**< multiple interface mode */
    uint32_t txDisableFlags;                    /**< portmask of sending diesabled ports */

    /* strings */
    char nameOfStation[PN_LLDP_NOS_LEN_MAX];    /**< name of station (copy from CM variable for external access) */
    char macStr[PN_LLDP_MAC_ADDR_LEN];          /**< MAC address as string (buffer for external usage) */
    uint16_t lenNameOfStation;                  /**< length of Name of Station in Bytes */

    /* unsupported variabes */
    PN_LLDP_PHY_IF_T phyIf;                     /**< PHY interface - setting not supported, only default values getable */
    uint16_t rtClass2PortStatus;                /**< Realtime Class 2 port Status - contant 0 */
    uint16_t rtClass3PortStatus;                /**< Realtime Class 3 port Status - contant 0 */
} PN_INSTANCE_LLDP_T;

GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct PN_LLDP_TLV_PHY_STATUS_T {
    uint8_t autoNegState;                       /**< auto-negotiation state */
    uint16_t advertisedCap_be16;                /**< advertised capabilities for auto negotiation in network order */
    uint16_t mauType_be16;                      /**< MAU Type in network order */
} GOAL_TARGET_PACKED PN_LLDP_TLV_PHY_STATUS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T PN_lldpInit(
    struct PN_INSTANCE_T *pPnio                 /**< [in] PROFINET instance */
);

void PN_lldpShutdown(
    struct PN_INSTANCE_T *pPnio                 /**< [in] PROFINET instance */
);

GOAL_STATUS_T PN_lldpHandleGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    GOAL_LLDP_HANDLE_T **ppLldp                 /**< [out] GOAL LLDP handle */
);

GOAL_STATUS_T PN_lldpInstanceGetByLldpHandle(
    GOAL_LLDP_HANDLE_T *pLldp,                  /**< [in] GOAL LLDP handle */
    struct PN_INSTANCE_T **ppPnio               /**< [out] PROFINET instance */
);

GOAL_STATUS_T PN_lldpPeerInfoGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    uint32_t portIdx,                           /**< port index */
    uint32_t *pPeerIdx,                         /**< [in, out] pointer for peer index */
    char **ppPortId,                            /**< [out] port ID pointer (may be NULL) */
    uint16_t *pPortIdLen,                       /**< [out] port id length in bytes (may be NULL) */
    char **ppChassisId,                         /**< [out] chassis ID pointer (may be NULL) */
    uint16_t *pChassisIdLen,                    /**< [out] chassis ID length in bytes (may be NULL) */
    uint8_t **ppMac                             /**< [out] peer MAC address pointer (may be NULL) */
);

GOAL_STATUS_T PN_lldpLocNameOfStationGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    char **ppNameOfStation,                     /**< [out] name of station pointer */
    uint16_t *pLenName                          /**< [out] length of name of station */
);

GOAL_STATUS_T PN_lldpLocOperMauTypeGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    uint16_t *pOperMauType                      /**< [out] operational MAU type */
);

GOAL_STATUS_T PN_lldpRemNameOfStationGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    uint32_t portIdx,                           /**< port index */
    char **ppNameOfStation,                     /**< [out] name of station pointer */
    uint16_t *pLenName                          /**< [out] length of name of station */
);

GOAL_STATUS_T PN_lldpLocPortDescSet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    const char *pPortDesc,                      /**< [in] port description */
    uint32_t len                                /**< description length */
);

GOAL_STATUS_T PN_lldpLocSystemDescSet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    const char *pSysDesc,                       /**< [in] system description */
    uint32_t len                                /**< description length */
);

GOAL_STATUS_T PN_lldpTxStateSet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    uint32_t portIdx,                           /**< port index */
    GOAL_BOOL_T enable                          /**< enable flag */
);

GOAL_STATUS_T PN_lldpStart(
    struct PN_INSTANCE_T *pPnio                 /**< [in] PROFINET instance */
);

GOAL_STATUS_T PN_lldpStop(
    struct PN_INSTANCE_T *pPnio                 /**< [in] PROFINET instance */
);

GOAL_STATUS_T PN_lldpMultipleInterfaceModeSet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    GOAL_BOOL_T multipleInferfaceMode           /**< multiple interface mode (for name of device) */
);

GOAL_STATUS_T PN_lldpLocAutoNegSupportGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    GOAL_BOOL_T *pAutoNeg                       /**< [out] auto neg support flag */
);

GOAL_STATUS_T PN_lldpLocAutoNegEnableGet(
    struct PN_INSTANCE_T *pPnio,                /**< [in] PROFINET instance */
    GOAL_BOOL_T *pAutoNeg                       /**< [out] auto neg enable flag */
);

#if 1 == GOAL_CONFIG_MRP
GOAL_STATUS_T PN_lldpTlvTxPnioMrpUpdate(
    struct PN_INSTANCE_T *pPnio                 /**< [in] PROFINET instance */
);
#endif /* 1 == GOAL_CONFIG_MRP */

GOAL_STATUS_T PN_lldpVarChanged(
    uint32_t modId,                             /**< module ID */
    uint32_t varId,                             /**< variable ID */
    GOAL_CM_VAR_T *pVar                         /**< [in] variable pointer */
);

#endif /* PN_LLDP_H */
