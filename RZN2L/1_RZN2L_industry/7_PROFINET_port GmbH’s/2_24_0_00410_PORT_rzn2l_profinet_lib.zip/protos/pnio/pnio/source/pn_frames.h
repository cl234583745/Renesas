/** @file
 *
 * @brief
 * PROFINET IO Frame Structures
 *
 * @details
 * This file contains the PROFINET IO frame structures.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_FRAMES_H
#define PN_FRAMES_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* Data Directions in Frames (U16) */
#define DATADIR_INPUT  0x0001
#define DATADIR_OUTPUT 0x0002


/****************************************************************************/
/* Data types */
/****************************************************************************/
/* Block Header */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          blockType;
    Unsigned16          blockLength;
    Unsigned8           blockVersionHigh;
    Unsigned8           blockVersionLow;
} GOAL_TARGET_PACKED BLOCK_HEADER_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Control Block: Connect */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          padding1;
    Unsigned8           arUUID[16];
    Unsigned16          sessionKey;
    Unsigned16          padding2;
    Unsigned16          controlCommand;
    Unsigned16          controlBlockProperties;
} GOAL_TARGET_PACKED CONTROL_BLOCK_CONNECT_T;
GOAL_TARGET_PACKED_STRUCT_POST


typedef CONTROL_BLOCK_CONNECT_T RELEASE_BLOCK_T;


/* Application relationship block request */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          type;
    Unsigned8           uuid[16];
    Unsigned16          sessionKey;
    Unsigned8           cmInitiatorMac[6];
    Unsigned8           cmInitiatorObjectUUID[16];
    Unsigned32          properties;
    Unsigned16          cmInitActToutFact; /* CM Initiator Activity Timeout Factor */
    Unsigned16          cmInitUDPRTPort;        /* CM Initiator UDP RT port */
    Unsigned16          stationNameLengh;       /* Station name length */
    Unsigned8           cmInitStationName[1];   /* CM Initiator Station name */
} GOAL_TARGET_PACKED AR_BLOCK_REQ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Application relationship block response */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          type;
    Unsigned8           uuid[16];
    Unsigned16          sessionKey;
    Unsigned8           cmResponderMac[6];
    Unsigned16          cmRespUDPRTPort;        /* CM Responder UDP RT port */
} GOAL_TARGET_PACKED AR_BLOCK_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Communication relationship block request - IO Data Object */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          slotNr;                 /* Slot number */
    Unsigned16          subSlotNr;              /* SubSlot number */
    Unsigned16          frameOffset;            /* IO Data Object frame offset */
} GOAL_TARGET_PACKED IOCRREQ_IOD_OBJ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Communication relationship block request - IO Consumer Status */
typedef IOCRREQ_IOD_OBJ_T IOCRREQ_IOCS_T;


/* Communication relationship block request - API */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32          apiNr;                  /* AP identifier number */
    Unsigned16          numberOfIODObj;         /* Number of IO Data Objects */
    Unsigned8           ioBlocks[FLA_LENGTH];   /* IO Data Objects and IOCS Blocks */
} GOAL_TARGET_PACKED IOCRREQ_API_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Communication relationship block request - body with BlockHeader */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          iocrType;               /* IO CR type */
    Unsigned16          reference;              /* IO CR preference */
    Unsigned16          lt;                     /* Length/Type field */
    Unsigned32          properties;             /* IO CR Properties */
    Unsigned16          dataLength;             /* C_SDU length */
    Unsigned16          frameID;                /* Frame ID */
    Unsigned16          sendClockFactor;        /* Send Clock Factor */
    Unsigned16          reductionRatio;         /* Reduction Ratio */
    Unsigned16          phase;                  /* Phase */
    Unsigned16          sequence;               /* Sequence */
    Unsigned32          frameSendOffset;        /* Frame send offset */
    Unsigned16          dataHoldFactorLegacy_be16; /* DataHoldFactory (legacy) */
    Unsigned16          dataHoldFactor;         /* Data hold factor */
    Unsigned16          tagHeader;              /* IO CR Tag Header */
    Unsigned8           multicastMac[6];        /* Multicast MAC address */
    Unsigned16          numberOfAPIs;           /* Number of APIs */
    Unsigned8           apiBlocks[FLA_LENGTH];  /* API blocks */
} GOAL_TARGET_PACKED IOCR_BLOCK_REQ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* IO CR Block Response */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          type;                   /* IO CR type */
    Unsigned16          reference;              /* IO CR reference */
    Unsigned16          frameID;
} GOAL_TARGET_PACKED IOCR_BLOCK_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Status and Error code defines */
/****************************************************************************/
/* 4.10.2.3.6 Coding of the field PNIOStatus */

/* Everything OK */
#define ERR_CODE_OK                                          0x00
#define ERR_DECODE_OK                                        0x00
#define ERR_CODE1_OK                                         0x00
#define ERR_CODE2_OK                                         0x00

/* 6.2.5.2 Coding of the field ErrorCode */
#define ERR_CODE_RESERVED                                    0x00
#define ERR_CODE_PNIO                                        0x81
#define ERR_CODE_RTA_ERROR                                   0xCF    /* RTA Error */
#define ERR_CODE_ALARM_ACK                                   0xDA    /* Alarm ACK */
#define ERR_CODE_IOD_CONNECT_RES                             0xDB    /* IODConnectRes */
#define ERR_CODE_IOD_RELEASE_RES                             0xDC    /* IODReleaseRes */
#define ERR_CODE_IODX_CONTROL_RES                            0xDD    /* IOD-, IOX-, ControlRes */
#define ERR_CODE_IOD_READ_RES                                0xDE    /* IODReadRes */
#define ERR_CODE_IOD_WRITE_RES                               0xDF    /* IODWriteRes */

/* 6.2.5.3 Coding of the field ErrorDecode */
#define ERR_DECODE_RESERVED                                  0x00
#define ERR_DECODE_PNIORW                                    0x80    /* context with user error codes */
#define ERR_DECODE_PNIO                                      0x81    /* context with other services */

/* 6.2.5.4 Coding of the field ErrorCode1 and (generic values of) ErrorCode2 */
#define ERR_CODE1_RESERVED                                   0x00
#define ERR_CODE2_RESERVED                                   0x00
#define ERR_CODE2_PARAM_BLOCK_TYPE                           0x00
#define ERR_CODE2_PARAM_BLOCK_LENGTH                         0x01
#define ERR_CODE2_PARAM_BLOCK_VER_HIGH                       0x02
#define ERR_CODE2_PARAM_BLOCK_VER_LOW                        0x03

/* ErrorCode1: 1 - Connect Parameter Error: Faulty ARBlockReq */
#define ERR_CODE1_FAU_AR_BLOCK_REQ                           0x01
#define ERR_CODE2_ERR_IN_PARAM_ARTYPE                        0x04
#define ERR_CODE2_ERR_IN_PARAM_ARPROP                        0x09

/* ErrorCode1: 2 - Connect Parameter Error: Faulty IOCRBlockReq */
/* Table: 776 - IOCRBlockReq - request check */
#define ERR_CODE1_FAU_IOCR_BLOCK_REQ                         0x02
#define ERR_CODE2_IOCRTYPE_ERROR                             0x04
#define ERR_CODE2_IOCRBLOCKREQ_LT_ERROR                      0x06
#define ERR_CODE2_IOCRPROPERTIES_ERROR                       0x07
#define ERR_CODE2_DATALEN_ERROR                              0x08
#define ERR_CODE2_FRAMEID_ERROR                              0x09
#define ERR_CODE2_SENDCLOCKFACTOR_ERROR                      0x0A
#define ERR_CODE2_REDRATIO_ERR                               0x0B
#define ERR_CODE2_IOCRBLOCKREQ_FRAME_SEND_OFFSET_ERROR       0x0E
#define ERR_CODE2_DHF_LEGACY_ERROR                           0x0F
#define ERR_CODE2_DHF_ERROR                                  0x10
#define ERR_CODE2_IOCRBLOCKREQ_NR_OF_API_ERROR               0x13
#define ERR_CODE2_API_CONFIG_WRONG                           0x14
#define ERR_CODE2_SLOT_CONFIG_WRONG                          0x16
#define ERR_CODE2_SUBSLOT_CONFIG_WRONG                       0x17
#define ERR_CODE2_WRONG_IO_DATA_OBJECT_FRAME_OFFSET          0x18
#define ERR_CODE2_WRONG_NUMBER_OF_IOCS                       0x19
#define ERR_CODE2_SLOT_CONFIG_WRONG_2                        0x1A
#define ERR_CODE2_SUBSLOT_CONFIG_WRONG_2                     0x1B
#define ERR_CODE2_WRONG_IOCS_FRAME_OFFSET                    0x1C

/* ErrorCode1: 3 - Connect Parameter Error: Faulty ExpectedSubmoduleBlockReq */
#define ERR_CODE1_FAU_EXP_SUBMODULE_BLOCK_REQ                0x03
#define ERR_CODE2_NR_OF_API_IS_ZERO                          0x04
#define ERR_CODE2_API_UNSUPPORTED                            0x05
#define ERR_CODE2_SLOT_NR_WRONG                              0x06
#define ERR_CODE2_MOD_IDENT_NR_IS_ZERO                       0x07
#define ERR_CODE2_MOD_PROP_RESERVED_NOT_ZERO                 0x08
#define ERR_CODE2_NR_OF_SUB_MOD_IS_ZERO                      0x09
#define ERR_CODE2_SUB_SLOT_NR_WRONG                          0x0A
#define ERR_CODE2_SUBMODULE_PROPERTIES                       0x0C
#define ERR_CODE2_SUBMODULE_DATA_LENGTH                      0x0E
#define ERR_CODE2_LENGTH_IOPS                                0x0F
#define ERR_CODE2_LENGTH_IOCS                                0x10

/* ErrorCode1: 4 - Connect Parameter Error: Faulty AlarmCRBlockReq */
#define ERR_CODE1_FAU_ALARM_CR_BLOCK_REQ                     0x04
#define ERR_CODE2_ALARM_CR_TYPE                              0x04
#define ERR_CODE2_TRANSPORT_TYPE                             0x05
#define ERR_CODE2_RTA_TIMEOUT_FACTOR                         0x07
#define ERR_CODE2_RTA_RETRIES                                0x08
#define ERR_CODE2_MAX_ALARM_DATA_LENGTH                      0x0A
#define ERR_CODE2_ALARM_CR_PRIO_HIGH                         0x0B
#define ERR_CODE2_ALARM_CR_PRIO_LOW                          0x0C

/* ErrorCode1: 8 - IODWriteReqHeader - request check */
#define ERR_PNIO_C1_RW_REC_PARAM_ERR                         0x08
#define ERR_PNIO_C2_AR_UUID_ERR                              0x05
#define ERR_PNIO_C2_REC_DATA_LEN                             0x0B
#define ERR_PNIO_C2_TARGET_AR_UUID_ERR                       0x0C

#define ERR_CODE1_PNIORW_APP                                 0xA0
#define ERR_CODE1_PNIORW_ACCESS                              0xB0
#define ERR_CODE1_PNIORW_RES                                 0xC0
#define ERR_CODE1_PNIORW_APP_READ_ERR                        (ERR_CODE1_PNIORW_APP | 0x00)
#define ERR_CODE1_PNIORW_APP_WRITE_ERR                       (ERR_CODE1_PNIORW_APP | 0x01)
#define ERR_CODE1_PNIORW_APP_MOD_FAIL                        (ERR_CODE1_PNIORW_APP | 0x02)
#define ERR_CODE1_PNIORW_APP_BUSY                            (ERR_CODE1_PNIORW_APP | 0x07)
#define ERR_CODE1_PNIORW_APP_VER_CONFLICT                    (ERR_CODE1_PNIORW_APP | 0x08)
#define ERR_CODE1_PNIORW_APP_UNSUP_FEAT                      (ERR_CODE1_PNIORW_APP | 0x09)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_IDX                    (ERR_CODE1_PNIORW_ACCESS | 0x00)
#define ERR_CODE1_PNIORW_ACCESS_WRITE_LEN_ERR                (ERR_CODE1_PNIORW_ACCESS | 0x01)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_SUBSLOT                (ERR_CODE1_PNIORW_ACCESS | 0x02)
#define ERR_CODE1_PNIORW_ACCESS_TYPE_CONFLICT                (ERR_CODE1_PNIORW_ACCESS | 0x03)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_AREA_API               (ERR_CODE1_PNIORW_ACCESS | 0x04)
#define ERR_CODE1_PNIORW_ACCESS_INVALID_STATE                (ERR_CODE1_PNIORW_ACCESS | 0x05)
#define ERR_CODE1_PNIORW_ACCESS_DENIED                       (ERR_CODE1_PNIORW_ACCESS | 0x06)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_RANGE                  (ERR_CODE1_PNIORW_ACCESS | 0x07)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_PARAM                  (ERR_CODE1_PNIORW_ACCESS | 0x08)
#define ERR_CODE1_PNIORW_ACCESS_INVAL_TYPE                   (ERR_CODE1_PNIORW_ACCESS | 0x09)
#define ERR_CODE1_PNIORW_ACCESS_BACKUP                       (ERR_CODE1_PNIORW_ACCESS | 0x0A)
#define ERR_CODE1_PNIORW_RES_READ_CONSTRAIN_CONFLICT         (ERR_CODE1_PNIORW_RES | 0x00)
#define ERR_CODE1_PNIORW_RES_WRITE_CONSTRAIN_CONFLICT        (ERR_CODE1_PNIORW_RES | 0x01)
#define ERR_CODE1_PNIORW_RES_BUSY                            (ERR_CODE1_PNIORW_RES | 0x02)
#define ERR_CODE1_PNIORW_RES_RESOURCE_UNAVAIL                (ERR_CODE1_PNIORW_RES | 0x03)

#define ERR_CODE2_PNIORW_USER_SPEC                           0x00
#define ERR_CODE2_API                                        0x06
#define ERR_CODE2_SLOT                                       0x07
#define ERR_CODE2_SUBSLOT                                    0x08
#define ERR_CODE2_PADDING                                    0x09
#define ERR_CODE2_INDEX                                      0x0A

/* ErrorCode1: 20 - IODControl Parameter Error: Faulty ControlBlockConnect */
#define ERR_CODE1_FAU_CTRL_BLOCK_CONNECT                     0x14
#define ERR_CODE2_FAU_CTRL_BLOCK_CONNECT_PADDING_ERROR       0x04
#define ERR_CODE2_FAU_CTRL_BLOCK_CONNECT_SESSION_KEY_ERROR   0x06
#define ERR_CODE2_FAU_CTRL_BLOCK_CONNECT_PADDING2_ERROR      0x07
#define ERR_CODE2_FAU_CTRL_BLOCK_CONNECT_CONTROL_COMMAND_ERROR 0x08
#define ERR_CODE2_FAU_CTRL_BLOCK_CONNECT_CONTROL_BLOCK_PROPERTIES_ERROR 0x09

/* ErrorCode1: 60 - AlarmAck Error Codes */
#define ERR_CODE1_ALARM_ACK                                  0x3C
#define ERR_CODE2_ALARM_TYPE_NOT_SUPPORTED                   0x00

/* ErrorCode1: 61 - CMDEV (0x3d) */
#define ERR_CODE1_CMDEV                                      0x3D
#define ERR_CODE2_CMDEV_STATE_CONFLICT                       0x00

/* ErrorCode1: 64 - CMRPC (successor of the RMPM) */
#define ERR_CODE1_CMRPC                                      0x40
#define ERR_CODE2_OUT_OF_AR_RESOURCES                        0x04
#define ERR_CODE2_AR_UUID_UNKNOWN                            0x05
#define ERR_CODE2_OUT_OF_RESOURCES                           0x07

/* ErrorCode1: 253 - Used by RTA for protocol error - RTA_ERR_CLS_PROTOCOL */
#define ERR_CODE1_RTA_ERR_CLS_PROTOCOL                       0xFD
#define ERR_CODE2_INSTANCE_CLOSED                            0x02  /* Instance closed - RTA_ERR_ABORT */
#define ERR_CODE2_AR_CONSUMER_DHT_WDT_EXPIRED                0x05  /* AR consumer DHT/WDT expired - RTA_ERR_ABORT */
#define ERR_CODE2_AR_CMI_TIMEOUT                             0x06
#define ERR_CODE2_AR_ABORT                                   0x08
#define ERR_CODE2_AR_ALARM_SEND_CONFIRM                      0x08
#define ERR_CODE2_AR_ALARM_IND_ERR                           0x0B /* AR alarm.ind (err) */
#define ERR_CODE2_AR_ABORT_REQ                               0x0D /* AR abort.req */
#define ERR_CODE2_AR_RE_RUN_ABORTS_EXISTING                  0x0E /* AR re-run aborts existing */
#define ERR_CODE2_AR_RELEASE_IND_RECEIVED                    0x0F
#define ERR_CODE2_AR_DEVICE_DEACTIVATED                      0x10
#define ERR_CODE2_AR_PROTOCOL_VIOLATION                      0x12 /* AR protocol violation */
#define ERR_CODE2_AR_RPC_BIND_ERROR                          0x14 /* AR RPC-Bind error */
#define ERR_CODE2_AR_RPC_CONNECT_ERROR                       0x15 /* AR RPC-Connect error */
#define ERR_CODE2_DCP_STATION_NAME_CHANGED                   0x1F
#define ERR_CODE2_DCP_RESET_TO_FACTORY_SETTINGS              0x20
#define ERR_CODE2_PDEV_NO_SPEED_DUPLEX                       0x24 /* PDEV, no port offers required speed or duplexity */
#define ERR_CODE2_MANUFACTURER_SPECIFIC_1                    0xC9


/****************************************************************************/
/* Expected Submodules Block - Body and List elements */
/****************************************************************************/
/* Submodule properties */
#define SUBMOD_PROP_TYPE_IO 0x0003

/* Expected Submodule Block Request - Submodule Data Description */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          dataDirection;
    Unsigned16          dataLength;
    Unsigned8           lengthIOCS;
    Unsigned8           lengthIOPS;
} GOAL_TARGET_PACKED EXPSUB_DATADESC_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Expected Submodule Block Request - Submodules */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          subSlotNr;
    Unsigned32          subModIdentNr;
    Unsigned16          subModProp;
} GOAL_TARGET_PACKED EXPSUB_SUBMOD_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Expected Submodule Block Request - Related API */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32          api;
    Unsigned16          slotNr;
    Unsigned32          modIdentNr;
    Unsigned16          modProperties;
    Unsigned16          nrOfSubMod;
} GOAL_TARGET_PACKED EXPSUB_API_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Expected Submodule Block Request - Body with BlockHeader */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          nrOfAPIs;
} GOAL_TARGET_PACKED EXP_SUBMOD_BLOCK_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Module Diff Block - Body and List elements */
/****************************************************************************/
/* Module Diff Block Response - SubModules */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          subSlotNr;
    Unsigned32          subModIdentNr;
    Unsigned16          subModState;
} GOAL_TARGET_PACKED MODDIFF_SUBMOD_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Module Diff Block Response - Modules */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16          slotNr;
    Unsigned32          modIdentNr;
    Unsigned16          modState;
    Unsigned16          nrOfSubMod;
    MODDIFF_SUBMOD_T    subMod[FLA_LENGTH];
} GOAL_TARGET_PACKED MODDIFF_MOD_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Module Diff Block Response - API */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32          api;
    Unsigned16          nrOfModules;
    MODDIFF_MOD_T       modules[FLA_LENGTH];
} GOAL_TARGET_PACKED MODDIFF_API_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* Module Diff Block Response - Body with Block Header */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          nrOfAPIs;
    MODDIFF_API_T       api[FLA_LENGTH];
} GOAL_TARGET_PACKED MOD_DIFF_BLOCK_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* IOD/IOX Block Request */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T      blockHeader;
    Unsigned16          reserved1;
    Unsigned8           arUUID[16];
    Unsigned16          sessionKey;
    Unsigned16          reserved2;
    Unsigned16          controlCmd;             /* Control command */
    Unsigned16          cntrlBlockProp; /* Control block properties */
} GOAL_TARGET_PACKED IO__BLOCK_RE__T;
GOAL_TARGET_PACKED_STRUCT_POST


typedef IO__BLOCK_RE__T IOX_BLOCK_REQ_T;
typedef IO__BLOCK_RE__T IOD_BLOCK_REQ_T;
typedef IO__BLOCK_RE__T IOX_BLOCK_RES_T;
typedef IO__BLOCK_RE__T IOD_BLOCK_RES_T;


/**
 * Expected Ident Data for 1 subslot 4/4 - SubSlot
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned16 subSlotNr;                   /* Subslot Number */
        Unsigned32 subModuleIdentNr;            /* SubModule Ident Number */
} GOAL_TARGET_PACKED EXP_IDENT_DATA_SUBSLOT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * Expected Ident Data for 1 subslot 3/4 - Slot
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned16 slotNr;                      /* Slot number */
        Unsigned32 moduleIdentNr;               /* Module Ident Number */
        Unsigned16 nrOfSubSlots;                /* Number of sub slots */
        EXP_IDENT_DATA_SUBSLOT_T expIdentDataSubslot;
} GOAL_TARGET_PACKED EXP_IDENT_DATA_SLOT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * Expected Ident Data for one subslot/slot/AR
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T header;          /* block header */
        Unsigned16 nrOfApis;            /* Number Of APIs */
        Unsigned32 api;                 /* API */
        Unsigned16 nrOfSlots;           /* number of slots */
        EXP_IDENT_DATA_SLOT_T expIdentDataSlot;
} GOAL_TARGET_PACKED EXP_IDENT_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


#endif /* PN_FRAMES_H */
