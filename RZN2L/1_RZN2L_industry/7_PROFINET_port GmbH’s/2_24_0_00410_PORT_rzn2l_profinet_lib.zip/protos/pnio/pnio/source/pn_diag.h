/** @file
 *
 * @brief
 * PROFINET Diagnostic Handling
 *
 * @details
 * Handling of diagnostic informations, generation of diagnostic alarms and
 * storage or removal of diagnostic informations.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_DIAG_H
#define PN_DIAG_H

#include <pn_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* 250 msec port state change timeout */
#define PN_DIAG_PD_CHECK_TIMEOUT (250 * PN_TIMER_MSEC)

/* diagnosis handle */
#define PN_DIAG_HANDLE_ERR                          -1

/* alarm specifiers */
#define PN_DIAG_ALARM_SPEC_CHAN_DIAG                (1 << 11)
#define PN_DIAG_ALARM_SPEC_MANU_SPEC_DIAG           (1 << 12)
#define PN_DIAG_ALARM_SPEC_SUBMOD_DIAG              (1 << 13)
#define PN_DIAG_ALARM_SPEC_AR_DIAG                  (1 << 15)

/* UserStructureIdentifier */
#define PN_DIAG_USI_MANUFACT_BEG                    0x0000
#define PN_DIAG_USI_MANUFACT_END                    0x7fff
#define PN_DIAG_USI_CHAN                            0x8000
#define PN_DIAG_USI_CHAN_EXT                        0x8002
#define PN_DIAG_USI_CHAN_QUAL                       0x8003
#define PN_DIAG_USI_MAINTENANCE                     0x8100

/* diagnosis defines */
#define PN_DIAG_CHAN_NUM_SUBMODULE                  0x8000
#define PN_DIAG_CHAN_TYPE_DATA_TRANS_IMPOSSIBLE     0x8000
#define PN_DIAG_CHAN_TYPE_REMOTE_MISMATCH           0x8001

/* ChannelProperties.Type */
#define PN_DIAG_CHAN_PROP_TYPE_UNSET                0x00
#define PN_DIAG_CHAN_PROP_TYPE_01                   0x01
#define PN_DIAG_CHAN_PROP_TYPE_02                   0x02
#define PN_DIAG_CHAN_PROP_TYPE_04                   0x03
#define PN_DIAG_CHAN_PROP_TYPE_08                   0x04
#define PN_DIAG_CHAN_PROP_TYPE_16                   0x05
#define PN_DIAG_CHAN_PROP_TYPE_32                   0x06
#define PN_DIAG_CHAN_PROP_TYPE_64                   0x07

/* ChannelProperties.Accumulative */
#define PN_DIAG_CHAN_PROP_ACCUMULATIVE              (1 << 8)

/* ChannelProperties.Maintainance */
#define PN_DIAG_CHAN_PROP_MAINT_FAULT               ((0 << 9) | (0 << 10))
#define PN_DIAG_CHAN_PROP_MAINT_REQ                 (1 << 9)
#define PN_DIAG_CHAN_PROP_MAINT_DEM                 (1 << 10)
#define PN_DIAG_CHAN_PROP_MAINT_MASK                (3 << 9)
#define PN_DIAG_CHAN_PROP_MAINT_SHIFT               9

/* ChannelProperties.Specifier */
#define PN_DIAG_CHAN_PROP_SPEC_ALL_DISAPP           (0 << 11)
#define PN_DIAG_CHAN_PROP_SPEC_APPEARS              (1 << 11)
#define PN_DIAG_CHAN_PROP_SPEC_DISAPP               (2 << 11)
#define PN_DIAG_CHAN_PROP_SPEC_DISAPP_BUT_REM       (3 << 11)
#define PN_DIAG_CHAN_PROP_SPEC_MASK                 (3 << 11)

/* ChannelProperties.Direction */
#define PN_DIAG_CHAN_PROP_DIR_MANU                  (0 << 13)
#define PN_DIAG_CHAN_PROP_DIR_INPUT                 (1 << 13)
#define PN_DIAG_CHAN_PROP_DIR_OUTPUT                (2 << 13)
#define PN_DIAG_CHAN_PROP_DIR_INOUT                 (3 << 13)

/* Diagnosis: Data Transfer Impossible */
#define PN_DIAG_CHAN_EXT_TYPE_LINK_STATE_MISMATCH   0x8000
#define PN_DIAG_CHAN_EXT_TYPE_MAUTYPE_MISMATCH      0x8001

/* Diagnosis: Remote Mismatch */
#define PN_DIAG_CHAN_EXT_TYPE_STATION_NAME_MISMATCH 0x8000
#define PN_DIAG_CHAN_EXT_TYPE_PORT_NAME_MISMATCH    0x8001
#define PN_DIAG_CHAN_EXT_TYPE_NO_PEER_DETECTED      0x8005

/* MaintenanceItem Block Type */
#define PN_DIAG_BLK_TYPE_MAINT_ITEM                 0x0f00

/* MaintenanceStatus */
#define PN_DIAG_MAINT_STATUS_MAINT_REQ              1
#define PN_DIAG_MAINT_STATUS_MAINT_DEM              2


/****************************************************************************/
/* structures */
/****************************************************************************/

typedef enum {
    NO_CHAN_DIAG_DATA = 0,                      /**< don't fill chan diag data */
    FILL_CHAN_USER,                             /**< fill with user data */
    FILL_CHAN_DIAG_DATA,                        /**< fill channel diag data */
    FILL_EXT_CHAN_DIAG_DATA,                    /**< fill ext channel diag data */
} PN_DIAG_ALARM_CHAN_DATA_T;

/**< diagnosis structure */
typedef struct {

    PN_BOOL_T used;                             /**< usage indicator */
    Unsigned32 api;                             /**< API */
    Unsigned16 slot;                            /**< slot */
    Unsigned16 subSlot;                         /**< subslot */
    Unsigned16 usi;                             /**< user structure identifier */
    Unsigned16 chanNum;                         /**< channel number */
    Unsigned16 chanProp;                        /**< channel properties */
    Unsigned16 chanErrType;                     /**< channel error type */

    Unsigned16 extChanErrType;                  /**< ext chan err type */
    Unsigned32 extChanAddValue;                 /**< ext chan added value */

    Unsigned16 dataLen;                         /**< manufact spec data len */
    Unsigned8 *pData;                           /**< manufact spec data */

    Unsigned16 alarmType;                       /**< AlarmType */
    PN_DIAG_ALARM_CHAN_DATA_T fillChanData;     /**< (ext) channel data */
    PN_BOOL_T flgSendAlarm;                     /**< send diagnosis alarm */
    unsigned int prio;                          /**< priority */
    PN_BOOL_T flgSeen;                          /**< seen flag for channel procesing */
    PN_BOOL_T flgAse;                           /**< Diagnosis ASE storage flag */
} PN_DIAG_TYPE_T;


/* MaintenanceItem */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 userStructureIdentifier_be16;    /**< UserStructureIdentifier */
    BLOCK_HEADER_T blockHeader;                 /**< BlockHeader */
    Unsigned16 padding;                         /**< Padding */
    Unsigned32 maintenanceStatus_be32;          /**< MaintenanceStatus */
} GOAL_TARGET_PACKED PN_DIAG_MAINT_ITEM_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* channel diagnosis data */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 chanNum;                         /**< channel number */
    Unsigned16 chanProp;                        /**< channel properties */
    Unsigned16 errorType;                       /**< error type */
} GOAL_TARGET_PACKED PN_CHANNEL_DIAGNOSIS_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/* extended channel diagnosis data */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 chanNum;                         /**< channel number */
    Unsigned16 chanProp;                        /**< channel properties */
    Unsigned16 errorType;                       /**< error type */
    Unsigned16 extChannelErrorType;             /**< ext chan error type */
    Unsigned32 extChannelAddValue;              /**< ext chan added value */
} GOAL_TARGET_PACKED PN_DIAG_CHAN_EXT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< DiagnosisItem Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    PN_DIAG_MAINT_ITEM_T itemMaint;             /**< MaintenanceItem (optional) */
    Unsigned16 userStructureIdentifier_be16;    /**< UserStructureIdentifier */
    union {                                     /**< Diagnosis Union */
        PN_CHANNEL_DIAGNOSIS_DATA_T chan;       /**< ChannelDiagnosisData */
        PN_DIAG_CHAN_EXT_T chanExt;             /**< ExtChannelDiagnosisData */
        /* QualifiedChannelDiagnosisData */
        /* ManufacturerData */
    } diag;
} GOAL_TARGET_PACKED PN_DIAG_DIAG_ITEM_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< extended channel diagnosis state */
typedef struct {
    PN_DIAG_HANDLE_T hdl;                       /**< diagnosis handle */
    PN_BOOL_T flgSet;                           /**< set diagnosis flag */
    PN_BOOL_T flgSetCur;                        /**< current set diagnosis flag */
    PN_BOOL_T flgTs;                            /**< timestamp set flag */
    PN_TIMESTAMP_T ts;                          /**< timestamp */
    Unsigned32 addVal;                          /**< diagnosis added value */
} PN_DIAG_EXT_CHAN_STATE_T;


/**< extended channel types */
typedef enum {
    PN_DIAG_TYPE_LINK_STATE_MISMATCH,           /**< PN_DIAG_CHAN_EXT_TYPE_LINK_STATE_MISMATCH */
    PN_DIAG_TYPE_MAUTYPE_MISMATCH,              /**< PN_DIAG_CHAN_EXT_TYPE_MAUTYPE_MISMATCH */

    PN_DIAG_DATATRANS_TYPES                     /**< end marker */
} PN_DIAG_DATATRANS_TYPES_T;


/**< extended channel types */
typedef enum {
    PN_DIAG_TYPE_STATION_NAME_MISMATCH,         /**< PN_DIAG_CHAN_EXT_TYPE_STATION_NAME_MISMATCH */
    PN_DIAG_TYPE_PORT_NAME_MISMATCH,            /**< PN_DIAG_CHAN_EXT_TYPE_PORT_NAME_MISMATCH */
    PN_DIAG_TYPE_NO_PEER_DETECTED,              /**< PN_DIAG_CHAN_EXT_TYPE_NO_PEER_DETECTED */

    PN_DIAG_REMMIS_TYPES                        /**< end marker */
} PN_DIAG_REMMIS_TYPES_T;


/**< extended channel diagnosis states */
typedef struct {
    PN_DIAG_EXT_CHAN_STATE_T dataTrans[PN_DIAG_DATATRANS_TYPES]; /**< DataTransfer */
    PN_DIAG_EXT_CHAN_STATE_T remMis[PN_DIAG_REMMIS_TYPES]; /**< RemoteMismatch */
} PN_DIAG_EXT_CHAN_STATES_T;


/****************************************************************************/
/* prototypes */
/****************************************************************************/

IOD_STATUS_T PN_diagInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_diagSendProcessAlarm(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot,                         /**< subslot number */
    Unsigned16 userStructIdent,                 /**< user structure ID */
    Unsigned16 dataLen,                         /**< data length */
    Unsigned8 *pData                            /**< data pointer */
);

IOD_STATUS_T PN_diagSendModuleAlarmHelper(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot,                         /**< subslot number */
    Unsigned8 alarmType                         /**< alarm type */
);

IOD_STATUS_T PN_diagSendIoxsAlarmHelper(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot                          /**< subslot number */
);

PN_DIAG_HANDLE_T PN_diagChanDiagAdd(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot,                         /**< subslot number */
    Unsigned16 channel,                         /**< channel number */
    Unsigned16 errorNumber,                     /**< error number */
    PN_BOOL_T maintenanceRequired,              /**< maintainance required flag */
    PN_BOOL_T maintenanceDemanded,              /**< maintainance demanded flag */
    PN_BOOL_T submitAlarm                       /**< submit alarm flag */
);

IOD_STATUS_T PN_diagChanDiagRemove(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_DIAG_HANDLE_T handle,                    /**< diagnosis handle */
    PN_BOOL_T submitAlarm                       /**< submit alarm flag */
);

PN_DIAG_HANDLE_T PN_diagExtChanDiagAdd(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot,                         /**< subslot number */
    Unsigned16 channel,                         /**< channel number */
    Unsigned16 errorNumber,                     /**< error number */
    Unsigned16 extChanErrType,                  /**< extended channel error type */
    Unsigned32 extChanAddValue,                 /**< extended channel error value */
    PN_BOOL_T maintenanceRequired,              /**< maintainance required flag */
    PN_BOOL_T maintenanceDemanded,              /**< maintainance demanded flag */
    PN_BOOL_T submitAlarm,                      /**< submit alarm flag */
    Unsigned16 alarmType                        /**< alarm type */
);

PN_DIAG_HANDLE_T PN_diagGenDiagAdd(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot,                         /**< subslot number */
    Unsigned16 channel,                         /**< channel number */
    Unsigned16 userStructIdent,                 /**< user structure ID */
    Unsigned16 dataLen,                         /**< data length */
    Unsigned8 *pData,                           /**< data pointer */
    PN_BOOL_T maintenanceRequired,              /**< maintainance required flag */
    PN_BOOL_T maintenanceDemanded,              /**< maintainance demanded flag */
    PN_BOOL_T submitAlarm                       /**< submit alarm flag */
);

PN_DIAG_HANDLE_T PN_diagGetFirstEntry(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_DIAG_HANDLE_T PN_diagGetNextEntry(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_DIAG_HANDLE_T diagHandle                 /**< diagnosis handle to start from */
);

PN_DIAG_TYPE_T * PN_diagGetDiagBufPtr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_DIAG_HANDLE_T handle                     /**< diagnosis handle */
);

void PN_diagClearSubSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 api,                       /**< API */
    const Unsigned16 slot,                      /**< Slot */
    const Unsigned16 subSlot                    /**< Subslot */
);

IOD_STATUS_T PN_diagPdPortData(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_diagAvail(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 api,                       /**< API */
    const Unsigned16 slot,                      /**< slot */
    const Unsigned16 subSlot,                   /**< subslot */
    Unsigned16 *pState                          /**< submodule state */
);

void PN_diagTriggerAlarm(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    PN_DIAG_TYPE_T *pDiagBuffer;                /**< diagnosis buffers */
    PN_DIAG_EXT_CHAN_STATES_T PN_diagExtChanStates[GOAL_TARGET_ETH_PORT_COUNT]; /**< port diagnosis states */
} PN_INSTANCE_DIAG_T;


#endif /* PN_DIAG_H */
