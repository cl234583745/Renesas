/** @file
 *
 * @brief
 * PROFINET GOAL Config Manager Connector
 *
 * @details
 * Handles the PROFINET configuration via the GOAL Config Manager.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_GOAL_CM_H
#define PN_GOAL_CM_H

#include <pn_includes.h>


/****************************************************************************/
/* GOAL Configuration Management */
/****************************************************************************/
#define PN_GOAL_CM_MOD_ID       GOAL_ID_PNIO
#define PN_GOAL_CM_MOD_STR      "PNIO"

#define PN_GOAL_CM_VARS \
/*              Name                            Data type        Max. Size  Validation CB       Change CB */    \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_STATION_NAME,    GOAL_CM_GENERIC,      255,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_VENDOR_ID,       GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_DEVICE_ID,       GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_VENDOR,          GOAL_CM_GENERIC,      255,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0HWREV,        GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SWREVPREF,    GOAL_CM_UINT8,          1,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SWREVENH,     GOAL_CM_UINT8,          1,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SWREVBUGFIX,  GOAL_CM_UINT8,          1,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SWREVINTCHG,  GOAL_CM_UINT8,          1,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SWREVCNT,     GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0PROFILEID,    GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0PROFILETYPE,  GOAL_CM_UINT16,         2,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0ORDERID,      GOAL_CM_GENERIC, (20 + 1),        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM0SERIALNR,     GOAL_CM_GENERIC, (16 + 1),        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM1TAGFUNC,      GOAL_CM_GENERIC,       32,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM1TAGLOC,       GOAL_CM_GENERIC,       22,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM2DATA,         GOAL_CM_GENERIC,       16,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM3DESC,         GOAL_CM_GENERIC,       54,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IM4SIG,          GOAL_CM_GENERIC,       54,        NULL,             NULL),     \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_HOLDFCT,         GOAL_CM_UINT16,         2,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_SYSCAP,          GOAL_CM_UINT32,         4,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_PORTDESC,        GOAL_CM_GENERIC, LLDP_PORT_DESC_LEN, NULL,          PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_SYSDESC,         GOAL_CM_GENERIC, LLDP_SYS_DESC_LEN,  NULL,          PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_TXINTERV,        GOAL_CM_UINT16,         2,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_MANADDR,         GOAL_CM_UINT32,         4,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_SYSTEM_NAME,     GOAL_CM_STRING,  LLDP_SYS_NAME_LEN, NULL,           PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_IFSUBTYPE,       GOAL_CM_UINT32,         4,        NULL,             PN_lldpVarChanged), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_PDPORTDATA,      GOAL_CM_GENERIC, sizeof(PN_REC_PDPORTDATA_CFG_T), NULL, NULL), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_FS_HELLO_MODE,   GOAL_CM_UINT32,         4,        NULL,             NULL), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_FS_HELLO_INTERVAL, GOAL_CM_UINT32,       4,        NULL,             NULL), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_FS_HELLO_RETRY,  GOAL_CM_UINT32,         4,        NULL,             NULL), \
    GOAL_CM_VAR(PN_GOAL_CM_VAR_FS_HELLO_DELAY,  GOAL_CM_UINT32,         4,        NULL,             NULL)


#include <goal_cm_id.h>
GOAL_CM_VAR_IDS(PN_goalCmVarIds, PN_GOAL_CM_VARS);

#include <goal_cm_t.h>


/****************************************************************************/
/* Exported variables */
/****************************************************************************/
extern GOAL_CM_VARENTRY_T PN_goalCmVars[];      /**< list of variables */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T PN_goalCmInitPre(
    void
);


#endif /* PN_GOAL_CM_H */
