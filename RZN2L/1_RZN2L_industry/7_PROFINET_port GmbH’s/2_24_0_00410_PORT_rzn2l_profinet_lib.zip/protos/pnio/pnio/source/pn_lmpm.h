/** @file
 *
 * @brief
 * PROFINET Link Mapping Protocol Module
 *
 * @details
 * This module implements Link Mapping Protocol. It provides basic
 * functionality for receiving and sending real time cyclic and acyclic
 * frames.When PNIO frame is received, it is dispatched to the appropiate
 * module (art data, crt data or dcp) depending on the value of frame id. For
 * sending acyclic data LM_submitART function is provided. Reception of
 * periodic real time data is initiated by LM_schedule function.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_LMPM_H
#define PN_LMPM_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define LMPM_PRIQ_7                        7
#define LMPM_PRIQ_6                        6
#define LMPM_PRIQ_5                        5
#define LMPM_PRIQ_4                        4
#define LMPM_PRIQ_3                        3
#define LMPM_PRIQ_2                        2
#define LMPM_PRIQ_1                        1
#define LMPM_PRIQ_0                        0

#if !defined(ETH_HDR_LEN)
#  error "ETH_HDR_LEN not defined"
#elif !defined(VLAN_TAG_LEN)
#  error "VLAN_TAG_LEN not defined"
#endif
#define PNIO_DATA_OFF                      (ETH_HDR_LEN + VLAN_TAG_LEN)

#define LMPM_MAX_INPUTS                    8
#define LMPM_MAX_OUTPUTS                   8

/**< maximum cycle counter range (0 - 0xffff) */
#define PN_LMPM_CYCLE_CNT_MAX              (0xFFFF + 1)

/**< minimal cycle counter local vs remote difference for valid frames */
#define PN_LMPM_CYCLE_CNT_DIFF_MIN         0x1000


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T LM_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void LMPM_shutdown(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T LM_schedule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    IO_EP_T *pEP                                /**< pointer to the endpoint to be scheduled */
);

IOD_STATUS_T LM_unschedule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const IO_EP_T *pEP                          /**< Pointer to the endpoint to be unscheduled */
);

IOD_STATUS_T LM_submitART(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const IOD_CREP_T *pEP,                      /**< endpoint object */
    OAL_BUFFER_T **pBuf                         /**< send buffer ptr ref */
);

Unsigned8 LM_fillMacHdr(
    const IOD_CREP_T *pEP,                      /**< endpoint object */
    Unsigned8 *pBuf                             /**< send buffer */
);

IOD_STATUS_T LM_handleCyclic(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    OAL_BUFFER_T **pBuf                         /**< frame buffer */
);

IOD_STATUS_T LM_handleNonCyclic(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    OAL_BUFFER_T *pBuf                          /**< frame buffer */
);

IOD_STATUS_T PN_lmpmEpIdGet(
    uint16_t *pIdFrame,                         /**< frame id */
    const IO_EP_T *pEp                          /**< endpoint ptr */
);

IOD_STATUS_T PN_lmpmEpDataLenGet(
    uint16_t *pLenData,                         /**< data length ptr */
    const IO_EP_T *pEp                          /**< endpoint ptr */
);

IOD_STATUS_T PN_lmpmEpById(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    IO_EP_T **ppEp,                             /**< endpoint ptr ref */
    uint16_t idFrame                            /**< frame id */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    PN_BOOL_T lmpmInitFlag;                     /**< LMPM init flag */
    IO_EP_T *arrOutputs[LMPM_MAX_OUTPUTS];      /**< output endpoints */
} PN_INSTANCE_LMPM_T;


#endif /* PN_LMPM_H */
