/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation
 *
 * @details
 * This module integrates the Simple Network Management Protocol (SNMP)
 * implementation from port GmbH. It can be disabled and replaced by an
 * external SNMP stack.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_SNMP_H
#define PN_SNMP_H


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
PN_STATUS_T PN_snmpInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_snmpReset(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

#endif /* PN_SNMP_H */
