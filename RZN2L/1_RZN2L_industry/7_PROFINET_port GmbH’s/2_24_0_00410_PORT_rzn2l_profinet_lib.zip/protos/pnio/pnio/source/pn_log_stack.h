/** @file
 *
 * @brief
 * PROFINET Logger Runtime Stack Information
 *
 * @details
 * Logs details of stack internal structures like module configuration.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_LOG_STACK_H
#define PN_LOG_STACK_H


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
void PN_logPnioModules(
    void
);


#endif /* PN_LOG_STACK_H */
