/** @file
 *
 * @brief
 * PROFINET Physical Device Manager
 *
 * @details
 * The Physical Device Manager module contains functions to access Modules and
 * Slots of the IO Device. This includes functions to access Record data. It
 * also is responsible to process Expected submodule Block request which is
 * included in Connect service frame. It contains the central stack
 * initialisation function `IOD_Init, which has to be called by user before
 * any other Stack function.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_PDEV_H
#define PN_PDEV_H

#include <pn_includes.h>


/****************************************************************************/
/* defines */
/****************************************************************************/
/* instance */
#define PN_INSTANCE_DEFAULT                 0

/* SubmoduleState.AddInfo */
#define PN_PDEV_SUB_STATE_ADD_NONE          (0 << 0)
#define PN_PDEV_SUB_STATE_ADD_NO_TAKE       (1 << 0)

/* SubmoduleState.MaintenanceRequired */
#define PN_PDEV_SUB_STATE_MAINTREQ_NO       (0 << 4)
#define PN_PDEV_SUB_STATE_MAINTREQ_YES      (1 << 4)

/* SubmoduleState.MaintenanceDemanded */
#define PN_PDEV_SUB_STATE_MAINTDEM_NO       (0 << 5)
#define PN_PDEV_SUB_STATE_MAINTDEM_YES      (1 << 5)

/* SubmoduleState.Fault */
#define PN_PDEV_SUB_STATE_FAULT_NO          (0 << 6)
#define PN_PDEV_SUB_STATE_FAULT_YES         (1 << 6)

/* SubmoduleState.ARInfo */
#define PN_PDEV_SUB_STATE_AR_OWN            (0 << 7)
#define PN_PDEV_SUB_STATE_AR_ARP            (1 << 7)
#define PN_PDEV_SUB_STATE_AR_SO             (2 << 7)
#define PN_PDEV_SUB_STATE_AR_IOC            (3 << 7)
#define PN_PDEV_SUB_STATE_AR_IOS            (4 << 7)

/* SubmoduleState.IdentInfo */
#define PN_PDEV_SUB_STATE_IDENT_INFO(_state) (_state << 11)

/* SubmoduleState.FormatIndicator */
#define PN_PDEV_SUB_STATE_FORM_IND          (1 << 15)


#define SUBMODULE_PROP_SHARED_INPUT         (0x0001 <<  2)

#define PN_IM_1_TAG_FUNC_LEN                32
#define PN_IM_1_TAG_LOC_LEN                 22
#define PN_IM_2_DATE_LEN                    16
#define PN_IM_3_DESC_LEN                    54
#define PN_IM_4_SIG_LEN                     54

#define PN_PDEV_MASK_IM_0                   0x01
#define PN_PDEV_MASK_IM_1                   0x02
#define PN_PDEV_MASK_IM_2                   0x04
#define PN_PDEV_MASK_IM_3                   0x08
#define PN_PDEV_MASK_IM_4                   0x10


/****************************************************************************/
/* exported variables */
/****************************************************************************/
extern const PNIO_VERSION_T pnio_version;       /**< Profinet Stack Version Information */


/****************************************************************************/
/* datatypes */
/****************************************************************************/
/**< instance configuration */
struct PN_INSTANCE_CFG_T;


/**< expected subslot block */
typedef struct {
    PN_BOOL_T used;                             /**< subslot usage flag */
    Unsigned16 number;                          /**< subslot */
    Unsigned32 identNumber;                     /**< subslot ident nr */
} PN_EXP_SUBSLOT_T;


/**< expected slot block */
typedef struct {
    PN_BOOL_T used;                             /**< slot usage flag */
    Unsigned16 number;                          /**< slot */
    Unsigned32 identNumber;                     /**< module ident nr */
    PN_EXP_SUBSLOT_T *pSubslot;                 /**< subslot list */
} PN_EXP_SLOT_T;


/**< expected API block */
typedef struct {
    PN_BOOL_T used;                             /**< API usage flag */
    Unsigned32 number;                          /**< API */
    PN_EXP_SLOT_T *pSlot;                       /**< slot list */
} PN_EXP_API_T;


/**< expected module/submodule block */
typedef struct {
    PN_BOOL_T used;                             /**< AR usage flag */
    Unsigned8 AR[AR_UUID_SIZE];                 /**< AR */
    PN_EXP_API_T *pApi;                         /**< API list */
} EXP_AR_T;


/**< subhelper callback for PD_processExpSubModBlock_loop */
typedef PN_STATUS_T (*PN_PD_PESMB_CB_T)(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int sel,                                    /**< stage: API (1), submod (2), desc (3) */
    AR_T *pAR,                                  /**< pointer to AR */
    const EXPSUB_API_T *pApi,                   /**< pointer to API block */
    const EXPSUB_SUBMOD_T *pSubMod,             /**< pointer to submodule block */
    const EXPSUB_DATADESC_T *pDataDesc,         /**< pointer to data descriptor */
    ERROR_STATUS_T *pErrorResp,                 /**< pointer to error response */
    SUBMOD_T **ppHdlSubmod                      /**< submodule handle ref */
);


/****************************************************************************/
/* prototypes */
/****************************************************************************/

GOAL_STATUS_T PN_init(
    void
);

GOAL_STATUS_T PN_cfgGet(
    struct PN_INSTANCE_CFG_T **ppCfg            /**< ptr to cfg ptr */
);

GOAL_STATUS_T PN_new(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PNA_CALLBACK_FUNC funcCb                    /**< appl callback handler */
);

IOD_STATUS_T PN_pdInitNVS(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PD_getAPI(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API number */
    AP_T **ppApi                                /**< API data ptr ref */
);

RET_T PD_getIMDescr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 rec,                             /**< I&M index (0 - 4) */
    void * pImData                              /**< ptr to store I&M data */
);

RET_T PD_setIMDescr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 rec,                             /**< I&M index */
    const void * pImData                        /**< ptr to get I&M data */
);

RET_T PD_getSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< Number of API */
    Unsigned16 slotNr,                          /**< Slot number */
    SLOT_T **ppSlot                             /**< Pointer to Slot */
);

Unsigned32 PD_getSlotIdentNumber(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot                             /**< slot */
);

Unsigned32 PD_getSubSlotIdentNumber(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot                          /**< subslot */
);

Unsigned8 PD_checkLocation(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot                          /**< subslot */
);

RET_T PD_getPlugModule(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 api,                       /**< API */
    const Unsigned16 slotNr,                    /**< slot */
    MODULE_T **ppModule                         /**< ptr to store module */
);

RET_T PD_getSubSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 api,                       /**< API */
    const Unsigned16 slotNr,                    /**< slot */
    const Unsigned16 subSlotNr,                 /**< subslot */
    SUBSLOT_T **ppSubSlot                       /**< ptr to store subslot */
);

RET_T PD_getSlotSubSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 api,                       /**< API */
    const Unsigned16 slotNr,                    /**< slot */
    const Unsigned16 subSlotNr,                 /**< subslot */
    SLOT_T **ppSlot,                            /**< ptr to store slot */
    SUBSLOT_T **ppSubSlot                       /**< ptr to store subslot */
);

RET_T PD_getApiSlotSubSlot(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slotNr,                          /**< slot */
    Unsigned16 subSlotNr,                       /**< subslot */
    AP_T **ppAP,                                /**< ptr to store API */
    SLOT_T **ppSlot,                            /**< ptr to store slot */
    SUBSLOT_T **ppSubSlot                       /**< ptr to store subslot */
);

IOD_STATUS_T PD_expRemoveAR(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR                                   /**< AR pointer */
);

PN_BOOL_T PD_expIsElementLocked(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< own AR, will be ignored */
    Unsigned32 iApi,                            /**< API */
    Unsigned16 iSlot,                           /**< slot */
    Unsigned16 iSubSlot,                        /**< subslot */
    int iLevel                                  /**< deepness level (0 = AR .. 3 = SubSlot) */
);

Unsigned16 PD_createModDiffBlock(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< AR */
    MOD_DIFF_BLOCK_T *pModDiffBlock,            /**< buffer to store ModuleDiffBlock */
    ERROR_STATUS_T *pErrorStatus                /**< ErrorStatus */
);

Unsigned16 PD_createExpIdentDataBlock(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< AR */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned16 index,                           /**< index */
    EXP_IDENT_DATA_T *pExpIdentDataBlock        /**< ptr to store block */
);

IOD_STATUS_T PD_processExpSubModBlock(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< pointer to AR */
    const EXP_SUBMOD_BLOCK_T *pExpSubModBlock,  /**< expected submodule block */
    ERROR_STATUS_T *pErrorResp                  /**< error response */
);

IOD_STATUS_T PD_getModuleByIdentNr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 moduleIdentNr,             /**< module ident nr */
    MODULE_T **ppModule                         /**< ptr to store module */
);

IOD_STATUS_T PD_getSubModuleByIdentNr(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned32 moduleIdentNr,             /**< module ident nr */
    const Unsigned32 subModuleIdentNr,          /**< submodule ident nr */
    SUBMOD_T **ppSubModule                      /**< ptr to store submodule */
);

IOD_STATUS_T PD_updateSlotSubslotState(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slotNr                           /**< slot */
);

IOD_STATUS_T PD_clearAR(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR                                   /**< pointer to AR */
);

void PN_pdClearIM(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_pnioLoop(
    void
);

void PN_pdevStart(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_pdevStop(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_callbackSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PNA_CALLBACK_FUNC cb                        /**< callback function */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
extern struct PN_INSTANCE_CFG_T PN_cfg;         /**< instance configuration */

typedef struct {
    EXP_AR_T *pExpectedARs;                     /**< exp submod block storage */
    GOAL_STAGE_HANDLER_T stageModules;          /**< modules ready stage */

    PN_BOOL_T IOD_InitDone;                     /**< stack start indicator */
    PNA_CALLBACK_FUNC PNA_callback;             /**< app callback function */

    int PN_flagShutdown;                        /**< global shutdown flag */
    PN_BOOL_T PN_pdevGlobalDisable;             /**< global stack enable */
} PN_INSTANCE_PDEV_T;


#endif /* PN_DEV_H */
