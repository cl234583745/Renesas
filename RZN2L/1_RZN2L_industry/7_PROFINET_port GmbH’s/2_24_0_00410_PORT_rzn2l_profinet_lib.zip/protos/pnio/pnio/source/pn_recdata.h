/** @file
 *
 * @brief
 * PROFINET Record Data Handling
 *
 * @details
 * This module contains the implementation of record data handling.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_RECDATA_H
#define PN_RECDATA_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define IODWriteReqHeader       0x0008U
#define IODReadReqHeader        0x0009U
#define IM0Data             0x0020U
#define IM1Data             0x0021U
#define IM2Data             0x0022U
#define IM3Data             0x0023U
#define IM4Data             0x0024U
#define PDNCDataCheck           0x0230U
#define ARFSUDataAdjust         0x0609U
#define BLOCK_TYPE_EXP_IDENT_DATA       0x0012
#define BLOCK_TYPE_API_DATA     0x001A
#define PN_RECDATA_PORTID_LEN   255
#define PN_BUSY_INDEX_UNDEFINED -1
#define PN_LEN_SEND_NO_RESPONSE 0xffff


/* record data block */
#define PN_REC_BLK_TYPE_DIAGNOSISDATA                               0x0010
#define PN_REC_BLK_TYPE_SUBSTITUTEVALUE                             0x0014
#define PN_REC_BLK_TYPE_RECINPDATAOBJELEM                           0x0015
#define PN_REC_BLK_TYPE_RECOUTDATAOBJELEM                           0x0016
#define PN_REC_BLK_TYPE_ARDATA                                      0x0018
#define PN_REC_BLK_TYPE_LOGBOOKDATA                                 0x0019
#define PN_REC_BLK_TYPE_PDPORTDATACHECK                             0x0200
#define PN_REC_BLK_TYPE_PDEVDATA                                    0x0201
#define PN_REC_BLK_TYPE_PDPORTDATAADJUST                            0x0202
#define PN_REC_BLK_TYPE_MRP_PDINTERFACEDATAADJUST                   0x0211
#define PN_REC_BLK_TYPE_MRP_PDINTERFACEDATAREAL                     0x0212
#define PN_REC_BLK_TYPE_MRP_PDINTERFACEDATACHECK                    0x0213
#define PN_REC_BLK_TYPE_MRP_PDPORTDATAADJUST                        0x0214
#define PN_REC_BLK_TYPE_MRP_PDPORTDATAREAL                          0x0215
#define PN_REC_BLK_TYPE_MRP_MANAGERPARAMS                           0x0216
#define PN_REC_BLK_TYPE_MRP_CLIENTPARAMS                            0x0217
#define PN_REC_BLK_TYPE_MRP_RINGSTATEDATA                           0x0219
#define PN_REC_BLK_TYPE_PDINTERFACEADJUST                           0x0250
#define PN_REC_BLK_TYPE_CHK_PEERS                                   0x020A
#define PN_REC_BLK_TYPE_CHK_MAUTYPE                                 0x020C
#define PN_REC_BLK_TYPE_PDINTERFACEMRPDATAADJUST                    0x0211
#define PN_REC_BLK_TYPE_CHK_LINKSTATE                               0x021C
#define PN_REC_BLK_TYPE_ADJ_MAUTYPE                                 0x020E
#define PN_REC_BLK_TYPE_ADJ_LINKSTATE                               0x021B
#define PN_REC_BLK_TYPE_ADJ_PEERTOPEER                              0x0224
#define PN_REC_BLK_TYPE_ADJ_DCP                                     0x0225
#define PN_REC_BLK_TYPE_PDPORTSTATISTIC                             0x0251
#define PN_REC_BLK_TYPE_MUL_BLK_HDR                                 0x0400
#define PN_REC_BLK_TYPE_FSHELLOBLOCK                                0x0600
#define PN_REC_BLK_TYPE_PDINTERFACEFSUDATAADJUST                    0x0608
#define PN_REC_BLK_TYPE_RES                                         0x8000
#define PN_REC_BLK_TYPE_WRITE_RES                                   0x8008
#define PN_REC_BLK_TYPE_READ_RES                                    0x8009
#define PN_REC_BLK_TYPE_ALARMCRBLOCK_RES                            0x8103
#define PN_REC_BLK_TYPE_ARSERVERBLK_RES                             0x8106

/* block versions */
#define PN_REC_BLK_VER_HIGH_1                                       1
#define PN_REC_BLK_VER_LOW_0                                        0
#define PN_REC_BLK_VER_LOW_1                                        1

/* record data indexes */
#define PN_REC_IDX_IM_0                                             0xaff0
#define PN_REC_IDX_IM_1                                             0xaff1
#define PN_REC_IDX_IM_2                                             0xaff2
#define PN_REC_IDX_IM_3                                             0xaff3
#define PN_REC_IDX_IM_4                                             0xaff4
#define PN_REC_IDX_REALIDENTIFICATIONDATA_FOR_ONE_SUBSLOT           0x8001
#define PN_REC_IDX_SUBSTITUTEVALUE_FOR_ONE_SUBSLOT                  0x801e
#define PN_REC_IDX_PDPORTDATACHECK_ONE_SUBSLOT                      0x802b
#define PN_REC_IDX_RECINPDATAOBJELEM_FOR_ONE_SUBSLOT                0x8028
#define PN_REC_IDX_RECOUTDATAOBJELEM_FOR_ONE_SUBSLOT                0x8029
#define PN_REC_IDX_PDPORTDATAADJUST_ONE_SUBSLOT                     0x802f
#define PN_REC_IDX_PDINTERFACE_MRP_DATA_REAL_FOR_ONE_SUBSLOT        0x8050
#define PN_REC_IDX_PDINTERFACE_MRP_DATA_CHECK_FOR_ONE_SUBSLOT       0x8051
#define PN_REC_IDX_PDINTERFACE_MRP_DATA_ADJUST_FOR_ONE_SUBSLOT      0x8052
#define PN_REC_IDX_PDPORT_MRP_DATA_ADJUST_FOR_ONE_SUBSLOT           0x8053
#define PN_REC_IDX_PDPORT_MRP_DATA_REAL_FOR_ONE_SUBSLOT             0x8054
#define PN_REC_IDX_PDNCDATACHECK_FOR_ONE_SUBSLOT                    0x8070
#define PN_REC_IDX_PDINTERFACEADJUST_FOR_ONE_SUBSLOT                0x8071
#define PN_REC_IDX_PDPORTSTATISTIC_FOR_ONE_SUBSLOT                  0x8072
#define PN_REC_IDX_PDINTERFACEDATAREAL_FOR_ONE_SUBSLOT              0x8080
#define PN_REC_IDX_PDINTERFACEFSUDATAADJUST                         0x8090
#define PN_REC_IDX_REALIDENTIFICATIONDATA_FOR_ONE_SLOT              0xc001
#define PN_REC_IDX_REALIDENTIFICATIONDATA_FOR_ONE_AR                0xe001
#define PN_REC_IDX_WRITEMULTIPLE                                    0xe040
#define PN_REC_IDX_ARFSUDATAADJUST_FOR_ONE_AR                       0xe050
#define PN_REC_IDX_REALIDENTIFICATIONDATA_FOR_ONE_API               0xf000
#define PN_REC_IDX_ARDATA_FOR_ONE_API                               0xf020
#define PN_REC_IDX_ARDATA                                           0xf820
#define PN_REC_IDX_LOGBOOKDATA                                      0xf830
#define PN_REC_IDX_PDEVDATA                                         0xf831
#define PN_REC_IDX_IM_0_FILTER_DATA                                 0xf840
#define PN_REC_IDX_PDREALDATA                                       0xf841
#define PN_REC_IDX_PDEXPECTEDDATA                                   0xf842
#define PN_REC_IDX_AUTOCONFIGURATION                                0xf850
#define PN_REC_IDX_CMSM_TRIGGER                                     0xfbff

/* PeerToPeerBoundary coding */
#define PN_REC_P2P_LLDP_MASK                                        0x01

/* SubstitutionMode */
#define PN_REC_SUBMODE_ZERO                                         0x0000
#define PN_REC_SUBMODE_LAST_VALUE                                   0x0001
#define PN_REC_SUBMODE_REPLACEMENT_VALUE                            0x0002

/* SubstituteDataValid */
#define PN_REC_SUBST_DATA_VALID_FALSE                               0
#define PN_REC_SUBST_DATA_VALID_TRUE                                (1 << 7)

/* Length Defines */
#define PN_REC_PEER_PORT_NAME_LEN                                   14
#define PN_REC_PEER_STATION_NAME_LEN                                255

/* MultipleInterfaceMode */
#define PN_REC_MULTIIFACE_MODE_NAME_OF_DEVICE                       (1 << 0)

/* macro for filling errorStatus structure */
#define SET_ERROR_STATUS(a, b, c, d) PN_PNIO_STATUS_SET(pErrorStatus, a, b, c, d)

/* set PROFINET status to given structure */
#define PN_PNIO_STATUS_SET(x, a, b, c, d)           \
    do {                                            \
        if (NULL == (void *) x) {                   \
            goal_logErr("status pointer is null");  \
            break;                                  \
        }                                           \
        (x)->errorCode = a;                         \
        (x)->errorDecode = b;                       \
        (x)->errorCode1 = c;                        \
        (x)->errorCode2 = d;                        \
    } while (0)


#define PN_REC_ADJ_DCP_MASK             0x03    /**< DCPBoundary mask */
#define PN_REC_ADJ_DCP_IDENT            0x01    /**< DCPBoundary Ident Egress Filter */
#define PN_REC_ADJ_DCP_HELLO            0x02    /**< DCPBoundary Hello Egress Filter */

#define PN_REC_IOCR_PROP_FRAMEID_RANGE_6    0x02 /**< IOCR FrameID Range 6 */

/* PDPortStatistics CounterStatus invalid flags */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFINOCTETS 0x01 /**< CounterStatus IfInOctets Invalid flag */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFOUTOCTETS 0x02 /**< CounterStatus IfOutOctets Invalid flag */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFINDISCARDS 0x04 /**< CounterStatus IfInDiscards Invalid flag */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFOUTDISCARDS 0x8 /**< CounterStatus IfOutDiscards Invalid flag */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFINERRORS 0x10 /**< CounterStatus IfInErrors Invalid flag */
#define PN_REC_PDPORTSTATISTIC_COUNTERSTATUS_INVALID_IFOUTERRORS 0x20 /**< CounterStatus IfOutErrors Invalid flag */


/****************************************************************************/
/* Data types */
/****************************************************************************/
/**
 * ARFSU payload types
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned32 helloMode_be32;
        Unsigned32 helloInterval_be32;
        Unsigned32 helloRetry_be32;
        Unsigned32 helloDelay_be32;
} GOAL_TARGET_PACKED FS_HELLO_BLOCK_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned16 padding;
        Unsigned32 mode;
        Unsigned8 uuid[16];
} GOAL_TARGET_PACKED FS_PARAMETER_BLOCK_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned16 padding;
        Unsigned8 data[FLA_LENGTH];
} GOAL_TARGET_PACKED FASTSTARTUP_BLOCK_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * ARFSU Data Adjust block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T subHeader;
        union {
                FS_PARAMETER_BLOCK_T fsParamBlock;
                FASTSTARTUP_BLOCK_T fastStartupBlock;
        } subData;
} GOAL_TARGET_PACKED ARFSU_DATA_ADJUST_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned16 padding1;
        BLOCK_HEADER_T subHeader;
        Unsigned16 padding2;
        union {
                FASTSTARTUP_BLOCK_T fastStartupBlock;
                FS_HELLO_BLOCK_T    helloBlock;
        } subData;
} GOAL_TARGET_PACKED PDFSU_DATA_ADJUST_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * PDNC DataCheck block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        Unsigned32 mainReqDropBudget;
        Unsigned32 mainDemDropBudget;
        Unsigned32 errorDropBudget;
} GOAL_TARGET_PACKED PDNC_DATACHECK_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * IOD Read Response IM0FilterData
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 nrOfApis;
        Unsigned32 api;
        Unsigned16 nrOfModules;

        Unsigned16 slotNumber;
        Unsigned32 moduleIdentNumber;
        Unsigned16 numberOfSubModules;
        Unsigned16 subSlotNumber;
        Unsigned32 subModuleIdentNumber;
} GOAL_TARGET_PACKED IM0_FILTERDATA_SUBMODULE_T;
GOAL_TARGET_PACKED_STRUCT_POST


typedef IM0_FILTERDATA_SUBMODULE_T IM0_FILTERDATA_DEVICE_T;


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        IM0_FILTERDATA_SUBMODULE_T subModule;
        IM0_FILTERDATA_DEVICE_T device;
} GOAL_TARGET_PACKED IM0_FILTERDATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * IOD Read Response IMData
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 vendorId_be16;
        Unsigned8 orderID[PN_LEN_ORDER_ID];
        Unsigned8 imSerialNumber[16];
        Unsigned16 imHardwareRevision_be16;
        Unsigned8 imRevisionPrefix;
        Unsigned8 imSWRevisionFunctionalEnhancement;
        Unsigned8 imSWRevisionBugFix;
        Unsigned8 imSWRevisionInternalChange;
        Unsigned16 imRevisionCounter_be16;
        Unsigned16 imProfileID_be16;
        Unsigned16 imProfileSpecificType_be16;
        Unsigned8 imVersionMajor;
        Unsigned8 imVersionMinor;
        Unsigned16 imSupported;
} GOAL_TARGET_PACKED IM0_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned8 IM_TagFunction[32];
        Unsigned8 IM_TagLocation[22];
} GOAL_TARGET_PACKED IM1_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned8 IM_Date[16];
} GOAL_TARGET_PACKED IM2_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned8 IM_Descriptor[54];
} GOAL_TARGET_PACKED IM3_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned8 IM_Signature[54];
} GOAL_TARGET_PACKED IM4_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * common IOD header
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 seqNumber;
        Unsigned8 ARUUID[16];
        Unsigned32 api;
        Unsigned16 slot;
        Unsigned16 subSlot;
        Unsigned16 padding1;
        Unsigned16 index;
        Unsigned32 recordDataLength;
} GOAL_TARGET_PACKED IOD_HEADER_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        IOD_HEADER_T header;
        Unsigned8 targetARUUID[16];
} GOAL_TARGET_PACKED IOD_READ_REQ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * IOD Write Request block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T dataHeader;
        union {
                IM1_DATA_T imData;
                PDFSU_DATA_ADJUST_T  pdiFSUdataAdjust;
        } payload;
} GOAL_TARGET_PACKED IOD_WRITE_REQ_PAYLOAD_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        union {
                IOD_WRITE_REQ_PAYLOAD_T body;
                Unsigned8 userSpecData[FLA_LENGTH];
        } data;
} GOAL_TARGET_PACKED IOD_WRITE_REQ_BODY_T;
GOAL_TARGET_PACKED_STRUCT_POST


GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        IOD_HEADER_T header;
        Unsigned16 additionalVal1;
        Unsigned16 additionalVal2;
        ERROR_STATUS_T errorStatus;
        Unsigned8 padding[16];
} GOAL_TARGET_PACKED IOD_WRITE_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * IOD Read Response RealIdentificationData
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 nrOfApis;
        Unsigned32 api;
        Unsigned16 numberOfSlots;
        Unsigned8 slotDescrData[FLA_LENGTH];
} GOAL_TARGET_PACKED REAL_IDENTIFICATION_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RealIdentificationData Slot */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 slotNr_be16;                     /**< SlotNumber */
    Unsigned32 modIdentNr_be32;                 /**< ModuleIdentNumber */
    Unsigned16 nrOfSubSlots_be16;               /**< NumberOfSubslots */
} GOAL_TARGET_PACKED PN_REC_REAL_IDENTIFICATION_SLOT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RealIdentificationData Subslot */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 subSlotNr_be16;                  /**< SubslotNumber */
    Unsigned32 subModIdentNr_be32;              /**< SubmoduleIdentNumber */
} GOAL_TARGET_PACKED PN_REC_REAL_IDENTIFICATION_SUBSLOT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< LogBookData */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T hdr;                         /**< header */
    Unsigned64 actualLocTs_be64;                /**< ActualLocalTimeStamp */
    Unsigned16 nrOfLogEntries_be16;             /**< NumberOfLogEntries */
} GOAL_TARGET_PACKED PN_REC_LOG_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< LogBookData Entry */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned64 LocalTimeStamp_be64;             /**< LocalTimeStamp */
    UUID_T arUUID;                              /**< ARUUID */
    ERROR_STATUS_T pnioStatus;                  /**< PNIOStatus */
    Unsigned32 entryDetail_be32;                /**< EntryDetail */
} GOAL_TARGET_PACKED LOG_DATA_ENTRY_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * API Data Block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 nrOfApis;
        Unsigned32 api;
} GOAL_TARGET_PACKED API_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< SubstituteDataObjectElement */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
                                                /*   Data */
    Unsigned8 subDataValid;                     /**< SubstituteDataValid */
} GOAL_TARGET_PACKED PN_REC_SUBSTITUTE_DATAOBJELEM_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< SubstituteDataItem */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 iocs;                             /**< IOCS */
                                                /**< SubstituteDataObjectElement */
} GOAL_TARGET_PACKED PN_REC_SUBSTITUTE_DATAITEM_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< SubstituteValue */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHdr;                      /**< header */
    Unsigned16 subMode_be16;                    /**< SubstitutionMode */
    PN_REC_SUBSTITUTE_DATAITEM_T dataItem;      /**< SubstituteDataItem */
} GOAL_TARGET_PACKED PN_REC_SUBSTITUTE_VALUE_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RecordInputDataObjectElement (0x8028) */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHdr;                      /**< header */
    Unsigned8 lengthIocs;                       /**< LengthIOCS */
    Unsigned8 iocs;                             /**< IOCS */
    Unsigned8 lengthIops;                       /**< LengthIOPS */
    Unsigned8 iops;                             /**< IOPS */
    Unsigned16 lengthData;                      /**< LengthData */
                                                /*   Data */
} GOAL_TARGET_PACKED PN_REC_RECINPDATAOBJ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RecordOutputDataObjectElement (0x8029) */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHdr;                      /**< header */
    Unsigned16 subActFlag;                      /**< SubstituteActiveFlag */
    Unsigned8 lengthIocs;                       /**< LengthIOCS */
    Unsigned8 lengthIops;                       /**< LengthIOPS */
    Unsigned16 lengthData;                      /**< LengthData */
    Unsigned8 iocs;                             /**< IOCS */
                                                /*   Data */
                                                /*   IOPS */
                                                /*   SubstituteValue */
} GOAL_TARGET_PACKED PN_REC_RECOUTDATAOBJ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RecordOutputDataObjectElement IOPS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 iops;                             /**< IOPS */
} GOAL_TARGET_PACKED PN_REC_RECOUTDATAOBJ_IOPS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * Port data block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        BLOCK_HEADER_T blockHeader;
        Unsigned16 padding;
        Unsigned16 slot;
        Unsigned16 subSlot;
} GOAL_TARGET_PACKED PORT_DATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**
 * IOD Read Response block
 */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
        IOD_HEADER_T header;
        Unsigned16 additionalVal1;
        Unsigned16 additionalVal2;
        Unsigned8 padding[20];
        union {
                unsigned char data;
                IM0_FILTERDATA_T im0FilterData;
                IM0_DATA_T imData;
                REAL_IDENTIFICATION_T realIdentData;
                IOD_WRITE_REQ_PAYLOAD_T pdfsuData;
                Unsigned8 userSpecData[FLA_LENGTH];
                PN_REC_LOG_DATA_T logData;
                EXP_IDENT_DATA_T expIdentData;
                API_DATA_T apiData;
                PORT_DATA_T portData;
        } data;
} GOAL_TARGET_PACKED IOD_READ_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< MultipleBlockHeader */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T pBlkHdr;                     /**< BlockHeader */
    Unsigned16 padding;                         /**< padding */
    Unsigned32 api_be32;                        /**< API */
    Unsigned16 slot_be16;                       /**< slot */
    Unsigned16 subSlot_be16;                    /**< subslot */
} GOAL_TARGET_PACKED PN_REC_MULTIPLE_BLK_HDR_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< Generic Read Handler Function */
typedef RET_T (*PN_REC_TABLE_READ_FUNC_T)(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    unsigned char *pData,                       /**< data ptr */
    Unsigned16 *pDataLen,                       /**< data length */
    Unsigned32 maxDataLen,                      /**< max data length */
    ERROR_STATUS_T *errorStatus,                /**< error status */
    AR_T *pAR,                                  /**< AR ptr */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    Unsigned16 index                            /**< index */
);

/**< Generic Read Table Entry */
typedef struct {
    Unsigned16 index;                           /**< record index */
    PN_BOOL_T targetArUuid;                     /**< TargetARUUID must-be-set flag */
    PN_REC_TABLE_READ_FUNC_T func;              /**< record handler */
} PN_REC_TABLE_READ_T;

/**< Remote interface specific entries of busy request */
typedef struct {
    Unsigned32 *pSequenceNumber;                /**< pointer to sequence number */
} BUSY_RECORD_REQ_REMOTE_DATA_T;

/**
 * Store busy request data
 */
typedef struct {
    PN_BOOL_T used;                             /**< usage flag */
    void *pSessionRemote;                       /**< remote session info handle */
    BUSY_RECORD_REQ_REMOTE_DATA_T remoteData;   /**< data of remote interface */
    PN_WRITE_INFO_T *pWriteInfo;                /**< information for write operation (NULL for everything except write) */
    AR_T *pAR;                                  /**< AR handle */
    Unsigned8 *pResponse;                       /**< response buffer */
    ERROR_STATUS_T *pResponseStatus;            /**< error status field in response buffer */
    Unsigned16 seqNumber;                       /**< sequence number */
    Unsigned32 api;                             /**< API */
    Unsigned16 slot;                            /**< slot */
    Unsigned16 subSlot;                         /**< subslot */
    Unsigned16 index;                           /**< index */
    Unsigned32 maxDataSize;                     /**< maximum data size */
} BUSY_RECORD_REQ_T;


/**< CheckPeers Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 numOfPeers;                       /**< number of peers */
} GOAL_TARGET_PACKED PN_REC_CHECKPEERS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< CheckMAUType Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 mauType_be16;                    /**< MAU type */
} GOAL_TARGET_PACKED PN_REC_CHECKMAUTYPE_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< CheckLinkState Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 linkState_be16;                  /**< link state */
} GOAL_TARGET_PACKED PN_REC_CHECKLINKSTATE_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDInterfaceMrpDataAdjust (BlockVersionLow 1) Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 padding0;                         /**< 1 byte padding */
    Unsigned8 mrpInstance;                      /**< MRP instance */
    Unsigned8 mrpDomainUuid[LEN_UUID];          /**< MRP Domain UUID */
    Unsigned16 mrpRole_be16;
    Unsigned16 padding_be16;                    /**< 2 byte padding */
    Unsigned8 mrpLengthDomainName;              /**< var. length, 0x03 if max. number of neighbours */
    Unsigned8 mrpDomainName[3];                 /**< Domain Name */
} GOAL_TARGET_PACKED PN_REC_PDINTERFACEMRPDATAADJUST_BLKVERS1;
GOAL_TARGET_PACKED_STRUCT_POST


/**< AdjustMAUType Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 padding;                         /**< padding */
    Unsigned16 mauType_be16;                    /**< MAU type */
    Unsigned16 adjProps_be16;                   /**< adjust properties */
} GOAL_TARGET_PACKED PN_REC_ADJMAUTYPE_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< AdjustLinkState Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 padding;                         /**< padding */
    Unsigned16 linkState_be16;                  /**< link state */
    Unsigned16 adjProps_be16;                   /**< adjust properties */
} GOAL_TARGET_PACKED PN_REC_ADJLINKSTATE_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< AdjustPeerToPeerBoundary Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 padding;                         /**< padding */
    Unsigned32 peerToPeer_be32;                 /**< PeerToPeerBoundary */
    Unsigned16 adjProps_be16;                   /**< adjust properties */
} GOAL_TARGET_PACKED PN_REC_ADJPEERTOPEER_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< AdjustDCPBoundary Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 padding;                         /**< padding */
    Unsigned32 dcp_be32;                        /**< DCPBoundary */
    Unsigned16 adjProps_be16;                   /**< adjust properties */
} GOAL_TARGET_PACKED PN_REC_ADJDCP_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDPortData Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T header;                      /**< header */
    Unsigned16 padding;                         /**< padding */
    Unsigned16 slot_be16;                       /**< slot */
    Unsigned16 subSlot_be16;                    /**< subslot */
} GOAL_TARGET_PACKED PN_REC_PDPORTDATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDPortDataCheck/Adjust Settings Interface Helper Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    PN_BOOL_T flag;                             /**< usage flag */
    Unsigned16 val;                             /**< value */
} GOAL_TARGET_PACKED PN_REC_PDPORTDATA_CFG_SUB_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDPortDataCheck/Adjust Settings Interface Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    PN_REC_PDPORTDATA_CFG_SUB_T checkMauType;   /**< CheckMAUType */
    PN_REC_PDPORTDATA_CFG_SUB_T checkLinkState; /**< CheckLinkState */

    struct {
        PN_BOOL_T flag;                         /**< usage flag */
        Unsigned8 numOfPeers;                   /**< NumberOfPeers */
        Unsigned8 peerPortNameLen;              /**< PeerPortName length */
        Unsigned8 peerPortName[PN_REC_PEER_PORT_NAME_LEN]; /**< PeerPortName */
        Unsigned8 peerStationNameLen;           /**< PeerStationName length */
        Unsigned8 peerStationName[PN_REC_PEER_STATION_NAME_LEN]; /**< PeerStationName */
    } checkPeers;

    PN_REC_PDPORTDATA_CFG_SUB_T adjustMauType;  /**< AdjustMAUType */
    PN_REC_PDPORTDATA_CFG_SUB_T adjustLinkState;/**< AdjustLinkState */
    PN_REC_PDPORTDATA_CFG_SUB_T adjustPeerToPeer; /**< AdjustLinkState */
    PN_REC_PDPORTDATA_CFG_SUB_T adjustDcp;      /**< AdjustDCPBoundary */
} GOAL_TARGET_PACKED PN_REC_PDPORTDATA_CFG_PORT_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDPortDataAdjust Settings Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    PN_REC_PDPORTDATA_CFG_SUB_T adjustIface;    /**< AdjustInterface */
    PN_REC_PDPORTDATA_CFG_PORT_T ports[GOAL_TARGET_ETH_PORT_COUNT];
} GOAL_TARGET_PACKED PN_REC_PDPORTDATA_CFG_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDInterfaceAdjust Structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T header;                      /**< header */
    Unsigned16 padding;                         /**< padding */
    Unsigned32 mulIfaceMode_be32;               /**< MultipleInterfaceMode */
                                                /*   padding */
} GOAL_TARGET_PACKED PN_REC_PDINTERFACEADJUST_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PDPortStatistic Structure (0x8072) */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T blkHdr;                      /**< header */
    Unsigned16 counterStatus;                   /**< CounterStatus or padding */
    Unsigned32 ifInOctets_be32;                 /**< ifInOctets */
    Unsigned32 ifOutOctets_be32;                /**< ifOutOctets */
    Unsigned32 ifInDiscards_be32;               /**< ifInDiscards */
    Unsigned32 ifOutDiscards_be32;              /**< ifOutDiscards */
    Unsigned32 ifInErrors_be32;                 /**< ifInErrors */
    Unsigned32 ifOutErrors_be32;                /**< ifOutErrors */
                                                /*   padding to Unsigned32 align */
} GOAL_TARGET_PACKED PN_REC_PDPORTSTATISTIC;
GOAL_TARGET_PACKED_STRUCT_POST


/**< PdevData (0xf831) */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T hdrBlk;                      /**< BlockHeader */
    Unsigned16 padding;                         /**< 2x Padding */
} GOAL_TARGET_PACKED PN_REC_PDEVDATA_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T PN_recdataInitPre(
    void
);

IOD_STATUS_T RD_processRecWrite(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int idxRec,                                 /**< write request index */
    const IOD_HEADER_T *pWriteReqHdr,           /**< write request header */
    const IOD_WRITE_REQ_BODY_T *pWriteReqBody   /**< write request body */
);

PN_STATUS_T RD_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_recPDPortDataReset(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_recPDPortDataParamStart(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_recPDPortDataParamEnd(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_recHeaderPrepare(
    BLOCK_HEADER_T *pHdr,                       /**< BlockHeader ptr */
    Unsigned16 type,                            /**< block type */
    Unsigned8 verHigh,                          /**< block version high */
    Unsigned8 verLow                            /**< block version low */
);

void PN_recHeaderLength(
    BLOCK_HEADER_T *pHdr,                       /**< BlockHeader ptr */
    Unsigned16 size                             /**< block size */
);

uint16_t PN_recMultipleBlockHeaderPrepare(
    PN_REC_MULTIPLE_BLK_HDR_T *pHdr,            /**< MultipleBlockHeader ptr */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot number */
    Unsigned16 subSlot                          /**< subslot number */
);

void PN_recMultipleBlockHeaderLength(
    PN_REC_MULTIPLE_BLK_HDR_T *pHdr,            /**< MultipleBlockHeader ptr */
    Unsigned16 size                             /**< block size */
);

IOD_STATUS_T PN_recBusyGet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int index,                                  /**< busy record index */
    BUSY_RECORD_REQ_T **rec                     /**< busy record ptr */
);

PN_STATUS_T PN_recSaveBusyRecordReq(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int *pHdl,                                  /**< busy handle */
    const IOD_HEADER_T *pReq,                   /**< request data */
    void *pSessionRemote,                       /**< remote session info */
    Unsigned32 *pSequenceNumber,                /**< pointer to sequence number */
    PN_WRITE_INFO_T *pWriteInfo,                /**< information for write operation (NULL for everything except write) */
    AR_T *pAR,                                  /**< application relation */
    Unsigned8 *pResp,                           /**< response buffer */
    Unsigned32 recordDataLen,                   /**< record data length */
    ERROR_STATUS_T *pResponseStatus             /**< PROFINET status field in response buffer */
);

PN_STATUS_T IOD_finishReadRecord(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int handle,                                 /**< record data busy index */
    const ERROR_STATUS_T *pStatusPnio,          /**< PROFINET status */
    const Unsigned8 *pRecordData,               /**< user supplied record data */
    Unsigned16 recordLength,                    /**< user supplied data length */
    Unsigned32 numSeq                           /**< sequence number */
);

PN_STATUS_T IOD_finishWriteRecord(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    int handle,                                 /**< record data busy index */
    const ERROR_STATUS_T *pStatusPnio,          /**< PROFINET status */
    Unsigned32 numSeq                           /**< sequence number */
);

PN_STATUS_T PN_recProcessRecRead(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const IOD_HEADER_T *pReadReqHdr,            /**< read request header */
    IOD_READ_RES_T *pReadRes,                   /**< target frame */
    Unsigned16 *pOutDataLen,                    /**< data length */
    Unsigned16 outBufSize,                      /**< size of output buffer (i.e. maximum length of output data) */
    ERROR_STATUS_T *pErrorStatus,               /**< error status */
    void *pSessionRemote,                       /**< remote session info */
    Unsigned32 *pSequenceNumber,                /**< pointer to sequence number */
    AR_T *pAR,                                  /**< AR pointer */
    PN_BOOL_T flgReadImpl                       /**< ImplicitRead flag */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    BUSY_RECORD_REQ_T *pBusyRecordRequests;     /**< busy record storage with spare buffer */
    PN_BOOL_T PN_recPDPortDataActive;           /**< PDPortDataAdjust flag */
    PN_BOOL_T PN_recPDPortDataNotFirst;         /**< PDPortDataAdjust init flag */
    PN_BOOL_T PN_recPDPortDataCfgWrite;         /**< write config flag */
    PN_REC_PDPORTDATA_CFG_T PN_recPDPortDataCfg; /**< PDPortDataAdjust settings */
} PN_INSTANCE_RECDATA_T;


#endif /* PN_RECDATA_H */
