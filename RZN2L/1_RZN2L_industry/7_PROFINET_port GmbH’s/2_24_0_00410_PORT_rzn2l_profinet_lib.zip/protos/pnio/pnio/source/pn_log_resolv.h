/** @file
 *
 * @brief
 * PROFINET Logger - Define Name Resolver
 *
 * @details
 * This helper resolves define names to strings.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_LOG_RESOLV_H
#define PN_LOG_RESOLV_H

#include <pn_includes.h>

#if CONFIG_LOGGING == 1
#if CONFIG_LOGGING_NAME_RESOLVER == 1

typedef enum {
    PN_LOG_RES_TYPE_APP_CALLBACK = 0,
    PN_LOG_RES_TYPE_MEM_QUEUES,
    PN_LOG_RES_TYPE_USAGE_TYPES,
} LOG_resType;


/**< generic convert function typedef */
typedef const char * (*LOG_convGeneric)(void *);

/**< ID and its string representation */
typedef struct {
    Unsigned32 id;
    const char *name;
    const LOG_convGeneric conv;
} LOG_MAP_ID_T;

#define LOG_MAP_ID_ELEM(id, conv) { id, #id, conv }


const char * LOG_resKeyVal(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    LOG_resType type,                           /**< key/value type */
    Unsigned32 keyId,                           /**< key ID */
    void *val                                   /**< pointer to value */
);

const char * LOG_convStr(void *str);
const char * LOG_convIPv4(void *ipAddr);
const char * LOG_convMAC(void *macAddr);
const char * LOG_convDataDir(DATA_DIR_T dataDir);
const char * LOG_convSlotState(SLOT_STATE_T state);
const char * LOG_convSubslotState(SUBSLOT_STATE_T state);
const char * LOG_convIoCrType(IO_CR_TYPE_T type);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    char resString[255];                        /**< result string */
} PN_INSTANCE_LOG_RESOLV_T;


#else /* ! CONFIG_LOGGING_NAME_RESOLVER */

const char * LOG_resIdToHexStr(Unsigned32 id);

#define LOG_resKeyVal(x, y, z) LOG_resIdToHexStr(y)
#define LOG_convStr(x) x
#define LOG_convIPv4(x) LOG_resIdToHexStr((Unsigned32) *x)
#define LOG_convMAC(x) "<MAC>"
#define LOG_convDataDir(x) LOG_resIdToHexStr(x)
#define LOG_convSlotState(x) LOG_resIdToHexStr(x)
#define LOG_convSubslotState(x) LOG_resIdToHexStr(x)
#define LOG_convIoCrType(x) LOG_resIdToHexStr(x)

#endif /* CONFIG_LOGGING_NAME_RESOLVER == 1 */
#endif /* CONFIG_LOGGING == 1 */
#endif /* PN_LOG_RESOLV_H */
