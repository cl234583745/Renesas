/** @file
 *
 * @brief
 * PROFINET Network Management Module
 *
 * @details
 * This module manages the network handling for the PROFINET stack.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_NET_H
#define PN_NET_H

#include <pn_includes.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T PN_netInitPre(
    void
);

IOD_STATUS_T PN_netInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_netRawGetFrameID(
    OAL_BUFFER_T *pBuf,                         /**< raw frame buffer */
    Unsigned16 *pnioID                          /**< PROFINET ID */
);

void PN_netEthUp(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_netEthDown(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_netIpGet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 *pIp,                            /**< IP addr */
    Unsigned32 *pNetmask,                       /**< netmask */
    Unsigned32 *pGateway                        /**< gateway */
);

PN_BOOL_T PN_netIpIsTemp(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_netIpClear(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_netEthSend(
    OAL_BUFFER_T **ppBuf,                       /**< frame buffer */
    PN_NET_TX_TYPE_T prio                       /**< priority */
);


#endif /* PN_NET_H */
