/** @file
 *
 * @brief
 * PROFINET Logger Architecture Information
 *
 * @details
 * Logs details of the used architecture and platform.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_LOG_SYSINFO_H
#define PN_LOG_SYSINFO_H


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
void PN_logSysinfo(
    void
);


#endif /* PN_LOG_SYSINFO_H */
