/** @file
 *
 * @brief
 * PROFINET Discovery and Basic Configuration Protocol Module
 *
 * @details
 * Discovery and basic Configuration Protocol module is responsible for reading
 * and writing basic device network configuration parameters and discovering
 * devices by means of different filter criteria.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_DCP_H
#define PN_DCP_H

#include <pn_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* DCP Options/Suboptions */
#define PN_DCP_OPT(maj, min)                ((maj << 8) | (min & 0xff))
#define PN_DCP_OPT_IP                       0x01
#define PN_DCP_OPT_IP_MAC                   0x01
#define PN_DCP_OPT_IP_PARAM                 0x02
#define PN_DCP_OPT_DEV                      0x02
#define PN_DCP_OPT_DEV_VENDOR               0x01
#define PN_DCP_OPT_DEV_NAME                 0x02
#define PN_DCP_OPT_DEV_ID                   0x03
#define PN_DCP_OPT_DEV_ROLE                 0x04
#define PN_DCP_OPT_DEV_OPTS                 0x05
#define PN_DCP_OPT_DEV_ALIAS                0x06
#define PN_DCP_OPT_CTRL                     0x05
#define PN_DCP_OPT_CTRL_START               0x01
#define PN_DCP_OPT_CTRL_STOP                0x02
#define PN_DCP_OPT_CTRL_SIGNAL              0x03
#define PN_DCP_OPT_CTRL_RESPONSE            0x04
#define PN_DCP_OPT_CTRL_FR                  0x05
#define PN_DCP_OPT_CTRL_RTF                 0x06
#define PN_DCP_OPT_INI                      0x06
#define PN_DCP_OPT_INI_SUB                  0x01
#define PN_DCP_OPT_ALL                      0xFF
#define PN_DCP_OPT_ALL_SUB                  0xFF

/* DCP Reset To Factory */
#define PN_DCP_RTF_RESET_APPL               0x01
#define PN_DCP_RTF_RESET_COMM               0x02
#define PN_DCP_RTF_RESET_ALL                0x04

/* DCP BlockQualifier */
#define DCP_BLKQUAL_TEMPORARY               0x0
#define DCP_BLKQUAL_PERMANENT               0x1

/* DCP Signal blink defines */
#define PN_DCP_SIGNAL_FREQ                  500 /**< 1Hz = 500ms on & off */
#define PN_DCP_SIGNAL_TIMER_CNT             5   /**< toggle blink 5 times */

/* Length Defines */
#define PN_DCP_LEN_SNAME                    240
#define PN_DCP_LEN_SNAME_MIN                1
#define PN_DCP_LEN_SNAME_XYZ                3
#define PN_DCP_LEN_SNAME_ABCDE              5
#define PN_DCP_LEN_LABEL                    63
#define PN_DCP_LEN_LABEL_MIN                1
#define PN_DCP_LEN_IP_PART                  3
#define PN_DCP_LEN_OPT_OFS                  2
#define PN_DCP_LEN_IP_PARAM                 12
#define PN_DCP_LEN_DEV_ID                   4
#define PN_DCP_LEN_DEV_ROLE                 2
#define PN_DCP_LEN_DEV_OPTS                 16
#define PN_DCP_OPT_INI_SUB_LEN              1

/* Port String */
#define PN_DCP_STR_PORT_PREFIX              "port-"
#define PN_DCP_STR_PORT_PREFIX_LEN          5
#define PN_DCP_STR_PORT_MAIN                PN_DCP_STR_PORT_PREFIX "xxx"
#define PN_DCP_STR_PORT_MAIN_LEN            3
#define PN_DCP_STR_PORT_DIVIDER             PN_DCP_STR_PORT_MAIN "-"
#define PN_DCP_STR_PORT_DIVIDER_LEN         1
#define PN_DCP_STR_PORT_SUB                 PN_DCP_STR_PORT_DIVIDER "xxxxx"
#define PN_DCP_STR_PORT_SUB_LEN             5

/* PN-AL-protocol_2722_V23Ed2MU3_Mar16 - 4.3.1.4.25 Coding of the field
 * DeviceVendorValue, refers to 4.10.3.3.1 Coding of the field DeviceType */
#define PN_DCP_LEN_VENDOR                   25

/* Count Defines */
#define PN_DCP_CNT_IP_PART                  4

/* Block Error */
#define PN_DCP_OK                           0x00
#define PN_DCP_ERR_OPT_UNSUPP               0x01
#define PN_DCP_ERR_SUB_UNSUPP               0x02
#define PN_DCP_ERR_SUB_SET                  0x03
#define PN_DCP_ERR_RESOURCE_ERR             0x04
#define PN_DCP_ERR_SET_NOT_POSSIBLE         0x05
#define PN_DCP_ERR_IN_OPER_SET_NOT_POS      0x06

/* Block Info */
#define PN_DCP_OPT_IP_NONE                  (0x00 << 0)
#define PN_DCP_OPT_IP_SET                   (0x01 << 0)
#define PN_DCP_OPT_IP_NO_CONFLICT           (0x00 << 7)


#define DCP_NUM_OPTS                       12
#define DCP_HDR_SIZE                       10

#define DCP_GET_REQ                        0x03
#define DCP_SET_REQ                        0x04
#define DCP_IDENTIFY_REQ                   0x05
#define DCP_HELLO_REQ                      0x06

#ifndef CONFIG_DCP_HOLD_TIME
#  define CONFIG_DCP_HOLD_TIME             3000
#endif

#define PN_DCP_HELLO_MASK                  0x0001
#define PN_DCP_HELLO_OFF                   0x0000
#define PN_DCP_HELLO_ON                    0x0001

#define PN_DCP_LEN_PEER_PORT_SHORT         8    /**< port id: port-xyz */
#define PN_DCP_LEN_PEER_PORT_LONG          14   /**< port id: port-xyz-rstuv */

#define PN_DCP_TYPE_HELLO_REQ              0xfefc /**< DCP-Hello-ReqPDU ID */
#define PN_DCP_TYPE_MIN                    0xfefd /**< min DCP id */
#define PN_DCP_TYPE_MAX                    0xfeff /**< max DCP id */

/**< PROFINET DCP - IP changed externally (manual/DHCP) */
#define PN_DCP_IP_SRC_EXT 0

/**< PROFINET DCP - IP changed internally (DCP) */
#define PN_DCP_IP_SRC_INT 1


/****************************************************************************/
/* Data types */
/****************************************************************************/
typedef enum {
    DCPMCR_STATE_OPEN = 0,                      /**< wait for identify req */
    DCPMCR_STATE_WRSP = 1,                      /**< wait for send resp delay */
} DCPMCR_STATE_T;


/** DCP State Management Structure */
typedef struct {
    /* DCP Multicast Receiver (Identify) */
    struct {
        DCPMCR_STATE_T  state;                  /**< DCPMCR state (Identify) */
        PN_TIMER_T     *pTmr;                   /**< identify response delay */
        OAL_BUFFER_T   *pBuf;                   /**< response frame buffer */
        IOD_CREP_T      ep;                     /**< endpoint data */
    } dcpmcr;

    /* DCP Unicast Receiver (Get/Set) */
    struct {
        char            sam[MAC_ADDR_LEN];      /**< source mac address */
        PN_TIMESTAMP_T  holdTimeout;            /**< hold timeout */
        Unsigned32      sxid;                   /**< transaction ID */
        IOD_CREP_T      ep;                     /**< endpoint data */
        OAL_BUFFER_T   *pBuf;                   /**< response frame buffer */
    } dcpucr;

    /* DCP Multicast Transmitter (Hello) */
    struct {
        OAL_BUFFER_T   *pBuf;                   /**< response frame buffer */
        Unsigned32      sxid;                   /**< transaction ID */
        IOD_CREP_T      ep;                     /**< endpoint data */
    } dcpmct;
} PN_DCP_STATE_T;


/**< DCP Block Header */
typedef struct {
    Unsigned8   option;                         /**< option */
    Unsigned8   subOpt;                         /**< suboption */
    Unsigned16  blkLen;                         /**< block length */
} PN_DCP_BLOCK_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T PN_dcpInitPre(
    void
);

IOD_STATUS_T PN_dcpInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_dcpRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const MACADDR_T *pSA,                       /**< source MAC address */
    const MACADDR_T *pDA,                       /**< dest MAC address */
    Unsigned8 *pData,                           /**< data pointer */
    unsigned int dataLen                        /**< data length */
);

IOD_STATUS_T PN_dcpEthUp(
    void
);

IOD_STATUS_T PN_dcpEthDown(
    void
);

IOD_STATUS_T PN_devSetDeviceName(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    char *strName,                              /**< device name */
    unsigned int length,                        /**< length of device name */
    PN_BOOL_T permFlag,                         /**< temporary or permanent */
    PN_BOOL_T flgCb                             /**< run callback flag */
);

IOD_STATUS_T PN_devGetDeviceName(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    char **pStrName,                            /**< pointer to device name */
    unsigned int *pLength                       /**< pointer to length of device name */
);

IOD_STATUS_T PN_devSetVendorName(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const char *strVendorName,                  /**< vendor name */
    unsigned int len                            /**< name length */
);

IOD_STATUS_T PN_dcpSendHello(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    PN_DCP_STATE_T dcpState;                    /**< DCP state */
    PN_BOOL_T dcpInitFlag;                      /**< DCP init flag */
    PN_BOOL_T PN_dcpClearIp;                    /**< IP clear flag */
    PN_TIMER_T *mpTmrBlink;                     /**< timer ID */
    unsigned int PN_dcpBlinkTimerCnt;           /**< blink counter */
    PN_DCP_BLINK_LIGHT_T PN_dcpBlinkLight;      /**< light state */
    Unsigned8 *globStrAlias;                    /**< alias name */
    unsigned int globLenAlias;                  /**< alias length */
    Unsigned16 *pBlockList;                     /**< found DCP-Identify-ReqPDU blocks */
    unsigned int idIpSrc;                       /**< IP update source */
} PN_INSTANCE_DCP_T;


#endif /* PN_DCP_H */
