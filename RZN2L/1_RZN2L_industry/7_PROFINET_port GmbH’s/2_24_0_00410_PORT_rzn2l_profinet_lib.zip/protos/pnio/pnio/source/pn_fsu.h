/** @file
 *
 * @brief
 * PROFINET Fast Startup
 *
 * @details
 * This module contains the implementation of Fast Start Up (FSU).
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_FSU_H
#define PN_FSU_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define PN_FS_HELLO_MODE_OFF 0x0                /* DCP Hello Req disabled (default) */
#define PN_FS_HELLO_MODE_ON 0x1                 /* send DCP Hello Req on LinkUp */
#define PN_FS_HELLO_MODE_ON_DELAY 0x2           /* send DCP Hello Req on LinkUp after HelloDelay */
#define PN_FS_HELLO_MODE_DEFAULT PN_FS_HELLO_MODE_OFF

#define PN_FS_HELLO_INTERVAL_30 0x1E            /* 30 ms wait time before conveying a second DCP_Hello.req (default) */
#define PN_FS_HELLO_INTERVAL_50 0x32            /* 50 ms wait time before conveying a second DCP_Hello.req */
#define PN_FS_HELLO_INTERVAL_100 0x64           /* 100 ms wait time before conveying a second DCP_Hello.req */
#define PN_FS_HELLO_INTERVAL_300 0x12C          /* 300 ms wait time before conveying a second DCP_Hello.req */
#define PN_FS_HELLO_INTERVAL_500 0x1F4          /* 500 ms wait time before conveying a second DCP_Hello.req */
#define PN_FS_HELLO_INTERVAL_1000 0x3E8         /* 1000 ms wait time before conveying a second DCP_Hello.req */
#define PN_FS_HELLO_INTERVAL_DEFAULT PN_FS_HELLO_INTERVAL_30

#define PN_FS_HELLO_RETRY_MIN 0x1               /* minimal number of retransmission of the Hello.req */
#define PN_FS_HELLO_RETRY_DEFAULT 0x3           /* default number of retransmission of the Hello.req */
#define PN_FS_HELLO_RETRY_MAX 0xF               /* maximal number of retransmission of the Hello.req */

#define PN_FS_HELLO_DELAY_0 0x0                 /* 0 ms wait time after first LinkUp before conveying a DCP_Hello.req (default) */
#define PN_FS_HELLO_DELAY_50 0x32               /* 50 ms wait time after first LinkUp before conveying a DCP_Hello.req */
#define PN_FS_HELLO_DELAY_100 0x64              /* 100 ms wait time after first LinkUp before conveying a DCP_Hello.req */
#define PN_FS_HELLO_DELAY_500 0x1F4             /* 500 ms wait time after first LinkUp before conveying a DCP_Hello.req */
#define PN_FS_HELLO_DELAY_1000 0x3E8            /* 1000 ms wait time after first LinkUp before conveying a DCP_Hello.req */
#define PN_FS_HELLO_DELAY_DEFAULT PN_FS_HELLO_DELAY_0

#define PN_FS_PARAMETER_MODE_OFF 0x0            /* parameter mode is off (default) */
#define PN_FS_PARAMETER_MODE_ON 0x1             /* parameter mode is on */
#define PN_FS_PARAMETER_MODE_DEFAULT PN_FS_PARAMETER_MODE_OFF


/****************************************************************************/
/* Typedefs */
/****************************************************************************/
typedef enum {
    PN_FSU_SM_DELAY = 0,                        /**< delay for first DCP Hello frame */
    PN_FSU_SM_SEND,                             /**< send DCP Hello frames by configured interval */
    PN_FSU_SM_END,                              /**< state machine end */
} PN_FSU_SM_T;

typedef struct {
    PN_TIMER_T *pTmr;                           /**< timer for DCP Hello delay */

    uint32_t helloMode;                         /**< configured FSU mode */
    uint32_t helloInterval;                     /**< configured interval of DCP Hello requests in ms */
    uint32_t helloRetry;                        /**< configured number of DCP Hello retries */
    uint32_t helloDelay;                        /**< configured number of DCP Hello delay */

    PN_BOOL_T flgDataValid;                     /**< data has been received and are valid */

    PN_FSU_SM_T state;                          /**< state machine */
    PN_BOOL_T flgInit;                          /**< initialization done flag */
} PN_INSTANCE_FSU_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T PN_fsuInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_fsuSmDcpHello(
    void *pArg                                  /**< Argument */
);
#endif /* PN_FSU_H */
