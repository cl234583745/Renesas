/** @file
 *
 * @brief
 * PROFINET Connectionless Remote Procedure Call Protocol Module
 *
 * @details
 * Connectionless Remote Procedure Call Protocol module is responsible for
 * delivery of messages exchanged between PROFINET device and controller during
 * connection establishment and reading or writing of record data.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_RPC_H
#define PN_RPC_H

#include <pn_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define PN_RPC_MAX_PDU_LEN   (sizeof(PN_RPC_HDR_T) + PN_RPC_MAX_DATA_LEN)

/**< maximum fragment number */
#define PN_RPC_MAX_FRAG_NUM  0x3f

#define RPC_GET_PKT_SIZE(l)    ((l) + sizeof(PN_RPC_HDR_T) + sizeof(PN_NDR_HDR_T))
#define RPC_GET_DATA_PTR(b)    ((Unsigned8 *)((Unsigned8 *)(b) + (sizeof(PN_RPC_HDR_T) + sizeof(PN_NDR_HDR_T))))

#define PN_RPC_VER             0x04
#define PN_RPC_IDEMPOT         0x20
#define PN_RPC_LITTLE_ENDIAN   0x10
#define PN_RPC_NOFACK          0x08
#define PN_RPC_FRAGM           0x04
#define PN_RPC_LASTFRAG        0x02
#define PN_RPC_IF_VER          0x00000001uL
#define PN_RPC_UUIDHINT_NO     0xFFFF
#define PN_RPC_AUTH_NO         0x00

#define PN_RPC_SRV_PORT        0x8894           /**< RPC port - 34964 (according to IANA)  */
#define PN_RPC_RSP_PORT        0xc000           /**< RPC responder port - 49152 (according to IANA) */
#define PN_RPC_EPM_SES_CNT     1                /**< count of RPC EPM sessions */
#define PN_RPC_EPM_PORT_CNT    2                /**< count of RPC EPM ports */
#define PN_RPC_IFACE_MASK_OBJECT 0xf0           /**< RPCObjectUUID interface position */
#define PN_RPC_IFACE_MASK_SUBSLOT 0x0f00        /**< subslot interface position */
#define PN_RPC_IFACE_SHIFT_OBJECT 4             /**< RPCObjectUUID interface shift */
#define PN_RPC_IFACE_SHIFT_SUBSLOT 8            /**< subslot interface shift */
#define PN_RPC_INSTANCE        1                /**< RPC EPM instance */

#define PN_RPC_SERVERBOOT_OFF  56
#define PN_RPC_IFVER_OFF       60
#define PN_RPC_SEQNO_OFF       64
#define PN_RPC_OPNO_OFF        68
#define PN_RPC_IHINT_OFF       70
#define PN_RPC_AHINT_OFF       72
#define PN_RPC_LEN_OFF         74
#define PN_RPC_FRAGNUM_OFF     76

#define PN_RPC_SERV_ARR_SIZE   6         /* max number of supported operations  */
#define PN_RPC_MAX_DATA_LEN    1200u     /* max packet length (RPC body) - RPC header not included */
#define PN_RPC_MAX_FRAME_LEN   (PN_RPC_MAX_DATA_LEN + sizeof(PN_RPC_HDR_T) + sizeof(PN_NDR_HDR_T)) /* max lenth of RPC packet (with RPC header) */
#define PN_RPC_MAX_NUM_RETX    4         /* maximum number of fragment retransmissions */

/* RPC fault/reject codes */
#define PN_RPC_ST_UNSPEC       0x1c000009uL
#define PN_RPC_ST_RESPTOOBIG   0x1c010013uL
#define PN_RPC_ST_UNSUPPORTED  0x1c010017uL
#define PN_RPC_ST_NCA_UNK_IF   0x1c010003

#define PN_RPC_NDR_HDR_SIZE    (sizeof(PN_RPC_HDR_T) + sizeof(PN_NDR_HDR_T))

#define PN_RPC_NDR_OFF         sizeof(PN_RPC_HDR_T)
#define PN_RPC_ARGLEN_OFF      (PN_RPC_NDR_OFF + 4)
#define PN_RPC_DATA_OFF        (sizeof(PN_RPC_HDR_T) + sizeof(PN_NDR_HDR_T))

#define PN_RPC_PCKT_TYPE_MASK  0x1F

#define PN_RPC_TIMEOUT_FRAG    500
#define PN_RPC_TIMEOUT_IDLE    3000

/* RPC states */
#define PN_RPC_ST_WFReq        0
#define PN_RPC_ST_WFFrg        1
#define PN_RPC_ST_WFRsp        3

#define PN_RPC_CANCEL_ACK_LEN  9

/* EPM defines */
#define PN_RPC_EPM_TYPE_EPMV4           0
#define PN_RPC_EPM_TYPE_PNIO            1
#define PN_RPC_EPM_TOWER_REF            3
#define PN_RPC_EPM_ENTRY_NO             1
#define PN_RPC_EPM_ENTRY_MAX            1
#define PN_RPC_EPM_ANNO_OFS             0
#define PN_RPC_EPM_FLOOR_MAX            5
#define PN_RPC_EPM_FLOOR_RPCID          0x0d
#define PN_RPC_EPM_FLOOR_RPCPROTOID     0x0a
#define PN_RPC_EPM_FLOOR_RPCSRVUDPPORT  0x08
#define PN_RPC_EPM_FLOOR_RPCHOSTADDR    0x09

/* RPC EPM Status - RPCEPMapStatus */
#define PN_RPC_EPM_STATUS_OKAY          0x00000000
#define PN_RPC_EPM_STATUS_EP_NOT_REG    0x16C9A0D6


/****************************************************************************/
/* Device annotation */
/****************************************************************************/
/* 4.10.2.2.4 - Coding of the field SWRevisionPrefix
 *
 * V - for an officially released version
 * R - for Revision
 * P - for Prototype
 * U - for Under Test (Field Test)
 * T - for Test Device
 */
#define PN_RPC_SWREV_OFFICIAL               'V'
#define PN_RPC_SWREV_REVISION               'R'
#define PN_RPC_SWREV_PROTOTYPE              'P'
#define PN_RPC_SWREV_UNDERTEST              'U'
#define PN_RPC_SWREV_TESTDEV                'T'


/* fixed string length for annotation */
#define PN_RPC_LEN_ANNO                     64
#define PN_RPC_LEN_DEVTYPE                  25
#define PN_RPC_LEN_ORDERID                  20
#define PN_RPC_LEN_HWREV                    5
#define PN_RPC_LEN_SWREV_PREFIX             1
#define PN_RPC_LEN_SWREV_ENH                3
#define PN_RPC_LEN_SWREV_BUGFIX             3
#define PN_RPC_LEN_SWREV_INTCHG             3


/****************************************************************************/
/* Data types */
/****************************************************************************/
typedef enum {
    PN_RPC_REQUEST = 0x00,
    PN_RPC_PING = 0x01,
    PN_RPC_RESPONSE = 0x02,
    PN_RPC_FAULT = 0x03,
    PN_RPC_WORKING = 0x04,
    PN_RPC_NOCALL = 0x05,
    PN_RPC_REJECT = 0x06,
    PN_RPC_ACK = 0x07,
    PN_RPC_CANCEL = 0x08,
    PN_RPC_FACK = 0x09,
    PN_RPC_CANCELACK = 0x0A
} PN_RPC_PCKT_TYPE;

typedef enum {
    PN_RPC_CONNECT = 0x00,
    PN_RPC_RELEASE = 0x01,
    PN_RPC_READ = 0x02,
    PN_RPC_EPMLOOKUP = 0x02,
    PN_RPC_WRITE = 0x03,
    PN_RPC_CONTROL = 0x04,
    PN_RPC_EPMFREE = 0x04,
    PN_RPC_READIMPLICIT = 0x05
} PN_RPC_OPERATION_T;

typedef IOD_STATUS_T (*FPTR_RPCSERV_T) (
    Unsigned8 serviceNum,
    RPC_SESSION_INFO_T *pSesInfo,
    const Unsigned8  *pInData,
    Unsigned16  inDataLen,
    Unsigned8  *pOutData,
    Unsigned16 *pOutDataLen,
    ERROR_STATUS_T *pErrCode);

typedef struct
{
    PN_RPC_OPERATION_T  serviceId;
    FPTR_RPCSERV_T  pftrCB;
} RPC_SERVICEINFO_T;


/**< RPC EPM UDP port info */
typedef struct {
    int used;                                   /**< usage indicator */
    int type;                                   /**< UDP port type (EPMv4, PNIO) */
    Unsigned16 port;                            /**< UDP port */
} PN_RPC_EPM_UDP_T;


/**< RPC EPM session info */
typedef struct {
    PN_BOOL_T used;                             /**< usage indicator */
    Unsigned8 handle[PN_RPC_EPM_HANDLE_LEN];    /**< EPM handle */
    PN_TIMESTAMP_T exp;                         /**< expiration timestamp */
    unsigned int portIdx;                       /**< port index */
} PN_RPC_EPM_SES_T;


/**< RPC EPM request */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32 rpcInquiryType_en32;             /**< RPCInquiryType */
    Unsigned32 rpcObjRef_en32;                  /**< RPCObjectReference */
    UUID_T rpcObjUuid;                          /**< RPCObjectUuid */
    Unsigned32 rpcIfaceRef_en32;                /**< RPCInterfaceReference */
    UUID_T rpcIfaceUuid;                        /**< RPCInterfaceUuid */
    Unsigned16 rpcIfaceVerMaj_en16;             /**< RPCInterfaceVersionMajor */
    Unsigned16 rpcIfaceVerMin_en16;             /**< RPCInterfaceVersionMinor */
    Unsigned32 rpcVerOpt_en32;                  /**< RPCVersionOption */
    Unsigned32 rpcEntryHandleAttr_en32;         /**< RPCEntryHandleAttribute */
    UUID_T rpcEntryHandleUuid;                  /**< RPCEntryHandleUuid */
    Unsigned32 rpcMaxEntries_en32;              /**< RPCMaxEntries */
} GOAL_TARGET_PACKED PN_RPC_EPM_REQ_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM response */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32 handleAttr;                      /**< RPCEntryHandleAttribute */
    UUID_T handleUUID;                          /**< RPCEntryHandleUUID */
    Unsigned32 noOfEntries;                     /**< RPCNumberOfEntries */
    Unsigned32 maxEntries;                      /**< RPCMaxEntries */
    Unsigned32 entriesOfs;                      /**< RPCEntriesOffset */
    Unsigned32 entriesCnt;                      /**< RPCEntriesCount */
} GOAL_TARGET_PACKED PN_RPC_EPM_RES_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM response entry */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    UUID_T objUUID;                             /**< RPCObjectUUID */
    Unsigned32 towerRef;                        /**< RPCTowerReference */
    Unsigned32 annoOfs;                         /**< RPCAnnotationOffset */
    Unsigned32 annoLen;                         /**< RPCAnnotationLength */
    char anno[PN_RPC_LEN_ANNO];                 /**< RPCAnnotation */
    Unsigned32 towerLen;                        /**< RPCTowerLength */
    Unsigned32 towerOctStrLen;                  /**< RPCTowerOctetStringLength */
} GOAL_TARGET_PACKED PN_RPC_EPM_RES_ENTRY_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 1/2 LHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 rpcId;                            /**< RPCID */
    UUID_T rpcIfaceUUID_le;                     /**< RPCInterfaceUUID */
    Unsigned16 rpcIfaceVerMaj_le;               /**< RPCInterfaceVersionMajor */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR12_LHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 1/2 RHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 rpcIfaceVerMin_le;               /**< RPCInterfaceVersionMinor */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR12_RHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 3 LHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 rpcProtoId;                       /**< RPCProtocolIdentifier */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR3_LHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 3 RHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 rpcIfaceVerMin_le;               /**< RPCInterfaceVersionMinor */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR3_RHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 4 LHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 rpcSrvUdpPort;                    /**< RPCServerUDPPort */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR4_LHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 4 RHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned16 rpcPortNum;                      /**< RPCPortNumber */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR4_RHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 5 LHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned8 rpcHostAddr;                      /**< RPCHostAddress */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR5_LHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< RPC EPM Floor 5 RHS */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32 rpcIpAddr;                       /**< RPCIPAddress */
} GOAL_TARGET_PACKED PN_RPC_EPM_FLOOR5_RHS_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< NDREPMapLookupFreeRes */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    Unsigned32 rpcEntryHandleAttr_en32;         /**< RPCEntryHandleAttribute */
    UUID_T rpcEntryHandleUuid_en;               /**< RPCEntryHandleUUID */
    Unsigned32 rpcEpmapStatus_en32;             /**< RPCEPMapStatus */
} GOAL_TARGET_PACKED PN_RPC_EPM_LOOKUP_FREE_RES;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Exported variables */
/****************************************************************************/
extern UUID_T PN_RPC_interface_id_pnio;         /**< UUID_IO_DeviceInterface - Table 246 - RPCInterfaceUUID for PNIO */
extern UUID_T PN_RPC_interface_id_epmv4;        /**< UUID_EPMap_Interface - Table 247 - RPCInterfaceUUID for the RPC EPM */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T RPC_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void RPC_shutdown(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_rpcCcontrolReqSend(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< Application relationship reference */
    const Unsigned8 *pData,                     /**< send buffer */
    Unsigned16 dataLen                          /**< send buffer length */
);

IOD_STATUS_T RPC_call(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    RPC_SESSION_INFO_T *pSesInfo,               /**< session info structure */
    const UUID_T *pObjectID,                    /**< object ID on RPC server */
    Unsigned8 servNum,                          /**< service number */
    const Unsigned8 *pData,                     /**< send buffer */
    Unsigned16 iDataLen                         /**< send buffer length */
);

void PN_rpcLoop(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_TIMESTAMP_T ts                           /**< current timestamp */
);

IOD_STATUS_T RPC_sendResponse(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    void *pSesInfo,                             /**< session ID */
    Unsigned16 respLen                          /**< response length */
);

IOD_STATUS_T PN_rpcEpmInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_rpcEpmReg(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned8 type,                             /**< port type */
    Unsigned16 port                             /**< port number */
);

Unsigned16 PN_rpcEpmReq(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    RPC_SESSION_INFO_T *pSesInfo,               /**< ptr to RPC session */
    const PN_RPC_PDU_HDR_T *pRequest            /**< EPM request data */
);

Unsigned16 PN_rpcEpmReqFree(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    RPC_SESSION_INFO_T *pSesInfo,               /**< ptr to RPC session */
    const PN_RPC_PDU_HDR_T *pRequest            /**< EPM request data */
);

void PN_rpcSesCtrlKeep(
    void *pSession,                             /**< session handle */
    PN_BOOL_T flag                              /**< flag */
);

void PN_rpcEpmAnno(
    char *pAnno,                                /**< annotation string storage ptr */
    uint16_t *pLen,                             /**< length storage */
    PN_BOOL_T flgLldp                           /**< LLDP chassis id flag */
);

void RPC_removeSession(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    void *pSession                              /**< session object ptr */
);

void PN_rpcNdrDataRespPnioStatusSet(
    RPC_SESSION_INFO_T *pSesInfo,               /**< session handle */
    const ERROR_STATUS_T *pStatusPnio           /**< PROFINET Status */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    RPC_SESSION_INFO_T *PN_rpcVarSesClient;     /**< session info for client requests */
    int PN_RPC_socket_rx;                       /**< RPC server conn handle */
    int PN_RPC_socket_tx;                       /**< RPC responder conn handle */
    RPC_SESSION_INFO_T *pSessionsArray;         /**< RPC session array */
    unsigned int sessionCount;                  /**< session counter */
    PN_LOCK_T *pRpcMutex;                       /**< RPC concurrent access mutex */
    Unsigned32 iServerBootTime;                 /**< server boot time */
    PN_BOOL_T PN_rpcFlagInit;                   /**< RPC init flag */
} PN_INSTANCE_RPC_T;


typedef struct {
    PN_RPC_EPM_UDP_T ports[PN_RPC_EPM_PORT_CNT]; /**< EPM ports */
    PN_RPC_EPM_SES_T sessions[PN_RPC_EPM_SES_CNT]; /**< EPM sessions */
    PN_BOOL_T initFlag;                         /**< RPC EPM init flag */
    PN_LOCK_T *pSessionMtx;                     /**< EPM session lock */
} PN_INSTANCE_RPC_EPM_T;


#endif /* PN_RPC_H */
