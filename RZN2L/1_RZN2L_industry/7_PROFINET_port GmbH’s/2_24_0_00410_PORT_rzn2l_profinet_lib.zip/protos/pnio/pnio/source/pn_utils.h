/** @file
 *
 * @brief
 * PROFINET Helper Functions
 *
 * @details
 * This module defines several utilities used by the PROFINET IO Stack like
 * memory check functions.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_UTILS_H
#define PN_UTILS_H


/****************************************************************************/
/** Macro: Clear an error code.
 *
 * This macro clears all 4 elements of the errorStatus variable. It sets
 * errorCode, errorCode1, errorCode2 and errorDecode to zero.
 */
#define CLEAR_ERROR_CODE() \
    do { \
        pErrorStatus->errorCode = 0; \
        pErrorStatus->errorCode1 = 0; \
        pErrorStatus->errorCode2 = 0; \
        pErrorStatus->errorDecode = 0; \
    } while (0)


/****************************************************************************/
/** Macro: Check if an error code is set.
 *
 * This macro checks all 4 elements of the errorStatus variable if at least one
 * of them is non-zero. It checks errorCode, errorCode1, errorCode2 and
 * errorDecode.
 */
#define IS_ERROR_CODE_SET() \
    ((0 != pErrorStatus->errorCode) || \
     (0 != pErrorStatus->errorCode1) || \
     (0 != pErrorStatus->errorCode2) || \
     (0 != pErrorStatus->errorDecode))


/****************************************************************************/
/** Macro: Mark an element as unused.
 *
 * This macro works around the circumstance that not every comiler has the
 * ability to mark a function parameter as unused. It should have no runtime
 * impact, as normal compilers just optimize the macro away.
 */
#define UNUSEDARG(x) ((void)(x))


/****************************************************************************/
/** Macro: Set an error if a condition is true.
 *
 * This macro checks the given condition if the local variable errCode2 is
 * zero. If the condition is false, it sets the errCode2 variable to errorCode.
 */
#define CHECK_PAR(condition, errorCode) \
    if ((!errCode2) && (condition))  { \
        errCode2 = errorCode; \
        PN_logErr("CHECK_PAR failed. errCode2: %d", errCode2); \
    }


/****************************************************************************/
/** Macro: Halt the device if a pointer is zero
 *
 * This macro halts the device if a given pointer is zero.
 */
#define PN_HALT_IF_NULL(x) if (!x) { OAL_halt(); }


/****************************************************************************/
/** Macro: Halt the device if a structure isn't active
 *
 * This macro halts the device if the active flag of a given structure pointer
 * isn't true.
 */
#define PN_HALT_IF_INACTIVE(x) if (PN_TRUE != x->active) { OAL_halt(); }


/****************************************************************************/
/** Macro: Halt the device if a condition doesn't match
 *
 * This macro halts the device if condition doesnt match - like ASSERT.
 */
#define PN_HALT_IF_FALSE(x) if (!(x)) { OAL_halt(); }


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
PN_STATUS_T PN_utilInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T PN_utilVerifyReqBlock(
    const BLOCK_HEADER_T *pBlockHdr,            /**< [in] block header */
    Unsigned16 expBlockType,                    /**< expected block type */
    Unsigned16 expBlockLen,                     /**< expected block length */
    ERROR_STATUS_T *pErrStatus                  /**< [out] error status */
);

void swapUUID(
    UUID_T *pUUID                               /**< [in,out] UUID pointer */
);

Unsigned32 PN_utilCrcFletcher32(
    Unsigned16 const *pData,                    /**< data pointer */
    Unsigned32 words                            /**< size in 16-bit words */
);

void PN_utilPadWithBlanks(
    Unsigned8 *str,                             /**< string pointer */
    unsigned int strLen,                        /**< string length */
    unsigned int fillLen                        /**< fill length */
);

void PN_utilRandInit(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 val                              /**< random start value */
);

Unsigned32 PN_utilRand(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void PN_utilRandStream(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    uint8_t *pArea,                             /**< ptr to store stream */
    unsigned int len                            /**< length of stream */
);

PN_BOOL_T PN_utilIsDigitRow(
    const char *str,                            /**< string */
    unsigned int len                            /**< num length */
);

PN_BOOL_T PN_utilIsVisibleString(
    const unsigned char *pStr,                  /**< string */
    unsigned int len                            /**< string length */
);

PN_BOOL_T PN_utilIsIm2DateTime(
    const unsigned char *pStr,                  /**< string */
    unsigned int len                            /**< string length */
);

PN_BOOL_T PN_utilUuidCmp(
    const UUID_T *pUuid1,                       /**< first UUID */
    PN_ENDIAN_T endian1,                        /**< first UUID endianness */
    const UUID_T *pUuid2,                       /**< second UUID */
    PN_ENDIAN_T endian2                         /**< second UUID endianness */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    Unsigned32 randVal;                         /**< random base value */
} PN_INSTANCE_UTIL_T;


#endif /* PN_UTILS_H */
