/** @file
 *
 * @brief
 * PROFINET Stack IO Data Module
 *
 * @details
 * This module implements PROFINET IO data functionality. This includes
 * processing of IO CR block as well as read and write IO Data (including IOPS)
 * and IOCS. Later are part of the user API.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_IODATA_H
#define PN_IODATA_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* IO CR types */
#define IO_INPUT_CR             0x0001
#define IO_OUTPUT_CR            0x0002

/* IO CR Properties Bits */
#define IOCR_PROP_RESERVED      0xFFFFF7F0      /* reserved bits */
#define IOCR_PROP_MEDIA_RED     0x00000800      /* Media redundancy */
#define IOCR_PROP_RTCLASS       0x0000000F      /* Real time class */

#define IOCR_RES_LEN 8
#define IOPS_LEN 1
#define IOCS_LEN 1


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T IO_createIOCS(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< pointer to active AR */
    Unsigned32 api,                             /**< API number */
    Unsigned16 slotNr,                          /**< Slot number */
    Unsigned16 subSlotNr,                       /**< SubSlot number */
    Unsigned16 frameOffset,                     /**< frame offset in cyclic buffer */
    IO_EP_T *pIOEP,                             /**< Cylcic data endpoint */
    IO_CR_TYPE_T ioCrType                       /**< IO communication relationship type */
);

IOD_STATUS_T IO_processIOCRBlock(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< pointer to AR */
    const IOCR_BLOCK_REQ_T *pIOCRBlockReq,      /**< request block buffer */
    IOCR_BLOCK_RES_T *pIOCRBlockRes,            /**< buffer to store response block */
    ERROR_STATUS_T *pErrorResp,                 /**< pointer to store error status */
    Unsigned16 *pRespLen                        /**< pointer to store length or response */
);

void IO_startCyclicComm(
    AR_T *pAR                                   /**< AR pointer */
);

IOD_STATUS_T PN_ioSetIoxsDirect(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /**< API */
    Unsigned16 slot,                            /**< slot */
    Unsigned16 subSlot,                         /**< subslot */
    SUBSLOT_T *pSubSlot,                        /**< subslot ptr */
    IO_CR_TYPE_T type,                          /**< input/output type */
    PN_BOOL_T iocsFlag,                         /**< IOCS/IOPS flag */
    Unsigned8 value                             /**< value */
);

IOD_STATUS_T PN_ioGetIoxsDirect(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    SUBSLOT_T *pSubSlot,                        /**< subslot ptr */
    IO_CR_TYPE_T type,                          /**< input/output type */
    PN_BOOL_T iocsFlag,                         /**< IOCS/IOPS flag */
    Unsigned8 *pValue                           /**< value ref */
);


#endif /* PN_IODATA_H */
