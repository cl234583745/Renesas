/** @file
 *
 * @brief
 * PROFINET Device Configuration Module
 *
 * @details
 * Provides the API to create slots and modules.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_DEVICE_H
#define PN_DEVICE_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define PN_DEVICE_API                       0   /**< default API */

#define PN_DEV_CC_A                         0   /**< PROFINET CC-A */
#define PN_DEV_CC_B                         1   /**< PROFINET CC-B */


/****************************************************************************/
/* Typedefs */
/****************************************************************************/
typedef unsigned int PN_DEV_CC_T;               /**< PROFINET Conformance Class */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T DEV_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T IOD_devDapSlotSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 nrDapSlot                        /**< slot number */
);

PN_STATUS_T IOD_devDapSlotGet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned16 *pNrDapSlot                      /**< slot number ptr */
);

PN_DEV_CC_T PN_devConfClassGet(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_devConfClassSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_DEV_CC_T idConfClass                     /**< Conformance Class id */
);

PN_STATUS_T PN_devConfTestGet(
    const char **pStrPnioStd,                   /**< [out] PROFINET standard */
    const char **pStrTestSpec,                  /**< [out] test specification */
    const char **pStrTestcases,                 /**< [out] testcases */
    const char **pStrArt,                       /**< [out] ART tester */
    const char **pStrSl1Test,                   /**< [out] SL1 Test */
    const char **pStrPnio,                      /**< [out] PROFINET version */
    const char **pStrGsd                        /**< [out] GSD version */
);

PN_STATUS_T PN_devSubslotSubstGet(
    SUBSLOT_T *pSubslot,                        /**< subslot handle */
    uint16_t *pModeSubst,                       /**< [out] substitution mode */
    uint8_t *pValIocs,                          /**< [out] substitution IOCS */
    uint8_t *pData                              /**< [out] substitute data (length: module specific) */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    PN_BOOL_T devInit;                          /**< device initialisation done flag */
    Unsigned16 devNrDapSlot;                    /**< DAP slot */
    PN_DEV_CC_T mIdConfClass;                   /**< Conformance Class */
    unsigned int cntApis;                       /**< API count */
    AP_T *pApis;                                /**< API list */
    MODULE_T *pModules;                         /**< module list */
    unsigned int cntMod;                        /**< module count */
} PN_INSTANCE_DEVICE_T;


#endif /* PN_DEVICE_H */
