/** @file
 *
 * @brief
 * PROFINET Cyclic Real Time Data Module
 *
 * @details
 * The cyclic real time data module is responsible for delivery of periodic
 * input or output data between device and the controller. It provides the
 * functions for initialization of buffers asociated with in or out endpoints
 * and access to the data and status information stored in the buffers.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_CRTDATA_H
#define PN_CRTDATA_H

#include <pn_includes.h>


/* endpoint queue sizes */
#define CRT_EP_MAX          2

#define CRT_RX_QUEUE_NUM    1
#define CRT_TX_QUEUE_NUM    2

/* defines */
#define PN_CRT_TIME_BASE    3125
#define PN_CRT_TIME_DIV     100000


/* prototypes */
IOD_STATUS_T CD_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

IOD_STATUS_T CD_openEP(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T              *pAR,                     /**< AR pointer */
    const Unsigned8   *ctrlMacAddr,             /**< controller MAC address */
    const Unsigned8   *pIOCRBlock,              /**< pointer to the IOCRBlock */
    IO_EP_T           **ppEP,                   /**< buffer holding pointer to the endpoint object */
    ERROR_STATUS_T    *pErrorStatus             /**< error status */
);

IOD_STATUS_T CD_closeEP(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    IO_EP_T *pEP                                /**< EP pointer */
);

IOD_STATUS_T CD_activateEP(
    IO_EP_T *pEP                                /**< EP pointer */
);

IOD_STATUS_T CD_getData(
    const IO_EP_T *pEP,                         /**< EP pointer */
    Unsigned16 offset,                          /**< EP buffer offset */
    Unsigned8 *pBuf,                            /**< pointer to store data */
    Unsigned16 len                              /**< read length */
);

IOD_STATUS_T CD_setData(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    IO_EP_T *pEP,                               /**< EP pointer */
    Unsigned16 offset,                          /**< EP buffer offset */
    const Unsigned8 *pBuf,                      /**< buffer to read data from */
    unsigned int len                            /**< write length */
);

void CD_exchangeOutputBuf(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    IO_EP_T *pEP,                               /**< EP pointer */
    OAL_BUFFER_T **pBuf                         /**< OAL buffer reference */
);

IOD_STATUS_T PN_crtGetApduStatus(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Integer32 arId,                             /**< AR ID */
    PN_APDU_STATUS_T *pApduStatus               /**< APDU status */
);

void PN_crtStationProblemIndicatorSet(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    PN_BOOL_T flag                              /**< indicator flag */
);

PN_BOOL_T PN_crtStationProblemIndicatorGet(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    IO_EP_T *arrEP[CRT_EP_MAX];                 /**< AR endpoints */
    PN_LOCK_T *arrEP_mutex;                     /**< AR EP mutex */
    QUEUE_T *pMemCrtTxQueue;                    /**< CRT TX memory descriptors */
    PN_BOOL_T PN_crtStatProbInd;                /**< StationProblemIndicator */
} PN_INSTANCE_CRT_T;


#endif /* PN_CRTDATA_H */
