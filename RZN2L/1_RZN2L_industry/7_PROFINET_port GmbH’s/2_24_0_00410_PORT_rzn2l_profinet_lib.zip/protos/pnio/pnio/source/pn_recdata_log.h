/** @file
 *
 * @brief
 * PROFINET Logdata Module
 *
 * @details
 * This module manages the logdata.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_RECDATA_LOG_H
#define PN_RECDATA_LOG_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define PN_REC_LOG_MAX_ENTRIES  4               /**< max logbook entries */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
PN_STATUS_T PN_recRdLogBookDataInit(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

RET_T PN_recRdLogBookData(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const IOD_HEADER_T *pReadReqHdr,            /**< request header */
    IOD_READ_RES_T *pReadRes,                   /**< response data */
    Unsigned16 *pOutDataLen                     /**< response length */
);

void PN_recRdLogBookAddEntry(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const UUID_T *pArUUID,                      /**< ARUUID */
    const ERROR_STATUS_T *pErrStatus,           /**< error status */
    Unsigned32 entryDetail                      /**< EntryDetail */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    LOG_DATA_ENTRY_T logBookBuf[PN_REC_LOG_MAX_ENTRIES]; /**< log book buffer */
    LOG_DATA_ENTRY_T *pLogBookCurrEntry;        /**< current entry */
    Unsigned16 cntLogEntries;                   /**< number of log entries */
} PN_INSTANCE_RECDATA_LOG_T;


#endif /* PN_RECDATA_LOG_H */
