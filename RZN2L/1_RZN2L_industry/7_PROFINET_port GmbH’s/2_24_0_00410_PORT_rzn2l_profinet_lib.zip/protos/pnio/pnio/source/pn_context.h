/** @file
 *
 * @brief
 * PROFINET Context Manager Module
 *
 * @details
 * This module implemented PROFINET IO Context manager functionality. It is
 * responsible for processing PROFINET service frames received by RPC module.
 * Depending on the service further processing is done inside Context Manager
 * or functions of responsible modules are called.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_CONTEXT_H
#define PN_CONTEXT_H

#include <pn_includes.h>
#include <pn_rpc_types.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
/* defines for CM BlockType request */
#define CM_AR_BLOCK_REQ                 0x0101
#define CM_IOCR_BLOCK_REQ               0x0102
#define CM_ALARM_CR_BLOCK_REQ           0x0103
#define CM_EXPSUB_BLOCK_REQ             0x0104
#define CM_MCR_BLOCK_REQ                0x0106
#define CM_IOD_CTRLBLK_CONN_REQ         0x0110  /* IOD Control Block Connect */
#define CM_IOD_CTRLBLK_PLUG_REQ         0x0111  /* IOD Control Block Plug */
#define CM_IOX_CTRLBLK_CONN_REQ         0x0112  /* IOX Control Block Connect */
#define CM_IOX_CTRLBLK_PLUG_REQ         0x0113  /* IOX Control Block Plug */
#define CM_IOD_RELEASE_BLK_REQ          0x0114  /* IOD Release BLock */

/* defines for CM BlockType response */
#define CM_AR_BLOCK_RES 0x8101
#define CM_IOCR_BLOCK_RES       0x8102
#define CM_MODDIFF_BLOCK        0x8104
#define CM_IOD_CTRLBLK_CONN_RES         0x8110  /* IOD Control Block Connect */
#define CM_IOD_CTRLBLK_PLUG_RES         0x8111  /* IOD Control Block Plug */
#define CM_IOX_CTRLBLK_APP_READY_RES    0x8112  /* IOX Control Block Application Ready Response */
#define CM_IOX_CTRLBLK_PLUG_RES         0x8113  /* IOX Control Block Plug */
#define CM_IOD_RELEASE_BLK_RES          0x8114  /* IOD Release BLock */

/* Control command bits */
#define CM_CNTRLCMD_PRM_END     0x0001  /* parameter end */
#define CM_CNTRLCMD_APPL_READY 0x0002   /* Application ready */
#define CM_CNTRLCMD_RELEASE     0x0004  /* Release */
#define CM_CNTRLCMD_DONE        0x0008  /* Done */

/* Connect Request states */
#define PN_CTX_CONN_REQ_STATE_INIT 0            /**< open for requests */
#define PN_CTX_CONN_REQ_STATE_PROCESS 1         /**< request is being processed */
#define PN_CTX_CONN_REQ_STATE_FIN 2             /**< answwer processed request */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
IOD_STATUS_T CM_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_ctxRemoteSessionStore(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    void *pRemoteSession,                       /**< remote session pointer */
    PN_BOOL_T flgIsRpc                          /**< remote session is RPC */
);

PN_STATUS_T PN_ctxConnReqInit(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    uint8_t *pBufConnReq,                       /**< memory for copy of connection request */
    uint32_t sizeBufConnReq,                    /**< size of buffer in bytes */
    const Unsigned8 *pInData,                   /**< request frame buffer */
    Unsigned16 inDataLen,                       /**< length of request frame */
    ERROR_STATUS_T *pErrorStatus,               /**< pointer to store error response */
    uint8_t *pResData                           /**< pointer to result data in response */
);

PN_STATUS_T PN_ctxConnReqProcess(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_ctxRspSend(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    void *pSessionRemote,                       /**< remote session info */
    uint16_t lenData                            /**< length of data to send */
);

IOD_STATUS_T PN_ctxReleaseReqProcess(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned8 *pInData,                   /**< request frame buffer */
    Unsigned16 inDataLen,                       /**< request frame length */
    Unsigned8 *pOutData,                        /**< pointer to store response frame */
    Unsigned16 *pOutDataLen,                    /**< pointer to store response length */
    ERROR_STATUS_T *pErrorStatus                /**< pointer to store error status */
);

PN_STATUS_T PN_ctxWriteReqProcess(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned8 *pInData,                   /**< buffer with request frame */
    Unsigned16 inDataLen,                       /**< length of request frame */
    Unsigned8 *pOutData,                        /**< buffer to store response frame */
    Unsigned16 *pOutDataLen,                    /**< pointer to store response length */
    ERROR_STATUS_T *pErrorStatus,               /**< error status */
    Unsigned32 *pSequenceNumber,                /**< buffer of sequence number of received frame */
    AR_T *pAR                                   /**< AR pointer */
);

PN_STATUS_T PN_ctxReadReqProcess(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned8 *pInData,                   /**< buffer with request frame */
    Unsigned8 *pOutData,                        /**< buffer to store response frame */
    Unsigned16 *pOutDataLen,                    /**< data length */
    Unsigned16 outBufSize,                      /**< size of output buffer (i.e. maximum length of output data) */
    ERROR_STATUS_T *pErrorStatus,               /**< error status */
    Unsigned32 *pSequenceNumber,                /**< buffer of sequence number of received frame */
    AR_T *pAR,                                  /**< AR pointer */
    PN_BOOL_T flgReadImpl                       /**< ImplicitRead flag */
);

PN_STATUS_T PN_ctxControlReqProcess(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned8 *pInData,                   /**< request frame buffer */
    Unsigned16 inDataLen,                       /**< request frame buffer */
    Unsigned8 *pOutData,                        /**< pointer to store response frame */
    Unsigned16 *pOutDataLen,                    /**< pointer to store response length */
    ERROR_STATUS_T *pErrorStatus                /**< pointer to store error status */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
/**< Connect Request state data */
typedef struct {
    uint32_t state;                             /**< state */
    uint8_t *pReq;                              /**< request data */
    uint16_t lenReq;                            /**< request length */
    unsigned int idxReq;                        /**< request parser index */
    uint8_t *pResData;                          /**< response payload */
    unsigned int idxRes;                        /**< response index */
    ERROR_STATUS_T *pStatus;                    /**< PROFINET status location */
    AR_T *pAr;                                  /**< application relation */
    unsigned int cntBlockIocr;                  /**< count of IOCR blocks */
    unsigned int idxAlarmCr;                    /**< alarm CR index */
    GOAL_BOOL_T flgBlkExp;                      /**< ExpSubmodBlk found flag */
} PN_INSTANCE_CTX_CONN_REQ_T;

/**< Context Module RPC specific data */
typedef struct {
    uint8_t *pBufConnReq;                       /**< memory for copy of connecion request */
    uint32_t sizeBufConnReq;                    /**< buffer size of memory */
} PN_INSTANCE_CTX_RPC_T;


/**< Context Module instance data */
typedef struct {
    const IOCR_BLOCK_REQ_T **ppIOCRBlockReq;    /**< IOCR block ptr */
    GOAL_LOCK_T *pLock;                         /**< context lock */
    PN_INSTANCE_CTX_CONN_REQ_T connReq;         /**< connect request state data */
    PN_WRITE_INFO_T write;                      /**< write information */
    PN_BOOL_T flgIsRpc;                         /**< context module handles a RPC connection */
    PN_INSTANCE_CTX_RPC_T rpc;                  /**< RPC specific data */
    void *pRemoteSession;                       /**< Remote session pointer (RPC or RSI information) */
} PN_INSTANCE_CTX_T;


#endif /* PN_CONTEXT_H */
