/** @file
 *
 * @brief
 * PROFINET Application Relationship Manager
 *
 * @details
 * The Application Relationship Manager module contains functions to create,
 * delete and find PROFINET IO Application relationships. It is also
 * responsible for processing AR Block Request from Connect service frame.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef PN_AR_H
#define PN_AR_H

#include <pn_includes.h>


/****************************************************************************/
/* constants */
/****************************************************************************/
#define AR_CAR_SINGLE                           0x0001
#define AR_IOSAR                                0x0006

#define PN_AR_PROP_STATE                        (7 << 0)
#define PN_AR_PROP_SUPERVISOR_TO_ALLOW          (1 << 3)
#define PN_AR_PROP_PARAM_SERVER                 (1 << 4)
#define PN_AR_PROP_DEVICE_ACCESS                (1 << 8)
#define PN_AR_PROP_COMPANION_AR                 (2 << 9)
#define PN_AR_PROP_ACK_COMPANION_AR             (1 << 1)
#define PN_AR_PROP_STARTUP_MODE                 (1 << 30)
#define PN_AR_PROP_PULL_MOD_ALARM_ALLOW         (1 << 31)

#define PN_AR_ACT_TOUT_DEFAULT                  1
#define PN_AR_ACT_TOUT_DEVACC                   100
#define PN_AR_ACT_TOUT_MAX                      1000


/****************************************************************************/
/* structures */
/****************************************************************************/

/**< ARServerBlock structure */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    BLOCK_HEADER_T header;                      /**< header */
    Unsigned16 length;                          /**< station name len */
} GOAL_TARGET_PACKED PN_AR_SERVER_BLK_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* prototypes */
/****************************************************************************/
IOD_STATUS_T AR_processArBlock(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const AR_BLOCK_REQ_T *pArBlockReq,          /**< AR block request */
    AR_BLOCK_RES_T *pArBlockRes,                /**< buffer to put AR block response */
    ERROR_STATUS_T *pErrorResp,                 /**< buffer to put Error status response */
    Unsigned16 *pRespLen,                       /**< length of AR block response */
    AR_T **ppAR                                 /**< pointer to store pointer of created AR */
);

PN_ALARM_EP_T * AR_getAlarmEP(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,
    Unsigned16 slotNr,
    Unsigned16 subSlotNr
);

AR_T * AR_getAR(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned32 api,                             /* API number */
    Unsigned16 slotNr,                          /* SubSlot number */
    Unsigned16 subslotNr                        /* Slot number */
);

IOD_STATUS_T AR_init(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

void AR_deleteAR(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAR,                                  /**< Pointer to AR object */
    Unsigned8 errCode2,                         /**< errCode2 (reason) for alarm */
    int noAlarm                                 /**< flag to signal if an alarm should be send */
);

void AR_deleteAll(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    Unsigned8 errCode2                          /**< error code 2 */
);

PN_BOOL_T IOD_getControllerAR(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

AR_T * AR_findAR(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    const Unsigned8 *
);

PN_BOOL_T PN_arCheckActive(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_arGetById(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    unsigned int id,                            /**< AR id */
    AR_T **ppAr                                 /**< AR ptr ref */
);

IOD_STATUS_T PN_arGetEpByType(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr,                                  /**< AR ptr */
    Unsigned8 type,                             /**< EP type */
    IO_EP_T **ppEp                              /**< EP ptr ref */
);

void PN_arDeleteARLoop(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

unsigned int IOD_getARCount(
    struct PN_INSTANCE_T *pPnio                 /**< PROFINET instance */
);

PN_STATUS_T PN_arEventServiceRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr,                                  /**< AR ptr */
    PN_BOOL_T flgReadWrite                      /**< Service is a Read or Write operation */
);

PN_STATUS_T PN_arEventConnectReqRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventParameterEndRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr,                                  /**< AR ptr */
    PN_BOOL_T flgPlug,                          /**< Parameter end belongs to plug request */
    Unsigned16 plugHandle                       /**< plug handle */
);

PN_STATUS_T PN_arEventApplReadySend(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventApplReadySendDone(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventAppReadyRespRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventPlugRespRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventWriteReqRecv(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventWrite(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);

PN_STATUS_T PN_arEventReadWriteDone(
    struct PN_INSTANCE_T *pPnio,                /**< PROFINET instance */
    AR_T *pAr                                   /**< AR ptr */
);


/****************************************************************************/
/* Instance Data */
/****************************************************************************/
typedef struct {
    AR_T *pAr;                                  /**< list of ARs */
    PN_BOOL_T flgDelete;                        /**< delete indicator */
    PN_LOCK_T *pLock;                           /**< AR lock */
} PN_INSTANCE_AR_T;


#endif /* PN_AR_H */
