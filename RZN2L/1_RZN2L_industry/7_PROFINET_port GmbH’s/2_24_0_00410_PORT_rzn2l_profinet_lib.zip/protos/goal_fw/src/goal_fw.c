/** @file
 *
 * @brief GOAL TCP/IP Firewall
 *
 * This module provides a minimal firewall implementation for ARP, UDP and TCP.
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#include <protos/goal_fw/src/goal_fw.h>


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_fwArp(
    GOAL_BUFFER_T **ppBuf                       /**< GOAL buffer */
);

static GOAL_STATUS_T goal_fwIpv4(
    GOAL_BUFFER_T **ppBuf                       /**< GOAL buffer */
);

static GOAL_STATUS_T goal_fwIpSetCb(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrNm,                            /**< netmask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary config flag */
);


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static uint32_t mAddrIp_be32;                   /**< IP address */
static uint32_t mAddrZero;                      /**< zeroed IP address */
static GOAL_NET_CHAN_T *mpNetChans;             /**< network channel list */
static unsigned int mCntNetChans;               /**< count of network channels */
static GOAL_BOOL_T mFlgInit;                    /**< initialized flag */


/****************************************************************************/
/** Initialize the Firewall
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_fwInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t addrIp;                            /* local ip address */

    /* prevent multiple init calls */
    if (GOAL_TRUE == mFlgInit) {
        return GOAL_OK;
    }
    mFlgInit = GOAL_TRUE;

    /* retrieve channel list */
    res = goal_netChanDataGet(&mpNetChans, &mCntNetChans);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to retrieve channel list");
        return res;
    }

    /* retrieve IP (necessary if goal_fwInit after goal_netIpSet */
    res = goal_netIpGet(&addrIp, NULL, NULL, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to retrieve IP");
        return res;
    }

    mAddrIp_be32 = GOAL_htobe32(addrIp);

    /* add IP address change callback */
    res = goal_mainCbReg(GOAL_ID_NET, GOAL_NET_CB_ID_IP_SET, (GOAL_FUNC_RET_NOARG_T) (void *) goal_fwIpSetCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register IP address change callback");
        return res;
    }

    /* register an high priority ARP frame handler */
    res = goal_ethProtoAddPos(GOAL_TRUE, GOAL_ETH_ETHERTYPE_ARP, NULL, goal_fwArp, GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register ARP handler");
        return res;
    }

    goal_logInfo("registered ARP handler");

    /* register an high priority IPv4 frame handler */
    res = goal_ethProtoAddPos(GOAL_TRUE, GOAL_ETH_ETHERTYPE_IPV4, NULL, goal_fwIpv4, GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register IPv4 (UDP/TCP) handler");
        return res;
    }

    goal_logInfo("registered UDP/TCP handler");

    return GOAL_OK;
}


/****************************************************************************/
/** ARP Firewall
 *
 * Drops ARP frames that match the following criteria:
 *   - EtherType is 0x0806 (Address Resolution Protocol)
 *   - data length must be equal or larger than 96 bytes
 *   - ARP hardware type is 0x0001
 *   - IP protocol is IPv4 (0x0800)
 *   - opcode is request (0x01)
 *   - target IPv4 address isn't zero _OR_ isn't device IPv4 address
 *
 * Otherwise the frame gets processed by the TCP/IP stack.
 *
 * Info: This only works if TCP/IP frames are processed by goal_ethReceive. It
 * doesn't work on systems like Linux where GOAL is behind the TCP/IP stack.
 *
 * @retval GOAL_OK process frame
 * @retval GOAL_ERR_MISMATCH drop frame
 */
static GOAL_STATUS_T goal_fwArp(
    GOAL_BUFFER_T **ppBuf                       /**< GOAL buffer */
)
{
    GOAL_FW_ARP_T *pArp;                        /* ARP frame */

    /* verify frame length */
    if (sizeof(GOAL_FW_ARP_T) > (*ppBuf)->dataLen) {

        /* frame can't be parsed and must be accepted */
        return GOAL_ERR_MISMATCH;
    }

    /* assign ARP frame */
    pArp = (GOAL_FW_ARP_T *) ((*ppBuf)->ptrData + sizeof(GOAL_FW_ETH_T));
    if ((*ppBuf)->flags & GOAL_QUEUE_FLG_VLAN) {
        pArp += sizeof(GOAL_FW_VLAN_T);
    }

    /* verify metadata */
    if ((GOAL_be16toh_p(&pArp->typeHw_be16) != GOAL_FW_ARP_TYPE_HW_ETH)
        || (GOAL_be16toh_p(&pArp->typeProto_be16) != GOAL_FW_ARP_TYPE_PROTO_IPV4)
        || (GOAL_be16toh_p(&pArp->idOpcode_be16) != GOAL_FW_ARP_ID_OPCODE_REQ)) {

        /* frame can't be parsed and must be accepted */
        return GOAL_ERR_MISMATCH;
    }

    /* check if device is addressed */
    if ((GOAL_CMP_EQUAL != GOAL_MEMCMP(&mAddrZero, pArp->addrIpTarget, GOAL_LEN_IPV4_ADDR))
        && (GOAL_CMP_EQUAL != GOAL_MEMCMP(&mAddrIp_be32, pArp->addrIpTarget, GOAL_LEN_IPV4_ADDR))) {

        /* frame isn't addressed to this device, drop it */
        return GOAL_OK;
    }

    /* accept frame as it fulfills device criteria */
    return GOAL_ERR_MISMATCH;
}


/****************************************************************************/
/** Firewall IP Address Set Callback
 *
 * Gets called by GOAL if the IP address settings change.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_fwIpSetCb(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrNm,                            /**< netmask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary config flag */
)
{
    UNUSEDARG(addrNm);
    UNUSEDARG(addrGw);
    UNUSEDARG(flgTemp);

    /* store new IP address */
    mAddrIp_be32 = GOAL_htobe32(addrIp);

    goal_logInfo("IP address updated");

    return GOAL_OK;
}


/****************************************************************************/
/** UDP/TCP Port Firewall
 *
 * Drops UDP/TCP frames that aren't matching the registered port range.
 *
 * @retval GOAL_OK process frame
 * @retval GOAL_ERR_MISMATCH drop frame
 */
static GOAL_STATUS_T goal_fwIpv4(
    GOAL_BUFFER_T **ppBuf                       /**< GOAL buffer */
)
{
    GOAL_FW_IPV4_T *pIpv4;                      /* IPv4 frame */
    GOAL_FW_UDP_T *pUdp;                        /* UDP frame */
    GOAL_FW_TCP_T *pTcp;                        /* TCP frame */
    uint16_t numPort;                           /* port number */
    GOAL_NET_TYPE_T  type;                      /* channel type */
    unsigned int len;                           /* payload length */
    unsigned int cnt;                           /* counter */
    GOAL_NET_CHAN_T *pChan;                     /* network channel */

    /* verify frame length */
    if ((sizeof(GOAL_FW_ETH_T) + sizeof(GOAL_FW_IPV4_T)) > (*ppBuf)->dataLen) {

        /* frame can't be parsed and must be accepted */
        return GOAL_ERR_MISMATCH;
    }

    /* assign IPv4 frame */
    pIpv4 = (GOAL_FW_IPV4_T *) ((*ppBuf)->ptrData + sizeof(GOAL_FW_ETH_T));
    len = (*ppBuf)->dataLen - sizeof(GOAL_FW_ETH_T) - sizeof(GOAL_FW_IPV4_T);
    if ((*ppBuf)->flags & GOAL_QUEUE_FLG_VLAN) {
        if (sizeof(GOAL_FW_VLAN_T) <= len) {
            return GOAL_ERR_MISMATCH;
        }

        pIpv4 += sizeof(GOAL_FW_VLAN_T);
        len -= sizeof(GOAL_FW_VLAN_T);
    }

    /* handle frame by type */
    switch (pIpv4->proto) {

        case GOAL_FW_IPV4_TYPE_ICMP:
            return GOAL_ERR_MISMATCH;

        case GOAL_FW_IPV4_TYPE_UDP:

            if (sizeof(GOAL_FW_UDP_T) > len) {
                return GOAL_OK;
            }

            pUdp = (GOAL_FW_UDP_T *) ((uint8_t *) pIpv4 + sizeof(GOAL_FW_IPV4_T));
            numPort = GOAL_be16toh_p(&pUdp->portDst_be16);
            type = GOAL_NET_UDP_SERVER;
            break;

        case GOAL_FW_IPV4_TYPE_TCP:

            if (sizeof(GOAL_FW_TCP_T) > len) {
                return GOAL_OK;
            }

            pTcp = (GOAL_FW_TCP_T *) ((uint8_t *) pIpv4 + sizeof(GOAL_FW_IPV4_T));
            numPort = GOAL_be16toh_p(&pTcp->portDst_be16);
            type = GOAL_NET_TCP;
            break;

        default:
            return GOAL_ERR_MISMATCH;
    }

    /* iterate through all channels */
    for (cnt = 0; cnt < mCntNetChans; cnt++) {

        /* assign channel */
        pChan = &mpNetChans[cnt];

        /* skip unused channels */
        if (GOAL_TRUE != pChan->used) {
            continue;
        }

        /* check channel type */
        if ((type == GOAL_NET_UDP_SERVER) && (pChan->type != GOAL_NET_UDP_SERVER) && (pChan->type != GOAL_NET_UDP_CLIENT)) {
            continue;
        }

        if ((type == GOAL_NET_TCP) && (pChan->type != GOAL_NET_TCP_CLIENT) && (pChan->type != GOAL_NET_TCP)) {
            continue;
        }

        /* compare port number */
         if (pChan->addr.localPort == numPort) {
            return GOAL_ERR_MISMATCH;
        }

    }

    /* port not found, drop frame */
    return GOAL_OK;
}
