/** @file
 *
 * @brief GOAL TCP/IP Firewall
 *
 * This module provides a minimal firewall implementation for ARP, UDP and TCP.
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_FW_H
#define GOAL_FW_H

#include <goal_includes.h>


/****************************************************************************/
/* Typedefs */
/****************************************************************************/
#define GOAL_FW_ARP_TYPE_HW_ETH 0x0001          /**< Ethernet */
#define GOAL_FW_ARP_TYPE_PROTO_IPV4 0x0800      /**< IPv4 */
#define GOAL_FW_ARP_ID_OPCODE_REQ 0x0001        /**< Request */

#define GOAL_FW_IPV4_TYPE_ICMP 0x01             /**< ICMP */
#define GOAL_FW_IPV4_TYPE_TCP 0x06              /**< TCP */
#define GOAL_FW_IPV4_TYPE_UDP 0x11              /**< UDP */


/****************************************************************************/
/* Datatypes */
/****************************************************************************/
/**< Ethernet header frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t macDst[MAC_ADDR_LEN];               /**< destination MAC address */
    uint8_t srcDst[MAC_ADDR_LEN];               /**< source MAC address */
    uint16_t typeEth_be16;                      /**< EtherType */
} GOAL_TARGET_PACKED GOAL_FW_ETH_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< VLAN frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t tpid_be16;                         /**< Tag Protocol Identifier */
    uint16_t tci_be16;                          /**< Tag Control Information */
} GOAL_TARGET_PACKED GOAL_FW_VLAN_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< simplified ARP frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t typeHw_be16;                       /**< hardware type */
    uint16_t typeProto_be16;                    /**< protocol type */
    uint8_t sizeHw;                             /**< hardware size */
    uint8_t sizeProto;                          /**< protocol size */
    uint16_t idOpcode_be16;                     /**< opcode id */
    uint8_t addrMacSender[MAC_ADDR_LEN];        /**< sender MAC address */
    uint8_t addrIpSender[GOAL_LEN_IPV4_ADDR];   /**< sender IP address */
    uint8_t addrMacTarget[MAC_ADDR_LEN];        /**< target MAC address */
    uint8_t addrIpTarget[GOAL_LEN_IPV4_ADDR];   /**< target IP address */
} GOAL_TARGET_PACKED GOAL_FW_ARP_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< simplified IPv4 frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint8_t verLen;                             /**< version and header length */
    uint8_t diffSrvFld;                         /**< differentiated services field */
    uint16_t lenTot_be16;                       /**< total length */
    uint16_t id_be16;                           /**< identification */
    uint16_t flagsOfs_be16;                     /**< flags and fragment offset */
    uint8_t ttl;                                /**< time to live */
    uint8_t proto;                              /**< protocol */
    uint16_t crcHdr_be16;                       /**< header checksum */
    uint32_t ipSrc_be32;                        /**< source IP */
    uint32_t ipDst_be32;                        /**< destination IP */
} GOAL_TARGET_PACKED GOAL_FW_IPV4_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< simplified UDP frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t portSrc_be16;                      /**< source port */
    uint16_t portDst_be16;                      /**< destination port */
    uint16_t len_be16;                          /**< data length */
    uint16_t crc_be16;                          /**< checksum */
} GOAL_TARGET_PACKED GOAL_FW_UDP_T;
GOAL_TARGET_PACKED_STRUCT_POST


/**< simplified TCP frame */
GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct {
    uint16_t portSrc_be16;                      /**< source port */
    uint16_t portDst_be16;                      /**< destination port */
    uint32_t numSeq_be32;                       /**< sequence number */
    uint32_t numAck_be32;                       /**< acknowledge number */
    uint16_t lenFlgs_be16;                      /**< header length and flags */
    uint16_t sizeWin_be16;                      /**< window size */
    uint16_t crc_be16;                          /**< checksum */
    uint16_t ptrUrg_be16;                       /**< urgent pointer */
} GOAL_TARGET_PACKED GOAL_FW_TCP_T;
GOAL_TARGET_PACKED_STRUCT_POST


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_fwInit(
    void
);


#endif /* GOAL_FW_H */
