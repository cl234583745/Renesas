/** @file
 *
 * @brief GOAL LLDP Tx
 *
 * This module implements sending mechanism of the GOAL LLDP implementation.
 *
 * The start of sending LLDP frames is triggered by a timer populated with
 * the Message Tx interval in seconds. If it is started cyclically it is tried
 * to send a LLDP frame on the next port, until on all active ports one frame was sent.
 *
 * The TLV data to send are stored directly in a prepared LLDP frame.
 * Directly before sending for all stored TLVs a TLV callback is send, allowing
 * to change data. If the length will be not changed, the data in the callback
 * can be modified directly, otherweise the corresponding setter API must be used.
 *
 * @copyright
 * Copyright 2023 port GmbH
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_LLDP
#include <goal_includes.h>
#include <goal_lldp_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define GOAL_LLDP_TX_INTERVAL_MIN    1          /**< Minimum value for msgTxInterval in seconds */
#define GOAL_LLDP_TX_INTERVAL_DEF   30          /**< Recommended value for msgTxInterval in seconds */
#define GOAL_LLDP_TX_INTERVAL_MAX 3600          /**< Minimum value for msgTxInterval in seconds */

#define GOAL_LLDP_TX_HOLD_MIN  1                /**< Minimum value for msgTxHold */
#define GOAL_LLDP_TX_HOLD_DEF  4                /**< Recommended value for msgTxHold */
#define GOAL_LLDP_TX_HOLD_MAX 100               /**< Maximum value for msgTxHold */

#define GOAL_LLDP_TX_TTL_MAX  0xFFFFu           /**< Maximum value for time to live */

#define GOAL_LLDP_TX_BUF_NUM_FIXED 1            /**< number of buffers always needed */
#define GOAL_LLDP_TX_BUF_NUM_TEMP 0             /**< number of buffers temporary needed needed */

#define GOAL_LLDP_TX_VLAN_PCP_MAX ((1 << 3) - 1) /**< maximum VLAN priority code point (3-bit value) */
#define GOAL_LLDP_TX_VLAN_VID_MAX ((1 << 12) - 1) /**< maximum VLAN-Identifier (12-bit value) */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_lldpTxBufferNew(
    GOAL_LLDP_TX_INSTANCE_T *pTx                /**< GOAL LLDP TX instance */
);

static GOAL_STATUS_T goal_lldpTxTlvMandetoryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpTxEntryGet(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_TX_TLV_LIST_T **ppEntry           /**< found transmit TLV list entry */
);

static GOAL_STATUS_T goal_lldpTxEntryCreate(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_TX_TLV_LIST_T **ppEntry           /**< created transmit TLV list entry */
);

static GOAL_STATUS_T goal_lldpTxTlvPosUpdate(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint16_t posNew,                            /**< new start position */
    uint16_t posOld                             /**< old start position in frame, which shall be moved to new one */
);

static void goal_lldpTxTimerCb(
    void *pArg                                  /**< timer argument */
);

static GOAL_STATUS_T goal_lldpTxPort(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpTxUpdateCallbacksExec(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpTxTtlUpdate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);


/****************************************************************************/
/** Create a new GOAL LLDP Tx instance
 *
 * This function creates all required resources and stores the created
 * Tx instance in the GOAL LLDP instance.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxNew(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP TX instance */

    /* allocate instance data */
    res = goal_memCalloc(&pLldp->pTx, sizeof(GOAL_LLDP_TX_INSTANCE_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP TX instance");
        return res;
    }

    /* store Tx instance pointer for faster access */
    pTx = pLldp->pTx;

    /* allocate LLDP tx buffer with all its structures */
    res = goal_lldpTxBufferNew(pTx);
    if GOAL_RES_ERR(res) {
        return res;
    }

    /* create Tx timer */
    res = goal_timerCreate(&pTx->pTmrSend, GOAL_TIMER_LOW);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("creating LLDP timer failed");
    }

    /* set default option values */
    pTx->msgTxInterval = GOAL_LLDP_TX_INTERVAL_DEF;
    pTx->msgTxHold = GOAL_LLDP_TX_HOLD_DEF;

    /* set default port specific values */
    pTx->lldpDisableTx = 0;

    /* clear unset pointers */
    pTx->pTlvList = NULL;
    pTx->macGenCb = NULL;

    /* create mandetory TLVs */
    res = goal_lldpTxTlvMandetoryCreate(pLldp);
    if GOAL_RES_ERR(res) {
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Shut down the LLDP Tx instance
 *
 * This function frees all allocated resources of the LLDP Tx instance. Also
 * the Tx instance itself is freed.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxShutdown(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP TX instance */
    GOAL_LLDP_TX_TLV_LIST_T *pEntry;            /* transmit TLV list entry to delete */
    GOAL_LLDP_TX_TLV_LIST_T *pNext;             /* next transmit TLV list entry */

    /* store Tx instance pointer for faster access */
    pTx = pLldp->pTx;

    if (NULL == pTx) {
        /* nothing to shutdown */
        return GOAL_OK;
    }

    /* free Tx list entries */
    pEntry = pTx->pTlvList;
    while (NULL != pEntry) {
        pNext = pEntry->pNext;
        res = goal_memFree(&pEntry);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to free LLDP transmit TLV list entry.");
        }
        pEntry = pNext;
    }
    pTx->pTlvList = NULL;

    /* delete timer */
    if (NULL != pTx->pTmrSend) {
        goal_timerDelete(&pTx->pTmrSend);
    }

    /* release LLDP Tx buffer */
    if (NULL != pTx->pLldpBuf) {
        res = goal_queueReleaseBuf(&pTx->pLldpBuf);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to release LLDP Tx buffer.");
        }
    }

    /* free instance itself */
    res = goal_memFree(&pLldp->pTx);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to free LLDP Tx instance.");
    }

    return res;
}


/****************************************************************************/
/** Start operation of GOAL LLDP Tx
 *
 * This function activate sending timer for LLDP. Also stops current sending
 * processes, if there are still ports to send LLDP frames in case, if this
 * is a restart.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxStart(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */

    /* start transmit timer with current values */
    res = goal_timerSetup(pLldp->pTx->pTmrSend,
                          GOAL_TIMER_PERIODIC,
                          pLldp->pTx->msgTxInterval * GOAL_TIMER_SEC,
                          goal_lldpTxTimerCb,
                          pLldp,
                          GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to setup and start Tx timer");
        return res;
    }

    /* start sending in general */
    pLldp->pTx->flgRun = GOAL_TRUE;

    /* start sending of current burst */
    pLldp->pTx->txPortId = 0;
    pLldp->pTx->flgTx = GOAL_TRUE;

    return GOAL_OK;
}


/****************************************************************************/
/** Stop operation of GOAL LLDP Tx
 *
 * This function deactivate sending timer for LLDP. Also stops current sending
 * processes, if there are still ports to send LLDP frames.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxStop(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    /* stop sending in general */
    pLldp->pTx->flgRun = GOAL_FALSE;

    /* stop sending of current burst */
    pLldp->pTx->flgTx = GOAL_FALSE;

    /* stop timer, if already running */
    return goal_timerStop(pLldp->pTx->pTmrSend);
}


/****************************************************************************/
/** Configure VLAN for LLDP messages
 *
 * This function is used to enable or disable VLAN tagging for LLDP messages.
 * If it is enabled the specified VLAN ID is used in combination with the
 * appropriate priority.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxVlanSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_BOOL_T vlanEnable,                     /**< enable/disable VLAN */
    uint16_t vlanId,                            /**< VLAN ID (VID) */
    uint8_t vlanPrio                            /**< priority for event messages (PCP) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_ETH_HEADER_WITH_VLAN_T *pEthHeaderVlan; /* Ethernet with VLAN Tag */
    GOAL_LLDP_ETH_HEADER_T *pEthHeader;         /* Ethernet without VLAN Tag */

    if (GOAL_TRUE == vlanEnable) {
        /* check VLAN arguments */
        if ((GOAL_LLDP_TX_VLAN_PCP_MAX < vlanPrio) || (GOAL_LLDP_TX_VLAN_VID_MAX < vlanId)) {
            return GOAL_ERR_PARAM;
        }

        pEthHeaderVlan = (GOAL_LLDP_ETH_HEADER_WITH_VLAN_T *) pLldp->pTx->pLldpBuf->ptrData;

        /* insert VLAN Tag, if not done yet */
        if (GOAL_FALSE == pLldp->pTx->vlanTag) {
            /* move all TLVs */
            res = goal_lldpTxTlvPosUpdate(pLldp->pTx, sizeof(GOAL_LLDP_ETH_HEADER_WITH_VLAN_T), sizeof(GOAL_LLDP_ETH_HEADER_T));
            if (GOAL_RES_ERR(res)) {
                return res;
            }

            /* update EtherTypes of LLDP and VLAN */
            pEthHeaderVlan->vlanTpid_be16 = GOAL_htobe16(GOAL_ETH_ETHERTYPE_VLAN);
            pEthHeaderVlan->ethType_be16 = GOAL_htobe16(GOAL_LLDP_ETH_TYPE_LLDP);

            /* indicate inserted VLAN tag */
            pLldp->pTx->vlanTag = GOAL_TRUE;
        }

        /* set VLAN tag control information value */
        pEthHeaderVlan->vlanTci_be16 = GOAL_htobe16(goal_miEthVlanTciCreate(vlanId, vlanPrio));
    }
    else {
        /* remove VLAN tag if not done yet */
        if (GOAL_TRUE == pLldp->pTx->vlanTag) {
            /* move all TLVs */
            res = goal_lldpTxTlvPosUpdate(pLldp->pTx, sizeof(GOAL_LLDP_ETH_HEADER_T), sizeof(GOAL_LLDP_ETH_HEADER_WITH_VLAN_T));
            if (GOAL_RES_ERR(res)) {
                return res;
            }

            /* update EtherType of LLDP, removing the one of VLAN */
            pEthHeader = (GOAL_LLDP_ETH_HEADER_T *) pLldp->pTx->pLldpBuf->ptrData;
            pEthHeader->ethType_be16 = GOAL_htobe16(GOAL_LLDP_ETH_TYPE_LLDP);

            /* indicate inserted VLAN tag */
            pLldp->pTx->vlanTag = GOAL_FALSE;
        }
    }

    return GOAL_OK;
}


/****************************************************************************/
/** LLDP Tx loop
 *
 * Checks if there is a LLDP frame to send.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxLoop(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP TX instance */

    /* store Tx instance pointer for faster access */
    pTx = pLldp->pTx;

    if (GOAL_FALSE == pTx->flgTx) {
        /* sending process not started */
        return GOAL_OK;
    }

    /* check if send buffer is ready again */
    if (GOAL_TRUE == (goal_queueFlagsGet(pTx->pLldpBuf, GOAL_QUEUE_FLG_TX))) {
        goal_logDbg("buffer is not ready");
        return GOAL_OK;
    }

    /* get next possible port to send */
    res = goal_ldpCorePortNextGet(pLldp, &pTx->txPortId);
    if (GOAL_RES_ERR(res)) {
        /* no further port to send data - reset data for next sending cycle */
        pTx->txPortId = 0;
        pTx->flgTx = GOAL_FALSE;

        return GOAL_OK;
    }

    /* send frame for current port */
    if (0 == (pTx->lldpDisableTx & (GOAL_ETH_PORT_BIT(pTx->txPortId) & GOAL_ETH_PORT_BITS))) {
        goal_logDbg("Send on LLDP frame on port %"FMT_u32, pTx->txPortId);
        goal_lldpTxPort(pLldp);
    }

    /* use next port in next round of this cycle */
    pTx->txPortId++;

    return GOAL_OK;
}


/****************************************************************************/
/** Add a transmit TLV
 *
 * This function registers a transmit TLV ID, OUI and Subtype ID, also registers an
 * optional TLV transmit callback, which is called directly before an LLDP frame is sent.
 *
 * Initial Data of the TLV are empty, and must be set with goal_lldpTxTlvValueSet().
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxTlvAdd(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_TLV_SEND_CB_T txCb                /**< send calback */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP Tx instance */
    GOAL_LLDP_TX_TLV_LIST_T *pEntry = NULL;     /* new transmit TLV list entry */

    /* prevent registering of End Of LLDPDU TLV */
    if (GOAL_LLDP_TLV_TYPE_EOF == tlvId) {
        goal_logErr("End Of LLDPDU TLV is directly handled by GOAL LLDP and is not allowed to be registered");
        return GOAL_ERROR;
    }

    /* get GOAL LLDP Tx instance for faster access */
    pTx = pLldp->pTx;

    /* get list entry, or create new one, if non-existent */
    res = goal_lldpTxEntryGet(pTx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
    if (GOAL_RES_ERR(res)) {
        res = goal_lldpTxEntryCreate(pTx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to create new Tx element");
            return res;
        }
    }

    /* store callback */
    if (NULL != pEntry->txCb) {
        goal_logWarn("The Tx TLV callback of TLV with ID %u will be overwritten.", tlvId);
    }
    pEntry->txCb = txCb;

    return GOAL_OK;
}


/****************************************************************************/
/** Set value of a TLV to be transmitted
 *
 * The value is directly stored in the prepared LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxTlvValueSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    uint8_t *pData,                             /**< data to set */
    uint16_t tlvDataLen                         /**< length of TLV data */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP Tx instance */
    GOAL_LLDP_TX_TLV_LIST_T *pEntry = NULL;     /* transmit TLV list entry */

    /* get GOAL LLDP Tx instance for faster access */
    pTx = pLldp->pTx;

    /* get list entry, or create new one, if non-existent */
    res = goal_lldpTxEntryGet(pTx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
    if GOAL_RES_ERR(res) {
        goal_logErr("Did not found TLV ID %u", tlvId);
        return res;
    }

    /* check if new data fit into frame */
    if (pTx->pLldpBuf->bufSize < (pTx->pLldpBuf->dataLen - pEntry->dataLen + tlvDataLen)) {
        goal_logErr("New data don't fit into LLDP transmit buffer");
        return GOAL_ERR_OVERFLOW;
    }

    if (pEntry->dataLen != tlvDataLen) {
        /* update positions of all folowing TLV data in frame */
        res = goal_lldpTxTlvPosUpdate(pTx,
                                      pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen + tlvDataLen,
                                      pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen + pEntry->dataLen);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to update Tx LLDP frame");
            return res;
        }
    }

    /* update TLV header */
    GOAL_LLDP_TLV_HEADER_SET(&pTx->pLldpBuf->ptrData[pEntry->pos], tlvId, tlvDataLen + pEntry->subHeaderLen);

    /* store data */
    GOAL_MEMCPY(&pTx->pLldpBuf->ptrData[pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen], pData, tlvDataLen);
    pEntry->dataLen = tlvDataLen;

    return GOAL_OK;
}


/****************************************************************************/
/** Get value of a TLV to be transmitted
 *
 * Get the pointer into the LLDP frame to transmit, and the length of the TLV data
 * in this frame (excluding header and subheader).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxTlvValueGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127 */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t **ppData,                           /**< [out] data of TLV (without OUI and subtype) */
    uint16_t *pDataLen                          /**< [out] length of data of TLV (without OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP Tx instance */
    GOAL_LLDP_TX_TLV_LIST_T *pEntry = NULL;     /* transmit TLV list entry */

    /* get GOAL LLDP Tx instance for faster access */
    pTx = pLldp->pTx;

    /* get list entry, or create new one, if non-existent */
    res = goal_lldpTxEntryGet(pTx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
    if GOAL_RES_ERR(res) {
        goal_logErr("Did not found TLV ID %u", tlvId);
        return res;
    }

    /* update port specific data */
    if (NULL != pEntry->txCb) {
        pEntry->txCb(pLldp,
                     portIdx,
                     pEntry->tlvId,
                     pEntry->tlvOuid,
                     pEntry->tlvSubtypeId,
                     &pTx->pLldpBuf->ptrData[pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen],
                     pEntry->dataLen);
    }

    /* get data */
    *ppData = &pTx->pLldpBuf->ptrData[pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen];
    *pDataLen = pEntry->dataLen;

    return GOAL_OK;
}


/****************************************************************************/
/** Set the hold time
 *
 * Set the number of LLDP frames the peer must not receive, until it assumes
 * that our device is not valid anymore.
 * Also recalculate the TTL value, which is sent in each LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxHoldSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t msgTxHold                           /**< tx hold time value */
)
{
    GOAL_STATUS_T res;                          /* result */

    if ((GOAL_LLDP_TX_HOLD_MIN > msgTxHold) || (GOAL_LLDP_TX_HOLD_MAX < msgTxHold)) {
        return GOAL_ERR_PARAM;
    }

    /* store data */
    pLldp->pTx->msgTxHold = msgTxHold;

    /* re-calculate TTL based on msgTxInterval and msgTxHold */
    res = goal_lldpTxTtlUpdate(pLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to update TTL value");
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Set the Tx interval time
 *
 * Set the number of seconds between sending of two LLDP frames on the same port.
 * Also recalculate the TTL value, which is sent in each LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxIntervalSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint16_t msgTxInterval                      /**< tx interval time value in seconds */
)
{
    GOAL_STATUS_T res;                          /* result */

    if ((GOAL_LLDP_TX_INTERVAL_MIN > msgTxInterval) || (GOAL_LLDP_TX_INTERVAL_MAX < msgTxInterval)) {
        return GOAL_ERR_PARAM;
    }

    /* store data */
    pLldp->pTx->msgTxInterval = msgTxInterval;

    /* re-calculate TTL based on msgTxInterval and msgTxHold */
    res = goal_lldpTxTtlUpdate(pLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to update TTL value");
    }

    /* reset timer after timer value change */
    if (GOAL_RES_OK(res) && (GOAL_TRUE == pLldp->pTx->flgRun)) {
        res = goal_lldpTxStop(pLldp);
        if (GOAL_RES_OK(res)) {
            res = goal_lldpTxStart(pLldp);
        }
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to restart LLDP timer");
        }
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Set the Tx disable flags
 *
 * Each bit corresponds to a port. If the bit is set, transmission is disabled
 * for this port.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxDisablePortFlagsSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint32_t txDisableFlags                     /**< Tx disable flags */
)
{
    /* store data */
    pLldp->pTx->lldpDisableTx = txDisableFlags;

    return GOAL_OK;
}


/****************************************************************************/
/** Get the Tx disable flags
 *
 * Each bit corresponds to a port. If the bit is set, transmission is disabled
 * for this port.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxDisablePortFlagsGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint32_t *pTxDisableFlags                   /**< Tx disable flags */
)
{
    /* store data */
    *pTxDisableFlags = pLldp->pTx->lldpDisableTx;

    return GOAL_OK;
}


/****************************************************************************/
/** Set MAC address genertion callback
 *
 * Set a Callback which is called directly before sending the LLDP frame on a
 * given port. This allows to use a port MAC address instead of the device MAC
 * address in the LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxMacGenCbSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_LLDP_MACGEN_CB_T macGenCb              /**< MAC address generation callback */
)
{
    pLldp->pTx->macGenCb = macGenCb;

    return GOAL_OK;
}


/****************************************************************************/
/** Inform GOAL of needed net buffers
 *
 * Informs GOAL that one net buffer is permanently used by a new LLDP Tx instance.
 * Also directly stores this buffer in the instance and initializes it.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxBufferNew(
    GOAL_LLDP_TX_INSTANCE_T *pTx                /**< GOAL LLDP TX instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t macLldp[] = GOAL_LLDP_MAC_ADDR;     /* LLDP multicast address */
    GOAL_LLDP_ETH_HEADER_T *pEthHeader;         /* Ethernet Header */

    /* request number of buffers needed for TX handling */
    res = goal_queuePoolBufsReq(GOAL_ID_LLDP,
                                GOAL_NETBUF_SIZE,
                                GOAL_LLDP_TX_BUF_NUM_FIXED,
                                GOAL_LLDP_TX_BUF_NUM_TEMP);
    if GOAL_RES_ERR(res) {
        goal_logErr("Failed to registered needed Tx buffers");
        return res;
    }


    /* allocate LLDP buffer to send */
    res = goal_ethGetNetBuf(&(pTx->pLldpBuf));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("No free buffer for LLDP found");
        return res;
    }

    /* mark buffer to be kept after sending */
    goal_queueFlagsSet(pTx->pLldpBuf, GOAL_QUEUE_FLG_NO_RELEASE);

    /* set Ethernet Frame header (Source Mac Address, might be updated during sending), without VLAN Tag */
    pEthHeader = (GOAL_LLDP_ETH_HEADER_T *) pTx->pLldpBuf->ptrData;
    GOAL_MEMCPY(pEthHeader->macDst, macLldp, MAC_ADDR_LEN);
    res = goal_ethMacAddrGet(GOAL_ETH_PORT_HOST, (GOAL_ETH_MAC_ADDR_T *) &pEthHeader->macSrc);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to get Device MAC address");
        return res;
    }
    GOAL_htobe16_p(&pEthHeader->ethType_be16, GOAL_LLDP_ETH_TYPE_LLDP);
    pTx->pLldpBuf->dataLen = sizeof(GOAL_LLDP_ETH_HEADER_T);

    /* indicate missing VLAN tag */
    pTx->vlanTag = GOAL_FALSE;

    /* Add End TLV from end of the LLDP buffer */
    GOAL_LLDP_TLV_END_SET(&pTx->pLldpBuf->ptrData[pTx->pLldpBuf->dataLen]);
    pTx->pLldpBuf->dataLen += GOAL_LLDP_TLV_END_SIZE;

    return GOAL_OK;

}


/****************************************************************************/
/** Create Tx handling of mandetory TLV
 *
 * Create handling of the mandetory TLVs Chassis ID, Port ID and TTL, populating
 * with default entries. No Tx callback is registered. Both can be updated using
 * goal_lldpTxTlvAdd() and goal_lldpTxTlvValueSet().
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxTlvMandetoryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t dataCahssisIdDefault[GOAL_LLDP_CHASSISID_LEN_STR_TO_TLV(MAC_ADDR_LEN)]; /* default data for Chassis ID */
    GOAL_LLDP_TLV_CHASSISID_T *pChassisIdDefault; /* pointer to default data for Chassis ID */
    uint8_t dataPortDefault[] = {GOAL_LLDP_PORTID_SUBTYPE_LOCAL, 'p', 'o', 'r', 't',}; /* default data for Port ID */

    /* Chassis ID */
    res = goal_lldpTxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_CHASSISID,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    pChassisIdDefault = (GOAL_LLDP_TLV_CHASSISID_T *) &dataCahssisIdDefault[0];
    pChassisIdDefault->subtype = GOAL_LLDP_CHASSISID_SUBTYPE_MAC;
    res = goal_ethMacAddrGet(GOAL_ETH_PORT_HOST, (GOAL_ETH_MAC_ADDR_T *) pChassisIdDefault->str);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    res = goal_lldpTxTlvValueSet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_CHASSISID,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 (uint8_t *) pChassisIdDefault,
                                 GOAL_LLDP_CHASSISID_LEN_STR_TO_TLV(MAC_ADDR_LEN));
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Port ID */
    res = goal_lldpTxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_PORTID,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    res = goal_lldpTxTlvValueSet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_PORTID,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 &dataPortDefault[0],
                                 sizeof(dataPortDefault));
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* TTL */
    res = goal_lldpTxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_TTL,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    res = goal_lldpTxTtlUpdate(pLldp);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Get Tx TLV entry
 *
 * Looks up the registered Tx TLV handlings, returning the corresponding list entry.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxEntryGet(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_TX_TLV_LIST_T **ppEntry           /**< found transmit TLV list entry */
)
{
    GOAL_LLDP_TX_TLV_LIST_T *pEntry;            /* transmit TLV list entry */

    GOAL_LL_FOREACH(pTx->pTlvList, pEntry) {
        if ((pEntry->tlvId == tlvId) && (pEntry->tlvOuid == tlvOuid) && (pEntry->tlvSubtypeId == tlvSubtypeId)) {
            /* found element in list */
            break;
        }
    }

    if (NULL == pEntry) {
        return GOAL_ERR_NOT_FOUND;
    }

    *ppEntry = pEntry;
    return GOAL_OK;

}


/****************************************************************************/
/** Create new Tx TLV entry
 *
 * Create a new list entry for Tx TLV handling.
 *
 * It is assumed, that the TLV ID (or the TLV OUI and the TLV Subtype in case of
 * TLV ID == 127) is not used. This must be checked before, e.g. using goal_lldpTxEntryGet().
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxEntryCreate(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_TX_TLV_LIST_T **ppEntry           /**< created transmit TLV list entry */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_TLV_LIST_T *pEntry = NULL;     /* new transmit TLV list entry */
    uint8_t subHeaderLen;                       /* length of sub header length (only for TLV ID == 127) */

    /* get subheader length */
    if (GOAL_LLDP_TLV_TYPE_OS_EXT == tlvId) {
        subHeaderLen = GOAL_LLDP_TLV_LEN_OUI + GOAL_LLDP_TLV_LEN_SUBTYPE;
    }
    else {
        subHeaderLen = 0;
    }

    /* check if data fit into LLDP frame */
    if (pTx->pLldpBuf->bufSize < (pTx->pLldpBuf->dataLen + GOAL_LLDP_TLV_HEADER_SIZE + subHeaderLen)) {
        return GOAL_ERR_OVERFLOW;
    }

    /* create new element */
    res = goal_memCalloc(&pEntry, sizeof(GOAL_LLDP_TX_TLV_LIST_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create Tx TLV list element");
        return res;
    }

    /* add element to end of list */
    GOAL_LL_APPEND(pTx->pTlvList, pEntry);

    /* set ID */
    pEntry->tlvId = tlvId;
    pEntry->tlvOuid = tlvOuid;
    pEntry->tlvSubtypeId = tlvSubtypeId;

    /* temporary remove End TLV from end of the LLDP buffer */
    pTx->pLldpBuf->dataLen -= GOAL_LLDP_TLV_END_SIZE;

    /* set information of TLV data */
    pEntry->pos = pTx->pLldpBuf->dataLen;
    pEntry->dataLen = 0;

    /* set header (length corresponds empty data field) */
    GOAL_LLDP_TLV_HEADER_SET(&pTx->pLldpBuf->ptrData[pTx->pLldpBuf->dataLen], tlvId, subHeaderLen);
    pTx->pLldpBuf->dataLen += GOAL_LLDP_TLV_HEADER_SIZE;

    /* set subheader */
    if (GOAL_LLDP_TLV_TYPE_OS_EXT == tlvId) {
        GOAL_htobe24_p(&pTx->pLldpBuf->ptrData[pTx->pLldpBuf->dataLen], tlvOuid);
        pTx->pLldpBuf->dataLen += GOAL_LLDP_TLV_LEN_OUI;
        pTx->pLldpBuf->ptrData[pTx->pLldpBuf->dataLen] = tlvSubtypeId;
        pTx->pLldpBuf->dataLen += GOAL_LLDP_TLV_LEN_SUBTYPE;
    }
    pEntry->subHeaderLen = subHeaderLen;

    /* re-add End TLV */
    GOAL_LLDP_TLV_END_SET(&pTx->pLldpBuf->ptrData[pTx->pLldpBuf->dataLen]);
    pTx->pLldpBuf->dataLen += GOAL_LLDP_TLV_END_SIZE;

    /* store result */
    *ppEntry = pEntry;

    return GOAL_OK;
}


/****************************************************************************/
/** Update TLV positions in LLDP Frame
 *
 * Moves all TLVs starting at or after the given old position in the LLDP frame.
 * The number of bytes moved corresponds the difference between the new and the old
 * position.
 *
 * Example:
 *  old: TLV1 TLV2 TLV3 TLV4        (posOld is start of TLV3)
 *  new: TLV1 TLV2... TLV3 TLV4     (posNew is start of TLV3)
 *  TLV2 incrases its length by 3 bytes, therefore TLV3 and TLV4 must be moved further by 3 Bytes.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxTlvPosUpdate(
    GOAL_LLDP_TX_INSTANCE_T *pTx,               /**< GOAL LLDP TX instance */
    uint16_t posNew,                            /**< new start position */
    uint16_t posOld                             /**< old start position in frame, which shall be moved to new one */
)
{
    GOAL_LLDP_TX_TLV_LIST_T *pEntry = NULL;     /* transmit TLV list entry */

    /* update all TLV data in frame */
    GOAL_MEMMOVE(&pTx->pLldpBuf->ptrData[posNew],
                 &pTx->pLldpBuf->ptrData[posOld],
                 pTx->pLldpBuf->dataLen - posOld);
    pTx->pLldpBuf->dataLen -= posOld;
    pTx->pLldpBuf->dataLen += posNew;

    /* update all position of Tx elements */
    GOAL_LL_FOREACH(pTx->pTlvList, pEntry) {
        if (posOld <= pEntry->pos) {
            pEntry->pos += posNew;
            pEntry->pos -= posOld;
        }
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Timer function for generating of LLDP frames
 *
 * Set the LLDP identity trigger flag.
 */
static void goal_lldpTxTimerCb(
    void *pArg                                  /**< timer argument */
)
{
    GOAL_LLDP_INSTANCE_T *pLldp = (GOAL_LLDP_INSTANCE_T *) pArg; /* GOAL LLDP instance */

    pLldp->pTx->flgTx = GOAL_TRUE;
}


/****************************************************************************/
/** Send LLDP frame on specified port
 *
 * Updates Port MAC address, call all Tx callbacks and send LLDP frame on
 * port specified in the Tx LLDP instance.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxPort(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_TX_INSTANCE_T *pTx;               /* GOAL LLDP TX instance */
    GOAL_LLDP_ETH_HEADER_T *pEthHeader;         /* Ethernet Header */
    GOAL_BUFFER_T *pLldpBufTmp;                 /* temporary LLDP buffer */

    /* store pointers for faster access */
    pTx = pLldp->pTx;
    pEthHeader = (GOAL_LLDP_ETH_HEADER_T *) pTx->pLldpBuf->ptrData;

    /* update MAC address if needed */
    if (NULL != pTx->macGenCb) {
        res = pTx->macGenCb(pLldp, pTx->txPortId, &pEthHeader->macSrc);
        if (GOAL_RES_ERR(res)) {
            goal_logWarn("Port MAC Address generation callback returned error - use device MAC address instead");
            res = goal_ethMacAddrGet(GOAL_ETH_PORT_HOST, (GOAL_ETH_MAC_ADDR_T *) &pEthHeader->macSrc[0]);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("Failed to get Device MAC address");
                return res;
            }
        }
    }

    /* update all port specific TLVs */
    goal_lldpTxUpdateCallbacksExec(pLldp);

    /* send frame */
    pTx->pLldpBuf->netPort = pTx->txPortId;
    pLldpBufTmp = pTx->pLldpBuf;
    res = goal_ethSend((void **) &pLldpBufTmp, GOAL_NET_TX_LLDP);

    return res;
}


/****************************************************************************/
/** Call all registered Tx update callbacks
 *
 * Checks each Tx TLV entry for a registered Tx update callback, and calls if there
 * is any. The callback itself can directly manipulate the data in the LLDP frame
 * if the length of the TLV is not changed, or may call corresponding API, allowing
 * to change the length of the TLV.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxUpdateCallbacksExec(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_LLDP_TX_TLV_LIST_T *pEntry;            /* transmit TLV lsit entry */

    GOAL_LL_FOREACH(pLldp->pTx->pTlvList, pEntry) {
        if (NULL == pEntry->txCb) {
            /* no callback registered - skip element */
            continue;
        }

        /* call registered callback */
        pEntry->txCb(pLldp,
                     pLldp->pTx->txPortId,
                     pEntry->tlvId,
                     pEntry->tlvOuid,
                     pEntry->tlvSubtypeId,
                     &pLldp->pTx->pLldpBuf->ptrData[pEntry->pos + GOAL_LLDP_TLV_HEADER_SIZE + pEntry->subHeaderLen],
                     pEntry->dataLen);
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Update TTL
 *
 * Update the TTL value in the prepared LLDP frame to send.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpTxTtlUpdate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t ttlRaw;                            /* time to live value calculation result (secured against overflow) */
    GOAL_LLDP_TLV_TTL_T ttl;                    /* TTL data in LLDP frame */

    /* calculate txTTL */
    ttlRaw = ((uint32_t) pLldp->pTx->msgTxHold) * ((uint32_t) pLldp->pTx->msgTxInterval) + 1;
    ttl.ttl_be16 = GOAL_htobe16((uint16_t) ((GOAL_LLDP_TX_TTL_MAX < ttlRaw) ? GOAL_LLDP_TX_TTL_MAX : ttlRaw));

    res = goal_lldpTxTlvValueSet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_TTL,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 (uint8_t *) &ttl,
                                 (uint16_t) sizeof(ttl));

    return res;
}
