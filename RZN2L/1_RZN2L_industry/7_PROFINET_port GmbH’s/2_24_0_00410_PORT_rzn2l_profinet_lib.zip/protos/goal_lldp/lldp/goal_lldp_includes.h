/** @file
 *
 * @brief GOAL LLDP stack
 *
 * This header file must be included by all files that are part of the GOAL
 * LLDP stack.
 *
 * @copyright
 * Copyright 0022 port GmbH
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */


#ifndef GOAL_LDDP_INCLUDES
#define GOAL_LDDP_INCLUDES


/****************************************************************************/
/* Includes */
/****************************************************************************/
#include <goal_lldp.h>
#include <goal_lldp_core.h>
#include <goal_lldp_tx.h>
#include <goal_lldp_rx.h>

#endif /* GOAL_LDDP_INCLUDES */
