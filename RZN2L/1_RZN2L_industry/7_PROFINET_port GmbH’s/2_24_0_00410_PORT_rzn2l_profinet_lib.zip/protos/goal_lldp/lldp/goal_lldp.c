/** @file
 *
 * @brief GOAL LLDP API
 *
 * This module implements the public API for the GOAL LLDP implementation.
 *
 * @copyright
 * Copyright 2023 port GmbH
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_LLDP
#include <goal_includes.h>
#include <goal_lldp_includes.h>


/****************************************************************************/
/* Variables */
/****************************************************************************/
static GOAL_LLDP_INSTANCE_T *mpListInst = NULL; /**< GOAL LLDP instance list */
static GOAL_STAGE_HANDLER_T mStageMem;          /**< memory init stage */
static GOAL_STAGE_HANDLER_T mStageShutdown;     /**< modules shutdown stage */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_lldpStageMemInit(
    void
);

static GOAL_STATUS_T goal_lldpShutdown(
    void
);

static void goal_lldpPhyStateCb(
    GOAL_ETH_PORT_T port,                       /**< GOAL port id */
    uint32_t maskChg,                           /**< change mask */
    GOAL_ETH_PORT_STATE_T *pState               /**< port state ptr */
);


/****************************************************************************/
/** Register GOAL LLDP
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_mainStageReg(GOAL_STAGE_MEM,
                            &mStageMem,
                            GOAL_STAGE_INIT,
                            goal_lldpStageMemInit);

    if GOAL_RES_OK(res) {
        res = goal_mainStageReg(GOAL_STAGE_MODULES,
                                &mStageShutdown,
                                GOAL_STAGE_SHUTDOWN,
                                goal_lldpShutdown);
    }

    return res;
}


/****************************************************************************/
/** Create new GOAL LLDP instance
 *
 * Create a GOAL LLDP instance for the given ID.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpNew(
    GOAL_LLDP_HANDLE_T **ppGlldp,               /**< [out] GOAL LLDP instance */
    uint32_t id                                 /**< instance id */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* GOAL LLDP instance handle */
    GOAL_BOOL_T flgInstFirst;                   /* this is the first created instance */
    uint32_t cnt;                               /* counter */
    uint32_t numPorts;                          /* number of ports */

    /* check if this is the first instance */
    if (NULL == mpListInst) {
        flgInstFirst = GOAL_TRUE;
    }
    else {
        flgInstFirst = GOAL_FALSE;
    }

    /* create generic GOAL instance */
    res = goal_instNew((GOAL_INSTANCE_T **) &pLldp, sizeof(GOAL_LLDP_INSTANCE_T), GOAL_ID_LLDP, id, "GOAL LLDP");
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create generic instance");
        return res;
    }

    /* initialize LLDP instance */
    res = goal_lldpCoreNew(pLldp, flgInstFirst);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to initialize LLDP instance");
    }

    /* add instance to list handle - ignore initialization error, preventing memory leak in shutdown phase */
    GOAL_LL_APPEND(mpListInst, pLldp);

    /* add PHY callbacks usable by all LLDP instances */
    if (GOAL_RES_OK(res) && (GOAL_TRUE == flgInstFirst)) {
        /* get number of ports */
        res = goal_ethCmd(GOAL_ETH_CMD_PORT_COUNT, GOAL_FALSE, GOAL_ETH_PORT_HOST, &numPorts);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("failed to get number of ports");
        }

        /* register Phy state callbacks for each external port */
        for (cnt = 0; (cnt < numPorts) && (GOAL_RES_OK(res)); cnt++) {
            res = goal_ethPortStateCbReg(cnt, goal_lldpPhyStateCb);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("failed to register Phy State Change callback");
            }
        }
    }

    /* store out values */
    if GOAL_RES_OK(res) {
        *ppGlldp = (GOAL_LLDP_HANDLE_T *) pLldp;
    }

    return res;
}


/****************************************************************************/
/** Start operation of GOAL LLDP
 *
 * This function starts operation of GOAL LLDP.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpStart(
    GOAL_LLDP_HANDLE_T *pGlldp                  /**< GOAL LLDP handle */
)
{
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance data */
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpCoreStart(pLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to start GOAL LLDP");
    }

    return res;
}


/****************************************************************************/
/** Stop operation of GOAL LLDP
 *
 * This function stops operation of GOAL LLDP.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpStop(
    GOAL_LLDP_HANDLE_T *pGlldp                  /**< GOAL LLDP handle */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpCoreStop(pLldp);

    return res;
}


/****************************************************************************/
/** Configure VLAN for LLDP messages
 *
 * This function is used to enable or disable VLAN tagging for LLDP messages.
 * If it is enabled the specified VLAN ID is used in combination with the
 * appropriate priority.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpVlanTxSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    GOAL_BOOL_T vlanEnable,                     /**< enable/disable VLAN */
    uint16_t vlanId,                            /**< VLAN ID (VID) */
    uint8_t vlanPrio                            /**< priority for event messages (PCP) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxVlanSet(pLldp, vlanEnable, vlanId, vlanPrio);

    return res;
}


/****************************************************************************/
/** Add transmit TLV handling
 *
 * This function registers a transmit TLV ID, also registers an optional
 * TLV transmit callback, which is called directly before an LLDP frame is sent.
 *
 * Initial Data of the TLV are empty, and must be set with goal_lldpTlvTxValueSet().
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxAdd(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint8_t tlvId,                              /**< TLV type id */
    GOAL_LLDP_TLV_SEND_CB_T txCb                /**< send calback (may be NULL) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvAdd(pLldp,
                            tlvId,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            txCb);

    return res;
}


/****************************************************************************/
/** Add transmit TLV handling for organisation specific ID
 *
 * This function registers a transmit TLV with ID 127 and given OUI and
 * organisation specific subtype, also registers an optional
 * TLV transmit callback, which is called directly before an LLDP frame is sent.
 *
 * Initial Data of the TLV are empty, and must be set with goal_lldpTlvTxOsValueSet().
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxOsAdd(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t tlvOuid,                           /**< OUI of custom TLV */
    uint8_t tlvSubtypeId,                       /**< subtype id of custom TLV */
    GOAL_LLDP_TLV_SEND_CB_T txCb                /**< send calback (may be NULL) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_OS_EXT,
                            tlvOuid,
                            tlvSubtypeId,
                            txCb);

    return res;
}


/****************************************************************************/
/** Set value of a TLV to be transmitted
 *
 * The value is directly stored in the prepared LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxValueSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint8_t tlvId,                              /**< TLV type id */
    uint8_t *pData,                             /**< data to set */
    uint16_t tlvDataLen                         /**< length of TLV data */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvValueSet(pLldp,
                                 tlvId,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 pData,
                                 tlvDataLen);

    return res;
}


/****************************************************************************/
/** Get value of a TLV to be transmitted
 *
 * The value is directly taken from the prepared LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxValueGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t tlvId,                              /**< TLV type id */
    uint8_t **ppData,                           /**< [out] data of TLV (without OUI and subtype) */
    uint16_t *ptlvDataLen                       /**< [out] length of data of TLV (without OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvValueGet(pLldp,
                                 tlvId,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 portIdx,
                                 ppData,
                                 ptlvDataLen);

    return res;
}


/****************************************************************************/
/** Set value of a TLV to be transmitted with organisation specific ID
 *
 * The value is directly stored in the prepared LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxOsValueSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t tlvOuid,                           /**< OUI of custom TLV */
    uint8_t tlvSubtypeId,                       /**< subtype id of custom TLV */
    uint8_t *pData,                             /**< data to set */
    uint16_t tlvDataLen                         /**< length of TLV data */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvValueSet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_OS_EXT,
                                 tlvOuid,
                                 tlvSubtypeId,
                                 pData,
                                 tlvDataLen);

    return res;
}


/****************************************************************************/
/** Get value of a TLV to be transmitted with organisation specific ID
 *
 * The value is directly taken from the prepared LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvTxOsValueGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t tlvOuid,                           /**< OUI of custom TLV */
    uint8_t tlvSubtypeId,                       /**< subtype id of custom TLV */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t **ppData,                           /**< [out] data of TLV (without OUI and subtype) */
    uint16_t *ptlvDataLen                       /**< [out] length of data of TLV (without OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpTxTlvValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_OS_EXT,
                                 tlvOuid,
                                 tlvSubtypeId,
                                 portIdx,
                                 ppData,
                                 ptlvDataLen);

    return res;
}


/****************************************************************************/
/** Add receive TLV handling
 *
 * Add a TLV which is listened on LLDP frame receiption. Up the the given
 * ammount of bytes of the received data are stored per port.
 * Also a receive callback can be registered, which is called after receiving
 * and a LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvRxAdd(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint8_t tlvId,                              /**< TLV type id */
    uint16_t tlvsizeMax,                        /**< maximum size of TLV */
    GOAL_LLDP_TLV_RECEIVE_CB_T rxCb             /**< receive callback */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxTlvAdd(pLldp,
                            tlvId,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            tlvsizeMax,
                            rxCb);
    return res;
}


/****************************************************************************/
/** Add receive TLV handling for organisation specific ID
 *
 * Add a TLV which is listened on LLDP frame receiption. Up the the given
 * ammount of bytes of the received data are stored per port.
 * Also a receive callback can be registered, which is called after receiving
 * and a LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvRxOsAdd(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t tlvOuid,                           /**< OUI of custom TLV */
    uint8_t tlvSubtypeId,                       /**< subtype id of custom TLV */
    uint16_t tlvsizeMax,                        /**< maximum size of TLV */
    GOAL_LLDP_TLV_RECEIVE_CB_T rxCb             /**< receive call back */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_OS_EXT,
                            tlvOuid,
                            tlvSubtypeId,
                            tlvsizeMax,
                            rxCb);

    return res;
}


/****************************************************************************/
/** Get information of connected peer
 *
 * If no peer is connected, a corresponding error code is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpPeerInfoGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    GOAL_LLDP_REMOTE_T **ppRemote               /**< [out] remote device information */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxPeerInfoGet(pLldp, portIdx, ppRemote);

    return res;
}


/****************************************************************************/
/** Get received TLV value
 *
 * Get the value of an received TLV with the given TLV ID on the given port.
 * If the data are invalid, e.g. if a remite device timed out, GOAL_ERR_NOT_FOUND
 * is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvRxValueGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint8_t tlvId,                              /**< TLV type id */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t **ppData,                           /**< [out] data of TLV (withoit OUI and subtype) */
    uint16_t *pDataLen                          /**< [out] length of data of TLV (withoit OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxTlvValueGet(pLldp,
                                 tlvId,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 portIdx,
                                 ppData,
                                 pDataLen);
    return res;
}


/****************************************************************************/
/** Get received TLV value for organisation specific ID
 *
 * Get the value of an received TLV with organisation specific ID the given
 * OUID and TLV subtype on the given port.
 * If the data are invalid, e.g. if a remite device timed out, GOAL_ERR_NOT_FOUND
 * is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTlvRxOsValueGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t tlvOuid,                           /**< OUI of custom TLV */
    uint8_t tlvSubtypeId,                       /**< subtype id */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t **ppData,                           /**< [out] data of TLV (withoit OUI and subtype) */
    uint16_t *pDataLen                          /**< [out] length of data of TLV (withoit OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxTlvValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_OS_EXT,
                                 tlvOuid,
                                 tlvSubtypeId,
                                 portIdx,
                                 ppData,
                                 pDataLen);
    return res;
}


/****************************************************************************/
/** Register a Frame reception callback
 *
 * This callback is called on frame reception. If the TLVs are valid, it is
 * called diectly before and directly after all registered RX TLV callbacks.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRemoteUpdateHandlerRegister(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    GOAL_LLDP_REMOTE_UPDATE_CB_T remoteUpdateCb /**< Remote Update Callback handler */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    res = goal_lldpRxRemoteUpdateHandlerRegister(pLldp, remoteUpdateCb);

    return res;
}


/****************************************************************************/
/** Set the hold time
 *
 * Set the number of LLDP frames the peer must not receive, until it assumes
 * that our device is not valid anymore.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpMsgTxHoldSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint8_t msgTxHold                           /**< tx hold time value */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* store data */
    res = goal_lldpTxHoldSet(pLldp, msgTxHold);

    return res;
}


/****************************************************************************/
/** Set the Tx interval time
 *
 * Set the number of seconds between sending of two LLDP frames on the same port.
 * The value must be not 0.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpMsgTxIntervalSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint16_t msgTxInterval                      /**< tx interval time value in seconds */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }
    if (0 == msgTxInterval) {
        return GOAL_ERR_PARAM;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* store data */
    res = goal_lldpTxIntervalSet(pLldp, msgTxInterval);

    return res;
}


/****************************************************************************/
/** Set arbitrary user data
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpUserDataSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    void *pUserData                             /**< arbitrary user data */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* store data */
    res = goal_lldpCoreUserDataSet(pLldp, pUserData);

    return res;
}


/****************************************************************************/
/** Get arbitrary user data
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpUserDataGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    void **ppUserData                           /**< [out] arbitrary user data */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if ((NULL == pGlldp) || (NULL == ppUserData)) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* get data */
    res = goal_lldpCoreUserDataGet(pLldp, ppUserData);

    return res;
}


/****************************************************************************/
/** Set the Tx disable flags
 *
 * Each bit corresponds to a port. If the bit is set, transmission is disabled
 * for this port.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpTxDisableFlagsSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t txDisableFlags                     /**< Tx disable flags */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* store data */
    res = goal_lldpTxDisablePortFlagsSet(pLldp, txDisableFlags);

    return res;
}


/****************************************************************************/
/** Set MAC address genertion callback
 *
 * Set a Callback which is called directly before sending the LLDP frame on a
 * given port. This allows to use a port MAC address instead of the device MAC
 * address in the LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpPortMacGenCbSet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    GOAL_LLDP_MACGEN_CB_T macGenCb              /**< MAC address generation callback */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* store data */
    res = goal_lldpTxMacGenCbSet(pLldp, macGenCb);

    return res;
}


/****************************************************************************/
/** Get current SysUpTime
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpSysUpTimeGet(
    GOAL_LLDP_HANDLE_T *pGlldp,                 /**< GOAL LLDP handle */
    uint32_t *pSysUpTime                        /**< [out] SysUpTime in hundreds of seconds */
)
{
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* check arguments */
    if (NULL == pGlldp) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* get instance from handle */
    pLldp = (GOAL_LLDP_INSTANCE_T *) pGlldp;

    /* get sysUpTime */
    *pSysUpTime = goal_lldpCoreSysUpTimeGet(pLldp);

    return GOAL_OK;
}


/****************************************************************************/
/** Stage Memory Initialization
 *
 * Initialize LLDP components, which require memory allocation.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpStageMemInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_INSTANCE_LIST_T *pListInst = NULL;     /* GOAL LLDP instance list */

    /* create GOAL LLDP instance list */
    res = goal_instListNew(&pListInst, GOAL_ID_LLDP);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create GOAL LLDP instance list");
    }

    /* list reference is available via GOAL instance API */
    UNUSEDARG(pListInst);

    return res;
}


/****************************************************************************/
/** Shut down GOAL LLDP module
 *
 * This function releases all resources.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpShutdown(
    void
)
{
    GOAL_LLDP_INSTANCE_T *pLldp;                /* current GOAL LLDP handle */
    GOAL_LLDP_INSTANCE_T *pLldpNext;            /* next GOAL LLDP handle */

    /* free all allocated resources of all instances */
    pLldp = mpListInst;
    while (pLldp) {
        goal_lldpCoreShutdown((GOAL_LLDP_INSTANCE_T *) pLldp);
        pLldpNext = pLldp->pNext;
        goal_instFree((GOAL_INSTANCE_T **) &pLldp);
        pLldp = pLldpNext;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Port state change callback
 *
 * This function is called by GOAL if one of the external ports changes its
 * status.
 */
static void goal_lldpPhyStateCb(
    GOAL_ETH_PORT_T port,                       /**< GOAL port id */
    uint32_t maskChg,                           /**< change mask */
    GOAL_ETH_PORT_STATE_T *pState               /**< port state ptr */
)
{
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP handle */

    GOAL_LL_FOREACH(mpListInst, pLldp) {
        goal_lldpCorePhyStateCb(pLldp, port, maskChg, pState);
    }
}
