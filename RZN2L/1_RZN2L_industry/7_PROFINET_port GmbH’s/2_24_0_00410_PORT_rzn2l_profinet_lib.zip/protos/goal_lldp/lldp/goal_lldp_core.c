/** @file
 *
 * @brief GOAL LLDP core
 *
 * This module implements the core of the GOAL LLDP implementation.
 *
 * @copyright
 * Copyright 2023 port GmbH
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_LLDP
#include <goal_includes.h>
#include <goal_lldp_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define GOAL_LLDP_CORE_MS_PER_HUNDERDS_OF_SECONDS 10 /**< ms in 1 / 100 s */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_lldpCoreNewInternal(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpCoreNewOnce(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpCoreShutdownInternal(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static void goal_lldpCoreLoop(
    void* pArg                                  /**< loop argument (GOAL LLDP instance) */
);

static GOAL_STATUS_T goal_lldpEthRx(
    GOAL_BUFFER_T **ppBuf                       /**< network buffer */
);


/****************************************************************************/
/** Create a new GOAL LLDP instance
 *
 * This function creates all required resources. Also creates new Rx and Tx
 * instances.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreNew(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_BOOL_T flgInstFirst                    /**< this is the first created instance */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_lldpCoreNewInternal(pLldp);

    if ((GOAL_RES_OK(res)) && (GOAL_TRUE == flgInstFirst)) {
        res = goal_lldpCoreNewOnce(pLldp);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_lldpTxNew(pLldp);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_lldpRxNew(pLldp, pLldp->core.numPorts);
    }

    return res;
}


/****************************************************************************/
/** Shut down the LLDP instance
 *
 * This function frees all allocated resources of the LLDP instance.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreShutdown(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP handle */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_lldpRxShutdown(pLldp);

    if (GOAL_RES_OK(res)) {
        res = goal_lldpTxShutdown(pLldp);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_lldpCoreShutdownInternal(pLldp);
    }

    return res;
}


/****************************************************************************/
/** Start operation of GOAL LLDP
 *
 * This function starts operation of GOAL LLDP.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreStart(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T resTot = GOAL_OK;             /* total result */
    GOAL_STATUS_T res;                          /* result */

    pLldp->core.flgRun = GOAL_TRUE;

    res = goal_lldpRxStart(pLldp);
    if GOAL_RES_ERR(res) {
        goal_logErr("Failed to start LLDP receiving");
        resTot = res;
    }

    res = goal_lldpTxStart(pLldp);
    if GOAL_RES_ERR(res) {
        goal_logErr("Failed to start LLDP sending");
        resTot = res;
    }

    return resTot;
}


/****************************************************************************/
/** Stop operation of GOAL LLDP
 *
 * This function stops operation of GOAL LLDP.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreStop(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T resTot = GOAL_OK;             /* total result */
    GOAL_STATUS_T res;                          /* result */

    res = goal_lldpTxStop(pLldp);
    if GOAL_RES_ERR(res) {
        goal_logErr("Failed to stop LLDP sending");
        resTot = res;
    }

    res = goal_lldpRxStop(pLldp);
    if GOAL_RES_ERR(res) {
        goal_logErr("Failed to stop LLDP receiving");
        resTot = res;
    }

    pLldp->core.flgRun = GOAL_FALSE;

    return resTot;
}


/****************************************************************************/
/** Set arbitrary user data
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreUserDataSet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    void *pUserData                             /**< arbitrary user data */
)
{
    pLldp->core.pUserData = pUserData;

    return GOAL_OK;
}


/****************************************************************************/
/** Get arbitrary user data
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpCoreUserDataGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    void **ppUserData                           /**< [out] arbitrary user data */
)
{
    *ppUserData = pLldp->core.pUserData;

    return GOAL_OK;
}


/****************************************************************************/
/** Port state change callback
 *
 * This function is called by GOAL if one of the external ports changes its
 * status.
 */
void goal_lldpCorePhyStateCb(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T port,                       /**< GOAL port id */
    uint32_t maskChg,                           /**< change mask */
    GOAL_ETH_PORT_STATE_T *pState               /**< port state ptr */
)
{
    if (0 != (maskChg & GOAL_ETH_PORT_STATE_LINK)) {
        if (GOAL_ETH_STATE_UP == pState->stateLink) {
            pLldp->core.portLinkUp |= (GOAL_ETH_PORT_BIT(port)& GOAL_ETH_PORT_BITS);
        }
        else {
            pLldp->core.portLinkUp &= ~(GOAL_ETH_PORT_BIT(port)& GOAL_ETH_PORT_BITS);

            /* delete remote device */
            (void) goal_lldpRxRemoteDeviceRemove(pLldp, port, GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_LINKDOWN);
        }
    }
}


/****************************************************************************/
/** Get next active port
 *
 * Check if the given port index belongs to an active port. Otherweise it is checked
 * which is the next active port index. If there is no such port, GOAL_ERR_NOT_FOUND
 * is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_ldpCorePortNextGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T *pPortId                    /**< [in,out] index of port */
)
{
    GOAL_ETH_PORT_T portId;                     /* port ID */

    for (portId = *pPortId; portId < pLldp->core.numPorts; portId++) {
        if (0 != (pLldp->core.portLinkUp & (GOAL_ETH_PORT_BIT(portId) & GOAL_ETH_PORT_BITS))) {
            /* found active port */
            *pPortId = portId;
            return GOAL_OK;
        }
    }

    /* no further port active */
    return GOAL_ERR_NOT_FOUND;
}


/****************************************************************************/
/** Get number of ports.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_ldpCorePortNumGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint32_t *pPortNum                          /**< [out] number of ports */
)
{
    *pPortNum = pLldp->core.numPorts;

    return GOAL_OK;
}


/****************************************************************************/
/** Get SysUpTime based on GOAL timestamp
 *
 * Get nunmber of hundreds of seconds since LLDP instance started.
 *
 * @returns uint32_t SysUpTime value
 */
uint32_t goal_lldpCoreSysUpTimeGet(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_TIMESTAMP_T ts;                        /* GOAL timestamp */

    ts = goal_timerTsGet();

    if (ts < pLldp->core.startTime) {
        return 0;
    }

    return (uint32_t) ((ts - pLldp->core.startTime) / GOAL_LLDP_CORE_MS_PER_HUNDERDS_OF_SECONDS);
}


/****************************************************************************/
/** Create a new GOAL LLDP instance
 *
 * This function creates all required resources.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpCoreNewInternal(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */

    pLldp->core.startTime = goal_timerTsGet();
    pLldp->core.pUserData = NULL;

    res = goal_mainLoopParamReg(goal_lldpCoreLoop, pLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to register LLDP Core loop");
    }

    return res;
}


/****************************************************************************/
/** Setup device to use LLDP
 *
 * This function setup the device allowing to receive and send LLDP frames.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpCoreNewOnce(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t stateBpdu;                         /* BPDU state */
    uint8_t macLldp[] = GOAL_LLDP_MAC_ADDR;     /* LLDP multicast address */


    pLldp->core.startTime = goal_timerTsGet();
    pLldp->core.pUserData = NULL;

    /* GOAL loop */
    res = goal_mainLoopParamReg(goal_lldpCoreLoop, pLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to register LLDP Core loop");
    }

    /* number of ports */
    res = goal_ethCmd(GOAL_ETH_CMD_PORT_COUNT, GOAL_FALSE, GOAL_ETH_PORT_HOST, &(pLldp->core.numPorts));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
    }

    /* MUlticast Mac Table entry */
    res = goal_ethMcastAdd(GOAL_ETH_PORT_MASK | GOAL_ETH_PORT_HOST, (GOAL_ETH_MAC_ADDR_T *) &macLldp);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set LLDP multicast MAC");
    }


    /* enable RX port resolution for LLDP frames
    *
    * Note: This setting is used on Linux with Switch support that routes all
    *       incoming data to interface "eth0" but has no way to tell on which
    *       port the data was received. To workaround this the switch driver
    *       provides an extra interface per Switch port ("eth1" .. "ethX").
    *       If a frame is send to one of these interfaces it is directly
    *       mapped to the matching Switch port. To receive frames via these
    *       interfaces the GOAL_ETH_CMD_RX_PORT_RES_ADD Ethernet command must
    *       be used to register a specific MAC address to the Switch driver.
    */
    if GOAL_RES_OK(res) {
        goal_ethCmd(GOAL_ETH_CMD_RX_PORT_RES_ADD, GOAL_TRUE, GOAL_ETH_PORT_HOST, &macLldp);
    }

    if (GOAL_RES_OK(res)) {
        /* try to enable BPDU forwarding if available */
        stateBpdu = GOAL_ETH_BPDU_CTRL_MGMT_FWD;
        goal_ethCmd(GOAL_ETH_CMD_BPDU, GOAL_TRUE, GOAL_ETH_PORT_HOST, &stateBpdu);
    }

    /* setup non-RT LLDP network handler */
    res = goal_ethProtoAdd(GOAL_FALSE, GOAL_LLDP_ETH_TYPE_LLDP, NULL, goal_lldpEthRx);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register lldp receive handler");
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Shut down the LLDP instance
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpCoreShutdownInternal(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    pLldp->core.flgRun = GOAL_FALSE;
    pLldp->core.pUserData = NULL;

    return GOAL_OK;
}


/****************************************************************************/
/** LLDP loop
 *
 * Checks if there is a LLDP frame to send. This function is called by
 * The GOAL main loop cyclically.
 */
static void goal_lldpCoreLoop(
    void *pArg                                  /**< loop argument (GOAL LLDP instance) */
)
{
    GOAL_LLDP_INSTANCE_T *pLldp;                /* GOAL LLDP instance */

    /* get instance from argument */
    if (NULL == pArg) {
        return;
    }
    pLldp = (GOAL_LLDP_INSTANCE_T *) pArg;

    /* only continue if LLDP is started */
    if (GOAL_FALSE == pLldp->core.flgRun) {
        return;
    }

    goal_lldpTxLoop(pLldp);
}


/****************************************************************************/
/** LLDP Ethernet Protocol handler
 *
 * Processes received LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpEthRx(
    GOAL_BUFFER_T **ppBuf                       /**< network buffer */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* forward to LLDP */
    res = goal_lldpRx(pLldp, *ppBuf);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* buffer is processed, it must be released at this point */
    goal_queueReleaseBuf(ppBuf);

    return GOAL_OK;
}
