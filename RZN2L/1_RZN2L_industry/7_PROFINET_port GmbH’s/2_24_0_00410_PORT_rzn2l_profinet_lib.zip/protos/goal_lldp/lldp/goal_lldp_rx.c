/** @file
 *
 * @brief GOAL LLDP Rx
 *
 * This module implements receiving mechanism of the GOAL LLDP implementation.
 *
 * Based on registered Rx TLV handling received data are stored and can gotten
 * by corresponding getter function. Cyclically it is checked for timeout remote
 * devices.
 *
 * On timeout or shutdown of any remote device, a remote device callback with that
 * information is sent.
 * On LLDP frame receiption first a remote device callback is done, indicating if
 * it is a new or known device (or if the device changed). After all TLV callbacks
 * are called followed by another device callback indicating if any TLV data changed.
 *
 * @copyright
 * Copyright 2023 port GmbH
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_LLDP
#include <goal_includes.h>
#include <goal_lldp_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define GOAL_LLDP_RX_INFO_AGED_CYCLE GOAL_TIMER_SEC  /**< frequency where data are checked for data timeout */

#define GOAL_LLDP_RX_TLV_FLAG_ACTIVE       (1u << 0) /**< TLV is valid since last received LLDP frame */
#define GOAL_LLDP_RX_TLV_FLAG_RECEIVED     (1u << 1) /**< TLV is received in current LLDP frame */
#define GOAL_LLDP_RX_TLV_FLAG_CHANGED      (1u << 2) /**< TLV is changed by current LLDP frame */

#define GOAL_LLDP_RX_TLV_MANDETORY_NUMBER          3 /**< number of mandetory TLVs */

#define GOAL_LLDP_RX_TLV_MANDETORY_ARRAY        /**< Mandetory TLV information */                           \
/*   tlvId,                         tlvLenMin,                          tlvLenMax */                        \
    {GOAL_LLDP_TLV_TYPE_CHASSISID,  GOAL_LLDP_TLV_LEN_CHASSISID_MIN,    GOAL_LLDP_TLV_LEN_CHASSISID_MAX},   \
    {GOAL_LLDP_TLV_TYPE_PORTID,     GOAL_LLDP_TLV_LEN_PORTID_MIN,       GOAL_LLDP_TLV_LEN_PORTID_MAX},      \
    {GOAL_LLDP_TLV_TYPE_TTL,        GOAL_LLDP_TLV_LEN_TTL_MIN,          GOAL_LLDP_TLV_LEN_TTL_MAX},


/****************************************************************************/
/* Macros */
/****************************************************************************/
#define GOAL_LLDP_RX_FLAG_SET(field, flag) (field) |= (flag)
#define GOAL_LLDP_RX_FLAG_CLEAR(field, flag) (field) &= ~(flag)
#define GOAL_LLDP_RX_FLAG_CLEAR_ALL(field) (field) = 0
#define GOAL_LLDP_RX_FLAG_IS_SET(field, flag) (0 != ((field) & (flag)))
#define GOAL_LLDP_RX_FLAG_IS_CLEARED(field, flag) (0 == ((field) & (flag)))


/****************************************************************************/
/* Types */
/****************************************************************************/
typedef struct GOAL_LLDP_RX_TLV_MANDETORY_INFO_T {
    uint8_t tlvId;                              /**< TLV ID */
    uint16_t tlvLenMin;                         /**< Minimum TLV length */
    uint16_t tlvLenMax;                         /**< Maximum TLV length */
} GOAL_LLDP_RX_TLV_MANDETORY_INFO_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_lldpRxTlvMandetoryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
);

static GOAL_STATUS_T goal_lldpRxEntryGet(
    GOAL_LLDP_RX_INSTANCE_T *pRx,               /**< GOAL LLDP RX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_RX_TLV_LIST_T **ppEntry           /**< found receive TLV list entry */
);

static GOAL_STATUS_T goal_lldpRxEntryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    uint16_t tlvSizeMax,                        /**< maximum size of TLV */
    GOAL_LLDP_RX_TLV_LIST_T **ppEntry           /**< created receive TLV list entry */
);

static GOAL_STATUS_T goal_lldpRxTlvSizeCorrect(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint16_t *pTlvSizeMax                       /**< [in, out] maximum requested size of TLV */
);

static GOAL_STATUS_T goal_lldpRxValid(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen,                           /**< length of data on bytes */
    uint16_t *pTtl                              /**< [out] time to live value in frame */
);

static GOAL_STATUS_T goal_lldpRxTlvClear(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx                     /**< Ethernet port index */
);

static GOAL_STATUS_T goal_lldpRxProcess(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen,                           /**< length of data on bytes */
    uint8_t *pMacSrc                            /**< source MAC address in LLDP frame (MAC address of remote device) */
);

static GOAL_STATUS_T goal_lldpRxRemoteDevChangeCheck(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pMacSrc                            /**< source MAC address in LLDP frame (MAC address of remote device) */
);

static GOAL_STATUS_T goal_lldpRxDataStore(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen                            /**< length of data on bytes */
);

static GOAL_STATUS_T goal_lldpRxDataChangeCheck(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx                     /**< Ethernet port index */
);

static void goal_lldpRxTimerCb(
    void *pArg                                  /**< timer argument */
);


/****************************************************************************/
/* Variables */
/****************************************************************************/
static GOAL_LLDP_RX_TLV_MANDETORY_INFO_T mTlvIdsMandetory[GOAL_LLDP_RX_TLV_MANDETORY_NUMBER] = {GOAL_LLDP_RX_TLV_MANDETORY_ARRAY}; /**< Ids of mandetory TLVs in LLDP frame (ordered by mandetory occurrence in LLDP frame) */


/****************************************************************************/
/** Create a new GOAL LLDP Rx instance
 *
 * This function creates all required resources and stores the created
 * Rx instance in the GOAL LLDP instance.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxNew(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint32_t numPorts                           /**< umber of ports */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t cnt;                               /* counter */

    /* allocate instance data */
    res = goal_memCalloc(&pLldp->pRx, sizeof(GOAL_LLDP_RX_INSTANCE_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP RX instance");
        return res;
    }

    /* allocate remote data */
    res = goal_memCalloc(&pLldp->pRx->pRemDevList, sizeof(GOAL_LLDP_RX_REMOTE_INFO_T) * numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP remote device list");
        return res;
    }

    /* setup unchangable remote data */
    for (cnt = 0; cnt < numPorts; cnt++) {
        pLldp->pRx->pRemDevList[cnt].remDev.portIdx = (GOAL_ETH_PORT_T) cnt;
    }

    /* clear receive TLV list */
    pLldp->pRx->pTlvList = NULL;

    /* create and start rxInfoAge timer */
    res = goal_timerCreate(&pLldp->pRx->pTmrRxInfoAge, GOAL_TIMER_LOW);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to create rxInfoAge timer");
        return res;
    }
    res = goal_timerSetup(pLldp->pRx->pTmrRxInfoAge,
                          GOAL_TIMER_PERIODIC,
                          GOAL_LLDP_RX_INFO_AGED_CYCLE,
                          goal_lldpRxTimerCb,
                          pLldp,
                          GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to setup and start rxInfoAge timer");
        return res;
    }

    /* create mandetory TLVs */
    res = goal_lldpRxTlvMandetoryCreate(pLldp);
    if GOAL_RES_ERR(res) {
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Shut down the LLDP Rx instance
 *
 * This function frees all allocated resources of the LLDP Rx instance. Also
 * the Rx instance itself is freed.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxShutdown(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_INSTANCE_T *pRx;               /* GOAL LLDP RX instance */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry;            /* receive TLV list entry to delete */
    GOAL_LLDP_RX_TLV_LIST_T *pNext;             /* next receive TLV list entry */

    /* store Tx instance pointer for faster access */
    pRx = pLldp->pRx;

    if (NULL == pRx) {
        /* nothing to shutdown */
        return GOAL_OK;
    }

    /* delete timer */
    goal_timerDelete(&pLldp->pRx->pTmrRxInfoAge);

    /* free receive list entries */
    pEntry = pRx->pTlvList;
    while (NULL != pEntry) {
        pNext = pEntry->pNext;

        if (NULL != pEntry->pLen) {
            res = goal_memFree(&pEntry->pLen);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("Failed to free TLV length array.");
            }
        }

        if (NULL != pEntry->pData) {
            res = goal_memFree(&pEntry->pData);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("Failed to free TLV data array.");
            }
        }

        res = goal_memFree(&pEntry);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to free LLDP Receive TLV list entry.");
        }
        pEntry = pNext;
    }
    pRx->pTlvList = NULL;

    if (NULL != pRx->pRemDevList) {
        res = goal_memFree(&pRx->pRemDevList);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to free LLDP Remote device list.");
        }
    }

    /* free instance itself */
    res = goal_memFree(&pLldp->pRx);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to free LLDP Rx instance.");
    }

    return res;
}


/****************************************************************************/
/** Start operation of GOAL LLDP Rx
 *
 * This function activate receiving of LLDP frames.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxStart(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    /* start LLDP receiving */
    pLldp->pRx->flgRun = GOAL_TRUE;

    return GOAL_OK;
}


/****************************************************************************/
/** Stop operation of GOAL LLDP Rx
 *
 * This function deactivate receiving of LLDP frames. LLDP frames are not
 * processed and dropped directly.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxStop(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t cnt;                               /* counter */
    uint32_t numPorts = 0;                      /* number of ports */
    GOAL_LLDP_RX_REMOTE_INFO_T *pRemoteDev;     /* remote device information */

    /* stop LLDP receiving */
    pLldp->pRx->flgRun = GOAL_FALSE;

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return res;
    }

    /* remove every remote device */
    for (cnt = 0; cnt < numPorts; cnt++) {
        pRemoteDev = &pLldp->pRx->pRemDevList[cnt];

        pRemoteDev->remDev.active = GOAL_FALSE;
        pRemoteDev->remDev.lastChange = 0;
        GOAL_MEMSET(&pRemoteDev->remDev.macAddr, 0, sizeof(GOAL_ETH_MAC_ADDR_T));

        res = goal_lldpRxTlvClear(pLldp, (GOAL_ETH_PORT_T) cnt);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to clear remote device flags");
        }
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Add receive TLV handling
 *
 * Add a TLV which is listened on LLDP frame receiption. Up the the given
 * ammount of bytes of the received data are stored per port.
 * Also a receive callback can be registered, which is called after receiving
 * and a LLDP frame.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxTlvAdd(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127 */
    uint16_t tlvSizeMax,                        /**< maximum size of TLV */
    GOAL_LLDP_TLV_RECEIVE_CB_T rxCb             /**< receive callback */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_INSTANCE_T *pRx;               /* GOAL LLDP Tx instance */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry = NULL;     /* new receive TLV list entry */

    /* prevent registering of End Of LLDPDU TLV */
    if (GOAL_LLDP_TLV_TYPE_EOF == tlvId) {
        goal_logErr("End Of LLDPDU TLV is directly handled by GOAL LLDP and is not allowed to be registered");
        return GOAL_ERROR;
    }

    /* check if a TLV should releay be listened */
    if (GOAL_LLDP_TLV_LEN_IGNORE == tlvSizeMax) {
        if (NULL == rxCb) {
            /* no need to really register Rx TLV */
            return GOAL_OK;
        }
        else {
            goal_logErr("Tried to register Rx callback, but specified to store no received data. This is not allowed.");
            return GOAL_ERR_PARAM;
        }
    }

    /* get GOAL LLDP Rx instance for faster access */
    pRx = pLldp->pRx;

    /* get list entry, or create new one, if non-existent */
    res = goal_lldpRxEntryGet(pRx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
    if (GOAL_RES_ERR(res)) {
        res = goal_lldpRxEntryCreate(pLldp, tlvId, tlvOuid, tlvSubtypeId, tlvSizeMax, &pEntry);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to create new Tx element");
            return res;
        }
    }
    else {
        /* there is an element already, check for enough allocated memory */
        if (tlvSizeMax > pEntry->dataLenMax) {
            goal_logErr("Rx TLV list element already registered with %u bytes, new size %u cannot be allocated", pEntry->dataLenMax, tlvSizeMax);
        }
        else {
            pEntry->dataLenListen = tlvSizeMax;
            goal_logInfo("Rx TLV list element already registered with %u bytes, this is enough to hold new size of %u bytes", pEntry->dataLenMax, tlvSizeMax);
        }
    }

    /* store callback */
    if (NULL != pEntry->rxCb) {
        goal_logWarn("The Rx TLV callback of TLV with ID %u will be overwritten.", tlvId);
    }
    pEntry->rxCb = rxCb;

    return GOAL_OK;
}


/****************************************************************************/
/** Get information of connected peer
 *
 * If no peer is connected, a corresponding error code is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxPeerInfoGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    GOAL_LLDP_REMOTE_T **ppRemote               /**< [out] remote device information */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_INSTANCE_T *pRx;               /* GOAL LLDP Rx instance */
    uint32_t numPorts = 0;                      /* number of ports */

    /* get GOAL LLDP Rx instance for faster access */
    pRx = pLldp->pRx;

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return res;
    }

    /* check for valid port index */
    if (portIdx >= numPorts) {
        goal_logErr("Invalid port index %"FMT_u32, portIdx);
        return GOAL_ERR_OUT_OF_RANGE;
    }

    /* get remote device information */
    if (GOAL_TRUE == pRx->pRemDevList[portIdx].remDev.active) {
        *ppRemote = &pRx->pRemDevList[portIdx].remDev;
        res = GOAL_OK;
    }
    else {
        res = GOAL_ERR_NOT_FOUND;
    }

    return res;
}


/****************************************************************************/
/** Get received TLV value
 *
 * Get the value of an received TLV with the given TLV ID on the given port.
 * If the data are invalid, e.g. if a remite device timed out, GOAL_ERR_NOT_FOUND
 * is returned.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxTlvValueGet(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127 */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t **ppData,                           /**< [out] data of TLV (without OUI and subtype) */
    uint16_t *pDataLen                          /**< [out] length of data of TLV (without OUI and subtype) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_INSTANCE_T *pRx;               /* GOAL LLDP Rx instance */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry = NULL;     /* receive TLV list entry */
    uint32_t numPorts = 0;                      /* number of ports */

    /* get GOAL LLDP Rx instance for faster access */
    pRx = pLldp->pRx;

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return res;
    }

    /* check for valid port index */
    if (portIdx >= numPorts) {
        goal_logErr("Invalid port index %"FMT_u32, portIdx);
        return GOAL_ERR_OUT_OF_RANGE;
    }

    /* get receive TLV list entry */
    res = goal_lldpRxEntryGet(pRx,
                              tlvId,
                              tlvOuid,
                              tlvSubtypeId,
                              &pEntry);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Did not found receive TLV list entry");
        return res;
    }

    /* check if data are still valid */
    if (GOAL_FALSE == pLldp->pRx->pRemDevList[portIdx].remDev.active) {
        /* no acive remote device */
        return GOAL_ERR_NOT_FOUND;
    }

    /* return out variables */
    *ppData = &pEntry->pData[pEntry->dataLenMax * portIdx];
    *pDataLen = pEntry->pLen[portIdx];

    return GOAL_OK;
}


/****************************************************************************/
/** Register a Frame reception callback
 *
 * This callback is called on frame reception. If the TLVs are valid, it is
 * called diectly before and directly after all registered RX TLV callbacks.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxRemoteUpdateHandlerRegister(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_LLDP_REMOTE_UPDATE_CB_T remoteUpdateCb /**< Remote Update Callback handler */
)
{
    if (NULL != pLldp->pRx->remoteUpdateCb) {
        goal_logWarn("GOAL LLDP remote data receive callback will be overwritten.");
    }
    pLldp->pRx->remoteUpdateCb = remoteUpdateCb;

    return GOAL_OK;
}


/****************************************************************************/
/** Handle received LLDP frame
 *
 * Retrieves the LLDP header and checks for valid header and TLV data
 * in the received LLDP frame. Based on the data the frame TLVs are further processed.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRx(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_BUFFER_T *pBuf                         /**< data received */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t *pMacSrc;                           /* source MAC address in LLDP frame (MAC address of remote device) */
    uint8_t *pMacDst;                           /* destination MAC address in LLDP frame */
    uint32_t numPorts = 0;                      /* number of ports */
    uint8_t macLldp[] = GOAL_LLDP_MAC_ADDR;     /* LLDP multicast address */
    uint8_t *pData;                             /* data pointer to start of first TLV */
    uint16_t dataLen;                           /* length of data from start of first LV to frame end */
    GOAL_ETH_PORT_T portIdx;                    /* Ethernet port index */
    GOAL_TIMESTAMP_T ts;                        /* current timestamp */
    uint16_t ttl = 0;                           /* time to live value */

    /* only process if Rx is enabled */
    if (GOAL_FALSE == pLldp->pRx->flgRun) {
        /* inform caller, that frame was processed */
        return GOAL_OK;
    }

    /* get data for faster access */
    portIdx = pBuf->netPort;

    /* get receive timestamp */
    ts = goal_timerTsGet();

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return res;
    }

    /* check for valid port index */
    if (portIdx >= numPorts) {
        goal_logErr("Invalid port index %"FMT_u32, portIdx);
        return GOAL_ERR_OUT_OF_RANGE;
    }

    /* get frame header data */
    if (GOAL_TRUE == (goal_queueFlagsGet(pBuf, GOAL_QUEUE_FLG_VLAN))) {
        if (sizeof(GOAL_LLDP_ETH_HEADER_WITH_VLAN_T) > pBuf->dataLen) {
            goal_logDbg("Received frame with invalid length");
            return GOAL_ERR_INVALID_FRAME;
        }

        pMacSrc = ((GOAL_LLDP_ETH_HEADER_WITH_VLAN_T *) pBuf->ptrData)->macSrc;
        pMacDst = ((GOAL_LLDP_ETH_HEADER_WITH_VLAN_T *) pBuf->ptrData)->macDst;
        pData = pBuf->ptrData + sizeof(GOAL_LLDP_ETH_HEADER_WITH_VLAN_T);
        dataLen = pBuf->dataLen - sizeof(GOAL_LLDP_ETH_HEADER_WITH_VLAN_T);
    }
    else {
        if (sizeof(GOAL_LLDP_ETH_HEADER_T) > pBuf->dataLen) {
            goal_logDbg("Received frame with invalid length");
            return GOAL_ERR_INVALID_FRAME;
        }
        pMacSrc = ((GOAL_LLDP_ETH_HEADER_T *) pBuf->ptrData)->macSrc;
        pMacDst = ((GOAL_LLDP_ETH_HEADER_T *) pBuf->ptrData)->macDst;
        pData = pBuf->ptrData + sizeof(GOAL_LLDP_ETH_HEADER_T);
        dataLen = pBuf->dataLen - sizeof(GOAL_LLDP_ETH_HEADER_T);
    }

    /* check if LLDP multicast address matches */
    if (0 != GOAL_MEMCMP(pMacDst, macLldp, MAC_ADDR_LEN)) {
        goal_logDbg("MAC address doesn't match ours");
        return GOAL_ERROR;
    }

    /* check for valid frame structure */
    res = goal_lldpRxValid(pLldp, pData, dataLen, &ttl);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("TLVs in received frame on port %"FMT_u32 " are not valid, frame is dropped", portIdx);
        return res;
    }

    /* store ttl und receive timestamp */
    pLldp->pRx->pRemDevList[portIdx].ttl = ttl;
    pLldp->pRx->pRemDevList[portIdx].tsRxLast = ts;

    /* process valid frame */
    if (GOAL_LLDP_TTL_SHUTDOWN == ttl) {
        res = goal_lldpRxRemoteDeviceRemove(pLldp, portIdx, GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_SHUTDOWN);
    }
    else {
        res = goal_lldpRxProcess(pLldp, portIdx, pData, dataLen, pMacSrc);
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Remove remote device data
 *
 * Remove all stored data of a remote device on the given port.
 * Directly for deletion call Remote callback.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_lldpRxRemoteDeviceRemove(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    GOAL_LLDP_REMOTE_CB_TYPE_T type             /**< callback type */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_REMOTE_INFO_T *pRemoteDev;     /* remote device information */

    /* get pointer for faster access */
    pRemoteDev = &pLldp->pRx->pRemDevList[portIdx];

    if (GOAL_FALSE == pRemoteDev->remDev.active) {
        /* no device was active before */
        return GOAL_OK;
    }

    /* inform that remote device will be delete */
    if (NULL != pLldp->pRx->remoteUpdateCb) {
        pLldp->pRx->remoteUpdateCb((GOAL_LLDP_HANDLE_T *) pLldp,
                                   &pRemoteDev->remDev,
                                   type);
    }

    /* set remote device information to sutdown */
    pRemoteDev->remDev.active = GOAL_FALSE;
    pRemoteDev->remDev.lastChange = 0;
    GOAL_MEMSET(&pRemoteDev->remDev.macAddr, 0, sizeof(GOAL_ETH_MAC_ADDR_T));
    res = goal_lldpRxTlvClear(pLldp, portIdx);
    if (GOAL_RES_ERR(res)) {
        goal_logDbg("Failed to clear remote data for port index %"FMT_u32, portIdx);
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Create Rx handling of mandetory TLV
 *
 * Create handling of the mandetory TLVs Chassis ID, Port ID and TTL, listening
 * to the maximum size possible. TLV Rx Callbacks can be registered separately
 * using goal_lldpRxTlvAdd() again.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxTlvMandetoryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp                 /**< GOAL LLDP instance */
)
{
    GOAL_STATUS_T res;                          /* result */

    /* Chassis ID */
    res = goal_lldpRxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_CHASSISID,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            GOAL_LLDP_TLV_LEN_CHASSISID_MAX,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to start listening on Chassis ID TLV");
    }

    /* Port ID */
    res = goal_lldpRxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_PORTID,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            GOAL_LLDP_TLV_LEN_PORTID_MAX,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to start listening on Port ID TLV");
    }

    /* Port ID */
    res = goal_lldpRxTlvAdd(pLldp,
                            GOAL_LLDP_TLV_TYPE_TTL,
                            GOAL_LLDP_OUID_NONE,
                            GOAL_LLDP_SUBTYPE_NONE,
                            GOAL_LLDP_TLV_LEN_TTL,
                            NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to start listening on TTL TLV");
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Get the registered Rx TLV handling entry
 *
 * Returns the added Rx TLV handling entry. If no entry is found,
 * GOAL_ERR_NOT_FOUND is returned.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxEntryGet(
    GOAL_LLDP_RX_INSTANCE_T *pRx,               /**< GOAL LLDP RX instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    GOAL_LLDP_RX_TLV_LIST_T **ppEntry           /**< found receive TLV list entry */
)
{
    GOAL_LLDP_RX_TLV_LIST_T *pEntry;            /* receive TLV list entry */

    GOAL_LL_FOREACH(pRx->pTlvList, pEntry) {
        if ((pEntry->tlvId == tlvId) && (pEntry->tlvOuid == tlvOuid) && (pEntry->tlvSubtypeId == tlvSubtypeId)) {
            /* found element in list */
            break;
        }
    }

    if (NULL == pEntry) {
        return GOAL_ERR_NOT_FOUND;
    }

    *ppEntry = pEntry;
    return GOAL_OK;

}


/****************************************************************************/
/** Creating new Rx TLV handling entry
 *
 * Store given identifiers for TLV (ID, UOID and subtype). Create receiving
 * buffers for each port with the given maximum size of data.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxEntryCreate(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint32_t tlvOuid,                           /**< TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId,                       /**< subtype id if type id is 127  */
    uint16_t tlvSizeMax,                        /**< maximum size of TLV */
    GOAL_LLDP_RX_TLV_LIST_T **ppEntry           /**< created receive TLV list entry */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_INSTANCE_T *pRx;               /* GOAL LLDP Rx instance */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry = NULL;     /* new receive TLV list entry */
    uint32_t numPorts = 0;                      /* number of ports */
    uint16_t tlvSizeMaxCorrected;               /* corrected value of TLV maximum size */

    /* get GOAL LLDP Rx instance for faster access */
    pRx = pLldp->pRx;

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return res;
    }

    /* use minimum possible maximum size */
    tlvSizeMaxCorrected = tlvSizeMax;
    res = goal_lldpRxTlvSizeCorrect(pLldp, tlvId, &tlvSizeMaxCorrected);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get/update maximum TLV size");
        return res;
    }

    /* create new element */
    res = goal_memCalloc(&pEntry, sizeof(GOAL_LLDP_RX_TLV_LIST_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to allocate Rx TLV list entry");
        return res;
    }

    /* add element to end of list */
    GOAL_LL_APPEND(pRx->pTlvList, pEntry);

    /* set ID */
    pEntry->tlvId = tlvId;
    pEntry->tlvOuid = tlvOuid;
    pEntry->tlvSubtypeId = tlvSubtypeId;

    /* set TLV meta data */
    if (GOAL_LLDP_TLV_TYPE_OS_EXT == tlvId) {
        pEntry->subHeaderLen = GOAL_LLDP_TLV_LEN_OUI + GOAL_LLDP_TLV_LEN_SUBTYPE;
    }
    else {
        pEntry->subHeaderLen = 0;
    }
    pEntry->dataLenMax = tlvSizeMaxCorrected;
    pEntry->dataLenListen = tlvSizeMaxCorrected;

    /* allocate buffers */
    res = goal_memCalloc(&pEntry->pData, tlvSizeMaxCorrected * numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP RX TLV data buffer");
        return res;
    }
    res = goal_memCalloc(&pEntry->pLen, sizeof(uint16_t) * numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP RX TLV length buffer");
        return res;
    }
    res = goal_memCalloc(&pEntry->pFlags, sizeof(uint8_t) * numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to allocate LLDP RX TLV flags buffer");
        return res;
    }

    /* store result */
    *ppEntry = pEntry;

    return GOAL_OK;
}


/****************************************************************************/
/** Correct requested TLV size
 *
 * Check requested TLV sizes to be allocated against maximum and minimum values
 * of given TLV IDs. If the value is outside this boardes, it is set to the
 * corresponding boarder value. For some IDs 0 bytes are possible.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxTlvSizeCorrect(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t tlvId,                              /**< TLV type id */
    uint16_t *pTlvSizeToAlloc                   /**< [in, out] size of TLV to allocate */
)
{
    uint16_t tlvSizeMax;                        /* maximum allowed TLV size */
    uint16_t tlvSizeMin = 0;                    /* minimum allowed TLV size */

    /* unused arguments */
    UNUSEDARG(pLldp);

    /* get maximum size of TLV defined by specification */
    switch (tlvId) {
        case GOAL_LLDP_TLV_TYPE_CHASSISID:
            tlvSizeMin = GOAL_LLDP_TLV_LEN_CHASSISID_MIN;
            tlvSizeMax = GOAL_LLDP_TLV_LEN_CHASSISID_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_PORTID:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_PORTID_MIN;
            tlvSizeMax = GOAL_LLDP_TLV_LEN_PORTID_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_TTL:
            tlvSizeMin = GOAL_LLDP_TLV_LEN_TTL_MIN;
            tlvSizeMax = GOAL_LLDP_TLV_LEN_TTL_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_PORTDESC:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_PORTDESC_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_SYSNAME:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_SYSNAME_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_SYSDESC:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_SYSDESC_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_SYSCAP:
            tlvSizeMin = GOAL_LLDP_TLV_LEN_SYSCAP;
            tlvSizeMax = GOAL_LLDP_TLV_LEN_SYSCAP;
            break;
        case GOAL_LLDP_TLV_TYPE_MANADDR:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_MANADDR_MIN;
            tlvSizeMax = GOAL_LLDP_TLV_LEN_MANADDR_MAX;
            break;
        case GOAL_LLDP_TLV_TYPE_OS_EXT:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_OS_DATA_STRING_MAX;
            break;
        default:
            tlvSizeMax = GOAL_LLDP_TLV_LEN_MAX;
            break;
    }

    /* check against minimum */
    if (*pTlvSizeToAlloc < tlvSizeMin) {
        goal_logWarn("TLV ID %u needs at least %u bytes, requested size is increased to this value.", tlvId, tlvSizeMin);
        *pTlvSizeToAlloc = tlvSizeMin;
    }

    /* check against maximum */
    if (*pTlvSizeToAlloc > tlvSizeMax) {
        if (GOAL_LLDP_TLV_LEN_UNLIMITED != *pTlvSizeToAlloc) {
            goal_logWarn("TLV ID %u only support at most %u bytes, requested size is decreased to this value.", tlvId, tlvSizeMax);
        }
        *pTlvSizeToAlloc = tlvSizeMax;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Check for valid TLVs in LLDP frame
 *
 * This function checks the following aspects:
 * - The mandetory TLVs are contained and have valid order and sizes (Port ID, Chassis ID, TTL)
 * - On TTL == 0 the parsing is stopped immediately
 * - There is no partial TLV
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxValid(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen,                           /**< length of data on bytes */
    uint16_t *pTtl                              /**< [out] time to live value in frame */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    uint8_t *pDataCur;                          /* current data pointer */
    uint16_t dataLenRem;                        /* remaining data length */
    uint16_t cnt;                               /* TLV counter */
    uint8_t tlvId;                              /* TLV ID */
    uint16_t tlvLen;                            /* TLV length */

    /* unused arguments */
    UNUSEDARG(pLldp);

    /* initialize local variables */
    pDataCur = pData;
    dataLenRem = dataLen;
    cnt = 0;

    /* check all TLVs */
    while (0 < dataLenRem) {
        /* check for valid header */
        if (GOAL_LLDP_TLV_HEADER_SIZE > dataLenRem) {
            goal_logDbg("TLV has no correc header");
            res = GOAL_ERR_INVALID_FRAME;
            break;
        }

        /* get information from TLV header */
        tlvId = GOAL_LLDP_TLV_ID_GET(pDataCur);
        tlvLen = GOAL_LLDP_TLV_LEN_GET(pDataCur);
        pDataCur += GOAL_LLDP_TLV_HEADER_SIZE;
        dataLenRem -= GOAL_LLDP_TLV_HEADER_SIZE;

        /* check for mandetory TLV */
        if (GOAL_LLDP_RX_TLV_MANDETORY_NUMBER > cnt) {
            if ((tlvId != mTlvIdsMandetory[cnt].tlvId) ||
                (tlvLen < mTlvIdsMandetory[cnt].tlvLenMin) ||
                (tlvLen > mTlvIdsMandetory[cnt].tlvLenMax)) {
                goal_logDbg("Mandetory TLV is invalid");
                res = GOAL_ERR_INVALID_FRAME;
                break;
            }
        }
        else {
            /* no mandetory TLV is allowed to show up twice */
            if ((GOAL_LLDP_TLV_TYPE_CHASSISID == tlvId) ||
                (GOAL_LLDP_TLV_TYPE_PORTID == tlvId) ||
                (GOAL_LLDP_TLV_TYPE_TTL == tlvId)) {
                goal_logDbg("Mandeotry TLV with ID %u apperaed twice", tlvId);
                res = GOAL_ERR_INVALID_FRAME;
                break;
            }
        }

        /* check for shutfownframe */
        if ((GOAL_LLDP_TLV_TYPE_TTL == tlvId)) {
            /* store ttl for timeout checks */
            *pTtl = GOAL_be16toh(((GOAL_LLDP_TLV_TTL_T *) pDataCur)->ttl_be16);
            if (GOAL_LLDP_TTL_SHUTDOWN == *pTtl) {
                /* received shutdown frame - stop processing further data */
                break;
            }
        }

        /* check for end of LLDP PDU */
        if (GOAL_LLDP_TLV_TYPE_EOF == tlvId) {
            /* received end of LLDP PDU - stop processing further data */
            break;
        }

        /* Organizationally Specific TLVs */
        if ((GOAL_LLDP_TLV_TYPE_OS_EXT == tlvId) && (GOAL_LLDP_TLV_LEN_OUI + GOAL_LLDP_TLV_LEN_SUBTYPE > tlvLen)) {
            goal_logDbg("Organizationally Specific TLV is not valid");
            res = GOAL_ERR_INVALID_FRAME;
            break;
        }

        /* check TLV information string length */
        if (tlvLen > dataLenRem) {
            goal_logDbg("TLV information string is incomplete");
            res = GOAL_ERR_INVALID_FRAME;
            break;
        }
        pDataCur += tlvLen;
        dataLenRem -= tlvLen;

        /* TLV was complete - check next one */
        cnt++;
    }

    /* check that mandetory TLVs are contaned */
    if ((GOAL_RES_OK(res)) && (GOAL_LLDP_RX_TLV_MANDETORY_NUMBER > cnt)) {
        goal_logDbg("Some mandetory TLVs are missing");
        res = GOAL_ERR_INVALID_FRAME;
    }

    return res;
}


/****************************************************************************/
/** Clear all flags in internal TLV handling structure.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxTlvClear(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx                     /**< Ethernet port index */
)
{
    GOAL_LLDP_RX_TLV_LIST_T *pEntry;            /* receive TLV list entry */

    GOAL_LL_FOREACH(pLldp->pRx->pTlvList, pEntry) {
        GOAL_LLDP_RX_FLAG_CLEAR_ALL(pEntry->pFlags[portIdx]);
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Further processing of received LLDP frame
 *
 * Process data from LLDP frame header and process each received TLV.
 * Call Remote Callback before and after TLV callabcks are called.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxProcess(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen,                           /**< length of data on bytes */
    uint8_t *pMacSrc                            /**< source MAC address in LLDP frame (MAC address of remote device) */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_lldpRxRemoteDevChangeCheck(pLldp, portIdx, pMacSrc);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to check remote device on port %"FMT_u32, portIdx);
        return res;
    }

    res = goal_lldpRxDataStore(pLldp, portIdx, pData, dataLen);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to store received LLDP data on port %"FMT_u32, portIdx);
        return res;
    }

    res = goal_lldpRxDataChangeCheck(pLldp, portIdx);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to check received LLDP data for changes on port %"FMT_u32, portIdx);
        return res;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Check for device change
 *
 * Check if the current LLDP frame is sent from the same remote device than the last one.
 * Either it is:
 * - a new device (no LLDP frame received before)
 * - the same device (same MAC address as in last frame)
 * - a new devie (other MAC address as in last frame)
 *
 * The remote callback is called with the corresponding event.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxRemoteDevChangeCheck(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pMacSrc                            /**< source MAC address in LLDP frame (MAC address of remote device) */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_REMOTE_CB_TYPE_T type;            /* callback type */
    GOAL_LLDP_RX_REMOTE_INFO_T *pRemoteDev;     /* remote device information */

    /* get pointer for faster access */
    pRemoteDev = &pLldp->pRx->pRemDevList[portIdx];

    /* update remote device information */
    if (GOAL_FALSE == pRemoteDev->remDev.active) {
        pRemoteDev->remDev.active = GOAL_TRUE;
        GOAL_MEMCPY(&pRemoteDev->remDev.macAddr, pMacSrc, sizeof(GOAL_ETH_MAC_ADDR_T));
        pLldp->pRx->pRemDevList[portIdx].flgInitial = GOAL_TRUE;
        type = GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_NEW;
    }
    else if (0 != GOAL_MEMCMP(&pRemoteDev->remDev.macAddr, pMacSrc, sizeof(GOAL_ETH_MAC_ADDR_T))) {
        /* inform, that peer device is replaced */
        if (NULL != pLldp->pRx->remoteUpdateCb) {
            pLldp->pRx->remoteUpdateCb((GOAL_LLDP_HANDLE_T *) pLldp,
                                       &pRemoteDev->remDev,
                                       GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_CHANGED);
        }

        /* setup data for new peer */
        GOAL_MEMCPY(&pRemoteDev->remDev.macAddr, pMacSrc, sizeof(GOAL_ETH_MAC_ADDR_T));
        pLldp->pRx->pRemDevList[portIdx].flgInitial = GOAL_TRUE;
        type = GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_NEW;

        /* clear TLV flags, handle as complete new data */
        res = goal_lldpRxTlvClear(pLldp, portIdx);
        if (GOAL_RES_ERR(res)) {
            goal_logDbg("Failed to clear remote data for port index %"FMT_u32, portIdx);
            return res;
        }
    }
    else {
        type = GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_UNCHANGED;
    }

    /* callback directly before TLV data change */
    if (NULL != pLldp->pRx->remoteUpdateCb) {
        pLldp->pRx->remoteUpdateCb((GOAL_LLDP_HANDLE_T *) pLldp,
                                   &pRemoteDev->remDev,
                                   type);
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Store TLV data
 *
 * Store the TLV data which are listened. Unregistered Rx TLVs are ignored.
 * Set information flags allowing to check for data changes.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxDataStore(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx,                    /**< Ethernet port index */
    uint8_t *pData,                             /**< received data starting with first TLV */
    uint16_t dataLen                            /**< length of data on bytes */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t tlvId;                              /* TLV ID */
    uint32_t tlvOuid;                           /* TLV ouid if type id is 127 */
    uint8_t tlvSubtypeId;                       /* subtype id if type id is 127  */
    uint16_t tlvLen;                            /* TLV length */
    uint16_t tlvLenToCopy;                      /* length of data stored in LLDP module */
    uint8_t *pDataCur;                          /* current data pointer */
    uint16_t dataLenRem;                        /* remaining data length */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry = NULL;     /* new receive TLV list entry */

    /* initialize local variables */
    pDataCur = pData;
    dataLenRem = dataLen;

    /* check all TLVs */
    while (0 < dataLenRem) {
        /* get information from TLV header */
        tlvId = GOAL_LLDP_TLV_ID_GET(pDataCur);
        tlvLen = GOAL_LLDP_TLV_LEN_GET(pDataCur);
        pDataCur += GOAL_LLDP_TLV_HEADER_SIZE;
        dataLenRem -= GOAL_LLDP_TLV_HEADER_SIZE;

        /* check for end of LLDP PDU */
        if (GOAL_LLDP_TLV_TYPE_EOF == tlvId) {
            break;
        }

        /* get OUI and subtpe */
        if (GOAL_LLDP_TLV_TYPE_OS_EXT == tlvId) {
            if (GOAL_LLDP_TLV_LEN_OUI + GOAL_LLDP_TLV_LEN_SUBTYPE > tlvLen) {
                /* minimum length of OS TLV not reached - skip malformed TLV */
                pDataCur += tlvLen;
                dataLenRem -= tlvLen;
                continue;
            }
            else if (GOAL_LLDP_TLV_LEN_OUI + GOAL_LLDP_TLV_LEN_SUBTYPE > dataLenRem) {
                /* LLDP frame to short, stop parsing */
                break;
            }

            tlvOuid = GOAL_be24toh_p(pDataCur);
            tlvSubtypeId = pDataCur[GOAL_LLDP_TLV_LEN_OUI];
        }
        else {
            tlvOuid = GOAL_LLDP_OUID_NONE;
            tlvSubtypeId = GOAL_LLDP_SUBTYPE_NONE;
        }

        /* get entry */
        res = goal_lldpRxEntryGet(pLldp->pRx, tlvId, tlvOuid, tlvSubtypeId, &pEntry);
        if (GOAL_RES_ERR(res)) {
            /* skip, if no one listens this TLV */
            pDataCur += tlvLen;
            dataLenRem -= tlvLen;
            continue;
        }

        /* check subeader */
        if ((pEntry->subHeaderLen > dataLenRem) || (pEntry->subHeaderLen > tlvLen)) {
            /* skip TLV with invalid subheader */
            pDataCur += tlvLen;
            dataLenRem -= tlvLen;
            continue;
        }

        /* remove subheader */
        pDataCur += pEntry->subHeaderLen;
        dataLenRem -= pEntry->subHeaderLen;
        tlvLen -= pEntry->subHeaderLen;

        /* check for how many bytes listeners are waiting */
        if (tlvLen > pEntry->dataLenListen) {
            goal_logInfo("Received %u more bytes than memory is reserved for TLV with ID %u, drop to many bytes", tlvLen - pEntry->dataLenListen, tlvId);
            tlvLenToCopy = pEntry->dataLenListen;
        }
        else {
            tlvLenToCopy = tlvLen;
        }

        /* indicate received data */
        GOAL_LLDP_RX_FLAG_SET(pEntry->pFlags[portIdx], GOAL_LLDP_RX_TLV_FLAG_RECEIVED);

        if ((GOAL_LLDP_RX_FLAG_IS_CLEARED(pEntry->pFlags[portIdx], GOAL_LLDP_RX_TLV_FLAG_ACTIVE)) ||
            (pEntry->pLen[portIdx] != tlvLenToCopy) ||
            (0 != GOAL_MEMCMP(&pEntry->pData[pEntry->dataLenMax * portIdx], pDataCur, tlvLenToCopy))) {

            /* store/update data */
            GOAL_MEMCPY(&pEntry->pData[pEntry->dataLenMax * portIdx], pDataCur, tlvLenToCopy);
            pEntry->pLen[portIdx] = tlvLenToCopy;

            /* indicate changed data */
            GOAL_LLDP_RX_FLAG_SET(pEntry->pFlags[portIdx], GOAL_LLDP_RX_TLV_FLAG_CHANGED);
        }

        /* go to next entry */
        pDataCur += tlvLen;
        dataLenRem -= tlvLen;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Check for data change
 *
 * Check if the current LLDP frame contains new/other data than before
 * Based on a real data change (new data, data change, no change, data missing)
 * the Rx TLV callback is called with the corresponding event for each TLV.
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_lldpRxDataChangeCheck(
    GOAL_LLDP_INSTANCE_T *pLldp,                /**< GOAL LLDP instance */
    GOAL_ETH_PORT_T portIdx                     /**< Ethernet port index */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_RX_TLV_LIST_T *pEntry;            /* receive TLV list entry */
    GOAL_LLDP_REMOTE_CB_TYPE_T type;            /* callback type */
    GOAL_LLDP_REMOTE_TLV_CB_TYPE_T typeTlv;     /* TLV callback type */
    uint8_t flags;                              /* LLDP TLV information flags */

    /* assume no change until any change occured */
    type = GOAL_LLDP_REMOTE_CB_TYPE_DATA_UNCHANGED;

    GOAL_LL_FOREACH(pLldp->pRx->pTlvList, pEntry) {
        flags = pEntry->pFlags[portIdx];

        if (GOAL_LLDP_RX_FLAG_IS_CLEARED(flags, GOAL_LLDP_RX_TLV_FLAG_ACTIVE)) {
            if (GOAL_LLDP_RX_FLAG_IS_CLEARED(flags, GOAL_LLDP_RX_TLV_FLAG_RECEIVED)) {
                /* no LLDP data received now and before */
                continue;
            }
            else {
                /* TLV is new and was not sent before */
                typeTlv = GOAL_LLDP_REMOTE_TLV_CB_NEW;
                type = GOAL_LLDP_REMOTE_CB_TYPE_DATA_UPDATE;
            }
        }
        else {
            if (GOAL_LLDP_RX_FLAG_IS_CLEARED(flags, GOAL_LLDP_RX_TLV_FLAG_RECEIVED)) {
                /* TLV data from last frame are missing in the current one */
                typeTlv = GOAL_LLDP_REMOTE_TLV_CB_REMOVED;
                type = GOAL_LLDP_REMOTE_CB_TYPE_DATA_UPDATE;
            }
            else if (GOAL_LLDP_RX_FLAG_IS_SET(flags, GOAL_LLDP_RX_TLV_FLAG_CHANGED)) {
                /* TLV data changed */
                typeTlv = GOAL_LLDP_REMOTE_TLV_CB_UPDATE;
                type = GOAL_LLDP_REMOTE_CB_TYPE_DATA_UPDATE;
            }
            else {
                /* no change in TLV since last LLDP frame */
                typeTlv = GOAL_LLDP_REMOTE_TLV_CB_UNCHANGED;
            }
        }

        /* TLV data change callback */
        if (NULL != pEntry->rxCb) {
            res = pEntry->rxCb((GOAL_LLDP_HANDLE_T *) pLldp,
                               portIdx,
                               pEntry->tlvId,
                               pEntry->tlvOuid,
                               pEntry->tlvSubtypeId,
                               &pEntry->pData[pEntry->dataLenMax * portIdx],
                               pEntry->pLen[portIdx],
                               typeTlv);
            if (GOAL_RES_ERR(res)) {
                goal_logDbg("Receive Callack returned error");
                continue;
            }
        }

        /* update flags for next frame */
        if (GOAL_LLDP_RX_FLAG_IS_SET(flags, GOAL_LLDP_RX_TLV_FLAG_RECEIVED)) {
            GOAL_LLDP_RX_FLAG_SET(flags, GOAL_LLDP_RX_TLV_FLAG_ACTIVE);
        }
        else {
            GOAL_LLDP_RX_FLAG_CLEAR(flags, GOAL_LLDP_RX_TLV_FLAG_ACTIVE);
        }
        GOAL_LLDP_RX_FLAG_CLEAR(flags, GOAL_LLDP_RX_TLV_FLAG_RECEIVED);
        GOAL_LLDP_RX_FLAG_CLEAR(flags, GOAL_LLDP_RX_TLV_FLAG_CHANGED);

        /* store flags */
        pEntry->pFlags[portIdx] = flags;
    }

    /* overwrite callback with initial, if these are the first data of this device */
    if (GOAL_TRUE == pLldp->pRx->pRemDevList[portIdx].flgInitial) {
        type = GOAL_LLDP_REMOTE_CB_TYPE_DATA_INITIAL;
        pLldp->pRx->pRemDevList[portIdx].flgInitial = GOAL_FALSE;
    }

    /* update last time of change */
    if ((GOAL_LLDP_REMOTE_CB_TYPE_DATA_UPDATE == type) ||
        (GOAL_LLDP_REMOTE_CB_TYPE_DATA_INITIAL == type)) {
        pLldp->pRx->pRemDevList[portIdx].remDev.lastChange = goal_lldpCoreSysUpTimeGet(pLldp);
    }

    if (NULL != pLldp->pRx->remoteUpdateCb) {
        pLldp->pRx->remoteUpdateCb((GOAL_LLDP_HANDLE_T *) pLldp,
                                   &pLldp->pRx->pRemDevList[portIdx].remDev,
                                   type);
    }

    return GOAL_OK;
}


/****************************************************************************/
/** rxInfoAge Timer Callback
 *
 * This function is called cyclically. It checks for timeouts remote devices,
 * i.e. if rxInfoAge is TRUE. In that case the device is removed and the
 * remote callback is called.
 */
static void goal_lldpRxTimerCb(
    void *pArg                                  /**< timer argument */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_LLDP_INSTANCE_T *pLldp = (GOAL_LLDP_INSTANCE_T *) pArg; /* GOAL LLDP instance */
    uint32_t cnt;                               /* counter */
    uint32_t numPorts = 0;                      /* number of ports */
    GOAL_TIMESTAMP_T ts;                        /* current timestamp */
    GOAL_LLDP_RX_REMOTE_INFO_T *pRemoteDev;     /* remote device information */

    /* get current timestamp */
    ts = goal_timerTsGet();

    /* get number of ports */
    res = goal_ldpCorePortNumGet(pLldp, &numPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to get number of ports");
        return;
    }

    /* remove every aged remote device */
    for (cnt = 0; cnt < numPorts; cnt++) {
        pRemoteDev = &pLldp->pRx->pRemDevList[cnt];

        /* skip ports withoute known remote data */
        if (GOAL_FALSE == pRemoteDev->remDev.active) {
            continue;
        }

        if (pRemoteDev->tsRxLast + (pRemoteDev->ttl * GOAL_TIMER_SEC) < ts) {
            res = goal_lldpRxRemoteDeviceRemove(pLldp, (GOAL_ETH_PORT_T) cnt, GOAL_LLDP_REMOTE_CB_TYPE_DEVICE_EXPIRED);
            if (GOAL_RES_ERR(res)) {
                goal_logWarn("Failed to remove timeout remote device information und port %"FMT_u32, cnt);
                continue;
            }
        }
    }
}
