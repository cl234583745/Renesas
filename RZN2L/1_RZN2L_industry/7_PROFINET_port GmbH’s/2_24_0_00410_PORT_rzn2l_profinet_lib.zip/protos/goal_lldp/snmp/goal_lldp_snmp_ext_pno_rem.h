/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_EXT_PNO_REM_FILE_H
#define GOAL_LLDP_SNMP_EXT_PNO_REM_FILE_H


/****************************************************************************/
/* Data structures */
/****************************************************************************/
typedef union {
    uint32_t LPDVal;                            /**< LPD value */
    uint32_t TxDVal;                            /**< TxD value */
    uint32_t RxDVal;                            /**< RxD value */
    uint32_t statusRT2;                         /**< RT2 status */
    uint32_t statusRT3;                         /**< RT3 status */
    struct {                                    /**< name of station */
        char *str;                              /**< name of station string */
        uint16_t len;                           /**< name of station length */
    } nameOfStation;
    char *strMrpUuId;                           /**< */
    uint32_t lenMrpUuId;                        /**< */
    uint32_t mrrtStatus;                        /**< */
    char *strPtcpMasterMac;                     /**< Mac addres of ptcp master */
    char *strPtcpSubdomainUUID;                 /**< */
    uint32_t lenPtcpSubdomainUUID;              /**< */
    char *strPtcpIRDataUUID;                    /**< */
    uint32_t lenPtcpIRDataUUID;                 /**< */
    uint32_t portModeRT3;                       /**< */
    uint32_t periodLen;                         /**< period length */
    GOAL_BOOL_T prtiodValid;                    /**< period validity */
    uint32_t redOffset;                         /**< */
    GOAL_BOOL_T redValid;                       /**< */
    uint32_t orangeOffset;                      /**< */
    GOAL_BOOL_T orangeValid;                    /**< */
    uint32_t greenOffset;                       /**< */
    GOAL_BOOL_T greenValid;                     /**< */
} LLDP_X_PNO_REM_DATA_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T xPnoRemTable_init(
    void
);

SNMP_RET_T xPnoRemTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T xPnoRemTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

#endif /* GOAL_LLDP_SNMP_EXT_PNO_REM_FILE_H */
