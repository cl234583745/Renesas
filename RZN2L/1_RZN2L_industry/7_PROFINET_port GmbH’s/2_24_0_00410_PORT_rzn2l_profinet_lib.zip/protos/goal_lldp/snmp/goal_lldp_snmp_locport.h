/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_LOCPORT_FILE_H
#define GOAL_LLDP_SNMP_LOCPORT_FILE_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define LLDP_PORTID_MAX_LEN 255
#define LLDP_PORTDESC_MAX_LEN 255


/****************************************************************************/
/* Data structures */
/****************************************************************************/
typedef union {
    char *pPortDesc;                            /**< lldpLocPortDesc */
    uint32_t portIdSubtype;                     /**< lldpLocPortIdSubtype */
    struct {
        char *str;                              /**< string of lldpLocPortId */
        uint32_t len;                           /**< length of lldpLocPortId */
    } portId;                                   /**< lldpLocPortId */
} LLDP_LOCPORT_DATA_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T locPortTable_init(
    void
);

SNMP_RET_T locporttable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T locporttable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


#endif /* GOAL_LLDP_SNMP_LOCPORT_FILE_H */
