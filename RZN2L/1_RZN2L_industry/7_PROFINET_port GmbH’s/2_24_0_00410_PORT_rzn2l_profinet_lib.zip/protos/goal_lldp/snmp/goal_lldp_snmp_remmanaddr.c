/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* table entries */
/****************************************************************************/
static LLDP_REMMANADDR_ENTRY_T remManAddrTable[LLDP_REM_MANADDR_MAX];


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T remManAddrTable_updateEntries(
    void
);

static SNMP_RET_T remManAddrTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T remManAddrTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initializes lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T remManAddrTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* clear table */
    GOAL_MEMSET(remManAddrTable, 0, sizeof(remManAddrTable));

    /* update Table */
    ret = remManAddrTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpRemManAddrTable");
    }
    else {
        goal_logErr("Could not initialize lldpRemManAddrTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
static SNMP_RET_T remManAddrTable_updateEntries(
    void
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    uint32_t index;                             /* index of table variable */
    uint32_t portIndex;                         /* port Index */
    GOAL_LLDP_TLV_MAN_ADDR_T *pManAddr = NULL;  /* Management Address TLV pointer */
    uint16_t lenManAddr = 0;                    /* TLV length */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */


    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* clear table */
    GOAL_MEMSET(remManAddrTable, 0, sizeof(remManAddrTable));

    /* clear counter of remote management addresses */
    index = 0;

    /* get remote device info */
    for (portIndex = 0; LLDP_PORTCOUNT_MAX > portIndex; portIndex++)
    {
        res = goal_lldpTlvRxValueGet(pLldp,
                                     GOAL_LLDP_TLV_TYPE_MANADDR,
                                     portIndex,
                                     (uint8_t **) &pManAddr,
                                     &lenManAddr);
        if ((GOAL_RES_ERR(res)) ||
            (GOAL_LLDP_TLV_LEN_MANADDR_MIN > lenManAddr) ||
            ((sizeof(uint8_t) + pManAddr->data[GOAL_LLDP_MANADDR_OFF_STRLEN] ) > lenManAddr)) {
            continue;
        }

        /* store data in table */
        remManAddrTable[index].active = GOAL_TRUE;
        remManAddrTable[index].portIndex = portIndex;
        remManAddrTable[index].remIndex = 1;
        remManAddrTable[index].manAddrSubtype = (uint32_t) pManAddr->data[GOAL_LLDP_MANADDR_OFF_SUBTYPE];
        remManAddrTable[index].pManAddr = &pManAddr->data[GOAL_LLDP_MANADDR_OFF_ADDRESS];
        remManAddrTable[index].manAddrLen = (uint32_t) (pManAddr->data[GOAL_LLDP_MANADDR_OFF_STRLEN] - sizeof(uint8_t));

        /* update table counter */
        index++;
    }

    /* deactivate unused entries */
    for (;ARRAY_ELEMENTS(remManAddrTable) > index; index++) {
        remManAddrTable[index].active = GOAL_FALSE;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex of table entry matching the index OID
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
static SNMP_RET_T remManAddrTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t *pOid;                             /* index OID */

    uint32_t timeMark;                          /* time mark of last change of device */
    uint32_t portIndex;                         /* number of port in GOAL count */
    uint32_t remIndex;                          /* remote index */
    uint32_t ip;                                /* management address as IP address */
    uint32_t type;                              /* management address subtype */
    uint32_t len;                               /* management address len */

    uint32_t cnt;                               /* counter */

    /* update table entries */
    ret = remManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }
    ret = locManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len < 5) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    timeMark = *pOid;
    pOid++;

    portIndex = *pOid - 1;
    pOid++;

    remIndex = *pOid;
    pOid++;

    type = *pOid;
    pOid++;

    len = *pOid;
    pOid++;

    /* check whether the indexes and column are there using the length of address */
    if (msg->index_oid_len != 6 + len) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* Only implemented for IP addresses */
    if (len != PN_IPV4_ADDR_LEN) {
            msg->error = SNMP_ERR_NO_CREATION;
            goal_logDbg("Management address only implemented for IP addresses");
        return SNMP_RET_NOERR;
    }

    /* store IP */
    ip = GOAL_htobe32(*pOid << 24 | *(pOid + 1) << 16 | *(pOid + 2) << 8 | *(pOid + 3));
    pOid += PN_IPV4_ADDR_LEN;


    /* found remote device? */
    for (cnt = 0; cnt < ARRAY_ELEMENTS(remManAddrTable); cnt++) {
        if ((remManAddrTable[cnt].timeMark >= timeMark) &&
            (remManAddrTable[cnt].remIndex == remIndex) &&
            (remManAddrTable[cnt].portIndex == portIndex) &&
            (remManAddrTable[cnt].manAddrSubtype == type) &&
            (remManAddrTable[cnt].manAddrLen = len) &&
            ((*(uint32_t *)(remManAddrTable[cnt].pManAddr)) == ip)) {
                *pIndex = cnt;
                msg->error = SNMP_NOERR;
                return SNMP_RET_NOERR;

        }
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;

}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T remManAddrTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    uint16_t lenManAddr = 0;                    /* TLV length */
    LLDP_REMMANADDR_DATA_T data;                /* result data for returning */
    GOAL_LLDP_TLV_MAN_ADDR_T *pManAddr = NULL;  /* Management Address TLV pointer */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = remManAddrTable_getIndex(msg, &column,&index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* get management address */
    res = goal_lldpTlvRxValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_MANADDR,
                                 index,
                                 (uint8_t **) &pManAddr,
                                 &lenManAddr);

    /* Valid request. Set the required value */
    switch (column) {

        /* lldpRemManAddrSubtype */
        case SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDRSUBTYPE:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) &remManAddrTable[index].manAddrSubtype, sizeof(remManAddrTable[index].manAddrSubtype), 0,
                       ASN1_INTEGER);
#           endif
            break;

        /* lldpRemManAddr */
        case SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDR:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) remManAddrTable[index].pManAddr, (uint16_t) remManAddrTable[index].manAddrLen, 0,
                       ASN1_OCTET_STRING);
#           endif
            break;

        /* lldpRemManAddrIfSubtype */
        case SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDRIFSUBTYPE:

            data.manAddrIfSubtype = (uint32_t) pManAddr->data[sizeof(uint8_t) + GOAL_LLDP_MANADDR_OFF_STRLEN];

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.manAddrIfSubtype, sizeof(data.manAddrIfSubtype), 0,
                       ASN1_INTEGER);
            break;

        /* lldpRemManAddrIf */
        case SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDRIFID:

            data.manAddrIfNumber = GOAL_htobe32(*(uint32_t *) &pManAddr->data[sizeof(uint8_t) + GOAL_LLDP_MANADDR_OFF_STRLEN + sizeof(uint8_t)]);

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.manAddrIfNumber, sizeof(data.manAddrIfNumber), 0,
                       ASN1_INTEGER);
            break;

        /* lldpRemManAddrOid */
        case SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDROID:

        /* unknown column */
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T remManAddrTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = remManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(remManAddrTable); index++) {
        if (GOAL_TRUE == remManAddrTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(remManAddrTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = remManAddrTable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T remManAddrTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[11];                      /* found OID */
    uint32_t foundOidTmp[11];                   /* temporary memory for found OID */
    uint8_t lenFoundOid = 0;                    /* length of found OID */
    uint8_t lenFoundOidTmp = 0;                 /* length of found temporary OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */
    uint32_t ignoreList[] = {1};                /* list of ignored sub OIDs during comparison */

    uint32_t cnt;                               /* counter */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDRSUBTYPE;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPREMMANADDRTABLE_COLUMN_LLDPREMMANADDROID)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(remManAddrTable); index++) {

        /* skip inactive entries */
        if (GOAL_FALSE == remManAddrTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = remManAddrTable[index].timeMark;
        foundOidTmp[2] = remManAddrTable[index].portIndex + 1;
        foundOidTmp[3] = remManAddrTable[index].remIndex;
        foundOidTmp[4] = remManAddrTable[index].manAddrSubtype;
        foundOidTmp[5] = remManAddrTable[index].manAddrLen;

        /* Only supported for IP Addresses */
        for (cnt = 0; (cnt < remManAddrTable[index].manAddrLen) && (cnt < 5); cnt++) {
            foundOidTmp[6 + cnt] = (uint32_t) *(remManAddrTable[index].pManAddr + cnt);
        }

        /* compare OID with given one of GETNEXT request ignoring time filter for this moment */
        lenFoundOidTmp = (ARRAY_ELEMENTS(foundOidTmp) < 6 + remManAddrTable[index].manAddrLen) ? ARRAY_ELEMENTS(foundOidTmp) : ((uint8_t) (6 + remManAddrTable[index].manAddrLen));
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, lenFoundOidTmp, ignoreList, 1, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp), foundOid, ARRAY_ELEMENTS(foundOid), ignoreList, 1, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        lenFoundOid = lenFoundOidTmp;
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* construct lexicographical next node by setting time filter value to given value or 0 */
        if (var->var->oid->len <= indexOidStart + 1) {
            foundOid[1] = 0;
        }
        else {
            foundOid[1] = var->var->oid->sub_oid[indexOidStart + 1];
        }

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, lenFoundOid * sizeof(foundOid[0]));
        var->var->oid->len = indexOidStart + lenFoundOid;

        SNMP_MEMCPY(msg->index_oid, foundOid, lenFoundOid * sizeof(foundOid[0]));
        msg->index_oid_len = lenFoundOid;


        /* get value of found OID */
        ret = remManAddrTable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = remManAddrTable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = remManAddrTable_getNextInternal(msg, var);
    return ret;
}
