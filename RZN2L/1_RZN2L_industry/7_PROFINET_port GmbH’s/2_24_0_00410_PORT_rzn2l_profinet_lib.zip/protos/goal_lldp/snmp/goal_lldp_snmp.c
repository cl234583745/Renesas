/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>

#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
#   include <snmp_rfc1213_mib.h>
#endif


/****************************************************************************/
/* OIDs */
/****************************************************************************/
static uint32_t lldp_lldpMessageTxInterval_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 1, 0};
static uint32_t lldp_lldpMessageTxHoldMultiplier_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 2, 0};
static uint32_t lldp_lldpReinitDelay_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 3, 0};
static uint32_t lldp_lldpTxDelay_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 4, 0};
static uint32_t lldp_lldpNotificationInterval_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 5, 0};
static uint32_t lldp_lldpPortConfigTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 6, 1};
static uint32_t lldp_lldpConfigManAddrTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 1, 7, 1};
static uint32_t lldp_lldpStatsRemTablesLastChangeTime_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 1, 0};
static uint32_t lldp_lldpStatsRemTablesInserts_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 2, 0};
static uint32_t lldp_lldpStatsRemTablesDeletes_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 3, 0};
static uint32_t lldp_lldpStatsRemTablesDrops_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 4, 0};
static uint32_t lldp_lldpStatsRemTablesAgeouts_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 5, 0};
static uint32_t lldp_lldpStatsTxPortTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 6, 1};
static uint32_t lldp_lldpStatsRxPortTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 2, 7, 1};
static uint32_t lldp_lldpLocChassisIdSubtype_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 1, 0};
static uint32_t lldp_lldpLocChassisId_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 2, 0};
static uint32_t lldp_lldpLocSysName_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 3, 0};
static uint32_t lldp_lldpLocSysDesc_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 4, 0};
static uint32_t lldp_lldpLocSysCapSupported_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 5, 0};
static uint32_t lldp_lldpLocSysCapEnabled_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 6, 0};
static uint32_t lldp_lldpLocPortTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 7, 1};
static uint32_t lldp_lldpLocManAddrTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 3, 8, 1};
static uint32_t lldp_lldpRemTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 4, 1, 1};
static uint32_t lldp_lldpRemManAddrTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 4, 2, 1};
static uint32_t lldp_lldpRemUnknownTLVTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 4, 3, 1};
static uint32_t lldp_lldpRemOrgDefInfoTable_OID[10] = {1, 0, 8802, 1, 1, 2, 1, 4, 4, 1};


/****************************************************************************/
/* external variables */
/****************************************************************************/
/* sysName and sysDescription defined in RFC1213 */
extern char sysName[];
extern char sysDescription[];


/****************************************************************************/
/* local variables variables */
/****************************************************************************/
static uint32_t remoteDevLastChange[GOAL_TARGET_ETH_PORT_COUNT]; /**< sysUptime of last change of device information */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_lldp_lldpstatsremtablesageouts_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_table_lldplocporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldplocporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpstatsrxporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpstatsrxporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremunknowntlvtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremunknowntlvtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldplocsysname_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpmessagetxholdmultiplier_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpmessagetxholdmultiplier_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldplocchassisidsubtype_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_table_lldpremmanaddrtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremmanaddrtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremorgdefinfotable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpremorgdefinfotable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldplocsyscapsupported_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpstatsremtablesdrops_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldplocsysdesc_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldplocsyscapenabled_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_table_lldplocmanaddrtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldplocmanaddrtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpstatstxporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpstatstxporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpportconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpportconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldpstatsremtablesdeletes_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpstatsremtableslastchangetime_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpstatsremtablesinserts_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpmessagetxinterval_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpmessagetxinterval_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpconfigManAddrTable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_table_lldpconfigManAddrTable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldptxdelay_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldptxdelay_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldpnotificationinterval_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpnotificationinterval_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldpreinitdelay_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_lldpreinitdelay_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_lldplocchassisid_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
);

static SNMP_RET_T snmp_lldp_mib_init(
    void
);

#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
static SNMP_RET_T goal_lldpSnmpSysDescrUpdate(
    void
);
#endif


/****************************************************************************/
/** SNMP LLDP MIB init registering function
 *
 * This function initializes the SNMP LLDP MIBs
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_lldpSnmpInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* register MIB init function */
    res = goal_lldpSnmpMibInit();

    return res;
}


/****************************************************************************/
/** SNMP LLDP MIB init function
 *
 * This function initializes the SNMP LLDP MIBs
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_lldpSnmpMibInit(
    void
)
{
    SNMP_RET_T resSnmp;                         /* SNMP result */

    /* clear last change time stamps of remote devieces */
    GOAL_MEMSET(remoteDevLastChange, 0, sizeof(remoteDevLastChange));

    resSnmp = snmp_lldp_mib_init();

    if (SNMP_RET_NOERR == resSnmp) {
        resSnmp = snmp_lldp_ext_pno_mib_init();
    }
    if (SNMP_RET_NOERR == resSnmp) {
        resSnmp = snmp_lldp_ext_dot3_mib_init();
    }

    if (SNMP_RET_NOERR != resSnmp) {
        goal_logErr("Could not initialize LLDP MIBs.");
        return GOAL_ERROR;
    }

    goal_logInfo("Initialized LLDP MIBs.");
    return GOAL_OK;
}


/****************************************************************************/
/** SNMP LLDP port list TX enable get function
 *
 * Get a LldpPortList string (see LLDP-MIB) indicating all ports to which
 * the local system management address instances will be transmitted
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_lldpSnmpPortListTxEnableGet(
    char *pLldpPortList,                        /**< lldp port list */
    uint16_t *pLldpPortListSize                 /**< length of port list in byte */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t cnt;                                /* counter */
    uint32_t txDisableFlags;                    /* bitmask of disabled flags */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    res = goal_lldpTxDisablePortFlagsGet(pLldp, &txDisableFlags);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    for (cnt = 0; cnt < GOAL_TARGET_ETH_PORT_COUNT; cnt++) {
        if (GOAL_BIT_IS_SET(txDisableFlags, cnt)) {
            GOAL_BIT_CLR(pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(cnt)], GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(cnt));
        }
        else {
            GOAL_BIT_SET(pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(cnt)], GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(cnt));
        }
    }

    /* clear unused bits of last byte */
    while (0 != (cnt % 8)) {
        GOAL_BIT_CLR(pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(cnt)], GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(cnt));
        cnt++;
    }

    *pLldpPortListSize = GOAL_LLDP_SNMP_BYTES_FOR_BITS(GOAL_TARGET_ETH_PORT_COUNT);

    return GOAL_OK;
}


/****************************************************************************/
/** SNMP LLDP port list TX enable get function
 *
 * Cleans a LldpPortList string (see LLDP-MIB) indicating all ports to which
 * the local system management address instances will be transmitted. Bits
 * belonging non-exist
 *
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
GOAL_STATUS_T goal_lldpSnmpPortListTxEnableClean(
    char *pLldpPortList,                        /**< lldp port list */
    uint16_t lldpPortListSize                   /**< number of bytes of port list */
)
{
    GOAL_BOOL_T flgWarn = GOAL_TRUE;            /* warning flag */
    uint32_t cnt;                               /* counter */

    /* clean all bits of byte contining last port */
    for (cnt = GOAL_TARGET_ETH_PORT_COUNT; 0 != cnt % 8; cnt++) {
        if (((uint8_t) pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(cnt)]) & GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(cnt)) {
            if (flgWarn) {
                goal_logWarn("There are too much TxEnable bits to set, unnecessary bits are ignored");
                flgWarn = GOAL_FALSE;
            }
            pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(GOAL_TARGET_ETH_PORT_COUNT)] &= ~ (uint8_t) GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(cnt);
        }
    }
    /* check all following bytes */
    for (cnt = GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE; cnt < lldpPortListSize; cnt++) {
        if ((pLldpPortList[cnt])) {
            if (flgWarn) {
                goal_logWarn("There are too much TxEnable bits to set, unnecessary bits are ignored");
                flgWarn = GOAL_FALSE;
            }
            pLldpPortList[cnt] = '\0';
        }
    }

    return GOAL_OK;
}


/****************************************************************************/
/** SNMP LLDP port list TX enable get function
 *
 * Activate or deactivates transmitting the local system management address
 * instances to ports using a LldpPortList string (see LLDP-MIB).
 *
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
GOAL_STATUS_T goal_lldpSnmpPortListTxEnableSet(
    char *pLldpPortList,                        /**< lldp port list */
    uint16_t lldpPortListSize                   /**< number of bytes og port list */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint8_t portIdx;                            /* portIdx */
    GOAL_BOOL_T enable;                         /* Tx enable flag */
    uint32_t txDisableFlags;                    /* bitmask of disabled flags */
    GOAL_STATUS_T resGoal;                      /* GOAL result */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    if (NULL == pLldpPortList) {
        goal_logErr("No lldp list given.");
        return GOAL_ERR_NULL_POINTER;
    }

    /* clean lldp port List bit not belonging to ports */
    resGoal = goal_lldpSnmpPortListTxEnableClean(pLldpPortList, lldpPortListSize);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logWarn("Could not clean portmap bits not matching a port. Output of bitmask may vary.");
    }

    if (GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE > lldpPortListSize) {
        lldpPortListSize = GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE;
    }

    /* clear disable flags to set */
    txDisableFlags = 0;

    /* calculate bitmask of ports to disable */
    for (portIdx = 0; portIdx < GOAL_TARGET_ETH_PORT_COUNT; portIdx++) {

        if (GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(portIdx) > lldpPortListSize) {
            /* if portmap is done completly, set rest of ports to false  */
            enable = GOAL_FALSE;
        }
        else {
            /* get enable flag from input value */
            enable = GOAL_BIT_IS_SET((uint8_t) pLldpPortList[GOAL_LLDP_SNMP_PORT_LIST_BYTE_NO(portIdx)], GOAL_LLDP_SNMP_PORT_LIST_BYTE_POS(portIdx));
        }

        if (GOAL_TRUE == enable) {
            GOAL_BIT_CLR(txDisableFlags, portIdx);
        }
        else {
            GOAL_BIT_SET(txDisableFlags, portIdx);
        }
    }

    /* apply disabled ports */
    res = goal_lldpTxDisablePortFlagsSet(pLldp, txDisableFlags);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    return GOAL_OK;
}


static SNMP_RET_T snmp_lldp_lldpstatsremtablesageouts_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_GAUGE);
    return ret;
}

static SNMP_RET_T snmp_lldp_table_lldplocporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = locporttable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = locporttable_getNext(msg, var);
            break;
        default:
            break;
        }
    return result;
}

static SNMP_RET_T snmp_lldp_table_lldplocporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpstatsrxporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpstatsrxporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpremunknowntlvtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpremunknowntlvtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocsysname_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);

    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldpmessagetxholdmultiplier_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpmessagetxholdmultiplier_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpremtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = remtable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = remtable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_table_lldpremtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocchassisidsubtype_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return value */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */
    uint8_t *pData = NULL;                      /* chassis ID TLV data */
    uint16_t dataLen = 0;                       /* chassis ID TLV data length */
    GOAL_LLDP_TLV_CHASSISID_T *pChassisId;      /* chassis ID */

    UNUSEDARG(msg);

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    res = goal_lldpTxTlvValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_CHASSISID,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 GOAL_ETH_PORT_HOST,
                                 &pData,
                                 &dataLen);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    if (GOAL_RES_ERR(res) || (GOAL_LLDP_TLV_LEN_CHASSISID_MIN > dataLen)) {
        return SNMP_RET_RESOURCE;
    }

    /* store chassis ID subtype */
    pChassisId = (GOAL_LLDP_TLV_CHASSISID_T *) pData;
    ret = snmp_set_var_value_type(var, &pChassisId->subtype,
            sizeof(pChassisId->subtype), 0, ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_table_lldpremmanaddrtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = remManAddrTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = remManAddrTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_table_lldpremmanaddrtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpremorgdefinfotable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpremorgdefinfotable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocsyscapsupported_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);

    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldpstatsremtablesdrops_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);

    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocsysdesc_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);

    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocsyscapenabled_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);

    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldplocmanaddrtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = locmanaddrtable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = locmanaddrtable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_table_lldplocmanaddrtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpstatstxporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpstatstxporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpportconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpportconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldpstatsremtablesdeletes_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_GAUGE);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpstatsremtableslastchangetime_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_TIMETICKS);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpstatsremtablesinserts_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_GAUGE);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpmessagetxinterval_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpmessagetxinterval_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_table_lldpconfigManAddrTable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = configManAddrTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = configManAddrTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_table_lldpconfigManAddrTable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */

    /* get column and index */
    ret = configManAddrTable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* check type and if column is writable */
    switch (column) {
        case SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE:
            if (SNMP_CMD_VALUE == cmd) {
                /* Check type and value */
                if (ASN1_OCTET_STRING != var->var->type) {
                    msg->error = SNMP_ERR_WRONG_TYPE;
                    return SNMP_RET_NOERR;
                }
            }
            break;
        default:
            msg->error = SNMP_ERR_NOT_WRITABLE;
            return SNMP_RET_NOERR;
    }

    switch (cmd) {
    /* Check type */
    case SNMP_CMD_VALUE:
        ret = configManAddrTable_checkValue(index, column, msg, var);
        break;
    case SNMP_CMD_SET:
        ret = configManAddrTable_setValue(index, column, msg, var);
        break;
    default:
        break;
    }
    return ret;
}

static SNMP_RET_T snmp_lldp_lldptxdelay_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldptxdelay_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldpnotificationinterval_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpnotificationinterval_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldpreinitdelay_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_INTEGER);
    return ret;
}

static SNMP_RET_T snmp_lldp_lldpreinitdelay_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_lldplocchassisid_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< variable entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return value */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */
    uint8_t *pData = NULL;                      /* chassis ID TLV data */
    uint16_t dataLen = 0;                       /* chassis ID TLV data length */
    GOAL_LLDP_TLV_CHASSISID_T *pChassisId;      /* chassis ID */

    UNUSEDARG(msg);

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    res = goal_lldpTxTlvValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_CHASSISID,
                                 GOAL_LLDP_OUID_NONE,
                                 GOAL_LLDP_SUBTYPE_NONE,
                                 GOAL_ETH_PORT_HOST,
                                 &pData,
                                 &dataLen);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    if (GOAL_RES_ERR(res) || (GOAL_LLDP_TLV_LEN_CHASSISID_MIN > dataLen)) {
        return SNMP_RET_RESOURCE;
    }

    /* store chassis ID subtype */
    pChassisId = (GOAL_LLDP_TLV_CHASSISID_T *) pData;

    /* store chassis ID */
    ret = snmp_set_var_value_type(var, (uint8_t *) &pChassisId->str[0], dataLen - sizeof(pChassisId->subtype),
            0, ASN1_OCTET_STRING);
    return ret;
}


static SNMP_RET_T snmp_lldp_mib_init(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;

    SNMP_TABLE_HANDLER_FUNC_SET_T lldpLocPortTable = {snmp_lldp_table_lldplocporttable_get, snmp_lldp_table_lldplocporttable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpStatsRxPortTable = {snmp_lldp_table_lldpstatsrxporttable_get, snmp_lldp_table_lldpstatsrxporttable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpRemUnknownTLVTable = {snmp_lldp_table_lldpremunknowntlvtable_get, snmp_lldp_table_lldpremunknowntlvtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpRemTable = {snmp_lldp_table_lldpremtable_get, snmp_lldp_table_lldpremtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpRemManAddrTable = {snmp_lldp_table_lldpremmanaddrtable_get, snmp_lldp_table_lldpremmanaddrtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpRemOrgDefInfoTable = {snmp_lldp_table_lldpremorgdefinfotable_get, snmp_lldp_table_lldpremorgdefinfotable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpLocManAddrTable = {snmp_lldp_table_lldplocmanaddrtable_get, snmp_lldp_table_lldplocmanaddrtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpStatsTxPortTable = {snmp_lldp_table_lldpstatstxporttable_get, snmp_lldp_table_lldpstatstxporttable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpPortConfigTable = {snmp_lldp_table_lldpportconfigtable_get, snmp_lldp_table_lldpportconfigtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpConfigManAddrTable = {snmp_lldp_table_lldpconfigManAddrTable_get, snmp_lldp_table_lldpconfigManAddrTable_set, NULL};
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpStatsRemTablesAgeouts_OID[0], 10, SNMP_RO, snmp_lldp_lldpstatsremtablesageouts_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpLocPortTable_OID[0], 10, &lldpLocPortTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpStatsRxPortTable_OID[0], 10, &lldpStatsRxPortTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpRemUnknownTLVTable_OID[0], 10, &lldpRemUnknownTLVTable);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocSysName_OID[0], 10, SNMP_RO, snmp_lldp_lldplocsysname_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpMessageTxHoldMultiplier_OID[0], 10, SNMP_RW, snmp_lldp_lldpmessagetxholdmultiplier_get, snmp_lldp_lldpmessagetxholdmultiplier_set);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpRemTable_OID[0], 10, &lldpRemTable);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocChassisIdSubtype_OID[0], 10, SNMP_RO, snmp_lldp_lldplocchassisidsubtype_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpRemManAddrTable_OID[0], 10, &lldpRemManAddrTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpRemOrgDefInfoTable_OID[0], 10, &lldpRemOrgDefInfoTable);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocSysCapSupported_OID[0], 10, SNMP_RO, snmp_lldp_lldplocsyscapsupported_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpStatsRemTablesDrops_OID[0], 10, SNMP_RO, snmp_lldp_lldpstatsremtablesdrops_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocSysDesc_OID[0], 10, SNMP_RO, snmp_lldp_lldplocsysdesc_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocSysCapEnabled_OID[0], 10, SNMP_RO, snmp_lldp_lldplocsyscapenabled_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpLocManAddrTable_OID[0], 10, &lldpLocManAddrTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpStatsTxPortTable_OID[0], 10, &lldpStatsTxPortTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpPortConfigTable_OID[0], 10, &lldpPortConfigTable);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpStatsRemTablesDeletes_OID[0], 10, SNMP_RO, snmp_lldp_lldpstatsremtablesdeletes_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpStatsRemTablesLastChangeTime_OID[0], 10, SNMP_RO, snmp_lldp_lldpstatsremtableslastchangetime_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpStatsRemTablesInserts_OID[0], 10, SNMP_RO, snmp_lldp_lldpstatsremtablesinserts_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpMessageTxInterval_OID[0], 10, SNMP_RW, snmp_lldp_lldpmessagetxinterval_get, snmp_lldp_lldpmessagetxinterval_set);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_lldpConfigManAddrTable_OID[0], 10, &lldpConfigManAddrTable);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpTxDelay_OID[0], 10, SNMP_RW, snmp_lldp_lldptxdelay_get, snmp_lldp_lldptxdelay_set);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpNotificationInterval_OID[0], 10, SNMP_RW, snmp_lldp_lldpnotificationinterval_get, snmp_lldp_lldpnotificationinterval_set);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpReinitDelay_OID[0], 10, SNMP_RW, snmp_lldp_lldpreinitdelay_get, snmp_lldp_lldpreinitdelay_set);
    rv |= snmp_mib_register_node((uint32_t *) &lldp_lldpLocChassisId_OID[0], 10, SNMP_RO, snmp_lldp_lldplocchassisid_get, NULL);
    rv |= locPortTable_init();
    rv |= locManAddrTable_init();
    rv |= configManAddrTable_init();
    rv |= remTable_init();
#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
    rv |= goal_lldpSnmpSysDescrUpdate();
#endif
    return rv;
}


#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
/****************************************************************************/
/** SNMP RFC1213 sysDescr Update
 *
 * This function gets a valid annotation string, which will be set as
 * sysDescr in RFC1213.
 *
 * @returns SNMP_RET_T value
 */
static SNMP_RET_T goal_lldpSnmpSysDescrUpdate(
    void
)
{
    static char strAnno[PN_LEN_SERIAL_NR + PN_RPC_LEN_ANNO + 1]; /* annotation string */
    uint16_t len;                               /* length of annotation string */

    /* get annotation string */
    PN_rpcEpmAnno(strAnno, &len, PN_TRUE);

    /* store chassis ID as sysDescr */
    sysDescriptionSet(strAnno, len);

    return SNMP_RET_NOERR;
}
#endif /* GOAL_SNMP_MIB_RFC1213_DISABLE */
