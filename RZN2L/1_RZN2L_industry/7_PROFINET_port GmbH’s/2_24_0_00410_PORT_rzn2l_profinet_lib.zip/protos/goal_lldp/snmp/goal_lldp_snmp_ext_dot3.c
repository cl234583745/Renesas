/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* OIDs */
/****************************************************************************/
static uint32_t lldp_ext_dot3_lldpXdot3RemLinkAggTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 3, 3, 1};
static uint32_t lldp_ext_dot3_lldpXdot3LocLinkAggTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 2, 3, 1};
static uint32_t lldp_ext_dot3_lldpXdot3LocPortTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 2, 1, 1};
static uint32_t lldp_ext_dot3_lldpXdot3LocMaxFrameSizeTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 2, 4, 1};
static uint32_t lldp_ext_dot3_lldpXdot3PortConfigTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 1, 1, 1};
static uint32_t lldp_ext_dot3_lldpXdot3LocPowerTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 2, 2, 1};
static uint32_t lldp_ext_dot3_lldpXdot3RemPortTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 3, 1, 1};
static uint32_t lldp_ext_dot3_lldpXdot3RemMaxFrameSizeTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 3, 4, 1};
static uint32_t lldp_ext_dot3_lldpXdot3RemPowerTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 4623, 1, 3, 2, 1};


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);



static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = xDot3LocPortTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = xDot3LocPortTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remporttable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = xDot3RemPortTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = xDot3RemPortTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remporttable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_NOERR;
}


SNMP_RET_T snmp_lldp_ext_dot3_mib_init(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3RemLinkAggTable = {snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_get, snmp_lldp_ext_dot3_table_lldpxdot3remlinkaggtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3LocLinkAggTable = {snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_get, snmp_lldp_ext_dot3_table_lldpxdot3loclinkaggtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3LocPortTable = {snmp_lldp_ext_dot3_table_lldpxdot3locporttable_get, snmp_lldp_ext_dot3_table_lldpxdot3locporttable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3LocMaxFrameSizeTable = {snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_get, snmp_lldp_ext_dot3_table_lldpxdot3locmaxframesizetable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3PortConfigTable = {snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_get, snmp_lldp_ext_dot3_table_lldpxdot3portconfigtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3LocPowerTable = {snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_get, snmp_lldp_ext_dot3_table_lldpxdot3locpowertable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3RemPortTable = {snmp_lldp_ext_dot3_table_lldpxdot3remporttable_get, snmp_lldp_ext_dot3_table_lldpxdot3remporttable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3RemMaxFrameSizeTable = {snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_get, snmp_lldp_ext_dot3_table_lldpxdot3remmaxframesizetable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXdot3RemPowerTable = {snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_get, snmp_lldp_ext_dot3_table_lldpxdot3rempowertable_set, NULL};
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3RemLinkAggTable_OID[0], 13, &lldpXdot3RemLinkAggTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3LocLinkAggTable_OID[0], 13, &lldpXdot3LocLinkAggTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3LocPortTable_OID[0], 13, &lldpXdot3LocPortTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3LocMaxFrameSizeTable_OID[0], 13, &lldpXdot3LocMaxFrameSizeTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3PortConfigTable_OID[0], 13, &lldpXdot3PortConfigTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3LocPowerTable_OID[0], 13, &lldpXdot3LocPowerTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3RemPortTable_OID[0], 13, &lldpXdot3RemPortTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3RemMaxFrameSizeTable_OID[0], 13, &lldpXdot3RemMaxFrameSizeTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_dot3_lldpXdot3RemPowerTable_OID[0], 13, &lldpXdot3RemPowerTable);
    rv |= xDot3LocPortTable_init();
    rv |= xDot3RemPortTable_init();
    return rv;
}
