/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_DEFINES_H
#define GOAL_LLDP_SNMP_DEFINES_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#ifndef LLDP_PORTCOUNT_MAX
#   ifdef GOAL_TARGET_ETH_PORT_COUNT
#       define LLDP_PORTCOUNT_MAX GOAL_TARGET_ETH_PORT_COUNT
#   else
#       define LLDP_PORTCOUNT_MAX 2
#   endif
#endif

#endif /* GOAL_LLDP_SNMP_DEFINES_H */
