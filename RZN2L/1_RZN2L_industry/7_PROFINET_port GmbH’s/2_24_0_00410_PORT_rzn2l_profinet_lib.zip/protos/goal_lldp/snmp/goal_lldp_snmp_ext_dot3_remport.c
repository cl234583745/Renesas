/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* local variables */
/****************************************************************************/
static uint32_t cntPorts;


/****************************************************************************/
/* table entries */
/****************************************************************************/
extern LLDP_REM_ENTRY_T remTable[LLDP_PORTCOUNT_MAX];


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T xDot3RemPortTable_updateEntries(
    void
);

static SNMP_RET_T xDot3RemPortTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T xDot3RemPortTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initializes lldpRemPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
SNMP_RET_T xDot3RemPortTable_init(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    ret = xDot3RemPortTable_updateEntries();

    return ret;
}


/****************************************************************************/
/** Updates all lldpRemPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
static SNMP_RET_T xDot3RemPortTable_updateEntries(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    /* get number of ports */
    resGoal = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not get number of ports");
        return SNMP_RET_RESOURCE;
    }

    /* check number of ports */
    if (cntPorts > LLDP_PORTCOUNT_MAX) {
        goal_logWarn("%"FMT_u32 " port detected, at most %"FMT_u32 " are supported. Define LLDP_PORTCOUNT_MAX to support more ports.", cntPorts, (uint32_t) LLDP_PORTCOUNT_MAX);
        goal_logWarn("Highest %"FMT_u32 " ports are ignored.", (cntPorts - (uint32_t) LLDP_PORTCOUNT_MAX));
        cntPorts = (uint32_t) LLDP_PORTCOUNT_MAX;
    }
    if (0 == cntPorts) {
        goal_logWarn("No port detected.");
    }

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex The requested index of the port
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
static SNMP_RET_T xDot3RemPortTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* get index from remTableTable, which use same ones */
    ret = remtable_getIndex(msg, pColumn, pIndex);

    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T xDot3RemPortTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    LLDP_X_DOT3_REM_PORT_DATA_T data;           /* result data for returning */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */
    PN_LLDP_TLV_PHY_STATUS_T *pPhyStatus = NULL; /* PROFINET PHY status */
    uint16_t lenPhyStatus = 0;                  /* length of PHY status */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* get table entry matching OID */
    ret = xDot3RemPortTable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* get LLDP data */
    res = goal_lldpRxTlvValueGet(pLldp,
                                 GOAL_LLDP_TLV_TYPE_OS_EXT,
                                 PN_LLDP_ORGEXT_8023_OUID,
                                 PN_LLDP_ORGEXT_8023_SUBTYPE_PHY_STATUS,
                                 index,
                                 (uint8_t **) &pPhyStatus,
                                 &lenPhyStatus);
    if ((GOAL_RES_ERR(res)) || (sizeof(PN_LLDP_TLV_PHY_STATUS_T) != lenPhyStatus)) {
        return SNMP_RET_RESOURCE;
    }

    /* Valid request. Set the required value */
    switch (column) {

        /* lldpXDot3RemPortAutoNegSupported */
        case SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTAUTONEGSUPPORTED:

            if (0 == (PN_LLDP_PHY_IF_AUTONEG_SUPPORT_FLAG & pPhyStatus->autoNegState)) {
                data.autoNegSupport = SNMP_FALSE;
            }
            else {
                data.autoNegSupport = SNMP_TRUE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.autoNegSupport,
                                sizeof(data.autoNegSupport), 0, ASN1_INTEGER);
            break;

        /* lldpXDot3RemPortAutoNegEnabled */
        case SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTAUTONEGENABLED:

            if (0 == (PN_LLDP_PHY_IF_AUTONEG_ENABLE_FLAG & pPhyStatus->autoNegState)) {
                data.autoNegEnable = SNMP_FALSE;
            }
            else {
                data.autoNegEnable = SNMP_TRUE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.autoNegEnable,
                                sizeof(data.autoNegEnable), 0, ASN1_INTEGER);
            break;

        /* lldpXDot3RemPortAutoNegAdvertisedCap */
        case SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTAUTONEGADVERTISEDCAP:

            data.autoNegAdvCap = GOAL_be16toh(pPhyStatus->advertisedCap_be16);
            ret = snmp_set_var_value_type(var, (uint8_t *) &data.autoNegAdvCap,
                                sizeof(data.autoNegAdvCap), 0, ASN1_OCTET_STRING);
            break;

        /* lldpXDot3RemPortOperMauType */
        case SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTOPERMAUTYPE:

            data.operMauType = (uint32_t) GOAL_be16toh(pPhyStatus->mauType_be16);

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.operMauType,
                                sizeof(data.operMauType), 0, ASN1_INTEGER);
            break;

        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T xDot3RemPortTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = xDot3RemPortTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }
    ret = remTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(remTable); index++) {
        if (GOAL_TRUE == remTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(remTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = xDot3RemPortTable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable -internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T xDot3RemPortTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* port index (GOAL notation, starting with 0) */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[4];                       /* found OID */
    uint32_t foundOidTmp[4];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */
    uint32_t ignoreList[] = {1};                /* list of ignored sub OIDs during comparison */

    uint32_t ports;                             /* number of GOAL ports */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get number of ports */
    resGoal = goal_ethPortsGet(&ports);
    if (GOAL_RES_ERR(resGoal) || ports == 0) {
        return SNMP_RET_NOERR;
    }

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTAUTONEGSUPPORTED;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPXDOT3REMPORTTABLE_COLUMN_LLDPXDOT3REMPORTOPERMAUTYPE)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ports; index++) {

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = remTable[index].timeMark;
        foundOidTmp[2] = remTable[index].portNum;
        foundOidTmp[3] = remTable[index].remIndex;

        /* compare OID with given one of GETNEXT request ignoring time filter for this moment */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                ignoreList, 1, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    ignoreList, 1, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /*  construct lexicographical next node by setting time filter value to given value or 0 */
        if (var->var->oid->len <= indexOidStart + 1) {
            foundOid[1] = 0;
        }
        else {
            foundOid[1] = var->var->oid->sub_oid[indexOidStart + 1];
        }

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = xDot3RemPortTable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = xDot3RemPortTable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = xDot3RemPortTable_getNextInternal(msg, var);
    return ret;
}
