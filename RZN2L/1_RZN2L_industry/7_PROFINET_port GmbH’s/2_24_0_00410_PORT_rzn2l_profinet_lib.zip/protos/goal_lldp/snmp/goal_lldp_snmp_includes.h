/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_INCLUDES_H
#define GOAL_LLDP_SNMP_INCLUDES_H

#include <goal_includes.h>
#include <pn_includes.h>
#include <goal_lldp_includes.h>
#include <snmp_includes.h>

#include <goal_lldp_snmp_defines.h>

#include <goal_lldp_snmp.h>
#include <goal_lldp_snmp_locport.h>
#include <goal_lldp_snmp_locmanaddr.h>
#include <goal_lldp_snmp_configmanaddr.h>
#include <goal_lldp_snmp_rem.h>
#include <goal_lldp_snmp_remmanaddr.h>

#include <goal_lldp_snmp_ext_pno.h>
#include <goal_lldp_snmp_ext_pno_loc.h>
#include <goal_lldp_snmp_ext_pno_rem.h>

#include <goal_lldp_snmp_ext_dot3.h>
#include <goal_lldp_snmp_ext_dot3_locport.h>
#include <goal_lldp_snmp_ext_dot3_remport.h>

#endif /* GOAL_LLDP_SNMP_INCLUDES_H */
