/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_EXT_DOT3_REM_PORT_FILE_H
#define GOAL_LLDP_SNMP_EXT_DOT3_REM_PORT_FILE_H


/****************************************************************************/
/* Data structures */
/****************************************************************************/
typedef union {
    GOAL_SNMP_BOOL_T autoNegSupport;            /**< auto neg supported */
    GOAL_SNMP_BOOL_T autoNegEnable;             /**< auto neg enabled */
    uint32_t operMauType;                       /**< operational MAU type */
    uint16_t autoNegAdvCap;                     /**< auto neg advertised cap */
} LLDP_X_DOT3_REM_PORT_DATA_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T xDot3RemPortTable_init(
    void
);

SNMP_RET_T xDot3RemPortTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T xDot3RemPortTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

#endif /* GOAL_LLDP_SNMP_EXT_DOT3_REM_PORT_FILE_H */
