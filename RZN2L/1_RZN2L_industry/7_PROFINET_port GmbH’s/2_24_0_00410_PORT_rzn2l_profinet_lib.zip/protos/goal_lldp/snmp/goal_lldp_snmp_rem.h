/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_REM_FILE_H
#define GOAL_LLDP_SNMP_REM_FILE_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
typedef struct lldpRemEntry {
    GOAL_BOOL_T active;                         /**< active flag */
    uint32_t timeMark;                          /**< time mark of last change of device */
    uint32_t portNum;                           /**< port number in SNMP count */
    uint32_t remIndex;                          /**< remote index */
} LLDP_REM_ENTRY_T;


typedef struct {
    unsigned int chassisIdSubtypeRaw;           /**< peer chassis ID subtype */
    uint32_t chassisIdSubtype;                  /**< peer chassis ID subtype */
    char *pChassisId;                           /**< peer chassis ID */
    unsigned int portIdSubtypeRaw;              /**< peer port ID subtype */
    uint32_t portIdSubtype;                     /**< peer port ID subtype */
    char *pPortId;                              /**< peer port ID */
} LLDP_REM_DATA_T;


/****************************************************************************/
/* extern variables decleration */
/****************************************************************************/
extern LLDP_REM_ENTRY_T remTable[LLDP_PORTCOUNT_MAX];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T remTable_init(
    void
);

SNMP_RET_T remTable_updateEntries(
    void
);

SNMP_RET_T remtable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

SNMP_RET_T remtable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T remtable_getNext(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< var entry */
);


#endif /* GOAL_LLDP_SNMP_REM_FILE_H */
