/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_LOCMANADDR_FILE_H
#define GOAL_LLDP_SNMP_LOCMANADDR_FILE_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define LLDP_MANADDR_MAX 1
#define LLDP_MANADDR_LEN 5                      /**< 1 byte len, 4 byte IP address */


/****************************************************************************/
/* Data structures */
/****************************************************************************/
typedef struct lldpLocManAddrEntry {
    GOAL_BOOL_T active;                         /**< active flag */
    uint32_t manAddrSubtype;                    /**< lldpLocManAddrSubtype */
    uint8_t *pManAddr;                          /**< lldpLocManAddr */
    uint8_t ipAddr[4];                          /**< IP address */
    uint32_t manAddrLen;                        /**< lldpLocManAddrLen */
} LLDP_LOCMANADDR_ENTRY_T;

typedef union {
    uint32_t manAddrIfSubtype;                  /**< lldpLocManAddrIfSubtype */
    uint32_t manAddrIfId;                       /**< lldpLocManAddrIfId */
    uint32_t *pManAddrOid;                      /**< lldpLocManAddrOID */
    uint32_t manAddrOidLen;                     /**< len of lldpLocManAddrOID */
} LLDP_LOCMANADDR_DATA_T;


/****************************************************************************/
/* extern variables decleration */
/****************************************************************************/
extern LLDP_LOCMANADDR_ENTRY_T locManAddrTable[LLDP_MANADDR_MAX];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T locManAddrTable_init(
    void
);

SNMP_RET_T locManAddrTable_updateEntries(
    void
);

SNMP_RET_T locmanaddrtable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

SNMP_RET_T locmanaddrtable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T locmanaddrtable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

#endif /* GOAL_LLDP_SNMP_LOCMANADDR_FILE_H */
