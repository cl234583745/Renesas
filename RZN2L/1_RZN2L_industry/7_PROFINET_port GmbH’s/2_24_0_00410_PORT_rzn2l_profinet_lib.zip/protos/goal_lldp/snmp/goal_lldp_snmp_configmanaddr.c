/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>

#include <goal_snmp.h>


/****************************************************************************/
/* table entries */
/****************************************************************************/
extern LLDP_LOCMANADDR_ENTRY_T locManAddrTable[LLDP_MANADDR_MAX]; /**< lldpLocManAddrTable */


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T configManAddrTable_updateEntries(
    void
);

static SNMP_RET_T configManAddrTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Updates all lldpConfigManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T configManAddrTable_init(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpConfigManAddrTable");
    }
    else {
        goal_logErr("Could not initialize lldpConfigManAddrTable");
    }
    return ret;
}


/****************************************************************************/
/** Initializes lldpConfigManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
static SNMP_RET_T configManAddrTable_updateEntries(
    void
)
{
    SNMP_RET_T ret ;                            /* SNMP return value */

    /* update neccesary tables */
    ret = locManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        goal_logErr("Could not update locManAddrTable, which is used for configManAddrTable");
        goal_logErr("Could not initialize lldpConfigManAddrTable");
        return ret;
    }

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex of table entry matching the index OID
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T configManAddrTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* get index from locManAddrTableTable, which use same ones */
    ret = locmanaddrtable_getIndex(msg, pColumn, pIndex);

    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T configManAddrTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T resGoal;                      /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */

    char pLldpList[GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE]; /* lldp list for PortsTxEnable */
    uint16_t lldpListSize;                      /* length if port list in byte */

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = configManAddrTable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {

        /* lldpConfigManAddrPortsTxEnable */
        case SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE:

            resGoal = goal_lldpSnmpPortListTxEnableGet(pLldpList, &lldpListSize);
            if GOAL_RES_ERR(resGoal) {
                return SNMP_RET_RESOURCE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) pLldpList,
                            lldpListSize, 0, ASN1_OCTET_STRING);
            break;

        /* unknown column */
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Sets the value of the given column and index
 *
 * @param index The index contained in the set request
 * @param column The column of table contained in the set request
 * @param msg The message containing the set request
 * @param var The var entry to set
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T configManAddrTable_setValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T res;                          /* GOAL result */

    UNUSEDARG(index);

    switch (column) {
        /* lldpConfigManAddrPortsTxEnable */
        case SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE:

            /* check correctness of var entry */
            if (ASN1_OCTET_STRING != var->var->type) {
                msg->error = SNMP_ERR_WRONG_TYPE;
                return SNMP_RET_NOERR;
            }

            /* set new values */
            res = goal_lldpSnmpPortListTxEnableSet((char *) var->var->data, var->var->size);
            if GOAL_RES_ERR(res) {
                msg->error = SNMP_ERR_NO_CREATION;
                return SNMP_RET_NOERR;
            }
            break;

        /* unknown column */
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Checks the value of the given column and index
 *
 * @retval SNMP_RET_NOERR value has correct format
 * @retval other on failure
 */
SNMP_RET_T configManAddrTable_checkValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    UNUSEDARG(index);

    switch (column) {
        /* lldpConfigManAddrPortsTxEnable */
        case SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE:
            /* check correctness of var entry */
            if (ASN1_OCTET_STRING != var->var->type) {
                msg->error = SNMP_ERR_WRONG_TYPE;
                return SNMP_RET_NOERR;
            }

            /* check value */
            if (SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE_MAX_SIZE < var->var->size) {
                msg->error = SNMP_ERR_WRONG_LENGTH;
                return SNMP_RET_NOERR;
            }
            if (GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE < var->var->size) {
                goal_logWarn("Got %"FMT_u32" TxEnable bytes, only %"FMT_u32" are neccesary", (uint32_t) var->var->size, (uint32_t) GOAL_LLDP_SNMP_LLDP_PORT_LIST_SIZE);
            }
            break;

        /* unknown column */
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T configManAddrTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index = 0;                         /* table index */

    /* update table entries */
    ret = configManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    if (ARRAY_ELEMENTS(locManAddrTable) <= index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = configManAddrTable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T configManAddrTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* port index (GOAL notation, starting with 0) */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t ipAddr;                            /* IP address */
    uint32_t foundOid[8];                       /* found OID */
    uint32_t foundOidTmp[8];                    /* temporary memory for found OID */
    uint8_t lenFoundOidTmp = 0;                 /* length of found temporary OID */
    uint8_t lenFoundOid = 0;                    /* length of found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPCONFIGMANADDRTABLE_COLUMN_LLDPCONFIGMANADDRPORTSTXENABLE)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(locManAddrTable); index++) {

        /* skip inactive entries */
        if ((GOAL_TRUE != locManAddrTable[index].active)) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = locManAddrTable[index].manAddrSubtype;
        foundOidTmp[2] = locManAddrTable[index].manAddrLen;


        /* Only supported for IP Addresses */
        if ((foundOidTmp[2] != PN_IPV4_ADDR_LEN) ||
            (SNMP_LLDPLOCMANADDRTABLE_LLDPLOCMANADDRSUBTYPE_IPV4 != locManAddrTable[index].manAddrSubtype)) {
                continue;
        }

        /* calculate OID from IP address */
        ipAddr = GOAL_be32toh_p(locManAddrTable[index].pManAddr);
        GOAL_SNMP_IP_ADDR_TO_OID(&foundOidTmp[3], ipAddr);

        /* compare OID with given one of GETNEXT request */
        lenFoundOidTmp = 3 + (uint8_t) locManAddrTable[index].manAddrLen;
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, lenFoundOidTmp, NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, lenFoundOidTmp, foundOid, lenFoundOid, NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, lenFoundOidTmp * sizeof(foundOidTmp[0]));
        lenFoundOid = lenFoundOidTmp;
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {
        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, lenFoundOid * sizeof(foundOid[0]));
        var->var->oid->len = indexOidStart + lenFoundOid;

        SNMP_MEMCPY(msg->index_oid, foundOid, lenFoundOid * sizeof(foundOid[0]));
        msg->index_oid_len = lenFoundOid;

        /* get value of found OID */
        ret = configManAddrTable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = configManAddrTable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = configManAddrTable_getNextInternal(msg, var);
    return ret;
}
