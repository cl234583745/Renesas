/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* table entries */
/****************************************************************************/
LLDP_REM_ENTRY_T remTable[LLDP_PORTCOUNT_MAX];


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T remtable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initializes lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T remTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* clear table */
    GOAL_MEMSET(remTable, 0, sizeof(remTable));

    /* update table */
    ret = remTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpRemTable");
    }
    else {
        goal_logErr("Could not initialize lldpRemTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T remTable_updateEntries(
    void
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    uint32_t index;                             /* index of table variable */
    uint32_t cntPorts;                          /* number of ports */
    GOAL_LLDP_REMOTE_T *pRemote = NULL;         /* remote info pointer */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */


    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* get number of ports */
    res = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not get number of ports");
        return SNMP_RET_RESOURCE;
    }

    /* check number of ports */
    if (cntPorts > LLDP_PORTCOUNT_MAX) {
        goal_logWarn("More ports detected than expacted. Some ports are ignored.");
        cntPorts = LLDP_PORTCOUNT_MAX;
    }

    /* get remote device info */
    for (index = 0; index < cntPorts; index++) {
        /* get time of last change */
        res = goal_lldpRxPeerInfoGet(pLldp, index, &pRemote);
        if (GOAL_RES_ERR(res)) {
            remTable[index].active = GOAL_FALSE;
            continue;
        }

        /* go to next table entry if nothing changed */
        if ((GOAL_TRUE == remTable[index].active) && (pRemote->lastChange == remTable[index].timeMark)) {
            continue;
        }

        /* store data */
        remTable[index].active = GOAL_TRUE;
        remTable[index].timeMark = pRemote->lastChange;
        remTable[index].portNum = index + 1;
        remTable[index].remIndex = GOAL_LLDP_SNMP_REM_INDEX_DEFAULT;
    }
    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex of table entry matching the index OID
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T remtable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t *pOid;                             /* index OID */

    uint32_t timeMark;                          /* time mark */
    unsigned int remIndex;                      /* remote index */

    /* update table entries */
    ret = remTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len != 4) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    timeMark = *pOid;
    pOid++;

    *pIndex = *pOid - 1;
    pOid++;

    remIndex = *pOid;
    pOid++;

    /* check for valid index */
    if ((GOAL_TRUE == remTable[*pIndex].active) &&
        (remTable[*pIndex].timeMark >= timeMark) &&
        (remTable[*pIndex].remIndex == remIndex)) {
            msg->error = SNMP_NOERR;
            return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T remtable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    LLDP_REM_DATA_T data;                       /* result data for returning */
    GOAL_LLDP_TLV_CHASSISID_T *pChassisId = NULL; /* Chassis ID TLV pointer */
    GOAL_LLDP_TLV_PORTID_T *pPortId = NULL;     /* Port ID TLV pointer */
    uint16_t lenTlv = 0;                        /* TLV length */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = remtable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {

        /* lldpRemTimeMark */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMTIMEMARK:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) &remTable[index].timeMark,
                                sizeof(remTable[index].timeMark), 0, ASN1_INTEGER);
#           endif
            break;

        /* lldpRemLocalPortNum */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMLOCALPORTNUM:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) &remTable[index].portNum,
                                sizeof(remTable[index].portNum), 0, ASN1_INTEGER);
#           endif
            break;

        /* lldpRemIndex */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMINDEX:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) &remTable[index].remIndex,
                                sizeof(remTable[index].remIndex), 0, ASN1_INTEGER);
#           endif
            break;

        /* lldpRemChassisIdSubtype */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMCHASSISIDSUBTYPE:

            res = goal_lldpTlvRxValueGet(pLldp,
                                         GOAL_LLDP_TLV_TYPE_CHASSISID,
                                         index,
                                         (uint8_t **) &pChassisId,
                                         &lenTlv);
            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_CHASSISID_MIN > lenTlv)) {
                return SNMP_RET_RESOURCE;
            }

            data.chassisIdSubtype = (uint32_t) pChassisId->subtype;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.chassisIdSubtype,
                                sizeof(data.chassisIdSubtype), 0, ASN1_INTEGER);
            break;

        /* lldpRemChassisId */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMCHASSISID:

            res = goal_lldpTlvRxValueGet(pLldp,
                                         GOAL_LLDP_TLV_TYPE_CHASSISID,
                                         index,
                                         (uint8_t **) &pChassisId,
                                         &lenTlv);
            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_CHASSISID_MIN > lenTlv)) {
                return SNMP_RET_RESOURCE;
            }

            data.pChassisId = &pChassisId->str[0];

            ret = snmp_set_var_value_type(var, (uint8_t *) data.pChassisId,
                                GOAL_LLDP_CHASSISID_LEN_TLV_TO_STR(lenTlv), 0, ASN1_OCTET_STRING);
            break;

        /* lldpRemPortIdSubtype */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMPORTIDSUBTYPE:

            res = goal_lldpTlvRxValueGet(pLldp,
                                         GOAL_LLDP_TLV_TYPE_PORTID,
                                         index,
                                         (uint8_t **) &pPortId,
                                         &lenTlv);
            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_PORTID_MIN > lenTlv)) {
                return SNMP_RET_RESOURCE;
            }

            data.portIdSubtype = (uint32_t) pPortId->subtype;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.portIdSubtype,
                                sizeof(data.portIdSubtype), 0, ASN1_INTEGER);
            break;

        /* lldpRemPortId */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMPORTID:

            res = goal_lldpTlvRxValueGet(pLldp,
                                         GOAL_LLDP_TLV_TYPE_PORTID,
                                         index,
                                         (uint8_t **) &pPortId,
                                         &lenTlv);

            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_PORTID_MIN > lenTlv)) {
                return SNMP_RET_RESOURCE;
            }

            data.pPortId = &pPortId->str[0];

            ret = snmp_set_var_value_type(var, (uint8_t *) data.pPortId,
                                GOAL_LLDP_PORTID_LEN_TLV_TO_STR(lenTlv), 0, ASN1_OCTET_STRING);

            break;

        /* lldpRemPortDesc */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMPORTDESC:
        /* lldpRemSysName */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMSYSNAME:
        /* lldpRemSysDesc */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMSYSDESC:
        /* lldpRemSysCapSupported */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMSYSCAPSUPPORTED:
        /* lldpRemCapEnabled */
        case SNMP_LLDPREMTABLE_COLUMN_LLDPREMSYSCAPENABLED:
        /* unknown column */
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T remtable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = remTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(remTable); index++) {
        if (GOAL_TRUE == remTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(remTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = remtable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T remtable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[4];                       /* found OID */
    uint32_t foundOidTmp[4];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */
    uint32_t ignoreList[] = {1};                /* list of ignored sub OIDs during comparison */

    uint32_t ports;                             /* number of GOAL ports */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get number of ports */
    resGoal = goal_ethPortsGet(&ports);
    if (GOAL_RES_ERR(resGoal) || ports == 0) {
        return SNMP_RET_NOERR;
    }

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTNUM;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPREMTABLE_COLUMN_LLDPREMSYSCAPENABLED)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ports; index++) {

        /* skip inactive entries */
        if (GOAL_TRUE != remTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = remTable[index].timeMark;
        foundOidTmp[2] = remTable[index].portNum;
        foundOidTmp[3] = remTable[index].remIndex;

        /* compare OID with given one of GETNEXT request ignoring time filter for this moment */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                ignoreList, 1, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    ignoreList, 1, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* construct lexicographical next node by setting time filter value to given value or 0 */
        if (var->var->oid->len <= indexOidStart + 1) {
            foundOid[1] = 0;
        }
        else {
            foundOid[1] = var->var->oid->sub_oid[indexOidStart + 1] ;
        }

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = remtable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = remtable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = remtable_getNextInternal(msg, var);
    return ret;
}
