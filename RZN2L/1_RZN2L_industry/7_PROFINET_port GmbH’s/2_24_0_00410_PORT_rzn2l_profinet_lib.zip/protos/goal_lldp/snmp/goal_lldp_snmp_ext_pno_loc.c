/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* local variables */
/****************************************************************************/
static uint32_t cntPorts;


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T xPnoLocTable_updateEntries(
    void
);

static SNMP_RET_T xPnoLocTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T xPnoLocTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Updates all lldpLocPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
SNMP_RET_T xPnoLocTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* update Table */
    ret = xPnoLocTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpXPnoLocTable");
    }
    else {
        goal_logErr("Could not initialize lldpXPnoLocTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates lldpLocPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
static SNMP_RET_T xPnoLocTable_updateEntries(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    /* get number of ports */
    resGoal = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not get number of ports");
        return SNMP_RET_RESOURCE;
    }

    /* check number of ports */
    if (cntPorts > LLDP_PORTCOUNT_MAX) {
        goal_logWarn("%"FMT_u32 " port detected, at most %"FMT_u32 " are supported. Define LLDP_PORTCOUNT_MAX to support more ports.", cntPorts, (uint32_t) LLDP_PORTCOUNT_MAX);
        goal_logWarn("Highest %"FMT_u32 " ports are ignored.", (cntPorts - (uint32_t) LLDP_PORTCOUNT_MAX));
        cntPorts = LLDP_PORTCOUNT_MAX;
    }
    if (0 == cntPorts) {
        goal_logWarn("No port detected.");
    }

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex The requested index of the port
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
static SNMP_RET_T xPnoLocTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t *pOid;                             /* index OID */

    /* update table entries */
    ret = xPnoLocTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* First check whether the index and column are there */
    if (msg->index_oid_len != 2) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and index */
    *pColumn = *pOid;
    pOid++;

    *pIndex = *pOid - 1;
    pOid++;

    /* check for valid index */
    if (*pIndex < cntPorts) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T xPnoLocTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    LLDP_X_PNO_LOC_DATA_T data;                 /* result data for returning */
    GOAL_PNIO_T *pPnio = NULL;                  /* PROFINET instance */

    /* get default PROFINET instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pPnio, GOAL_ID_PNIO, PN_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        PN_logErr("PROFINET instance %u could not be found", PN_INSTANCE_DEFAULT);
        return SNMP_RET_RESOURCE;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = xPnoLocTable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {
        /* lldpXPnoLocPDValue */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCLPDVALUE:

            data.LPDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.LPDVal,
                            sizeof(data.LPDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoLocPortTxDValue */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTTXDVALUE:

            data.TxDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.TxDVal,
                            sizeof(data.TxDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoLocPortRxDValue */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTRXDVALUE:

            data.RxDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.RxDVal,
                            sizeof(data.RxDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoLocPortStatusRT2 */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTSTATUSRT2:

        /* lldpXPnoLocPortStatusRT3 */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTSTATUSRT3:
            msg->error = SNMP_ERR_NO_CREATION;
            break;

        /* lldpXPnoLocPortNoS */
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTNOS:
            res = PN_lldpLocNameOfStationGet(pPnio->pInstLocal, &data.nameOfStation.str, &data.nameOfStation.len);
            if (GOAL_RES_ERR(res)) {
                return SNMP_RET_RESOURCE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) &(data.nameOfStation.str[0]),
                            data.nameOfStation.len, 0, ASN1_OCTET_STRING);
            break;

        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTMRPUUID:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTMRRTSTATUS:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTPTCPMASTER:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTPTCPSUBDOMAINUUID:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTPTCPIRDATAUUID:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTMODERT3:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTPERIODLENGTH:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTPERIODVALIDITY:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTREDOFFSET:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTREDVALIDITY:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTORANGEOFFSET:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTORANGEVALIDITY:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTGREENOFFSET:
        case SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTGREENVALIDITY:
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldLocPortTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T xPnoLocTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* update table entries */
    ret = xPnoLocTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* process request to internal get next function */
    ret = xPnoLocTable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldLocPortTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T xPnoLocTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[2];                       /* found OID */
    uint32_t foundOidTmp[2];                    /* temporary memory for found OID */
    uint8_t lenFoundOidTmp = 0;                 /* length of found temporary OID */
    uint8_t lenFoundOid = 0;                    /* length of found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCLPDVALUE;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPXPNOLOCTABLE_COLUMN_LLDPXPNOLOCPORTGREENVALIDITY)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < cntPorts; index++) {

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = index + 1;

        /* compare OID with given one of GETNEXT request */
        lenFoundOidTmp = ARRAY_ELEMENTS(foundOidTmp);
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, lenFoundOidTmp, NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, lenFoundOidTmp, foundOid, lenFoundOid, NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, lenFoundOidTmp * sizeof(foundOidTmp[0]));
        lenFoundOid = lenFoundOidTmp;
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, lenFoundOid * sizeof(foundOid[0]));
        var->var->oid->len = indexOidStart + lenFoundOid;

        SNMP_MEMCPY(msg->index_oid, foundOid, lenFoundOid * sizeof(foundOid[0]));
        msg->index_oid_len = lenFoundOid;

        /* get value of found OID */
        ret = xPnoLocTable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = xPnoLocTable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = xPnoLocTable_getNextInternal(msg, var);
    return ret;
}
