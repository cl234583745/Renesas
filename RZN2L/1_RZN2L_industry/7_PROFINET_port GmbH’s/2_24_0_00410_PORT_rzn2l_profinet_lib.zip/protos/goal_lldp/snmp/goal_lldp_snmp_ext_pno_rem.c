/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* table entries */
/****************************************************************************/
extern LLDP_REM_ENTRY_T remTable[LLDP_PORTCOUNT_MAX];


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T xPnoRemTable_updateEntries(
    void
);

static SNMP_RET_T xPnoRemTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

static SNMP_RET_T xPnoRemTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);


/****************************************************************************/
/** Initializes lldpRemPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
SNMP_RET_T xPnoRemTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* update Table */
    ret = xPnoRemTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpXPnoRemTable");
    }
    else {
        goal_logErr("Could not initialize lldpXPnoRemTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates all lldpRemPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
static SNMP_RET_T xPnoRemTable_updateEntries(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    /* update neccesary tables */
    ret = remTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        goal_logErr("Could not update remTable, which is used for xPnoRemTable");
        goal_logErr("Could not initialize lldpXPnoRemTable");
    }

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex The requested index of the port
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
static SNMP_RET_T xPnoRemTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* get index from remTable, which use same ones */
    ret = remtable_getIndex(msg, pColumn, pIndex);

    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T xPnoRemTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    LLDP_X_PNO_REM_DATA_T data;                 /* result data for returning */
    GOAL_PNIO_T *pPnio = NULL;                  /* PROFINET instance */

    /* get default PROFINET instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pPnio, GOAL_ID_PNIO, PN_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        PN_logErr("PROFINET instance %u could not be found", PN_INSTANCE_DEFAULT);
        return SNMP_RET_RESOURCE;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = xPnoRemTable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {
        /* lldpXPnoRemLPDValue */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMLPDVALUE:

            data.LPDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.LPDVal,
                            sizeof(data.LPDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoRemPortTxDValue */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTTXDVALUE:

            data.TxDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.TxDVal,
                            sizeof(data.TxDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoRemPortRxDValue */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTRXDVALUE:

            data.RxDVal = 0;

            ret = snmp_set_var_value_type(var, (uint8_t *) &data.RxDVal,
                            sizeof(data.RxDVal), 0, ASN1_UINTEGER32);
            break;

        /* lldpXPnoRemPortStatusRT2 */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTSTATUSRT2:

        /* lldpXPnoRemPortStatusRT3 */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTSTATUSRT3:
            msg->error = SNMP_ERR_NO_CREATION;
            break;

        /* lldpXPnoRemPortNoS */
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTNOS:

            res = PN_lldpRemNameOfStationGet(pPnio->pInstLocal, index, &data.nameOfStation.str, &data.nameOfStation.len);
            if (GOAL_RES_ERR(res)) {
                return SNMP_RET_RESOURCE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) data.nameOfStation.str,
                            (uint16_t) data.nameOfStation.len, 0, ASN1_OCTET_STRING);
            break;

        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTMRPUUID:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTMRRTSTATUS:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTPTCPMASTER:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTPTCPSUBDOMAINUUID:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTPTCPIRDATAUUID:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTMODERT3:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTPERIODLENGTH:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTPERIODVALIDITY:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTREDOFFSET:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTREDVALIDITY:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTORANGEOFFSET:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTORANGEVALIDITY:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTGREENOFFSET:
        case SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTGREENVALIDITY:
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T xPnoRemTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = remTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(remTable); index++) {
        if (GOAL_TRUE == remTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(remTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = xPnoRemTable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T xPnoRemTable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */


    uint32_t foundOid[4];                       /* found OID */
    uint32_t foundOidTmp[4];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */
    uint32_t ignoreList[] = {1};                /* list of ignored sub OIDs during comparison */

    uint32_t ports;                             /* number of GOAL ports */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get number of ports */
    resGoal = goal_ethPortsGet(&ports);
    if (GOAL_RES_ERR(resGoal) || ports == 0) {
        return SNMP_RET_NOERR;
    }

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMLPDVALUE;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPXPNOREMTABLE_COLUMN_LLDPXPNOREMPORTGREENVALIDITY)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(remTable); index++) {

        /* skip inactive entries */
        if (GOAL_TRUE != remTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = remTable[index].timeMark;
        foundOidTmp[2] = remTable[index].portNum;
        foundOidTmp[3] = remTable[index].remIndex;

        /* compare OID with given one of GETNEXT request ignoring time filter for this moment */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, ARRAY_ELEMENTS(foundOidTmp), ignoreList, 1, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp), foundOid, ARRAY_ELEMENTS(foundOid), ignoreList, 1, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* construct lexicographical next node by setting time filter value to given value or 0 */
        if (var->var->oid->len <= indexOidStart + 1) {
            foundOid[1] = 0;
        }
        else {
            foundOid[1] = var->var->oid->sub_oid[indexOidStart + 1];
        }

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = xPnoRemTable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            var->var->oid->sub_oid[indexOidStart + ARRAY_ELEMENTS(foundOid) - 1] = foundOid[ARRAY_ELEMENTS(foundOid) - 1] + 1;
            msg->index_oid[ARRAY_ELEMENTS(foundOid) - 1] = foundOid[ARRAY_ELEMENTS(foundOid) - 1] + 1;
            ret = xPnoRemTable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = xPnoRemTable_getNextInternal(msg, var);
    return ret;
}
