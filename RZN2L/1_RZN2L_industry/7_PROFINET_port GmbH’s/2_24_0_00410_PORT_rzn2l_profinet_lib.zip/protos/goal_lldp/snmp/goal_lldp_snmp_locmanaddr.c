/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* table entries */
/****************************************************************************/
LLDP_LOCMANADDR_ENTRY_T locManAddrTable[LLDP_MANADDR_MAX];


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T locmanaddrtable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initializes lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T locManAddrTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* clear table */
    GOAL_MEMSET(locManAddrTable, 0, sizeof(locManAddrTable));

    /* update table */
    ret = locManAddrTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpLocManAddrTable");
    }
    else {
        goal_logErr("Could not initialize lldpLocManAddrTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates lldpLocManAddrTable entries
 *
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Management address could not be read from GOAL
 */
SNMP_RET_T locManAddrTable_updateEntries(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t index;                             /* index of table variable */
    GOAL_LLDP_TLV_MAN_ADDR_T *pManAddr = NULL;  /* management address pointer */
    uint16_t lenManAddr = 0;                    /* management address length */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* clear table */
    GOAL_MEMSET(locManAddrTable, 0, sizeof(locManAddrTable));

    /* retrive all differen management addresses */
    for (index = 0; (index < LLDP_MANADDR_MAX); index++) {

        /* get management address */
        res = goal_lldpTlvTxValueGet(pLldp,
                                     GOAL_ETH_PORT_HOST,
                                     GOAL_LLDP_TLV_TYPE_MANADDR,
                                     (uint8_t **) &pManAddr,
                                     &lenManAddr);
        if ((GOAL_RES_ERR(res)) ||
            (GOAL_LLDP_TLV_LEN_MANADDR_MIN > lenManAddr) ||
            ((sizeof(uint8_t) + pManAddr->data[GOAL_LLDP_MANADDR_OFF_STRLEN] )> lenManAddr)) {

            goal_logErr("Could not get management address no. %"FMT_u32, index);
            return SNMP_RET_RESOURCE;
        }

        /* store data in table */
        locManAddrTable[index].active = GOAL_TRUE;
        locManAddrTable[index].pManAddr = &pManAddr->data[GOAL_LLDP_MANADDR_OFF_ADDRESS];
        locManAddrTable[index].manAddrSubtype = (uint32_t) pManAddr->data[GOAL_LLDP_MANADDR_OFF_SUBTYPE];
        locManAddrTable[index].manAddrLen = (uint32_t) (pManAddr->data[GOAL_LLDP_MANADDR_OFF_STRLEN] - sizeof(uint8_t));
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex of table entry matching the index OID
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T locmanaddrtable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t ip;
    uint32_t len;
    uint32_t type;
    uint32_t cnt;
    uint32_t *pOid;

    /* update table entries */
    ret = locManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len < 3) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and both following indices: address type and len */
    *pColumn = *pOid;
    pOid++;

    type = *pOid;
    pOid++;

    len = *pOid;
    pOid++;

    /* check whether the indexes and column are there using the length of address */
    if (msg->index_oid_len != 3 + len) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* Only implemented for IP addresses */
    if (len != 4) {
            msg->error = SNMP_ERR_NO_CREATION;
            goal_logDbg("Management address only implemented for IP addresses");
        return SNMP_RET_NOERR;
    }

    /* get IP from OID as 32 bit value */
    ip = GOAL_SNMP_IP_ADDR_FROM_OID(pOid);
    pOid += 4;

    /* check for valid index */
    for (cnt = 0; cnt < LLDP_MANADDR_MAX; cnt++) {
        if ((GOAL_TRUE == locManAddrTable[cnt].active) &&
            (locManAddrTable[cnt].manAddrSubtype == type) &&
            (locManAddrTable[cnt].manAddrLen == len) &&
            (GOAL_be32toh_p(locManAddrTable[cnt].pManAddr) == ip)) {

                /* store found table index */
                *pIndex = cnt;
                msg->error = SNMP_NOERR;
                break;
        }
    }

    /* nothing found */
    if (LLDP_MANADDR_MAX == cnt) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T locmanaddrtable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */

    LLDP_LOCMANADDR_DATA_T data;                /* result data for returning */

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = locmanaddrtable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {
        /* lldpLocManAddrSubtype */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDRSUBTYPE:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) &(locManAddrTable[index].manAddrSubtype),
                            sizeof(locManAddrTable[index].manAddrSubtype), 0, ASN1_INTEGER);
#           endif
            break;

        /* lldpLocManAddr */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDR:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            ret = snmp_set_var_value_type(var, (uint8_t *) locManAddrTable[index].pManAddr,
                                locManAddrTable[index].manAddrLen, 0, ASN1_OCTET_STRING);
#           endif
            break;

        /* lldpLocManAddrLen */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDRLEN:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(locManAddrTable[index].manAddrLen),
                            sizeof(locManAddrTable[index].manAddrLen), 0, ASN1_INTEGER);
            break;

        /* lldpLocManAddrIfIdSubtype */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDRIFSUBTYPE:

            data.manAddrIfSubtype = SNMP_LLDPLOCMANADDRTABLE_LLDPLOCMANADDRIFSUBTYPE_IFINDEX;

            ret = snmp_set_var_value_type(var, (uint8_t *) &(data.manAddrIfSubtype),
                            sizeof(data.manAddrIfSubtype), 0, ASN1_INTEGER);
            break;

        /* lldpLocManAddrIfId */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDRIFID:

            data.manAddrIfId = index + 1;

            ret = snmp_set_var_value_type(var, (uint8_t *) &(data.manAddrIfId),
                            sizeof(data.manAddrIfId), 0, ASN1_INTEGER);
            break;

        /* lldpLocManAddrOID */
        case SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDROID:
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T locmanaddrtable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = locManAddrTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(locManAddrTable); index++) {
        if (GOAL_TRUE == locManAddrTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(locManAddrTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = locmanaddrtable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldRemTable Internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T locmanaddrtable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t ipAddr;                            /* IP address */
    uint32_t foundOid[8];                       /* found OID */
    uint32_t foundOidTmp[8];                    /* temporary memory for found OID */
    uint8_t lenFoundOid = 0;                    /* length of found OID */
    uint8_t lenFoundOidTmp = 0;                 /* length of found temporary OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDRSUBTYPE;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPLOCMANADDRTABLE_COLUMN_LLDPLOCMANADDROID)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(locManAddrTable); index++) {

        /* skip inactive entries */
        if (GOAL_TRUE != locManAddrTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = locManAddrTable[index].manAddrSubtype;
        foundOidTmp[2] = locManAddrTable[index].manAddrLen;


        /* Only supported for IP Addresses */
        if ((foundOidTmp[2] != PN_IPV4_ADDR_LEN) ||
            (SNMP_LLDPLOCMANADDRTABLE_LLDPLOCMANADDRSUBTYPE_IPV4 != locManAddrTable[index].manAddrSubtype)) {
                continue;
        }

        /* calculate IP addresse */
        ipAddr = GOAL_be32toh_p(locManAddrTable[index].pManAddr);
        GOAL_SNMP_IP_ADDR_TO_OID(&foundOidTmp[3], ipAddr);

        /* compare OID with given one of GETNEXT request */
        lenFoundOidTmp = 3 + (uint8_t) locManAddrTable[index].manAddrLen;
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, lenFoundOidTmp, NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, lenFoundOidTmp, foundOid, lenFoundOid, NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, lenFoundOidTmp * sizeof(foundOidTmp[0]));
        lenFoundOid = lenFoundOidTmp;
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {
        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, lenFoundOid * sizeof(foundOid[0]));
        var->var->oid->len = indexOidStart + lenFoundOid;

        SNMP_MEMCPY(msg->index_oid, foundOid, lenFoundOid * sizeof(foundOid[0]));
        msg->index_oid_len = lenFoundOid;

        /* get value of found OID */
        ret = locmanaddrtable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = locmanaddrtable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = locmanaddrtable_getNextInternal(msg, var);
    return ret;
}
