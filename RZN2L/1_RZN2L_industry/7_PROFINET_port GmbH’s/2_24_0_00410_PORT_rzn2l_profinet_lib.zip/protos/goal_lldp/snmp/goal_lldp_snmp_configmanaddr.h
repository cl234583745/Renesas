/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_CONFIGMANADDR_FILE_H
#define GOAL_LLDP_SNMP_CONFIGMANADDR_FILE_H

#include <goal_snmp.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T configManAddrTable_init(
    void
);

SNMP_RET_T configManAddrTable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

SNMP_RET_T configManAddrTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T configManAddrTable_setValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T configManAddrTable_checkValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T configManAddrTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

#endif /* GOAL_LLDP_SNMP_CONFIGMANADDR_FILE_H */
