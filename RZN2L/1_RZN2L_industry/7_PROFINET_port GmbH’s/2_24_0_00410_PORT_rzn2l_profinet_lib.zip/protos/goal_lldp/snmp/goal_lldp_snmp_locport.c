/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* local variables */
/****************************************************************************/
static char strInterfaceName[LLDP_PORTDESC_MAX_LEN];
static uint32_t cntPorts;


/****************************************************************************/
/* prototypes */
/****************************************************************************/
static SNMP_RET_T locPortTable_updateEntries(
    void
);

static SNMP_RET_T locporttable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T locporttable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initializes lldpLocPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table initialized
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
SNMP_RET_T locPortTable_init(
    void
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* update table */
    ret = locPortTable_updateEntries();

    if (SNMP_RET_NOERR == ret) {
        goal_logInfo("Initialized lldpLocPortTable");
    }
    else {
        goal_logErr("Could not initialize lldpLocPortTable");
    }
    return ret;
}


/****************************************************************************/
/** Updates lldpLocPortTable entries
 *
 * Sets the port names and collects the current values for the entries
 * from GOAL.
 *
 * @retval SNMP_RET_NOERR Table updated
 * @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
 */
static SNMP_RET_T locPortTable_updateEntries(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    /* get number of ports */
    resGoal = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not get number of ports");
        return SNMP_RET_RESOURCE;
    }

    /* check number of ports */
    if (cntPorts > LLDP_PORTCOUNT_MAX) {
        goal_logWarn("More ports detected than expacted. Some ports are ignored.");
        cntPorts = LLDP_PORTCOUNT_MAX;
    }

     return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
 *
 * @param msg The message containing the get request
 * @param pColumn The requested column
 * @param pIndex The requested index of the port
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
static SNMP_RET_T locporttable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t *pOid;                             /* index OID */

    /* update table entries */
    ret = locPortTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* First check whether the index and column are there */
    if (msg->index_oid_len != 2) {
            msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and index */
    *pColumn = *pOid;
    pOid++;

    *pIndex = *pOid - 1;
    pOid++;

    /* check for valid index */
    if (*pIndex < cntPorts) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
 *
 * @param msg The message containing the get request
 * @param var The var entry to update
 *
 * @retval SNMP_RET_NOERR value successfully copied
 * @retval other on failure
 */
SNMP_RET_T locporttable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t column = 0;                        /* column of request */
    uint32_t index = 0;                         /* array index matching request index */
    LLDP_LOCPORT_DATA_T data;                   /* result data for returning */
    uint16_t lenTlv = 0;                           /* length */
    GOAL_LLDP_TLV_PORTID_T *pPortId = NULL;     /* pointer to Port ID TLV */
    GOAL_LLDP_INSTANCE_T *pLldp = NULL;         /* LLDP instance */

    /* retrieve default instance */
    res = goal_instGetById((GOAL_INSTANCE_T **) &pLldp, GOAL_ID_LLDP, GOAL_LLDP_INSTANCE_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = locporttable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch (column) {
        /* lldpLocPortNum */
        case SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTNUM:
#           if SNMP_HIDE_NOT_ACCESSIBLE == 1
            msg->error = SNMP_ERR_NO_CREATION;
#           else
            index++;
            ret = snmp_set_var_value_type(var, (uint8_t *) &index,
                            sizeof(index), 0, ASN1_INTEGER);
            index --;
#           endif
            break;

        /* lldpLocPortDesc */
        case SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTDESC:

            /* set interface descriptor */
            data.pPortDesc = strInterfaceName;
            res = goal_snmpGetInterface(index, LLDP_PORTDESC_MAX_LEN, &data.pPortDesc);
            if (GOAL_RES_ERR(res)) {
                return SNMP_RET_RESOURCE;
            }

            ret = snmp_set_var_value_type(var, (uint8_t *) data.pPortDesc,
                            (uint16_t) GOAL_STRLEN(data.pPortDesc), 0, ASN1_OCTET_STRING);
            break;

        /* lldpLocPortIdSubtype */
        case SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTIDSUBTYPE:

            /* get Port ID */
            res = goal_lldpTlvTxValueGet(pLldp,
                                         index,
                                         GOAL_LLDP_TLV_TYPE_PORTID,
                                         (uint8_t **) &pPortId,
                                         &lenTlv);
            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_PORTID_MIN > lenTlv)) {

                goal_logErr("Could not get Port ID no. %"FMT_u32, index);
                return SNMP_RET_RESOURCE;
            }


            data.portIdSubtype = (uint32_t) pPortId->subtype;

            ret = snmp_set_var_value_type(var, (uint8_t *) &(data.portIdSubtype),
                            sizeof(data.portIdSubtype), 0, ASN1_INTEGER);
            break;

        /* lldpPortId */
        case SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTID:

            /* get Port ID */
            res = goal_lldpTlvTxValueGet(pLldp,
                                         index,
                                         GOAL_LLDP_TLV_TYPE_PORTID,
                                         (uint8_t **) &pPortId,
                                         &lenTlv);
            if ((GOAL_RES_ERR(res)) || (GOAL_LLDP_TLV_LEN_PORTID_MIN > lenTlv)) {

                goal_logErr("Could not get Port ID no. %"FMT_u32, index);
                return SNMP_RET_RESOURCE;
            }

            data.portId.len = (uint32_t) GOAL_LLDP_PORTID_LEN_TLV_TO_STR(lenTlv);
            data.portId.str = pPortId->str;

            ret = snmp_set_var_value_type(var, (uint8_t *) data.portId.str,
                            (uint16_t) data.portId.len, 0, ASN1_OCTET_STRING);
            break;
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldLocPortTable
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
SNMP_RET_T locporttable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    /* update table entries */
    ret = locPortTable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* process request to internal get next function */
    ret = locporttable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the lldLocPortTable - internal part
 *
 * @param msg The SNMP message containing the getnext request
 * @param var The var entry where the value is stored
 *
 * @retval SNMP_RET_RESOURCE No next value found in the table
 * @retval SNMP_RET_NOERR on success
 */
static SNMP_RET_T locporttable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[2];                       /* found OID */
    uint32_t foundOidTmp[2];                    /* temporary memory for found OID */
    uint8_t lenFoundOidTmp = 0 ;                /* length of found temporary OID */
    uint8_t lenFoundOid = 0;                    /* length of found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */


    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTNUM;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_LLDPLOCPORTTABLE_COLUMN_LLDPLOCPORTDESC)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < cntPorts; index++) {

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = index + 1;

        /* compare OID with given one of GETNEXT request */
        lenFoundOidTmp = ARRAY_ELEMENTS(foundOidTmp);
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len, foundOidTmp, lenFoundOidTmp, NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, lenFoundOidTmp, foundOid, lenFoundOid, NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, lenFoundOidTmp * sizeof(foundOidTmp[0]));
        lenFoundOid = lenFoundOidTmp;
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, lenFoundOid * sizeof(foundOid[0]));
        var->var->oid->len = indexOidStart + lenFoundOid;

        SNMP_MEMCPY(msg->index_oid, foundOid, lenFoundOid * sizeof(foundOid[0]));
        msg->index_oid_len = lenFoundOid;

        /* get value of found OID */
        ret = locporttable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = locporttable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0]++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = locporttable_getNextInternal(msg, var);
    return ret;
}
