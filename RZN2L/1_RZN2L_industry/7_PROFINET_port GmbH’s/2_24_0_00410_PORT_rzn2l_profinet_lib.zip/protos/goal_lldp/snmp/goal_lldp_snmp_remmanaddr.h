/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LLDP_SNMP_REM_MAN_ADDR_FILE_H
#define GOAL_LLDP_SNMP_REM_MAN_ADDR_FILE_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define LLDP_REM_MANADDR_MAX LLDP_PORTCOUNT_MAX


/****************************************************************************/
/* Data structures */
/****************************************************************************/
typedef struct {
    GOAL_BOOL_T active;
    uint32_t timeMark;
    uint32_t portIndex;
    uint32_t remIndex;
    uint32_t manAddrSubtype;
    uint8_t *pManAddr;
    uint32_t manAddrLen;
} LLDP_REMMANADDR_ENTRY_T;

typedef union {
    unsigned int manAddrIfSubtypeRaw;
    uint32_t manAddrIfSubtype;
    unsigned int manAddrIfNumberRaw;
    uint32_t manAddrIfNumber;
} LLDP_REMMANADDR_DATA_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T remManAddrTable_init(
    void
);

SNMP_RET_T remManAddrTable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T remManAddrTable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


#endif /* GOAL_LLDP_SNMP_REM_MAN_ADDR_FILE_H */
