/** @file
 *
 * @brief
 * PROFINET Simple Network Management Protocol Implementation for LLDP
 *
 * @details
 * This module contains the Simple Network Management Protocol
 * for LLDP including LLDP_MIB, LLDP_EXT_PNO_MIB and LLDP_EXT_DOT3_MIB
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_lldp_snmp_includes.h>


/****************************************************************************/
/* OIDs */
/****************************************************************************/
static uint32_t lldp_ext_pno_lldpXPnoConfigTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 3791, 1, 1, 1, 1};
static uint32_t lldp_ext_pno_lldpXPnoLocTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 3791, 1, 2, 1, 1};
static uint32_t lldp_ext_pno_lldpXPnoRemTable_OID[13] = {1, 0, 8802, 1, 1, 2, 1, 5, 3791, 1, 3, 1, 1};


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoloctable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoloctable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoremtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoremtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
);


static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoconfigtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoconfigtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoloctable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = xPnoLocTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = xPnoLocTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoloctable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoremtable_get(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = xPnoRemTable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = xPnoRemTable_getNext(msg, var);
            break;
        default:
            break;
    }
    return result;
}

static SNMP_RET_T snmp_lldp_ext_pno_table_lldpxpnoremtable_set(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var,                       /**< variable entry */
    SNMP_CMD_T cmd                              /**< command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}


SNMP_RET_T snmp_lldp_ext_pno_mib_init(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXPnoConfigTable = {snmp_lldp_ext_pno_table_lldpxpnoconfigtable_get, snmp_lldp_ext_pno_table_lldpxpnoconfigtable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXPnoLocTable = {snmp_lldp_ext_pno_table_lldpxpnoloctable_get, snmp_lldp_ext_pno_table_lldpxpnoloctable_set, NULL};
    SNMP_TABLE_HANDLER_FUNC_SET_T lldpXPnoRemTable = {snmp_lldp_ext_pno_table_lldpxpnoremtable_get, snmp_lldp_ext_pno_table_lldpxpnoremtable_set, NULL};
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_pno_lldpXPnoConfigTable_OID[0], 13, &lldpXPnoConfigTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_pno_lldpXPnoLocTable_OID[0], 13, &lldpXPnoLocTable);
    rv |= snmp_mib_register_table((uint32_t *) &lldp_ext_pno_lldpXPnoRemTable_OID[0], 13, &lldpXPnoRemTable);
    rv |= xPnoLocTable_init();
    rv |= xPnoRemTable_init();
    return rv;
}
