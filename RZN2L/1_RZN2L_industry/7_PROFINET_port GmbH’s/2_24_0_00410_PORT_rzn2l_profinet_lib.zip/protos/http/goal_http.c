/** @file
 *
 * @brief Implementation of the HTTP protocol
 *
 * Implementation of the HTTP protocol with basic features.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#define GOAL_ID GOAL_ID_HTTP
#include "goal_includes.h"
#include "goal_http.h"
#include "goal_http_resmgr.h"
#include "goal_http_parser.h"
#include "goal_http_tmpmgr.h"
#include "cm/goal_http_cm.h"
#if GOAL_CONFIG_HTTPS == 1
#  include "goal_https.h"
#  include "cm/goal_https_cm.h"
#endif
#include "goal_http_idlist.h"

#include "goal_net.h"


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_HTTP_SEND_RETRY_MAX            200         /* maxmimum number of sending retries */


/****************************************************************************/
/* Local variables */
/****************************************************************************/

#undef GOAL_HTTP_NAME
#define GOAL_HTTP_NAME(name, nr, str) {name, str, GOAL_HTTP_STRLEN(str)}

#undef GOAL_HTTP_EXT_NAME
#define GOAL_HTTP_EXT_NAME(name, nr, str, cont) {name, str, GOAL_HTTP_STRLEN(str), cont}

static struct goal_httpTableEntry goal_httpStatusTable[] = {GOAL_HTTP_STATUS}; /**< table of possible http status */
static struct goal_httpTableEntry goal_httpContentTable[] = {GOAL_HTTP_CONTENT}; /**< table of possible http content types */
static struct goal_httpTableEntry goal_httpMethodTable[] = {GOAL_HTTP_METHOD}; /**< table of possible http methods (GET, POST, etc.) */
static struct goal_httpExtTableEntry goal_httpFileExtTable[] = {GOAL_HTTP_FILE_EXT}; /**< table of possible file extensions */
static GOAL_HTTP_INST_CNT_T *pInstCnt = NULL;   /**< pointer to instance count */

static uint32_t cntChannel;                     /**< channel id counter */
static GOAL_STAGE_HANDLER_T stageInit;          /**< init stage handler */


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/

static GOAL_STATUS_T http_getInstCnt(
    uint32_t *pCntVar                           /**< pointer to count return */
);

static GOAL_STATUS_T http_incInstCnt(
    void
);

#if GOAL_CONFIG_GEN_CTC_CC == 1
static GOAL_STATUS_T goal_httpSendNextCtcFrag(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan                  /**< channel pointer */
);
#endif

static GOAL_STATUS_T goal_httpBufRelease(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to released buffer reference */
);

static GOAL_STATUS_T goal_httpTransDone(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_STATUS_T   state                       /**< goal status */
);

static GOAL_STATUS_T http_GetInstanceByChn(
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_HTTP_T **ppInst                        /**< return for instance pointer */
);

static void httpNetCb(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
);

static GOAL_STATUS_T goal_httpProcessReq(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
);

static GOAL_STATUS_T goal_httpCheckRet(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_STATUS_T           retParser,          /**< return from parser */
    GOAL_HTTP_APPLRET_T    *pApplRet            /**< pointer to application return */
);

static GOAL_STATUS_T goal_httpSendRes(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_HTTP_APPLRET_T    *pApplRet            /**< pointer to application return */
);

static GOAL_STATUS_T goal_httpAddHeader(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to net channel */
    GOAL_BUFFER_T *pBuf,                        /**< pointer to buffer */
    GOAL_HTTP_APPLRET_T *pApplRet               /**< pointer to application info */
);

static GOAL_STATUS_T goal_httpSendFrag(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel info */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to buffer reference */
);

static GOAL_STATUS_T goal_httpAllocResBuf(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to buffer pointer */
);

static GOAL_STATUS_T goal_httpForwardReq(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_HTTP_PARSE_T      *pPrsInfo,           /**< pointer to parser info */
    GOAL_HTTP_APPLRET_T    *pApplRet            /**< application return pointer */
);

static GOAL_STATUS_T goal_httpChnSetResBuf(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    GOAL_BUFFER_T   *pBuf                       /**< buffer pointer */
);

static GOAL_STATUS_T goal_httpChnSetRdySend(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    GOAL_BOOL_T flag                            /**< ready to send flag */
);

static GOAL_STATUS_T goal_httpChnGetRdySend(
    GOAL_HTTP_T *pInst,                         /**< [in] instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< [in] channel pointer */
    GOAL_BOOL_T *pFlag                          /**< [out] ready to send pointer */
);

static GOAL_STATUS_T goal_httpChnResetPend(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan                      /**< channel pointer */
);

static GOAL_STATUS_T goal_httpChnGetPend(
    GOAL_HTTP_T *pInst,                         /**< [in] instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< [in] channel pointer */
    GOAL_BOOL_T *pFlag                          /**< [out] pend flag pointer */
);

static GOAL_STATUS_T goal_httpChnClear(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan                  /**< channel pointer */
);

static GOAL_STATUS_T goal_httpChnChkWind(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< pointer to channel */
    GOAL_HTTP_PARSE_T  *pInfoPrs                /**< pointer to parser info */
);

static GOAL_STATUS_T goal_httpChnCpyChnk(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_BUFFER_T   *pBuf,                      /**< pointer to buffer from net module */
    uint8_t         **pData,                    /**< return pointer for buffered data */
    uint32_t        *pLenData                   /**< return pointer for buffered data length */
);

static GOAL_STATUS_T goal_httpChnGetResInfo(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_HTTP_RESFRAG_T     *pResFrag,          /**< pointer to fragmentation info */
    GOAL_HTTP_CTC_FRAG_T    *pCtcFrag           /**< pointer to CTC fragmentation info */
);

static GOAL_STATUS_T goal_httpChnGetResType(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< channel pointer */
    GOAL_HTTP_RESTYP_T  *pResType,              /**< pointer to response type */
    GOAL_HTTP_STATUS_T  *pHttpStatus            /**< pointer to http channel status */
);

static GOAL_STATUS_T goal_httpChnSetResType(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< channel pointer */
    GOAL_HTTP_RESTYP_T  resType,                /**< response type */
    GOAL_HTTP_STATUS_T  httpStatus              /**< http status of channel */
);

static GOAL_STATUS_T goal_httpFwAppl(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    GOAL_HTTP_REQ_T    *pReq,                   /**< pointer to request */
    const uint8_t       **pBuf,                 /**< address of pointer to return buffer */
    uint32_t            *pLen,                  /**< return length */
    GOAL_HTTP_STATUS_T *pState,                 /**< return status */
    GOAL_HTTP_CONTENT_T *pContent               /**< return content type */
);

static GOAL_STATUS_T goal_httpFwApplOnePost(
    GOAL_HTTP_T        *pInst,                  /**< instance pointer */
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    const uint8_t       **pBuf,                 /**< address of pointer to return buffer */
    uint32_t            *pLen,                  /**< return length */
    GOAL_HTTP_STATUS_T *pState,                 /**< return status */
    GOAL_HTTP_CONTENT_T *pContent,              /**< return content type */
    GOAL_HTTP_APPLCB_DATA_T *pCbInfo            /**< pointer to callback info */
);

static GOAL_STATUS_T goal_httpGetUrlStr(
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    char               **ppUrl,                 /**< URL string */
    uint32_t           *pLenUrl,                /**< URL length */
    uint32_t           *pLenMatch               /**< match length */
);

static GOAL_STATUS_T http_searchString(
    char *pMes,                                 /**< message string */
    char *strSearch,                            /**< string to look for */
    uint32_t *pStart,                           /**< start character */
    uint32_t *pEnd                              /**< end character */
);

static GOAL_STATUS_T goal_httpPastInit(
    void
);

static void goal_httpMainLoop(
    void
);


/****************************************************************************/
/** This function returns the recent http instance count.
 *
 * @return GOAL_OK on success
 * @return GOAL error code otherwise
 *
 */
static GOAL_STATUS_T http_getInstCnt(
    uint32_t *pCntVar                           /**< pointer to count return */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */

    /* get lock */
    ret = goal_lockGet(pInstCnt->lock, GOAL_LOCK_INFINITE);
    if (GOAL_RES_OK(ret)) {
        /* set return pointer */
        *pCntVar = pInstCnt->cnt;

        /* release lock */
        goal_lockPut(pInstCnt->lock);
    }
    return ret;
}


/****************************************************************************/
/** This function increases the recent http instance count.
 *
 * @return GOAL_OK on success
 * @return GOAL error code otherwise
 *
 */
static GOAL_STATUS_T http_incInstCnt(
    void
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */

    /* get lock */
    ret = goal_lockGet(pInstCnt->lock, GOAL_LOCK_INFINITE);
    if (GOAL_RES_OK(ret)) {
        /* increase instance count */
        pInstCnt->cnt++;
        /* release lock */
        goal_lockPut(pInstCnt->lock);
    }
    return ret;
}


/****************************************************************************/
/** This function searches a string within a given buffer.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 *
 * The string is searched within the given start and end border values.
 * When the function returns GOAL_OK, the string has been found and
 * start and end variables contain the offset of the string in the message.
 */
static GOAL_STATUS_T http_searchString(
    char *pMes,                                 /**< message string */
    char *strSearch,                            /**< string to look for */
    uint32_t *pStart,                           /**< start character */
    uint32_t *pEnd                              /**< end character */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint32_t lenSearch;                         /* search string length */
    uint32_t cnt = 0;                           /* loop counter */

    /* check input params */
    if ((NULL == pStart)
    ||  (NULL == pEnd)
    ||  (NULL == pMes)
    ||  (NULL == strSearch)) {
        return GOAL_ERR_NULL_POINTER;
    } else if (*pStart >= *pEnd) {
        return GOAL_ERROR;
    }

    /* get search string length */
    lenSearch = (uint32_t) GOAL_STRLEN(strSearch);

    for (cnt = *pStart; (cnt < *pEnd) && (GOAL_OK != ret); cnt++) {
        /* check first character */
        if (strSearch[0] == pMes[cnt]) {
            if (0 == GOAL_MEMCMP(&pMes[cnt], strSearch, lenSearch)) {
                /* set border values */
                *pStart = cnt;
                *pEnd = cnt + lenSearch;
                /* set return value */
                ret = GOAL_OK;
            }
        }
    }
    return ret;
}


#if (GOAL_CONFIG_GEN_CTC_CC == 1)


/****************************************************************************/
/** Response buffer release callback function
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpSendNextCtcFrag(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan                  /**< channel pointer */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    const uint8_t *pData = NULL;                /* data pointer */
    uint32_t lenData = 0;                       /* data length */
    GOAL_BUFFER_T *pNew = NULL;                 /* new buffer pointer */

    if (GOAL_RES_OK(ret)) {
        /* use callback function */
        ret = goal_httpDataContinueCc(pInst, pChan, &pData, &lenData);
    }

    if (GOAL_RES_OK(ret)) {
        /* get new buffer */
        ret = goal_httpAllocResBuf(pInst, &pNew);
    }

    if (GOAL_RES_OK(ret)) {
        /* set buffer for this channel */
        ret = goal_httpChnSetResBuf(pInst, pChan, pNew);
    }

    if (GOAL_RES_OK(ret)) {
        /* add next fragment to buffer */
        ret = goal_httpAddToBuffer(pInst, pNew, pChan, pData, lenData);
    }

    /* release buffer if any error occurred */
    if (GOAL_RES_ERR(ret) && (NULL != pNew)) {
        goal_queueReleaseBuf(&pNew);
    }

    if (GOAL_RES_OK(ret)) {
        /* set ready to send flag */
        ret = goal_httpChnSetRdySend(pInst, pChan, GOAL_TRUE);
    }

    return ret;
}

#endif


/****************************************************************************/
/** Response buffer release callback function
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpBufRelease(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to released buffer reference */
)
{
    GOAL_STATUS_T           ret = GOAL_ERROR;   /* return value */
    GOAL_HTTP_RESFRAG_T     resFrag;            /* response fragmentation info */
    GOAL_HTTP_CTC_FRAG_T    ctcFrag;            /* CTC fragmentation info */
    GOAL_BUFFER_T           *pNew = NULL;       /* buffer pointer */
    GOAL_BOOL_T             rdySnd = GOAL_FALSE; /* ready to send flag */
    GOAL_BOOL_T             pend = GOAL_FALSE;  /* send buffer pending flag */

    /* check pointer */
    if ((NULL == pInst) || (NULL == pChan) || (NULL == ppBuf)) {
        /* error */
        return GOAL_ERR_NULL_POINTER;
    }

    /* get fragmentation info */
    ret = goal_httpChnGetResInfo(pInst, pChan, &resFrag, &ctcFrag);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* get ready to send flag */
    ret = goal_httpChnGetRdySend(pInst, pChan, &rdySnd);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* get send buffer pending flag */
    ret = goal_httpChnGetPend(pInst, pChan, &pend);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* check ready to send */
    if (GOAL_TRUE == rdySnd) {
        /* check for valid buffer */
        if (NULL == *ppBuf) {
            return GOAL_ERR_NULL_POINTER;
        }

        /* send */
        ret = goal_httpSendFrag(pInst, pChan, ppBuf);
        /* return if sending is waiting for next loop iteration or failed */
        if ((GOAL_RES_ERR(ret)) || (GOAL_OK_DELAYED == ret)) {
            return ret;
        }

        /* release buffer */
        ret = goal_queueReleaseBuf(ppBuf);
        if (GOAL_RES_ERR(ret)) {
            goal_logErr("Buffer could not be released");
        }

        /* reset ready to send flag */
        ret = goal_httpChnSetRdySend(pInst, pChan, GOAL_FALSE);
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }

        /* reset pending flag */
        goal_httpChnResetPend(pInst, pChan);
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }

    /* check fragmentation info */
    } else if ((GOAL_TRUE == resFrag.flag) && (GOAL_FALSE == pend)) {
        /* get new buffer */
        ret = goal_httpAllocResBuf(pInst, &pNew);
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }

        if (GOAL_RES_OK(ret)) {
            /* set response buffer for this channel */
            ret = goal_httpChnSetResBuf(pInst, pChan, pNew);

            /* release buffer if any error occurred */
            if (GOAL_RES_ERR(ret)) {
                goal_queueReleaseBuf(&pNew);
            }
        }

        if (GOAL_RES_OK(ret)) {
            /* add next fragment to buffer */
            ret = goal_httpAddToBuffer(pInst, pNew, pChan,
                                    (const uint8_t *) (resFrag.pData + resFrag.srcOff),
                                    (resFrag.lenData - resFrag.srcOff));

            /* release buffer if any error occurred */
            if (GOAL_RES_ERR(ret)) {
                goal_queueReleaseBuf(&pNew);
            }
        }

        if (GOAL_RES_OK(ret)) {
            /* set ready to send flag */
            ret = goal_httpChnSetRdySend(pInst, pChan, GOAL_TRUE);
        }
#if (GOAL_CONFIG_GEN_CTC_CC == 1)
    } else if ((GOAL_TRUE == ctcFrag.getFrag) && (GOAL_FALSE == pend)) {
        /* get and send next data fragment */
        ret = goal_httpSendNextCtcFrag(pInst, pChan);
#endif
    } else {
        if (GOAL_TRUE == goal_httpChnState_get(pInst, pChan, GOAL_HTTP_CHNFLAG_CLOSCHN)) {
#if (GOAL_CONFIG_GEN_CTC_CC == 1)
            /* inform AC to close channel */
            goal_httpChnCloseCc(pInst, pChan);
#endif

            /* inform application that transaction is done */
            ret = goal_httpTransDone(pInst, pChan, GOAL_OK);
            /* clear channel */
            ret = goal_httpChnClear(pInst, pChan);

            /* no fragments to send, close channel */
            goal_netClose(pChan);
        }
    }
    /* leave loop */
    return ret;
}


/****************************************************************************/
/** Informs application via callback that transmission is done
 *
 * @retval GOAL_OK successful
 *
 */
static GOAL_STATUS_T goal_httpTransDone(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_STATUS_T   state                       /**< goal status */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    GOAL_HTTP_REQFRAG_T reqFrag;                /* request fragmentation info */
    GOAL_HTTP_REQCB_T   pfnApplCb;              /* application callback */
    GOAL_HTTP_APPLCB_DATA_T infoApplCb;         /* application callback info */
    uint32_t id = 0;                            /* channel ID */

    /* init struct */
    GOAL_MEMSET(&infoApplCb, 0, sizeof(infoApplCb));

    /* get channel request info */
    ret = goal_httpChnGetReqInfo(pInst, pChan, &reqFrag);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* set callback function pointer */
    pfnApplCb = (GOAL_HTTP_REQCB_T) (reqFrag.pfnAppCb);
    if (pfnApplCb) {
        if (GOAL_RES_OK(state)) {
            /* state is OK */
            infoApplCb.reqType = GOAL_HTTP_FW_REQ_DONE_OK;
        } else {
            /* state is not ok */
            infoApplCb.reqType = GOAL_HTTP_FW_REQ_DONE_ERR;
        }
        /* set application callback info struct */
        infoApplCb.pInst = pInst;
        infoApplCb.hdlRes = reqFrag.hdlRes;

        ret = goal_httpChannelId(pInst->pListChan, pChan, &id);
        if (GOAL_RES_OK(ret)) {
            infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;

            /* use callback */
            ret = (*pfnApplCb)(&infoApplCb);
        }
    }
    return ret;
}


/****************************************************************************/
/** HTTP Callback for net module
 *
 * Sends received data to http module, which handles the incoming request.
 *
 */
static GOAL_STATUS_T http_GetInstanceByChn(
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_HTTP_T **ppInst                        /**< return for instance pointer */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    uint32_t cnt1;                              /* loop 1 counter */
    uint32_t cnt2;                              /* loop 2 counter */
    uint32_t cntInst;                           /* http instance count */
    uint32_t cntChn;                            /* channel count */
    GOAL_BOOL_T fndFlag = GOAL_FALSE;           /* found flag */
    GOAL_HTTP_T *pInst;                         /* temporary instance pointer */

    /* get recent instance count */
    ret = http_getInstCnt(&cntInst);

    if (GOAL_RES_OK(ret)) {
        for (cnt1 = 0; ((cnt1 < cntInst) && (GOAL_RES_OK(ret)) && (GOAL_FALSE == fndFlag)); cnt1++) {
            /* get instance */
            ret = goal_instGetById((GOAL_INSTANCE_T **) &pInst, GOAL_ID_HTTP, cnt1);

            if (GOAL_RES_OK(ret)) {
                /* get channel count */
                cntChn = pInst->cntChn;
                /* search channel */
                for (cnt2 = 0; ((cnt2 < cntChn) && (GOAL_FALSE == fndFlag)); cnt2++) {
                    if (pChan == pInst->pChanHdl[cnt2].pChan) {
                        /* found correct channel */
                        *ppInst = pInst;
                        /* set flag */
                        fndFlag = GOAL_TRUE;
                    }
                }
            }
        }
    }

    if ((GOAL_RES_OK(ret)) && (GOAL_FALSE == fndFlag)) {
        /* error */
        ret = GOAL_ERR_NOT_FOUND;
    }

    return ret;
}


/****************************************************************************/
/** HTTP Callback for net module
 *
 * Sends received data to http module, which handles the incoming request.
 *
 */
static void httpNetCb(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
)
{
    GOAL_NET_ADDR_T remote;                     /* remote address */
    GOAL_STATUS_T res;                          /* result */
    GOAL_HTTP_T *pInstance = NULL;              /* instance pointer */

    /* channel opened */
    if (GOAL_NET_CB_NEW_SOCKET == cbType) {
        goal_logDbg("HTTP connection opened");
        /* activate channel */
        res = goal_netActivate(pChan);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("error while activating TCP channel");
            goal_netClose(pChan);
        }
    }
    /* data received */
    else if (GOAL_NET_CB_NEW_DATA == cbType) {
        goal_logDbg("HTTP request received");

        /* get IP Address of remote node
         * depending on the platform this callback might not be able to provide
         * the address via pAddr
         */
        res = goal_netGetRemoteAddr(pChan, &remote);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to get Remote Address for socket %"FMT_u64, (uint64_t) (PtrCast) pChan);
            return;
        }

        /* get instance */
        res = http_GetInstanceByChn(pChan, &pInstance);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to link channel to instance");
            return;
        }

        /* process message */
        res = goal_httpProcessReq(pInstance, pChan, pBuf);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to process message");
            return;
        }
    }
    /* channel closed */
    else if (GOAL_NET_CB_CLOSING == cbType) {
        goal_logDbg("HTTP connection closed");
        /* get instance */
        res = http_GetInstanceByChn(pChan, &pInstance);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to get instance by channel");
            return;
        }
        /* set close channel flag (application callback will be used via main) */
        goal_httpChnState_set(pInstance, pChan, GOAL_HTTP_CHNFLAG_CLOSCHN);
    }
}


/****************************************************************************/
/** This functions processes a received request message from http client.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpProcessReq(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    GOAL_HTTP_PARSE_T      infoPrs;             /* parser information struct */
    GOAL_HTTP_APPLRET_T    applRet;             /* application return */

    uint8_t     *pDataIn = NULL;                /* incoming data after chunk handling */
    uint32_t    lenDataIn = 0;                  /* incoming data length after chunk handling */

    GOAL_MEMSET(&applRet, 0, sizeof(applRet));
    GOAL_MEMSET(&infoPrs, 0, sizeof(infoPrs));

    /* check instance pointer */
    if (NULL == pInst) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* copy data chunk to channel buffer */
    ret = goal_httpChnCpyChnk(pInst, pChan, pBuf, &pDataIn, &lenDataIn);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("Data chunk buffering failed");
        return ret;
    }

    /* check for parsing */
    if (GOAL_TRUE == goal_httpChnState_get(pInst, pChan, GOAL_HTTP_CHNFLAG_PARSE)) {
        /* set parser input information */
        GOAL_MEMSET(&infoPrs, 0, sizeof(GOAL_HTTP_PARSE_T));
        infoPrs.in.pChan = pChan;
        infoPrs.in.strMes = pDataIn;
        infoPrs.in.lenMes = lenDataIn;
        infoPrs.in.pMethTable = &goal_httpMethodTable[0];
        infoPrs.in.lenMethTable = ARRAY_ELEMENTS(goal_httpMethodTable);
        infoPrs.in.pFileExtTable = &goal_httpFileExtTable[0];
        infoPrs.in.lenFileExtTable = ARRAY_ELEMENTS(goal_httpFileExtTable);

        /* parse message */
        ret = goal_httpParse(pInst, &infoPrs);
        if (GOAL_RES_ERR(ret)) {
            /* check parser return value */
            goal_httpCheckRet(pInst, pChan, ret, &applRet);
            if (GOAL_HTTP_STATUS_BAD_REQ_11 == applRet.retState) {
                /* error */
                goal_logErr("Http parser returned error");
            }
        }
        /* check for forwarding */
        if (GOAL_FALSE == goal_httpChnState_get(pInst, pChan, GOAL_HTTP_CHNFLAG_FORWARD)) {
            /* wind chunk buffer forward */
            goal_httpChnChkWind(pInst, pChan, &infoPrs);
        }
    }

    /* check for forwarding */
    if (GOAL_TRUE == goal_httpChnState_get(pInst, pChan, GOAL_HTTP_CHNFLAG_FORWARD)) {
        /* forward request to application and get/put user data */
        ret = goal_httpForwardReq(pInst, &infoPrs, &applRet);
        if (GOAL_RES_ERR(ret)) {
            goal_logErr("Http request forwarding to application failed");
            goal_httpChnState_set(pInst, pChan, GOAL_HTTP_CHNFLAG_CLOSCHN);
        }
        /* wind receive chunk buffer forward */
        goal_httpChnChkWind(pInst, pChan, &infoPrs);
    }

    /* check for sending response */
    if (GOAL_TRUE == goal_httpChnState_get(pInst, pChan, GOAL_HTTP_CHNFLAG_SENDRES)) {
        /* send response */
        ret = goal_httpSendRes(pInst, pChan, &applRet);
        if (GOAL_RES_ERR(ret)) {
            goal_logErr("Http response sending failed");
            goal_httpChnState_set(pInst, pChan, GOAL_HTTP_CHNFLAG_CLOSCHN);
        }
    }

    /* check for channel closing */
    if (GOAL_RES_ERR(ret)) {
        /* clear channel */
        goal_httpChnClear(pInst, pChan);
        /* close channel */
        goal_netClose(pChan);
    }

    return ret;
}


/****************************************************************************/
/** This function prepares and sends a reponse message.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpCheckRet(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_STATUS_T           retParser,          /**< return from parser */
    GOAL_HTTP_APPLRET_T    *pApplRet            /**< pointer to application return */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */

    /* set application return */
    pApplRet->lenData = 0;
    pApplRet->retContent = GOAL_HTTP_CONTENT_UNK;

    /* set return state for http response */
    switch (retParser) {
    case GOAL_ERR_ACCESS:
        pApplRet->retState = GOAL_HTTP_STATUS_UNAUTH_11;
        break;

    case GOAL_ERR_UNSUPPORTED:
        pApplRet->retState = GOAL_HTTP_STATUS_FORBID_11;
        break;

    case GOAL_ERR_NODATA:
        pApplRet->retState = GOAL_HTTP_STATUS_NOT_FOUND_11;
        break;

    case GOAL_ERR_DELAYED:
        pApplRet->retState = GOAL_HTTP_STATUS_CONTINUE_11;
        break;

    default:
        pApplRet->retState = GOAL_HTTP_STATUS_BAD_REQ_11;
        break;
    }

    /* allow sending */
    goal_httpChnState_set(pInst, pChan, GOAL_HTTP_CHNFLAG_SENDRES);

    return ret;
}


/****************************************************************************/
/** This function prepares and sends a response message.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpSendRes(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_HTTP_APPLRET_T     *pApplRet           /**< pointer to application return */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    GOAL_BUFFER_T *pBuf = NULL;                 /* pointer to response buffer */

    /* get buffer from net module */
    ret = goal_httpAllocResBuf(pInst, &pBuf);

    if (GOAL_RES_OK(ret)) {
        /* set response buffer for this channel */
        ret = goal_httpChnSetResBuf(pInst, pChan, pBuf);
    }

    if (GOAL_RES_OK(ret)) {
        /* add header info */
        ret = goal_httpAddHeader(pInst, pChan, pBuf, pApplRet);
    }

    /* add user data */
    if (GOAL_RES_OK(ret) && (0 != pApplRet->lenData) && (NULL != pApplRet->pData)) {
        if ((GOAL_HTTP_CONTENT_HTML == pApplRet->retContent) ||
            (GOAL_HTTP_CONTENT_JS == pApplRet->retContent)) {
            /* replace templates for html and java script */
            ret = goal_httpTmpMgrParse(pInst, pChan, pBuf, pApplRet->hdlRes, pApplRet->pData, pApplRet->lenData, 0);
        } else {
            /* set buffer without template parsing */
            ret = goal_httpAddToBuffer(pInst, pBuf, pChan, pApplRet->pData, pApplRet->lenData);
        }
    }

    /* release buffer if any error occurred */
    if (GOAL_RES_ERR(ret) && (NULL != pBuf)) {
        goal_queueReleaseBuf(&pBuf);
    }

    if (GOAL_RES_OK(ret)) {
        /* set ready to send flag */
        ret = goal_httpChnSetRdySend(pInst, pChan, GOAL_TRUE);
    }

    /* in case of sending 101 continue response, leave channel open */
    if (GOAL_HTTP_STATUS_CONTINUE_11 != pApplRet->retState) {
        /* close channel after sending */
        goal_httpChnState_set(pInst, pChan, GOAL_HTTP_CHNFLAG_CLOSCHN);
    }

    return ret;
}


/****************************************************************************/
/** This adds http header information to a net buffer.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpAddHeader(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to net channel */
    GOAL_BUFFER_T *pBuf,                        /**< pointer to buffer */
    GOAL_HTTP_APPLRET_T *pApplRet               /**< pointer to application info */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */

    /* add http status header */
    if (GOAL_RES_OK(ret)) {
        ret = goal_httpAddToBuffer(pInst, pBuf, pChan,
                                    (const uint8_t *) (goal_httpStatusTable[pApplRet->retState].strMes),
                                    goal_httpStatusTable[pApplRet->retState].lenMes);
    }

    /* add sub-header */
    if (GOAL_HTTP_STATUS_UNAUTH_11 == pApplRet->retState) {
        if (GOAL_RES_OK(ret)) {
            ret = goal_httpAddToBuffer(pInst, pBuf, pChan,
                                        (const uint8_t *) (goal_httpStatusTable[GOAL_HTTP_STATUS_AUTH_CHALLENGE].strMes),
                                        goal_httpStatusTable[GOAL_HTTP_STATUS_AUTH_CHALLENGE].lenMes);
        }
    }

    /* add http content type */
    if ((0 != pApplRet->lenData) && (NULL != pApplRet->pData)) {
        if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_CONTENT_UNK != pApplRet->retContent)) {
            /* get content type from request */
            ret = goal_httpAddToBuffer(pInst, pBuf, pChan,
                                        (const uint8_t *) (goal_httpContentTable[pApplRet->retContent].strMes),
                                        goal_httpContentTable[pApplRet->retContent].lenMes);
        }
    }

    /* add http connection close */
    if (GOAL_RES_OK(ret)) {
        ret = goal_httpAddToBuffer(pInst, pBuf, pChan,
                                   (const uint8_t *) (goal_httpStatusTable[GOAL_HTTP_STATUS_CONN_CLOSE].strMes),
                                    goal_httpStatusTable[GOAL_HTTP_STATUS_CONN_CLOSE].lenMes);
    }

    /*  add header end */
    if (GOAL_RES_OK(ret)) {
        ret = goal_httpAddToBuffer(pInst, pBuf, pChan,
                                    (const uint8_t *) GOAL_HTTP_HDREND_STR,
                                    (uint32_t) GOAL_STRLEN((const char *) GOAL_HTTP_HDREND_STR));
    }

    return ret;
}


/****************************************************************************/
/** This function gets a buffer from net module.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpAllocResBuf(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to buffer pointer */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint16_t retry = 0;                         /* number of retries */

    UNUSEDARG(pInst);

    for (retry = 0; retry < 5; retry++) {
        /* get buffer from net module */
        ret = goal_ethGetNetBuf(ppBuf);
        if (GOAL_RES_OK(ret)) {
            /* leave loop */
            break;
        }
    }

    if (GOAL_RES_ERR(ret)) {
        /* error */
        goal_logErr("No response buffer available");
    }

    return ret;
}


/****************************************************************************/
/** This function forwards a client request to the user application.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpForwardReq(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_HTTP_PARSE_T       *pPrsInfo,          /**< pointer to parser info */
    GOAL_HTTP_APPLRET_T     *pApplRet           /**< application return pointer */
)
{
    GOAL_STATUS_T   ret = GOAL_ERROR;           /* return value */
    GOAL_HTTP_REQ_T        request;             /* request info */
    GOAL_HTTP_RESTYP_T     resType;             /* response type */

    /* fill request data */
    request.method = pPrsInfo->out.method;
    request.fileExt = pPrsInfo->out.fileExt;
    request.hdlRes = pPrsInfo->out.hdlRes;

    /* forward request to application */
    ret = goal_httpFwAppl(pInst, pPrsInfo, &request, &(pApplRet->pData),
                          &(pApplRet->lenData), &(pApplRet->retState),
                          &(pApplRet->retContent));
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* set resource handle */
    pApplRet->hdlRes = pPrsInfo->out.hdlRes;

    /* get response type */
    ret = goal_httpChnGetResType(pInst, pPrsInfo->in.pChan, &resType, NULL);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* check response type */
    if (GOAL_HTTP_RES_IMMEDT == resType) {
        /* set channel flag */
        ret = goal_httpChnState_set(pInst, pPrsInfo->in.pChan, GOAL_HTTP_CHNFLAG_SENDRES);
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }
    }

    return ret;
}


/****************************************************************************/
/** This function forwards the client request to the application.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpFwAppl(
    GOAL_HTTP_T        *pInst,                  /**< instance pointer */
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    GOAL_HTTP_REQ_T    *pReq,                   /**< pointer to request */
    const uint8_t       **pBuf,                 /**< address of pointer to return buffer */
    uint32_t            *pLen,                  /**< return length */
    GOAL_HTTP_STATUS_T *pState,                 /**< return status */
    GOAL_HTTP_CONTENT_T *pContent               /**< return content type */
)
{
    GOAL_STATUS_T   ret = GOAL_ERROR;           /* return value */
    GOAL_HTTP_REQFRAG_T reqFrag;                /* request fragment information */
    GOAL_HTTP_REQCB_T   pfnApplCb;              /* application callback */
    GOAL_HTTP_APPLCB_DATA_T infoApplCb;         /* application callback info */

    static GOAL_BOOL_T writeAct = GOAL_FALSE;   /* active write flag */
    uint32_t id = 0;                            /* channel id */

    /* init application callback info struct */
    GOAL_MEMSET(&infoApplCb, 0, sizeof(GOAL_HTTP_APPLCB_DATA_T));

    if ((NULL == pBuf) || (NULL == pLen) || (NULL == pReq)) {
        /* NULL pointer error */
        return GOAL_ERR_NULL_POINTER;
    }

    /* set application callback pointer */
    pfnApplCb = (GOAL_HTTP_REQCB_T) (pPrs->out.pfnCb);

    /* get channel request info */
    ret = goal_httpChnGetReqInfo(pInst, pPrs->in.pChan, &reqFrag);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* check for multipart POST request */
    if (GOAL_TRUE == reqFrag.flag) {
        if ((0 == reqFrag.lenRemain) && (GOAL_FALSE == writeAct)) {
            /* multipart request with one data chunk handle as oneshot */
            ret = goal_httpFwApplOnePost(pInst, pPrs, pBuf, pLen,
                                             pState, pContent, &infoApplCb);

        } else if ((0 == reqFrag.lenRemain) && (GOAL_TRUE == writeAct)) {
            /* check URL string */
            if (NULL == pPrs->out.strUrl) {
                ret = goal_httpGetUrlStr(pPrs, &pPrs->out.strUrl, &pPrs->out.lenUrl, &pPrs->out.lenMatch);
                if (GOAL_RES_ERR(ret)) {
                    return ret;
                }
            }

            /* get channel state */
            ret = goal_httpChnGetResType(pInst, pPrs->in.pChan, NULL, pState);
            /* use application callback */
            if ((NULL != pfnApplCb) && (pPrs->out.lenData) &&
                (GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState))) {
                /* set application callback info struct for POST DATA */
                infoApplCb.pInst = pInst;
                infoApplCb.reqType = GOAL_HTTP_FW_POST_DATA;
                infoApplCb.hdlRes = pPrs->out.hdlRes;

                ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                if (GOAL_RES_OK(ret)) {
                    infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                }

                infoApplCb.pRet = pState;
                infoApplCb.cs.pData = pPrs->out.pData;
                infoApplCb.cs.lenData = pPrs->out.lenData;
                infoApplCb.cs.pUrl = pPrs->out.strUrl;
                infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                infoApplCb.sc.ppData = pBuf;
                infoApplCb.sc.pLenData = pLen;
                infoApplCb.sc.pContType = pContent;
                /* use callback */
                ret = (*pfnApplCb)(&infoApplCb);

                if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState))) {
                    /* set application callback info struct for POST END */
                    infoApplCb.pInst = pInst;
                    infoApplCb.reqType = GOAL_HTTP_FW_POST_END;
                    infoApplCb.hdlRes = pPrs->out.hdlRes;

                    ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                    if (GOAL_RES_OK(ret)) {
                        infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                    }

                    infoApplCb.pRet = pState;
                    infoApplCb.cs.pData = NULL;
                    infoApplCb.cs.lenData = 0;
                    infoApplCb.cs.pUrl = pPrs->out.strUrl;
                    infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                    infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                    infoApplCb.sc.ppData = pBuf;
                    infoApplCb.sc.pLenData = pLen;
                    infoApplCb.sc.pContType = pContent;
                    /* use callback */
                    ret = (*pfnApplCb)(&infoApplCb);
                }
            }
            /* last part of data received, set response type */
            ret = goal_httpChnSetResType(pInst, pPrs->in.pChan, GOAL_HTTP_RES_IMMEDT, *pState);
            if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_ERR(*pState))) {
                /* set return length and content */
                *pLen = 0;
                *pContent = GOAL_HTTP_CONTENT_UNK;
            }
            /* reset write flag */
            writeAct = GOAL_FALSE;
        } else {
            /* check URL string */
            if (NULL == pPrs->out.strUrl) {
                ret = goal_httpGetUrlStr(pPrs, &pPrs->out.strUrl, &pPrs->out.lenUrl, &pPrs->out.lenMatch);
                if (GOAL_RES_ERR(ret)) {
                    return ret;
                }
            }

            /* first data chunk */
            if (GOAL_FALSE == writeAct) {
                /* use application callback */
                if (NULL != pfnApplCb) {
                    /* set application callback info struct for POST START */
                    infoApplCb.pInst = pInst;
                    infoApplCb.reqType = GOAL_HTTP_FW_POST_START;
                    infoApplCb.hdlRes = pPrs->out.hdlRes;

                    ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                    if (GOAL_RES_OK(ret)) {
                        infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                    }

                    infoApplCb.pRet = pState;
                    infoApplCb.cs.pData = NULL;
                    infoApplCb.cs.lenData = 0;
                    infoApplCb.cs.pUrl = pPrs->out.strUrl;
                    infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                    infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                    infoApplCb.sc.ppData = pBuf;
                    infoApplCb.sc.pLenData = pLen;
                    infoApplCb.sc.pContType = pContent;
                    /* use callback */
                    ret = (*pfnApplCb)(&infoApplCb);

                    if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState)) && (pPrs->out.lenData)) {
                        /* set application callback info struct for POST DATA */
                        infoApplCb.pInst = pInst;
                        infoApplCb.reqType = GOAL_HTTP_FW_POST_DATA;
                        infoApplCb.hdlRes = pPrs->out.hdlRes;

                        ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                        if (GOAL_RES_OK(ret)) {
                            infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                        }

                        infoApplCb.pRet = pState;
                        infoApplCb.cs.pData = pPrs->out.pData;
                        infoApplCb.cs.lenData = pPrs->out.lenData;
                        infoApplCb.cs.pUrl = pPrs->out.strUrl;
                        infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                        infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                        infoApplCb.sc.ppData = pBuf;
                        infoApplCb.sc.pLenData = pLen;
                        infoApplCb.sc.pContType = pContent;
                        /* use callback */
                        ret = (*pfnApplCb)(&infoApplCb);
                    }
                }
                /* set response type */
                ret = goal_httpChnSetResType(pInst, pPrs->in.pChan, GOAL_HTTP_RES_LATER, *pState);
                if (GOAL_RES_ERR(ret)) {
                    return ret;
                }
                /* set flag */
                writeAct = GOAL_TRUE;
            } else {
                /* get channel state */
                ret = goal_httpChnGetResType(pInst, pPrs->in.pChan, NULL, pState);
                /* use application callback */
                if ((NULL != pfnApplCb) && (GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState))) {
                    /* set application callback info struct */
                    infoApplCb.pInst = pInst;
                    infoApplCb.reqType = GOAL_HTTP_FW_POST_DATA;
                    infoApplCb.hdlRes = pPrs->out.hdlRes;

                    ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                    if (GOAL_RES_OK(ret)) {
                        infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                    }

                    infoApplCb.pRet = pState;
                    infoApplCb.cs.pData = pPrs->out.pData;
                    infoApplCb.cs.lenData = pPrs->out.lenData;
                    infoApplCb.cs.pUrl = pPrs->out.strUrl;
                    infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                    infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                    infoApplCb.sc.ppData = pBuf;
                    infoApplCb.sc.pLenData = pLen;
                    infoApplCb.sc.pContType = pContent;
                    /* use callback */
                    ret = (*pfnApplCb)(&infoApplCb);
                }
            }
        }
    } else {
        switch (pReq->method)
        {
            case GOAL_HTTP_METHOD_GET:
                /* use application callback */
                if (NULL != pfnApplCb) {
                    /* set application callback info struct */
                    infoApplCb.pInst = pInst;
                    infoApplCb.reqType = GOAL_HTTP_FW_GET;
                    infoApplCb.hdlRes = pPrs->out.hdlRes;

                    ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
                    if (GOAL_RES_OK(ret)) {
                        infoApplCb.hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
                    }

                    infoApplCb.pRet = pState;
                    infoApplCb.cs.pUrl = pPrs->out.strUrl;
                    infoApplCb.cs.lenUrl = pPrs->out.lenUrl;
                    infoApplCb.cs.lenMatch = pPrs->out.lenMatch;
                    infoApplCb.cs.lenData = 0;
                    infoApplCb.sc.ppData = pBuf;
                    infoApplCb.sc.pLenData = pLen;
                    infoApplCb.sc.pContType = pContent;
                    /* use callback */
                    ret = (*pfnApplCb)(&infoApplCb);
                } else {
                  /* error */
                  ret = GOAL_ERR_NULL_POINTER;
                }

                break;

            case GOAL_HTTP_METHOD_POST:
                /* oneshot post */
                ret = goal_httpFwApplOnePost(pInst, pPrs, pBuf, pLen,
                                             pState, pContent, &infoApplCb);

                break;

            default:
                break;
        }
    }
    return ret;
}


/****************************************************************************/
/** Forwards a oneshot POST to the application
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpFwApplOnePost(
    GOAL_HTTP_T        *pInst,                  /**< instance pointer */
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    const uint8_t       **pBuf,                 /**< address of pointer to return buffer */
    uint32_t            *pLen,                  /**< return length */
    GOAL_HTTP_STATUS_T *pState,                 /**< return status */
    GOAL_HTTP_CONTENT_T *pContent,              /**< return content type */
    GOAL_HTTP_APPLCB_DATA_T *pCbInfo            /**< pointer to callback info */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    GOAL_HTTP_REQCB_T pfnApplCb = NULL;         /* application callback */
    uint32_t id = 0;                            /* channel id */

    /* set application callback pointer */
    pfnApplCb = (GOAL_HTTP_REQCB_T) (pPrs->out.pfnCb);

    /* use application callback */
    if (NULL == pfnApplCb) {
        ret = GOAL_ERR_NULL_POINTER;
    } else {
        /* check URL string */
        if (NULL == pPrs->out.strUrl) {
            ret = goal_httpGetUrlStr(pPrs, &pPrs->out.strUrl, &pPrs->out.lenUrl, &pPrs->out.lenMatch);
            if (GOAL_RES_ERR(ret)) {
                return ret;
            }
        }

        /* set application callback info struct for POST START */
        pCbInfo->pInst = pInst;
        pCbInfo->reqType = GOAL_HTTP_FW_POST_START;
        pCbInfo->hdlRes = pPrs->out.hdlRes;

        ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
        if (GOAL_RES_OK(ret)) {
            pCbInfo->hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
        }

        pCbInfo->pRet = pState;
        pCbInfo->cs.pUrl = pPrs->out.strUrl;
        pCbInfo->cs.lenUrl = pPrs->out.lenUrl;
        pCbInfo->cs.lenMatch = pPrs->out.lenMatch;
        pCbInfo->cs.pData = NULL;
        pCbInfo->cs.lenData = 0;
        pCbInfo->sc.ppData = pBuf;
        pCbInfo->sc.pLenData = pLen;
        pCbInfo->sc.pContType = pContent;
        /* use callback */
        ret = (*pfnApplCb)(pCbInfo);

        if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState))) {
            /* set application callback info struct for POST DATA */
            pCbInfo->pInst = pInst;
            pCbInfo->reqType = GOAL_HTTP_FW_POST_DATA;
            pCbInfo->hdlRes = pPrs->out.hdlRes;

            ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
            if (GOAL_RES_OK(ret)) {
                pCbInfo->hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
            }

            pCbInfo->pRet = pState;
            pCbInfo->cs.pUrl = pPrs->out.strUrl;
            pCbInfo->cs.lenUrl = pPrs->out.lenUrl;
            pCbInfo->cs.lenMatch = pPrs->out.lenMatch;
            pCbInfo->cs.pData = pPrs->out.pData;
            pCbInfo->cs.lenData = pPrs->out.lenData;
            pCbInfo->sc.ppData = pBuf;
            pCbInfo->sc.pLenData = pLen;
            pCbInfo->sc.pContType = pContent;
            /* use callback */
            ret = (*pfnApplCb)(pCbInfo);
        }

        if ((GOAL_RES_OK(ret)) && (GOAL_HTTP_STATUS_OK(*pState))) {
            /* set application callback info struct for POST END */
            pCbInfo->pInst = pInst;
            pCbInfo->reqType = GOAL_HTTP_FW_POST_END;
            pCbInfo->hdlRes = pPrs->out.hdlRes;

            ret = goal_httpChannelId(pInst->pListChan, pPrs->in.pChan, &id);
            if (GOAL_RES_OK(ret)) {
                pCbInfo->hdlTransm = (GOAL_HTTP_HDL_T) (PtrCast) id;
            }

            pCbInfo->pRet = pState;
            pCbInfo->cs.pUrl = pPrs->out.strUrl;
            pCbInfo->cs.lenUrl = pPrs->out.lenUrl;
            pCbInfo->cs.lenMatch = pPrs->out.lenMatch;
            pCbInfo->cs.pData = NULL;
            pCbInfo->cs.lenData = 0;
            pCbInfo->sc.ppData = pBuf;
            pCbInfo->sc.pLenData = pLen;
            pCbInfo->sc.pContType = pContent;
            /* use callback */
            ret = (*pfnApplCb)(pCbInfo);
        }
    }
    return ret;
}


/****************************************************************************/
/** Find URL String from parser info
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpGetUrlStr(
    GOAL_HTTP_PARSE_T  *pPrs,                   /**< parser info */
    char               **ppUrl,                 /**< URL string */
    uint32_t           *pLenUrl,                /**< URL length */
    uint32_t           *pLenMatch               /**< match length */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint32_t len = 0;                           /* length */
    uint32_t cnt;                               /* loop count */

    /* find end of request type string */
    for (cnt = 0; cnt < pPrs->in.lenMes; cnt++) {
        if (' ' == pPrs->in.strMes[cnt]) {
            ret = GOAL_OK;
            break;
        }
    }

    /* set URL string */
    if (GOAL_RES_OK(ret)) {
        *ppUrl = (char *) &pPrs->in.strMes[cnt + 1];
        ret = GOAL_ERROR;
        len = 1;
        for (cnt = cnt + 2; cnt < pPrs->in.lenMes; cnt++) {
            if (0 != pPrs->in.strMes[cnt]) {
                len++;
            } else {
                ret = GOAL_OK;
                break;
            }
        }
    }
    if (GOAL_RES_ERR(ret)) {
        *ppUrl = NULL;
        *pLenUrl = 0;
    } else if ((1 == len) && ('/' == (*ppUrl)[0])) {
        *ppUrl = GOAL_HTTP_STANDARD_INDEX_NAME;
        *pLenUrl = GOAL_HTTP_STANDARD_INDEX_NAME_LEN;
    } else {
        *pLenUrl = len;
    }

    /* set match length */
    *pLenMatch = *pLenUrl;

    return ret;
}


/****************************************************************************/
/** This function sends fragments of a prepared client response.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpSendFrag(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel info */
    GOAL_BUFFER_T   **ppBuf                     /**< pointer to buffer reference */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    uint8_t cnt;                                /* counter */

    UNUSEDARG(pInst);

    /* check pointer */
    if (NULL == ppBuf) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* check buffer */
    if (NULL == *ppBuf) {
        return GOAL_ERR_NULL_POINTER;
    }

    for (cnt = 0; cnt < pInst->cntChn; cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            break;
        }
    }

    ret = goal_netSend(pChan, *ppBuf);

    if (cnt < pInst->cntChn) {
        if (GOAL_RES_OK(ret)) {
            pInst->pChanHdl[cnt].cntSendTry = 0;
        }
        else {
            pInst->pChanHdl[cnt].cntSendTry++;
        }
    }

    /* report error */
    if (GOAL_RES_ERR(ret)) {
        if ((pInst->pChanHdl[cnt].cntSendTry < GOAL_HTTP_SEND_RETRY_MAX)
            && (!(GOAL_ERR_NET_SEND_CHAN_DISABLED == ret))) {
            /* retry in next loop iteration */
            ret = GOAL_OK_DELAYED;
        }
        else {
            goal_logErr("Buffer could not be sent");
            /* release buffer in case of error */
            goal_queueReleaseBuf(ppBuf);
            /* reset pending flag */
            goal_httpChnResetPend(pInst, pChan);
        }
    }

    return ret;
}


/****************************************************************************/
/** Get http channel request information
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpChnGetReqInfo(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_HTTP_REQFRAG_T    *pReqFrag            /**< pointer to fragmentation info */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint32_t cnt;                               /* loop counter */

    /* check pointer */
    if (NULL == pReqFrag) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* copy fragmentation info */
            GOAL_MEMCPY(pReqFrag, &(pInst->pChanHdl[cnt].reqFrag), sizeof (GOAL_HTTP_REQFRAG_T));
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Get http channel response information
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnGetResInfo(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< pointer to channel */
    GOAL_HTTP_RESFRAG_T     *pResFrag,          /**< pointer to fragmentation info */
    GOAL_HTTP_CTC_FRAG_T    *pCtcFrag           /**< pointer to CTC fragmentation info */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    if (NULL == pResFrag) {
        return GOAL_ERR_NULL_POINTER;
    }

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* copy fragmentation info */
            GOAL_MEMCPY(pResFrag, &(pInst->pChanHdl[cnt].resFrag), sizeof (GOAL_HTTP_RESFRAG_T));
            GOAL_MEMCPY(pCtcFrag, &(pInst->pChanHdl[cnt].ctcFrag), sizeof (GOAL_HTTP_CTC_FRAG_T));
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Clear http channel information
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnClear(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan                  /**< channel pointer */
)
{
    uint32_t cnt;                               /* loop counter */
    uint32_t offset;                            /* offset for reset */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    if ((NULL == pInst) || (NULL == pChan)) {
        /* error */
        return GOAL_ERR_NULL_POINTER;
    }

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* prevent memory leak */
               if (NULL != pInst->pChanHdl[cnt].pRes) {
                 /* release buffer before its pointer is cleared */
                 goal_queueReleaseBuf(&(pInst->pChanHdl[cnt].pRes));
            }
            /* reset channel information, excluding channel pointer */
            offset = sizeof(GOAL_NET_CHAN_T *);
            GOAL_MEMSET(((char *) &(pInst->pChanHdl[cnt]) + offset), 0, (sizeof(GOAL_HTTP_CHN_T) - offset));
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Resets specified channel flags
 *
 * @retval GOAL_TRUE if flag is set
 * @retval GOAL_FALSE if flag is not set
 */
GOAL_STATUS_T goal_httpChnState_reset(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    uint32_t        flag                        /**< channel flag */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            pInst->pChanHdl[cnt].chnState &= ~(flag);
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets specified channel flags
 *
 * @retval GOAL_TRUE if flag is set
 * @retval GOAL_FALSE if flag is not set
 */
GOAL_STATUS_T goal_httpChnState_set(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    uint32_t        flag                        /**< channel flag */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            pInst->pChanHdl[cnt].chnState |= flag;
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Returns state of channel flag
 *
 * @retval GOAL_TRUE if flag is set
 * @retval GOAL_FALSE if flag is not set
 */
GOAL_BOOL_T goal_httpChnState_get(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    uint32_t        flag                        /**< channel flag */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    GOAL_BOOL_T retFlag = GOAL_FALSE;           /* return flag */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return retFlag;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            if (flag & pInst->pChanHdl[cnt].chnState) {
                retFlag = GOAL_TRUE;
            } else {
                retFlag = GOAL_FALSE;
            }
            /* end loop */
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return retFlag;
}


/****************************************************************************/
/** Copyies data chunk to channel buffer
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnChkWind(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< pointer to channel */
    GOAL_HTTP_PARSE_T  *pInfoPrs                /**< pointer to parser info */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint32_t cnt = 0;                           /* loop counter */
    uint32_t dataOffset = 0;                    /* data string offset */
    uint32_t offset;                            /* offset */
    GOAL_HTTP_REQFRAG_T *pReqFrag;              /* request fragmentation info */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* get fragmentation info */
            pReqFrag = &pInst->pChanHdl[cnt].reqFrag;

            /* check if not all chunks are received */
            if ((GOAL_TRUE == pReqFrag->flag) && (GOAL_FALSE == pReqFrag->lastBound)) {
                /* find data string offset */
                for (dataOffset = 0; dataOffset < pInst->pChanHdl[cnt].lenData; dataOffset++) {
                    if (0 == pInst->pChanHdl[cnt].tmpBuf[dataOffset]) {
                        break;
                    }
                }
                if (dataOffset == pInst->pChanHdl[cnt].lenData) {
                    return ret;
                }
                dataOffset++;
            }

            /* get offset from parsed message */
            offset = pInfoPrs->out.lenParsed;
            if ((offset >= dataOffset) && (offset <= pInst->pChanHdl[cnt].lenData)) {
                /* calculate new length */
                pInst->pChanHdl[cnt].lenData -= (offset - dataOffset);
                /* copy chunk to beginning of buffer */
                GOAL_MEMCPY(&(pInst->pChanHdl[cnt].tmpBuf[dataOffset]), &(pInst->pChanHdl[cnt].tmpBuf[offset]), pInst->pChanHdl[cnt].lenData - dataOffset);
                /* clear unused buffer */
                offset = pInst->pChanHdl[cnt].lenData;
                GOAL_MEMSET(&(pInst->pChanHdl[cnt].tmpBuf[offset]), 0, (HTTP_CHN_TMPBUF_LEN - offset));
            }
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Copyies data chunk to channel buffer
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnCpyChnk(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< pointer to channel */
    GOAL_BUFFER_T   *pBuf,                      /**< pointer to buffer from net module */
    uint8_t         **pData,                    /**< return pointer for buffered data */
    uint32_t        *pLenData                   /**< return pointer for buffered data length */
)
{
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */
    uint32_t cnt;                               /* loop counter */
    uint32_t offset = 0;                        /* offset */
    uint8_t *pDest;                             /* pointer to destination */
    uint32_t start = 0;                         /* start character */
    uint32_t end = 0;                           /* end character */
    GOAL_BOOL_T flag = GOAL_TRUE;               /* loop bool */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* search channel */
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_TRUE == flag)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* get recent data offset */
            offset = pInst->pChanHdl[cnt].lenData;

            if ((HTTP_CHN_TMPBUF_LEN - offset) < pBuf->dataLen) {
                ret = GOAL_ERROR;
                flag = GOAL_FALSE;
            } else {
                /* set destination pointer */
                pDest = &(pInst->pChanHdl[cnt].tmpBuf[offset]);
                /* copy data chunk */
                GOAL_MEMCPY(pDest, pBuf->ptrData, pBuf->dataLen);
                /* update data length */
                pInst->pChanHdl[cnt].lenData += pBuf->dataLen;
                /* set returns */
                *pData = &(pInst->pChanHdl[cnt].tmpBuf[0]);
                *pLenData = pInst->pChanHdl[cnt].lenData;
                /* search header end */
                start = 0;
                end = pInst->pChanHdl[cnt].lenData;
                ret = http_searchString((char *) &(pInst->pChanHdl[cnt].tmpBuf[0]), GOAL_HTTP_HDREND_STR,
                                         &start, &end);
                if (GOAL_RES_OK(ret)) {
                    /* set parse flag */
                    pInst->pChanHdl[cnt].chnState |= GOAL_HTTP_CHNFLAG_PARSE;
                }
                /*set return value */
                ret = GOAL_OK;
                flag = GOAL_FALSE;
            }
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets http channel response type
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnGetResType(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< channel pointer */
    GOAL_HTTP_RESTYP_T  *pResType,              /**< pointer to response type, optional */
    GOAL_HTTP_STATUS_T  *pHttpStatus            /**< pointer to http channel status, optional */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find free slot */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set return for response type and http channel status */
            if (pResType) {
                *pResType = pInst->pChanHdl[cnt].resType;
            }
            if (pHttpStatus) {
                *pHttpStatus = pInst->pChanHdl[cnt].httpStatus;
            }
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Gets http channel response type
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnSetResType(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< channel pointer */
    GOAL_HTTP_RESTYP_T  resType,                /**< response type */
    GOAL_HTTP_STATUS_T  httpStatus              /**< http status of channel */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find free slot */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set response type and http channel status */
            pInst->pChanHdl[cnt].resType = resType;
            pInst->pChanHdl[cnt].httpStatus = httpStatus;
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets http channel response buffer pointer
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnSetResBuf(
    GOAL_HTTP_T     *pInst,                     /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    GOAL_BUFFER_T   *pBuf                       /**< buffer pointer */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find free slot */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if ((pChan == pInst->pChanHdl[cnt].pChan) && (NULL == pInst->pChanHdl[cnt].pRes)) {
            /* set buffer pointer */
            pInst->pChanHdl[cnt].pRes = pBuf;
            pInst->pChanHdl[cnt].pend = GOAL_TRUE;
            ret = GOAL_OK;
        }
    }

    /* unlock muetx */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets http channel request information
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpChnSetReqInfo(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< channel pointer */
    GOAL_HTTP_REQFRAG_T     *pReqFrag           /**< pointer to request information */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find free slot */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set request fragmentation info */
            GOAL_MEMCPY(&(pInst->pChanHdl[cnt].reqFrag), pReqFrag, sizeof(GOAL_HTTP_REQFRAG_T));
            ret = GOAL_OK;
        }
    }
    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets http channel response information
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpChnSetResInfo(
    GOAL_HTTP_T             *pInst,             /**< instance pointer */
    GOAL_NET_CHAN_T         *pChan,             /**< channel pointer */
    GOAL_BUFFER_T           *pBuf,              /**< buffer pointer */
    GOAL_HTTP_RESFRAG_T     *pResFrag           /**< pointer to response info */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find free slot */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* skip channels with other active response buffers */
            if ((NULL == pInst->pChanHdl[cnt].pRes) || (pBuf == pInst->pChanHdl[cnt].pRes)) {
                /* set buffer */
                pInst->pChanHdl[cnt].pRes = pBuf;
                /* set response fragmentation info */
                GOAL_MEMCPY(&(pInst->pChanHdl[cnt].resFrag), pResFrag, sizeof(GOAL_HTTP_RESFRAG_T));
                ret = GOAL_OK;
            }
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Sets http channel ready to send
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnSetRdySend(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< channel pointer */
    GOAL_BOOL_T flag                            /**< ready to send flag */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            pInst->pChanHdl[cnt].rdySend = flag;
            /* set return */
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Gets http channel ready to send
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnGetRdySend(
    GOAL_HTTP_T *pInst,                         /**< [in] instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< [in] channel pointer */
    GOAL_BOOL_T *pFlag                          /**< [out] ready to send pointer */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            *pFlag = pInst->pChanHdl[cnt].rdySend;
            /* set return */
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Resets buffer pending flag
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnResetPend(
    GOAL_HTTP_T *pInst,                         /**< instance pointer */
    GOAL_NET_CHAN_T *pChan                      /**< channel pointer */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            pInst->pChanHdl[cnt].pend = GOAL_FALSE;
            /* set return */
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Gets http channel send buffer pending flag
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpChnGetPend(
    GOAL_HTTP_T *pInst,                         /**< [in] instance pointer */
    GOAL_NET_CHAN_T *pChan,                     /**< [in] channel pointer */
    GOAL_BOOL_T *pFlag                          /**< [out] pend flag pointer */
)
{
    uint32_t cnt;                               /* loop counter */
    GOAL_STATUS_T ret = GOAL_ERROR;             /* return value */

    /* lock mutex */
    ret = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("error acquiring channel lock");
        return ret;
    }

    /* find channel */
    ret = GOAL_ERROR;
    for (cnt = 0; ((cnt < pInst->cntChn) && (GOAL_ERROR == ret)); cnt++) {
        if (pChan == pInst->pChanHdl[cnt].pChan) {
            /* set flag */
            *pFlag = pInst->pChanHdl[cnt].pend;
            /* set return */
            ret = GOAL_OK;
        }
    }

    /* unlock mutex */
    goal_lockPut(pInst->lockChn);

    return ret;
}


/****************************************************************************/
/** Registers the http module for GOAL.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpNewImpl(
    GOAL_HTTP_T **ppInst,                       /**< pointer to instance pointer */
    uint16_t port,                              /**< port to link instance to */
    uint16_t cntChn                             /**< channel count */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    GOAL_HTTP_CHN_T *pChanHdl = NULL;           /* pointer to channel handler */
    GOAL_NET_ADDR_T addr;                       /* net address */
    GOAL_NET_CHAN_T *pChan;                     /* channel */
    uint32_t optVal;                            /* option value */
    uint32_t cnt;                               /* loop counter */
    uint32_t cntInst;                           /* instance count */
    GOAL_HTTP_IDLIST_T *pEntry = NULL;          /* list entry */

    /* get recent instance count */
    ret = http_getInstCnt(&cntInst);

    /* check TCP port, only 1 instance per port allowed */
    if ((GOAL_RES_OK(ret)) && (0 < cntInst)) {
        for (cnt = 0; cnt < cntInst; cnt++) {
            /* get instance by Id */
            ret = goal_instGetById((GOAL_INSTANCE_T **) ppInst, GOAL_ID_HTTP, cnt);
            if ((GOAL_RES_OK(ret)) && ((*ppInst)->localPort == port)) {
                /* port is already in use */
                ret = GOAL_ERR_ALREADY_USED;
            }
        }
    }

    if (GOAL_RES_OK(ret)) {
        /* new http instance, use recent instance count as id */
        ret = goal_instNew((GOAL_INSTANCE_T **) ppInst, sizeof(GOAL_HTTP_T), GOAL_ID_HTTP, cntInst,
                            "HTTP Instance");
    }

    if (GOAL_RES_OK(ret)) {
        /* increase instance count */
        ret = http_incInstCnt();
    }

    /* store channel count and port number */
    if (GOAL_RES_OK(ret)) {
        /* set TCP port in instance */
        (*ppInst)->localPort = port;
        (*ppInst)->cntChn = cntChn;
        /* allocate memory for the channel handler */
        ret = goal_memCalloc(&pChanHdl, (cntChn * sizeof(GOAL_HTTP_CHN_T)));
    }

    /* set channel handler pointer */
    if (GOAL_RES_OK(ret)) {
        (*ppInst)->pChanHdl = pChanHdl;
        /* create lock for channel handler */
        ret = goal_lockCreate(GOAL_LOCK_BINARY, &((*ppInst)->lockChn), 0, 1, GOAL_ID_HTTP);
    }

    if (GOAL_RES_OK(ret)) {
        /* allocate memory for template path */
        ret = goal_memCalloc(&((*ppInst)->pTemplatePath), sizeof(GOAL_HTTP_TMPMGR_L_PATH_T));
    }

    if (GOAL_RES_OK(ret)) {
        /* init and set address struct */
        GOAL_MEMSET(&addr, 0, sizeof(GOAL_NET_ADDR_T));
        addr.localPort = port;

        /* init HTTP channels */
        for (cnt = 0; cnt < cntChn; cnt++) {
            /* register TCP server */
            ret = goal_netOpen(&pChan, &addr, GOAL_NET_TCP_LISTENER, httpNetCb);
            if (GOAL_RES_ERR(ret)) {
                goal_logErr("error while opening TCP server channel on port %"FMT_u32, (uint32_t) (addr.localPort));
                goal_targetHalt();
            }

            /* set TCP channel to non-blocking */
            optVal = 1;
            ret = goal_netSetOption(pChan, GOAL_NET_OPTION_NONBLOCK, &optVal);
            if (GOAL_RES_ERR(ret)) {
                goal_logErr("error while setting TCP channel to non-blocking");
                goal_targetHalt();
            }

            /* link channel to instance */
            (*ppInst)->pChanHdl[cnt].pChan = pChan;

            if (GOAL_RES_OK(ret)) {
                ret = goal_memCalloc(&pEntry, sizeof(GOAL_HTTP_IDLIST_T));
            }

            cntChannel++;

            if (GOAL_RES_OK(ret)) {
                pEntry->id = cntChannel;
                pEntry->pChannel = pChan;
                GOAL_LL_APPEND((*ppInst)->pListChan, pEntry);
            }
        }
    }

    return ret;
}


/****************************************************************************/
/** Sends buffer fragments in case there are some pending.
 *
 */
static void goal_httpMainLoop(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_HTTP_T *pInst = NULL;                  /* instance pointer */
    GOAL_BUFFER_T **ppBuf = NULL;               /* buffer pointer reference */
    GOAL_NET_CHAN_T *pChan = NULL;              /* channel pointer */
    GOAL_HTTP_RESFRAG_T resFrag;                /* response fragmentation */
    uint32_t cntInst = 0;                       /* instance count */
    uint32_t cntChan = 0;                       /* channel count */
    uint32_t cnt1 = 0;                          /* loop counter */
    uint32_t cnt2 = 0;                          /* loop counter */

    /* init resposne fragmentation struct */
    GOAL_MEMSET(&resFrag, 0, sizeof(resFrag));

    /* get instance count */
    res = http_getInstCnt(&cntInst);
    if ((GOAL_RES_OK(res)) && (0 != cntInst)) {
        for (cnt1 = 0; cnt1 < cntInst; cnt1++) {
            /* get instance */
            res = goal_instGetById((GOAL_INSTANCE_T **) &pInst, GOAL_ID_HTTP, cnt1);
            if (GOAL_RES_OK(res)) {
                /* get channel count */
                cntChan = pInst->cntChn;
                for (cnt2 = 0; cnt2 < cntChan; cnt2++) {
                    /* get lock */
                    res = goal_lockGet(pInst->lockChn, GOAL_LOCK_INFINITE);
                    if (GOAL_RES_OK(res)) {
                        /* get channel pointer */
                        pChan = pInst->pChanHdl[cnt2].pChan;
                        /* get buffer pointer */
                        ppBuf = &pInst->pChanHdl[cnt2].pRes;
                        /* release lock */
                        goal_lockPut(pInst->lockChn);
                        if (NULL != pChan) {
                            /* release buffer or send next fragment */
                            res = goal_httpBufRelease(pInst, pChan, ppBuf);
                            if (GOAL_RES_ERR(res)) {
                                goal_logErr("error during release of buffer or sending next fragment");
                                /* clear channel */
                                res = goal_httpChnClear(pInst, pChan);
                                if (GOAL_RES_ERR(res)) {
                                    goal_logErr("failed to clear channel");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}


/****************************************************************************/
/** Registers the http module for GOAL.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpInitImpl(
    void
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    static GOAL_BOOL_T initFlag = GOAL_FALSE;   /* init flag for this function */

    /* check init flag */
    if (GOAL_TRUE == initFlag) {
        /* error */
        goal_logErr("Already initialized");
        ret = GOAL_ERROR;
    } else {
        /* set init flag */
        initFlag = GOAL_TRUE;

        /* init HTTP CM module */
        ret = goal_httpRegCmVars();
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }

#if GOAL_CONFIG_HTTPS == 1
        /* init HTTPS CM module */
        ret = goal_httpsRegCmVars();
        if (GOAL_RES_ERR(ret)) {
            return ret;
        }
#endif /* GOAL_CONFIG_HTTPS == 1 */

        /* register the NET via RPC init function */
        if (GOAL_RES_OK(ret)) {
            ret = goal_mainStageReg(GOAL_STAGE_LOCK, &stageInit, GOAL_STAGE_INIT, goal_httpPastInit);
        }

    }

    return ret;
}


/****************************************************************************/
/** Registers resources required for the http module for GOAL.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_httpPastInit(
    void
)
{
    GOAL_STATUS_T ret;                          /* return value */

    /* init instance count */
    ret = goal_memCalloc(&pInstCnt, sizeof(GOAL_HTTP_INST_CNT_T));
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }
    ret = goal_lockCreate(GOAL_LOCK_BINARY, &(pInstCnt->lock), 0, 1, GOAL_ID_HTTP);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* register main loop function */
    ret = goal_mainLoopReg(goal_httpMainLoop);
    if (GOAL_RES_ERR(ret)) {
        goal_logErr("Registration of main loop function failed");
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Initializes a new instance of the https server.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpsNewImpl(
    GOAL_HTTP_T **ppInst,                       /**< HTTPS instance */
    uint16_t port,                              /**< port to link instance to */
    uint16_t cntChn                             /**< channel count */
)
{
#if GOAL_CONFIG_HTTPS == 1
    GOAL_MI_TLS_CERT_T miTlsCert;               /* certificate info struct */
    GOAL_MI_TLS_T *pMiTls = NULL;               /* MA TLS handle */
    GOAL_NET_CHAN_T *pChanNet = NULL;           /* Net Channel descriptor */
    GOAL_NET_CHAN_T *pChanTls = NULL;           /* TLS Channel descriptor */
    GOAL_HTTP_IDLIST_T *pEntry = NULL;          /* list entry */
    uint8_t cnt = 0;                            /* counter */
    GOAL_STATUS_T res;                          /* result */

    res = goal_httpNewImpl(ppInst, port, cntChn);

    /* get certificate information */
    if (GOAL_RES_OK(res)) {
        GOAL_MEMSET(&miTlsCert, 0, sizeof(GOAL_MI_TLS_CERT_T));
        res = goal_httpsGetCert(&miTlsCert);
    }

    if (GOAL_RES_OK(res)) {
        /* open TLS channel */
        res = goal_miTlsOpen(GOAL_MI_TLS_ID_DEFAULT, GOAL_MA_TLS_ID_DEFAULT, &miTlsCert);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("error while opening TLS channel");
            goal_targetHalt();
        }

        /* get MI TLS handle */
        res = goal_miTlsGetById(&pMiTls, GOAL_MI_TLS_ID_DEFAULT);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Could not get MI TLS handle from given ID");
        }

        GOAL_LL_FOREACH((*ppInst)->pListChan, pEntry) {
            pChanNet = pEntry->pChannel;

            /* open TLS channel */
            res = goal_miTlsSessOpen(pMiTls, &pChanTls, pChanNet);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("error while opening TLS channel");
                goal_targetHalt();
            }

            /* add HTTP to TLS channel */
            res = goal_httpChnAdd(pChanTls);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("error while adding channel to http channels");
                return res;
            }

            /* correct channel of HttpNew() */
            pEntry->pChannel = pChanTls;

            /* link channel to instance - overwrite net channel */
            (*ppInst)->pChanHdl[cnt].pChan = pChanTls;
            cnt++;
        }
    }

    return res;

#else
    UNUSEDARG(ppInst);
    UNUSEDARG(port);
    UNUSEDARG(cntChn);

    return GOAL_ERR_UNSUPPORTED;
#endif /* GOAL_CONFIG_HTTPS == 1 */
}


/****************************************************************************/
/** Add given channels to http module.
 *
 * This function may be called after GOAL intialization and must be called
 * after GOAL_STAGE_NET.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_httpChnAdd(
    GOAL_NET_CHAN_T *pChan                      /**< List of channel to open */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    /* check for invalid channel */
    if (NULL == pChan) {
        goal_logErr("invalid channel");
        return GOAL_ERR_NULL_POINTER;
    }

    /* add callback */
    res = goal_netOpenTunnel(NULL, pChan, httpNetCb, NULL, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not add callback to given channel");
        return res;
    }

    return res;
}


/****************************************************************************/
/** Adds the current message strMes to the buffer ppBuf. If message is too long,
 * the buffer will be send with part of the message and a new one is requested,
 * which is repeated until message is added completely or no buffer is free.
 *
 * If a buffer could not be sent, it is stored as pAnswBuf and *ppBuf is set
 * to NULL. If not the complete message could be sent, the rest is stored in
 * strMesMem and lenMesMem.
 *
 * @retval GOAL_OK successful
 * @retval GOAL_ERR_NET_SEND could not get new buffer, message is stored
 * @retval other failed
 */
GOAL_STATUS_T goal_httpAddToBuffer(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_BUFFER_T       *pBuf,                  /**< buffer pointer */
    GOAL_NET_CHAN_T     *pChan,                 /**< pointer to net channel */
    const uint8_t       *strMes,                /**< message for sending */
    uint32_t            len                     /**< length of message */
)
{
    GOAL_STATUS_T ret = GOAL_OK;                /* return value */
    uint32_t      bufSize = pBuf->bufSize;      /* send buffer size */
    uint32_t      offset;                       /* data copy offset */
    uint32_t      copylen;                      /* data copy length */
    GOAL_HTTP_RESFRAG_T resFrag;                /* response fragmentation info */

    /* if message fits in current buffer, add it */
    if ((pBuf->dataLen + len) <= bufSize) {
        /* calculate data offset and copy length */
        offset = pBuf->dataLen;
        copylen = len;
        /* set fragmentation info */
        resFrag.flag = GOAL_FALSE;
        resFrag.pData = NULL;
        resFrag.lenData = 0;
        resFrag.srcOff = 0;

    }
    /* if message does not fit, copy part */
    else {
        /* calculate data offset and copy length */
        offset = pBuf->dataLen;
        copylen = bufSize - offset;
        /* set fragmentation info */
        resFrag.flag = GOAL_TRUE;
        resFrag.pData = (const uint8_t *) strMes;
        resFrag.lenData = len;
        resFrag.srcOff = copylen;
    }

    /* set fragmentation info */
    ret = goal_httpChnSetResInfo(pInst, pChan, pBuf, &resFrag);
    if (GOAL_RES_ERR(ret)) {
        return ret;
    }

    /* copy data into send buffer */
    GOAL_MEMCPY((char *)(pBuf->ptrData + offset), strMes, copylen);
    /* update data length */
    pBuf->dataLen += copylen;

    return ret;
}


