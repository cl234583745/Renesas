
/** @file
 *
 *  Http webserver parsing module header
 *
 * This application runs a simple HTTP server that hosts a demo HTML page.
 * It can be accessed via web browser by browsing the IP address of this device.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
*/


#ifndef GOAL_HTTP_PARSER_H
#define GOAL_HTTP_PARSER_H


/****************************************************************************/
/* Defines */
/****************************************************************************/

/** MIME types for POST request */
typedef enum {
    GOAL_HTTP_POST_M_NO_SUPP = 0,               /**< not supported */
    GOAL_HTTP_POST_M_MULTIPART,                 /**< mulipart/form-data */
    GOAL_HTTP_POST_M_URLENC,                    /**< application/x-www-form-urlencoded */
    GOAL_HTTP_POST_M_JSON                       /**< application/json */
} GOAL_HTTP_POST_MIME_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/

GOAL_STATUS_T goal_httpParse(
    GOAL_HTTP_T         *pInst,                 /**< instance pointer */
    GOAL_HTTP_PARSE_T   *pInfoParse             /**< pointer to parser information struct */
);

#endif /* GOAL_HTTP_PARSER_H */
