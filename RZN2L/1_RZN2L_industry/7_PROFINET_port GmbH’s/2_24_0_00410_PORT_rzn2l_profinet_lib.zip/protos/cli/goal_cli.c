/** @file
 *
 * @brief GOAL Adaption Layer for ACyCLIC
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_cli.h"
#include <acyclic.h>
#if GOAL_CONFIG_CLI_DBG == 1
#include "goal_dbg_cli.h"
#endif
#if (GOAL_CONFIG_CLI_UDP == 1)
#include <goal_cli_udp.h>
#endif


/****************************************************************************/
/* Forward declarations */
/****************************************************************************/
struct GOAL_CLI_HELP_T;


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_CLI_PRINTF_BUF_SIZE    255
#ifndef GOAL_CLI_UDP_BUF_SIZE
#define GOAL_CLI_UDP_BUF_SIZE       GOAL_CLI_PRINTF_BUF_SIZE
#endif


/****************************************************************************/
/* Local structures */
/****************************************************************************/
/**< command help list item */
typedef struct GOAL_CLI_HELP_T {
    const char *strCmd;                         /**< command name */
    const char *strCmdHelp;                     /**< command help text */

    struct GOAL_CLI_HELP_T *pNext;              /**< next item pointer */
} GOAL_CLI_HELP_T;


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static GOAL_STAGE_HANDLER_T stageCli;           /**< CLI pre-stage */
static ACYCLIC_T *pHdlAcyclic;                  /**< ACyCLIC handle */
static GOAL_CLI_HELP_T *pHelp = NULL;           /**< command help list */
static GOAL_BOOL_T flgInit = GOAL_FALSE;        /**< init flag */
static GOAL_CLI_CMD_UNKNOWN_T pFuncUnknown = NULL; /**< command not found handler */
static unsigned int lenHelpCmd = 0;             /**< longest help entry length */


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_cliInitMod(
    void
);

static void goal_cliLoop(
    void
);

static void goal_cliCmdHelp(
    struct ACYCLIC_T *pAcyclic                  /**< ACyCLIC handle */
);


/****************************************************************************/
/** ACyCLIC CLI init stage handler
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_cliInitMod(
    void
)
{
    GOAL_STATUS_T resGoal;                      /* GOAL result */
    uint8_t resAcyclic;                         /* ACyCLIC result */

    /* initialize ACyCLIC */
    resAcyclic = acyclic_init(&pHdlAcyclic);
    if (resAcyclic) {
        goal_logErr("error initializing ACyCLIC");
        return GOAL_ERROR;
    }

    /* enable init flag */
    flgInit = GOAL_TRUE;

    /* register ACyCLIC command: "help" */
    resGoal = goal_cliCmdReg(GOAL_CLI_CMD_HELP, GOAL_CLI_CMD_HELP_TEXT, goal_cliCmdHelp, NULL, NULL);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("failed to register 'help' command");
        return resGoal;
    }

#if GOAL_CONFIG_CLI_DBG == 1
    resGoal = goal_dbgInitCli();
#endif /* GOAL_CONFIG_CLI_DBG */

#if GOAL_CONFIG_CLI_UDP == 1
    resGoal = goal_cliInitUdp();
#endif /* GOAL_CONFIG_CLI_UDP */

    /* register ACyCLIC main loop */
    return goal_mainLoopReg(goal_cliLoop);
}


/****************************************************************************/
/** ACyCLIC init wrapper
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_cliInit(
    GOAL_CLI_CMD_UNKNOWN_T pFunc                /**< unknown cmd handler */
)
{
    /* register unknown command handler */
    pFuncUnknown = pFunc;

    /* add callback to CLI pre-stage */
    return goal_mainStageReg(GOAL_STAGE_CLI_PRE, &stageCli, GOAL_STAGE_INIT, goal_cliInitMod);
}


/****************************************************************************/
/** ACyCLIC calloc wrapper
 *
 * @retval pointer successful allocation
 * @retval NULL allocation failed
 */
void *goal_cliCalloc(
    unsigned int size                           /**< calloc size */
)
{
    GOAL_STATUS_T res;                          /* result */
    char *mem = NULL;                           /* allocation pointer */

    res = goal_memCalloc(&mem, size);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to allocate CLI memory");
        return NULL;
    }

    return mem;
}


/****************************************************************************/
/** ACyCLIC printf wrapper
 */
void goal_cliPrintf(
    const char *strFormat,                      /**< printf-like format description */
    ...                                         /**< printf-like arguments */
)
{
    static char buf[GOAL_CLI_PRINTF_BUF_SIZE];  /* printf buffer */
    va_list arglist;                            /* argument list */

    GOAL_VA_START(arglist, strFormat);
    GOAL_VSNPRINTF(buf, GOAL_CLI_PRINTF_BUF_SIZE - 1, strFormat, arglist);
    GOAL_VA_END(arglist);
    buf[GOAL_CLI_PRINTF_BUF_SIZE - 1] = 0;
    PUTS_INF(buf);

    /* short stop to prevent buffer overflow */
    goal_timerSleep(GOAL_TIMER_MSEC);
}


/****************************************************************************/
/** ACyCLIC command register wrapper
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_cliCmdReg(
    const char *strCmd,                         /**< command name */
    const char *strCmdHelp,                     /**< command help text */
    GOAL_CLI_CMD_FUNC_T pFunc,                  /**< command function */
    GOAL_CLI_CMD_T *pHdlCmd,                    /**< parent command handle */
    GOAL_CLI_CMD_T **ppHdlCmdChild              /**< child command handle */
)
{
    GOAL_STATUS_T resGoal;                      /* GOAL result */
    int resAcyclic;                             /* ACyCLIC result */
    GOAL_CLI_CMD_T *pHdlCmdTmp = NULL;          /* command handle */
    GOAL_CLI_HELP_T **ppHelpIdx;                /* help list index */
    size_t lenHelpTmp;                          /* temporary help text length */

    /* check init flag */
    if (!flgInit) {
        goal_logErr("CLI not initialized");
        return GOAL_ERROR;
    }

    /* add command */
    resAcyclic = acyclic_cmd_add(pHdlAcyclic, (!pHdlCmd) ? &pHdlAcyclic->cmds : &pHdlCmd->sub, strCmd, pFunc, &pHdlCmdTmp);
    if (resAcyclic) {
        goal_logErr("failed to add CLI command");
        return GOAL_ERROR;
    }

    /* add command help text for root elements */
    if (!pHdlCmd) {

        /* find free help entry */
        for (ppHelpIdx = &pHelp; *ppHelpIdx; ppHelpIdx = &(*ppHelpIdx)->pNext);

        /* allocate help entry */
        resGoal = goal_memCalloc(ppHelpIdx, sizeof(GOAL_CLI_HELP_T));
        if (GOAL_RES_ERR(resGoal)) {
            goal_logErr("failed to allocate help entry");
            return resGoal;
        }

        /* assign help */
        (*ppHelpIdx)->strCmd = strCmd;
        (*ppHelpIdx)->strCmdHelp = strCmdHelp;

        /* check if entry is longer than existing entries */
        lenHelpTmp = GOAL_STRLEN(strCmd);
        if (lenHelpCmd < lenHelpTmp) {
            lenHelpCmd = (unsigned int) lenHelpTmp;
        }
    }

    /* return child handle if requested */
    if (ppHdlCmdChild) {
        *ppHdlCmdChild = pHdlCmdTmp;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** ACyCLIC command get wrapper
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_cliCmdGet(
    GOAL_CLI_CMD_T **ppHdlCmd,                  /**< command handle */
    const char *strCmd                          /**< command name */
)
{
    *ppHdlCmd = acyclic_cmd_get(pHdlAcyclic, strCmd);
    if (NULL == *ppHdlCmd) {
        return GOAL_ERR_NOT_FOUND;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** ACyCLIC processing loop
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static void goal_cliLoop(
    void
)
{
    acyclic_loop(pHdlAcyclic);
}


/****************************************************************************/
/** ACyCLIC command 'help'
 *
 * @retval 0 successful
 * @retval other failed
 */
static void goal_cliCmdHelp(
    struct ACYCLIC_T *pAcyclic                  /**< ACyCLIC handle */
)
{
    GOAL_CLI_HELP_T *pHelpIdx;                  /* help list index */
    unsigned int cnt;                           /* counter */

    UNUSEDARG(pAcyclic);

    /* iterate through help elements */
    for (pHelpIdx = pHelp; pHelpIdx; pHelpIdx = pHelpIdx->pNext) {
        goal_cliPrintf("%s", pHelpIdx->strCmd);
        for (cnt = (unsigned int) GOAL_STRLEN(pHelpIdx->strCmd); cnt < lenHelpCmd; cnt++) {
            goal_cliPrintf(" ");
        }
        goal_cliPrintf("    %s\n", pHelpIdx->strCmdHelp);
    }
}


/****************************************************************************/
/** ACyCLIC retrieve parameter count
 *
 * @retval count parameter count
 */
unsigned int goal_cliParamCount(
    GOAL_CLI_DATA_T *pAcyclic                   /**< ACyCLIC handle */
)
{
    return pAcyclic->arg_cnt;
}


/****************************************************************************/
/** ACyCLIC retrieve parameter
 *
 * @retval count parameter count
 */
GOAL_STATUS_T goal_cliParamGet(
    GOAL_CLI_DATA_T *pAcyclic,                  /**< ACyCLIC handle */
    unsigned int idx,                           /**< parameter index */
    const char **ppStr,                         /**< parameter string start */
    unsigned int *pStrLen                       /**< parameter string length */
)
{
    if (pAcyclic->arg_cnt <= idx) {
        goal_logDbg("invalid parameter index");
        return GOAL_ERROR;
    }

    *ppStr = pAcyclic->args[idx].name;
    *pStrLen = pAcyclic->args[idx].len;

    return GOAL_OK;
}


/****************************************************************************/
/** Parse a parameter at the given index as a port value
 *
 * @returns GOAL_OK successful
 * @returns GOAL_ERR_PARAM Port parameter not valid
 * @returns GOAL_ERR_OVERFLOW No parameter at the given index
 * @returns GOAL_ERR_SPECIFIC Port count could not be retrieved
 */
GOAL_STATUS_T goal_cliParamAsPortGet(
    GOAL_CLI_DATA_T *pData,                     /**< Parameter data */
    uint32_t idx,                               /**< Parameter index */
    uint32_t *pPort,                            /**< Pointer to port number */
    uint32_t *pPortCount                        /**< Pointer to number of ports */
)
{
    GOAL_STATUS_T res;                          /* Result */
    unsigned int portStrLen;                    /* Param length */
    const char *pPortStr = NULL;                /* Param string pointer */
    uint32_t port;                              /* Port */
    uint32_t portCount;                         /* Port count */
    char *pEndPtr;                              /* End pointer */

    res = goal_ethPortsGet(&portCount);
    if (GOAL_RES_ERR(res)) {
        goal_cliPrintf("Could not retrieve port count.\n");
        return GOAL_ERR_SPECIFIC;
    }

    /* Get port param and check whether a valid port */
    res = goal_cliParamGet(pData, idx, &pPortStr, &portStrLen);
    if (GOAL_RES_OK(res)) {
        errno = 0;
        port = (uint32_t) GOAL_STRTOUL(pPortStr, &pEndPtr, 10);
        if ((pEndPtr != (pPortStr + portStrLen)) || ERANGE == errno) {
            goal_cliPrintf("Invalid port format\n");
            return GOAL_ERR_PARAM;
        }

        if (portCount < port) {
            goal_cliPrintf("Invalid port number %u. Max. port number is %u.\n", port, portCount);
            return GOAL_ERR_PARAM;
        }

        *pPort = port;
        *pPortCount = portCount;
        return GOAL_OK;
    }

    return GOAL_ERR_OVERFLOW;
}


/****************************************************************************/
/** Parse a parameter at the given index as uint32_t value
 *
 * @returns GOAL_OK successful
 * @returns GOAL_ERR_PARAM Parameter not valid
 * @returns GOAL_ERR_OVERFLOW No parameter at the given index
 */
GOAL_STATUS_T goal_cliParamAsUint32Get(
    GOAL_CLI_DATA_T *pData,                     /**< Parameter data */
    uint32_t idx,                               /**< Parameter index */
    uint32_t *pVal                              /**< Pointer to parsed value */
)
{
    GOAL_STATUS_T res;                          /* Result */
    uint32_t val;                               /* Value */
    unsigned int strLen;                        /* Param length */
    const char *pStr = NULL;                    /* Param string pointer */
    char *pEndPtr;                              /* End pointer */

    /* Get param */
    res = goal_cliParamGet(pData, idx, &pStr, &strLen);
    if (GOAL_RES_ERR(res)) {
        goal_cliPrintf("Syntax error\n");
        return GOAL_ERR_OVERFLOW;
    }

    /* Parse and check param */
    errno = 0;
    val = (uint32_t) GOAL_STRTOUL(pStr, &pEndPtr, 0);
    if (pEndPtr != (pStr + strLen) || ERANGE == errno) {
        goal_cliPrintf("Invalid param format: \"%.*s\".\n", strLen, pStr);
        return GOAL_ERR_PARAM;
    }

    *pVal = val;
    return GOAL_OK;
}


/****************************************************************************/
/** Parse a parameter at the given index as IPv4 address or netmask
 *
 * @returns GOAL_OK successful
 * @returns GOAL_ERR_PARAM Parameter not valid
 * @returns GOAL_ERR_OVERFLOW No parameter at the given index
 */
GOAL_STATUS_T goal_cliParamAsIpGet(
    GOAL_CLI_DATA_T *pData,                     /**< Parameter data */
    uint32_t idx,                               /**< Parameter index */
    uint32_t *pVal,                             /**< Pointer to parsed IP */
    GOAL_BOOL_T isNetmask                       /**< If true, checks whether IP is valid netmask */
)
{
    GOAL_STATUS_T res;                          /* Result */
    uint32_t val;                               /* Value */
    unsigned int strLen;                        /* Param length */
    const char *pStr = NULL;                    /* Param string pointer */

    /* Get param */
    res = goal_cliParamGet(pData, idx, &pStr, &strLen);
    if (GOAL_RES_ERR(res)) {
        goal_cliPrintf("Syntax error\n");
        return GOAL_ERR_OVERFLOW;
    }

    /* ip address */
    res = goal_netAsciiToIp(pStr, strLen, &val);
    if (GOAL_RES_ERR(res)) {
        goal_cliPrintf("Invalid IP address: \"%.*s\".\n", strLen, pStr);
        return GOAL_ERR_PARAM;
    }

    /* If the IP is a netmask, check whether it is valid */
    if (isNetmask) {
        if (0 != (~val & (~val + 1))) {
            goal_cliPrintf("Invalid netmask: \"%.*s\".\n", strLen, pStr);
            return GOAL_ERR_PARAM;
        }
    }

    *pVal = val;
    return GOAL_OK;
}


/****************************************************************************/
/** Parse a parameter at the given index as an a mask consisting of 0s and 1s
 *
 * @returns GOAL_OK successful
 * @returns GOAL_ERR_PARAM Parameter not valid
 * @returns GOAL_ERR_OVERFLOW No parameter at the given index
 */
GOAL_STATUS_T goal_cliParamAsMaskGet(
    GOAL_CLI_DATA_T *pData,                     /**< Parameter data */
    uint32_t idx,                               /**< Parameter index */
    uint32_t *pVal,                             /**< Pointer to parsed value */
    uint32_t len                                /**< The required len */
)
{
    GOAL_STATUS_T res;                          /* Result */
    uint32_t val;                               /* Value */
    unsigned int strLen;                        /* Param length */
    const char *pStr = NULL;                    /* Param string pointer */
    const char *pPtr;                           /* Position pointer */
    uint32_t pos;                               /* Position index */

    /* Get param */
    res = goal_cliParamGet(pData, idx, &pStr, &strLen);
    if (GOAL_RES_ERR(res)) {
        goal_cliPrintf("Syntax error\n");
        return GOAL_ERR_OVERFLOW;
    }

    /* Check mask length */
    if (strLen > len) {
        goal_cliPrintf("Mask too long (%"FMT_u32" instead of %"FMT_u32"): %s\n", strLen, len, pStr);
        return GOAL_ERR_OVERFLOW;
    }

    /* Parse and check param */
    val = 0;
    pos = 0;
    pPtr = pStr;
    while (pos < strLen) {
        if (*pPtr != '0' && *pPtr != '1') {
            goal_cliPrintf("Syntax error in mask %s\n", pStr);
            return GOAL_ERR_PARAM;
        }
        if (*pPtr == '1') {
           val |= (1 << pos);
        }
        pos++;
        pPtr++;
    }

    /* Return value */
    *pVal = val;
    return GOAL_OK;
}


/****************************************************************************/
/** Prints an uint32_t value as a mask
 *
 */
void goal_cliPrintMaskParam(
    uint32_t val,                               /**< Value to print */
    uint32_t len                                /**< Bit count of mask */
)
{
    uint32_t idx;                               /* index */

    for (idx = 0; idx < len; idx++) {
        goal_cliPrintf("%c", (val & (1 << idx)) ? '1' : '0');
    }
}


/****************************************************************************/
/** ACyCLIC CLI command-not-found handler
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
uint8_t acyclic_cmd_not_found(
    GOAL_CLI_DATA_T *pAcyclic                   /**< ACyCLIC handle */
)
{
    GOAL_STATUS_T res = GOAL_ERR_NOT_FOUND;     /* result */

    if (pFuncUnknown) {
        res = pFuncUnknown(pAcyclic);
    }

    /* command not found */
    return (GOAL_RES_OK(res)) ? 0 : 1;
}
