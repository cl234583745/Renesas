/** @file
 *
 * @brief GOAL CLI over UDP
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#if (GOAL_CONFIG_CLI_UDP == 1)
#include <goal_cli_udp.h>

#if (GOAL_CONFIG_TCPIP_STACK != 1)
# error "CLI over UDP requires GOAL_CONFIG_TCPIP_STACK"
#endif


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#ifndef GOAL_CLI_UDP_BUF_SIZE
#  define GOAL_CLI_UDP_BUF_SIZE       100
#endif

#ifndef GOAL_CONFIG_CLI_UDP_PORT
#  define GOAL_CONFIG_CLI_UDP_PORT 1234
#endif


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static uint8_t strUdpCmd[GOAL_CLI_UDP_BUF_SIZE]; /**< CLI string via udp */
static uint32_t udpCmdLen;                      /**< length of CLI string via udp */
static GOAL_NET_CHAN_T *pUdpChan = NULL;        /**< channel of connection */
static uint32_t udpCmdCurChar;                  /**< current index of character in CLI string */


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static void goal_cliUdpCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T *pBuf                         /**< GOAL buffer */
);

static void goal_cliUdpReceive(
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_NET_ADDR_T *pAddr,                     /**< connection data */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
);


/****************************************************************************/
/** CLI over UDP initialization
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_cliInitUdp(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_ADDR_T addr;                       /* address */
    GOAL_NET_CHAN_T *pChan;                     /* UDP channel */
    uint32_t optVal;                            /* option value */

    /* register UDP server */
    GOAL_MEMSET(&addr, 0, sizeof(GOAL_NET_ADDR_T));
    addr.localPort = GOAL_CONFIG_CLI_UDP_PORT;
    res = goal_netOpen(&pChan, &addr, GOAL_NET_UDP_SERVER, goal_cliUdpCallback);
    if (GOAL_OK != res) {
        goal_logErr("error while opening UDP server channel on port %"FMT_u32, (uint32_t) GOAL_CONFIG_CLI_UDP_PORT);
        goal_targetHalt();
    }

    /* set UDP channel to non-blocking */
    optVal = 1;
    res = goal_netSetOption(pChan, GOAL_NET_OPTION_NONBLOCK, &optVal);
    if (GOAL_OK != res) {
        goal_logErr("error while setting UDP channel to non-blocking");
        goal_targetHalt();
    }

    /* enable broadcast reception */
    optVal = 1;
    res = goal_netSetOption(pChan, GOAL_NET_OPTION_BROADCAST, &optVal);
    if (GOAL_OK != res) {
        goal_logErr("error while setting UDP channel to receive broadcasts");
        goal_targetHalt();
    }

    /* activate channel */
    res = goal_netActivate(pChan);
    if (GOAL_OK != res) {
        goal_logErr("error while enabling UDP channel");
        goal_targetHalt();
    }

    /* greet */
    goal_logInfo("waiting for CLI UDP connections on port %u", GOAL_CONFIG_CLI_UDP_PORT);

    return res;
}


/****************************************************************************/
/** UDP CLI Server Callback
 *
 */
static void goal_cliUdpCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T *pBuf                         /**< GOAL buffer */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_ADDR_T remote;                     /* remote addresse */

    if (cbType == GOAL_NET_CB_NEW_DATA) {

        /* get IP Address of remote node */
        res = goal_netGetRemoteAddr(pChan, &remote);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to get Remote Address for socket %p", (void *) pChan);
        }
        else {
            goal_cliUdpReceive(pChan, &remote, pBuf);
        }
    }
}


/****************************************************************************/
/** ACyCLIC CLI registration of remote pc via UDP
 *
 */
static void goal_cliUdpReceive(
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_NET_ADDR_T *pAddr,                     /**< connection data */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
)
{
    UNUSEDARG(pAddr);

    GOAL_STRNCPY ((char *) strUdpCmd, (char *) pBuf->ptrData, pBuf->dataLen);
    udpCmdLen = pBuf->dataLen;
    udpCmdCurChar = udpCmdLen;
    pUdpChan = pChan;
}


/****************************************************************************/
/** ACyCLIC retrieve channel descriptor of UDP connection
 *
 * @retval channel descriptor
 */
GOAL_NET_CHAN_T *goal_cliUdpChanGet(
    void
)
{
    return pUdpChan;
}


/****************************************************************************/
/** ACyCLIC retrieve pointer to address of UDP client
 *
 * @retval pointer to adress
 */
GOAL_NET_ADDR_T *goal_cliUdpAddrGet(
    void
)
{
    return &pUdpChan->addr;
}


/****************************************************************************/
/** returns character of udp command
 *
 * @retval character
 */
GOAL_STATUS_T goal_cliUdpCmdCharGet(
    char *pKey                                  /**< key */
)
{
    if (udpCmdLen >= udpCmdCurChar && udpCmdCurChar > 0) {
        *pKey = (char) strUdpCmd[udpCmdLen - (udpCmdCurChar --)];
        return GOAL_OK;
    }

    *pKey = 0;
    return GOAL_ERR_NODATA;
}


/****************************************************************************/
/** Sends a char to the command line and via udp
 *
 *  @retval GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_cliUdpCharPut(
    char c                                      /**< character */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_BUFFER_T *pBuf = NULL;                 /* GOAL buffer */

    /* send character to remote */
    if (NULL != pUdpChan) {

        /* get buffer */
        res = goal_ethGetNetBuf(&pBuf);
        if (GOAL_RES_ERR(res)) {
            /* try again if getting was to fast */
            goal_timerSleep(GOAL_TIMER_MSEC);
            pBuf = NULL;
            res = goal_ethGetNetBuf(&pBuf);
        }
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Could not get buffer");
            return res;
        }

        /* fill buffer */
        *pBuf->ptrData = (uint8_t) c;
        pBuf->dataLen = 1;

        /* send buffer */
        res = goal_netSend(goal_cliUdpChanGet(), pBuf);
        if (GOAL_RES_ERR(res)) {
            /* try again if sending was too fast */
            goal_timerSleep(GOAL_TIMER_MSEC);
            res = goal_netSend(goal_cliUdpChanGet(), pBuf);
        }
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Could not send buffer");
        }

        /* release buffer */
        res = goal_queueReleaseBuf(&pBuf);                                                                         \
    }

    return res;
}

#endif /* GOAL_CONFIG_CLI_UDP */
