/** @file
 *
 * @brief GOAL CLI over UDP
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_config.h>

#if (GOAL_CONFIG_CLI_UDP == 1)
GOAL_STATUS_T goal_cliInitUdp(
    void
);

GOAL_NET_CHAN_T *goal_cliUdpChanGet(
    void
);

GOAL_NET_ADDR_T *goal_cliUdpAddrGet(
    void
);

GOAL_STATUS_T goal_cliUdpCharPut(
    char c                                      /**< character */
);

GOAL_STATUS_T goal_cliUdpCmdCharGet(
    char *pKey                                  /**< key */
);
#endif /* GOAL_CONFIG_CLI_UDP */
