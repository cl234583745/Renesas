/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#ifdef SNMP_CONF_STATICVARS


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static SNMP_VARLIST_T varlist_pool[SNMP_CONF_STATIC_VARLISTPOOL];
static SNMP_VARENTRY_T varentry_pool[SNMP_CONF_STATIC_VARENTRYPOOL];
static SNMP_VAR_T var_pool[SNMP_CONF_STATIC_VARPOOL];
static SNMP_OID_T oid_pool[SNMP_CONF_STATIC_OIDPOOL];


/****************************************************************************/
/** Allocates an OID structure from static pool.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_alloc_snmp_oid(
    SNMP_OID_T **oid                            /**< OID */
)
{
    uint16_t i;
    for (i = 0; i < SNMP_CONF_STATIC_OIDPOOL; i++) {
        if (oid_pool[i].inuse==0){
            *oid = &oid_pool[i];
            oid_pool[i].inuse=1;
            oid_pool[i].len = 0;
            return SNMP_RET_NOERR;
        }
    }
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** Frees an OID and returns it to the var pool.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_free_snmp_oid(
    SNMP_OID_T *oid                             /**< OID */
)
{
    oid->inuse = 0;
    oid->len = 0;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Allocates a var list using the static var pool.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_alloc_snmp_varlist(
    SNMP_VARLIST_T **list                       /**< Var list */
)
{
    uint16_t i;
    for (i = 0; i < SNMP_CONF_STATIC_VARLISTPOOL; i++) {
        if (varlist_pool[i].inuse == 0) {
            varlist_pool[i].inuse = 1;
            varlist_pool[i].head = NULL;
            varlist_pool[i].tail = NULL;
            *list = &varlist_pool[i];
            return SNMP_RET_NOERR;
        }
    }
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** Allocates a varentry in the given list from the static var pool.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_alloc_snmp_varentry(
    SNMP_VARLIST_T *list,                       /**< Var list */
    ASN1_TYPE type,                             /**< ASN.1 type */
    uint32_t *oid,                              /**< OID */
    uint8_t oid_len,                            /**< OID length */
    SNMP_VARENTRY_T **entry                     /**< Var entry */
)
{
    SNMP_RET_T rv;
    uint16_t i;
    uint16_t j;
    for (i = 0; i < SNMP_CONF_STATIC_VARENTRYPOOL; i++) {
        if (varentry_pool[i].inuse == 0) {
            for (j = 0; j < SNMP_CONF_STATIC_VARPOOL; j++) {
                if (var_pool[j].inuse == 0) {
                    var_pool[j].inuse = 1;
                    varentry_pool[i].inuse = 1;
                    *entry = &varentry_pool[i];
                    varentry_pool[i].var = &var_pool[j];
                    varentry_pool[i].var->type = type;
                    varentry_pool[i].var->sign = 0;
                    varentry_pool[i].var->size = 0;
                    varentry_pool[i].var->enc_size = 0;
                    varentry_pool[i].var->error_code = SNMP_VAR_NOERR;
                    SNMP_MEMSET(&(varentry_pool[i].var->data[0]),0,4*128);

                    rv = static_alloc_snmp_oid(&(var_pool[j].oid));
                    if (rv==SNMP_RET_NOERR){
                        if (oid!=NULL){
                        SNMP_MEMCPY(&(var_pool[j].oid->sub_oid),oid,sizeof(uint32_t)*oid_len);
                        var_pool[j].oid->len = oid_len;
                        }
                        /* Insert entry into list */
                        if (list->head == NULL) {
                            list->head = &varentry_pool[i];
                            list->tail = &varentry_pool[i];
                        } else {
                            list->tail->next = &varentry_pool[i];
                            varentry_pool[i].prev = list->tail;
                            list->tail = &varentry_pool[i];
                        }
                        return SNMP_RET_NOERR;
                    }
                }
            }

        }
    }
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** Frees an entry and returns it to the static var pool.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_free_snmp_varentry(
    SNMP_VARENTRY_T *entry                      /**< Var entry */
)
{
    entry->inuse = 0;
    entry->var->inuse = 0;
    static_free_snmp_oid(entry->var->oid);
    entry->var->enc_size = 0;
    entry->var->sign = 0;
    entry->var->size = 0;
    entry->var = NULL;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Frees a static varlist incl. all var entries.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T static_free_snmp_varlist(
    SNMP_VARLIST_T *list                        /**< Var list */
)
{
    SNMP_VARENTRY_T *current;
    SNMP_VARENTRY_T *entry = list->head;
    while (entry != NULL) {
        current = entry;
        static_free_snmp_varentry(current);
        entry = entry->next;
        current->next = NULL;
        current->prev = NULL;
    }
    list->inuse = 0;
    list->head = NULL;
    list->tail = NULL;
    return SNMP_RET_NOERR;
}

#endif /* SNMP_CONF_STATICVARS */
