/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef ASN1_H_
#define ASN1_H_


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_ASN1_TYPE_LONGFORM       0x80
#define SNMP_ASN1_TYPE_LONGFORM_MASK  0x7F


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_asn1_encode(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t value_size,                        /**< Value data size */
    ASN1_TYPE type,                             /**< Value's ASN.1 type */
    uint8_t *buffer,                            /**< Buffer */
    uint8_t sign,                               /**< Sign of integer value */
    void **end_ptr                              /**< End pointer */
);

SNMP_RET_T snmp_asn1_decode(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t len,                               /**< Value data size */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    uint8_t *sign,                              /**< Sign of integer values */
    ASN1_TYPE *type,                            /**< ASN.1 type */
    void **end_ptr                              /**< End pointer */
);

SNMP_RET_T snmp_asn1_decode_oid_to_array(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint32_t *oid,                              /**< OID */
    uint16_t *oid_len,                          /**< OID length */
    void **end_ptr                              /**< End pointer */
);

SNMP_RET_T snmp_asn1_get_encoding_size(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t value_size,                        /**< Value data size */
    uint32_t *enc_size,                         /**< Encoding size */
    uint8_t sign,                               /**< Sign of integer values */
    ASN1_TYPE type                              /**< Value's ASN.1 type */
);

uint8_t snmp_asn1_get_uint32_octet_count(
    uint32_t val                                /**< Value */
);

uint8_t snmp_asn1_get_int32_octet_count(
    int32_t val                                 /**< Value */
);

uint8_t snmp_asn1_get_len_octet_count(
    uint32_t val                                /**< Value */
);

SNMP_RET_T snmp_asn1_encode_uint32(
    uint32_t conv_value,                        /**< Value to convert */
    uint8_t *buffer,                            /**< Target buffer */
    void **end_ptr,                             /**< Pointer to first byte after encoding */
    uint8_t type_override,                      /**< Type override */
    uint8_t header                              /**< Header */
);

SNMP_RET_T snmp_asn1_encode_len(
    uint32_t conv_value,                        /**< Value to convert */
    uint8_t *buffer,                            /**< Target buffer */
    void **end_ptr,                             /**< Pointer to first byte after encoding */
    uint8_t type_override,                      /**< Type override */
    uint8_t header                              /**< Header */
);

uint32_t snmp_asn1_decode_7bit_uint(
    uint8_t *buffer,                            /**< Buffer */
    uint32_t len,                               /**< Buffer length */
    void **end_ptr                              /**< End pointer */
);

uint8_t asn1_encode_7bit_uint(
    uint32_t val,                               /**< Value to encode */
    uint8_t *buffer                             /**< Buffer */
);

SNMP_RET_T snmp_asn1_decode_berInt(
    uint8_t *pBuf,                              /**< buffer pointer */
    uint32_t *pVal,                             /**< Pointer to decoded value */
    uint8_t **pEndPtr                           /**< End pointer */
);

SNMP_RET_T snmp_asn1_decodeLength(
    uint8_t *ptr,                               /**< Pointer to buffer */
    uint32_t size,                              /**< Remaining size */
    void **end_ptr,                             /**< Pointer to next byte after processing */
    uint32_t *var                               /**< Pointer where value will be stored */
);

#endif /* ASN1_H_ */
