/** @file
 *
 * @brief
 * SNMP stack implementation
 *
 * @details
 * simple network protocol stack implementation.
 *
 * @copyright
 * Copyright 2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
#include <snmp_rfc1213_mib.h>
#endif
#if (0 == GOAL_SNMP_MIB_PORT_DISABLE)
#include <snmp_portgmbh_mib.h>
#endif


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_SNMP_LOCALHOST             "127.0.0.1"


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static char *strReadCommunityDef = "public";    /**< default read community */
static char *strWriteCommunityDef = "private";  /**< default write community */
static GOAL_INSTANCE_SNMP_T snmp;               /**< default SNMP instance */


/****************************************************************************/
/** SNMP target register config manager variables
 *
 * This function registers config manager variables
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_snmpInitImpl(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
    res = goal_snmpMibRfc1213InitPre();
#endif

    return res;
}


/****************************************************************************/
/** Set up SNMP instance.
 *
 * Initializes the SNMP stack and loads the required MIBs.
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpNewImpl(
    GOAL_INSTANCE_SNMP_T **ppSnmp,              /**< SNMP instance reference */
    uint32_t id                                 /**< SNMP instance id */
)
{
    SNMP_RET_T resSnmp = SNMP_RET_NOERR;        /* SNMP result */
    GOAL_STATUS_T resGoal = GOAL_OK;            /* GOAL result */

    UNUSEDARG(id);

    /* return default instance */
    *ppSnmp = &snmp;

    /* add MIBs to register stage */

#if (0 == GOAL_SNMP_MIB_RFC1213_DISABLE)
    resGoal = goal_snmpMibInitReg(goal_snmpMibRfc1213Init);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not add RFC1213 Table init to registering stage.");
        return resGoal;
    }
#endif

#if (0 == GOAL_SNMP_MIB_PORT_DISABLE)
    resGoal = goal_snmpMibInitReg(goal_snmpMibPortInit);
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not add port gmbh Table init to registering stage.");
        return resGoal;
    }
#endif

    /* initialize the SNMP stack */
    resSnmp = snmp_init();
    if (resSnmp != SNMP_RET_NOERR) {
        goal_logErr("Could not initialize SNMP module.");
        return GOAL_ERR_INIT;
    }

    /* set default community strings */
    resSnmp = snmp_communitySet(strReadCommunityDef, strWriteCommunityDef);
    if (resSnmp != SNMP_RET_NOERR) {
        goal_logErr("Could not set default community strings.");
        return GOAL_ERR_INIT;
    }

    /* Initialize SNMP UDP server */
    resGoal = snmp_portInit();
    if (GOAL_RES_ERR(resGoal)) {
        goal_logErr("Could not open UDP connection for SNMP module.");
        return resGoal;
    }

    /* Inform user */
    goal_logInfo("SNMP daemon is up and running.");

    return GOAL_OK;
}



/****************************************************************************/
/** Register SNMP community strings
 *
 * Store the given cumminity strings.
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpCommSet(
    GOAL_INSTANCE_SNMP_T *pSnmp,                /**< SNMP instance handle */
    char *strReadCommunity,                     /**< read community string */
    char *strWriteCommunity                     /**< write community string */
)
{
    SNMP_RET_T resSnmp = SNMP_RET_NOERR;        /* SNMP result */

    UNUSEDARG(pSnmp);

    resSnmp = snmp_communitySet(strReadCommunity, strWriteCommunity);

    return (SNMP_RET_NOERR == resSnmp) ? GOAL_OK : GOAL_ERROR;
}


/****************************************************************************/
/** SNMP SET sys variables request
 *
 * Starts a SNMP SET request for sysContact, sysName and sysLocation.
 * Default values are used.
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpResetToDefault(
    GOAL_INSTANCE_SNMP_T *pSnmp                 /**< SNMP instance handle */
)
{
    GOAL_STATUS_T resGoal = GOAL_OK;            /* GOAL result */

    UNUSEDARG(pSnmp);

    goal_snmpReset(NULL);

    return resGoal;
}


/****************************************************************************/
/** Initializes SNMP traps
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpTrapsInit(
    GOAL_INSTANCE_SNMP_T *pSnmp,                /**< SNMP instance handle */
    uint32_t trapSink                           /**< trap sink IP address */
)
{
    SNMP_RET_T resSnmp;                         /* SNMP result */

    UNUSEDARG(pSnmp);

    resSnmp = snmp_trapsInit(trapSink);

    return (SNMP_RET_NOERR == resSnmp) ? GOAL_OK : GOAL_ERROR;
}


/****************************************************************************/
/** Get instance handle for given id
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpGetById(
    GOAL_INSTANCE_SNMP_T **ppSnmp,              /**< [out] SNMP instance reference */
    uint32_t id                                 /**< SNMP instance id */
)
{
    UNUSEDARG(id);
    *ppSnmp = NULL;

    return GOAL_OK;
}
