/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/** Print type string for ASN.1 type
 *
 */
void snmp_debug_print_entry_type(
    ASN1_TYPE asn                               /**< ASN.1 type */
)
{
    switch (asn) {
    case ASN1_INTEGER:
        SNMP_LOG("Integer32");
        break;
    case ASN1_IPADDR:
        SNMP_LOG("IPv4 Address");
        break;
    case ASN1_OCTET_STRING:
        SNMP_LOG("OctetString");
        break;
    case ASN1_OID:
        SNMP_LOG("OID");
        break;
    case ASN1_TIMETICKS:
        SNMP_LOG("Timeticks");
        break;
    case ASN1_BITSTRING:
        SNMP_LOG("Bitstring");
        break;
    case ASN1_COUNTER:
        SNMP_LOG("Counter");
        break;
    case ASN1_COUNTER64:
        SNMP_LOG("Counter64");
        break;
    case ASN1_GAUGE:
        SNMP_LOG("Gauge");
        break;
    case ASN1_NSAPADDRESS:
        SNMP_LOG("NsapAddress");
        break;
    case ASN1_NULL:
        SNMP_LOG("Null");
        break;
    case ASN1_OPAQUE:
        SNMP_LOG("Opaque");
        break;
    case ASN1_SEQUENCE:
        SNMP_LOG("Sequence");
        break;
    case ASN1_UINTEGER32:
        SNMP_LOG("Uinteger32");
        break;
    }
}


/****************************************************************************/
/** Prints a variable list with entry details.
 *
 */
void snmp_debug_print_entry_list(
    SNMP_VARLIST_T *pList                       /**< Var list */
)
{
    uint32_t cntEntry;                          /* entry counter */
    uint32_t cntSubOid;                         /* sub OID counter */
    uint32_t cntData;                           /* data counter */
    SNMP_VARENTRY_T *pEntry;                    /* variable entry */;

    for (cntEntry = 0, pEntry = pList->head; pEntry != NULL; cntEntry++, pEntry = pEntry->next) {
        SNMP_LOG("\n======================= Entry %02u =======================\n", cntEntry);

        SNMP_LOG("OID: %u", pEntry->var->oid->sub_oid[0]);
        for (cntSubOid = 1; cntSubOid < pEntry->var->oid->len; cntSubOid++) {
            SNMP_LOG(".%u", pEntry->var->oid->sub_oid[cntSubOid]);
        }
        SNMP_LOG("\n");

        SNMP_LOG("Type: ");
        snmp_debug_print_entry_type(pEntry->var->type);
        SNMP_LOG("\n");
        SNMP_LOG("Size: %i\n", pEntry->var->size);
        SNMP_LOG("Signed: %s\n", (pEntry->var->sign > 0) ? "true" : "false");

        SNMP_LOG("Data: ");
        for (cntData = 0; cntData < pEntry->var->size; cntData++) {
            SNMP_LOG("0x%02X ", pEntry->var->data[cntData]);
        }
        SNMP_LOG("\n");

        SNMP_LOG("========================================================\n");
    }
}


/****************************************************************************/
/** Prints a MIB tree.
 *
 */
void snmp_debug_print_tree(
    SNMP_MIB_NODE_T *pNode,                     /**< Start node */
    int indent                                  /**< Indent */
)
{
    SNMP_MIB_NODE_T *pCurrent;                  /* current node */
    SNMP_MIB_NODE_T *pChild;                    /* child of current node */

    if (NULL == pNode) {
        return;
    }

    /* draw indent line */
    for (; indent; indent--) {
        SNMP_LOG("--");
    }

    /* iterate through nodes */
    for (pCurrent = pNode; pCurrent; SNMP_MIB_GET_NEXT_CHILD(pCurrent, pCurrent)) {
        SNMP_LOG("%u ", pCurrent->oid);

        SNMP_MIB_GET_FIRST_CHILD(pChild, pCurrent);
        if (NULL != pChild) {
            SNMP_LOG("\n");
            snmp_debug_print_tree(pChild, indent + 1);
            SNMP_LOG("\n");
        }
    }
}


