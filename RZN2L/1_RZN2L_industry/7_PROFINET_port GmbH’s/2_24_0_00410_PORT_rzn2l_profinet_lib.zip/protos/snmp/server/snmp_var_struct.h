/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_VAR_STRUCT_H
#define SNMP_VAR_STRUCT_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_VAR_MAX_DATA (4 * 128)
#define SNMP_OID_MAX_LEN  128


/****************************************************************************/
/* Structs */
/****************************************************************************/
/*
 * Struct representing an OID
 */
typedef struct {
    uint32_t sub_oid[SNMP_OID_MAX_LEN];
    uint8_t len;
    uint8_t inuse;
} SNMP_OID_T;

/*
 * Struct representing a SNMP variable
 */
typedef struct {
    /* The OID of this var */
    SNMP_OID_T *oid;
    /* The data of this var */
    uint8_t data[SNMP_VAR_MAX_DATA];
    /* The type of this var */
    ASN1_TYPE type;
    uint8_t inuse;
    uint16_t size;
    uint8_t sign;
    uint32_t enc_size;
    SNMP_VAR_ERROR_T error_code;
} SNMP_VAR_T;

/*
 * List helper struct for variable lists
 */
typedef struct SNMP_VARENTRY_T{
    struct SNMP_VARENTRY_T *prev;
    struct SNMP_VARENTRY_T *next;
    SNMP_VAR_T *var;
    uint8_t inuse;
} SNMP_VARENTRY_T;

/*
 * Struct representing a variable list
 */
typedef struct {
    SNMP_VARENTRY_T *head;
    SNMP_VARENTRY_T *tail;
    uint16_t entry_count;
    void *user_data;
    uint8_t inuse;
} SNMP_VARLIST_T;


#endif /* SNMP_VAR_STRUCT_H */
