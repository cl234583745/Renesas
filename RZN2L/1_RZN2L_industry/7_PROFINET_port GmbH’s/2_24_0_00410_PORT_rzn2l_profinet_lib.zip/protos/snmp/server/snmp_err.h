/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_ERR_H
#define SNMP_ERR_H

/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef enum {
    SNMP_RET_NOERR,                    /**< No error */
    SNMP_RET_ASN1_UNKNOWN_TYPE,                /**< An unknown ASN.1 type was requested */
    SNMP_RET_ASN1_RESOURCE,            /**< Insufficient resources during ASN.1 operation (e.g. buffer to small) */
    SNMP_RET_ASN1_RANGE,            /**< The value is out of range for this ASN.1 type */
    SNMP_RET_ASN1_TYPEERR,            /**< A type mismatch was detected */
    SNMP_RET_RESOURCE,                /**< Insufficient resources (e.g. buffer to small) */
    SNMP_RET_NET,                /**< Network error */
    SNMP_RET_PARAM,                /**< Parameter error */
    SNMP_RET_AUTH                /**< Authentication failure (invalid community string) */
} SNMP_RET_T;

typedef enum {
    SNMP_NOERR=0,                     /**< No error occurred */
    SNMP_ERR_RESP_TOO_LARGE,                     /**< Response message too large to transport */
    SNMP_ERR_NAME_NOT_FOUND,                     /**< The name of the requested object was not found */
    SNMP_ERR_TYPE_MISMATCH,                     /**< A data type in the request did not match the data type in the SNMP agent */
    SNMP_ERR_READ_ONLY,                 /**< The SNMP manager attempted to set a read-only parameter */
    SNMP_ERR_GENERAL_ERROR,                 /**< General Error (some error other than the ones listed above) */
    SNMP_ERR_NO_ACCESS,
    SNMP_ERR_WRONG_TYPE,
    SNMP_ERR_WRONG_LENGTH,
    SNMP_ERR_WRONG_ENCODING,
    SNMP_ERR_WRONG_VALUE,
    SNMP_ERR_NO_CREATION,
    SNMP_ERR_INCONSISTENT_VALUE,
    SNMP_ERR_RESOURCE_UNAVAIL,
    SNMP_ERR_COMMIT_FAILED,
    SNMP_ERR_UNDO_FAILED,
    SNMP_ERR_AUTH,
    SNMP_ERR_NOT_WRITABLE,
    SNMP_ERR_INCONSISTENT_NAME
} SNMP_ERROR_T;

typedef enum snmp_var_error_codes {
    SNMP_VAR_NOERR=0,
    SNMP_VAR_NOSUCHOBJECT=0x80,
    SNMP_VAR_NOSUCHINSTANCE,
    SNMP_VAR_ENDOFMIBVIEW
} SNMP_VAR_ERROR_T;

#endif /* SNMP_ERR_H */
