/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_H
#define SNMP_H


/****************************************************************************/
/* Macros */
/****************************************************************************/
#ifndef ARRAY_ELEMENTS
#  define ARRAY_ELEMENTS(x) (sizeof(x) / sizeof(x[0]))
#endif


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_V1 0
#define SNMP_V2 1

#define SNMP_RO 0
#define SNMP_RW 1

#ifndef SNMP_HIDE_NOT_ACCESSIBLE
    #define SNMP_HIDE_NOT_ACCESSIBLE    1
#endif


/****************************************************************************/
/* Structs/enums */
/****************************************************************************/
/* SNMP bool values */
typedef enum {
    SNMP_TRUE = 1,
    SNMP_FALSE = 2
} GOAL_SNMP_BOOL_T;

/* SNMP message types */
typedef enum {
    SNMP_MSG_GET=0xA0,
    SNMP_MSG_GETNEXT,
    SNMP_MSG_RESP,
    SNMP_MSG_SET,
    SNMP_MSG_TRAP,
    SNMP_MSG_GETBULK,
    SNMP_MSG_INFORM,
    SNMP_MSG_TRAPV2,
    SNMP_MSG_LAST
} SNMP_MSG_TYPE_T;

/* Predefined trap types */
typedef enum {
    SNMP_TRAP_COLDSTART=0,
    SNMP_TRAP_WARMSTART,
    SNMP_TRAP_LINKDOWN,
    SNMP_TRAP_LINKUP,
    SNMP_TRAP_AUTHFAIL,
    SNMP_TRAP_EGPNEIGHLOSS,
    SNMP_TRAP_ESPECIFIC
} SNMP_TRAP_TYPE_T;

/* Structure containing data of an SNMP request */
typedef struct {
    uint32_t xid;                                /**< request ID */
    SNMP_ERROR_T error;                          /**< SNMP error code */
    uint32_t error_index;                        /**< index of entry caused error */
    uint32_t *index_oid;                         /**< length of index OID */
    uint16_t index_oid_len;                      /**< index OID */
    SNMP_VARLIST_T *list;                        /**< varBindList */
    SNMP_VARLIST_T *pListBackup;                 /**< received varBindList */
    SNMP_MSG_TYPE_T type;                        /**< message type */
    uint16_t size;                               /**< message size */
    uint32_t nonrep;                             /**< non-repeaters value (of GetBulk request) */
    uint32_t maxrep;                             /**< max-repititions value (of GetBulk request) */
    uint32_t sport;                              /**< source port */
    uint32_t dport;                              /**< destination port */
    uint8_t version;                             /**< SNMP message version */
} SNMP_MSG_T;

/* These are stack statistics required esp. by MIB-II.
 * For further documentation of the meaning of the different
 * fields please refer to RFC1213-MIB. The variable names are
 * equal to the MIB node names.
 */
typedef struct {
    /* Total number of GET PDUs () */
    uint32_t snmpInGetRequests;
    /* Number of ASN.1 parser errors (snmpInASNParseErrs) */
    uint32_t snmpInASNParseErrs;
    /* Total number of packets (snmpInPkts) */
    uint32_t snmpInPkts;
    /* Number of bad versions in PDUs (snmpInBadVersions) */
    uint32_t snmpInBadVersions;
    /* Number of unknown community names (snmpInBadCommunityNames) */
    uint32_t snmpInBadCommunityNames;
    /* Number of access errors cause by wrong community names (snmpInBadCommunityUses) */
    uint32_t snmpInBadCommunityUses;
    /* Number of messages containing tooBig in error-field (snmpInTooBigs) */
    uint32_t snmpInTooBigs;
    /* Number of MIB variables containing noSuchName in reply (snmpInNoSuchNames) */
    uint32_t snmpInNoSuchNames;
    /* Total number of set vars */
    uint32_t snmpInTotalSetVars;
    uint32_t snmpInTotalReqVars;
    uint32_t snmpInGenErrs;
    uint32_t snmpInReadOnlys;
    uint32_t snmpInBadValues;
    uint32_t snmpInGetNexts;
    uint32_t snmpInSetRequests;
    uint32_t snmpInGetResponses;
    uint32_t snmpInTraps;
    uint32_t snmpOutTooBigs;
    uint32_t snmpOutNoSuchNames;
    uint32_t snmpOutBadValues;
    uint32_t snmpOutGenErrs;
    uint32_t snmpOutGetRequests;
    uint32_t snmpOutGetResponses;
    uint32_t snmpOutGetNexts;
    uint32_t snmpOutSetRequests;
    uint32_t snmpOutTraps;
    uint32_t snmpEnableAuthenTraps;

    /* Total number of sent packets (snmpOutPkts) */
    uint32_t snmpOutPkts;

} SNMP_STATS_T;


typedef SNMP_RET_T (* SNMP_RESET_FUNC_T)(
    void *pArg                                   /**< reset argument */
);

typedef struct SNMP_RESET_HANDLER_T{
    SNMP_RESET_FUNC_T pFunc;                     /**< SNMP reset function */
    struct SNMP_RESET_HANDLER_T *pNext;          /**< next handler */
} SNMP_RESET_HANDLER_T;


/****************************************************************************/
/* extern variable declerations */
/****************************************************************************/
extern char snmp_op_community[SNMP_CONF_MAX_COMMUNITY_LEN]; /**< community string of current operation */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_init(
    void
);

SNMP_RET_T snmp_communitySet(
    char *strReadCommunity,                      /**< read community */
    char *strWriteCommunity                      /**< write community */
);

SNMP_RET_T goal_snmpReset(
    void *pArg                                   /**< argument */
);

SNMP_RET_T goal_snmpResetReg(
    SNMP_RESET_FUNC_T pFunc                      /**< SNMP reset function */
);

SNMP_RET_T snmp_close(
    void
);

SNMP_RET_T snmp_send_trap_v1(
    char *pDstAddr,                              /**< Dst address */
    char *pSrcAddr,                              /**< Src address */
    SNMP_TRAP_TYPE_T trapId,                     /**< Trap id to send */
    uint32_t specificTrap,                       /**< Specific trap id to send */
    uint32_t timestamp,                          /**< Timestamp */
    SNMP_OID_T *pEnterpriseOid,                  /**< Enterprise ID to use */
    SNMP_VARLIST_T *pVars                        /**< Varlist to attach */
);


SNMP_STATS_T *snmp_get_statistics(
    void
);

SNMP_RET_T snmp_decode_msg(
    uint8_t *pBuffer,                            /**< Buffer */
    uint16_t size,                               /**< Buffer size */
    SNMP_MSG_T *pMsg                             /**< Message */
);

SNMP_RET_T snmp_process_get(
    SNMP_MSG_T *pMsg                             /**< Message */
);

SNMP_RET_T snmp_process_getnext(
    SNMP_MSG_T *pMsg                             /**< Message */
);

SNMP_RET_T snmp_process_set(
    SNMP_MSG_T *pMsg                             /**< Message */
);

SNMP_RET_T snmp_process_getbulk(
    SNMP_MSG_T *pMsg                             /**< Message */
);

SNMP_RET_T snmp_send_trap_v2(
    uint32_t ip,                                 /**< Dst address */
    uint16_t dport,                              /**< Dst port */
    uint32_t *pOid,                              /**< Trap OID */
    uint16_t lenOid,                             /**< Trap OID len */
    SNMP_VARLIST_T *pList                        /**< Varlist */
);

SNMP_RET_T snmp_trapsInit(
    uint32_t trapSink                            /**< trap sink IP address */
);

SNMP_RET_T snmp_oidIsSmaller(
    uint32_t *pLeftOid,                          /**< left OID in relation */
    uint32_t lenLeftOid,                         /**< length of left OID */
    uint32_t *pRightOid,                         /**< right OID in relation */
    uint32_t lenRightOid,                        /**< length of right OID */
    uint32_t *pIgnoreList,                       /**< list of indexes for sub OIDs to ignore in comparison */
    uint32_t lenIgnoreList,                      /**< number of sub OIDs to ignore */
    GOAL_BOOL_T *pLeftSmallerRight               /**< OID comparison result  */
);

SNMP_RET_T snmp_responseMapToV1(
    SNMP_MSG_T *pMsg                             /**< Message */
);

#endif /* SNMP_H */
