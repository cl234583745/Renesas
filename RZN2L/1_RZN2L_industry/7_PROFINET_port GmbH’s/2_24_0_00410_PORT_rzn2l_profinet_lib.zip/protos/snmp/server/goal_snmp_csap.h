/** @file
 *
 * @brief csap configuration - generated
 *
 * @copyright
 * Copyright 2010-2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_CSAP_H
#define SNMP_CSAP_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define SNMP_CSAP_NEW 1
#define SNMP_CSAP_COMM_SET 2
#define SNMP_CSAP_TRAPS_INIT 3


/****************************************************************************/
/* Global Prototypes */
/****************************************************************************/
GOAL_STATUS_T snmp_csapReg(
    void
);

#endif /* SNMP_CSAP_H */
