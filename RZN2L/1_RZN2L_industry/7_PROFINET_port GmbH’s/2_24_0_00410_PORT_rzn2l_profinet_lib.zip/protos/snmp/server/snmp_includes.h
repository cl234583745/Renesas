/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_INCLUDES_H
#define SNMP_INCLUDES_H

#include <snmp_conf.h>

#include <snmp_err.h>

#include <snmp_util.h>
#include <snmp_var_types.h>
#include <snmp_var_struct.h>
#include <snmp_var.h>

#include <goal_snmp.h>
#include <snmp.h>

#include <snmp_asn1.h>

#include <snmp_port.h>
#include <snmp_mib.h>
#include <snmp_debug.h>

#ifndef  GOAL_SNMP_MIB_RFC1213_DISABLE
#   include <snmp_rfc1213_mib.h>
#endif

#endif /* SNMP_INCLUDES_H */
