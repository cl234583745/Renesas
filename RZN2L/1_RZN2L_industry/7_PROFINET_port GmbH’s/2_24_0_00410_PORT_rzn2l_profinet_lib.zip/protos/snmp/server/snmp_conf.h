/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_CONF_H_
#define SNMP_CONF_H_


/* Max. string len of SNMP community to be processed */
#define SNMP_CONF_MAX_COMMUNITY_LEN 255

/*
 * If SNMP_CONF_MEM_STATICVARS is defined
 * a static var pool is created and used
 * instead of dynamic memory allocation.
 */
#define SNMP_CONF_STATICVARS
/*
 * Number of concurrent var lists
 */
#define SNMP_CONF_STATIC_VARLISTPOOL 2
/*
 * Number of concurrent var entries
 */
#define SNMP_CONF_STATIC_VARENTRYPOOL 5
/*
 * Number of concurrent vars. Should be equal to
 * or higher then SNMP_CONF_STATIC_VARENTRYPOOL
 */
#define SNMP_CONF_STATIC_VARPOOL 5
/*
 * Number of concurrent OIDs. Should be equal to
 * or higher than SNMP_CONF_STATIC_VARENTRYPOOL
 */
#define SNMP_CONF_STATIC_OIDPOOL 5

/**
 * Number of static allocated MIB nodes
 */
#define SNMP_CONF_STATIC_MIBNODES 360

/* Local and remote UDP ports */
#define SNMP_CONF_NET_LOCAL_PORT 161
#define SNMP_CONF_NET_REMOTE_PORT 161
#define SNMP_CONF_NET_BUFFERSIZE 1500
#define SNMP_CONF_NET_TRAP_REMOTE_PORT 162

/* Platform dependent byte access macros */
#define HIGHBYTE(x) ((x>>8) & 0xFF)
#define LOWBYTE(x) (x & 0xFF)
#define HIGHWORD(x) ((x>>16) & 0xFFFF)
#define LOWWORD(x) (x & 0xFFFF)

/* Macros for memcpy, memset and host/network byte order conversion */
#define SNMP_MEMCPY(dst,src,cnt) GOAL_MEMCPY(dst,src,cnt)
#define SNMP_MEMSET(dst,val,cnt) GOAL_MEMSET(dst,val,cnt)
#define NTOH32(x) GOAL_be32toh(x)

/* Macros for malloc and free */
#define MALLOC(x) malloc(x)
#define FREE(x) free(x)

/* Macro for unused arguments */
#define UNUSEDARG(x) ((void)(x))

#endif /* SNMP_CONF_H_ */
