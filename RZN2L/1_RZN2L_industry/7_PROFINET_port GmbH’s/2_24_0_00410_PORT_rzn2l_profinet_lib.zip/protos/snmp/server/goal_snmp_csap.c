/** @file
 *
 * @brief csap configuration - generated
 *
 * @copyright
 * Copyright 2010-2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"
#include "goal_snmp_csap_types.h"
#include "goal_snmp_csap.h"


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static GOAL_STATUS_T snmpNewCsap(
    void
);

static GOAL_STATUS_T snmpCommSetCsap(
    void
);

static GOAL_STATUS_T snmpTrapsInitCsap(
    void
);


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static GOAL_CSAP_FUNCTION_LIST_T csapList[] = {
    { SNMP_CSAP_NEW, snmpNewCsap, 2, GOAL_FALSE, &csapList[1] },
    { SNMP_CSAP_COMM_SET, snmpCommSetCsap, 3, GOAL_FALSE, &csapList[2] },
    { SNMP_CSAP_TRAPS_INIT, snmpTrapsInitCsap, 2, GOAL_FALSE, NULL }
};

static GOAL_CSAP_HANDLE_T *pHdlCsap;            /**< handle */


/****************************************************************************/
/** csap read and execution function
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T snmpNewCsap(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */
    GOAL_INSTANCE_SNMP_T *pHdlSnmp;             /* handle */
    uint32_t id;                                /* handle id */
    uint32_t idSnmp;                            /* idSnmp */

    GOAL_CSAP_POP(id, uint32_t);
    GOAL_CSAP_POP(idSnmp, uint32_t);

    pHdlSnmp = NULL;
    UNUSEDARG(id);

    if (GOAL_RES_OK(res)) {
        res = goal_snmpNewImpl(&pHdlSnmp, idSnmp);
    }

    return res;
}


/****************************************************************************/
/** csap read and execution function
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T snmpCommSetCsap(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */
    GOAL_INSTANCE_SNMP_T *pHdlSnmp;             /* handle */
    uint32_t id;                                /* handle id */
    char * strReadCommunity;                    /* strReadCommunity */
    char * strWriteCommunity;                   /* strWriteCommunity */

    GOAL_CSAP_POP(id, uint32_t);
    GOAL_CSAP_POP_STR(strReadCommunity, char *);
    GOAL_CSAP_POP_STR(strWriteCommunity, char *);

    res = goal_instGetById((GOAL_INSTANCE_T **) &pHdlSnmp, GOAL_ID_SNMP, id);

    if (GOAL_RES_OK(res)) {
        res = goal_snmpCommSetImpl(pHdlSnmp, strReadCommunity, strWriteCommunity);
    }

    return res;
}


/****************************************************************************/
/** csap read and execution function
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T snmpTrapsInitCsap(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */
    GOAL_INSTANCE_SNMP_T *pHdlSnmp;             /* handle */
    uint32_t id;                                /* handle id */
    uint32_t trapSink;                          /* trapSink */

    GOAL_CSAP_POP(id, uint32_t);
    GOAL_CSAP_POP(trapSink, uint32_t);

    res = goal_instGetById((GOAL_INSTANCE_T **) &pHdlSnmp, GOAL_ID_SNMP, id);

    if (GOAL_RES_OK(res)) {
        res = goal_snmpTrapsInitImpl(pHdlSnmp, trapSink);
    }

    return res;
}


/****************************************************************************/
/** Register module at csap
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T snmp_csapReg(
    void
)
{
    GOAL_STATUS_T res;                          /* return value */
    /* register functions */
    res = goal_csapReg(&pHdlCsap, GOAL_ID_SNMP, csapList);

    return res;
}
