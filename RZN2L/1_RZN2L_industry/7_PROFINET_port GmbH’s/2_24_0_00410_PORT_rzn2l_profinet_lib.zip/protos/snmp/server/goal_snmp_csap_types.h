#include <goal_includes.h>
#include <goal_snmp.h>

#define goal_snmpCommSetImpl goal_snmpCommSet
#define goal_snmpTrapsInitImpl goal_snmpTrapsInit

