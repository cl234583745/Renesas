/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_MIB_H
#define SNMP_MIB_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define SNMP_MIB_NODE_FLAG_IN_USE               ((uint8_t) (1 << 0))
#define SNMP_MIB_NODE_FLAG_IS_TABLE             ((uint8_t) (1 << 1))
#define SNMP_MIB_NODE_FLAG_HAS_TABLE_GET        ((uint8_t) (1 << 2))
#define SNMP_MIB_NODE_FLAG_HAS_TABLE_SET        ((uint8_t) (1 << 3))
#define SNMP_MIB_NODE_FLAG_HAS_TABLE_INDEXER    ((uint8_t) (1 << 4))
#define SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET       ((uint8_t) (1 << 5))
#define SNMP_MIB_NODE_FLAG_HAS_SIMPLE_SET       ((uint8_t) (1 << 6))
#define SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT       ((uint8_t) (1 << 7))


/****************************************************************************/
/* Struct/enums */
/****************************************************************************/
typedef uint8_t SNMP_MIB_NODE_FLAGS_T;           /**< MIB node flags */

typedef enum {
    SNMP_TCMD_GET,                               /**< get command for MIB table indexer */
    SNMP_TCMD_GETNEXT,                           /**< getnext command for MIB table indexer */
    SNMP_TCMD_SET                                /**< set command for MIB table indexer */
} SNMP_TABLE_CMD_T;

typedef enum {
    SNMP_CMD_EXISTS,                             /**< OID exists command */
    SNMP_CMD_VALUE,                              /**< check set value command */
    SNMP_CMD_CANCREATE,                          /**< check if can create table row */
    SNMP_CMD_CREATE,                             /**< create table row */
    SNMP_CMD_SET,                                /**< set value */
    SNMP_CMD_UNDO,                               /**< undo setting of value */
    SNMP_CMD_GET,                                /**< get variable of given OID */
    SNMP_CMD_GETNEXT,                            /**< get next variable of given OID */
    SNMP_CMD_COMMIT                              /**< commit value */
} SNMP_CMD_T;


typedef SNMP_RET_T (*snmp_get_handler_func)(SNMP_MSG_T *, SNMP_VARENTRY_T *);
typedef SNMP_RET_T (*snmp_set_handler_func)(SNMP_MSG_T *, SNMP_VARENTRY_T*, SNMP_CMD_T cmd);
typedef SNMP_RET_T (*snmp_table_indexer_func)(SNMP_MSG_T *, SNMP_TABLE_CMD_T cmd);
typedef SNMP_RET_T (*snmp_table_get_handler_func)(SNMP_MSG_T *, SNMP_VARENTRY_T*, SNMP_CMD_T cmd);
typedef SNMP_RET_T (*snmp_table_set_handler_func)(SNMP_MSG_T *, SNMP_VARENTRY_T*, SNMP_CMD_T cmd);

typedef GOAL_STATUS_T (*GOAL_SNMP_MIB_INIT_REG_FUNC_T)(void);

typedef struct {
    snmp_table_get_handler_func getHandler;      /**< table get handler */
    snmp_table_set_handler_func setHandler;      /**< table set handler */
    snmp_table_indexer_func tableIndexer;        /**< table indexer */
} SNMP_TABLE_HANDLER_FUNC_SET_T;

typedef struct {
    snmp_get_handler_func getHandler;            /**< scalar get handler */
    snmp_set_handler_func setHandler;            /**< scalar set handler */
} SNMP_SIMPLE_NODE_HANDLER_FUNC_SET_T;

typedef union {
    SNMP_TABLE_HANDLER_FUNC_SET_T *pTableHandler; /**< table handler function set */
    SNMP_SIMPLE_NODE_HANDLER_FUNC_SET_T *pSimpleHandler; /**< simple node handler function set */
} SNMP_HANDLER_T ;

GOAL_TARGET_PACKED_STRUCT_PRE
typedef GOAL_TARGET_PACKED_PRE struct SNMP_MIB_NODE_T {
    uint32_t oid;                                /**< sub OID of MIB node */
    union {
        SNMP_HANDLER_T handler;                  /**< table or simple node handler */
        struct SNMP_MIB_NODE_T *pChild;          /**< first child of node */
    } child;                                     /**< child (node or handler set) */
    struct SNMP_MIB_NODE_T *pNext;               /**< next child of parent or parent node */
    SNMP_MIB_NODE_FLAGS_T flags;                 /**< node flags */
} GOAL_TARGET_PACKED SNMP_MIB_NODE_T;
GOAL_TARGET_PACKED_STRUCT_POST

typedef struct SNMP_MIB_NODE_LIST_T {
    SNMP_MIB_NODE_T *pNode;                      /**< current node */
    struct SNMP_MIB_NODE_LIST_T *pNext;          /**< next node list element */
} SNMP_MIB_NODE_LIST_T;

typedef struct GOAL_SNMP_MIB_INIT_REG_LIST_T {
    GOAL_SNMP_MIB_INIT_REG_FUNC_T func;          /**< current MIB register callback */
    struct GOAL_SNMP_MIB_INIT_REG_LIST_T *pNext; /**< next MIB register callback */
} GOAL_SNMP_MIB_INIT_REG_LIST_T;


/****************************************************************************/
/* Macros */
/****************************************************************************/
#define SNMP_MIB_GET_FIRST_CHILD(pRes, pNode)       pRes = (pNode->flags &                                                          \
                                                           (SNMP_MIB_NODE_FLAG_HAS_TABLE_GET |                                      \
                                                           SNMP_MIB_NODE_FLAG_HAS_TABLE_SET |                                       \
                                                           SNMP_MIB_NODE_FLAG_HAS_TABLE_INDEXER |                                   \
                                                           SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET |                                      \
                                                           SNMP_MIB_NODE_FLAG_HAS_SIMPLE_SET)) ? NULL : pNode->child.pChild
#define SNMP_MIB_GET_NEXT_CHILD(pRes, pNode)        pRes = (pNode->flags & SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT) ? NULL : pNode->pNext
#define SNMP_MIB_GET_PARENT(pRes, pNode)            pRes = pNode;                                                                   \
                                                    while ((!(pRes->flags & SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT)) &&                  \
                                                        (NULL != pRes->pNext)) {                                                    \
                                                        pRes = pRes->pNext;                                                         \
                                                    }                                                                               \
                                                    pRes = pRes->pNext


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_mib_register_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< scalar get handler */
    snmp_set_handler_func setHandler            /**< scalar set handler */
);

SNMP_RET_T snmp_mib_register_high_prio_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< Get handler */
    snmp_set_handler_func setHandler            /**< Set handler */
);

SNMP_RET_T snmp_mib_register_table(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_TABLE_HANDLER_FUNC_SET_T *pTableHandler /**< Table handler set */
);

SNMP_RET_T snmp_mib_find_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to found node */
);

SNMP_RET_T snmp_mib_find_table_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode,                   /**< Pointer to found node */
    uint32_t **ppTableOid                       /**< Pointer to table OID */
);

SNMP_RET_T snmp_mib_get_next_node(
    SNMP_MIB_NODE_T *pCurrent,                  /**< Current node */
    SNMP_MIB_NODE_T **ppNext                    /**< Next node */
);

SNMP_RET_T snmp_mib_find_high_prio_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to found node */
);

SNMP_RET_T snmp_mib_find_node_with_at_least_oid(
    uint32_t **ppOid,                           /**< OID */
    uint16_t *pOidLen,                          /**< pointer remaining OID length */
    SNMP_MIB_NODE_T **ppNode,                   /**< pointer to pointer of found node */
    GOAL_BOOL_T *pFlgExactMatch                 /**< pointer to flag for given OID matches found node */
);

SNMP_RET_T snmp_mib_insert_child_node(
    SNMP_MIB_NODE_T *pParent,                   /**< Parent node */
    SNMP_MIB_NODE_T *pChild                     /**< Child node */
);

void snmp_mib_print_mib_tree(
    void
);

GOAL_STATUS_T goal_snmpMibInitReg(
    GOAL_SNMP_MIB_INIT_REG_FUNC_T mibInitFunc   /**< MIB init function to register */
);

GOAL_STATUS_T goal_snmpMibInit(
    void
);

#endif /* SNMP_MIB_H */
