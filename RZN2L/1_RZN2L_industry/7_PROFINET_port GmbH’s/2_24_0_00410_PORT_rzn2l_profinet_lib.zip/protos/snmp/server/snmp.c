/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_SNMP
#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/* Macros */
/****************************************************************************/
/* Helper macro for msg parsing */
#define SNMP_MSG_ASN1_DECODE(target, target_size) \
    targetLen = target_size; \
    rv = snmp_asn1_decode(pData, size, (uint8_t *) target, &targetLen, &sign, &type, (void **)&pEnd); \
    if (rv != SNMP_RET_NOERR) return rv; \
    size -= pEnd - pData; \
    pData = pEnd;

/* Helper macro for error eval */
#define SNMP_ERR_RET(rv) \
    if (rv != SNMP_RET_NOERR){ \
        SNMP_LOG("Error code: %u at %s:%d\n", rv, __FILE__, __LINE__);\
        return rv;}

/* Helper macro for error eval incl. stats increment */
#define SNMP_ERR_BREAK_STAT(rv, stat) \
    if (rv != SNMP_RET_NOERR){ \
        stat++; \
        SNMP_LOG("Error code: %u at %s:%d\n", rv, __FILE__, __LINE__);\
        break;}


/****************************************************************************/
/* Global variables */
/****************************************************************************/
char snmp_op_community[SNMP_CONF_MAX_COMMUNITY_LEN]; /**< community string of current operation */


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static char snmpReadCommunity[SNMP_CONF_MAX_COMMUNITY_LEN]; /**< read community string */
static char snmpWriteCommunity[SNMP_CONF_MAX_COMMUNITY_LEN]; /**< read/write community string */
static uint8_t snmpNetBuffer[SNMP_CONF_NET_BUFFERSIZE]; /**< Buffer for receiving */
static SNMP_STATS_T stats;                       /**< Statistics of the SNMP stack */
static SNMP_RESET_HANDLER_T *pResetList = NULL;  /**< reset handler list */
static uint32_t snmpTrapSink;                    /**< registered trap sink */
static uint32_t snmpColdStartTrap_OID[] = {1, 3, 6, 1, 6, 3, 1, 1, 5, 1}; /**< coldstart trap OID */
#define OID_COLDSTART_LEN 10


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_process_table(
    SNMP_MIB_NODE_T *pnode,                      /**< MIB node */
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_VARENTRY_T *pEntry,                     /**< Varentry */
    SNMP_CMD_T cmd,                              /**< Table cmd */
    SNMP_CMD_T specCmd                           /**< Spec. table cmd */
);

static uint8_t snmp_get_access_type(
    SNMP_MSG_TYPE_T type                         /**< Message type */
);

static SNMP_RET_T snmp_is_validpMsg_type(
    SNMP_MSG_TYPE_T type                         /**< Message type */
);

static SNMP_RET_T snmp_get_oid_for_node(
    SNMP_MIB_NODE_T *pNode,                      /**< MIB node */
    SNMP_OID_T *pOid                             /**< OID */
);

static SNMP_RET_T snmp_getnext_intern(
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_VARENTRY_T *pEntry                      /**< Varlist */
);

static SNMP_RET_T snmp_for_all_varlist_entries(
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_CMD_T cmd,                              /**< Command */
    SNMP_CMD_T specCmd,                          /**< Specific command */
    uint32_t endIndex,                           /**< Last index to process */
    uint32_t *lastIndex                          /**< Last index processed */
);


/****************************************************************************/
/** Initializes the SNMP stack
 *
 * @retval SNMP_RET_NOERR success
 * @retval others fail
 */
SNMP_RET_T snmp_init(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    GOAL_STATUS_T res;                          /**< GOAL result */

    /* init MIBs */
    res = goal_snmpMibInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not initialize MIBs.");
        return SNMP_RET_RESOURCE;
    }

    /* clear stats */
    SNMP_MEMSET(&stats,0,sizeof(SNMP_STATS_T));
    return rv;
}


/****************************************************************************/
/** Set Community strings of SNMP stack
 *
 * @retval SNMP_RET_NOERR success
 * @retval others fail
 */
SNMP_RET_T snmp_communitySet(
    char *strReadCommunity,                      /**< read community */
    char *strWriteCommunity                      /**< write community */
)
{
    /* check for right community string lengths */
    if ((GOAL_STRNLEN(strReadCommunity, SNMP_CONF_MAX_COMMUNITY_LEN) > SNMP_CONF_MAX_COMMUNITY_LEN - 1) ||
        (GOAL_STRNLEN(strWriteCommunity, SNMP_CONF_MAX_COMMUNITY_LEN) > SNMP_CONF_MAX_COMMUNITY_LEN - 1)) {
        return SNMP_RET_RESOURCE;
    }

    /* copy community strings */
    SNMP_MEMCPY(&(snmpReadCommunity[0]), strReadCommunity, GOAL_STRLEN(strReadCommunity));

    snmpReadCommunity[GOAL_STRLEN(strReadCommunity) + 1] = 0;
    SNMP_MEMCPY(&(snmpWriteCommunity[0]), strWriteCommunity, GOAL_STRLEN(strWriteCommunity));

    snmpWriteCommunity[GOAL_STRLEN(strWriteCommunity) + 1] = 0;

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Reset the SNMP stack.
 *
 * Calls all registered SNMP reset handlers
 *
 * @retval SNMP_RET_NOERR success
 * @retval others fail
 */
SNMP_RET_T goal_snmpReset(
    void *pArg                                   /**< argument */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;              /* return value */
    SNMP_RESET_HANDLER_T **ppReset;              /* pointer to current reset list element */

    /* use all registered reset handlers */
    for (ppReset = &pResetList; NULL!= *ppReset; ppReset = &(*ppReset)->pNext) {
        if (NULL != (*ppReset)->pFunc) {
            rv |= (*ppReset)->pFunc(pArg);
        }
    }

    return rv;
}


/****************************************************************************/
/** Register a SNMP reset handler.
 *
 * All registered handlers are called in snmp_reset
 *
 * @retval SNMP_RET_NOERR success
 * @retval others fail
 */
SNMP_RET_T goal_snmpResetReg(
    SNMP_RESET_FUNC_T pFunc                      /**< SNMP reset function */
)
{
    GOAL_STATUS_T res;                           /* GOAL result */
    SNMP_RESET_HANDLER_T **ppLast;               /* pointer to last reset list element */
    SNMP_RESET_HANDLER_T *pHandler;              /* new reset handler */

    /* allocate protocol handler and set function pointer */
    res = goal_memCalloc(&pHandler, sizeof(SNMP_RESET_HANDLER_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to allocate protocol handler");
    }
    else {
        pHandler->pFunc = pFunc;
    }

    /* add handler to list end */
    if (GOAL_RES_OK(res)) {
        for (ppLast = &pResetList; NULL!= *ppLast; ppLast = &(*ppLast)->pNext);
        *ppLast = pHandler;
    }

    return  (GOAL_RES_OK(res)) ? SNMP_RET_NOERR : SNMP_RET_RESOURCE;
}




/****************************************************************************/
/** Returns the access type (ro,rw) for a given message type
 *
 * @returns access type
 */
static uint8_t snmp_get_access_type(
    SNMP_MSG_TYPE_T type                         /**< Message type */
)
{
    if (type == SNMP_MSG_SET) {
        return SNMP_RW;
    }
    else {
        return SNMP_RO;
    }
}


/****************************************************************************/
/** Send SNMPv1 trap
 *
 * @retval SNMP_RET_NOERR success
 * @retval others fail
 */
SNMP_RET_T snmp_send_trap_v1(
    char *pDstAddr,                              /**< Dst address */
    char *pSrcAddr,                              /**< Src address */
    SNMP_TRAP_TYPE_T trapId,                     /**< Trap id to send */
    uint32_t specificTrap,                       /**< Specific trap id to send */
    uint32_t timestamp,                          /**< Timestamp */
    SNMP_OID_T *pEnterpriseOid,                  /**< Enterprise ID to use */
    SNMP_VARLIST_T *pVars                        /**< Varlist to attach */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;              /* SNMP return value */
    SNMP_VARENTRY_T *pEntry;                     /* varlist */
    uint8_t *pData;                              /* current data pointer */
    uint32_t version = 0;                        /* SNMP message version */
    uint32_t vblistSize = 0;                     /* varBindList size */
    uint32_t pduSize = 0;                        /* PDU size */
    uint32_t msgSize = 0;                        /* total size of message */
    uint8_t cnt;                                 /* counter */

    UNUSEDARG(pDstAddr);

    SNMP_MEMSET(&snmpNetBuffer, 0, SNMP_CONF_NET_BUFFERSIZE);

    /* First calculate the different sizes of the msg elements */
    if (pVars != NULL )
            snmp_calc_var_enc_len(pVars, &vblistSize);

    pduSize = vblistSize + 2 + snmp_asn1_get_uint32_octet_count(vblistSize);

    snmp_asn1_get_encoding_size((uint8_t *) pEnterpriseOid->sub_oid, pEnterpriseOid->len,
                    &pduSize, 0, ASN1_OID);
    snmp_asn1_get_encoding_size((uint8_t *) pSrcAddr, (uint16_t) GOAL_STRLEN(pSrcAddr),
                    &pduSize, 0, ASN1_IPADDR);
    snmp_asn1_get_encoding_size((uint8_t *) &trapId, sizeof(uint32_t),
                    &pduSize, 0, ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) &specificTrap, sizeof(uint32_t),
                    &pduSize, 0, ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) &timestamp, sizeof(uint32_t),
                    &pduSize, 0, ASN1_TIMETICKS);

    msgSize = pduSize + 2 + snmp_asn1_get_uint32_octet_count(pduSize);
    snmp_asn1_get_encoding_size((uint8_t *) &version, sizeof(uint32_t),
                    &msgSize, 0, ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) snmpReadCommunity,
                    (uint16_t) GOAL_STRLEN(snmpReadCommunity), &msgSize, 0, ASN1_OCTET_STRING);

    /* ASN1 header */
    snmpNetBuffer[0] = (uint8_t) 0x30;
    pData = &snmpNetBuffer[1];

    /* Message size */
    cnt = snmp_asn1_get_uint32_octet_count(msgSize);
    *pData = 0x80 + cnt;
    pData++;
    snmp_asn1_encode_uint32(msgSize, (uint8_t *) pData, (void **) &pData, 0, 0);

    /* Version */
    snmp_asn1_encode((uint8_t *) &version, sizeof(uint32_t), ASN1_INTEGER,
                    (uint8_t *) pData, 0, (void **) &pData);

    /* Community */
    snmp_asn1_encode((uint8_t *) &(snmpReadCommunity[0]),
                    (uint16_t) GOAL_STRLEN(snmpReadCommunity), ASN1_OCTET_STRING, (uint8_t *) pData, 0,
                    (void **) &pData);

    /* SNMP TRAP pdu */
    *(pData) = (uint8_t) SNMP_MSG_TRAP;
    pData++;

    /* Store PDU size */
    cnt = snmp_asn1_get_uint32_octet_count(pduSize);
    *pData = 0x80 + cnt;
    pData++;
    snmp_asn1_encode_uint32(pduSize, (uint8_t *) pData, (void **) &pData, 0, 0);

    /* Enterprise OID */
    snmp_asn1_encode((uint8_t *) pEnterpriseOid->sub_oid, pEnterpriseOid->len, ASN1_OID,
                    (uint8_t *) pData, 0, (void **) &pData);

    /* Agent Address */
    snmp_asn1_encode((uint8_t *) pSrcAddr, (uint16_t) GOAL_STRLEN(pSrcAddr), ASN1_IPADDR,
                    (uint8_t *) pData, 0, (void **) &pData);

    /* Trap ID */
    snmp_asn1_encode((uint8_t *) &trapId, sizeof(uint32_t), ASN1_INTEGER,
                    (uint8_t *) pData, 0, (void **) &pData);

    /* Specific ID */
    snmp_asn1_encode((uint8_t *) &specificTrap, sizeof(uint32_t), ASN1_INTEGER,
                    (uint8_t *) pData, 0, (void **) &pData);

    /* Timestamp */
    snmp_asn1_encode((uint8_t *) &timestamp, sizeof(uint32_t), ASN1_TIMETICKS,
                    (uint8_t *) pData, 0, (void **) &pData);

    /*Varbind list */
    *(pData) = (uint8_t) 0x30;
    pData++;

    /* Varbind list size */
    cnt = snmp_asn1_get_uint32_octet_count(vblistSize);
    *pData = 0x80+cnt;
    pData++;
    snmp_asn1_encode_uint32(vblistSize, (uint8_t *) pData, (void **) &pData, 0, 0);

    if (pVars != NULL ) {
        pEntry = pVars->head;
        while (pEntry != NULL ) {
            /* ASN1 header */
            *(pData) = (uint8_t) 0x30;
            pData++;

            cnt = snmp_asn1_get_uint32_octet_count(pEntry->var->enc_size);
            *pData = 0x80+cnt;
            pData++;
            /* The encode sizes were calculated during msg size calculation so just use them here */
            snmp_asn1_encode_uint32(pEntry->var->enc_size, (uint8_t *) pData,
                            (void **) &pData, 0, 0);

            /* Encode OID */
            snmp_asn1_encode((uint8_t *) pEntry->var->oid, pEntry->var->oid->len,
                            ASN1_OID, (uint8_t *) pData, 0, (void **) &pData);
            /* Do we need to encode something? */
            if (pEntry->var->error_code != 0) {
                *(pData) = (uint8_t) pEntry->var->error_code;
                pData++;
                *(pData) = (uint8_t) 0x00;
                pData++;
            } else if (pEntry->var->size != 0) {
                snmp_asn1_encode((uint8_t *) &(pEntry->var->data[0]),
                                pEntry->var->size, pEntry->var->type, (uint8_t *) pData,
                                pEntry->var->sign, (void **) &pData);
            } else {
                /* Null encoding */
                *(pData) = (uint8_t) 0x5;
                pData++;
                *(pData) = (uint8_t) 0x0;
                pData++;
            }
            pEntry = pEntry->next;
        }
    }

    SNMP_LOG("Msg %u VB %u PDU %u \n", msgSize, vblistSize, pduSize);

    /* TODO: create portable version of snmp_sendpMsg */
#if 0
    rv = snmp_sendpMsg(&snmp_sockfd, (uint8_t *) &snmpNetBuffer,
                    pData - (uint8_t *) snmpNetBuffer, dst_addr, SNMP_CONF_NET_TRAP_REMOTE_PORT);
#endif

    return rv;
}


/****************************************************************************/
/** Checks whether a type is a valid SNMPv2 msg type
 *
 * @retval SNMP_RET_NOERR success
 * @retval SNMP_RET_ASN1_RANGE not a valid msg type
 */
static SNMP_RET_T snmp_is_validpMsg_type(
    SNMP_MSG_TYPE_T type                         /**< Message type */
)
{
    if ((SNMP_MSG_GET > type) || (SNMP_MSG_LAST < type)) {
        return SNMP_RET_ASN1_RANGE;
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Decodes an SNMPvX msg into given msg structure
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_decode_msg(
    uint8_t *pBuffer,                            /**< Buffer */
    uint16_t size,                               /**< Buffer size */
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;              /* SNMP return value */
    SNMP_RET_T rvFree = SNMP_RET_NOERR;          /* SNMP return value of free command*/
    uint8_t sign;                                /* sign of variable */
    uint16_t targetLen;                          /* length of variable */
    uint8_t *pEnd = NULL;                        /* end of data pointer */
    uint8_t *pData = pBuffer;                    /* current data pointer */
    uint32_t msgSize = 0;                        /* total message size */
    uint32_t var = 3;                            /* value of variable */
    uint8_t msgType = 0;                         /* type of message */
    uint32_t pduSize;                            /* PDU size */
    uint32_t vbSize;                             /* varBindList size */
    SNMP_VARLIST_T *pVarlist = NULL;             /* varBindList */
    SNMP_VARLIST_T *pVarlistBackup = NULL;       /* backup varlist */
    SNMP_VARENTRY_T *pVarEntry;                  /* varBindList entry */
    SNMP_VARENTRY_T *pVarEntryBackup;            /* backup varlist entry */
    ASN1_TYPE type;                              /* variable type */

    /* ASN.1 header */
    if (pBuffer[0] != (uint8_t) 0x30)
            return SNMP_RET_RESOURCE;
    pData++;
    size--;

    /* Message size */
    snmp_asn1_decode_berInt(pData, &msgSize, &pEnd);

    size -= pEnd - pData;
    pData = pEnd;

    if (msgSize > size){
        stats.snmpInGenErrs++;
        return SNMP_RET_RESOURCE;
    }

    /* Version */
    SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
    if (var != SNMP_V1 && var != SNMP_V2){
        stats.snmpInBadVersions++;
        return SNMP_RET_RESOURCE;
    }
    else
        pMsg->version = (uint8_t) var;

    /* Community string */
    SNMP_MSG_ASN1_DECODE(&(snmp_op_community[0]), SNMP_CONF_MAX_COMMUNITY_LEN);

    SNMP_LOG("Communities: %s %s %s\n", snmp_op_community, snmpReadCommunity,
                    snmpWriteCommunity);

    /* Message type */
    msgType = *((uint8_t *) pData);
    pData++;
    size--;

    rv = snmp_is_validpMsg_type((SNMP_MSG_TYPE_T) msgType);
    SNMP_ERR_RET(rv);

    pMsg->type = (SNMP_MSG_TYPE_T) msgType;

    /* Check community string */
    if (snmp_get_access_type((SNMP_MSG_TYPE_T)msgType) == SNMP_RO) {
        /* RO can be accessed by read and write community */
        if (strncmp(&(snmpReadCommunity[0]), &(snmp_op_community[0]),
                        SNMP_CONF_MAX_COMMUNITY_LEN)
                        && strncmp(&(snmpWriteCommunity[0]), &(snmp_op_community[0]),
                                        SNMP_CONF_MAX_COMMUNITY_LEN)){
            stats.snmpInBadCommunityNames++;
                return SNMP_RET_AUTH;
        }
    } else {
        /* RW can only be accessed by write community */
        if (strncmp(&(snmpWriteCommunity[0]), &(snmp_op_community[0]),
                        SNMP_CONF_MAX_COMMUNITY_LEN)) {
            stats.snmpInBadCommunityUses++;
                return SNMP_RET_AUTH;
        }
    }
    /* PDU size */
    snmp_asn1_decode_berInt(pData, &pduSize, &pEnd);
    size -= pEnd - pData;
    pData = pEnd;

    if (pduSize > size){
        stats.snmpInGenErrs++;
            return SNMP_RET_RESOURCE;
    }

    /* Request ID */
    SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
    pMsg->xid = var;

    if (pMsg->type == SNMP_MSG_GETBULK) {
        /* non-repeaters */
        SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
        pMsg->nonrep = var;

        /* max-repetitions */
        SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
        pMsg->maxrep = var;

    } else {
        /* Error */
        SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
        pMsg->error = (SNMP_ERROR_T) var;

        /* Error Index */
        SNMP_MSG_ASN1_DECODE(&var, sizeof(uint32_t));
        pMsg->error_index = var;

    }

    if (size > 0) {
        if (!(*((uint8_t *) pData) == ASN1_SEQUENCE)){
            stats.snmpInASNParseErrs++;
                return SNMP_RET_RESOURCE;
        }
        pData++;
        size--;

        /* Varbind list size */
        snmp_asn1_decode_berInt(pData, &vbSize, &pEnd);
        size -= pEnd - pData;
        pData = pEnd;

        if (vbSize > size){
            stats.snmpInGenErrs++;
                return SNMP_RET_RESOURCE;
        }

        /* alloc varbind list */
        rv = snmp_alloc_varlist(&pVarlist);
        if (SNMP_RET_NOERR != rv) {
            goal_logErr("Could not allocate variable list.");
            return rv;
        }

        /* alloc varbind list backup */
        rv = snmp_alloc_varlist(&pVarlistBackup);
        if (SNMP_RET_NOERR != rv) {
            goal_logErr("Could not allocate variable list backup.");
            rvFree = snmp_free_varlist(pVarlist);
            if (SNMP_RET_NOERR != rvFree) {
                goal_logErr("Could not free variable list.");
            }
            return rv;
        }

        while (size > 0) {
            /* Sequence */
            if (!(*((uint8_t *) pData) == ASN1_SEQUENCE)){
                stats.snmpInASNParseErrs++;
                goal_logErr("ASN1 sequnce start byte is incorrect.");
                rv = SNMP_RET_RESOURCE;
                break;
            }
            pData++;
            size--;

            /* Varbind size */
            rv = snmp_asn1_decodeLength(pData, size, (void **) &pEnd, &var);
            SNMP_ERR_BREAK_STAT(rv, stats.snmpInGenErrs);

            size -= pEnd - pData;
            pData = pEnd;

            /* There is a varbinding so alloc pVarEntry */
            rv = snmp_alloc_varentry(pVarlist, ASN1_NULL, NULL, 0, &pVarEntry);
            SNMP_ERR_BREAK_STAT(rv, stats.snmpInGenErrs);

            /* There is a varbinding so alloc pVarEntry backup */
            rv = snmp_alloc_varentry(pVarlistBackup, ASN1_NULL, NULL, 0, &pVarEntryBackup);
            SNMP_ERR_BREAK_STAT(rv, stats.snmpInGenErrs);

            /* OID */
            rv = snmp_asn1_decode(pData, size,
                            (uint8_t *) (&pVarEntry->var->oid->sub_oid[0]), &targetLen,
                            &sign, &type, (void **) &pEnd);

            if (SNMP_RET_NOERR != rv) {
                goal_logErr("Error in decoding OID.");
                break;
            }

            pVarEntry->var->oid->len = (uint8_t) targetLen;
            size -= pEnd - pData;
            pData = pEnd;

            /* copy OID into backup */
            GOAL_MEMCPY(&pVarEntryBackup->var->oid->sub_oid[0], &pVarEntry->var->oid->sub_oid[0], targetLen * sizeof(pVarEntry->var->oid->sub_oid[0]));
            pVarEntryBackup->var->oid->len = (uint8_t) targetLen;

            /* Var value */
            targetLen = SNMP_VAR_MAX_DATA;
            rv = snmp_asn1_decode(pData, size, &(pVarEntry->var->data[0]),
                            &targetLen, &sign, &type, (void **) &pEnd);

            if (SNMP_RET_NOERR != rv) {
                goal_logErr("Error in decoding of ASN1 sequence");
                break;
            }

            pVarEntry->var->type = type;
            pVarEntry->var->size = targetLen;
            pVarEntry->var->sign = sign;
            size -= pEnd - pData;
            pData = pEnd;

            /* copy data into backup */
            GOAL_MEMCPY(&pVarEntryBackup->var->data[0], &pVarEntry->var->data[0], targetLen * sizeof(pVarEntry->var->data[0]));
            pVarEntryBackup->var->type = type;
            pVarEntryBackup->var->size = targetLen;
            pVarEntryBackup->var->sign = sign;

        }

    }

    /* free varlist if any error occurred */
    if (SNMP_RET_NOERR != rv) {
        rvFree = snmp_free_varlist(pVarlist);
        if (SNMP_RET_NOERR != rvFree) {
            goal_logErr("Could not free variable list.");
        }
        rvFree = snmp_free_varlist(pVarlistBackup);
        if (SNMP_RET_NOERR != rvFree) {
            goal_logErr("Could not free variable list backup.");
        }
        return rv;
    }

    /* add varlist to massage variable */
    pMsg->list = pVarlist;
    pMsg->pListBackup = pVarlistBackup;

    return rv;
}


/****************************************************************************/
/** Processes an SNMP GET message
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_process_get(
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    SNMP_VARENTRY_T *pEntry = pMsg->list->head;  /* varBindList entry */
    uint32_t *pOid;                              /* OID of reveived message */
    uint32_t *pTableOid;                         /* part of OID used for table */
    uint32_t index = 1;                          /* index of current varBindList entry */
    SNMP_MIB_NODE_T *pNode = NULL;               /* current node */

    while (pEntry != NULL) {
        pOid = (uint32_t *) &(pEntry->var->oid->sub_oid);

        /* First we check for simple node */
        snmp_mib_find_node(pOid, pEntry->var->oid->len, &pNode);
        if ((pNode != NULL) &&  (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET)) {
            pNode->child.handler.pSimpleHandler->getHandler(pMsg, pEntry);
        }
        else
        {
            /* Not a simple node so search for a table node */
            snmp_mib_find_table_node(pOid, pEntry->var->oid->len, &pNode, &pTableOid);
            if (pNode != NULL ) {
                /* This should be a table node */
                pMsg->index_oid = pTableOid+1;
                pMsg->index_oid_len = (uint8_t) (pEntry->var->oid->len - (pTableOid + 1 - pOid));
                SNMP_LOG("index len: %u\n",pMsg->index_oid_len);
                snmp_process_table(pNode, pMsg, pEntry, SNMP_CMD_GET, SNMP_CMD_GET);
                if (SNMP_NOERR != pMsg->error) {
                    pMsg->error_index = index;
                    return SNMP_RET_NOERR;
                }
            }
            else {
                pEntry->var->error_code = SNMP_VAR_NOSUCHOBJECT;
            }
        }
        pNode = NULL;
        stats.snmpInTotalReqVars++;
        /* Time for next pEntry */
        pEntry = pEntry->next;
        index++;
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Internal SNMP GETNEXT message processing
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_getnext_intern(
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_VARENTRY_T *pEntry                      /**< Varlist */
)
{
    uint32_t *pOid;                              /* current OID */
    uint16_t lenOid = pEntry->var->oid->len;     /* OID length */
    SNMP_OID_T origOid;                          /* OID of received request */
    SNMP_RET_T ret = SNMP_RET_RESOURCE;          /* SNMP return value */
    SNMP_MIB_NODE_T *pNode = NULL;               /* current node */
    SNMP_MIB_NODE_T *pLast;                      /* last node */

    pOid = (uint32_t *) &(pEntry->var->oid->sub_oid);
    SNMP_MEMCPY(&origOid, pOid, sizeof(SNMP_OID_T));
    GOAL_BOOL_T flgExactMatch = GOAL_TRUE;

    /* get first node using lexicographically at least given OID */
    ret = snmp_mib_find_node_with_at_least_oid(&pOid, &lenOid, &pNode, &flgExactMatch);
    if (SNMP_RET_NOERR != ret) {
        goal_logErr("Error while getting next node for SNMP GETNEXT");
        return ret;
    }

    /* check for end of table */
    if (NULL == pNode) {
        pEntry->var->error_code = SNMP_VAR_ENDOFMIBVIEW;
        return ret;
    }

    /* if hit a simple node exactly, go to next node */
    if (flgExactMatch && (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET)) {
        lenOid = 0;
        pLast = pNode;
        snmp_mib_get_next_node(pLast, &pNode);

        /* check for end of table */
        if (NULL == pNode) {
            pEntry->var->error_code = SNMP_VAR_ENDOFMIBVIEW;
            return ret;
        }

        flgExactMatch = GOAL_FALSE;
    }

    /* go to next node with get handler */
    if (!(pNode->flags & (SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET | SNMP_MIB_NODE_FLAG_HAS_TABLE_GET))) {
        if (0 == lenOid) {
            pLast = pNode;
            snmp_mib_get_next_node(pLast, &pNode);
        }
        else {
            return SNMP_RET_RESOURCE;
        }
    }

    /* store found node OID in var and update index oid pointer */
    if (!(flgExactMatch && (0 < lenOid))) {
        snmp_get_oid_for_node(pNode, pEntry->var->oid);
        pOid = (uint32_t *) &(pEntry->var->oid->sub_oid[pEntry->var->oid->len]);
    }

    /* store index OID in pMsg */
    pMsg->index_oid = pOid;
    pMsg->index_oid_len = lenOid;

    /* clear errors */
    pMsg->error = SNMP_NOERR;

    /* hit simple node */
    if (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET) {
        ret = pNode->child.handler.pSimpleHandler->getHandler(pMsg, pEntry);
    }

    /* hit table node */
    else if (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_TABLE_GET) {
        ret = snmp_process_table(pNode, pMsg, pEntry, SNMP_CMD_GETNEXT, SNMP_CMD_GETNEXT);
        if ((SNMP_RET_NOERR != ret) || (SNMP_NOERR != pMsg->error)) {
            /* store current index OID length in case of changing in snmp_process_table */
            lenOid = pMsg->index_oid_len;
        }
    }

    /* hit no valid node */
    else  {
        goal_logWarn("Did not find matching node using get next. Trying again.");
        /* get next node */
        pEntry->var->oid->len -= lenOid;
        pEntry->var->oid->sub_oid[pEntry->var->oid->len - 1]++;
        return snmp_getnext_intern(pMsg, pEntry);
    }

    /* check for errors */
    if ((SNMP_RET_NOERR != ret) || (SNMP_NOERR != pMsg->error)) {
        /* did not find node (e.g. it was not accessible ) */
        pEntry->var->oid->len -= lenOid;
        pEntry->var->oid->sub_oid[pEntry->var->oid->len - 1]++;
        return snmp_getnext_intern(pMsg, pEntry);
    }
    else if ((SNMP_V1 == pMsg->version) && (ASN1_COUNTER64 == pEntry->var->type)) {
        /* skip Counter64 values fpr SNMP v1 */
        pEntry->var->oid->len -= lenOid;
        pEntry->var->oid->sub_oid[pEntry->var->oid->len - 1]++;
        return snmp_getnext_intern(pMsg, pEntry);
    }
    else {
        /* success, update stats */
        stats.snmpInTotalReqVars++;
        return SNMP_RET_NOERR;
    }
}


/****************************************************************************/
/** Processes an SNMP GETBULK message
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_process_getbulk(
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    uint16_t index;                              /* index of current varBindList entry */
    SNMP_RET_T ret = SNMP_RET_NOERR;             /* SNMP return value */
    SNMP_VARENTRY_T *pNext;                      /* next var Entry */
    SNMP_VARENTRY_T *pEntry = pMsg->pListBackup->head; /* current var entry */
    SNMP_VARLIST_T *pListReply = NULL;           /* replay varBindList */
    SNMP_VARENTRY_T *pEntryRepeat;               /* pEntry to repeat */

    /* free prepared reply list */
    if (NULL != pMsg->list) {
        snmp_free_varlist(pMsg->list);
    }

    /* allocate new anser varBindList */
    ret = snmp_alloc_varlist(&pListReply);
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* first get all non-repetitive variables */
    for (index = 0; index < pMsg->nonrep; index++) {

        /* check if request contains enough varBindList entries */
        if (NULL == pEntry) {
            snmp_free_varlist(pListReply);
            return SNMP_RET_PARAM;
        }

        /* alloc answer varBindList entry */
        ret = snmp_alloc_varentry(pListReply, pEntry->var->type, pEntry->var->oid->sub_oid, pEntry->var->oid->len, &pNext);
        if (SNMP_RET_NOERR != ret) {
            snmp_free_varlist(pListReply);
            return ret;
        }

        /* call get next for new entry */
        ret = snmp_getnext_intern(pMsg, pNext);
        if (SNMP_RET_NOERR != ret) {
            snmp_free_varlist(pListReply);
            return ret;
        }

        /* repeat with next entry */
        pEntry = pEntry->next;
    }

    /* Now proceed with the repetitive vars */
    SNMP_LOG("Repetitiv: %u\n", pMsg->maxrep);
    while (NULL != pEntry){
        pEntryRepeat = pEntry;
        for(index = 0; index < pMsg->maxrep; index++) {
            SNMP_LOG("Repetitiv loop %u\n", index);
            ret = snmp_alloc_varentry(pListReply, pEntryRepeat->var->type, pEntryRepeat->var->oid->sub_oid, pEntryRepeat->var->oid->len, &pNext);
            if (SNMP_RET_NOERR != ret) {
                snmp_free_varlist(pListReply);
                return ret;
            }
            ret = snmp_getnext_intern(pMsg, pNext);
            if (SNMP_VAR_ENDOFMIBVIEW == pNext->var->error_code) {
                index = (uint16_t) pMsg->maxrep;
            }
            else {
                pEntryRepeat = pNext;
            }
        }
        pEntry = pEntry->next;
    }

    /* replace reply list */
    pMsg->list = pListReply;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Processes table request and delegate it to the according handler
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
static SNMP_RET_T snmp_process_table(
    SNMP_MIB_NODE_T *pnode,                      /**< MIB node */
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_VARENTRY_T *pEntry,                     /**< Varentry */
    SNMP_CMD_T cmd,                              /**< Table cmd */
    SNMP_CMD_T specCmd                           /**< Spec. table cmd */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;             /* SNMP return value */

    switch (cmd) {
        case SNMP_CMD_GETNEXT:
        case SNMP_CMD_GET:
            ret = pnode->child.handler.pTableHandler->getHandler(pMsg, pEntry, cmd);
            break;
        case SNMP_CMD_SET:
            ret = pnode->child.handler.pTableHandler->setHandler(pMsg, pEntry, specCmd);
            break;
        default:
            ret = SNMP_RET_PARAM;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Constructs the full OID tree for a given node
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
static SNMP_RET_T snmp_get_oid_for_node(
    SNMP_MIB_NODE_T *pNode,                      /**< MIB node */
    SNMP_OID_T *pOid                             /**< OID */
)
{
    uint32_t revoid[128];                        /* calculated OID in reversed order */
    SNMP_MIB_NODE_T *pCurrent = pNode;           /* current node */
    SNMP_MIB_NODE_T *pParent;                    /* parent node */
    uint8_t cnt = 0;                             /* counter */
    int cntRev;                                  /* counter in reverse direction */

    GOAL_MEMSET(&revoid, 0, sizeof(revoid));
    revoid[0] = pNode->oid;

    /* Walk up the tree and build the reverse OID */
    SNMP_MIB_GET_PARENT(pParent, pCurrent);
    while (NULL != pParent) {
        cnt++;
        pCurrent = pParent;
        revoid[cnt] = pCurrent->oid;
        SNMP_MIB_GET_PARENT(pParent, pCurrent);
    }
    pOid->len = cnt;

    /* Ignore the highest node, it's only our root */
    cntRev = cnt-1;
    GOAL_MEMSET(pOid->sub_oid, 0, sizeof(pOid->sub_oid));

    /* Reverse copy the OID to the target */
    cnt = 0;
    while(0 <= cntRev){
        pOid->sub_oid[cnt] = revoid[cntRev];
        if (0 != cntRev) {
            cntRev--;
        }
        else {
            break;
        }

        cnt++;
    }

    /* Everything is fine */
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Processes an SNMP GETNEXT message
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_process_getnext(
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;             /* SNMP return value */
    SNMP_VARENTRY_T *pEntry = pMsg->list->head;  /* variable entry */
    SNMP_OID_T *pOid;                            /* OID of received message */
    uint32_t *pIndexOid;                         /* index OID */
    uint16_t indexOidLen;                        /* length of Index OID */

    while (NULL != pEntry) {

        /* store OID */
        ret = snmp_alloc_oid(&pOid);
        if (SNMP_RET_NOERR != ret) {
            goal_logErr("Could not allocate memory for calculating next OID");
            return ret;
        }
        pOid->len = pEntry->var->oid->len;
        GOAL_MEMCPY(pOid->sub_oid, pEntry->var->oid->sub_oid, pOid->len * sizeof(*pOid->sub_oid));
        pIndexOid = pMsg->index_oid;
        indexOidLen = pMsg->index_oid_len;

        /* forward getnext request */
        ret = snmp_getnext_intern(pMsg, pEntry);

        if (SNMP_RET_NOERR != ret) {
            pEntry = NULL;
        }
        else {
            /* restore requested OID if end of MIB is reached */
            if (SNMP_VAR_ENDOFMIBVIEW == pEntry->var->error_code) {
                pEntry->var->oid->len = pOid->len;
                GOAL_MEMCPY(pEntry->var->oid->sub_oid, pOid->sub_oid, pOid->len * sizeof(*pOid->sub_oid));
                pMsg->index_oid = pIndexOid ;
                pMsg->index_oid_len = indexOidLen;
            }
            /* Time for next entry */
            pEntry = pEntry->next;
        }

        /* release stored OID */
        snmp_free_oid(pOid);
    }
    return ret;
}


/****************************************************************************/
/** Processes all vars of a varlist
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
static SNMP_RET_T snmp_for_all_varlist_entries(
    SNMP_MSG_T *pMsg,                            /**< Message */
    SNMP_CMD_T cmd,                              /**< Command */
    SNMP_CMD_T specCmd,                          /**< Specific command */
    uint32_t endIndex,                           /**< Last index to process */
    uint32_t *lastIndex                          /**< Last index processed */
)
{
    SNMP_VARENTRY_T *pEntry = pMsg->list->head;  /* variable entry */
    uint32_t *pOid;                              /* OID */
    uint32_t *pTableOid;                         /* part of OID used for table */
    uint32_t index = 1;                          /* index of var entry */
    SNMP_RET_T result = SNMP_RET_NOERR;          /* SNMP result */
    SNMP_MIB_NODE_T *pNode = NULL;               /* current node */

    /* The first run checks whether all data to set is valid */
    while (pEntry != NULL && endIndex != index){
        *lastIndex = index;
        pOid = (uint32_t *) &(pEntry->var->oid->sub_oid);

        /* First we check whether the var is a table entry */
        snmp_mib_find_table_node(pOid, pEntry->var->oid->len, &pNode, &pTableOid);
        if (NULL != pNode) {

            /* This should be a table node */
            pMsg->index_oid = pTableOid+1;
            pMsg->index_oid_len = (uint8_t) (pEntry->var->oid->len - (pTableOid + 1 - pOid));
            SNMP_LOG("index len: %u\n",pMsg->index_oid_len);
            snmp_process_table(pNode,pMsg, pEntry, cmd, specCmd);
            if (0 != pMsg->error) {
                pMsg->error_index = index;
                return SNMP_RET_NOERR;
            }
        }
        else{
            /* Not a table node so search for a node entry */
            snmp_mib_find_node(pOid, pEntry->var->oid->len, &pNode);

            if (pNode == NULL ){
                pMsg->error = SNMP_ERR_NO_ACCESS;
                pMsg->error_index = index;
                return SNMP_RET_NOERR;
            }else{
                if (!(pNode->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_SET)){
                    pMsg->error = SNMP_ERR_NOT_WRITABLE;
                    pMsg->error_index = index;
                }
                else {
                    /* Let the set handler check for type and value */
                    if (SNMP_RET_NOERR != pNode->child.handler.pSimpleHandler->setHandler(pMsg, pEntry, cmd)){
                        pMsg->error_index = index;
                        return SNMP_RET_NOERR;
                    }
                }
            }
        }
        index++;
        pEntry = pEntry->next;
    }
    return result;
}


/****************************************************************************/
/** Processes an SNMP SET message
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_process_set(
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    SNMP_RET_T rv;                               /* SNMP result */
    uint32_t lastindex;                          /* last index */

    /* check for settable values */
    rv = snmp_for_all_varlist_entries(pMsg, SNMP_CMD_SET, SNMP_CMD_VALUE, pMsg->list->entry_count, &lastindex);
    stats.snmpInTotalSetVars += lastindex;

    /* set values */
    if (SNMP_RET_NOERR == rv) {
        rv = snmp_for_all_varlist_entries(pMsg, SNMP_CMD_SET, SNMP_CMD_SET, pMsg->list->entry_count, &lastindex);
    }

    if (SNMP_RET_NOERR == rv) {
        /* commit new values */
        rv = snmp_for_all_varlist_entries(pMsg, SNMP_CMD_SET, SNMP_CMD_COMMIT, pMsg->list->entry_count, &lastindex);
    }
    else {
        /* restore old values */
        rv = snmp_for_all_varlist_entries(pMsg, SNMP_CMD_SET, SNMP_CMD_UNDO, lastindex, &lastindex);
        pMsg->error = SNMP_ERR_COMMIT_FAILED;
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Returns a pointer to the statistics of the SNMP stack.
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_STATS_T *snmp_get_statistics(
    void
)
{
    return &stats;
}


/****************************************************************************/
/** Sends a SNMPv2c trap to the given IP using a cold start
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_trapsInit(
    uint32_t trapSink                            /**< trap sink IP address */
)
{
    snmpTrapSink = trapSink;
    snmp_send_trap_v2(snmpTrapSink, SNMP_CONF_NET_TRAP_REMOTE_PORT, (uint32_t *) &snmpColdStartTrap_OID , OID_COLDSTART_LEN, NULL);
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Checks if a given OID is lexicographically smaller than the second one.
 * A list of ignored index entry can be used to ignore entries completly.
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_oidIsSmaller(
    uint32_t *pLeftOid,                          /**< left OID in relation */
    uint32_t lenLeftOid,                         /**< length of left OID */
    uint32_t *pRightOid,                         /**< right OID in relation */
    uint32_t lenRightOid,                        /**< length of right OID */
    uint32_t *pIgnoreList,                       /**< list of indexes for sub OIDs to ignore in comparison */
    uint32_t lenIgnoreList,                      /**< number of sub OIDs to ignore */
    GOAL_BOOL_T *pLeftSmallerRight               /**< OID comparison result  */
)
{
    uint32_t len;                                /* length of shorter OID */
    uint32_t cnt;                                /* counter for index entries */
    uint32_t cntIgnore;                          /* counter for ignore list */
    GOAL_BOOL_T flgIgnoreEntry;                  /* ignore current entry flag */

    *pLeftSmallerRight = GOAL_TRUE;

    /* get maximal length checking OID entries */
    len = (lenLeftOid < lenRightOid) ? lenLeftOid : lenRightOid;

    /* check for length == 0 */
    if (0 == len) {
        *pLeftSmallerRight = (lenRightOid == 0) ? GOAL_FALSE : GOAL_TRUE;
        return SNMP_RET_NOERR;
    }

    /* check if sub OID index 0 shall be ignored */
    flgIgnoreEntry = GOAL_FALSE;
    for (cntIgnore = 0; cntIgnore < lenIgnoreList; cntIgnore ++) {
        if (0 == *(pIgnoreList + cntIgnore)) {
            flgIgnoreEntry = GOAL_TRUE;
        }
    }

    /* compare sub OIDs */
    for (cnt = 0; cnt < len; cnt++) {
        flgIgnoreEntry = GOAL_FALSE;
        /* check if current sub OID index shall be ignored */
        for (cntIgnore = 0; cntIgnore < lenIgnoreList; cntIgnore ++) {
            if (*(pIgnoreList + cntIgnore) == cnt) {
                flgIgnoreEntry = GOAL_TRUE;
            }
        }
        if (!flgIgnoreEntry) {
            /* smaller OID entry found, left is smaller than right */
            if (pLeftOid[cnt] < pRightOid[cnt]) {
                *pLeftSmallerRight = GOAL_TRUE;
                return SNMP_RET_NOERR;
            }
            /* bigger OID entry found, left is bigger than right */
            if (pLeftOid[cnt] > pRightOid[cnt]) {
                *pLeftSmallerRight = GOAL_FALSE;
                return SNMP_RET_NOERR;
            }
        }
    }

    /* all len entry are equal, the shorter OID is smaller */
    *pLeftSmallerRight = (lenLeftOid < lenRightOid) ? GOAL_TRUE : GOAL_FALSE;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Map SNMP v2c response to snmp v1 response
 *
 * SNMP v2c is more complex than v1. Maps v2c respoinses contining v2c specific
 * error codes, data types and exceptions into v1 responses.
 *
 * See RFC 2089 for more information.
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_responseMapToV1(
    SNMP_MSG_T *pMsg                             /**< Message */
)
{
    SNMP_VARENTRY_T *pVar;                       /* verlist entry */
    uint32_t errorIndex;                         /* error index */

    /* mapping of error status */
    switch(pMsg->error) {
        case SNMP_NOERR:
        case SNMP_ERR_RESP_TOO_LARGE:
        case SNMP_ERR_NAME_NOT_FOUND:
        case SNMP_ERR_TYPE_MISMATCH:
        case SNMP_ERR_READ_ONLY:
        case SNMP_ERR_GENERAL_ERROR:
          /* no change needed */
          break;

        case SNMP_ERR_WRONG_TYPE:
        case SNMP_ERR_WRONG_LENGTH:
        case SNMP_ERR_WRONG_ENCODING:
        case SNMP_ERR_WRONG_VALUE:
        case SNMP_ERR_INCONSISTENT_VALUE:
            /* set error code to badValue */
            pMsg->error = SNMP_ERR_TYPE_MISMATCH;
            break;

        case SNMP_ERR_NO_ACCESS:
        case SNMP_ERR_NO_CREATION:
        case SNMP_ERR_AUTH:
        case SNMP_ERR_NOT_WRITABLE:
        case SNMP_ERR_INCONSISTENT_NAME:
            /* set error code to noSuchName */
            pMsg->error = SNMP_ERR_NAME_NOT_FOUND;
            break;

        case SNMP_ERR_RESOURCE_UNAVAIL:
        case SNMP_ERR_COMMIT_FAILED:
        case SNMP_ERR_UNDO_FAILED:
            /* set error code to genErr */
            pMsg->error = SNMP_ERR_GENERAL_ERROR;
            break;
    }

    /* mapping of exceptions */
    pVar = pMsg->list->head;
    errorIndex = 1;
    while (NULL != pVar) {
        if ((SNMP_VAR_NOSUCHOBJECT == pVar->var->error_code) ||
            (SNMP_VAR_NOSUCHINSTANCE == pVar->var->error_code) ||
            (SNMP_VAR_ENDOFMIBVIEW == pVar->var->error_code)) {
            /* map noSuchObject, noSuchInstance and endOfMibView to noSuchName error */
            pMsg->error = SNMP_ERR_NAME_NOT_FOUND;
            pMsg->error_index = errorIndex;
            /* clear error exception */
            pVar->var->error_code = SNMP_VAR_NOERR;
        }
        errorIndex++;
        pVar = pVar->next;
    }

    /* do not allow COUNTER64 type in GET requests */
    if (SNMP_MSG_GET == pMsg->type) {
        pVar = pMsg->list->head;
        errorIndex = 1;
        while (NULL != pVar) {
            if (ASN1_COUNTER64 == pVar->var->type) {
                /* map noSuchObject, noSuchInstance and endOfMibView to noSuchName error */
                pMsg->error = SNMP_ERR_NAME_NOT_FOUND;
                pMsg->error_index = errorIndex;
            }
            errorIndex++;
            pVar = pVar->next;
        }
    }

    return SNMP_RET_NOERR;
}
