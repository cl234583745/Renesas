/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_DEBUG_H_
#define SNMP_DEBUG_H_


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
void snmp_debug_print_entry_list(
    SNMP_VARLIST_T *pList                       /**< Var list */
);

void snmp_debug_print_entry_type(
    ASN1_TYPE asn                               /**< ASN.1 type */
);

void snmp_debug_print_tree(
    SNMP_MIB_NODE_T *pNode,                     /**< Start node */
    int indent                                  /**< Indent */
);

#endif /* SNMP_DEBUG_H_ */
