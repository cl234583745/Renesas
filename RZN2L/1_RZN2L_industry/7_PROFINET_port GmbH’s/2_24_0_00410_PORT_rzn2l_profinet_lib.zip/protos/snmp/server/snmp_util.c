/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_SNMP_UTIL_INTERFACE_STR_FORMAT     "eno%"FMT_u32


/****************************************************************************/
/** Returns interface name for given interface index
 *
 * @returns GOAL_OK successful
 * @returns other fail
 */
GOAL_STATUS_T goal_snmpGetInterface(
    uint32_t idInterface,                       /**< interface id */
    uint32_t maxSize,                           /**< max possible size of interface name storage */
    char **pStrInterface                        /**< pointer where interface name will be written */
)
{
    const char *strInterface;                   /* interface name string */

    /* only one target interface is supported */
    if (idInterface == 0)
    {
        strInterface = goal_targetGetInterface();
        if (GOAL_STRLEN(strInterface) != 0) {
            GOAL_STRNCPY(*pStrInterface, strInterface, maxSize);
            return GOAL_OK;
        }
    }
    GOAL_SNPRINTF(*pStrInterface, maxSize, GOAL_SNMP_UTIL_INTERFACE_STR_FORMAT, idInterface);

    return GOAL_OK;

}
