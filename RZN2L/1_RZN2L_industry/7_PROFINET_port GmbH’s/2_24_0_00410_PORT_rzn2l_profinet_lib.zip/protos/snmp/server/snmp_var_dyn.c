/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#ifndef SNMP_CONF_STATICVARS


/****************************************************************************/
/** Allocates an OID structure using dyn. memory allocation.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T dyn_alloc_snmp_oid(
    SNMP_OID_T **oid                            /**< OID */
)
{
    SNMP_OID_T *o = (SNMP_OID_T *) MALLOC(sizeof(SNMP_OID_T));
    if (o==NULL) return SNMP_RET_RESOURCE;
    o->len = 0;
    *oid = o;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Frees an OID.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T dyn_free_snmp_oidSNMP_RET_T static_free_snmp_oid(
    SNMP_OID_T *oid                             /**< OID */
)
{
    FREE(oid);
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Allocates a var list using dyn. memory allocation.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T dyn_alloc_snmp_varlist(
    SNMP_VARLIST_T **list                       /**< Var list */
)
{
    SNMP_VARLIST_T *vl = (SNMP_VARLIST_T *) MALLOC(
            sizeof(SNMP_VARLIST_T));
    if (vl == NULL)
    return SNMP_RET_RESOURCE;
    vl->head = NULL;
    vl->tail = NULL;
    *list = vl;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Allocates a varentry in the given list using dyn. memory allocation.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
 */
SNMP_RET_T dyn_alloc_snmp_varentry(
    SNMP_VARLIST_T *list,                       /**< Var list */
    ASN1_TYPE type,                             /**< ASN.1 type */
    uint32_t *oid,                              /**< OID */
    uint8_t oid_len,                            /**< OID length */
    SNMP_VARENTRY_T **entry                     /**< Var entry */
)
{
    SNMP_VAR_T *var;
    OID* new_oid;
    SNMP_VARENTRY_T *vl = (SNMP_VARENTRY_T *) MALLOC(
            sizeof(SNMP_VARENTRY_T));
    if (vl == NULL)
    return SNMP_RET_RESOURCE;
    var = (SNMP_VAR_T *) MALLOC(sizeof(SNMP_VAR_T));
    if (vl == NULL) {
        FREE(vl);
        return SNMP_RET_RESOURCE;
    }

    vl->var = var;
    SNMP_MEMSET(&(var->data[0]),0,4*128);
    if (oid!=NULL) {
        new_oid = (SNMP_OID_T *) MALLOC(sizeof(SNMP_OID_T));
        if (new_oid==NULL) {
            FREE(var);
            FREE(vl);
            return SNMP_RET_RESOURCE;
        }
        vl->var->oid = new_oid;
        SNMP_MEMCPY(&(vl->var->oid->sub_oid),oid,sizeof(uint32_t)*oid_len);
        vl->var->oid->len = oid_len;
    }
    /* Insert entry into list */
    if (list->head == NULL) {
        list->head = vl;
        list->tail = vl;
    } else {
        list->tail->next = vl;
        vl->prev = list->tail;
        list->tail = vl;
    }
    *entry = vl;
    vl->var->type = type;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Frees an entry.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T dyn_free_snmp_varentry(
    SNMP_VARENTRY_T *entry                      /**< Var entry */
)
{
    FREE(entry->var->oid);
    FREE(entry->var);
    FREE(entry);
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Frees a varlist incl. all var entries.
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T dyn_free_snmp_varlist(
    SNMP_VARLIST_T *list                        /**< Var list */
)
{
    SNMP_VARENTRY_T *current;
    SNMP_VARENTRY_T *entry = list->head;
    while (entry != NULL) {
        current = entry;
        entry = entry->next;
        dyn_free_snmp_varentry(current);
    }
    FREE(list);
    return SNMP_RET_NOERR;
}
#endif
