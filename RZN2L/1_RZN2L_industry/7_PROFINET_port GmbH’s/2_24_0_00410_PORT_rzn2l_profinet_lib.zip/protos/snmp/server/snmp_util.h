/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_UTIL_H
#define SNMP_UTIL_H


/****************************************************************************/
/* Defines */
/****************************************************************************/
#ifdef CONFIG_SNMP_LOGGING
#  define SNMP_LOG(...) printf(__VA_ARGS__)
#else
#  define SNMP_LOG(...)
#endif


/****************************************************************************/
/* Macros */
/****************************************************************************/
#define GOAL_SNMP_IP_ADDR_FROM_OID(pOid) \
    ((*(pOid) & 0xFF) << 24) |  ((*(pOid + 1) & 0xFF) << 16) | ((*(pOid + 2) & 0xFF) << 8) | (*(pOid + 3) & 0xFF)

#define GOAL_SNMP_IP_ADDR_TO_OID(pOid, ip) \
    *(pOid) = (ip >> 24) & 0xFF; \
    *(pOid + 1) = (ip >> 16) & 0xFF; \
    *(pOid + 2) = (ip >> 8) & 0xFF; \
    *(pOid + 3) = (ip & 0xFF);


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_snmpGetInterface(
    uint32_t idInterface,                       /**< interface id */
    uint32_t maxSize,                           /**< max possible size of interface name storage */
    char **pStrInterface                        /**< pointer where interface name will be written */
);

#endif /* SNMP_UTIL_H */
