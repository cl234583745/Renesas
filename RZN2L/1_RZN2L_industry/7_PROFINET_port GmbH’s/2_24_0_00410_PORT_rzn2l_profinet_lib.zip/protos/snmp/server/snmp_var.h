/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_VAR_H
#define SNMP_VAR_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define snmp_alloc_varlist      static_alloc_snmp_varlist
#define snmp_alloc_varentry     static_alloc_snmp_varentry
#define snmp_free_varlist       static_free_snmp_varlist
#define snmp_free_varentry      static_free_snmp_varentry
#define snmp_alloc_oid          static_alloc_snmp_oid
#define snmp_free_oid           static_free_snmp_oid


/****************************************************************************/
/* Allocation Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_alloc_varlist(
    SNMP_VARLIST_T **list                       /**< Var list */
);

SNMP_RET_T snmp_alloc_varentry(
    SNMP_VARLIST_T *list,                       /**< Var list */
    ASN1_TYPE type,                             /**< ASN.1 type */
    uint32_t *oid,                              /**< OID */
    uint8_t oid_len,                            /**< OID length */
    SNMP_VARENTRY_T **entry                     /**< Var entry */
);

SNMP_RET_T snmp_free_varentry(
    SNMP_VARENTRY_T *entry                      /**< Var entry */
);

SNMP_RET_T snmp_free_varlist(
    SNMP_VARLIST_T *list                        /**< Var list */
);

SNMP_RET_T snmp_alloc_oid(
    SNMP_OID_T **oid                            /**< OID */
);

SNMP_RET_T static_free_snmp_oid(
    SNMP_OID_T *oid                             /**< OID */
);


/****************************************************************************/
/* general Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_set_var_value(
    SNMP_VARENTRY_T *entry,                     /**< Variable */
    uint8_t *value,                             /**< Value */
    uint16_t size,                              /**< Value data size */
    uint8_t sign                                /**< Sign for integers */
);

SNMP_RET_T snmp_set_var_value_type(
    SNMP_VARENTRY_T *entry,                     /**< Variable */
    uint8_t *value,                             /**< Value */
    uint16_t size,                              /**< Value data size */
    uint8_t sign,                               /**< Sign for integers */
    ASN1_TYPE type                              /**< ASN.1 type */
);

SNMP_RET_T snmp_calc_var_enc_len(
    SNMP_VARLIST_T *list,                       /**< Var list */
    uint32_t *len                               /**< Calculated length */
);

#endif /* SNMP_VAR_H */
