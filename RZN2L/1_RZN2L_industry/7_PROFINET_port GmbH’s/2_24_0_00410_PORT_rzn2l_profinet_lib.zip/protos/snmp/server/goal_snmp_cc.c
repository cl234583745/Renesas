/** @file
 *
 * @brief
 * SNMP snmp implementation communication core backend
 *
 * @details
 * simple network protocol stack implementation.
 *
 * @copyright
 * Copyright 2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>
#include <goal_media/goal_mi_mctc.h>
#include <goal_snmp_rpc.h>

#if GOAL_CONFIG_CSAP == 1
# include "goal_snmp_csap.h"
#endif


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static GOAL_STAGE_HANDLER_T stageMod;           /**< module stage handler */
static GOAL_RPC_HDL_CHN_T *pHdlSnmpRpc;         /**< PROFINET RPC handle (acyclic data) */

/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_snmpInitRpc(
    void
);

#undef GOAL_SNMP_FUNC_ENTRY
#define GOAL_SNMP_FUNC_ENTRY(id, name, func) \
    static GOAL_STATUS_T func( \
        GOAL_RPC_HDL_T *pHdlRpc                 /**< RPC handle */ \
    );

GOAL_SNMP_FUNC_LIST


/****************************************************************************/
/* Function and parameter mappings */
/****************************************************************************/
/**< id to function mapping */
typedef struct {
    unsigned int id;                            /**< function id */
    GOAL_RPC_FUNC_T pFunc;                      /**< function ptr */
} GOAL_SNMP_FUNC_PTR_T;

/* id to function mapping */
#undef GOAL_SNMP_FUNC_ENTRY
#define GOAL_SNMP_FUNC_ENTRY(id, name, func) { id, func },
static GOAL_SNMP_FUNC_PTR_T goal_snmpTblFunc[] = {
    GOAL_SNMP_FUNC_LIST
};


/****************************************************************************/
/** SNMP target register config manager variables
 *
 * This function registers config manager variables
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_snmpInitCc(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    /* initialize SNMP stack */
    res = goal_snmpInitImpl();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to initialize SNMP stack");
        return res;
    }

    /* register modules stage for SNMP RPC initialization */
    res = goal_mainStageReg(GOAL_STAGE_MODULES, &stageMod, GOAL_STAGE_INIT, goal_snmpInitRpc);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register in modules stage");
        return res;
    }

    return res;
}


/****************************************************************************/
/** Setup PROFINET RPC Application Core Functionality
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_snmpInitRpc(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    unsigned int cnt;                           /* counter */

    /* setup RPC channel for acyclic data exchange */
    res = goal_rpcSetupChannel(&pHdlSnmpRpc, GOAL_ID_MI_CTC_DEFAULT);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to setup RPC channel");
        return res;
    }

    /* register RPC functions */
    for (cnt = 0; cnt < ARRAY_ELEMENTS(goal_snmpTblFunc); cnt++) {
        res = goal_rpcRegisterService(GOAL_ID_SNMP, (GOAL_RPC_FUNC_ID) goal_snmpTblFunc[cnt].id, goal_snmpTblFunc[cnt].pFunc);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("failed to register SNMP RPC function nr %u", goal_snmpTblFunc[cnt].id);
            return res;
        }
    }

#if GOAL_CONFIG_CSAP == 1
    if (GOAL_RES_OK(res)) {
        res = snmp_csapReg();
    }
#endif

    goal_logInfo("SNMP Communication Core successfully started");

    return GOAL_OK;
}


/****************************************************************************/
/** Register SNMP community strings
 *
 * Store the given cumminity strings.
 *
 * RPC call parameters:
 *   1. read community string length
 *   2. read community string (without NULL terminator)
 *   3. write community string length
 *   4. write community string (without NULL terminator)
 *
 * @returns GOAL_STATUS_T value
 */
static GOAL_STATUS_T goal_snmpRpcCommSet(
    GOAL_RPC_HDL_T *pHdlRpc                     /**< RPC handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    uint16_t lenReadCommunity = 0;              /* read community string length */
    char strReadCommunity[SNMP_CONF_MAX_COMMUNITY_LEN + 1]; /* read community string */
    uint16_t lenWriteCommunity = 0;             /* write community string length */
    char strWriteCommunity[SNMP_CONF_MAX_COMMUNITY_LEN + 1]; /* write community string */

    GOAL_RPC_POP(lenReadCommunity, uint16_t);
    GOAL_RPC_POP_PTR(strReadCommunity, lenReadCommunity);
    strReadCommunity[lenReadCommunity] = 0;

    GOAL_RPC_POP(lenWriteCommunity, uint16_t);
    GOAL_RPC_POP_PTR(strWriteCommunity, lenWriteCommunity);
    strWriteCommunity[lenWriteCommunity] = 0;

    res = goal_snmpCommSet(NULL, strReadCommunity, strWriteCommunity);

    return res;
}


/****************************************************************************/
/** Initializes SNMP traps
 *
 * RPC call parameters:
 *   1. Trapsink (IP address)
 *
 * @returns GOAL_STATUS_T value
 */
static GOAL_STATUS_T goal_snmpRpcTrapsInit(
    GOAL_RPC_HDL_T *pHdlRpc                     /**< RPC handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    uint32_t trapSink = 0;                      /* trap sink */

    GOAL_RPC_POP(trapSink, uint32_t);

    res = goal_snmpTrapsInit(NULL, trapSink);

    return res;
}


/****************************************************************************/
/** Create new SNMP instance
 *
 * RPC call parameters:
 *   1. Trapsink (IP address)
 *
 * @returns GOAL_STATUS_T value
 */
static GOAL_STATUS_T goal_snmpRpcNew(
    GOAL_RPC_HDL_T *pHdlRpc                     /**< RPC handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_INSTANCE_SNMP_T *pSnmpInstance = NULL; /* snmp instance */
    uint32_t id = 0;                            /* instance id */

    GOAL_RPC_POP(id, uint32_t);
    res = goal_snmpNewImpl(&pSnmpInstance, id);

    return res;
}
