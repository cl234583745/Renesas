/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_VAR_TYPES_H
#define SNMP_VAR_TYPES_H


/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef enum {
    ASN1_INTEGER = 2,
    ASN1_BITSTRING,
    ASN1_OCTET_STRING,
    ASN1_NULL,
    ASN1_OID,
    ASN1_SEQUENCE = 0x30,
    ASN1_IPADDR = 0x40,
    ASN1_COUNTER,
    ASN1_GAUGE,
    ASN1_TIMETICKS,
    ASN1_OPAQUE,
    ASN1_NSAPADDRESS,
    ASN1_COUNTER64,
    ASN1_UINTEGER32
} ASN1_TYPE;

#endif /* SNMP_VAR_TYPES_H */
