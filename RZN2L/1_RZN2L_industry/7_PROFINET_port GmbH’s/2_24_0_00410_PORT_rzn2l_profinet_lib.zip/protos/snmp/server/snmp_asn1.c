/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/* Local variables */
/****************************************************************************/
/* Small buffer for 7bit int encoding */
static uint8_t uintbuf[5];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static uint8_t snmp_asn1_get_7bit_uint_octet_count(
    uint32_t val                                /**< Value */
);

static SNMP_RET_T asn1_decode_int32(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    uint8_t *sign,                              /**< Sign */
    void **end_ptr                              /**< End pointer */
);

static SNMP_RET_T asn1_encode_sint32(
    int32_t conv_value,                         /**< Value to convert */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
);


SNMP_RET_T asn1_decode_oid(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    void **end_ptr                              /**< End pointer */
);

static SNMP_RET_T asn1_encode_octet_string(
    ASN1_TYPE type,                             /**< ASN.1 type */
    void *string,                               /**< String to encode */
    uint32_t length,                            /**< String length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
);

static SNMP_RET_T asn1_decode_octet_string(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    void **end_ptr                              /**< End pointer */
);

static SNMP_RET_T asn1_encode_ip_string(
    char *ip,                                   /**< IP address */
    uint32_t length,                            /**< Address length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
);

static SNMP_RET_T asn1_encode_OID(
    uint32_t *oid,                              /**< OID */
    uint8_t oid_len,                            /**< OID length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
);

#define SNMP_IP_ADDR_TO_ASN1(pBuf, ip) \
    *(pBuf + 2) = *(ip + 3); \
    *(pBuf + 3) = *(ip + 2); \
    *(pBuf + 4) = *(ip + 1); \
    *(pBuf + 5) = *(ip);



/****************************************************************************/
/** Calculates the number of octets required for encoding an uint32 value
 * as an ASN.1 integer
 *
 * @returns The number of octets required to encode this uint32 value
 */
uint8_t snmp_asn1_get_uint32_octet_count(
    uint32_t val                                /**< Value */
)
{
    if (val > 0x7FFFFF)
        return 4;
    if (val > 0x7FFF)
        return 3;
    if (val > 0x7F)
        return 2;
    return 1;
}


/****************************************************************************/
/** Calculates the number of octets required for encoding an int32 value
 * as an ASN.1 integer
 *
 * @returns The number of octets required to encode this int32 value
 */
uint8_t snmp_asn1_get_int32_octet_count(
    int32_t val                                 /**< Value */
)
{
    if (val < 0)
        val = ~val;
    if (val > 0x7FFFFF)
        return 4;
    if (val > 0x7FFF)
        return 3;
    if (val > 0x7F)
        return 2;
    return 1;
}

/****************************************************************************/
/**  Calculates the number of octets required for encoding an length
 * value as an ASN.1 integer
 *
 *
 * @returns The number of octets required to encode this length value
 */
uint8_t snmp_asn1_get_len_octet_count(
    uint32_t val                                /**< Value */
)
{
	if (val > 0xFFFFFF)
		return 5;
	if (val > 0xFFFF)
		return 4;
	if (val > 0xFF)
		return 3;
    if (val > 0x7F)
		return 2;
	return 1;
}


/****************************************************************************/
/**  Calculates the number of octets required for encoding an 7bit uint OID
 * value as an ASN.1 integer
 *
 *
 * @returns The number of octets required to encode this OID value
 */
static uint8_t snmp_asn1_get_7bit_uint_octet_count(
    uint32_t val                                /**< Value */
)
{
    uint8_t cnt;                                /* counter */

    /* use allways at least one byte for encoding */
    val = val >> 7;
    cnt = 1;

    /* count number of needed 7 bit uints */
    while (val > 0)
    {
        val = val >> 7;
        cnt++;
    }

	return cnt;
}


/****************************************************************************/
/** Encodes an uint32 value as an ASN.1 integer
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code
 */
SNMP_RET_T snmp_asn1_encode_uint32(
    uint32_t conv_value,                        /**< Value to convert */
    uint8_t *buffer,                            /**< Target buffer */
    void **end_ptr,                             /**< Pointer to first byte after encoding */
    uint8_t type_override,                      /**< Type override */
    uint8_t header                              /**< Header */
)
{
    SNMP_RET_T res = SNMP_RET_ASN1_RANGE;
    uint32_t offset = 0;

    uint8_t cnt = snmp_asn1_get_uint32_octet_count(conv_value);

    /* ASN1 type */
    if (header) {
        if (!type_override)
                *buffer = (uint8_t) ASN1_INTEGER;
        else
                *buffer = (uint8_t) type_override;
        offset++;
        *(buffer + offset) = cnt;
        offset++;
    }
    if (cnt == 4) {
        *(buffer + offset + 3) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset + 2) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + offset + 1) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *(buffer + offset) = (uint8_t) HIGHBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 4);
        return res;
    }
    if (cnt == 3) {
        *(buffer + offset + 2) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset + 1) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + offset) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 3);
        return res;
    }
    if (cnt == 2) {
        *(buffer + offset + 1) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 2);
        return res;
    }
    if (cnt == 1) {
        *(buffer + offset) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 1);
        return res;
    }
    return res;
}


/****************************************************************************/
/** Encodes an length value as an ASN.1 integer
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code
 */
SNMP_RET_T snmp_asn1_encode_len(
    uint32_t conv_value,                        /**< Value to convert */
    uint8_t *buffer,                            /**< Target buffer */
    void **end_ptr,                             /**< Pointer to first byte after encoding */
    uint8_t type_override,                      /**< Type override */
    uint8_t header                              /**< Header */
)
{
    SNMP_RET_T res = SNMP_RET_ASN1_RANGE;
    uint32_t offset = 0;

    uint8_t cnt = snmp_asn1_get_len_octet_count(conv_value) - 1;

    /* ASN1 type */
    if (header) {
        if (!type_override)
                *buffer = (uint8_t) ASN1_INTEGER;
        else
                *buffer = (uint8_t) type_override;
        offset++;
        *(buffer + offset) = cnt;
        offset++;
    }
    if (cnt == 4) {
        *(buffer + offset + 3) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset + 2) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + offset + 1) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *(buffer + offset) = (uint8_t) HIGHBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 4);
        return res;
    }
    if (cnt == 3) {
        *(buffer + offset + 2) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset + 1) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + offset) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 3);
        return res;
    }
    if (cnt == 2) {
        *(buffer + offset + 1) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + offset) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 2);
        return res;
    }
    if (cnt <= 1) {
        *(buffer + offset) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + offset + 1);
        return res;
    }
    return res;
}


/****************************************************************************/
/** Decodes an ASN.1 integer into a var struct
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code
 */
static SNMP_RET_T asn1_decode_int32(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    uint8_t *sign,                              /**< Sign */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_NOERR;
    uint8_t cnt = 0;
    uint8_t *src;
    uint8_t size = 0;
    uint32_t val = 0;
    int32_t pseudo = -1;

    UNUSEDARG(len);

    if (*(buffer) != ASN1_INTEGER && *(buffer) != ASN1_GAUGE && *(buffer) != ASN1_TIMETICKS
             &&    *(buffer) != ASN1_COUNTER) {
        return SNMP_RET_ASN1_TYPEERR;
    }
    cnt = *(buffer + 1);
    if (*(buffer + 2) & 0x80) {
        *sign = 1;
        /* Fill the buffer with a negative value*/
        SNMP_MEMCPY(target, &pseudo, *target_len);
    } else {
        *sign = 0;
        SNMP_MEMSET(target,0, sizeof(uint32_t));
    }
    if (cnt == 5) {
        src = buffer + 3;
        size = cnt - 1;
    } else {
        src = buffer + 2;
        size = cnt;
    }
    /* Copy the data from buffer to var entry*/
    SNMP_MEMCPY(target+(4-size), src, size);

    /* Change to host order */
    val = NTOH32((uint32_t) *(((uint32_t *) target)));

    /* Copy data back to var entry*/
    SNMP_MEMCPY(target, &val, 4);


    *target_len = 4;

    *end_ptr = buffer +1 +cnt+1;

    return res;
}


/****************************************************************************/
/** Encodes a signed int32 value as an ASN.1 integer
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code
 */
static SNMP_RET_T asn1_encode_sint32(
    int32_t conv_value,                         /**< Value to convert */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_ASN1_RANGE;

    uint8_t cnt = snmp_asn1_get_int32_octet_count(conv_value);

    /* ASN1 type */
    *buffer = (uint8_t) ASN1_INTEGER;
    /* length */
    *(buffer + 1) = cnt;
    if (cnt == 4) {
        *(buffer + 5) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + 4) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + 3) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *(buffer + 2) = (uint8_t) HIGHBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + 6);
        return res;
    }
    if (cnt == 3) {
        *(buffer + 4) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + 3) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *(buffer + 2) = (uint8_t) LOWBYTE(HIGHWORD(conv_value));
        *end_ptr = (void *) (buffer + 5);
        return res;
    }
    if (cnt == 2) {
        *(buffer + 3) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *(buffer + 2) = (uint8_t) HIGHBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + 4);
        return res;
    }
    if (cnt == 1) {
        *(buffer + 2) = (uint8_t) LOWBYTE(LOWWORD(conv_value));
        *end_ptr = (void *) (buffer + 3);
        return res;
    }
    return res;
}


/****************************************************************************/
/** Encodes a signed int32 value as an ASN.1 integer
 *
 * @returns The number of octets used to encode this value
 */
uint8_t asn1_encode_7bit_uint(
    uint32_t val,                               /**< Value to encode */
    uint8_t *buffer                             /**< Buffer */
)
{
    uint8_t cnt;
    uint8_t i;
    // TODO: Big/little endian awareness

    /* Single or multibyte encoding */
    if (val <= 0x7f)
    {
        *(buffer) = (uint8_t) val;
        return 1;
    }
    else {
        cnt = snmp_asn1_get_7bit_uint_octet_count(val);
        for(i = cnt; i> 0; i--) {
            *(buffer+(cnt-i)) = 0x80 | ((val >> ((i-1) * 7)) & 0x7F);
        }
        *(buffer+cnt-1) = val & 0x7F;
    }
    return cnt;
}


/****************************************************************************/
/** Decodes an ASN.1 7 bit int array to an uint32_t value.
 *
 * @returns The decoded uint32_t value
 */
uint32_t snmp_asn1_decode_7bit_uint(
    uint8_t *buffer,                            /**< Buffer */
    uint32_t len,                               /**< Buffer length */
    void **end_ptr                              /**< End pointer */
)
{
    uint32_t val = 0;
    uint8_t offset = 0;

    UNUSEDARG(len);

    while (*(buffer + offset) & 0x80) {
        val = val << 7;
        val |= (*(buffer + offset) & 0x7f);
        offset++;
    }
    val=val<<7;
    val |= (*(buffer + offset) & 0x7f);
    *end_ptr = buffer + offset + 1;
    return val;
}


/****************************************************************************/
/** Decodes an OID into an uint32_t array
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_decode_oid_to_array(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint32_t *oid,                              /**< OID */
    uint16_t *oid_len,                          /**< OID length */
    void **end_ptr                              /**< End pointer */
)
{
    uint8_t size;
    uint8_t *ptr;
    uint8_t i = 0;
    if (*buffer != ASN1_OID)
        return SNMP_RET_ASN1_TYPEERR;
    size = *(buffer + 1);
    if (*(buffer + 2) <= 39) {
        *oid = 0;
        *(oid + 1) = (uint8_t) *(buffer + 2);
    } else if (*(buffer + 2) <= 79) {
        *oid = 1;
        *(oid + 1) = (uint8_t) *(buffer + 2) - 40;
    } else {
        *oid = 2;
        *(oid + 1) = (uint8_t) *(buffer + 2) - 80;
    }
    ptr = buffer + 3;
    *end_ptr = ptr;
    *(oid_len) = 2;

    size--;
    while(size>0){
        *(oid + 2 + i) = snmp_asn1_decode_7bit_uint(ptr, len, end_ptr);
        *(oid_len) += 1;
        size -= ( (uint8_t *) *end_ptr)-ptr;
        ptr = *end_ptr;
        i++;
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Decodes an an ASN.1 OID into a var struct
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T asn1_decode_oid(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res;

    if (*(buffer) != ASN1_OID)
        return SNMP_RET_ASN1_TYPEERR;
    res = snmp_asn1_decode_oid_to_array(buffer, len, (uint32_t *) target, target_len, end_ptr);

    return res;

}


/****************************************************************************/
/** Encodes a char string as an ASN.1 OCTET STRING
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
static SNMP_RET_T asn1_encode_octet_string(
    ASN1_TYPE type,                             /**< ASN.1 type */
    void *string,                               /**< String to encode */
    uint32_t length,                            /**< String length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
)
{
    uint32_t cnt;
    SNMP_RET_T res = SNMP_RET_NOERR;
    *buffer = (uint8_t) type;
    buffer++;

    if (length <= 0x7F)
        snmp_asn1_encode_uint32(length, (uint8_t *) buffer, (void **) &buffer, 0, 0);
    else {
        cnt = snmp_asn1_get_len_octet_count(length);
        *buffer = 0x80 + (uint8_t) cnt - 1;
        buffer++;
        snmp_asn1_encode_len(length, (uint8_t *) buffer, (void **) &buffer, 0, 0);
    }

    SNMP_MEMCPY(buffer, (uint8_t *) string, length);
    *end_ptr = buffer + length;
    return res;
}


/****************************************************************************/
/** Decodes an an ASN.1 string into a var struct
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
static SNMP_RET_T asn1_decode_octet_string(
    uint8_t *buffer,                            /**< Buffer */
    uint16_t len,                               /**< Buffer length */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_NOERR;            /* SNMP result */
    uint32_t lenStr;                            /* length of string */

    /* check for correct type */
    if (*(buffer) != ASN1_OCTET_STRING) {
        return SNMP_RET_ASN1_TYPEERR;
    }
    buffer++;

    /* decode length of string */
    res = snmp_asn1_decodeLength(buffer, len, end_ptr, &lenStr);
    if (SNMP_RET_NOERR != res) {
        return res;
    }

    /* check decoded length against buffer length */
    if (*target_len < lenStr) {
        return SNMP_RET_ASN1_RESOURCE;
    }

    /* check for correct size of string length (16 bit) */
    if ((uint16_t) lenStr < lenStr) {
        return SNMP_RET_ASN1_RESOURCE;
    }

    /* copy string to target buffer */
    SNMP_MEMCPY(target, *end_ptr, lenStr);
    *target_len = (uint16_t) lenStr;
    *end_ptr = (void *) (((uint8_t *) *end_ptr) + lenStr);

    /* add NULL terminator to string */
    *(target + *target_len) = 0;

    return res;
}


/****************************************************************************/
/** Encodes an ipv4 address string as an ASN.1 NETADDR
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
static SNMP_RET_T asn1_encode_ip_string(
    char *ip,                                   /**< IP address */
    uint32_t length,                            /**< Address length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_NOERR;

    UNUSEDARG(length);

    /* Assign type and length */
    *buffer = (uint8_t) ASN1_IPADDR;
    *(buffer + 1) = 4;

    /* Reverse copy ip address */
    SNMP_IP_ADDR_TO_ASN1(buffer, (uint8_t *) ip);

    *end_ptr = buffer + 2 + 4;
    return res;
}


/****************************************************************************/
/** Calculates the encoding size of the given value, size and type
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_get_encoding_size(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t value_size,                        /**< Value data size */
    uint32_t *enc_size,                         /**< Encoding size */
    uint8_t sign,                               /**< Sign of integer values */
    ASN1_TYPE type                              /**< Value's ASN.1 type */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    uint16_t i = 0;
    switch (type) {
    case ASN1_COUNTER:
    case ASN1_INTEGER:
    case ASN1_UINTEGER32:
    case ASN1_GAUGE:
    case ASN1_TIMETICKS:
        if (!sign)
            *enc_size += snmp_asn1_get_uint32_octet_count(*((uint32_t *) conv_value));
        else
            *enc_size += snmp_asn1_get_int32_octet_count(
                                *((int32_t *) conv_value));
        *enc_size += 2;
        break;
    case ASN1_IPADDR:
        *enc_size += 6;
        break;
    case ASN1_NULL:
        *enc_size += 2;
        break;
    case ASN1_OCTET_STRING:
    case ASN1_BITSTRING:
        *enc_size += snmp_asn1_get_len_octet_count(value_size);
        *enc_size += 1 + value_size;
        break;
    case ASN1_OID:
        for (i = 1; i < value_size; ++i) {
            *enc_size += snmp_asn1_get_7bit_uint_octet_count(
                            *(((uint32_t *) conv_value) + i));
        }
        *enc_size += snmp_asn1_get_len_octet_count(*enc_size) + 1;
        break;
    default:
            break;
    }
    return rv;
}


/****************************************************************************/
/** Encodes an OID as ASN.1 into a target buffer
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
static SNMP_RET_T asn1_encode_OID(
    uint32_t *oid,                              /**< OID */
    uint8_t oid_len,                            /**< OID length */
    uint8_t *buffer,                            /**< Buffer */
    void **end_ptr                              /**< End pointer */
)
{
    uint8_t i = 0;
    uint8_t enc_len = 0;
    SNMP_RET_T res = SNMP_RET_NOERR;
    uint16_t offset = 0;
    uint8_t *oid_buffer;
    *buffer = (uint8_t) ASN1_OID;

    *(buffer + 2) = (uint8_t) ((*oid) * 40 + *(oid + 1));
    oid_buffer = buffer+3;
    for (i = 2; i < oid_len; i++) {
        enc_len = asn1_encode_7bit_uint(*(oid + i), (uint8_t *) (&uintbuf));
        SNMP_MEMCPY(oid_buffer, uintbuf, enc_len);
        oid_buffer += enc_len;
        offset += enc_len;
    }

    *(buffer + 1) = (uint8_t) (1 + offset);
    *end_ptr = oid_buffer;
    return res;
}


/****************************************************************************/
/** Encodes the given value to an ASN.1 type as specified
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_encode(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t value_size,                        /**< Value data size */
    ASN1_TYPE type,                             /**< Value's ASN.1 type */
    uint8_t *buffer,                            /**< Buffer */
    uint8_t sign,                               /**< Sign of integer value */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_ASN1_UNKNOWN_TYPE;
    switch (type) {
    case ASN1_INTEGER:
        if (sign)
            return asn1_encode_sint32(*((int32_t *) conv_value), buffer, end_ptr);
        else
            return snmp_asn1_encode_uint32(*((uint32_t *) conv_value), buffer,
                            end_ptr, 0, 1);
    case ASN1_BITSTRING:
    case ASN1_OCTET_STRING:
        return asn1_encode_octet_string(type, conv_value, value_size, buffer, end_ptr);
    case ASN1_OID:
        if (SNMP_OID_MAX_LEN < value_size) {
            return SNMP_RET_ASN1_RANGE;
        }
        return asn1_encode_OID((uint32_t *) conv_value, (uint8_t) value_size, buffer,
                            end_ptr);
    case ASN1_GAUGE:
    case ASN1_TIMETICKS:
    case ASN1_UINTEGER32:
    case ASN1_COUNTER:
        return snmp_asn1_encode_uint32(*((uint32_t *) conv_value), buffer,
                        end_ptr, (uint8_t) type, 1);
    case ASN1_IPADDR:
        return asn1_encode_ip_string((char *) conv_value, value_size, buffer,
                        end_ptr);
    default:
        break;
    }
    return res;
}


/****************************************************************************/
/** Decodes the length info of an ASN.1 type value
 *
 * @returns SNMP_RET_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_decodeLength(
    uint8_t *ptr,                               /**< Pointer to buffer */
    uint32_t size,                              /**< Remaining size */
    void **end_ptr,                             /**< Pointer to next byte after processing */
    uint32_t *var                               /**< Pointer where value will be stored */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP result */
    uint8_t lenSize = 0;                        /* number of size bytes in ASN1 long form */
    uint32_t len;                               /* decodes length */

    /* Long form encoding consists of 0x80 + length bits
     * followed by the length bytes
     */
    if (SNMP_ASN1_TYPE_LONGFORM & *ptr) {
        lenSize = (uint8_t) (*ptr & (~ SNMP_ASN1_TYPE_LONGFORM));
        switch (lenSize) {
            case 0:
                /* number of size bytes is 0 */
                return SNMP_RET_ASN1_RANGE;
            case 1:
                len = *(ptr + 1);
                break;
            case 2:
                len = GOAL_be16toh_p(ptr + 1);
                break;
            case 3:
                len = GOAL_be24toh_p(ptr + 1);
                break;
            case 4:
                len = GOAL_be32toh_p(ptr + 1);
                break;
            default:
                /* only 32 bit (== 4 byte) length is supported */
                return SNMP_RET_ASN1_RANGE;
        }

        /* check decoded length against remaing size */
        if (size < len) {
            return SNMP_RET_ASN1_RANGE;
        }

        /* store decodes length */
        *var = len;

        /* update pointer using number of size bytes and */
        *end_ptr = ptr + 1 + lenSize;

    } else {
        /* Short form with one byte with bits 7-1 */
        *var = snmp_asn1_decode_7bit_uint(ptr, size, end_ptr);
    }
    return ret;
}



/****************************************************************************/
/** Decodes the given ASN.1 type value
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_decode(
    uint8_t *conv_value,                        /**< Value to convert */
    uint16_t len,                               /**< Value data size */
    uint8_t *target,                            /**< Target buffer */
    uint16_t *target_len,                       /**< Target buffer length */
    uint8_t *sign,                              /**< Sign of integer values */
    ASN1_TYPE *type,                            /**< ASN.1 type */
    void **end_ptr                              /**< End pointer */
)
{
    SNMP_RET_T res = SNMP_RET_ASN1_UNKNOWN_TYPE;
    *type = (ASN1_TYPE) *(conv_value);
    switch (*type) {
    case ASN1_GAUGE:
    case ASN1_COUNTER:
    case ASN1_UINTEGER32:
    case ASN1_INTEGER:
    case ASN1_TIMETICKS:
        return asn1_decode_int32(conv_value, len, target, target_len, sign,
                        end_ptr);
    case ASN1_OCTET_STRING:
        return asn1_decode_octet_string(conv_value, len, target, target_len,
                        end_ptr);
    case ASN1_OID:
        return asn1_decode_oid(conv_value, len, target, target_len, end_ptr);
    case ASN1_NULL:
        *end_ptr=conv_value+2;
        *target_len=0;
        return SNMP_RET_NOERR;
    default:
            break;
    }
    return res;
}


/****************************************************************************/
/** Decodes a BER encoded integer
 *
 * @returns SNMP_ERR_NOERR in case of success, otherwise error code.
 */
SNMP_RET_T snmp_asn1_decode_berInt(
    uint8_t *pBuf,                              /**< buffer pointer */
    uint32_t *pVal,                             /**< Pointer to decoded value */
    uint8_t **pEndPtr                           /**< End pointer */
)
{
    uint32_t len = 1;                           /**< Length */
    uint32_t i;                                 /**< Index */
    *pVal = 0;

    if (*pBuf & 0x80) {
        len = *pBuf & 0x7F;
        pBuf++;
    }

    for (i = 0; i < len; i++) {
        *pVal |= ((uint32_t) *pBuf) << (8 * (len - i - 1));
        pBuf++;
    }

    *pEndPtr = pBuf;

    return SNMP_RET_NOERR;
}
