/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/** Set value of a variable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_set_var_value(
    SNMP_VARENTRY_T *entry,                     /**< Variable */
    uint8_t *value,                             /**< Value */
    uint16_t size,                              /**< Value data size */
    uint8_t sign                                /**< Sign for integers */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    SNMP_MEMCPY(&(entry->var->data[0]),value, size);
    entry->var->size = size;
    entry->var->sign = sign;
    return rv;
}


/****************************************************************************/
/** Set value of and type of a variable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_set_var_value_type(
    SNMP_VARENTRY_T *entry,                     /**< Variable */
    uint8_t *value,                             /**< Value */
    uint16_t size,                              /**< Value data size */
    uint8_t sign,                               /**< Sign for integers */
    ASN1_TYPE type                              /**< ASN.1 type */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    SNMP_MEMSET(entry->var->data, 0, SNMP_VAR_MAX_DATA);
    SNMP_MEMCPY(&(entry->var->data[0]),value, size);
    if (ASN1_OID != type)
        entry->var->size = size;
    else
        /* Size of OID is measured in OID elements, not bytes */
        entry->var->size = size/sizeof(uint32_t);
    entry->var->sign = sign;
    entry->var->type = type;
    return rv;
}


/****************************************************************************/
/** Calculates the encoding length of a var list
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_calc_var_enc_len(
    SNMP_VARLIST_T *list,                       /**< Var list */
    uint32_t *len                               /**< Calculated length */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;
    uint32_t enc_size=0;
    SNMP_VARENTRY_T *entry=NULL;

    if (list == NULL || len==NULL) return SNMP_RET_PARAM;
    entry = list->head;
    while (entry!=NULL) {
        /* get length in bytes of OID + coded length  */
        rv += snmp_asn1_get_encoding_size((uint8_t *)&(entry->var->oid->sub_oid[0]), entry->var->oid->len, &enc_size, 0, ASN1_OID);

        /* add length in bytes of var data + coded length */
        if (entry->var->size == 0 || entry->var->error_code != 0)
            rv += snmp_asn1_get_encoding_size(&(entry->var->data[0]), entry->var->size, &enc_size, entry->var->sign, ASN1_NULL);
        else
            rv += snmp_asn1_get_encoding_size(&(entry->var->data[0]), entry->var->size, &enc_size, entry->var->sign, entry->var->type);

        /* store size in var */
        entry->var->enc_size = enc_size;

        /* add length of coded length for complete var */
        enc_size += snmp_asn1_get_len_octet_count(enc_size);

        /* add 1 byte for ASN.1 0x30 */
        enc_size += 1;

        /* add encoding length to total length */
        *len += enc_size;

        /* go to next entry */
        entry = entry->next;
        enc_size = 0;
    }
    return rv;

}
