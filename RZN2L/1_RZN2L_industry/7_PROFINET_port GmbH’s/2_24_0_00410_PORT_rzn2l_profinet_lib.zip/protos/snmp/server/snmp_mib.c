/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_SNMP
#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static SNMP_MIB_NODE_T snmpMibNodes[SNMP_CONF_STATIC_MIBNODES]; /**< Allocated MIB nodes */
static SNMP_MIB_NODE_T snmpMibRoot;            /**< root node for all MIBs */
static SNMP_MIB_NODE_LIST_T *pSnmpMibHighPrioNodeListRoot = NULL; /**< root of high priority nodes */
static GOAL_SNMP_MIB_INIT_REG_LIST_T *pSnmpMibInitRoot = NULL; /**< root for MIB registration callbacks */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_mib_alloc_node(
    uint32_t oid,                               /**< sub OID */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to allocated node */
);

static SNMP_MIB_NODE_T *mib_find_next_node_by_oid(
    uint32_t oid,                               /**< sub OID */
    SNMP_MIB_NODE_T *pParent                    /**< Parent node */
);

static SNMP_RET_T mib_register_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNewNode                 /**< Pointer to new MIB node */
);

static SNMP_RET_T snmp_mib_register_node_internal(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< Get handler */
    snmp_set_handler_func setHandler,           /**< Set handler */
    GOAL_BOOL_T flgPrioHigh                     /**< High Priority flag */
);

static SNMP_RET_T mib_get_next_handler_node_down(
    SNMP_MIB_NODE_T *pStart,                    /**< Start node */
    SNMP_MIB_NODE_T *pIgnore,                   /**< Node to ignore */
    SNMP_MIB_NODE_T **ppNext,                   /**< Pointer to next node */
    uint8_t recursive                           /**< Recursive */
);

static SNMP_RET_T mib_get_next_handler_node_up(
    SNMP_MIB_NODE_T *pStart,                    /**< Start node */
    SNMP_MIB_NODE_T *pIgnore,                   /**< Node to ignore */
    SNMP_MIB_NODE_T **ppNext,                   /**< Pointer to next node */
    uint8_t recursive                           /**< Recursive */
);

static SNMP_RET_T snmp_mib_store_high_prio_node(
    SNMP_MIB_NODE_T *pNode                      /**< node */
);


/****************************************************************************/
/** Allocates a new MIB node
 *
 * @retval SNMP_ERR_NOERR success
 * @retval SNMP_RET_RESOURCE no free nodes available.
 */
static SNMP_RET_T snmp_mib_alloc_node(
    uint32_t oid,                               /**< sub OID */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to allocated node */
)
{
    uint32_t cnt = 0;                           /* counter */

    /* find first unused node */
    for (cnt = 0; cnt < SNMP_CONF_STATIC_MIBNODES; cnt++) {
        if (!(snmpMibNodes[cnt].flags & SNMP_MIB_NODE_FLAG_IN_USE)) {
            /* clear and return node */
            *ppNode = &(snmpMibNodes[cnt]);
            (*ppNode)->flags = SNMP_MIB_NODE_FLAG_IN_USE;
            (*ppNode)->oid = oid;
            (*ppNode)->child.pChild = NULL;
            (*ppNode)->pNext = NULL;
            return SNMP_RET_NOERR;
        }
    }

    /* no free node found */
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** Searches for the next child node with the given sub OID
 *
 * @returns Pointer to MIB node or null if not found
 */
static SNMP_MIB_NODE_T *mib_find_next_node_by_oid(
    uint32_t oid,                               /**< sub OID */
    SNMP_MIB_NODE_T *pParent                    /**< Parent node */
)
{
    SNMP_MIB_NODE_T *pNode;                     /* current node */

    /* find child node with given OID */
    SNMP_MIB_GET_FIRST_CHILD(pNode, pParent);
    while (NULL != pNode) {
        if (pNode->oid == oid) {
            /* found node with given OID */
            return pNode;
        }

        /* look up next child */
        SNMP_MIB_GET_NEXT_CHILD(pNode, pNode);
    }

    /* found no node with given OID */
    return NULL ;
}


/****************************************************************************/
/** Inserts a child node to the given parent node
 *
 * @retval SNMP_ERR_NOERR success
 * @retval SNMP_RET_PARAM node exists in MIB tree already
 */
SNMP_RET_T snmp_mib_insert_child_node(
    SNMP_MIB_NODE_T *pParent,                   /**< Parent node */
    SNMP_MIB_NODE_T *pChild                     /**< Child node */
)
{
    SNMP_MIB_NODE_T *pCurrent;                  /* current node */

    SNMP_MIB_GET_FIRST_CHILD(pCurrent, pParent);

    /* This parent has no children yet */
    if (pCurrent == NULL) {
        pParent->child.pChild = pChild;
        pChild->pNext = pParent;
        pChild->flags |= SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT;
    }
    else if (pChild->oid < pCurrent->oid) {
        /* insert child on first position */
        pParent->child.pChild = pChild;
        pChild->pNext = pCurrent;
    }
    else {
        /* find last node before new child */
        while ((!(pCurrent->flags & SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT)) &&
            (pCurrent->pNext != NULL) &&
            (pCurrent->pNext->oid < pChild->oid)) {
            pCurrent = pCurrent->pNext;
        }

        /* check if node exists already */
        if ((!(pCurrent->flags & SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT)) &&
            (pCurrent->pNext->oid == pChild->oid)) {
            return SNMP_RET_PARAM;
        }

        /* insert node */
        pChild->pNext = pCurrent->pNext;
        pCurrent->pNext = pChild;

        /* check if new node is last child */
        if (pCurrent->flags & SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT) {
            pCurrent->flags &= ~SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT;
            pChild->flags |= SNMP_MIB_NODE_FLAG_NEXT_IS_PARENT;
        }
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Register a MIB variable with the given OID
 *
 * This also creates a new MIB node element.
 *
 * @returns SNMP_RET_NOERR in case of success, SNMP_RET_PARAM if MIB node already exists
 */
static SNMP_RET_T mib_register_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNewNode                 /**< Pointer to new MIB node */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;             /* SNMP return value */
    uint32_t cnt = 0;                           /* counter */
    SNMP_MIB_NODE_T *pNode = &snmpMibRoot;      /* current node */
    SNMP_MIB_NODE_T *pNext = &snmpMibRoot;      /* next node */
    SNMP_MIB_NODE_T *pLast = NULL;              /* last node */
    uint32_t *pSubOid = pOid;                   /* sub OID of given OID */

    /* find first non-registered node in MIB tree */
    while ((NULL != pNext) && (0xFFFF != lenOid)) {
        pLast = pNext;
        pNext = mib_find_next_node_by_oid(*pSubOid, pLast);
        pSubOid++;
        lenOid--;
    }
    if (lenOid == 0xFFFF) {
        /* Node already exists! */
        return SNMP_RET_PARAM;
    }
    if (pSubOid != pOid) {
        pSubOid--;
        lenOid++;
    }

    /* alloc and insert all new nodes in MIB tree */
    for (cnt = 0; cnt < lenOid; cnt++) {
        rv = snmp_mib_alloc_node(*pSubOid, &pNode);
        if (rv != SNMP_RET_NOERR) {
            return rv;
        }
        rv = snmp_mib_insert_child_node(pLast, pNode);
        if (rv != SNMP_RET_NOERR) {
            return rv;
        }

        pLast = pNode;
        pSubOid++;
    }
    *ppNewNode = pLast;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Register a given MIB variable which is not a table
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
SNMP_RET_T snmp_mib_register_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< scalar get handler */
    snmp_set_handler_func setHandler            /**< scalar set handler */
)
{
    return snmp_mib_register_node_internal(pOid, lenOid, access, getHandler, setHandler, GOAL_FALSE);
}


/****************************************************************************/
/** Register a given MIB variable which is not a table and add it
 * to a list of nodes processed with high priority in SNMP get requests.
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
SNMP_RET_T snmp_mib_register_high_prio_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< Get handler */
    snmp_set_handler_func setHandler            /**< Set handler */
)
{
    return snmp_mib_register_node_internal(pOid, lenOid, access, getHandler, setHandler, GOAL_TRUE);
}


/****************************************************************************/
/** Register a given MIB variable which is not a table. If high prio flag is
 * set it will be added to a list of nodes processed with high priority in
 * SNMP get requests.
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
static SNMP_RET_T snmp_mib_register_node_internal(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    uint8_t access,                             /**< Access rights */
    snmp_get_handler_func getHandler,           /**< Get handler */
    snmp_set_handler_func setHandler,           /**< Set handler */
    GOAL_BOOL_T flgPrioHigh                     /**< High Priority flag */
)
{
    SNMP_MIB_NODE_T *pNode;                     /* current node */
    SNMP_RET_T rv;                              /* SNMP return value */
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_SIMPLE_NODE_HANDLER_FUNC_SET_T *pHandler; /* simple pNode handler pointer */

    UNUSEDARG(access);

    /* alloc function handler pointer */
    res = goal_memCalloc(&pHandler, sizeof(SNMP_SIMPLE_NODE_HANDLER_FUNC_SET_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to alloc simple node handler");
        return SNMP_RET_RESOURCE;
    }

    /* register nodes */
    rv = mib_register_node(pOid, lenOid, &pNode);
    if (SNMP_RET_NOERR != rv) {
        goal_memFree(&pHandler);
        return rv;
    }

    /* store get and set handler */
    pHandler->getHandler = getHandler;
    pHandler->setHandler = setHandler;
    pNode->child.handler.pSimpleHandler = pHandler;

    /* store handler flags */
    if (NULL != getHandler) {
        pNode->flags |= SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET;
    }
    if (NULL != setHandler) {
        pNode->flags |= SNMP_MIB_NODE_FLAG_HAS_SIMPLE_SET;
    }

    /* add registered node to high priority list */
    if (GOAL_TRUE == flgPrioHigh) {
        rv = snmp_mib_store_high_prio_node(pNode);
        if (SNMP_RET_NOERR != rv) {
            goal_logWarn("failed to add node to high priority queue");
        }
    }

    return rv;
}


/****************************************************************************/
/** Stores a given MIB node in high priority MIB node list.
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
static SNMP_RET_T snmp_mib_store_high_prio_node(
    SNMP_MIB_NODE_T *pNode                      /**< node */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_MIB_NODE_LIST_T *pCurList;             /* already stored list */
    SNMP_MIB_NODE_LIST_T *pList = NULL;         /* high priority list element */

    /* allocate memory for list element */
    res = goal_memCalloc((char **) &pList, sizeof(SNMP_MIB_NODE_LIST_T));
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    /* prepare lsit element */
    pList->pNode = pNode;
    pList->pNext = NULL;

    /* store node */
    if (NULL == pSnmpMibHighPrioNodeListRoot) {
        /* store node as first list element */
        pSnmpMibHighPrioNodeListRoot = pList;
    }
    else {
        /* find last list entry */
        pCurList = pSnmpMibHighPrioNodeListRoot;
        while (NULL != pCurList->pNext) {
            pCurList = pCurList->pNext;
        }
        /* append node */
        pCurList->pNext = pList;
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Register a MIB node as a table.
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
SNMP_RET_T snmp_mib_register_table(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_TABLE_HANDLER_FUNC_SET_T *pTableHandler /**< Table handler set */
)
{
    SNMP_MIB_NODE_T *pNode;                     /* current node */
    SNMP_RET_T rv;                              /* SNMP return value */
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_TABLE_HANDLER_FUNC_SET_T *pHandler;    /* table handler pointer */

    /* alloc function handler pointer */
    res = goal_memCalloc(&pHandler, sizeof(SNMP_TABLE_HANDLER_FUNC_SET_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to alloc simple node handler");
        return SNMP_RET_RESOURCE;
    }

    /* register nodes */
    rv = mib_register_node(pOid, lenOid, &pNode);
    if (SNMP_RET_NOERR != rv) {
        goal_memFree(&pHandler);
        return rv;
    }

    /* store get and set handler */
    pHandler->getHandler = pTableHandler->getHandler;
    pHandler->setHandler = pTableHandler->setHandler;
    pHandler->tableIndexer = pTableHandler->tableIndexer;
    pNode->child.handler.pTableHandler = pHandler;

    /* store handler flags */
    if (NULL != pTableHandler->getHandler) {
        pNode->flags |= SNMP_MIB_NODE_FLAG_HAS_TABLE_GET;
    }
    if (NULL != pTableHandler->setHandler) {
        pNode->flags |= SNMP_MIB_NODE_FLAG_HAS_TABLE_SET;
    }
    if (NULL != pTableHandler->tableIndexer) {
        pNode->flags |= SNMP_MIB_NODE_FLAG_HAS_TABLE_INDEXER;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Searches for a MIB node identified by an OID.
 *
 *
 * @retval SNMP_RET_NOERR success
 * @retval SNMP_RET_PARAM failed
 */
SNMP_RET_T snmp_mib_find_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to found node */
)
{
    SNMP_MIB_NODE_T *pNode = &snmpMibRoot;      /* current node */
    SNMP_MIB_NODE_T *pLast;                     /* last node */
    uint32_t *pSubOid = pOid;                   /* sub OID for next node */

    /* look up MIB tree */
    while ((NULL != pNode) && (0 < lenOid)) {
        pLast = pNode;
        pNode = mib_find_next_node_by_oid(*pSubOid, pLast);
        pSubOid++;
        lenOid--;
    }

    /* check for valid node */
    if ((NULL != pNode) && (lenOid == 0)) {
        *ppNode = pNode;
        return SNMP_RET_NOERR;
    }

    /* no node found */
    *ppNode = NULL;
    return SNMP_RET_PARAM;
}


/****************************************************************************/
/** Searches for a MIB node identified by an OID in high priority
 * MIB node list.
 *
 *
 * @retval SNMP_RET_NOERR success
 * @retval SNMP_RET_PARAM failed
 */
SNMP_RET_T snmp_mib_find_high_prio_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode                    /**< Pointer to found node */
)
{
    SNMP_MIB_NODE_LIST_T *pList;                /* current node lsit pointer */
    SNMP_MIB_NODE_T *pNode;                     /* current node pointer */
    uint32_t cnt;                               /* counter */

    if (0 < lenOid) {
        /* look for every list element */
        for (pList = pSnmpMibHighPrioNodeListRoot; NULL != pList; pList=pList->pNext) {

            /* get high priority node node */
            pNode = pList->pNode;

            for (cnt = lenOid; 0 < cnt; cnt--) {
                /* stop with node if OID does not match */
                if (pNode->oid != *(pOid + cnt - 1)) {
                    cnt = 0;
                    break;
                }

                /* get previous OID entry */
                SNMP_MIB_GET_PARENT(pNode, pNode);

                if ((0 == (cnt - 1)) && (pNode == &snmpMibRoot)) {
                    /* found node */
                    *ppNode = pList->pNode;
                    return SNMP_RET_NOERR;
                }
            }
        }
    }

    /* no node found */
    *ppNode = NULL;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Searches for a MIB node identified by an OID.
 *
 * If a node while descending the MIB tree is found, this node will be
 * returned and the exact match flag will be set.
 *
 * If in one step no node is found, the lexicographically next node with a
 * get handler will be returned.
 *
 * @retval SNMP_RET_NOERR success
 * @retval SNMP_RET_PARAM failed
 */
SNMP_RET_T snmp_mib_find_node_with_at_least_oid(
    uint32_t **ppOid,                           /**< OID */
    uint16_t *pOidLen,                          /**< pointer remaining OID length */
    SNMP_MIB_NODE_T **ppNode,                   /**< pointer to pointer of found node */
    GOAL_BOOL_T *pFlgExactMatch                 /**< pointer to flag for given OID matches found node */
)
{
    SNMP_MIB_NODE_T *pLastNode = NULL;          /* pointer to prevous node */
    SNMP_MIB_NODE_T *pNextNode = NULL;          /* pointer to following node */
    SNMP_MIB_NODE_T *pNode = NULL;              /* pointer to current node */

    *pFlgExactMatch = GOAL_TRUE;
    pNode = &snmpMibRoot;

    /* if node tree is empty, return NULL */
    if (NULL == pNode) {
        *ppNode = pNode;
        return SNMP_RET_NOERR;
    }

    /* if no node is registered, return NULL */
    SNMP_MIB_GET_FIRST_CHILD(pNextNode, pNode);
    if (NULL == pNextNode) {
        *ppNode = NULL;
        return SNMP_RET_NOERR;
    }

    /* find node as long they are matching exactly to OID */
    while ((*pOidLen > 0) && (NULL != pNextNode)) {
        pLastNode = pNode;
        pNode = pNextNode;

        /* find child matching current OID entry */
        while ((NULL != pNode) && (pNode->oid != **ppOid)) {
            SNMP_MIB_GET_NEXT_CHILD(pNode, pNode);
        }

        /* if matching OID entrx exists, go to next one */
        if ((NULL != pNode) && (pNode->oid == **ppOid)) {
            /* go to next exactly matching child */
            *((uint32_t **)ppOid) += 1;
            *((uint16_t *) pOidLen) -= 1;
        }
        else {
            /* stop looking nodes using OID */
            *pFlgExactMatch = GOAL_FALSE;
            *pOidLen = 0;
        }

        if (NULL != pNode) {
            SNMP_MIB_GET_FIRST_CHILD(pNextNode, pNode);
        }
        else {
            pNextNode = NULL;
        }
    }

    /* if no matching OID entry exists, find lexicographically next node */
    if (GOAL_FALSE == *pFlgExactMatch) {

        /* find next node of all children */
        SNMP_MIB_GET_FIRST_CHILD(pNode, pLastNode);
        pNextNode = NULL;
        while (NULL != pNode) {
            if (pNode->oid >= **ppOid) {
                if (NULL == pNextNode) {
                    pNextNode = pNode;
                }
                else {
                    if (pNextNode->oid < pNode->oid) {
                        pNextNode = pNode;
                    }
                }
            }
            SNMP_MIB_GET_NEXT_CHILD(pNode, pNode);
        }
        pNode = pNextNode;

        /* if no child is found, directly find next node looking from last node */
        if (NULL == pNode) {
            SNMP_MIB_GET_NEXT_CHILD(pNode, pLastNode);

            /* if there is no other brother of parent node, find next node looking above the father */
            if (NULL == pNode) {
                mib_get_next_handler_node_up(pLastNode, NULL, &pNode, SNMP_TRUE);
            }

            /* otherwise get next handler node directly */
            else if (!(pNode->flags & (SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET | SNMP_MIB_NODE_FLAG_HAS_TABLE_GET))) {
                pLastNode = pNode;
                snmp_mib_get_next_node(pLastNode, &pNode);
            }
        }
    }

    /* return found node */
    *ppNode = pNode;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Search for first table node identified by an OID
 *
 *
 * @returns SNMP_RET_NOERR in case of success, error code otherwise
 */
SNMP_RET_T snmp_mib_find_table_node(
    uint32_t *pOid,                             /**< OID */
    uint16_t lenOid,                            /**< OID length */
    SNMP_MIB_NODE_T **ppNode,                   /**< Pointer to found node */
    uint32_t **ppTableOid                       /**< Pointer to table OID */
)
{
    SNMP_MIB_NODE_T *pNode = &snmpMibRoot;      /* current node */
    SNMP_MIB_NODE_T *pLast;                     /* last node */
    uint32_t *pSubOid = pOid;                   /* sub OID of next node */

    /* look up MIB tree */
    while ((NULL != pNode) && (0 < lenOid)) {
        pLast = pNode;
        pNode = mib_find_next_node_by_oid(*pSubOid, pLast);
        /* stop if current node is table node */
        if ((NULL != pNode) && (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_TABLE_GET)) {
            *ppNode = pNode;
            *ppTableOid = pSubOid;
            return SNMP_RET_NOERR;
        }
        pSubOid++;
        lenOid--;
    }

    /* no table node found */
    *ppNode = NULL;
    return SNMP_RET_PARAM;
}


/****************************************************************************/
/** Traverses the MIB tree downwards to find lexicographical next node with get handler.
 *
 *
 * @retval SNMP_RET_NOERR success,
 * @retval SNMP_RET_PARAM failed
 */
static SNMP_RET_T mib_get_next_handler_node_down(
    SNMP_MIB_NODE_T *pStart,                    /**< Start node */
    SNMP_MIB_NODE_T *pIgnore,                   /**< Node to ignore */
    SNMP_MIB_NODE_T **ppNext,                   /**< Pointer to next node */
    uint8_t recursive                           /**< Recursive */
)
{
    SNMP_RET_T ret;
    SNMP_MIB_NODE_T *pCurrent;                  /* current node */
    SNMP_MIB_NODE_T *pFirstChild;               /* first child of current node */
    SNMP_MIB_NODE_T *pNextChild;                /* next child node of parent */

    UNUSEDARG(recursive);

    pCurrent = pStart;

    /* looking for get handler using first child node */
    SNMP_MIB_GET_FIRST_CHILD(pFirstChild, pCurrent);
    if ((NULL != pFirstChild) && (pIgnore != pFirstChild)) {
            if (pFirstChild->flags & (SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET | SNMP_MIB_NODE_FLAG_HAS_TABLE_GET)) {
                /* child has table or scalar get handler */
                *ppNext = pFirstChild;
                return SNMP_RET_NOERR;
        }
        ret = mib_get_next_handler_node_down(pFirstChild, NULL, ppNext, SNMP_TRUE);
        if (SNMP_RET_NOERR == ret) {
            /* found node with table or scalar handler starting with first child node */
            return SNMP_RET_NOERR;
        }
    }

    /* look up all bigger brothers */
    SNMP_MIB_GET_NEXT_CHILD(pNextChild, pCurrent);
    while (NULL != pNextChild) {
        pCurrent = pNextChild;
        if (pCurrent != pIgnore) {
            if (pCurrent->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET) {
                /* brother node has scalar get handler */
                *ppNext = pCurrent;
                return SNMP_RET_NOERR;
            }

            /* check children of */
            SNMP_MIB_GET_FIRST_CHILD(pFirstChild, pCurrent);
            if ((NULL != pFirstChild) && (pIgnore != pFirstChild)) {
                if (pFirstChild->flags & (SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET | SNMP_MIB_NODE_FLAG_HAS_TABLE_GET)) {
                    /* child has table or scalar get handler */
                    *ppNext = pFirstChild;
                    return SNMP_RET_NOERR;
                }
                ret = mib_get_next_handler_node_down(pFirstChild, NULL, ppNext, SNMP_TRUE);
                if (SNMP_RET_NOERR == ret) {
                    /* found node with table or scalar handler starting with first child node */
                    return SNMP_RET_NOERR;
                }
            }
        }
        SNMP_MIB_GET_NEXT_CHILD(pNextChild, pCurrent);
    }

    /* no node with table or scalar handler found */
    return SNMP_RET_PARAM;
}


/****************************************************************************/
/** Traverses the MIB tree upwards to find lexicographical next node with get handler.
 *
 *
 * @retval SNMP_RET_NOERR success,
 * @retval SNMP_RET_PARAM failed
 */
static SNMP_RET_T mib_get_next_handler_node_up(
    SNMP_MIB_NODE_T *pStart,                    /**< Start node */
    SNMP_MIB_NODE_T *pIgnore,                   /**< Node to ignore */
    SNMP_MIB_NODE_T **ppNext,                   /**< Pointer to next node */
    uint8_t recursive                           /**< Recursive */
)
{
    SNMP_MIB_NODE_T *pCurrent;                  /* current node */
    SNMP_MIB_NODE_T *pParent;                   /* parent node */
    SNMP_MIB_NODE_T *pNextOfParent;             /* next node of parent node */
    SNMP_RET_T rv;                              /* SNMP return value */

    UNUSEDARG(recursive);
    UNUSEDARG(pIgnore);

    /* start with parent of current node */
    pCurrent = pStart;
    SNMP_MIB_GET_PARENT(pParent, pCurrent);

    /* recursivly look up all successors of the parents */
    while (NULL != pParent) {
        SNMP_MIB_GET_NEXT_CHILD(pNextOfParent, pParent);
        if (NULL != pNextOfParent) {
            /* find next handler looking downwards from current node*/
            rv = mib_get_next_handler_node_down(pNextOfParent, pCurrent, ppNext, SNMP_TRUE);
            if (SNMP_RET_NOERR == rv) {
                /* found table or scalar handler */
                return rv;
            }
        }
        pCurrent = pParent;
        SNMP_MIB_GET_PARENT(pParent, pCurrent);
    }

    /* no node with table or scalar handler found */
    return SNMP_RET_PARAM;
}


/****************************************************************************/
/** Traverses the MIB tree upwards to find lexicographical next node with get handler.
 *
 *
 * @retval SNMP_RET_NOERR success,
 * @retval SNMP_RET_PARAM failed
 */
SNMP_RET_T snmp_mib_get_next_node(
    SNMP_MIB_NODE_T *pCurrent,                  /**< Current node */
    SNMP_MIB_NODE_T **ppNext                    /**< Next node */
)
{
    SNMP_RET_T rv;                              /* SNMP return value */

    /* check for valid start node */
    if (NULL == pCurrent) {
        return SNMP_RET_PARAM;
    }

    /* get next node looking downwards */
    rv = mib_get_next_handler_node_down(pCurrent, NULL, ppNext, SNMP_TRUE);
    if (SNMP_RET_PARAM == rv) {
        /* get lexicographically next node, which is not downwards */
        rv = mib_get_next_handler_node_up(pCurrent, NULL, ppNext, SNMP_TRUE);
    }

    if (SNMP_RET_PARAM == rv) {
        /* no node found */
        *ppNext = NULL;
        return rv;
    }

    /* found node */
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Print full MIB tree
 *
 *
 */
void snmp_mib_print_mib_tree(
    void
)
{
    snmp_debug_print_tree(&snmpMibRoot,1);
}


/****************************************************************************/
/** Register an MIB init function. This function must be called before
 * goal_snmpMibInit is used.
 *
 *
 * @returns GOAL_STATUS_T
 */
GOAL_STATUS_T goal_snmpMibInitReg(
    GOAL_SNMP_MIB_INIT_REG_FUNC_T mibInitFunc   /**< MIB init function to register */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    GOAL_SNMP_MIB_INIT_REG_LIST_T *pPrevCb;     /* previous init callback */
    GOAL_SNMP_MIB_INIT_REG_LIST_T *pCurCb;      /* curent init callback */


    /* allocate memory for init function */
    res = goal_memCalloc((char **) &pCurCb, sizeof(GOAL_SNMP_MIB_INIT_REG_LIST_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not allocate memory for MIB registration callback");
        return res;
    }

    /* store MIB init function in lsit element */
    pCurCb->func = mibInitFunc;
    pCurCb->pNext = NULL;

    /* append list element to end of List */
    pPrevCb = pSnmpMibInitRoot;
    if (NULL == pPrevCb) {
        pSnmpMibInitRoot = pCurCb;
    }
    else {
        while (pPrevCb->pNext) {
            pPrevCb = pPrevCb->pNext;
        }
        pPrevCb->pNext = pCurCb;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Calls all MIB init function registered previously.
 *
 *
 * @returns GOAL_STATUS_T
 */
GOAL_STATUS_T goal_snmpMibInit(
    void
)
{
    GOAL_SNMP_MIB_INIT_REG_LIST_T *pCurCb;      /* curent init callback */
    GOAL_STATUS_T res;                          /* GOAL result */

    pCurCb = pSnmpMibInitRoot;

    /* call all callbacks any until error occurs */
    while (NULL != pCurCb) {
        if (NULL != pCurCb->func) {
            res = pCurCb->func();
            if (GOAL_RES_ERR(res)) {
                return res;
            }
        }
        pCurCb = pCurCb->pNext;
    }

    return GOAL_OK;
}
