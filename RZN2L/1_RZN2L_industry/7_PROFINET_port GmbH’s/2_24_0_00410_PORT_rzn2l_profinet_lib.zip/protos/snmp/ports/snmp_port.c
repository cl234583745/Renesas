/** @file
 *
 * @brief
 * GOAL port of Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the glue for the Simple Network Management Protocol
 * (SNMP) implementation from port GmbH.
 *
 * @copyright
 * Copyright 2010-2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_SNMP_LOCALHOST     GOAL_NET_IPV4(127, 0, 0, 1)

/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_send(
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    SNMP_MSG_TYPE_T type,                       /**< message type */
    uint32_t errorCode,                         /**< error code */
    uint32_t errorSpec,                         /**< error specifier */
    uint32_t xid,                               /**< XID */
    uint32_t version,                           /**< Version */
    SNMP_VARLIST_T *pVars                       /**< variables list */
);

static void snmp_recv(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
);


/****************************************************************************/
/* External variables */
/****************************************************************************/
extern char snmp_op_community[];                 /**< community string of current operation */

/****************************************************************************/
/* Local variables */
/****************************************************************************/
static SNMP_MSG_T snmp_msgData;                 /**< SNMP msg struct */
static GOAL_NET_CHAN_T *pSnmpDesc = NULL;       /**< SNMP descriptor */
static GOAL_NET_ADDR_T addr;                    /**< GOAL net address */

/* Predefined OIDs */
static uint32_t sysUpTime_OID[] = {1, 3, 6, 1, 2, 1, 1, 3, 0};
#define OID_SYSUPTIME_LEN 9

static uint32_t snmpTrap_OID[] = {1, 3, 6, 1, 6, 3, 1, 1, 4, 1, 0};
#define OID_SNMPTRAP_LEN 11


/****************************************************************************/
/** Initialize the SNMP Server
 *
 * Initializes the internal SNMP server implementation.
 *
 * @returns 0 successful
 * @returns other fail
 */
GOAL_STATUS_T snmp_portInit(
    void
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    int one = 1;                                /* non block argument */

    /* open SNMP UDP port */
    GOAL_MEMSET(&addr, 0, sizeof(GOAL_NET_ADDR_T));
    addr.localPort = SNMP_SERVER_PORT;
#if GOAL_CONFIG_SNMP_GOAL_SNMP == 0
    addr.localIp = GOAL_SNMP_LOCALHOST;
#endif
    res = goal_netOpen(&pSnmpDesc, &addr, GOAL_NET_UDP_SERVER, snmp_recv);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("couldn't open SNMP UDP port: %d", SNMP_SERVER_PORT);
    }

    /* set socket to non-blocking */
    if (GOAL_RES_OK(res)) {
        res = goal_netSetOption(pSnmpDesc, GOAL_NET_OPTION_NONBLOCK, &one);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("could not set channel to non-blocking");
        }
    }

    /* activate UDP port */
    if (GOAL_RES_OK(res)) {
        res = goal_netActivate(pSnmpDesc);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("could not activate channel");
        }
    }

    /* print hello */
    if (GOAL_RES_OK(res)) {
        goal_logInfo("SNMP server launched at UDP port: %d", SNMP_SERVER_PORT);
    }

    /* TODO: cleanup SNMP init state on error */

    return res;
}


/****************************************************************************/
/** SNMP UDP Data Receive Handler
 *
 * Handles received SNMP data.
 */
static void snmp_recv(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;             /* return value */
    GOAL_BOOL_T flgSendResp = GOAL_FALSE;       /* response sending flag */

    UNUSEDARG(cbType);

    /* decode SNMP message */
    rv = snmp_decode_msg(pBuf->ptrData, pBuf->dataLen, &snmp_msgData);
    if (SNMP_RET_NOERR != rv) {
        return;
    }

    /* process SNMP message */
    switch (snmp_msgData.type) {

        case SNMP_MSG_GET:
            snmp_get_statistics()->snmpInGetRequests++;
            rv = snmp_process_get(&snmp_msgData);
            if (SNMP_RET_NOERR != rv) {
                break;
            }
            flgSendResp = GOAL_TRUE;
            break;

        case SNMP_MSG_GETBULK:
            /* GETBULK not available for SNMPv1 */
            if (SNMP_V1 != snmp_msgData.version) {
                snmp_get_statistics()->snmpInGetRequests++;
                rv = snmp_process_getbulk(&snmp_msgData);
                if (SNMP_RET_NOERR != rv) {
                    break;
                }
                flgSendResp = GOAL_TRUE;
            }
            break;

        case SNMP_MSG_GETNEXT:
            snmp_get_statistics()->snmpInGetNexts++;
            rv = snmp_process_getnext(&snmp_msgData);
            if (SNMP_RET_NOERR != rv) {
                break;
            }
            flgSendResp = GOAL_TRUE;
            break;

        case SNMP_MSG_SET:
            snmp_get_statistics()->snmpInSetRequests++;
            rv = snmp_process_set(&snmp_msgData);
            if (SNMP_RET_NOERR != rv) {
                break;
            }
            flgSendResp = GOAL_TRUE;
            break;

        default:
            break;
    }

    /* send response after correct request */
    if (GOAL_TRUE == flgSendResp) {
        /* map v2c to v1 if necessary */
        if (SNMP_V1 == snmp_msgData.version) {
            rv = snmp_responseMapToV1(&snmp_msgData);
            if (SNMP_RET_NOERR != rv) {
                goal_logWarn("failed to SNMP v2c response to v1 response");
            }
        }

        if (SNMP_NOERR != snmp_msgData.error) {
            /* send recieved varlist on error */
            rv = snmp_send(pChan, SNMP_MSG_RESP, snmp_msgData.error, snmp_msgData.error_index, snmp_msgData.xid, snmp_msgData.version, snmp_msgData.pListBackup);
        }
        else {
            /* send answer varlist if no error occured */
            rv = snmp_send(pChan, SNMP_MSG_RESP, snmp_msgData.error, snmp_msgData.error_index, snmp_msgData.xid, snmp_msgData.version, snmp_msgData.list);
        }
        if (SNMP_RET_NOERR != rv) {
            goal_logErr("failed to send SNMP response");
        }

        /* update send counter */
        snmp_get_statistics()->snmpOutGetResponses++;
    }

    /* free varBindLists */
    if (NULL != snmp_msgData.list) {
        snmp_debug_print_entry_list(snmp_msgData.list);
        snmp_free_varlist(snmp_msgData.list);
    }
    if (NULL != snmp_msgData.pListBackup) {
        snmp_free_varlist(snmp_msgData.pListBackup);
    }
}


/****************************************************************************/
/** Sends a SNMPv2c trap to the given IP and destination port
 *
 * @retval SNMP_RET_NOERR success
 * @retval other failed
 */
SNMP_RET_T snmp_send_trap_v2(
    uint32_t ip,                                 /**< Dst address */
    uint16_t dport,                              /**< Dst port */
    uint32_t *pOid,                              /**< Trap OID */
    uint16_t lenOid,                             /**< Trap OID len */
    SNMP_VARLIST_T *pList                        /**< Varlist */
)
{
    SNMP_VARLIST_T *pdulist;                     /* PDU list */
    SNMP_VARENTRY_T *pEntry = NULL;              /* entry ptr */
    SNMP_VARENTRY_T *pTmp = NULL;                /* temp entry ptr */
    SNMP_MIB_NODE_T *pNode = NULL;               /* node ptr */
    SNMP_RET_T rv;                               /* return value */

    /* Allocate varbind list and add sysUpTime and trap OID */
    rv = snmp_alloc_varlist(&pdulist);

    if (SNMP_RET_NOERR == rv) {
        rv = snmp_alloc_varentry(pdulist, ASN1_TIMETICKS, (uint32_t *) &sysUpTime_OID, OID_SYSUPTIME_LEN, &pEntry);
    }

    if (SNMP_RET_NOERR == rv) {
        rv = snmp_mib_find_node((uint32_t *) sysUpTime_OID, OID_SYSUPTIME_LEN, &pNode);
    }

    if (SNMP_RET_NOERR == rv) {
        if (pNode->flags & SNMP_MIB_NODE_FLAG_HAS_SIMPLE_GET) {
            rv = pNode->child.handler.pSimpleHandler->getHandler(NULL, pEntry);
        }
        else {
            rv = SNMP_RET_PARAM;
        }
    }

    if (SNMP_RET_NOERR == rv) {
        rv = snmp_alloc_varentry(pdulist, ASN1_OID, (uint32_t *) snmpTrap_OID, OID_SNMPTRAP_LEN, &pEntry);
    }

    if (SNMP_RET_NOERR == rv) {
        rv = snmp_set_var_value(pEntry, (uint8_t *) pOid, lenOid * sizeof(uint32_t), 0);
        pEntry->var->size = lenOid;
    }
    if (SNMP_RET_NOERR == rv) {
        /* Append list entries to pdu varbind list */
        if ((NULL != pList) && (NULL != pList->head)) {
            pTmp = pdulist->tail;
            pdulist->tail->next = pList->head;
            pdulist->tail = pList->tail;
        }
    }


    GOAL_MEMCPY(&addr, &pSnmpDesc->addr, sizeof(GOAL_NET_ADDR_T));

    pSnmpDesc->addr.remoteIp = ip;
    pSnmpDesc->addr.remotePort = dport;

    if (SNMP_RET_NOERR == rv) {
        snmp_send(pSnmpDesc, SNMP_MSG_TRAPV2, 0, 0, 0, 1, pdulist);
    }
    /* Free up pdu varbind list */
    if ((NULL != pList) && (NULL != pList->head)) {
        pdulist->tail = pTmp;
        pdulist->tail->next = NULL;
    }

    GOAL_MEMCPY(&pSnmpDesc->addr, &addr, sizeof(GOAL_NET_ADDR_T));

    snmp_free_varlist(pdulist);

    return rv;
}


/****************************************************************************/
/** SNMP UDP Data Send Function
 *
 * Sends SNMP answers.
 */
static SNMP_RET_T snmp_send(
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    SNMP_MSG_TYPE_T type,                       /**< message type */
    uint32_t errorCode,                         /**< error code */
    uint32_t errorSpec,                         /**< error specifier */
    uint32_t xid,                               /**< XID */
    uint32_t version,                           /**< version */
    SNMP_VARLIST_T *pVars                       /**< variables list */
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;             /* SNMP return value */
    GOAL_STATUS_T retVal = GOAL_OK;             /* GOAL result */
    GOAL_BUFFER_T *pBuf = NULL;                 /* GOAL buffer desc */
    SNMP_VARENTRY_T *pEntry;                    /* pEntry ptr */
    uint8_t *pData;                             /* data ptr */
    uint32_t msg_size = 0;                      /* message size */
    uint32_t pdu_size = 0;                      /* PDU size */
    uint32_t vblist_size = 0;                   /* vblist size */
    unsigned char *pBuffer;                     /* data buffer ptr */
    uint32_t snmp_version = version;            /* SNMP version ptr */
    uint8_t cnt;                                /* counter */

    /* allocate send buffer */
    if (GOAL_RES_ERR(goal_ethGetNetBuf(&pBuf))) {
        return SNMP_RET_RESOURCE;
    }
    GOAL_MEMSET(pBuf->ptrData, 0, ETH_MTU_LEN);
    pBuffer = pBuf->ptrData;

    snmp_calc_var_enc_len(pVars, &vblist_size);
    pdu_size = vblist_size + 1 + snmp_asn1_get_len_octet_count(vblist_size);

    snmp_asn1_get_encoding_size((uint8_t *) &xid, sizeof(uint32_t), &pdu_size, 0,
            ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) &errorCode,  sizeof(uint32_t),
            &pdu_size, 0, ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) &errorSpec,  sizeof(uint32_t),
            &pdu_size, 0, ASN1_INTEGER);

    msg_size = pdu_size + 1 + snmp_asn1_get_len_octet_count(pdu_size);

    snmp_asn1_get_encoding_size((uint8_t *) &snmp_version, sizeof(uint32_t),
            &msg_size, 0, ASN1_INTEGER);
    snmp_asn1_get_encoding_size((uint8_t *) snmp_op_community,
            (uint16_t) GOAL_STRLEN(snmp_op_community), &msg_size, 0, ASN1_OCTET_STRING);

    /* ASN1 header */
    pBuffer[0] = (uint8_t) 0x30;
    pData = &(pBuffer[1]);

    /* Message size */
    if (msg_size <= 0x7F)
        snmp_asn1_encode_uint32(msg_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    else {
        cnt = snmp_asn1_get_len_octet_count(msg_size);
        *pData = 0x80 + cnt - 1;
        pData++;
        snmp_asn1_encode_len(msg_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    }

    /* Version */
    snmp_asn1_encode((uint8_t *) &snmp_version, sizeof(uint32_t), ASN1_INTEGER,
            (uint8_t *) (pData), 0, (void **) &pData);

    /* Community */
    snmp_asn1_encode((uint8_t *) &(snmp_op_community[0]),
            (uint16_t) GOAL_STRLEN(snmp_op_community), ASN1_OCTET_STRING, (uint8_t *) pData, 0,
            (void **) &pData);

    /* SNMP message size */
    *(pData) = (uint8_t) type;
    pData++;

    /* PDU size */
    if (pdu_size <= 0x7F)
        snmp_asn1_encode_uint32(pdu_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    else {
        cnt = snmp_asn1_get_len_octet_count(pdu_size);
        *pData = 0x80 + cnt - 1;
        pData++;
        snmp_asn1_encode_len(pdu_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    }

    /* Request ID */
    snmp_asn1_encode((uint8_t *) &xid, sizeof(uint32_t), ASN1_INTEGER,
            (uint8_t *) pData, 0, (void **) &pData);

    /* Error Code */
    snmp_asn1_encode((uint8_t *) &errorCode,  sizeof(uint32_t), ASN1_INTEGER,
            (uint8_t *) pData, 0, (void **) &pData);

    /* Specific Error Code */
    snmp_asn1_encode((uint8_t *) &errorSpec,  sizeof(uint32_t), ASN1_INTEGER,
            (uint8_t *) pData, 0, (void **) &pData);

    /* Varbind list */
    *(pData) = (uint8_t) 0x30;
    pData++;
    if (vblist_size <= 0x7F)
        snmp_asn1_encode_uint32(vblist_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    else {
        cnt = snmp_asn1_get_len_octet_count(vblist_size);
        *pData = 0x80 + cnt - 1;
        pData++;
        snmp_asn1_encode_len(vblist_size, (uint8_t *) pData, (void **) &pData, 0, 0);
    }

    if (NULL != pVars) {
        pEntry = pVars->head;
        while (NULL != pEntry) {
            /* ASN1 header */
            *(pData) = (uint8_t) 0x30;
            pData++;


            /* decode length of vars */
            if (pEntry->var->enc_size <= 0x7F)
                snmp_asn1_encode_uint32(pEntry->var->enc_size, (uint8_t *) pData, (void **) &pData, 0, 0);
            else {
                cnt = snmp_asn1_get_len_octet_count(pEntry->var->enc_size);
                *pData = 0x80 + cnt - 1;
                pData++;
                snmp_asn1_encode_len(pEntry->var->enc_size, (uint8_t *) pData, (void **) &pData, 0, 0);
            }

            /* Encode OID */
            snmp_asn1_encode((uint8_t *) pEntry->var->oid, pEntry->var->oid->len,
                    ASN1_OID, (uint8_t *) pData, 0, (void **) &pData);
            /* Do we need to encode something? */
            if (pEntry->var->error_code != 0) {
                *(pData) = (uint8_t) pEntry->var->error_code;
                pData++;
                *(pData) = (uint8_t) 0x00;
                pData++;
            } else if (pEntry->var->size != 0) {
                snmp_asn1_encode((uint8_t *) &(pEntry->var->data[0]),
                        pEntry->var->size, pEntry->var->type, (uint8_t *) pData,
                        pEntry->var->sign, (void **) &pData);
            } else {
                /* Null encoding */
                *(pData) = (uint8_t) 0x5;
                pData++;
                *(pData) = (uint8_t) 0x0;
                pData++;
            }
            pEntry = pEntry->next;
        }
    }

    /* send SNMP response */
    pBuf->dataLen = (uint16_t) (pData - (uint8_t *) pBuffer);
    retVal = goal_netSend(pChan, pBuf);
    if (GOAL_RES_ERR(retVal)) {
        rv = SNMP_RET_NET;
    }

    /* release buffer */
    goal_queueReleaseBuf(&pBuf);

    return rv;
}
