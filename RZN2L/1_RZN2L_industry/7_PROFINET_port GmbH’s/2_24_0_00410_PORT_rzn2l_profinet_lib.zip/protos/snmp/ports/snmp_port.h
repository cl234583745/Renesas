/** @file
 *
 * @brief
 * GOAL port of Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the glue for the Simple Network Management Protocol
 * (SNMP) implementation from port GmbH.
 *
 * @copyright
 * Copyright 2010-2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_PORT_H
#define SNMP_PORT_H

/****************************************************************************/
/* Defines */
/****************************************************************************/
#define GOAL_SNMP_PORT_DEFAULT 161
#define GOAL_SNMP_PORT_PROXY_DEFAULT 16100

#ifdef GOAL_CONFIG_SNMP_PORT
#   define SNMP_SERVER_PORT GOAL_CONFIG_SNMP_PORT
#else
#   ifdef GOAL_CONFIG_SNMP_GOAL_SNMP
#       define SNMP_SERVER_PORT GOAL_SNMP_PORT_DEFAULT
#   else
#       define SNMP_SERVER_PORT GOAL_SNMP_PORT_PROXY_DEFAULT
#   endif
#endif


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T snmp_portInit(
    void
);


#endif /* SNMP_PORT_H */
