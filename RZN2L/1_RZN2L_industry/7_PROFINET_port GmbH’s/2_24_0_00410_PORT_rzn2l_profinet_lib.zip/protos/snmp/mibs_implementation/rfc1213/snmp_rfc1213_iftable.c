/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_rfc1213_iftable.h>
#include <snmp_rfc1213_mib.h>


/****************************************************************************/
/* Variables */
/****************************************************************************/
static IFTABLE_ENTRY_T ifTable[SNMP_RFC1213_IFTABLE_MAX_ENTRIES];
static char *strLocalHost = "lo";
static uint32_t NULL_OID[2] = {0, 0};


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T iftable_updateEntries(
    void
);

static SNMP_RET_T iftable_updateEntry(
    uint32_t idx                                /**< Index */
);

static SNMP_RET_T iftable_updateLinkSpeed(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOperStatus(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateMtu(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOperStatus(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInOctets(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOutOctets(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInDiscards(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOutDiscards(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInErrors(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOutErrors(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInNUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOutNUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateOutUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_updateInUnkownProtosPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T iftable_tableEntryInit(
    uint32_t idx,                               /**< table index */
    uint32_t goalPort                           /**< GOAL port */
);
static SNMP_RET_T iftable_updateOutQLen(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
);

static SNMP_RET_T iftable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Initialize IfTable Entry
*
* @returns SNMP_RET_T status
*/

/****************************************************************************/
/** Initializes ifTable entries
*
* Sets the port names and collects the current values for the entries
* from GOAL.
*
* @retval SNMP_RET_NOERR Table entry initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T iftable_tableEntryInit(
    uint32_t idx,                               /** table index */
    uint32_t goalPort                           /**< GOAL port */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;
    GOAL_STATUS_T res;

    /* check for valid index */
    if (SNMP_RFC1213_IFTABLE_MAX_ENTRIES <= idx) {
        goal_logErr("Wrong table Index: %"FMT_u32", maximum: %"FMT_u32, idx, (uint32_t) SNMP_RFC1213_IFTABLE_MAX_ENTRIES);
        return SNMP_RET_PARAM;
    }

    /* set port */
    ifTable[idx].goalPort = goalPort;

    /* set if type, and MAC address */
    if (GOAL_ETH_PORT_HOST != goalPort) {
        ifTable[idx].type = SNMP_IFTABLE_IFTYPE_ETHERNET_CSMACD;
        res = goal_ethMacAddrGet(goalPort, (GOAL_ETH_MAC_ADDR_T *) ifTable[idx].physAddress);
        if (GOAL_RES_ERR(res)){
           ret = SNMP_RET_RESOURCE;
        }
    }
    else {
        ifTable[idx].type = SNMP_IFTABLE_IFTYPE_SOFTWARELOOPBACK;
    }

    /* set adnim status */
    ifTable[idx].adminStatus = SNMP_IFTABLE_IFADMINSTATUS_UP;

    return ret;
}


/****************************************************************************/
/** Initializes ifTable entries
*
* Sets the port names and collects the current values for the entries
* from GOAL.
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T iftable_init(
    void
)
{
    uint8_t idx;
    uint32_t cnt;
    GOAL_STATUS_T res;
    SNMP_RET_T ret;
    ret = SNMP_RET_NOERR;

    /* clear table */
    GOAL_MEMSET(ifTable, 0, sizeof(ifTable));

    /* get number of ports */
    res = goal_ethPortsGet(&cnt);
    if ((GOAL_RES_ERR(res)) || (ARRAY_ELEMENTS(ifTable) <= cnt)) {
        ret = SNMP_RET_RESOURCE;
    }
    else {
        /* initialize table entries */
        for (idx = 0; idx < cnt; ++idx) {
            ret = iftable_tableEntryInit(idx, GOAL_ETH_PORT(idx));
            if (SNMP_RET_NOERR != ret) {
                goal_logErr("Init of ifTable failed!");
                break;
            }
            ifTable[idx].adminStatus = SNMP_IFTABLE_IFADMINSTATUS_UP;
        }

        /* initialize host port table entry */
        if (SNMP_RET_NOERR == ret) {
            ret = iftable_tableEntryInit(idx, GOAL_ETH_PORT_HOST);
            ifTable[idx].adminStatus = SNMP_IFTABLE_IFADMINSTATUS_UP;
        }

        /* update entries */
        if (SNMP_RET_NOERR == ret) {
            ret = iftable_updateEntries();
        }
    }

    goal_logInfo("SNMP: RFC1213 ifTable initialized.");
    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
*
* @param msg The message containing the get request
* @param pColumn The requested column
* @param pIndex The requested index of the port
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
static SNMP_RET_T iftable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    GOAL_STATUS_T resGoal;                      /* GOAL result */

    uint32_t *pOid;                             /* index OID */

    uint32_t cntPorts;                          /* number of GOAL ports */

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len != 2) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    *pIndex = *pOid - 1;
    pOid++;

    /* Get number of ports and check index */
    resGoal = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(resGoal)) {
            return SNMP_RET_RESOURCE;
    }
    if (*pIndex > cntPorts){
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* check for valid index */
    if (GOAL_TRUE == ifTable[*pIndex].active) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the values of all ifTableEntries
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_PARAM Port information could not be read from GOAL
*/
static SNMP_RET_T iftable_updateEntries(
    void
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T res;                          /* GOAL result */
    uint32_t cntPorts;                          /* number of ports */
    uint8_t idx;                                /* index counter */

    /* get number of ports */
    res = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }

    cntPorts = (SNMP_RFC1213_IFTABLE_MAX_ENTRIES < cntPorts) ? SNMP_RFC1213_IFTABLE_MAX_ENTRIES : cntPorts;

    for (idx = 0; idx < cntPorts; ++idx) {
        ret |= iftable_updateEntry(idx);
    }
    return ret;
}


/****************************************************************************/
/** Updates the ifSpeed value of the given iftable entry
*
*/
static SNMP_RET_T iftable_updateLinkSpeed(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    uint32_t val;                               /* eth cmd return value */
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    if (entry->goalPort & GOAL_ETH_PORT_HOST) {
        val = GOAL_ETH_SPEED_DEFAULT;
    }
    else {
        res = goal_ethLinkSpeedGet(entry->goalPort, &val);
    }

    if (GOAL_RES_ERR(res) || GOAL_ETH_SPEED_DEFAULT == val || GOAL_ETH_SPEED_UNKNOWN == val) {
        entry->speed = 0;
    }
    else {
        entry->speed = val * SNMP_RFC1213_IFTABLE_SPEED_FACTOR;
    }

    return ret;
}


/****************************************************************************/
/** Updates the ifOperStatus value of the given iftable entry
*
*/
static SNMP_RET_T iftable_updateOperStatus(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    uint32_t val;                               /* eth cmd return value */
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    if (entry->goalPort & GOAL_ETH_PORT_HOST) {
        val = GOAL_ETH_STATE_UP;
    }
    else {
        res = goal_ethLinkStateGet(entry->goalPort, &val);
    }

    if (GOAL_RES_ERR(res) || GOAL_ETH_STATE_DEFAULT == val || GOAL_ETH_STATE_UNKNOWN == val) {
        entry->operStatus = SNMP_IFTABLE_IFOPERSTATUS_DOWN;
    }
    else {
        entry->operStatus = (GOAL_ETH_STATE_UP == val) ?
                            SNMP_IFTABLE_IFOPERSTATUS_UP : SNMP_IFTABLE_IFOPERSTATUS_DOWN;
    }

    return ret;
}


/****************************************************************************/
/** Updates the ifMtu value of the given iftable entry
*
*/
static SNMP_RET_T iftable_updateMtu(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    entry->mtu = ETH_MTU_LEN;

    return ret;
}


/****************************************************************************/
/** Updates the ifOutQLen value of the given iftable entry
*
*/
static SNMP_RET_T iftable_updateOutQLen(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    entry->outQLen = 0;

    return ret;
}


/****************************************************************************/
/** Updates the ifInOctets value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateInOctets(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->inOctets, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFINOCTETS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->inOctets = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifOutOctets value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateOutOctets(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->outOctets, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUTOCTETS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->outOctets = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifInDiscards value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateInDiscards(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->inDiscards, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFINDISCARDS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->inDiscards = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifOutDiscards value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateOutDiscards(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->outDiscards, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUTDISCARDS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->outDiscards = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifInErrors value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateInErrors(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->inErrors, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFINERRORS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->inErrors = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifOutErrors value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateOutErrors(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->outErrors, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUTERRORS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->outErrors = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifInNUcastPkts value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateInNUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint64_t val;                               /* value */

    res = goal_statValGetById(&val, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFIN_MCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        val = 0;
    }
    entry->inNUcastPkts = val;

    res = goal_statValGetById(&val, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFIN_BCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        val = 0;
    }
    entry->inNUcastPkts += val;

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifOutNUcastPkts value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateOutNUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint64_t val;                               /* value */

    res = goal_statValGetById(&val, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUT_MCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        val = 0;
    }
    entry->outNUcastPkts = val;

    res = goal_statValGetById(&val, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUT_BCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        val = 0;
    }
    entry->outNUcastPkts += val;

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifInUcastPkts value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateInUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->inUcastPkts, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFIN_UCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->inUcastPkts = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifOutUcastPkts value of the given iftable entry
 *
 */
static SNMP_RET_T iftable_updateOutUcastPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */

    res = goal_statValGetById(&entry->outUcastPkts, GOAL_ID_ETH, GOAL_STAT_ID_ETH_IFOUT_UCAST_PKTS, entry->goalPort);
    if (GOAL_RES_ERR(res)) {
        entry->outUcastPkts = 0;
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the ifInUnknownProtos value of the given iftable entry
*
*/
static SNMP_RET_T iftable_updateInUnkownProtosPkts(
    IFTABLE_ENTRY_T *entry                      /**< Table entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */

    entry->inUnknownProtos = 0;

    return ret;
}


/****************************************************************************/
/** Updates a single iftable entry
*
* @retval SNMP_RET_NOERR entry successfully update
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
* @retval SNMP_RET_PARAM Invalid port index
*/
static SNMP_RET_T iftable_updateEntry(
    uint32_t idx                                /**< Index */
)
{
    GOAL_STATUS_T res;                          /* GOAL result */
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    uint32_t cntPorts;                          /* number of ports */
    IFTABLE_ENTRY_T *entry = &ifTable[idx];     /* ifTable entry */

    /* get number of ports */
    res = goal_ethPortsGet(&cntPorts);
    if (GOAL_RES_ERR(res)) {
        return SNMP_RET_RESOURCE;
    }
    else if (idx > cntPorts) {
        return SNMP_RET_PARAM;
    }

    ret |= iftable_updateLinkSpeed(entry);
    ret |= iftable_updateOperStatus(entry);
    ret |= iftable_updateMtu(entry);
    ret |= iftable_updateOutQLen(entry);
    ret |= iftable_updateInOctets(entry);
    ret |= iftable_updateOutOctets(entry);
    ret |= iftable_updateInDiscards(entry);
    ret |= iftable_updateOutDiscards(entry);
    ret |= iftable_updateInErrors(entry);
    ret |= iftable_updateOutErrors(entry);
    ret |= iftable_updateInNUcastPkts(entry);
    ret |= iftable_updateOutNUcastPkts(entry);
    ret |= iftable_updateInUcastPkts(entry);
    ret |= iftable_updateOutUcastPkts(entry);
    ret |= iftable_updateInUnkownProtosPkts(entry);

    entry->active = GOAL_TRUE;
    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iftable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index;                             /* array index matching request index */
    char description[SNMP_RFC1213_IFTABLE_MAX_DESC]; /* ifDescr */
    char *pDescription = &description[0];       /* pointer to ifDescr */

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = iftable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch(column) {
        case SNMP_IFTABLE_COLUMN_IFDESCR:
            ret = iftable_getPortDescription(index, &pDescription);
            if (SNMP_RET_NOERR != ret) {
                break;
            }
            ret = snmp_set_var_value_type(var, (uint8_t *) pDescription,
                    (uint16_t) GOAL_STRNLEN(pDescription, SNMP_RFC1213_IFTABLE_MAX_DESC), 0, ASN1_OCTET_STRING);
            break;
        case SNMP_IFTABLE_COLUMN_IFINDEX:
            index ++;
            ret = snmp_set_var_value_type(var, (uint8_t *) &(index), sizeof(index), 0,
                        ASN1_INTEGER);
            index --;
            break;
        case SNMP_IFTABLE_COLUMN_IFTYPE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].type), sizeof(ifTable[index].type), 0,
                        ASN1_INTEGER);
            break;
        case SNMP_IFTABLE_COLUMN_IFMTU:
            iftable_updateMtu(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].mtu), sizeof(ifTable[index].mtu), 0,
                        ASN1_INTEGER);
            break;
        case SNMP_IFTABLE_COLUMN_IFSPEED:
            iftable_updateLinkSpeed(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].speed), sizeof(ifTable[index].speed), 0,
                        ASN1_GAUGE);
            break;
        case SNMP_IFTABLE_COLUMN_IFPHYSADDRESS:
            ret = snmp_set_var_value_type(var, (uint8_t *) ifTable[index].physAddress, MAC_ADDR_LEN, 0,
                        ASN1_OCTET_STRING);
            break;
        case SNMP_IFTABLE_COLUMN_IFADMINSTATUS:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].adminStatus), sizeof(ifTable[index].adminStatus), 0,
                        ASN1_INTEGER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOPERSTATUS:
            iftable_updateOperStatus(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].operStatus), sizeof(ifTable[index].operStatus), 0,
                        ASN1_INTEGER);
            break;
        case SNMP_IFTABLE_COLUMN_IFLASTCHANGE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].lastChange), sizeof(ifTable[index].lastChange), 0,
                        ASN1_TIMETICKS);
            break;
        case SNMP_IFTABLE_COLUMN_IFINOCTETS:
            iftable_updateInOctets(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inOctets), sizeof(ifTable[index].inOctets), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFINUCASTPKTS:
            iftable_updateInUcastPkts(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inUcastPkts), sizeof(ifTable[index].inUcastPkts), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFINNUCASTPKTS:
            iftable_updateInNUcastPkts(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inNUcastPkts), sizeof(ifTable[index].inNUcastPkts), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFINDISCARDS:
            iftable_updateInDiscards(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inDiscards), sizeof(ifTable[index].inDiscards), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFINERRORS:
            iftable_updateInErrors(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inErrors), sizeof(ifTable[index].inErrors), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFINUNKNOWNPROTOS:
            iftable_updateInUnkownProtosPkts(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].inUnknownProtos), sizeof(ifTable[index].inUnknownProtos), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTOCTETS:
            iftable_updateOutOctets(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outOctets), sizeof(ifTable[index].outOctets), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTUCASTPKTS:
            iftable_updateOutUcastPkts(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outUcastPkts), sizeof(ifTable[index].outUcastPkts), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTNUCASTPKTS:
            iftable_updateInNUcastPkts(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outNUcastPkts), sizeof(ifTable[index].outNUcastPkts), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTDISCARDS:
            iftable_updateOutDiscards(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outDiscards), sizeof(ifTable[index].outDiscards), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTERRORS:
            iftable_updateOutErrors(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outErrors), sizeof(ifTable[index].outErrors), 0,
                        ASN1_COUNTER);
            break;
        case SNMP_IFTABLE_COLUMN_IFOUTQLEN:
            iftable_updateOutQLen(&ifTable[index]);
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ifTable[index].outQLen), sizeof(ifTable[index].outQLen), 0,
                        ASN1_GAUGE);
            break;
        case SNMP_IFTABLE_COLUMN_IFSPECIFIC:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(NULL_OID), sizeof(NULL_OID), 0,
                        ASN1_OID);
            break;
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Sets the value of the given column and index
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iftable_setValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;
    GOAL_STATUS_T res;
    uint32_t cnt;

    UNUSEDARG(column);

    /* Get number of ports and check index against */
    res = goal_ethPortsGet(&cnt);
    if (GOAL_RES_ERR(res)) {
           return SNMP_RET_RESOURCE;
    }
    cnt++;
    if (index>cnt){
       msg->error = SNMP_ERR_NO_CREATION;
       return SNMP_RET_NOERR;
    }

    switch (column) {


        case SNMP_IFTABLE_COLUMN_IFDESCR:
        case SNMP_IFTABLE_COLUMN_IFINDEX:
        case SNMP_IFTABLE_COLUMN_IFTYPE:
        case SNMP_IFTABLE_COLUMN_IFMTU:
        case SNMP_IFTABLE_COLUMN_IFSPEED:
        case SNMP_IFTABLE_COLUMN_IFPHYSADDRESS:
            msg->error = SNMP_ERR_READ_ONLY;
            break;

        case SNMP_IFTABLE_COLUMN_IFADMINSTATUS:
            ifTable[index-1].adminStatus_old = ifTable[index-1].adminStatus;
            GOAL_MEMCPY(&ifTable[index-1].adminStatus, var->var->data, sizeof(uint32_t));
            break;

        case SNMP_IFTABLE_COLUMN_IFOPERSTATUS:
        case SNMP_IFTABLE_COLUMN_IFLASTCHANGE:
        case SNMP_IFTABLE_COLUMN_IFINOCTETS:
        case SNMP_IFTABLE_COLUMN_IFINUCASTPKTS:
        case SNMP_IFTABLE_COLUMN_IFINNUCASTPKTS:
        case SNMP_IFTABLE_COLUMN_IFINDISCARDS:
        case SNMP_IFTABLE_COLUMN_IFINERRORS:
        case SNMP_IFTABLE_COLUMN_IFINUNKNOWNPROTOS:
        case SNMP_IFTABLE_COLUMN_IFOUTOCTETS:
        case SNMP_IFTABLE_COLUMN_IFOUTUCASTPKTS:
        case SNMP_IFTABLE_COLUMN_IFOUTNUCASTPKTS:
        case SNMP_IFTABLE_COLUMN_IFOUTDISCARDS:
        case SNMP_IFTABLE_COLUMN_IFOUTERRORS:
        case SNMP_IFTABLE_COLUMN_IFOUTQLEN:
        case SNMP_IFTABLE_COLUMN_IFSPECIFIC:
            msg->error = SNMP_ERR_READ_ONLY;
            break;

        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;

}


/****************************************************************************/
/** Undos the last value setting of the given column and index
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iftable_setValue_undo(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;
    GOAL_STATUS_T res;
    uint32_t cnt;

    UNUSEDARG(column);
    UNUSEDARG(var);

    UNUSEDARG(var);

    /* Get number of ports and check index against */
    res = goal_ethPortsGet(&cnt);
    if (GOAL_RES_ERR(res)) {
           return SNMP_RET_RESOURCE;
    }
    cnt++;
    if (index>cnt){
       msg->error = SNMP_ERR_NO_CREATION;
       return SNMP_RET_NOERR;
    }

    switch (column) {
        case SNMP_IFTABLE_COLUMN_IFADMINSTATUS:
            ifTable[index-1].adminStatus = ifTable[index-1].adminStatus_old;
            break;

        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }

    return ret;
}


/****************************************************************************/
/** Sends the new admin state for the given index to GOAL
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iftable_setAdminStatusToGoal(
    uint32_t index
)
{
    //goal_ethLinkStateSet(GOAL_ETH_PORT(index-1), SNMP_IFTABLE_IFADMINSTATUS_UP ==ifTable[index-1].adminStatus?1:0);
   /* TODO: Link State set */
   UNUSEDARG(index);

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Processes a getnext request for the ifTable
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iftable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(ifTable); index++) {
        if (GOAL_TRUE == ifTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(ifTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = iftable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the ifTable - internal part
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
static SNMP_RET_T iftable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[2];                       /* found OID */
    uint32_t foundOidTmp[2];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_IFTABLE_COLUMN_IFINDEX;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_IFTABLE_COLUMN_IFSPECIFIC)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(ifTable); index ++) {

        /* skip inactive entries */
        if (GOAL_TRUE != ifTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = index + 1;

        /* compare OID with given one of GETNEXT request */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = iftable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = iftable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0] ++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = iftable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Get description string for an entry
*
* @retval SNMP_RET_RESOURCE invalid index
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iftable_getPortDescription(
    uint32_t index,                             /**< Index */
    char **pStrName                             /**< port description pointer reference */
)
{
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* SNMP return value */
    GOAL_STATUS_T res;                          /* GOAL result */
    uint32_t cnt;                               /* port count */

    res = goal_ethPortsGet(&cnt);
    if (GOAL_RES_ERR(res) || cnt == 0 || index > cnt ) {
        ret = SNMP_RET_RESOURCE;
    }

    if (SNMP_RET_NOERR == ret) {
        if (GOAL_ETH_PORT_HOST != ifTable[index].goalPort) {
            /* set interface descriptor */
            res = goal_snmpGetInterface(ifTable[index].goalPort, SNMP_RFC1213_IFTABLE_MAX_DESC, pStrName);
            if (GOAL_RES_ERR(res)) {
                return SNMP_RET_RESOURCE;
            }
        }
        else {
            /* set host port */
            GOAL_STRNCPY(*pStrName, strLocalHost, SNMP_RFC1213_IFTABLE_MAX_DESC);
        }
    }

    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Get ifIndex for a given GOAL port
*
* @retval SNMP_RET_PARAM invalid port
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iftable_ifIndexGetByGoalPort(
    uint32_t goalPort,                          /**< GOAL port */
    uint32_t *pIfIndex                          /**< ifIndex */
)
{
    uint32_t index;
    uint32_t cnt;
    GOAL_STATUS_T res;
    res = goal_ethPortsGet(&cnt);
    cnt++;
    if (GOAL_RES_OK(res)) {
        for (index = 0; index < cnt; index++) {
            if (goalPort == ifTable[index].goalPort) {
                *pIfIndex = index + 1;
                return SNMP_RET_NOERR;
            }
        }
    }
    return SNMP_RET_PARAM;
}
