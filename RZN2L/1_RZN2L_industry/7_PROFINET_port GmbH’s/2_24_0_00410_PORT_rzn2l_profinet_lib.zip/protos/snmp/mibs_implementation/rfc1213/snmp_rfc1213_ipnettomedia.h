/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_RFC1213_IPNETTOMEDIA_FILE_H
#define SNMP_RFC1213_IPNETTOMEDIA_FILE_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES 1
#define SNMP_IPNETTOMEDIA_TYPE_OTHER    1
#define SNMP_IPNETTOMEDIA_TYPE_INVALID  2
#define SNMP_IPNETTOMEDIA_TYPE_DYNAMIC  3
#define SNMP_IPNETTOMEDIA_TYPE_STATIC   4


/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef struct {
    GOAL_BOOL_T active;                         /** active flag */
    uint32_t ipNetToMediaIfIndex;               /**< ipNetToMediaIfIndex */
    GOAL_ETH_MAC_ADDR_T ipNetToMediaPhysAddress; /**< ipNetToMediaPhysAddress */
    uint32_t ipNetToMediaNetAddress;            /**< ipNetToMediaNetAddress */
    uint32_t ipNetToMediaType;                  /**< ipNetTOMediaType */
} IPNETTOMEDIA_ENTRY_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T ipnettomedia_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T ipnettomedia_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T ipnettomedia_init(
    void
);

#endif /* SNMP_RFC1213_IPNETTOMEDIA_FILE_H */
