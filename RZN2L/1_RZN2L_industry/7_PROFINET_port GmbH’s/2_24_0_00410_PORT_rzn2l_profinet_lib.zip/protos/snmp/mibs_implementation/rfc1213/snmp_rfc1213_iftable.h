/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_RFC1213_IFTABLE_FILE_H
#define SNMP_RFC1213_IFTABLE_FILE_H

/****************************************************************************/
/* Global Variables */
/****************************************************************************/


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_RFC1213_IFTABLE_MAX_DESC 255
#define SNMP_RFC1213_IFTABLE_MAX_ENTRIES (GOAL_TARGET_ETH_PORT_COUNT + 1)
#define SNMP_RFC1213_IFTABLE_SPEED_FACTOR 1000000


/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef struct {
    GOAL_BOOL_T active;                         /**< active flag */
    uint32_t type;                              /**< ifType */
    uint32_t mtu;                               /**< ifMtu */
    uint32_t speed;                             /**< ifSpeed */
    uint8_t physAddress[6];                     /**< ifPhysAddres */
    uint32_t adminStatus;                       /**< ifAdminStatus */
    uint32_t adminStatus_old;                   /**< ifAdminStatus for undo */
    uint32_t operStatus;                        /**< ifOperStatus */
    uint32_t lastChange;                        /**< ifLastChange */
    uint64_t inOctets;                          /**< ifInOctets */
    uint64_t inUcastPkts;                       /**< ifInUcastPkts */
    uint64_t inNUcastPkts;                      /**< ifInNUcastPkts */
    uint64_t inDiscards;                        /**< ifInDiscards */
    uint64_t inErrors;                          /**< ifInErrors */
    uint64_t inUnknownProtos;                   /**< ifInUnknownProtos */
    uint64_t outOctets;                         /**< ifOutOctets */
    uint64_t outUcastPkts;                      /**< ifOutUcastPkts */
    uint64_t outNUcastPkts;                     /**< ifOutNUcastPkts */
    uint64_t outDiscards;                       /**< ifOutDiscards */
    uint64_t outErrors;                         /**< ifOutErrors */
    uint64_t outQLen;                           /**< ifOutQLen */
    uint32_t goalPort;                          /**< GOAL port */
} IFTABLE_ENTRY_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T iftable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iftable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


SNMP_RET_T iftable_setValue(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iftable_setValue_undo(
    uint32_t index,                             /**< Index */
    uint32_t column,                            /**< Column */
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iftable_setAdminStatusToGoal(
    uint32_t index                              /**< table index */
);

SNMP_RET_T iftable_init(
    void
);

SNMP_RET_T iftable_getPortDescription(
    uint32_t index,                             /**< Index */
    char **pName                                /**< Port description */
);

SNMP_RET_T iftable_ifIndexGetByGoalPort(
    uint32_t goalPort,                          /**< GOAL port */
    uint32_t *pIfIndex                          /**< ifIndex */
);

#endif /* SNMP_RFC1213_IFTABLE_FILE_H */
