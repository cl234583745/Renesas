/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_rfc1213_iproutetable.h>
#include <snmp_rfc1213_mib.h>
#include <snmp_rfc1213_iftable.h>



/****************************************************************************/
/* Variables */
/****************************************************************************/
static IPROUTETABLE_ENTRY_T ipRouteTable[SNMP_RFC1213_IPROUTETABLE_MAX_ENTRIES];
static uint32_t IPROUTE_NULL_OID[2] = {0, 0};


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T iproutetable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T iproutetable_updateEntries(
    void
);

static SNMP_RET_T iproutetable_tableEntryUpdate(
    uint32_t idx
);

static SNMP_RET_T iproutetable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);


/****************************************************************************/
/** Updates an ipRouteTable entry
*
*
* @retval SNMP_RET_NOERR Table initialized
*/
SNMP_RET_T iproutetable_tableEntryUpdate(
    uint32_t idx                                /**< Index */
)
{
    uint32_t addrIp;                            /* IP address */
    uint32_t addrMask;                          /* IP mask */
    uint32_t addrGw;                            /* Gateway */
    GOAL_BOOL_T flgTemp;                        /* Temp flag */
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* Return value */
    GOAL_STATUS_T res;                          /* Result */

    /* check for valid index */
    if (SNMP_RFC1213_IPROUTETABLE_MAX_ENTRIES <= idx) {
        goal_logErr("Wrong table Index: %"FMT_u32", maximum: %"FMT_u32, idx, (uint32_t) SNMP_RFC1213_IPROUTETABLE_MAX_ENTRIES);
        return SNMP_RET_PARAM;
    }

    /* TODO: Support more than one route */
    res = goal_netIpGet(&addrIp, &addrMask, &addrGw, &flgTemp);

    if (GOAL_RES_OK(res)) {
        ipRouteTable[idx].ipRouteDest = 0;
        ret = iftable_ifIndexGetByGoalPort(GOAL_ETH_PORT_HOST, &ipRouteTable[idx].ipRouteIfIndex);
        if (SNMP_RET_NOERR != ret) {
            ipRouteTable[idx].active = GOAL_FALSE;
            return ret;
        }
        else {
            ipRouteTable[idx].ipRouteMetric1 = -1;
            ipRouteTable[idx].ipRouteMetric2 = -1;
            ipRouteTable[idx].ipRouteMetric3 = -1;
            ipRouteTable[idx].ipRouteMetric4 = -1;
            ipRouteTable[idx].ipRouteMetric5 = -1;
            ipRouteTable[idx].ipRouteNextHop = addrGw;
            ipRouteTable[idx].ipRouteType = SNMP_RFC1213_IPROUTETYPE_DIRECT;
            ipRouteTable[idx].ipRouteProto = SNMP_RFC1213_IPROUTEPROTO_LOCAL;
            ipRouteTable[idx].ipRouteAge = 0;
            ipRouteTable[idx].ipRouteMask = addrMask;

            ipRouteTable[idx].active = GOAL_TRUE;
        }
    }
    else {
        ipRouteTable[idx].active = GOAL_FALSE;
    }
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** Initializes ipRouteTable entries
*
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T iproutetable_init(
    void
)
{
    SNMP_RET_T ret;                             /* Return value */

    ret = SNMP_RET_NOERR;
    GOAL_MEMSET(ipRouteTable, 0, sizeof(ipRouteTable));
    iproutetable_updateEntries();

    goal_logInfo("SNMP: RFC1213 ipRouteTable initialized.");

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
*
* @param msg The message containing the get request
* @param pColumn The requested column
* @param pIndex of table entry matching the index OID
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
static SNMP_RET_T iproutetable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    uint32_t *pOid;                             /* index OID */

    uint32_t ip;                                /* ip address */
    uint32_t cnt;

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len != 5) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    ip = GOAL_SNMP_IP_ADDR_FROM_OID(pOid);
    pOid += 4;

    /* Look for the according entry in the ipTable */
    for (cnt = 0; cnt < ARRAY_ELEMENTS(ipRouteTable); cnt++) {
        /* check for valid index */
        if ((GOAL_TRUE == ipRouteTable[cnt].active) &&
            (ip == ipRouteTable[cnt].ipRouteDest)) {
                *pIndex = cnt;
                break;
        }
    }

    /* Set no error code return if something was found */
    if (ARRAY_ELEMENTS(ipRouteTable) > cnt) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the values of all ipRouteTableEntries
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_PARAM Port information could not be read from GOAL
*/
SNMP_RET_T iproutetable_updateEntries(
    void
)
{
    uint8_t idx;                                /* Index */
    SNMP_RET_T ret;                             /* SNMP return value */

    for (idx = 0; idx < SNMP_RFC1213_IPROUTETABLE_MAX_ENTRIES; ++idx) {
        ret = iproutetable_tableEntryUpdate(idx);
        if (SNMP_RET_NOERR == ret) {
            ipRouteTable[idx].active = GOAL_FALSE;
        }
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iproutetable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index;                             /* array index matching request index */


    /* clear error message */
    msg->error = SNMP_NOERR;

    /* Update address info */
    ret = iproutetable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* get table entry matching OID */
    ret = iproutetable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch(column) {
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEDEST:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteDest),
                            sizeof(ipRouteTable[index].ipRouteDest), 0, ASN1_IPADDR);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEIFINDEX:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteIfIndex),
                            sizeof(ipRouteTable[index].ipRouteIfIndex), 0, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC1:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMetric1),
                            sizeof(ipRouteTable[index].ipRouteMetric1), 1, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC2:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMetric2),
                            sizeof(ipRouteTable[index].ipRouteMetric2), 1, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC3:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMetric3),
                            sizeof(ipRouteTable[index].ipRouteMetric3), 1, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC4:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMetric4),
                            sizeof(ipRouteTable[index].ipRouteMetric4), 1, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC5:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMetric5),
                            sizeof(ipRouteTable[index].ipRouteMetric5), 1, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTENEXTHOP:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteNextHop),
                            sizeof(ipRouteTable[index].ipRouteNextHop), 0, ASN1_IPADDR);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTETYPE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteType),
                            sizeof(ipRouteTable[index].ipRouteType), 0, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEPROTO:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteProto),
                            sizeof(ipRouteTable[index].ipRouteProto), 0, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEAGE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteAge),
                            sizeof(ipRouteTable[index].ipRouteAge), 0, ASN1_INTEGER);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEMASK:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipRouteTable[index].ipRouteMask),
                            sizeof(ipRouteTable[index].ipRouteMask), 0, ASN1_IPADDR);
            break;
        case SNMP_IPROUTETABLE_COLUMN_IPROUTEINFO:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(IPROUTE_NULL_OID),
                            sizeof(IPROUTE_NULL_OID), 0, ASN1_OID);
            break;
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the ipRouteTable
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iproutetable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* Update table entries */
    ret = iproutetable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(ipRouteTable); index++) {
        if (GOAL_TRUE == ipRouteTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(ipRouteTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = iproutetable_getNextInternal(msg, var);
    return ret;
}



/****************************************************************************/
/** Processes a getnext request for the ipRouteTable - internal part
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iproutetable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[5];                       /* found OID */
    uint32_t foundOidTmp[5];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* Update address info */
    ret = iproutetable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_IPROUTETABLE_COLUMN_IPROUTEDEST;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_IPROUTETABLE_COLUMN_IPROUTEINFO)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(ipRouteTable); index ++) {

        /* skip inactive entries */
        if (GOAL_TRUE != ipRouteTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        GOAL_SNMP_IP_ADDR_TO_OID(&foundOidTmp[1], ipRouteTable[index].ipRouteDest);

        /* compare OID with given one of GETNEXT request */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = iproutetable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = iproutetable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0] ++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = iproutetable_getNextInternal(msg, var);
    return ret;
}
