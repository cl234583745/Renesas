/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */


#ifndef SNMP_RFC1213_H
#define SNMP_RFC1213_H

/****************************************************************************/
/* Constants */
/****************************************************************************/
#define GOAL_SNMP_MIB2_CM_MOD_ID    GOAL_ID_SNMP /**< CM module ID */
#define GOAL_SNMP_MIB2_SYSSTRINGLEN 255

/* Constants definition for snmpInGetNexts */
#define SNMP_SNMPINGETNEXTS_LOWER_LIMIT 0
#define SNMP_SNMPINGETNEXTS_UPPER_LIMIT 0

/* Constants definition for icmpOutEchoReps */
#define SNMP_ICMPOUTECHOREPS_LOWER_LIMIT 0
#define SNMP_ICMPOUTECHOREPS_UPPER_LIMIT 0

/* Constants definition for tcpRtoAlgorithm */
#define SNMP_TCPRTOALGORITHM_OTHER 1
#define SNMP_TCPRTOALGORITHM_CONSTANT 2
#define SNMP_TCPRTOALGORITHM_RSRE 3
#define SNMP_TCPRTOALGORITHM_VANJ 4
#define SNMP_TCPRTOALGORITHM_LOWER_LIMIT 1
#define SNMP_TCPRTOALGORITHM_UPPER_LIMIT 4

/* Constants definition for tcpOutSegs */
#define SNMP_TCPOUTSEGS_LOWER_LIMIT 0
#define SNMP_TCPOUTSEGS_UPPER_LIMIT 0

/* Columns constants definition for ipAddrTable */
#define SNMP_IPADDRTABLE_COLUMN_IPADENTADDR 1
#define SNMP_IPADDRTABLE_COLUMN_IPADENTIFINDEX 2
#define SNMP_IPADDRTABLE_COLUMN_IPADENTNETMASK 3
#define SNMP_IPADDRTABLE_COLUMN_IPADENTBCASTADDR 4
#define SNMP_IPADDRTABLE_COLUMN_IPADENTREASMMAXSIZE 5

/* Constants definition for ipFragOKs */
#define SNMP_IPFRAGOKS_LOWER_LIMIT 0
#define SNMP_IPFRAGOKS_UPPER_LIMIT 0

/* Constants definition for sysServices */
#define SNMP_SYSSERVICES_LOWER_LIMIT 0
#define SNMP_SYSSERVICES_UPPER_LIMIT 127

/* Constants definition for snmpInGetResponses */
#define SNMP_SNMPINGETRESPONSES_LOWER_LIMIT 0
#define SNMP_SNMPINGETRESPONSES_UPPER_LIMIT 0

/* Constants definition for snmpInBadCommunityUses */
#define SNMP_SNMPINBADCOMMUNITYUSES_LOWER_LIMIT 0
#define SNMP_SNMPINBADCOMMUNITYUSES_UPPER_LIMIT 0

/* Constants definition for ipInReceives */
#define SNMP_IPINRECEIVES_LOWER_LIMIT 0
#define SNMP_IPINRECEIVES_UPPER_LIMIT 0

/* Constants definition for ipOutRequests */
#define SNMP_IPOUTREQUESTS_LOWER_LIMIT 0
#define SNMP_IPOUTREQUESTS_UPPER_LIMIT 0

/* Constants definition for sysObjectID */

/* Constants definition for icmpOutDestUnreachs */
#define SNMP_ICMPOUTDESTUNREACHS_LOWER_LIMIT 0
#define SNMP_ICMPOUTDESTUNREACHS_UPPER_LIMIT 0

/* Constants definition for tcpRtoMax */
#define SNMP_TCPRTOMAX_LOWER_LIMIT 0
#define SNMP_TCPRTOMAX_UPPER_LIMIT 0

/* Constants definition for snmpOutGetResponses */
#define SNMP_SNMPOUTGETRESPONSES_LOWER_LIMIT 0
#define SNMP_SNMPOUTGETRESPONSES_UPPER_LIMIT 0

/* Constants definition for tcpPassiveOpens */
#define SNMP_TCPPASSIVEOPENS_LOWER_LIMIT 0
#define SNMP_TCPPASSIVEOPENS_UPPER_LIMIT 0

/* Columns constants definition for atTable */
#define SNMP_ATTABLE_COLUMN_ATIFINDEX 1
#define SNMP_ATTABLE_COLUMN_ATPHYSADDRESS 2
#define SNMP_ATTABLE_COLUMN_ATNETADDRESS 3

/* Constants definition for snmpOutGetNexts */
#define SNMP_SNMPOUTGETNEXTS_LOWER_LIMIT 0
#define SNMP_SNMPOUTGETNEXTS_UPPER_LIMIT 0

/* Constants definition for tcpInErrs */
#define SNMP_TCPINERRS_LOWER_LIMIT 0
#define SNMP_TCPINERRS_UPPER_LIMIT 0

/* Constants definition for snmpInTotalReqVars */
#define SNMP_SNMPINTOTALREQVARS_LOWER_LIMIT 0
#define SNMP_SNMPINTOTALREQVARS_UPPER_LIMIT 0

/* Constants definition for icmpInParmProbs */
#define SNMP_ICMPINPARMPROBS_LOWER_LIMIT 0
#define SNMP_ICMPINPARMPROBS_UPPER_LIMIT 0

/* Constants definition for udpOutDatagrams */
#define SNMP_UDPOUTDATAGRAMS_LOWER_LIMIT 0
#define SNMP_UDPOUTDATAGRAMS_UPPER_LIMIT 0

/* Constants definition for sysUpTime */
#define SNMP_SYSUPTIME_LOWER_LIMIT 0
#define SNMP_SYSUPTIME_UPPER_LIMIT 0

/* Constants definition for icmpOutAddrMaskReps */
#define SNMP_ICMPOUTADDRMASKREPS_LOWER_LIMIT 0
#define SNMP_ICMPOUTADDRMASKREPS_UPPER_LIMIT 0

/* Constants definition for udpInErrors */
#define SNMP_UDPINERRORS_LOWER_LIMIT 0
#define SNMP_UDPINERRORS_UPPER_LIMIT 0

/* Constants definition for icmpOutAddrMasks */
#define SNMP_ICMPOUTADDRMASKS_LOWER_LIMIT 0
#define SNMP_ICMPOUTADDRMASKS_UPPER_LIMIT 0

/* Constants definition for egpAs */
#define SNMP_EGPAS_LOWER_LIMIT 0
#define SNMP_EGPAS_UPPER_LIMIT 0

/* Constants definition for icmpInAddrMasks */
#define SNMP_ICMPINADDRMASKS_LOWER_LIMIT 0
#define SNMP_ICMPINADDRMASKS_UPPER_LIMIT 0

/* Columns constants definition for udpTable */
#define SNMP_UDPTABLE_COLUMN_UDPLOCALADDRESS 1
#define SNMP_UDPTABLE_COLUMN_UDPLOCALPORT 2

/* Constants definition for ipOutDiscards */
#define SNMP_IPOUTDISCARDS_LOWER_LIMIT 0
#define SNMP_IPOUTDISCARDS_UPPER_LIMIT 0

/* Constants definition for icmpOutTimestamps */
#define SNMP_ICMPOUTTIMESTAMPS_LOWER_LIMIT 0
#define SNMP_ICMPOUTTIMESTAMPS_UPPER_LIMIT 0

/* Constants definition for snmpInSetRequests */
#define SNMP_SNMPINSETREQUESTS_LOWER_LIMIT 0
#define SNMP_SNMPINSETREQUESTS_UPPER_LIMIT 0

/* Constants definition for icmpInTimestampReps */
#define SNMP_ICMPINTIMESTAMPREPS_LOWER_LIMIT 0
#define SNMP_ICMPINTIMESTAMPREPS_UPPER_LIMIT 0

/* Constants definition for ipInHdrErrors */
#define SNMP_IPINHDRERRORS_LOWER_LIMIT 0
#define SNMP_IPINHDRERRORS_UPPER_LIMIT 0

/* Constants definition for icmpInMsgs */
#define SNMP_ICMPINMSGS_LOWER_LIMIT 0
#define SNMP_ICMPINMSGS_UPPER_LIMIT 0

/* Constants definition for snmpOutNoSuchNames */
#define SNMP_SNMPOUTNOSUCHNAMES_LOWER_LIMIT 0
#define SNMP_SNMPOUTNOSUCHNAMES_UPPER_LIMIT 0

/* Constants definition for icmpOutParmProbs */
#define SNMP_ICMPOUTPARMPROBS_LOWER_LIMIT 0
#define SNMP_ICMPOUTPARMPROBS_UPPER_LIMIT 0

/* Constants definition for icmpOutMsgs */
#define SNMP_ICMPOUTMSGS_LOWER_LIMIT 0
#define SNMP_ICMPOUTMSGS_UPPER_LIMIT 0

/* Constants definition for egpInErrors */
#define SNMP_EGPINERRORS_LOWER_LIMIT 0
#define SNMP_EGPINERRORS_UPPER_LIMIT 0

/* Constants definition for icmpInEchoReps */
#define SNMP_ICMPINECHOREPS_LOWER_LIMIT 0
#define SNMP_ICMPINECHOREPS_UPPER_LIMIT 0

/* Constants definition for snmpOutTooBigs */
#define SNMP_SNMPOUTTOOBIGS_LOWER_LIMIT 0
#define SNMP_SNMPOUTTOOBIGS_UPPER_LIMIT 0

/* Constants definition for icmpInTimeExcds */
#define SNMP_ICMPINTIMEEXCDS_LOWER_LIMIT 0
#define SNMP_ICMPINTIMEEXCDS_UPPER_LIMIT 0

/* Constants definition for sysLocation */

/* Columns constants definition for tcpConnTable */
#define SNMP_TCPCONNTABLE_COLUMN_TCPCONNSTATE 1
#define SNMP_TCPCONNTABLE_COLUMN_TCPCONNLOCALADDRESS 2
#define SNMP_TCPCONNTABLE_COLUMN_TCPCONNLOCALPORT 3
#define SNMP_TCPCONNTABLE_COLUMN_TCPCONNREMADDRESS 4
#define SNMP_TCPCONNTABLE_COLUMN_TCPCONNREMPORT 5

/* Constants definition for ipRoutingDiscards */
#define SNMP_IPROUTINGDISCARDS_LOWER_LIMIT 0
#define SNMP_IPROUTINGDISCARDS_UPPER_LIMIT 0

/* Constants definition for snmpInGetRequests */
#define SNMP_SNMPINGETREQUESTS_LOWER_LIMIT 0
#define SNMP_SNMPINGETREQUESTS_UPPER_LIMIT 0

/* Constants definition for snmpInTotalSetVars */
#define SNMP_SNMPINTOTALSETVARS_LOWER_LIMIT 0
#define SNMP_SNMPINTOTALSETVARS_UPPER_LIMIT 0

/* Columns constants definition for ifTable */
#define SNMP_IFTABLE_COLUMN_IFINDEX 1
#define SNMP_IFTABLE_COLUMN_IFDESCR 2
#define SNMP_IFTABLE_COLUMN_IFTYPE 3
#define SNMP_IFTABLE_COLUMN_IFMTU 4
#define SNMP_IFTABLE_COLUMN_IFSPEED 5
#define SNMP_IFTABLE_COLUMN_IFPHYSADDRESS 6
#define SNMP_IFTABLE_COLUMN_IFADMINSTATUS 7
#define SNMP_IFTABLE_COLUMN_IFOPERSTATUS 8
#define SNMP_IFTABLE_COLUMN_IFLASTCHANGE 9
#define SNMP_IFTABLE_COLUMN_IFINOCTETS 10
#define SNMP_IFTABLE_COLUMN_IFINUCASTPKTS 11
#define SNMP_IFTABLE_COLUMN_IFINNUCASTPKTS 12
#define SNMP_IFTABLE_COLUMN_IFINDISCARDS 13
#define SNMP_IFTABLE_COLUMN_IFINERRORS 14
#define SNMP_IFTABLE_COLUMN_IFINUNKNOWNPROTOS 15
#define SNMP_IFTABLE_COLUMN_IFOUTOCTETS 16
#define SNMP_IFTABLE_COLUMN_IFOUTUCASTPKTS 17
#define SNMP_IFTABLE_COLUMN_IFOUTNUCASTPKTS 18
#define SNMP_IFTABLE_COLUMN_IFOUTDISCARDS 19
#define SNMP_IFTABLE_COLUMN_IFOUTERRORS 20
#define SNMP_IFTABLE_COLUMN_IFOUTQLEN 21
#define SNMP_IFTABLE_COLUMN_IFSPECIFIC 22

/* Constants definition for ifType */
#define SNMP_IFTABLE_IFTYPE_SDLC 17
#define SNMP_IFTABLE_IFTYPE_DDN_X25 4
#define SNMP_IFTABLE_IFTYPE_PROPPOINTTOPOINTSERIAL 22
#define SNMP_IFTABLE_IFTYPE_ULTRA 29
#define SNMP_IFTABLE_IFTYPE_SLIP 28
#define SNMP_IFTABLE_IFTYPE_OTHER 1
#define SNMP_IFTABLE_IFTYPE_ETHERNET_3MBIT 26
#define SNMP_IFTABLE_IFTYPE_EON 25
#define SNMP_IFTABLE_IFTYPE_FDDI 15
#define SNMP_IFTABLE_IFTYPE_E1 19
#define SNMP_IFTABLE_IFTYPE_NSIP 27
#define SNMP_IFTABLE_IFTYPE_STARLAN 11
#define SNMP_IFTABLE_IFTYPE_DS3 30
#define SNMP_IFTABLE_IFTYPE_ETHERNET_CSMACD 6
#define SNMP_IFTABLE_IFTYPE_HDH1822 3
#define SNMP_IFTABLE_IFTYPE_DS1 18
#define SNMP_IFTABLE_IFTYPE_ISO88023_CSMACD 7
#define SNMP_IFTABLE_IFTYPE_RFC877_X25 5
#define SNMP_IFTABLE_IFTYPE_ISO88024_TOKENBUS 8
#define SNMP_IFTABLE_IFTYPE_REGULAR1822 2
#define SNMP_IFTABLE_IFTYPE_PROTEON_80MBIT 13
#define SNMP_IFTABLE_IFTYPE_FRAME_RELAY 32
#define SNMP_IFTABLE_IFTYPE_ISO88026_MAN 10
#define SNMP_IFTABLE_IFTYPE_PPP 23
#define SNMP_IFTABLE_IFTYPE_ISO88025_TOKENRING 9
#define SNMP_IFTABLE_IFTYPE_PRIMARYISDN 21
#define SNMP_IFTABLE_IFTYPE_PROTEON_10MBIT 12
#define SNMP_IFTABLE_IFTYPE_LAPB 16
#define SNMP_IFTABLE_IFTYPE_HYPERCHANNEL 14
#define SNMP_IFTABLE_IFTYPE_BASICISDN 20
#define SNMP_IFTABLE_IFTYPE_SIP 31
#define SNMP_IFTABLE_IFTYPE_SOFTWARELOOPBACK 24

/* Constants definition for ifAdminStatus */
#define SNMP_IFTABLE_IFADMINSTATUS_UP 1
#define SNMP_IFTABLE_IFADMINSTATUS_TESTING 3
#define SNMP_IFTABLE_IFADMINSTATUS_DOWN 2

/* Constants definition for ifOperStatus */
#define SNMP_IFTABLE_IFOPERSTATUS_UP 1
#define SNMP_IFTABLE_IFOPERSTATUS_TESTING 3
#define SNMP_IFTABLE_IFOPERSTATUS_DOWN 2

/* Constants definition for snmpInReadOnlys */
#define SNMP_SNMPINREADONLYS_LOWER_LIMIT 0
#define SNMP_SNMPINREADONLYS_UPPER_LIMIT 0

/* Constants definition for ipForwDatagrams */
#define SNMP_IPFORWDATAGRAMS_LOWER_LIMIT 0
#define SNMP_IPFORWDATAGRAMS_UPPER_LIMIT 0

/* Constants definition for icmpOutTimeExcds */
#define SNMP_ICMPOUTTIMEEXCDS_LOWER_LIMIT 0
#define SNMP_ICMPOUTTIMEEXCDS_UPPER_LIMIT 0

/* Constants definition for icmpOutEchos */
#define SNMP_ICMPOUTECHOS_LOWER_LIMIT 0
#define SNMP_ICMPOUTECHOS_UPPER_LIMIT 0

/* Constants definition for egpOutMsgs */
#define SNMP_EGPOUTMSGS_LOWER_LIMIT 0
#define SNMP_EGPOUTMSGS_UPPER_LIMIT 0

/* Constants definition for icmpInSrcQuenchs */
#define SNMP_ICMPINSRCQUENCHS_LOWER_LIMIT 0
#define SNMP_ICMPINSRCQUENCHS_UPPER_LIMIT 0

/* Constants definition for icmpOutErrors */
#define SNMP_ICMPOUTERRORS_LOWER_LIMIT 0
#define SNMP_ICMPOUTERRORS_UPPER_LIMIT 0

/* Constants definition for tcpActiveOpens */
#define SNMP_TCPACTIVEOPENS_LOWER_LIMIT 0
#define SNMP_TCPACTIVEOPENS_UPPER_LIMIT 0

/* Columns constants definition for egpNeighTable */
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHSTATE 1
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHADDR 2
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHAS 3
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHINMSGS 4
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHINERRS 5
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHOUTMSGS 6
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHOUTERRS 7
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHINERRMSGS 8
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHOUTERRMSGS 9
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHSTATEUPS 10
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHSTATEDOWNS 11
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHINTERVALHELLO 12
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHINTERVALPOLL 13
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHMODE 14
#define SNMP_EGPNEIGHTABLE_COLUMN_EGPNEIGHEVENTTRIGGER 15

/* Constants definition for tcpEstabResets */
#define SNMP_TCPESTABRESETS_LOWER_LIMIT 0
#define SNMP_TCPESTABRESETS_UPPER_LIMIT 0

/* Constants definition for ipInDelivers */
#define SNMP_IPINDELIVERS_LOWER_LIMIT 0
#define SNMP_IPINDELIVERS_UPPER_LIMIT 0

/* Constants definition for icmpInErrors */
#define SNMP_ICMPINERRORS_LOWER_LIMIT 0
#define SNMP_ICMPINERRORS_UPPER_LIMIT 0

/* Constants definition for ipReasmTimeout */
#define SNMP_IPREASMTIMEOUT_LOWER_LIMIT 0
#define SNMP_IPREASMTIMEOUT_UPPER_LIMIT 0

/* Constants definition for snmpInPkts */
#define SNMP_SNMPINPKTS_LOWER_LIMIT 0
#define SNMP_SNMPINPKTS_UPPER_LIMIT 0

/* Constants definition for ipOutNoRoutes */
#define SNMP_IPOUTNOROUTES_LOWER_LIMIT 0
#define SNMP_IPOUTNOROUTES_UPPER_LIMIT 0

/* Constants definition for tcpRtoMin */
#define SNMP_TCPRTOMIN_LOWER_LIMIT 0
#define SNMP_TCPRTOMIN_UPPER_LIMIT 0

/* Constants definition for ipFragFails */
#define SNMP_IPFRAGFAILS_LOWER_LIMIT 0
#define SNMP_IPFRAGFAILS_UPPER_LIMIT 0

/* Constants definition for udpNoPorts */
#define SNMP_UDPNOPORTS_LOWER_LIMIT 0
#define SNMP_UDPNOPORTS_UPPER_LIMIT 0

/* Constants definition for snmpOutGenErrs */
#define SNMP_SNMPOUTGENERRS_LOWER_LIMIT 0
#define SNMP_SNMPOUTGENERRS_UPPER_LIMIT 0

/* Constants definition for sysName */

/* Constants definition for icmpInDestUnreachs */
#define SNMP_ICMPINDESTUNREACHS_LOWER_LIMIT 0
#define SNMP_ICMPINDESTUNREACHS_UPPER_LIMIT 0

/* Constants definition for ipInAddrErrors */
#define SNMP_IPINADDRERRORS_LOWER_LIMIT 0
#define SNMP_IPINADDRERRORS_UPPER_LIMIT 0

/* Constants definition for ipDefaultTTL */
#define SNMP_IPDEFAULTTTL_LOWER_LIMIT 0
#define SNMP_IPDEFAULTTTL_UPPER_LIMIT 0

/* Constants definition for tcpRetransSegs */
#define SNMP_TCPRETRANSSEGS_LOWER_LIMIT 0
#define SNMP_TCPRETRANSSEGS_UPPER_LIMIT 0

/* Constants definition for ipFragCreates */
#define SNMP_IPFRAGCREATES_LOWER_LIMIT 0
#define SNMP_IPFRAGCREATES_UPPER_LIMIT 0

/* Constants definition for ipInUnknownProtos */
#define SNMP_IPINUNKNOWNPROTOS_LOWER_LIMIT 0
#define SNMP_IPINUNKNOWNPROTOS_UPPER_LIMIT 0

/* Constants definition for udpInDatagrams */
#define SNMP_UDPINDATAGRAMS_LOWER_LIMIT 0
#define SNMP_UDPINDATAGRAMS_UPPER_LIMIT 0

/* Constants definition for tcpOutRsts */
#define SNMP_TCPOUTRSTS_LOWER_LIMIT 0
#define SNMP_TCPOUTRSTS_UPPER_LIMIT 0

/* Constants definition for icmpInEchos */
#define SNMP_ICMPINECHOS_LOWER_LIMIT 0
#define SNMP_ICMPINECHOS_UPPER_LIMIT 0

/* Constants definition for icmpOutRedirects */
#define SNMP_ICMPOUTREDIRECTS_LOWER_LIMIT 0
#define SNMP_ICMPOUTREDIRECTS_UPPER_LIMIT 0

/* Constants definition for ifNumber */
#define SNMP_IFNUMBER_LOWER_LIMIT 0
#define SNMP_IFNUMBER_UPPER_LIMIT 0

/* Constants definition for icmpInRedirects */
#define SNMP_ICMPINREDIRECTS_LOWER_LIMIT 0
#define SNMP_ICMPINREDIRECTS_UPPER_LIMIT 0

/* Constants definition for tcpMaxConn */
#define SNMP_TCPMAXCONN_LOWER_LIMIT 0
#define SNMP_TCPMAXCONN_UPPER_LIMIT 0

/* Constants definition for snmpInTooBigs */
#define SNMP_SNMPINTOOBIGS_LOWER_LIMIT 0
#define SNMP_SNMPINTOOBIGS_UPPER_LIMIT 0

/* Constants definition for icmpInAddrMaskReps */
#define SNMP_ICMPINADDRMASKREPS_LOWER_LIMIT 0
#define SNMP_ICMPINADDRMASKREPS_UPPER_LIMIT 0

/* Constants definition for egpInMsgs */
#define SNMP_EGPINMSGS_LOWER_LIMIT 0
#define SNMP_EGPINMSGS_UPPER_LIMIT 0

/* Constants definition for snmpOutBadValues */
#define SNMP_SNMPOUTBADVALUES_LOWER_LIMIT 0
#define SNMP_SNMPOUTBADVALUES_UPPER_LIMIT 0

/* Columns constants definition for ipRouteTable */
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEDEST 1
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEIFINDEX 2
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC1 3
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC2 4
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC3 5
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC4 6
#define SNMP_IPROUTETABLE_COLUMN_IPROUTENEXTHOP 7
#define SNMP_IPROUTETABLE_COLUMN_IPROUTETYPE 8
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEPROTO 9
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEAGE 10
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMASK 11
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEMETRIC5 12
#define SNMP_IPROUTETABLE_COLUMN_IPROUTEINFO 13

/* Constants definition for snmpInNoSuchNames */
#define SNMP_SNMPINNOSUCHNAMES_LOWER_LIMIT 0
#define SNMP_SNMPINNOSUCHNAMES_UPPER_LIMIT 0

/* Constants definition for tcpInSegs */
#define SNMP_TCPINSEGS_LOWER_LIMIT 0
#define SNMP_TCPINSEGS_UPPER_LIMIT 0

/* Constants definition for snmpOutTraps */
#define SNMP_SNMPOUTTRAPS_LOWER_LIMIT 0
#define SNMP_SNMPOUTTRAPS_UPPER_LIMIT 0

/* Constants definition for egpOutErrors */
#define SNMP_EGPOUTERRORS_LOWER_LIMIT 0
#define SNMP_EGPOUTERRORS_UPPER_LIMIT 0

/* Constants definition for snmpInBadValues */
#define SNMP_SNMPINBADVALUES_LOWER_LIMIT 0
#define SNMP_SNMPINBADVALUES_UPPER_LIMIT 0

/* Constants definition for snmpEnableAuthenTraps */
#define SNMP_SNMPENABLEAUTHENTRAPS_ENABLED 1
#define SNMP_SNMPENABLEAUTHENTRAPS_DISABLED 2
#define SNMP_SNMPENABLEAUTHENTRAPS_LOWER_LIMIT 1
#define SNMP_SNMPENABLEAUTHENTRAPS_UPPER_LIMIT 2

/* Constants definition for snmpInBadVersions */
#define SNMP_SNMPINBADVERSIONS_LOWER_LIMIT 0
#define SNMP_SNMPINBADVERSIONS_UPPER_LIMIT 0

/* Constants definition for tcpAttemptFails */
#define SNMP_TCPATTEMPTFAILS_LOWER_LIMIT 0
#define SNMP_TCPATTEMPTFAILS_UPPER_LIMIT 0

/* Constants definition for snmpOutPkts */
#define SNMP_SNMPOUTPKTS_LOWER_LIMIT 0
#define SNMP_SNMPOUTPKTS_UPPER_LIMIT 0

/* Constants definition for ipInDiscards */
#define SNMP_IPINDISCARDS_LOWER_LIMIT 0
#define SNMP_IPINDISCARDS_UPPER_LIMIT 0

/* Constants definition for snmpOutSetRequests */
#define SNMP_SNMPOUTSETREQUESTS_LOWER_LIMIT 0
#define SNMP_SNMPOUTSETREQUESTS_UPPER_LIMIT 0

/* Constants definition for snmpInGenErrs */
#define SNMP_SNMPINGENERRS_LOWER_LIMIT 0
#define SNMP_SNMPINGENERRS_UPPER_LIMIT 0

/* Constants definition for icmpInTimestamps */
#define SNMP_ICMPINTIMESTAMPS_LOWER_LIMIT 0
#define SNMP_ICMPINTIMESTAMPS_UPPER_LIMIT 0

/* Constants definition for snmpInASNParseErrs */
#define SNMP_SNMPINASNPARSEERRS_LOWER_LIMIT 0
#define SNMP_SNMPINASNPARSEERRS_UPPER_LIMIT 0

/* Constants definition for icmpOutSrcQuenchs */
#define SNMP_ICMPOUTSRCQUENCHS_LOWER_LIMIT 0
#define SNMP_ICMPOUTSRCQUENCHS_UPPER_LIMIT 0

/* Constants definition for ipReasmFails */
#define SNMP_IPREASMFAILS_LOWER_LIMIT 0
#define SNMP_IPREASMFAILS_UPPER_LIMIT 0

/* Constants definition for snmpOutGetRequests */
#define SNMP_SNMPOUTGETREQUESTS_LOWER_LIMIT 0
#define SNMP_SNMPOUTGETREQUESTS_UPPER_LIMIT 0

/* Constants definition for tcpCurrEstab */

/* Constants definition for sysContact */

/* Constants definition for ipReasmReqds */
#define SNMP_IPREASMREQDS_LOWER_LIMIT 0
#define SNMP_IPREASMREQDS_UPPER_LIMIT 0

/* Constants definition for ipReasmOKs */
#define SNMP_IPREASMOKS_LOWER_LIMIT 0
#define SNMP_IPREASMOKS_UPPER_LIMIT 0

/* Constants definition for icmpOutTimestampReps */
#define SNMP_ICMPOUTTIMESTAMPREPS_LOWER_LIMIT 0
#define SNMP_ICMPOUTTIMESTAMPREPS_UPPER_LIMIT 0

/* Constants definition for ipForwarding */
#define SNMP_IPFORWARDING_FORWARDING 1
#define SNMP_IPFORWARDING_NOTFORWARDING 2
#define SNMP_IPFORWARDING_LOWER_LIMIT 1
#define SNMP_IPFORWARDING_UPPER_LIMIT 2

/* Constants definition for snmpInTraps */
#define SNMP_SNMPINTRAPS_LOWER_LIMIT 0
#define SNMP_SNMPINTRAPS_UPPER_LIMIT 0

/* Columns constants definition for ipNetToMediaTable */
#define SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIAIFINDEX 1
#define SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIAPHYSADDRESS 2
#define SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIANETADDRESS 3
#define SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIATYPE 4

/* Constants definition for snmpInBadCommunityNames */
#define SNMP_SNMPINBADCOMMUNITYNAMES_LOWER_LIMIT 0
#define SNMP_SNMPINBADCOMMUNITYNAMES_UPPER_LIMIT 0


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T snmp_RFC1213_MIB_init(
    void
);

void sysDescriptionSet(
    char *strDesc,                              /**< Value for sysDescription */
    uint16_t len                                /**< string length */
);

void sysLocationSet(
    char *strLocation,                          /**< Value for sysLocation */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flgWriteNvs                     /**< write NVS flag */
);

void sysContactSet(
    char *strContact,                           /**< Value for sysContact */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flgWriteNvs                     /**< write NVS flag */
);

void sysNameSet(
    char *strName,                              /**< Value for sysContact */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flgWriteNvs                     /**< write NVS flag */
);

void sysLocationSetUndo(
    void
);

void sysContactSetUndo(
    void
);

void sysNameSetUndo(
    void
);

GOAL_STATUS_T goal_snmpMibRfc1213InitPre(
    void
);

GOAL_STATUS_T goal_snmpMibRfc1213Init(
    void
);

#endif /* SNMP_RFC1213_H */
