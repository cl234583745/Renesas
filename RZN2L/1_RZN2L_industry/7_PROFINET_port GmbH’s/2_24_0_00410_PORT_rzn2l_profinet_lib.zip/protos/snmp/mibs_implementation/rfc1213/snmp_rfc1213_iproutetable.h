/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_RFC1213_IPROUTETABLE_FILE_H
#define SNMP_RFC1213_IPROUTETABLE_FILE_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_RFC1213_IPROUTETABLE_MAX_ENTRIES 1

#define SNMP_RFC1213_IPROUTEPROTO_OTHER 1
#define SNMP_RFC1213_IPROUTEPROTO_LOCAL 2
#define SNMP_RFC1213_IPROUTEPROTO_NETMGMT 1

#define SNMP_RFC1213_IPROUTETYPE_OTHER 1
#define SNMP_RFC1213_IPROUTETYPE_INVALID 2
#define SNMP_RFC1213_IPROUTETYPE_DIRECT 3
#define SNMP_RFC1213_IPROUTETYPE_INDIRECT 1

/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef struct {
    GOAL_BOOL_T active;                         /**< active flag */
    uint32_t ipRouteDest;                       /**< ipRouteDest */
    uint32_t ipRouteIfIndex;                    /**< ipRouteIfIndex */
    int32_t ipRouteMetric1;                     /**< ipRouteMetric1 */
    int32_t ipRouteMetric2;                     /**< ipRouteMetric2 */
    int32_t ipRouteMetric3;                     /**< ipRouteMetric3 */
    int32_t ipRouteMetric4;                     /**< ipRouteMetric4 */
    uint32_t ipRouteNextHop;                    /**< ipRouteNextHop */
    uint32_t ipRouteType;                       /**< ipRouteType */
    uint32_t ipRouteProto;                      /**< ipRouteProto */
    uint32_t ipRouteAge;                        /**< ipRouteAge */
    uint32_t ipRouteMask;                       /**< ipRouteMask */
    int32_t ipRouteMetric5;                     /**< ipRouteMetric5 */
} IPROUTETABLE_ENTRY_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T iproutetable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iproutetable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iproutetable_init(
    void
);

#endif /* SNMP_RFC1213_IPROUTETABLE_FILE_H */
