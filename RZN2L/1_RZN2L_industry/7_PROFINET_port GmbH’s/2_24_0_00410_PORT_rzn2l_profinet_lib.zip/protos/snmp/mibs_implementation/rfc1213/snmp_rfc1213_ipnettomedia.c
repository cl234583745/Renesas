/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_rfc1213_ipnettomedia.h>
#include <snmp_rfc1213_mib.h>
#include <snmp_rfc1213_iftable.h>


/****************************************************************************/
/* Variables */
/****************************************************************************/
static IPNETTOMEDIA_ENTRY_T ipNetToMediaTable[SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T ipnettomedia_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T ipnettomedia_updateEntries(
    void
);

static SNMP_RET_T ipnettomedia_tableEntryUpdate(
    uint32_t idx
);

static SNMP_RET_T ipnettomedia_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T ipnettomedia_indexGetByMac(
    GOAL_ETH_MAC_ADDR_T *pMac,                  /**< MAC address */
    uint32_t *pIdx                              /**< Index */
);


/****************************************************************************/
/** Updates an ipNetToMediaTable entry
*
*
* @retval SNMP_RET_NOERR Table initialized
*/
SNMP_RET_T ipnettomedia_tableEntryUpdate(
    uint32_t idx                                /**< Index */
)
{
    uint32_t addrIp;                            /* IP address */
    uint32_t addrMask;                          /* IP mask */
    uint32_t addrGw;                            /* Gateway */
    GOAL_BOOL_T flgTemp;                        /* Temp flag */
    SNMP_RET_T ret = SNMP_RET_NOERR;            /* Return value */
    GOAL_STATUS_T res;                          /* Result */

    /* check for valid index */
    if (SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES <= idx) {
        goal_logErr("Wrong table Index: %"FMT_u32", maximum: %"FMT_u32, idx, (uint32_t) SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES);
        return SNMP_RET_PARAM;
    }

    /* TODO: Support more than one IP address */
    res = goal_netIpGet(&addrIp, &addrMask, &addrGw, &flgTemp);
    if (GOAL_RES_OK(res)) {
        ipNetToMediaTable[idx].ipNetToMediaNetAddress = addrIp;
        res = goal_ethMacAddrGet(GOAL_ETH_PORT_HOST, &ipNetToMediaTable[0].ipNetToMediaPhysAddress);
        ipNetToMediaTable[idx].ipNetToMediaType = SNMP_IPNETTOMEDIA_TYPE_STATIC;
        iftable_ifIndexGetByGoalPort(GOAL_ETH_PORT_HOST, &ipNetToMediaTable[idx].ipNetToMediaIfIndex);
    }
    return ret;
}


/****************************************************************************/
/** Initializes ipNetToMediaTable entries
*
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T ipnettomedia_init(
    void
)
{
    SNMP_RET_T ret;                             /* Return value */

    ret = SNMP_RET_NOERR;
    GOAL_MEMSET(ipNetToMediaTable, 0, sizeof(ipNetToMediaTable));
    ipnettomedia_updateEntries();

    goal_logInfo("SNMP: RFC1213 ipNetToMediaTable initialized.");

    return ret;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
*
* @param msg The message containing the get request
* @param pColumn The requested column
* @param pIndex of table entry matching the index OID
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
static SNMP_RET_T ipnettomedia_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    uint32_t *pOid;                             /* index OID */

    uint32_t ifIndex;                           /* Interface index */
    GOAL_ETH_MAC_ADDR_T mac;                    /* MAC address */
    uint32_t cnt;

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len != 8) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    ifIndex = *pOid;
    pOid++;

    for (cnt = 0; MAC_ADDR_LEN > cnt; cnt++) {
        mac[cnt] = (uint8_t) (*pOid & 0xFF);
        pOid++;
    }

    /* Look for the according entry in the ipNetToMediaTable */
    for (cnt = 0; cnt < ARRAY_ELEMENTS(ipNetToMediaTable); cnt++) {
        /* check for valid index */
        if ((GOAL_TRUE == ipNetToMediaTable[cnt].active) &&
            (ifIndex == ipNetToMediaTable[cnt].ipNetToMediaIfIndex) &&
            (!GOAL_MEMCMP(mac,ipNetToMediaTable[cnt].ipNetToMediaPhysAddress, 6))) {
                *pIndex = cnt;
                break;
        }
    }

    /* Set no error code return if something was found */
    if (ARRAY_ELEMENTS(ipNetToMediaTable) > cnt) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Updates the values of all ipNetToMediaTableEntries
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_PARAM Port information could not be read from GOAL
*/
SNMP_RET_T ipnettomedia_updateEntries(
    void
)
{
    uint8_t idx;                                /* Index */
    SNMP_RET_T ret;                             /* SNMP return value */

    for (idx = 0; idx < SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES; ++idx) {
        ret = ipnettomedia_tableEntryUpdate(idx);
        if (SNMP_RET_NOERR == ret) {
            ipNetToMediaTable[idx].active = GOAL_TRUE;
        }
        else {
            ipNetToMediaTable[idx].active = GOAL_FALSE;
        }
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T ipnettomedia_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index;                             /* array index matching request index */

    /* Update entries */
    ret = ipnettomedia_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* get table entry matching OID */
    ret = ipnettomedia_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch(column) {
        case SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIAIFINDEX:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipNetToMediaTable[index].ipNetToMediaIfIndex),
                            sizeof(ipNetToMediaTable[index].ipNetToMediaIfIndex), 0, ASN1_INTEGER);
            break;
        case SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIAPHYSADDRESS:
            ret = snmp_set_var_value_type(var, (uint8_t *) ipNetToMediaTable[index].ipNetToMediaPhysAddress,
                            MAC_ADDR_LEN, 0, ASN1_OCTET_STRING);
            break;
        case SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIANETADDRESS:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipNetToMediaTable[index].ipNetToMediaNetAddress),
                            sizeof(ipNetToMediaTable[index].ipNetToMediaNetAddress), 0, ASN1_IPADDR);
            break;
        case SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIATYPE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipNetToMediaTable[index].ipNetToMediaType),
                            sizeof(ipNetToMediaTable[index].ipNetToMediaType), 0, ASN1_INTEGER);
            break;
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the ipNetToMediaTable
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T ipnettomedia_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* Update table entries */
    ret = ipnettomedia_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(ipNetToMediaTable); index++) {
        if (GOAL_TRUE == ipNetToMediaTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(ipNetToMediaTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = ipnettomedia_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the ipNetToMediaTable - internal part
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
static SNMP_RET_T ipnettomedia_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index = 0;                         /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[8];                       /* found OID */
    uint32_t foundOidTmp[8];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    uint32_t cnt;                               /* counter */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIAIFINDEX;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_IPNETTOMEDIATABLE_COLUMN_IPNETTOMEDIATYPE)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(ipNetToMediaTable); index ++) {

        /* skip inactive entries */
        if (GOAL_TRUE != ipNetToMediaTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        foundOidTmp[1] = ipNetToMediaTable[index].ipNetToMediaIfIndex;
        for (cnt = 0; MAC_ADDR_LEN > cnt; cnt++) {
            foundOidTmp[2 + cnt] = (uint32_t) ipNetToMediaTable[index].ipNetToMediaPhysAddress[cnt];
        }

        /* compare OID with given one of GETNEXT request */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = ipnettomedia_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = ipnettomedia_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0] ++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = ipnettomedia_getNextInternal(msg, var);
    return ret;
}



/****************************************************************************/
/** Return index for given MAC address
*
* @retval SNMP_RET_PARAM No such entry in table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T ipnettomedia_indexGetByMac(
    GOAL_ETH_MAC_ADDR_T *pMac,                  /**< MAC address */
    uint32_t *pIdx                              /**< Index */
)
{
    SNMP_RET_T ret = SNMP_RET_PARAM;            /* Return value */
    uint32_t idx;                               /* Index */

    for (idx = 0; idx < SNMP_RFC1213_IPNETTOMEDIA_MAX_ENTRIES; ++idx) {
        if (!(GOAL_MEMCMP(ipNetToMediaTable[idx].ipNetToMediaPhysAddress, pMac, MAC_ADDR_LEN))) {
            *pIdx = idx;
            ret = SNMP_RET_NOERR;
            break;
        }
    }
    return ret;
}
