/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_RFC1213_IPTABLE_FILE_H
#define SNMP_RFC1213_IPTABLE_FILE_H


/****************************************************************************/
/* Constants */
/****************************************************************************/
#define SNMP_RFC1213_IPADDRTABLE_MAX_ENTRIES 1
#define SNMP_RFC1213_REASMMAXSIZE 65535
#define SNMP_RFC1213_IPADDRSIZE 32


/****************************************************************************/
/* Structs */
/****************************************************************************/
typedef struct {
    GOAL_STATUS_T active;                        /**< active flag */
    uint32_t ipAdEntAddr;                       /**< ipAdEntAddr */
    uint32_t ipAdEntIfIndex;                    /**< ipAdEntIfIndex */
    uint32_t ipAdEntNetMask;                    /**< ipAdEntNetMask */
    uint32_t ipAdEntBcastAddr;                  /**< ipAdEntBcastAddr */
    uint32_t ipAdEntReasmMaxSize;               /**< ipAdEntReasmMaxSize */
} IPADDRTABLE_ENTRY_T;


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
SNMP_RET_T iptable_getValue(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iptable_getNext(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

SNMP_RET_T iptable_init(
    void
);

#endif /* SNMP_RFC1213_IPTABLE_FILE_H */
