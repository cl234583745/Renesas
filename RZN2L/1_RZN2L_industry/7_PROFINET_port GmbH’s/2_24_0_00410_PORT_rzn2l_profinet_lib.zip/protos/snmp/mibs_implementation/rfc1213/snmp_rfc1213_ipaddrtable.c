/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_rfc1213_ipaddrtable.h>
#include <snmp_rfc1213_mib.h>
#include <snmp_rfc1213_iftable.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/
#define SNMP_RFC1213_REASMMAXSIZE 65535
#define SNMP_RFC1213_IPADDRSIZE 32


/****************************************************************************/
/* Variables */
/****************************************************************************/
static IPADDRTABLE_ENTRY_T ipTable[SNMP_RFC1213_IPADDRTABLE_MAX_ENTRIES];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
static SNMP_RET_T iptable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
);

static SNMP_RET_T iptable_ipAddressUpdate(
    IPADDRTABLE_ENTRY_T *pEntry                 /**< Table entry */
);

static SNMP_RET_T iptable_updateEntries(
    void
);

static SNMP_RET_T iptable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< Message */
    SNMP_VARENTRY_T *var                        /**< Var entry */
);

static SNMP_RET_T iptable_bcastAddrCalc(
    uint32_t netmask,                           /**< Netmask */
    uint32_t *pAddr                             /**< Bcast addr */
);


/****************************************************************************/
/** Initializes ipTable entries
*
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T iptable_init(
    void
)
{
    GOAL_STATUS_T res;
    SNMP_RET_T ret;
    uint32_t addrIp;
    uint32_t addrMask;
    uint32_t addrGw;
    GOAL_BOOL_T flgTmp;
    ret = SNMP_RET_NOERR;
    uint32_t cnt;

    /* clear table */
    GOAL_MEMSET(ipTable, 0, sizeof(ipTable));

    /* get IP address */
    res = goal_netIpGet(&addrIp, &addrMask, &addrGw, &flgTmp);
    if (GOAL_RES_ERR(res)) {
        ret = SNMP_RET_RESOURCE;
    }
    else {
        for (cnt = 0; ARRAY_ELEMENTS(ipTable) > cnt; cnt++) {
            /* update IP address table entries and set active flag */
            ret = iptable_ipAddressUpdate(&ipTable[cnt]);
            if (SNMP_RET_NOERR == ret) {
                ipTable[cnt].active = GOAL_TRUE;
            }
            else {
                ipTable[cnt].active = GOAL_FALSE;
            }
        }

    }

    goal_logInfo("SNMP: RFC1213 ipAddrTable initialized.");

    return ret;
}


/****************************************************************************/
/** Updates the values of all ipTableEntries
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_PARAM Port information could not be read from GOAL
*/
static SNMP_RET_T iptable_updateEntries(
    void
)
{
    uint32_t index;                             /* table index */
    SNMP_RET_T ret;                             /* SNMP return value */

    /* Update address info */
    for (index = 0; ARRAY_ELEMENTS(ipTable) > index; index ++) {
        ret = iptable_ipAddressUpdate(&ipTable[index]);
        if (SNMP_RET_NOERR != ret) {
            return ret;
        }
    }
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Gets column of table and table entry matching given index OID.
*
* @param msg The message containing the get request
* @param pColumn The requested column
* @param pIndex of table entry matching the index OID
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
static SNMP_RET_T iptable_getIndex(
    SNMP_MSG_T *msg,                            /**< SNMP message */
    uint32_t *pColumn,                          /**< pointer to column */
    uint32_t *pIndex                            /**< pointer to array index of entry */
)
{
    uint32_t *pOid;                             /* index OID */
    uint32_t ip;                                /* ip address */
    uint32_t cnt;                               /* counter */

    /* First check whether the indexes and column are there */
    if (msg->index_oid_len != 5) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    pOid = msg->index_oid;

    /* Get column and indices */
    *pColumn = *pOid;
    pOid++;

    ip = GOAL_SNMP_IP_ADDR_FROM_OID(pOid);
    pOid += 4;

    /* Look for the according entry in the ipTable */
    for (cnt = 0; cnt < ARRAY_ELEMENTS(ipTable); cnt++) {
        /* check for valid index */
        if ((ip == ipTable[cnt].ipAdEntAddr) &&
            (GOAL_TRUE == ipTable[cnt].active)) {
                *pIndex = cnt;
                break;
        }
    }

    /* Set no error code return if something was found */
    if (ARRAY_ELEMENTS(ipTable) > cnt) {
        msg->error = SNMP_NOERR;
        return SNMP_RET_NOERR;
    }

    /* not found */
    msg->error = SNMP_ERR_NO_CREATION;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Initializes ipTable entries
*
*
* @retval SNMP_RET_NOERR Table initialized
* @retval SNMP_RET_RESOURCE Port information could not be read from GOAL
*/
SNMP_RET_T iptable_ipAddressUpdate(
    IPADDRTABLE_ENTRY_T *pEntry                 /**< Table entry */
)
{
    GOAL_STATUS_T res;                          /* result */
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t addrIp;                            /* IP address */
    uint32_t addrMask;                          /* IP address mask */
    uint32_t addrGw;                            /* gateway */
    GOAL_BOOL_T flgTmp;                         /* temporary flag */

    ret = SNMP_RET_NOERR;

    /* get IP address */
    res = goal_netIpGet(&addrIp, &addrMask, &addrGw, &flgTmp);
    if (GOAL_RES_ERR(res)) {
        ret = SNMP_RET_RESOURCE;
    }
    else {
        /* TODO: implement init for more than one IP address */
        pEntry->ipAdEntAddr = addrIp;
        pEntry->ipAdEntNetMask = addrMask;
        pEntry->ipAdEntReasmMaxSize = SNMP_RFC1213_REASMMAXSIZE;
        iptable_bcastAddrCalc(pEntry->ipAdEntNetMask, &pEntry->ipAdEntBcastAddr);
        iftable_ifIndexGetByGoalPort(GOAL_ETH_PORT_HOST, &(pEntry->ipAdEntIfIndex));
    }
    return ret;
}


/****************************************************************************/
/** Copies the current value of the given column and index to the given var
*
* @param msg The message containing the get request
* @param var The var entry to update
*
* @retval SNMP_RET_NOERR value successfully copied
* @retval other on failure
*/
SNMP_RET_T iptable_getValue(
    SNMP_MSG_T *msg,
    SNMP_VARENTRY_T *var
)
{
    SNMP_RET_T ret;                             /* SNMP return balue */
    uint32_t column = 0;                        /* column of request */
    uint32_t index;                             /* array index matching request index */

    /* update table entries */
    ret = iptable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* clear error message */
    msg->error = SNMP_NOERR;

    /* get table entry matching OID */
    ret = iptable_getIndex(msg, &column, &index);
    if (SNMP_RET_NOERR != ret || SNMP_NOERR != msg->error) {
        return ret;
    }

    /* Valid request. Set the required value */
    switch(column) {
        case SNMP_IPADDRTABLE_COLUMN_IPADENTADDR:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipTable[index].ipAdEntAddr),
                    sizeof(uint32_t), 0, ASN1_IPADDR);
            break;
        case SNMP_IPADDRTABLE_COLUMN_IPADENTIFINDEX:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipTable[index].ipAdEntIfIndex),
                            sizeof(ipTable[index].ipAdEntIfIndex), 0, ASN1_INTEGER);
            break;
        case SNMP_IPADDRTABLE_COLUMN_IPADENTNETMASK:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipTable[index].ipAdEntNetMask),
                            sizeof(uint32_t), 0, ASN1_IPADDR);
            break;
        case SNMP_IPADDRTABLE_COLUMN_IPADENTBCASTADDR:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipTable[index].ipAdEntBcastAddr),
                            sizeof(ipTable[index].ipAdEntBcastAddr), 0, ASN1_INTEGER);
            break;
        case SNMP_IPADDRTABLE_COLUMN_IPADENTREASMMAXSIZE:
            ret = snmp_set_var_value_type(var, (uint8_t *) &(ipTable[index].ipAdEntReasmMaxSize),
                            sizeof(ipTable[index].ipAdEntReasmMaxSize), 0, ASN1_INTEGER);
            break;
        default:
            msg->error = SNMP_ERR_NO_CREATION;
            break;
    }
    return ret;
}


/****************************************************************************/
/** Calculate the lowest set bit of the bcast addr
*
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iptable_bcastAddrCalc(
    uint32_t netmask,                           /**< Netmask */
    uint32_t *pAddr                             /**< Bcast addr */
)
{
     uint32_t i;
     for(i=0;i < SNMP_RFC1213_IPADDRSIZE; i++) {
        if (netmask & (1 << i)) {
            break;
        }
     }
     *pAddr = (i + 1);
     return SNMP_RET_NOERR;
}


/****************************************************************************/
/** Processes a getnext request for the ipTable
*
* @param msg The SNMP message containing the getnext request
* @param var The var entry where the value is stored
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
SNMP_RET_T iptable_getNext(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< varentry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
    uint32_t index;                             /* table index */

    /* update table entries */
    ret = iptable_updateEntries();
    if (SNMP_RET_NOERR != ret) {
        return ret;
    }

    /* short check if table is complietly inactive */
    for (index = 0; index < ARRAY_ELEMENTS(ipTable); index++) {
        if (GOAL_TRUE == ipTable[index].active) {
            break;
        }
    }
    if (ARRAY_ELEMENTS(ipTable) == index) {
        /* return if table is inactive */
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* process request to internal get next function */
    ret = iptable_getNextInternal(msg, var);
    return ret;
}


/****************************************************************************/
/** Processes a getnext request for the ipTable - internal part
*
* @param msg The SNMP message containing the getnext request
* @param var The var entry where the value is stored
*
* @retval SNMP_RET_RESOURCE No next value found in the table
* @retval SNMP_RET_NOERR on success
*/
static SNMP_RET_T iptable_getNextInternal(
    SNMP_MSG_T *msg,                            /**< message */
    SNMP_VARENTRY_T *var                        /**< varentry */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */

    uint32_t column;                            /* column of GETNEXT request */
    uint32_t index;                             /* index of array element containing information */

    GOAL_BOOL_T flgSmaller;                     /* flag if first OID is smaller than second one */
    GOAL_BOOL_T found = GOAL_FALSE;             /* next OID found flag */

    uint32_t foundOid[5];                       /* found OID */
    uint32_t foundOidTmp[5];                    /* temporary memory for found OID */
    uint8_t indexOidStart;                      /* index of first arrayentry of index OID for var */

    /* check for valid index OID */
    if (msg->index_oid_len > var->var->oid->len) {
        goal_logErr("Index OID for get next request is not valid.");
        return SNMP_RET_PARAM;
    }
    indexOidStart = (uint8_t) (var->var->oid->len - msg->index_oid_len);

    /* get column of GETNEXT rquest */
    if (msg->index_oid_len == 0 || (msg->index_oid_len > 0 && *(msg->index_oid) == 0)) {
        column = SNMP_IPADDRTABLE_COLUMN_IPADENTADDR;
    }
    else {
        column = *msg->index_oid;
    }

    /* check if column is valid */
    if (column > SNMP_IPADDRTABLE_COLUMN_IPADENTREASMMAXSIZE)
    {
        return SNMP_RET_RESOURCE;
    }

    /* go through table */
    for (index = 0; index < ARRAY_ELEMENTS(ipTable); index ++) {

        /* skip inactive entries */
        if (GOAL_TRUE != ipTable[index].active) {
            continue;
        }

        /* calculate OID of table entry */
        foundOidTmp[0] = column;
        GOAL_SNMP_IP_ADDR_TO_OID(&foundOidTmp[1], ipTable[index].ipAdEntAddr);

        /* compare OID with given one of GETNEXT request */
        ret = snmp_oidIsSmaller(&var->var->oid->sub_oid[indexOidStart], msg->index_oid_len,
                                foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                NULL, 0, &flgSmaller);
        if (!flgSmaller) {
            continue;
        }

        /* check if found index OID is smaller than already found one before */
        if (found) {
            ret = snmp_oidIsSmaller(foundOidTmp, ARRAY_ELEMENTS(foundOidTmp),
                                    foundOid, ARRAY_ELEMENTS(foundOid),
                                    NULL, 0, &flgSmaller);
            if (!flgSmaller) {
                continue;
            }
        }
        /* found bigger index OID */
        SNMP_MEMCPY(foundOid, foundOidTmp, sizeof(foundOid));
        found = GOAL_TRUE;
    }

    /* store found index OID */
    if (found) {

        /* store */
        SNMP_MEMCPY(&(var->var->oid->sub_oid[indexOidStart]), foundOid, sizeof(foundOid));
        var->var->oid->len = indexOidStart + ARRAY_ELEMENTS(foundOid);

        SNMP_MEMCPY(msg->index_oid, foundOid, sizeof(foundOid));
        msg->index_oid_len = ARRAY_ELEMENTS(foundOid);

        /* get value of found OID */
        ret = iptable_getValue(msg, var);
        if ((SNMP_NOERR == msg->error) && (SNMP_RET_NOERR == ret)) {
            return ret;
        }
        else {
            /* go to next OID if got nothing */
            ret = iptable_getNextInternal(msg, var);
            return ret;
        }
    }

    /* if nothing found, try again with next column */

    /* set new index OID length to 1 and use a column only */
    msg->index_oid_len = 1;
    var->var->oid->len = indexOidStart + 1;

    /* go to next column */
    msg->index_oid[0] ++;
    var->var->oid->sub_oid[indexOidStart] = msg->index_oid[0];

    ret = iptable_getNextInternal(msg, var);
    return ret;
}
