/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_rfc1213_mib.h>
#include <snmp_rfc1213_iftable.h>
#include <snmp_rfc1213_ipaddrtable.h>
#include <snmp_rfc1213_ipnettomedia.h>
#include <snmp_rfc1213_iproutetable.h>


#if GOAL_CONFIG_ETH_STATS != 1
#error "MIB II implementation requires GOAL Ethernet Statistics (GOAL_CONFIG_ETH_STATS)!"
#endif

#if GOAL_CONFIG_IP_STATS != 1
#error "MIB II implementation requires GOAL IP Statistics (GOAL_CONFIG_IP_STATS)!"
#endif


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define GOAL_SNMP_OID_CONTACT           "1.3.6.1.2.1.1.4.0"
#define GOAL_SNMP_OID_NAME              "1.3.6.1.2.1.1.5.0"
#define GOAL_SNMP_OID_LOCATION          "1.3.6.1.2.1.1.6.0"

#define GOAL_SNMP_LOCALHOST             "127.0.0.1"

#define GOAL_SNMP_SYS_LOCATION_DEFAULT  "somewhere"
#define GOAL_SNMP_SYS_CONTACT_DEFAULT   "Someone <someone@somewhere.net>"
#define GOAL_SNMP_SYS_NAME_DEFAULT      "something"


/****************************************************************************/
/* OIDs */
/****************************************************************************/
static uint32_t RFC1213_MIB_sysDescr_OID[9] =                   { 1, 3, 6, 1, 2, 1, 1, 1, 0 };
static uint32_t RFC1213_MIB_sysContact_OID[9] =                 { 1, 3, 6, 1, 2, 1, 1, 4, 0 };
static uint32_t RFC1213_MIB_sysName_OID[9] =                    { 1, 3, 6, 1, 2, 1, 1, 5, 0 };
static uint32_t RFC1213_MIB_sysLocation_OID[9] =                { 1, 3, 6, 1, 2, 1, 1, 6, 0 };
#if (0 == GOAL_SNMP_MIB_RFC1213_SYS_ONLY)
static uint32_t RFC1213_MIB_snmpInGetNexts_OID[9] =             { 1, 3, 6, 1, 2, 1, 11, 16, 0 };
static uint32_t RFC1213_MIB_icmpOutEchoReps_OID[9] =            { 1, 3, 6, 1, 2, 1, 5, 22, 0 };
static uint32_t RFC1213_MIB_tcpRtoAlgorithm_OID[9] =            { 1, 3, 6, 1, 2, 1, 6, 1, 0 };
static uint32_t RFC1213_MIB_tcpOutSegs_OID[9] =                 { 1, 3, 6, 1, 2, 1, 6, 11, 0 };
static uint32_t RFC1213_MIB_ipAddrTable_OID[9] =                { 1, 3, 6, 1, 2, 1, 4, 20, 1 };
static uint32_t RFC1213_MIB_ipFragOKs_OID[9] =                  { 1, 3, 6, 1, 2, 1, 4, 17, 0 };
static uint32_t RFC1213_MIB_sysServices_OID[9] =                { 1, 3, 6, 1, 2, 1, 1, 7, 0 };
static uint32_t RFC1213_MIB_snmpInGetResponses_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 18, 0 };
static uint32_t RFC1213_MIB_snmpInBadCommunityUses_OID[9] =     { 1, 3, 6, 1, 2, 1, 11, 5, 0 };
static uint32_t RFC1213_MIB_ipInReceives_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 3, 0 };
static uint32_t RFC1213_MIB_ipOutRequests_OID[9] =              { 1, 3, 6, 1, 2, 1, 4, 10, 0 };
static uint32_t RFC1213_MIB_sysObjectID_OID[9] =                { 1, 3, 6, 1, 2, 1, 1, 2, 0 };
static uint32_t RFC1213_MIB_icmpOutDestUnreachs_OID[9] =        { 1, 3, 6, 1, 2, 1, 5, 16, 0 };
static uint32_t RFC1213_MIB_tcpRtoMax_OID[9] =                  { 1, 3, 6, 1, 2, 1, 6, 3, 0 };
static uint32_t RFC1213_MIB_snmpOutGetResponses_OID[9] =        { 1, 3, 6, 1, 2, 1, 11, 28, 0 };
static uint32_t RFC1213_MIB_tcpPassiveOpens_OID[9] =            { 1, 3, 6, 1, 2, 1, 6, 6, 0 };
static uint32_t RFC1213_MIB_atTable_OID[9] =                    { 1, 3, 6, 1, 2, 1, 3, 1, 1 };
static uint32_t RFC1213_MIB_snmpOutGetNexts_OID[9] =            { 1, 3, 6, 1, 2, 1, 11, 26, 0 };
static uint32_t RFC1213_MIB_tcpInErrs_OID[9] =                  { 1, 3, 6, 1, 2, 1, 6, 14, 0 };
static uint32_t RFC1213_MIB_snmpInTotalReqVars_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 13, 0 };
static uint32_t RFC1213_MIB_icmpInParmProbs_OID[9] =            { 1, 3, 6, 1, 2, 1, 5, 5, 0 };
static uint32_t RFC1213_MIB_udpOutDatagrams_OID[9] =            { 1, 3, 6, 1, 2, 1, 7, 4, 0 };
static uint32_t RFC1213_MIB_sysUpTime_OID[9] =                  { 1, 3, 6, 1, 2, 1, 1, 3, 0 };
static uint32_t RFC1213_MIB_icmpOutAddrMaskReps_OID[9] =        { 1, 3, 6, 1, 2, 1, 5, 26, 0 };
static uint32_t RFC1213_MIB_udpInErrors_OID[9] =                { 1, 3, 6, 1, 2, 1, 7, 3, 0 };
static uint32_t RFC1213_MIB_icmpOutAddrMasks_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 25, 0 };
static uint32_t RFC1213_MIB_egpAs_OID[9] =                      { 1, 3, 6, 1, 2, 1, 8, 6, 0 };
static uint32_t RFC1213_MIB_icmpInAddrMasks_OID[9] =            { 1, 3, 6, 1, 2, 1, 5, 12, 0 };
static uint32_t RFC1213_MIB_udpTable_OID[9] =                   { 1, 3, 6, 1, 2, 1, 7, 5, 1 };
static uint32_t RFC1213_MIB_ipOutDiscards_OID[9] =              { 1, 3, 6, 1, 2, 1, 4, 11, 0 };
static uint32_t RFC1213_MIB_icmpOutTimestamps_OID[9] =          { 1, 3, 6, 1, 2, 1, 5, 23, 0 };
static uint32_t RFC1213_MIB_snmpInSetRequests_OID[9] =          { 1, 3, 6, 1, 2, 1, 11, 17, 0 };
static uint32_t RFC1213_MIB_icmpInTimestampReps_OID[9] =        { 1, 3, 6, 1, 2, 1, 5, 11, 0 };
static uint32_t RFC1213_MIB_ipInHdrErrors_OID[9] =              { 1, 3, 6, 1, 2, 1, 4, 4, 0 };
static uint32_t RFC1213_MIB_icmpInMsgs_OID[9] =                 { 1, 3, 6, 1, 2, 1, 5, 1, 0 };
static uint32_t RFC1213_MIB_snmpOutNoSuchNames_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 21, 0 };
static uint32_t RFC1213_MIB_icmpOutParmProbs_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 18, 0 };
static uint32_t RFC1213_MIB_icmpOutMsgs_OID[9] =                { 1, 3, 6, 1, 2, 1, 5, 14, 0 };
static uint32_t RFC1213_MIB_egpInErrors_OID[9] =                { 1, 3, 6, 1, 2, 1, 8, 2, 0 };
static uint32_t RFC1213_MIB_icmpInEchoReps_OID[9] =             { 1, 3, 6, 1, 2, 1, 5, 9, 0 };
static uint32_t RFC1213_MIB_snmpOutTooBigs_OID[9] =             { 1, 3, 6, 1, 2, 1, 11, 20, 0 };
static uint32_t RFC1213_MIB_icmpInTimeExcds_OID[9] =            { 1, 3, 6, 1, 2, 1, 5, 4, 0 };
static uint32_t RFC1213_MIB_tcpConnTable_OID[9] =               { 1, 3, 6, 1, 2, 1, 6, 13, 1 };
static uint32_t RFC1213_MIB_ipRoutingDiscards_OID[9] =          { 1, 3, 6, 1, 2, 1, 4, 23, 0 };
static uint32_t RFC1213_MIB_snmpInGetRequests_OID[9] =          { 1, 3, 6, 1, 2, 1, 11, 15, 0 };
static uint32_t RFC1213_MIB_snmpInTotalSetVars_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 14, 0 };
static uint32_t RFC1213_MIB_ifTable_OID[9] =                    { 1, 3, 6, 1, 2, 1, 2, 2, 1 };
static uint32_t RFC1213_MIB_snmpInReadOnlys_OID[9] =            { 1, 3, 6, 1, 2, 1, 11, 11, 0 };
static uint32_t RFC1213_MIB_ipForwDatagrams_OID[9] =            { 1, 3, 6, 1, 2, 1, 4, 6, 0 };
static uint32_t RFC1213_MIB_icmpOutTimeExcds_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 17, 0 };
static uint32_t RFC1213_MIB_icmpOutEchos_OID[9] =               { 1, 3, 6, 1, 2, 1, 5, 21, 0 };
static uint32_t RFC1213_MIB_egpOutMsgs_OID[9] =                 { 1, 3, 6, 1, 2, 1, 8, 3, 0 };
static uint32_t RFC1213_MIB_icmpInSrcQuenchs_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 6, 0 };
static uint32_t RFC1213_MIB_icmpOutErrors_OID[9] =              { 1, 3, 6, 1, 2, 1, 5, 15, 0 };
static uint32_t RFC1213_MIB_tcpActiveOpens_OID[9] =             { 1, 3, 6, 1, 2, 1, 6, 5, 0 };
static uint32_t RFC1213_MIB_egpNeighTable_OID[9] =              { 1, 3, 6, 1, 2, 1, 8, 5, 1 };
static uint32_t RFC1213_MIB_tcpEstabResets_OID[9] =             { 1, 3, 6, 1, 2, 1, 6, 8, 0 };
static uint32_t RFC1213_MIB_ipInDelivers_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 9, 0 };
static uint32_t RFC1213_MIB_icmpInErrors_OID[9] =               { 1, 3, 6, 1, 2, 1, 5, 2, 0 };
static uint32_t RFC1213_MIB_ipReasmTimeout_OID[9] =             { 1, 3, 6, 1, 2, 1, 4, 13, 0 };
static uint32_t RFC1213_MIB_snmpInPkts_OID[9] =                 { 1, 3, 6, 1, 2, 1, 11, 1, 0 };
static uint32_t RFC1213_MIB_ipOutNoRoutes_OID[9] =              { 1, 3, 6, 1, 2, 1, 4, 12, 0 };
static uint32_t RFC1213_MIB_tcpRtoMin_OID[9] =                  { 1, 3, 6, 1, 2, 1, 6, 2, 0 };
static uint32_t RFC1213_MIB_ipFragFails_OID[9] =                { 1, 3, 6, 1, 2, 1, 4, 18, 0 };
static uint32_t RFC1213_MIB_udpNoPorts_OID[9] =                 { 1, 3, 6, 1, 2, 1, 7, 2, 0 };
static uint32_t RFC1213_MIB_snmpOutGenErrs_OID[9] =             { 1, 3, 6, 1, 2, 1, 11, 24, 0 };
static uint32_t RFC1213_MIB_icmpInDestUnreachs_OID[9] =         { 1, 3, 6, 1, 2, 1, 5, 3, 0 };
static uint32_t RFC1213_MIB_ipInAddrErrors_OID[9] =             { 1, 3, 6, 1, 2, 1, 4, 5, 0 };
static uint32_t RFC1213_MIB_ipDefaultTTL_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 2, 0 };
static uint32_t RFC1213_MIB_tcpRetransSegs_OID[9] =             { 1, 3, 6, 1, 2, 1, 6, 12, 0 };
static uint32_t RFC1213_MIB_ipFragCreates_OID[9] =              { 1, 3, 6, 1, 2, 1, 4, 19, 0 };
static uint32_t RFC1213_MIB_ipInUnknownProtos_OID[9] =          { 1, 3, 6, 1, 2, 1, 4, 7, 0 };
static uint32_t RFC1213_MIB_udpInDatagrams_OID[9] =             { 1, 3, 6, 1, 2, 1, 7, 1, 0 };
static uint32_t RFC1213_MIB_tcpOutRsts_OID[9] =                 { 1, 3, 6, 1, 2, 1, 6, 15, 0 };
static uint32_t RFC1213_MIB_icmpInEchos_OID[9] =                { 1, 3, 6, 1, 2, 1, 5, 8, 0 };
static uint32_t RFC1213_MIB_icmpOutRedirects_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 20, 0 };
static uint32_t RFC1213_MIB_ifNumber_OID[9] =                   { 1, 3, 6, 1, 2, 1, 2, 1, 0 };
static uint32_t RFC1213_MIB_icmpInRedirects_OID[9] =            { 1, 3, 6, 1, 2, 1, 5, 7, 0 };
static uint32_t RFC1213_MIB_tcpMaxConn_OID[9] =                 { 1, 3, 6, 1, 2, 1, 6, 4, 0 };
static uint32_t RFC1213_MIB_snmpInTooBigs_OID[9] =              { 1, 3, 6, 1, 2, 1, 11, 8, 0 };
static uint32_t RFC1213_MIB_icmpInAddrMaskReps_OID[9] =         { 1, 3, 6, 1, 2, 1, 5, 13, 0 };
static uint32_t RFC1213_MIB_egpInMsgs_OID[9] =                  { 1, 3, 6, 1, 2, 1, 8, 1, 0 };
static uint32_t RFC1213_MIB_snmpOutBadValues_OID[9] =           { 1, 3, 6, 1, 2, 1, 11, 22, 0 };
static uint32_t RFC1213_MIB_ipRouteTable_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 21, 1 };
static uint32_t RFC1213_MIB_snmpInNoSuchNames_OID[9] =          { 1, 3, 6, 1, 2, 1, 11, 9, 0 };
static uint32_t RFC1213_MIB_tcpInSegs_OID[9] =                  { 1, 3, 6, 1, 2, 1, 6, 10, 0 };
static uint32_t RFC1213_MIB_snmpOutTraps_OID[9] =               { 1, 3, 6, 1, 2, 1, 11, 29, 0 };
static uint32_t RFC1213_MIB_egpOutErrors_OID[9] =               { 1, 3, 6, 1, 2, 1, 8, 4, 0 };
static uint32_t RFC1213_MIB_snmpInBadValues_OID[9] =            { 1, 3, 6, 1, 2, 1, 11, 10, 0 };
static uint32_t RFC1213_MIB_snmpEnableAuthenTraps_OID[9] =      { 1, 3, 6, 1, 2, 1, 11, 30, 0 };
static uint32_t RFC1213_MIB_snmpInBadVersions_OID[9] =          { 1, 3, 6, 1, 2, 1, 11, 3, 0 };
static uint32_t RFC1213_MIB_tcpAttemptFails_OID[9] =            { 1, 3, 6, 1, 2, 1, 6, 7, 0 };
static uint32_t RFC1213_MIB_snmpOutPkts_OID[9] =                { 1, 3, 6, 1, 2, 1, 11, 2, 0 };
static uint32_t RFC1213_MIB_ipInDiscards_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 8, 0 };
static uint32_t RFC1213_MIB_snmpOutSetRequests_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 27, 0 };
static uint32_t RFC1213_MIB_snmpInGenErrs_OID[9] =              { 1, 3, 6, 1, 2, 1, 11, 12, 0 };
static uint32_t RFC1213_MIB_icmpInTimestamps_OID[9] =           { 1, 3, 6, 1, 2, 1, 5, 10, 0 };
static uint32_t RFC1213_MIB_snmpInASNParseErrs_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 6, 0 };
static uint32_t RFC1213_MIB_icmpOutSrcQuenchs_OID[9] =          { 1, 3, 6, 1, 2, 1, 5, 19, 0 };
static uint32_t RFC1213_MIB_ipReasmFails_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 16, 0 };
static uint32_t RFC1213_MIB_snmpOutGetRequests_OID[9] =         { 1, 3, 6, 1, 2, 1, 11, 25, 0 };
static uint32_t RFC1213_MIB_tcpCurrEstab_OID[9] =               { 1, 3, 6, 1, 2, 1, 6, 9, 0 };
static uint32_t RFC1213_MIB_ipReasmReqds_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 14, 0 };
static uint32_t RFC1213_MIB_ipReasmOKs_OID[9] =                 { 1, 3, 6, 1, 2, 1, 4, 15, 0 };
static uint32_t RFC1213_MIB_icmpOutTimestampReps_OID[9] =       { 1, 3, 6, 1, 2, 1, 5, 24, 0 };
static uint32_t RFC1213_MIB_ipForwarding_OID[9] =               { 1, 3, 6, 1, 2, 1, 4, 1, 0 };
static uint32_t RFC1213_MIB_snmpInTraps_OID[9] =                { 1, 3, 6, 1, 2, 1, 11, 19, 0 };
static uint32_t RFC1213_MIB_ipNetToMediaTable_OID[9] =          { 1, 3, 6, 1, 2, 1, 4, 22, 1 };
static uint32_t RFC1213_MIB_snmpInBadCommunityNames_OID[9] =    { 1, 3, 6, 1, 2, 1, 11, 4, 0 };
#endif /* !GOAL_SNMP_MIB_RFC1213_SYS_ONLY */


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static char *strLocationDefault = GOAL_SNMP_SYS_LOCATION_DEFAULT; /**< default name */
static char *strContactDefault = GOAL_SNMP_SYS_CONTACT_DEFAULT; /**< default name */
static char *strNameDefault = GOAL_SNMP_SYS_NAME_DEFAULT; /**< default name */
static char *strDesc = "SNMP example";          /**< description */
static GOAL_BOOL_T flgDescValid = GOAL_FALSE;   /**< description validity flag */


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_snmpCmModAdd(
    void
);

static GOAL_STATUS_T goal_snmpCmModReg(
    void
);

static void sysLocationInit(
    void
);

static void sysContactInit(
    void
);

static void sysNameInit(
    void
);

static SNMP_RET_T snmp_rfc1213_mib_reset(
    void *pArg                                  /**< reset argument */
);

static SNMP_RET_T snmp_rfc1213_mib_sysdescr_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_syscontact_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_syscontact_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_sysname_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_sysname_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_syslocation_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_syslocation_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
#if (0 == GOAL_SNMP_MIB_RFC1213_SYS_ONLY)
static SNMP_RET_T snmp_rfc1213_mib_snmpingetnexts_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutechoreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcprtoalgorithm_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpoutsegs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_ipaddrtable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_ipaddrtable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_ipfragoks_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_sysservices_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpingetresponses_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpinbadcommunityuses_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipinreceives_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipoutrequests_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_sysobjectid_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutdestunreachs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcprtomax_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutgetresponses_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcppassiveopens_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_attable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_attable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutgetnexts_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpinerrs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpintotalreqvars_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinparmprobs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_udpoutdatagrams_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_sysuptime_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutaddrmaskreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_udpinerrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutaddrmasks_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_egpas_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinaddrmasks_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_udptable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_udptable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_ipoutdiscards_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpouttimestamps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpinsetrequests_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpintimestampreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipinhdrerrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinmsgs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutnosuchnames_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutparmprobs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutmsgs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_egpinerrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinechoreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpouttoobigs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpintimeexcds_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_tcpconntable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_tcpconntable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_iproutingdiscards_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpingetrequests_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpintotalsetvars_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_iftable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_iftable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpinreadonlys_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipforwdatagrams_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpouttimeexcds_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutechos_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_egpoutmsgs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinsrcquenchs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpouterrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpactiveopens_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_egpneightable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_egpneightable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_tcpestabresets_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipindelivers_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinerrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipreasmtimeout_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpinpkts_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipoutnoroutes_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcprtomin_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipfragfails_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_udpnoports_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutgenerrs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpindestunreachs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipinaddrerrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipdefaultttl_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipdefaultttl_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_tcpretranssegs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipfragcreates_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipinunknownprotos_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_udpindatagrams_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpoutrsts_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinechos_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutredirects_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ifnumber_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinredirects_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpmaxconn_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpintoobigs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpinaddrmaskreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_egpinmsgs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutbadvalues_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_iproutetable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_iproutetable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpinnosuchnames_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpinsegs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpouttraps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_egpouterrors_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpinbadvalues_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpenableauthentraps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpenableauthentraps_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpinbadversions_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpattemptfails_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutpkts_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipindiscards_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutsetrequests_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpingenerrs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpintimestamps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpinasnparseerrs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpoutsrcquenchs_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipreasmfails_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_snmpoutgetrequests_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_tcpcurrestab_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);

static SNMP_RET_T snmp_rfc1213_mib_ipreasmreqds_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipreasmoks_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_icmpouttimestampreps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipforwarding_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_ipforwarding_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpintraps_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
static SNMP_RET_T snmp_rfc1213_mib_table_ipnettomediatable_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_table_ipnettomediatable_set(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var, SNMP_CMD_T cmd);
static SNMP_RET_T snmp_rfc1213_mib_snmpinbadcommunitynames_get(SNMP_MSG_T *msg, SNMP_VARENTRY_T *var);
#endif /* GOAL_SNMP_MIB_RFC1213_SYS_ONLY */


/****************************************************************************/
/* Variables */
/****************************************************************************/
static char sysLocation[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysLocation_old[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysDescription[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysContact[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysContact_old[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysName[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static char sysName_old[GOAL_SNMP_MIB2_SYSSTRINGLEN];
static uint32_t sysServices = 72; /* Layer 4 an 7. See page 14 of RFC1213 */
extern uint32_t PORTGMBH_MIB_pnioStackName_OID[12];

static GOAL_STAGE_HANDLER_T stageCmModReg;      /**< CM module register stage */
static GOAL_STAGE_HANDLER_T stageCmModAdd;      /**< CM module add stage */
static GOAL_CM_MODDEF_T cmMod = GOAL_CM_MODDEF(GOAL_SNMP_MIB2_CM_MOD_ID, "GOAL_SNMP_MIB2_MODULE"); /**< CM module definition */


/****************************************************************************/
/* Configuration Variables Management */
/****************************************************************************/
#define GOAL_SNMP_MIB2_CM_VARS \
/*              Name,                            Data type,       Max. size,                        Validation Cb,    Change Cb */   \
    GOAL_CM_VAR(GOAL_SNMP_MIB2_CM_SYS_LOCATION,  GOAL_CM_STRING,  GOAL_SNMP_MIB2_SYSSTRINGLEN,      NULL,             NULL),         \
    GOAL_CM_VAR(GOAL_SNMP_MIB2_CM_SYS_CONTACT,   GOAL_CM_STRING,  GOAL_SNMP_MIB2_SYSSTRINGLEN,      NULL,             NULL),         \
    GOAL_CM_VAR(GOAL_SNMP_MIB2_CM_SYS_NAME,      GOAL_CM_STRING,  GOAL_SNMP_MIB2_SYSSTRINGLEN,      NULL,             NULL)

/* generate 'enum GOAL_SNMP_MIB2_CM_VARS_ID_T' that contains all variable names */
#include <goal_cm_id.h>
GOAL_CM_VAR_IDS(GOAL_SNMP_MIB2_CM_VARS_ID_T, GOAL_SNMP_MIB2_CM_VARS);

/* generate 'GOAL_CM_VARENTRY_T cmVars[]' array that maps the above table */
#include <goal_cm_t.h>
GOAL_CM_VARLIST(cmVars, GOAL_SNMP_MIB2_CM_VARS);



/****************************************************************************/
/** Register Configuration Variables
 *
 * This function is called by the GOAL init-stage system to register its
 * configuration management variables.
 *
 * API functions from earlier stages are allowed to be used here.
 *
 * @retval GOAL_OK successful
 * @retval other fail
 *
 */
GOAL_STATUS_T goal_snmpMibRfc1213InitPre(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* register cm variables */
    res = goal_mainStageReg(GOAL_STAGE_CM_MOD_REG, &stageCmModReg, GOAL_STAGE_INIT, goal_snmpCmModReg);

    /* add callback to configuration management module add stage */
    if (GOAL_RES_OK(res)) {
        res = goal_mainStageReg(GOAL_STAGE_CM_MOD_ADD, &stageCmModAdd, GOAL_STAGE_INIT, goal_snmpCmModAdd);
    }

    return res;
}


/****************************************************************************/
/** Add SNMP Configuration Module
 *
 * This function is called by the GOAL init-stage system to add the application
 * module to configuration mangement.
 *
 * API functions from earlier stages are allowed to be used here.
 */
static GOAL_STATUS_T goal_snmpCmModAdd(
    void
)
{
    /* add config variables */
    return goal_cmAddModule(&cmMod, cmVars, NULL, NULL, NULL);
}


/****************************************************************************/
/** Register Configuration Variables
 *
 * This function is called by the GOAL init-stage system to register its
 * configuration management variables.
 *
 * API functions from earlier stages are allowed to be used here.
 *
 * @retval GOAL_OK successful
 * @retval other fail
 *
 */
static GOAL_STATUS_T goal_snmpCmModReg(
    void
)
{
    /* add config variables */
    return goal_cmRegModule(cmVars);
}


/****************************************************************************/
/** SNMP LLDP MIB init function
 *
 * This function initializes the SNMP LLDP MIBs
 *
 *
 * @retval GOAL_OK successful
 * @retval other fail
 */
GOAL_STATUS_T goal_snmpMibRfc1213Init(
    void
)
{
    SNMP_RET_T resSnmp;                         /* SNMP result */

    /* register MIB nodes */
    resSnmp = snmp_RFC1213_MIB_init();

    if (SNMP_RET_NOERR != resSnmp) {
        goal_logErr("Could not initialize RFC1213 MIB II.");
        return GOAL_ERROR;
    }

    /* set sysDescriptor */
    if (GOAL_FALSE == flgDescValid) {
        sysDescriptionSet(strDesc, (uint16_t) GOAL_STRLEN(strDesc));
    }

    /* initialize sys variables */
    sysLocationInit();
    sysContactInit();
    sysNameInit();

    goal_logInfo("Initialized RFC1213 MIB II.");
    return GOAL_OK;
}


#if (0 == GOAL_SNMP_MIB_RFC1213_SYS_ONLY)
/****************************************************************************/
/** inGetNexts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_snmpingetnexts_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInGetNexts),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutEchoReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_icmpoutechoreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpRtAlgorithm
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_tcprtoalgorithm_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = SNMP_TCPRTOALGORITHM_OTHER;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** tcpOutSegs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_tcpoutsegs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_TCPOUTSEGS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipAddrTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_table_ipaddrtable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = iptable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = iptable_getNext(msg, var);
            break;
        default:
            break;
        }
    return result;
}


/****************************************************************************/
/** ipAddrTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_table_ipaddrtable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** ipFragOks
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
static SNMP_RET_T snmp_rfc1213_mib_ipfragoks_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_IPFRAGOKS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** sysServices
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysservices_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *)&sysServices, sizeof(uint32_t), 0, ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** snmpInGetResponses
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpingetresponses_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInGetResponses),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInBadCommunityUses
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinbadcommunityuses_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInBadCommunityUses),
                sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInReceives
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipinreceives_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_IPINRECEIVES);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipOutRequests
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipoutrequests_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_IPOUTREQUESTS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** sysObjectId
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysobjectid_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;                             /* SNMP return value */
#if (1 == GOAL_SNMP_MIB_PORT_DISABLE)
    uint32_t NULL_OID[2] = {0, 0};              /* OID 0.0 */
#endif

    UNUSEDARG(msg);

#if (0 == GOAL_SNMP_MIB_PORT_DISABLE)
    ret = snmp_set_var_value_type(var, (uint8_t *) &PORTGMBH_MIB_pnioStackName_OID[0],sizeof(PORTGMBH_MIB_pnioStackName_OID), 0, ASN1_OID);
#else
    ret = snmp_set_var_value_type(var, (uint8_t *) &(NULL_OID), sizeof(NULL_OID), 0, ASN1_OID);
#endif /* GOAL_SNMP_MIB_PORT_DISABLE */
    return ret;
}


/****************************************************************************/
/** icmpOutDestUnreachs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutdestunreachs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPOUTDESTUNREACHS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpRtoMax
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcprtomax_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** snmpOutGetResponses
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutgetresponses_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutGetResponses),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpPassiveOpens
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcppassiveopens_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_TCPPASSIVEOPENS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** atTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_attable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** atTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_attable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** snmpOutGetNexts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutgetnexts_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutGetNexts),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpInErrs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpinerrs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_TCPINERRS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInToalReqVars
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpintotalreqvars_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInTotalReqVars),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInParmProbs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinparmprobs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINPARMPROBS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** udpOutDatagrams
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_udpoutdatagrams_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (1 << GOAL_NET_IP_STATS_UDPOUTDATAGRAMS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** sysUpTime
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysuptime_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    /* Time stamp is in ms, sysUpTime in hundredth of a second */

    uint32_t val = (((uint32_t) goal_targetGetTimestamp()) / 10);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(val), 0,
                    ASN1_TIMETICKS);
    return ret;
}


/****************************************************************************/
/** icmpOutAddrMaskReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutaddrmaskreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** udpInErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_udpinerrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_UDPINERRORS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutAddrMasks
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutaddrmasks_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpAs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_egpas_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** icmpInAddrMasks
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinaddrmasks_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINADDRMASKS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** udpTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_udptable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** udpTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_udptable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** ipOutDiscards
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipoutdiscards_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPOUTDISCARDS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutTimeStamps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpouttimestamps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInSetRequests
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinsetrequests_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInSetRequests),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInTimeStampReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpintimestampreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINTIMESTAMPS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInHdrErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipinhdrerrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPINHDRERRORS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInMsgs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinmsgs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
   SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINMSGS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutNoSuchNames
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutnosuchnames_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutNoSuchNames),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutParmProbs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutparmprobs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutMsgs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutmsgs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPOUTMSGS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpInErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_egpinerrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInEchoReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinechoreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINECHOREPS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutTooBigs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpouttoobigs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutTooBigs),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInTimeExcds
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpintimeexcds_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINTIMEEXCDS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpConnTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_tcpconntable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** tcpConnTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_tcpconntable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** ipRoutingDiscards
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_iproutingdiscards_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInGetRequests
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpingetrequests_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInGetRequests),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInTotalSetVars
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpintotalsetvars_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInTotalSetVars),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ifTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_iftable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = iftable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = iftable_getNext(msg, var);
            break;
        default:
            break;
        }
    return result;
}


/****************************************************************************/
/** ifTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_iftable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    uint32_t column;
    uint32_t index;
    uint32_t cnt;
    GOAL_STATUS_T res;
    uint32_t val;

    SNMP_RET_T result = SNMP_RET_NOERR;

    /* First check whether the index and column are there */
    if (msg->index_oid_len != 2) {
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }

    /* Get column and index */
    column = *msg->index_oid;
    index = *(msg->index_oid+1);

    /* Get number of ports and check index against */
    res = goal_ethPortsGet(&cnt);
    if (GOAL_RES_ERR(res)) {
            return SNMP_RET_RESOURCE;
    }
    if (index>cnt){
        msg->error = SNMP_ERR_NO_CREATION;
        return SNMP_RET_NOERR;
    }
    if (SNMP_IFTABLE_COLUMN_IFADMINSTATUS != column){
        msg->error = SNMP_ERR_NOT_WRITABLE;
        return SNMP_RET_NOERR;
    }

    switch (cmd) {
    /* Check type and value */
    case SNMP_CMD_VALUE:
        if (ASN1_INTEGER != var->var->type) {
            msg->error = SNMP_ERR_WRONG_TYPE;
            return SNMP_RET_NOERR;
        }
        GOAL_MEMCPY(&val, var->var->data, sizeof(uint32_t));
        if (val < SNMP_IFTABLE_IFADMINSTATUS_UP || val > SNMP_IFTABLE_IFADMINSTATUS_TESTING ) {
            msg->error = SNMP_ERR_WRONG_VALUE;
            return SNMP_RET_NOERR;
        }
        break;
        /* Set the value */
    case SNMP_CMD_SET:
        iftable_setValue(index, column, msg, var);
        break;
        /* Undo the value setting */
    case SNMP_CMD_UNDO:
        iftable_setValue_undo(index, column, msg, var);
        break;
        /* Commit the value -> transaction complete */
    case SNMP_CMD_COMMIT:
        iftable_setAdminStatusToGoal(index);
        break;
    default:
        break;
    }
    return result;
}


/****************************************************************************/
/** snmpInReadonlys
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinreadonlys_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInReadOnlys),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipForwDatagrams
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipforwdatagrams_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPFORWDATAGRAMS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutTimeExcds
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpouttimeexcds_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPOUTTIMEEXCDS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutEcho
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutechos_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPOUTECHOS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpOutMsgs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_egpoutmsgs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInSrcQuenchs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinsrcquenchs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINSRCQUENCHS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpouterrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPOUTERRORS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;

}


/****************************************************************************/
/** tcpActiveOpens
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpactiveopens_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPACTIVEOPENS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpNeighTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_egpneightable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(msg);
    UNUSEDARG(var);
    UNUSEDARG(cmd);
    return SNMP_RET_RESOURCE;
}


/****************************************************************************/
/** egpNeighTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_egpneightable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** tcpEstabResets
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpestabresets_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPESTABRESETS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInDelivers
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipindelivers_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPINDELIVERS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinerrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINERRORS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipReasmTimeout
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipreasmtimeout_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** snmpInPkts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinpkts_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInPkts),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipOutNoRoutes
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipoutnoroutes_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpRtoMin
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcprtomin_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** ipFragFails
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipfragfails_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPFRAGFAILS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** udpNoPorts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_udpnoports_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_UDPNOPORTS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutGenErrs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutgenerrs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutGenErrs),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInDestUnreachs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpindestunreachs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINDESTUNREACHS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInAddrErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipinaddrerrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPINADDRERRORS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipDefaultTtl
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipdefaultttl_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 1;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
                sizeof(uint32_t), 0, ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** ipDefaultTtl
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipdefaultttl_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** tcpRetransSegs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpretranssegs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPRETRANSSEGS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipFragCreates
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipfragcreates_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPFRAGCREATES);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInUnkownProtos
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipinunknownprotos_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPINUNKOWNPROTOS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}

/****************************************************************************/
/** udpInDatagrams
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_udpindatagrams_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
   SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_UDPINDATAGRAMS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpOutRsts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpoutrsts_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPOUTRSTS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInEchos
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinechos_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINECHOS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutRedirects
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutredirects_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ifNumber
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ifnumber_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    uint32_t val;
    GOAL_STATUS_T res;
    UNUSEDARG(msg);
    res = goal_ethPortsGet(&val);
    val ++;
    if (GOAL_RES_ERR(res))
        val = 0;
    snmp_set_var_value_type(var, (uint8_t *) &val, sizeof(val), 0, ASN1_INTEGER);
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** icmpInRedirects
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinredirects_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
   SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINREDIRECTS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpMaxConn
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpmaxconn_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    int32_t val = -1;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 1, ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** snmpInTooBigs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpintoobigs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInTooBigs),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInAddrMaskReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpinaddrmaskreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINADDRMASKREPS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpInMsgs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_egpinmsgs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutBadValues
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutbadvalues_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    SNMP_STATS_T *stats = snmp_get_statistics();
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutBadValues),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipRouteTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_iproutetable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = iproutetable_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = iproutetable_getNext(msg, var);
            break;
        default:
            break;
        }
    return result;
}


/****************************************************************************/
/** ipRouteTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_iproutetable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** snmpInNoSuchNames
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinnosuchnames_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInNoSuchNames),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpInSegs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpinsegs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPINSEGS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutTraps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpouttraps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutTraps),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** egpOutErrors
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_egpouterrors_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
            ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInBadValues
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinbadvalues_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInBadValues),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpEnableAuthenTraps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpenableauthentraps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    uint32_t val = 0;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** snmpEnableAuthenTraps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpenableauthentraps_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** snmpInBadVersions
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinbadversions_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInBadVersions),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpAttemptFails
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpattemptfails_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_TCPATTEMPTFAILS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutPkts
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutpkts_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutPkts),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipInDiscards
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipindiscards_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPINDISCARDS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutSetRequests
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutsetrequests_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutSetRequests),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInGenErrs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpingenerrs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInGenErrs),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpInTimestamps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpintimestamps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_ICMPINTIMESTAMPS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpInAsnParseErrs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinasnparseerrs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInASNParseErrs),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutSrcQuenchs
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpoutsrcquenchs_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipReasmFails
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipreasmfails_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPREASMFAILS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** snmpOutGetRequests
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpoutgetrequests_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpOutGetRequests),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** tcpCurrEstab
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_tcpcurrestab_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_GAUGE);
    return ret;
}


/****************************************************************************/
/** ipReasmReqds
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipreasmreqds_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPREASMREQGDS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipReamsOks
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipreasmoks_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    GOAL_NET_IP_STATS_GET_T statsGet;
    GOAL_NET_IP_STATS_COUNTER_T counter;

    UNUSEDARG(msg);

    statsGet.maskStats = (((uint64_t) 1) << GOAL_NET_IP_STATS_IPREASMOKS);
    statsGet.pCounter = &counter;
    counter.val = 0;

    goal_netCmd(GOAL_NET_CMD_IP_STATS_GET, GOAL_FALSE, &statsGet);

    ret = snmp_set_var_value_type(var, (uint8_t *) &(counter.val), sizeof(uint32_t), 0,
                    ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** icmpOutTimeStampReps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_icmpouttimestampreps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    uint32_t val = 0;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val),
               sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipForwarding
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipforwarding_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    uint32_t val;
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    val = 2;
    ret = snmp_set_var_value_type(var, (uint8_t *) &(val), sizeof(uint32_t), 0,
                    ASN1_INTEGER);
    return ret;
}


/****************************************************************************/
/** ipForwarding
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_ipforwarding_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** snmpInTraps
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpintraps_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInTraps),
                    sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}


/****************************************************************************/
/** ipNetToMediaTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_ipnettomediatable_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
        case SNMP_CMD_GET:
            result = ipnettomedia_getValue(msg, var);
            break;
        case SNMP_CMD_GETNEXT:
            result = ipnettomedia_getNext(msg, var);
            break;
        default:
            break;
        }
    return result;
}


/****************************************************************************/
/** ipNetToMediaTable
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_table_ipnettomediatable_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    UNUSEDARG(var);
    UNUSEDARG(cmd);

    msg->error = SNMP_ERR_READ_ONLY;
    return SNMP_RET_NOERR;
}


/****************************************************************************/
/** snmpInBadCommunityNames
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_snmpinbadcommunitynames_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    SNMP_STATS_T *stats = snmp_get_statistics();
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) &(stats->snmpInBadCommunityNames),
                sizeof(uint32_t), 0, ASN1_COUNTER);
    return ret;
}
#endif /* GOAL_SNMP_MIB_RFC1213_SYS_ONLY */


/****************************************************************************/
/** sysDescription
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysdescr_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    UNUSEDARG(var);
    ret = snmp_set_var_value_type(var, (uint8_t *) (sysDescription),
                    (uint16_t) GOAL_STRLEN((char *) sysDescription), 0, ASN1_OCTET_STRING);
    return ret;
}


/****************************************************************************/
/** sysContact
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_syscontact_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) (sysContact),
                    (uint16_t) GOAL_STRLEN((char *) sysContact), 0, ASN1_OCTET_STRING);
    return ret;
}


/****************************************************************************/
/** sysContact
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_syscontact_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
    /* Check type and value */
    case SNMP_CMD_VALUE:
            if (ASN1_OCTET_STRING != var->var->type) {
                    msg->error = SNMP_ERR_WRONG_TYPE;
                    result = SNMP_RET_PARAM;
            } else if (var->var->size > GOAL_SNMP_MIB2_SYSSTRINGLEN) {
                    msg->error = SNMP_ERR_WRONG_LENGTH;
                    result = SNMP_RET_PARAM;
            }
            break;
            /* Set the value */
    case SNMP_CMD_SET:
            sysContactSet((char *) (var->var->data), var->var->size, GOAL_TRUE);
            break;
            /* Undo the value setting */
    case SNMP_CMD_UNDO:
            sysContactSetUndo();
            break;
            /* Commit the value -> transaction complete */
    case SNMP_CMD_COMMIT:
            /* Nothing to do for commit */
            break;
    default:
            break;
    }
    return result;
}


/****************************************************************************/
/** sysName
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysname_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) (sysName),
                    (uint16_t) GOAL_STRLEN((char *) sysName), 0, ASN1_OCTET_STRING);
    return ret;

}


/****************************************************************************/
/** sysName
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_sysname_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
    /* Check type and value */
    case SNMP_CMD_VALUE:
            if (ASN1_OCTET_STRING != var->var->type) {
                    msg->error = SNMP_ERR_WRONG_TYPE;
                    result = SNMP_RET_PARAM;
            } else if (var->var->size > GOAL_SNMP_MIB2_SYSSTRINGLEN) {
                    msg->error = SNMP_ERR_WRONG_LENGTH;
                    result = SNMP_RET_PARAM;
            }
            break;
            /* Set the value */
    case SNMP_CMD_SET:
            sysNameSet((char *) (var->var->data), var->var->size, GOAL_TRUE);
            break;
            /* Undo the value setting */
    case SNMP_CMD_UNDO:
            sysNameSetUndo();
            break;
            /* Commit the value -> transaction complete */
    case SNMP_CMD_COMMIT:
            /* Nothing to do for commit */
            break;
    default:
            break;
    }
    return result;
}


/****************************************************************************/
/** sysLocation
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_syslocation_get(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var                        /**< Variable */
)
{
    SNMP_RET_T ret;
    UNUSEDARG(msg);
    ret = snmp_set_var_value_type(var, (uint8_t *) (sysLocation),
                    (uint16_t) GOAL_STRLEN((char *) sysLocation), 0, ASN1_OCTET_STRING);
    return ret;
}


/****************************************************************************/
/** sysLocation
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_rfc1213_mib_syslocation_set(
    SNMP_MSG_T *msg,                            /**< SNMP Message */
    SNMP_VARENTRY_T *var,                       /**< Variable */
    SNMP_CMD_T cmd                              /**< Table command */
)
{
    SNMP_RET_T result = SNMP_RET_NOERR;
    switch (cmd) {
    /* Check type and value */
    case SNMP_CMD_VALUE:
            if (ASN1_OCTET_STRING != var->var->type) {
                    msg->error = SNMP_ERR_WRONG_TYPE;
                    result = SNMP_RET_PARAM;
            } else if (var->var->size > GOAL_SNMP_MIB2_SYSSTRINGLEN) {
                    msg->error = SNMP_ERR_WRONG_LENGTH;
                    result = SNMP_RET_PARAM;
            }
            break;
            /* Set the value */
    case SNMP_CMD_SET:
            sysLocationSet((char *) (var->var->data), var->var->size, GOAL_TRUE);
            break;
            /* Undo the value setting */
    case SNMP_CMD_UNDO:
            sysLocationSetUndo();
            break;
            /* Commit the value -> transaction complete */
    case SNMP_CMD_COMMIT:
            /* Nothing to do for commit */
            break;
    default:
            break;
    }
    return result;
}


/****************************************************************************/
/** MIB init function
 *
 * @return SNMP_RET_NOERR on success otherwise error code
 */
SNMP_RET_T snmp_RFC1213_MIB_init(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;

#if (0 == GOAL_SNMP_MIB_RFC1213_SYS_ONLY)
    SNMP_TABLE_HANDLER_FUNC_SET_T ipAddrTable = {
                    snmp_rfc1213_mib_table_ipaddrtable_get,
                    snmp_rfc1213_mib_table_ipaddrtable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T atTable = {
                    snmp_rfc1213_mib_table_attable_get,
                    snmp_rfc1213_mib_table_attable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T udpTable = {
                    snmp_rfc1213_mib_table_udptable_get,
                    snmp_rfc1213_mib_table_udptable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T tcpConnTable = {
                    snmp_rfc1213_mib_table_tcpconntable_get,
                    snmp_rfc1213_mib_table_tcpconntable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T ifTable = {
                    snmp_rfc1213_mib_table_iftable_get,
                    snmp_rfc1213_mib_table_iftable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T egpNeighTable = {
                    snmp_rfc1213_mib_table_egpneightable_get,
                    snmp_rfc1213_mib_table_egpneightable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T ipRouteTable = {
                    snmp_rfc1213_mib_table_iproutetable_get,
                    snmp_rfc1213_mib_table_iproutetable_set, NULL };
    SNMP_TABLE_HANDLER_FUNC_SET_T ipNetToMediaTable = {
                    snmp_rfc1213_mib_table_ipnettomediatable_get,
                    snmp_rfc1213_mib_table_ipnettomediatable_set, NULL };
#endif /* !GOAL_SNMP_MIB_RFC1213_SYS_ONLY */

    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysDescr_OID[0], 9,
            SNMP_RO, snmp_rfc1213_mib_sysdescr_get, NULL);

    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysContact_OID[0], 9,
            SNMP_RW, snmp_rfc1213_mib_syscontact_get, snmp_rfc1213_mib_syscontact_set);

    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysName_OID[0], 9,
            SNMP_RW, snmp_rfc1213_mib_sysname_get, snmp_rfc1213_mib_sysname_set);

    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysLocation_OID[0], 9,
            SNMP_RW, snmp_rfc1213_mib_syslocation_get, snmp_rfc1213_mib_syslocation_set);

#if (0 == GOAL_SNMP_MIB_RFC1213_SYS_ONLY)
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpInGetNexts_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpingetnexts_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutEchoReps_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_icmpoutechoreps_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_tcpRtoAlgorithm_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_tcprtoalgorithm_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpOutSegs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcpoutsegs_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_ipAddrTable_OID[0],
                    9, &ipAddrTable);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipFragOKs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_ipfragoks_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysServices_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_sysservices_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInGetResponses_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpingetresponses_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInBadCommunityUses_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinbadcommunityuses_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipInReceives_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipinreceives_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipOutRequests_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipoutrequests_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_sysObjectID_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_sysobjectid_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutDestUnreachs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutdestunreachs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpRtoMax_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcprtomax_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutGetResponses_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpoutgetresponses_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_tcpPassiveOpens_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_tcppassiveopens_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_atTable_OID[0], 9,
                    &atTable);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutGetNexts_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_snmpoutgetnexts_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpInErrs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcpinerrs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInTotalReqVars_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpintotalreqvars_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInParmProbs_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_icmpinparmprobs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_udpOutDatagrams_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_udpoutdatagrams_get, NULL);
    rv |= snmp_mib_register_high_prio_node((uint32_t *) &RFC1213_MIB_sysUpTime_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_sysuptime_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutAddrMaskReps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutaddrmaskreps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_udpInErrors_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_udpinerrors_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutAddrMasks_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutaddrmasks_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_egpAs_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_egpas_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInAddrMasks_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_icmpinaddrmasks_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_udpTable_OID[0], 9,
                    &udpTable);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipOutDiscards_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipoutdiscards_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutTimestamps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpouttimestamps_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInSetRequests_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinsetrequests_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInTimestampReps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpintimestampreps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipInHdrErrors_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipinhdrerrors_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpInMsgs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_icmpinmsgs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutNoSuchNames_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpoutnosuchnames_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutParmProbs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutparmprobs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpOutMsgs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_icmpoutmsgs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_egpInErrors_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_egpinerrors_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpInEchoReps_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_icmpinechoreps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpOutTooBigs_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpouttoobigs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInTimeExcds_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_icmpintimeexcds_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_tcpConnTable_OID[0],
                    9, &tcpConnTable);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_ipRoutingDiscards_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_iproutingdiscards_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInGetRequests_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpingetrequests_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInTotalSetVars_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpintotalsetvars_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_ifTable_OID[0], 9,
                    &ifTable);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInReadOnlys_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_snmpinreadonlys_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_ipForwDatagrams_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_ipforwdatagrams_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutTimeExcds_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpouttimeexcds_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpOutEchos_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_icmpoutechos_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_egpOutMsgs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_egpoutmsgs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInSrcQuenchs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpinsrcquenchs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpOutErrors_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_icmpouterrors_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpActiveOpens_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_tcpactiveopens_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_egpNeighTable_OID[0],
                    9, &egpNeighTable);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpEstabResets_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_tcpestabresets_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipInDelivers_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipindelivers_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpInErrors_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_icmpinerrors_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipReasmTimeout_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipreasmtimeout_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpInPkts_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_snmpinpkts_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipOutNoRoutes_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipoutnoroutes_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpRtoMin_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcprtomin_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipFragFails_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_ipfragfails_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_udpNoPorts_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_udpnoports_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpOutGenErrs_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpoutgenerrs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInDestUnreachs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpindestunreachs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipInAddrErrors_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipinaddrerrors_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipDefaultTTL_OID[0],
                    9,
                    SNMP_RW, snmp_rfc1213_mib_ipdefaultttl_get,
                    snmp_rfc1213_mib_ipdefaultttl_set);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpRetransSegs_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_tcpretranssegs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipFragCreates_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipfragcreates_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_ipInUnknownProtos_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_ipinunknownprotos_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_udpInDatagrams_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_udpindatagrams_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpOutRsts_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcpoutrsts_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_icmpInEchos_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_icmpinechos_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutRedirects_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutredirects_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ifNumber_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_ifnumber_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInRedirects_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_icmpinredirects_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpMaxConn_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcpmaxconn_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpInTooBigs_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpintoobigs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInAddrMaskReps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpinaddrmaskreps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_egpInMsgs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_egpinmsgs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutBadValues_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpoutbadvalues_get, NULL);
    rv |= snmp_mib_register_table((uint32_t *) &RFC1213_MIB_ipRouteTable_OID[0],
                    9, &ipRouteTable);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInNoSuchNames_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinnosuchnames_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpInSegs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_tcpinsegs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpOutTraps_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpouttraps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_egpOutErrors_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_egpouterrors_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInBadValues_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_snmpinbadvalues_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpEnableAuthenTraps_OID[0], 9, SNMP_RW,
                    snmp_rfc1213_mib_snmpenableauthentraps_get,
                    snmp_rfc1213_mib_snmpenableauthentraps_set);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInBadVersions_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinbadversions_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_tcpAttemptFails_OID[0], 9,
                    SNMP_RO, snmp_rfc1213_mib_tcpattemptfails_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpOutPkts_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_snmpoutpkts_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipInDiscards_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipindiscards_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutSetRequests_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpoutsetrequests_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpInGenErrs_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_snmpingenerrs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpInTimestamps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpintimestamps_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInASNParseErrs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinasnparseerrs_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutSrcQuenchs_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpoutsrcquenchs_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipReasmFails_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipreasmfails_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpOutGetRequests_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpoutgetrequests_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_tcpCurrEstab_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_tcpcurrestab_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipReasmReqds_OID[0],
                    9,
                    SNMP_RO, snmp_rfc1213_mib_ipreasmreqds_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipReasmOKs_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_ipreasmoks_get, NULL);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_icmpOutTimestampReps_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_icmpouttimestampreps_get, NULL);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_ipForwarding_OID[0],
                    9,
                    SNMP_RW, snmp_rfc1213_mib_ipforwarding_get,
                    snmp_rfc1213_mib_ipforwarding_set);
    rv |= snmp_mib_register_node((uint32_t *) &RFC1213_MIB_snmpInTraps_OID[0], 9,
    SNMP_RO, snmp_rfc1213_mib_snmpintraps_get, NULL);
    rv |= snmp_mib_register_table(
                    (uint32_t *) &RFC1213_MIB_ipNetToMediaTable_OID[0], 9,
                    &ipNetToMediaTable);
    rv |= snmp_mib_register_node(
                    (uint32_t *) &RFC1213_MIB_snmpInBadCommunityNames_OID[0], 9, SNMP_RO,
                    snmp_rfc1213_mib_snmpinbadcommunitynames_get, NULL);

    rv |= iftable_init();
    rv |= iptable_init();
    rv |= ipnettomedia_init();
    rv |= iproutetable_init();
#endif /* !GOAL_SNMP_MIB_RFC1213_SYS_ONLY */

    /* register reset handler */
    rv |= goal_snmpResetReg(snmp_rfc1213_mib_reset);

    /* register reset handler */

    SNMP_MEMSET(sysLocation_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMSET(sysContact_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMSET(sysName_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    return rv;
}


/****************************************************************************/
/** Set sysLocation value
 *
 */
void sysLocationSet(
    char *strLocation,                          /**< value for sysLocation */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flagWriteNvs                    /**< write NVS flag */
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysLocation_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysLocation_old, sysLocation,
        GOAL_STRNLEN(sysLocation, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    SNMP_MEMSET(sysLocation, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysLocation, strLocation, len);

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_LOCATION, sysLocation,
        (uint32_t) GOAL_STRLEN(sysLocation), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysLocation");
    }
    else if (GOAL_TRUE == flagWriteNvs) {
        goal_cmSave();
    }
}


/****************************************************************************/
/** sysLocation Undo
 *
 */
void sysLocationSetUndo(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysLocation, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysLocation, sysLocation_old,
        GOAL_STRNLEN(sysLocation_old, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_LOCATION, sysLocation,
        (uint32_t)GOAL_STRLEN(sysLocation), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysLocation");
    }
    else {
        goal_cmSave();
    }
}


/****************************************************************************/
/** Set sysDescription
 *
 */
void sysDescriptionSet(
    char *desc,                                 /**< Description */
    uint16_t len                                /**< Length */
)
{
    SNMP_MEMSET(sysDescription, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysDescription, desc, len);
    flgDescValid = GOAL_TRUE;
}


/****************************************************************************/
/** Set sysContact value
 *
 */
void sysContactSet(
    char *strContact,                           /**< value for sysContact */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flagWriteNvs                    /**< write NVS flag */
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysContact_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysContact_old, sysContact,
        GOAL_STRNLEN(sysContact, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    SNMP_MEMSET(sysContact, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysContact, strContact, len);

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_CONTACT, sysContact,
        (uint32_t) GOAL_STRLEN(sysContact), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysContact");
    }
    else if (GOAL_TRUE == flagWriteNvs) {
        goal_cmSave();
    }
}


/****************************************************************************/
/** sysContact Undo
 *
 */
void sysContactSetUndo(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysContact, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysContact, sysContact_old,
        GOAL_STRNLEN(sysContact_old, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_CONTACT, sysContact,
        (uint32_t) GOAL_STRLEN(sysContact), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysContact");
    }
    else {
        goal_cmSave();
    }
}


/****************************************************************************/
/** Set sysName value
 *
 */
void sysNameSet(
    char *strName,                              /**< value for sysName */
    uint16_t len,                               /**< string length */
    GOAL_BOOL_T flagWriteNvs                    /**< write NVS flag */
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysName_old, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysName_old, sysName,
        GOAL_STRNLEN(sysName, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    SNMP_MEMSET(sysName, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysName, strName, len);

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_NAME, sysName,
        (uint32_t) GOAL_STRLEN(sysName), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysName");
    }
    else if (GOAL_TRUE == flagWriteNvs) {
        goal_cmSave();
    }
}


/****************************************************************************/
/** sysName Undo
 *
 */
void sysNameSetUndo(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    SNMP_MEMSET(sysName, 0, GOAL_SNMP_MIB2_SYSSTRINGLEN);
    SNMP_MEMCPY(sysName, sysName_old,
        GOAL_STRNLEN(sysName_old, GOAL_SNMP_MIB2_SYSSTRINGLEN));

    res = goal_cmSetVarValue(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_NAME, sysName,
        (uint32_t) GOAL_STRLEN(sysName), GOAL_FALSE, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Could not set sysName");
    }
    else {
        goal_cmSave();
    }
}



/****************************************************************************/
/** Get sysLocation value from config manager and set loaded value.
 * If no valid value is found, default value is set.
 *
 */
static void sysLocationInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar;                      /* CM var handle */
    uint16_t cmLen;                             /* length of cm variable */

    /* get stored CM variable vor sysLocation */
    res = goal_cmGetVarById(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_LOCATION, &pCmVar);

    /* calculate length of loaded sysLocation */
    if (GOAL_RES_OK(res)) {
        cmLen = (uint16_t) GOAL_STRLEN(GOAL_CM_VAR_STRING(pCmVar));
    }
    else {
        cmLen = 0;
    }

    /* set loaded sysLocation, if valid */
    if (0 == cmLen) {
        sysLocationSet(strLocationDefault, (uint16_t) GOAL_STRLEN(strLocationDefault), GOAL_FALSE);
    }
    else {
        sysLocationSet(GOAL_CM_VAR_STRING(pCmVar), cmLen, GOAL_FALSE);
    }


}


/****************************************************************************/
/** Get sysContact value from config manager and set loaded value.
 * If no valid value is found, default value is set.
 *
 */
static void sysContactInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar;                      /* CM var handle */
    uint16_t cmLen;                             /* length of cm variable */

    /* get stored CM variable vor sysContact */
    res = goal_cmGetVarById(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_CONTACT, &pCmVar);

    /* calculate length of loaded sysContact */
    if (GOAL_RES_OK(res)) {
        cmLen = (uint16_t) GOAL_STRLEN(GOAL_CM_VAR_STRING(pCmVar));
    }
    else {
        cmLen = 0;
    }

    /* set loaded sysContact, if valid */
    if (0 == cmLen) {
        sysContactSet(strContactDefault, (uint16_t) GOAL_STRLEN(strContactDefault), GOAL_FALSE);
    }
    else {
        sysContactSet(GOAL_CM_VAR_STRING(pCmVar), cmLen, GOAL_FALSE);
    }
}


/****************************************************************************/
/** Get sysName value from config manager and set loaded value.
 * If no valid value is found, default value is set.
 *
 */
static void sysNameInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar;                      /* CM var handle */
    uint16_t cmLen;                             /* length of cm variable */

    /* get stored CM variable vor sysName */
    res = goal_cmGetVarById(GOAL_SNMP_MIB2_CM_MOD_ID, GOAL_SNMP_MIB2_CM_SYS_NAME, &pCmVar);

    /* calculate length of loaded sysName */
    if (GOAL_RES_OK(res)) {
        cmLen = (uint16_t) GOAL_STRLEN(GOAL_CM_VAR_STRING(pCmVar));
    }
    else {
        cmLen = 0;
    }

    /* set loaded sysName, if valid */
    if (0 == cmLen) {
        sysNameSet(strNameDefault, (uint16_t) GOAL_STRLEN(strNameDefault), GOAL_FALSE);
    }
    else {
        sysNameSet(GOAL_CM_VAR_STRING(pCmVar), cmLen, GOAL_FALSE);
    }
}


/****************************************************************************/
/** Sets sysLocation, sysContact and sysName to default values.
 *
 * @returns SNMP_RET_T value
 */
static SNMP_RET_T snmp_rfc1213_mib_reset(
    void *pArg                                  /**< reset argument */
)
{
    UNUSEDARG(pArg);

    /* set sysLocation to default */
    sysLocationSet(strLocationDefault, (uint16_t) GOAL_STRLEN(strLocationDefault), GOAL_FALSE);

    /* set sysContact to default */
    sysContactSet(strContactDefault, (uint16_t) GOAL_STRLEN(strContactDefault), GOAL_FALSE);

    /* set sysName to default and store Data*/
    sysNameSet(strNameDefault, (uint16_t) GOAL_STRLEN(strNameDefault), GOAL_TRUE);

    return SNMP_RET_NOERR;
}
