/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>

#include <snmp_portgmbh_mib.h>


/****************************************************************************/
/* Local variables */
/****************************************************************************/
uint32_t PORTGMBH_MIB_pnioStackName_OID[12] =           {1, 3, 6, 1, 4, 1, 44228, 1, 1, 2, 1, 0};
static uint32_t PORTGMBH_MIB_snmpStackName_OID[12] =    {1, 3, 6, 1, 4, 1, 44228, 1, 1, 1, 1, 0};
static uint32_t PORTGMBH_MIB_pnioStackVersion_OID[12] = {1, 3, 6, 1, 4, 1, 44228, 1, 1, 2, 2, 0};
static uint32_t PORTGMBH_MIB_snmpStackVersion_OID[12] = {1, 3, 6, 1, 4, 1, 44228, 1, 1, 1, 2, 0};

static char *strSnmpStackName = "port SNMP Stack";
static char *strSnmpStackVersion = "v0.1.0";
static char *strPnioStackName = "port PROFINET Stack";
static char *strPnioStackVersion = "v1.1.0";


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static SNMP_RET_T snmp_portgmbh_mib_snmpstackname_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
);

static SNMP_RET_T snmp_portgmbh_mib_pniostackversion_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
);

static SNMP_RET_T snmp_portgmbh_mib_pniostackname_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
);

static SNMP_RET_T snmp_portgmbh_mib_snmpstackversion_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
);


/****************************************************************************/
/** Returns the current value for snmpStackName
 *
 * @param pMsg The message containing the get request
 * @param pVar The variable entry where the value will be stored
 *
 * @returns SNMP_RET_NOERR when successful, otherwise error code
 */
static SNMP_RET_T snmp_portgmbh_mib_snmpstackname_get(
    SNMP_MSG_T *pMsg,                      /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
)
{
    UNUSEDARG(pMsg);

    return snmp_set_var_value_type(pVar, (uint8_t *) strSnmpStackName,
                                   (uint16_t) GOAL_STRLEN(strSnmpStackName), 0, ASN1_OCTET_STRING);
}


/****************************************************************************/
/** Returns the current value for pnioStackVersion
 *
 * @param pMsg The message containing the get request
 * @param pVar The variable entry where the value will be stored
 *
 * @returns SNMP_RET_NOERR when successful, otherwise error code
 */
static SNMP_RET_T snmp_portgmbh_mib_pniostackversion_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
)
{
    UNUSEDARG(pMsg);

    return snmp_set_var_value_type(pVar, (uint8_t *) strPnioStackVersion,
                                   (uint16_t) GOAL_STRLEN(strPnioStackVersion), 0, ASN1_OCTET_STRING);
}


/****************************************************************************/
/** Returns the current value for pnioStackName
 *
 * @param pMsg The message containing the get request
 * @param pVar The variable entry where the value will be stored
 *
 * @returns SNMP_RET_NOERR when successful, otherwise error code
 */
static SNMP_RET_T snmp_portgmbh_mib_pniostackname_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
)
{
    UNUSEDARG(pMsg);

    return snmp_set_var_value_type(pVar, (uint8_t *) strPnioStackName,
                                   (uint16_t) GOAL_STRLEN(strPnioStackName), 0, ASN1_OCTET_STRING);
}


/****************************************************************************/
/** Returns the current value for snmpStackVersion
 *
 * @param pMsg The message containing the get request
 * @param pVar The variable entry where the value will be stored
 *
 * @returns SNMP_RET_NOERR when successful, otherwise error code
 */
static SNMP_RET_T snmp_portgmbh_mib_snmpstackversion_get(
    SNMP_MSG_T *pMsg,                           /**< message */
    SNMP_VARENTRY_T *pVar                       /**< variable */
)
{
    UNUSEDARG(pMsg);

    return snmp_set_var_value_type(pVar, (uint8_t *) strSnmpStackVersion,
                                   (uint16_t) GOAL_STRLEN(strSnmpStackVersion), 0, ASN1_OCTET_STRING);
}


/****************************************************************************/
/** Initializes the port GmbH MIB
 *
 * @returns GOAL_STATUS_T value
 */
GOAL_STATUS_T goal_snmpMibPortInit(
    void
)
{
    SNMP_RET_T rv = SNMP_RET_NOERR;             /* result */

    rv |= snmp_mib_register_node((uint32_t *) PORTGMBH_MIB_snmpStackName_OID,
                                 ARRAY_ELEMENTS(PORTGMBH_MIB_snmpStackName_OID),
                                 SNMP_RO, snmp_portgmbh_mib_snmpstackname_get, NULL);

    rv |= snmp_mib_register_node((uint32_t *) PORTGMBH_MIB_pnioStackVersion_OID,
                                 ARRAY_ELEMENTS(PORTGMBH_MIB_pnioStackVersion_OID),
                                 SNMP_RO, snmp_portgmbh_mib_pniostackversion_get, NULL);

    rv |= snmp_mib_register_node((uint32_t *) PORTGMBH_MIB_pnioStackName_OID,
                                 ARRAY_ELEMENTS(PORTGMBH_MIB_pnioStackName_OID),
                                 SNMP_RO, snmp_portgmbh_mib_pniostackname_get, NULL);

    rv |= snmp_mib_register_node((uint32_t *) PORTGMBH_MIB_snmpStackVersion_OID,
                                 ARRAY_ELEMENTS(PORTGMBH_MIB_snmpStackVersion_OID),
                                 SNMP_RO, snmp_portgmbh_mib_snmpstackversion_get, NULL);

    if (SNMP_RET_NOERR != rv) {
        goal_logErr("Could not initialize Enterprise MIB.");
        return GOAL_ERROR;
    }

    goal_logInfo("Initialized Enterprise MIB.");
    return GOAL_OK;
}
