/** @file
 *
 * @brief
 * Simple Network Management Protocol Implementation
 *
 * @details
 * This module contains the Simple Network Management Protocol implementation
 * from port GmbH.
 *
 * @copyright
 * Copyright 2010-2016 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef SNMP_PORTGMBH_MIB_FILE_H
#define SNMP_PORTGMBH_MIB_FILE_H


/****************************************************************************/
/* extern variable declerations */
/****************************************************************************/
extern uint32_t PORTGMBH_MIB_pnioStackName_OID[12];


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_snmpMibPortInit(
    void
);

#endif /* SNMP_PORTGMBH_MIB_FILE_H */
