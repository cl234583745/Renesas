# goal lm emitter module

 - translates goal lm log messages into readable form and outputs
   to multiple targets

