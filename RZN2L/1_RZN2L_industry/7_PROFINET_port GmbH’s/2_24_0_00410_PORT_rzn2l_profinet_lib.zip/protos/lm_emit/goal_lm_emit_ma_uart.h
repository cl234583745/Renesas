/** @file
 *
 * @brief emitter for goal lm emitter over MA_UART
 *
 * @details
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_LM_EMIT_MA_UART_H
#define GOAL_LM_EMIT_MA_UART_H


/****************************************************************************/
/* Defines */
/****************************************************************************/

#define EMIT_BUF_SIZE GOAL_NETBUF_SIZE          /**< size the emitter can buffer */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_lmEmitMaUartReg(
    void
);

#endif /* GOAL_LM_EMIT_MA_UART_H */
