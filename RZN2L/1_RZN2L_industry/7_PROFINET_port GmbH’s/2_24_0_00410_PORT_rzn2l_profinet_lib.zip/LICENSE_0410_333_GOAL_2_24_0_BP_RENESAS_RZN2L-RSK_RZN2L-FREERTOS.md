# Licenses

GOAL (Generic Open Abstraction Layer) incorporates various software to support
a wide variety of platforms.

A list of used software and their licenses is provided in the following chapters.

Port GmbH shall not be held liable for the provided license information. Please
always check your requirements against the official provided license
information from the used software product.


## FreeRTOS (v10.0.1)


### License Conditions

    The FreeRTOS kernel is released under the MIT open source license, the text of
    which is provided below.

    This license covers the FreeRTOS kernel source files, which are located in the
    /FreeRTOS/Source directory of the official FreeRTOS kernel download.  It also
    covers most of the source files in the demo application projects, which are
    located in the /FreeRTOS/Demo directory of the official FreeRTOS download.  The
    demo projects may also include third party software that is not part of FreeRTOS
    and is licensed separately to FreeRTOS.  Examples of third party software
    includes header files provided by chip or tools vendors, linker scripts,
    peripheral drivers, etc.  All the software in subdirectories of the /FreeRTOS
    directory is either open source or distributed with permission, and is free for
    use.  For the avoidance of doubt, refer to the comments at the top of each
    source file.


    License text:
    -------------

    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
    Permission is hereby granted, free of charge, to any person obtaining a copy of
    this software and associated documentation files (the "Software"), to deal in
    the Software without restriction, including without limitation the rights to
    use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
    the Software, and to permit persons to whom the Software is furnished to do so,
    subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
    FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
    COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
    IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
    CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.


### Copyrights

    Copyright (C) 2017 Amazon.com, Inc. or its affiliates.  All Rights Reserved.
## psnprintf - Portable snprintf Implementation (v0.4)


### License Conditions

    Source: https://web.archive.org/web/20060819235203/http://yallara.cs.rmit.edu.au/~aholkner/psnprintf/psnprintf.html
    
    The psnprintf library (the "WORK") was written by Alex Holkner (the
    "AUTHOR"). The author hereby grants you the right to use the work in any
    way you desire, including but not limited to redistribution, modification,
    selling and the inclusion in a larger work. No acknowledgement of the
    author is required. The author provides the work AS IS and is not
    responsible for any damage the work causes. The work carries no express or
    implied warranty.
    
    Alex Holkner, 17-Oct-2004
    alex@partiallydisassembled.net
    aholkner@cs.rmit.edu.au


### Copyrights

    Alex Holkner, 17-Oct-2004


## uthash


### License Conditions

    Copyright (c) 2005-2014, Troy D. Hanson    http://troydhanson.github.com/uthash/
    All rights reserved.
    
    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions are met:
    
        * Redistributions of source code must retain the above copyright
          notice, this list of conditions and the following disclaimer.
    
    THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS
    IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
    TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
    PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER
    OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
    EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
    PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
    PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
    LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
    NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
    SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


### Copyrights

    Copyright (c) 2005-2014, Troy D. Hanson. All rights reserved.


