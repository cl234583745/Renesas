# Licenses

GOAL (Generic Open Abstraction Layer) incorporates various software to support
a wide variety of platforms.

A list of used software and their licenses is provided in the following chapters.

Port GmbH shall not be held liable for the provided license information. Please
always check your requirements against the official provided license
information from the used software product.


