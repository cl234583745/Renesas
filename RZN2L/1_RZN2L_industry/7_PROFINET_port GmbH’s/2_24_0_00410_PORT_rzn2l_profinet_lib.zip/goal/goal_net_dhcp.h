/** @file
 *
 * @brief DHCP Client
 *
 * @details
 * This module implements a DHCPv4 client.
 *
 * @copyright
 * Copyright 2016-2020.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_NET_DHCP_H
#define GOAL_NET_DHCP_H


/****************************************************************************/
/* Public functions */
/****************************************************************************/
GOAL_STATUS_T goal_netDhcpInit(
    void
);

GOAL_STATUS_T goal_netDhcpShutdown(
    void
);

GOAL_STATUS_T goal_netDhcpStart(
    void
);

void goal_netDhcpLoop(
    void
);

GOAL_STATUS_T goal_netDhcpStop(
    void
);

GOAL_STATUS_T goal_netDhcpRelease(
    GOAL_BOOL_T *pReleaseTx                     /**< send RELEASE message */
);

GOAL_STATUS_T goal_netDhcpGetAddr(
    GOAL_NET_DHCP_T *pAddrData                  /**< DHCP address data */
);

GOAL_STATUS_T goal_netDhcpGetState(
    uint32_t *pState                            /**< current state */
);


#endif /* GOAL_NET_DHCP_H */
