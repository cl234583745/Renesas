/** @file
 *
 * @brief eth configuration
 *
 * @copyright
 * Copyright 2021 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_ETH_CM_H
#define GOAL_ETH_CM_H

#include <goal_includes.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_ethRegCmVars(
    void
);


/****************************************************************************/
/* Configuration Variables Management */
/****************************************************************************/

#define GOAL_CM_ETH_MOD_ID      4

#define GOAL_CM_ETH_VARS \
/*              Name,              Data type,       Max. size,        Validation Cb, Change Cb */   \
    GOAL_CM_VAR(ETH_CM_VAR_MAC, GOAL_CM_GENERIC, 6, NULL, NULL)

enum GOAL_CM_ETH_VAR_IDS {
    ETH_CM_VAR_MAC = 0,
    GOAL_CM_ETH_VAR_LAST
};

enum GOAL_CM_ETH_VIRT_VAR_IDS {
    ETH_CM_VAR_LINK = 1000,
    ETH_CM_VAR_SPEED = 1001,
    ETH_CM_VAR_DUPLEX = 1002,
    ETH_CM_VAR_PORTCNT = 1003,
    GOAL_CM_ETH_VIRT_VAR_LAST
};

#endif /* GOAL_ETH_CM_H */

