/** @file
 *
 * @brief lm configuration
 *
 * @copyright
 * Copyright 2021 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_LM_CM_H
#define GOAL_LM_CM_H

#include <goal_includes.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_lmRegCmVars(
    void
);


/****************************************************************************/
/* Configuration Variables Management */
/****************************************************************************/

#define GOAL_CM_LM_MOD_ID      35

#define GOAL_CM_LM_VARS \
/*              Name,              Data type,       Max. size,        Validation Cb, Change Cb */   \
    GOAL_CM_VAR(LM_CM_VAR_VERSION, GOAL_CM_UINT8, 1, NULL, NULL)

enum GOAL_CM_LM_VAR_IDS {
    LM_CM_VAR_VERSION = 0,
    GOAL_CM_LM_VAR_LAST
};

enum GOAL_CM_LM_VIRT_VAR_IDS {
    LM_CM_VAR_READBUFFER = 1000,
    LM_CM_VAR_CNT = 1001,
    LM_CM_VAR_EXLOG_READBUFFER = 1002,
    LM_CM_VAR_EXLOG_CNT = 1003,
    LM_CM_VAR_EXLOG_SIZE = 1004,
    LM_CM_VAR_EXLOG_USAGE = 1005,
    LM_CM_VAR_EXLOG_ERASE = 1006,
    GOAL_CM_LM_VIRT_VAR_LAST
};

#endif /* GOAL_LM_CM_H */

