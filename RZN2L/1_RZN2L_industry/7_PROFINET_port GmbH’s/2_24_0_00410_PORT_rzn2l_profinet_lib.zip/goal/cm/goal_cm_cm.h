/** @file
 *
 * @brief cm configuration
 *
 * @copyright
 * Copyright 2021 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_CM_CM_H
#define GOAL_CM_CM_H

#include <goal_includes.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_cmRegCmVars(
    void
);


/****************************************************************************/
/* Configuration Variables Management */
/****************************************************************************/

#define GOAL_CM_CM_MOD_ID      2

#define GOAL_CM_CM_VARS \
/*              Name,              Data type,       Max. size,        Validation Cb, Change Cb */   \
    GOAL_CM_VAR(CM_CM_VAR_VERSION, GOAL_CM_UINT32, 4, NULL, NULL)

enum GOAL_CM_CM_VAR_IDS {
    CM_CM_VAR_VERSION = 0,
    GOAL_CM_CM_VAR_LAST
};

enum GOAL_CM_CM_VIRT_VAR_IDS {
    CM_CM_VAR_SAVE = 1000,
    GOAL_CM_CM_VIRT_VAR_LAST
};

#endif /* GOAL_CM_CM_H */

