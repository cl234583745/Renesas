/** @file
 *
 * @brief Debug CLI command
 *
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_DBG_CLI_H
#define GOAL_DBG_CLI_H


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_dbgInitCli(
    void
);

#endif /* GOAL_DBG_CLI_H */
