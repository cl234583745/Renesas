/** @file
 *
 * @brief GOAL Network Handling
 *
 * This module implements the interface for managing TCP and UDP connections.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_NET
#include <goal_includes.h>
#include "cm/goal_net_cm.h"

#if GOAL_CONFIG_TCPIP_STACK == 1


/****************************************************************************/
/* global variables */
/****************************************************************************/
GOAL_BOOL_T goal_netInitFlag = GOAL_FALSE;      /**< init flag */

#if GOAL_CONFIG_IP_STATS_NAMES == 1
#  undef GOAL_IP_STATS_RV
#  define GOAL_IP_STATS_RV(nr, id, desc) desc

/**< IP statistics names */
static const char *strIpStats[] = {
    GOAL_IP_STATS_RV_LIST,
};
#endif


/****************************************************************************/
/* local variables */
/****************************************************************************/
static GOAL_STAGE_HANDLER_T stageInit;          /**< init stage handler */
#if GOAL_CONFIG_CLI == 1
static GOAL_STAGE_HANDLER_T stageCli;           /**< CLI init stage handler */
#endif
#if GOAL_CONFIG_MEDIA_MI_ETH == 0
static GOAL_STAGE_HANDLER_T stageMiNetOpen;     /**< open stage handler */
#endif
static GOAL_STAGE_HANDLER_T stageShutdown;      /**< shutdown stage handler */
static uint32_t goal_netTgtHandleSize;          /**< target handle size */
static GOAL_NET_CHAN_T goal_netChans[GOAL_CONFIG_NET_CHAN_MAX]; /**< channels */
static GOAL_BOOL_T flgNetOpen;                  /**< open flag */
static uint16_t dynPorts[GOAL_CONFIG_NET_CHAN_MAX]; /**< list of dynamic ports */


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static GOAL_STATUS_T goal_netInit(
    void
);

static GOAL_STATUS_T goal_netFindFreeChan(
    GOAL_NET_CHAN_T **ppChanHandle              /**< pointer to found channel */
);

static GOAL_STATUS_T goal_netShutdown(
    void
);

static GOAL_STATUS_T ipValidCheck(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary config flag */
);

static GOAL_STATUS_T goal_netChanOpen(
    GOAL_NET_CHAN_T **ppChanHandle,             /**< pointer to channel handle */
    GOAL_NET_ADDR_T *pAddr,                     /**< remote address */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_CB_T callback,                     /**< channel callback */
    GOAL_BOOL_T flgReusable                     /**< channel reusability flag */
);


/****************************************************************************/
/** Register stage handler
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netInitPre(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* init stage */
    res = goal_mainStageReg(GOAL_STAGE_NET_PRE, &stageInit, GOAL_STAGE_INIT, goal_netInit);

#if GOAL_CONFIG_CLI == 1
    /* CLI stage */
    if (GOAL_RES_OK(res)) {
        res = goal_mainStageReg(GOAL_STAGE_CLI, &stageCli, GOAL_STAGE_INIT, goal_netInitCli);
    }
#endif

#if GOAL_CONFIG_MEDIA_MI_ETH == 0
    /* mi open stage */
    if (GOAL_RES_OK(res)) {
        res = goal_mainStageReg(GOAL_STAGE_NET_PRE, &stageMiNetOpen, GOAL_STAGE_INIT, goal_miNetOpen);
    }
#endif

    /* shutdown stage */
    if (GOAL_RES_OK(res)) {
        res = goal_mainStageReg(GOAL_STAGE_NET_PRE, &stageShutdown, GOAL_STAGE_SHUTDOWN, goal_netShutdown);
    }

    goal_netRegCmVars();

    return res;
}


/****************************************************************************/
/** Initialize Network Handling
 *
 * Initialize all channels for the TCP/IP stack.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
static GOAL_STATUS_T goal_netInit(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    unsigned int cnt;                           /* counter */
    GOAL_BOOL_T flgValid = GOAL_FALSE;          /* IP valid flag */

    /* initialize channels */
    GOAL_MEMSET(goal_netChans, 0, sizeof(goal_netChans));

    /* initialize list of dynamic ports */
    GOAL_MEMSET(dynPorts, 0, sizeof(dynPorts));

    /* retrieve size of target handle */
    goal_netTgtHandleSize = goal_targetNetGetHandleSize();
    GOAL_ASSERT(goal_netTgtHandleSize);

    /* initialize target handle storage space */
    for (cnt = 0; (cnt < GOAL_CONFIG_NET_CHAN_MAX) && (GOAL_OK == res); cnt++) {
        res = goal_memCallocAlign(&goal_netChans[cnt].pData, goal_netTgtHandleSize, GOAL_TARGET_MEM_ALIGN_CPU);
    }

    /* request default number of buffers */
    res = goal_queuePoolBufsReq(GOAL_ID_NET, GOAL_NETBUF_SIZE, GOAL_CONFIG_BUF_NUM, 0);

    /* initialize target */
    if (GOAL_RES_OK(res)) {
        res = goal_targetNetInit();
    }

    /* trigger IP configuration sync */
    if (GOAL_RES_OK(res)) {
        res = goal_netFlgValidGet(&flgValid);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_mainCbReg(GOAL_ID_NET, GOAL_NET_CB_ID_IP_SET_VERIFY, (GOAL_FUNC_RET_NOARG_T) (void *) ipValidCheck);
    }

    if (GOAL_OK == res) {
        /* set init-done flag */
        goal_netInitFlag = GOAL_TRUE;
    }

    return res;
}


/****************************************************************************/
/** Open Media Interface Net
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_miNetOpen(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    uint32_t addrIp = 0;                        /* IP address */
    uint32_t addrMask = 0;                      /* netmask */
    uint32_t addrGw = 0;                        /* gateway */
    GOAL_BOOL_T flgValid = GOAL_FALSE;          /* IP valid flag */
    GOAL_BOOL_T flgTemp = GOAL_TRUE;            /* IP temp flag */
    GOAL_BOOL_T flgDefaultIpUse = GOAL_FALSE;   /* usage of default IP flag */
    GOAL_BOOL_T flgDhcpEnabled = GOAL_FALSE;    /* DHCP enabled flag */

    /* don't open twice */
    if (GOAL_TRUE == flgNetOpen) {
        return GOAL_OK;
    }

#if GOAL_CONFIG_DHCP == 1
    /* initialize DHCP client */
    if (GOAL_RES_OK(res)) {
        res = goal_netDhcpInit();
    }
#endif

    /* add protocol handler */
    if (GOAL_RES_OK(res)) {
        res = goal_targetNetStart(NULL);
    }

    /* read IP settings from TCP/IP stack */
    res = goal_targetNetIpGet(&addrIp, &addrMask, &addrGw, NULL);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:158: */
        goal_lmLog(GOAL_ID_NET, 158, 127, 0, 0, GOAL_LOG_SEV_ERROR, "failed to get IP configuration");
    }

    /* if we get no valid settings, check the non volatile settings */
    if (GOAL_RES_ERR(res) || (0 == addrIp)) {

        /* check DHCP status, ignore result */
        goal_netCmDhcpGet(&flgDhcpEnabled);

        /* get ip address from CM */
        res = goal_netIpGet(&addrIp, &addrMask, &addrGw, &flgTemp);
        if (GOAL_RES_OK(res) && (GOAL_TRUE == flgTemp)) {
            if (GOAL_FALSE == flgDhcpEnabled) {
                /* if temp. flag is set (IP not valid) and DHCP is not set, use default IP */
                flgDefaultIpUse = GOAL_TRUE;
            }
        } else if (GOAL_RES_ERR(res)) {
            /* use default IP, if reading ip address from CM failed */
            flgDefaultIpUse = GOAL_TRUE;
        }
    }

    /* check IP configuration of CM or target */
    if (GOAL_RES_OK(res) && (GOAL_FALSE == flgDefaultIpUse) && (GOAL_FALSE == flgDhcpEnabled)) {
        res = goal_netIpValidCheck(addrIp, addrMask, addrGw, GOAL_TRUE);
        if (GOAL_RES_ERR(res)) {
            /* use default IP */
            flgDefaultIpUse = GOAL_TRUE;
        }
    }

    /* if either system or nvs don't give use valid settings, set the default IP */
    if (GOAL_RES_ERR(res) || (GOAL_TRUE == flgDefaultIpUse)) {
        /* use default net address */
        addrIp = GOAL_CONFIG_NET_ADDR_IP_DEFAULT;
        addrMask = GOAL_CONFIG_NET_ADDR_MASK_DEFAULT;
        addrGw = GOAL_CONFIG_NET_ADDR_GATEWAY_DEFAULT;
        flgTemp = GOAL_TRUE;

        res = GOAL_OK;
    }

    /* sync config with CM */
    if (GOAL_RES_OK(res)) {
        flgValid = (GOAL_TRUE == flgTemp) ? GOAL_FALSE : GOAL_TRUE;
        res = goal_netCmIpSet(addrIp, addrMask, addrGw, flgValid);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:159: */
            goal_lmLog(GOAL_ID_NET, 159, 128, 0, 0, GOAL_LOG_SEV_ERROR, "failed to update IP configuration");
        }
    }

    if (GOAL_RES_OK(res)) {
        /* use stored IP, except DHCP is enabled */
        res = goal_netCmIpCommit();

        if (GOAL_FALSE == flgDhcpEnabled) {
            /* GG_LOG ID:30: */
            goal_lmLog(GOAL_ID_NET, 30, 20, 4, 0, GOAL_LOG_SEV_INFO, "ip address: $1");
            goal_lmLogParamIPV4(addrIp);
            goal_lmLogFinish();
            /* GG_LOG ID:31: */
            goal_lmLog(GOAL_ID_NET, 31, 21, 4, 0, GOAL_LOG_SEV_INFO, "netmask: $1");
            goal_lmLogParamIPV4(addrMask);
            goal_lmLogFinish();
            /* GG_LOG ID:32: */
            goal_lmLog(GOAL_ID_NET, 32, 22, 4, 0, GOAL_LOG_SEV_INFO, "gateway: $1");
            goal_lmLogParamIPV4(addrGw);
            goal_lmLogFinish();
            /* GG_LOG ID:33: */
            goal_lmLog(GOAL_ID_NET, 33, 23, 1, 0, GOAL_LOG_SEV_INFO, "IP valid flag: $1");
            goal_lmLogParamBOOLEAN(flgValid);
            goal_lmLogFinish();
        }
    }

    /* inform callback listeners */
    GOAL_MAIN_CB_FOREACH(GOAL_ID_NET, GOAL_NET_CB_ID_NET_UP, GOAL_NET_CB_NET_UP_T, NULL, GOAL_ID_DEFAULT)

    if (GOAL_RES_OK(res)) {
        flgNetOpen = GOAL_TRUE;
    }

    return res;
}


/****************************************************************************/
/** Find free channel handle
 *
 * Finds the next unused channel handle of goal_netChans.
 * The finder returns a channel handle that is as different from the input
 * channel handle as possible.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
static GOAL_STATUS_T goal_netFindFreeChan(
    GOAL_NET_CHAN_T **ppChanHandle              /**< pointer to found channel */
)
{
    unsigned int cnt;                           /* counter */
    GOAL_BOOL_T flgReuable = GOAL_FALSE;        /* reusable channel handle flag */

    /* look up channels */
    for (cnt = 0; GOAL_CONFIG_NET_CHAN_MAX > cnt; cnt++) {
        if (GOAL_FALSE == goal_netChans[cnt].used) {
            if (&goal_netChans[cnt] == *ppChanHandle) {
                flgReuable = GOAL_TRUE;
            } else {
                break;
            }
        }
    }

    /* check if no unused channel is found */
    if ((GOAL_CONFIG_NET_CHAN_MAX == cnt) && (GOAL_FALSE == flgReuable)) {
        /* GG_LOG ID:160: */
        goal_lmLog(GOAL_ID_NET, 160, 129, 0, 0, GOAL_LOG_SEV_ERROR, "Could not find free GOAL channel");
        return GOAL_ERR_ALLOC;
    }

    /* return unused channel handle */
    if (GOAL_CONFIG_NET_CHAN_MAX > cnt) {
        *ppChanHandle = &goal_netChans[cnt];
    }
    return GOAL_OK;
}


/****************************************************************************/
/** Informs the channel of a new Event, i.e. a new connection, new data or
 * close using the registered channel callback.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netCb(
    GOAL_NET_CB_TYPE_T type,                    /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel handle */
    GOAL_BUFFER_T *pBuf                         /**< GOAL buffer */
)
{
    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        /* GG_LOG ID:192: */
        goal_lmLog(GOAL_ID_NET, 192, 152, 0, 0, GOAL_LOG_SEV_ERROR, "not initialized");
        return GOAL_ERR_NOT_INITIALIZED;
    }

    /* check if channel is valid */
    if (GOAL_FALSE == pChan->active) {
        /* GG_LOG ID:161: */
        goal_lmLog(GOAL_ID_NET, 161, 130, 0, 0, GOAL_LOG_SEV_ERROR, "Channel in application directon is not active.");
        return GOAL_ERR_NET_SEND_CHAN_DISABLED;
    }

    /* check for valid callback */
    if (NULL == pChan->callback) {
        goal_lmLog(GOAL_ID_NET, 194, 154, 0, 0, GOAL_LOG_SEV_ERROR, "no callback function registered");
        return GOAL_ERR_NULL_POINTER;
    }

    pChan->callback(type, pChan, pBuf);

    return GOAL_OK;
}


/****************************************************************************/
/** Open a new network channel
 *
 * Get a new channel handle if possible, and open an network channel on the
 * specified port.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netOpen(
    GOAL_NET_CHAN_T **ppChanHandle,             /**< pointer to channel handle */
    GOAL_NET_ADDR_T *pAddr,                     /**< remote address */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_CB_T callback                      /**< channel callback */
)
{
    return goal_netChanOpen(ppChanHandle, pAddr, type, callback, GOAL_FALSE);
}


/****************************************************************************/
/** Open a network channel with reusability of the channel handle
 *
 * Open an network channel on the specified port.
 * If the given channel handle is reusable, i.e. the handle can be found in
 * the channel handle pool and the attributes of the handls are not changed,
 * the handle will be reused. Existing socket options may continue to be
 * used depending on the target network channel opener.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netOpenReusable(
    GOAL_NET_CHAN_T **ppChanHandle,             /**< pointer to channel handle */
    GOAL_NET_ADDR_T *pAddr,                     /**< remote address */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_CB_T callback                      /**< channel callback */
)
{
    return goal_netChanOpen(ppChanHandle, pAddr, type, callback, GOAL_TRUE);
}


/****************************************************************************/
/** Open a network channel
 *
 * Open an network channel on the specified port.
 * The new channel is bound to pAddr->localIp and pAddr->localPort.
 * If a TCP client connection is opened the channel will also be connected to
 * pAddr->remoteIp and pAddr->remotePort.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
static GOAL_STATUS_T goal_netChanOpen(
    GOAL_NET_CHAN_T **ppChanHandle,             /**< pointer to channel handle */
    GOAL_NET_ADDR_T *pAddr,                     /**< remote address */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_CB_T callback,                     /**< channel callback */
    GOAL_BOOL_T flgReusable                     /**< channel reusability flag */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_CHAN_T *pChan = NULL;              /* channel */
    GOAL_BOOL_T flgDynPort = GOAL_FALSE;        /* dynamic port flag */
    uint32_t cnt;                               /* count */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_OPEN;
    }

    /* check channel handle reference */
    if (NULL == ppChanHandle) {
        return GOAL_ERR_PARAM;
    }

    /* check address pointer */
    if (NULL == pAddr) {
        return GOAL_ERR_PARAM;
    }

    /* check channel type */
    if (GOAL_NET_TCP == type) {
        return GOAL_ERR_PARAM;
    }

    /* reuse channel handl, if reusability flag is set and channel handle and its relevant attributes are not changed */
    if ((GOAL_TRUE == flgReusable) && (NULL != *ppChanHandle) && (GOAL_NET_INTERNAL != type) && (GOAL_NET_TCP_LISTENER != type)) {
        /* find valid handle */
        for (cnt = 0; GOAL_CONFIG_NET_CHAN_MAX > cnt; cnt++) {
            if (&goal_netChans[cnt] == *ppChanHandle) {
                /* do not reuse channel handle if the channel is active or generic data pointer is null */
                if ((GOAL_FALSE == goal_netChans[cnt].active) && (NULL != goal_netChans[cnt].pData)) {
                    pChan = &goal_netChans[cnt];
                    if ((pChan->type != type) || (pChan->callback != callback)) {
                        pChan = NULL;
                    } else {
                        if ((GOAL_NET_TCP_CLIENT == type) || (GOAL_NET_UDP_CLIENT == type)) {
                            if ((pChan->addr.remoteIp != pAddr->remoteIp) || (pChan->addr.remotePort != pAddr->remotePort)) {
                                pChan = NULL;
                            }
                        } else if (GOAL_NET_UDP_SERVER == type) {
                            if ((pChan->addr.localIp != pAddr->localIp) || (pChan->addr.localPort != pAddr->localPort)) {
                                pChan = NULL;
                            }
                        }
                    }
                }
                break;
            }
        }

        /* remove local port number from list of dynamic local ports in case of client type */
        if ((NULL != pChan) && ((GOAL_NET_TCP_CLIENT == type) || (GOAL_NET_UDP_CLIENT == type))) {
            for (cnt = 0; cnt <GOAL_CONFIG_NET_CHAN_MAX; cnt++) {
                if ((0 != dynPorts[cnt]) && (dynPorts[cnt] == pChan->addr.localPort)) {
                    dynPorts[cnt] = 0;
                    /* reset local port parameter if address parameter is identical to that in channel handle */
                    if (pAddr == &(pChan->addr)) {
                        pAddr->localPort = 0;
                    }
                    break;
                }
            }
        }
    }

    /* find a free network channel and reset generic data pointer if necessary */
    if (NULL == pChan) {
        pChan = *ppChanHandle;
        res = goal_netFindFreeChan(&pChan);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:162: */
            goal_lmLog(GOAL_ID_NET, 162, 131, 0, 0, GOAL_LOG_SEV_ERROR, "no free channel found");
            return res;
        }
        pChan->pData = NULL;
    }

    /* set dynamic port flag if client local port is 0 */
    if (((GOAL_NET_TCP_CLIENT == type) || (GOAL_NET_UDP_CLIENT == type)) && (0 == pAddr->localPort)) {
        flgDynPort = GOAL_TRUE;
    }

    /* open channel */
    res = goal_targetNetOpen(&pChan->pData, type, pAddr);
    if (GOAL_RES_ERR(res)) {

        /* free channel */
        pChan->used = GOAL_FALSE;
        pChan->active = GOAL_FALSE;

        /* GG_LOG ID:163: */
        goal_lmLog(GOAL_ID_NET, 163, 132, 0, 0, GOAL_LOG_SEV_ERROR, "opening channel failed");
        return res;
    }

    /* store channel data */
    if (GOAL_NET_TCP_LISTENER == type) {
        pChan->type = GOAL_NET_TCP;
    }
    else {
            pChan->type = type;
    }
    GOAL_MEMCPY(&pChan->addr, pAddr, sizeof(GOAL_NET_ADDR_T));
    pChan->callback = callback;
    pChan->used = GOAL_TRUE;

    /* add port number to list of dynamic ports if necessary */
    if (GOAL_TRUE == flgDynPort) {
        for (cnt = 0; GOAL_CONFIG_NET_CHAN_MAX > cnt; cnt++) {
            if (0 == dynPorts[cnt]) {
                dynPorts[cnt] = pAddr->localPort;
                break;
            }
        }
    }

    /* return channel handle */
    *ppChanHandle = pChan;

    return GOAL_OK;
}


/****************************************************************************/
/** GOAL tunnel opening
 *
 * This function provides a new channel handle to which is connected the
 * given channel handle in send direction. the given callback, sending and
 * closing function are registered. The sending and closing functions can
 * be NULL. If no sending function is registered, by default goal_netSend
 * sends the buffer to next channel directly.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netOpenTunnel(
    GOAL_NET_CHAN_T **ppChanHandle,             /**< pointer to channel handle structure */
    GOAL_NET_CHAN_T *pChanSendDir,              /**< handle in send direction to which ppChanHandle will be connected */
    GOAL_NET_CB_T callback,                     /**< receive callback */
    GOAL_NET_SEND_FUNC_T send,                  /**< sending function */
    GOAL_NET_CLOSE_FUNC_T close                 /**< closing function */
)
{
    uint32_t cnt;                               /* counter */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_OPEN;
    }

    /* check for valid callback */
    if (callback == NULL) {
        /* GG_LOG ID:164: */
        goal_lmLog(GOAL_ID_NET, 164, 133, 0, 0, GOAL_LOG_SEV_ERROR, "No callback is given");
        return GOAL_ERR_NET_OPEN;
    }

    /* check if another channel in application direction is requested */
    if (NULL != ppChanHandle) {

        /* find a free network channel */
        for (cnt = 0; GOAL_CONFIG_NET_CHAN_MAX > cnt; cnt++) {
            if (!goal_netChans[cnt].used) {
                break;
            }
        }
        if (GOAL_CONFIG_NET_CHAN_MAX <= cnt) {
            /* GG_LOG ID:165: */
            goal_lmLog(GOAL_ID_NET, 165, 131, 0, 0, GOAL_LOG_SEV_ERROR, "no free channel found");
            return GOAL_ERR_NET_OPEN;
        }

        /* open new channel and store type */
        goal_netChans[cnt].used = GOAL_TRUE;
        goal_netChans[cnt].type = GOAL_NET_INTERNAL;
        goal_netChans[cnt].pData = NULL;


        /* pass channel handle to caller */
        *ppChanHandle = &goal_netChans[cnt];

        /* connect both channels */
        pChanSendDir->pChanApplDir = *ppChanHandle;
        (*ppChanHandle)->pChanSendDir = pChanSendDir;

        /* store channel sending and closing function */
        (*ppChanHandle)->send = send;
        (*ppChanHandle)->close = close;
    }

    /* store callback in sending direction channel */
    pChanSendDir->callback = callback;

    return GOAL_OK;
}


/****************************************************************************/
/** GOAL net Option - manual closure after peer close
 *
 * This function sets a flag indicating if GOAL shall close a net channel
 * automatically if the it is closed by the peer or if it shall be closed
 * manually. This allows to delay the channel close process
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_netCloseManSet(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle structure */
    GOAL_BOOL_T flgCloseMan                     /**< manually close flag if */
)
{
    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERROR;
    }

    /* check NULL pointer */
    if (NULL == pChanHandle) {
        return GOAL_ERROR;
    }

    pChanHandle->flgCloseMan = flgCloseMan;

    return GOAL_OK;
}


/****************************************************************************/
/** Open a network channel from target
 *
 * Open a network channel and assign the given target channel.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netOpenTgt(
    void *pTargetHandle,                        /**< target handle */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_ADDR_T *pAddr                      /**< remote address */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_CHAN_T *pChan;                     /* channel */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_OPEN;
    }

    /* check if channel exists */
    if (pTargetHandle == NULL) {
        /* GG_LOG ID:166: */
        goal_lmLog(GOAL_ID_NET, 166, 134, 0, 0, GOAL_LOG_SEV_ERROR, "Chanel handle is not valid");
        return GOAL_ERR_NULL_POINTER;
    }

    /* get associated channel to handle */
    res = goal_netGetChanHandleTgt(pTargetHandle, &pChan);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:167: */
        goal_lmLog(GOAL_ID_NET, 167, 135, 0, 0, GOAL_LOG_SEV_ERROR, "Could not find channel for target handle");
        return GOAL_ERR_NOT_FOUND;
    }

    /* store channel remote data */
    pChan->addr.remoteIp = pAddr->remoteIp;
    pChan->addr.remotePort = pAddr->remotePort;
    pChan->type = type;

    /* activate or reactivate and inform all channel in application direction */
    pChan->used = GOAL_TRUE;
    pChan->active = GOAL_TRUE;
    if (pChan->callback) {
        pChan->callback(GOAL_NET_CB_NEW_SOCKET, pChan, NULL);
    }

    return res;
}


/****************************************************************************/
/** TCP client channel connected to server
 *
 * This function is called by the net driver if a TCP client socket connected to
 * its remote endpoint.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netConnectedTgt(
    GOAL_NET_CHAN_T *pChanHandle                /**< channel handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if channel is in use */
    if (GOAL_TRUE != pChanHandle->used) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChanHandle->active) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if this is a TCP client socket */
    if (GOAL_NET_TCP_CLIENT != pChanHandle->type) {
        return GOAL_ERR_NET_CLOSE;
    }

    if (pChanHandle->callback) {
        pChanHandle->callback(GOAL_NET_CB_CONNECTED, pChanHandle, NULL);
    }

    return res;
}


/****************************************************************************/
/** Find GOAL channel handle by target handle
 *
 * This function searches the GAOL sockets for the specified target handle. If
 * a GOAL socket was found its channel handle is stored in @em pChanHandle.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netGetChanHandleTgt(
    void *pTgtHandle,                           /**< target handle */
    GOAL_NET_CHAN_T **ppChanHandle              /**< GOAL channel handle */
)
{
    unsigned int cnt;                           /* counter */

    /* look up channels */
    for (cnt = 0; GOAL_CONFIG_NET_CHAN_MAX > cnt; cnt++) {
        /* skip unused elements */
        if (GOAL_FALSE == goal_netChans[cnt].used) {
            continue;
        }

        /* skip elements withour target data */
        if (NULL == goal_netChans[cnt].pData) {
            continue;
        }

        if (0 == GOAL_MEMCMP(pTgtHandle, goal_netChans[cnt].pData, goal_netTgtHandleSize)) {
            /* found it */
            *ppChanHandle = &goal_netChans[cnt];
            break;
        }
    }

    /* check if valid handle is found */
    if (GOAL_CONFIG_NET_CHAN_MAX <= cnt) {
        return GOAL_ERR_OUT_OF_RANGE;
    }
    else {
        return GOAL_OK;
    }
}


/****************************************************************************/
/** Close a network channel
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netClose(
    GOAL_NET_CHAN_T *pChanHandle                /**< channel handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_NET_CHAN_T *pChan = pChanHandle;       /* channel handle */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if channel is in use */
    if (GOAL_TRUE != pChan->used) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChan->active) {
        return GOAL_ERR_NET_CLOSE;
    }

    if (GOAL_NET_INTERNAL != pChan->type) {

        /* deactivate channel before closing it */
        goal_targetNetDeactivate(pChan->pData);

        /* close channel in target */
        res = goal_targetNetClose(pChan->pData, pChan->type);
    }

    /* use closing function if registered */
    if (NULL != pChan->close) {
        pChan->close(pChan);
    }

    /* deactivate GOAL channel */
    pChan->active = GOAL_FALSE;
    if ((GOAL_NET_TCP != pChan->type) && (GOAL_NET_TCP_CLIENT != pChan->type) && (GOAL_NET_INTERNAL != pChan->type)) {
        pChan->used = GOAL_FALSE;
    }

    return res;
}


/****************************************************************************/
/** Close a network channel from target
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netCloseTgt(
    void *pTargetHandle                         /**< target handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_NET_CHAN_T *pChanHandle;               /* net chan handle */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* get net channel handle */
    res = goal_netGetChanHandleTgt(pTargetHandle, &pChanHandle);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:168: */
        goal_lmLog(GOAL_ID_NET, 168, 136, 0, 0, GOAL_LOG_SEV_ERROR, "Could not find net Channel to given target channel");
        return res;
    }

    /* check if channel is in use */
    if (GOAL_TRUE != pChanHandle->used) {
        return GOAL_ERR_NET_CLOSE;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChanHandle->active) {
        return GOAL_ERR_NET_CLOSE;
    }

    if (GOAL_FALSE == pChanHandle->flgCloseMan) {
        /* close target channel from our side */
        res = goal_targetNetClose(pChanHandle->pData, pChanHandle->type);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:169: */
            goal_lmLog(GOAL_ID_NET, 169, 137, 0, 0, GOAL_LOG_SEV_ERROR, "Could not close target channel handle");
        }

        /* deactivate channel before closing it */
        res = goal_targetNetDeactivate(pChanHandle->pData);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:170: */
            goal_lmLog(GOAL_ID_NET, 170, 138, 0, 0, GOAL_LOG_SEV_ERROR, "Could not deactivate target channel handle.");
        }
    }
    else {
        /* closure is called manually */
        res = GOAL_OK_DELAYED;
    }

    /* inform application about channel close */
    goal_netCb(GOAL_NET_CB_CLOSING, pChanHandle, NULL);

    /* deactivate and close GOAL channel */
    if (GOAL_FALSE == pChanHandle->flgCloseMan) {
        pChanHandle->active = GOAL_FALSE;
    }

    return res;
}


/****************************************************************************/
/** Reopen all network channels
 *
 * Triggers the target channel reconnect functionality by keeping the GOAL
 * internal channel index/id stable.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netReopen(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t cnt;                               /* counter */
    uint32_t idxDynPort = 0;                    /* index for list of dynamic ports */
    GOAL_BOOL_T errFlag = GOAL_FALSE;           /* error flag */

    uint16_t portBak = 0;                       /* port backup */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_REOPEN;
    }

    /* iterate through all available non-internal channels */
    for (cnt = 0; cnt < GOAL_CONFIG_NET_CHAN_MAX; cnt++) {
        if ((GOAL_TRUE == goal_netChans[cnt].used) && (goal_netChans[cnt].type != GOAL_NET_INTERNAL)) {

            /* check local port if connection type is TCP client */
            if ((GOAL_NET_TCP_CLIENT == goal_netChans[cnt].type) || (GOAL_NET_UDP_CLIENT == goal_netChans[cnt].type)) {
                /* backup old local port number */
                portBak = goal_netChans[cnt].addr.localPort;
                if (0 != portBak) {
                    for (idxDynPort = 0; idxDynPort < GOAL_CONFIG_NET_CHAN_MAX; idxDynPort++) {
                        if ((0 != dynPorts[idxDynPort]) && (dynPorts[idxDynPort] == portBak)) {
                            /* reset port number */
                            goal_netChans[cnt].addr.localPort = 0;
                            dynPorts[idxDynPort] = 0;
                            break;
                        }
                    }
                }
            }

            /* reopen channel */
            res = goal_targetNetReopen(goal_netChans[cnt].pData, goal_netChans[cnt].type, &goal_netChans[cnt].addr);
            if (GOAL_RES_ERR(res)) {

                /* disable channel */
                goal_netChans[cnt].active = GOAL_FALSE;

                /* inform application about channel close */
                res = goal_netCb(GOAL_NET_CB_CLOSING, &goal_netChans[cnt], NULL);
                if (GOAL_RES_ERR(res)) {
                    /* GG_LOG ID:171: */
                    goal_lmLog(GOAL_ID_NET, 171, 139, 0, 0, GOAL_LOG_SEV_WARNING, "Could not close channel after failed reopen call");
                }

                /* invalidate target channel */
                goal_netChans[cnt].pData = NULL;

                /* release channel */
                goal_netChans[cnt].used = GOAL_FALSE;

                errFlag = GOAL_TRUE;
                /* GG_LOG ID:172: */
                goal_lmLog(GOAL_ID_NET, 172, 140, 4, 0, GOAL_LOG_SEV_ERROR, "failed to reopen channel: $1");
                goal_lmLogParamUINT32(cnt);
                goal_lmLogFinish();
            }
            else {
                /* reactivate reopened channel if it was active before */
                if ((GOAL_NET_TCP != goal_netChans[cnt].type) && (GOAL_TRUE == goal_netChans[cnt].active)) {
                    res = goal_netActivate(&goal_netChans[cnt]);
                    if (GOAL_RES_ERR(res)) {
                        errFlag = GOAL_TRUE;
                        /* GG_LOG ID:173: */
                        goal_lmLog(GOAL_ID_NET, 173, 141, 0, 0, GOAL_LOG_SEV_ERROR, "Could not reactivate reopened channel");
                    }
                }

                /* add port number to list of dynamic ports if necessary */
                if (((GOAL_NET_TCP_CLIENT == goal_netChans[cnt].type) || (GOAL_NET_UDP_CLIENT == goal_netChans[cnt].type)) && (portBak != goal_netChans[cnt].addr.localPort)) {
                    dynPorts[idxDynPort] = goal_netChans[cnt].addr.localPort;
                }
            }
        }
    }

    return (GOAL_TRUE == errFlag) ? GOAL_ERR_NET_REOPEN : GOAL_OK;
}


/****************************************************************************/
/** Activate channel
 *
 * Only activated channels can send and receive data.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netActivate(
    GOAL_NET_CHAN_T *pChanHandle                /**< channel handle */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_ACTIVATE;
    }

    /* activate all channels in sending direction */
    while (pChanHandle) {

        /* check if channel is reserved */
        if (GOAL_FALSE == pChanHandle->used) {
            /* GG_LOG ID:174: */
            goal_lmLog(GOAL_ID_NET, 174, 142, 0, 0, GOAL_LOG_SEV_ERROR, "Given channel isn't reserved.");
            return GOAL_ERR_NET_ACTIVATE;
        }

        if (GOAL_NET_INTERNAL == pChanHandle->type) {
            /* activate internal channels */
            pChanHandle->active = GOAL_TRUE;
        }
        else {
            /* enable target */
            res = goal_targetNetActivate(pChanHandle->pData);
            if (GOAL_RES_OK(res)) {
                pChanHandle->active = GOAL_TRUE;
            }
            break;
        }

        pChanHandle = pChanHandle->pChanSendDir;

    }

    /* check if no target channel is found */
    if (NULL == pChanHandle) {
        /* GG_LOG ID:175: */
        goal_lmLog(GOAL_ID_NET, 175, 143, 0, 0, GOAL_LOG_SEV_ERROR, "Invalid Channel given, no target channel found");
        return GOAL_ERR_PARAM;
    }

    return res;
}


/****************************************************************************/
/** Get the remote address for a open channel
 *
 * This function provides the remote address of an open channel.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netGetRemoteAddr(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle */
    GOAL_NET_ADDR_T *pAddr                      /**< pointer to store address */
)
{
    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_ADDRESS;
    }

    /* find last channel in sending direction */
    while (NULL != pChanHandle) {
        if (GOAL_NET_INTERNAL == pChanHandle->type) {
            pChanHandle = pChanHandle->pChanSendDir;
        }
        else {
            break;
        }
    }
    if (NULL == pChanHandle) {
        /* GG_LOG ID:176: */
        goal_lmLog(GOAL_ID_NET, 176, 144, 0, 0, GOAL_LOG_SEV_ERROR, "Could not find target handle to given channel");
        return GOAL_ERR_NET_ADDRESS;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChanHandle->active) {
        /* GG_LOG ID:177: */
        goal_lmLog(GOAL_ID_NET, 177, 145, 0, 0, GOAL_LOG_SEV_ERROR, "given channel isn't ready");
        return GOAL_ERR_NET_ADDRESS;
    }

    /* return remote address */
    GOAL_MEMCPY(pAddr, &pChanHandle->addr, sizeof(GOAL_NET_ADDR_T));

    return GOAL_OK;
}


/****************************************************************************/
/** Send Data over Network Channel
 *
 * Send data in pBuf with bufLen size over the network channel.
 *
 * If destination again is a GOAL channel, its sending function is used or
 * - if no one is defined - its directly forwarded to next channel.
 *
 * Otherwise pBuf is forwarded to target.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netSend(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle */
    GOAL_BUFFER_T *pBuf                         /**< buffer with data to send */
)
{
    GOAL_STATUS_T res;                          /* result */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_SEND;
    }

    /* check if channel is valid */
    if (NULL == pChanHandle) {
        /* GG_LOG ID:178: */
        goal_lmLog(GOAL_ID_NET, 178, 146, 0, 0, GOAL_LOG_SEV_ERROR, "Could not send. Channel is disabled");
        return GOAL_ERR_NET_SEND_CHAN_DISABLED;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChanHandle->active) {
        /* GG_LOG ID:179: */
        goal_lmLog(GOAL_ID_NET, 179, 146, 0, 0, GOAL_LOG_SEV_ERROR, "Could not send. Channel is disabled");
        return GOAL_ERR_NET_SEND_CHAN_DISABLED;
    }

    /* find next sending function */
    while ((NULL == pChanHandle->send) && (GOAL_NET_INTERNAL == pChanHandle->type)) {
        pChanHandle = pChanHandle->pChanSendDir;

        /* check if channel is valid */
        if (NULL == pChanHandle) {
            /* GG_LOG ID:180: */
            goal_lmLog(GOAL_ID_NET, 180, 146, 0, 0, GOAL_LOG_SEV_ERROR, "Could not send. Channel is disabled");
            return GOAL_ERR_NET_SEND_CHAN_DISABLED;
        }

        /* check if channel is active */
        if (GOAL_TRUE != pChanHandle->active) {
            /* GG_LOG ID:181: */
            goal_lmLog(GOAL_ID_NET, 181, 146, 0, 0, GOAL_LOG_SEV_ERROR, "Could not send. Channel is disabled");
            return GOAL_ERR_NET_SEND_CHAN_DISABLED;
        }
    }

    /* send buffer */
    if (NULL == pChanHandle->send) {
        res = goal_targetNetSend(pChanHandle->pData, pChanHandle->type,
                                &pChanHandle->addr, pBuf);
    }
    else if (GOAL_NET_INTERNAL == pChanHandle->type) {
        res = pChanHandle->send(pChanHandle->pChanSendDir, pBuf);
    }
    else {
        /* one of the two equalities before must be true */
        /* GG_LOG ID:182: */
        goal_lmLog(GOAL_ID_NET, 182, 147, 0, 0, GOAL_LOG_SEV_ERROR, "Internal error in sending function");
        res = GOAL_ERROR;
    }

    return  res;
}


/****************************************************************************/
/** Shutdown network handling
 *
 * This function closes all open channels.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
static GOAL_STATUS_T goal_netShutdown(
    void
)
{
    unsigned int cnt;                           /* counter */

    /* iterate through all open channels */
    for (cnt = 0; cnt < GOAL_CONFIG_NET_CHAN_MAX; cnt++) {
        if (GOAL_TRUE == goal_netChans[cnt].active) {

            /* disable channel */
            goal_netChans[cnt].active = GOAL_FALSE;

            /* inform channel callback that the channel was closed */
            if (NULL != goal_netChans[cnt].callback) {
                goal_netChans[cnt].callback(GOAL_NET_CB_CLOSING, &goal_netChans[cnt], NULL);
            }

            /* close channel */
            if (GOAL_NET_INTERNAL != goal_netChans[cnt].type) {
                goal_targetNetClose(goal_netChans[cnt].pData, goal_netChans[cnt].type);
            }

            /* invalidate target channel */
            GOAL_MEMSET(goal_netChans[cnt].pData, 0, sizeof(goal_netTgtHandleSize));

            /* release channel */
            goal_netChans[cnt].used = GOAL_FALSE;
        }
    }

    goal_netInitFlag = GOAL_FALSE;
    /* GG_LOG ID:183: */
    goal_lmLog(GOAL_ID_NET, 183, 148, 0, 0, GOAL_LOG_SEV_INFO, "network shutdown");

    return GOAL_OK;
}


/****************************************************************************/
/** Change the property of a network socket
 *
 * This function will change the specified property of a net socket by calling
 * a target specific function.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netSetOption(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle */
    GOAL_NET_OPTION_T option,                   /**< GOAL option ID */
    void *pValue                                /**< option value */
)
{
    GOAL_STATUS_T res;                          /* result */

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_OPTION;
    }

    /* check if channel is active */
    if (GOAL_TRUE != pChanHandle->used) {
        /* GG_LOG ID:184: */
        goal_lmLog(GOAL_ID_NET, 184, 149, 0, 0, GOAL_LOG_SEV_ERROR, "setting option on inactive channel isn't possible");
        return GOAL_ERR_NET_SEND;
    }

    /* find target channel */
    while (GOAL_NET_INTERNAL == pChanHandle->type) {
        /* get next channel */
        pChanHandle = pChanHandle->pChanSendDir;

        /* check if handle is valid */
        if (NULL == pChanHandle) {
            /* GG_LOG ID:185: */
            goal_lmLog(GOAL_ID_NET, 185, 143, 0, 0, GOAL_LOG_SEV_ERROR, "Invalid Channel given, no target channel found");
            return GOAL_ERR_PARAM;
        }

        /* check if channel is active */
        if (GOAL_TRUE != pChanHandle->active) {
            /* GG_LOG ID:186: */
            goal_lmLog(GOAL_ID_NET, 186, 149, 0, 0, GOAL_LOG_SEV_ERROR, "setting option on inactive channel isn't possible");
            return GOAL_ERR_NET_SEND;
        }
    }

    /* set option in target */
    res = goal_targetNetOptSet(pChanHandle->pData, pChanHandle->type, option, pValue);
    return res;
}


/****************************************************************************/
/** Set network channel callback function
 *
 * This function sets the callback for a network channel.
 * It only works for channels that were created by TCP Listener channels. Other
 * channels get their callback from @em goal_netOpen().
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netSetCallback(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle */
    GOAL_NET_CB_T callback                      /**< receive callback */
)
{
    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        return GOAL_ERR_NET_CALLBACK;
    }

    /* check if channel is reserved */
    if (GOAL_TRUE == pChanHandle->used) {
        /* GG_LOG ID:187: */
        goal_lmLog(GOAL_ID_NET, 187, 150, 0, 0, GOAL_LOG_SEV_ERROR, "setting callback on unallocated channel isn't possible");
        return GOAL_ERR_NET_CALLBACK;
    }

    /* check if callback is already set */
    if (pChanHandle->callback) {
        /* GG_LOG ID:188: */
        goal_lmLog(GOAL_ID_NET, 188, 151, 0, 0, GOAL_LOG_SEV_ERROR, "callback function already set on channel");
        return GOAL_ERR_NET_CALLBACK;
    }

    /* set callback */
    pChanHandle->callback = callback;

    return GOAL_OK;
}


/****************************************************************************/
/** Network data receive handler
 *
 * This function hands over the received data to the registered callback
 * function.
 */
void goal_netRecv(
    void *pTgtHandle,                           /**< target handle */
    GOAL_NET_ADDR_T *pAddr,                     /**< remote addresse */
    GOAL_BUFFER_T *pBuf                         /**< buffer with rx data */
)
{
    uint32_t cnt;                               /* counter */

    UNUSEDARG(pAddr);

    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        /* GG_LOG ID:189: */
        goal_lmLog(GOAL_ID_NET, 189, 152, 0, 0, GOAL_LOG_SEV_ERROR, "not initialized");
        return;
    }

    /* find associated channel for given target channel */
    for (cnt = 0; cnt < GOAL_CONFIG_NET_CHAN_MAX; cnt++) {
        /* skip unused elements */
        if (GOAL_FALSE == goal_netChans[cnt].used) {
            continue;
        }
        /* skip elements without target data */
        if (NULL == goal_netChans[cnt].pData) {
            continue;
        }
        if (!GOAL_MEMCMP(pTgtHandle, goal_netChans[cnt].pData, goal_netTgtHandleSize)) {
            break;
        }
    }

    if (GOAL_CONFIG_NET_CHAN_MAX <= cnt) {
        return;
    }

    /* check if channel is active */
    if (GOAL_TRUE != goal_netChans[cnt].active) {
        /* check if an another associated channel */
        for (cnt = cnt + 1; cnt < GOAL_CONFIG_NET_CHAN_MAX; cnt++) {
            /* skip unused elements */
            if (GOAL_FALSE == goal_netChans[cnt].used) {
                continue;
            }
            /* skip inactive elements */
            if (GOAL_FALSE == goal_netChans[cnt].active) {
                continue;
            }
            /* skip elements without target data */
            if (NULL == goal_netChans[cnt].pData) {
                continue;
            }
            if (!GOAL_MEMCMP(pTgtHandle, goal_netChans[cnt].pData, goal_netTgtHandleSize)) {
                break;
            }
        }
        if (GOAL_CONFIG_NET_CHAN_MAX == cnt) {
            /* GG_LOG ID:190: */
            goal_lmLog(GOAL_ID_NET, 190, 153, 0, 0, GOAL_LOG_SEV_ERROR, "channel isn't ready yet");
            return;
        }
    }

    if (NULL != pAddr) {
        /* store remote data */
        goal_netChans[cnt].addr.remoteIp = pAddr->remoteIp;
        goal_netChans[cnt].addr.remotePort = pAddr->remotePort;
    }

    /* check if callback is already set */
    if (NULL == goal_netChans[cnt].callback) {
        /* GG_LOG ID:191: */
        goal_lmLog(GOAL_ID_NET, 191, 154, 0, 0, GOAL_LOG_SEV_ERROR, "no callback function registered");
        return;
    }

    /* inform application */
    goal_netChans[cnt].callback(GOAL_NET_CB_NEW_DATA, &goal_netChans[cnt], pBuf);
}


/****************************************************************************/
/** Network data receive handler for opend channel tunnel
 *
 * This function hands over the received data to the registered callback
 * function of the next channel in application direction.
 */
void goal_netRecvTunnel(
    GOAL_NET_CHAN_T *pChanHandle,               /**< channel handle */
    GOAL_BUFFER_T *pBuf                         /**< buffer with rx data */
)
{
    /* check init flag */
    if (GOAL_TRUE != goal_netInitFlag) {
        /* GG_LOG ID:192: */
        goal_lmLog(GOAL_ID_NET, 192, 152, 0, 0, GOAL_LOG_SEV_ERROR, "not initialized");
        return;
    }

    /* check for valid channel */
    if (NULL == pChanHandle) {
        /* GG_LOG ID:193: */
        goal_lmLog(GOAL_ID_NET, 193, 155, 0, 0, GOAL_LOG_SEV_INFO, "recieve function called wihour channel.");
        return;
    }

    /* check if callback is already set */
    if (NULL == pChanHandle->callback) {
        /* GG_LOG ID:194: */
        goal_lmLog(GOAL_ID_NET, 194, 154, 0, 0, GOAL_LOG_SEV_ERROR, "no callback function registered");
        return;
    }

    pChanHandle->callback(GOAL_NET_CB_NEW_DATA, pChanHandle, pBuf);
}


/****************************************************************************/
/** Network cyclic loop
 *
 * Check if new data is available and if yes, process each data channel.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
void goal_netLoop(
    void
)
{
    if (GOAL_TRUE == goal_targetNetAvail()) {
        goal_targetNetPoll();
    }

#if GOAL_CONFIG_DHCP == 1
    goal_netDhcpLoop();
#endif
}


/****************************************************************************/
/** Convert an ASCII string (aaa.bbb.ccc.ddd) to an IP address
 *
 * The generated address is in host byte order.
 *
 * @retval GOAL_OK success
 * @retval other fail
 */
GOAL_STATUS_T goal_netAsciiToIp(
    const char *pStr,                           /**< ASCII string */
    uint32_t strLen,                            /**< string buffer length */
    uint32_t *pNetAddr                          /**< net address */
)
{
    uint32_t tmp = 0;                           /* temporary value */
    uint32_t dots = 0;                          /* number of dots read */
    uint32_t charCnt = 0;                       /* number of read chars */

    do {
        switch (*pStr) {
            case '0':
            case '1':
            case '2':
            case '3':
            case '4':
            case '5':
            case '6':
            case '7':
            case '8':
            case '9':
                /* char2int
                 * assume decimal power of one for the current char
                 * if last char was also a number, previous tmp has a higher
                 * decimal power
                 */
                tmp = tmp * 10 + (uint32_t) (*pStr - '0');
                break;

            case '.':
                dots++;
                if (dots > 3) {
                    return GOAL_ERROR;
                }
                /* no break, fall trough, last byte has no dot */
                GOAL_TARGET_FALLTHROUGH;

            case '\0':
                if (tmp > 255) {
                    return GOAL_ERROR;
                }
                /* add converted byte to address, assume segment size of 8 bit */
                *pNetAddr = (*pNetAddr << 8) | tmp;
                tmp = 0;
                break;

            default:
                if (charCnt == strLen) {
                    *pNetAddr = (*pNetAddr << 8) | tmp;
                }
                else {
                    return GOAL_ERROR;
                }
                break;
        }
    } while ((*pStr++ != '\0') && (charCnt++ < strLen));

    /* get address format by number of dots
     * - a.b.c.d (3 dots): last segment is 8 bit
     * - a.b.c (2 dots): last segment is 16 bit
     * - a.b (1 dots): last segment is 24 bit
     * - a (0 dots): last segment is 32bit
     * --> size of last segment might need correction
     */
    *pNetAddr <<= 8 * (3 - dots);

    return GOAL_OK;
}


/****************************************************************************/
/** Convert a network address to an ASCII string (x.x.x.x)
 *
 * @returns string length
 */
int goal_netIpToAscii(
    const uint32_t netAddr,                     /**< net address */
    char *pBuf,                                 /**< ASCII buffer */
    uint32_t bufLen                             /**< buffer length */
)
{
    return GOAL_SNPRINTF(pBuf, bufLen, "%"FMT_u32".%"FMT_u32".%"FMT_u32".%"FMT_u32,
                         (netAddr >> 24) & 0xff, (netAddr >> 16) & 0xff,
                         (netAddr >> 8) & 0xff, netAddr & 0xff);
}


/****************************************************************************/
/** Generic network command caller
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmd(
    GOAL_NET_CMD_T cmd,                         /**< command */
    GOAL_BOOL_T wrFlag,                         /**< write flag */
    void *pArg                                  /**< argument */
)
{
#if GOAL_CONFIG_DHCP == 1
    switch (cmd) {
        case GOAL_NET_CMD_DHCP_START:
            return goal_netDhcpStart();

        case GOAL_NET_CMD_DHCP_STOP:
            return goal_netDhcpStop();

        case GOAL_NET_CMD_DHCP_RELEASE:
            return goal_netDhcpRelease((GOAL_BOOL_T *) pArg);

        case GOAL_NET_CMD_DHCP_STATE:
            return goal_netDhcpGetState((uint32_t *) pArg);

        case GOAL_NET_CMD_DHCP_ADDR:
            return goal_netDhcpGetAddr((GOAL_NET_DHCP_T *) pArg);

        default:
            /* pass command to net driver */
            break;
    }
#endif /* GOAL_CONFIG_DHCP == 1 */

    /* call network command handler */
    return goal_targetNetCmd(cmd, wrFlag, pArg);
}


/****************************************************************************/
/** Set IP Address
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netIpSet(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary IP config flag */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    res = goal_netIpValidCheck(addrIp, addrMask, addrGw, flgTemp);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* GG_LOG ID:34: */
    goal_lmLog(GOAL_ID_NET, 34, 20, 4, 0, GOAL_LOG_SEV_INFO, "ip address: $1");
    goal_lmLogParamIPV4(addrIp);
    goal_lmLogFinish();
    /* GG_LOG ID:35: */
    goal_lmLog(GOAL_ID_NET, 35, 21, 4, 0, GOAL_LOG_SEV_INFO, "netmask: $1");
    goal_lmLogParamIPV4(addrMask);
    goal_lmLogFinish();
    /* GG_LOG ID:36: */
    goal_lmLog(GOAL_ID_NET, 36, 22, 4, 0, GOAL_LOG_SEV_INFO, "gateway: $1");
    goal_lmLogParamIPV4(addrGw);
    goal_lmLogFinish();
    /* GG_LOG ID:37: */
    goal_lmLog(GOAL_ID_NET, 37, 23, 1, 0, GOAL_LOG_SEV_INFO, "IP valid flag: $1");
    goal_lmLogParamBOOLEAN((GOAL_BOOL_T) !flgTemp);
    goal_lmLogFinish();

    /* update IP address */
    res = goal_targetNetIpSet(addrIp, addrMask, addrGw, flgTemp);
    if (GOAL_RES_OK(res)) {
        /* GG_LOG ID:195: */
        goal_lmLog(GOAL_ID_NET, 195, 156, 0, 0, GOAL_LOG_SEV_INFO, "successfully updated IP configuration");
    } else {
        /* GG_LOG ID:196: */
        goal_lmLog(GOAL_ID_NET, 196, 157, 0, 0, GOAL_LOG_SEV_ERROR, "failed to set IP configuration");
    }

    /* sync config with CM */
    res = goal_netCmIpSet(addrIp, addrMask, addrGw, (GOAL_FALSE == flgTemp) ? GOAL_TRUE : GOAL_FALSE);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:197: */
        goal_lmLog(GOAL_ID_NET, 197, 128, 0, 0, GOAL_LOG_SEV_ERROR, "failed to update IP configuration");
        return res;
    }

    /* inform callback listeners */
    GOAL_MAIN_CB_FOREACH(GOAL_ID_NET, GOAL_NET_CB_ID_IP_SET, GOAL_NET_CB_IP_SET_T, addrIp, addrMask, addrGw, flgTemp)

    return res;
}


/****************************************************************************/
/** Get IP Address
 *
 * Unneeded pointers can be set to NULL.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_netIpGet(
    uint32_t *pAddrIp,                          /**< IP address */
    uint32_t *pAddrMask,                        /**< subnet mask */
    uint32_t *pAddrGw,                          /**< gateway */
    GOAL_BOOL_T *pFlgTemp                       /**< temporary IP config flag */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_BOOL_T flgValid = GOAL_FALSE;          /* IP valid flag */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    /* check NULL pointers */
    if (pAddrIp) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_IP, &pCmVar);
        if (GOAL_RES_ERR(res)) {
            return res;
        }
        *pAddrIp = GOAL_CM_VAR_UINT32(pCmVar);
    }

    if (pAddrMask) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_NETMASK, &pCmVar);
        if (GOAL_RES_ERR(res)) {
            return res;
        }
        *pAddrMask = GOAL_CM_VAR_UINT32(pCmVar);
    }

    if (pAddrGw) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_GW, &pCmVar);
        if (GOAL_RES_ERR(res)) {
            return res;
        }
        *pAddrGw = GOAL_CM_VAR_UINT32(pCmVar);
    }

    if (pFlgTemp) {
        res = goal_netFlgValidGet(&flgValid);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:198: */
            goal_lmLog(GOAL_ID_NET, 198, 158, 0, 0, GOAL_LOG_SEV_ERROR, "failed to retrieve valid flag");
            return res;
        }
        *pFlgTemp = (GOAL_FALSE == flgValid) ? GOAL_TRUE : GOAL_FALSE;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Check IP Address for Validity
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_netIpValidCheck(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary IP config flag */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(flgTemp);

    /* verify IP settings */
    GOAL_MAIN_CB_FOREACH_RES(GOAL_ID_NET, GOAL_NET_CB_ID_IP_SET_VERIFY, GOAL_NET_CB_IP_SET_VERIFY_T, addrIp, addrMask, addrGw);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("verification of IP settings failed");
        return res;
    }

    return res;
}


/****************************************************************************/
/** Update DHCP Configuration in CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmDhcpSet(
    GOAL_BOOL_T enableDhcp                      /**< flag to enable DHCP */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_ENABLED, &pCmVar);
    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT8(pCmVar, (uint8_t) enableDhcp);
    }

    return res;
}


/****************************************************************************/
/** Get DHCP Configuration in CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmDhcpGet(
    GOAL_BOOL_T *pEnableDhcp                    /**< DHCP enable status */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    if (NULL == pEnableDhcp) {
        res = GOAL_ERR_NULL_POINTER;
    }

    if (GOAL_RES_OK(res)) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_ENABLED, &pCmVar);
    }

    if (GOAL_RES_OK(res)) {
        *pEnableDhcp = (GOAL_CM_VAR_UINT8(pCmVar)) ? GOAL_TRUE : GOAL_FALSE;
    }

    return res;
}
/****************************************************************************/
/** Update IP Configuration in CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmIpSet(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgValid                        /**< valid flag */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_IP, &pCmVar);
    if (GOAL_RES_ERR(res)) {
        return res;
    }
    GOAL_CM_SETVAR_UINT32(pCmVar, addrIp);

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_NETMASK, &pCmVar);
    if (GOAL_RES_ERR(res)) {
        return res;
    }
    GOAL_CM_SETVAR_UINT32(pCmVar, addrMask);

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_GW, &pCmVar);
    if (GOAL_RES_ERR(res)) {
        return res;
    }
    GOAL_CM_SETVAR_UINT32(pCmVar, addrGw);

    return goal_netFlgValidSet(flgValid);
}


/****************************************************************************/
/** Apply IP Configuration from applications
 *
 * This function applies the IP settings from CM and can be called from
 * applications.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmIpCommit(
    void
)
{
    return goal_netCmIpCb(0, 0, NULL);
}


/****************************************************************************/
/** Apply IP Configuration from CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmIpCb(
    uint32_t modId,                             /**< module ID */
    uint32_t varId,                             /**< variable Id */
    GOAL_CM_VAR_T *pVar                         /**< variable pointer */
)
{
    UNUSEDARG(modId);
    UNUSEDARG(varId);
    UNUSEDARG(pVar);

    uint32_t addrIp = 0;                        /* IP address */
    uint32_t addrMask = 0;                      /* subnet mask */
    uint32_t addrGw = 0;                        /* gateway */
    uint8_t flgValid = 0;                       /* valid flag */
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar;                      /* CM variable */
    uint8_t dhcpEnable = 0;                     /* DHCP enable flag */
    GOAL_BOOL_T dhcpReleaseTx;                  /* transmit DHCP release message */

    /* clear trigger */
    if (NULL != pVar) {
        GOAL_CM_SETVAR_UINT8(pVar, 0);
    }

    /* DHCP is priorized */
    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_ENABLED, &pCmVar);
    if (GOAL_RES_OK(res)) {
        dhcpEnable = GOAL_CM_VAR_UINT8(pCmVar);
        if (0 != dhcpEnable) {

            dhcpReleaseTx = GOAL_FALSE;
            goal_netCmd(GOAL_NET_CMD_DHCP_RELEASE, GOAL_FALSE, &dhcpReleaseTx);
            goal_netCmd(GOAL_NET_CMD_DHCP_START, GOAL_FALSE, NULL);
        }
    }

    /* DHCP not configured */
    if (GOAL_RES_OK(res) && 0 == dhcpEnable) {

#if GOAL_CONFIG_DHCP == 1
        goal_netCmd(GOAL_NET_CMD_DHCP_STOP, GOAL_FALSE, NULL);
#endif

        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_IP, &pCmVar);
        if (GOAL_RES_OK(res)) {
            addrIp = GOAL_CM_VAR_UINT32(pCmVar);
        }

        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_NETMASK, &pCmVar);
        if (GOAL_RES_OK(res)) {
            addrMask = GOAL_CM_VAR_UINT32(pCmVar);
        }

        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_GW, &pCmVar);
        if (GOAL_RES_OK(res)) {
            addrGw = GOAL_CM_VAR_UINT32(pCmVar);
        }

        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_VALID, &pCmVar);
        if (GOAL_RES_OK(res)) {
            flgValid = GOAL_CM_VAR_UINT8(pCmVar);
        }

        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_COMMIT, &pCmVar);
        if (GOAL_RES_OK(res)) {
            GOAL_CM_SETVAR_UINT8(pCmVar, 0);
        }

        res = goal_netIpSet(addrIp, addrMask, addrGw, (GOAL_FALSE == flgValid) ? GOAL_TRUE : GOAL_FALSE);
    }

    return res;
}


/****************************************************************************/
/** Check if IP configuration is valid
 *
 * @retval GOAL_OK successful, flag is set
 * @retval other failed, flag isn't set
 */
GOAL_STATUS_T goal_netFlgValidGet(
    GOAL_BOOL_T *pFlgValid                      /**< valid flag ptr */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pVarCm = NULL;               /* CM variable */

    if (!pFlgValid) {
        return GOAL_ERR_NULL_POINTER;
    }

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_VALID, &pVarCm);
    if (GOAL_RES_OK(res)) {
        *pFlgValid = (GOAL_CM_VAR_UINT8(pVarCm)) ? GOAL_TRUE : GOAL_FALSE;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Set IP configuration state
 *
 * @retval GOAL_OK successful, flag is set
 * @retval other failed, flag isn't set
 */
GOAL_STATUS_T goal_netFlgValidSet(
    GOAL_BOOL_T flgValid                        /**< valid flag */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pVarCm = NULL;               /* CM variable */

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_VALID, &pVarCm);
    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT8(pVarCm, (uint8_t) flgValid);
    }

    return res;
}


/****************************************************************************/
/** Update DNS Configuration in CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmDnsSet(
    uint32_t dns1,                              /**< nameserver 1 */
    uint32_t dns2                               /**< nameserver 2 */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DNS0, &pCmVar);
    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT32(pCmVar, dns1);
    }

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DNS1, &pCmVar);
    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT32(pCmVar, dns2);
    }

    return res;
}


/****************************************************************************/
/** Get DNS Configuration from CM
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netCmDnsGet(
    uint32_t *pDns1,                            /**< nameserver 1 */
    uint32_t *pDns2                             /**< nameserver 2 */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable */

    if (NULL == pDns1 || NULL == pDns2) {
        res = GOAL_ERR_NULL_POINTER;
    }
    if (GOAL_RES_OK(res)) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DNS0, &pCmVar);
    }

    if (GOAL_RES_OK(res)) {
        *pDns1 = GOAL_CM_VAR_UINT32(pCmVar);
    }

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DNS1, &pCmVar);
    if (GOAL_RES_OK(res)) {
        *pDns2 = GOAL_CM_VAR_UINT32(pCmVar);
    }

    return res;
}


/****************************************************************************/
/** Get Channel List
 *
 * Using this API is not recommended.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_netChanDataGet(
    GOAL_NET_CHAN_T **ppChanData,               /**< [out] channel data */
    unsigned int *pCntChans                     /**< channel count */
)
{
    *ppChanData = goal_netChans;
    *pCntChans = GOAL_CONFIG_NET_CHAN_MAX;

    return GOAL_OK;
}


/****************************************************************************/
/** Default IP address check function
 *
 * This function is called each time a IP address change (static ip) is requested.
 * It checks for validity of the IP address.
 *
 * Sources: - EtherNet/IP Stack
 *          - RFC 6890
 *
 * @returns GOAL_STATUS_T result
 */
static GOAL_STATUS_T ipValidCheck(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary config flag */
)
{
    UNUSEDARG(flgTemp);

    /* allow special case (0.0.0.0/0.0.0.0) */
    if ((addrIp == 0) && (addrGw == 0)) {
        return GOAL_OK;
    }

    /* check for reserved net (0.0.0.0/8) */
    if (((addrIp & 0xff000000) == 0) ||
        ((addrIp & 0xffffff00) == 0)) {
        goal_logErr("reserved net 0.0.0.0/8 not allowed");
        return GOAL_ERR_IP_SET;
    }

    /* check for loopback (127.0.0.0/8) */
    if (((addrIp & 0xffffff00) == 0x7F000000) ||
        ((addrGw & 0xffffff00) == 0x7F000000)) {
        goal_logErr("local ip address 127.0.0.0/8 not allowed");
        return GOAL_ERR_IP_SET;
    }

    /* check for test net (192.0.2.0/24) */
    if (((addrIp & 0xffffff00) == 0xC0000200) ||
        ((addrGw & 0xffffff00) == 0xC0000200)) {
        goal_logErr("address from test net (rfc 5737) not allowed");
        return GOAL_ERR_IP_SET;
    }

    /* hostID == 0 || hostID == ~0 is invalid */
    if (((addrIp & ~addrMask) == 0) ||
        ((addrIp & ~addrMask) == ~addrMask)) {
        goal_logErr("host id is invalid (address & netmask combination)");
        return GOAL_ERR_IP_SET;
    }

    /* GW must be in same subnet as device */
    if ((addrGw != 0) &&
        ((addrIp & addrMask) != (addrGw & addrMask))) {
        goal_logErr("gateway is outside of network");
        return GOAL_ERR_IP_SET;
    }

    /* check net class, D is invalid */
    if (((addrIp & 0xff000000) >= 0xE0000000) ||
        ((addrGw & 0xff000000) >= 0xE0000000)) {
        goal_logErr("class D net not allowed as IP address");
        return GOAL_ERR_IP_SET;
    }

    /* check if address or gateway is a broadcast address */
    if (((addrIp & 0x000000ff) == 0) || ((addrIp & 0x000000ff) == 0xff) ||
        (addrGw != 0 && (((addrGw & 0x000000ff) == 0) || ((addrGw & 0x000000ff) == 0xff)))) {
        goal_logErr("address or gateway is a broadcast address");
        return GOAL_ERR_IP_SET;
    }

    /* check for valid netmask */
    if (0 != (addrMask & (~addrMask >> 1))) {
        goal_logErr("netmask contains invalid bits set");
        return GOAL_ERR_IP_SET;
    }

    return GOAL_OK;
}


#endif /* GOAL_CONFIG_TCPIP_STACK */
