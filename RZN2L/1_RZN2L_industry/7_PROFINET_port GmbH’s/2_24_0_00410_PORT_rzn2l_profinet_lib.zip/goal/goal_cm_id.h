#undef GOAL_CM_VAR
#define GOAL_CM_VAR(varId, type, maxSize, validate, change) varId
