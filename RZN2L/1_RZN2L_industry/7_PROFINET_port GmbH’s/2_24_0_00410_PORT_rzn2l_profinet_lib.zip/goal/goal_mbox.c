/** @file
 *
 * @brief Mailbox Management
 *
 * This module implements MAilboxes to exchange arbitrary messages between
 * tasks. All callers of these functions must know the size of a message for
 * each mailbox.
 *
 * @copyright
 * Copyright 2010-2021.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_MBOX
#include <goal_includes.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define GOAL_MBOX_FLAG_EMPTY             (1<<0) /**< mailbox is empty */
#define GOAL_MBOX_FLAG_FULL              (1<<1) /**< mailbox is full */


/****************************************************************************/
/** Create a mailbox
 *
 * This function allocates and initializes a mailbox. Its data area is allocated
 * to store @em numMsg messages. Each messages is expected to be @em sizeMsg
 * bytes.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_mboxCreate(
    GOAL_MBOX_T **ppMbox,                       /**< [out] Mailbox pointer reference */
    uint16_t numMsg,                            /**< number of messages */
    uint16_t sizeMsg                            /**< size of each message */
)
{
    GOAL_STATUS_T res;                          /* result */

    if ((NULL == ppMbox) || (0 == numMsg) || (0 == sizeMsg)) {
        return GOAL_ERR_PARAM;
    }

    /* allocate mbox */
    res = goal_memCalloc(ppMbox, sizeof(GOAL_MBOX_T));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("could not create mailbox");
    }

    if (GOAL_RES_OK(res)) {
        /* allocate data area */
        res = goal_memCalloc(&((*ppMbox)->pMsgData), numMsg * sizeMsg);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("could not create mailbox data area");
        }
    }

    if (GOAL_RES_OK(res)) {
        /* create mutex */
        res = goal_lockCreate(GOAL_LOCK_BINARY, &((*ppMbox)->pMutex), 0, 1, GOAL_ID);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("failed to create mailbox lock");
        }
    }

    if (GOAL_RES_OK(res)) {
        /* initialize members that are not zero */
        (*ppMbox)->flags = GOAL_MBOX_FLAG_EMPTY;
        (*ppMbox)->numMsg = numMsg;
        (*ppMbox)->sizeMsg = sizeMsg;
    }

    return res;
}


/****************************************************************************/
/** Destroy a mailbox
 *
 * This function frees the mailbox and its data. After calling this function
 * @em ppMbox is set to NULL.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_mboxDestroy(
    GOAL_MBOX_T **ppMbox                        /**< [in out] Mailbox pointer reference */
)
{
    GOAL_STATUS_T res;                          /* result */

    if (NULL == ppMbox) {
        return GOAL_ERR_PARAM;
    }

    res = goal_memFree(&((*ppMbox)->pMsgData));

    if (GOAL_RES_OK(res)) {
        res = goal_memFree(ppMbox);
    }

    if (GOAL_RES_OK(res)) {
        *ppMbox = NULL;
    }

    return res;
}


/****************************************************************************/
/** Return first new message from a given mailbox
 *
 * This function is thread-safe. The message size is the value specified with
 * @em goal_mboxCreate.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_mboxMsgGet(
    GOAL_MBOX_T *pMbox,                         /**< mailbox */
    uint8_t *pMsg                               /**< [out] message buffer */
)
{
    GOAL_STATUS_T retVal = GOAL_OK;             /* return value */

    if ((NULL == pMbox) || (NULL == pMsg)) {
        return GOAL_ERR_PARAM;
    }

    /* fast-return if mailbox is empty */
    if (pMbox->flags & GOAL_MBOX_FLAG_EMPTY) {
        return GOAL_ERR_QUEUE_EMPTY;
    }

    goal_lockGet(pMbox->pMutex, GOAL_LOCK_INFINITE);

    /* get message if mailbox isn't empty */
    if (0 == (pMbox->flags & GOAL_MBOX_FLAG_EMPTY)) {
        GOAL_MEMCPY(pMsg, &pMbox->pMsgData[pMbox->rdIdx * pMbox->sizeMsg], pMbox->sizeMsg);
        pMbox->rdIdx = (pMbox->rdIdx + 1) % pMbox->numMsg;

        /* set empty flag if mailbox is now empty */
        if (pMbox->rdIdx == pMbox->wrIdx) {
            pMbox->flags |= GOAL_MBOX_FLAG_EMPTY;
        }

        /* remove full flag */
        pMbox->flags &= ~GOAL_MBOX_FLAG_FULL;
    }
    else {
        retVal = GOAL_ERR_QUEUE_EMPTY;
        goal_logDbg("mailbox empty: %p", (void *) pMbox);
    }

    /* release mutex */
    goal_lockPut(pMbox->pMutex);

    return retVal;
}


/****************************************************************************/
/** Add a message to a given mailbox
 *
 * This function is thread-safe. The message size is the value specified with
 * @em goal_mboxCreate.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_mboxMsgPut(
    GOAL_MBOX_T *pMbox,                         /**< mailbox */
    uint8_t *pMsg                               /**< [in] message buffer */
)
{
    GOAL_STATUS_T retVal = GOAL_OK;             /* return value */

    if ((NULL == pMbox) || (NULL == pMsg)) {
        return GOAL_ERR_PARAM;
    }

    /* fast-return if mailbox is full */
    if (pMbox->flags & GOAL_MBOX_FLAG_FULL) {
        return GOAL_ERR_QUEUE_FULL;
    }

    goal_lockGet(pMbox->pMutex, GOAL_LOCK_INFINITE);

    /* only add message if mailbox isn't full */
    if (0 == (pMbox->flags & GOAL_MBOX_FLAG_FULL)) {

        GOAL_MEMCPY(&pMbox->pMsgData[pMbox->wrIdx * pMbox->sizeMsg], pMsg, pMbox->sizeMsg);
        pMbox->wrIdx = (pMbox->wrIdx + 1) % pMbox->numMsg;

        /* set full flag if mailbox is now full */
        if (pMbox->rdIdx == pMbox->wrIdx) {
            pMbox->flags |= GOAL_MBOX_FLAG_FULL;
        }

        /* remove empty flag */
        pMbox->flags &= ~GOAL_MBOX_FLAG_EMPTY;
    }
    else {
        retVal = GOAL_ERR_QUEUE_FULL;
        goal_logDbg("mailbox full: %p", (void *) pMbox);
    }

    /* release mutex */
    goal_lockPut(pMbox->pMutex);

    return retVal;
}


/****************************************************************************/
/** Check if a mailbox is full
 *
 * @retval 0 mailbox is not full
 * @retval 1 mailbox is full
 */
uint8_t goal_mboxIsFull(
    GOAL_MBOX_T *pMbox                          /**< mailbox */
)
{
    return (pMbox->flags & GOAL_MBOX_FLAG_FULL) ? 1 : 0;
}


/****************************************************************************/
/** Check if a mailbox is empty
 *
 * @retval 0 mailbox is not empty
 * @retval 1 mailbox is empty
 */
uint8_t goal_mboxIsEmpty(
    GOAL_MBOX_T *pMbox                          /**< mailbox */
)
{
    return (pMbox->flags & GOAL_MBOX_FLAG_EMPTY) ? 1 : 0;
}


