/** @file
 *
 * @brief Ethernet CLI command
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_ETH_CLI_H
#define GOAL_ETH_CLI_H


/****************************************************************************/
/* Structs */
/****************************************************************************/
/**< VLAN in mode */
typedef struct {
    char *strMode;                              /**< mode string */
    GOAL_ETH_VLANIN_MODE_T inmode;              /**< in mode */
} GOAL_ETH_CLI_VLANINMODE_T;


/**< VLAN out mode */
typedef struct {
    char *strMode;                              /**< mode string */
    GOAL_ETH_VLANOUT_MODE_T outmode;            /**< out mode */
} GOAL_ETH_CLI_VLANOUTMODE_T;


/**< Speed mode */
typedef struct {
    char *strMode;                              /**< mode string */
    uint32_t speed;                             /**< speed */
} GOAL_ETH_CLI_SPEEDMODE_T;


/**< Link mode */
typedef struct {
    char *strMode;                              /**< mode string */
    uint32_t link;                              /**< link */
} GOAL_ETH_CLI_LINKSTATE_T;


/**< Duplex mode */
typedef struct {
    char *strMode;                              /**< mode string */
    uint32_t duplex;                            /**< duplex mode */
} GOAL_ETH_CLI_DUPLEXMODE_T;

/**< Autonegotiation mode */
typedef struct {
    char *strMode;                              /**< mode string */
    uint32_t autoneg;                           /**< autonegotiation mode */
} GOAL_ETH_CLI_AUTONEG_T;

/**< QoS mode */
typedef struct {
    char *strMode;                              /**< mode string */
    uint32_t qosMode;                           /**< QoS mode */
} GOAL_ETH_CLI_QOSMODE_T;

/**< Mirror mode */
typedef struct {
    char *strMode;                              /**< mode string */
    GOAL_ETH_MIRR_MODE_T mirrortype;            /**< mirror */
} GOAL_ETH_CLI_MIRRORMODE_T;

/**< MDI state */
typedef struct {
    char *strState;                             /**< state string */
    uint32_t state;                             /**< state value */
} GOAL_ETH_CLI_MDISTATE_T;

/**< MDI mode */
typedef struct {
    char *strMode;                             /**< state string */
    uint32_t mode;                             /**< state value */
} GOAL_ETH_CLI_MDIMODE_T;


/****************************************************************************/
/* Structs */
/****************************************************************************/
GOAL_STATUS_T goal_ethInitCli(
    void
);


#endif /* GOAL_ETH_CLI_H */
