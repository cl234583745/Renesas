/** @file
 *
 * @brief Low Level Interface of GOAL
 *
 * This provides the API to the target specific functions used by GOAL.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_TARGET_API_H
#define GOAL_TARGET_API_H

#include <goal_includes.h>


/****************************************************************************/
/* List of public functions */
/****************************************************************************/
GOAL_STATUS_T goal_targetInitPre(
    void
);

void goal_targetReset(
    void
);

void goal_targetHalt(
    void
);

GOAL_TIMESTAMP_T goal_targetGetTimestamp(
    void
);

uint32_t goal_targetGetTicks(
    void
);

void goal_targetLoop(
    void
);

uint32_t goal_targetGetTimestampDiffUs(
    void
);

uint32_t goal_targetGetButtons(
    void
);

void goal_targetSetLeds(
    uint32_t leds                               /**< LED bitmask */
);

void goal_targetClearLeds(
    uint32_t leds                               /**< LED bit field */
);

uint32_t goal_targetGetLeds(
    void
);

/* Ethernet interface */
#if GOAL_CONFIG_ETHERNET == 1
GOAL_STATUS_T goal_targetEthCmd(
    GOAL_ETH_CMD_T cmd,                         /**< command */
    GOAL_BOOL_T wrFlag,                         /**< write flag */
    uint32_t port,                              /**< port ID */
    void *pArg                                  /**< argument */
);

GOAL_STATUS_T goal_targetGetMacAddr(
    GOAL_ETH_PORT_T portIdx,                    /**< port index */
    char *pMacAddr                              /**< MAC address */
);
#endif /* GOAL_CONFIG_ETHERNET */

void goal_targetSetInterface(
    const char *strName                         /**< interface name */
);

const char * goal_targetGetInterface(
    void
);

/* Non-volatile Memory interface */
unsigned int goal_targetNvsGetSize(
    void
);

GOAL_STATUS_T goal_targetNvsReadData(
    void *pData,                                /**< read buffer */
    unsigned int size                           /**< read length */
);

GOAL_STATUS_T goal_targetNvsWriteData(
    void *pData,                                /**< write buffer */
    unsigned int size                           /**< write length */
);

/* Lock interface */
GOAL_STATUS_T goal_targetLockInit(
    void
);

GOAL_STATUS_T goal_targetLockShutdown(
    void
);

GOAL_STATUS_T goal_targetLockCreate(
    GOAL_LOCK_TYPE_T lockType,                  /**< lock type */
    GOAL_LOCK_T *pLock,                         /**< lock handle */
    uint32_t valInit,                           /**< initial value */
    uint32_t valMax                             /**< maximum value */
);

GOAL_STATUS_T goal_targetLockGet(
    GOAL_LOCK_T *pLock,                         /**< lock handle */
    uint32_t timeout                            /**< timeout */
);

GOAL_STATUS_T goal_targetLockPut(
    GOAL_LOCK_T *pLock                          /**< lock handle */
);

GOAL_STATUS_T goal_targetLockDelete(
    GOAL_LOCK_T *pLock                          /**< lock handle */
);

/* timer interface */
GOAL_STATUS_T goal_targetTimerInit(
    void
);

GOAL_STATUS_T goal_targetTimerCreate(
    GOAL_TIMER_T *pTmr                          /**< timer */
);

GOAL_STATUS_T goal_targetTimerStart(
    GOAL_TIMER_T *pTmr                          /**< timer */
);

GOAL_STATUS_T goal_targetTimerStop(
    GOAL_TIMER_T *pTmr                          /**< timer */
);

GOAL_STATUS_T goal_targetTimerDelete(
    GOAL_TIMER_T *pTmr                          /**< timer */
);

/* logging interface */
#if GOAL_CONFIG_LOGGING_TARGET_RAW == 1
void goal_targetMsgRaw(
    const char *str,                            /**< message */
    unsigned int len                            /**< message length */
);
#endif /* GOAL_CONFIG_LOGGING_TARGET_RAW */

/* UART character get and put */
GOAL_STATUS_T goal_tgtCharGet(
    char *pBuf                                  /**< single character buffer */
);

GOAL_STATUS_T goal_tgtCharPut(
    char c                                      /**< character */
);

GOAL_STATUS_T goal_targetNetInit(
    void
);

GOAL_STATUS_T goal_targetNetStart(
    void* pArg                                  /**< argument */
);

/* TCP/IP Stack interface */
#if GOAL_CONFIG_TCPIP_STACK == 1

uint32_t goal_targetNetGetHandleSize(
    void
);

GOAL_STATUS_T goal_targetNetRecv(
    GOAL_BUFFER_T **ppBuf                       /**< receive buffer */
);

GOAL_STATUS_T goal_targetNetIpSet(
    uint32_t addrIp,                            /**< IP address */
    uint32_t addrMask,                          /**< subnet mask */
    uint32_t addrGw,                            /**< gateway */
    GOAL_BOOL_T flgTemp                         /**< temporary IP config flag */
);

GOAL_STATUS_T goal_targetNetIpGet(
    uint32_t *pAddrIp,                          /**< IP address */
    uint32_t *pAddrMask,                        /**< subnet mask */
    uint32_t *pAddrGw,                          /**< gateway */
    GOAL_BOOL_T *pFlgTemp                       /**< temporary IP config flag */
);

GOAL_STATUS_T goal_targetNetOpen(
    void **ppTargetHandle,                      /**< pointer to target handle structure */
    GOAL_NET_TYPE_T type,                       /**< channel type */
    GOAL_NET_ADDR_T *pAddr                      /**< channel address data */
);

GOAL_STATUS_T goal_targetNetReopen(
    char *pTgtHandle,                           /**< target channel handle */
    GOAL_NET_TYPE_T type,                       /**< channel type */
    GOAL_NET_ADDR_T *pAddr                      /**< channel address data */
);

GOAL_STATUS_T goal_targetNetClose(
    void *pTargetHandle,                        /**< target channel handle */
    GOAL_NET_TYPE_T type                        /**< channel type */
);

GOAL_STATUS_T goal_targetNetActivate(
    void *pTargetHandle                         /**< target channel handle */
);

GOAL_STATUS_T goal_targetNetDeactivate(
    void *pTargetHandle                         /**< target channel handle */
);

GOAL_STATUS_T goal_targetNetSend(
    void *pTargetHandle,                        /**< target channel handle */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_ADDR_T *pAddr,                     /**< address */
    GOAL_BUFFER_T *pBuf                         /**< send buffer */
);

GOAL_STATUS_T goal_targetNetOptSet(
    void *pTargetHandle,                        /**< target channel handle */
    GOAL_NET_TYPE_T type,                       /**< connection type */
    GOAL_NET_OPTION_T option,                   /**< GOAL option ID */
    void *pValue                                /**< option value */
);

void goal_targetNetPoll(
    void
);

GOAL_BOOL_T goal_targetNetAvail(
    void
);

GOAL_STATUS_T goal_targetNetCmd(
    GOAL_NET_CMD_T id,                          /**< command ID */
    GOAL_BOOL_T wrFlag,                         /**< write flag */
    void *pArg                                  /**< argument */
);

GOAL_STATUS_T goal_targetNetGetRemoteAddr(
    void *pTargetHandle,                        /**< target Handle */
    GOAL_NET_ADDR_T **ppAddr                    /**< pointer to store address */
);
#endif /* GOAL_CONFIG_TCPIP_STACK */


#if GOAL_CONFIG_TASK == 1
GOAL_STATUS_T goal_tgtTaskCreate(
    GOAL_TASK_T *pTask                          /**< GOAL task handle */
);

GOAL_STATUS_T goal_tgtTaskStart(
    GOAL_TASK_T *pTask                          /**< GOAL task handle */
);

GOAL_STATUS_T goal_tgtTaskExit(
    void
);

GOAL_STATUS_T goal_tgtTaskMsSleep(
    uint32_t msReq,                             /**< ms requested to sleep */
    uint32_t *pMsRem                            /**< remaining ms if interrupted */
);

GOAL_STATUS_T goal_tgtTaskTestSelf(
    GOAL_TASK_T *pTask                          /**< task handle */
);

GOAL_STATUS_T goal_tgtTaskPrioGet(
    GOAL_TASK_T *pTask,                         /**< task handle */
    uint32_t *pPrio                             /**< priority ref */
);

GOAL_STATUS_T goal_tgtTaskPrioSet(
    GOAL_TASK_T *pTask,                         /**< task handle */
    uint32_t prio                               /**< priority */
);

GOAL_STATUS_T goal_tgtTaskSuspend(
    GOAL_TASK_T *pTask                          /**< task handle */
);

GOAL_STATUS_T goal_tgtTaskResume(
    GOAL_TASK_T *pTask                          /**< task handle */
);
#endif /* GOAL_CONFIG_TASK == 1 */

#endif /* GOAL_TARGET_API_H */
