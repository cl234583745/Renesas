/** @file
 *
 * @brief DHCP Client
 *
 * @details
 * This module implements a DHCPv4 client.
 *
 * @copyright
 * Copyright 2016-2020.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#define GOAL_ID GOAL_ID_DHCP
#include <goal_includes.h>
#include "cm/goal_net_cm.h"


/****************************************************************************/
/* Local defines */
/****************************************************************************/
/** DHCP frame field offsets */
#define DHCP_FIELD_OP       0                   /**< DHCP frame field "op" */
#define DHCP_FIELD_HTYPE    1                   /**< DHCP frame field "htype" */
#define DHCP_FIELD_HLEN     2                   /**< DHCP frame field "hlen" */
#define DHCP_FIELD_HOPS     3                   /**< DHCP frame field "hops" */
#define DHCP_FIELD_XID      4                   /**< DHCP frame field "xid" */
#define DHCP_FIELD_SECS     8                   /**< DHCP frame field "secs" */
#define DHCP_FIELD_FLAGS    10                  /**< DHCP frame field "flags" */
#define DHCP_FIELD_CIADDR   12                  /**< DHCP frame field "ciaddr" */
#define DHCP_FIELD_YIADDR   16                  /**< DHCP frame field "yiaddr" */
#define DHCP_FIELD_SIADDR   20                  /**< DHCP frame field "siaddr" */
#define DHCP_FIELD_GIADDR   24                  /**< DHCP frame field "giaddr" */
#define DHCP_FIELD_CHADDR   28                  /**< DHCP frame field "chaddr" */
#define DHCP_FIELD_PAD      34                  /**< rest of chaddr + sname + file */
#define DHCP_FIELD_SNAME    44                  /**< DHCP frame field "sname" */
#define DHCP_FIELD_FILE     108                 /**< DHCP frame field "file" */
#define DHCP_FIELD_COOKIE   236                 /**< cookie position in "options" */
#define DHCP_FIELD_OPTIONS  240                 /**< DHCP frame field "options" */

/** DHCP frame field values */
#define DHCP_OP_BOOTREQ     1                   /**< BOOTP Boot Request */
#define DHCP_OP_BOOTRES     2                   /**< BOOTP Boot Reply */
#define DHCP_COOKIE         0x63825363          /**< magic cookie */
#define DHCP_HTYPE_ETH      1                   /**< hardware type: Ethernet */
#define DHCP_HLEN_ETH       6                   /**< hardware address lenght: Ethernet */
#define DHCP_FLAG_BCAST     (1<<15)             /**< Broadcast flag */
#define DHCP_XID_INIT       0xabcdef00          /**< initial xid value */

/** DHCP frame lengths */
#define DHCP_LEN_PAD        202                 /**< lenght of pad bytes */
#define DHCP_LEN_HEADER     240                 /**< lenght of DHCP header */

/** DHCP option fields */
#define DHCP_OPT_ID         0                   /**< option Id */
#define DHCP_OPT_LEN        1                   /**< option length */
#define DHCP_OPT_DATA       2                   /**< option data */

/** DHCP Option codes */
#define DHCP_OPT_ID_PAD         0               /**< padding */
#define DHCP_OPT_ID_NETMASK     1               /**< Subnet Mask */
#define DHCP_OPT_ID_GATEWAY     3               /**< Gateway address */
#define DHCP_OPT_ID_DNS_SERVER  6               /**< DNS Server address */
#define DHCP_OPT_ID_HOSTNAME   12               /**< Host Name */
#define DHCP_OPT_ID_DOMAINNAME 15               /**< Domain Name */
#define DHCP_OPT_ID_REQ_IPADDR 50               /**< requested IP address */
#define DHCP_OPT_ID_LEASE_TIME 51               /**< IP Lease time */
#define DHCP_OPT_ID_MSG_TYPE   53               /**< DHCP Message type */
#define DHCP_OPT_ID_SERVER_ID  54               /**< Server Identifier */
#define DHCP_OPT_ID_PARAM_LIST 55               /**< Parameter Request list */
#define DHCP_OPT_ID_T1_VAL     58               /**< Renewal Time (T1) */
#define DHCP_OPT_ID_T2_VAL     59               /**< Rebinding Time (T2) */
#define DHCP_OPT_ID_END       255               /**< End marker */


/** DHCP Message Types */
#define DHCP_MSG_TYPE_DISCOVER 1                /**< DHCPDISCOVER */
#define DHCP_MSG_TYPE_OFFER    2                /**< DHCPOFFER */
#define DHCP_MSG_TYPE_REQUEST  3                /**< DHCPREQUEST */
#define DHCP_MSG_TYPE_DECLINE  4                /**< DHCPDECLINE */
#define DHCP_MSG_TYPE_ACK      5                /**< DHCPACK */
#define DHCP_MSG_TYPE_NAK      6                /**< DHCPNAK */
#define DHCP_MSG_TYPE_RELEASE  7                /**< DHCPRELEASE */
#define DHCP_MSG_TYPE_INFORM   8                /**< DHCPINFORM */

/** port numbers */
#define DHCP_CLIENT_PORT      68                /**< DHCP client port */
#define DHCP_SERVER_PORT      67                /**< DHCP server port */

/** Timeouts in ms */
#define DHCP_TIMEOUT_OFF 0xffffffffffffffff     /**< timeout timer is off */
#define DHCP_TIMEOUT_DISCOVER  2000             /**< rx timeout after sending DISCOVER */
#define DHCP_TIMEOUT_REQUEST   10000            /**< rx timeout after sending REQUEST */


/****************************************************************************/
/* Local data types */
/****************************************************************************/
/** DHCP client states */
typedef uint8_t DHCP_STATE_T;
#define DHCP_STATE_INIT       0                 /**< initial state */
#define DHCP_STATE_SELECTING  1                 /**< selecting DHCP server */
#define DHCP_STATE_REQUESTING 2                 /**< requesting configuration */
#define DHCP_STATE_BOUND      3                 /**< iface bound to ip address */
#define DHCP_STATE_RENEWING   4                 /**< renewing configuration */
#define DHCP_STATE_REBINDING  5                 /**< rebinding ip address to iface */

/** DHCP client events */
typedef enum {
    DHCP_EVENT_START,                           /**< start DHCP Discovery */
    DHCP_EVENT_STOP,                            /**< abort DHCP process */
    DHCP_EVENT_TIMEOUT,                         /**< receive timeout */
    DHCP_EVENT_OFFER_RX,                        /**< DHCP OFFER received */
    DHCP_EVENT_ACK_RX,                          /**< DHCP ACK received */
    DHCP_EVENT_NACK_RX,                         /**< DHCP NACK received */
    DHCP_EVENT_T1_EXPIRED,                      /**< T1 timer expired */
    DHCP_EVENT_T2_EXPIRED,                      /**< T2 timer expired */
    DHCP_EVENT_LEASE_EXPIRED,                   /**< IP address leasing expired */
} DHCP_EVENT_T;


/****************************************************************************/
/* Local functions */
/****************************************************************************/
static void goal_netDhcpReceiveCb(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T   *pBuf                       /**< GOAL buffer */
);

static GOAL_STATUS_T goal_netDhcpEventThrown(
    DHCP_EVENT_T event                          /**< event Id */
);

static GOAL_STATUS_T goal_netDhcpTxDiscover(
    void
);

static GOAL_STATUS_T goal_netDhcpTxRequest(
    GOAL_BOOL_T renewing                        /**< renew active lease */
);

static void goal_netDhcpCreateHeader(
    uint8_t *pData,                             /**< frame data */
    uint16_t *pLen                              /**< current frame length */
);

static void goal_netDhcpTimeCalc(
    uint32_t leaseTime,                         /**< DHCP lease time in s */
    uint32_t renewTime,                         /**< DHCP renewing time in s */
    uint32_t rebindTime                         /**< DHCP rebinding time in s */
);

static void goal_netDhcpIpLost(
    void
);

static GOAL_STATUS_T goal_netDhcpIpSet(
    void
);

static GOAL_STATUS_T goal_netDhcpStateSet(
    DHCP_STATE_T state                          /**< DHCP enable */
);

static DHCP_STATE_T goal_netDhcpStateGet(
    void
);


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static DHCP_STATE_T dhcpState = DHCP_STATE_INIT; /**< state of DHCP client */
static GOAL_BOOL_T flgDhcpInit = GOAL_FALSE;    /**< initialization flag */
static GOAL_BOOL_T flgDhcpActive = GOAL_FALSE;  /**< initialization flag */
static GOAL_NET_CHAN_T *pDhcpChan;              /**< DHCP socket */
static GOAL_TIMESTAMP_T dhcpTimeout = DHCP_TIMEOUT_OFF; /**< DHCP timeout timer */
static uint32_t dhcpXid = DHCP_XID_INIT;        /**< transaction ID */
static uint32_t dhcpServer = 0xffffffff;        /**< DHCP server address */
static GOAL_ETH_MAC_ADDR_T dhcpMac;             /**< local MAC address */
static GOAL_NET_DHCP_T dhcpData;                /**< DHCP data */
static GOAL_TIMESTAMP_T dhcpLeaseTime;          /**< lease time */
static GOAL_TIMESTAMP_T dhcpRenewTime;          /**< renewal time */
static GOAL_TIMESTAMP_T dhcpRebindTime;         /**< rebinding time */


/****************************************************************************/
/** Initialize the DHCP client
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpInit(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_ADDR_T netAddr;                    /* local net address */
    int optVal;                                 /* socket option value */

    GOAL_MEMSET(&netAddr, 0, sizeof(GOAL_NET_ADDR_T));
    netAddr.localPort = DHCP_CLIENT_PORT;

    /* DHCP requires one buffer temporarily for protocol execution */
    res = goal_queuePoolBufsReq(GOAL_ID_DHCP, GOAL_NETBUF_SIZE, 0, 1);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:199: */
        goal_lmLog(GOAL_ID_DHCP, 199, 159, 0, 0, GOAL_LOG_SEV_ERROR, "failed to request network buffers");
        return res;
    }


    /* open socket */
    res = goal_netOpen(&pDhcpChan, &netAddr, GOAL_NET_UDP_CLIENT,
                       goal_netDhcpReceiveCb);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:200: */
        goal_lmLog(GOAL_ID_DHCP, 200, 160, 0, 0, GOAL_LOG_SEV_ERROR, "failed to allocate socket");
        return res;
    }

    /* make socket non-blocking */
    optVal = 1;
    res = goal_netSetOption(pDhcpChan, GOAL_NET_OPTION_NONBLOCK, &optVal);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:201: */
        goal_lmLog(GOAL_ID_DHCP, 201, 161, 0, 0, GOAL_LOG_SEV_ERROR, "failed to set socket to non-blocking");
        goal_netClose(pDhcpChan);
        return res;
    }

    /* make socket reusable */
    optVal = 1;
    res = goal_netSetOption(pDhcpChan, GOAL_NET_OPTION_REUSEADDR, &optVal);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:202: */
        goal_lmLog(GOAL_ID_DHCP, 202, 162, 0, 0, GOAL_LOG_SEV_ERROR, "failed to make socket reusable");
        goal_netClose(pDhcpChan);
        return res;
    }

    /* allow socket to receive broadcast messages */
    optVal = 1;
    res = goal_netSetOption(pDhcpChan, GOAL_NET_OPTION_BROADCAST, &optVal);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:203: */
        goal_lmLog(GOAL_ID_DHCP, 203, 163, 0, 0, GOAL_LOG_SEV_ERROR, "failed to enable Broadcast for socket");
        goal_netClose(pDhcpChan);
        return res;
    }

    goal_netActivate(pDhcpChan);

    res = goal_ethCmd(GOAL_ETH_CMD_MAC_ADDR, GOAL_FALSE, 0, &dhcpMac);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:204: */
        goal_lmLog(GOAL_ID_DHCP, 204, 113, 0, 0, GOAL_LOG_SEV_ERROR, "failed to get MAC address");
        goal_netClose(pDhcpChan);
        return res;
    }

    if (GOAL_RES_OK(res)) {
        res = goal_netDhcpStateSet(DHCP_STATE_INIT);
    }

    flgDhcpInit = GOAL_TRUE;

    return GOAL_OK;
}


/****************************************************************************/
/** Shut down the DHCP client
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpShutdown(
    void
)
{
    if (GOAL_TRUE == flgDhcpInit) {
        goal_netClose(pDhcpChan);
        flgDhcpInit = GOAL_FALSE;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Start the DHCP client
 *
 * This function triggers the DHCP client to send DHCPDISCOVER messages until a
 * response was received.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpStart(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    if (GOAL_FALSE == flgDhcpInit) {
        res = goal_netDhcpInit();
    }

    if (GOAL_RES_ERR(res)) {
        return res;
    }

    return goal_netDhcpEventThrown(DHCP_EVENT_START);
}


/****************************************************************************/
/** Stop the DHCP client
 *
 * This function stops the DHCP client from obtaining an IP address. If the the
 * client is in the state DHCP_STATE_BOUND or higher this function has no effect.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpStop(
    void
)
{
    if (GOAL_FALSE == flgDhcpInit) {
        return GOAL_ERROR;
    }

    return goal_netDhcpEventThrown(DHCP_EVENT_STOP);
}


/****************************************************************************/
/** Release the current IP Address
 *
 * This function also removes the IP address from the TCP/IP stack.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpRelease(
    GOAL_BOOL_T *pReleaseTx                     /**< send RELEASE message */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_BUFFER_T *pTxBuf = NULL;               /* send buffer */
    uint8_t *pData;                             /* current byte in frame */

    if (GOAL_FALSE == flgDhcpInit) {
        return GOAL_ERROR;
    }

    if (DHCP_STATE_INIT == goal_netDhcpStateGet()) {
        /* client has not started */
        return GOAL_OK;
    }

    if ((DHCP_STATE_BOUND <= goal_netDhcpStateGet()) && (GOAL_TRUE == *pReleaseTx)) {
        /* get send buffer */
        res = goal_ethGetNetBuf(&pTxBuf);
        if (GOAL_RES_ERR(res)) {
            /* GG_LOG ID:205: */
            goal_lmLog(GOAL_ID_DHCP, 205, 164, 0, 0, GOAL_LOG_SEV_ERROR, "no free buffer");
            return res;
        }

        goal_netDhcpCreateHeader(pTxBuf->ptrData, &pTxBuf->dataLen);

        GOAL_htobe32_p(&pTxBuf->ptrData[DHCP_FIELD_CIADDR], dhcpData.addrIp);

        pData = &pTxBuf->ptrData[DHCP_FIELD_OPTIONS];

        /* add option DHCP Message Type: RELEASE */
        pData[DHCP_OPT_ID] = DHCP_OPT_ID_MSG_TYPE;
        pData[DHCP_OPT_LEN] = 1;
        pData[DHCP_OPT_DATA] = DHCP_MSG_TYPE_RELEASE;
        pData += 3;
        pTxBuf->dataLen += 3;

        /* add end marker */
        *pData = DHCP_OPT_ID_END;
        pTxBuf->dataLen++;

        /* send frame */
        pDhcpChan->addr.remotePort = DHCP_SERVER_PORT;
        pDhcpChan->addr.remoteIp = dhcpServer;

        goal_netSend(pDhcpChan, pTxBuf);

        goal_queueReleaseBuf(&pTxBuf);
    }

    goal_netDhcpStateSet(DHCP_STATE_INIT);
    dhcpTimeout = DHCP_TIMEOUT_OFF;
    dhcpServer = 0xffffffff;

    return goal_netIpSet(0, 0, 0, GOAL_FALSE);
}


/****************************************************************************/
/** Get the address data obtained via DHCP
 *
 * This function only succeeds if the client is in the state DHCP_STATE_BOUND
 * or above.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpGetAddr(
    GOAL_NET_DHCP_T *pAddrData                  /**< DHCP address data */
)
{
    if (GOAL_FALSE == flgDhcpInit) {
        return GOAL_ERROR;
    }

    if (DHCP_STATE_BOUND > goal_netDhcpStateGet()) {
        return GOAL_ERR_NET_DHCP_ADDR;
    }

    GOAL_MEMCPY(pAddrData, &dhcpData, sizeof(GOAL_NET_DHCP_T));

    return GOAL_OK;
}


/****************************************************************************/
/** Get the current state of the DHCP client
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
GOAL_STATUS_T goal_netDhcpGetState(
    uint32_t *pState                            /**< current state */
)
{
    switch (goal_netDhcpStateGet()) {
        case DHCP_STATE_INIT:
            *pState = GOAL_NET_DHCP_STATE_DISABLED;
            break;

        case DHCP_STATE_SELECTING:
        case DHCP_STATE_REQUESTING:
            *pState = GOAL_NET_DHCP_STATE_PROGRESS;
            break;

        case DHCP_STATE_BOUND:
        case DHCP_STATE_RENEWING:
        case DHCP_STATE_REBINDING:
            *pState = GOAL_NET_DHCP_STATE_BOUND;
            break;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** DHCP cyclic loop
 *
 * This function must be called cyclically to check for timeouts.
 */
void goal_netDhcpLoop(
    void
)
{
    /* check for timeout */
    if ((DHCP_TIMEOUT_OFF != dhcpTimeout) &&
        (dhcpTimeout <= goal_timerTsGet())) {
        goal_netDhcpEventThrown(DHCP_EVENT_TIMEOUT);
    }

    if (DHCP_STATE_BOUND == goal_netDhcpStateGet()) {
        if (dhcpRenewTime <= goal_timerTsGet()) {
            goal_netDhcpEventThrown(DHCP_EVENT_T1_EXPIRED);
        }
    }
    else if (DHCP_STATE_RENEWING == goal_netDhcpStateGet()) {
        if (dhcpRebindTime <= goal_timerTsGet()) {
            goal_netDhcpEventThrown(DHCP_EVENT_T2_EXPIRED);
        }
    }
    else if (DHCP_STATE_REBINDING == goal_netDhcpStateGet()) {
        if (dhcpLeaseTime <= goal_timerTsGet()) {
            goal_netDhcpEventThrown(DHCP_EVENT_LEASE_EXPIRED);
        }
    }

}


/****************************************************************************/
/** Process a DHCP event
 *
 * This function is called to process a DHCP event. The event might change the
 * DHCP state and thus the behavior of the DHCP client.
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_netDhcpEventThrown(
    DHCP_EVENT_T event                          /**< event Id */
)
{
    GOAL_STATUS_T res = GOAL_ERROR;             /* result */

    switch (goal_netDhcpStateGet()) {
        case DHCP_STATE_INIT:
            if (DHCP_EVENT_START == event) {
                res = goal_netDhcpTxDiscover();
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                goal_netDhcpStateSet(DHCP_STATE_SELECTING);
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_DISCOVER;
                flgDhcpActive = GOAL_TRUE;
                res = GOAL_OK;
            }
            break;

        case DHCP_STATE_SELECTING:
            if (DHCP_EVENT_TIMEOUT == event) {
                res = goal_netDhcpTxDiscover();
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_DISCOVER;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_STOP == event) {
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                flgDhcpActive = GOAL_FALSE;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_OFFER_RX == event) {
                /* check offer for validity */
                res = goal_netIpValidCheck(dhcpData.addrIp,
                                           dhcpData.addrNetmask,
                                           dhcpData.addrGateway,
                                           GOAL_TRUE);
                if (GOAL_RES_OK(res)) {
                    res = goal_netDhcpTxRequest(GOAL_FALSE);
                    if (GOAL_RES_ERR(res)) {
                        return res;
                    }
                    goal_netDhcpStateSet(DHCP_STATE_REQUESTING);
                }
                else {
                    /* restart DHCP sequence */
                    goal_netDhcpStateSet(DHCP_STATE_SELECTING);
                }
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_REQUEST;
                res = GOAL_OK;
            }
            break;

        case DHCP_STATE_REQUESTING:
            if (DHCP_EVENT_TIMEOUT == event) {
                res = goal_netDhcpTxDiscover();
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                goal_netDhcpStateSet(DHCP_STATE_SELECTING);
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_DISCOVER;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_STOP == event) {
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_ACK_RX == event) {

                /* apply IP settings */
                res = goal_netDhcpIpSet();

                goal_netDhcpStateSet(DHCP_STATE_BOUND);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
            }
            else if (DHCP_EVENT_NACK_RX == event) {
                /* GG_LOG ID:206: */
                goal_lmLog(GOAL_ID_DHCP, 206, 165, 0, 0, GOAL_LOG_SEV_ERROR, "DHCP Request rejected by server");
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            break;

        case DHCP_STATE_BOUND:
            if (DHCP_EVENT_T1_EXPIRED == event) {
                res = goal_netDhcpTxRequest(GOAL_TRUE);
                if (GOAL_RES_ERR(res)) {
                    return res;
                }

                goal_netDhcpStateSet(DHCP_STATE_RENEWING);
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_REQUEST;
                res = GOAL_OK;
            }
            break;

        case DHCP_STATE_RENEWING:
            if (DHCP_EVENT_TIMEOUT == event) {
                res = goal_netDhcpTxRequest(GOAL_TRUE);
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_REQUEST;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_ACK_RX == event) {
                goal_netDhcpStateSet(DHCP_STATE_BOUND);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_NACK_RX == event) {
                /* GG_LOG ID:207: */
                goal_lmLog(GOAL_ID_DHCP, 207, 165, 0, 0, GOAL_LOG_SEV_ERROR, "DHCP Request rejected by server");
                goal_netDhcpIpLost();
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_T2_EXPIRED == event) {
                dhcpServer = 0xffffffff;
                res = goal_netDhcpTxRequest(GOAL_TRUE);
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                goal_netDhcpStateSet(DHCP_STATE_REBINDING);
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_REQUEST;
                res = GOAL_OK;
            }
            break;

        case DHCP_STATE_REBINDING:
            if (DHCP_EVENT_TIMEOUT == event) {
                res = goal_netDhcpTxRequest(GOAL_TRUE);
                if (GOAL_RES_ERR(res)) {
                    return res;
                }
                dhcpTimeout = goal_timerTsGet() + DHCP_TIMEOUT_REQUEST;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_ACK_RX == event) {
                goal_netDhcpStateSet(DHCP_STATE_BOUND);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_NACK_RX == event) {
                /* GG_LOG ID:208: */
                goal_lmLog(GOAL_ID_DHCP, 208, 165, 0, 0, GOAL_LOG_SEV_ERROR, "DHCP Request rejected by server");
                goal_netDhcpIpLost();
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            else if (DHCP_EVENT_LEASE_EXPIRED == event) {
                /* GG_LOG ID:209: */
                goal_lmLog(GOAL_ID_DHCP, 209, 166, 0, 0, GOAL_LOG_SEV_ERROR, "Lost IP Lease");
                goal_netDhcpIpLost();
                goal_netDhcpStateSet(DHCP_STATE_INIT);
                dhcpTimeout = DHCP_TIMEOUT_OFF;
                res = GOAL_OK;
            }
            break;
    }

    return res;
}


/****************************************************************************/
/** Build the DHCP header
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static void goal_netDhcpCreateHeader(
    uint8_t *pData,                             /**< frame data */
    uint16_t *pLen                              /**< current frame length */
)
{
    pData[DHCP_FIELD_OP] = DHCP_OP_BOOTREQ;
    pData[DHCP_FIELD_HTYPE] = DHCP_HTYPE_ETH;
    pData[DHCP_FIELD_HLEN] = DHCP_HLEN_ETH;
    pData[DHCP_FIELD_HOPS] = 0;
    GOAL_htobe32_p(&pData[DHCP_FIELD_XID], dhcpXid);
    GOAL_htobe16_p(&pData[DHCP_FIELD_SECS], 0);
    GOAL_htobe16_p(&pData[DHCP_FIELD_FLAGS], DHCP_FLAG_BCAST);
    /*  set ciaddr, yiaddr, siaddr & giaddr to 0 */
    GOAL_MEMSET(&pData[DHCP_FIELD_CIADDR], 0, 4 * sizeof(uint32_t));
    GOAL_MEMCPY(&pData[DHCP_FIELD_CHADDR], (uint8_t *) dhcpMac, 6);
    /* pad rest of chaddr field + sname + file */
    GOAL_MEMSET(&pData[DHCP_FIELD_PAD], 0, DHCP_LEN_PAD);
    GOAL_htobe32_p(&pData[DHCP_FIELD_COOKIE], DHCP_COOKIE);

    *pLen = DHCP_LEN_HEADER;
}


/****************************************************************************/
/** Create and send a DHCP DISCOVER frame
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_netDhcpTxDiscover(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_BUFFER_T *pTxBuf = NULL;               /* send buffer */
    uint8_t *pData;                             /* current byte in frame */

    /* get send buffer */
    res = goal_ethGetNetBuf(&pTxBuf);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:210: */
        goal_lmLog(GOAL_ID_DHCP, 210, 164, 0, 0, GOAL_LOG_SEV_ERROR, "no free buffer");
        return res;
    }

    /* set transaction id with each new frame */
    dhcpXid = goal_utilRand();

    goal_netDhcpCreateHeader(pTxBuf->ptrData, &pTxBuf->dataLen);

    pData = &pTxBuf->ptrData[DHCP_FIELD_OPTIONS];

    /* add option DHCP Message Type: DISCOVER */
    pData[DHCP_OPT_ID] = DHCP_OPT_ID_MSG_TYPE;
    pData[DHCP_OPT_LEN] = 1;
    pData[DHCP_OPT_DATA] = DHCP_MSG_TYPE_DISCOVER;
    pData += 3;
    pTxBuf->dataLen += 3;

    /* add end marker */
    *pData = DHCP_OPT_ID_END;
    pTxBuf->dataLen++;


    /* send frame */
    pDhcpChan->addr.remotePort = DHCP_SERVER_PORT;
    pDhcpChan->addr.remoteIp = dhcpServer;

    res = goal_netSend(pDhcpChan, pTxBuf);

    goal_queueReleaseBuf(&pTxBuf);

    return res;
}


/****************************************************************************/
/** Create and send a DHCP REQUEST frame
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T goal_netDhcpTxRequest(
    GOAL_BOOL_T renewing                        /**< renew active lease */
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_BUFFER_T *pTxBuf = NULL;               /* send buffer */
    uint8_t *pData;                             /* current byte in frame */

    /* get send buffer */
    res = goal_ethGetNetBuf(&pTxBuf);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:211: */
        goal_lmLog(GOAL_ID_DHCP, 211, 164, 0, 0, GOAL_LOG_SEV_ERROR, "no free buffer");
        return res;
    }

    goal_netDhcpCreateHeader(pTxBuf->ptrData, &pTxBuf->dataLen);

    if (GOAL_TRUE == renewing) {
        GOAL_htobe32_p(&pTxBuf->ptrData[DHCP_FIELD_CIADDR], dhcpData.addrIp);
    }

    pData = &pTxBuf->ptrData[DHCP_FIELD_OPTIONS];

    /* add option DHCP Message Type: REQUEST */
    pData[DHCP_OPT_ID] = DHCP_OPT_ID_MSG_TYPE;
    pData[DHCP_OPT_LEN] = 1;
    pData[DHCP_OPT_DATA] = DHCP_MSG_TYPE_REQUEST;
    pData += 3;
    pTxBuf->dataLen += 3;

    if (GOAL_FALSE == renewing) {
        /* add server Id */
        pData[DHCP_OPT_ID] = DHCP_OPT_ID_SERVER_ID;
        pData[DHCP_OPT_LEN] = 4;
        GOAL_htobe32_p(&pData[DHCP_OPT_DATA], dhcpServer);
        pData += 6;
        pTxBuf->dataLen += 6;
    }

    /* add requested IP */
    pData[DHCP_OPT_ID] = DHCP_OPT_ID_REQ_IPADDR;
    pData[DHCP_OPT_LEN] = 4;
    GOAL_htobe32_p(&pData[DHCP_OPT_DATA], dhcpData.addrIp);
    pData += 6;
    pTxBuf->dataLen += 6;

    /* add requested parameter list */
    pData[DHCP_OPT_ID] = DHCP_OPT_ID_PARAM_LIST;
    pData[DHCP_OPT_LEN] = 8;
    pData[DHCP_OPT_DATA + 0] = DHCP_OPT_ID_NETMASK;
    pData[DHCP_OPT_DATA + 1] = DHCP_OPT_ID_GATEWAY;
    pData[DHCP_OPT_DATA + 2] = DHCP_OPT_ID_DNS_SERVER;
    pData[DHCP_OPT_DATA + 3] = DHCP_OPT_ID_HOSTNAME;
    pData[DHCP_OPT_DATA + 4] = DHCP_OPT_ID_DOMAINNAME;
    pData[DHCP_OPT_DATA + 5] = DHCP_OPT_ID_LEASE_TIME;
    pData[DHCP_OPT_DATA + 6] = DHCP_OPT_ID_T1_VAL;
    pData[DHCP_OPT_DATA + 7] = DHCP_OPT_ID_T2_VAL;
    pData += 10;
    pTxBuf->dataLen += 10;

    /* add end marker */
    *pData = DHCP_OPT_ID_END;
    pTxBuf->dataLen++;

    /* send frame */
    pDhcpChan->addr.remotePort = DHCP_SERVER_PORT;
    pDhcpChan->addr.remoteIp = dhcpServer;

    res = goal_netSend(pDhcpChan, pTxBuf);

    goal_queueReleaseBuf(&pTxBuf);

    return res;
}


/****************************************************************************/
/** Callback for Implicit Message data
 *
 * This function is called by GOAL, if new data was received for our DHCP
 * socket.
 */
static void goal_netDhcpReceiveCb(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T   *pBuf                       /**< GOAL buffer */
)
{
    uint16_t optLen;                            /* length of option block */
    uint8_t *pOptData;                          /* option block */
    uint32_t tmpU32;                            /* temporary U32 value */
    uint8_t len;                                /* option data length */
    uint32_t leaseTime = 0;                     /* DHCP lease time */
    uint8_t msgType = 0;                        /* DHCP message type */
    uint32_t serverId = 0;                      /* DHCP Server Id */
    uint32_t t1Val = 0;                         /* T1 (Renewal Time) */
    uint32_t t2Val = 0;                         /* T2 (Rebinding Time) */
    uint8_t strLen;                             /* string length */

    UNUSEDARG(cbType);

    if (GOAL_FALSE == flgDhcpActive) {
        return;
    }

    if ((pChan != pDhcpChan) || (NULL == pBuf)) {
        /* GG_LOG ID:212: */
        goal_lmLog(GOAL_ID_DHCP, 212, 167, 0, 0, GOAL_LOG_SEV_ERROR, "invalid callback");
        return;
    }

    if (DHCP_LEN_HEADER > pBuf->dataLen) {
        /* GG_LOG ID:213: */
        goal_lmLog(GOAL_ID_DHCP, 213, 168, 0, 0, GOAL_LOG_SEV_ERROR, "invalid length");
        return;
    }

    if (DHCP_OP_BOOTRES != pBuf->ptrData[DHCP_FIELD_OP]) {
        /* GG_LOG ID:214: */
        goal_lmLog(GOAL_ID_DHCP, 214, 169, 0, 0, GOAL_LOG_SEV_ERROR, "no BOOTRES");
        return;
    }

    tmpU32 = GOAL_be32toh_p(&pBuf->ptrData[DHCP_FIELD_XID]);
    if (tmpU32 != dhcpXid) {
        /* silently ignore responses for other hosts */
        return;
    }

    if (0 != GOAL_MEMCMP(&pBuf->ptrData[DHCP_FIELD_CHADDR], dhcpMac, DHCP_HLEN_ETH)) {
        /* GG_LOG ID:216: */
        goal_lmLog(GOAL_ID_DHCP, 216, 171, 0, 0, GOAL_LOG_SEV_ERROR, "invalid HW address");
        return;
    }

    tmpU32 = GOAL_be32toh_p(&pBuf->ptrData[DHCP_FIELD_COOKIE]);
    if (DHCP_COOKIE != tmpU32) {
        /* GG_LOG ID:217: */
        goal_lmLog(GOAL_ID_DHCP, 217, 172, 4, 0, GOAL_LOG_SEV_ERROR, "invalid cookie $1");
        goal_lmLogParamUINT32(tmpU32);
        goal_lmLogFinish();
        return;
    }

    /* read all options */
    optLen = pBuf->dataLen - DHCP_LEN_HEADER;
    pOptData = &pBuf->ptrData[DHCP_FIELD_OPTIONS];
    GOAL_MEMSET(&dhcpData, 0, sizeof(GOAL_NET_DHCP_T));

    while (optLen) {
        switch (pOptData[DHCP_OPT_ID]) {
            case DHCP_OPT_ID_PAD:
                /* padding byte, skip it */
                pOptData++;
                optLen--;
                break;

            case DHCP_OPT_ID_NETMASK:
                /* subnet mask, 4 bytes */
                dhcpData.addrNetmask = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                pOptData += 6;
                optLen -= 6;
                break;

            case DHCP_OPT_ID_GATEWAY:
                /* Gateway address, multiple of 4 bytes */
                dhcpData.addrGateway = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                len = pOptData[DHCP_OPT_LEN];
                pOptData += len + 2;
                optLen -= len + 2;
                break;

            case DHCP_OPT_ID_DNS_SERVER:
                /* DNS Server address, multiple of 4 bytes */
                dhcpData.addrDns1 = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                len = pOptData[DHCP_OPT_LEN];
                if (8 <= len) {
                    dhcpData.addrDns2 = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA + 4]);
                }
                else {
                    dhcpData.addrDns2 = 0;
                }
                pOptData += len + 2;
                optLen -= len + 2;
                break;

            case DHCP_OPT_ID_DOMAINNAME:
                /* arbitrary length */
                len = pOptData[DHCP_OPT_LEN];
                strLen = len;
                if (GOAL_NET_DNAME_LEN - 1 < strLen) {
                    /* string must fit into buffer, last byte reserved for \0 */
                    strLen = GOAL_NET_DNAME_LEN - 1;
                }
                GOAL_MEMCPY(dhcpData.domainName, &pOptData[DHCP_OPT_DATA], strLen);
                dhcpData.domainName[strLen] = '\0';
                pOptData += len + 2;
                optLen -= len + 2;
                break;

            case DHCP_OPT_ID_HOSTNAME:
                /* arbitrary length */
                len = pOptData[DHCP_OPT_LEN];
                strLen = len;
                if (GOAL_NET_HNAME_LEN - 1 < strLen) {
                    /* string must fit into buffer, last byte reserved for \0 */
                    strLen = GOAL_NET_DNAME_LEN - 1;
                }
                GOAL_MEMCPY(dhcpData.hostName, &pOptData[DHCP_OPT_DATA], strLen);
                dhcpData.hostName[strLen] = '\0';
                pOptData += len + 2;
                optLen -= len + 2;
                break;

            case DHCP_OPT_ID_LEASE_TIME:
                leaseTime = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                pOptData += 6;
                optLen -= 6;
                break;

            case DHCP_OPT_ID_MSG_TYPE:
                msgType = pOptData[DHCP_OPT_DATA];
                pOptData += 3;
                optLen -= 3;
                break;

            case DHCP_OPT_ID_SERVER_ID:
                serverId = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                pOptData += 6;
                optLen -= 6;
                break;

            case DHCP_OPT_ID_T1_VAL:
                t1Val = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                pOptData += 6;
                optLen -= 6;
                break;

            case DHCP_OPT_ID_T2_VAL:
                t2Val = GOAL_be32toh_p(&pOptData[DHCP_OPT_DATA]);
                pOptData += 6;
                optLen -= 6;
                break;

            case DHCP_OPT_ID_END:
                /* reached end of options */
                optLen = 0;
                break;

            default:
                /* unknown option, skip it */
                len = pOptData[DHCP_OPT_LEN];
                pOptData += len + 2;
                optLen -= len + 2;
                break;
        }
    }

    /* depending on the message type, do some specific checking */
    switch (msgType) {
        case DHCP_MSG_TYPE_OFFER:
            if (0 == serverId) {
                /* GG_LOG ID:218: */
                goal_lmLog(GOAL_ID_DHCP, 218, 173, 0, 0, GOAL_LOG_SEV_ERROR, "OFFER had no server ID");
                return;
            }
            dhcpData.addrIp = GOAL_be32toh_p(&pBuf->ptrData[DHCP_FIELD_YIADDR]);
            dhcpServer = serverId;
            goal_netDhcpEventThrown(DHCP_EVENT_OFFER_RX);
            break;

        case DHCP_MSG_TYPE_ACK:
            if (((serverId == dhcpServer) || (DHCP_STATE_REBINDING == goal_netDhcpStateGet())) &&
                (0 != leaseTime)) {
                goal_netDhcpTimeCalc(leaseTime, t1Val, t2Val);
                dhcpData.addrIp = GOAL_be32toh_p(&pBuf->ptrData[DHCP_FIELD_YIADDR]);
                goal_netDhcpEventThrown(DHCP_EVENT_ACK_RX);
            }
            break;

        case DHCP_MSG_TYPE_NAK:
            goal_netDhcpEventThrown(DHCP_EVENT_NACK_RX);
            break;

        default:
            /* GG_LOG ID:219: */
            goal_lmLog(GOAL_ID_DHCP, 219, 174, 4, 0, GOAL_LOG_SEV_ERROR, "unknown or no message type $1");
            goal_lmLogParamUINT32(msgType);
            goal_lmLogFinish();
            break;
    }
}


/****************************************************************************/
/** Calculate renewing and rebinding times
 */
static void goal_netDhcpTimeCalc(
    uint32_t leaseTime,                         /**< DHCP lease time in s */
    uint32_t renewTime,                         /**< DHCP renewing time in s */
    uint32_t rebindTime                         /**< DHCP rebinding time in s */
)
{
    GOAL_TIMESTAMP_T now;                       /* current time in ms */

    now = goal_timerTsGet();

    if (0 == renewTime) {
        renewTime = (uint32_t) (0.5 * leaseTime);
    }
    if (0 == rebindTime) {
        rebindTime = (uint32_t) (0.875 * leaseTime);
    }

    dhcpLeaseTime = now + (leaseTime * 1000);
    dhcpRenewTime = now + (renewTime * 1000);
    dhcpRebindTime = now + (rebindTime * 1000);
}


/****************************************************************************/
/** IP address lease time expired
 *
 * This function removes the current IP address from the device.
 */
static void goal_netDhcpIpLost(
    void
)
{
    GOAL_STATUS_T res;                          /* return value */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable entry */

    /* GG_LOG ID:220: */
    goal_lmLog(GOAL_ID_DHCP, 220, 175, 0, 0, GOAL_LOG_SEV_INFO, "IP address lease time expired !!!");

    dhcpServer = 0xffffffff;

    res = goal_netIpSet(0, 0, 0, GOAL_FALSE);

    if (GOAL_RES_OK(res)) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_STATE, &pCmVar);
    }

    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT8(pCmVar, goal_netDhcpStateGet());
    }

}


/****************************************************************************/
/** IP address valid
 *
 * This function sets the current IP address of the device.
 */
static GOAL_STATUS_T goal_netDhcpIpSet(
    void
)
{
    GOAL_STATUS_T res;                          /* return value */
    GOAL_BOOL_T flgValid = GOAL_FALSE;          /* IP valid flag */
    GOAL_CM_VAR_T *pCmVar = NULL;               /* CM variable entry */

    res = goal_netIpSet(dhcpData.addrIp, dhcpData.addrNetmask, dhcpData.addrGateway, GOAL_FALSE);
    if (GOAL_RES_OK(res)) {
        res = goal_netFlgValidGet(&flgValid);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_netCmIpSet(dhcpData.addrIp, dhcpData.addrNetmask, dhcpData.addrGateway, flgValid);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_STATE, &pCmVar);
    }

    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT8(pCmVar, goal_netDhcpStateGet());
    }

    return res;
}


/****************************************************************************/
/** set DHCP state in CM
 *
 */
static GOAL_STATUS_T goal_netDhcpStateSet(
    DHCP_STATE_T state                          /**< DHCP enable */
)
{
    GOAL_STATUS_T res;                          /* return value */
    GOAL_CM_VAR_T *pCmVar;                      /* CM variable entry */

    res = goal_cmGetVarById(GOAL_CM_NET_MOD_ID, NET_CM_VAR_DHCP_STATE, &pCmVar);

    if (GOAL_RES_OK(res)) {
        GOAL_CM_SETVAR_UINT8(pCmVar, (uint8_t) state);
    }

    dhcpState = state;

    return res;
}


/****************************************************************************/
/** get DHCP state
 *
 */
static DHCP_STATE_T goal_netDhcpStateGet(
    void
)
{
    return dhcpState;
}
