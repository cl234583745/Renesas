#undef GOAL_CM_VAR
#if GOAL_CM_NAMES == 1
#define GOAL_CM_VAR(varId, type, maxSize, validate, change) {varId, type, maxSize, NULL, validate, change, NULL, NULL, #varId}
#else
#define GOAL_CM_VAR(varId, type, maxSize, validate, change) {varId, type, maxSize, NULL, validate, change, NULL, NULL}
#endif
