/** @file
 *
 * @brief GOAL Bus Handling
 *
 * This module implements a generic bus interface.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_BUS_H
#define GOAL_BUS_H

#include "goal_includes.h"


/****************************************************************************/
/* data types */
/****************************************************************************/
struct GOAL_BUS_T;

typedef GOAL_STATUS_T (* GOAL_BUS_FUNC_READ)(
    struct GOAL_BUS_T *pBus,                    /**< bus handle */
    uint32_t addr,                              /**< read address */
    uint32_t reg,                               /**< register */
    char *pVal,                                 /**< buffer address */
    uint32_t len                                /**< read length */
);

typedef GOAL_STATUS_T (* GOAL_BUS_FUNC_WRITE)(
    struct GOAL_BUS_T *pBus,                    /**< bus handle */
    uint32_t addr,                              /**< write address */
    uint32_t reg,                               /**< register */
    char *pVal,                                 /**< buffer address */
    uint32_t len                                /**< write length */
);

typedef struct GOAL_BUS_T {
    GOAL_BUS_FUNC_READ read;                    /**< data read */
    GOAL_BUS_FUNC_WRITE write;                  /**< data write */
    void *pData;                                /**< bus specific data */
} GOAL_BUS_T;


#endif /* GOAL_BUS_H */
