# GOAL Core System
