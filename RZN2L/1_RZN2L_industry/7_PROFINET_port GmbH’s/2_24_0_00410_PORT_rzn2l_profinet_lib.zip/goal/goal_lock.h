/** @file
 *
 * @brief GOAL Locking Mechanisms
 *
 * This module implements binary and counting lock functions.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_LOCK_H
#define GOAL_LOCK_H


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_lockInitPre(
    void
);

GOAL_STATUS_T goal_lockCreate(
    GOAL_LOCK_TYPE_T lockType,                  /**< GOAL_LOCK_BINARY or GOAL_LOCK_COUNT */
    GOAL_LOCK_T **ppLock,                       /**< pointer to lock ref */
    uint32_t valInit,                           /**< initial lock value */
    uint32_t valMax,                            /**< maximal lock value */
    GOAL_ID_T usage                             /**< usage indicator */
);

GOAL_STATUS_T goal_lockGet(
    GOAL_LOCK_T *pLock,                         /**< lock data */
    uint32_t timeout                            /**< lock timeout */
);

void goal_lockPut(
    GOAL_LOCK_T *pLock                          /**< lock data */
);

void goal_lockDelete(
    GOAL_LOCK_T *pLockId                        /**< lock ID */
);

GOAL_STATUS_T goal_lockGetIfTrue(
    GOAL_LOCK_T *pLock,                         /**< lock */
    uint32_t timeout,                           /**< lock timeout */
    volatile GOAL_BOOL_T *pVal                  /**< value to check */
);

GOAL_STATUS_T goal_lockGetIfFalse(
    GOAL_LOCK_T *pLock,                         /**< lock */
    uint32_t timeout,                           /**< lock timeout */
    volatile GOAL_BOOL_T *pVal                  /**< value to check */
);


#endif /* GOAL_LOCK_H */
