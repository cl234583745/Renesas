/** @file
 *
 * @brief
 * PROFINET Device Identification Example
 *
 * @details
 * This example shows how to update the device identification.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID                0           /**< PROFINET id */

#define APPL_VENDOR_ID              0x028c      /**< port GmbH vendor id */
#define APPL_DEVICE_ID              0x0001      /**< device id */
#define APPL_HWREV                  0x0001      /**< hardware revision */
#define APPL_SWREV_PREFIX           GOAL_PNIO_SWREV_PROTOTYPE /**< sw revision prefix */
#define APPL_SWREV_FUNCENH          0x50        /**< functional enhancement */
#define APPL_SWREV_BUGFIX           0x03        /**< bugfix */
#define APPL_SWREV_INTCHG           0x18        /**< internal change */
#define APPL_SWREV_REVCNT           0x0000      /**< revision counter */
#define APPL_PROFILE_ID             0xf600      /**< profile id */
#define APPL_PROFILE_SPECTYPE       0x0000      /**< profile specific type */
#define APPL_ORDER_ID               "00210"     /**< order id */
#define APPL_SERIAL_NUM             "20074"     /**< serial number */
#define APPL_VENDOR_NAME            "port GmbH" /**< vendor name */
#define APPL_PORT_DESC              "pnioTestPort" /**< port description */
#define APPL_SYSTEM_DESC            "PROFINET System" /**< system description */

#define APPL_MOD_SIZE       64                  /**< module size */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */


/****************************************************************************/
/** Application Main
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /**************************/
    /* set device information */
    /**************************/

    /* vendor id */
    res = goal_pnioVendorIdSet(pPnio, APPL_VENDOR_ID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set vendor id");
        return res;
    }

    /* device id */
    res = goal_pnioDeviceIdSet(pPnio, APPL_DEVICE_ID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set device id");
        return res;
    }

    /* hardware revision */
    res = goal_pnioHwRevSet(pPnio, APPL_HWREV);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set hardware revision");
        return res;
    }

    /* software revision */
    res = goal_pnioSwRevSet(pPnio, APPL_SWREV_PREFIX, APPL_SWREV_FUNCENH, APPL_SWREV_BUGFIX, APPL_SWREV_INTCHG, APPL_SWREV_REVCNT);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set software revision");
        return res;
    }

    /* profile id */
    res = goal_pnioProfileIdSet(pPnio, APPL_PROFILE_ID, APPL_PROFILE_SPECTYPE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set profile id");
        return res;
    }

    /* order id */
    res = goal_pnioOrderIdSet(pPnio, APPL_ORDER_ID, strlen(APPL_ORDER_ID));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set order id");
        return res;
    }

    /* serial number */
    res = goal_pnioSerialNumSet(pPnio, APPL_SERIAL_NUM, strlen(APPL_SERIAL_NUM));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set serial number");
        return res;
    }

    /* vendor name */
    res = goal_pnioVendorNameSet(pPnio, APPL_VENDOR_NAME, strlen(APPL_VENDOR_NAME));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set vendor name");
        return res;
    }

    /* port description */
    res = goal_pnioPortDescSet(pPnio, APPL_PORT_DESC, strlen(APPL_PORT_DESC));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set port description");
        return res;
    }

    /* system description */
    res = goal_pnioSystemDescSet(pPnio, APPL_SYSTEM_DESC, strlen(APPL_SYSTEM_DESC));
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set system description");
        return res;
    }

    /*********************************/
    /* Slot and module configuration */
    /*********************************/

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, APPL_MOD_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, APPL_MOD_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, APPL_MOD_SIZE, APPL_MOD_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);
    UNUSEDARG(id);
    UNUSEDARG(pCb);

    /* handle callback IDs */

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
}
