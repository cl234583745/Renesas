/** @file
 *
 * @brief
 * PROFINET Communication Core Example
 *
 * @details
 * This example just starts the PROFINET stack on the communication core. The
 * complete API logic is handled in the PROFINET stack specific RPC CC driver.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>
#include <goal_snmp.h>


/****************************************************************************/
/** Application Init
 *
 * Initialize the PROFINET stack on the communication core.
 */
GOAL_STATUS_T appl_init(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* initialize SNMP */
    res = goal_snmpInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of SNMP failed");
    }

    /* initialize PROFINET */
    res = goal_pnioInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of PROFINET failed");
    }

    return res;
}
