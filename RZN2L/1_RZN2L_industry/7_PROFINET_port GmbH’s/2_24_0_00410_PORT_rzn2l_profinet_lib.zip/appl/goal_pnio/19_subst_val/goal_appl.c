/** @file
 *
 * @brief
 * PROFINET SubstituteValue Example
 *
 * @details
 * This examples cyclically monitors the APDU status and the IOPS of the output
 * module. If a status changes the output data buffer is shown.
 *
 * @copyright
 * Copyright 2010-2019 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define MODULE_SIZE         64                  /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T mFlgAppReady;                /**< app ready flag */
static GOAL_BOOL_T mFlgConnInit;                /**< connection init flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR id */
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */
static uint8_t mData[MODULE_SIZE];              /**< output data buffer */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * Setup slots/modules and link them together.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != mFlgAppReady) {
                mFlgAppReady = GOAL_TRUE;
                mFlgConnInit = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                mFlgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    static GOAL_PNIO_APDU_STATUS_T statusApduLast; /* last APDU_Status */
    static GOAL_PNIO_IOXS_T stateIopsLast;      /* producer state */
    GOAL_STATUS_T res;                          /* result */
    GOAL_PNIO_APDU_STATUS_T statusApdu;         /* APDU_Status */
    GOAL_PNIO_IOXS_T stateIops;                 /* producer state */
    GOAL_BOOL_T flgShow = GOAL_FALSE;           /* show data flag */

    /* leave if offline */
    if (GOAL_TRUE != mFlgAppReady) {
        return;
    }

    /* read APDU status */
    res = goal_pnioApduStatusGet(pPnio, idAr, &statusApdu);
    if (GOAL_RES_OK(res)) {

        /* print all info on connection start */
        if (GOAL_TRUE == mFlgConnInit) {
            statusApduLast.statusData = ~statusApdu.statusData;
        }

        if (statusApduLast.statusData != statusApdu.statusData) {
            flgShow = GOAL_TRUE;

            if ((GOAL_PNIO_APDU_DS_STATE_PRIMARY & statusApduLast.statusData) != (GOAL_PNIO_APDU_DS_STATE_PRIMARY & statusApdu.statusData)) {
                goal_logInfo("APDU_Status.DataStatus.State: IOCR state is %s", (GOAL_PNIO_APDU_DS_STATE_PRIMARY & statusApdu.statusData) ? "primary" : "backup");

                if (GOAL_PNIO_APDU_DS_STATE_PRIMARY & statusApdu.statusData) {
                    goal_logInfo("APDU_Status.DataStatus.Redundancy: %s primary AR of a given AR-set is present", (GOAL_PNIO_APDU_DS_REDUNDANCY_BCK_NONE_PRIM & statusApdu.statusData) ? "none" : "(default) one");
                } else {
                    goal_logInfo("APDU_Status.DataStatus.Redundancy: ARState from the IO device point of view is %s", (GOAL_PNIO_APDU_DS_REDUNDANCY_PRIM_IS_BCK & statusApdu.statusData) ? "backup" : "(default) primary");
                }
            }

            if ((GOAL_PNIO_APDU_DS_DATAVALID_VALID & statusApduLast.statusData) != (GOAL_PNIO_APDU_DS_DATAVALID_VALID & statusApdu.statusData)) {
                goal_logInfo("APDU_Status.DataStatus.DataValid: DataItem %svalid", (GOAL_PNIO_APDU_DS_DATAVALID_VALID & statusApdu.statusData) ? "" : "in");
            }

            if ((GOAL_PNIO_APDU_DS_PROVIDERSTATE_RUN & statusApduLast.statusData) != (GOAL_PNIO_APDU_DS_PROVIDERSTATE_RUN & statusApdu.statusData)) {
                goal_logInfo("APDU_Status.DataStatus.ProviderState: %s", (GOAL_PNIO_APDU_DS_PROVIDERSTATE_RUN & statusApdu.statusData) ? "run" : "stop");
            }

            if ((GOAL_PNIO_APDU_DS_STATION_PROBLEM_INDICATOR & statusApduLast.statusData) != (GOAL_PNIO_APDU_DS_STATION_PROBLEM_INDICATOR & statusApdu.statusData)) {
                goal_logInfo("APDU_Status.DataStatus.StationProblemIndicator: %s", (GOAL_PNIO_APDU_DS_STATION_PROBLEM_INDICATOR & statusApdu.statusData) ? "normal operation" : "problem detected");
            }

            if ((GOAL_PNIO_APDU_DS_IGNORE_DATASTATUS & statusApduLast.statusData) != (GOAL_PNIO_APDU_DS_IGNORE_DATASTATUS & statusApdu.statusData)) {
                goal_logInfo("APDU_Status.DataStatus.Ignore: %s the DataStatus", (GOAL_PNIO_APDU_DS_IGNORE_DATASTATUS & statusApdu.statusData) ? "ignore" : "evaluate");
            }

            statusApduLast.statusData = statusApdu.statusData;
        }
    }

    /* read IOPS status */
    res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, (char *) mData, MODULE_SIZE, &stateIops);
    if (GOAL_RES_OK(res)) {

        /* print all info on connection start */
        if (GOAL_TRUE == mFlgConnInit) {
            stateIopsLast = ~stateIops;
        }

        if (stateIopsLast != stateIops) {
            flgShow = GOAL_TRUE;
            stateIopsLast = stateIops;
            goal_logInfo("output IOPS changed: 0x%02hhx", stateIops);
        }
    }

    /* show data if requested */
    if (GOAL_TRUE == flgShow) {
        goal_logInfo("hex data: %02hhx %02hhx %02hhx %02hhx %02hhx %02hhx %02hhx %02hhx", mData[0], mData[1], mData[2], mData[3], mData[4], mData[5], mData[6], mData[7]);
    }

    /* clear connection init flag */
    if (GOAL_TRUE == mFlgConnInit) {
        mFlgConnInit = GOAL_FALSE;
    }
}
