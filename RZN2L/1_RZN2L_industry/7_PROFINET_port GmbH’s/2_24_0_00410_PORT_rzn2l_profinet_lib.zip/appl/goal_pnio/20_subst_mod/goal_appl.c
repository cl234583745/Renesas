/** @file
 *
 * @brief
 * PROFINET Dynamic Module Configuration Example
 *
 * @details
 * This example shows how to accept a wrong submodule with the same
 * characteristic by using the substitute flag as subslot state.
 *
 * @copyright
 * Copyright 2010-2019 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define MODULE_SIZE         64                  /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static void main_modulePull(
    void
);

static void main_modulePlug(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< connection ID */
static uint16_t cntSlot = 0;                    /**< slot counter */
static GOAL_PNIO_T *pPnio = NULL;               /**< GOAL PROFINET handle */


/****************************************************************************/
/** Application Main
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }
    cntSlot++;

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }
    cntSlot++;

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, MODULE_SIZE, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Pull all modules
 *
 * Remove all modules from their slots.
 */
static void main_modulePull(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    uint16_t cnt;                               /* counter */

    /* slot 0 contains DAP and interfaces, don't pull these */
    for (cnt = APPL_SLOT_1; cnt <= cntSlot; cnt++) {
        res = goal_pnioModPull(pPnio, APPL_API, cnt);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("error while pulling module: %u", cnt);
        }
    }
}


/****************************************************************************/
/** Plug module from ExpectedSubmoduleEntry
 */
static void main_modulePlug(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res;                          /* result */
    uint32_t idApi;                             /* API id */
    uint16_t idSlot;                            /* slot id */
    uint16_t idSubslot;                         /* subslot id */
    uint32_t idMod;                             /* module id */
    uint32_t idSubmod;                          /* submodule id */

    /* assign ids */
    idApi = pCb->data[1].u32;
    idSlot = pCb->data[2].u16;
    idSubslot = pCb->data[3].u16;
    idMod = pCb->data[4].u32;
    idSubmod = pCb->data[5].u32;

    /* skip requests for unknown API */
    if (APPL_API != idApi) {
        goal_logErr("unknown API in ExpectedSubmoduleBlock entry");
        return;
    }

    /* skip module requests as submodules plug modules recursively */
    if (GOAL_TRUE == pCb->data[6].valBool) {
        return;
    }

    /* skip requests for DAP slot (DAP & interfaces) */
    if (APPL_SLOT_1 > idSlot) {
        return;
    }

    /* allow APPL_MOD_1:APPL_MOD_1_SUB_1 in slot APPL_API:APPL_SLOT_1:APPL_SLOT_1_SUB_1 */
    if ((APPL_API == idApi) && (APPL_SLOT_1 == idSlot) && (APPL_SLOT_1_SUB_1 == idSubslot)) {
        if ((APPL_MOD_1 == idMod) && (APPL_MOD_1_SUB_1 == idSubmod)) {

            /* plug module */
            res = goal_pnioSubmodPlug(pPnio, idApi, idSlot, idSubslot, idMod, idSubmod);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("error while plugging module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u)", idMod, idSubmod, idApi, idSlot, idSubslot);
                return;
            }

            goal_logInfo("plugged module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u)", idMod, idSubmod, idApi, idSlot, idSubslot);

            return;
        }
    }

    /* allow APPL_MOD_2:APPL_MOD_2_SUB_1 or APPL_MOD_3:APPL_MOD_3_SUB_1 in slot APPL_API:APPL_SLOT_2:APPL_SLOT_2_SUB_1 and mark it as ok or substitute */
    if ((APPL_API == idApi) && (APPL_SLOT_2 == idSlot) && (APPL_SLOT_2_SUB_1 == idSubslot)) {

        /* plug module */
        res = goal_pnioSubmodPlug(pPnio, idApi, idSlot, idSubslot, APPL_MOD_2, APPL_MOD_2_SUB_1);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("error while plugging module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u)", (uint32_t) APPL_MOD_2, (uint32_t) APPL_MOD_2_SUB_1, idApi, idSlot, idSubslot);
            return;
        }

        /* mark state as ok */
        if ((APPL_MOD_2 == idMod) && (APPL_MOD_2_SUB_1 == idSubmod)) {

            res = goal_pnioSubslotStateSet(pPnio, idApi, idSlot, idSubslot, GOAL_PNIO_SUBSLOT_STATE_GOOD);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("error while setting subslot state (%"FMT_u32", %u, %u) to ok", idApi, idSlot, idSubslot);
                return;
            }

            goal_logInfo("plugged module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u) - state: ok", (uint32_t) APPL_MOD_2, (uint32_t) APPL_MOD_2_SUB_1, idApi, idSlot, idSubslot);

            return;
        }

        /* mark state as substitute */
        if ((APPL_MOD_3 == idMod) && (APPL_MOD_3_SUB_1 == idSubmod)) {

            res = goal_pnioSubslotStateSet(pPnio, idApi, idSlot, idSubslot, GOAL_PNIO_SUBSLOT_STATE_SUBST);
            if (GOAL_RES_ERR(res)) {
                goal_logErr("error while setting subslot state (%"FMT_u32", %u, %u) to substitute", idApi, idSlot, idSubslot);
                return;
            }

            goal_logInfo("plugged module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u) - state: subst", (uint32_t) APPL_MOD_3, (uint32_t) APPL_MOD_3_SUB_1, idApi, idSlot, idSubslot);

            return;
        }
    }

    goal_logInfo("ignored plug request of module (0x%08"FMT_x32", 0x%08"FMT_x32") into slot (%"FMT_u32", %u, %u)", idMod, idSubmod, idApi, idSlot, idSubslot);
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_CONNECT_REQUEST_EXP_START:
            /* start of ExpectedSubmoduleBlock received, remove all modules */
            main_modulePull();
            break;

        case GOAL_PNIO_CB_ID_EXP_SUBMOD:
            /* module config request received */
            main_modulePlug(pCb);
            break;
    }

    return res;
}
