/** @file
 *
 * @brief
 * PROFINET Set Device Name Example
 *
 * @details
 * This example shows how to update the device name from the application. Be
 * aware that this is not specification conform and must only be used (if
 * necessary) during development.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET instance id */
#define APPL_PNIO_NAME      "testdevice"        /**< PROFINET device name */


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_PNIO_T *pPnio;                      /**< PROFINET instance */


/****************************************************************************/
/** Application Init
 *
 * Build up the device structure and initialize the Profinet stack.
 */
GOAL_STATUS_T appl_init(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* initialize PROFINET */
    res = goal_pnioInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of PROFINET failed");
    }

    return res;
}


/****************************************************************************/
/** Application Setup
 *
 * Setup the application.
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* set the device name / name of station */
    res = goal_pnioDeviceNameSet(pPnio, APPL_PNIO_NAME, GOAL_STRLEN(APPL_PNIO_NAME), GOAL_TRUE, GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set the PROFINET device name");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}
