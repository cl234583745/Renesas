/** @file
 *
 * @brief
 * Demonstrate how postponing the ExpectedSubmoduleBlock processing works.
 *
 * @details
 * After the ExpectedSubmoduleBlock request is signaled via its callback, the
 * stack is informed that the processing can be continued later.
 *
 * @copyright
 * Copyright 2010-2019 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define APPL_TIMEOUT_TRIGGER_VAL (30 * GOAL_TIMER_SEC) /**< timeout trigger in ms */


#define MODULE_SIZE              64             /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static GOAL_STATUS_T appl_expSubmodBlkProcess(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */
static GOAL_TIMESTAMP_T mTsTout;                /**< timeout trigger value */
static GOAL_BOOL_T mFlgPostponed;               /**< postpone state */


/****************************************************************************/
/** Application Main
 *
 * Build up the device structure and initialize the Profinet stack.
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * Setup slots/modules and link them together.
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration successful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:

            /* reset ExpSubmodBlk postpone state */
            mTsTout = 0;
            mFlgPostponed = GOAL_FALSE;

            break;

        case GOAL_PNIO_CB_ID_CONNECT_REQUEST_EXP_START:
            goal_logInfo("start of ExpectedSubmoduleBlock processing");
            break;

        case GOAL_PNIO_CB_ID_EXP_SUBMOD:
            return appl_expSubmodBlkProcess(pHdlPnio, pCb);

        default:
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    static GOAL_TIMESTAMP_T diffLast = 0;       /* last difference */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    GOAL_TIMESTAMP_T diffCur;                   /* current difference */


    /* get current timestamp */
    tsCur = goal_timerTsGet();

    if (0 != mTsTout) {
        if (mTsTout <= tsCur) {
            goal_logInfo("restart ExpectedSubmoduleBlock processing");
            goal_pnioConnReqProcess(pPnio);
            mTsTout = 0;
        } else {
        diffCur = (mTsTout - tsCur) / GOAL_TIMER_SEC;
        if (diffLast != diffCur) {
            diffLast = diffCur;
            goal_logInfo("seconds: %"FMT_u64, diffCur);
            }
        }
    }

}


/****************************************************************************/
/** Handler for ExpectedSubmoduleBlock Entries
 *
 * @returns PN_STATUS_T result
 */
static GOAL_STATUS_T appl_expSubmodBlkProcess(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    UNUSEDARG(pHdlPnio);

    if (GOAL_PNIO_IND_MOD == pCb->data[6].expMode) {
        goal_logInfo("expecting module 0x%"FMT_x32" in slot 0x%"FMT_x32":0x%x", pCb->data[4].u32, pCb->data[1].u32, pCb->data[2].u16);
    } else {
        goal_logInfo("expecting submodule 0x%"FMT_x32":0x%"FMT_x32" in subslot 0x%"FMT_x32":0x%x:0x%x", pCb->data[4].u32, pCb->data[5].u32, pCb->data[1].u32, pCb->data[2].u16, pCb->data[3].u16);
    }

    /* postpone at last submodule */
    if (GOAL_PNIO_IND_SUBMOD == pCb->data[6].expMode) {
        if ((APPL_MOD_2 == pCb->data[4].u32) && (APPL_MOD_2_SUB_1 == pCb->data[5].u32)) {
            if ((APPL_API == pCb->data[1].u32) && (APPL_SLOT_2 == pCb->data[2].u16) && (APPL_SLOT_2_SUB_1 == pCb->data[3].u16)) {
                if (GOAL_FALSE == mFlgPostponed) {

                    /* mark postpone state as done */
                    mFlgPostponed = GOAL_TRUE;

                    /* start timer to answer request */
                    mTsTout = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;

                    /* inform user */
                    goal_logInfo(">>>>>>>>> INFO <<<<<<<<<");
                    goal_logInfo("sleeping %u seconds before answering Connect Request", APPL_TIMEOUT_TRIGGER_VAL / GOAL_TIMER_SEC);
                    goal_logInfo(">>>>>>>>> INFO <<<<<<<<<");

                    return GOAL_OK_DELAYED;
                }
            }
        }
    }

    return GOAL_OK;
}
