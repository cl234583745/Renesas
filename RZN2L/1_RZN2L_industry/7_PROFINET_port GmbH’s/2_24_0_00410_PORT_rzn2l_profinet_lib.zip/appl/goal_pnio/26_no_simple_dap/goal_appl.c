/** @file
 *
 * @brief
 * PROFINET Example of Device Access Point Configuration.
 *
 * @details
 * This example shows how to configure the device access point manually.
 *
 * @copyright
 * Copyright 2023 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */
#define APPL_API            APPL_PNIO_ID        /**< API 0 */

#define APPL_TIMEOUT_TRIGGER_VAL 100 * GOAL_TIMER_MSEC /**< timeout trigger in ms */
#define MODULE_SIZE 64                          /**< module sizes */

/* Device Access Point */
#define APPL_SLOT_0             0x0             /**< slot 0 */
#define APPL_SLOT_0_SUB_1       0x1             /**< submodule for slot 0 */
#define APPL_SLOT_0_SUB_8000    0x8000          /**< submodule for slot 0 */
#define APPL_SLOT_0_SUB_8001    0x8001          /**< submodule for slot 0 */

#define APPL_MOD_11             0x11            /**< module 17 */
#define APPL_MOD_11_SUB_1       0x01            /**< submodule for module 17 */
#define APPL_MOD_11_SUB_2       0x02            /**< submodule for module 17 */
#define APPL_MOD_11_SUB_3       0x03            /**< submodule for module 17 */

/* slots/modules for process data */
#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x1                 /**< module 1 */
#define APPL_MOD_1_SUB_1    0x1                 /**< submodule for module 1 */
#define APPL_MOD_2          0x2                 /**< module 2 */
#define APPL_MOD_2_SUB_1    0x1                 /**< submodule for module 2 */


/****************************************************************************/
/* Slot/Module Assigning of Device Access Point */
/****************************************************************************/
#define APPL_CONFIG_DAP \
    { APPL_SLOT_0, APPL_SLOT_0_SUB_1, APPL_MOD_11, APPL_MOD_11_SUB_1 }

#define APPL_CONFIG_IFACE \
    { APPL_SLOT_0, APPL_SLOT_0_SUB_8000, APPL_MOD_11, APPL_MOD_11_SUB_2 }

#define APPL_CONFIG_PORTS \
    { APPL_SLOT_0, APPL_SLOT_0_SUB_8001, APPL_MOD_11, APPL_MOD_11_SUB_3 }


/****************************************************************************/
/* Types */
/****************************************************************************/
typedef struct APPL_SLOT_MODULE_T {
    uint32_t slot;                              /**< slot */
    uint32_t subslot;                           /**< subslot */
    uint32_t module;                            /**< module */
    uint32_t submodule;                         /**< submodule */
} APPL_SLOT_MODULE_T;


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< connection ID */
static GOAL_PNIO_T *pPnio = NULL;               /**< GOAL PROFINET handle */
static char dataDm[MODULE_SIZE];                /**< buffer for DM module data */

static APPL_SLOT_MODULE_T mConfigDap = APPL_CONFIG_DAP; /**< slots/modules of DAP */
static APPL_SLOT_MODULE_T mConfigIface = APPL_CONFIG_IFACE; /**< slots/modules of interface */
static APPL_SLOT_MODULE_T mConfigPorts = APPL_CONFIG_PORTS; /**< slots/modules of ports */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static GOAL_STATUS_T appl_dapCreate(
    uint16_t portCnt                            /**< one module for each port */
);


/****************************************************************************/
/** Application Main
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    uint16_t portCnt = 0;                       /* number of ports */

    res = goal_ethCmd(GOAL_ETH_CMD_PORT_COUNT, GOAL_FALSE, 0, (void *) &portCnt);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create DAP");
        return res;
    }

    /* configure maximal number of slots (inclusive DAP), minimum 3 */
    goal_pnioCfgSlotMaxCntSet((portCnt < 3) ? 3 : portCnt + 1);

    res = goal_pnioCfgDevDapSimpleSet(GOAL_FALSE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to disable simple DAP configuration");
        return res;
    }

    /* configure modules and slots of DAP */
    goal_pnioCfgDevDapModuleSet(mConfigDap.module);
    goal_pnioCfgDevDapSlotSet(mConfigDap.slot);
    goal_pnioCfgDevDapSubslotSet(mConfigDap.subslot);

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* create device access point */
    res = appl_dapCreate(portCnt);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create DAP");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    }

    /* create submodules */
    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    }

    if (GOAL_RES_ERR(res)) {
        goal_logErr("error while module-setup");
    }
    else {
        goal_logInfo("PROFINET ready");
    }

    return res;
}


/****************************************************************************/
/** Create and Plug Device Access Point
 *
 * return GOAL_STATUS_T
 */
static GOAL_STATUS_T appl_dapCreate(
    uint16_t portCnt                            /**< one module for each port */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    uint8_t cnt;                                /* counter for ports */

    /* create submodules for DAP, interface and ports */
    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodNew(pPnio, mConfigDap.module, mConfigDap.submodule,
            GOAL_PNIO_MOD_TYPE_INPUT, 0, 0, GOAL_PNIO_FLG_AUTO_GEN);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubmodNew(pPnio, mConfigIface.module, mConfigIface.submodule,
            GOAL_PNIO_MOD_TYPE_INPUT, 0, 0, GOAL_PNIO_FLG_AUTO_GEN);
    }

    for (cnt = 0; cnt < portCnt && GOAL_RES_OK(res); cnt++) {
        res = goal_pnioSubmodNew(pPnio, mConfigPorts.module, mConfigPorts.submodule + cnt,
            GOAL_PNIO_MOD_TYPE_INPUT, 0, 0, GOAL_PNIO_FLG_AUTO_GEN);
    }

    /* create subslots for DAP, interface and ports */
    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubslotNew(pPnio, APPL_API, mConfigDap.slot, mConfigDap.subslot,
            GOAL_PNIO_FLG_AUTO_GEN);
    }

    if (GOAL_RES_OK(res)) {
        res = goal_pnioSubslotNew(pPnio, APPL_API, mConfigIface.slot, mConfigIface.subslot,
            GOAL_PNIO_FLG_AUTO_GEN);
    }

    for (cnt = 0; cnt < portCnt && GOAL_RES_OK(res); cnt++) {
        res = goal_pnioSubslotNew(pPnio, APPL_API, mConfigPorts.slot, mConfigPorts.subslot + cnt,
            GOAL_PNIO_FLG_AUTO_GEN);
    }

    /* plug submodules in subslots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, mConfigDap.slot, mConfigDap.subslot,
        mConfigDap.module, mConfigDap.submodule);

    res = goal_pnioSubmodPlug(pPnio, APPL_API, mConfigIface.slot, mConfigIface.subslot,
        mConfigIface.module, mConfigIface.submodule);

    for (cnt = 0; cnt < portCnt && GOAL_RES_OK(res); cnt++) {
        res = goal_pnioSubmodPlug(pPnio, APPL_API, mConfigPorts.slot, mConfigPorts.subslot + cnt,
            mConfigPorts.module, mConfigPorts.submodule + cnt);
    }

    return res;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    static GOAL_TIMESTAMP_T tsTout;             /* timeout timestamp */
    uint8_t iops;                               /* IO producer status */

    /* get current timestamp */
    tsCur = goal_timerTsGet();

    /* mirror output data from submod 0:2:1 to input data from submod 0:1:1 */
    if ((GOAL_TRUE == flgAppReady) && (tsTout <= tsCur)) {

        /* update timeout value */
        tsTout = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, dataDm, MODULE_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, dataDm, MODULE_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }

    }
}
