/** @file
 *
 * @brief
 * PROFINET Process Alert Example
 *
 * @details
 * Cyclically sends an process alarm that additionally transmits user specific
 * data to the controller.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define APPL_TIMEOUT_TRIGGER_VAL GOAL_TIMER_SEC /**< timeout trigger in ms */
#define APPL_TIMEOUT_PROCESS_ALERT_SET 10       /**< retrigger timeout 10 sec. */

#define MODULE_SIZE              64             /**< module sizes */
#define MAX_DATA_LENGHT          10             /**< user data lenght */
#define MAX_ALARM_PAYLOAD_LENGTH 28             /**< [MaintenanceItem],[DiagnosisItem] ^ AlarmItem */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */

#define APPL_ALARM_MANUFACTURER_DEMO_USI 0x00   /**< custom "User Structure Identifier" */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static void TriggerProcessAlert(
    void
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR ID */
static char data[MODULE_SIZE];                  /**< buffer for module data */
static GOAL_TIMESTAMP_T tsTout;                 /**< timeout timestamp */
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */
static GOAL_TIMESTAMP_T tsTout;                 /**< timeout trigger value */
static uint8_t ProcAlertData[MAX_DATA_LENGHT] = { 255, 2, 200, 4, 5, 6, 7, 8, 9, 10 }; /**< user data */


/****************************************************************************/
/** Application Main
 *
 * Build up the device structure and initialize the Profinet stack.
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * Setup slots/modules and link them together.
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* change the max alarm payload lenght for user specific values in config var */
    goal_pnioCfgDiagBufMaxDataSizeSet(MAX_ALARM_PAYLOAD_LENGTH);
    goal_pnioCfgNewIoDataCbSet(GOAL_TRUE);

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* initialize timeout timestamp */
    tsTout = goal_timerTsGet();

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, MODULE_SIZE, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration successful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Set diagnosis entry
 */
void TriggerProcessAlert(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

     goal_logInfo("sending process alert:\n");
     res = goal_pnioAlarmProcessSend(pPnio,
                                        APPL_API,
                                        APPL_SLOT_1,
                                        APPL_SLOT_1_SUB_1,
                                        APPL_ALARM_MANUFACTURER_DEMO_USI,
                                        MAX_DATA_LENGHT,
                                        ProcAlertData
                                        );


    if (GOAL_RES_ERR(res)) {
             goal_logErr("failed to send process alert");
             return;
    }
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        default:
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    static int cnt = 0;                         /* counter */
    GOAL_STATUS_T res;                          /* result */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    uint8_t iops;                               /* IO producer status */

    /* get current timestamp */
    tsCur = goal_timerTsGet();

    /* mirror output data from submod 0:2:1 to input data from submod 0:1:1 */
    if ((GOAL_TRUE == flgAppReady) && (tsTout <= tsCur)) {

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, data, MODULE_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, data, MODULE_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* make a cyclic trigger */
        cnt++;

            /* set diag entry after 40 seconds */
            if (0 == (cnt % APPL_TIMEOUT_PROCESS_ALERT_SET)) {
                TriggerProcessAlert();
                cnt = 0;
            }

            /* update timeout value */
        tsTout = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;
    }
}
