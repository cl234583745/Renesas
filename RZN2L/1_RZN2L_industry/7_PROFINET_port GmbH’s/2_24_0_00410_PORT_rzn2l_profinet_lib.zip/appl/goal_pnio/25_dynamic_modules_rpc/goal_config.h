/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic Open
 * Abstraction Layer (GOAL).
 *
 * For details see chapter "Build Configuration" in the documentation.
 *
 * @copyright
 * Copyright 2010-2021 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

#define GOAL_CONFIG_PNIO_MCTC_DP_AUTO 1         /* adding Data Provider to DM automatically */
#define GOAL_CONFIG_PNIO_MCTC_APDU_AUTO 1       /* adding APDU status to DM automatically */

#endif /* GOAL_CONFIG_H */
