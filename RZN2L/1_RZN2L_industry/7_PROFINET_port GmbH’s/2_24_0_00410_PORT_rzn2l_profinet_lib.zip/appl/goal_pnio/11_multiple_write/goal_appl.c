/** @file
 *
 * @brief
 * PROFINET Busy Record Handling Example
 *
 * @details
 * This example provides an example of how to store a read and a write request
 * and process them later. This helps for example when an answer to a request
 * takes a long time.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define APPL_TIMEOUT_TRIGGER_VAL GOAL_TIMER_SEC /**< timeout trigger in ms */
#define MODULE_SIZE         64                  /**< module sizes */
#define RECORD_DATA_TIMEOUT (900 * GOAL_TIMER_MSEC) /**< record answer timeout (0.9 s) */
#define WRITE_REQ_CALLB_MAX 10                  /**< number of stored write req callbacks */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */


/****************************************************************************/
/* Local Structures */
/****************************************************************************/
typedef struct {
    GOAL_BOOL_T used;                           /**< usage flag */
    GOAL_PNIO_CB_DATA_T dataCb;                 /**< callback data */
} WRITE_REQ_CALLB_T;


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


static GOAL_STATUS_T storeWriteRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static void answerWriteRequest(
    void
);

static void processNextWriteRequest(
    void
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR ID */
static char data[MODULE_SIZE];                  /**< buffer for module data */
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */
static GOAL_BOOL_T writeReqAvail = GOAL_FALSE;  /**< write request available flag */
static GOAL_TIMESTAMP_T tsReqWrite;             /**< write request timestamp */
static GOAL_TIMESTAMP_T tsIoCopy;               /**< IO data copy timestamp */
static WRITE_REQ_CALLB_T bufWriteReq[WRITE_REQ_CALLB_MAX]; /**< write request buffer */
static uint8_t writeProcIndex = 0;              /**< index of write request */


/****************************************************************************/
/** Application Main
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* initialize timestamps */
    tsIoCopy = goal_timerTsGet() + GOAL_TIMER_SEC;
    tsReqWrite = goal_timerTsGet() - 1;

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, MODULE_SIZE, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Process a write request
 *
 * Process the next write request
 */
static void processNextWriteRequest(
    void
)
{
    uint8_t cnt = 0;                            /* counter */

    while (!bufWriteReq[writeProcIndex].used) {
        writeProcIndex++;
        if (WRITE_REQ_CALLB_MAX <= writeProcIndex) {
            writeProcIndex = 0;
        }

        cnt++;
        if (WRITE_REQ_CALLB_MAX <= cnt) {
            writeReqAvail = GOAL_FALSE;
            return;
        }
    }

    tsReqWrite = goal_timerTsGet() + RECORD_DATA_TIMEOUT;
    writeReqAvail = GOAL_TRUE;
}


/****************************************************************************/
/** Store a write request for later processing
 *
 * @retval GOAL_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T storeWriteRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    static uint8_t storeIndex = 0;              /* buffer index */
    uint8_t cnt = 0;                            /* counter */

    goal_logInfo("CB: Write request for record %u at api %"FMT_u32", slot %u, subslot %u",
                 pCb->data[5].u16, pCb->data[2].u32, pCb->data[3].u16, pCb->data[4].u16);

    /* check if busy index is valid */
    if (GOAL_PNIO_REC_BUSY_IDX_UNDEF == pCb->data[8].i32) {
        return GOAL_ERR_UNSUPPORTED;
    }

    /*  find unused buffer slot to store callback data */
    while (bufWriteReq[storeIndex].used) {
        storeIndex++;
        if (WRITE_REQ_CALLB_MAX <= storeIndex) {
            storeIndex = 0;
        }

        cnt++;
        if (WRITE_REQ_CALLB_MAX <= cnt) {
            /* discard request */
            goal_logErr("CB: out of resources for write request");
            return GOAL_OK;
        }
    }

    bufWriteReq[storeIndex].used = GOAL_TRUE;
    GOAL_MEMCPY(&bufWriteReq[storeIndex].dataCb, pCb, sizeof(GOAL_PNIO_CB_DATA_T));

    /* index increment */
    storeIndex++;
    if (WRITE_REQ_CALLB_MAX <= storeIndex) {
        storeIndex = 0;
    }

    /* if there wasn't any remaining request, retrigger processing for new request */
    if (GOAL_FALSE == writeReqAvail) {
        processNextWriteRequest();
    }

    return GOAL_OK_SUPPORTED;
}


/****************************************************************************/
/** Answer a stored write request.
 */
static void answerWriteRequest(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* skip answering if no record is pending */
    if (GOAL_TRUE != writeReqAvail) {
        return;
    }

    /* answer request */
    res = goal_pnioRecWriteFinish(pPnio, bufWriteReq[writeProcIndex].dataCb.data[8].i32, NULL, bufWriteReq[writeProcIndex].dataCb.data[10].u32);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("CB: error while finishing write record");
    } else {
        goal_logInfo("CB: finished write record request");
    }

    /* remove stored request */
    GOAL_MEMSET(&bufWriteReq[writeProcIndex], 0, sizeof(WRITE_REQ_CALLB_T));

    /* process next request */
    processNextWriteRequest();
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_WRITE_RECORD:
            res = storeWriteRequest(pCb);
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    uint8_t iops;                               /* IO producer status */

    /* get current timestamp */
    tsCur = goal_timerTsGet();

    /* mirror output data from submod 0:2:1 to input data from submod 0:1:1 */
    if ((GOAL_TRUE == flgAppReady) && (tsIoCopy <= tsCur)) {

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, data, MODULE_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, data, MODULE_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* update timeout value */
        tsIoCopy = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;
    }

    /* if a write request was stored, answer it later */
    if ((GOAL_TRUE == writeReqAvail) && (tsReqWrite <= tsCur)) {
        answerWriteRequest();
    }
}
