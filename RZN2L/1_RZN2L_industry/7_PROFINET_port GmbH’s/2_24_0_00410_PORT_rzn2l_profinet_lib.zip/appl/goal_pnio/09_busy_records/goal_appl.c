/** @file
 *
 * @brief
 * PROFINET Busy Record Handling Example
 *
 * @details
 * This example provides an example of how to store a read and a write request
 * and process them later. This helps for example when an answer to a request
 * takes a long time.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define MODULE_SIZE         64                  /**< module sizes */

#define RECORD_DATA_LENGTH  3                   /**< record data length */
#define RECORD_DATA_TIMEOUT (5 * GOAL_TIMER_SEC) /**< record answer timeout (5 s) */

#define APPL_TIMEOUT_TRIGGER_VAL GOAL_TIMER_SEC /**< timeout trigger in ms */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static GOAL_STATUS_T storeReadRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static GOAL_STATUS_T storeWriteRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);

static void answerReadRequest(
    void
);

static void answerWriteRequest(
    void
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR id */
static char data[MODULE_SIZE];                  /**< buffer for module data */
static GOAL_PNIO_CB_DATA_T readReq;             /**< read request storage */
static GOAL_PNIO_CB_DATA_T writeReq;            /**< write request storage */
static GOAL_BOOL_T readReqAvail = GOAL_FALSE;   /**< read request available flag */
static GOAL_BOOL_T writeReqAvail = GOAL_FALSE;  /**< write request available flag */
static GOAL_TIMESTAMP_T readReqTs;              /**< read request timestamp */
static GOAL_TIMESTAMP_T writeReqTs;             /**< write request timestamp */
static uint8_t readReqData[RECORD_DATA_LENGTH] = { 1, 2, 3 }; /**< read request data */
static GOAL_TIMESTAMP_T tsTout;                 /**< timeout timestamp */
static GOAL_PNIO_T *pPnio = NULL;               /**< GOAL PROFINET handle */


/****************************************************************************/
/** Application Main
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* initialize timeouts */
    tsTout = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;
    readReqTs = goal_timerTsGet() - 1;
    writeReqTs = goal_timerTsGet() - 1;

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Store a read request for later processing
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T storeReadRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    /*
     * For a complete list of params, see IOD_CB_READ_RECORD
     * section in the PROFINET stack manual.
     */
    goal_logInfo("CB: Read request for record %u at api %"FMT_u32", slot %u, subslot %u",
               pCb->data[5].u16, pCb->data[2].u32, pCb->data[3].u16, pCb->data[4].u16);

    /* if the read request storage is used, discard request */
    if (GOAL_TRUE == readReqAvail) {
        goal_logErr("CB: out of resources for read request");
        return GOAL_OK;
    }

    /* store request */
    GOAL_MEMCPY(&readReq, pCb, sizeof(GOAL_PNIO_CB_DATA_T));
    readReqTs = goal_timerTsGet() + RECORD_DATA_TIMEOUT;
    readReqAvail = GOAL_TRUE;

    return GOAL_OK_SUPPORTED;
}


/****************************************************************************/
/** Store a write request for later processing
 *
 * @retval IOD_OK successful
 * @retval other failed
 */
static GOAL_STATUS_T storeWriteRequest(
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    /*
     * For a complete list of params, see IOD_CB_WRITE_RECORD
     * section in the PROFINET stack manual.
     */
    goal_logInfo("CB: Write request for record %u at api %"FMT_u32", slot %u, subslot %u",
               pCb->data[5].u16, pCb->data[2].u32, pCb->data[3].u16, pCb->data[4].u16);

    /* if the write request storage is used, discard request */
    if (GOAL_TRUE == writeReqAvail) {
        goal_logErr("CB: out of resources for write request");
        return GOAL_OK;
    }

    /* store request */
    GOAL_MEMCPY(&writeReq, pCb, sizeof(GOAL_PNIO_CB_DATA_T));
    writeReqTs = goal_timerTsGet() + RECORD_DATA_TIMEOUT;
    writeReqAvail = GOAL_TRUE;

    return GOAL_OK_SUPPORTED;
}


/****************************************************************************/
/** Answer a stored read request.
 */
static void answerReadRequest(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* skip answering if no record is pending */
    if (GOAL_TRUE != readReqAvail) {
        return;
    }

    /* answer request */
    res = goal_pnioRecReadFinish(pPnio, readReq.data[8].i32, NULL, readReqData, RECORD_DATA_LENGTH, readReq.data[9].u32);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("CB: error while finishing read record");
    } else {
        goal_logInfo("CB: finished read record request");
    }

    /* remove stored request */
    readReqAvail = GOAL_FALSE;
}


/****************************************************************************/
/** Answer a stored write request.
 */
static void answerWriteRequest(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_PNIO_STATUS_T statusPnio = { 0, 0, 0, 0 }; /* PNIO Status */

    /* skip answering if no record is pending */
    if (GOAL_TRUE != writeReqAvail) {
        return;
    }

    /* answer request */
    res = goal_pnioRecWriteFinish(pPnio, writeReq.data[8].i32, &statusPnio, writeReq.data[10].u32);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("CB: error while finishing write record");
    } else {
        goal_logInfo("CB: finished write record request");
    }

    /* remove stored request */
    writeReqAvail = GOAL_FALSE;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_READ_RECORD:
            return storeReadRequest(pCb);

        case GOAL_PNIO_CB_ID_WRITE_RECORD:
            return storeWriteRequest(pCb);
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    uint8_t iops;                               /* IO producer status */

    /* get current timestamp */
    tsCur = goal_timerTsGet();

    /* mirror output data from submod 0:2:1 to input data from submod 0:1:1 */
    if ((GOAL_TRUE == flgAppReady) && (tsTout <= tsCur)) {

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, data, MODULE_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, data, MODULE_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* update timeout value */
        tsTout = tsCur + APPL_TIMEOUT_TRIGGER_VAL;
    }

    /* if a read and/or write request was stored, answer it 10 s later */
    if ((GOAL_TRUE == readReqAvail) && (readReqTs <= tsCur)) {
        answerReadRequest();
    }

    if ((GOAL_TRUE == writeReqAvail) && (writeReqTs <= tsCur)) {
        answerWriteRequest();
    }
}
