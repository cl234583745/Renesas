/** @file
 *
 * @brief
 * PROFINET Advanced I/O Demonstration
 *
 * @details
 * This application shows how to handle input and output data. To use this
 * application the PLC has to be preconfigured.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID            0               /**< PROFINET id */

#define MODULE_SIZE 64                          /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */

#define APPL_DEMO_SHIFT_BIT     0               /* choose the bit to set in a byte of the input data */
#define APPL_DEMO_SHIFT_BYTE    16              /* choose the byte in which a bit shall be set */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR id */
static GOAL_BOOL_T flgIoCycle = GOAL_FALSE;     /**< flag for IO cycle start */
static char dataInput[MODULE_SIZE];             /**< buffer for input module data */
static char dataOutput[MODULE_SIZE];            /**< buffer for output module data */
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    /* initialize PROFINET */
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * Setup slots/modules and link them together.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, MODULE_SIZE, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_NEW_IO_DATA:
            /* tell application that a new cycle begins */
            flgIoCycle = GOAL_TRUE;
            break;

        default:
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    static unsigned int cntLoop = 0;            /* loop counter */
    static uint32_t cntButton = 0;              /* counts how many loops a button was pressed */
    static uint8_t bitDemoshift = APPL_DEMO_SHIFT_BIT; /* choose the bit to set in a byte of the input data */
    static uint8_t byteDemoshift = APPL_DEMO_SHIFT_BYTE; /* choose the byte in which a bit shall be set */
    GOAL_STATUS_T res;                          /* result */
    uint8_t iops;                               /* IO producer status */
    uint32_t stateButtons;                      /* pressed buttons (bitcoded) */
    uint32_t stateLeds;                         /* which LED to activate (bitcoded) */

    /* Demo Application
     *  - first bytes of consumed data is mapped to the LEDs
     *  - Buttons are mapped to the produced data
     *  - produced data also contains various counters */
    if (GOAL_TRUE == flgAppReady) {

        /* count the loops */
        cntLoop++;

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, dataOutput, MODULE_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* map bytes 0 to 3 to the LEDs */
        stateLeds = GOAL_be32toh_p((uint8_t *) dataOutput);
        goal_targetSetLeds(stateLeds);

        /* read buttons */
        stateButtons = goal_targetGetButtons();

        /* mirror buttons to first 4 bytes of input data */
        GOAL_htobe32_p((uint8_t *) dataInput, stateButtons);

        /* mirror Bytes 4 to 7 back to the IO Master */
        GOAL_MEMCPY(&dataInput[4], &dataOutput[4], sizeof(uint32_t));

        /* bytes 8 to 11 contain a loop counter */
        GOAL_htobe32_p((uint8_t *) &dataInput[8], cntLoop);

        /* increment counter, if button was pressed */
        if ((0 != stateButtons) && (0xffffffff > cntButton)) {
            cntButton++;
        }

        /* button counter is in bytes 12..15 of input data */
        GOAL_htobe32_p((uint8_t *) &dataInput[12], cntButton);

        /* shift bit from bit 0 of byte 16 to bit 7 of byte 63 each IO cycle */
        if (GOAL_TRUE == flgIoCycle) {
            flgIoCycle = GOAL_FALSE;

            if (7 < bitDemoshift) {

                /* change current byte to 0 and set bit of next byte */
                dataInput[byteDemoshift] = 0;
                bitDemoshift = 0;
                if (63 == byteDemoshift) {
                    byteDemoshift = 16;
                }
                else {
                    byteDemoshift++;
                }
                dataInput[byteDemoshift] = (char) (1 << bitDemoshift);
            }
            else {
                /* shift trough current byte */
                dataInput[byteDemoshift] = (char) (1 << bitDemoshift);
                bitDemoshift++;
            }
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, dataInput, MODULE_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }
    }
}
