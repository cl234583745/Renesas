/** @file
 *
 * @brief
 * PROFINET Alarm Button Example
 *
 * @details
 * This example shows how to trigger an alarm by pressing a button. The
 * OAL_getButtons API must be supported by the target.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */

#define MODULE_SIZE         64                  /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR id */
static GOAL_PNIO_T *pPnio = NULL;               /**< GOAL PROFINET handle */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return goal_pnioInit();
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, MODULE_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, MODULE_SIZE, MODULE_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_ALARM_NOTIFY:
            goal_logInfo("AlarmNotification received in application");

            goal_logInfo("AlarmNotification: Priority: %s", (GOAL_PNIO_ALARM_PRIO_HIGH == pCb->data[1].u32) ? "high" : "low");
            goal_logInfo("AlarmNotification: API: %"FMT_u32, pCb->data[2].pAlarmNotify->idApi);
            goal_logInfo("AlarmNotification: Slot: %u", pCb->data[2].pAlarmNotify->idSlot);
            goal_logInfo("AlarmNotification: SubSlot: %u", pCb->data[2].pAlarmNotify->idSubslot);
            goal_logInfo("AlarmNotification: ModuleIdentNumber: %"FMT_u32, pCb->data[2].pAlarmNotify->idMod);
            goal_logInfo("AlarmNotification: SubmoduleIdentNumber: %"FMT_u32, pCb->data[2].pAlarmNotify->idSubmod);
            goal_logInfo("AlarmNotification: AlarmSpecifier: 0x%04x", pCb->data[2].pAlarmNotify->specAlarm);
            goal_logInfo("AlarmNotification: SequenceNumber: %u", pCb->data[2].pAlarmNotify->nrSeq);
            goal_logInfo("AlarmNotification: UserData Length: %u", pCb->data[3].u16);
            break;

        case GOAL_PNIO_CB_ID_ALARM_NOTIFY_ACK:
            goal_logInfo("AlarmNotification-Ack received in application");

            goal_logInfo("AlarmNotification-Ack: Priority: %s", (GOAL_PNIO_ALARM_PRIO_HIGH == pCb->data[1].u32) ? "high" : "low");
            goal_logInfo("AlarmNotification-Ack: API: %"FMT_u32, pCb->data[2].pAlarmNotifyAck->idApi);
            goal_logInfo("AlarmNotification-Ack: Slot: %u", pCb->data[2].pAlarmNotifyAck->idSlot);
            goal_logInfo("AlarmNotification-Ack: SubSlot: %u", pCb->data[2].pAlarmNotifyAck->idSubslot);
            goal_logInfo("AlarmNotification-Ack: AlarmSpecifier: 0x%04x", pCb->data[2].pAlarmNotifyAck->specAlarm);
            goal_logInfo("AlarmNotification-Ack: SequenceNumber: %u", pCb->data[2].pAlarmNotifyAck->nrSeq);

            goal_logInfo("AlarmNotification-Ack: PNIOStatus: 0x%02x, 0x%02x, 0x%02x, 0x%02x",
                       pCb->data[2].pAlarmNotifyAck->status.code,
                       pCb->data[2].pAlarmNotifyAck->status.decode,
                       pCb->data[2].pAlarmNotifyAck->status.code1,
                       pCb->data[2].pAlarmNotifyAck->status.code2);

            break;

        case GOAL_PNIO_CB_ID_ALARM_ACK_TIMEOUT:
            goal_logInfo("Alarm-ACK timeout, AR: %"FMT_u32, pCb->data[0].idAr);
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_PNIO_ALARM_NOTIFY_T dataAlarmNotify;   /* alarm notification */
    uint16_t seqAlarmNotify = 0;                /* alarm notification sequence */

    if ((GOAL_TRUE == flgAppReady) && (goal_targetGetButtons())) {

        GOAL_MEMSET(&dataAlarmNotify, 0, sizeof(GOAL_PNIO_ALARM_NOTIFY_T));

        dataAlarmNotify.typeAlarm = GOAL_PNIO_ALARM_TYPE_PROCESS;
        dataAlarmNotify.idApi = APPL_API;
        dataAlarmNotify.idSlot = APPL_SLOT_1;
        dataAlarmNotify.idSubslot = APPL_SLOT_1_SUB_1;
        dataAlarmNotify.idMod = APPL_MOD_1;
        dataAlarmNotify.idSubmod = APPL_MOD_1_SUB_1;

        res = goal_pnioAlarmNotifySend(pPnio, &seqAlarmNotify, idAr, GOAL_PNIO_ALARM_PRIO_LOW, &dataAlarmNotify, 0, NULL);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to send alarm notification.");
        }

        goal_logInfo("Alarm submission: %s", (GOAL_RES_OK(res)) ? "successful" : "failed");
    }
}
