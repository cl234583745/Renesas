/** @file
 *
 * @brief
 * PROFINET Simple I/O Example
 *
 * @details
 * This example provides a possible test environment for a simplified
 * conformance test.
 *
 * @copyright
 * Copyright 2010-2017 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>
#include <goal_snmp.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET id */
#define APPL_SNMP_ID        0                   /**< SNMP id */

#define APPL_TIMEOUT_TRIGGER_VAL GOAL_TIMER_SEC /**< timeout trigger in ms */
#define APPL_MOD_SIZE       64                  /**< module sizes */

#define APPL_API            0                   /**< API 0 */

#define APPL_SLOT_1         1                   /**< slot 1 */
#define APPL_SLOT_1_SUB_1   1                   /**< submodule for slot 1 */
#define APPL_SLOT_2         2                   /**< slot 2 */
#define APPL_SLOT_2_SUB_1   1                   /**< submodule for slot 2 */

#define APPL_MOD_1          0x30                /**< module 1 */
#define APPL_MOD_1_SUB_1    0x01                /**< submodule for module 1 */
#define APPL_MOD_2          0x31                /**< module 2 */
#define APPL_MOD_2_SUB_1    0x01                /**< submodule for module 2 */
#define APPL_MOD_3          0x32                /**< module 3 */
#define APPL_MOD_3_SUB_1    0x01                /**< submodule for module 3 */

#define APPL_ADDR_TRAPSINK  GOAL_NET_IPV4(192, 168, 0, 33) /**< trap sink address */


/****************************************************************************/
/* Local Prototypes */
/****************************************************************************/
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pPnio,                         /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
);


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_BOOL_T flgAppReady = GOAL_FALSE;    /**< app ready flag */
static GOAL_PNIO_AR_ID_T idAr = 0;              /**< AR ID */
static char data[APPL_MOD_SIZE];                /**< buffer for module data */
static GOAL_TIMESTAMP_T tsTout;                 /**< timeout timestamp */
static GOAL_PNIO_T *pPnio;                      /**< GOAL PROFINET handle */
static GOAL_INSTANCE_SNMP_T *pInstanceSnmp;     /**< GOAL_SNMP handle */
static char *strReadCommunity = "public";       /**< read community */
static char *strWriteCommunity = "private";     /**< write community */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* initialize PROFINET */
    res = goal_pnioInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of PROFINET failed");
        return res;
    }

    /* initialize SNMP */
    res = goal_snmpInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to initialize SNMP");
    }

    return res;
}


/****************************************************************************/
/** Create the device configuration (slots/modules/params).
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* create new SNMP instance */
    res = goal_snmpNew(&pInstanceSnmp, APPL_SNMP_ID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new SNMP instance");
        return res;
    }

    /* configure SNMP instance id */
    res = goal_pnioCfgSnmpIdSet(APPL_SNMP_ID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to set SNMP instance id");
        return res;
    }

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, appl_pnioCb);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    /* update SNMP community strings */
    res = goal_snmpCommSet(pInstanceSnmp, strReadCommunity, strWriteCommunity);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to register community strings stack");
        return res;
    }

    /* init trap incl. sending cold start trap */
    res = goal_snmpTrapsInit(pInstanceSnmp, APPL_ADDR_TRAPSINK);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to init SNMP traps");
        return res;
    }

    /* initialize timeout timestamp */
    tsTout = goal_timerTsGet();

    goal_logInfo("Initializing device structure");

    /* create subslots */
    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    res = goal_pnioSubslotNew(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add subslot");
        return res;
    }

    /* create submodules */
    res = goal_pnioSubmodNew(pPnio, APPL_MOD_1, APPL_MOD_1_SUB_1, GOAL_PNIO_MOD_TYPE_INPUT, APPL_MOD_SIZE, 0, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_2, APPL_MOD_2_SUB_1, GOAL_PNIO_MOD_TYPE_OUTPUT, 0, APPL_MOD_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    res = goal_pnioSubmodNew(pPnio, APPL_MOD_3, APPL_MOD_3_SUB_1, GOAL_PNIO_MOD_TYPE_IO, APPL_MOD_SIZE, APPL_MOD_SIZE, GOAL_PNIO_FLG_AUTO_GEN);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to add submodule");
        return res;
    }

    /* plug modules into slots */
    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, APPL_MOD_1, APPL_MOD_1_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    res = goal_pnioSubmodPlug(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, APPL_MOD_2, APPL_MOD_2_SUB_1);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to plug submodule");
        return res;
    }

    /* PROFINET configuration succesful */
    goal_logInfo("PROFINET ready");

    return GOAL_OK;
}


/****************************************************************************/
/** Profinet Callback Handler
 *
 * This function collects all callbacks from the stack and decides if the
 * callback must be handled.
 */
static GOAL_STATUS_T appl_pnioCb(
    GOAL_PNIO_T *pHdlPnio,                      /**< PROFINET handle */
    GOAL_PNIO_CB_ID_T id,                       /**< callback id */
    GOAL_PNIO_CB_DATA_T *pCb                    /**< callback parameters */
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* return value */

    UNUSEDARG(pHdlPnio);

    /* handle callback IDs */
    switch (id) {

        case GOAL_PNIO_CB_ID_APPL_READY:
            /* application ready was confirmed, start data handling if not
             * already running */
            if (GOAL_TRUE != flgAppReady) {
                flgAppReady = GOAL_TRUE;
                idAr = pCb->data[0].idAr;
            }
            break;

        case GOAL_PNIO_CB_ID_RELEASE_AR:
            /* AR was released, stop data handling if it was the first AR */
            if (idAr == pCb->data[0].idAr) {
                flgAppReady = GOAL_FALSE;
                idAr = 0;
            }
            break;

        case GOAL_PNIO_CB_ID_BLINK:
            goal_targetSetLeds((pCb->data[1].stateDcpLight) ? UINT32_MAX : 0);
            break;

        case GOAL_PNIO_CB_ID_FACTORY_RESET:
        case GOAL_PNIO_CB_ID_RESET_TO_FACTORY:
            break;

        default:
            break;
    }

    return res;
}


/****************************************************************************/
/** Main Loop
 *
 * This function must implement the application logic and must not block. It is
 * called in a loop (the GOAL loop) and if state tracking is necessary it
 * should use static or global variables.
 */
void appl_loop(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_TIMESTAMP_T tsCur;                     /* current timestamp */
    uint8_t iops;                               /* IO producer status */

    /* get current timestamp */
    tsCur = goal_timerTsGet();

    /* mirror output data from submod 0:2:1 to input data from submod 0:1:1 */
    if ((GOAL_TRUE == flgAppReady) && (tsTout <= tsCur)) {

        /* read data from output module */
        res = goal_pnioDataOutputGet(pPnio, APPL_API, APPL_SLOT_2, APPL_SLOT_2_SUB_1, data, APPL_MOD_SIZE, &iops);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* copy data to input module */
        res = goal_pnioDataInputSet(pPnio, APPL_API, APPL_SLOT_1, APPL_SLOT_1_SUB_1, data, APPL_MOD_SIZE, GOAL_PNIO_IOXS_GOOD);
        if (GOAL_RES_ERR(res)) {
            return;
        }

        /* update timeout value */
        tsTout = goal_timerTsGet() + APPL_TIMEOUT_TRIGGER_VAL;
    }
}
