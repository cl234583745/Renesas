/** @file
 *
 * @brief
 * PROFINET Pre-Configuration Example
 *
 * @details
 * This example shows how to set the most common PROFINET configuration
 * variables.
 *
 * @copyright
 * Copyright 2010-2018 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <goal_pnio.h>


/****************************************************************************/
/* Local Defines */
/****************************************************************************/
#define APPL_PNIO_ID        0                   /**< PROFINET instance id */


/****************************************************************************/
/* Local Variables */
/****************************************************************************/
static GOAL_PNIO_T *pPnio;                      /**< PROFINET instance */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* initialize PROFINET */
    res = goal_pnioInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of PROFINET failed");
    }

    return res;
}


/****************************************************************************/
/** Application Setup
 *
 * Show the most common PROFINET configuration settings.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* Vendor Id */
    res = goal_pnioCfgVendorIdSet(GOAL_PNIO_CFG_ID_VENDOR);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device Id */
    res = goal_pnioCfgDeviceIdSet(GOAL_PNIO_CFG_ID_DEVICE);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Vendor Name */
    res = goal_pnioCfgVendorNameSet(GOAL_PNIO_CFG_STR_VENDOR);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Port Name */
    res = goal_pnioCfgPortNameSet(GOAL_PNIO_CFG_STR_PORT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* System Description */
    res = goal_pnioCfgSystemDescSet(GOAL_PNIO_CFG_STR_SYSTEM);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Order Id */
    res = goal_pnioCfgOrderIdSet(GOAL_PNIO_CFG_STR_ID_ORDER);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Serial Number */
    res = goal_pnioCfgSerialNumSet(GOAL_PNIO_CFG_STR_NUM_SERIAL);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Hardware Revision */
    res = goal_pnioCfgHwRevSet(GOAL_PNIO_CFG_ID_REV_HW);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Software Revision Prefix */
    res = goal_pnioCfgSwRevPrefixSet(GOAL_PNIO_CFG_CHR_REV_SW_PREFIX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Software Revision Functional Enhancement */
    res = goal_pnioCfgSwRevFuncEnhSet(GOAL_PNIO_CFG_ID_REV_SW_FUNC_ENH);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Software Revision Bugfix */
    res = goal_pnioCfgSwRevBugfixSet(GOAL_PNIO_CFG_ID_REV_SW_BUGFIX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Software Revision Internal Change */
    res = goal_pnioCfgSwRevIntChgSet(GOAL_PNIO_CFG_ID_REV_SW_INT_CHG);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Software Revision Count */
    res = goal_pnioCfgSwRevCntSet(GOAL_PNIO_CFG_ID_REV_SW_REV_CNT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 1 Tag Function */
    res = goal_pnioCfgIm1TagFuncSet(GOAL_PNIO_CFG_STR_IM_1_TAG_FUNC);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 1 Tag Location */
    res = goal_pnioCfgIm1TagLocSet(GOAL_PNIO_CFG_STR_IM_1_TAG_LOC);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 2 Date */
    res = goal_pnioCfgIm2DateSet(GOAL_PNIO_CFG_STR_IM_2_DATE);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 3 Description */
    res = goal_pnioCfgIm3DescSet(GOAL_PNIO_CFG_STR_IM_3_DESC);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 4 Signature */
    res = goal_pnioCfgIm4SigSet(GOAL_PNIO_CFG_STR_IM_4_SIG);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP Simple Mode */
    res = goal_pnioCfgDevDapSimpleSet(GOAL_PNIO_CFG_FLG_DEV_DAP_SIMPLE);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP API */
    res = goal_pnioCfgDevDapApiSet(GOAL_PNIO_CFG_ID_DEV_DAP_API);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP Slot */
    res = goal_pnioCfgDevDapSlotSet(GOAL_PNIO_CFG_ID_DEV_DAP_SLOT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP Subslot */
    res = goal_pnioCfgDevDapSubslotSet(GOAL_PNIO_CFG_ID_DEV_DAP_SUBSLOT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP Module */
    res = goal_pnioCfgDevDapModuleSet(GOAL_PNIO_CFG_ID_DEV_DAP_MOD);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Device DAP Submodule */
    res = goal_pnioCfgDevDapSubmoduleSet(GOAL_PNIO_CFG_ID_DEV_DAP_SUBMOD);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* New IO Data Callback */
    res = goal_pnioCfgNewIoDataCbSet(GOAL_PNIO_CFG_FLG_CB_NEW_IO_DATA);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* LLDP Generate MAC Addresses */
    res = goal_pnioCfgLldpGenMacSet(GOAL_PNIO_CFG_FLG_LLDP_GEN_MAC);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 1-4 Support */
    res = goal_pnioCfgIm14SupportSet(GOAL_PNIO_CFG_FLG_IM_1_4_SUPPORT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 1-4 Callback */
    res = goal_pnioCfgIm14CbSet(GOAL_PNIO_CFG_FLG_IM_1_4_CB);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 0 Callback */
    res = goal_pnioCfgIm0CbSet(GOAL_PNIO_CFG_FLG_IM_0_CB);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* I&M 0 FilterData Callback */
    res = goal_pnioCfgIm0FilterDataCbSet(GOAL_PNIO_CFG_FLG_IM_0_FILTER_CB);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Record Data Storage Size */
    res = goal_pnioCfgRecDataBusyBufsizeSet(GOAL_PNIO_CFG_CNT_REC_DATA_BUSY_BUFSIZE);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* RPC Fragmentation Maximum Request Length */
    res = goal_pnioCfgRpcFragReqLenMaxSet(GOAL_PNIO_CFG_SIZE_RPC_FRAG_MAX_REQ_LEN);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* RPC Fragment Support Enable */
    res = goal_pnioCfgRpcFragEnableSet(GOAL_PNIO_CFG_FLG_RPC_FRAG_SUPPORT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* RPC Session Maximum Count */
    res = goal_pnioCfgRpcSessionMaxCntSet(GOAL_PNIO_CFG_NUM_RPC_SESSIONS);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Diagnosis Maximum Buffer Count */
    res = goal_pnioCfgDiagBufMaxCntSet(GOAL_PNIO_CFG_NUM_DIAG_BUF_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Diagnosis Maximum Data Size */
    res = goal_pnioCfgDiagBufMaxDataSizeSet(GOAL_PNIO_CFG_NUM_DIAG_DATA_SIZE_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* IOCR Maximum Blocks */
    res = goal_pnioCfgIocrBlocksMaxSet(GOAL_PNIO_CFG_NUM_IOCR_BLOCKS_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Communication Relation Maximum Count */
    res = goal_pnioCfgCrMaxCntSet(GOAL_PNIO_CFG_NUM_CR_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Application Relation Maximum Count */
    res = goal_pnioCfgArMaxCntSet(GOAL_PNIO_CFG_NUM_AR_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* API Maximum Count */
    res = goal_pnioCfgApiMaxCntSet(GOAL_PNIO_CFG_NUM_API_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Slot Maximum Count */
    res = goal_pnioCfgSlotMaxCntSet(GOAL_PNIO_CFG_NUM_SLOT_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Subslot Maximum Count */
    res = goal_pnioCfgSubslotMaxCntSet(GOAL_PNIO_CFG_NUM_SUBSLOT_MAX);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Interface Subslot */
    res = goal_pnioCfgSubslotIfSet(GOAL_PNIO_CFG_ID_SUBSLOT_IF);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* Port Subslot */
    res = goal_pnioCfgSubslotPortSet(GOAL_PNIO_CFG_ID_SUBSLOT_PORT);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    /* create new PROFINET instance */
    res = goal_pnioNew(&pPnio, APPL_PNIO_ID, NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new PROFINET instance");
        return res;
    }

    return res;
}
