/** @file
 *
  * @brief header for goal LM usage example
 *
 * This application demonstrates the integration of LM and some log messages
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_APPL_H
#define GOAL_APPL_H

#include <goal_includes.h>


/****************************************************************************/
/* Defines */
/****************************************************************************/

#define APPL_VERSION "0.0.0.1"

#endif /* GOAL_APPL_H */

