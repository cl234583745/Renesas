/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic Open
 * Abstraction Layer (GOAL).
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

#define GOAL_CONFIG_ETHERNET 1
#define GOAL_CONFIG_TCPIP_STACK 1

#define GOAL_CONFIG_LOGGING 1
#define GOAL_CONFIG_LOGGING_TARGET_RAW 1

#define GOAL_CONFIG_CLI_UART 1
#define GOAL_CONFIG_CLI_DBG 1
#define GOAL_CONFIG_CLI_HISTORY 1
#define GOAL_CONFIG_CLI_HISTORY_SIZE 10

#endif /* GOAL_CONFIG_H */
