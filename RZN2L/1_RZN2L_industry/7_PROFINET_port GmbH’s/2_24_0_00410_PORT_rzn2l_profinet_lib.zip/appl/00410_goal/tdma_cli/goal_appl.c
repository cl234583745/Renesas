/** @file
 *
 * @brief Command Line Interface Example
 *
 * This application basically initializes the Command Line interface (CLI).
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"
#include <goal_gptp_includes.h>
#include <goal_dd.h>
#include <goal_appl.h>
#include "goal_dd_config.h"


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define MAIN_APPL_IP            GOAL_NET_IPV4(192, 168, 0, 10)
#define MAIN_APPL_NM            GOAL_NET_IPV4(255, 255, 255, 0)
#define MAIN_APPL_GW            GOAL_NET_IPV4(0, 0, 0, 0)
#define MAIN_APPL_UDP_PORT      44444
#define MAIN_APPL_TOS           0xE0

/* TDMA config values */
#define TDMA_CYCLE_TIME         400             /**< TDMA cycle time in us */
#define TDMA_TSLT_NUM             4             /**< number of configured timeslots */
#define TDMA_OFFSET_TS0           0             /**< start of time slot 0 in us */
#define TDMA_OFFSET_TS1         100             /**< start of time slot 1 in us */
#define TDMA_OFFSET_TS2         200             /**< start of time slot 2 in us */
#define TDMA_OFFSET_TS3         300             /**< start of time slot 3 in us */
#define TDMA_QUEUES_TS0         1               /**< queues allowed to transmit during time slot 0 */
#define TDMA_QUEUES_TS1         (1 | 2)         /**< queues allowed to transmit during time slot 1 */
#define TDMA_QUEUES_TS2         (1 | 4)         /**< queues allowed to transmit during time slot 2 */
#define TDMA_QUEUES_TS3         (1 | 3)         /**< queues allowed to transmit during time slot 3 */
#define TDMA_PORTS              (GOAL_ETH_PORT_BIT(0) | GOAL_ETH_PORT_BIT(1)) /**< ports used for TDAM scheduling */
#define TDMA_START_CYCLE_OFFSET 10              /**< number of cycles to wait before starting scheduling */


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static PTP_TIMEPROPERTIES_DS_T myTimeProps;     /**< time properties of this device */
static GOAL_STAGE_HANDLER_T stageCmModReg;      /**< CM module register stage */
static GOAL_STAGE_HANDLER_T stageCmModAdd;      /**< CM module add stage */
static GOAL_CM_MODDEF_T cmMod = GOAL_CM_MODDEF(APPL_CM_MOD_ID, "APPL_MODULE"); /**< CM module definition */
/** timeslot start offsets */
static uint32_t tsltStart[TDMA_TSLT_NUM] = {
    TDMA_OFFSET_TS0,
    TDMA_OFFSET_TS1,
    TDMA_OFFSET_TS2,
    TDMA_OFFSET_TS3
};
/** timeslot queue assignments */
static uint32_t tsltQueues[TDMA_TSLT_NUM] = {
    TDMA_QUEUES_TS0,
    TDMA_QUEUES_TS1,
    TDMA_QUEUES_TS2,
    TDMA_QUEUES_TS3
};


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
void goal_ptpCallback(
    PTP_CB_ID_T cbId,                           /**< callback ID */
    void *pCbData                               /**< callback data */
);

static GOAL_STATUS_T ddCallback(
    GOAL_DD_T *pHdlDd,                          /**< DD handle */
    GOAL_DD_CB_ID_T cbId,                       /**< callback ID */
    GOAL_DD_CB_DATA_T *pCbData                  /**< callback data */
);

static GOAL_STATUS_T appl_cmModReg(
    void
);

static GOAL_STATUS_T appl_cmModAdd(
    void
);

GOAL_STATUS_T appl_cmChg(
    uint32_t modId,                             /**< module ID */
    uint32_t varId,                             /**< variable Id */
    GOAL_CM_VAR_T *pVar                         /**< variable pointer */
);

static void goal_udpServerCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T *pBuf                         /**< GOAL buffer */
);

static GOAL_STATUS_T goal_applEthCallback(
    GOAL_BUFFER_T **ppBuf                       /**< Ethernet buffer */
);

static GOAL_STATUS_T goal_tdmaCb(
    void *pArg,                                 /**< user specific argument */
    uint32_t tdmaEventMask                      /**< TMDA event mask */
);

static GOAL_STATUS_T goal_tdmaInit(
    void
);

static GOAL_STATUS_T goal_tdmaStart(
    void
);

/* generate 'GOAL_CM_VARENTRY_T cmVars[]' array that maps the above table */
#include <goal_cm_t.h>
GOAL_CM_VARLIST(cmVars, APPL_CM_VARS);


/****************************************************************************/
/** Register Application Configuration Variables
 *
 * This function is called by GOAL init-stage system to register its
 * configuration management variables.
 *
 * API functions from earlier stages are allowed to be used here.
 */
static GOAL_STATUS_T appl_cmModReg(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* register application variables */
    res = goal_cmRegModule(cmVars);

    return res;
}


/****************************************************************************/
/** Add Application Configuration Module
 *
 * This function is called by GOAL init-stage system to add the application
 * module to configuration mangement.
 *
 * API functions from earlier stages are allowed to be used here.
 */
static GOAL_STATUS_T appl_cmModAdd(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* add application variables */
    res = goal_cmAddModule(&cmMod, cmVars, NULL, NULL, NULL);

    return res;
}


/****************************************************************************/
/** Handle Configuration Variable Changes
 *
 * This function is called by the configuration management when a variable was
 * changed.
 */
GOAL_STATUS_T appl_cmChg(
    uint32_t modId,                             /**< module ID */
    uint32_t varId,                             /**< variable Id */
    GOAL_CM_VAR_T *pVar                         /**< variable pointer */
)
{
    UNUSEDARG(pVar);

#if GOAL_CONFIG_LOGGING == 0
    UNUSEDARG(modId);
    UNUSEDARG(varId);
#endif

    goal_logInfo("variable %" FMT_u32 ":%" FMT_u32 " was changed", modId, varId);

    return GOAL_OK;
}


/****************************************************************************/
/** Application Init
 *
 * This function initializes the DD, CLI, PTP and GOAL.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* register CM reg stage handler */
    res = goal_mainStageReg(GOAL_STAGE_CM_MOD_REG, &stageCmModReg, GOAL_STAGE_INIT, appl_cmModReg);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register CM reg stage handler");
        return res;
    }

    /* register CM add stage handler */
    res = goal_mainStageReg(GOAL_STAGE_CM_MOD_ADD, &stageCmModAdd, GOAL_STAGE_INIT, appl_cmModAdd);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to register CM add stage handler");
        return res;
    }

    /* Init DD */
    res = goal_ddInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Initialization of GOAL dd failed");
        return res;
    }

    /* initialize CLI */
    res = goal_cliInit(NULL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to initialize CLI");
        return res;
    }

    /* initialize PTP stack */
    res = goal_gptpInit(goal_ptpCallback);
    if (GOAL_RES_ERR(res)) {
        return res;
    }

    return res;
}


/****************************************************************************/
/** TDMA scheduler initialization
 *
 * This function is called after GOAL initialization to setup the TDMA
 * scheduler incl. cycle time and an event callback
 */
static GOAL_STATUS_T goal_tdmaInit(
    void
)
{
    GOAL_ETH_TDMA_CONFIG_T config;              /* TDMA config */
    GOAL_ETH_TDMA_TSLT_CFG_T tsltCfg;           /* timeslot configuration */
    GOAL_STATUS_T res;                          /* result */
    uint8_t cnt;                                /* loop counter */

    /* Set TDMA configuration */
    config.tdmaPorts = TDMA_PORTS | GOAL_ETH_PORT_MASK;
    config.tdmaCycleTime = TDMA_CYCLE_TIME;
    config.eventMask = GOAL_ETH_TDMA_EVENT_T1 | GOAL_ETH_TDMA_EVENT_T2 | GOAL_ETH_TDMA_EVENT_T3 | GOAL_ETH_TDMA_EVENT_EOC;
    config.cb = goal_tdmaCb;
    config.pArg = NULL;

    res = goal_ethCmd(GOAL_ETH_CMD_TDMA_CONFIG, GOAL_TRUE, GOAL_ETH_PORT_HOST, &config);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Setting config of TDMA failed");
    }

    for (cnt = 0; (cnt < TDMA_TSLT_NUM) && GOAL_RES_OK(res); cnt++) {
        tsltCfg.timeslotNum = cnt;
        tsltCfg.startOffset = tsltStart[cnt];
        tsltCfg.queueMsk = tsltQueues[cnt];
        tsltCfg.guardBand = 0;

        res = goal_ethCmd(GOAL_ETH_CMD_TDMA_TSLT_CFG, GOAL_TRUE, GOAL_ETH_PORT_HOST, &tsltCfg);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Setting timeslot %u of TDMA failed", cnt);
        }
    }

    return res;
}


/****************************************************************************/
/** Start TDMA scheduler
 *
 * This function calculates the start time and enables the TDMA scheduler
 */
static GOAL_STATUS_T goal_tdmaStart(
    void
)
{
    PTP_TIMESTAMP_T ptpTime;                    /* PTP timestamp */
    GOAL_STATUS_T res;                          /* result */
    GOAL_ETH_TDMA_ENABLE_T tdmaEnable;          /* TDMA enable settings */
    uint64_t cycleTimeNs;                       /* TDAM cycle time in ns */

    cycleTimeNs = GOAL_TIME_US_TO_NS(TDMA_CYCLE_TIME);
    ptp_getCurrentTime(&ptpTime);

    /* adjust start time to start of a global cycle */
    tdmaEnable.tdmaStartTime = ptpTime.nsec / cycleTimeNs;
    tdmaEnable.tdmaStartTime = (tdmaEnable.tdmaStartTime + TDMA_START_CYCLE_OFFSET) * cycleTimeNs;
    tdmaEnable.enable = GOAL_TRUE;

    res = goal_ethCmd(GOAL_ETH_CMD_TDMA_ENABLE, GOAL_TRUE, GOAL_ETH_PORT_HOST, &tdmaEnable);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to start TDMA scheduler");
    }

    return res;
}


/****************************************************************************/
/** TDMA Event callback
 *
 * This callback is invoked every time a TDMA event occurs (end of T1, end of
 * T2, end of T3, end of cycle).
 */
static GOAL_STATUS_T goal_tdmaCb(
    void *pArg,                                 /**< user specific argument */
    uint32_t tdmaEventMask                      /**< TMDA event mask */
)
{
    UNUSEDARG(pArg);

    /* End of T1 */
    if (GOAL_ETH_TDMA_EVENT_T1 & tdmaEventMask) {
        /* Process end of T1 here */
    }

    /* End of T2 */
    if (GOAL_ETH_TDMA_EVENT_T2 & tdmaEventMask) {
        /* Process end of T2 here */
    }

    /* End of T3 */
    if (GOAL_ETH_TDMA_EVENT_T3 & tdmaEventMask) {
        /* Process end of T3 here */
    }

    /* End of Cycle */
    if (GOAL_ETH_TDMA_EVENT_EOC & tdmaEventMask) {
        /* Process end of cycle here */
    }

    return GOAL_OK;
}


/****************************************************************************/
/** PTP application callback
 *
 * This function is called by the PTP stack to inform the application about
 * special events that might require the application's attention.
 */
void goal_ptpCallback(
    PTP_CB_ID_T cbId,                           /**< callback ID */
    void *pCbData                               /**< callback data */
)
{
    PTP_TIMEPROPERTIES_DS_T *pTimeProperties;   /* timePropertiesDS data set */
    PTP_TIMESTAMP_T *pTs;                       /* new system time */

    switch (cbId) {
        case PTP_CB_TIME_UPDATE:
            /* the local clock was updated by the PTP stack */
            pTs = (PTP_TIMESTAMP_T *) pCbData;
            goal_logInfo("new system time: %"FMT_u64" s %"FMT_u32" ns",
                         pTs->sec, pTs->nsec);
            UNUSEDARG(pTs); /* if logging is disabled */
            break;

        case PTP_CB_GRANDMASTER:
            /* device is grandmaster of this domain, state the properties of
             * its time source (synchronized to it by non-PTP means)
             * pCbData points to a PTP_TIMEPROPERTIES_DS_T struct
             */
            GOAL_MEMCPY(pCbData, (void *) &myTimeProps, sizeof(PTP_TIMEPROPERTIES_DS_T));
            break;

        case PTP_CB_SYNC:
            /* The local clock is synchronized to a master. The application
             * should do all necessary steps to synchronize to the new time and
             * then call ptp_syncFinished().
             */
            ptp_syncFinished();
            break;

        case PTP_CB_UTC_PROP_UPDATE:
            /* a management node requested to change the device's UTC properties,
             * application must determine if the new values are applicable
             */
            pTimeProperties = (PTP_TIMEPROPERTIES_DS_T *) pCbData;
            myTimeProps.utcOffset = pTimeProperties->utcOffset;
            myTimeProps.leap61 = pTimeProperties->leap61;
            myTimeProps.leap59 = pTimeProperties->leap59;
            myTimeProps.utcOffsetValid = pTimeProperties->utcOffsetValid;
            break;

        case PTP_CB_TRACABLE_UPDATE:
            /* a management node requested to change the device's traceability
             * properties, application must determine if the new values are
             * applicable
             */
            pTimeProperties = (PTP_TIMEPROPERTIES_DS_T *) pCbData;
            myTimeProps.timeTracable = pTimeProperties->timeTracable;
            myTimeProps.freqTracable = pTimeProperties->freqTracable;
            break;

        case PTP_CB_TIMESCALE_UPDATE:
            /* a management node requested to change the device's time scale
             * properties, application must determine if the new values are
             * applicable
             */
            pTimeProperties = (PTP_TIMEPROPERTIES_DS_T *) pCbData;
            myTimeProps.ptpTimescale = pTimeProperties->ptpTimescale;
            myTimeProps.timeSrc = pTimeProperties->timeSrc;
            break;

        case PTP_CB_IN_SYNC:
            goal_logInfo("synchronization successful");
            goal_tdmaStart();
            break;

        case PTP_CB_OUT_OF_SYNC:
            goal_logInfo("lost synchronization");
            break;
    }
}


/****************************************************************************/
/** goal dd callback
 *
 */
static GOAL_STATUS_T ddCallback(
    GOAL_DD_T *pHdlDd,                          /**< DD handle */
    GOAL_DD_CB_ID_T cbId,                       /**< callback ID */
    GOAL_DD_CB_DATA_T *pCbData                  /**< callback data */
)
{
    UNUSEDARG(pCbData);
    UNUSEDARG(pHdlDd);

    switch (cbId) {
        case GOAL_DD_CB_ID_WINK:
            break;
        default:
            break;
    }

    return GOAL_OK;
}


/****************************************************************************/
/** Application Setup
 *
 * This function is called by the GOAL init-stage system to open the UDP
 * channel and register the default Ethernet handler.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_ADDR_T addr;                       /* net address */
    GOAL_NET_CHAN_T *pChan;                     /* channel */
    uint32_t optVal;                            /* option value */
    uint8_t tosVal;                             /* TOS value */
    uint32_t ip;                                /* ip */
    uint32_t nm;                                /* netmask */
    uint32_t gw;                                /* gateway */
    GOAL_DD_T *pHdlDd;                          /* dd handle */


    /* initialize time properties, these values are application specific */
    myTimeProps.utcOffset = 33;
    myTimeProps.utcOffsetValid = GOAL_TRUE;
    myTimeProps.leap59 = GOAL_FALSE;
    myTimeProps.leap61 = GOAL_FALSE;
    myTimeProps.timeTracable = GOAL_FALSE;
    myTimeProps.freqTracable = GOAL_FALSE;
    myTimeProps.ptpTimescale = GOAL_TRUE;
    myTimeProps.timeSrc = PTP_TIME_SRC_INTERNAL_OSC;

     /* set IP address */
    ip = MAIN_APPL_IP;
    nm = MAIN_APPL_NM;
    gw = MAIN_APPL_GW;
    res = goal_netIpSet(ip, nm, gw, GOAL_FALSE);
    if (GOAL_OK != res) {
        goal_logErr("failed to set IP address");
        return res;
    }

    /* Init DD */
    res = goal_ddNew(&pHdlDd, GOAL_DD_FEAT_ALL);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error creating dd instance");
    }

    res = goal_ddCustomerIdSet(pHdlDd, GOAL_DD_CUSTOMERID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error configuring customer id");
    }

    res = goal_ddModuleNameSet(pHdlDd, (uint8_t *) GOAL_DD_MODULENAME);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error configuring module name");
    }

    goal_ddCallbackReg(pHdlDd, (GOAL_DD_FUNC_CB_T) ddCallback);

    /* Init TDMA */
    res = goal_tdmaInit();
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error while initializing TDMA scheduler");
    }

    /* register UDP server */
    GOAL_MEMSET(&addr, 0, sizeof(GOAL_NET_ADDR_T));
    addr.localPort = MAIN_APPL_UDP_PORT;
    res = goal_netOpen(&pChan, &addr, GOAL_NET_UDP_SERVER, goal_udpServerCallback);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error while opening UDP server channel on port %"FMT_u32, (uint32_t) MAIN_APPL_UDP_PORT);
        return res;
    }

    /* set UDP channel to non-blocking */
    optVal = 1;
    res = goal_netSetOption(pChan, GOAL_NET_OPTION_NONBLOCK, &optVal);
    if (GOAL_OK != res) {
        goal_logErr("error while setting UDP channel to non-blocking");
        return res;
    }

    /* activate channel */
    res = goal_netActivate(pChan);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error while enabling UDP channel");
        return res;
    }

    /* Set TOS value for channel */
    tosVal = MAIN_APPL_TOS;
    res = goal_netSetOption(pChan, GOAL_NET_OPTION_TOS, &tosVal);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("error while setting TOS value");
        return res;
    }

    /* Register default Ethernet handler */
    res = goal_ethProtoAddPos(GOAL_TRUE, 0, NULL, &goal_applEthCallback, GOAL_TRUE);

    return GOAL_OK;
}


/****************************************************************************/
/** Ethernet Callback
 *
 * This callback is invoked for every received Ethernet frame. It MUST return
 * an error so that the frame is forwarded to the other network stacks such as
 * the TCP/IP stack.
 */
static GOAL_STATUS_T goal_applEthCallback(
    GOAL_BUFFER_T **ppBuf                       /**< Ethernet buffer */
)
{
    uint32_t tsNsec;                            /* PPT Timestamp nsec */
    uint64_t tsSec;                             /* PPT Timestamp sec */

    /* Get the timestamp from PTP */
    tsNsec = (*ppBuf)->tsNsec;
    tsSec = (*ppBuf)->tsSec;

    /*
     * Keep the compiler happy. You may replace the next two lines
     * with the processing code or your choice.
     */
    UNUSEDARG(tsNsec);
    UNUSEDARG(tsSec);

    /* Return an error to forward the frame */
    return GOAL_ERR_NODATA;
}


/****************************************************************************/
/** UDP Server Callback
 *
 * Mirror data back to the sender
 */
static void goal_udpServerCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    GOAL_NET_CHAN_T *pChan,                     /**< channel descriptor */
    GOAL_BUFFER_T *pBuf                         /**< GOAL buffer */
)
{
    UNUSEDARG(cbType);

    /* echo message */
    goal_netSend(pChan, pBuf);
}
