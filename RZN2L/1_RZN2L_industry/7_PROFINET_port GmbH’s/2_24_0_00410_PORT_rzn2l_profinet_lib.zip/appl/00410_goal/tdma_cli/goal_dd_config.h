/** @file
 *
 * @brief Device detection configuration
 *
 * @copyright
 * Copyright 2020.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_DD_CONFIG_H_
#define GOAL_DD_CONFIG_H_

#define GOAL_DD_PORT                    19010
#define GOAL_DD_HOSTNAME                "RZN_TSN_DEMO"
#define GOAL_DD_MODULENAME              "RZN1-D_DEMOBOARD_EB"
#define GOAL_DD_MODULESTATE             0
#define GOAL_DD_CUSTOMERID              0x00000001

#endif /* GOAL_DD_CONFIG_H_ */
