/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic Open
 * Abstraction Layer (GOAL).
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

/* Network config */
#define GOAL_CONFIG_ETHERNET 1
#define GOAL_CONFIG_TCPIP_STACK 1

/* Log config */
#define GOAL_CONFIG_LOGGING 1

/* CLI config */
#define GOAL_CONFIG_CLI_UDP 1
#define GOAL_CONFIG_CLI_UDP_PORT 1234
#define GOAL_CONFIG_CLI_DBG 1
#define GOAL_CONFIG_CLI_HISTORY 1
#define GOAL_CONFIG_CLI_HISTORY_SIZE 10

/* TDMA config */
#define GOAL_CONFIG_TDMA 1

/* PTP config */
#define GOAL_LOG_ID_PTP (1<<0)

#define GOAL_CONFIG_NET_CHAN_MAX 20

#endif /* GOAL_CONFIG_H */
