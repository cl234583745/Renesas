/** @file
 *
 * @brief IGMP Snooping Example
 *
 * This example application basically initializes the board with GOAL
 * running IGMP snooping.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"
#include <protos/igmpsnoop/goal_igmp_snoop.h>


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    /* initialize IGMP snooping */
    return igmpSnoop_initPre(IGMP_SNOOP_VERSION2);
}
