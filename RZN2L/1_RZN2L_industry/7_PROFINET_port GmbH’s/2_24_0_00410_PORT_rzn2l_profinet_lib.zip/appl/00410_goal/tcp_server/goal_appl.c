/** @file
 *
 * @brief Simple TCP Echo Server
 *
 * Note:    This demo application is meant to demonstrate the basic
 *          handling of this feature.
 *          It is not meant for performance benchmarking and it is
 *          not optimized for performance evaluation purposes.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define MAIN_APPL_TCP_PORT      1234
#define MAIN_APPL_IP            GOAL_NET_IPV4(192, 168, 0, 10)
#define MAIN_APPL_NM            GOAL_NET_IPV4(255, 255, 255, 0)
#define MAIN_APPL_GW            GOAL_NET_IPV4(0, 0, 0, 0)


/****************************************************************************/
/* Local prototypes */
/****************************************************************************/
static void tcpCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    struct GOAL_NET_CHAN_T *pChan,              /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
);


/****************************************************************************/
/** Application Setup
 *
 * This function is called by the GOAL init-stage system to open TCP channels.
 *
 * API functions from earlier stages are allowed to be used here.
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_NET_ADDR_T addr;                       /* net address */
    GOAL_NET_CHAN_T *pChan;                     /* channel */
    uint32_t optVal;                            /* option value */
    uint32_t ip;                                /* IP address */
    uint32_t nm;                                /* netmask */
    uint32_t gw;                                /* gateway */
    uint32_t cnt;                               /* counter */

    /* set IP address */
    ip = MAIN_APPL_IP;
    nm = MAIN_APPL_NM;
    gw = MAIN_APPL_GW;
    res = goal_netIpSet(ip, nm, gw, GOAL_FALSE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Set IP failed");
        return res;
    }


    for (cnt = 0; cnt < 3; cnt++) {
        /* register TCP server */
        GOAL_MEMSET(&addr, 0, sizeof(GOAL_NET_ADDR_T));
        addr.localPort = MAIN_APPL_TCP_PORT;
        res = goal_netOpen(&pChan, &addr, GOAL_NET_TCP_LISTENER, tcpCallback);
        if (GOAL_OK != res) {
            goal_logErr("error while opening TCP server channel on port %"FMT_u32, (uint32_t) MAIN_APPL_TCP_PORT);
            return res;
        }

        /* set TCP channel to non-blocking */
        optVal = 1;
        res = goal_netSetOption(pChan, GOAL_NET_OPTION_NONBLOCK, &optVal);
        if (GOAL_OK != res) {
            goal_logErr("error while setting TCP channel to non-blocking");
            return res;
        }
    }

    /* greet */
    goal_logInfo("waiting for TCP connections on port %u", MAIN_APPL_TCP_PORT);

    return GOAL_OK;
}


/****************************************************************************/
/** TCP Server Callback
 *
 * Print a hexdump of the received data.
 */
static void tcpCallback(
    GOAL_NET_CB_TYPE_T cbType,                  /**< callback type */
    struct GOAL_NET_CHAN_T *pChan,              /**< channel descriptor */
    struct GOAL_BUFFER_T *pBuf                  /**< GOAL buffer */
)
{
    GOAL_NET_ADDR_T remote;                     /* remote address */
    GOAL_STATUS_T res;                          /* result */

    if (cbType == GOAL_NET_CB_NEW_SOCKET) {
        goal_logInfo("new TCP socket from TCPListener: %p", (void *) pChan);
    }
    else if (cbType == GOAL_NET_CB_NEW_DATA) {
        goal_logInfo("Data received on tcp socket %p", (void *) pChan);

        /* get IP Address of remote node */
        res = goal_netGetRemoteAddr(pChan, &remote);
        if (GOAL_RES_ERR(res)) {
            goal_logErr("Failed to get Remote Address for socket %p", (void *) pChan);
            return;
        }

        goal_logInfo("sender 0x%08"FMT_x32":%u", remote.remoteIp, remote.remotePort);

        /* echo message */
        goal_netSend(pChan, pBuf);

        /* strip linefeeds and carriage returns */
        while (pBuf->dataLen) {
            if (('\r' == pBuf->ptrData[pBuf->dataLen - 1])
                || ('\n' == pBuf->ptrData[pBuf->dataLen - 1])) {
                pBuf->dataLen--;
                continue;
            }

            pBuf->ptrData[pBuf->dataLen] = 0;
            break;
        }

        /* log message */
        goal_logInfo("TCP message: '%s'", pBuf->ptrData);
    }
    else if (cbType == GOAL_NET_CB_CLOSING) {
        goal_logInfo("Closing TCP socket %p", (void *) pChan);
    }
}
