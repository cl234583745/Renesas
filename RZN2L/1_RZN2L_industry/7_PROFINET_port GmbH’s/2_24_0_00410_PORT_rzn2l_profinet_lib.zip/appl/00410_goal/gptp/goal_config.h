/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic Open
 * Abstraction Layer (GOAL).
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

#define GOAL_CONFIG_LOGGING 1
#define GOAL_CONFIG_ETHERNET 1
#define GOAL_CONFIG_ETH_STATS 1
#define GOAL_CONFIG_TCPIP_STACK 1

#define GOAL_CONFIG_LOGGING_BUFFER_SIZE 4096
/* #define GOAL_CONFIG_LOGGING_TARGET_RAW 1 */
#define GOAL_CONFIG_LOGGING_TARGET_NONBLOCK 1

#define GOAL_LOG_ID_PTP (1<<0)

#define GOAL_CONFIG_NET_CHAN_MAX 20

#endif /* GOAL_CONFIG_H */
