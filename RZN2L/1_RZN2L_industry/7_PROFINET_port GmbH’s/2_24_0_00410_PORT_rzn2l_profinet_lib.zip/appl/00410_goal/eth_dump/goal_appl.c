/** @file
 *
 * @brief Ethernet MAC Address Dump
 *
 * This application prints the src and dst MAC address of all frames
 * received at the R-IN core.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>


/****************************************************************************/
/* GOAL_CONFIG_ETHERNET_DUMP_MAC is set in goal_config.h */
/****************************************************************************/
