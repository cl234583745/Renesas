/** @file
 *
 * @brief Simple GOAL Example
 *
 * This module provides a simple application template using GOAL.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"


/****************************************************************************/
/* GOAL is initialized without Ethernet. No functionality is shown here. */
/****************************************************************************/
