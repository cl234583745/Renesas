/** @file
 *
 * @brief Configuration Management Demonstration
 *
 * This application shows how to use the configuration management.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_APPL_H
#define GOAL_APPL_H

#include <goal_includes.h>


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T appl_cmChg(
    uint32_t modId,                             /**< module ID */
    uint32_t varId,                             /**< variable Id */
    GOAL_CM_VAR_T *pVar                         /**< variable pointer */
);


/****************************************************************************/
/* Configuration Variables Management */
/****************************************************************************/
#define APPL_CM_MOD_ID      0                   /**< CM module ID */
#define APPL_CM_STRING_LEN  20                  /**< CM string length */

#define APPL_CM_VARS \
/*              Name,                Data type,       Max. size,          Validation Cb, Change Cb */   \
    GOAL_CM_VAR(APPL_CM_VAR_UINT8,   GOAL_CM_UINT8,   sizeof(uint8_t),    NULL,          appl_cmChg),   \
    GOAL_CM_VAR(APPL_CM_VAR_UINT16,  GOAL_CM_UINT16,  sizeof(uint16_t),   NULL,          appl_cmChg),   \
    GOAL_CM_VAR(APPL_CM_VAR_UINT32,  GOAL_CM_UINT32,  sizeof(uint32_t),   NULL,          appl_cmChg),   \
    GOAL_CM_VAR(APPL_CM_VAR_GENERIC, GOAL_CM_GENERIC, APPL_CM_STRING_LEN, NULL,          appl_cmChg)

/* generate 'enum APPL_CM_VARS_ID_T' that contains all variable names */
#include <goal_cm_id.h>
GOAL_CM_VAR_IDS(APPL_CM_VARS_ID_T, APPL_CM_VARS);


#endif /* GOAL_APPL_H */
