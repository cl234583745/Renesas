/** @file
 *
 * @brief application template
 *
 * This module provides a simple application template using GOAL.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include "goal_includes.h"


/****************************************************************************/
/** Application Init
 *
 * Initialize required GOAL components like protocols.
 *
 * Note: If the function body is empty the whole function can be removed.
 */
GOAL_STATUS_T appl_init(
    void
)
{
    return GOAL_OK;
}


/****************************************************************************/
/** Application Setup
 *
 * Configure GOAL and components.
 *
 * Note: If the function body is empty the whole function can be removed.
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    return GOAL_OK;
}


/****************************************************************************/
/** Application Loop
 *
 * Perform cyclic application tasks.
 *
 * Note: If the function body is empty the whole function can be removed.
 */
void appl_loop(
    void
)
{
}
