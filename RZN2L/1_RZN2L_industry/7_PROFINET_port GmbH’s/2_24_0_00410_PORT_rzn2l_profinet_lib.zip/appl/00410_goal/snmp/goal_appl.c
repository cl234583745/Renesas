/** @file
 *
 * @brief SNMP example
 *
 * This application demonstrates the initialization and basic usage of
 * the Simple Network Management Protocol (SNMP) with GOAL.
 *
 * @copyright
 * Copyright 2010-2017.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#include <goal_includes.h>
#include <snmp_includes.h>


/****************************************************************************/
/* Local defines */
/****************************************************************************/
#define APPL_SNMP_ID        0
#define APPL_ADDR_IP        GOAL_NET_IPV4(192, 168, 0, 50)
#define APPL_ADDR_NETMASK   GOAL_NET_IPV4(255, 255, 255, 0)
#define APPL_ADDR_GATEWAY   GOAL_NET_IPV4(0, 0, 0, 0)
#define APPL_ADDR_TRAPSINK  GOAL_NET_IPV4(192, 168, 150, 33)


/****************************************************************************/
/* Local variables */
/****************************************************************************/
static char *strReadCommunity = "public";       /**< read community */
static char *strWriteCommunity = "private";     /**< write community */
static GOAL_INSTANCE_SNMP_T *pInstanceSnmp;     /**< GOAL_SNMP handle */


/****************************************************************************/
/** Application Init
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_init(
    void
)
{
    /* init SNMP stack */
    return goal_snmpInit();
}


/****************************************************************************/
/** Application Setup
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T appl_setup(
    void
)
{
    GOAL_STATUS_T res;                          /* result */

    /* set IP parameters */
    res = goal_netIpSet(APPL_ADDR_IP, APPL_ADDR_NETMASK, APPL_ADDR_GATEWAY, GOAL_TRUE);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to set IP address");
        return res;
    }

    /* create new SNMP instance */
    res = goal_snmpNew(&pInstanceSnmp, APPL_SNMP_ID);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("failed to create a new SNMP instance");
        return res;
    }

    /* update SNMP community strings */
    res = goal_snmpCommSet(pInstanceSnmp, strReadCommunity, strWriteCommunity);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to register community strings stack");
        return res;
    }

    /* init trap incl. sending cold start trap */
    res = goal_snmpTrapsInit(pInstanceSnmp, APPL_ADDR_TRAPSINK);
    if (GOAL_RES_ERR(res)) {
        goal_logErr("Failed to init SNMP traps");
        return res;
    }

    return res;
}
