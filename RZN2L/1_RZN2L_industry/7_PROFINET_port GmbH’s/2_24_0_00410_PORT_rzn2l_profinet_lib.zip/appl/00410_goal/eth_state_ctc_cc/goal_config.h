/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic Open
 * Abstraction Layer (GOAL).
 *
 * @copyright
 * Copyright 2010-2018.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

#define GOAL_CONFIG_ETHERNET 1
#define GOAL_CONFIG_ETH_STATS 1
#define GOAL_CONFIG_ETH_STATS_NAMES 1

#define GOAL_CONFIG_LOGGING 1
#define GOAL_CONFIG_LOGGING_TARGET_RAW 1

#endif /* GOAL_CONFIG_H */
