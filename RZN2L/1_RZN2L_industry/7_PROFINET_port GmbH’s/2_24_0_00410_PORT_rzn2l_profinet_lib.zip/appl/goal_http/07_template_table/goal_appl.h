/** @file
 *
 * @brief Http webserver Example
 *
 * This application runs a simple HTTP server that hosts a demo HTML page.
 * It can be accessed via web browser by browsing the IP address of this device.
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
*/
#ifndef GOAL_APPL_H
#define GOAL_APPL_H

#include <goal_includes.h>


/****************************************************************************/
/* Webserver data as defines */
/****************************************************************************/

/** application template list defintion */
typedef struct {
    char name[32];                              /**< list name */
    char value[32];                             /**< value */
    void *sublist;                              /**< pionter to sublist */
} GOAL_APPL_LIST_T;


#endif /* GOAL_APPL_H */
