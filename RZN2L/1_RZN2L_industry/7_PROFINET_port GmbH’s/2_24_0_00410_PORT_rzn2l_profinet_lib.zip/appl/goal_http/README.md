## GOAL HTTPD Example applications

### 01_get

    This example application provides a simple webpage and an application 
    callback showing the handling of a http GET method request.

### 02_post

    This example application provides a simple webpage and an application 
    callback showing the handling of a http POST method request.

### 03_list_res

    This example application adds several resources to the httpd resource 
    manager and uses the system print to print the sorted resource list.

### 04_auth

    This example application shows the usage basic authentication.

### 05_template_cm

    This example shows the usage of webpage templating using CM variables
    and simple application variables. The application callback function is used.
  
### 06_template_list
    
    This example shows the usage of template lists generating an unnumbered list on
    webpage display.
    
### 07_template_table

    This example shows the usage of template lists generating a table on webpage
    display.
