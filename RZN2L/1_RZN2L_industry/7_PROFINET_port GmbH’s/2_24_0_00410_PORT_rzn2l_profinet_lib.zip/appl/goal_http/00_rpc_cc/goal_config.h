/** @file
 *
 * @brief GOAL Configuration File
 *
 * This file controls various components and settings of the Generic OS
 * Abstraction Layer (GOAL).
 *
 * @copyright
 * Copyright 2020 port GmbH Halle/Saale.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */

#ifndef GOAL_CONFIG_H
#define GOAL_CONFIG_H

#define GOAL_CONFIG_TCPIP_STACK 1
#define GOAL_CONFIG_TCPIP_TCP 1

#define GOAL_CONFIG_NET_ADDR_DEFAULT_USE 1

#define GOAL_CONFIG_LOGGING 1
#define GOAL_CONFIG_LOGGING_TARGET_RAW 1


#endif /* GOAL_CONFIG_H */
