/** @file
 *
 * @brief Global Configuration of GOAL
 *
 * This file allows to globally change GOAL default settings without having to
 * modify all applications. No defines must be enabled by default in the
 * repository.
 *
 * @copyright
 * Copyright 2010-2018.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#ifndef GOAL_GLOBAL_H
#define GOAL_GLOBAL_H


/****************************************************************************/
/* Global Settings */
/****************************************************************************/
#define GOAL_GLOB_MA_SPI_ID_0_MODE_3 0          /**< set SPI mode 3 on MA ID 0 */


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
GOAL_STATUS_T goal_globInit(
    void
);


#endif /* GOAL_GLOBAL_H */
