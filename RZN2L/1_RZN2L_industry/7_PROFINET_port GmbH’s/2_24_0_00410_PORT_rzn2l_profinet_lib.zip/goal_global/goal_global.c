/** @file
 *
 * @brief Global Configuration of GOAL
 *
 * This file allows to globally change GOAL default settings without having to
 * modify all applications. No defines must be enabled by default in the
 * repository.
 *
 * @copyright
 * Copyright 2010-2018.
 * This software is protected Intellectual Property and may only be used
 * according to the license agreement.
 */
#include <goal_includes.h>
#if GOAL_GLOB_MA_SPI_ID_0_MODE_3 == 1
#  include <goal_media/goal_ma_spi.h>
#endif


/****************************************************************************/
/* Prototypes */
/****************************************************************************/
#if GOAL_GLOB_MA_SPI_ID_0_MODE_3 == 1
static GOAL_STATUS_T goal_globMaSpiId0Mode3(
    void
);
#endif


/****************************************************************************/
/** Register enabled global configuration functions
 *
 * @returns GOAL_STATUS_T result
 */
GOAL_STATUS_T goal_globInit(
    void
)
{
    GOAL_STATUS_T res = GOAL_OK;                /* result */
    GOAL_STAGE_HANDLER_T *pStage = NULL;        /* stage handler */

    /* compiler fix */
    UNUSEDARG(pStage);
    UNUSEDARG(res);

#if GOAL_GLOB_MA_SPI_ID_0_MODE_3 == 1
    /* initialize/overwrite stage handler */
    pStage = NULL;

    res = goal_memCalloc(&pStage, sizeof(GOAL_STAGE_HANDLER_T));
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:257: */
        goal_lmLog(GOAL_ID_GLOBAL, 257, 208, 0, 0, GOAL_LOG_SEV_ERROR, "failed to allocate stage handle");
        return res;
    }

    res = goal_mainStageReg(GOAL_STAGE_GOAL, pStage, GOAL_STAGE_INIT, goal_globMaSpiId0Mode3);
    if (GOAL_RES_OK(res)) {
        return res;
    }
#endif

    return GOAL_OK;
}


#if GOAL_GLOB_MA_SPI_ID_0_MODE_3 == 1
/****************************************************************************/
/** Global Goal Configuration
 *
 * @returns GOAL_STATUS_T result

 * @result GOAL_STATUS_T result
 */
static GOAL_STATUS_T goal_globMaSpiId0Mode3(
    void
)
{
    GOAL_STATUS_T res;                          /* result */
    GOAL_MA_SPI_T *pHdlMaSpi = NULL;            /* MA handle for SPI */

    res = goal_maSpiGetById(&pHdlMaSpi, 0);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:258: */
        goal_lmLog(GOAL_ID_GLOBAL, 258, 209, 0, 0, GOAL_LOG_SEV_ERROR, "failed to get MA SPI for id 0");
        return res;
    }

    res = goal_maSpiCfgModeSet(pHdlMaSpi, GOAL_MA_SPI_MODE_3);
    if (GOAL_RES_ERR(res)) {
        /* GG_LOG ID:259: */
        goal_lmLog(GOAL_ID_GLOBAL, 259, 210, 0, 0, GOAL_LOG_SEV_ERROR, "failed to set MA SPI 0 mode 3");
        return res;
    }

    /* GG_LOG ID:260: */
    goal_lmLog(GOAL_ID_GLOBAL, 260, 211, 0, 0, GOAL_LOG_SEV_INFO, "successfully set MA SPI 0 mode 3");

    return GOAL_OK;
}
#endif /* GOAL_GLOB_MA_SPI_ID_0_MODE_3 == 1 */
